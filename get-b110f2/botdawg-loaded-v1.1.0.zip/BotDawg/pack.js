/*
 * © 2026 Joshua Dawson — J-Dawgs Industries. All rights reserved.
 *
 * BotDawg™ pack manager — what BotDawg carries in the box, and the
 * one-action reset that takes it back out.
 *
 * BotDawg ships LOADED: the J-Dawgs pack (a tool library in tools/,
 * playbooks in knowledge/, memory pre-structured to hold them) is in
 * the Brain's reach from the first run. The pristine pack lives in
 * pack/jdawgs/ and is never edited in place.
 *
 * The folder convention is the whole interface — for the J-Dawgs
 * pack and for the owner's own load alike:
 *   tools/manifest.json   { "tools": [ { id, name, description,
 *                            file, pack? } ] } — the planner searches
 *                            this by name and description.
 *   tools/<file>          one plain file per tool: what it is, when
 *                            to use it, its method, its output shape.
 *   knowledge/<file>.md   plain playbooks and checklists. The Brain
 *                            sees the index and reads files whole.
 * Drop your own files in the same shape and the Brain can use them
 * the same way — no code, no registry, no permission from J-Dawgs.
 *
 * START CLEAN (one action, console button or `pack clean`): removes
 * the J-Dawgs pack from tools/ and knowledge/, wipes memory and
 * personalization back to the blank fresh-buyer state, and resets
 * the usage meter. What it deliberately KEEPS: the engine, the
 * built-in skills, the nevers, the activity log (with the reset
 * itself recorded), and the owner's model connection + caps — the
 * connection is the owner's own account hookup, not J-Dawgs content,
 * and wiping it would punish the owner for cleaning house.
 * LOAD THE J-DAWGS PACK (`pack load`) restores the pack's tools and
 * knowledge into reach. It does not resurrect wiped memory or
 * personalization — those were the owner's, and the reset said so.
 */
'use strict';

const fs = require('fs');
const path = require('path');
const lib = require('./lib');

const TOOLS_DIR = path.join(lib.ROOT, 'tools');
const KNOW_DIR = path.join(lib.ROOT, 'knowledge');
const PRISTINE = path.join(lib.ROOT, 'pack', 'jdawgs');
const STATE_FILE = path.join(lib.ROOT, 'pack-state.json');
const PACK_TAG = 'jdawgs';
const LIB_DIR = path.join(lib.ROOT, 'pack', 'jdawgs', 'library');

/* The tool library (Loaded edition): pack/jdawgs/library/ holds the
 * store library's own MANIFEST.json plus its module and page files —
 * one pristine copy, which is also the Start clean / Load source.
 * Converted here into active-manifest entries: CALLABLE tools carry
 * kind 'callable' + their module file name; OPEN-ONLY tools with a
 * finished page carry kind 'page' + their page file name. Pending
 * tools (no build exists) and duplicates are NEVER converted — they
 * are not in this edition and are not claimed anywhere. */
function libraryEntries() {
  const m = readJson(path.join(LIB_DIR, 'MANIFEST.json'), { tools: [] });
  const out = [];
  for (const t of (Array.isArray(m.tools) ? m.tools : [])) {
    if (t.classification === 'CALLABLE' && t.module) {
      out.push({ id: t.slug, name: t.name, description: t.description, pack: PACK_TAG, kind: 'callable', module: path.basename(t.module) });
    } else if (t.classification === 'OPEN-ONLY' && t.page) {
      out.push({ id: t.slug, name: t.name, description: t.description, pack: PACK_TAG, kind: 'page', page: path.basename(t.page) });
    }
  }
  return out;
}

function readJson(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; }
}

function loadManifest() {
  const m = readJson(path.join(TOOLS_DIR, 'manifest.json'), { tools: [] });
  return { tools: Array.isArray(m.tools) ? m.tools : [] };
}

function saveManifest(m) {
  fs.mkdirSync(TOOLS_DIR, { recursive: true });
  fs.writeFileSync(path.join(TOOLS_DIR, 'manifest.json'), JSON.stringify(m, null, 2) + '\n');
}

function packState() { return readJson(STATE_FILE, { jdawgs: 'loaded' }); }
function savePackState(s) { fs.writeFileSync(STATE_FILE, JSON.stringify(s, null, 2) + '\n'); }

/* The planner's search: plain keyword scoring over id + name +
 * description. No embeddings, no index files — the manifest is small
 * enough to score whole, and the owner can read exactly what matched. */
function searchPack(query, limit = 12) {
  const words = String(query || '').toLowerCase().split(/[^a-z0-9]+/).filter(w => w.length > 2);
  const scored = loadManifest().tools.map(t => {
    const hay = `${t.id} ${t.name} ${t.description}`.toLowerCase();
    let score = 0;
    for (const w of words) if (hay.includes(w)) score += hay.split(w).length - 1;
    return { tool: t, score };
  }).filter(x => x.score > 0);
  scored.sort((a, b) => b.score - a.score);
  return scored.slice(0, limit).map(x => x.tool);
}

function getPackTool(id) {
  const entry = loadManifest().tools.find(t => t.id === id);
  if (!entry) return null;
  if (entry.kind === 'callable') return { entry, content: null, modulePath: path.join(LIB_DIR, 'tools', entry.module) };
  if (entry.kind === 'page') return { entry, content: null, pagePath: path.join(LIB_DIR, 'pages', entry.page) };
  let content = '';
  try { content = fs.readFileSync(path.join(TOOLS_DIR, entry.file), 'utf8'); } catch { return { entry, content: null }; }
  return { entry, content };
}

function knowledgeIndex() {
  let names = [];
  try { names = fs.readdirSync(KNOW_DIR).filter(f => /\.(md|txt)$/i.test(f)); } catch { return []; }
  return names.map(f => {
    let title = f;
    try {
      const first = fs.readFileSync(path.join(KNOW_DIR, f), 'utf8').split('\n').map(s => s.trim()).find(s => s.length > 3);
      if (first) title = first.replace(/^#+\s*/, '').slice(0, 90);
    } catch { /* keep the file name */ }
    return { file: f, title };
  });
}

function packStatus() {
  const tools = loadManifest().tools;
  return {
    jdawgsLoaded: packState().jdawgs === 'loaded' && tools.some(t => t.pack === PACK_TAG),
    packTools: tools.filter(t => t.pack === PACK_TAG).length,
    ownTools: tools.filter(t => t.pack !== PACK_TAG).length,
    knowledgeFiles: knowledgeIndex().length,
  };
}

/* ---------------- Start clean ---------------- */

function startClean() {
  const manifest = loadManifest();
  const packTools = manifest.tools.filter(t => t.pack === PACK_TAG);
  for (const t of packTools) { if (!t.file) continue; try { fs.rmSync(path.join(TOOLS_DIR, t.file), { force: true }); } catch { /* already gone */ } }
  saveManifest({ tools: manifest.tools.filter(t => t.pack !== PACK_TAG) });

  // Knowledge: the pack's files are the ones with pristine copies.
  let knowRemoved = 0;
  try {
    for (const f of fs.readdirSync(path.join(PRISTINE, 'knowledge'))) {
      const active = path.join(KNOW_DIR, f);
      if (fs.existsSync(active)) { fs.rmSync(active, { force: true }); knowRemoved++; }
    }
  } catch { /* no pristine knowledge */ }

  lib.saveMemory({ facts: [], projects: {}, topicsOff: [] });
  const old = lib.loadCharter();
  const fresh = structuredClone(lib.DEFAULT_CHARTER);
  fresh.model = old.model;   // the owner's own account hookup stays
  fresh.caps = old.caps;     // and their caps stay
  lib.saveCharter(fresh);
  fs.writeFileSync(path.join(lib.ROOT, 'usage.json'), JSON.stringify({ days: {} }, null, 2) + '\n');
  savePackState({ jdawgs: 'clean' });
  lib.audit('pack-start-clean', { packToolsRemoved: packTools.length, knowledgeRemoved: knowRemoved });
  return { ok: true, summary: `Started clean. Removed ${packTools.length} J-Dawgs pack tool(s) and ${knowRemoved} knowledge file(s); memory and personalization are blank again. Kept, on purpose: the engine, the built-in skills, the nevers, the activity log, and your model connection and caps.` };
}

/* ---------------- Load the J-Dawgs pack ---------------- */

function loadJdawgsPack() {
  const pristineManifest = readJson(path.join(PRISTINE, 'tools', 'manifest.json'), { tools: [] });
  fs.mkdirSync(TOOLS_DIR, { recursive: true });
  fs.mkdirSync(KNOW_DIR, { recursive: true });
  let toolsCopied = 0;
  for (const t of pristineManifest.tools) {
    try { fs.copyFileSync(path.join(PRISTINE, 'tools', t.file), path.join(TOOLS_DIR, t.file)); toolsCopied++; } catch { /* missing pristine file */ }
  }
  const manifest = loadManifest();
  const byId = new Map(manifest.tools.map(t => [t.id, t]));
  for (const t of pristineManifest.tools) byId.set(t.id, t);
  const libEntries = libraryEntries();
  for (const t of libEntries) byId.set(t.id, t);
  saveManifest({ tools: [...byId.values()] });

  let knowCopied = 0;
  try {
    for (const f of fs.readdirSync(path.join(PRISTINE, 'knowledge'))) {
      fs.copyFileSync(path.join(PRISTINE, 'knowledge', f), path.join(KNOW_DIR, f));
      knowCopied++;
    }
  } catch { /* no pristine knowledge */ }

  // Memory structure to hold the pack (facts are NOT restored — a
  // wiped memory stays wiped; only the structure comes back).
  const mem = lib.loadMemory();
  mem.projects = mem.projects || {};
  mem.projects['j-dawgs-pack'] = { instructions: 'The J-Dawgs pack is loaded: its tools are in tools/ (see tools/manifest.json) and its playbooks in knowledge/. The Brain can search the manifest and apply pack tools, and read knowledge files whole.' };
  lib.saveMemory(mem);

  savePackState({ jdawgs: 'loaded' });
  lib.audit('pack-loaded', { tools: toolsCopied, knowledge: knowCopied });
  return { ok: true, summary: `J-Dawgs pack loaded: ${toolsCopied + libEntries.length} tool(s) (${libEntries.length} of them from the tool library) and ${knowCopied} knowledge file(s) are in the Brain's reach. Your memory and personalization were left exactly as they are.` };
}

module.exports = { loadManifest, searchPack, getPackTool, knowledgeIndex, packStatus, startClean, loadJdawgsPack, libraryEntries, TOOLS_DIR, KNOW_DIR, LIB_DIR };
