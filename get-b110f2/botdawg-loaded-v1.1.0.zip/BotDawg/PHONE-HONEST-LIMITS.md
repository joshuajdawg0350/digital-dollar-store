# HONEST LIMITS — BotDawg Phone: what it does not do

© 2026 Joshua Dawson — J-Dawgs Industries. All rights reserved.

BotDawg Phone is the tap-and-use edition of BotDawg: one file that
opens in your phone's browser. No install, no account, no server.
It does the jobs that honestly work on a phone — and only those.
Here is the plain list of what it does NOT do, so nothing surprises
you.

## Jobs the phone version does not have

- **No watching pages.** The desktop BotDawg can watch a web page
  and tell you when it changes. The phone version cannot — a phone
  browser will not let one page read other pages, and BotDawg will
  not pretend otherwise. Ask it to watch a page and it says so
  plainly and points you to the desktop version.
- **No research runs.** Research means reading source pages you
  name. The phone version cannot fetch pages, so it does not offer
  research.
- **No folder organizing.** Organizing means cataloging folders on
  a computer and reporting duplicates. A phone browser cannot see
  your folders, so that job is desktop-only.
- **No proof-runs.** Checking a product page end to end (links,
  price, claims) needs the desktop version's browser checks.
- **No human-check clicking.** The desktop BotDawg can — only with
  your permission switched on — click a "Verify you are human"
  checkbox on a page you send it to. The phone version never does
  this. There is no such switch in it.

## How it runs — the limits of one file on a phone

- **It works when it is open.** BotDawg Phone runs while the page
  is open in your browser. It does not run in the background, it
  has no schedules, and nothing happens while it is closed. It
  says so rather than pretending to be always on.
- **Built-in mode only.** The desktop version can think through a
  model account of your own if you connect one. The phone version
  has no model hookup: writing is done with built-in templates and
  the facts you teach it, and every draft is labeled that way.
  Questions it cannot answer from what it remembers get an honest
  "I will not fake an answer" — never an invented one.
- **Everything stays on this phone.** Your setup, facts, drafts,
  usage meter, activity log, and chat history are kept in this
  page's storage on this phone only. They do not sync anywhere,
  and the desktop BotDawg does not see them. Clear the browser's
  site data and they are gone.
- **Save the file on your phone.** Opened from your phone's own
  files, BotDawg Phone works with no signal at all. If you open it
  from a web link instead, whether it reopens offline is up to
  your browser's cache — save the file to be sure.
- **Finished work lives in the page.** Drafts, prepared messages,
  prompt sets, and websites are saved under "Finished work" in
  the page, with a Copy button. There are no files in a folder
  like the desktop version has.
- **Websites are one page, and never hosted by BotDawg.** The
  phone version builds the same one-page website the desktop
  version does (new in v1.1.0): a single HTML file from your
  facts, gaps marked [fill-in], no online store, no checkout.
  Copy it out of Finished work, open it in a browser, or hand it
  to a host — BotDawg does not host, post, or upload it.

## What it will never do, by design — same as desktop

- It does **not** send, post, buy, pay, delete, or log in as you.
  Ask in chat and it refuses in plain words — and, where a draft
  is the useful thing, prepares the draft instead. You read it,
  you send it, with your own hand.
- It does **not** invent facts, prices, or results. It answers
  from what you taught it and says plainly when something is not
  in what it knows.
- It never asks for or stores your passwords. There is nothing to
  log in to — it is one file, and it is yours.

## No Brain on the phone — plainly

- The phone version has **no Brain**. Open-ended Brain jobs —
  the kind your own connected model plans step by step — are
  **desktop-only**. On the phone, BotDawg runs its built-in
  skills (chat, drafts, messages, sharpen, memory,
  personalization, one-page websites) and says plainly when a
  job needs the desktop Brain. There is no phone Brain parity
  and nothing here pretends there is.
