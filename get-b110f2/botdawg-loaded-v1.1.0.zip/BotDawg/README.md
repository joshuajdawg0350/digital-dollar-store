# BotDawg™ — a general-purpose agent that is YOURS

© 2026 Joshua Dawson — J-Dawgs Industries. All rights reserved.

**Big dreams for a small world.**

BotDawg is a general-purpose agent you own outright. It runs entirely on
your computer, out of this one folder. Unbox it, make it yours on one
screen, and it works — it never comes back to J-Dawgs for anything. Its
memory is a file in this folder. Its planning loop is in this folder. Its
built-in Prompt Generator is in this folder. And when you give it a model
(your own account, your own key), it thinks through YOUR model — never
ours. No J-Dawgs server, account, or permission is needed for BotDawg to
work, ever.

**Two versions in this package — computer and phone.** Everything
below describes the computer version, which lives in this folder and
does everything. The phone version is in here too: one single file,
`botdawg-phone.html`. Put it on your phone and open it in the phone's
browser (or open it from a link) and BotDawg is right there — chat,
drafts, prepared messages, prompt sharpening, memory, and
personalization, no install and no computer needed. It does not do
everything the computer version does; **PHONE-HONEST-LIMITS.md**
states plainly what it leaves out. Use either one, or both — each
keeps its own memory on its own device, and the two do not sync with
each other.

## What it does

- **Plans and runs multi-step work.** Say the job in plain words; BotDawg
  shows its plan and the estimated cost first, then runs it step by step,
  checking its own work as it goes. Pause it and it picks up exactly
  where it stopped — no work is lost.
- **Proof-runs product pages** (its starter specialty): give it a product
  page and the seller's own stated facts, and it checks the door for
  real — answers, says what the seller says, price matches, buy link
  works, loads in a real browser — and writes a sealed record: PASS /
  FAIL / UNCHECKED, hits and misses both.
- **Watches pages** and tells you what changed, line by line.
- **Researches questions** from sources you point it at. Every fact in
  the brief carries its source number; sources it could not open are
  listed as COULD NOT VERIFY.
- **Writes drafts in your voice** — emails, posts, pages, notes — from
  the facts it remembers. Drafts only.
- **Organizes folders**: a full catalog and an exact-duplicate report.
  It never moves or deletes anything.
- **Prepares messages** with a before-you-send checklist. It never sends.
- **Remembers your facts** across sessions — in a plain file you can
  open, edit, or delete. You can ban whole topics from its memory.
- **Sharpens rough requests** with its built-in J-Dawgs Prompt
  Generator: your words in, three ready prompts out (Straight, Detailed,
  Short), filled with what it remembers about your business. Slots it
  cannot fill stay marked [fill-in] — it never guesses.
- **Teaches itself your routines**: show it the steps once, save them as
  a personal skill, run them any time.
- **Talks with you in a chat box** (new in v1.0.2): the console
  carries a chat panel with BotDawg's head on it. Ask a question in
  plain words, or hand it a job the same way — chat runs through the
  same planner, run loop, estimate, caps, permissions, and audit log
  as the work boxes, and its answers speak in the name and voice you
  gave it. It is a local chat on your own screen, not a messaging
  channel: nothing is texted, posted, or sent anywhere.
- **Clicks a "Verify you are human" checkbox — only with your
  permission** (new in v1.0.1). The human-check skill is OFF by
  default. Switch it on (one tick on the console screen) and BotDawg
  may click that one checkbox on a page you send it to, then confirm
  the check really cleared before it reports success. It solves no
  puzzles, it does not pretend to be a person, some sites may still
  refuse it — and every use is in the activity log.
- **Runs on schedule** while it is on: standing watches and jobs in
  `schedules.json`, plus any task file dropped in `inbox/`.
- **Builds a one-page website**: say "build me a
  website" and BotDawg makes one complete website page — a single
  HTML file you can open in any browser and hand to any host — from
  what it knows about your business: your name, your offerings, your
  contact facts, your brand color. Anything it doesn't know stays
  marked [fill-in]; it never invents services, prices, or claims.
  One page only in built-in mode — no online store, no checkout —
  and BotDawg does not host or post it; putting it online is your
  step.
- **The Brain — any job in plain words (with your model connected).**
  The skills above are the jobs BotDawg knows by name. Connect your
  own model (setup step one, below) and the Brain turns on: a job
  that matches no skill is planned by YOUR model into steps, shown
  to you with an estimate before it runs, then executed locally, one
  step at a time — write a file, read a file, draft, sharpen,
  remember, fetch a public page, list a folder, apply a pack tool —
  with your model checking each step's result before the next one.
  That is the difference between a secretary and an AI: the skill
  list is the floor, not the ceiling. With no model connected,
  BotDawg runs in **built-in mode** — skills and templates, labeled
  as such — and open-ended jobs say UNABLE in plain words.
- **Ships loaded — and rewritable to clean.** This **Loaded** edition arrives with
  the full J-Dawgs load in the box: the tool library — **400 tools
  the Brain runs headlessly** plus **417 more as full pages** it can
  hand you to open (reference material, never run headlessly) —
  searched from `tools/manifest.json`, plus playbooks in
  `knowledge/`. 76 cataloged store tools have no finished build;
  they are not in this box and are not claimed. One action on the console — **Start clean** — removes
  the pack and blanks memory and personalization; **Load the J-Dawgs
  pack** puts it back. Your own tools and knowledge drop into the
  same two folders in the same shape, and the Brain uses them the
  same way. What ships in the box is the tools, the methods, the
  memory structure, and the engine; the raw intelligence is your
  connected model.

## What it costs you in work — always in the open

Every task shows a **cost estimate before it runs**, in plain work
units. What a step costs depends on the job: sharpening a request is
1 unit; writing a draft or preparing a message is 2; building a website is 4; watching a page
is 2; organizing a folder is 1 plus 1 per 50 files (or part of 50);
research is 1 plus 1 per source actually read; a proof run is 6; a
human check is 3 when it clicks and clears, 1 when the page has no
check to clear (or it is already cleared), and 0 when it is not
allowed. When your own model does the writing or the thinking, its
use adds 1 unit per 1,000 tokens. A **live meter** counts units as
work happens. **You set hard caps** per
task and per day; BotDawg stops at the cap and says so. **A task that
fails or is stopped is charged 0 units** — the attempt is logged and
marked free. One stated exception: a **Brain run** charges for the
model use it actually made (metered per 1,000 tokens) plus the steps
it actually completed — your model's work is real spend on your own
account the moment it happens, and a cap-stopped Brain run reports
exactly what got done and what it cost. The full ledger is in `usage.json`, and every action ever
taken is in `audit.jsonl`, in plain words. No opaque credits, ever.

## What it does NOT do — honest limits

- It does **not** send, post, buy, pay, delete, or log in as you.
  Consequences stay with the owner. It never asks for your passwords.
- It does **not** invent search results, facts, or prices. Jobs outside
  its skills print UNABLE in plain words instead of a fake success —
  unless your model is connected, in which case the Brain plans them
  (see above). The nevers hold under the Brain exactly as everywhere
  else: no send/post/buy/pay/delete/log-in tool exists for the model
  to plan with, and a plan step asking for one is refused by the
  engine, in the open.
- Without a model set up, writing and research run in built-in mode
  (templates and extracts) and say so on every output. Connect your own
  model on the setup screen for full drafting and synthesis.
- Its browser check needs a browser engine: run `npm install playwright`
  in this folder once (or point `BOTDAWG_PLAYWRIGHT` at an install).
  Without one, that one check prints UNCHECKED — never a guessed pass.
- Scheduled work runs while BotDawg is running on your computer
  (`node botdawg.js serve`). It does not run while your computer is off,
  and it says so.
- No voice, no phone calls, no chat-app channels in v1. The chat box
  (v1.1.0) sits on the console screen, on your computer only — it is
  not a texting or messaging-app channel, and it reaches no one but
  you. One screen, one folder, plain files.

## Quick start

```
node botdawg.js setup        # creates your settings file
node botdawg.js console      # the one screen: setup + work + memory + meter
node botdawg.js ask "Watch https://example.com/prices for changes"
node botdawg.js brief        # your morning brief
```

## Make it yours (no code)

Open the console and fill in one screen: its **name**, **your business**,
its **voice** (plain / warm / formal), your **brand color**, the **facts**
it should always know, its **job focus**, your **model** (optional), and
your **usage caps**. Everything BotDawg produces — reports, drafts,
briefs — comes out in your name, your voice, your color.

Starter templates live in `templates/`, shaped by the jobs buyers ask
for most: proof-run a product door, watch a price page, a research
brief, follow-up drafts.

## Your data

Everything is plain files in this folder: `charter.json` (who it is),
`memory.json` (what it knows), `usage.json` (what work cost),
`audit.jsonl` (everything it did), `chat-history.json` (what you and
it said in the chat box), `out/` (everything it made).
Export = copy the folder. Delete = delete the folder. Your data is
never used to train anything, and none of it ever leaves your computer
except the public pages you tell it to read and your own model endpoint,
if you set one up.
