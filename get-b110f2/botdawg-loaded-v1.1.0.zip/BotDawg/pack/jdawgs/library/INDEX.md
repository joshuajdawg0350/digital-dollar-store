# BotDawg Tool Library Pack — Index

Built 2026-11-24 from the AI Tool Store's own records: the store catalog inside the
AI Tool Store artifact, the J-Dawgs Agent Exchange catalog (689 listings), the
tool-builder log (626 build records), and the local artifact library that holds
every tool's page.

## Counts

| Class | Count | What it means |
|---|---|---|
| Cataloged | 893 | Every distinct tool found across the store's records, deduplicated |
| **CALLABLE** | **400** | Headless modules in `tools/` — BotDawg calls them directly, inputs in, results out. Every one was loaded and run with a real input in this build (see TEST-RESULTS.md) |
| OPEN-ONLY with page | 417 | Interactive/visual tools; the full working page ships in `pages/` and BotDawg hands it to the buyer |
| OPEN-ONLY pending | 76 | Listed in store records but no finished local build exists to copy or extract yet |
| SKIP (duplicates) | 26 | Duplicate catalog listings and duplicate artifact-directory name variants; each is recorded in MANIFEST.json with its reason, none silently dropped |

## The honest headline

**BotDawg ships with 400 working tools inside** — callable headlessly, each one
test-proven in this pack — **plus the full working pages of 417 more tools** it can
hand the buyer, for 817 usable tools out of the 893 the store has ever cataloged.
The remaining 76 are names in store records with no finished build behind them yet;
they are marked pending in the manifest, not counted, and not claimed.

## Files

- `MANIFEST.json` — every tool: slug, name, one-line description, store price
  (record only), category/family where known, classification, and for open-only
  tools the reason.
- `tools/<slug>.js` — the 400 callable cores, one uniform contract (see PACK-NOTES.md).
- `pages/<slug>.html` — the 421 open-only tool pages, copied byte-for-byte from the
  artifact library.
- `TEST-RESULTS.md` — the test input and result for every callable module, plus the
  failure record for the 88 extracted cores that did not pass and were reclassified.
- `PACK-NOTES.md` — how the pack loads, sizes, and the families that dominate.
- `work/` — the build machinery (catalog merge, extractor, test harness) and its raw
  results, kept for provenance and reruns.
