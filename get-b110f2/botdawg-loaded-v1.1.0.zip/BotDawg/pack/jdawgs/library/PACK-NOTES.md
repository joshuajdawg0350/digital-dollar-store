# Pack notes — BotDawg Tool Library Pack

## How the pack loads (for the Brain crew)

- The Brain planner reads `MANIFEST.json` once at startup and indexes `tools` by
  slug, name, description and family. Search = match the job's words against
  name + description + family; the manifest is the single source of truth — a tool
  that is not in the manifest does not exist to BotDawg.
- CALLABLE entries carry `module: "tools/<slug>.js"`. The module contract is exactly:
  `module.exports = { id, name, description, inputSpec, run(input) -> { ok, output, summary } }`.
  `run` is synchronous in every shipped module (the Brain may still `await` it safely).
  Input convention: `input.text` is the primary text the tool works on (a config file,
  listing, transcript, document — the tool's own `inputSpec` says which). Multi-part
  tools (e.g. quote-vs-invoice consistency auditors) also accept their named parts as
  extra string fields on `input`; the module's internal adapter tries the call shapes
  in order, so the planner can pass `{ text, ...parts }` uniformly.
  `_raw` on the result is the tool's own structured verdict object (findings, counts)
  when it produces one — the planner can quote exact findings from it.
  `__examples` on each module holds the tool's own shipped worked examples, useful as
  few-shot context or smoke tests; it is not part of the contract.
- OPEN-ONLY entries carry `page: "pages/<slug>.html"` (or `null` when pending).
  BotDawg's move for these: tell the buyer what the tool does and open/copy the page
  for them — never claim to have run it headlessly.
- SKIP entries are duplicates only; the planner ignores them.
- Prices in the manifest are store record-keeping only. Inside BotDawg the tools are
  the owner's; no per-use charge logic lives in this pack.

## How the callable cores were made

The store's tools are single-file web pages whose pure logic (parsers + an audit /
auditConfig / analyze entry function) sits in front of the page's DOM wiring. For
each tool, the extractor took that pure-logic section verbatim from the tool's own
page and wrapped it in the contract above; the only new code is the wrapper, a set of
headless DOM stubs (some tools capture page handles at load; the audit path never
uses them), and a call-shape adapter. Where a page's logic could not be separated
cleanly, the tool stayed OPEN-ONLY — nothing was re-implemented by guesswork.

Every extracted core was then tested for real: loaded in Node and run with the tool's
own shipped RISKY/HARDENED worked examples where the page carries them (risky must
produce findings; hardened must produce no blockers), otherwise one of its shipped
examples, otherwise a generic probe input. 488 cores were extracted; 400 passed and
ship as CALLABLE; 88 failed (wrong input shape for multi-part tools, helpers living
in the wiring section, entry points that returned nothing) and were reclassified
OPEN-ONLY with their failure recorded in TEST-RESULTS.md. Their modules were deleted
— the pack never ships a callable that failed its test.

## Sizes

| Part | Size |
|---|---|
| `tools/` — 400 callable modules | 11,105,330 bytes (~10.6 MiB) |
| `pages/` — 417 open-only pages | 40,563,503 bytes (~38.7 MiB) |
| `MANIFEST.json` + docs | ~1 MB |
| Pack total on disk | ~54 MB |

The page weight is the tools' own single-file builds (some embed large reference
data — e.g. the Cron Explainer's page is ~9.9 MB). Callable modules are lean by
comparison because only the logic section is carried.

## Families that dominate the catalog

| Family | Cataloged | Callable |
|---|---|---|
| Server config safety auditors (Nextcloud, Gitea, PostgreSQL, …) | 318 | 273 |
| Other auditors (agent traces, listings, documents, processes) | 237 | 71 |
| Consistency auditors (proposal/quote vs final invoice, trade & install jobs) | 155 | 34 |
| Checkers | 35 | 6 |
| Converters, planners, forges, explainers, misc | 140 | 16 |
| Voiceproofing | 8 | 0 |

The store's center of gravity is audit work: 710 of 893 cataloged tools are auditors
of some kind. The config-safety family extracts best because those pages share the
most regular structure; the consistency auditors are the biggest callable gap —
many take two or three documents at once and their entry points expect shapes the
generic adapter could not satisfy. They are the first family to hand-port in a
follow-up run, followed by the flagship free tools (Data Converter, Cron Explainer,
Regex Tester — all OPEN-ONLY here because their pages are large, heavily
interactive builds; the Cron Explainer's page alone is ~9.9 MB).

## Honest edges

- 76 cataloged tools have no finished local build (store records list them; the
  artifact library has no page). They are OPEN-ONLY pending in the manifest and are
  not in the headline number.
- 143 catalog entries come only from the builder log or the local library (built,
  not yet wired into the store/Exchange listings when this pack was made). They are
  real builds with real pages and are included, with their sources named per entry.
- Catalog sources occasionally disagree on price for the same tool; the manifest
  keeps the Exchange price where present, else the builder-log price, and names its
  sources per entry so any conflict can be traced.
