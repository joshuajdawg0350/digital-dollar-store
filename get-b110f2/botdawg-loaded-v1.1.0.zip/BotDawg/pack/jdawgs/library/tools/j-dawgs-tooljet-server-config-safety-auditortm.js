'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs ToolJet Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var HARDENED_TEXT = [
          "TOOLJET_HOST=https://tooljet.example.com",
          "LOCKBOX_MASTER_KEY=a7f3c9e2b841d6f0a9c2e7b4d8f1a3c6e9b2d5f8a1c4e7b0d3f6a9c2e5b8d1f4",
          "SECRET_KEY_BASE=f4e8b2c6a0d3f7a1c5e9b3d7f1a5c9e3b7d1f5a9c3e7b1d5f9a3c7e1b5d9f3a7",
          "PG_HOST=db.internal.example.com",
          "PG_USER=tooljet",
          "PG_DB=tooljet_prod",
          "ORM_TYPE=postgres",
          "TOOLJET_DB=tooljet",
          "PGRST_HOST=https://pgrst.internal.example.com",
          "SSO_GOOGLE_OAUTH2_CLIENT_ID=1234567890-abc.apps.googleusercontent.com",
          "DISABLE_SIGNUP=true",
          "COMMENT_FEATURE_ENABLE=false",
          "ENABLE_PRIVATE_APP_EMBED=false"
        ].join("\n");

        var KNOWN_KEYS = {
          TOOLJET_HOST:1, LOCKBOX_MASTER_KEY:1, SECRET_KEY_BASE:1,
          PG_HOST:1, PG_USER:1, PG_PASS:1, PG_DB:1, PG_PORT:1,
          ORM_TYPE:1, TOOLJET_DB:1, TOOLJET_DB_HOST:1, TOOLJET_DB_USER:1, TOOLJET_DB_PASS:1, TOOLJET_DB_NAME:1,
          PGRST_HOST:1, PGRST_PORT:1,
          SSO_GOOGLE_OAUTH2_CLIENT_ID:1, SSO_GOOGLE_OAUTH2_CLIENT_SECRET:1,
          DISABLE_SIGNUP:1, ENABLE_PRIVATE_APP_EMBED:1, COMMENT_FEATURE_ENABLE:1,
          NODE_ENV:1, PORT:1, SERVER_HOST:1, DATABASE_URL:1
        };
        var PLACEHOLDER_TOKENS = ["changeme","change-me","change_me","change-me-please",
          "your-secret","your_secret","yoursecret","your-key","example","placeholder",
          "defaultsecret","default-secret","letmein","todo-change","insert-secret"];
        var MASTER_KEYS = ["LOCKBOX_MASTER_KEY","SECRET_KEY_BASE"];

        function isPlaceholder(v){
          var lower = v.toLowerCase();
          if (lower === "secret") return true;
          for (var i=0;i<PLACEHOLDER_TOKENS.length;i++){
            if (lower.indexOf(PLACEHOLDER_TOKENS[i]) !== -1) return true;
          }
          if (/^(.)\1+$/.test(v)) return true; /* aaaa…, ****…, xxxx… */
          return false;
        }
        function isTrueVal(v){
          var l = v.trim().toLowerCase();
          return l==="true"||l==="1"||l==="yes"||l==="on";
        }
        function stripQuotes(v){
          if (v.length>=2){
            var a=v.charAt(0), b=v.charAt(v.length-1);
            if ((a==='"'&&b==='"')||(a==="'"&&b==="'")) return v.slice(1,-1);
          }
          return v;
        }
        function hostnameOf(v){
          var m = /^[a-z][a-z0-9+.-]*:\/\/([^\/:?#]+)/i.exec(v);
          if (m) return m[1].toLowerCase();
          var bare = v.split("/")[0].split(":")[0];
          return bare ? bare.toLowerCase() : "";
        }
        function isLocalHost(h){
          return h==="localhost"||h==="127.0.0.1"||h==="::1"||h==="[::1]"||/\.local$/.test(h);
        }

        function parseConfig(text){
          var rawLines = String(text==null?"":text).split(/\r?\n/);
          var entries = [], notParsed = [], occurrences = {};
          for (var i=0;i<rawLines.length;i++){
            var lineNo = i+1;
            var trimmed = rawLines[i].trim();
            if (trimmed==="") continue;
            if (trimmed.charAt(0)==="#") continue;
            var work = trimmed;
            if (work.indexOf("export ")===0) work = work.slice(7).trim();
            var eq = work.indexOf("=");
            if (eq<=0){ notParsed.push(lineNo); continue; }
            var key = work.slice(0,eq).trim();
            if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(key)){ notParsed.push(lineNo); continue; }
            key = key.toUpperCase();
            var value = stripQuotes(work.slice(eq+1).trim());
            var entry = { key:key, line:lineNo, value:value, length:value.length };
            entries.push(entry);
            if (!occurrences[key]) occurrences[key]=[];
            occurrences[key].push(entry);
          }
          var effective = {};
          entries.forEach(function(e){ effective[e.key]=e; }); /* last value wins */
          return { rawLines:rawLines, entries:entries, notParsed:notParsed,
                   occurrences:occurrences, effective:effective };
        }

        function auditConfig(text){
          var parsed = parseConfig(text);
          var findings = [];
          function add(sev, code, key, line, lines, length, message){
            findings.push({ severity:sev, code:code, key:key||null,
              line:(typeof line==="number"?line:null),
              lines:(lines&&lines.length?lines.slice():null),
              length:(typeof length==="number"?length:null),
              message:message });
          }

          var recognized = 0, seenRec = {};
          parsed.entries.forEach(function(e){
            if (KNOWN_KEYS[e.key] || /^(TOOLJET|PG_|PGRST|SSO_|LOCKBOX)/.test(e.key)){
              if (!seenRec[e.key]){ seenRec[e.key]=1; recognized++; }
            }
          });

          parsed.notParsed.forEach(function(ln){
            add("INFO","NOT_PARSED",null,ln,null,null,
              "Line "+ln+" could not be parsed as a KEY=value line. It is reported as NOT PARSED and was not guessed at.");
          });

          if (parsed.entries.length===0 || recognized===0){
            return { verdict:"NOT ENOUGH TO GRADE", findings:findings, parsed:parsed,
                     recognized:recognized,
                     note:"The paste is empty, prose, or contains no recognizable ToolJet keys, so there is nothing to grade." };
          }

          var eff = parsed.effective;

          /* --- Host / transport --- */
          var hostEntry = eff["TOOLJET_HOST"] || null;
          var hostName = hostEntry ? hostnameOf(hostEntry.value) : "";
          var hostIsLocal = hostName ? isLocalHost(hostName) : false;
          var hostIsPublic = !!hostEntry && !!hostName && !hostIsLocal;
          if (!hostEntry){
            add("WARNING","HOST_MISSING","TOOLJET_HOST",null,null,null,
              "TOOLJET_HOST is not set in the pasted text, so transport and public exposure cannot be verified.");
          } else if (/^http:\/\//i.test(hostEntry.value) && !hostIsLocal){
            add("HIGH","HOST_PLAINTEXT_HTTP","TOOLJET_HOST",hostEntry.line,null,null,
              "TOOLJET_HOST uses http:// on a non-localhost host ("+hostName+"), so traffic — including logins and session cookies — crosses the network unencrypted. Serve it over https:// instead.");
          }

          /* --- Master secrets: BLOCKER --- */
          MASTER_KEYS.forEach(function(k){
            var e = eff[k];
            if (!e){
              add("BLOCKER","MASTER_KEY_MISSING",k,null,null,null,
                k+" is missing from the pasted config. ToolJet needs a strong value for this key; a missing one means data encrypted with it is unprotected or unreadable.");
              return;
            }
            var reasons = [];
            if (isPlaceholder(e.value)) reasons.push("it is an example/placeholder value");
            if (e.length < 32) reasons.push("it is only "+e.length+" characters long (minimum 32)");
            if (reasons.length){
              add("BLOCKER","MASTER_KEY_WEAK",k,e.line,null,e.length,
                k+" is not deployable: "+reasons.join(" and ")+". The value itself is never shown — key, line, and length only. Replace it with a unique random secret of at least 32 characters.");
            }
          });

          /* --- Database passwords: HIGH --- */
          var pgPass = eff["PG_PASS"];
          if (pgPass && pgPass.length>0){
            add("HIGH","DB_PASSWORD_PLAINTEXT","PG_PASS",pgPass.line,null,pgPass.length,
              "PG_PASS carries a database password in plaintext in the pasted config (length "+pgPass.length+" characters; the value is never shown). Inject it from a secret store or environment vault instead of keeping it in a config file.");
          }
          parsed.entries.forEach(function(e){
            if (e.key==="PG_PASS") return;
            var m = /:\/\/(?:[^:\s\/@]+):([^@\s\/]+)@/.exec(e.value);
            if (m){
              add("HIGH","PASSWORD_IN_URL",e.key,e.line,null,m[1].length,
                e.key+" embeds a password inside a URL on this line (password length "+m[1].length+" characters; the value is never shown). Move the credential out of the URL and into a secret reference.");
            }
          });

          /* --- SSO client secrets: HIGH --- */
          Object.keys(eff).forEach(function(k){
            if (MASTER_KEYS.indexOf(k)!==-1 || k==="PG_PASS") return;
            var isSsoSecret = /CLIENT_SECRET$/.test(k) || (k.indexOf("SSO")===0 && k.indexOf("SECRET")!==-1);
            if (isSsoSecret){
              var e = eff[k];
              if (e.length>0){
                add("HIGH","SSO_SECRET_PLAINTEXT",k,e.line,null,e.length,
                  k+" is an SSO client secret present in plaintext in the pasted config (length "+e.length+" characters; the value is never shown). Keep client secrets in a secret store, not in a shareable config file.");
              }
            }
          });

          /* --- Open signup: WARNING --- */
          var ds = eff["DISABLE_SIGNUP"];
          if (hostIsPublic){
            if (!ds){
              add("WARNING","OPEN_SIGNUP_ABSENT","DISABLE_SIGNUP",null,null,null,
                "DISABLE_SIGNUP is absent while TOOLJET_HOST is a public host, so anyone who can reach the server can create an account. Set DISABLE_SIGNUP=true for a public deployment.");
            } else if (!isTrueVal(ds.value)){
              add("WARNING","OPEN_SIGNUP_ENABLED","DISABLE_SIGNUP",ds.line,null,null,
                "DISABLE_SIGNUP is not set to true while TOOLJET_HOST is a public host, so self-service signup is open. Set DISABLE_SIGNUP=true for a public deployment.");
            }
          }

          /* --- Comment / debug flags in production posture: WARNING --- */
          var cf = eff["COMMENT_FEATURE_ENABLE"];
          if (cf && isTrueVal(cf.value) && hostIsPublic){
            add("WARNING","COMMENTS_ENABLED_PUBLIC","COMMENT_FEATURE_ENABLE",cf.line,null,null,
              "COMMENT_FEATURE_ENABLE is enabled while the host is public. If this deployment does not need in-app comments for outside users, turn it off for production.");
          }
          Object.keys(eff).forEach(function(k){
            if (k.indexOf("DEBUG")!==-1 && isTrueVal(eff[k].value)){
              add("WARNING","DEBUG_ENABLED",k,eff[k].line,null,null,
                k+" is enabled. Debug flags should be off in a production deployment.");
            }
          });

          /* --- Duplicate keys: WARNING --- */
          Object.keys(parsed.occurrences).forEach(function(k){
            var occ = parsed.occurrences[k];
            if (occ.length>1){
              var lines = occ.map(function(o){return o.line;});
              var last = lines[lines.length-1];
              add("WARNING","DUPLICATE_KEY",k,lines[0],lines,null,
                k+" is defined "+occ.length+" times, on lines "+lines.join(" and ")+". The last value wins — line "+last+" is the one in effect — so the earlier definition is dead text that can mislead a reviewer.");
            }
          });

          var sevRank = { BLOCKER:0, HIGH:1, WARNING:2, INFO:3 };
          findings.sort(function(a,b){
            if (sevRank[a.severity]!==sevRank[b.severity]) return sevRank[a.severity]-sevRank[b.severity];
            var la = a.line==null?99999:a.line, lb = b.line==null?99999:b.line;
            return la-lb;
          });

          var hasBlocker = findings.some(function(f){return f.severity==="BLOCKER";});
          var hasHigh = findings.some(function(f){return f.severity==="HIGH";});
          var hasOther = findings.length>0;
          var verdict, note;
          if (hasBlocker || hasHigh){
            verdict = "DO NOT DEPLOY";
            note = "At least one BLOCKER or HIGH finding must be fixed before this config goes anywhere near a server.";
          } else if (hasOther){
            verdict = "DEPLOY WITH FIXES";
            note = "No BLOCKER or HIGH findings, but warnings or unparsed lines remain. Fix them, then re-audit.";
          } else {
            verdict = "SAFE TO DEPLOY";
            note = "No BLOCKER, HIGH, WARNING, or INFO findings in the pasted text.";
          }
          return { verdict:verdict, findings:findings, parsed:parsed, recognized:recognized, note:note };
        }

        function countsOf(result){
          var c = { BLOCKER:0, HIGH:0, WARNING:0, INFO:0 };
          result.findings.forEach(function(f){ c[f.severity]++; });
          return c;
        }
        function locText(f){
          if (f.lines && f.lines.length) return "lines "+f.lines.join(", ");
          if (typeof f.line==="number") return "line "+f.line;
          return "no line (missing)";
        }
        function buildReport(result){
          var c = countsOf(result);
          var out = [];
          out.push("J-Dawgs ToolJet Server Config Safety Auditor — audit report");
          out.push("Verdict: "+result.verdict);
          out.push("Lines read: "+result.parsed.rawLines.length+" | Keys read: "+result.parsed.entries.length+
                   " | Recognizable ToolJet keys: "+result.recognized);
          out.push("Counts: BLOCKER "+c.BLOCKER+" | HIGH "+c.HIGH+" | WARNING "+c.WARNING+" | INFO/NOT PARSED "+c.INFO);
          out.push("Note: "+result.note);
          out.push("Secret handling: findings carry key name, line number, and value length only. No secret value appears in this report.");
          out.push("");
          if (!result.findings.length){
            out.push("Findings: none.");
          } else {
            out.push("Findings:");
            result.findings.forEach(function(f,i){
              var s = (i+1)+". ["+f.severity+"] "+(f.key?f.key+" — ":"")+locText(f);
              if (typeof f.length==="number") s += " — value length "+f.length+" characters";
              s += "\n   "+f.message;
              out.push(s);
            });
          }
          return out.join("\n");
        }
        function buildJson(result){
          var c = countsOf(result);
          return JSON.stringify({
            tool:"J-Dawgs ToolJet Server Config Safety Auditor",
            verdict:result.verdict,
            note:result.note,
            summary:{ linesRead:result.parsed.rawLines.length, keysRead:result.parsed.entries.length,
                      recognizableToolJetKeys:result.recognized,
                      counts:{ BLOCKER:c.BLOCKER, HIGH:c.HIGH, WARNING:c.WARNING, INFO:c.INFO } },
            secretHandling:"Findings carry key name, line number, and value length only. Secret values are never included.",
            findings:result.findings.map(function(f){
              return { severity:f.severity, code:f.code, key:f.key, line:f.line, lines:f.lines,
                       valueLength:f.length, location:locText(f), message:f.message };
            })
          }, null, 2);
        }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-tooljet-server-config-safety-auditortm',
  name: 'J-Dawgs ToolJet Server Config Safety Auditor',
  description: 'Grades a pasted ToolJet server env config offline into one deploy verdict (SAFE TO DEPLOY / DEPLOY WITH FIXES / DO NOT DEPLOY / NOT ENOUGH TO GRADE) — secrets reported by key name, line, and length only, never the secret value.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
