'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Directus Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var PLANTED = "Plant3d-Passw0rd-Never-Print-Me-7391";

      var RISKY = [
        "# Directus — production .env (RISKY worked example)",
        "KEY=example-key-123",
        "SECRET=shortsecret",
        "DB_CLIENT=pg",
        "DB_HOST=db.internal.example.com",
        "DB_PORT=5432",
        "DB_DATABASE=directus",
        "DB_USER=directus",
        "DB_PASSWORD=" + PLANTED,
        "DB_SSL=false",
        "ADMIN_EMAIL=admin@example.com",
        "ADMIN_PASSWORD=admin123",
        "PUBLIC_URL=http://cms.example.com",
        "CORS_ENABLED=true",
        "CORS_ORIGIN=*",
        "CACHE_ENABLED=false",
        "RATE_LIMITER_ENABLED=false",
        "ACCESS_TOKEN_TTL=7d",
        "REFRESH_TOKEN_TTL=90d",
        "WEBSOCKETS_ENABLED=true",
        "TELEMETRY=true",
        "THIS LINE IS NOT A VALID ASSIGNMENT"
      ].join("\n");

      var HARDENED = [
        "# Directus — production .env (hardened example)",
        "KEY=${DIRECTUS_KEY}",
        "SECRET=${DIRECTUS_SECRET}",
        "DB_CLIENT=pg",
        "DB_HOST=db.internal.example.com",
        "DB_PORT=5432",
        "DB_DATABASE=directus",
        "DB_USER=directus",
        "DB_PASSWORD=${DB_PASSWORD}",
        "DB_SSL=true",
        "ADMIN_EMAIL=admin@example.com",
        "ADMIN_PASSWORD=${ADMIN_PASSWORD}",
        "PUBLIC_URL=https://cms.example.com",
        "CORS_ENABLED=true",
        "CORS_ORIGIN=https://app.example.com",
        "CACHE_ENABLED=true",
        "RATE_LIMITER_ENABLED=true",
        "ACCESS_TOKEN_TTL=15m",
        "REFRESH_TOKEN_TTL=7d",
        "WEBSOCKETS_ENABLED=true",
        "WEBSOCKETS_AUTH=handshake",
        "TELEMETRY=false"
      ].join("\n");

      var WORKED = [
        "# Agent worked example — input",
        "KEY=example-key",
        "SECRET=short",
        "PUBLIC_URL=http://cms.example.com",
        "RATE_LIMITER_ENABLED=false"
      ].join("\n");

      var DIRECTUS_KEYS = {
        KEY:1, SECRET:1, DB_CLIENT:1, DB_HOST:1, DB_PORT:1, DB_DATABASE:1, DB_USER:1,
        DB_PASSWORD:1, DB_PASSWORD_FILE:1, DATABASE_URL:1, DB_SSL:1,
        ADMIN_EMAIL:1, ADMIN_PASSWORD:1, ADMIN_PASSWORD_FILE:1,
        PUBLIC_URL:1, CORS_ENABLED:1, CORS_ORIGIN:1, CORS_CREDENTIALS:1,
        CACHE_ENABLED:1, CACHE_STORE:1, RATE_LIMITER_ENABLED:1, RATE_LIMITER_STORE:1,
        ACCESS_TOKEN_TTL:1, REFRESH_TOKEN_TTL:1, REFRESH_TOKEN_COOKIE_NAME:1,
        SESSION_COOKIE_NAME:1, WEBSOCKETS_ENABLED:1, WEBSOCKETS_AUTH:1,
        TELEMETRY:1, TELEMETRY_ENABLE:1, STORAGE_LOCATIONS:1, ASSETS_CACHE_TTL:1,
        LOGIN_STALL_TIME:1, PASSWORD_RESET_URL_ALLOW_LIST:1, USER_INVITE_URL_ALLOW_LIST:1,
        CONTENT_SECURITY_POLICY_DIRECTIVES__FRAME_SRC:1, EXTENSIONS_PATH:1, SERVE_APP:1
      };

      var WEAK_EXACT = {
        "secret":1,"key":1,"changeme":1,"change-me":1,"change_me":1,"password":1,
        "admin":1,"test":1,"example":1,"directus":1,"123456":1,"12345678":1,
        "supersecret":1,"mysecret":1,"your-secret":1,"your_secret":1,"default":1,
        "letmein":1,"please-change-me":1,"randomstring":1
      };

      function isWeakExample(v){
        var s = String(v).toLowerCase();
        if (WEAK_EXACT[s]) return true;
        if (s.indexOf("example") !== -1) return true;
        if (s.indexOf("changeme") !== -1 || s.indexOf("change-me") !== -1 || s.indexOf("change_me") !== -1) return true;
        if (s.indexOf("placeholder") !== -1) return true;
        if (s.indexOf("your-") === 0 || s.indexOf("your_") === 0) return true;
        if (s.indexOf("todo") !== -1) return true;
        if (/^x{4,}$/.test(s)) return true;
        return false;
      }

      function isRefValue(v){
        return /\$\{[^}]+\}/.test(v);
      }

      function stripQuotes(v){
        v = v.replace(/\s+$/, "");
        if (v.length >= 2){
          var a = v.charAt(0), b = v.charAt(v.length-1);
          if ((a === '"' && b === '"') || (a === "'" && b === "'")) return v.slice(1,-1);
        }
        return v;
      }

      function parseConfig(text){
        var entries = {};   // KEY -> {value, line}
        var order = [];
        var notParsed = [];
        var lines = String(text == null ? "" : text).split(/\r?\n/);
        for (var i = 0; i < lines.length; i++){
          var raw = lines[i];
          var lineNo = i + 1;
          var t = raw.replace(/^\s+/, "");
          if (t === "") continue;
          if (t.charAt(0) === "#") continue;
          var m = t.match(/^(?:export\s+)?([A-Za-z_][A-Za-z0-9_.]*)\s*=\s*(.*)$/);
          if (!m){ notParsed.push({ line: lineNo }); continue; }
          var key = m[1].toUpperCase();
          var val = m[2];
          // strip unquoted inline comment
          if (val.charAt(0) !== '"' && val.charAt(0) !== "'"){
            var hashIdx = val.indexOf(" #");
            if (hashIdx !== -1) val = val.slice(0, hashIdx);
          }
          val = stripQuotes(val.replace(/^\s+/, ""));
          if (!entries[key]) order.push(key);
          entries[key] = { value: val, line: lineNo };
        }
        return { entries: entries, order: order, notParsed: notParsed, lineCount: lines.length };
      }

      function parseDurationMs(v){
        var m = String(v).trim().match(/^(\d+(?:\.\d+)?)\s*(ms|s|m|h|d|w|y)?$/i);
        if (!m) return null;
        var n = parseFloat(m[1]);
        var unit = (m[2] || "ms").toLowerCase();
        var mult = { ms:1, s:1000, m:60000, h:3600000, d:86400000, w:604800000, y:31536000000 };
        return n * mult[unit];
      }

      function isTruthy(v){ return /^(true|1|yes|on)$/i.test(String(v).trim()); }
      function isFalsy(v){ return /^(false|0|no|off)$/i.test(String(v).trim()); }

      function isRemoteHost(host){
        if (!host) return false;
        var h = String(host).trim().toLowerCase();
        if (h === "localhost" || h === "127.0.0.1" || h === "::1" || h === "0.0.0.0") return false;
        if (h.indexOf(".") !== -1) return true;               // dotted hostname / public IP
        if (/^\d+\.\d+\.\d+\.\d+$/.test(h)) return true;
        return false;                                          // bare service name (docker etc.) = internal
      }

      function audit(text){
        var parsed = parseConfig(text);
        var e = parsed.entries;
        var findings = [];
        var passes = [];

        function add(sev, key, line, message){
          findings.push({ severity: sev, key: key, line: (line == null ? null : line), message: message });
        }
        function get(k){ return e[k]; }
        function hasFileRef(k){ return !!e[k + "_FILE"]; }
        function safeRef(k){
          var ent = e[k];
          if (!ent) return false;
          if (hasFileRef(k)) return true;
          if (k.slice(-5) === "_FILE") return true;
          return isRefValue(ent.value);
        }

        // Recognizability
        var recognized = 0;
        for (var i = 0; i < parsed.order.length; i++){
          if (DIRECTUS_KEYS[parsed.order[i]]) recognized++;
        }

        if (recognized < 2){
          var np0 = parsed.notParsed.map(function(n){ return { severity:"NOT PARSED", key:null, line:n.line, message:"Line " + n.line + " was not parsed (content not shown)." }; });
          return {
            verdict: "NOT ENOUGH TO GRADE",
            recognized: recognized,
            lineCount: parsed.lineCount,
            findings: np0,
            passes: [],
            counts: countSev(np0),
            notEnough: true
          };
        }

        // ---- KEY & SECRET (BLOCKER tier) ----
        ["KEY","SECRET"].forEach(function(k){
          var ent = get(k);
          if (!ent || ent.value === ""){
            add("BLOCKER", k, ent ? ent.line : null, k + " is missing. Directus will not boot securely without it — set a long random value or a ${...} / _FILE reference.");
            return;
          }
          if (safeRef(k)){ passes.push(k + " — supplied via a ${...} or _FILE reference; value not in the file."); return; }
          var reasons = [];
          if (isWeakExample(ent.value)) reasons.push("matches a known example/placeholder pattern");
          if (ent.value.length < 32) reasons.push("is under 32 characters (length " + ent.value.length + ")");
          if (reasons.length){
            add("BLOCKER", k, ent.line, k + " " + reasons.join(" and ") + ". Anyone who has seen the docs or the example file can guess it. Value not shown.");
          } else {
            passes.push(k + " — present, length " + ent.value.length + ", no example pattern. Value not shown.");
          }
        });

        // ---- Database credential (HIGH) ----
        var dbUrl = get("DATABASE_URL");
        var dbPw = get("DB_PASSWORD");
        var dbCredFound = false;
        if (dbUrl && dbUrl.value !== ""){
          dbCredFound = true;
          if (safeRef("DATABASE_URL")){
            passes.push("DATABASE_URL — supplied via a ${...} reference; not graded as plaintext.");
          } else {
            var um = dbUrl.value.match(/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\/[^:\/@]+:([^@]*)@/);
            if (um && um[1] !== ""){
              var pwLen = um[1].length;
              add("HIGH", "DATABASE_URL", dbUrl.line, "DATABASE_URL embeds a plaintext password (length " + pwLen + "). Move the credential to a secret manager or a _FILE reference. Password not shown.");
            } else {
              passes.push("DATABASE_URL — no embedded password found in the pasted text.");
            }
          }
        }
        if (dbPw && dbPw.value !== ""){
          dbCredFound = true;
          if (safeRef("DB_PASSWORD")){
            passes.push("DB_PASSWORD — supplied via a ${...} or _FILE reference; value not in the file.");
          } else {
            add("HIGH", "DB_PASSWORD", dbPw.line, "DB_PASSWORD is stored in plaintext in this file (length " + dbPw.value.length + "). Anyone with the file owns the database. Use a ${...} reference or DB_PASSWORD_FILE. Value not shown.");
          }
        }
        if (hasFileRef("DB_PASSWORD")) dbCredFound = true;
        if (!dbCredFound){
          add("INFO", "Database credential", null, "No DB_PASSWORD, DATABASE_URL, or _FILE reference in the paste; the database credential was not graded.");
        }

        // ---- ADMIN_PASSWORD ----
        var ap = get("ADMIN_PASSWORD");
        if (ap && ap.value !== ""){
          if (safeRef("ADMIN_PASSWORD")){
            passes.push("ADMIN_PASSWORD — supplied via a ${...} or _FILE reference; value not in the file.");
          } else {
            var apReasons = ["stored in plaintext in this file (length " + ap.value.length + ")"];
            if (ap.value.length < 12) apReasons.push("under 12 characters");
            if (isWeakExample(ap.value)) apReasons.push("matches a known example/placeholder pattern");
            add("HIGH", "ADMIN_PASSWORD", ap.line, "ADMIN_PASSWORD is " + apReasons.join(", ") + ". Bootstrap admin credentials in a file tend to stay the real credentials. Value not shown.");
          }
        } else if (get("ADMIN_EMAIL")){
          add("INFO", "ADMIN_PASSWORD", null, "ADMIN_EMAIL is set but no ADMIN_PASSWORD was in the paste; the bootstrap admin password was not graded.");
        }

        // ---- PUBLIC_URL ----
        var pu = get("PUBLIC_URL");
        if (pu && pu.value !== ""){
          if (/^http:\/\//i.test(pu.value)){
            add("HIGH", "PUBLIC_URL", pu.line, "PUBLIC_URL uses http:// (" + pu.value + "). Admin sessions, password-reset links, and tokens will travel and be generated over plaintext HTTP. Serve Directus over https:// and update PUBLIC_URL.");
          } else if (/^https:\/\//i.test(pu.value)){
            passes.push("PUBLIC_URL — uses https://.");
          } else {
            add("INFO", "PUBLIC_URL", pu.line, "PUBLIC_URL is set to a value that is not an http(s) URL (" + pu.value + "); scheme was not graded.");
          }
        } else {
          add("INFO", "PUBLIC_URL", null, "PUBLIC_URL is not set in the paste; generated links and redirects fall back to the request host.");
        }

        // ---- CORS ----
        var ce = get("CORS_ENABLED"), co = get("CORS_ORIGIN");
        if (ce && isTruthy(ce.value) && co && co.value !== "" && !safeRef("CORS_ORIGIN")){
          var origin = co.value.trim();
          if (origin === "*" || isTruthy(origin)){
            add("HIGH", "CORS_ORIGIN", co.line, "CORS is enabled with CORS_ORIGIN set to \"" + origin + "\" — any website can call this API from a visitor's browser. List the exact origins that need access.");
          } else {
            passes.push("CORS_ORIGIN — restricted to named origin(s), not a wildcard.");
          }
        } else if (ce && isTruthy(ce.value)){
          passes.push("CORS_ENABLED — on, and no wildcard CORS_ORIGIN found in the paste.");
        }

        // ---- Rate limiter ----
        var rl = get("RATE_LIMITER_ENABLED");
        if (!rl || rl.value === ""){
          add("WARNING", "RATE_LIMITER_ENABLED", null, "RATE_LIMITER_ENABLED is missing from the paste. Confirm it is enabled — without it, login and API endpoints take unlimited attempts.");
        } else if (safeRef("RATE_LIMITER_ENABLED")){
          passes.push("RATE_LIMITER_ENABLED — set via a reference; not graded as on/off.");
        } else if (isFalsy(rl.value)){
          add("WARNING", "RATE_LIMITER_ENABLED", rl.line, "Rate limiting is disabled (RATE_LIMITER_ENABLED=false). Brute-force and scraping traffic gets no pushback. Turn it on before deploying.");
        } else if (isTruthy(rl.value)){
          passes.push("RATE_LIMITER_ENABLED — on.");
        }

        // ---- Token TTLs ----
        var att = get("ACCESS_TOKEN_TTL");
        if (att && att.value !== "" && !safeRef("ACCESS_TOKEN_TTL")){
          var attMs = parseDurationMs(att.value);
          if (attMs !== null && attMs > 86400000){
            add("WARNING", "ACCESS_TOKEN_TTL", att.line, "ACCESS_TOKEN_TTL is " + att.value + " — over 1 day. A stolen access token stays valid far too long; 15 minutes is the Directus default for a reason.");
          } else if (attMs !== null){
            passes.push("ACCESS_TOKEN_TTL — " + att.value + ", within 1 day.");
          } else {
            add("INFO", "ACCESS_TOKEN_TTL", att.line, "ACCESS_TOKEN_TTL value \"" + att.value + "\" could not be read as a duration; not graded.");
          }
        }
        var rtt = get("REFRESH_TOKEN_TTL");
        if (rtt && rtt.value !== "" && !safeRef("REFRESH_TOKEN_TTL")){
          var rttMs = parseDurationMs(rtt.value);
          if (rttMs !== null && rttMs > 30 * 86400000){
            add("WARNING", "REFRESH_TOKEN_TTL", rtt.line, "REFRESH_TOKEN_TTL is " + rtt.value + " — over 30 days. A leaked refresh token is a month-plus back door. Shorten it.");
          } else if (rttMs !== null){
            passes.push("REFRESH_TOKEN_TTL — " + rtt.value + ", within 30 days.");
          } else {
            add("INFO", "REFRESH_TOKEN_TTL", rtt.line, "REFRESH_TOKEN_TTL value \"" + rtt.value + "\" could not be read as a duration; not graded.");
          }
        }

        // ---- Cache ----
        var cache = get("CACHE_ENABLED");
        if (cache && isFalsy(cache.value)){
          add("INFO", "CACHE_ENABLED", cache.line, "CACHE_ENABLED=false — the data cache is off. Not a security hole, but every request hits the database; expect slow responses under load.");
        } else if (cache && isTruthy(cache.value)){
          passes.push("CACHE_ENABLED — on.");
        }

        // ---- Websockets ----
        var ws = get("WEBSOCKETS_ENABLED");
        if (ws && isTruthy(ws.value)){
          if (!get("WEBSOCKETS_AUTH")){
            add("WARNING", "WEBSOCKETS_ENABLED", ws.line, "Websockets are enabled and no WEBSOCKETS_AUTH posture appears in the paste. Confirm who can open a socket and subscribe before this faces the public internet.");
          } else {
            passes.push("WEBSOCKETS_ENABLED — on, with a WEBSOCKETS_AUTH posture present.");
          }
        }

        // ---- Telemetry ----
        var tel = get("TELEMETRY") || get("TELEMETRY_ENABLE");
        if (tel && isTruthy(tel.value)){
          add("INFO", tel === get("TELEMETRY") ? "TELEMETRY" : "TELEMETRY_ENABLE", tel.line, "Telemetry is on — this instance phones home usage data. Harmless for most, a policy problem for some; know that it is on.");
        } else if (tel){
          passes.push("Telemetry — off.");
        }

        // ---- DB_SSL vs remote host ----
        var hostEnt = get("DB_HOST");
        var hostVal = hostEnt ? hostEnt.value : null;
        if (!hostVal && dbUrl && dbUrl.value && !safeRef("DATABASE_URL")){
          var hm = dbUrl.value.match(/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\/(?:[^@]*@)?([^:\/?#]+)/);
          if (hm) hostVal = hm[1];
        }
        var ssl = get("DB_SSL");
        if (ssl && isFalsy(ssl.value) && isRemoteHost(hostVal)){
          add("HIGH", "DB_SSL", ssl.line, "DB_SSL=false while the database host (" + hostVal + ") is remote. Database traffic — including credentials and content — crosses the network unencrypted. Enable DB_SSL.");
        } else if (ssl && isTruthy(ssl.value)){
          passes.push("DB_SSL — on.");
        }

        // ---- Not parsed lines ----
        parsed.notParsed.forEach(function(n){
          findings.push({ severity:"NOT PARSED", key:null, line:n.line, message:"Line " + n.line + " was not parsed — it is not a KEY=value line, a blank line, or a comment (content not shown)." });
        });

        var counts = countSev(findings);
        var verdict;
        if (counts.BLOCKER > 0 || counts.HIGH > 0) verdict = "DO NOT DEPLOY";
        else if (counts.WARNING > 0) verdict = "DEPLOY WITH FIXES";
        else verdict = "SAFE TO DEPLOY";

        return {
          verdict: verdict,
          recognized: recognized,
          lineCount: parsed.lineCount,
          findings: findings,
          passes: passes,
          counts: counts,
          notEnough: false
        };
      }

      function countSev(findings){
        var c = { BLOCKER:0, HIGH:0, WARNING:0, INFO:0, "NOT PARSED":0 };
        findings.forEach(function(f){ if (c.hasOwnProperty(f.severity)) c[f.severity]++; });
        return c;
      }

      function buildReport(r){
        var L = [];
        L.push("J-DAWGS DIRECTUS SERVER CONFIG SAFETY AUDITOR — REPORT");
        L.push("Verdict: " + r.verdict);
        L.push("Counts: BLOCKER " + r.counts.BLOCKER + " · HIGH " + r.counts.HIGH + " · WARNING " + r.counts.WARNING + " · INFO " + r.counts.INFO + " · NOT PARSED " + r.counts["NOT PARSED"]);
        L.push("Recognized Directus keys: " + r.recognized + " · Lines in paste: " + r.lineCount);
        L.push("");
        if (r.notEnough){
          L.push("The paste was not recognizably a Directus config (fewer than two recognized Directus keys), so nothing was graded.");
        } else {
          L.push("FINDINGS");
          if (!r.findings.length) L.push("- None.");
          r.findings.forEach(function(f){
            var loc = f.line ? "Line " + f.line : "No line";
            var key = f.key ? " · " + f.key : "";
            L.push("- [" + f.severity + "] " + loc + key + " — " + f.message);
          });
          L.push("");
          L.push("CHECKS THAT PASSED");
          if (!r.passes.length) L.push("- None.");
          r.passes.forEach(function(p){ L.push("- " + p); });
        }
        if (r.notEnough && r.findings.length){
          L.push("");
          L.push("NOT PARSED");
          r.findings.forEach(function(f){ L.push("- Line " + f.line + " — not parsed (content not shown)."); });
        }
        L.push("");
        L.push("Secret values are never printed in this report — findings name the key, the line, and the length only.");
        L.push("Graded locally in the browser. Nothing was uploaded, saved, or sent to a server. This tool never verifies secrets.");
        return L.join("\n");
      }

      function buildJson(r){
        return {
          tool: "J-Dawgs Directus Server Config Safety Auditor",
          verdict: r.verdict,
          counts: {
            blocker: r.counts.BLOCKER, high: r.counts.HIGH, warning: r.counts.WARNING,
            info: r.counts.INFO, notParsed: r.counts["NOT PARSED"]
          },
          recognizedDirectusKeys: r.recognized,
          linesInPaste: r.lineCount,
          findings: r.findings.map(function(f){
            return { severity: f.severity, key: f.key, line: f.line, message: f.message };
          }),
          passedChecks: r.passes.slice(),
          notes: [
            "Secret values are never included — findings carry key name, line, and length only.",
            "Graded locally in the browser; nothing uploaded or saved; no server was contacted; secrets were not verified."
          ]
        };
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-directus-server-config-safety-auditor',
  name: 'J-Dawgs Directus Server Config Safety Auditor',
  description: 'Host tools only tell you the server started; ours grades a pasted Directus server .env config offline into one deploy verdict — secrets by key name/line/length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
