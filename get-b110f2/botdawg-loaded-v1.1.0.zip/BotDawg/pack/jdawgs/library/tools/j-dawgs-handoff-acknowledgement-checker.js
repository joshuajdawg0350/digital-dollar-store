'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Handoff Acknowledgement Checker".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the check function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

    'use strict';

    /* ---------- Examples (verified against the grading rules below) ---------- */
    var EXAMPLE_BRIEF = [
      'Goal:',
      '1. Finish the checkout page redesign and deploy it to staging for review.',
      '',
      'Done:',
      '2. Database migration to PostgreSQL is complete and verified.',
      '',
      'Pending:',
      '3. Write the regression tests for the payment flow before Friday.',
      '',
      'Blockers:',
      '4. CRITICAL blocker: the payment gateway sandbox keys are expired — request new keys from the vendor before any payment testing.',
      '',
      'Decisions:',
      '5. Keep the existing design tokens and the current CSS framework.',
      '',
      'Do-not-redo:',
      '6. Do not rebuild the invoice PDF generator — it was finished and approved last week.'
    ].join('\n');

    var EXAMPLE_ACK_GAPS = [
      'Got it — thanks for the brief.',
      'I will finish the checkout page redesign and deploy it to staging for review.',
      'The PostgreSQL database migration is complete and verified, noted.',
      'I will write the regression tests for the payment flow before Friday.',
      'And on the blocker: the payment gateway sandbox keys are expired, so I will request new keys from the vendor before any payment testing.',
      'Starting now.'
    ].join('\n');

    var EXAMPLE_ACK_CLEAN = [
      'Understood — all six points covered:',
      '1) I will finish the checkout page redesign and deploy it to staging for review.',
      '2) Noted: the PostgreSQL database migration is complete and verified.',
      '3) I will write the regression tests for the payment flow before Friday.',
      '4) The CRITICAL blocker is on my list — the payment gateway sandbox keys are expired, and I will request new keys from the vendor before any payment testing.',
      '5) I will keep the existing design tokens and the current CSS framework.',
      '6) I will not rebuild the invoice PDF generator — it was finished and approved last week, so it stays untouched.'
    ].join('\n');

    /* ---------- Text helpers ---------- */
    var STOP = {};
    ('the a an and or of to in on at by for with from into is are was were be been being it its this that these those i you he she we they me him her us them my your his their our as if but so no not do does did done have has had can could will would shall should may might am about over under again once any all').split(' ').forEach(function(w){ STOP[w] = 1; });

    function tokenize(text){
      return String(text).toLowerCase()
        .replace(/['’]/g, '')
        .replace(/[^a-z0-9\s$]/g, ' ')
        .split(/\s+/)
        .filter(function(w){ return w.length > 0; });
    }

    function sigWords(text){
      var seen = {}, out = [];
      tokenize(text).forEach(function(w){
        if (STOP[w]) return;
        if (w.length < 3 && !/^\$?\d/.test(w)) return;
        if (!seen[w]) { seen[w] = 1; out.push(w); }
      });
      return out;
    }

    function esc(s){
      return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
    }

    /* ---------- Brief parsing ---------- */
    var SECTION_KEYS = ['goal','goals','objective','objectives','done','completed','complete','pending','todo','to do','to-do','blockers','blocker','blocked','decisions','decision','decided','do-not-redo','do not redo','dont redo',"don't redo",'notes','note','context','background','status','risks','risk','next steps','scope','rules','warnings','warning'];

    function cleanSection(s){
      return s.replace(/:\s*$/, '').replace(/\s+/g, ' ').trim();
    }

    function parseBrief(text){
      var items = [], section = 'General';
      String(text).split(/\r?\n/).forEach(function(raw){
        var line = raw.trim(), m;
        if (!line) return;
        if (/^(-{3,}|={3,}|_{3,})$/.test(line)) return;
        if (/handoff brief/i.test(line) && line.length < 80 && !/^\d/.test(line)) return; /* document title line */
        m = line.match(/^#{1,6}\s+(.+)$/);
        if (m) { section = cleanSection(m[1]); return; }
        m = line.match(/^([A-Za-z][A-Za-z0-9 '&\-]{0,40}):\s*$/);
        if (m) { section = cleanSection(m[1]); return; }
        var num = null, body = line;
        m = line.match(/^(\d{1,3})[\.\)]\s+(.*)$/);
        if (m) { num = parseInt(m[1], 10); body = m[2]; }
        else {
          m = line.match(/^[-*•–]\s+(.*)$/) || line.match(/^\[[ xX]\]\s+(.*)$/);
          if (m) { body = m[1]; }
          else {
            m = line.match(/^([A-Za-z][A-Za-z '&\-]{0,30}):\s+(.+)$/);
            if (m && SECTION_KEYS.indexOf(m[1].toLowerCase().trim()) >= 0) {
              section = cleanSection(m[1]); body = m[2];
            } else if (items.length && /^[a-z]/.test(line)) {
              items[items.length - 1].text += ' ' + line; /* wrapped continuation line */
              return;
            }
          }
        }
        items.push({ num: num, section: section, text: body.trim() });
      });
      items.forEach(function(it, i){ it.id = (it.num != null ? it.num : i + 1); });
      return items;
    }

    /* ---------- Grading ---------- */
    function isCritical(text){
      var t = String(text);
      return /\bcritical\b/i.test(t)
        || /\bmust\b/i.test(t)
        || /blocker/i.test(t)
        || /\bdo\s+not\b/i.test(t)
        || /\bdon'?t\b/i.test(t)
        || /\bnever\b/i.test(t)
        || /deadline/i.test(t)
        || /\$\s?\d/.test(t)
        || /\b\d[\d,]*(\.\d{2})?\s?(dollars|usd)\b/i.test(t);
    }

    function numberQuoted(id, ackRaw){
      var re = new RegExp('(^|[^0-9])#?' + id + '\\s*[\\)\\.:]|\\bitem\\s*#?' + id + '\\b|\\bpoint\\s*#?' + id + '\\b', 'i');
      return re.test(ackRaw);
    }

    function gradeItem(item, ackRaw, ackSet){
      var words = sigWords(item.text);
      var critical = isCritical(item.text);
      if (words.length === 0) {
        return { grade: 'ACKNOWLEDGED', pct: 100, matched: 0, total: 0, critical: critical, quoted: false, note: 'no keywords to check' };
      }
      var matched = 0;
      words.forEach(function(w){ if (ackSet[w]) matched++; });
      var ratio = matched / words.length;
      var quoted = numberQuoted(item.id, ackRaw);
      var grade;
      if (quoted || ratio >= 0.55) grade = 'ACKNOWLEDGED';
      else if ((matched >= 2 && ratio >= 0.2) || (matched >= 1 && ratio >= 0.34)) grade = 'PARTIAL';
      else grade = 'NOT ACKNOWLEDGED';
      return { grade: grade, pct: Math.round(ratio * 100), matched: matched, total: words.length, critical: critical, quoted: quoted, note: '' };
    }

    function computeVerdict(graded){
      var critNot = false, critPart = false, anyGap = false;
      graded.forEach(function(g){
        if (g.grade !== 'ACKNOWLEDGED') anyGap = true;
        if (g.critical && g.grade === 'NOT ACKNOWLEDGED') critNot = true;
        if (g.critical && g.grade === 'PARTIAL') critPart = true;
      });
      if (critNot) return 'DO NOT START';
      if (critPart || anyGap) return 'START WITH GAPS';
      return 'READY TO START';
    }

    function addedByReceiver(ackText, briefText){
      var briefSet = {};
      sigWords(briefText).forEach(function(w){ briefSet[w] = 1; });
      tokenize(briefText).forEach(function(w){ briefSet[w] = 1; });
      var sentences = [];
      String(ackText).split(/\n+/).forEach(function(line){
        line.replace(/([.!?])\s+/g, '$1').split('').forEach(function(s){
          s = s.trim();
          if (s) sentences.push(s);
        });
      });
      var added = [];
      sentences.forEach(function(s){
        var words = sigWords(s);
        if (words.length < 5) return;
        var matched = 0;
        words.forEach(function(w){ if (briefSet[w]) matched++; });
        if (matched / words.length < 0.3) added.push(s);
      });
      return added.slice(0, 8);
    }

    function check(briefText, ackText){
      var items = parseBrief(briefText);
      var ackSet = {};
      sigWords(ackText).forEach(function(w){ ackSet[w] = 1; });
      tokenize(ackText).forEach(function(w){ if (!STOP[w] && w.length >= 3) ackSet[w] = 1; });
      var graded = items.map(function(it){
        var g = gradeItem(it, ackText, ackSet);
        g.item = it;
        return g;
      });
      return {
        items: items,
        graded: graded,
        verdict: items.length ? computeVerdict(graded) : null,
        added: addedByReceiver(ackText, briefText)
      };
    }

    /* ---------- Output text builders ---------- */
    function verdictReason(res){
      var reasons = [];
      res.graded.forEach(function(g){
        if (g.critical && g.grade === 'NOT ACKNOWLEDGED') {
          reasons.push('Item ' + g.item.id + ' (' + g.item.section + ') is CRITICAL and was not acknowledged: "' + g.item.text + '"');
        }
      });
      if (reasons.length) return reasons.join(' ');
      res.graded.forEach(function(g){
        if (g.critical && g.grade === 'PARTIAL') {
          reasons.push('Item ' + g.item.id + ' (' + g.item.section + ') is CRITICAL and only partly acknowledged.');
        }
      });
      if (reasons.length) return reasons.join(' ');
      var gaps = res.graded.filter(function(g){ return g.grade !== 'ACKNOWLEDGED'; });
      if (!gaps.length) return 'Every item in the brief was acknowledged.';
      return gaps.length + (gaps.length === 1 ? ' item was' : ' items were') + ' not fully acknowledged — see the coverage table.';
    }

    function buildFollowUp(res){
      var missing = res.graded.filter(function(g){ return g.grade === 'NOT ACKNOWLEDGED'; });
      var partial = res.graded.filter(function(g){ return g.grade === 'PARTIAL'; });
      var lines = [];
      lines.push('Hi — quick check before you start. Your acknowledgement did not cover everything in the handoff brief.');
      if (missing.length) {
        lines.push('');
        lines.push('NOT MENTIONED AT ALL:');
        missing.forEach(function(g){
          lines.push(g.item.id + '. [' + g.item.section + '] ' + g.item.text + (g.critical ? ' (CRITICAL)' : ''));
        });
      }
      if (partial.length) {
        lines.push('');
        lines.push('MENTIONED ONLY IN PART — please confirm these in full:');
        partial.forEach(function(g){
          lines.push(g.item.id + '. [' + g.item.section + '] ' + g.item.text + (g.critical ? ' (CRITICAL)' : ''));
        });
      }
      lines.push('');
      lines.push('Please reply confirming each of these' + (missing.concat(partial).some(function(g){ return g.critical; }) ? ' — especially the CRITICAL ones' : '') + ' — before work begins, so nothing from the brief gets dropped.');
      return lines.join('\n');
    }

    function buildReport(res){
      var counts = { ack: 0, part: 0, not: 0, crit: 0 };
      res.graded.forEach(function(g){
        if (g.grade === 'ACKNOWLEDGED') counts.ack++;
        else if (g.grade === 'PARTIAL') counts.part++;
        else counts.not++;
        if (g.critical) counts.crit++;
      });
      var lines = [];
      lines.push('HANDOFF ACKNOWLEDGEMENT CHECK');
      lines.push('Verdict: ' + res.verdict);
      lines.push('Items: ' + res.items.length + ' — Acknowledged ' + counts.ack + ' · Partial ' + counts.part + ' · Not acknowledged ' + counts.not + ' · Critical items ' + counts.crit);
      lines.push('Why: ' + verdictReason(res));
      lines.push('');
      lines.push('PER-ITEM COVERAGE');
      res.graded.forEach(function(g){
        lines.push(g.item.id + '. [' + g.item.section + '] ' + g.item.text);
        lines.push('   -> ' + g.grade + (g.critical ? ' · CRITICAL' : '') + ' · ' + g.pct + '% keyword overlap (' + g.matched + '/' + g.total + ' significant words' + (g.quoted ? '; item number quoted' : '') + ')');
      });
      lines.push('');
      lines.push('ADDED BY RECEIVER (info only, never an error)');
      if (res.added.length) res.added.forEach(function(s){ lines.push('- ' + s); });
      else lines.push('- none detected');
      lines.push('');
      lines.push('Method: keyword-overlap heuristics, not understanding. A NOT ACKNOWLEDGED grade means no trace was found in the acknowledgement text, not proof the receiver did not read the brief.');
      lines.push('Checked with the J-Dawgs Handoff Acknowledgement Checker™.');
      return lines.join('\n');
    }

    /* ---------- Rendering (browser only) ---------- */
    function gradeClass(grade){
      if (grade === 'ACKNOWLEDGED') return 'ack';
      if (grade === 'PARTIAL') return 'part';
      return 'not';
    }
    function verdictClass(v){
      if (v === 'READY TO START') return 'ready';
      if (v === 'START WITH GAPS') return 'gaps';
      return 'stop';
    }
  return { "check": (typeof check !== 'undefined' ? check : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_BRIEF": (typeof EXAMPLE_BRIEF !== 'undefined' ? EXAMPLE_BRIEF : undefined), "EXAMPLE_ACK_GAPS": (typeof EXAMPLE_ACK_GAPS !== 'undefined' ? EXAMPLE_ACK_GAPS : undefined), "EXAMPLE_ACK_CLEAN": (typeof EXAMPLE_ACK_CLEAN !== 'undefined' ? EXAMPLE_ACK_CLEAN : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["check"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-handoff-acknowledgement-checker',
  name: 'J-Dawgs Handoff Acknowledgement Checker',
  description: 'Cross-checks a handoff brief against the receiver\'s acknowledgement: unacknowledged items named, critical misses force DO NOT START, plus a copyable missing-items follow-up draft.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["check"]) return { ok: false, output: null, summary: 'Extracted core has no check function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_BRIEF": __core["EXAMPLE_BRIEF"], "EXAMPLE_ACK_GAPS": __core["EXAMPLE_ACK_GAPS"], "EXAMPLE_ACK_CLEAN": __core["EXAMPLE_ACK_CLEAN"] }
};
