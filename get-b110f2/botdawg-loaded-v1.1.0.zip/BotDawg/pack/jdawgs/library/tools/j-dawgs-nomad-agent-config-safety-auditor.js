'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Nomad Agent Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

    "use strict";
    /* ============================================================
       J-Dawgs Nomad Agent Config Safety Auditor
       Original, clean-room implementation built from public Nomad
       configuration concepts only. Runs entirely in the browser:
       nothing is stored, nothing is uploaded.
       ============================================================ */

    var RISKY_EXAMPLE = [
      '# Risky Nomad agent config — training example, not a real deployment.',
      '# Every secret-looking value below is a placeholder.',
      'bind_addr  = "0.0.0.0"',
      'data_dir   = "/opt/nomad/data"',
      'datacenter = "dc1"',
      '',
      'leave_on_interrupt = true',
      '',
      'server {',
      '  enabled          = true',
      '  bootstrap_expect = 1',
      '}',
      '',
      'acl {',
      '  enabled = false',
      '}',
      '',
      'tls {',
      '  http                   = false',
      '  rpc                    = false',
      '  verify_server_hostname = false',
      '}',
      '',
      'client {',
      '  enabled = true',
      '',
      '  options {',
      '    "driver.raw_exec.enable" = "1"',
      '  }',
      '}',
      '',
      'consul {',
      '  address = "127.0.0.1:8500"',
      '  token   = "EXAMPLE-PLACEHOLDER-CONSUL-TOKEN"',
      '}',
      '',
      'telemetry {',
      '  publish_allocation_metrics = true',
      '}'
    ].join("\n");

    var HARDENED_EXAMPLE = [
      '# Hardened Nomad agent config — training example.',
      '# The gossip key below is a placeholder in the standard 16-byte class.',
      'bind_addr  = "10.0.4.21"',
      'data_dir   = "/opt/nomad/data"',
      'datacenter = "dc1"',
      '',
      'leave_on_interrupt = true',
      'leave_on_terminate = true',
      '',
      'server {',
      '  enabled          = true',
      '  bootstrap_expect = 3',
      '  encrypt          = "CANARYKEY01234567890ab=="',
      '}',
      '',
      'acl {',
      '  enabled = true',
      '}',
      '',
      'tls {',
      '  http                   = true',
      '  rpc                    = true',
      '  verify_server_hostname = true',
      '  ca_file                = "/etc/nomad/tls/ca.pem"',
      '  cert_file              = "/etc/nomad/tls/server.pem"',
      '  key_file               = "/etc/nomad/tls/server-key.pem"',
      '}',
      '',
      'client {',
      '  enabled = false',
      '}',
      '',
      'consul {',
      '  address    = "127.0.0.1:8500"',
      '  ssl        = true',
      '  verify_ssl = true',
      '}',
      '',
      'vault {',
      '  enabled = true',
      '  address = "https://vault.service.consul:8200"',
      '}',
      '',
      'telemetry {',
      '  publish_node_metrics       = true',
      '  publish_allocation_metrics = false',
      '  disable_hostname           = false',
      '  prometheus_metrics         = true',
      '}'
    ].join("\n");

    /* ---------------- Tokenizer ---------------- */
    function tokenize(text) {
      var tokens = [], i = 0, line = 1, n = text.length;
      while (i < n) {
        var c = text[i];
        if (c === "\n") { line++; i++; continue; }
        if (c === " " || c === "\t" || c === "\r") { i++; continue; }
        if (c === "#") { while (i < n && text[i] !== "\n") i++; continue; }
        if (c === "/" && text[i + 1] === "/") { while (i < n && text[i] !== "\n") i++; continue; }
        if (c === "/" && text[i + 1] === "*") {
          i += 2;
          while (i < n && !(text[i] === "*" && text[i + 1] === "/")) { if (text[i] === "\n") line++; i++; }
          i += 2; continue;
        }
        if (c === '"') {
          var s = "", startLine = line; i++;
          while (i < n && text[i] !== '"') {
            if (text[i] === "\\" && i + 1 < n) { s += text[i + 1]; i += 2; }
            else { if (text[i] === "\n") line++; s += text[i]; i++; }
          }
          i++;
          tokens.push({ t: "string", v: s, line: startLine });
          continue;
        }
        if (c === "{" || c === "}" || c === "=" || c === "[" || c === "]" || c === ",") {
          tokens.push({ t: c, v: c, line: line }); i++; continue;
        }
        if (c === "<" && text[i + 1] === "<") {
          var hm = /^<<-?\s*"?([A-Za-z0-9_]+)"?/.exec(text.slice(i, i + 48));
          if (hm) {
            var marker = hm[1], rest = text.slice(i);
            var endIdx = rest.indexOf("\n" + marker);
            var consumed = endIdx === -1 ? rest.length : endIdx + marker.length + 1;
            var seg = rest.slice(0, consumed);
            line += (seg.match(/\n/g) || []).length;
            tokens.push({ t: "string", v: "(heredoc)", line: line });
            i += consumed; continue;
          }
        }
        var wm = /^[^\s{}=\[\],#"]+/.exec(text.slice(i));
        if (wm) { tokens.push({ t: "word", v: wm[0], line: line }); i += wm[0].length; continue; }
        i++;
      }
      return tokens;
    }

    /* ---------------- Parser ----------------
       Builds a tree of blocks {type:'block', name, label, line, children}
       and attributes {type:'attr', key, value, vtype, line}.
       Throws {notParsed:true, line, msg} on unbalanced braces. */
    function parse(tokens) {
      var pos = 0;
      var root = { type: "block", name: "(root)", label: "", line: 0, children: [] };

      function parseValue() {
        var tk = tokens[pos];
        if (!tk) return { v: "", t: "word" };
        if (tk.t === "string") { pos++; return { v: tk.v, t: "string" }; }
        if (tk.t === "[") {
          var depth = 0, parts = [];
          while (pos < tokens.length) {
            var t2 = tokens[pos]; pos++;
            if (t2.t === "[") depth++;
            else if (t2.t === "]") { depth--; if (depth === 0) break; }
            else if (t2.t === "string" || t2.t === "word") parts.push(t2.v);
          }
          return { v: parts.join(", "), t: "list" };
        }
        if (tk.t === "{") {
          var d = 0;
          while (pos < tokens.length) {
            var t3 = tokens[pos]; pos++;
            if (t3.t === "{") d++;
            else if (t3.t === "}") { d--; if (d === 0) break; }
          }
          return { v: "(object)", t: "object" };
        }
        pos++;
        if (tk.v === "true" || tk.v === "false") return { v: tk.v, t: "bool" };
        if (/^-?\d+(\.\d+)?$/.test(tk.v)) return { v: tk.v, t: "number" };
        return { v: tk.v, t: "word" };
      }

      function parseBody(node) {
        while (pos < tokens.length) {
          var tk = tokens[pos];
          if (tk.t === "}") return;
          if (tk.t === "word" || tk.t === "string") {
            var isQuotedKey = tk.t === "string";
            var name = tk.v, nameLine = tk.line;
            pos++;
            var labels = [];
            if (!isQuotedKey) {
              while (pos < tokens.length && tokens[pos].t === "string") { labels.push(tokens[pos].v); pos++; }
            }
            if (pos < tokens.length && tokens[pos].t === "=") {
              pos++;
              var val = parseValue();
              node.children.push({ type: "attr", key: name, value: val.v, vtype: val.t, line: nameLine });
            } else if (!isQuotedKey && pos < tokens.length && tokens[pos].t === "{") {
              pos++;
              var blk = { type: "block", name: name, label: labels[0] || "", line: nameLine, children: [] };
              node.children.push(blk);
              parseBody(blk);
              if (pos < tokens.length && tokens[pos].t === "}") { pos++; }
              else {
                throw { notParsed: true, line: nameLine,
                  msg: 'Block "' + name + '" opened at line ' + nameLine + ' is never closed — a closing "}" is missing.' };
              }
            } else {
              node.children.push({ type: "stray", key: name, line: nameLine });
            }
          } else { pos++; }
        }
      }

      parseBody(root);
      if (pos < tokens.length && tokens[pos].t === "}") {
        throw { notParsed: true, line: tokens[pos].line,
          msg: 'Closing brace "}" at line ' + tokens[pos].line + ' has no matching opening brace.' };
      }
      return root;
    }

    /* ---------------- Tree helpers ---------------- */
    function findBlock(node, name) {
      if (!node) return null;
      for (var i = 0; i < node.children.length; i++) {
        var c = node.children[i];
        if (c.type === "block" && c.name === name) return c;
      }
      return null;
    }
    function findAttr(node, key) {
      if (!node) return null;
      for (var i = 0; i < node.children.length; i++) {
        var c = node.children[i];
        if (c.type === "attr" && c.key === key) return c;
      }
      return null;
    }
    function collectBlocks(node, name, out) {
      for (var i = 0; i < node.children.length; i++) {
        var c = node.children[i];
        if (c.type === "block") {
          if (c.name === name) out.push(c);
          collectBlocks(c, name, out);
        }
      }
    }
    function collectPlugins(node, out) {
      for (var i = 0; i < node.children.length; i++) {
        var c = node.children[i];
        if (c.type === "block") {
          if (c.name === "plugin") out.push(c);
          collectPlugins(c, out);
        }
      }
    }
    function isTrue(a) { return !!a && a.vtype === "bool" && a.value === "true"; }
    function isFalse(a) { return !!a && a.vtype === "bool" && a.value === "false"; }
    function truthyVal(a) {
      if (!a) return false;
      return a.value === "true" || a.value === "1";
    }

    function ipPart(raw) {
      if (!raw) return "";
      var v = String(raw).trim();
      if (v.indexOf("{{") !== -1) return "";
      v = v.replace(/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//, "");
      var slash = v.indexOf("/"); if (slash !== -1) v = v.slice(0, slash);
      if (v.charAt(0) === "[") { var rb = v.indexOf("]"); return rb === -1 ? v : v.slice(1, rb); }
      var colon = v.lastIndexOf(":");
      if (colon !== -1 && v.indexOf(":") === colon) v = v.slice(0, colon);
      return v;
    }
    function isIPv4(v) { return /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(v); }
    function isPrivateIP(v) {
      if (v === "::1" || v.toLowerCase().indexOf("fe80:") === 0) return true;
      var lc = v.toLowerCase();
      if (lc.indexOf("fc") === 0 || lc.indexOf("fd") === 0) {
        if (/^[0-9a-f:]+$/.test(lc)) return true;
      }
      if (!isIPv4(v)) return false;
      var p = v.split(".").map(function (x) { return parseInt(x, 10); });
      if (p[0] === 10 || p[0] === 127) return true;
      if (p[0] === 172 && p[1] >= 16 && p[1] <= 31) return true;
      if (p[0] === 192 && p[1] === 168) return true;
      if (p[0] === 169 && p[1] === 254) return true;
      return false;
    }
    function looksLikeIP(v) { return isIPv4(v) || /^[0-9a-fA-F:]*:[0-9a-fA-F:]*$/.test(v) && v.indexOf(":") !== -1; }

    /* ---------------- Known surface ----------------
       Anything outside these sets is counted NOT AUDITED, never guessed. */
    var KNOWN_ROOT_BLOCKS = { server:1, client:1, acl:1, tls:1, consul:1, vault:1, telemetry:1, ports:1, advertise:1, ui:1, plugin:1, autopilot:1 };
    var KNOWN_NESTED = {
      server: { server_join:1 },
      client: { options:1, meta:1, server_join:1, host_volume:1 },
      plugin: { config:1 }
    };
    var FREE_FORM_BLOCKS = { options:1, meta:1, config:1 };
    var KNOWN_KEYS = {
      root: { bind_addr:1, data_dir:1, datacenter:1, region:1, name:1, log_level:1, log_json:1,
        enable_debug:1, enable_syslog:1, syslog_facility:1, disable_update_check:1,
        disable_anonymous_signature:1, leave_on_interrupt:1, leave_on_terminate:1,
        advertise_addr:1, pid_file:1, plugin_dir:1, http_proxy:1, limits:1, tls:0 },
      server: { enabled:1, bootstrap_expect:1, encrypt:1, heartbeat_grace:1, min_heartbeat_ttl:1,
        max_heartbeats_per_second:1, retry_join:1, retry_max:1, retry_interval:1, start_join:1,
        rejoin_after_leave:1, node_gc_threshold:1, job_gc_threshold:1, eval_gc_threshold:1,
        deployment_gc_threshold:1, non_voting_server:1, raft_protocol:1, authoritative_region:1,
        redundant_region:1, upgrade_version:1, data_dir:1, encrypt_rpc:1 },
      client: { enabled:1, node_class:1, reserved:1, gc_interval:1, gc_disk_usage_threshold:1,
        gc_inode_usage_threshold:1, gc_max_allocs:1, gc_parallel_destroys:1, no_host_uuid:1,
        max_kill_timeout:1, client_min_port:1, client_max_port:1, reserved_ports:1,
        cni_path:1, bridge_network_name:1, chroot_env:1, disable_remote_hcl:1 },
      acl: { enabled:1, token_ttl:1, policy_ttl:1, role_ttl:1, replication_token:1 },
      tls: { http:1, rpc:1, verify_server_hostname:1, verify_https_client:1, ca_file:1, cert_file:1,
        key_file:1, rpc_upgrade_mode:1, tls_cipher_suites:1, tls_min_version:1,
        tls_prefer_server_cipher_suites:1, client_cert_file:1, client_key_file:1 },
      consul: { address:1, token:1, auth:1, ssl:1, verify_ssl:1, ca_file:1, cert_file:1, key_file:1,
        auto_advertise:1, checks_use_advertise:1, client_auto_join:1, server_auto_join:1,
        server_service_name:1, client_service_name:1, service_identity:1, task_identity:1,
        allow_unauthenticated:1, grpc_address:1, timeout:1 },
      vault: { enabled:1, address:1, token:1, allow_unauthenticated:1, create_from_role:1,
        ca_file:1, ca_path:1, cert_file:1, key_file:1, tls_skip_verify:1, namespace:1 },
      telemetry: { collection_interval:1, disable_hostname:1, publish_allocation_metrics:1,
        publish_node_metrics:1, prometheus_metrics:1, filter_default:1, prefix_filter:1,
        statsd_address:1, statsite_address:1, datadog_address:1, datadog_tags:1,
        disable_tagged_metrics:1, use_node_name:1, in_memory_collection_interval:1,
        in_memory_retention_period:1 },
      ports: { http:1, rpc:1, serf:1 },
      advertise: { http:1, rpc:1, serf:1 },
      ui: { enabled:1 },
      autopilot: { cleanup_dead_servers:1, last_contact_threshold:1, max_trailing_logs:1,
        min_quorum:1, server_stabilization_time:1, enable_redundancy_zones:1,
        disable_upgrade_migration:1, enable_custom_upgrades:1 },
      server_join: { retry_join:1, retry_max:1, retry_interval:1, start_join:1 },
      host_volume: { path:1, read_only:1 },
      plugin: {}
    };
    KNOWN_KEYS["(root)"] = KNOWN_KEYS.root;

    function walkUnknown(node, ctxName, counter) {
      var keys = KNOWN_KEYS[ctxName] || null;
      var nested = KNOWN_NESTED[ctxName] || null;
      for (var i = 0; i < node.children.length; i++) {
        var c = node.children[i];
        if (c.type === "attr") {
          if (FREE_FORM_BLOCKS[ctxName]) continue;
          if (!keys || !keys[c.key]) counter.n++;
        } else if (c.type === "block") {
          var known;
          if (ctxName === "root") known = !!KNOWN_ROOT_BLOCKS[c.name];
          else known = !!(nested && nested[c.name]);
          if (!known) { counter.n++; }
          else walkUnknown(c, c.name, counter);
        } else if (c.type === "stray") { counter.n++; }
      }
    }

    /* ---------------- Audit ---------------- */
    function audit(text) {
      var tokens, root;
      try {
        tokens = tokenize(text);
        root = parse(tokens);
      } catch (e) {
        if (e && e.notParsed) {
          return {
            notParsed: true, line: e.line,
            verdict: "NOT PARSED",
            findings: [{ sev: "BLOCKER", line: e.line, check: "Parse", title: "Config not parsed",
              msg: e.msg + " The audit stopped here — a config that does not parse gets no guessed-at findings.",
              fix: "Fix the brace balance at the line shown, then re-audit." }],
            counts: { blockers: 1, warnings: 0, notes: 0, notAudited: 0 }
          };
        }
        throw e;
      }

      var findings = [];
      function add(sev, line, check, title, msg, fix) {
        findings.push({ sev: sev, line: line || null, check: check, title: title, msg: msg, fix: fix });
      }

      var server = findBlock(root, "server");
      var client = findBlock(root, "client");
      var acl = findBlock(root, "acl");
      var tls = findBlock(root, "tls");
      var consul = findBlock(root, "consul");
      var vault = findBlock(root, "vault");
      var telemetry = findBlock(root, "telemetry");

      var serverEnabledOff = server && isFalse(findAttr(server, "enabled"));
      var isServer = !!server && !serverEnabledOff;
      var clientEnabledAttr = client ? findAttr(client, "enabled") : null;
      var clientOn = client && !isFalse(clientEnabledAttr) &&
        (isTrue(clientEnabledAttr) || !clientEnabledAttr);

      /* ---- Posture facts ---- */
      var aclOn = acl && isTrue(findAttr(acl, "enabled"));
      var tlsHttpOn = tls && isTrue(findAttr(tls, "http"));
      var tlsRpcOn = tls && isTrue(findAttr(tls, "rpc"));

      var bindAttr = findAttr(root, "bind_addr");
      var bindVal = bindAttr ? String(bindAttr.value) : null;
      var exposedBind = bindVal === "0.0.0.0" || bindVal === "::";

      var advertisePublic = false, advertiseLine = null, advertiseDesc = "";
      var advCandidates = [];
      var advAddrAttr = findAttr(root, "advertise_addr");
      if (advAddrAttr) advCandidates.push({ a: advAddrAttr, what: "advertise_addr" });
      var advBlock = findBlock(root, "advertise");
      if (advBlock) {
        ["http", "rpc", "serf"].forEach(function (k) {
          var a = findAttr(advBlock, k);
          if (a) advCandidates.push({ a: a, what: "advertise." + k });
        });
      }
      advCandidates.forEach(function (cand) {
        var ip = ipPart(cand.a.value);
        if (!ip || !looksLikeIP(ip)) return;
        if (ip === "0.0.0.0" || ip === "::" || !isPrivateIP(ip)) {
          advertisePublic = true; advertiseLine = cand.a.line; advertiseDesc = cand.what;
        }
      });
      var exposed = exposedBind || advertisePublic;
      var postureTxt = "Current posture in this file: ACLs " + (aclOn ? "enabled" : "not enabled") +
        ", TLS for HTTP " + (tlsHttpOn ? "on" : "off") + ", TLS for RPC " + (tlsRpcOn ? "on" : "off") + ".";

      /* ---- ACL ---- */
      if (isServer) {
        if (!acl) {
          add("BLOCKER", server.line, "ACL", "No acl block on a server config",
            "This config defines a server but has no acl block, so Nomad runs with ACLs off: any client that can reach the API can submit, inspect, and stop jobs.",
            'Add an acl block with enabled = true, then bootstrap ACLs and issue tokens before the server takes traffic.');
        } else {
          var aclEnabled = findAttr(acl, "enabled");
          if (!aclEnabled) {
            add("BLOCKER", acl.line, "ACL", "acl block present but enabled is not set",
              "Nomad defaults ACLs to off when acl.enabled is not set, so this server runs unauthenticated even though an acl block exists.",
              "Set enabled = true inside the acl block, then bootstrap ACLs and issue tokens.");
          } else if (isFalse(aclEnabled)) {
            add("BLOCKER", aclEnabled.line, "ACL", "ACLs explicitly disabled (acl.enabled = false)",
              "With ACLs disabled, anyone who can reach the HTTP API or RPC ports has full control of the cluster — submit jobs, read variables, stop allocations.",
              "Set acl.enabled = true, bootstrap ACLs (nomad acl bootstrap), and distribute tokens to operators and clients.");
          } else if (isTrue(aclEnabled)) {
            add("NOTE", aclEnabled.line, "ACL", "ACLs enabled",
              "acl.enabled = true — API and RPC calls require tokens. Keep the bootstrap token somewhere safer than this file.",
              "No change needed.");
          }
        }
      } else if (!server && !client) {
        add("NOTE", null, "Structure", "No server or client block found",
          "The pasted text has neither a server nor a client block. The audit graded what was pasted; this may be a partial config.",
          "Paste the full agent config for a complete audit.");
      }

      /* ---- TLS ---- */
      if (!tls) {
        add(exposed ? "BLOCKER" : "WARNING", bindAttr ? bindAttr.line : null, "TLS", "No tls block — HTTP and RPC are unencrypted",
          "Without a tls block, Nomad serves its HTTP API and RPC in plaintext." + (exposed ? " This config is also reachable on exposed addresses (see the bind/advertise findings), which escalates this to a blocker: credentials and job specs cross the network readable by anyone on the path." : " On a locked-down private network this is a warning; combined with an exposed bind or advertise address it becomes a blocker."),
          "Add a tls block with http = true, rpc = true, verify_server_hostname = true, and ca_file / cert_file / key_file pointing at your CA material.");
      } else {
        var httpA = findAttr(tls, "http");
        if (!isTrue(httpA)) {
          add(exposed ? "BLOCKER" : "WARNING", httpA ? httpA.line : tls.line, "TLS",
            httpA ? "tls.http = false — HTTP API is unencrypted" : "tls.http is not set — defaults to off",
            "The HTTP API (jobs, variables, ACL tokens in headers) travels in plaintext." + (exposed ? " Because this config binds or advertises on exposed addresses, plaintext API traffic is reachable beyond the host — blocker." : ""),
            "Set tls.http = true and provide ca_file / cert_file / key_file.");
        }
        var rpcA = findAttr(tls, "rpc");
        if (!isTrue(rpcA)) {
          add(exposed ? "BLOCKER" : "WARNING", rpcA ? rpcA.line : tls.line, "TLS",
            rpcA ? "tls.rpc = false — RPC is unencrypted" : "tls.rpc is not set — defaults to off",
            "Server-to-server and server-to-client RPC travels in plaintext, so job payloads and dispatch traffic can be read or tampered with in transit." + (exposed ? " Combined with the exposed bind/advertise addresses in this config — blocker." : ""),
            "Set tls.rpc = true with the same CA material as HTTP.");
        }
        var vshA = findAttr(tls, "verify_server_hostname");
        if (isFalse(vshA)) {
          add("WARNING", vshA.line, "TLS", "tls.verify_server_hostname = false",
            "TLS is on, but hostname verification is off: a valid certificate for the wrong host is accepted, which weakens protection against a spoofed server.",
            "Set verify_server_hostname = true and issue certificates whose SANs match the names agents dial (for example server.<region>.nomad).");
        } else if (!vshA) {
          add("NOTE", tls.line, "TLS", "tls.verify_server_hostname is not set",
            "The key is absent, and Nomad's default leaves hostname verification off. Encryption still works, but peer identity rests on the CA alone.",
            "Set verify_server_hostname = true explicitly so the posture is deliberate, not inherited.");
        }
        var vhcA = findAttr(tls, "verify_https_client");
        if (isFalse(vhcA)) {
          add("NOTE", vhcA.line, "TLS", "tls.verify_https_client = false",
            "HTTPS clients are not asked for a certificate. That can be a deliberate choice behind a load balancer, but on a directly exposed API it removes a layer of client identity.",
            "Turn it on for directly exposed agents, or document the compensating control.");
        }
      }

      /* ---- Exposure: bind / advertise ---- */
      if (exposedBind) {
        var bindSev = (!aclOn && !tlsHttpOn) ? "BLOCKER" : "WARNING";
        add(bindSev, bindAttr.line, "Exposure", "bind_addr = \"" + bindVal + "\" — listening on every interface",
          "The agent binds all interfaces, so its HTTP, RPC, and Serf ports answer on every network the host touches. " + postureTxt,
          (!aclOn && !tlsHttpOn)
            ? "Do not expose this agent until ACLs are enabled and TLS is on; better, bind to the private interface address the cluster actually uses."
            : "Bind to the private cluster interface where you can; where 0.0.0.0 is required, keep ACLs and TLS on and firewall 4646/4647/4648 to cluster hosts only.");
      }
      if (advertisePublic) {
        var advSev = (!aclOn && !tlsHttpOn) ? "BLOCKER" : "WARNING";
        add(advSev, advertiseLine, "Exposure", "Advertised address is public or wildcard (" + advertiseDesc + ")",
          "Other agents and clients will dial the advertised address, and it resolves outside the private network. " + postureTxt,
          "Advertise the private address peers should dial (or a template such as {{ GetPrivateIP }}), and keep public reachability behind a firewall or load balancer with ACLs and TLS on.");
      }

      /* ---- Server: bootstrap_expect + encrypt ---- */
      if (server) {
        var be = findAttr(server, "bootstrap_expect");
        if (isServer) {
          if (!be) {
            add("NOTE", server.line, "Server", "bootstrap_expect is not set",
              "Without bootstrap_expect, servers wait for an explicit join instead of forming a cluster on their own. Fine when an orchestrator joins them; a surprise when it does not.",
              "Set bootstrap_expect to the number of servers that must be up to bootstrap (an odd number, 3 or 5 for production).");
          } else {
            var bn = parseInt(be.value, 10);
            if (!isNaN(bn) && be.vtype === "number") {
              if (bn === 0) {
                add("WARNING", be.line, "Server", "bootstrap_expect = 0",
                  "A value of 0 disables automatic bootstrapping entirely — the cluster will not form until servers are joined by hand.",
                  "Use 1 for a throwaway dev agent, or an odd 3 / 5 for production.");
              } else if (bn === 1) {
                add("WARNING", be.line, "Server", "bootstrap_expect = 1 — single-server cluster",
                  "One server means zero fault tolerance: if this host is down, the cluster is down, and its data is the only copy of cluster state. Acceptable for dev and evaluation; a production risk.",
                  "Run 3 servers (or 5 for larger clusters) and set bootstrap_expect to match.");
              } else if (bn % 2 === 0) {
                add("WARNING", be.line, "Server", "bootstrap_expect = " + bn + " — an even number",
                  "Raft quorum for " + bn + " servers is " + (bn / 2 + 1) + ", so the cluster tolerates " + (bn - bn / 2 - 1 + 1 - 1) + " failure" + ((bn / 2 - 1) === 1 ? "" : "s") + " — no better than " + (bn - 1) + " servers, with one more host that can split a vote. Odd counts are strictly better for the same money.",
                  "Use an odd bootstrap_expect — " + (bn - 1) + " or " + (bn + 1) + " — to match the servers you actually run.");
              } else {
                add("NOTE", be.line, "Server", "bootstrap_expect = " + bn,
                  bn + " servers tolerate " + ((bn - 1) / 2) + " simultaneous failure" + (((bn - 1) / 2) === 1 ? "" : "s") + " — a sound quorum size.",
                  "No change needed.");
              }
            }
          }
          var enc = findAttr(server, "encrypt");
          if (!enc) {
            add("WARNING", server.line, "Server", "No encrypt key in the server block — gossip is unencrypted",
              "Without server.encrypt, Serf gossip between agents is not encrypted: anyone who can observe or join the gossip pool sees cluster membership and can attempt to join it.",
              'Generate a key with nomad operator gossip keyring generate and set it as server.encrypt on every server (and client, where used). The value is a secret — this tool never prints it.');
          } else {
            var raw = String(enc.value);
            var pad = /==$/.test(raw) ? 2 : ( /=$/.test(raw) ? 1 : 0 );
            var bytes = Math.max(0, Math.round(raw.length / 4) * 3 - pad);
            var cls = bytes >= 32 ? "32-byte class" : bytes === 16 ? "standard 16-byte class"
              : bytes < 16 ? "shorter than the standard 16-byte key class" : "a non-standard length class (" + raw.length + " characters)";
            if (bytes < 16) {
              add("WARNING", enc.line, "Server", "encrypt key present but short (key \"encrypt\", line " + enc.line + ")",
                "An encrypt key is set, graded by presence and length class only: it falls in " + cls + ". Nomad gossip keys are 16 bytes (32 also accepted); a shorter value usually means a truncated paste or a hand-typed password. The value itself is never shown here.",
                "Replace it with a generated key: nomad operator gossip keyring generate, pasted whole, on every agent that shares the gossip pool.");
            } else {
              add("NOTE", enc.line, "Server", "encrypt key present (key \"encrypt\", line " + enc.line + ")",
                "A gossip encryption key is set, in the " + cls + ". Graded by presence and length class only — the value is never shown, and this tool cannot confirm the same key is installed on the other agents.",
                "No change needed; confirm out-of-band that every agent carries the same key.");
            }
          }
        }
      }

      /* ---- Co-location ---- */
      if (isServer && clientOn) {
        add("NOTE", client.line, "Topology", "Server and client enabled on the same agent",
          "This agent both runs the control plane (server, line " + server.line + ") and accepts workloads (client, line " + client.line + "). Common and convenient in dev; in production, a workload that escapes or exhausts the host takes a server — and its vote — with it.",
          "Prefer dedicated servers in production; keep co-location for dev clusters and small homelabs.");
      }

      /* ---- Risky drivers: options + plugins ---- */
      var optionsBlocks = [];
      collectBlocks(root, "options", optionsBlocks);
      optionsBlocks.forEach(function (ob) {
        ob.children.forEach(function (c) {
          if (c.type !== "attr") return;
          var k = c.key.toLowerCase();
          if (k.indexOf("raw_exec") !== -1 && truthyVal(c)) {
            add("WARNING", c.line, "Drivers", "raw_exec driver enabled via client options",
              "The raw_exec driver runs job commands directly on the host with no container isolation. Any principal who can submit jobs can run arbitrary commands as the Nomad user.",
              'Remove the "driver.raw_exec.enable" option (or set it to "0") on production clients; keep it only on clients fenced off for trusted workloads.');
          }
          if (k.indexOf("docker") !== -1 && k.indexOf("volumes") !== -1 && truthyVal(c)) {
            add("WARNING", c.line, "Drivers", "Docker volumes enabled via client options",
              "driver.docker.volumes lets jobs mount host paths into containers, which can turn a job submission into host filesystem access.",
              'Set "driver.docker.volumes" to "false" unless specific jobs need host mounts, and prefer named volumes where you can.');
          }
        });
      });
      var plugins = [];
      collectPlugins(root, plugins);
      plugins.forEach(function (pl) {
        if ((pl.label || "").toLowerCase() === "raw_exec") {
          var cfg = findBlock(pl, "config");
          var en = cfg ? findAttr(cfg, "enabled") : null;
          if (!isFalse(en)) {
            add("WARNING", pl.line, "Drivers", "raw_exec driver plugin declared",
              "A raw_exec plugin block enables the driver that executes job commands directly on the host, without isolation.",
              "Remove the raw_exec plugin block on production clients, or set enabled = false in its config, unless trusted workloads require it.");
          }
        }
      });

      /* ---- Consul ---- */
      if (consul) {
        var ctok = findAttr(consul, "token");
        if (ctok) {
          add("NOTE", ctok.line, "Consul", "consul.token is set in this file (key \"token\", line " + ctok.line + ")",
            "A Consul ACL token sits in the config file. Its value is never shown by this tool. A token in the file is a token in every backup, screenshot, and repo this file touches.",
            "Prefer delivering the token via the CONSUL_HTTP_TOKEN environment variable or a root-only file, and rotate any token that has been committed or shared.");
        }
        var cvs = findAttr(consul, "verify_ssl");
        if (isFalse(cvs)) {
          add("WARNING", cvs.line, "Consul", "consul.verify_ssl = false",
            "The agent will not verify Consul's TLS certificate, so a spoofed Consul endpoint on the path can intercept registration and lookup traffic.",
            "Set verify_ssl = true and provide consul.ca_file for your Consul CA.");
        }
      }

      /* ---- Vault ---- */
      if (vault) {
        var vtok = findAttr(vault, "token");
        if (vtok) {
          add("NOTE", vtok.line, "Vault", "vault.token is set in this file (key \"token\", line " + vtok.line + ")",
            "A Vault token sits in the config file; its value is never shown by this tool. Prefer Vault's own renewal flow over a long-lived token parked in config.",
            "Use create_from_role with a short-lived token delivered at provisioning, and rotate any token that has been committed or shared.");
        }
        if (isTrue(findAttr(vault, "enabled"))) {
          var vaddr = findAttr(vault, "address");
          if (vaddr && /^http:\/\//i.test(String(vaddr.value))) {
            add("WARNING", vaddr.line, "Vault", "Vault enabled but its address is http:// — no TLS to Vault",
              "Vault is enabled while vault.address uses plain http, so tokens and leased secrets cross to Vault unencrypted. The agent's own tls block does not protect this hop — Vault has its own TLS pairing.",
              "Point vault.address at the https endpoint and set vault.ca_file so the agent verifies Vault's certificate.");
          }
          var vskip = findAttr(vault, "tls_skip_verify");
          if (isTrue(vskip)) {
            add("WARNING", vskip.line, "Vault", "vault.tls_skip_verify = true",
              "The agent skips verifying Vault's certificate, which quietly removes the protection the https address suggests.",
              "Set tls_skip_verify = false and provide vault.ca_file.");
          }
        }
      }

      /* ---- Telemetry ---- */
      if (telemetry) {
        if (isTrue(findAttr(telemetry, "publish_allocation_metrics"))) {
          var pam = findAttr(telemetry, "publish_allocation_metrics");
          add("NOTE", pam.line, "Telemetry", "telemetry.publish_allocation_metrics = true",
            "Per-allocation metrics are published. Useful for chargeback and debugging, but they reveal job names and shapes to anyone who can reach the metrics endpoint — keep that endpoint on the private network.",
            "No change needed if the metrics endpoint is private; otherwise set it to false.");
        }
        if (isTrue(findAttr(telemetry, "disable_hostname"))) {
          var dh = findAttr(telemetry, "disable_hostname");
          add("NOTE", dh.line, "Telemetry", "telemetry.disable_hostname = true",
            "The hostname label is stripped from metrics. Deliberate in multi-tenant metric pipelines; a surprise when you go looking for which host a series came from.",
            "No change needed if intentional; set it to false to keep the hostname label.");
        }
      }

      /* ---- Leave behavior consistency ---- */
      var loi = findAttr(root, "leave_on_interrupt");
      var lot = findAttr(root, "leave_on_terminate");
      if (loi || lot) {
        var loiT = isTrue(loi), lotT = isTrue(lot);
        var present = (loi ? 1 : 0) + (lot ? 1 : 0);
        if (present === 1 || loiT !== lotT) {
          var setOne = loi || lot;
          add("NOTE", setOne.line, "Lifecycle", "leave_on_interrupt and leave_on_terminate disagree",
            "Only one of the pair is set (or they are set differently): the agent leaves the cluster gracefully on one stop signal but is marked down unexpectedly on the other. Orchestrators and init systems send different signals, so the mismatch shows up exactly at upgrade time.",
            "Set both to the same value — usually true for long-lived agents — unless the difference is deliberate and documented.");
        }
      }

      /* ---- Duplicate keys ---- */
      (function dupWalk(node, path) {
        var seen = {};
        node.children.forEach(function (c) {
          if (c.type === "attr") {
            if (c.key === "retry_join" || c.key === "start_join") return;
            if (seen[c.key] !== undefined) {
              add("WARNING", c.line, "Duplicates", "Duplicate key \"" + c.key + "\" in " + path,
                "\"" + c.key + "\" is set at line " + seen[c.key] + " and again at line " + c.line + " in the same block. HCL keeps the last value and discards the first, so the line " + seen[c.key] + " setting is dead text — and a classic source of \"I changed it but nothing happened.\"",
                "Delete the setting you do not mean, keeping one \"" + c.key + "\" per block.");
            } else { seen[c.key] = c.line; }
          }
        });
        node.children.forEach(function (c) {
          if (c.type === "block") dupWalk(c, path === "the top level" ? "block \"" + c.name + "\"" : path + " › \"" + c.name + "\"");
        });
      })(root, "the top level");

      /* ---- Unknown surface ---- */
      var counter = { n: 0 };
      walkUnknown(root, "root", counter);

      var sevRank = { BLOCKER: 0, WARNING: 1, NOTE: 2 };
      findings.sort(function (a, b) {
        if (sevRank[a.sev] !== sevRank[b.sev]) return sevRank[a.sev] - sevRank[b.sev];
        var la = a.line === null ? 99999 : a.line, lb = b.line === null ? 99999 : b.line;
        return la - lb;
      });

      var counts = { blockers: 0, warnings: 0, notes: 0, notAudited: counter.n };
      findings.forEach(function (f) {
        if (f.sev === "BLOCKER") counts.blockers++;
        else if (f.sev === "WARNING") counts.warnings++;
        else counts.notes++;
      });

      var verdict = counts.blockers > 0 ? "DO NOT DEPLOY"
        : counts.warnings > 0 ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY";

      return { notParsed: false, verdict: verdict, findings: findings, counts: counts };
    }

    /* ---------------- Rendering ---------------- */
    function esc(s) {
      return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
    }
    var lastResult = null;

    function buildTextReport(r) {
      var lines = [];
      lines.push("J-Dawgs Nomad Agent Config Safety Auditor — text report");
      lines.push("Verdict: " + r.verdict);
      lines.push("Counts: " + r.counts.blockers + " blocker(s), " + r.counts.warnings +
        " warning(s), " + r.counts.notes + " note(s), " + r.counts.notAudited + " item(s) not audited");
      lines.push("----------------------------------------------------------------");
      if (!r.findings.length) lines.push("No findings.");
      r.findings.forEach(function (f) {
        lines.push("[" + f.sev + "] " + (f.line ? "Line " + f.line + " — " : "") + f.title);
        lines.push("  Finding: " + f.msg);
        lines.push("  Fix: " + f.fix);
      });
      if (r.counts.notAudited > 0) {
        lines.push("NOT AUDITED: " + r.counts.notAudited + " block(s)/key(s) were not recognized " +
          "by this tool's check set. They were counted, not guessed at — review them by hand.");
      }
      lines.push("----------------------------------------------------------------");
      lines.push("Text audit of a pasted config only. Never connected to a cluster; " +
        "certificates, live gossip encryption, and host firewalling were not verified. " +
        "Token and encrypt values are never printed by this tool.");
      return lines.join("\n");
    }

    function buildJson(r) {
      return JSON.stringify({
        tool: "J-Dawgs Nomad Agent Config Safety Auditor",
        verdict: r.verdict,
        counts: {
          blockers: r.counts.blockers,
          warnings: r.counts.warnings,
          notes: r.counts.notes,
          not_audited: r.counts.notAudited
        },
        findings: r.findings.map(function (f) {
          return { severity: f.sev, line: f.line, check: f.check, title: f.title, finding: f.msg, fix: f.fix };
        }),
        scope: "Text audit of pasted config only; no cluster connection; token and encrypt values never included."
      }, null, 2);
    }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-nomad-agent-config-safety-auditor',
  name: 'J-Dawgs Nomad Agent Config Safety Auditor',
  description: 'Grades a pasted Nomad agent config offline — ACL, TLS, and exposure posture — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
