'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Elasticsearch Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var RISKY_EXAMPLE = [
        "# Risky example — a tutorial config headed for a shared host",
        "cluster.name: risky-cluster",
        "node.name: node-1",
        "network.host: 0.0.0.0",
        "discovery.type: single-node",
        "action.destructive_requires_name: false",
        "http.cors.enabled: true",
        'http.cors.allow-origin: "*"'
      ].join("\n");

      var HARDENED_EXAMPLE = [
        "# Hardened example — loopback bind, security on, TLS present",
        "cluster.name: hardened-cluster",
        "node.name: node-1",
        "network:",
        "  host: 127.0.0.1",
        "xpack:",
        "  security:",
        "    enabled: true",
        "    http:",
        "      ssl:",
        "        enabled: true",
        "        keystore:",
        "          path: certs/http.p12",
        "    transport:",
        "      ssl:",
        "        enabled: true",
        "        verification_mode: certificate",
        "        keystore:",
        "          path: certs/transport.p12",
        "action.destructive_requires_name: true",
        'discovery.seed_hosts: ["node-1", "node-2", "node-3"]',
        'cluster.initial_master_nodes: ["node-1", "node-2", "node-3"]'
      ].join("\n");

      var SECRET_WORDS = ["password", "passwd", "secret", "token", "credential", "api_key", "apikey", "secure_password"];

      /* ---------- parsing ---------- */

      function stripComment(line) {
        var inS = false, inD = false, i, c;
        for (i = 0; i < line.length; i++) {
          c = line.charAt(i);
          if (c === "'" && !inD) { inS = !inS; }
          else if (c === '"' && !inS) { inD = !inD; }
          else if (c === "#" && !inS && !inD && (i === 0 || /\s/.test(line.charAt(i - 1)))) {
            return line.slice(0, i);
          }
        }
        return line;
      }

      function parseScalar(raw) {
        var v = raw.trim();
        if (v.length >= 2) {
          var first = v.charAt(0), last = v.charAt(v.length - 1);
          if ((first === '"' && last === '"') || (first === "'" && last === "'")) {
            return v.slice(1, v.length - 1);
          }
        }
        return v;
      }

      function splitListItems(inner) {
        var items = [], cur = "", inS = false, inD = false, i, c;
        for (i = 0; i < inner.length; i++) {
          c = inner.charAt(i);
          if (c === "'" && !inD) { inS = !inS; cur += c; }
          else if (c === '"' && !inS) { inD = !inD; cur += c; }
          else if (c === "," && !inS && !inD) { items.push(cur); cur = ""; }
          else { cur += c; }
        }
        if (cur.trim() !== "" || items.length) { items.push(cur); }
        var out = [];
        for (i = 0; i < items.length; i++) {
          var t = items[i].trim();
          if (t !== "") { out.push(parseScalar(t)); }
        }
        return out;
      }

      function isSecretKey(key) {
        var lk = key.toLowerCase(), i;
        for (i = 0; i < SECRET_WORDS.length; i++) {
          if (lk.indexOf(SECRET_WORDS[i]) !== -1) { return true; }
        }
        return false;
      }

      function parseConfig(text) {
        var rawLines = text.split(/\r?\n/);
        var entries = {};       // dotted key -> {value, list, line, isParent}
        var notParsed = [];     // line numbers
        var duplicates = [];    // {key, firstLine, line}
        var stack = [];         // {indent, key}
        var listTarget = null;  // {key, keyIndent}
        var i, raw, content, indent, trimmed, lineNo;

        function noteEntry(key, entry) {
          if (Object.prototype.hasOwnProperty.call(entries, key)) {
            duplicates.push({ key: key, firstLine: entries[key].line, line: entry.line });
            return false;
          }
          entries[key] = entry;
          return true;
        }

        for (i = 0; i < rawLines.length; i++) {
          lineNo = i + 1;
          raw = rawLines[i];
          if (/^\t/.test(raw) || /^ +\t/.test(raw)) { notParsed.push(lineNo); listTarget = null; continue; }
          content = stripComment(raw);
          if (content.trim() === "") { continue; }
          indent = content.length - content.replace(/^ +/, "").length;
          trimmed = content.trim();

          // Block list item
          if (trimmed === "-" || trimmed.indexOf("- ") === 0) {
            var itemRaw = trimmed === "-" ? "" : trimmed.slice(2).trim();
            if (!listTarget || indent < listTarget.keyIndent || itemRaw === "") {
              notParsed.push(lineNo);
              continue;
            }
            var tgt = entries[listTarget.key];
            if (tgt) {
              if (!tgt.list) { tgt.list = []; }
              tgt.list.push(parseScalar(itemRaw));
            }
            continue;
          }

          // Key line
          var m = trimmed.match(/^([A-Za-z0-9_][A-Za-z0-9_.\-]*)\s*:\s*(.*)$/);
          if (!m) { notParsed.push(lineNo); listTarget = null; continue; }
          var keyPart = m[1];
          var valuePart = m[2].trim();

          while (stack.length && stack[stack.length - 1].indent >= indent) { stack.pop(); }
          if (stack.length === 0) {
            if (indent !== 0) { notParsed.push(lineNo); listTarget = null; continue; }
          } else {
            if (indent !== stack[stack.length - 1].indent + 2) { notParsed.push(lineNo); listTarget = null; continue; }
          }
          var parentPath = stack.length ? stack[stack.length - 1].key : "";
          var fullKey = parentPath ? parentPath + "." + keyPart : keyPart;

          if (valuePart === "") {
            // Opens a mapping or a block list.
            noteEntry(fullKey, { value: null, list: null, line: lineNo, isParent: true });
            stack.push({ indent: indent, key: fullKey });
            listTarget = { key: fullKey, keyIndent: indent };
          } else if (valuePart.charAt(0) === "[") {
            if (valuePart.charAt(valuePart.length - 1) !== "]") { notParsed.push(lineNo); listTarget = null; continue; }
            var items = splitListItems(valuePart.slice(1, valuePart.length - 1));
            noteEntry(fullKey, { value: null, list: items, line: lineNo, isParent: false });
            listTarget = null;
          } else {
            noteEntry(fullKey, { value: parseScalar(valuePart), list: null, line: lineNo, isParent: false });
            listTarget = null;
          }
        }
        return { entries: entries, notParsed: notParsed, duplicates: duplicates, lineCount: rawLines.length };
      }

      /* ---------- grading helpers ---------- */

      function getEntry(entries, key) {
        return Object.prototype.hasOwnProperty.call(entries, key) ? entries[key] : null;
      }
      function scalarOf(entry) {
        if (!entry) { return null; }
        if (entry.list) { return entry.list.join(", "); }
        return entry.value;
      }
      function boolOf(entry) {
        var v = scalarOf(entry);
        if (v === null || v === undefined) { return null; }
        var lv = String(v).trim().toLowerCase();
        if (lv === "true") { return true; }
        if (lv === "false") { return false; }
        return null;
      }
      function listOf(entry) {
        if (!entry) { return null; }
        if (entry.list) { return entry.list.slice(); }
        if (entry.value !== null && entry.value !== undefined && entry.value !== "") { return [String(entry.value)]; }
        return [];
      }

      function classifyHost(v) {
        var s = String(v).trim().toLowerCase();
        if (s === "_local_" || s === "_loopback_" || s === "localhost" || s === "::1" || s.indexOf("127.") === 0) { return "loopback"; }
        if (s === "0.0.0.0" || s === "::" || s === "_global_") { return "wildcard"; }
        if (s === "_site_") { return "site"; }
        if (s.charAt(0) === "_") { return "interface"; }
        var m = s.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
        if (m) {
          var a = parseInt(m[1], 10), b = parseInt(m[2], 10);
          if (a === 10) { return "private"; }
          if (a === 172 && b >= 16 && b <= 31) { return "private"; }
          if (a === 192 && b === 168) { return "private"; }
          if (a === 169 && b === 254) { return "private"; }
          return "public";
        }
        return "hostname";
      }
      var HOST_RANK = { loopback: 0, private: 1, hostname: 2, interface: 2, site: 3, public: 3, wildcard: 4 };

      function hostClassOf(entries) {
        var e = getEntry(entries, "network.host") || getEntry(entries, "network.bind_host");
        if (!e) { return { cls: "default-loopback", values: [], entry: null }; }
        var vals = listOf(e) || [];
        var worst = "loopback";
        for (var i = 0; i < vals.length; i++) {
          var c = classifyHost(vals[i]);
          if (HOST_RANK[c] > HOST_RANK[worst]) { worst = c; }
        }
        return { cls: worst, values: vals, entry: e };
      }
      function isExposed(cls) {
        return cls === "wildcard" || cls === "public" || cls === "site" || cls === "interface" || cls === "hostname";
      }

      /* ---------- audit ---------- */

      function audit(text) {
        var parsed = parseConfig(text);
        var entries = parsed.entries;
        var findings = [];   // {sev, title, detail, lines: "Line 4" etc.}
        var positives = [];
        var keys = Object.keys(entries);
        var scalarKeyCount = 0, k;
        for (k = 0; k < keys.length; k++) { if (!entries[keys[k]].isParent) { scalarKeyCount++; } }

        function add(sev, title, detail, linesLabel) {
          findings.push({ sev: sev, title: title, detail: detail, lines: linesLabel || "" });
        }
        function lineLabel(entry) { return entry ? "Line " + entry.line : "Not set"; }

        // NOT PARSED lines
        for (k = 0; k < parsed.notParsed.length; k++) {
          add("NOT PARSED",
            "Line " + parsed.notParsed[k] + " could not be parsed",
            "This line is not flat dotted-key YAML or simple 2-space nested YAML, so it was excluded from grading. The auditor never guesses past a line it cannot read — fix the line and re-audit.",
            "Line " + parsed.notParsed[k]);
        }

        // Duplicates
        for (k = 0; k < parsed.duplicates.length; k++) {
          var d = parsed.duplicates[k];
          add("WARNING",
            "Duplicate key: " + d.key,
            "This key is defined on line " + d.firstLine + " and again on line " + d.line + ". The first value was graded; a real node may reject the file or take the last value. Keep one definition.",
            "Lines " + d.firstLine + " and " + d.line);
        }

        // Plain-text secrets — key name and line only, never the value.
        var secretCount = 0;
        for (k = 0; k < keys.length; k++) {
          var key = keys[k], e = entries[key];
          if (e.isParent) { continue; }
          if (isSecretKey(key)) {
            secretCount++;
            add("WARNING",
              "Secret stored in plain text: " + key,
              "This key holds a credential value directly in elasticsearch.yml. Move it into the Elasticsearch keystore (elasticsearch-keystore) and reference it from the config instead. The value is never shown in this audit.",
              lineLabel(e));
          }
        }
        if (secretCount === 0 && scalarKeyCount > 0) {
          positives.push("No password, secret, token, or credential keys found in the pasted file.");
        }

        // Bind + security pairing
        var host = hostClassOf(entries);
        var secEntry = getEntry(entries, "xpack.security.enabled");
        var secVal = boolOf(secEntry);
        var securityOn = secVal === true;
        var hostLine = lineLabel(host.entry);
        var hostDesc = host.values.length ? host.values.join(", ") : "(default)";
        var nonLoopback = host.cls !== "loopback" && host.cls !== "default-loopback";

        if (host.cls === "default-loopback") {
          add("NOTE",
            "network.host is not set",
            "With no network.host, Elasticsearch binds loopback only. That is a development posture: fine on a workstation, not a production answer for a shared host.",
            "Not set");
        }

        if (isExposed(host.cls)) {
          if (!securityOn) {
            add("BLOCKER",
              "Exposed bind with security off or unset",
              "network.host is " + hostDesc + " — reachable beyond this host — while xpack.security.enabled is " + (secEntry ? "false" : "absent") + ". Anyone who can reach the HTTP or transport port can read, write, and delete the cluster's data. Set xpack.security.enabled: true and bind to loopback or a private address before this goes anywhere shared.",
              hostLine + (secEntry ? " · " + lineLabel(secEntry) : " · xpack.security.enabled not set"));
          } else {
            add("WARNING",
              "Exposed bind — reachable beyond this host",
              "network.host is " + hostDesc + ". Security is enabled, but this node answers on non-loopback interfaces: confirm TLS is enforced, firewall rules restrict 9200/9300 to known hosts, and the exposure is deliberate.",
              hostLine + " · " + lineLabel(secEntry));
          }
        } else if (host.cls === "private") {
          if (!securityOn) {
            add("BLOCKER",
              "Private-network bind with security off or unset",
              "network.host is " + hostDesc + " — a non-loopback private address — while xpack.security.enabled is " + (secEntry ? "false" : "absent") + ". Every device on that network can reach this cluster with no authentication. Enable security or bind to loopback.",
              hostLine + (secEntry ? " · " + lineLabel(secEntry) : " · xpack.security.enabled not set"));
          } else {
            add("NOTE",
              "Private-network bind with security enabled",
              "network.host is " + hostDesc + ", a non-loopback private address, so the node is reachable from the local network. Security is enabled; keep the network boundary honest and it is a reasonable posture.",
              hostLine + " · " + lineLabel(secEntry));
            positives.push("Bind stays on a private address with security enabled (lines " + host.entry.line + " and " + secEntry.line + ").");
          }
        } else {
          // loopback or default-loopback
          if (secEntry && secVal === false) {
            add("WARNING",
              "Development posture: security explicitly off",
              "xpack.security.enabled is false with a loopback-only bind. That is the development posture — acceptable on a local workstation, and it must not travel to a shared host or a non-loopback bind.",
              lineLabel(secEntry) + " · " + hostLine);
          } else if (!secEntry) {
            add("WARNING",
              "Development posture: no security setting",
              "There is no xpack.security.enabled setting and the bind is loopback-only — the development posture. Fine for local work; a production node needs security enabled and, with it, TLS and users configured.",
              hostLine + " · xpack.security.enabled not set");
          } else if (securityOn) {
            positives.push("Loopback-only bind with xpack.security.enabled: true (line " + secEntry.line + ").");
          }
        }

        // Single-node discovery + bind
        var dtEntry = getEntry(entries, "discovery.type");
        var dtVal = scalarOf(dtEntry);
        if (dtVal && String(dtVal).trim().toLowerCase() === "single-node") {
          if (nonLoopback) {
            add("BLOCKER",
              "single-node discovery on a non-loopback bind",
              "discovery.type: single-node makes the node form a one-node cluster and skips the production bootstrap checks that would flag this exposure. Combined with the non-loopback bind on " + hostDesc + ", a starting-but-dangerous node waves itself through. Use real discovery settings (discovery.seed_hosts and cluster.initial_master_nodes) for anything beyond a laptop.",
              lineLabel(dtEntry) + " · " + hostLine);
          } else {
            add("NOTE",
              "single-node discovery on a loopback bind",
              "discovery.type: single-node with a loopback-only bind is the standard local-development setup. It is not a production discovery posture.",
              lineLabel(dtEntry));
          }
        }

        // CORS
        var corsE = getEntry(entries, "http.cors.enabled");
        var corsO = getEntry(entries, "http.cors.allow-origin");
        if (boolOf(corsE) === true) {
          var originVal = scalarOf(corsO);
          if (originVal && String(originVal).indexOf("*") !== -1) {
            add("WARNING",
              "CORS open to every origin",
              'http.cors.enabled is true and http.cors.allow-origin is "*", so any website a user visits can make their browser talk to this cluster. Restrict allow-origin to the specific origins that need access.',
              lineLabel(corsE) + " · " + lineLabel(corsO));
          } else {
            add("NOTE",
              "CORS enabled with a restricted origin",
              "http.cors.enabled is true and allow-origin does not open to every origin. Keep the list as short as the clients allow.",
              lineLabel(corsE) + (corsO ? " · " + lineLabel(corsO) : ""));
          }
        }

        // Destructive actions
        var destEntry = getEntry(entries, "action.destructive_requires_name");
        var destVal = boolOf(destEntry);
        if (destVal === false) {
          add("WARNING",
            "Destructive actions do not require a name",
            "action.destructive_requires_name is false, so wildcard deletes (DELETE /_all, DELETE /*) are allowed. One mistyped request can destroy every index. Set it to true so destructive calls must name their target.",
            lineLabel(destEntry));
        } else if (destVal === true) {
          positives.push("action.destructive_requires_name: true — wildcard deletes are blocked (line " + destEntry.line + ").");
        }

        // Scripting posture
        var stEntry = getEntry(entries, "script.allowed_types");
        if (stEntry) {
          var types = listOf(stEntry) || [];
          var hasInline = false, i;
          for (i = 0; i < types.length; i++) { if (String(types[i]).trim().toLowerCase() === "inline") { hasInline = true; } }
          if (hasInline) {
            add("WARNING",
              "Inline scripting is enabled",
              "script.allowed_types includes inline, so any client that can reach the cluster can submit arbitrary scripts in requests. Prefer stored scripts, and drop inline unless a client genuinely needs it.",
              lineLabel(stEntry));
          } else {
            add("NOTE",
              "Scripting restricted to non-inline types",
              "script.allowed_types is set to " + types.join(", ") + " — inline scripting is not on the list.",
              lineLabel(stEntry));
          }
        }
        var legacyInline = getEntry(entries, "script.inline");
        if (legacyInline && boolOf(legacyInline) === true) {
          add("WARNING",
            "Legacy inline scripting switch is on",
            "script.inline is true (a legacy setting). Inline scripts run arbitrary code in requests; turn it off and use stored scripts.",
            lineLabel(legacyInline));
        }

        // Master nodes vs seed hosts consistency
        var mastersEntry = getEntry(entries, "cluster.initial_master_nodes");
        var seedsEntry = getEntry(entries, "discovery.seed_hosts");
        if (mastersEntry && seedsEntry) {
          var masters = listOf(mastersEntry) || [];
          var seeds = listOf(seedsEntry) || [];
          var seedNames = {};
          var si;
          for (si = 0; si < seeds.length; si++) {
            var sn = String(seeds[si]).split(":")[0].trim().toLowerCase();
            seedNames[sn] = true;
          }
          var missing = [];
          for (si = 0; si < masters.length; si++) {
            var mn = String(masters[si]).trim();
            if (!seedNames[mn.toLowerCase()]) { missing.push(mn); }
          }
          if (missing.length) {
            add("WARNING",
              "initial_master_nodes and seed_hosts disagree",
              "cluster.initial_master_nodes lists " + missing.join(", ") + ", but discovery.seed_hosts does not include " + (missing.length === 1 ? "it" : "them") + " by name. Master-eligible nodes that discovery cannot find can stall cluster formation. Make the two lists agree.",
              lineLabel(mastersEntry) + " · " + lineLabel(seedsEntry));
          } else if (masters.length) {
            positives.push("cluster.initial_master_nodes and discovery.seed_hosts agree (lines " + mastersEntry.line + " and " + seedsEntry.line + ").");
          }
        }

        // Published ports beyond loopback
        if (nonLoopback) {
          var httpPortE = getEntry(entries, "http.port");
          var transPortE = getEntry(entries, "transport.port");
          var httpPort = scalarOf(httpPortE) || "9200 (default)";
          var transPort = scalarOf(transPortE) || "9300 (default)";
          add("NOTE",
            "Ports published beyond loopback",
            "With this bind, the HTTP port " + httpPort + " and the transport port " + transPort + " answer on non-loopback interfaces. Anything that can route to this host can knock on both; the transport port should only ever be reachable by other cluster nodes.",
            hostLine + (httpPortE ? " · " + lineLabel(httpPortE) : "") + (transPortE ? " · " + lineLabel(transPortE) : ""));
          var pubE = getEntry(entries, "network.publish_host");
          if (pubE) {
            var pubVal = scalarOf(pubE);
            if (pubVal && classifyHost(pubVal) !== "loopback") {
              add("NOTE",
                "publish_host is non-loopback",
                "network.publish_host advertises a non-loopback address to other nodes. That is normal inside a cluster and worth a second look anywhere else.",
                lineLabel(pubE));
            }
          }
        }

        // TLS posture when security is on
        if (securityOn) {
          var hasHttpTls = false, hasTransTls = false;
          for (k = 0; k < keys.length; k++) {
            if (keys[k].indexOf("xpack.security.http.ssl.") === 0) { hasHttpTls = true; }
            if (keys[k].indexOf("xpack.security.transport.ssl.") === 0) { hasTransTls = true; }
          }
          if (hasHttpTls && hasTransTls) {
            positives.push("TLS settings present for both HTTP and transport layers.");
          } else if (hasHttpTls || hasTransTls) {
            positives.push("TLS settings present for the " + (hasHttpTls ? "HTTP" : "transport") + " layer; no " + (hasHttpTls ? "transport" : "HTTP") + " TLS settings appear in the pasted file.");
          } else {
            add("NOTE",
              "Security on, but no TLS settings in the pasted file",
              "xpack.security.enabled is true, yet no xpack.security.http.ssl or xpack.security.transport.ssl settings appear in the pasted text. TLS may be configured in another file — this audit only sees what was pasted.",
              lineLabel(secEntry));
          }
        }

        if (parsed.duplicates.length === 0 && scalarKeyCount > 0) {
          positives.push("No duplicate keys — every setting is defined exactly once.");
        }

        // Verdict
        var counts = { BLOCKER: 0, WARNING: 0, NOTE: 0, "NOT PARSED": 0 };
        for (k = 0; k < findings.length; k++) { counts[findings[k].sev]++; }

        var verdict, verdictClass, why;
        if (scalarKeyCount === 0 && parsed.notParsed.length === 0) {
          verdict = "NOT PARSED";
          verdictClass = "v-np";
          why = "Nothing to audit — the input was empty. Paste an elasticsearch.yml and run the audit again.";
        } else if (scalarKeyCount === 0) {
          verdict = "NOT PARSED";
          verdictClass = "v-np";
          why = "No setting in the pasted text could be parsed, so there is nothing safe to grade. The unparsed lines are listed below; the auditor never guesses past them.";
        } else if (counts.BLOCKER > 0) {
          verdict = "DO NOT DEPLOY";
          verdictClass = "v-no";
          why = counts.BLOCKER + (counts.BLOCKER === 1 ? " blocker" : " blockers") + " must be fixed before this config goes on any host other people can reach.";
        } else if (counts.WARNING > 0 || counts["NOT PARSED"] > 0) {
          verdict = "DEPLOY WITH FIXES";
          verdictClass = "v-fixes";
          why = "No blockers, but " + (counts.WARNING + counts["NOT PARSED"]) + (counts.WARNING + counts["NOT PARSED"] === 1 ? " item needs" : " items need") + " attention before this is production-clean.";
        } else {
          verdict = "SAFE TO DEPLOY";
          verdictClass = "v-safe";
          why = "No blockers, no warnings, and nothing unparsed. The pasted config's bind, security, discovery, and destructive-action posture all check out — within the limits of a text audit.";
        }

        return {
          verdict: verdict, verdictClass: verdictClass, why: why,
          findings: findings, positives: positives, counts: counts,
          keyCount: scalarKeyCount
        };
      }

      /* ---------- report ---------- */

      function buildReport(result) {
        var out = [];
        out.push("J-Dawgs Elasticsearch Server Config Safety Auditor — report");
        out.push("Verdict: " + result.verdict);
        out.push("Settings parsed: " + result.keyCount +
          " · Blockers: " + result.counts.BLOCKER +
          " · Warnings: " + result.counts.WARNING +
          " · Notes: " + result.counts.NOTE +
          " · Not parsed: " + result.counts["NOT PARSED"]);
        out.push("");
        if (result.findings.length) {
          out.push("Findings:");
          for (var i = 0; i < result.findings.length; i++) {
            var f = result.findings[i];
            out.push("[" + f.sev + "] " + f.title + (f.lines ? " (" + f.lines + ")" : ""));
            out.push("  " + f.detail);
          }
          out.push("");
        }
        if (result.positives.length) {
          out.push("What checked out:");
          for (var j = 0; j < result.positives.length; j++) { out.push("- " + result.positives[j]); }
          out.push("");
        }
        out.push("Limits: text audit of the pasted elasticsearch.yml only. It never connected to a cluster, never verified the keystore, certificates, or stored users/roles, and cannot confirm what a running node actually bound. Secret values are never printed in this report.");
        return out.join("\n");
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-elasticsearch-server-config-safety-auditortm',
  name: 'J-Dawgs Elasticsearch Server Config Safety Auditor',
  description: 'Node startup only checks your config on its host, and development mode waves exposure through; ours grades a pasted elasticsearch.yml anywhere — bind exposure, security pairing, and discovery posture included — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
