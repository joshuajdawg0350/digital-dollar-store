'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Plausible Analytics Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Example configs ---------- */

      var RISKY_EXAMPLE = [
        "# Plausible self-hosted - production config (risky worked example)",
        "BASE_URL=http://stats.example.com",
        "SECRET_KEY_BASE=abc123short",
        "DATABASE_URL=postgres://plausible:DbPass!4927xQ@db.internal:5432/plausible",
        "CLICKHOUSE_DATABASE_URL=http://default:clickpass99@clickhouse:8123/plausible_events",
        "ADMIN_USER_EMAIL=admin@example.com",
        "ADMIN_USER_PWD=hunter2",
        "DISABLE_REGISTRATION=false",
        "TOTP_VAULT_KEY=short-totp",
        "HOST=0.0.0.0",
        "PORT=8000",
        "SMTP_HOST_ADDR=mail.example.com",
        "SMTP_HOST_PASSWORD=smtp-pass-123",
        "DISABLE_STATS=false",
        "this line is not a setting at all"
      ].join("\n");

      var HARDENED_EXAMPLE = [
        "# Plausible self-hosted - production config (hardened example)",
        "BASE_URL=https://stats.example.com",
        "SECRET_KEY_BASE=${SECRET_KEY_BASE}",
        "DATABASE_URL=postgres://plausible:${DATABASE_PASSWORD}@db.internal:5432/plausible",
        "CLICKHOUSE_DATABASE_URL=http://default:${CLICKHOUSE_PASSWORD}@clickhouse:8123/plausible_events",
        "ADMIN_USER_EMAIL=admin@example.com",
        "ADMIN_USER_PWD=${ADMIN_USER_PWD}",
        "DISABLE_REGISTRATION=true",
        "TOTP_VAULT_KEY=${TOTP_VAULT_KEY}",
        "HOST=127.0.0.1",
        "PORT=8000",
        "SMTP_HOST_ADDR=mail.example.com",
        "SMTP_HOST_PASSWORD=${SMTP_HOST_PASSWORD}"
      ].join("\n");

      var WORKED_EXAMPLE = [
        "BASE_URL=http://stats.example.com",
        "SECRET_KEY_BASE=abc123",
        "DATABASE_URL=postgres://plausible:********@db:5432/plausible",
        "DISABLE_REGISTRATION=false"
      ].join("\n");

      /* ---------- Parsing ---------- */

      var KNOWN_KEYS = {
        BASE_URL: 1, SECRET_KEY_BASE: 1, DATABASE_URL: 1, CLICKHOUSE_DATABASE_URL: 1,
        ADMIN_USER_EMAIL: 1, ADMIN_USER_NAME: 1, ADMIN_USER_PWD: 1,
        DISABLE_REGISTRATION: 1, TOTP_VAULT_KEY: 1, DISABLE_STATS: 1,
        HOST: 1, PORT: 1, LISTEN_IP: 1,
        SMTP_HOST_ADDR: 1, SMTP_HOST_PORT: 1, SMTP_HOST_USER: 1, SMTP_HOST_PASSWORD: 1,
        SMTP_HOST_SSL_ENABLED: 1, MAILER_EMAIL: 1, MAILER_NAME: 1,
        GOOGLE_CLIENT_ID: 1, GOOGLE_CLIENT_SECRET: 1,
        HCAPTCHA_SITE_KEY: 1, HCAPTCHA_SECRET_KEY: 1,
        GEOLITE2_COUNTRY_DB: 1, IP_GEOLOCATION_DB: 1, RELEASE_NAME: 1, ERL_FLAGS: 1
      };

      function unquote(v) {
        if (v.length >= 2) {
          var first = v.charAt(0), last = v.charAt(v.length - 1);
          if ((first === '"' && last === '"') || (first === "'" && last === "'")) {
            return v.slice(1, -1);
          }
        }
        return v;
      }

      function parseConfig(text) {
        var entries = {};   // key -> { value, line }
        var order = [];
        var notParsed = []; // line numbers only, never contents
        var lines = String(text == null ? "" : text).split(/\r?\n/);
        for (var i = 0; i < lines.length; i++) {
          var lineNo = i + 1;
          var raw = lines[i];
          var trimmed = raw.replace(/^\s+|\s+$/g, "");
          if (trimmed === "" || trimmed.charAt(0) === "#") continue;
          var body = trimmed.replace(/^export\s+/, "");
          var m = body.match(/^([A-Za-z_][A-Za-z0-9_]*)\s*(=|:)\s*(.*)$/);
          if (!m) { notParsed.push(lineNo); continue; }
          var key = m[1].toUpperCase();
          var value = unquote(m[3].replace(/\s+$/, ""));
          if (!entries[key]) order.push(key);
          entries[key] = { value: value, line: lineNo };
        }
        return { entries: entries, order: order, notParsed: notParsed, lineCount: lines.length };
      }

      function isRef(value) {
        return /^\$\{[^}]*\}$/.test(value);
      }
      function containsRef(value) {
        return /\$\{[^}]*\}/.test(value);
      }
      function looksExample(value) {
        var s = value.toLowerCase();
        if (/example|change[-_ ]?me|placeholder|replace[-_ ]?(me|this|with)|your[-_ ]|todo|insert[-_ ]|generate[-_ ]?(me|one)/.test(s)) return true;
        if (/^(.)\1{7,}$/.test(value)) return true; // one repeated character
        return false;
      }
      function urlPassword(value) {
        var m = value.match(/^[A-Za-z][A-Za-z0-9+.-]*:\/\/([^/?#]*)/);
        if (!m) return null;
        var authority = m[1];
        var at = authority.lastIndexOf("@");
        if (at < 0) return null;
        var userinfo = authority.slice(0, at);
        var colon = userinfo.indexOf(":");
        if (colon < 0) return null;
        var pw = userinfo.slice(colon + 1);
        return pw === "" ? null : pw;
      }

      /* ---------- Grading ---------- */

      var SEV_RANK = { "BLOCKER": 0, "HIGH": 1, "WARNING": 2, "INFO": 3, "NOT PARSED": 4 };

      function audit(text) {
        var parsed = parseConfig(text);
        var e = parsed.entries;
        var findings = [];
        function add(severity, key, line, title, detail) {
          findings.push({ severity: severity, key: key, line: line, title: title, detail: detail });
        }
        function get(key) { return e[key] || null; }

        var knownCount = 0;
        for (var k in e) { if (KNOWN_KEYS[k]) knownCount++; }
        var gradeable = knownCount >= 2;

        /* SECRET_KEY_BASE */
        var skb = get("SECRET_KEY_BASE");
        if (!skb) {
          add("BLOCKER", "SECRET_KEY_BASE", null, "SECRET_KEY_BASE is not set",
            "Plausible cannot sign sessions or tokens without it. Generate a long random value (64+ characters) and keep it out of the file via an environment reference.");
        } else if (!isRef(skb.value)) {
          if (looksExample(skb.value)) {
            add("BLOCKER", "SECRET_KEY_BASE", skb.line, "SECRET_KEY_BASE is an example / placeholder value",
              "Example keys are public knowledge — anyone can forge sessions with one. Replace it with a generated secret of 64+ characters.");
          } else if (skb.value.length < 64) {
            add("BLOCKER", "SECRET_KEY_BASE", skb.line, "SECRET_KEY_BASE is too short (" + skb.value.length + " characters)",
              "Plausible expects at least 64 characters. A short key is brute-forceable. The value itself is never shown here.");
          }
        }

        /* TOTP_VAULT_KEY */
        var totp = get("TOTP_VAULT_KEY");
        if (!totp) {
          add("HIGH", "TOTP_VAULT_KEY", null, "TOTP_VAULT_KEY is not set",
            "Stored two-factor (TOTP) secrets are not encrypted at rest without a vault key. Set a long random value, ideally via an environment reference.");
        } else if (!isRef(totp.value)) {
          if (looksExample(totp.value)) {
            add("HIGH", "TOTP_VAULT_KEY", totp.line, "TOTP_VAULT_KEY is an example / placeholder value",
              "Replace it with a generated secret; an example vault key protects nothing.");
          } else if (totp.value.length < 32) {
            add("HIGH", "TOTP_VAULT_KEY", totp.line, "TOTP_VAULT_KEY is short (" + totp.value.length + " characters)",
              "Use at least 32 characters of random material. The value itself is never shown here.");
          }
        }

        /* Database URLs */
        ["DATABASE_URL", "CLICKHOUSE_DATABASE_URL"].forEach(function (key) {
          var ent = get(key);
          if (!ent) return;
          var pw = urlPassword(ent.value);
          if (pw !== null && !containsRef(pw)) {
            add("HIGH", key, ent.line, "Plaintext password embedded in " + key + " (" + pw.length + " characters)",
              "The database password sits in the connection string in this file. Move credentials into environment references (for example ${...}) so the file alone does not hand over the database. The password itself is never shown here.");
          }
        });
        if (!get("DATABASE_URL")) {
          add("WARNING", "DATABASE_URL", null, "DATABASE_URL is not set in this paste",
            "Plausible needs a Postgres connection. If it is supplied elsewhere (orchestrator, secrets manager), ignore this — otherwise the server will not start.");
        }

        /* Admin password */
        var apwd = get("ADMIN_USER_PWD");
        if (apwd) {
          if (!isRef(apwd.value)) {
            if (apwd.value.length < 12) {
              add("HIGH", "ADMIN_USER_PWD", apwd.line, "ADMIN_USER_PWD is a short plaintext password (" + apwd.value.length + " characters)",
                "The seeded admin password is stored literally in the config and is under 12 characters. Use an environment reference and a long password. The value itself is never shown here.");
            } else {
              add("HIGH", "ADMIN_USER_PWD", apwd.line, "ADMIN_USER_PWD is stored as a plaintext literal (" + apwd.value.length + " characters)",
                "Anyone who reads this file gets the admin password. Move it to an environment reference (${...}). The value itself is never shown here.");
            }
          }
        } else {
          add("INFO", "ADMIN_USER_PWD", null, "ADMIN_USER_PWD is not set in this paste",
            "No admin account is seeded from the config; the first account is created through the registration flow instead — which makes the registration check below matter more.");
        }

        /* BASE_URL */
        var base = get("BASE_URL");
        var baseIsHttps = false;
        if (!base) {
          add("WARNING", "BASE_URL", null, "BASE_URL is not set in this paste",
            "Plausible falls back to a local default (http on localhost). Set the real public URL before deploying.");
        } else if (!isRef(base.value)) {
          if (/^https:\/\//i.test(base.value)) {
            baseIsHttps = true;
          } else if (/^http:\/\//i.test(base.value)) {
            add("HIGH", "BASE_URL", base.line, "BASE_URL uses http:// (no TLS)",
              "Sessions and analytics traffic for this instance cross the network unencrypted. Put the instance behind HTTPS and set BASE_URL to the https:// address.");
          }
        }

        /* Registration */
        var reg = get("DISABLE_REGISTRATION");
        if (!reg) {
          add("WARNING", "DISABLE_REGISTRATION", null, "DISABLE_REGISTRATION is not set — registration is open",
            "Plausible's default allows anyone who finds the instance to register an account. Set DISABLE_REGISTRATION=true (or invite_only) once your users exist.");
        } else {
          var rv = reg.value.toLowerCase();
          if (rv !== "true" && rv !== "invite_only") {
            add("WARNING", "DISABLE_REGISTRATION", reg.line, "DISABLE_REGISTRATION is not true — registration is open",
              "With registration enabled, anyone who finds the instance can create an account. Set it to true (or invite_only) for a private instance.");
          }
        }

        /* HOST bind */
        var host = get("HOST");
        if (host && host.value === "0.0.0.0" && !baseIsHttps) {
          add("WARNING", "HOST", host.line, "HOST is bound to 0.0.0.0 with no HTTPS in BASE_URL",
            "The app listens on every network interface while the public URL has no TLS posture. Bind to localhost behind a TLS reverse proxy, or set an https:// BASE_URL.");
        }

        /* SMTP password */
        var smtp = get("SMTP_HOST_PASSWORD");
        if (smtp && !isRef(smtp.value)) {
          add("HIGH", "SMTP_HOST_PASSWORD", smtp.line, "SMTP_HOST_PASSWORD is stored as a plaintext literal (" + smtp.value.length + " characters)",
            "Mail credentials in the config file can be replayed against your mail server. Move the password to an environment reference (${...}). The value itself is never shown here.");
        }
        if (!get("SMTP_HOST_ADDR")) {
          add("INFO", "SMTP_HOST_ADDR", null, "No SMTP host is configured in this paste",
            "Without SMTP, Plausible cannot send password resets, invites, or report emails. Fine for a private test instance; a gap for production.");
        }

        /* Info-level flags */
        var stats = get("DISABLE_STATS");
        if (stats) {
          add("INFO", "DISABLE_STATS", stats.line, "DISABLE_STATS is set",
            "This flag changes the public stats endpoint behavior. Noted so it is a deliberate choice, not a leftover from a copied example.");
        }
        for (var key2 in e) {
          if (/DEBUG/.test(key2) && /^(true|1|yes)$/i.test(e[key2].value)) {
            add("INFO", key2, e[key2].line, key2 + " is enabled",
              "Debug-style flags left on in production can leak internals and slow the server. Noted for review.");
          }
        }

        /* Not parsed lines */
        parsed.notParsed.forEach(function (lineNo) {
          add("NOT PARSED", null, lineNo, "Line " + lineNo + " is not a KEY=value setting",
            "It was skipped by the grader (and would be skipped or misread by a strict .env loader). The line's contents are never shown here — check it for a typo, a missing '=', or a stray paste.");
        });

        findings.sort(function (a, b) {
          var r = SEV_RANK[a.severity] - SEV_RANK[b.severity];
          if (r !== 0) return r;
          return (a.line || 0) - (b.line || 0);
        });

        var counts = { BLOCKER: 0, HIGH: 0, WARNING: 0, INFO: 0, "NOT PARSED": 0 };
        findings.forEach(function (f) { counts[f.severity]++; });

        var verdict;
        if (!gradeable) verdict = "NOT ENOUGH TO GRADE";
        else if (counts.BLOCKER > 0 || counts.HIGH > 0) verdict = "DO NOT DEPLOY";
        else if (counts.WARNING > 0) verdict = "DEPLOY WITH FIXES";
        else verdict = "SAFE TO DEPLOY";

        return {
          gradeable: gradeable,
          knownKeyCount: knownCount,
          verdict: verdict,
          counts: counts,
          findings: findings,
          lineCount: parsed.lineCount
        };
      }

      /* ---------- Output builders (secret-free by construction) ---------- */

      function verdictWhy(result) {
        if (!result.gradeable) {
          return "This paste contains fewer than two recognizable Plausible settings (" + result.knownKeyCount + " found), so it does not look like a Plausible config. Nothing was graded.";
        }
        switch (result.verdict) {
          case "DO NOT DEPLOY":
            return "Blockers or high-severity findings are present. Fix every BLOCKER and HIGH item before this config goes anywhere near a server.";
          case "DEPLOY WITH FIXES":
            return "No blockers or high-severity findings, but warnings remain. Fix them before calling this production-ready.";
          case "SAFE TO DEPLOY":
            return "No blockers, high-severity findings, or warnings in the graded checks. This grades the pasted text only — it does not verify the live server or the secrets themselves.";
          default:
            return "";
        }
      }

      function buildReport(result) {
        var lines = [];
        lines.push("J-Dawgs Plausible Analytics Server Config Safety Auditor");
        lines.push("Verdict: " + result.verdict);
        lines.push("Findings: " + result.counts.BLOCKER + " BLOCKER, " + result.counts.HIGH + " HIGH, " +
          result.counts.WARNING + " WARNING, " + result.counts.INFO + " INFO, " + result.counts["NOT PARSED"] + " NOT PARSED");
        lines.push("Note: secret values are never shown. Findings name the key, line, and length only.");
        lines.push("");
        if (!result.gradeable) {
          lines.push("The paste was not recognizably a Plausible config (fewer than two known settings found), so no checks were graded.");
        } else if (result.findings.length === 0) {
          lines.push("No findings. Every graded check passed.");
        } else {
          result.findings.forEach(function (f, i) {
            var where = f.key ? f.key : "line";
            var loc = f.line ? "line " + f.line : "not present";
            lines.push((i + 1) + ". [" + f.severity + "] " + where + " (" + loc + ") - " + f.title);
            lines.push("   " + f.detail);
          });
        }
        lines.push("");
        lines.push("Graded from pasted text only, in the browser. No server was contacted and no secret was verified.");
        return lines.join("\n");
      }

      function buildJSON(result) {
        var obj = {
          tool: "J-Dawgs Plausible Analytics Server Config Safety Auditor",
          verdict: result.verdict,
          gradeable: result.gradeable,
          recognizedPlausibleSettings: result.knownKeyCount,
          counts: {
            blocker: result.counts.BLOCKER,
            high: result.counts.HIGH,
            warning: result.counts.WARNING,
            info: result.counts.INFO,
            notParsed: result.counts["NOT PARSED"]
          },
          findings: result.findings.map(function (f) {
            return { severity: f.severity, key: f.key, line: f.line, title: f.title, detail: f.detail };
          }),
          note: "Secret values are never included. Findings report key name, line number, and length only. Graded from pasted text only; no server was contacted."
        };
        return JSON.stringify(obj, null, 2);
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined), "WORKED_EXAMPLE": (typeof WORKED_EXAMPLE !== 'undefined' ? WORKED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-plausible-analytics-server-config-safety-auditor',
  name: 'J-Dawgs Plausible Analytics Server Config Safety Auditor',
  description: 'Grades a pasted Plausible Analytics server config fully offline into one deploy verdict — SAFE TO DEPLOY / DEPLOY WITH FIXES / DO NOT DEPLOY / NOT ENOUGH TO GRADE — open registration, an http BASE_URL, short SECRET_KEY_BASE and TOTP_VAULT_KEY values, and plaintext database passwords, with secrets sh',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"], "WORKED_EXAMPLE": __core["WORKED_EXAMPLE"] }
};
