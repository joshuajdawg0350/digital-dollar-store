'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs SLA Credit Claim Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var WORKED = [
        "SERVICE: Acme Cloud API",
        "PERIOD: 2026-10-01 TO 2026-10-31",
        "COMMITMENT: 99.9",
        "FEE: 1200",
        "CREDIT: below 99.9 -> 10",
        "CREDIT: below 99.0 -> 25",
        "CREDIT: below 95.0 -> 50",
        "OUTAGE: 2026-10-07 240 database failover",
        "OUTAGE: 2026-10-19 360 network outage",
        "OUTAGE: 2026-10-26 120 partial degradation",
        "CLAIM-BY: 2026-11-30",
        "AS-OF: 2026-11-15"
      ].join("\n");

      var CLEAN = [
        "SERVICE: Acme Cloud API",
        "PERIOD: 2026-10-01 TO 2026-10-31",
        "COMMITMENT: 99.9",
        "FEE: 1200",
        "CREDIT: below 99.9 -> 10",
        "CREDIT: below 99.0 -> 25",
        "CREDIT: below 95.0 -> 50",
        "OUTAGE: 2026-10-12 30 brief blip",
        "CLAIM-BY: 2026-11-30",
        "AS-OF: 2026-11-15"
      ].join("\n");

      var $ = function(id){ return document.getElementById(id); };
      var inputEl = $("input"), reportEl = $("report"), pitchEl = $("pitch");

      function pad2(n){ return (n < 10 ? "0" : "") + n; }
      function fmtDate(d){ return d.y + "-" + pad2(d.m) + "-" + pad2(d.d); }
      function dayNum(d){ return Math.round(Date.UTC(d.y, d.m - 1, d.d) / 86400000); }
      function parseDate(s){
        if(!s) return null;
        s = String(s).trim();
        var m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
        var y, mo, da;
        if(m){ y = +m[1]; mo = +m[2]; da = +m[3]; }
        else {
          m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
          if(!m) return null;
          y = +m[3]; mo = +m[1]; da = +m[2];
        }
        if(mo < 1 || mo > 12 || da < 1 || da > 31) return null;
        var t = new Date(Date.UTC(y, mo - 1, da));
        if(t.getUTCFullYear() !== y || t.getUTCMonth() !== mo - 1 || t.getUTCDate() !== da) return null;
        return { y: y, m: mo, d: da };
      }
      function parseNum(s){
        if(s == null) return null;
        var t = String(s).replace(/[$,%\s]/g, "").replace(/,/g, "");
        if(t === "") return null;
        var n = Number(t);
        return isFinite(n) ? n : null;
      }
      function num(n){ return n.toLocaleString("en-US"); }
      function money(n){
        return "$" + n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
      }
      function pct(n){ return n.toFixed(3) + "%"; }
      function esc(s){
        return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
      }

      function audit(text){
        var lines = String(text || "").split(/\r?\n/);
        var service = null, period = null, commitment = null, fee = null;
        var claimBy = null, asOf = null;
        var tiers = [];        // {threshold, credit, line}
        var outages = [];      // {line, raw, dateStr, date, minutes, note, status, reason}
        var issues = [];       // strings naming missing / unparsable / ignored facts
        var seen = {};         // singleton keys already set (for duplicate notes)
        var present = {};      // keys seen at all

        function dupNote(key, ln){
          if(seen[key]) issues.push("Line " + ln + ": duplicate " + key + " line — the last one wins.");
          seen[key] = true;
        }

        for(var i = 0; i < lines.length; i++){
          var ln = i + 1;
          var raw = lines[i];
          var line = raw.trim();
          if(line === "") continue;
          var km = line.match(/^([A-Za-z][A-Za-z-]*)\s*:\s*(.*)$/);
          if(!km){
            issues.push("Line " + ln + ": not in KEY: value format — ignored. (\"" + line + "\")");
            continue;
          }
          var key = km[1].toUpperCase();
          var val = km[2].trim();
          present[key] = true;

          if(key === "SERVICE"){
            dupNote("SERVICE", ln);
            service = val;
          } else if(key === "PERIOD"){
            dupNote("PERIOD", ln);
            var pm = val.match(/^(\S+)\s+TO\s+(\S+)$/i);
            var ps = pm ? parseDate(pm[1]) : null;
            var pe = pm ? parseDate(pm[2]) : null;
            if(ps && pe && dayNum(pe) >= dayNum(ps)){
              period = { start: ps, end: pe };
            } else {
              period = null;
              issues.push("Line " + ln + ": PERIOD is unparsable — expected \"PERIOD: YYYY-MM-DD TO YYYY-MM-DD\" with the end on or after the start. Got: \"" + val + "\".");
            }
          } else if(key === "COMMITMENT"){
            dupNote("COMMITMENT", ln);
            var c = parseNum(val);
            if(c !== null && c > 0 && c <= 100){ commitment = c; }
            else { commitment = null; issues.push("Line " + ln + ": COMMITMENT is unparsable — expected an uptime percent such as 99.9. Got: \"" + val + "\"."); }
          } else if(key === "FEE"){
            dupNote("FEE", ln);
            var f = parseNum(val);
            if(f !== null && f >= 0){ fee = f; }
            else { fee = null; issues.push("Line " + ln + ": FEE is unparsable — expected a monthly fee amount such as 1200. Got: \"" + val + "\"."); }
          } else if(key === "CREDIT"){
            var cm = val.match(/below\s+([0-9]+(?:\.[0-9]+)?)\s*%?\s*(?:->|→|=>)\s*([0-9]+(?:\.[0-9]+)?)\s*%?/i);
            if(cm){ tiers.push({ threshold: parseFloat(cm[1]), credit: parseFloat(cm[2]), line: ln }); }
            else issues.push("Line " + ln + ": CREDIT tier is unparsable — expected \"CREDIT: below <uptime percent> -> <credit percent>\". The tier was excluded. Got: \"" + val + "\".");
          } else if(key === "OUTAGE"){
            var o = { line: ln, raw: line, dateStr: "", date: null, minutes: null, note: "", status: "", reason: "" };
            var toks = val.split(/\s+/).filter(function(t){ return t !== ""; });
            o.dateStr = toks.length ? toks[0] : "";
            o.date = parseDate(o.dateStr);
            var rest = toks.slice(2).join(" ");
            o.note = toks.length > 2 ? rest : "";
            var mins = null;
            if(toks.length >= 2){
              var mt = toks[1].match(/^([0-9]+(?:\.[0-9]+)?)/);
              if(mt) mins = parseFloat(mt[1]);
            }
            o.minutes = mins;
            if(/\bEXCLUDED\b/i.test(line)){
              o.status = "EXCLUDED";
              o.reason = "Marked EXCLUDED on the line — left out as a scheduled-maintenance exclusion.";
            } else if(!o.date){
              o.status = "UNPARSABLE";
              o.reason = "No readable date at the start of the line — excluded by line number, never guessed.";
            } else if(mins === null){
              o.status = "UNPARSABLE";
              o.reason = "No duration in minutes after the date — excluded by line number, never guessed.";
            }
            outages.push(o);
          } else if(key === "CLAIM-BY"){
            dupNote("CLAIM-BY", ln);
            var cb = parseDate(val);
            if(cb){ claimBy = cb; }
            else { claimBy = null; issues.push("Line " + ln + ": CLAIM-BY is unparsable — expected a date such as 2026-11-30. Got: \"" + val + "\"."); }
          } else if(key === "AS-OF"){
            dupNote("AS-OF", ln);
            var ao = parseDate(val);
            if(ao){ asOf = ao; }
            else { asOf = null; issues.push("Line " + ln + ": AS-OF is unparsable — expected a date such as 2026-11-15. Got: \"" + val + "\"."); }
          } else {
            issues.push("Line " + ln + ": unrecognized key \"" + km[1] + "\" — ignored.");
          }
        }

        // Required-fact check: name each missing fact individually.
        var missing = [];
        if(!period && !present["PERIOD"]) missing.push("PERIOD (no PERIOD line was pasted)");
        else if(!period) missing.push("PERIOD (pasted but unparsable — see line note above)");
        if(commitment === null && !present["COMMITMENT"]) missing.push("COMMITMENT (no COMMITMENT line was pasted)");
        else if(commitment === null) missing.push("COMMITMENT (pasted but unparsable — see line note above)");
        if(fee === null && !present["FEE"]) missing.push("FEE (no FEE line was pasted)");
        else if(fee === null) missing.push("FEE (pasted but unparsable — see line note above)");
        if(tiers.length === 0) missing.push("CREDIT table (no parsable CREDIT tier line was pasted)");
        if(!claimBy && !present["CLAIM-BY"]) missing.push("CLAIM-BY (no CLAIM-BY line was pasted)");
        else if(!claimBy) missing.push("CLAIM-BY (pasted but unparsable — see line note above)");
        if(!asOf && !present["AS-OF"]) missing.push("AS-OF (no AS-OF line was pasted)");
        else if(!asOf) missing.push("AS-OF (pasted but unparsable — see line note above)");

        // Out-of-period flagging needs the period; only possible when settled inputs exist.
        var counted = [], totalOutage = 0;
        outages.forEach(function(o){
          if(o.status) return; // already EXCLUDED or UNPARSABLE
          if(period && (dayNum(o.date) < dayNum(period.start) || dayNum(o.date) > dayNum(period.end))){
            o.status = "OUT OF PERIOD";
            o.reason = "Dated " + fmtDate(o.date) + ", outside the period " + fmtDate(period.start) + " to " + fmtDate(period.end) + " — excluded.";
            return;
          }
          o.status = "COUNTED";
          counted.push(o);
          totalOutage += o.minutes;
        });

        var R = {
          service: service, period: period, commitment: commitment, fee: fee,
          tiers: tiers, outages: outages, counted: counted, totalOutage: totalOutage,
          claimBy: claimBy, asOf: asOf, missing: missing, issues: issues,
          verdict: "", verdictClass: "", detail: "",
          periodDays: 0, periodMinutes: 0, uptime: null,
          earnedTier: null, creditAmount: null, daysLeft: null
        };

        if(missing.length){
          R.verdict = "NOT SETTLED";
          R.verdictClass = "unsettled";
          R.detail = "Required facts are missing or unparsable, so no verdict can be computed. Missing: " + missing.join("; ") + ".";
          return R;
        }

        R.periodDays = dayNum(period.end) - dayNum(period.start) + 1;
        R.periodMinutes = R.periodDays * 1440;
        R.uptime = (R.periodMinutes - totalOutage) / R.periodMinutes * 100;
        R.daysLeft = dayNum(claimBy) - dayNum(asOf);

        // Earned tier: every row whose threshold the actual uptime falls below; highest credit wins.
        var matching = tiers.filter(function(t){ return R.uptime < t.threshold; });
        matching.sort(function(a, b){ return b.credit - a.credit; });
        R.earnedTier = matching.length ? matching[0] : null;
        R.matching = matching;

        if(R.uptime >= commitment){
          R.verdict = "NO CREDIT EARNED";
          R.verdictClass = "";
          R.detail = "Actual uptime " + pct(R.uptime) + " meets the " + commitment + "% commitment, so no credit is owed for this period.";
        } else if(!R.earnedTier){
          R.verdict = "NO CREDIT EARNED";
          R.verdictClass = "";
          R.detail = "Actual uptime " + pct(R.uptime) + " fell below the " + commitment + "% commitment, but NO TIER MATCHES — no CREDIT row covers an uptime this low (or this high), so no credit amount can be computed from the pasted table.";
        } else {
          R.creditAmount = fee * R.earnedTier.credit / 100;
          if(R.daysLeft < 0){
            R.verdict = "CLAIM WINDOW CLOSED";
            R.verdictClass = "closed";
            R.detail = "A credit of " + money(R.creditAmount) + " was earned (" + R.earnedTier.credit + "% of the " + money(fee) + " fee), but AS-OF " + fmtDate(asOf) + " is " + (-R.daysLeft) + " day" + (-R.daysLeft === 1 ? "" : "s") + " past the CLAIM-BY date " + fmtDate(claimBy) + ".";
          } else {
            R.verdict = "CLAIM THE CREDIT";
            R.verdictClass = "claim";
            R.detail = "Claim " + money(R.creditAmount) + " — " + R.earnedTier.credit + "% of the " + money(fee) + " monthly fee. " + R.daysLeft + " day" + (R.daysLeft === 1 ? "" : "s") + " left: AS-OF " + fmtDate(asOf) + ", CLAIM-BY " + fmtDate(claimBy) + ".";
          }
        }
        return R;
      }

      function sumSpell(counted){
        if(!counted.length) return "no counted outages = 0";
        return counted.map(function(o){ return String(o.minutes); }).join(" + ") + " = " + num(counted.reduce(function(a, o){ return a + o.minutes; }, 0));
      }

      function buildSteps(R){
        var steps = [];
        if(R.period){
          steps.push("Period: " + fmtDate(R.period.start) + " to " + fmtDate(R.period.end) + " = " + R.periodDays + " days (both the first and last day counted).");
          steps.push("Period minutes: " + R.periodDays + " days × 1,440 minutes per day = " + num(R.periodMinutes) + " minutes.");
        }
        steps.push("Total outage minutes (counted lines only): " + sumSpell(R.counted) + " minutes.");
        if(R.period && R.uptime !== null){
          steps.push("Actual uptime: (" + num(R.periodMinutes) + " − " + num(R.totalOutage) + ") ÷ " + num(R.periodMinutes) + " × 100 = " + pct(R.uptime) + ".");
          steps.push("Commitment: " + R.commitment + "%. Actual uptime " + pct(R.uptime) + (R.uptime >= R.commitment ? " meets" : " falls below") + " the commitment.");
        }
        if(R.uptime !== null && R.tiers.length){
          if(R.earnedTier){
            steps.push("Earned tier: uptime " + pct(R.uptime) + " is below " + R.earnedTier.threshold + "% → " + R.earnedTier.credit + "% credit (the highest matching CREDIT row).");
            steps.push("Credit amount: " + money(R.fee) + " × " + R.earnedTier.credit + "% = " + money(R.creditAmount) + ".");
          } else if(R.uptime < R.commitment){
            steps.push("Earned tier: NO TIER MATCHES — actual uptime " + pct(R.uptime) + " is not below any CREDIT row's threshold that yields a credit for this miss.");
          } else {
            steps.push("Earned tier: none — the commitment was met, so no CREDIT row applies.");
          }
        }
        if(R.claimBy && R.asOf){
          if(R.daysLeft >= 0) steps.push("Days left to claim: CLAIM-BY " + fmtDate(R.claimBy) + " minus AS-OF " + fmtDate(R.asOf) + " = " + R.daysLeft + " day" + (R.daysLeft === 1 ? "" : "s") + " left.");
          else steps.push("Claim window: AS-OF " + fmtDate(R.asOf) + " is " + (-R.daysLeft) + " day" + (-R.daysLeft === 1 ? "" : "s") + " past CLAIM-BY " + fmtDate(R.claimBy) + " — the window closed " + (-R.daysLeft) + " day" + (-R.daysLeft === 1 ? "" : "s") + " ago.");
        }
        return steps;
      }

      function buildReport(R){
        var L = [];
        L.push("J-Dawgs SLA Credit Claim Auditor™ — report");
        L.push("Service: " + (R.service ? R.service : "(not named)"));
        if(R.period) L.push("Period: " + fmtDate(R.period.start) + " TO " + fmtDate(R.period.end));
        if(R.commitment !== null) L.push("Commitment: " + R.commitment + "% uptime");
        if(R.fee !== null) L.push("Monthly fee: " + money(R.fee));
        L.push("");
        L.push("VERDICT: " + R.verdict);
        L.push(R.detail);
        L.push("");
        L.push("Arithmetic:");
        buildSteps(R).forEach(function(s){ L.push("- " + s); });
        L.push("");
        L.push("Outage lines:");
        if(!R.outages.length) L.push("- (none pasted — total outage minutes counted as 0)");
        R.outages.forEach(function(o){
          var base = "- Line " + o.line + ": " + (o.date ? fmtDate(o.date) : (o.dateStr || "(no date)")) +
            (o.minutes !== null ? " — " + o.minutes + " min" : " — (no duration)") +
            (o.note ? " — " + o.note : "");
          if(o.status === "COUNTED") L.push(base + " [COUNTED]");
          else L.push(base + " [" + o.status + " — " + o.reason + "]");
        });
        if(R.issues.length || R.missing.length){
          L.push("");
          L.push("Missing / unparsable / ignored:");
          R.missing.forEach(function(m){ L.push("- MISSING: " + m); });
          R.issues.forEach(function(s){ L.push("- " + s); });
        }
        L.push("");
        L.push("Limits: pasted evidence only — this report verifies no outage really happened and uses no provider terms beyond the paste. It files nothing and is not legal or financial advice.");
        return L.join("\n");
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-sla-credit-claim-auditortm-2',
  name: 'J-Dawgs SLA Credit Claim Auditor',
  description: '',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
