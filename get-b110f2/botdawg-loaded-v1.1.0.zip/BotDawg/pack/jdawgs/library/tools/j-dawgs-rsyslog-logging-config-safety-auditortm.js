'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs rsyslog Logging Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

    "use strict";

    var RISKY_EXAMPLE = [
      "# Risky forwarding setup — do not deploy as-is",
      "$ModLoad imudp",
      "$UDPServerRun 514",
      "$ModLoad imtcp",
      "$InputTCPServerRun 514",
      "$RepeatedMsgReduction on",
      "$FileCreateMode 0644",
      "*.* /var/log/everything.log",
      "*.* @@logs.example.net:514",
      'action(type="ommysql" server="db.example.net" db="syslog" uid="logger" dbpassword="Sup3rSecretValue123")'
    ].join("\n");

    var HARDENED_EXAMPLE = [
      "# Hardened forwarding setup",
      'global(workdirectory="/var/spool/rsyslog")',
      'module(load="imtcp")',
      'input(type="imtcp" port="514" ratelimit.interval="600" ratelimit.burst="20000")',
      "$PrivDropToUser syslog",
      "$PrivDropToGroup syslog",
      "$FileCreateMode 0640",
      "$DirCreateMode 0750",
      'action(type="omfwd" target="logs.example.net" port="6514" protocol="tcp"',
      '       StreamDriver="gtls" StreamDriverMode="1" StreamDriverAuthMode="x509/name"',
      '       queue.type="LinkedList" queue.filename="fwdq" queue.saveonshutdown="on"',
      '       queue.maxdiskspace="1g" action.resumeRetryCount="-1")',
      '*.* /var/log/secure.log'
    ].join("\n");

    var KNOWN_DIRECTIVE = /^\$(ModLoad|IncludeConfig|WorkDirectory|PrivDropToUser|PrivDropToGroup|PrivDropToUserID|PrivDropToGroupID|FileCreateMode|DirCreateMode|FileGroup|FileOwner|DirGroup|DirOwner|FileOwnerMode|RepeatedMsgReduction|SystemLogRateLimitInterval|SystemLogRateLimitBurst|IMUDP|IMTCP|IMUXSock|ActionQueue|ActionResume|ActionSend|ActionForward|ActionExecOnly|Input|UDPServer|TCPServer|MainMsgQueue|DefaultNetstreamDriver|DefaultNetstreamDriverCAFile|DefaultNetstreamDriverCertFile|DefaultNetstreamDriverKeyFile|Template|Umask|UMASK|MaxMessageSize|MaxOpenFiles|DropMsgsWithMaliciousDNSPtrRecords|LocalHostName|AbortOnUncleanConfig|SystemLogSocket|ErrorMessagesToStderr|PrivDrop|ModuleLoad|OmitLocalLogging|SystemLogUse|Outchannel|MarkMessagePeriod|SpaceSaving|ControlCharacter|EscapeControlCharactersOnReceive|CreateDirs|DirOwnerMode|DirGroupMode|FileGroupMode|ResetConfigVariables|Log|Debug|DebugFile|NoFork|TimeNumeral|DisableTimestamp|DynFile|HUPisRestart|StdOut|Sync|Queue|Parser|GenerateConfigGraph|ConfigGraph|ExecOnlyOnce|PreserveFQDN|IMFile|IMMark|OperatingStateFile)/i;

    var BLOCK_KEYWORDS = ["module", "input", "action", "global", "ruleset", "template", "parser", "lookup", "dyn_stats", "main_queue", "property", "constant", "include"];
    var STMT_STOP = { "if": 1, "then": 1, "else": 1, "and": 1, "or": 1, "not": 1, "exists": 1, "contains": 1, "startswith": 1, "call": 1, "set": 1, "unset": 1, "stop": 1, "exec": 1 };

    function lineOf(text, idx) {
      var n = 1, i = 0;
      while (i < idx) { if (text.charCodeAt(i) === 10) n++; i++; }
      return n;
    }

    function parseParams(inner) {
      var params = {};
      var re = /([A-Za-z0-9_.\-]+)\s*=\s*(?:"([^"]*)"|([^\s)]+))/g;
      var m;
      while ((m = re.exec(inner)) !== null) {
        params[m[1].toLowerCase()] = (m[2] !== undefined) ? m[2] : m[3];
      }
      return params;
    }

    function extractBlocks(text) {
      var blocks = [];
      var unparsed = [];
      var re = /\b(module|input|action|global|ruleset|template|parser|lookup|dyn_stats|main_queue|property|constant|include)\s*\(/gi;
      var m;
      while ((m = re.exec(text)) !== null) {
        var kind = m[1].toLowerCase();
        var openIdx = m.index + m[0].length - 1;
        var depth = 0, inStr = false, j = openIdx, closed = -1;
        for (; j < text.length; j++) {
          var ch = text.charAt(j);
          if (inStr) {
            if (ch === "\\") { j++; }
            else if (ch === '"') { inStr = false; }
          } else if (ch === '"') { inStr = true; }
          else if (ch === "(") { depth++; }
          else if (ch === ")") { depth--; if (depth === 0) { closed = j; break; } }
        }
        var startLine = lineOf(text, m.index);
        if (closed === -1) {
          unparsed.push({ line: startLine, kind: kind });
          break;
        }
        var inner = text.substring(openIdx + 1, closed);
        blocks.push({
          kind: kind,
          startLine: startLine,
          endLine: lineOf(text, closed),
          params: parseParams(inner)
        });
        re.lastIndex = closed + 1;
      }
      return { blocks: blocks, unparsed: unparsed };
    }

    function audit(text) {
      var findings = [];
      var good = [];
      var notAudited = [];
      var notAuditedSeen = {};
      var lines = text.split(/\r?\n/);
      var extracted = extractBlocks(text);
      var blocks = extracted.blocks;
      var unparsed = extracted.unparsed;

      function addFinding(line, severity, rule, title, message, fix) {
        findings.push({ line: line, severity: severity, rule: rule, title: title, message: message, fix: fix });
      }
      function noteNotAudited(name) {
        if (!notAuditedSeen[name]) { notAuditedSeen[name] = 1; notAudited.push(name); }
      }

      var consumed = {};
      var bi;
      for (bi = 0; bi < blocks.length; bi++) {
        for (var ln = blocks[bi].startLine; ln <= blocks[bi].endLine; ln++) consumed[ln] = true;
      }
      for (bi = 0; bi < unparsed.length; bi++) {
        for (var uln = unparsed[bi].line; uln <= lines.length; uln++) consumed[uln] = true;
      }

      /* ---------- Pre-pass: globals that can appear anywhere ---------- */
      var workdirSet = false;
      var privUser = false, privGroup = false;
      var legacyRateInterval = null, legacyRateBurst = null, legacyRateIntervalLine = 0;
      var legacyModuleRate = false;

      var i, raw, t, m;
      for (i = 0; i < lines.length; i++) {
        t = lines[i].trim();
        if (t.charAt(0) === "$") {
          if (/^\$WorkDirectory\b/i.test(t)) workdirSet = true;
          if (/^\$PrivDropToUser\b/i.test(t)) privUser = true;
          if (/^\$PrivDropToGroup\b/i.test(t)) privGroup = true;
          if ((m = t.match(/^\$SystemLogRateLimitInterval\s+(\S+)/i))) { legacyRateInterval = m[1]; legacyRateIntervalLine = i + 1; }
          if ((m = t.match(/^\$SystemLogRateLimitBurst\s+(\S+)/i))) { legacyRateBurst = m[1]; }
          if (/^\$IM(UDP|TCP)RateLimit(Interval|Burst)\b/i.test(t)) legacyModuleRate = true;
        }
      }
      for (bi = 0; bi < blocks.length; bi++) {
        if (blocks[bi].kind === "global" && blocks[bi].params.workdirectory) workdirSet = true;
      }
      var legacyRateSet = (legacyRateInterval !== null) || (legacyRateBurst !== null) || legacyModuleRate;
      var legacyRateDisabled = (legacyRateInterval !== null && legacyRateBurst !== null &&
        parseInt(legacyRateInterval, 10) === 0 && parseInt(legacyRateBurst, 10) === 0);

      /* ---------- Secrets: flag by key name and line only ---------- */
      var secretSeen = {};
      function scanSecrets(lineText, lineNo) {
        var re = /([A-Za-z0-9_.]*(?:password|passwd)[A-Za-z0-9_.]*)\s*=/gi;
        var sm;
        while ((sm = re.exec(lineText)) !== null) {
          var key = sm[1];
          var id = lineNo + "|" + key.toLowerCase();
          if (!secretSeen[id]) {
            secretSeen[id] = 1;
            addFinding(lineNo, "WARNING", "PLAINTEXT_SECRET",
              "Secret stored in plain text in the config",
              "A value is assigned to the secret-shaped parameter \"" + key + "\" directly in this config. Anyone who can read the config file can read the secret. (The value itself is never shown in this audit.)",
              "Move the secret out of the config: load it from a root-only file or environment-provided credential, restrict the config file to mode 0600 owned by root, and rotate the secret since it has been sitting in plain text.");
          }
        }
        var lm = lineText.match(/^\s*\$[A-Za-z0-9_]*(password|passwd)[A-Za-z0-9_]*\s+(\S+)/i);
        if (lm) {
          var lkey = lineText.trim().split(/\s+/)[0];
          var lid = lineNo + "|" + lkey.toLowerCase();
          if (!secretSeen[lid]) {
            secretSeen[lid] = 1;
            addFinding(lineNo, "WARNING", "PLAINTEXT_SECRET",
              "Secret stored in plain text in the config",
              "A value is assigned to the secret-shaped directive \"" + lkey + "\" directly in this config. Anyone who can read the config file can read the secret. (The value itself is never shown in this audit.)",
              "Move the secret out of the config, restrict the config file to mode 0600 owned by root, and rotate the secret.");
          }
        }
      }
      for (i = 0; i < lines.length; i++) scanSecrets(lines[i], i + 1);

      /* ---------- Queue evaluation helpers ---------- */
      var usesDiskQueue = false;
      var firstDiskQueueLine = 0;

      function noteDiskQueue(lineNo) {
        usesDiskQueue = true;
        if (!firstDiskQueueLine) firstDiskQueueLine = lineNo;
      }
      function evalQueueParams(qt, qf, save, lineNo, what) {
        if (qt === undefined || qt === null || qt === "" || /^direct$/i.test(qt)) {
          addFinding(lineNo, "WARNING", "NO_ACTION_QUEUE",
            "Forwarding action has no action queue",
            "This " + what + " has no action queue (queue.type is absent or Direct), so logs are lost whenever the receiver is down or unreachable — rsyslog discards messages it cannot deliver immediately.",
            "Give the action a disk-assisted queue: queue.type=\"LinkedList\" with queue.filename set, queue.saveonshutdown=\"on\", and an action.resumeRetryCount so delivery retries instead of dropping.");
          return;
        }
        if ((/^linkedlist$/i.test(qt) || /^disk$/i.test(qt)) && !qf) {
          addFinding(lineNo, "WARNING", "MEMORY_ONLY_QUEUE",
            "Action queue is in-memory only",
            "This " + what + " uses queue.type \"" + qt + "\" with no queue.filename, so the queue lives only in memory and its buffered logs are lost on restart.",
            "Set queue.filename on the action so the queue becomes disk-assisted and survives a restart.");
          return;
        }
        if (qf) {
          noteDiskQueue(lineNo);
          if (save && /^on$/i.test(save)) {
            good.push("Disk-assisted action queue with queue.filename and queue.saveonshutdown=\"on\" (line " + lineNo + ") — buffered logs survive an outage and a restart.");
          }
        }
      }

      /* ---------- Inputs & rate limiting ---------- */
      var inputs = []; // {line, proto, port, interval, burst, legacy}
      function evalRateLimit(inp) {
        if (inp.legacy) {
          if (legacyRateDisabled) {
            addFinding(legacyRateIntervalLine, "BLOCKER", "RATE_LIMIT_DISABLED",
              "Rate limiting disabled entirely",
              "Legacy $SystemLogRateLimitInterval and $SystemLogRateLimitBurst are both explicitly set to 0, so rate limiting is disabled entirely — a flooding sender can fill the disk with log traffic.",
              "Set a real window and burst, for example $SystemLogRateLimitInterval 600 and $SystemLogRateLimitBurst 20000, sized to your normal log volume.");
          } else if (!legacyRateSet) {
            addFinding(inp.line, "WARNING", "NO_RATE_LIMIT",
              "Listening input has no rate limiting",
              "This " + inp.proto + " input listens for remote logs, and no rate limiting is configured anywhere (no ratelimit.interval / ratelimit.burst, and no legacy $SystemLogRateLimitInterval). A flood — hostile or just a broken sender looping — can fill the disk and silently crowd out real logs.",
              "Set rate limits on the input, for example ratelimit.interval=\"600\" ratelimit.burst=\"20000\", or the legacy $SystemLogRateLimitInterval / $SystemLogRateLimitBurst pair.");
          } else {
            good.push("Input rate limiting is configured (legacy rate-limit directives present).");
          }
          return;
        }
        var iv = inp.interval, bu = inp.burst;
        if (iv !== undefined && bu !== undefined && parseInt(iv, 10) === 0 && parseInt(bu, 10) === 0) {
          addFinding(inp.line, "BLOCKER", "RATE_LIMIT_DISABLED",
            "Rate limiting disabled entirely",
            "This " + inp.proto + " input sets ratelimit.interval=\"0\" and ratelimit.burst=\"0\" explicitly, so rate limiting is disabled entirely — a flooding sender can fill the disk with log traffic.",
            "Set a real window and burst, for example ratelimit.interval=\"600\" ratelimit.burst=\"20000\", sized to your normal log volume.");
        } else if (iv === undefined && bu === undefined) {
          addFinding(inp.line, "WARNING", "NO_RATE_LIMIT",
            "Listening input has no rate limiting",
            "This " + inp.proto + " input listens for remote logs with no ratelimit.interval / ratelimit.burst set. A flood — hostile or just a broken sender looping — can fill the disk, and rsyslog's own discard behavior can silently drop messages under load.",
            "Set ratelimit.interval and ratelimit.burst on the input, for example ratelimit.interval=\"600\" ratelimit.burst=\"20000\".");
        } else if (iv !== undefined && parseInt(iv, 10) === 0) {
          addFinding(inp.line, "WARNING", "RATE_LIMIT_INTERVAL_ZERO",
            "Rate-limit interval is 0",
            "This " + inp.proto + " input sets ratelimit.interval=\"0\", which turns the rate-limit window off in practice, so senders are effectively unthrottled.",
            "Set ratelimit.interval to a real window in seconds (for example \"600\") together with a ratelimit.burst sized to your normal volume.");
        } else {
          good.push("Rate limiting is set on the " + inp.proto + " input (line " + inp.line + ").");
        }
      }

      /* ---------- Legacy line pass ---------- */
      var legacyQueue = { type: null, filename: null, save: null };
      var firstPrivInputLine = 0;

      function evalLegacyForward(lineNo, proto) {
        if (proto === "tcp") {
          addFinding(lineNo, "BLOCKER", "PLAINTEXT_TCP_FORWARDING",
            "Plaintext TCP forwarding of logs",
            "This legacy @@ rule forwards logs over TCP with no TLS — legacy forwarding syntax has no encryption, so log contents (which routinely contain usernames, addresses, and internal hostnames) cross the network readable by anyone on the path.",
            "Forward with RainerScript instead: action(type=\"omfwd\" protocol=\"tcp\" StreamDriver=\"gtls\" StreamDriverMode=\"1\" StreamDriverAuthMode=\"x509/name\" ...) so the stream is encrypted and the receiver is authenticated.");
        } else {
          addFinding(lineNo, "WARNING", "PLAINTEXT_UDP_FORWARDING",
            "Plaintext, unreliable UDP forwarding",
            "This legacy single-@ rule forwards logs over UDP in plaintext — readable by anyone on the network path — and UDP is unreliable: datagrams dropped in transit are gone with no error anywhere.",
            "If these logs matter, forward over TCP with TLS instead: action(type=\"omfwd\" protocol=\"tcp\" StreamDriver=\"gtls\" StreamDriverMode=\"1\" StreamDriverAuthMode=\"x509/name\" ...). Keep UDP only for logs you can afford to lose.");
        }
        evalQueueParams(legacyQueue.type, legacyQueue.filename, legacyQueue.save, lineNo, "legacy forwarding rule");
      }

      for (i = 0; i < lines.length; i++) {
        var lineNo = i + 1;
        raw = lines[i];
        t = raw.trim();
        if (!t || t.charAt(0) === "#") continue;
        if (consumed[lineNo]) continue;

        if (t.charAt(0) === "$") {
          var dname = t.split(/\s+/)[0];
          if (!KNOWN_DIRECTIVE.test(dname)) { noteNotAudited(dname); continue; }
          var dval = t.substring(dname.length).trim();
          var dl = dname.toLowerCase();

          if (dl === "$actionqueuetype") legacyQueue.type = dval.split(/\s+/)[0];
          else if (dl === "$actionqueuefilename") legacyQueue.filename = dval.split(/\s+/)[0];
          else if (dl === "$actionqueuesaveonshutdown") legacyQueue.save = dval.split(/\s+/)[0];
          else if (dl === "$udpserverrun" || dl === "$inputudpserverrun") {
            inputs.push({ line: lineNo, proto: "UDP (imudp)", port: parseInt(dval, 10) || 514, legacy: true });
          } else if (dl === "$tcpserverrun" || dl === "$inputtcpserverrun") {
            inputs.push({ line: lineNo, proto: "TCP (imtcp)", port: parseInt(dval, 10) || 514, legacy: true });
          } else if (dl === "$repeatedmsgreduction") {
            if (/^on$/i.test(dval)) {
              addFinding(lineNo, "INFO", "REPEATED_MSG_REDUCTION",
                "Repeated message reduction is on",
                "$RepeatedMsgReduction is on, so rsyslog collapses repeats into a single \"last message repeated N times\" line. That can hide repeated attack evidence — a thousand failed logins become one summary line with the detail gone.",
                "Leave it off on security-relevant logs, or make sure your review process treats the repeat count itself as a signal worth alerting on.");
            }
          } else if (dl === "$filecreatemode") {
            var fcm = dval.split(/\s+/)[0];
            var fcmVal = parseInt(fcm, 8);
            if (!isNaN(fcmVal) && (fcmVal & ~parseInt("640", 8)) !== 0) {
              addFinding(lineNo, "WARNING", "FILE_CREATE_MODE",
                "Log files are created with mode " + fcm,
                "$FileCreateMode " + fcm + " is more permissive than 0640. Log files routinely contain usernames, source addresses, and internal details, and this mode lets accounts beyond the owning user/group read them.",
                "Set $FileCreateMode 0640 (or stricter, 0600) so only the owner and the log group can read log files.");
            } else if (!isNaN(fcmVal)) {
              good.push("$FileCreateMode " + fcm + " is no more permissive than 0640 (line " + lineNo + ").");
            }
          } else if (dl === "$dircreatemode") {
            var dcm = dval.split(/\s+/)[0];
            var dcmVal = parseInt(dcm, 8);
            if (!isNaN(dcmVal) && (dcmVal & ~parseInt("750", 8)) !== 0) {
              addFinding(lineNo, "INFO", "DIR_CREATE_MODE",
                "Log directories are created with mode " + dcm,
                "$DirCreateMode " + dcm + " is more permissive than 0750, so accounts outside the log group can traverse or read into directories rsyslog creates for log files.",
                "Set $DirCreateMode 0750 (or stricter) unless another account genuinely needs access.");
            }
          }
          continue;
        }

        /* RainerScript statement we do not know? */
        var stmtM = t.match(/^([A-Za-z_][A-Za-z0-9_.]*)\s*\(/);
        if (stmtM && BLOCK_KEYWORDS.indexOf(stmtM[1].toLowerCase()) === -1 && !STMT_STOP[stmtM[1].toLowerCase()]) {
          noteNotAudited(stmtM[1] + "()");
          continue;
        }

        /* Legacy rule line: selector <ws> action */
        var ruleM = t.match(/^(\S+)\s+(.+)$/);
        if (ruleM) {
          var selector = ruleM[1];
          var act = ruleM[2].trim();
          if (selector.charAt(0) === "&") { act = act; selector = "&"; }
          var looksLikeRule = /[.*]/.test(selector) || selector === "&";
          var a = act.replace(/^-/, "");
          if (looksLikeRule) {
            if (a.indexOf("@@") === 0) evalLegacyForward(lineNo, "tcp");
            else if (a.indexOf("@") === 0) evalLegacyForward(lineNo, "udp");
            else if (/^:omfwd:/i.test(a) || /^:omrelp:/i.test(a)) {
              addFinding(lineNo, "WARNING", "NO_ACTION_QUEUE",
                "Forwarding action has no action queue",
                "This forwarding rule carries no queue configuration the auditor can verify, so logs are lost whenever the receiver is down or unreachable.",
                "Move this forwarding into a RainerScript action() with a disk-assisted queue (queue.type=\"LinkedList\", queue.filename set, queue.saveonshutdown=\"on\").");
            }
          }
        }
      }

      /* ---------- RainerScript block pass ---------- */
      for (bi = 0; bi < blocks.length; bi++) {
        var b = blocks[bi];
        var p = b.params;

        if (b.kind === "global") {
          if (p.repeatedmsgreduction && /^on$/i.test(p.repeatedmsgreduction)) {
            addFinding(b.startLine, "INFO", "REPEATED_MSG_REDUCTION",
              "Repeated message reduction is on",
              "RepeatedMsgReduction is set on, so rsyslog collapses repeats into a single \"last message repeated N times\" line. That can hide repeated attack evidence — a thousand failed logins become one summary line with the detail gone.",
              "Leave it off on security-relevant logs, or alert on the repeat count itself.");
          }
          continue;
        }

        if (b.kind === "input") {
          var itype = (p.type || "").toLowerCase();
          if (itype === "imudp" || itype === "imtcp") {
            inputs.push({
              line: b.startLine,
              proto: itype === "imudp" ? "UDP (imudp)" : "TCP (imtcp)",
              port: p.port !== undefined ? parseInt(p.port, 10) : 514,
              interval: p["ratelimit.interval"],
              burst: p["ratelimit.burst"],
              legacy: false
            });
          }
          continue;
        }

        if (b.kind === "action") {
          var atype = (p.type || "").toLowerCase();
          if (atype === "omfwd") {
            var proto = (p.protocol || "tcp").toLowerCase();
            var target = p.target || "the receiver";
            if (proto === "udp") {
              addFinding(b.startLine, "WARNING", "PLAINTEXT_UDP_FORWARDING",
                "Plaintext, unreliable UDP forwarding",
                "This omfwd action forwards logs to " + target + " over UDP in plaintext — readable by anyone on the network path — and UDP is unreliable: datagrams dropped in transit are gone with no error anywhere.",
                "If these logs matter, forward over TCP with TLS: StreamDriver=\"gtls\" StreamDriverMode=\"1\" StreamDriverAuthMode=\"x509/name\". Keep UDP only for logs you can afford to lose.");
            } else {
              var driver = (p.streamdriver || "").toLowerCase();
              var mode = p.streamdrivermode;
              var tlsOk = (driver === "gtls" || driver === "ossl") && mode === "1";
              if (!tlsOk) {
                addFinding(b.startLine, "BLOCKER", "PLAINTEXT_TCP_FORWARDING",
                  "Plaintext TCP forwarding of logs",
                  "This omfwd action forwards logs to " + target + " over TCP without working TLS (StreamDriver must be \"gtls\" or \"ossl\" and StreamDriverMode must be \"1\"), so log contents cross the network readable by anyone on the path.",
                  "Set StreamDriver=\"gtls\" (or \"ossl\"), StreamDriverMode=\"1\", and StreamDriverAuthMode=\"x509/name\" on the action, with the CA and peer name configured to match the receiver.");
              } else if (p.streamdriverauthmode === undefined) {
                addFinding(b.startLine, "WARNING", "TLS_NO_AUTH_MODE",
                  "TLS forwarding without an authentication mode",
                  "This omfwd action encrypts with TLS but sets no StreamDriverAuthMode, so anonymous authentication is allowed — the stream is encrypted, but rsyslog does not verify it is really talking to your log receiver.",
                  "Set StreamDriverAuthMode=\"x509/name\" (or \"x509/fingerprint\") so the receiver's certificate is checked before logs are sent.");
              } else {
                good.push("TLS forwarding to " + target + " with StreamDriverAuthMode set (line " + b.startLine + ") — encrypted and the receiver is authenticated.");
              }
            }
            evalQueueParams(p["queue.type"], p["queue.filename"], p["queue.saveonshutdown"], b.startLine, "omfwd forwarding action");
          } else if (atype === "omrelp" || atype === "ommysql" || atype === "omlibdbi" || atype === "ompgsql") {
            evalQueueParams(p["queue.type"], p["queue.filename"], p["queue.saveonshutdown"], b.startLine, atype + " remote action");
          } else if (atype === "omfile") {
            var ofcm = p.filecreatemode;
            if (ofcm) {
              var ofv = parseInt(ofcm, 8);
              if (!isNaN(ofv) && (ofv & ~parseInt("640", 8)) !== 0) {
                addFinding(b.startLine, "WARNING", "FILE_CREATE_MODE",
                  "Log files are created with mode " + ofcm,
                  "This omfile action uses fileCreateMode " + ofcm + ", more permissive than 0640, so accounts beyond the owning user/group can read the log files it writes.",
                  "Set fileCreateMode=\"0640\" (or stricter, \"0600\") on file outputs.");
              }
            }
          }
          continue;
        }
      }

      /* ---------- Input-level verdicts needing whole-file knowledge ---------- */
      var seenRateLines = {};
      for (i = 0; i < inputs.length; i++) {
        evalRateLimit(inputs[i]);
        if (inputs[i].port !== undefined && !isNaN(inputs[i].port) && inputs[i].port < 1024 && !firstPrivInputLine) {
          firstPrivInputLine = inputs[i].line;
        }
      }
      if (firstPrivInputLine && !privUser && !privGroup) {
        addFinding(firstPrivInputLine, "INFO", "NO_PRIVILEGE_DROP",
          "No privilege drop configured",
          "An input listens on a privileged port (below 1024), and the config sets neither $PrivDropToUser nor $PrivDropToGroup, so rsyslog keeps running with full root privileges after startup instead of dropping to an unprivileged account.",
          "Add $PrivDropToUser and $PrivDropToGroup (for example, the syslog user/group) so rsyslog binds its ports as root, then drops privileges for normal operation.");
      }
      if (privUser || privGroup) {
        good.push("Privilege drop is configured ($PrivDropToUser / $PrivDropToGroup present).");
      }

      if (usesDiskQueue && !workdirSet) {
        addFinding(firstDiskQueueLine, "WARNING", "NO_WORKDIRECTORY",
          "Disk queues used but no WorkDirectory set",
          "This config uses disk-assisted queues (queue.filename is set) but never sets a WorkDirectory, so queue files land in rsyslog's default spool location — verify that location exists, is writable, and has room, or the queue can fail exactly when an outage makes it matter.",
          "Set $WorkDirectory (legacy) or global(workdirectory=\"/var/spool/rsyslog\") to a dedicated spool directory with enough space for your queue.maxdiskspace settings.");
      }

      var rank = { BLOCKER: 0, WARNING: 1, INFO: 2 };
      findings.sort(function (x, y) {
        if (x.line !== y.line) return x.line - y.line;
        return rank[x.severity] - rank[y.severity];
      });

      var counts = { BLOCKER: 0, WARNING: 0, INFO: 0 };
      for (i = 0; i < findings.length; i++) counts[findings[i].severity]++;

      var verdict = counts.BLOCKER > 0 ? "DO NOT DEPLOY" : (counts.WARNING > 0 ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY");

      return {
        verdict: verdict,
        counts: counts,
        findings: findings,
        good: good,
        notAudited: notAudited,
        unparsed: unparsed
      };
    }

    /* ---------------- Rendering ---------------- */

    function esc(s) {
      return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
    }

    function buildTextReport(r) {
      var out = [];
      out.push("J-Dawgs rsyslog Logging Config Safety Auditor\u2122 — Audit Report");
      out.push("Verdict: " + r.verdict);
      out.push("Counts: BLOCKER " + r.counts.BLOCKER + " · WARNING " + r.counts.WARNING + " · INFO " + r.counts.INFO);
      out.push("");
      if (r.findings.length === 0) {
        out.push("Findings: none.");
      } else {
        out.push("Findings:");
        for (var i = 0; i < r.findings.length; i++) {
          var f = r.findings[i];
          out.push("Line " + f.line + " [" + f.severity + "] " + f.title + " (" + f.rule + ")");
          out.push("  " + f.message);
          out.push("  Fix: " + f.fix);
        }
      }
      if (r.good.length) {
        out.push("");
        out.push("What is already right:");
        for (var g = 0; g < r.good.length; g++) out.push("  - " + r.good[g]);
      }
      if (r.notAudited.length) {
        out.push("");
        out.push("Not audited (seen, outside this rule set): " + r.notAudited.join(", "));
      }
      if (r.unparsed.length) {
        out.push("");
        out.push("Unparsable RainerScript blocks (excluded, starting lines): " +
          r.unparsed.map(function (u) { return u.kind + "() at line " + u.line; }).join(", "));
      }
      return out.join("\n");
    }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-rsyslog-logging-config-safety-auditortm',
  name: 'J-Dawgs rsyslog Logging Config Safety Auditor',
  description: 'rsyslogd -N1 only validates that a config loads; ours grades a pasted rsyslog.conf offline — plaintext forwarding, missing action queues that drop logs on outage, rate limits that silently discard messages — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
