'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Strapi Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Worked examples ---------- */

      var RISKY_LINES = [
        "# Risky worked example - a Strapi .env pasted as-is. It starts fine and deploys badly.",
        "HOST=0.0.0.0",
        "PORT=1337",
        "APP_KEYS=abc123,def456",
        "API_TOKEN_SALT=shortsalt",
        "ADMIN_JWT_SECRET=shortsecret9",
        "JWT_SECRET=changeme",
        "TRANSFER_TOKEN_SALT=example-salt",
        "DATABASE_URL=postgres://strapi:dbpass123@db.example.com:5432/strapi",
        "NODE_ENV=development",
        "ADMIN_URL=http://admin.example.com",
        "ALLOW_PUBLIC_REGISTRATION=true"
      ];
      var RISKY = RISKY_LINES.join("\n");

      var HARDENED_LINES = [
        "# Hardened worked example - the same shape, done right.",
        "HOST=127.0.0.1",
        "PORT=1337",
        "APP_KEYS=kX7vQ2mZ9pL4wR8tN6yH3jF5dS1aG0bV,Qw8Er5Ty2Ui9Op3As6Df1Gh4Jk7Lz0Xc,Mn3Bv6Cx9Za2Ls5Kd8Fg1Hj4Qw7Er0Ty,Zx1Cv4Bn7Mk2Jh5Gf8Ds3Aq6Ws9Ed0Rf",
        "API_TOKEN_SALT=pO9iU8yT7rE6wQ5aS4dF3gH2jK1lZ0xC",
        "ADMIN_JWT_SECRET=vB8nM7kL6jH5gF4dS3aQ2wE1rT0yU9iO",
        "JWT_SECRET=aS3dF5gH7jK9lZ1xC2vB4nM6qW8eR0tY",
        "TRANSFER_TOKEN_SALT=uI9oP0aS8dF7gH6jK5lZ4xC3vB2nM1qW",
        "ENCRYPTION_KEY=hG6fD5sA4qW3eR2tY1uI0oP9aS8dF7gH",
        "DATABASE_URL=postgres://strapi@db.internal.example.com:5432/strapi",
        "NODE_ENV=production",
        "ADMIN_URL=https://admin.example.com",
        "ALLOW_PUBLIC_REGISTRATION=false"
      ];
      var HARDENED = HARDENED_LINES.join("\n");

      var GIBBERISH = "blorple snizzle wumpus\nthe quick brown fox jumps over\n12345 !!! ??? ===\nno config lives here at all";

      /* Planted secret values in the risky example. The self-test proves these
         strings appear 0 times in findings, report, and JSON output. */
      var PLANTED_SECRETS = ["shortsecret9", "dbpass123", "shortsalt", "abc123", "def456", "changeme", "example-salt"];

      /* ---------- Auditor ---------- */

      var SECRET_KEYS = ["APP_KEYS","API_TOKEN_SALT","ADMIN_JWT_SECRET","JWT_SECRET","TRANSFER_TOKEN_SALT","ENCRYPTION_KEY"];
      var REQUIRED_KEYS = ["APP_KEYS","API_TOKEN_SALT","ADMIN_JWT_SECRET","TRANSFER_TOKEN_SALT"];
      var EXPECTED_KEYS = ["JWT_SECRET","ENCRYPTION_KEY"];
      var MIN_SECRET_LEN = 32;
      var PLACEHOLDER_RE = /(example|change[\s_-]?me|placeholder|your[\s_-]|default|secret|test|todo|sample|demo|password|1234|xxxx)/i;

      function normalizeKey(k){ return k.toUpperCase().replace(/[\s.\-]+/g,"_"); }

      function stripQuotes(v){
        v = v.replace(/,\s*$/,"").trim();
        if (v.length >= 2){
          var a = v.charAt(0), b = v.charAt(v.length-1);
          if ((a === '"' && b === '"') || (a === "'" && b === "'")) v = v.slice(1,-1);
        }
        return v.trim();
      }

      function parseConfig(text){
        var entries = [];
        var lines = String(text == null ? "" : text).split(/\r?\n/);
        for (var i = 0; i < lines.length; i++){
          var raw = lines[i];
          var lineNo = i + 1;
          var t = raw.trim();
          if (!t || t.charAt(0) === "#" || t.indexOf("//") === 0) continue;
          var m = t.match(/^(?:export\s+)?["']?([A-Za-z_][A-Za-z0-9_.\-]*)["']?\s*[:=]\s*(.*)$/);
          if (m){
            entries.push({ key: normalizeKey(m[1]), rawKey: m[1], value: stripQuotes(m[2]), line: lineNo });
          } else if (/register\s*:\s*true/i.test(t)){
            entries.push({ key: "REGISTER", rawKey: "register", value: "true", line: lineNo });
          }
        }
        return entries;
      }

      function isTruthy(v){
        var s = String(v).trim().toLowerCase();
        return s === "true" || s === "yes" || s === "1" || s === "on";
      }

      function audit(text){
        var entries = parseConfig(text);
        var findings = [];
        function add(severity, key, line, message){
          findings.push({ severity: severity, key: key, line: line, message: message });
        }
        function byKey(k){
          for (var i = 0; i < entries.length; i++) if (entries[i].key === k) return entries[i];
          return null;
        }

        /* Recognizability: how much of a Strapi config is this? */
        var knownSet = {};
        var KNOWN = SECRET_KEYS.concat(["DATABASE_URL","DATABASE_PASSWORD","DATABASE_HOST","DATABASE_NAME","DATABASE_USERNAME","HOST","PORT","NODE_ENV","URL","PUBLIC_URL","ADMIN_URL","SERVER_URL","STRAPI_ADMIN_URL"]);
        entries.forEach(function(e){
          if (KNOWN.indexOf(e.key) >= 0 || /REGIST/.test(e.key)) knownSet[e.key] = true;
        });
        var knownCount = Object.keys(knownSet).length;

        if (knownCount < 3){
          add("info","(input)",null,"Only " + knownCount + " recognizable Strapi config key(s) found. Paste a .env or config with keys such as APP_KEYS, API_TOKEN_SALT, ADMIN_JWT_SECRET, DATABASE_URL, HOST, and NODE_ENV to get a grade.");
          return finish("NOT ENOUGH TO GRADE", findings, knownCount);
        }

        /* Secret keys & salts: presence, length, placeholder values.
           Values are never copied into a finding - key, line, length only. */
        SECRET_KEYS.forEach(function(k){
          var e = byKey(k);
          if (!e){
            if (REQUIRED_KEYS.indexOf(k) >= 0) add("critical", k, null, k + " is missing. Strapi needs it set to a long random value before this config can deploy safely.");
            else if (EXPECTED_KEYS.indexOf(k) >= 0) add("medium", k, null, k + " is not set. Current Strapi versions expect it; set it to a long random value.");
            return;
          }
          if (e.value === ""){
            add("critical", k, e.line, k + " is present on line " + e.line + " but empty (length 0). Set it to a random value of at least " + MIN_SECRET_LEN + " characters.");
            return;
          }
          var parts = (k === "APP_KEYS") ? e.value.split(",").map(function(s){ return s.trim(); }).filter(function(s){ return s !== ""; }) : [e.value];
          if (parts.length === 0){
            add("critical", k, e.line, k + " on line " + e.line + " holds no usable value. Set it to a random value of at least " + MIN_SECRET_LEN + " characters.");
            return;
          }
          parts.forEach(function(p, idx){
            var label = (k === "APP_KEYS" && parts.length > 1) ? (k + " entry " + (idx + 1)) : k;
            if (PLACEHOLDER_RE.test(p)){
              add("critical", k, e.line, label + " on line " + e.line + " matches a known example/placeholder pattern (length " + p.length + "). Anyone can guess it - replace it with a random value of at least " + MIN_SECRET_LEN + " characters.");
            } else if (p.length < MIN_SECRET_LEN){
              add("critical", k, e.line, label + " on line " + e.line + " is too short: length " + p.length + ", minimum " + MIN_SECRET_LEN + " characters for keys, salts, and secrets.");
            }
          });
        });

        /* Database credentials. Passwords are reported by key, line, length ONLY. */
        var dbUrl = byKey("DATABASE_URL");
        if (dbUrl && dbUrl.value){
          var um = dbUrl.value.match(/^[a-z][a-z0-9+.\-]*:\/\/[^:@\/]+:([^@\/]+)@/i);
          if (um){
            add("critical","DATABASE_URL", dbUrl.line, "DATABASE_URL on line " + dbUrl.line + " embeds a plaintext database password (password length " + um[1].length + "). The password itself is never shown here. Move credentials out of the URL into a secrets manager or separate protected variables.");
          }
          if (/^http:\/\//i.test(dbUrl.value)){
            add("medium","DATABASE_URL", dbUrl.line, "DATABASE_URL on line " + dbUrl.line + " uses an unencrypted http:// address.");
          }
        }
        var dbPw = byKey("DATABASE_PASSWORD");
        if (dbPw){
          if (dbPw.value === ""){
            add("medium","DATABASE_PASSWORD", dbPw.line, "DATABASE_PASSWORD is present on line " + dbPw.line + " but empty (length 0).");
          } else {
            add("high","DATABASE_PASSWORD", dbPw.line, "DATABASE_PASSWORD on line " + dbPw.line + " stores a plaintext database password in the config (length " + dbPw.value.length + "). The password itself is never shown here. Prefer a secrets manager or injected environment secret.");
          }
        }

        /* NODE_ENV production posture */
        var nodeEnv = byKey("NODE_ENV");
        if (!nodeEnv){
          add("medium","NODE_ENV", null, "NODE_ENV is not set. Set NODE_ENV=production for a deployed server so Strapi runs in production posture.");
        } else if (nodeEnv.value.toLowerCase() !== "production"){
          add("high","NODE_ENV", nodeEnv.line, "NODE_ENV on line " + nodeEnv.line + " is set to \"" + nodeEnv.value + "\", not \"production\". Development posture can expose debug output and looser defaults.");
        }

        /* HOST bind */
        var host = byKey("HOST");
        if (!host){
          add("medium","HOST", null, "HOST is not set. Confirm what interface the server binds by default before deploying - set HOST explicitly.");
        } else if (host.value === "0.0.0.0" || host.value === "::"){
          add("high","HOST", host.line, "HOST on line " + host.line + " is " + host.value + ", which binds the server to all network interfaces. That is fine only behind a firewall or reverse proxy you control; otherwise bind to 127.0.0.1 or a private address.");
        }

        /* http:// URLs anywhere in the values */
        entries.forEach(function(e){
          if (e.key === "DATABASE_URL") return;
          if (/http:\/\//i.test(e.value)){
            add("medium", e.key, e.line, e.key + " on line " + e.line + " uses an http:// URL. Anything sent to it crosses the network unencrypted - use https://.");
          }
        });

        /* Admin / public registration and upload flags */
        entries.forEach(function(e){
          if (/REGIST/.test(e.key) && isTruthy(e.value)){
            add("high", e.key, e.line, e.key + " on line " + e.line + " turns public registration ON. Anyone on the internet can create an account - turn it off unless open signup is deliberate.");
          }
          if (/UPLOAD/.test(e.key) && /public/i.test(e.value)){
            add("medium", e.key, e.line, e.key + " on line " + e.line + " points uploads at a public setting. Confirm uploaded files are meant to be world-readable before deploying.");
          }
          if (/ADMIN/.test(e.key) && /REGIST/.test(e.key) && isTruthy(e.value)){
            add("critical", e.key, e.line, e.key + " on line " + e.line + " leaves admin registration open. Close it once the admin account exists.");
          }
        });

        var hasCrit = findings.some(function(f){ return f.severity === "critical"; });
        var hasFix = findings.some(function(f){ return f.severity === "high" || f.severity === "medium"; });
        var verdict = hasCrit ? "DO NOT DEPLOY" : (hasFix ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY");
        return finish(verdict, findings, knownCount);
      }

      function finish(verdict, findings, knownCount){
        var counts = { critical:0, high:0, medium:0, info:0 };
        findings.forEach(function(f){ counts[f.severity] = (counts[f.severity] || 0) + 1; });
        var order = { critical:0, high:1, medium:2, info:3 };
        findings.sort(function(a,b){
          var d = order[a.severity] - order[b.severity];
          if (d !== 0) return d;
          var la = a.line == null ? 9999 : a.line, lb = b.line == null ? 9999 : b.line;
          return la - lb;
        });
        return { verdict: verdict, counts: counts, findings: findings, recognizedKeys: knownCount };
      }

      function buildReport(result){
        var out = [];
        out.push("J-Dawgs Strapi Server Config Safety Auditor - audit report");
        out.push("Verdict: " + result.verdict);
        out.push("Recognized Strapi config keys: " + result.recognizedKeys);
        out.push("Findings: " + result.findings.length + " total (" +
          result.counts.critical + " critical, " + result.counts.high + " high, " +
          result.counts.medium + " medium, " + result.counts.info + " info)");
        out.push("Note: secret values are never printed. Findings name the key, the line, and the length only.");
        out.push("");
        if (result.findings.length === 0){
          out.push("No findings.");
        } else {
          result.findings.forEach(function(f, i){
            out.push((i + 1) + ". [" + f.severity.toUpperCase() + "] " +
              (f.line == null ? "(no line)" : "Line " + f.line) + " - " + f.key + ": " + f.message);
          });
        }
        return out.join("\n");
      }

      function buildJson(result){
        return JSON.stringify({
          tool: "J-Dawgs Strapi Server Config Safety Auditor",
          verdict: result.verdict,
          recognizedKeys: result.recognizedKeys,
          counts: result.counts,
          findings: result.findings.map(function(f){
            return { line: f.line, severity: f.severity, key: f.key, message: f.message };
          }),
          note: "Secret values are never included. Findings report key name, line, and length only."
        }, null, 2);
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-strapi-server-config-safety-auditortm',
  name: 'J-Dawgs Strapi Server Config Safety Auditor',
  description: 'Grades a pasted Strapi .env/config offline into one deploy verdict (SAFE TO DEPLOY / DEPLOY WITH FIXES / DO NOT DEPLOY / NOT ENOUGH TO GRADE) — secrets reported by key name, line, and length only, never the secret value.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
