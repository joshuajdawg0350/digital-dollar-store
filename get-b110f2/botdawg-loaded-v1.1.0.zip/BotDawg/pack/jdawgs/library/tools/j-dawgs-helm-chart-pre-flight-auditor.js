'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Helm Chart Pre-Flight Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

    "use strict";

    /* ============================================================
       Honest-subset YAML parser.
       Handles: nested block mappings, block sequences, sequence
       items that are maps, plain / single- / double-quoted scalars,
       comments. Anything else (flow style, anchors, aliases, merge
       keys, block scalars, tabs, unbalanced quotes, indentation it
       cannot place) is recorded in ctx.notParsed with its line
       number and surfaced as a NOT PARSED finding. Nothing is
       silently skipped.
       ============================================================ */

    function stripComment(s) {
      var inS = false, inD = false;
      for (var i = 0; i < s.length; i++) {
        var c = s[i];
        if (inS) { if (c === "'") inS = false; continue; }
        if (inD) { if (c === "\\") { i++; continue; } if (c === '"') inD = false; continue; }
        if (c === "'") inS = true;
        else if (c === '"') inD = true;
        else if (c === "#" && (i === 0 || /\s/.test(s[i - 1]))) return s.slice(0, i);
      }
      return s;
    }

    var SECRET_KEY_RE = /(password|passwd|token|secret|apikey|api_key|privatekey|private_key)/i;

    function redactLineForDisplay(raw) {
      var m = raw.match(/^(\s*-\s*|\s*)([A-Za-z0-9_.\-"']+)\s*:\s*(.*)$/);
      if (m && SECRET_KEY_RE.test(m[2]) && m[3]) {
        return m[1] + m[2] + ": ••• (value hidden)";
      }
      return raw;
    }

    function preprocess(text, ctx) {
      var rawLines = String(text).replace(/\r\n?/g, "\n").split("\n");
      var lines = [];
      for (var i = 0; i < rawLines.length; i++) {
        var raw = rawLines[i], ln = i + 1;
        if (/^\s*$/.test(raw)) continue;
        if (/^\t/.test(raw) || /^ +\t/.test(raw)) {
          ctx.notParsed.push({ line: ln, text: redactLineForDisplay(raw.trim()), reason: "tab indentation — YAML forbids tabs and this parser will not guess at them" });
          continue;
        }
        var noComment = stripComment(raw);
        if (/^\s*$/.test(noComment)) continue;
        var trimmed = noComment.replace(/\s+$/, "");
        var indent = trimmed.match(/^ */)[0].length;
        var content = trimmed.slice(indent);
        if (content === "---" || content === "...") continue;
        lines.push({ indent: indent, content: content, line: ln, raw: raw.trim() });
      }
      return lines;
    }

    function parseScalar(str, lineObj, ctx) {
      str = String(str).trim();
      if (str === "" || str === "~" || /^null$/i.test(str)) {
        return { type: "scalar", value: null, raw: str, line: lineObj.line };
      }
      var c0 = str.charAt(0);
      if (c0 === "{" || c0 === "[") {
        ctx.notParsed.push({ line: lineObj.line, text: redactLineForDisplay(lineObj.raw), reason: "flow-style collection (" + c0 + "…) — this parser reads block style only" });
        return { type: "scalar", value: null, raw: str, line: lineObj.line, unparsed: true };
      }
      if (c0 === "&" || c0 === "*") {
        ctx.notParsed.push({ line: lineObj.line, text: redactLineForDisplay(lineObj.raw), reason: (c0 === "&" ? "anchor" : "alias") + " — anchors and aliases are not expanded by this parser" });
        return { type: "scalar", value: null, raw: str, line: lineObj.line, unparsed: true };
      }
      if (c0 === '"' || c0 === "'") {
        var q = c0;
        if (str.length < 2 || str.charAt(str.length - 1) !== q) {
          ctx.notParsed.push({ line: lineObj.line, text: redactLineForDisplay(lineObj.raw), reason: "unbalanced quote — the scalar does not close on this line" });
          return { type: "scalar", value: null, raw: str, line: lineObj.line, unparsed: true };
        }
        var inner = str.slice(1, -1);
        if (q === '"') inner = inner.replace(/\\n/g, "\n").replace(/\\t/g, "\t").replace(/\\"/g, '"').replace(/\\\\/g, "\\");
        else inner = inner.replace(/''/g, "'");
        return { type: "scalar", value: inner, raw: str, line: lineObj.line, quoted: true };
      }
      return { type: "scalar", value: str, raw: str, line: lineObj.line };
    }

    function isListLine(l) { return l.content === "-" || l.content.indexOf("- ") === 0; }

    var KEY_RE = /^("(?:[^"\\]|\\.)*"|'[^']*'|[^:\s][^:]*?):(?:\s+(.*))?$/;

    function parseBlock(lines, start, ctx) {
      var i = start;
      if (i >= lines.length) return [{ type: "scalar", value: null, raw: "", line: 0 }, i];
      var effIndent = lines[i].indent;

      if (isListLine(lines[i])) {
        var items = [];
        var listLine = lines[i].line;
        while (i < lines.length && lines[i].indent === effIndent && isListLine(lines[i])) {
          var itemLine = lines[i];
          var rest = itemLine.content === "-" ? "" : itemLine.content.slice(2);
          var j = i + 1, sub = [];
          while (j < lines.length && lines[j].indent > effIndent) { sub.push(lines[j]); j++; }
          if (rest === "") {
            if (sub.length) {
              var r0 = parseBlock(sub, 0, ctx);
              items.push(r0[0]);
              for (var a = r0[1]; a < sub.length; a++) leftover(sub[a], ctx);
            } else {
              items.push({ type: "scalar", value: null, raw: "", line: itemLine.line });
            }
          } else if (!KEY_RE.test(rest) && !isListLine({ content: rest })) {
            var sc = parseScalar(rest, itemLine, ctx);
            sc.line = itemLine.line;
            items.push(sc);
            for (var b = 0; b < sub.length; b++) leftover(sub[b], ctx);
          } else {
            var virt = { indent: effIndent + 2, content: rest, line: itemLine.line, raw: itemLine.raw };
            var group = [virt].concat(sub);
            var r2 = parseBlock(group, 0, ctx);
            items.push(r2[0]);
            for (var c = r2[1]; c < group.length; c++) leftover(group[c], ctx);
          }
          i = j;
        }
        return [{ type: "list", items: items, line: listLine }, i];
      }

      var entries = [];
      var seen = {};
      var mapLine = lines[i].line;
      while (i < lines.length && lines[i].indent === effIndent && !isListLine(lines[i])) {
        var L = lines[i];
        var m = L.content.match(KEY_RE);
        if (!m) {
          ctx.notParsed.push({ line: L.line, text: redactLineForDisplay(L.raw), reason: "not a \"key: value\" line and not a list item — this parser cannot place it" });
          i++;
          continue;
        }
        var keyRaw = m[1].trim();
        var key = keyRaw;
        if ((keyRaw.charAt(0) === '"' && keyRaw.charAt(keyRaw.length - 1) === '"') ||
            (keyRaw.charAt(0) === "'" && keyRaw.charAt(keyRaw.length - 1) === "'")) {
          key = keyRaw.slice(1, -1);
        }
        if (key === "<<") {
          ctx.notParsed.push({ line: L.line, text: redactLineForDisplay(L.raw), reason: "merge key (<<) — merges are not expanded by this parser" });
          i++;
          continue;
        }
        if (Object.prototype.hasOwnProperty.call(seen, key)) {
          ctx.dupes.push({ key: key, line: L.line });
        }
        seen[key] = true;
        var inline = (m[2] === undefined ? "" : m[2]);
        var node;
        if (inline !== "") {
          if (inline.charAt(0) === "|" || inline.charAt(0) === ">") {
            ctx.notParsed.push({ line: L.line, text: redactLineForDisplay(L.raw), reason: "block scalar (" + inline.charAt(0) + ") — multi-line literal/folded text is not read by this parser" });
            node = { type: "scalar", value: null, raw: inline, line: L.line, unparsed: true };
            i++;
            while (i < lines.length && lines[i].indent > effIndent) i++; /* lines belong to the reported construct */
          } else {
            node = parseScalar(inline, L, ctx);
            i++;
          }
        } else {
          var nxt = (i + 1 < lines.length) ? lines[i + 1] : null;
          if (!nxt || nxt.indent < effIndent) {
            node = { type: "scalar", value: null, raw: "", line: L.line };
            i++;
          } else if (nxt.indent === effIndent && isListLine(nxt)) {
            var rl = parseBlock(lines, i + 1, ctx);
            node = rl[0]; i = rl[1];
          } else if (nxt.indent > effIndent) {
            var rb = parseBlock(lines, i + 1, ctx);
            node = rb[0]; i = rb[1];
          } else {
            node = { type: "scalar", value: null, raw: "", line: L.line };
            i++;
          }
        }
        entries.push({ key: key, line: L.line, value: node });
      }
      return [{ type: "map", entries: entries, line: mapLine }, i];
    }

    function leftover(lineObj, ctx) {
      ctx.notParsed.push({ line: lineObj.line, text: redactLineForDisplay(lineObj.raw), reason: "indentation does not line up with the structure around it — this parser will not guess where it belongs" });
    }

    function parseDocument(text) {
      var ctx = { notParsed: [], dupes: [] };
      var lines = preprocess(text, ctx);
      if (!lines.length) return { root: null, ctx: ctx, empty: true };
      var r = parseBlock(lines, 0, ctx);
      for (var k = r[1]; k < lines.length; k++) leftover(lines[k], ctx);
      ctx.notParsed.sort(function (a, b) { return a.line - b.line; });
      return { root: r[0], ctx: ctx, empty: false };
    }

    /* ---------- tree helpers ---------- */
    function getChild(mapNode, key) {
      if (!mapNode || mapNode.type !== "map") return null;
      for (var i = 0; i < mapNode.entries.length; i++) {
        if (mapNode.entries[i].key === key) return mapNode.entries[i];
      }
      return null;
    }
    function childScalar(mapNode, key) {
      var e = getChild(mapNode, key);
      if (!e || !e.value || e.value.type !== "scalar") return undefined;
      return e.value.value;
    }
    function isTrue(v) { return v === true || (typeof v === "string" && /^true$/i.test(v)); }
    function isFalse(v) { return v === false || (typeof v === "string" && /^false$/i.test(v)); }

    function walkMaps(node, path, keyName, cb) {
      if (!node) return;
      if (node.type === "map") {
        cb(node, path, keyName);
        for (var i = 0; i < node.entries.length; i++) {
          var e = node.entries[i];
          walkMaps(e.value, path ? path + "." + e.key : e.key, e.key, cb);
        }
      } else if (node.type === "list") {
        for (var j = 0; j < node.items.length; j++) {
          walkMaps(node.items[j], path + "[" + j + "]", keyName, cb);
        }
      }
    }
    function walkEntries(node, path, cb) {
      if (!node) return;
      if (node.type === "map") {
        for (var i = 0; i < node.entries.length; i++) {
          var e = node.entries[i];
          var p = path ? path + "." + e.key : e.key;
          cb(e, p);
          walkEntries(e.value, p, cb);
        }
      } else if (node.type === "list") {
        for (var j = 0; j < node.items.length; j++) walkEntries(node.items[j], path + "[" + j + "]", cb);
      }
    }

    /* ============================================================
       Audit checks
       ============================================================ */
    var SEMVER_RE = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-((?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*)(?:\.(?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*))*))?(?:\+([0-9a-zA-Z-]+(?:\.[0-9a-zA-Z-]+)*))?$/;

    function audit(chartText, valuesText, env) {
      var findings = [];
      function add(sev, file, line, msg) { findings.push({ sev: sev, file: file, line: line, msg: msg }); }
      var isProd = env === "production";

      /* ---------- Chart.yaml ---------- */
      var chartDoc = parseDocument(chartText);
      chartDoc.ctx.notParsed.forEach(function (n) {
        add("notparsed", "Chart.yaml", n.line, "NOT PARSED — " + n.reason + ": “" + n.text + "”");
      });
      chartDoc.ctx.dupes.forEach(function (d) {
        add("warning", "Chart.yaml", d.line, "Duplicate key “" + d.key + "” in the same mapping — most YAML parsers silently keep the last value.");
      });

      if (chartDoc.empty) {
        add("blocker", "Chart.yaml", null, "Chart.yaml is empty — nothing was pasted, so there is no chart metadata to audit.");
      } else if (!chartDoc.root || chartDoc.root.type !== "map") {
        add("blocker", "Chart.yaml", chartDoc.root ? chartDoc.root.line : null, "Chart.yaml did not parse as a top-level mapping of keys — Helm expects Chart.yaml to be a map.");
      } else {
        var croot = chartDoc.root;

        var apiE = getChild(croot, "apiVersion");
        if (!apiE) {
          add("blocker", "Chart.yaml", null, "apiVersion is missing — Helm requires it in Chart.yaml.");
        } else {
          var apiV = childScalar(croot, "apiVersion");
          if (apiV === "v2") {
            add("note", "Chart.yaml", apiE.line, "apiVersion is v2 — current Helm chart format.");
          } else if (apiV === "v1") {
            add("blocker", "Chart.yaml", apiE.line, "apiVersion is v1 — the legacy Helm 2 format. Current Helm expects v2 (v1 charts also declare dependencies in a separate requirements.yaml this tool never sees).");
          } else if (apiV === null || apiV === undefined) {
            add("blocker", "Chart.yaml", apiE.line, "apiVersion has no readable value.");
          } else {
            add("blocker", "Chart.yaml", apiE.line, "apiVersion is “" + apiV + "” — Helm recognises v1 and v2, and current charts should be v2.");
          }
        }

        var nameE = getChild(croot, "name");
        if (!nameE || !childScalar(croot, "name")) {
          add("blocker", "Chart.yaml", nameE ? nameE.line : null, "name is missing or empty — every chart needs a name in Chart.yaml.");
        }

        var verE = getChild(croot, "version");
        var verV = childScalar(croot, "version");
        if (!verE || verV === null || verV === undefined || verV === "") {
          add("blocker", "Chart.yaml", verE ? verE.line : null, "version is missing — Helm requires a chart version in Chart.yaml.");
        } else if (!SEMVER_RE.test(String(verV))) {
          add("blocker", "Chart.yaml", verE.line, "version “" + verV + "” is not valid semantic versioning (expected MAJOR.MINOR.PATCH, e.g. 1.4.2) — Helm refuses to package a chart whose version is not valid semver.");
        } else {
          add("note", "Chart.yaml", verE.line, "version " + verV + " is valid semver.");
        }

        var appE = getChild(croot, "appVersion");
        if (!appE || childScalar(croot, "appVersion") === null || childScalar(croot, "appVersion") === undefined || childScalar(croot, "appVersion") === "") {
          add("warning", "Chart.yaml", appE ? appE.line : null, "appVersion is missing — it records the version of the application being deployed, and many charts also use it as the default image tag. Without it, nobody can tell from the chart what app version ships.");
        }

        var kubeE = getChild(croot, "kubeVersion");
        if (kubeE) {
          var kv = childScalar(croot, "kubeVersion");
          if (typeof kv === "string" && kv) {
            var nums = kv.match(/\d+\.\d+(?:\.\d+)?/g) || [];
            var old = null;
            nums.forEach(function (n) {
              var parts = n.split(".").map(Number);
              if (parts[0] < 1 || (parts[0] === 1 && parts[1] < 16)) old = n;
            });
            if (old) {
              add("warning", "Chart.yaml", kubeE.line, "kubeVersion constraint “" + kv + "” reaches back to Kubernetes " + old + " — versions before 1.16 are long past end-of-life and rely on APIs removed from modern clusters. This constraint looks deprecated; tighten it to versions you actually support.");
            } else {
              add("note", "Chart.yaml", kubeE.line, "kubeVersion constraint “" + kv + "” stays within supported Kubernetes versions.");
            }
          }
        }

        var depsE = getChild(croot, "dependencies");
        if (depsE && depsE.value) {
          if (depsE.value.type === "list") {
            if (!depsE.value.items.length) {
              add("note", "Chart.yaml", depsE.line, "dependencies is present but empty — no dependency pins to check.");
            }
            depsE.value.items.forEach(function (item, idx) {
              var label = "dependency #" + (idx + 1);
              if (!item || item.type !== "map") {
                add("warning", "Chart.yaml", item ? item.line : depsE.line, label + " is not a mapping with name/version — its pin could not be checked.");
                return;
              }
              var dn = childScalar(item, "name");
              if (dn) label = "dependency “" + dn + "”";
              var dvE = getChild(item, "version");
              var dv = childScalar(item, "version");
              if (!dvE || dv === null || dv === undefined || dv === "") {
                add("blocker", "Chart.yaml", dvE ? dvE.line : item.line, label + " has no version — an unpinned dependency resolves to whatever is newest at install time, so two installs of the same chart can deploy different software.");
              } else if (!SEMVER_RE.test(String(dv))) {
                add("blocker", "Chart.yaml", dvE.line, label + " is pinned to “" + dv + "”, which is a range or a non-exact version, not an exact pin. Pin the exact version (e.g. 12.5.1) so every install resolves identically.");
              } else {
                add("note", "Chart.yaml", dvE.line, label + " is pinned to exact version " + dv + ".");
              }
            });
          } else if (depsE.value.type === "scalar" && depsE.value.value !== null) {
            add("warning", "Chart.yaml", depsE.line, "dependencies is a single value, not a list — dependency pins could not be checked.");
          }
        }
      }

      /* ---------- values.yaml ---------- */
      var valDoc = parseDocument(valuesText);
      valDoc.ctx.notParsed.forEach(function (n) {
        add("notparsed", "values.yaml", n.line, "NOT PARSED — " + n.reason + ": “" + n.text + "”");
      });
      valDoc.ctx.dupes.forEach(function (d) {
        add("warning", "values.yaml", d.line, "Duplicate key “" + d.key + "” in the same mapping — most YAML parsers silently keep the last value.");
      });

      if (valDoc.empty) {
        add("warning", "values.yaml", null, "values.yaml is empty — nothing was pasted, so there are no values to audit. Every check below that depends on values is skipped, not passed.");
      } else if (!valDoc.root || valDoc.root.type !== "map") {
        add("blocker", "values.yaml", valDoc.root ? valDoc.root.line : null, "values.yaml did not parse as a top-level mapping of keys — Helm values files must be a map.");
      } else {
        var vroot = valDoc.root;

        /* --- workload sections: any map holding image / resources / replicaCount --- */
        var workloads = [];
        walkMaps(vroot, "", null, function (node, path) {
          if (getChild(node, "image") || getChild(node, "resources") || getChild(node, "replicaCount")) {
            workloads.push({ node: node, path: path || "(root)" });
          }
        });

        var anyReplica = false;
        workloads.forEach(function (w) {
          var rc = childScalar(w.node, "replicaCount");
          if (rc !== undefined && rc !== null && rc !== "") anyReplica = true;
        });

        if (!workloads.length) {
          add("warning", "values.yaml", null, "No workload section found — no mapping in values.yaml holds an image, resources, or replicaCount key, so image, resource, and replica checks had nothing to run against.");
        }

        workloads.forEach(function (w) {
          var where = w.path === "(root)" ? "the top level of values.yaml" : "section “" + w.path + "”";

          /* image checks */
          var imgE = getChild(w.node, "image");
          if (imgE && imgE.value && imgE.value.type === "map") {
            var img = imgE.value;
            var repo = childScalar(img, "repository");
            var repoE = getChild(img, "repository");
            if (repo === undefined || repo === null || repo === "") {
              add("blocker", "values.yaml", repoE ? repoE.line : imgE.line, "In " + where + ": image.repository is missing or empty — the workload has no image to pull.");
            }
            var tagE = getChild(img, "tag");
            var tag = childScalar(img, "tag");
            if (tag === undefined || tag === null || tag === "") {
              if (isProd) {
                add("blocker", "values.yaml", tagE ? tagE.line : imgE.line, "In " + where + ": image.tag is not set. In production an unset tag drifts to whatever the chart default is — pin an exact tag.");
              } else {
                add("warning", "values.yaml", tagE ? tagE.line : imgE.line, "In " + where + ": image.tag is not set — the chart's default (often the appVersion, sometimes latest) decides what runs.");
              }
            } else if (String(tag).toLowerCase() === "latest") {
              if (isProd) {
                add("blocker", "values.yaml", tagE.line, "In " + where + ": image.tag is “latest”. In production that is a blocker — “latest” is a moving target, so a rollback or a pod restart can silently change the code that is running. Pin an exact version tag.");
              } else {
                add("warning", "values.yaml", tagE.line, "In " + where + ": image.tag is “latest” — a moving target. Tolerable in " + env + ", but pin an exact tag before this goes anywhere near production.");
              }
            }
            var ppE = getChild(img, "pullPolicy");
            var pp = childScalar(img, "pullPolicy");
            if (pp === undefined || pp === null || pp === "") {
              add("note", "values.yaml", ppE ? ppE.line : imgE.line, "In " + where + ": image.pullPolicy is not set — Kubernetes defaults apply (Always for a “latest” tag, IfNotPresent otherwise). Setting it explicitly removes the guesswork.");
            } else {
              add("note", "values.yaml", ppE.line, "In " + where + ": image.pullPolicy is " + pp + ".");
              if (String(tag).toLowerCase() === "latest" && String(pp) === "IfNotPresent") {
                add("warning", "values.yaml", ppE.line, "In " + where + ": pullPolicy IfNotPresent combined with tag “latest” means a node that already has some “latest” image cached will never pull a newer one — nodes end up running different code.");
              }
            }
          } else if (imgE) {
            add("warning", "values.yaml", imgE.line, "In " + where + ": image is not a mapping, so repository / tag / pullPolicy could not be checked.");
          }

          /* resource checks */
          var resE = getChild(w.node, "resources");
          var resNode = resE && resE.value && resE.value.type === "map" ? resE.value : null;
          var resLine = resE ? resE.line : w.node.line;
          function resVal(kind, key) {
            if (!resNode) return undefined;
            var kindE = getChild(resNode, kind);
            if (!kindE || !kindE.value || kindE.value.type !== "map") return undefined;
            return childScalar(kindE.value, key);
          }
          var missingReq = [], missingLim = [];
          ["cpu", "memory"].forEach(function (k) {
            var rv = resVal("requests", k);
            if (rv === undefined || rv === null || rv === "") missingReq.push(k);
            var lv = resVal("limits", k);
            if (lv === undefined || lv === null || lv === "") missingLim.push(k);
          });
          if (missingReq.length) {
            add("warning", "values.yaml", resLine, "In " + where + ": resource requests are missing " + missingReq.join(" and ") + ". Without requests the scheduler cannot place pods sensibly and autoscaling has nothing to work from.");
          }
          if (missingLim.length) {
            if (isProd) {
              add("blocker", "values.yaml", resLine, "In " + where + ": resource limits are missing " + missingLim.join(" and ") + ". In production an unbounded container can consume a whole node — memory especially, since an OOM event takes neighbours down with it. Set limits.cpu and limits.memory.");
            } else {
              add("warning", "values.yaml", resLine, "In " + where + ": resource limits are missing " + missingLim.join(" and ") + " — fine to explore without them in " + env + ", but set them before production.");
            }
          }
          if (!missingReq.length && !missingLim.length && resNode) {
            add("note", "values.yaml", resLine, "In " + where + ": resource requests and limits set for both cpu and memory.");
          }
        });

        /* --- securityContext checks (whole file) --- */
        var scNodes = [];
        walkMaps(vroot, "", null, function (node, path, keyName) {
          if (keyName === "securityContext") scNodes.push({ node: node, path: path });
        });
        var anyRunAsNonRoot = false, anyROFS = false;
        scNodes.forEach(function (s) {
          var at = "securityContext at “" + s.path + "”";
          var sc = s.node;
          if (isTrue(childScalar(sc, "runAsRoot"))) {
            add("blocker", "values.yaml", getChild(sc, "runAsRoot").line, "The " + at + " sets runAsRoot: true — the container explicitly runs as root. Set runAsNonRoot: true and a non-zero runAsUser instead.");
          }
          var uid = childScalar(sc, "runAsUser");
          if (uid !== undefined && uid !== null && String(uid) === "0") {
            add("blocker", "values.yaml", getChild(sc, "runAsUser").line, "The " + at + " sets runAsUser: 0 — that is root, whatever runAsNonRoot claims alongside it.");
          }
          if (isTrue(childScalar(sc, "privileged"))) {
            add("blocker", "values.yaml", getChild(sc, "privileged").line, "The " + at + " sets privileged: true — privileged containers get near-host-level access. Almost nothing needs this; remove it or expect a hard no from any pod security policy.");
          }
          if (isTrue(childScalar(sc, "allowPrivilegeEscalation"))) {
            add("blocker", "values.yaml", getChild(sc, "allowPrivilegeEscalation").line, "The " + at + " sets allowPrivilegeEscalation: true — a process can gain more privileges than its parent. Set it to false unless the workload genuinely needs setuid-style escalation.");
          }
          if (isTrue(childScalar(sc, "runAsNonRoot"))) anyRunAsNonRoot = true;
          if (isTrue(childScalar(sc, "readOnlyRootFilesystem"))) anyROFS = true;
          /* capabilities can nest runAsUser etc. — only direct keys checked, by design */
          var capE = getChild(sc, "capabilities");
          if (capE && capE.value && capE.value.type === "map") {
            walkMaps(capE.value, s.path + ".capabilities", "capabilities", function () {});
          }
        });
        if (!scNodes.length) {
          add("warning", "values.yaml", null, "No securityContext appears anywhere in values.yaml — runAsNonRoot and readOnlyRootFilesystem are left to chart defaults, which usually means containers run as root with a writable root filesystem.");
        } else {
          if (!anyRunAsNonRoot) {
            add("warning", "values.yaml", scNodes[0].node.line, "securityContext is present, but runAsNonRoot is not set to true in any of them — nothing stops the image's default (often root) user from running.");
          }
          if (!anyROFS) {
            add("note", "values.yaml", scNodes[0].node.line, "readOnlyRootFilesystem is not set to true in any securityContext — containers can write to their root filesystem. Setting it (with explicit writable mounts where needed) shrinks what a compromised process can change.");
          }
        }

        /* --- replicaCount in production --- */
        if (isProd && !anyReplica) {
          add("warning", "values.yaml", null, "Expected environment is production, but replicaCount does not appear in any workload section — the replica count falls back to the chart default (very often 1, a single point of failure).");
        }

        /* --- ingress TLS --- */
        var ingressNodes = [];
        walkMaps(vroot, "", null, function (node, path, keyName) {
          if (keyName === "ingress") ingressNodes.push({ node: node, path: path });
        });
        ingressNodes.forEach(function (ing) {
          var enE = getChild(ing.node, "enabled");
          if (!isTrue(childScalar(ing.node, "enabled"))) return;
          var tlsE = getChild(ing.node, "tls");
          var hasHosts = false;
          if (tlsE && tlsE.value) {
            if (tlsE.value.type === "list") {
              tlsE.value.items.forEach(function (it) {
                if (it && it.type === "map") {
                  var h = getChild(it, "hosts");
                  if (h && h.value && h.value.type === "list" && h.value.items.length) hasHosts = true;
                  if (h && h.value && h.value.type === "scalar" && h.value.value) hasHosts = true;
                }
              });
            } else if (tlsE.value.type === "map") {
              var hh = getChild(tlsE.value, "hosts");
              if (hh) hasHosts = true;
            }
          }
          if (!hasHosts) {
            add("warning", "values.yaml", enE ? enE.line : ing.node.line, "Ingress at “" + ing.path + "” is enabled but declares no TLS hosts — traffic is served over plain HTTP. Add a tls section with hosts (and the secret holding the certificate).");
          } else {
            add("note", "values.yaml", tlsE.line, "Ingress at “" + ing.path + "” is enabled and declares TLS hosts.");
          }
        });

        /* --- hardcoded secret-looking values (key name only; value never printed) --- */
        walkEntries(vroot, "", function (e, path) {
          var norm = e.key.toLowerCase().replace(/[^a-z0-9]/g, "");
          var hit = ["password", "passwd", "token", "secret", "apikey"].some(function (kw) {
            return norm === kw || norm.slice(-kw.length) === kw;
          });
          if (!hit) return;
          if (!e.value || e.value.type !== "scalar") return;
          var v = e.value.value;
          if (v === null || v === undefined || v === "") return;
          var vs = String(v);
          if (vs.charAt(0) === "{" || vs.indexOf("{{") === 0) return; /* templated/reference, not a literal */
          var peek = vs.slice(0, 2);
          add(isProd ? "blocker" : "warning", "values.yaml", e.line,
            "Hardcoded secret-looking value under key “" + e.key + "” (at " + path + ") — the value starts with “" + peek + "…” and the rest is deliberately not shown. Literal passwords, tokens, and API keys in values.yaml end up in git history and in the rendered release. Move it into a Kubernetes Secret and reference it instead.");
        });
      }

      /* ---------- order + verdict ---------- */
      var sevRank = { blocker: 0, warning: 1, notparsed: 2, note: 3 };
      findings.sort(function (a, b) {
        if (sevRank[a.sev] !== sevRank[b.sev]) return sevRank[a.sev] - sevRank[b.sev];
        if (a.file !== b.file) return a.file < b.file ? -1 : 1;
        var la = a.line === null ? 0 : a.line, lb = b.line === null ? 0 : b.line;
        return la - lb;
      });
      var counts = { blocker: 0, warning: 0, notparsed: 0, note: 0 };
      findings.forEach(function (f) { counts[f.sev]++; });
      var verdict = counts.blocker > 0 ? "DO NOT DEPLOY" : (counts.warning > 0 || counts.notparsed > 0) ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY";
      return { findings: findings, counts: counts, verdict: verdict, env: env };
    }

    /* ============================================================
       Worked examples
       ============================================================ */
    var RISKY_CHART = [
      "apiVersion: v2",
      "name: billing-api",
      "version: 1.4",
      "appVersion: \"2.1.0\"",
      "kubeVersion: \">=1.14.0-0\"",
      "dependencies:",
      "  - name: postgresql",
      "    version: \">=12.0.0\"",
      "    repository: https://charts.example.invalid/postgresql",
      ""
    ].join("\n");

    var RISKY_VALUES = [
      "image:",
      "  repository: registry.example.invalid/billing-api",
      "  tag: \"latest\"",
      "  pullPolicy: IfNotPresent",
      "",
      "database:",
      "  host: db.internal",
      "  password: \"hunter2-prod\"",
      "",
      "resources:",
      "  requests:",
      "    cpu: 100m",
      "    memory: 128Mi",
      "",
      "ingress:",
      "  enabled: true",
      "  hosts:",
      "    - host: billing.example.invalid",
      "      paths:",
      "        - /",
      ""
    ].join("\n");

    var CLEAN_CHART = [
      "apiVersion: v2",
      "name: billing-api",
      "version: 1.4.2",
      "appVersion: \"2.1.0\"",
      "kubeVersion: \">=1.24.0-0\"",
      "dependencies:",
      "  - name: postgresql",
      "    version: 12.5.1",
      "    repository: https://charts.example.invalid/postgresql",
      ""
    ].join("\n");

    var CLEAN_VALUES = [
      "replicaCount: 3",
      "",
      "image:",
      "  repository: registry.example.invalid/billing-api",
      "  tag: \"2.1.0\"",
      "  pullPolicy: IfNotPresent",
      "",
      "resources:",
      "  requests:",
      "    cpu: 250m",
      "    memory: 256Mi",
      "  limits:",
      "    cpu: 500m",
      "    memory: 512Mi",
      "",
      "securityContext:",
      "  runAsNonRoot: true",
      "  runAsUser: 10001",
      "  readOnlyRootFilesystem: true",
      "  allowPrivilegeEscalation: false",
      "  privileged: false",
      "",
      "ingress:",
      "  enabled: true",
      "  tls:",
      "    - secretName: billing-tls",
      "      hosts:",
      "        - billing.example.invalid",
      ""
    ].join("\n");
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-helm-chart-pre-flight-auditor',
  name: 'J-Dawgs Helm Chart Pre-Flight Auditor',
  description: 'Audits a pasted Chart.yaml + values.yaml offline before deploy — image pinning, resource limits, securityContext posture, secret keys flagged by name only, unpinned dependencies — and returns one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
