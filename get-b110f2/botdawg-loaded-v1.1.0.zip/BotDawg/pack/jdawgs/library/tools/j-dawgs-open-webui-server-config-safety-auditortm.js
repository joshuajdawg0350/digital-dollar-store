'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Open WebUI Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

  "use strict";

  var RISKY = [
    "# RISKY EXAMPLE - fake short values on purpose. Do not deploy this.",
    "WEBUI_SECRET_KEY=short123",
    "WEBUI_AUTH=false",
    "ENABLE_SIGNUP=true",
    "DEFAULT_USER_ROLE=admin",
    "WEBUI_URL=http://chat.example.com",
    "CORS_ALLOW_ORIGIN=*",
    "ENABLE_OAUTH_SIGNUP=true",
    "OAUTH_CLIENT_SECRET=abc123",
    "DATABASE_URL=postgres://admin:weak@db.example.com:5432/openwebui",
    "REDIS_PASSWORD=redispw99",
    "ENABLE_RAG_WEB_SEARCH=true",
    "BYPASS_MODEL_ACCESS_CONTROL=true",
    "ENABLE_ADMIN_EXPORT=true",
    "HOST=0.0.0.0",
    "PORT=8080",
    "OPENAI_API_KEY=sk-fake123"
  ].join("\n");

  var HARDENED = [
    "# HARDENED EXAMPLE - long fake values, shaped like a locked-down deploy.",
    "WEBUI_SECRET_KEY=kX9vQ2mZ8pL4wR7tY1nB6sD3fG5hJ0aK9cE2uI4oP7qW1x",
    "WEBUI_AUTH=true",
    "ENABLE_SIGNUP=false",
    "ENABLE_LOGIN_FORM=true",
    "DEFAULT_USER_ROLE=user",
    "WEBUI_URL=https://chat.example.com",
    "CORS_ALLOW_ORIGIN=https://chat.example.com",
    "ENABLE_OAUTH_SIGNUP=false",
    "DATABASE_URL=postgresql://openwebui@db.internal:5432/openwebui",
    "REDIS_PASSWORD=R8dK2pQ9xW4mZ7vN1bT6yU3eA5sF0gH2jL9cV4bN7mQ1w",
    "ENABLE_RAG_WEB_SEARCH=false",
    "BYPASS_MODEL_ACCESS_CONTROL=false",
    "ENABLE_ADMIN_EXPORT=false",
    "HOST=127.0.0.1",
    "PORT=8080"
  ].join("\n");

  var KNOWN = {
    WEBUI_SECRET_KEY:1, WEBUI_AUTH:1, WEBUI_URL:1, WEBUI_NAME:1, WEBUI_HOST:1, WEBUI_PORT:1,
    ENABLE_SIGNUP:1, ENABLE_LOGIN_FORM:1, DEFAULT_USER_ROLE:1, DEFAULT_MODELS:1,
    CORS_ALLOW_ORIGIN:1, ENABLE_OAUTH_SIGNUP:1, OAUTH_MERGE_ACCOUNTS_BY_EMAIL:1, OAUTH_PROVIDER_NAME:1,
    GOOGLE_OAUTH_CLIENT_ID:1, GOOGLE_OAUTH_CLIENT_SECRET:1, GOOGLE_REDIRECT_URI:1,
    MICROSOFT_OAUTH_CLIENT_ID:1, MICROSOFT_OAUTH_CLIENT_SECRET:1, MICROSOFT_REDIRECT_URI:1,
    GITHUB_OAUTH_CLIENT_ID:1, GITHUB_OAUTH_CLIENT_SECRET:1, GITHUB_REDIRECT_URI:1,
    OPENID_PROVIDER_URL:1, OPENID_CLIENT_ID:1, OPENID_CLIENT_SECRET:1, OPENID_REDIRECT_URI:1,
    OAUTH_CLIENT_ID:1, OAUTH_CLIENT_SECRET:1, OAUTH_REDIRECT_URI:1,
    DATABASE_URL:1, DATABASE_POOL_SIZE:1, REDIS_URL:1, REDIS_PASSWORD:1,
    ENABLE_RAG_WEB_SEARCH:1, RAG_WEB_SEARCH_ENGINE:1, BYPASS_MODEL_ACCESS_CONTROL:1,
    ENABLE_ADMIN_EXPORT:1, ENABLE_ADMIN_CHAT_ACCESS:1, HOST:1, PORT:1,
    OPENAI_API_KEY:1, OPENAI_API_KEYS:1, OPENAI_API_BASE_URL:1, OLLAMA_BASE_URL:1, ENABLE_OLLAMA_API:1,
    DATA_DIR:1, JWT_EXPIRES_IN:1, SESSION_COOKIE_SECURE:1, SESSION_COOKIE_SAME_SITE:1,
    WEBUI_SESSION_COOKIE_SECURE:1, ENABLE_CHANNELS:1, ENABLE_COMMUNITY_SHARING:1,
    USER_PERMISSIONS:1, MODEL_FILTER_ENABLED:1, AIOHTTP_CLIENT_TIMEOUT:1, GLOBAL_LOG_LEVEL:1
  };

  var PLACEHOLDER_TOKENS = ["changeme","change_me","change-me","change me","example","placeholder",
    "your-secret","your_secret","yoursecret","replace-me","replace_me","replaceme","dummy",
    "xxxxxxxx","123456","letmein","default-secret","dev-secret","test-secret","insecure"];

  function isSecretKey(key){
    return /(SECRET|PASSWORD|PASSWD|PWD|TOKEN|API_KEY|APIKEY|PRIVATE_KEY|ACCESS_KEY)/.test(key) || key === "DATABASE_URL";
  }
  function stripQuotes(v){
    v = v.trim();
    if (v.length >= 2 && ((v.charAt(0)==='"' && v.charAt(v.length-1)==='"') || (v.charAt(0)==="'" && v.charAt(v.length-1)==="'"))) {
      v = v.slice(1,-1);
    }
    return v.trim();
  }
  function parseConfig(text){
    var entries = {};   // KEY -> {value, line}
    var order = [];
    var lines = String(text == null ? "" : text).split(/\r\n|\r|\n/);
    for (var i = 0; i < lines.length; i++){
      var raw = lines[i];
      var line = raw.trim();
      if (!line) continue;
      if (line.charAt(0) === "#" || line.indexOf("//") === 0) continue;
      if (line.indexOf("- ") === 0) line = line.slice(2).trim();
      if (line.indexOf("export ") === 0) line = line.slice(7).trim();
      var m = line.match(/^([A-Za-z_][A-Za-z0-9_.\-]*)\s*[:=]\s*(.*)$/);
      if (!m) continue;
      var key = m[1].toUpperCase();
      var value = stripQuotes(m[2] || "");
      // Drop a trailing inline comment on unquoted values.
      var hashAt = value.indexOf(" #");
      if (hashAt > 0) value = value.slice(0, hashAt).trim();
      if (!entries[key]) order.push(key);
      entries[key] = { value: value, line: i + 1 };
    }
    return { entries: entries, order: order, totalLines: lines.length };
  }
  function boolVal(v){
    if (v == null) return null;
    var s = String(v).trim().toLowerCase();
    if (s === "true" || s === "1" || s === "yes" || s === "on") return true;
    if (s === "false" || s === "0" || s === "no" || s === "off") return false;
    return null;
  }
  function hasPlaceholder(v){
    var s = String(v).toLowerCase();
    for (var i = 0; i < PLACEHOLDER_TOKENS.length; i++){
      if (s.indexOf(PLACEHOLDER_TOKENS[i]) !== -1) return true;
    }
    return false;
  }

  function audit(text){
    var parsed = parseConfig(text);
    var entries = parsed.entries;
    var recognized = 0;
    parsed.order.forEach(function(k){ if (KNOWN[k]) recognized++; });
    var result = {
      verdict: "NOT ENOUGH TO GRADE",
      gradable: false,
      totalLines: parsed.totalLines,
      keysFound: parsed.order.length,
      keysRecognized: recognized,
      findings: []
    };
    if (!String(text || "").trim() || recognized === 0){
      return result;
    }
    result.gradable = true;
    var F = result.findings;
    function add(line, key, severity, title, detail, fix, valueLength){
      F.push({ line: (typeof line === "number" ? line : null), key: key, severity: severity,
        title: title, detail: detail, fix: fix,
        valueLength: (typeof valueLength === "number" ? valueLength : null) });
    }
    function get(k){ return entries[k] || null; }

    // --- WEBUI_SECRET_KEY ---
    var sk = get("WEBUI_SECRET_KEY");
    if (!sk){
      add(null, "WEBUI_SECRET_KEY", "critical",
        "WEBUI_SECRET_KEY is missing",
        "No WEBUI_SECRET_KEY appears anywhere in this config. Open WebUI signs sessions with this key; without one set by you, sessions rest on a default or regenerated value and logins can break or be forged across restarts.",
        "Set WEBUI_SECRET_KEY to a long random value (32+ characters) from a password generator or secret manager, keep it out of source control, and reuse the same value across restarts and replicas.");
    } else if (sk.value.length === 0){
      add(sk.line, "WEBUI_SECRET_KEY", "critical",
        "WEBUI_SECRET_KEY is set but empty",
        "The key is present on line " + sk.line + " with a value length of 0. An empty session secret is no secret at all.",
        "Give WEBUI_SECRET_KEY a long random value (32+ characters) and load it from your secret store, not from a committed file.", 0);
    } else if (hasPlaceholder(sk.value)){
      add(sk.line, "WEBUI_SECRET_KEY", "critical",
        "WEBUI_SECRET_KEY looks like a placeholder or example value",
        "The value on line " + sk.line + " (length " + sk.value.length + ") matches a known placeholder pattern. Placeholder secrets are public knowledge — anyone who has seen the docs has seen this value. The value itself is never shown in this report.",
        "Replace it with a freshly generated random secret of 32+ characters that has never appeared in documentation, a repo, or a chat message.", sk.value.length);
    } else if (sk.value.length < 16){
      add(sk.line, "WEBUI_SECRET_KEY", "critical",
        "WEBUI_SECRET_KEY is critically short",
        "The value on line " + sk.line + " is only " + sk.value.length + " characters long. A secret that short can be brute-forced, and whoever cracks it can forge session cookies for any account, including admins. The value itself is never shown in this report.",
        "Regenerate WEBUI_SECRET_KEY at 32+ random characters (48 is better) and rotate it anywhere the short value was ever used.", sk.value.length);
    } else if (sk.value.length < 32){
      add(sk.line, "WEBUI_SECRET_KEY", "high",
        "WEBUI_SECRET_KEY is shorter than 32 characters",
        "The value on line " + sk.line + " is " + sk.value.length + " characters long. That is below the 32-character floor for a session-signing secret. The value itself is never shown in this report.",
        "Regenerate WEBUI_SECRET_KEY at 32+ random characters and store it in a secret manager.", sk.value.length);
    }

    // --- Auth switch ---
    var auth = get("WEBUI_AUTH");
    if (auth && boolVal(auth.value) === false){
      add(auth.line, "WEBUI_AUTH", "critical",
        "Authentication is disabled (WEBUI_AUTH=false)",
        "With WEBUI_AUTH off, Open WebUI serves without its login gate. Anyone who can reach the port can use the app — and on many setups the first session effectively acts with full access.",
        "Set WEBUI_AUTH=true and put a real identity path in front of it (built-in accounts with signup closed, or OAuth/OIDC). Only disable auth on a box that is unreachable from any network you do not fully control.");
    }

    // --- Signup + default role ---
    var signup = get("ENABLE_SIGNUP");
    var role = get("DEFAULT_USER_ROLE");
    var roleVal = role ? String(role.value).trim().toLowerCase() : null;
    if (signup && boolVal(signup.value) === true){
      if (role && roleVal === "admin"){
        add(role.line, "DEFAULT_USER_ROLE", "critical",
          "Open signup hands every new account the admin role",
          "ENABLE_SIGNUP is on (line " + signup.line + ") and DEFAULT_USER_ROLE is admin (line " + role.line + "). Anyone on the internet can register and immediately own the instance: users, models, connections, and settings.",
          "Turn ENABLE_SIGNUP off once your real accounts exist. If signup must stay open, set DEFAULT_USER_ROLE to user (or pending with manual approval) — never admin.");
      } else if (role && roleVal === "pending"){
        add(role.line, "DEFAULT_USER_ROLE", "high",
          "Open signup with pending accounts invites abuse",
          "ENABLE_SIGNUP is on (line " + signup.line + ") and new accounts land as pending (line " + role.line + "). Pending is safer than admin, but an open form still invites spam registrations, approval-queue flooding, and social-engineering attempts on whoever approves accounts.",
          "Close signup (ENABLE_SIGNUP=false) if the user list is known. If it must stay open, keep the pending role, approve by hand, and put rate limiting or a reverse proxy in front of the signup route.");
      } else if (role && roleVal === "user"){
        add(signup.line, "ENABLE_SIGNUP", "medium",
          "Public signup is open",
          "ENABLE_SIGNUP is on (line " + signup.line + ") with the standard user role. Anyone can create a working account and consume your model budget and storage.",
          "Turn ENABLE_SIGNUP off if the audience is known. If it stays on, watch new-account growth and set per-user limits.");
      } else if (!role){
        add(signup.line, "ENABLE_SIGNUP", "medium",
          "Public signup is open and no default role is pinned",
          "ENABLE_SIGNUP is on (line " + signup.line + ") and DEFAULT_USER_ROLE does not appear in this config, so new accounts take whatever the build defaults to — which has changed across versions.",
          "Set DEFAULT_USER_ROLE explicitly to user or pending, or turn ENABLE_SIGNUP off entirely.");
      }
    } else if (role && roleVal === "admin" && (!signup || boolVal(signup.value) !== false)){
      add(role.line, "DEFAULT_USER_ROLE", "medium",
        "Default user role is admin",
        "DEFAULT_USER_ROLE is admin (line " + role.line + "). If signup is ever switched on — by you, a co-admin, or a config slip — every new account becomes an admin.",
        "Set DEFAULT_USER_ROLE to user and promote real admins by hand.");
    }

    // --- Public URL scheme ---
    var url = get("WEBUI_URL");
    if (url && /^http:\/\//i.test(url.value) && !/localhost|127\.0\.0\.1|\[::1\]/i.test(url.value)){
      add(url.line, "WEBUI_URL", "high",
        "WEBUI_URL uses plain http",
        "The public URL on line " + url.line + " starts with http://. Login traffic, session cookies, and chat content tied to that origin cross the network unencrypted, and OAuth redirects built on it inherit the weakness.",
        "Serve Open WebUI over https (a reverse proxy with a real certificate is the usual route) and set WEBUI_URL to the https address.");
    }

    // --- CORS ---
    var cors = get("CORS_ALLOW_ORIGIN");
    if (cors && cors.value.indexOf("*") !== -1){
      add(cors.line, "CORS_ALLOW_ORIGIN", "high",
        "CORS allows every origin (wildcard)",
        "CORS_ALLOW_ORIGIN on line " + cors.line + " contains a wildcard, so any website a logged-in user visits can script requests toward your instance's API from their browser.",
        "Replace the wildcard with the exact origin(s) that legitimately embed or call the app — usually just your own WEBUI_URL origin — or leave CORS unset if nothing cross-origin needs access.");
    }

    // --- Model access bypass ---
    var bypass = get("BYPASS_MODEL_ACCESS_CONTROL");
    if (bypass && boolVal(bypass.value) === true){
      add(bypass.line, "BYPASS_MODEL_ACCESS_CONTROL", "critical",
        "Model access control is bypassed",
        "BYPASS_MODEL_ACCESS_CONTROL is on (line " + bypass.line + "). Per-model and per-user access restrictions stop applying, so every signed-in user can reach every configured model and connection.",
        "Set BYPASS_MODEL_ACCESS_CONTROL=false and grant model access per user or group instead.");
    }

    // --- Admin export ---
    var admExp = get("ENABLE_ADMIN_EXPORT");
    if (admExp && boolVal(admExp.value) === true){
      add(admExp.line, "ENABLE_ADMIN_EXPORT", "high",
        "Admin data export is enabled",
        "ENABLE_ADMIN_EXPORT is on (line " + admExp.line + "). A single admin session — legitimate or hijacked — can bulk-export instance data, including chat content, in one action.",
        "Set ENABLE_ADMIN_EXPORT=false unless you have a scheduled, reviewed need for exports, and turn it back off when the export is done.");
    }

    // --- RAG web search ---
    var rag = get("ENABLE_RAG_WEB_SEARCH");
    if (rag && boolVal(rag.value) === true){
      add(rag.line, "ENABLE_RAG_WEB_SEARCH", "medium",
        "RAG web search is enabled",
        "ENABLE_RAG_WEB_SEARCH is on (line " + rag.line + "). The server fetches arbitrary web content into chats, which widens the SSRF and prompt-injection surface and can pull internal or malicious pages into model context.",
        "Leave ENABLE_RAG_WEB_SEARCH off unless users genuinely need live web results; if it stays on, restrict outbound traffic at the network layer and treat fetched pages as untrusted input.");
    }

    // --- OAuth signup without a secret in the paste ---
    var oauthSignup = get("ENABLE_OAUTH_SIGNUP");
    var oauthSecretPresent = !!(get("OAUTH_CLIENT_SECRET") || get("GOOGLE_OAUTH_CLIENT_SECRET") ||
      get("MICROSOFT_OAUTH_CLIENT_SECRET") || get("GITHUB_OAUTH_CLIENT_SECRET") || get("OPENID_CLIENT_SECRET"));
    if (oauthSignup && boolVal(oauthSignup.value) === true && !oauthSecretPresent){
      add(oauthSignup.line, "ENABLE_OAUTH_SIGNUP", "medium",
        "OAuth signup is on but no OAuth client secret appears in this config",
        "ENABLE_OAUTH_SIGNUP is on (line " + oauthSignup.line + "), yet no OAuth client secret key appears anywhere in the paste. Either the secret lives somewhere this audit cannot see, or OAuth is half-configured and will fail — or fall back — in ways you have not reviewed.",
        "Confirm the OAuth client secret is set in the real deployment (this audit only grades what was pasted), or turn ENABLE_OAUTH_SIGNUP off.");
    }

    // --- Database URL embedded credentials ---
    var db = get("DATABASE_URL");
    if (db && db.value){
      var m = db.value.match(/^[a-z][a-z0-9+.-]*:\/\/([^/:@]+):([^@]*)@/i);
      if (m){
        var pwLen = m[2].length;
        if (pwLen < 16){
          add(db.line, "DATABASE_URL", "high",
            "Database password embedded in DATABASE_URL is short",
            "DATABASE_URL on line " + db.line + " carries an embedded password of only " + pwLen + " characters (length only — the password is never shown here). Anyone who reads this config file owns the database.",
            "Use a database password of 20+ random characters, load DATABASE_URL from a secret manager instead of a committed file, and rotate the current password since it has lived in plain text.", db.value.length);
        } else {
          add(db.line, "DATABASE_URL", "medium",
            "Database credentials are embedded in DATABASE_URL",
            "DATABASE_URL on line " + db.line + " carries its password inside the URL (value length " + db.value.length + "; the password itself is never shown here). Anyone who can read the config — a repo, a backup, a screenshot — has the database credentials.",
            "Load DATABASE_URL from a secret manager or an untracked env file with tight permissions, and rotate the password if this config was ever shared.", db.value.length);
        }
      }
    }

    // --- Redis URL without auth / plaintext ---
    var redisUrl = get("REDIS_URL");
    if (redisUrl && redisUrl.value){
      var hasCred = /:\/\/[^/@]+@/.test(redisUrl.value);
      var isLocal = /localhost|127\.0\.0\.1|\[::1\]/i.test(redisUrl.value);
      if (!hasCred && !isLocal){
        add(redisUrl.line, "REDIS_URL", "medium",
          "Redis URL carries no password",
          "REDIS_URL on line " + redisUrl.line + " points at a non-local host with no embedded credentials. An unauthenticated Redis on a reachable network is a well-known takeover path.",
          "Require a Redis password (requirepass / ACL), or bind Redis to localhost or a private network only, and pass the credential through REDIS_URL or REDIS_PASSWORD from your secret store.");
      } else if (/^redis:\/\//i.test(redisUrl.value) && !isLocal){
        add(redisUrl.line, "REDIS_URL", "medium",
          "Redis traffic is unencrypted (redis://)",
          "REDIS_URL on line " + redisUrl.line + " uses the plaintext redis:// scheme toward a non-local host, so session data and the Redis password cross the network in the clear.",
          "Use rediss:// (TLS) for any Redis that is not on the same private network, or tunnel the connection.");
      }
    }

    // --- Generic secret strength (one finding per secret key) ---
    parsed.order.forEach(function(key){
      if (key === "WEBUI_SECRET_KEY" || key === "DATABASE_URL") return;
      if (!isSecretKey(key)) return;
      var e = entries[key];
      if (!e) return;
      if (e.value.length === 0){
        add(e.line, key, "high", key + " is set but empty",
          "The secret on line " + e.line + " has a value length of 0. The integration it protects will fail open, fail closed in a confusing way, or fall back to a default — none of which you chose on purpose.",
          "Set " + key + " to its real value from your secret manager, or remove the line entirely if the integration is unused.", 0);
      } else if (hasPlaceholder(e.value)){
        add(e.line, key, "high", key + " looks like a placeholder value",
          "The value on line " + e.line + " (length " + e.value.length + ") matches a known placeholder pattern. Placeholder secrets are public knowledge. The value itself is never shown in this report.",
          "Replace " + key + " with the real, freshly issued secret and store it in a secret manager, not in the config file.", e.value.length);
      } else if (e.value.length < 16){
        add(e.line, key, "high", key + " is short (" + e.value.length + " characters)",
          "The secret on line " + e.line + " is only " + e.value.length + " characters long (length only — the value is never shown here). Short secrets get guessed, and this one sits in plain text in the config.",
          "Rotate " + key + " to a long random value (20+ characters where the provider allows it) and load it from a secret manager.", e.value.length);
      } else if (e.value.length < 20){
        add(e.line, key, "medium", key + " is on the short side (" + e.value.length + " characters)",
          "The secret on line " + e.line + " is " + e.value.length + " characters long (length only — the value is never shown here). That is below the 20-character comfort floor for a credential stored in plain text.",
          "When " + key + " next rotates, issue a longer value (20+ random characters) and keep it in a secret manager.", e.value.length);
      }
    });

    // --- Bind address ---
    ["HOST","WEBUI_HOST"].forEach(function(k){
      var h = get(k);
      if (h && /^(0\.0\.0\.0|::|\[::\]|\*)$/.test(h.value.trim())){
        add(h.line, k, "high",
          "Service binds to every network interface (" + k + ")",
          k + " on line " + h.line + " binds the app to all interfaces. Combined with any auth or signup weakness above, the instance is reachable from every network the host touches — including the public internet if the box has a public address or a forwarded port.",
          "Bind to 127.0.0.1 and publish through a hardened reverse proxy, or bind only the specific private interface you intend — and make sure a firewall backs up the choice.");
      }
    });

    // Sort: line ascending, missing-line findings first, then severity weight.
    var w = { critical: 0, high: 1, medium: 2, low: 3 };
    F.sort(function(a, b){
      var la = a.line == null ? -1 : a.line, lb = b.line == null ? -1 : b.line;
      if (la !== lb) return la - lb;
      return w[a.severity] - w[b.severity];
    });

    var hasCrit = F.some(function(f){ return f.severity === "critical"; });
    var hasHighOrMed = F.some(function(f){ return f.severity === "high" || f.severity === "medium"; });
    result.verdict = hasCrit ? "DO NOT DEPLOY" : (hasHighOrMed ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY");
    return result;
  }

  function esc(s){
    return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
  }
  function counts(F){
    var c = { critical: 0, high: 0, medium: 0, low: 0 };
    F.forEach(function(f){ c[f.severity] = (c[f.severity] || 0) + 1; });
    return c;
  }
  function buildReport(r){
    var lines = [];
    lines.push("J-Dawgs Open WebUI Server Config Safety Auditor - Audit Report");
    lines.push("================================================================");
    lines.push("Verdict: " + r.verdict);
    lines.push("Generated: " + new Date().toLocaleString());
    lines.push("Lines scanned: " + r.totalLines + " | Keys found: " + r.keysFound + " | Open WebUI keys recognized: " + r.keysRecognized);
    lines.push("");
    if (!r.gradable){
      lines.push("This paste does not look like an Open WebUI configuration, so there is");
      lines.push("nothing to grade. Paste KEY=value lines for an Open WebUI deployment");
      lines.push("(WEBUI_SECRET_KEY, WEBUI_AUTH, ENABLE_SIGNUP, WEBUI_URL, and friends)");
      lines.push("and run the audit again.");
    } else if (r.findings.length === 0){
      lines.push("Findings: none. No rule fired on this config.");
      lines.push("That is a clean first pass, not a guarantee: this is a heuristic text");
      lines.push("audit of pasted config only. It does not connect to a server, verify");
      lines.push("signatures, or replace a live security review.");
    } else {
      var c = counts(r.findings);
      lines.push("Findings: " + r.findings.length + " (" + c.critical + " critical, " + c.high + " high, " + c.medium + " medium, " + c.low + " low)");
      lines.push("");
      r.findings.forEach(function(f, i){
        lines.push("----------------------------------------------------------------");
        lines.push((i + 1) + ". [" + f.severity.toUpperCase() + "] " + (f.line == null ? "Line: not present" : "Line " + f.line) + " | Key: " + f.key + (f.valueLength != null ? " | Value length: " + f.valueLength : ""));
        lines.push("    " + f.title);
        lines.push("    Detail: " + f.detail);
        lines.push("    Fix: " + f.fix);
      });
      lines.push("----------------------------------------------------------------");
      lines.push("");
      lines.push("Reminder: this is a heuristic text audit of pasted config only. It does");
      lines.push("not connect to a server, verify signatures, or replace a live security review.");
    }
    lines.push("");
    lines.push("Secret handling: findings report key name, line number, and length only.");
    lines.push("Secret values from the paste never appear in this report or the JSON export.");
    return lines.join("\n");
  }
  function buildJSON(r){
    return JSON.stringify({
      tool: "J-Dawgs Open WebUI Server Config Safety Auditor",
      version: 1,
      generatedAt: new Date().toISOString(),
      verdict: r.verdict,
      gradable: r.gradable,
      stats: { linesScanned: r.totalLines, keysFound: r.keysFound, keysRecognized: r.keysRecognized,
        findingCounts: counts(r.findings) },
      findings: r.findings.map(function(f){
        return { line: f.line, key: f.key, severity: f.severity, title: f.title,
          detail: f.detail, fix: f.fix, valueLength: f.valueLength };
      }),
      secretHandling: "Findings carry key name, line number, and value length only. Secret values are never included."
    }, null, 2);
  }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-open-webui-server-config-safety-auditortm',
  name: 'J-Dawgs Open WebUI Server Config Safety Auditor',
  description: 'Grades a pasted Open WebUI environment configuration fully offline into one deploy verdict — signup and default-role posture, API and provider keys, external web access, and plaintext secrets shown by key name, line, and length only. Open WebUI only exercises its config by starting the server; this ',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
