'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs GitLab CI Pipeline Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

    "use strict";

    /* ---------------- Example configs (fake values only) ---------------- */

    var RISKY = [
      "# Worked example — every value below is fake.",
      "include:",
      "  - remote: 'https://templates.example.net/shared-pipeline.yml'",
      "  - project: 'platform/shared-ci'",
      "    file: '/templates/deploy.yml'",
      "",
      "stages:",
      "  - build",
      "  - test",
      "  - deploy",
      "",
      "variables:",
      '  CI_DEBUG_TRACE: "true"',
      '  DEPLOY_TOKEN: "fake-token-1234567890"',
      "",
      "build_app:",
      "  stage: build",
      "  image: node:latest",
      "  script:",
      "    - curl -fsSL https://get.example.net/install.sh | sh",
      "    - echo \"token is $DEPLOY_TOKEN\"",
      "  artifacts:",
      "    paths:",
      "      - .env",
      "      - .",
      "",
      "deploy_prod:",
      "  stage: deploy",
      "  image: alpine",
      "  allow_failure: true",
      "  script:",
      "    - apk add curl",
      "    - ./deploy.sh production"
    ].join("\n");

    var CLEAN = [
      "# Worked example — a config that should pass clean.",
      "include:",
      "  - local: '/templates/base.yml'",
      "  - project: 'platform/shared-ci'",
      "    ref: 'v2.4.0'",
      "    file: '/templates/deploy.yml'",
      "",
      "stages:",
      "  - build",
      "  - test",
      "  - deploy",
      "",
      "variables:",
      '  CI_DEBUG_TRACE: "false"',
      "",
      "build_app:",
      "  stage: build",
      "  image: node:20.11.1-alpine@sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
      "  cache:",
      "    key:",
      "      files:",
      "        - package-lock.json",
      "    paths:",
      "      - node_modules/",
      "  rules:",
      "    - if: $CI_COMMIT_BRANCH",
      "  script:",
      "    - npm ci",
      "  artifacts:",
      "    paths:",
      "      - dist/",
      "    expire_in: 1 week",
      "",
      "deploy_prod:",
      "  stage: deploy",
      "  image: alpine:3.19.1",
      "  environment:",
      "    name: production",
      "  rules:",
      "    - if: $CI_COMMIT_BRANCH == $CI_DEFAULT_BRANCH",
      "      when: manual",
      "  script:",
      "    - ./deploy.sh production"
    ].join("\n");

    /* ---------------- Heuristic line parser ---------------- */

    var RESERVED = { stages: 1, variables: 1, include: 1, cache: 1, "default": 1, image: 1, services: 1, workflow: 1, before_script: 1, after_script: 1 };
    var SECRET_RE = /(SECRET|TOKEN|PASSWORD|PASSWD|API_?KEY|PRIVATE_?KEY|ACCESS_?KEY|CREDENTIAL|AUTH|BEARER)/i;

    function indentOf(s) { var m = s.match(/^ */); return m ? m[0].length : 0; }
    function stripQuotes(v) {
      v = String(v).trim();
      if (v.length >= 2 && ((v.charAt(0) === '"' && v.charAt(v.length - 1) === '"') || (v.charAt(0) === "'" && v.charAt(v.length - 1) === "'"))) {
        v = v.slice(1, -1);
      }
      return v;
    }
    function redactValue(v) {
      if (!v) return "(empty value)";
      return '"' + v.slice(0, 2) + '…" (' + v.length + " characters — value never printed in full)";
    }
    function hostOf(u) {
      var m = String(u).match(/^https?:\/\/([^\/:?#]+)/i);
      return m ? m[1] : "(host could not be read from the URL)";
    }

    /* block: array of {raw, no}. Returns child lines of the key at block[idx]. */
    function subBlock(block, idx) {
      var ki = indentOf(block[idx].raw), out = [], k, r;
      for (k = idx + 1; k < block.length; k++) {
        r = block[k].raw;
        if (!r.trim() || r.trim().charAt(0) === "#") continue;
        if (indentOf(r) <= ki) break;
        out.push(block[k]);
      }
      return out;
    }
    function findKeys(block, name) {
      var out = [], re = new RegExp("^" + name + "\\s*:");
      block.forEach(function (l, i) { if (re.test(l.raw.trim())) out.push(i); });
      return out;
    }
    function keyValue(raw, name) {
      var m = raw.trim().match(new RegExp("^" + name + "\\s*:\\s*(.*)$"));
      return m ? m[1] : null;
    }
    function varNamesIn(text) {
      var names = [], m, re = /\$\{?([A-Za-z_][A-Za-z0-9_]*)\}?/g;
      while ((m = re.exec(text)) !== null) names.push(m[1]);
      return names;
    }

    function checkImage(value, job, lineNo, F) {
      var v = stripQuotes(String(value).split(/\s+/)[0] || "");
      if (!v) return;
      if (v.charAt(0) === "$") {
        F.push({ sev: "INFO", job: job, line: lineNo, title: "Image comes from a variable (" + v + ")",
          detail: "The image reference is set from a CI variable, so its pinning cannot be graded from the config text.",
          fix: "Make sure the variable resolves to a digest-pinned image (name@sha256:…) wherever it is set." });
        return;
      }
      if (v.indexOf("@sha256:") !== -1) return; /* digest pinned — good */
      var lastSlash = v.lastIndexOf("/"), lastColon = v.lastIndexOf(":");
      if (lastColon > lastSlash) {
        if (v.slice(lastColon + 1) === "latest") {
          F.push({ sev: "WARNING", job: job, line: lineNo, title: "Image uses the :latest tag (" + v + ")",
            detail: ":latest is a moving target — the same pipeline can build on different images from one run to the next, and a compromised or broken upstream tag lands silently.",
            fix: "Pin an exact version tag (e.g. " + v.slice(0, lastColon) + ":20.11.1) or, better, a digest: " + v.slice(0, lastColon) + "@sha256:<digest>." });
        }
      } else {
        F.push({ sev: "WARNING", job: job, line: lineNo, title: "Image has no tag (" + v + ")",
          detail: "An untagged image reference means :latest is implied — a moving target that can change under the same pipeline without any edit to this file.",
          fix: "Pin an exact version tag or a digest: " + v + "@sha256:<digest>." });
      }
    }

    function checkVariablesBlock(children, job, F) {
      children.forEach(function (l) {
        var m = l.raw.trim().match(/^([A-Za-z_][A-Za-z0-9_]*)\s*:\s*(.*)$/);
        if (!m) return;
        var key = m[1], val = stripQuotes(m[2].replace(/\s+#.*$/, ""));
        if (key === "CI_DEBUG_TRACE") {
          if (/^(true|yes|on|1)$/i.test(val)) {
            F.push({ sev: "BLOCKER", job: job, line: l.no, title: "CI_DEBUG_TRACE is switched on",
              detail: "With CI_DEBUG_TRACE true, GitLab prints full job tracing — every variable value, including masked secrets, can land in the job log for anyone with log access to read.",
              fix: "Remove CI_DEBUG_TRACE (or set it to \"false\") and rotate any secret that ever ran under it." });
          }
          return;
        }
        if (SECRET_RE.test(key) && val && val.charAt(0) !== "$") {
          F.push({ sev: "WARNING", job: job, line: l.no, title: "Secret-shaped variable " + key + " is set to a literal value in the config",
            detail: "The value is committed to the repository in plain text: " + redactValue(val) + ". Anyone who can read the repo owns this credential.",
            fix: "Delete the value from the YAML, set " + key + " under Settings → CI/CD → Variables (masked, and protected if only protected branches use it), and rotate the credential — it is already in git history." });
        }
      });
    }

    function checkScriptLine(cmd, job, lineNo, F) {
      var names = varNamesIn(cmd);
      var secretVars = names.filter(function (n) { return SECRET_RE.test(n); });

      if (/\b(curl|wget)\b/.test(cmd) && /\|\s*(sudo\s+)?(ba|z|da)?sh\b/.test(cmd)) {
        F.push({ sev: "BLOCKER", job: job, line: lineNo, title: "Remote script piped straight into a shell (curl | sh)",
          detail: "This downloads code from the network and executes it in the job, unverified. Whoever controls that URL — or compromises it — runs arbitrary code with your CI variables and job token.",
          fix: "Download the installer, pin and verify its checksum (sha256sum -c), then run it — or install the tool from a pinned package/image instead." });
      }

      if (secretVars.length) {
        var redir = cmd.match(/>>?\s*(\S+)/);
        if (redir) {
          F.push({ sev: "WARNING", job: job, line: lineNo, title: "Secret variable $" + secretVars[0] + " is written to a file (" + redir[1] + ")",
            detail: "Writing a secret to disk inside the job risks it being swept into artifacts, cache, or a later cat/debug step and published. (Flagged by key name only — the value is never shown.)",
            fix: "Avoid materialising the secret as a file; if a tool truly needs a file, write it outside the project directory, chmod 600, and delete it in after_script." });
        } else if (/\becho\b/.test(cmd) || /\bprintf\b/.test(cmd)) {
          F.push({ sev: "WARNING", job: job, line: lineNo, title: "Secret variable $" + secretVars[0] + " is echoed in a script line",
            detail: "Echoing a secret-shaped variable sends it to the job log. Masking usually catches exact matches, but any transformation (encoding, splitting, prefixing) defeats the mask. (Flagged by key name only — the value is never shown.)",
            fix: "Remove the echo. Debug with the variable's name and length only, never its value." });
        }
      }

      if (/\bprintenv\b/.test(cmd) || /^env\s*$/.test(cmd.trim()) || /\|\s*env\b/.test(cmd)) {
        F.push({ sev: "WARNING", job: job, line: lineNo, title: "Script dumps the whole environment (printenv / env)",
          detail: "printenv prints every CI variable at once — the fastest way to leak every secret the job can see into a log or an artifact.",
          fix: "Remove the dump. Print only the specific non-secret variables you need, by name." });
      }

      var mApk = cmd.match(/\bapk\s+add\b(.*)$/);
      if (mApk) {
        var apkPkgs = mApk[1].split(/\s+/).filter(function (t) { return t && t.charAt(0) !== "-" && t !== "&&" && t !== "\\"; });
        var apkUnpinned = apkPkgs.filter(function (t) { return t.indexOf("=") === -1; });
        if (apkPkgs.length && apkUnpinned.length) {
          F.push({ sev: "WARNING", job: job, line: lineNo, title: "Unpinned apk install (" + apkUnpinned.join(", ") + ")",
            detail: "apk add without a version takes whatever the repository serves today — builds stop being reproducible and a bad upstream update lands unreviewed.",
            fix: "Pin versions: apk add " + apkUnpinned[0] + "=<version>, or use a base image that already contains the tool." });
        }
      }
      var mApt = cmd.match(/\bapt(-get)?\s+install\b(.*)$/);
      if (mApt) {
        var aptPkgs = mApt[2].split(/\s+/).filter(function (t) { return t && t.charAt(0) !== "-" && t !== "&&" && t !== "\\"; });
        var aptUnpinned = aptPkgs.filter(function (t) { return t.indexOf("=") === -1; });
        if (aptPkgs.length && aptUnpinned.length) {
          F.push({ sev: "WARNING", job: job, line: lineNo, title: "Unpinned apt install (" + aptUnpinned.join(", ") + ")",
            detail: "apt-get install without =version floats to the newest package in the image's repositories — the same config builds differently over time.",
            fix: "Pin versions: apt-get install " + aptUnpinned[0] + "=<version>, and prefer images that already carry the tool." });
        }
      }
      var mPip = cmd.match(/\bpip3?\s+install\b(.*)$/);
      if (mPip && !/(^|\s)(-r|--requirement)\b/.test(mPip[1])) {
        var pipPkgs = mPip[1].split(/\s+/).filter(function (t) { return t && t.charAt(0) !== "-" && t !== "&&" && t !== "\\"; });
        var pipUnpinned = pipPkgs.filter(function (t) { return t.indexOf("==") === -1; });
        if (pipPkgs.length && pipUnpinned.length) {
          F.push({ sev: "WARNING", job: job, line: lineNo, title: "Unpinned pip install (" + pipUnpinned.join(", ") + ")",
            detail: "pip install without == takes the newest release on PyPI at run time — unreviewed code, straight into a job that holds your CI secrets.",
            fix: "Pin exact versions (pip install " + pipUnpinned[0] + "==<version>) or install from a hashed requirements file (pip install -r requirements.txt --require-hashes)." });
        }
      }
    }

    function scriptLinesOf(sectionLines) {
      var out = [];
      ["script", "before_script", "after_script"].forEach(function (key) {
        findKeys(sectionLines, key).forEach(function (idx) {
          var inline = keyValue(sectionLines[idx].raw, key);
          if (inline && inline !== ">" && inline !== "|" && inline.charAt(0) !== "[") {
            out.push({ cmd: inline, no: sectionLines[idx].no });
            return;
          }
          subBlock(sectionLines, idx).forEach(function (l) {
            var t = l.raw.trim().replace(/^-\s+/, "");
            if (t) out.push({ cmd: t, no: l.no });
          });
        });
      });
      return out;
    }

    function isSensitivePath(p) {
      var v = stripQuotes(String(p).trim());
      if (v === "." || v === "./" || v === "*" || v === "**" || v === "./*") return "the whole repository root";
      if (/(^|\/)\.env(\..*)?$/.test(v)) return "an .env file";
      if (/\.pem$|\.key$|\.p12$|\.pfx$/i.test(v)) return "a private key / certificate file";
      if (/id_rsa|id_ed25519|\.ssh|credentials|\.gnupg/i.test(v)) return "a credential file";
      return null;
    }

    function auditIncludes(section, F) {
      var lines = section.lines.slice(1);
      var rest = stripQuotes(section.rest || "");
      function remoteFinding(url, lineNo) {
        F.push({ sev: "BLOCKER", job: "include", line: lineNo, title: "Remote include from " + hostOf(url),
          detail: "include: remote pulls pipeline configuration from " + hostOf(url) + " over the network and executes it as part of this pipeline. The URL's content can change at any time with no commit, no review, and no merge request in this project.",
          fix: "Vendor the file into this repository (include: local), or move it into a project you control and include it with include: project plus a pinned ref (tag or full commit SHA)." });
      }
      if (/^https?:\/\//i.test(rest)) remoteFinding(rest, section.lineNo);
      if (rest.charAt(0) === "[") {
        var toks = rest.match(/https?:\/\/[^\s\]'"]+/g) || [];
        toks.forEach(function (u) { remoteFinding(u, section.lineNo); });
      }

      var pending = null;
      function flushPending() {
        if (!pending) return;
        if (!pending.ref) {
          F.push({ sev: "WARNING", job: "include", line: pending.line, title: "include: project '" + pending.project + "' has no pinned ref",
            detail: "Without a ref:, GitLab pulls the included file from the other project's default branch HEAD — that project can change this pipeline's behaviour at any time, with no change here.",
            fix: "Add ref: with an immutable pin — a release tag (ref: 'v1.2.0') or a full 40-character commit SHA." });
        } else if (!(/^v?\d+\.\d+(\.\d+)?$/.test(pending.ref) || /^[0-9a-f]{40}$/i.test(pending.ref) || /^v?\d+$/.test(pending.ref))) {
          F.push({ sev: "WARNING", job: "include", line: pending.line, title: "include: project '" + pending.project + "' pins ref '" + pending.ref + "', which looks like a moving branch",
            detail: "A branch name as ref still moves: every push to that branch in '" + pending.project + "' rewrites what this pipeline runs.",
            fix: "Pin ref: to a release tag (ref: 'v1.2.0') or a full 40-character commit SHA instead of a branch name." });
        }
        pending = null;
      }

      lines.forEach(function (l) {
        var t = l.raw.trim();
        var m;
        if ((m = t.match(/remote\s*:\s*['"]?(https?:\/\/[^\s'"]+)/))) { flushPending(); remoteFinding(m[1], l.no); return; }
        if ((m = t.match(/^-\s*['"]?(https?:\/\/[^\s'"]+)/))) { flushPending(); remoteFinding(m[1], l.no); return; }
        if ((m = t.match(/project\s*:\s*['"]?([^\s'"]+)['"]?/))) { flushPending(); pending = { project: m[1], line: l.no, ref: null }; return; }
        if ((m = t.match(/^\s*-?\s*ref\s*:\s*['"]?([^\s'"]+)['"]?/)) && pending) { pending.ref = m[1]; flushPending(); return; }
        if ((m = t.match(/local\s*:\s*['"]?([^\s'"]+)['"]?/))) {
          flushPending();
          F.push({ sev: "INFO", job: "include", line: l.no, title: "Local include: " + m[1],
            detail: "Local includes live in this repository and change only through commits and merge requests — the safest include posture. It is graded on the reference only; this tool cannot see the included file's contents.",
            fix: "No change needed. Keep the included file under the same review rules as the main config." });
          return;
        }
        if ((m = t.match(/template\s*:\s*['"]?([^\s'"]+)['"]?/))) {
          flushPending();
          F.push({ sev: "INFO", job: "include", line: l.no, title: "Template include: " + m[1],
            detail: "GitLab's official templates are maintained upstream and versioned with GitLab itself. Graded on the reference only — the template's contents are not read by this tool.",
            fix: "No change needed. Re-check the template's behaviour at GitLab upgrades." });
          return;
        }
        if (/^-\s/.test(t)) flushPending();
      });
      flushPending();
    }

    function auditCacheBlock(cacheChildren, job, lineNo, isGlobal, F) {
      var keyIdxs = findKeys(cacheChildren, "key");
      if (isGlobal) {
        F.push({ sev: "INFO", job: job, line: lineNo, title: "Top-level cache: is shared by every job",
          detail: "A cache defined at the top level is inherited by all jobs. Cache is not isolated between jobs: a job that can write cache entries can poison what trusted jobs — including deploys — later restore and run.",
          fix: "Scope caches per job where it matters, give deploy jobs their own key, and use policy: pull on jobs that should never write the shared cache." });
      }
      if (!keyIdxs.length) {
        F.push({ sev: "INFO", job: job, line: lineNo, title: "Cache has no key of its own",
          detail: "With no key:, GitLab falls back to a single shared default cache key for every branch and job — builds overwrite each other's cache and any job can poison the one cache everyone restores.",
          fix: "Set a files-based key (key: files: - <lockfile>) so the cache tracks your dependencies, not whichever job ran last." });
        return;
      }
      keyIdxs.forEach(function (ki) {
        var kv = keyValue(cacheChildren[ki].raw, "key") || "";
        if (kv.indexOf("CI_COMMIT_REF_SLUG") !== -1) {
          F.push({ sev: "INFO", job: job, line: cacheChildren[ki].no, title: "Cache key uses $CI_COMMIT_REF_SLUG (one cache per branch)",
            detail: "A ref-slug key gives every branch its own cache: safe from cross-branch poisoning, but each new branch starts cold and caches multiply. A files-based key (key: files: - Gemfile.lock / package-lock.json) instead shares one cache that only changes when your dependencies change — usually the better default for dependency folders like node_modules or vendor.",
            fix: "If this cache holds dependencies, switch to a files-based key over your lockfile; keep the ref-slug key only for caches that genuinely differ per branch." });
        }
      });
    }

    function audit(text) {
      var F = [], NP = [];
      if (!text || !text.trim()) {
        return { error: "Nothing to audit — the input is empty. Paste the full text of a .gitlab-ci.yml.", line: null };
      }
      var rawLines = text.split(/\r?\n/);
      var i, raw;

      for (i = 0; i < rawLines.length; i++) {
        var lead = rawLines[i].match(/^[\s]*/)[0];
        if (lead.indexOf("\t") !== -1) {
          return { error: "Line " + (i + 1) + " is indented with a tab. YAML forbids tab indentation, and GitLab would reject this file — replace the tab with spaces and audit again.", line: i + 1 };
        }
      }

      var lines = rawLines.map(function (r, idx) { return { raw: r, no: idx + 1 }; });

      /* NOT PARSED constructs */
      lines.forEach(function (l) {
        var t = l.raw.trim();
        if (!t || t.charAt(0) === "#") return;
        if (/<<\s*:/.test(t)) NP.push({ line: l.no, what: "YAML merge key (<<:)" });
        if (/!reference\b/.test(t)) NP.push({ line: l.no, what: "GitLab !reference tag" });
        var am = t.match(/:\s+&([A-Za-z0-9_-]+)\b/);
        if (am) NP.push({ line: l.no, what: "YAML anchor (&" + am[1] + ")" });
        var al = t.match(/(?::\s+|-\s+)\*([A-Za-z0-9_-]+)\s*$/);
        if (al && !/<<\s*:/.test(t)) NP.push({ line: l.no, what: "YAML alias (*" + al[1] + ")" });
      });

      /* Top-level structure */
      var tops = [];
      for (i = 0; i < lines.length; i++) {
        raw = lines[i].raw;
        if (!raw.trim() || raw.trim().charAt(0) === "#" || indentOf(raw) !== 0) continue;
        var m = raw.match(/^([A-Za-z0-9_.][A-Za-z0-9_.\-\/]*)\s*:\s*(.*)$/);
        if (!m) {
          if (/^-\s/.test(raw)) {
            return { error: "Line " + (i + 1) + " starts a top-level list. A .gitlab-ci.yml is a mapping of jobs and settings, not a list — this does not parse as a GitLab CI config.", line: i + 1 };
          }
          return { error: "Line " + (i + 1) + " is not a recognisable YAML key line: \"" + raw.trim().slice(0, 80) + "\". The audit stopped here rather than guess at the structure.", line: i + 1 };
        }
        tops.push({ key: m[1], rest: m[2], lineNo: lines[i].no, idx: i });
      }
      if (!tops.length) {
        return { error: "No top-level keys were found — this does not look like a .gitlab-ci.yml file.", line: null };
      }
      tops.forEach(function (tp, k) {
        var end = (k + 1 < tops.length) ? tops[k + 1].idx : lines.length;
        tp.lines = lines.slice(tp.idx, end);
        if ((tp.rest || "").charAt(0) === "{") NP.push({ line: tp.lineNo, what: "Flow-style mapping on '" + tp.key + "'" });
      });

      var jobs = tops.filter(function (tp) { return !RESERVED[tp.key] && tp.key.charAt(0) !== "."; });

      /* Global sections */
      tops.forEach(function (tp) {
        if (tp.key === "include") auditIncludes(tp, F);
        if (tp.key === "variables") checkVariablesBlock(tp.lines.slice(1), "(global variables)", F);
        if (tp.key === "image") checkImage(tp.rest || "", "(global default image)", tp.lineNo, F);
        if (tp.key === "cache") auditCacheBlock(tp.lines.slice(1), "(global cache)", tp.lineNo, true, F);
        if (tp.key === "services" || tp.key === "default") auditImagesAndServices(tp.lines, "(" + tp.key + ")", F);
        if (tp.key === "before_script" || tp.key === "after_script") {
          tp.lines.slice(1).forEach(function (l) {
            var c = l.raw.trim().replace(/^-\s+/, "");
            if (c) checkScriptLine(c, "(global " + tp.key + ")", l.no, F);
          });
        }
      });

      /* Per-job checks */
      var anyGating = jobs.some(function (j) {
        return findKeys(j.lines, "rules").length || findKeys(j.lines, "only").length || findKeys(j.lines, "except").length;
      });

      jobs.forEach(function (job) {
        var L = job.lines, name = job.key;

        auditImagesAndServices(L, name, F);

        findKeys(L, "variables").forEach(function (vi) {
          checkVariablesBlock(subBlock(L, vi), name, F);
        });

        scriptLinesOf(L).forEach(function (s) { checkScriptLine(s.cmd, name, s.no, F); });

        /* artifacts */
        findKeys(L, "artifacts").forEach(function (ai) {
          var sub = subBlock(L, ai);
          var hasExpire = sub.some(function (l) { return /^expire_in\s*:/.test(l.raw.trim()); });
          var sensitive = [];
          findKeys(sub, "paths").forEach(function (pi) {
            var inline = keyValue(sub[pi].raw, "paths");
            if (inline && inline.charAt(0) === "[") {
              inline.replace(/[\[\]]/g, "").split(",").forEach(function (p) {
                var why = isSensitivePath(p);
                if (why) sensitive.push({ path: stripQuotes(p), why: why, line: sub[pi].no });
              });
            }
            subBlock(sub, pi).forEach(function (l) {
              var t = l.raw.trim();
              if (t.charAt(0) !== "-") return;
              var p = stripQuotes(t.replace(/^-\s+/, ""));
              var why = isSensitivePath(p);
              if (why) sensitive.push({ path: p, why: why, line: l.no });
            });
          });
          sensitive.forEach(function (s) {
            F.push({ sev: "BLOCKER", job: name, line: s.line, title: "Artifacts publish " + s.why + " (" + s.path + ")",
              detail: "artifacts: paths uploads this from the job workspace to GitLab, where it can be downloaded from the job page by anyone with project access — and it outlives the job. Publishing " + s.why + " hands it to every future viewer of this pipeline.",
              fix: "Remove \"" + s.path + "\" from artifacts: paths. If a downstream job truly needs it, pass only the specific built files it needs — never a secrets file, never the repo root." });
          });
          if (sensitive.length && !hasExpire) {
            F.push({ sev: "WARNING", job: name, line: L[ai].no, title: "Sensitive artifacts have no expire_in",
              detail: "These artifacts expose sensitive paths and carry no expire_in, so GitLab keeps the latest artifacts indefinitely instead of letting them lapse.",
              fix: "Add expire_in (for example expire_in: 1 day) to this artifacts: block — or better, stop publishing the sensitive paths at all." });
          }
        });

        /* cache per job */
        findKeys(L, "cache").forEach(function (ci) {
          auditCacheBlock(subBlock(L, ci), name, L[ci].no, false, F);
        });

        /* deploy gating */
        var stageVal = null, envName = null, hasEnv = false;
        findKeys(L, "stage").forEach(function (si) { stageVal = stripQuotes(keyValue(L[si].raw, "stage") || ""); });
        findKeys(L, "environment").forEach(function (ei) {
          hasEnv = true;
          var ev = keyValue(L[ei].raw, "environment");
          if (ev) envName = stripQuotes(ev);
          subBlock(L, ei).forEach(function (l) {
            var nm = l.raw.trim().match(/^name\s*:\s*(.*)$/);
            if (nm) envName = stripQuotes(nm[1]);
          });
        });
        var blockText = L.map(function (l) { return l.raw; }).join("\n");
        var hasManual = /when\s*:\s*manual/.test(blockText);
        var isDeploy = /deploy|prod/i.test(name) || stageVal === "deploy" || /prod/i.test(envName || "");
        findKeys(L, "allow_failure").forEach(function (fi) {
          var fv = stripQuotes(keyValue(L[fi].raw, "allow_failure") || "");
          if (/^true$/i.test(fv) && isDeploy) {
            F.push({ sev: "BLOCKER", job: name, line: L[fi].no, title: "Deploy job has allow_failure: true",
              detail: "A production deploy that is allowed to fail lets the pipeline go green while the deploy silently did not happen — or half-happened. The next release then builds on a production state nobody verified.",
              fix: "Remove allow_failure (or set it to false) on the deploy job so a failed deploy fails the pipeline and a human looks at it." });
          }
        });
        if (isDeploy && !hasEnv && !hasManual) {
          F.push({ sev: "WARNING", job: name, line: job.lineNo, title: "Deploy job has no environment: and no manual gate",
            detail: "Nothing ties this job to a named environment (so no deployment history, no protected-environment rules, no approval flow) and nothing makes a human press play — it can run automatically on any pipeline that reaches it.",
            fix: "Add environment: name: production (and protect that environment in GitLab), and/or gate the job with rules: - when: manual on the default branch." });
        }

        /* rules trap */
        if (anyGating && !findKeys(L, "rules").length && !findKeys(L, "only").length && !findKeys(L, "except").length) {
          F.push({ sev: "INFO", job: name, line: job.lineNo, title: "Job has no rules: or only:/except: while other jobs in this file do",
            detail: "Other jobs in this config gate themselves; this one does not, so it runs on every pipeline — every branch, tag, schedule, and merge request — whether or not its work is needed there.",
            fix: "If that always-on behaviour is intended, leave it. Otherwise add rules: (or only:/except:) matching the pipelines this job should actually run in." });
        }
      });

      var counts = { BLOCKER: 0, WARNING: 0, INFO: 0 };
      F.forEach(function (f) { counts[f.sev]++; });
      var verdict = counts.BLOCKER > 0 ? "DO NOT SHIP" : (counts.WARNING > 0 ? "SHIP WITH FIXES" : "SAFE TO SHIP");
      var order = { BLOCKER: 0, WARNING: 1, INFO: 2 };
      F.sort(function (a, b) { return (order[a.sev] - order[b.sev]) || (a.line - b.line); });
      return { error: null, verdict: verdict, counts: counts, findings: F, notParsed: NP };
    }

    function auditImagesAndServices(L, jobLabel, F) {
      findKeys(L, "image").forEach(function (ii) {
        var v = keyValue(L[ii].raw, "image");
        if (v) { checkImage(v, jobLabel, L[ii].no, F); return; }
        subBlock(L, ii).forEach(function (l) {
          var nm = l.raw.trim().match(/^name\s*:\s*(.+)$/);
          if (nm) checkImage(nm[1], jobLabel, l.no, F);
        });
      });
      findKeys(L, "services").forEach(function (si) {
        subBlock(L, si).forEach(function (l) {
          var t = l.raw.trim();
          if (t.charAt(0) === "-") {
            var v = t.replace(/^-\s+/, "");
            if (/^[\w.\/:@$-]+$/.test(v)) checkImage(v, jobLabel + " (service)", l.no, F);
          }
          var nm = t.match(/^name\s*:\s*(.+)$/);
          if (nm) checkImage(nm[1], jobLabel + " (service)", l.no, F);
        });
      });
    }

    /* ---------------- Rendering ---------------- */

    var lastReportText = "";
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-gitlab-ci-pipeline-safety-auditor',
  name: 'J-Dawgs GitLab CI Pipeline Safety Auditor',
  description: 'GitLab\'s CI linter needs a live project and stops at validity; ours audits a pasted .gitlab-ci.yml anywhere — remote includes, CI_DEBUG_TRACE, artifact exposure of .env, deploy allow_failure gating, curl|sh — into one ship verdict (SAFE TO SHIP / SHIP WITH FIXES / DO NOT SHIP).',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
