'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Wedding Vendor Proposal, Contract & Final Invoice Consistency Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";
/* ---------- helpers ---------- */
function $(id){return document.getElementById(id);}
function parseMoney(s){ if(s==null) return null; var v=parseFloat(String(s).replace(/[$,]/g,"")); return isNaN(v)?null:v; }
function fmt(n){ if(n==null||isNaN(n)) return "—"; var neg=n<0; var a=Math.abs(n); var s=a.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g,","); return (neg?"-$":"$")+s; }
function fmtNum(n){ return (Math.round(n*100)/100).toString().replace(/\B(?=(\d{3})+(?!\d))/g,","); }
function lines(t){ return String(t||"").split(/\r?\n/); }
function firstMoneyIn(text){ var m=String(text).match(/\$\s?[\d,]+(?:\.\d{1,2})?/); return m?parseMoney(m[0]):null; }
function moneyAfter(labelRe, text){
  var ls=lines(text), i, m;
  for(i=0;i<ls.length;i++){ if(labelRe.test(ls[i])){ m=ls[i].match(/\$\s?[\d,]+(?:\.\d{1,2})?/); if(m) return parseMoney(m[0]); } }
  return null;
}
function pctAfter(labelRe, text){
  var ls=lines(text), i, m;
  for(i=0;i<ls.length;i++){ if(labelRe.test(ls[i])){ m=ls[i].match(/(\d+(?:\.\d+)?)\s*%/); if(m) return parseFloat(m[1]); } }
  return null;
}
function findDate(text){
  var m=String(text).match(/\b(January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2},\s*\d{4}\b/i)
      || String(text).match(/\b\d{1,2}\/\d{1,2}\/\d{4}\b/);
  return m?m[0].replace(/\s+/g," "):null;
}
function findTimes(text){
  var all=String(text).match(/\b\d{1,2}:\d{2}\s*(?:AM|PM|am|pm)\b/g)||[];
  var out=[], seen={}, i;
  for(i=0;i<all.length;i++){ var t=all[i].toUpperCase().replace(/\s+/g," "); if(!seen[t]){seen[t]=1;out.push(t);} }
  return out;
}
function findHours(text){
  var m=String(text).match(/(\d+(?:\.\d+)?)\s*hours?\s*(?:of\s+)?(?:coverage|service|photography|music|staffing)?/i);
  if(m) return parseFloat(m[1]);
  m=String(text).match(/(\d+(?:\.\d+)?)\s*hours?/i);
  return m?parseFloat(m[1]):null;
}
function findGuests(text){
  var m=String(text).match(/(\d[\d,]*)\s*(?:guests|people|persons|attendees)/i);
  return m?parseInt(m[1].replace(/,/g,""),10):null;
}
function findPerGuest(text){
  var ls=lines(text), i, m;
  for(i=0;i<ls.length;i++){ if(/per\s*(guest|person|head)|each guest/i.test(ls[i])){ m=ls[i].match(/\$\s?[\d,]+(?:\.\d{1,2})?/); if(m) return parseMoney(m[0]); } }
  return null;
}
function findPerHour(text){
  var ls=lines(text), i, m;
  for(i=0;i<ls.length;i++){ if(/per\s*hour|hourly/i.test(ls[i])){ m=ls[i].match(/\$\s?[\d,]+(?:\.\d{1,2})?/); if(m) return parseMoney(m[0]); } }
  return null;
}
function termSentences(text, re){
  var ls=lines(text), out=[], i;
  for(i=0;i<ls.length;i++){ var L=ls[i].trim(); if(L && re.test(L)) out.push(L); }
  return out;
}
function lineItems(text){
  var ls=lines(text), out=[], i, m;
  for(i=0;i<ls.length;i++){
    var L=ls[i].trim(); if(!L) continue;
    if(/^(total|grand total|amount due|balance due|subtotal|deposit|tax)\b/i.test(L)) continue;
    m=L.match(/\$\s?([\d,]+(?:\.\d{1,2})?)\s*$/);
    if(m){ var label=L.replace(/\$\s?[\d,]+(?:\.\d{1,2})?\s*$/,"").replace(/[—–\-:·•]+\s*$/,"").trim(); out.push({label:label||L, amount:parseMoney(m[1]), raw:L}); }
  }
  return out;
}
function normKey(s){ return String(s||"").toLowerCase().replace(/[^a-z0-9 ]/g," ").replace(/\s+/g," ").trim(); }
function keyWords(s){ var stop={the:1,a:1,an:1,of:1,and:1,for:1,with:1,per:1,each:1,x:1}; return normKey(s).split(" ").filter(function(w){return w.length>2 && !stop[w] && isNaN(parseFloat(w));}); }
function matchesItem(label, poolText){
  /* Strict: EVERY distinctive word of the label must appear in the pool.
     A loose half-match let "Service charge" pass on the word "service"
     alone (from "hours of service") and "Travel fee" on the word "fee"
     alone (from "carries no fee") — exactly the fees this tool exists to catch. */
  var kw=keyWords(label); if(!kw.length) return true;
  var pool=normKey(poolText), i;
  for(i=0;i<kw.length;i++){ if(pool.indexOf(kw[i])<0) return false; }
  return true;
}

/* ---------- extraction ---------- */
function extract(text){
  var t=String(text||"");
  var d={ present:t.trim().length>0, text:t };
  d.total = moneyAfter(/total|package price|contract price|quote/i, t);
  if(d.total==null) d.total = firstMoneyIn(t);
  d.deposit = moneyAfter(/deposit/i, t);
  d.depositPct = pctAfter(/deposit/i, t);
  d.balance = moneyAfter(/balance/i, t);
  d.guests = findGuests(t);
  d.perGuest = findPerGuest(t);
  d.perHour = findPerHour(t);
  d.hours = findHours(t);
  d.date = findDate(t);
  d.times = findTimes(t);
  d.items = lineItems(t);
  d.taxLines = termSentences(t, /tax/i);
  d.cancelLines = termSentences(t, /cancel|postpon/i);
  return d;
}

/* ---------- audit ---------- */
var DOCNAMES={proposal:"Proposal / Quote", contract:"Contract", invoice:"Final Invoice"};
var lastResult=null;

function audit(){
  var raw={ proposal:$("docProposal").value, contract:$("docContract").value, invoice:$("docInvoice").value };
  var d={ proposal:extract(raw.proposal), contract:extract(raw.contract), invoice:extract(raw.invoice) };
  var findings=[]; // {level: crit|warn|ok|info, title, detail, arith}
  function add(level,title,detail,arith){ findings.push({level:level,title:title,detail:detail,arith:arith||""}); }

  var presentKeys=Object.keys(d).filter(function(k){return d[k].present;});
  var missingKeys=Object.keys(d).filter(function(k){return !d[k].present;});

  if(presentKeys.length<2){
    add("info","Not enough documents to cross-check","Documents provided: "+(presentKeys.length? presentKeys.map(function(k){return DOCNAMES[k];}).join(", "):"none")+". A cross-check needs at least two of the three documents; all three are needed for a SAFE TO PAY verdict.","");
    return finish("NOT ENOUGH TO COMPARE","Provide at least the proposal and the final invoice — all three documents for a full check.",d,findings,missingKeys);
  }
  if(missingKeys.length){
    add("warn","Missing document caps the verdict at PAY WITH FIXES","Missing: "+missingKeys.map(function(k){return DOCNAMES[k];}).join(", ")+". The remaining documents were cross-checked against each other, but no verdict above PAY WITH FIXES is possible without all three.","");
  }

  /* Totals across documents */
  var totalsPresent=["proposal","contract","invoice"].filter(function(k){return d[k].present && d[k].total!=null;});
  ["proposal","contract","invoice"].forEach(function(k){ if(d[k].present && d[k].total==null) add("warn","No total price stated in the "+DOCNAMES[k],"The "+DOCNAMES[k]+" paste contains no recognisable total figure, so its total could not be compared. Nothing was guessed.",""); });
  if(totalsPresent.length>=2){
    var base=totalsPresent[0], i;
    for(i=1;i<totalsPresent.length;i++){
      var k=totalsPresent[i], diff=d[k].total-d[base].total;
      if(Math.abs(diff)>0.005){
        add("crit","Total price differs: "+DOCNAMES[base]+" vs "+DOCNAMES[k],
          "The "+DOCNAMES[base]+" states "+fmt(d[base].total)+" and the "+DOCNAMES[k]+" states "+fmt(d[k].total)+".",
          fmt(d[k].total)+" − "+fmt(d[base].total)+" = "+fmt(diff));
      } else {
        add("ok","Total price agrees: "+DOCNAMES[base]+" vs "+DOCNAMES[k],"Both state "+fmt(d[base].total)+".", fmt(d[k].total)+" − "+fmt(d[base].total)+" = $0.00");
      }
    }
  }

  /* Invoice line items sum vs stated invoice total */
  if(d.invoice.present && d.invoice.items.length && d.invoice.total!=null){
    var sum=0, parts=[];
    d.invoice.items.forEach(function(it){ sum+=it.amount; parts.push(fmt(it.amount)); });
    var sdiff=d.invoice.total-sum;
    if(Math.abs(sdiff)>0.005){
      add("crit","Invoice line items do not add up to the stated invoice total",
        "Adding the invoice's own line items gives "+fmt(sum)+", but the invoice states a total of "+fmt(d.invoice.total)+".",
        parts.join(" + ")+" = "+fmt(sum)+"\n"+fmt(d.invoice.total)+" (stated total) − "+fmt(sum)+" (line-item sum) = "+fmt(sdiff));
    } else {
      add("ok","Invoice line items add up","The invoice's line items sum exactly to its stated total of "+fmt(d.invoice.total)+".", parts.join(" + ")+" = "+fmt(sum));
    }
  } else if(d.invoice.present && !d.invoice.items.length){
    add("warn","Invoice has no recognisable line items","No lines ending in an amount were found on the invoice paste, so the line-item sum check could not run.","");
  }

  /* Deposit amount + % */
  var depPresent=["proposal","contract","invoice"].filter(function(k){return d[k].present && d[k].deposit!=null;});
  if(depPresent.length>=2){
    var db=depPresent[0];
    for(var di=1; di<depPresent.length; di++){
      var dk=depPresent[di], dd=d[dk].deposit-d[db].deposit;
      if(Math.abs(dd)>0.005) add("crit","Deposit amount differs: "+DOCNAMES[db]+" vs "+DOCNAMES[dk], DOCNAMES[db]+" states a deposit of "+fmt(d[db].deposit)+"; "+DOCNAMES[dk]+" states "+fmt(d[dk].deposit)+".", fmt(d[dk].deposit)+" − "+fmt(d[db].deposit)+" = "+fmt(dd));
      else add("ok","Deposit amount agrees: "+DOCNAMES[db]+" vs "+DOCNAMES[dk],"Both state "+fmt(d[db].deposit)+".", fmt(d[dk].deposit)+" − "+fmt(d[db].deposit)+" = $0.00");
    }
  }
  ["proposal","contract"].forEach(function(k){
    if(d[k].present && d[k].deposit!=null && d[k].total!=null && d[k].depositPct!=null){
      var implied=d[k].deposit/d[k].total*100, pdiff=implied-d[k].depositPct;
      if(Math.abs(pdiff)>1) add("warn","Deposit % does not match the deposit amount in the "+DOCNAMES[k],
        "The "+DOCNAMES[k]+" states a deposit of "+fmt(d[k].deposit)+" on a total of "+fmt(d[k].total)+" and calls it "+d[k].depositPct+"%.",
        fmt(d[k].deposit)+" ÷ "+fmt(d[k].total)+" × 100 = "+implied.toFixed(1)+"% (stated: "+d[k].depositPct+"%)");
      else add("ok","Deposit % checks out in the "+DOCNAMES[k], fmt(d[k].deposit)+" on "+fmt(d[k].total)+" is "+implied.toFixed(1)+"%, matching the stated "+d[k].depositPct+"%.", fmt(d[k].deposit)+" ÷ "+fmt(d[k].total)+" × 100 = "+implied.toFixed(1)+"%");
    } else if(d[k].present && d[k].deposit!=null && d[k].depositPct==null){
      add("info","Deposit % not stated in the "+DOCNAMES[k],"A deposit of "+fmt(d[k].deposit)+" is stated with no percentage, so the percentage could not be cross-checked.","");
    }
  });

  /* Balance due: total − deposit vs stated balance */
  ["proposal","contract","invoice"].forEach(function(k){
    if(d[k].present && d[k].total!=null && d[k].deposit!=null && d[k].balance!=null){
      var expect=d[k].total-d[k].deposit, bd=d[k].balance-expect;
      if(Math.abs(bd)>0.005) add("crit","Balance due does not follow from total − deposit in the "+DOCNAMES[k],
        "The "+DOCNAMES[k]+" states total "+fmt(d[k].total)+", deposit "+fmt(d[k].deposit)+", and balance due "+fmt(d[k].balance)+".",
        fmt(d[k].total)+" − "+fmt(d[k].deposit)+" = "+fmt(expect)+" expected balance\n"+fmt(d[k].balance)+" (stated) − "+fmt(expect)+" = "+fmt(bd));
      else add("ok","Balance due checks out in the "+DOCNAMES[k], fmt(d[k].total)+" − "+fmt(d[k].deposit)+" = "+fmt(expect)+", matching the stated balance.", fmt(d[k].total)+" − "+fmt(d[k].deposit)+" = "+fmt(expect));
    }
  });
  /* Cross-document balance: invoice balance vs contract total − deposit paid */
  if(d.invoice.present && d.invoice.balance!=null && d.contract.present && d.contract.total!=null){
    var paidDep = d.invoice.deposit!=null? d.invoice.deposit : (d.contract.deposit!=null? d.contract.deposit : null);
    if(paidDep!=null){
      var expB=d.contract.total-paidDep, xb=d.invoice.balance-expB;
      if(Math.abs(xb)>0.005) add("crit","Invoice balance due does not match the contract",
        "Contract total "+fmt(d.contract.total)+" minus deposit "+fmt(paidDep)+" leaves "+fmt(expB)+", but the invoice asks for a balance of "+fmt(d.invoice.balance)+".",
        fmt(d.contract.total)+" − "+fmt(paidDep)+" = "+fmt(expB)+"\n"+fmt(d.invoice.balance)+" (invoice balance) − "+fmt(expB)+" = "+fmt(xb));
      else add("ok","Invoice balance due matches the contract","Contract total minus deposit equals the invoice balance of "+fmt(d.invoice.balance)+".", fmt(d.contract.total)+" − "+fmt(paidDep)+" = "+fmt(expB));
    }
  }

  /* Guests × per-guest rate recomputed */
  ["proposal","contract","invoice"].forEach(function(k){
    if(d[k].present && d[k].guests!=null && d[k].perGuest!=null){
      var prod=d[k].guests*d[k].perGuest;
      add("info","Per-guest math in the "+DOCNAMES[k]+" (recomputed, not trusted)",
        "Stated: "+fmtNum(d[k].guests)+" guests × "+fmt(d[k].perGuest)+" per guest.",
        fmtNum(d[k].guests)+" × "+fmt(d[k].perGuest)+" = "+fmt(prod)+(d[k].total!=null? "\nDocument total stated: "+fmt(d[k].total)+" (the per-guest product covers only the per-guest portion — other lines may make up the rest)":""));
    }
  });
  var guestDocs=["proposal","contract","invoice"].filter(function(k){return d[k].present && d[k].guests!=null;});
  if(guestDocs.length>=2){
    var gb=guestDocs[0];
    for(var gi=1; gi<guestDocs.length; gi++){
      var gk=guestDocs[gi];
      if(d[gk].guests!==d[gb].guests){
        var rate=d[gk].perGuest||d[gb].perGuest;
        add("crit","Guest count differs: "+DOCNAMES[gb]+" vs "+DOCNAMES[gk],
          DOCNAMES[gb]+" states "+fmtNum(d[gb].guests)+" guests; "+DOCNAMES[gk]+" states "+fmtNum(d[gk].guests)+" guests."+(rate? " At "+fmt(rate)+" per guest that headcount gap alone is worth "+fmt(Math.abs(d[gk].guests-d[gb].guests)*rate)+".":""),
          fmtNum(d[gk].guests)+" − "+fmtNum(d[gb].guests)+" = "+fmtNum(d[gk].guests-d[gb].guests)+" guests"+(rate? "\n"+fmtNum(Math.abs(d[gk].guests-d[gb].guests))+" × "+fmt(rate)+" = "+fmt(Math.abs(d[gk].guests-d[gb].guests)*rate):""));
      } else add("ok","Guest count agrees: "+DOCNAMES[gb]+" vs "+DOCNAMES[gk],"Both state "+fmtNum(d[gb].guests)+" guests.","");
    }
  }
  var rateDocs=["proposal","contract","invoice"].filter(function(k){return d[k].present && d[k].perGuest!=null;});
  if(rateDocs.length>=2){
    var rb=rateDocs[0];
    for(var ri=1; ri<rateDocs.length; ri++){
      var rk=rateDocs[ri], rd=d[rk].perGuest-d[rb].perGuest;
      if(Math.abs(rd)>0.005) add("crit","Per-guest rate differs: "+DOCNAMES[rb]+" vs "+DOCNAMES[rk], DOCNAMES[rb]+" states "+fmt(d[rb].perGuest)+" per guest; "+DOCNAMES[rk]+" states "+fmt(d[rk].perGuest)+".", fmt(d[rk].perGuest)+" − "+fmt(d[rb].perGuest)+" = "+fmt(rd));
    }
  }
  var hourDocs=["proposal","contract","invoice"].filter(function(k){return d[k].present && d[k].perHour!=null;});
  ["proposal","contract","invoice"].forEach(function(k){
    if(d[k].present && d[k].hours!=null && d[k].perHour!=null){
      add("info","Per-hour math in the "+DOCNAMES[k]+" (recomputed)", "Stated: "+d[k].hours+" hours × "+fmt(d[k].perHour)+" per hour.", d[k].hours+" × "+fmt(d[k].perHour)+" = "+fmt(d[k].hours*d[k].perHour));
    }
  });
  if(hourDocs.length>=2){
    var hb=hourDocs[0];
    for(var hi=1; hi<hourDocs.length; hi++){
      var hk=hourDocs[hi], hd=d[hk].perHour-d[hb].perHour;
      if(Math.abs(hd)>0.005) add("crit","Per-hour rate differs: "+DOCNAMES[hb]+" vs "+DOCNAMES[hk], DOCNAMES[hb]+" states "+fmt(d[hb].perHour)+" per hour; "+DOCNAMES[hk]+" states "+fmt(d[hk].perHour)+".", fmt(d[hk].perHour)+" − "+fmt(d[hb].perHour)+" = "+fmt(hd));
    }
  }

  /* Hours of coverage */
  var hoursDocs=["proposal","contract","invoice"].filter(function(k){return d[k].present && d[k].hours!=null;});
  if(hoursDocs.length>=2){
    var hob=hoursDocs[0];
    for(var hoi=1; hoi<hoursDocs.length; hoi++){
      var hok=hoursDocs[hoi];
      if(d[hok].hours!==d[hob].hours) add("crit","Hours of coverage differ: "+DOCNAMES[hob]+" vs "+DOCNAMES[hok], DOCNAMES[hob]+" states "+d[hob].hours+" hours; "+DOCNAMES[hok]+" states "+d[hok].hours+" hours.", d[hok].hours+" − "+d[hob].hours+" = "+(d[hok].hours-d[hob].hours)+" hours");
      else add("ok","Hours of coverage agree: "+DOCNAMES[hob]+" vs "+DOCNAMES[hok],"Both state "+d[hob].hours+" hours.","");
    }
  }

  /* Date */
  var dateDocs=["proposal","contract","invoice"].filter(function(k){return d[k].present && d[k].date;});
  ["proposal","contract","invoice"].forEach(function(k){ if(d[k].present && !d[k].date) add("warn","No event date found in the "+DOCNAMES[k],"No date in a recognisable format appears in the "+DOCNAMES[k]+" paste, so its date could not be compared.",""); });
  if(dateDocs.length>=2){
    var dab=dateDocs[0];
    for(var dai=1; dai<dateDocs.length; dai++){
      var dak=dateDocs[dai];
      if(normKey(d[dak].date)!==normKey(d[dab].date)) add("crit","Event date differs: "+DOCNAMES[dab]+" vs "+DOCNAMES[dak], DOCNAMES[dab]+" states "+d[dab].date+"; "+DOCNAMES[dak]+" states "+d[dak].date+".","");
      else add("ok","Event date agrees: "+DOCNAMES[dab]+" vs "+DOCNAMES[dak],"Both state "+d[dab].date+".","");
    }
  }

  /* Times */
  ["proposal","contract","invoice"].forEach(function(k){
    if(!d[k].present) return;
    ["proposal","contract"].forEach(function(o){});
    if(k!=="invoice"){
      /* compare against each other below */
    }
  });
  if(d.proposal.present && d.contract.present && d.proposal.times.length && d.contract.times.length){
    var sameT = d.proposal.times.join("|")===d.contract.times.join("|");
    if(!sameT) add("warn","Start/end times differ between Proposal and Contract","Proposal times found: "+d.proposal.times.join(", ")+". Contract times found: "+d.contract.times.join(", ")+".","");
    else add("ok","Start/end times agree between Proposal and Contract","Both show: "+d.proposal.times.join(", ")+".","");
  }
  if(d.invoice.present && d.contract.present && d.invoice.times.length && d.contract.times.length){
    var extraT=d.invoice.times.filter(function(t){return d.contract.times.indexOf(t)<0;});
    if(extraT.length) add("warn","Invoice shows times not in the Contract","Invoice-only times: "+extraT.join(", ")+". Contract times: "+d.contract.times.join(", ")+". If the invoice bills time outside the contracted window, that is where an overtime difference usually hides.","");
  }

  /* Invoice-only fees: named lines on the invoice whose keywords appear in neither proposal nor contract */
  if(d.invoice.present && d.invoice.items.length && (d.proposal.present||d.contract.present)){
    var priorText=((d.proposal.present?d.proposal.text:"")+" "+(d.contract.present?d.contract.text:""));
    var feeTotal=0, feeCount=0;
    d.invoice.items.forEach(function(it){
      if(!matchesItem(it.label, priorText)){
        feeCount++; feeTotal+=it.amount;
        add("crit","Invoice-only charge — in neither the Proposal nor the Contract: “"+it.label+"”",
          "This line appears on the final invoice but its wording matches nothing promised in the proposal or agreed in the contract. Amount billed: "+fmt(it.amount)+".",
          fmt(it.amount)+" billed with $0.00 in the proposal/contract for this item → unexplained "+fmt(it.amount));
      }
    });
    if(feeCount) add("crit","Invoice-only charges total "+fmt(feeTotal), feeCount+" invoice line(s) have no counterpart in the proposal or contract.", "Sum of invoice-only lines = "+fmt(feeTotal));
    else add("ok","No invoice-only charges","Every invoice line's wording matches something in the proposal or contract.","");
  }

  /* Promised in proposal/contract but not billed / not on invoice */
  if(d.invoice.present && d.proposal.present){
    d.proposal.items.forEach(function(it){
      var onInvoice=d.invoice.items.some(function(iv){ return matchesItem(it.label, iv.label) || matchesItem(iv.label, it.label); });
      var kwHit=matchesItem(it.label, d.invoice.text);
      if(!onInvoice && !kwHit) add("warn","Promised in the Proposal but not found on the Invoice: “"+it.label+"”","The proposal lists this at "+fmt(it.amount)+"; no matching line or wording appears on the final invoice. Either it was delivered and not billed, or it was dropped — confirm which before paying.","");
    });
  }

  /* Tax treatment as stated */
  ["proposal","contract","invoice"].forEach(function(k){
    if(d[k].present && d[k].taxLines.length) add("info","Tax treatment as stated — "+DOCNAMES[k],"“"+d[k].taxLines.join(" · ")+"”","");
    else if(d[k].present) add("warn","Tax treatment not stated in the "+DOCNAMES[k],"No sentence mentioning tax was found in the "+DOCNAMES[k]+" paste. What the paste does not say was not assumed.","");
  });
  var taxDocs=["proposal","contract","invoice"].filter(function(k){return d[k].present && d[k].taxLines.length;});
  if(taxDocs.length>=2){
    var tb=normKey(d[taxDocs[0]].taxLines.join(" "));
    for(var ti=1; ti<taxDocs.length; ti++){
      if(normKey(d[taxDocs[ti]].taxLines.join(" "))!==tb) add("warn","Tax wording differs between documents","Compare the quoted tax sentences above word for word — e.g. “tax included” in one document and “plus tax” in another changes what the total should be. The amounts were not adjusted; the wording difference is flagged as stated.","");
    }
  }

  /* Cancellation / postponement terms as stated */
  ["proposal","contract","invoice"].forEach(function(k){
    if(d[k].present && d[k].cancelLines.length) add("info","Cancellation / postponement terms as stated — "+DOCNAMES[k],"“"+d[k].cancelLines.join(" · ")+"”","");
  });
  if(d.contract.present && !d.contract.cancelLines.length) add("warn","No cancellation/postponement terms found in the Contract","No sentence mentioning cancellation or postponement was found in the contract paste. That absence is reported, not filled in.","");
  if(d.proposal.present && d.contract.present && d.proposal.cancelLines.length && d.contract.cancelLines.length){
    if(normKey(d.proposal.cancelLines.join(" "))!==normKey(d.contract.cancelLines.join(" "))) add("warn","Cancellation/postponement wording differs between Proposal and Contract","Both state terms (quoted above) but not in the same words. Read both before relying on either — this tool flags the difference; it does not interpret which wording governs.","");
    else add("ok","Cancellation/postponement terms match between Proposal and Contract","Identical wording in both documents.","");
  }

  /* Verdict */
  var hasCrit=findings.some(function(f){return f.level==="crit";});
  var hasWarn=findings.some(function(f){return f.level==="warn";});
  var verdict, why;
  if(hasCrit){ verdict="DO NOT PAY YET"; why="At least one money, date, or billed-item difference above needs the vendor's answer in writing before the balance moves."; }
  else if(hasWarn || missingKeys.length){ verdict="PAY WITH FIXES"; why= missingKeys.length? "Capped at PAY WITH FIXES because the "+missingKeys.map(function(k){return DOCNAMES[k];}).join(", ")+" is missing. Fix the flagged items, then pay." : "No blocking money difference was found, but the flagged items should be fixed or confirmed in writing first."; }
  else { verdict="SAFE TO PAY"; why="Every figure that could be compared agrees across the documents provided, and the invoice's own lines add up to its stated total."; }
  return finish(verdict, why, d, findings, missingKeys);
}

function finish(verdict, why, d, findings, missingKeys){
  var keys=["proposal","contract","invoice"];
  var summary=keys.map(function(k){
    return { doc:DOCNAMES[k], provided:d[k].present, total:d[k].total, deposit:d[k].deposit, depositPct:d[k].depositPct, balance:d[k].balance, guests:d[k].guests, perGuest:d[k].perGuest, perHour:d[k].perHour, hours:d[k].hours, date:d[k].date, times:d[k].times };
  });
  var result={ tool:"J-Dawgs Wedding Vendor Proposal, Contract & Final Invoice Consistency Auditor™", verdict:verdict, verdictReason:why, missingDocuments:missingKeys.map(function(k){return DOCNAMES[k];}), summary:summary, findings:findings, note:"Text cross-check only. Verifies no booking or vendor. Not legal or financial advice. Figures are compared exactly as stated in the pasted text; nothing was fabricated." };
  lastResult=result;
  render(result);
  return result;
}

function esc(s){ return String(s==null?"":s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"); }

function render(r){
  var box=$("verdictBox");
  var cls = r.verdict==="SAFE TO PAY" ? "safe" : r.verdict==="PAY WITH FIXES" ? "fixes" : r.verdict==="DO NOT PAY YET" ? "donot" : "notenough";
  box.className="verdict "+cls;
  box.innerHTML='<span class="v">'+esc(r.verdict)+'</span><p style="margin:.35rem 0 0">'+esc(r.verdictReason)+'</p>';

  var html='<table><tr><th>Figure (as stated)</th><th>Proposal / Quote</th><th>Contract</th><th>Final Invoice</th></tr>';
  function row(label, fn){ html+="<tr><td><strong>"+label+"</strong></td>"+r.summary.map(function(s){return "<td>"+fn(s)+"</td>";}).join("")+"</tr>"; }
  function money(v){ return v==null?'<span class="small">not stated</span>':'<span class="num">'+fmt(v)+"</span>"; }
  row("Provided", function(s){ return s.provided? "Yes":"<strong>Missing</strong>"; });
  row("Total price", function(s){ return money(s.total); });
  row("Deposit", function(s){ return money(s.deposit); });
  row("Deposit %", function(s){ return s.depositPct==null?'<span class="small">not stated</span>':'<span class="num">'+s.depositPct+"%</span>"; });
  row("Balance due", function(s){ return money(s.balance); });
  row("Guest count", function(s){ return s.guests==null?'<span class="small">not stated</span>':'<span class="num">'+fmtNum(s.guests)+"</span>"; });
  row("Per-guest rate", function(s){ return money(s.perGuest); });
  row("Per-hour rate", function(s){ return money(s.perHour); });
  row("Hours of coverage", function(s){ return s.hours==null?'<span class="small">not stated</span>':'<span class="num">'+s.hours+"</span>"; });
  row("Event date", function(s){ return s.date? esc(s.date):'<span class="small">not stated</span>'; });
  row("Times found", function(s){ return s.times&&s.times.length? esc(s.times.join(", ")):'<span class="small">none found</span>'; });
  html+="</table>";
  $("summaryTable").innerHTML=html;

  if(!r.findings.length){ $("findings").innerHTML='<p class="small">No findings.</p>'; }
  else{
    $("findings").innerHTML=r.findings.map(function(f){
      var tagCls=f.level==="crit"?"crit":f.level==="warn"?"warn":f.level==="ok"?"ok":"info";
      var tagTxt=f.level==="crit"?"Blocks payment":f.level==="warn"?"Fix / confirm":f.level==="ok"?"Agrees":"As stated";
      return '<div class="finding"><span class="tag '+tagCls+'">'+tagTxt+'</span><div><strong>'+esc(f.title)+'</strong></div><div>'+esc(f.detail)+'</div>'+(f.arith? '<div class="arith">'+esc(f.arith)+"</div>":"")+"</div>";
    }).join("");
  }

  var lines=[];
  lines.push("WEDDING VENDOR CONSISTENCY AUDIT — J-Dawgs Consistency Auditor™");
  lines.push("VERDICT: "+r.verdict);
  lines.push(r.verdictReason);
  if(r.missingDocuments.length) lines.push("Missing documents: "+r.missingDocuments.join(", "));
  lines.push("");
  lines.push("FIGURES AS STATED:");
  r.summary.forEach(function(s){
    lines.push("- "+s.doc+": "+(s.provided? ("total "+(s.total==null?"not stated":fmt(s.total))+", deposit "+(s.deposit==null?"not stated":fmt(s.deposit))+(s.depositPct!=null?" ("+s.depositPct+"%)":"")+", balance "+(s.balance==null?"not stated":fmt(s.balance))+", guests "+(s.guests==null?"not stated":s.guests)+", hours "+(s.hours==null?"not stated":s.hours)+", date "+(s.date||"not stated")) : "NOT PROVIDED"));
  });
  lines.push("");
  lines.push("FINDINGS:");
  r.findings.forEach(function(f,i){
    lines.push((i+1)+". ["+f.level.toUpperCase()+"] "+f.title);
    lines.push("   "+f.detail);
    if(f.arith) lines.push("   Arithmetic: "+f.arith.replace(/\n/g," | "));
  });
  lines.push("");
  lines.push("Text cross-check only. Verifies no booking or vendor. Not legal or financial advice. Figures compared exactly as stated; nothing fabricated.");
  $("reportText").textContent=lines.join("\n");
  $("jsonText").textContent=JSON.stringify(r,null,2);
}

/* ---------- clipboard with selectable-text fallback ---------- */
function copyFrom(el, statusEl, okMsg){
  var text=el.textContent;
  function done(ok){ statusEl.textContent = ok? okMsg : "Clipboard was blocked — the text above is selectable: tap/click it, select all, and copy manually."; if(!ok){ selectNode(el); } }
  if(navigator.clipboard && navigator.clipboard.writeText){
    navigator.clipboard.writeText(text).then(function(){done(true);}, function(){ fallbackCopy(text, el, done); });
  } else fallbackCopy(text, el, done);
}
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-wedding-vendor-consistency-auditor',
  name: 'J-Dawgs Wedding Vendor Proposal, Contract & Final Invoice Consistency Auditor',
  description: 'Every vendor system grades its own document in isolation; ours cross-checks a wedding vendor\'s proposal, contract, and final invoice against each other — totals, deposit percentage, guest-count × rate, coverage hours, and invoice-only fees, with the arithmetic shown — into one pay verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
