'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Mautic Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

var RISKY = [
"MAUTIC_SITE_URL=http://mail.example.com",
"MAUTIC_SECRET_KEY=changeme123",
"MAUTIC_DB_HOST=localhost",
"MAUTIC_DB_NAME=mautic",
"MAUTIC_DB_USER=mautic",
"MAUTIC_DB_PASSWORD=password123",
"MAUTIC_MAILER_PASSWORD=letmein",
"MAUTIC_TRUSTED_HOSTS=",
"MAUTIC_DEBUG=1",
"MAUTIC_ENV=dev"
].join("\n");

var HARDENED = [
"MAUTIC_SITE_URL=https://marketing.acme-mail.com",
"MAUTIC_SECRET_KEY=${VAULT_MAUTIC_SECRET_KEY}",
"MAUTIC_DB_HOST=db.internal",
"MAUTIC_DB_PORT=3306",
"MAUTIC_DB_NAME=mautic_prod",
"MAUTIC_DB_USER=mautic_app",
"MAUTIC_DB_PASSWORD=${VAULT_DB_PASSWORD}",
"MAUTIC_TRUSTED_HOSTS=marketing.acme-mail.com",
"MAUTIC_MAILER_TRANSPORT=smtp",
"MAUTIC_MAILER_HOST=smtp.acme-mail.com",
"MAUTIC_MAILER_PORT=587",
"MAUTIC_MAILER_ENCRYPTION=tls",
"MAUTIC_MAILER_USER=mailer@acme-mail.com",
"MAUTIC_MAILER_PASSWORD=${VAULT_MAILER_PASSWORD}",
"MAUTIC_DEBUG=0",
"MAUTIC_ENV=prod"
].join("\n");

var PLANTED = ["changeme123","password123","letmein"];

var EXAMPLE_WORDS = ["changeme","change-me","change_me","change me","example","your_","your-","your ","password","passwd","letmein","123456","12345","placeholder","replace_me","replaceme","todo","default","secret123","qwerty","sample","demo123","test123"];

var KNOWN = {};
["secret_key","secret","db_driver","db_host","db_port","db_name","db_user","db_password","db_table_prefix","db_path",
 "site_url","trusted_hosts","trusted_proxies","mailer_from_name","mailer_from_email","mailer_transport","mailer_host",
 "mailer_port","mailer_user","mailer_password","mailer_encryption","mailer_auth_mode","mailer_api_key",
 "locale","default_locale","default_timezone","debug","app_debug","kernel_debug","env","app_env","environment",
 "transifex","image_path","upload_dir","session_path"].forEach(function(k){ KNOWN[k]=true; });

function normKey(raw){
  var k = raw.toLowerCase();
  if(k.indexOf("mautic_")===0) k = k.substring(7);
  return k;
}
function isRecognizable(raw, norm){
  if(KNOWN[norm]) return true;
  var up = raw.toUpperCase();
  if(up.indexOf("MAUTIC_")===0) return true;
  if(norm.indexOf("mailer_")===0 || norm.indexOf("db_")===0) return true;
  return false;
}
function isReference(v){
  if(!v) return false;
  var s = v.replace(/\s+/g,"");
  return s.indexOf("${")===0 || s.indexOf("%env(")===0 || /^env\(/i.test(s) || /^vault:/i.test(s) || /^secret:/i.test(s) || s.indexOf("{{")===0;
}
function isExampleValue(v){
  var s = v.toLowerCase();
  for(var i=0;i<EXAMPLE_WORDS.length;i++){ if(s.indexOf(EXAMPLE_WORDS[i])>=0) return true; }
  return false;
}
function truthy(v){
  var s = String(v).toLowerCase().replace(/\s+/g,"");
  return s==="true"||s==="1"||s==="on"||s==="yes";
}
function stripQuotes(s){
  s = s.replace(/^\s+/,"").replace(/\s+$/,"");
  if(s.length>=2){
    var a=s.charAt(0), b=s.charAt(s.length-1);
    if((a==='"'&&b==='"')||(a==="'"&&b==="'")) return s.substring(1,s.length-1);
  }
  return s;
}
function parsePhpValue(rawVal){
  var s = rawVal.replace(/,\s*$/,"").replace(/^\s+/,"").replace(/\s+$/,"");
  if(s.charAt(0)==="["){
    var inner = s.replace(/^\[/,"").replace(/\]$/,"");
    var parts = inner.match(/'[^']*'|"[^"]*"/g);
    if(!parts) return inner.replace(/\s+/g,"");
    return parts.map(function(p){ return stripQuotes(p); }).join(",");
  }
  if(/^array\s*\(/i.test(s)){
    var inner2 = s.replace(/^array\s*\(/i,"").replace(/\)$/,"");
    var parts2 = inner2.match(/'[^']*'|"[^"]*"/g);
    if(!parts2) return inner2.replace(/\s+/g,"");
    return parts2.map(function(p){ return stripQuotes(p); }).join(",");
  }
  if(/^(true|false)$/i.test(s)) return s.toLowerCase();
  if(/^null$/i.test(s)) return "";
  return stripQuotes(s);
}
function isStructural(t){
  return t==="<?php"||t==="?>"||t==="return ["||t==="return array("||t==="];"||t===");"||t==="["||t==="];"||t===","||/^'parameters'\s*=>\s*\[$/.test(t)||/^"parameters"\s*=>\s*\[$/.test(t);
}
function parseConfig(text){
  var lines = String(text||"").split(/\r?\n/);
  var entries = [], notParsed = [];
  for(var i=0;i<lines.length;i++){
    var lineNo = i+1;
    var t = lines[i].replace(/^\s+/,"").replace(/\s+$/,"");
    if(t==="") continue;
    if(t.indexOf("#")===0 || t.indexOf("//")===0 || t.indexOf("/*")===0 || t.indexOf("*")===0) continue;
    if(isStructural(t)) continue;
    var m = t.match(/^(?:export\s+)?([A-Za-z_][A-Za-z0-9_.]*)\s*=\s*(.*)$/);
    if(m && t.indexOf("=>")===-1){
      entries.push({line:lineNo, rawKey:m[1], norm:normKey(m[1]), value:stripQuotes(m[2])});
      continue;
    }
    var pm = t.match(/^['"]([^'"]+)['"]\s*=>\s*(.+)$/);
    if(pm){
      var vraw = pm[2].replace(/^\s+/,"").replace(/\s+$/,"");
      if(vraw==="[" || /^array\s*\($/i.test(vraw)) continue;
      entries.push({line:lineNo, rawKey:pm[1], norm:normKey(pm[1]), value:parsePhpValue(vraw)});
      continue;
    }
    notParsed.push(lineNo);
  }
  return {entries:entries, notParsed:notParsed};
}
function findEntry(entries, norms){
  for(var i=0;i<entries.length;i++){ if(norms.indexOf(entries[i].norm)>=0) return entries[i]; }
  return null;
}
function F(sev, line, key, explanation, fix){
  return {severity:sev, line:(line==null?null:line), key:key, explanation:explanation, fix:fix};
}

function audit(text){
  var parsed = parseConfig(text);
  var entries = parsed.entries;
  var findings = [];
  var recog = 0, seen = {};
  entries.forEach(function(e){ if(isRecognizable(e.rawKey, e.norm) && !seen[e.norm]){ seen[e.norm]=true; recog++; } });

  /* secret key */
  var sk = findEntry(entries, ["secret_key","secret"]);
  if(!sk){
    findings.push(F("BLOCKER", null, "secret_key",
      "No secret key was found in the config. Mautic uses the secret key to protect sessions and signed data; running without one leaves that protection missing or defaulted.",
      "Set MAUTIC_SECRET_KEY (or the secret_key parameter) to a random value of at least 32 characters from a password generator, and keep it out of the file if your host supports vault or environment references."));
  } else if(isReference(sk.value)){
    findings.push(F("INFO", sk.line, sk.rawKey,
      "The secret key is supplied by an external reference rather than typed into the config, so no key material appears in this text.",
      "No change needed — make sure the referenced secret is at least 32 characters where it is stored."));
  } else if(isExampleValue(sk.value)){
    findings.push(F("BLOCKER", sk.line, sk.rawKey,
      "The secret key looks like an example or placeholder value (length " + sk.value.length + "). Example keys are public knowledge, so anyone could reproduce the protection this key is supposed to provide.",
      "Replace it with a fresh random value of at least 32 characters that has never been published or shared."));
  } else if(sk.value.length < 32){
    findings.push(F(sk.value.length < 16 ? "BLOCKER" : "HIGH", sk.line, sk.rawKey,
      "The secret key is only " + sk.value.length + " characters long. Keys shorter than 32 characters are far easier to guess or brute-force.",
      "Generate a new random secret key of at least 32 characters (64 is better) and update the config."));
  }

  /* database password */
  var dbp = findEntry(entries, ["db_password"]);
  if(dbp){
    if(isReference(dbp.value)){
      findings.push(F("INFO", dbp.line, dbp.rawKey,
        "The database password is supplied by an external reference, not typed into the config text.",
        "No change needed — keep the real password in the vault or secret store the reference points to."));
    } else if(dbp.value===""){
      findings.push(F("HIGH", dbp.line, dbp.rawKey,
        "The database password is set but empty (length 0). A database account with no password is open to anyone who can reach the database.",
        "Set a long, unique password on the database account and supply it by reference where possible."));
    } else if(isExampleValue(dbp.value) || dbp.value.length < 12){
      findings.push(F("BLOCKER", dbp.line, dbp.rawKey,
        "A database password is typed directly into the config in plaintext, and it is short or example-style (length " + dbp.value.length + "). Anyone who reads this file — a backup, a screenshot, a leaked repo — gets the database keys.",
        "Change the database password to a long, unique one (16+ characters), and supply it through a vault or environment reference instead of typing it into the config."));
    } else {
      findings.push(F("HIGH", dbp.line, dbp.rawKey,
        "A database password is typed directly into the config in plaintext (length " + dbp.value.length + "). Anyone who reads this file — a backup, a screenshot, a leaked repo — gets the database keys.",
        "Move the password into a vault or secret store and reference it (for example ${VAULT_DB_PASSWORD}) instead of storing the value in the config text."));
    }
  } else if(findEntry(entries, ["db_name","db_user","db_host"])){
    findings.push(F("WARNING", null, "db_password",
      "Database settings are present but no database password key was found. If the database account has no password, the data is exposed; if the password lives elsewhere, this audit cannot see that from the pasted text.",
      "Confirm the database account has a strong password and that the config supplies it by reference."));
  }

  /* mailer password */
  var mp = findEntry(entries, ["mailer_password"]);
  if(mp){
    if(isReference(mp.value)){
      findings.push(F("INFO", mp.line, mp.rawKey,
        "The mailer password is supplied by an external reference, not typed into the config text.",
        "No change needed — keep the real password in the vault or secret store the reference points to."));
    } else if(mp.value===""){
      findings.push(F("WARNING", mp.line, mp.rawKey,
        "The mailer password is set but empty (length 0). If the mail account needs a password, sending will fail or the account is unprotected.",
        "Set the mail account password and supply it by reference where possible."));
    } else if(isExampleValue(mp.value) || mp.value.length < 12){
      findings.push(F("BLOCKER", mp.line, mp.rawKey,
        "A mailer password is typed directly into the config in plaintext, and it is short or example-style (length " + mp.value.length + "). Whoever holds it can send mail as your server and burn your sender reputation.",
        "Change the mail password to a long, unique one (16+ characters), and supply it through a vault or environment reference instead of typing it into the config."));
    } else {
      findings.push(F("HIGH", mp.line, mp.rawKey,
        "A mailer password is typed directly into the config in plaintext (length " + mp.value.length + "). Whoever holds it can send mail as your server and burn your sender reputation.",
        "Move the password into a vault or secret store and reference it (for example ${VAULT_MAILER_PASSWORD}) instead of storing the value in the config text."));
    }
  }

  /* site_url */
  var su = findEntry(entries, ["site_url"]);
  if(!su){
    findings.push(F("WARNING", null, "site_url",
      "No site_url was found. Mautic builds links in emails and pages from this value; without it, links can point at the wrong place.",
      "Set MAUTIC_SITE_URL (or site_url) to the full public https address of the installation."));
  } else if(su.value===""){
    findings.push(F("HIGH", su.line, su.rawKey,
      "site_url is set but empty. Links Mautic generates in emails and pages will be broken.",
      "Set site_url to the full public https address of the installation."));
  } else if(/^http:\/\//i.test(su.value)){
    findings.push(F("HIGH", su.line, su.rawKey,
      "site_url uses plain http. Logins, tracking links, and form submissions tied to this address travel unencrypted and can be intercepted or altered.",
      "Move the installation behind https (a TLS certificate) and update site_url to the https address."));
  } else if(!/^https:\/\//i.test(su.value)){
    findings.push(F("WARNING", su.line, su.rawKey,
      "site_url does not start with https://, so this audit cannot confirm the installation is served over an encrypted connection.",
      "Set site_url to the full https address of the installation."));
  }

  /* trusted hosts */
  var th = findEntry(entries, ["trusted_hosts"]);
  if(!th){
    findings.push(F("WARNING", null, "trusted_hosts",
      "No trusted_hosts setting was found. Without a host allow-list, the app can be reached under host names you did not intend, which enables host-header attacks against links and password resets.",
      "Set MAUTIC_TRUSTED_HOSTS (or trusted_hosts) to the exact host name(s) the installation answers on."));
  } else if(th.value.replace(/[\[\]\s]/g,"")===""){
    findings.push(F("HIGH", th.line, th.rawKey,
      "trusted_hosts is empty. No host allow-list is in force, so the app can be reached under arbitrary host names, which enables host-header attacks against links and password resets.",
      "Set trusted_hosts to the exact host name(s) the installation answers on — never a wildcard."));
  } else if(th.value.indexOf("*")>=0){
    findings.push(F("BLOCKER", th.line, th.rawKey,
      "trusted_hosts contains a wildcard, which trusts every host name — the allow-list stops protecting anything.",
      "Replace the wildcard with the exact host name(s) the installation answers on."));
  }

  /* debug / dev posture */
  entries.forEach(function(e){
    if(e.norm==="debug"||e.norm==="app_debug"||e.norm==="kernel_debug"||/_debug$/.test(e.norm)){
      if(truthy(e.value)){
        findings.push(F("BLOCKER", e.line, e.rawKey,
          "Debug mode is switched on. In production, debug output can expose file paths, configuration, and other internals to visitors, and it slows the server down.",
          "Turn debug off for deployment (set it to 0 / false) and use the server logs instead."));
      }
    }
    if(e.norm==="env"||e.norm==="app_env"||e.norm==="environment"){
      var v = e.value.toLowerCase();
      if(v==="dev"||v==="development"||v==="debug"){
        findings.push(F("HIGH", e.line, e.rawKey,
          "The environment is set to a development posture. Dev posture typically enables debug tooling and relaxed errors that should never face the public internet.",
          "Set the environment to prod for deployment."));
      } else if(v==="test"){
        findings.push(F("WARNING", e.line, e.rawKey,
          "The environment is set to test. A test posture is not a production posture and can behave differently under real traffic.",
          "Set the environment to prod for deployment."));
      }
    }
  });

  /* not parsed */
  parsed.notParsed.forEach(function(ln){
    findings.push(F("INFO", ln, "(line " + ln + ")",
      "NOT PARSED: line " + ln + " is neither a KEY=VALUE line nor a PHP 'key' => 'value' parameter line, so it was not graded. If it carries a setting, that setting was not checked.",
      "Rewrite the line in KEY=VALUE or 'key' => 'value' form, or remove it if it does not belong in the config."));
  });

  var counts = {BLOCKER:0, HIGH:0, WARNING:0, INFO:0};
  findings.forEach(function(f){ counts[f.severity]++; });

  var verdict;
  if(recog < 3) verdict = "NOT ENOUGH TO GRADE";
  else if(counts.BLOCKER > 0) verdict = "DO NOT DEPLOY";
  else if(counts.HIGH > 0 || counts.WARNING > 0) verdict = "DEPLOY WITH FIXES";
  else verdict = "SAFE TO DEPLOY";

  return {verdict:verdict, findings:findings, counts:counts, recognizable:recog, parsedCount:entries.length};
}

function lineLabel(f){ return f.line==null ? "Missing from config" : "Line " + f.line; }

function buildReport(r){
  var out = [];
  out.push("J-Dawgs Mautic Server Config Safety Auditor — audit report");
  out.push("Verdict: " + r.verdict);
  out.push("Recognizable Mautic keys: " + r.recognizable + " | Parsed settings: " + r.parsedCount);
  out.push("Findings: " + r.findings.length + " (BLOCKER " + r.counts.BLOCKER + ", HIGH " + r.counts.HIGH + ", WARNING " + r.counts.WARNING + ", INFO " + r.counts.INFO + ")");
  out.push("Offline text audit only — no server was contacted, and this does not verify the config will start.");
  out.push("Secret values are never included: secrets are reported by key name, line, and length only.");
  out.push("");
  if(r.findings.length===0) out.push("No findings.");
  r.findings.forEach(function(f, i){
    out.push((i+1) + ". [" + f.severity + "] " + lineLabel(f) + " - " + f.key);
    out.push("   " + f.explanation);
    out.push("   Fix: " + f.fix);
  });
  return out.join("\n");
}
function buildJson(r){
  return JSON.stringify({
    tool:"J-Dawgs Mautic Server Config Safety Auditor",
    verdict:r.verdict,
    recognizableMauticKeys:r.recognizable,
    parsedSettings:r.parsedCount,
    counts:r.counts,
    findings:r.findings.map(function(f){
      return {severity:f.severity, line:f.line, key:f.key, explanation:f.explanation, fix:f.fix};
    })
  }, null, 2);
}

function esc(s){
  return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
}

var lastResult = null, lastReport = "", lastJson = "";
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_WORDS": (typeof EXAMPLE_WORDS !== 'undefined' ? EXAMPLE_WORDS : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-mautic-server-config-safety-auditor',
  name: 'J-Dawgs Mautic Server Config Safety Auditor',
  description: 'Grades a pasted Mautic server config offline into one deploy verdict, secrets by key name/line/length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_WORDS": __core["EXAMPLE_WORDS"] }
};
