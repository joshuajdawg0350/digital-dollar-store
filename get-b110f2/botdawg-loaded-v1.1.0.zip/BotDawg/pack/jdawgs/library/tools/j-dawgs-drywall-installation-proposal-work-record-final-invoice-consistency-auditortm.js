'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Drywall Installation Proposal, Work Record & Final Invoice Consistency Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Examples ---------- */

      var PLANTED = {
        proposal: [
          "# Proposal — garage + two bedrooms, as quoted",
          "ITEM Drywall board 4x8 5/8 in fire-rated | 40 | 28.00",
          "ITEM Drywall board 4x8 1/2 in regular | 60 | 16.00",
          "ITEM Joint compound 5 gal | 10 | 18.00",
          "LABOR 32 | 65.00",
          "DEPOSIT 500.00",
          "FEE Permit | 150.00",
          "FEE Delivery | 75.00"
        ].join("\n"),
        record: [
          "# Work record — what the crew actually installed and worked",
          "ITEM Drywall board 4x8 1/2 in regular | 100 | 16.00",
          "ITEM Joint compound 5 gal | 8 | 18.00",
          "LABOR 30 | 65.00",
          "DEPOSIT 500.00",
          "FEE Permit | 150.00",
          "FEE Delivery | 75.00"
        ].join("\n"),
        invoice: [
          "# Final invoice — exactly as billed",
          "ITEM Drywall board 4x8 5/8 in fire-rated | 44 | 28.00 | 1232.00",
          "ITEM Drywall board 4x8 1/2 in regular | 60 | 16.00 | 960.00",
          "ITEM Joint compound 5 gal | 12 | 18.00 | 240.00",
          "LABOR 36 | 65.00 | 2340.00",
          "FEE Permit | 150.00",
          "FEE Permit | 150.00",
          "FEE Cleanup | 120.00",
          "TOTAL 5252.00"
        ].join("\n")
      };

      var CLEAN = {
        proposal: [
          "# Proposal — one bedroom + ceiling patch",
          "ITEM Drywall board 4x8 1/2 in regular | 50 | 16.00",
          "ITEM Joint compound 5 gal | 6 | 18.00",
          "LABOR 20 | 65.00",
          "DEPOSIT 300.00",
          "FEE Delivery | 75.00"
        ].join("\n"),
        record: [
          "# Work record — installed and worked as proposed",
          "ITEM Drywall board 4x8 1/2 in regular | 50 | 16.00",
          "ITEM Joint compound 5 gal | 6 | 18.00",
          "LABOR 20 | 65.00",
          "DEPOSIT 300.00",
          "FEE Delivery | 75.00"
        ].join("\n"),
        invoice: [
          "# Final invoice — matches proposal and work record",
          "ITEM Drywall board 4x8 1/2 in regular | 50 | 16.00 | 800.00",
          "ITEM Joint compound 5 gal | 6 | 18.00 | 108.00",
          "LABOR 20 | 65.00 | 1300.00",
          "FEE Delivery | 75.00",
          "DEPOSIT 300.00",
          "TOTAL 1983.00"
        ].join("\n")
      };

      /* ---------- Helpers ---------- */

      function r2(x) { return Math.round((x + Number.EPSILON) * 100) / 100; }
      function fmt(n) {
        var neg = n < 0;
        var s = Math.abs(r2(n)).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        return (neg ? "-$" : "$") + s;
      }
      function num(raw) {
        if (raw == null) return NaN;
        var s = String(raw).replace(/[$,]/g, "").trim();
        if (s === "") return NaN;
        var v = parseFloat(s);
        return isNaN(v) ? NaN : v;
      }
      function normText(s) {
        return String(s).toLowerCase()
          .replace(/["\u2033]/g, " in ")
          .replace(/\s+/g, " ")
          .trim();
      }
      function thicknessOf(name) {
        var m = name.match(/(\d+)\s*\/\s*(\d+)\s*in/);
        if (m) return { label: m[1] + "/" + m[2] + " in", value: parseInt(m[1], 10) / parseInt(m[2], 10) };
        m = name.match(/(\d+(?:\.\d+)?)\s*in/);
        if (m) return { label: m[1] + " in", value: parseFloat(m[1]) };
        return { label: "", value: null };
      }
      function typeOf(name) {
        if (/fire|type\s*x/.test(name)) return "fire-rated";
        if (/moisture|mold|greenboard|green board/.test(name)) return "moisture-resistant";
        if (/regular|standard/.test(name)) return "regular";
        return "unspecified";
      }
      function isBoard(name) {
        return /board|sheetrock|gypsum|drywall/.test(name);
      }
      function baseKey(name) {
        return name
          .replace(/\d+\s*\/\s*\d+\s*in/g, " ")
          .replace(/\d+(?:\.\d+)?\s*in/g, " ")
          .replace(/fire-rated|fire rated|type x|moisture-resistant|moisture resistant|mold-resistant|mold resistant|regular|standard/g, " ")
          .replace(/[^a-z0-9 ]/g, " ")
          .replace(/\s+/g, " ")
          .trim();
      }
      function specLabel(item) {
        var parts = [];
        if (item.thickness.label) parts.push(item.thickness.label);
        if (item.type && item.type !== "unspecified") parts.push(item.type);
        return parts.length ? parts.join(" ") : item.name;
      }

      /* ---------- Parser ---------- */

      function parseDoc(text, docName) {
        var doc = { items: [], labor: [], deposit: 0, fees: [], total: null, errors: [] };
        var lines = String(text || "").split(/\r?\n/);
        lines.forEach(function (rawLine, idx) {
          var line = rawLine.trim();
          if (line === "" || line.charAt(0) === "#") return;
          var where = docName + " line " + (idx + 1) + ": “" + line + "”";
          var parts = line.split("|").map(function (p) { return p.trim(); });
          var head = parts[0];
          var kwMatch = head.match(/^([A-Za-z]+)\s*(.*)$/);
          if (!kwMatch) { doc.errors.push(where + " — could not read this line."); return; }
          var kw = kwMatch[1].toUpperCase();
          var rest = kwMatch[2].trim();
          if (kw === "ITEM") {
            var qty = num(parts[1]), price = num(parts[2]);
            var lt = parts.length > 3 ? num(parts[3]) : null;
            if (!rest || isNaN(qty) || isNaN(price) || (parts.length > 3 && isNaN(lt))) {
              doc.errors.push(where + " — ITEM needs: ITEM name | qty | unit price [| line total].");
              return;
            }
            var n = normText(rest);
            doc.items.push({
              name: rest, norm: n, qty: qty, price: price, lineTotal: lt,
              board: isBoard(n), thickness: thicknessOf(n), type: typeOf(n),
              base: baseKey(n), spec: (thicknessOf(n).value == null ? "?" : thicknessOf(n).value) + "|" + typeOf(n)
            });
          } else if (kw === "LABOR") {
            var hours = num(rest !== "" ? rest : parts[0].replace(/^LABOR/i, ""));
            // LABOR hours may be in rest (before first |) — parts[0] is "LABOR 32"
            hours = num(kwMatch[2]);
            var rate = num(parts[1]);
            var ltot = parts.length > 2 ? num(parts[2]) : null;
            if (isNaN(hours) || isNaN(rate) || (parts.length > 2 && isNaN(ltot))) {
              doc.errors.push(where + " — LABOR needs: LABOR hours | rate [| total].");
              return;
            }
            doc.labor.push({ hours: hours, rate: rate, total: ltot });
          } else if (kw === "DEPOSIT") {
            var amt = num(rest);
            if (isNaN(amt)) { doc.errors.push(where + " — DEPOSIT needs: DEPOSIT amount."); return; }
            doc.deposit += amt;
          } else if (kw === "FEE") {
            var fAmt = num(parts[1]);
            if (!rest || isNaN(fAmt)) { doc.errors.push(where + " — FEE needs: FEE name | amount."); return; }
            doc.fees.push({ name: rest, norm: normText(rest), amount: fAmt });
          } else if (kw === "TOTAL") {
            var tAmt = num(rest);
            if (isNaN(tAmt)) { doc.errors.push(where + " — TOTAL needs: TOTAL amount."); return; }
            doc.total = tAmt;
          } else {
            doc.errors.push(where + " — unrecognized line type “" + kw + "”. Use ITEM, LABOR, DEPOSIT, FEE, or TOTAL.");
          }
        });
        return doc;
      }

      /* ---------- Audit ---------- */

      function audit(proposalText, recordText, invoiceText) {
        var P = parseDoc(proposalText, "Proposal");
        var R = parseDoc(recordText, "Work Record");
        var I = parseDoc(invoiceText, "Final Invoice");
        var findings = []; // counted in the overcharge total
        var notes = [];    // informational only
        var errors = P.errors.concat(R.errors, I.errors);

        function addFinding(tag, title, math, amount) {
          findings.push({ tag: tag, title: title, math: math, amount: r2(amount) });
        }
        function addNote(title, math) { notes.push({ title: title, math: math }); }

        /* Proposal lookups */
        function proposalItemByNorm(n) {
          for (var i = 0; i < P.items.length; i++) if (P.items[i].norm === n) return P.items[i];
          return null;
        }
        function proposalItemBySpec(base, spec) {
          for (var i = 0; i < P.items.length; i++) if (P.items[i].base === base && P.items[i].spec === spec) return P.items[i];
          return null;
        }

        /* ----- Board reconciliation: spec swaps + sheet overage ----- */
        var invBoards = I.items.filter(function (it) { return it.board; });
        var recBoards = R.items.filter(function (it) { return it.board; });
        if (invBoards.length || recBoards.length) {
          // Pool of recorded board quantities, by base + spec.
          var pool = {}; // key base||spec -> {qty, price, label, base}
          recBoards.forEach(function (it) {
            var k = it.base + "||" + it.spec;
            if (!pool[k]) pool[k] = { qty: 0, price: it.price, label: specLabel(it), base: it.base };
            pool[k].qty += it.qty;
          });
          var leftoverBilled = [];
          invBoards.forEach(function (it) {
            var k = it.base + "||" + it.spec;
            var avail = pool[k] ? pool[k].qty : 0;
            var matched = Math.min(it.qty, avail);
            if (pool[k]) pool[k].qty -= matched;
            var left = r2(it.qty - matched);
            if (left > 0) leftoverBilled.push({ item: it, qty: left });
            // Unit price above proposal for the same spec
            var prop = proposalItemBySpec(it.base, it.spec);
            if (prop && it.price > prop.price + 0.004) {
              addFinding("Unit price", "Board billed above proposal price — " + it.name,
                "Invoice " + fmt(it.price) + "/sheet vs proposal " + fmt(prop.price) + "/sheet on " + it.qty +
                " sheets: " + it.qty + " × (" + fmt(it.price) + " − " + fmt(prop.price) + ") = " + fmt(it.qty * (it.price - prop.price)),
                it.qty * (it.price - prop.price));
            }
          });
          // Pair leftover billed with leftover recorded of a different spec (same base) -> swap.
          leftoverBilled.forEach(function (lb) {
            Object.keys(pool).forEach(function (k) {
              if (lb.qty <= 0) return;
              var slot = pool[k];
              if (slot.base !== lb.item.base || slot.qty <= 0) return;
              var swapQty = Math.min(lb.qty, slot.qty);
              var diff = lb.item.price - slot.price;
              if (diff > 0.004) {
                addFinding("Board spec swap", "Spec swap — billed as " + specLabel(lb.item) + ", recorded installed as " + slot.label,
                  swapQty + " sheets billed at " + fmt(lb.item.price) + " (" + lb.item.name + ") but the work record shows " +
                  slot.label + " installed at " + fmt(slot.price) + ": " + swapQty + " × (" + fmt(lb.item.price) + " − " +
                  fmt(slot.price) + ") = " + fmt(swapQty * diff),
                  swapQty * diff);
              } else {
                addNote("Spec difference, no price overcharge",
                  swapQty + " sheets billed as " + specLabel(lb.item) + " while the work record shows " + slot.label +
                  " installed; the billed price is not higher, so $0 is counted — the spec difference itself may still matter (e.g. fire rating).");
              }
              slot.qty = r2(slot.qty - swapQty);
              lb.qty = r2(lb.qty - swapQty);
            });
          });
          // Anything still billed with nothing recorded behind it -> quantity overage.
          leftoverBilled.forEach(function (lb) {
            if (lb.qty > 0) {
              addFinding("Quantity", "Sheets billed above sheets recorded installed — " + lb.item.name,
                "Billed " + lb.item.qty + " sheets; the work record accounts for " + r2(lb.item.qty - lb.qty) +
                " of them (same spec or swapped spec). Unaccounted: " + lb.qty + " × " + fmt(lb.item.price) + " = " + fmt(lb.qty * lb.item.price),
                lb.qty * lb.item.price);
            }
          });
          // Recorded but never billed -> note only.
          Object.keys(pool).forEach(function (k) {
            if (pool[k].qty > 0) {
              addNote("Installed but not billed", "The work record shows " + pool[k].qty + " more sheets of " +
                pool[k].label + " installed than the invoice bills. Not counted as an overcharge.");
            }
          });
        }

        /* ----- Non-board items: quantity vs work record, price vs proposal ----- */
        I.items.forEach(function (it) {
          if (it.board) return;
          var rec = null;
          R.items.forEach(function (ri) { if (ri.norm === it.norm) rec = ri; });
          var prop = proposalItemByNorm(it.norm);
          if (!rec) {
            addFinding("Not recorded", "Billed but never recorded as installed — " + it.name,
              "Invoice bills " + it.qty + " × " + fmt(it.price) + " = " + fmt(it.qty * it.price) +
              ", and the work record contains no line for this item at all" +
              (prop ? " (it does appear in the proposal at qty " + prop.qty + ")." : " (it is not in the proposal either)."),
              it.qty * it.price);
            return;
          }
          if (it.qty > rec.qty + 1e-9) {
            var over = r2(it.qty - rec.qty);
            addFinding("Quantity", "Quantity billed above quantity recorded — " + it.name,
              "Billed " + it.qty + ", work record shows " + rec.qty + " used/installed: (" + it.qty + " − " + rec.qty +
              ") × " + fmt(it.price) + " = " + fmt(over * it.price),
              over * it.price);
          }
          if (prop && it.price > prop.price + 0.004) {
            addFinding("Unit price", "Unit price billed above proposal — " + it.name,
              it.qty + " × (" + fmt(it.price) + " − " + fmt(prop.price) + ") = " + fmt(it.qty * (it.price - prop.price)),
              it.qty * (it.price - prop.price));
          }
        });

        /* ----- Labor ----- */
        var invHours = I.labor.reduce(function (s, l) { return s + l.hours; }, 0);
        var recHours = R.labor.reduce(function (s, l) { return s + l.hours; }, 0);
        var propHours = P.labor.reduce(function (s, l) { return s + l.hours; }, 0);
        var invRate = I.labor.length ? I.labor[0].rate : 0;
        var propRate = P.labor.length ? P.labor[0].rate : null;
        if (I.labor.length && R.labor.length && invHours > recHours + 1e-9) {
          var overH = r2(invHours - recHours);
          addFinding("Labor", "Labor billed above recorded hours",
            "Billed " + invHours + " hrs, work record shows " + recHours + " hrs: (" + invHours + " − " + recHours +
            ") × " + fmt(invRate) + " = " + fmt(overH * invRate),
            overH * invRate);
        }
        if (I.labor.length && propRate != null && invRate > propRate + 0.004) {
          addFinding("Labor rate", "Labor rate billed above proposal rate",
            "Billed " + invHours + " hrs at " + fmt(invRate) + " vs proposal rate " + fmt(propRate) + ": " + invHours +
            " × (" + fmt(invRate) + " − " + fmt(propRate) + ") = " + fmt(invHours * (invRate - propRate)),
            invHours * (invRate - propRate));
        }
        if (I.labor.length && !R.labor.length) {
          addNote("No labor in work record", "The invoice bills " + invHours + " labor hours but the work record has no LABOR line to check them against.");
        }
        if (propHours && invHours > propHours + 1e-9 && recHours >= invHours - 1e-9) {
          addNote("Hours above proposal, supported by work record",
            "Billed " + invHours + " hrs vs " + propHours + " hrs proposed, but the work record also shows " + recHours + " hrs — not counted as an overcharge.");
        }

        /* ----- Deposit ----- */
        var documentedDeposit = Math.max(P.deposit, R.deposit);
        if (documentedDeposit > 0 && I.deposit < documentedDeposit - 0.004) {
          var short = r2(documentedDeposit - I.deposit);
          addFinding("Deposit", "Deposit not fully credited on the invoice",
            "Deposit documented as paid: " + fmt(documentedDeposit) + " (proposal " + fmt(P.deposit) + ", work record " +
            fmt(R.deposit) + "). Credit shown on the invoice: " + fmt(I.deposit) + ". Uncredited: " + fmt(documentedDeposit) +
            " − " + fmt(I.deposit) + " = " + fmt(short),
            short);
        }

        /* ----- Fees: duplicates + invoice-only ----- */
        var propFeeNorms = {}, recFeeNorms = {};
        P.fees.forEach(function (f) { propFeeNorms[f.norm] = true; });
        R.fees.forEach(function (f) { recFeeNorms[f.norm] = true; });
        var seenFees = {};
        I.fees.forEach(function (f) {
          if (seenFees[f.norm]) {
            addFinding("Duplicate fee", "Duplicate fee on the invoice — " + f.name,
              "“" + f.name + "” appears more than once on the invoice. Extra occurrence: " + fmt(f.amount),
              f.amount);
          } else if (!propFeeNorms[f.norm] && !recFeeNorms[f.norm]) {
            addFinding("Invoice-only fee", "Fee on the invoice that is in neither the proposal nor the work record — " + f.name,
              "“" + f.name + "” billed at " + fmt(f.amount) + " appears nowhere in the proposal and nowhere in the work record.",
              f.amount);
          }
          seenFees[f.norm] = true;
        });
        var invFeeNorms = {};
        I.fees.forEach(function (f) { invFeeNorms[f.norm] = true; });
        P.fees.concat(R.fees).forEach(function (f) {
          if (!invFeeNorms[f.norm]) {
            addNote("Agreed fee missing from invoice", "“" + f.name + "” (" + fmt(f.amount) +
              ") appears in the proposal / work record but not on the invoice. Not counted as an overcharge.");
            invFeeNorms[f.norm] = true; // report once
          }
        });

        /* ----- Arithmetic: invoice line totals ----- */
        I.items.forEach(function (it) {
          if (it.lineTotal == null) return;
          var computed = r2(it.qty * it.price);
          var diff = r2(it.lineTotal - computed);
          if (diff > 0.004) {
            addFinding("Arithmetic", "Invoice line total is overstated — " + it.name,
              "Printed line total " + fmt(it.lineTotal) + " vs " + it.qty + " × " + fmt(it.price) + " = " + fmt(computed) +
              ": " + fmt(it.lineTotal) + " − " + fmt(computed) + " = " + fmt(diff),
              diff);
          } else if (diff < -0.004) {
            addNote("Invoice line total understated — " + it.name,
              "Printed " + fmt(it.lineTotal) + " vs " + it.qty + " × " + fmt(it.price) + " = " + fmt(computed) +
              ". This one runs in your favor; not counted.");
          }
        });
        I.labor.forEach(function (l) {
          if (l.total == null) return;
          var computed = r2(l.hours * l.rate);
          var diff = r2(l.total - computed);
          if (diff > 0.004) {
            addFinding("Arithmetic", "Invoice labor total is overstated",
              "Printed labor total " + fmt(l.total) + " vs " + l.hours + " × " + fmt(l.rate) + " = " + fmt(computed) +
              ": " + fmt(l.total) + " − " + fmt(computed) + " = " + fmt(diff),
              diff);
          } else if (diff < -0.004) {
            addNote("Invoice labor total understated",
              "Printed " + fmt(l.total) + " vs " + l.hours + " × " + fmt(l.rate) + " = " + fmt(computed) + ". In your favor; not counted.");
          }
        });

        /* ----- Arithmetic: invoice grand total ----- */
        if (I.total != null) {
          var lineSum = 0;
          I.items.forEach(function (it) { lineSum += (it.lineTotal != null ? it.lineTotal : r2(it.qty * it.price)); });
          I.labor.forEach(function (l) { lineSum += (l.total != null ? l.total : r2(l.hours * l.rate)); });
          var feeSum = I.fees.reduce(function (s, f) { return s + f.amount; }, 0);
          var expected = r2(lineSum + feeSum - I.deposit);
          var tDiff = r2(I.total - expected);
          if (tDiff > 0.004) {
            addFinding("Arithmetic", "Invoice grand total is overstated",
              "Printed TOTAL " + fmt(I.total) + " vs the invoice's own lines: items + labor " + fmt(r2(lineSum)) +
              " + fees " + fmt(feeSum) + " − deposit credit " + fmt(I.deposit) + " = " + fmt(expected) +
              ": " + fmt(I.total) + " − " + fmt(expected) + " = " + fmt(tDiff),
              tDiff);
          } else if (tDiff < -0.004) {
            addNote("Invoice grand total understated",
              "Printed TOTAL " + fmt(I.total) + " vs the invoice's own lines summing to " + fmt(expected) + ". In your favor; not counted.");
          }
        } else if (I.items.length || I.labor.length) {
          addNote("No TOTAL line on the invoice", "The invoice paste has no TOTAL line, so the grand total itself could not be arithmetic-checked.");
        }

        var total = r2(findings.reduce(function (s, f) { return s + f.amount; }, 0));
        var verdict = total > 0.004 ? "DO NOT PAY YET" : "SAFE TO PAY";
        return { verdict: verdict, overchargeTotal: total, findings: findings, notes: notes, errors: errors };
      }

      /* ---------- Report / JSON ---------- */

      function buildReport(res) {
        var out = [];
        out.push("J-Dawgs Drywall Installation Proposal, Work Record & Final Invoice Consistency Auditor™");
        out.push("Text cross-check of proposal vs work record vs final invoice. This report does not verify physical work.");
        out.push("");
        out.push("VERDICT: " + res.verdict);
        out.push("DOCUMENTED OVERCHARGE TOTAL: " + fmt(res.overchargeTotal));
        out.push("");
        if (res.findings.length) {
          out.push("OVERCHARGE COMPONENTS (arithmetic shown):");
          res.findings.forEach(function (f, i) {
            out.push((i + 1) + ". [" + f.tag + "] " + f.title + " — " + fmt(f.amount));
            out.push("   " + f.math);
          });
          out.push("");
          out.push("TOTAL: " + res.findings.map(function (f) { return fmt(f.amount); }).join(" + ") + " = " + fmt(res.overchargeTotal));
        } else {
          out.push("No overcharges documented. Every billed line is supported by the work record and the proposal, the deposit is credited, and the invoice arithmetic checks out.");
        }
        if (res.notes.length) {
          out.push("");
          out.push("NOTES (not counted in the total):");
          res.notes.forEach(function (n) { out.push("- " + n.title + ": " + n.math); });
        }
        if (res.errors.length) {
          out.push("");
          out.push("LINES THAT COULD NOT BE READ:");
          res.errors.forEach(function (e) { out.push("- " + e); });
        }
        return out.join("\n");
      }

      function buildJSON(res) {
        return JSON.stringify({
          tool: "J-Dawgs Drywall Installation Proposal, Work Record & Final Invoice Consistency Auditor™",
          scope: "Text cross-check only — proposal vs work record vs final invoice. Does not verify physical work.",
          verdict: res.verdict,
          documentedOverchargeTotal: res.overchargeTotal,
          currency: "USD",
          findings: res.findings.map(function (f) {
            return { type: f.tag, title: f.title, arithmetic: f.math, amount: f.amount };
          }),
          notes: res.notes.map(function (n) { return { title: n.title, detail: n.math }; }),
          unreadLines: res.errors
        }, null, 2);
      }

      /* ---------- UI ---------- */

      var lastResult = null;
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-drywall-installation-proposal-work-record-final-invoice-consistency-auditortm',
  name: 'J-Dawgs Drywall Installation Proposal, Work Record & Final Invoice Consistency Auditor',
  description: '',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
