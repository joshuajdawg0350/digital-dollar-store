'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Mealie Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

/* ---------- Worked examples (line numbers are part of the spec) ---------- */
var RISKY = [
"# Risky example - for practice only. Do not deploy this.",
"SECRET_KEY=abc123",
"DB_ENGINE=postgres",
"POSTGRES_USER=mealie",
"POSTGRES_PASSWORD=pass123",
"POSTGRES_SERVER=db",
"POSTGRES_PORT=5432",
"POSTGRES_DB=mealie",
"BASE_URL=http://mealie.dawson.family",
"ALLOW_SIGNUP=true",
"API_DOCS=true",
"SMTP_HOST=mail.dawson.family",
"SMTP_PORT=25",
"SMTP_FROM_EMAIL=mealie@dawson.family",
"SMTP_USER=mealie@dawson.family",
"SMTP_PASSWORD=mailpass",
"OIDC_AUTH_ENABLED=true",
"OIDC_CLIENT_ID=",
"LDAP_AUTH_ENABLED=false"
].join("\n");

var HARDENED = [
"# Hardened example - strong sample values. Generate your own secrets before real use.",
"SECRET_KEY=9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08",
"DB_ENGINE=postgres",
"POSTGRES_USER=mealie",
"POSTGRES_PASSWORD=Tr7!mQ9zX2#vL8pW4&nK6sD1fG5hJ3b",
"POSTGRES_SERVER=db",
"POSTGRES_PORT=5432",
"POSTGRES_DB=mealie",
"BASE_URL=https://mealie.dawson.family",
"ALLOW_SIGNUP=false",
"API_DOCS=false",
"SMTP_HOST=mail.dawson.family",
"SMTP_PORT=587",
"SMTP_FROM_EMAIL=mealie@dawson.family",
"SMTP_USER=mealie@dawson.family",
"SMTP_PASSWORD=Zx9!qwEr7@Ty3#Ui5$Op1&As8*Df4+",
"SMTP_AUTH_STRATEGY=TLS",
"OIDC_AUTH_ENABLED=false",
"LDAP_AUTH_ENABLED=false"
].join("\n");

/* ---------- Parsing ---------- */
function stripQuotes(v){
  v = v.trim();
  if(v.length >= 2 && ((v.charAt(0)==='"' && v.charAt(v.length-1)==='"') || (v.charAt(0)==="'" && v.charAt(v.length-1)==="'"))){
    return v.slice(1,-1);
  }
  return v;
}
function parseConfig(text){
  var entries = []; // {key, value, line}
  var lines = text.split(/\r?\n/);
  for(var i=0;i<lines.length;i++){
    var raw = lines[i];
    var t = raw.trim();
    if(!t || t.charAt(0)==="#") continue;
    if(t.indexOf("export ")===0) t = t.slice(7).trim();
    var eq = t.indexOf("=");
    var colon = t.indexOf(":");
    var key, val;
    if(eq > 0){ key = t.slice(0,eq).trim(); val = t.slice(eq+1); }
    else if(colon > 0 && /^[A-Za-z_][A-Za-z0-9_]*\s*:/.test(t)){ key = t.slice(0,colon).trim(); val = t.slice(colon+1); }
    else continue;
    if(!/^[A-Za-z_][A-Za-z0-9_]*$/.test(key)) continue;
    // Strip an inline comment only when preceded by whitespace and value is unquoted
    var vtrim = val.trim();
    if(vtrim.charAt(0) !== '"' && vtrim.charAt(0) !== "'"){
      var hash = vtrim.indexOf(" #");
      if(hash > 0) vtrim = vtrim.slice(0,hash).trim();
      val = vtrim;
    }
    entries.push({ key: key.toUpperCase(), value: stripQuotes(String(val)), line: i+1 });
  }
  return entries;
}
function byKey(entries, key){
  for(var i=0;i<entries.length;i++) if(entries[i].key===key) return entries[i];
  return null;
}
function truthy(v){ return /^(true|1|yes|on)$/i.test(String(v).trim()); }
function falsy(v){ return /^(false|0|no|off)$/i.test(String(v).trim()); }

var PLACEHOLDER_WORDS = ["changeme","change-me","change_me","your-secret","your_secret","placeholder","example-secret","default-secret","insecure","letmein","123456","12345678","qwerty"];
function isPlaceholder(v){
  var low = String(v).toLowerCase();
  if(low==="password"||low==="secret"||low==="test"||low==="demo"||low==="default"||low==="admin"||low==="mealie"||low==="postgres") return true;
  for(var i=0;i<PLACEHOLDER_WORDS.length;i++) if(low.indexOf(PLACEHOLDER_WORDS[i])>=0) return true;
  if(low.indexOf("your-")===0 || low.indexOf("your_")===0) return true;
  if(low.indexOf("xxx")>=0 || low.indexOf("todo")>=0 || low.indexOf("replace")>=0) return true;
  return false;
}
function uniqueChars(v){ var s={},c=0; for(var i=0;i<v.length;i++){ if(!s[v.charAt(i)]){s[v.charAt(i)]=1;c++;} } return c; }

var KNOWN_KEYS = ["SECRET_KEY","DB_ENGINE","DATABASE_URL","POSTGRES_USER","POSTGRES_PASSWORD","POSTGRES_SERVER","POSTGRES_PORT","POSTGRES_DB","BASE_URL","ALLOW_SIGNUP","API_DOCS","OIDC_AUTH_ENABLED","OIDC_CLIENT_ID","OIDC_CLIENT_SECRET","OIDC_ISSUER","OIDC_CONFIGURATION_URL","OIDC_SIGNUP_ENABLED","LDAP_AUTH_ENABLED","LDAP_SERVER_URL","LDAP_BIND_TEMPLATE","LDAP_ADMIN_FILTER","LDAP_USER_FILTER","LDAP_BIND_PASSWORD","SMTP_HOST","SMTP_PORT","SMTP_FROM_EMAIL","SMTP_FROM_NAME","SMTP_USER","SMTP_PASSWORD","SMTP_AUTH_STRATEGY","DEBUG","PRODUCTION","LOG_LEVEL","TZ","DEFAULT_USER","DEFAULT_GROUP","TOKEN_TIME","CACHE_DIR","DATA_DIR","NLTK_DATA"];

/* ---------- Audit ---------- */
function audit(text){
  var entries = parseConfig(text);
  var findings = []; // {severity, key, line, secretLength(null|number), title, detail, fix}
  var passes = [];   // {key, line, note}
  function add(sev, entry, key, secretLength, title, detail, fix){
    findings.push({ severity: sev, key: key, line: entry ? entry.line : null, secretLength: (typeof secretLength==="number"?secretLength:null), title: title, detail: detail, fix: fix });
  }
  function pass(key, entry, note){ passes.push({ key:key, line: entry?entry.line:null, note:note }); }

  function checkSecret(entry, opts){
    // opts: {label, minCritical, minStrong, genFix}
    var v = entry.value, len = v.length;
    if(len===0){ add("critical", entry, entry.key, 0, opts.label+" is empty", "The key is present but has no value, so Mealie falls back to a default or fails open.", opts.genFix); return; }
    if(isPlaceholder(v)){ add("critical", entry, entry.key, len, opts.label+" looks like a placeholder or example value", "The value matches a known placeholder/example pattern (reported by length only: "+len+" characters). Anyone who has seen the docs has seen this value.", opts.genFix); return; }
    if(len < opts.minCritical){ add("critical", entry, entry.key, len, opts.label+" is far too short ("+len+" characters)", "At "+len+" characters this can be guessed or brute-forced. Length is the main defense for a value like this.", opts.genFix); return; }
    if(len < opts.minStrong){ add("high", entry, entry.key, len, opts.label+" is short ("+len+" characters)", "It clears the bare minimum but sits below the "+opts.minStrong+"-character strength this auditor expects for a deployed server.", opts.genFix); return; }
    if(uniqueChars(v) < 8){ add("high", entry, entry.key, len, opts.label+" has very low variety", "The value is long but built from very few distinct characters, which makes it far easier to guess than its length suggests.", opts.genFix); return; }
    pass(entry.key, entry, opts.label+" is "+len+" characters with good variety (value never shown).");
  }

  var knownCount = 0;
  for(var i=0;i<entries.length;i++) if(KNOWN_KEYS.indexOf(entries[i].key)>=0) knownCount++;

  /* SECRET_KEY */
  var sk = byKey(entries,"SECRET_KEY");
  if(sk){ checkSecret(sk, { label:"SECRET_KEY", minCritical:32, minStrong:64, genFix:"Generate a fresh random value of at least 64 characters (for example: openssl rand -hex 32), store it only in the server config, and restart Mealie. Treat the old value as compromised." }); }
  else if(entries.length){ add("high", null, "SECRET_KEY", null, "SECRET_KEY is missing", "Mealie signs sessions and tokens with this key. Without an explicit strong value the deployment relies on defaults.", "Set SECRET_KEY to a freshly generated random value of at least 64 characters and restart Mealie."); }

  /* Database */
  var engine = byKey(entries,"DB_ENGINE");
  var dbUrl = byKey(entries,"DATABASE_URL");
  var pgPass = byKey(entries,"POSTGRES_PASSWORD");
  if(dbUrl){
    var m = /^[a-zA-Z][a-zA-Z0-9+.-]*:\/\/[^:\/@]+:([^@]*)@/.exec(dbUrl.value);
    if(m){
      var urlPassLen = m[1].length;
      if(urlPassLen===0 || isPlaceholder(m[1])) add("critical", dbUrl, "DATABASE_URL", urlPassLen, "Database password inside DATABASE_URL is empty or a placeholder", "The connection string carries a password of "+urlPassLen+" characters that is empty or a known placeholder pattern.", "Put a freshly generated database password of at least 20 characters in the connection string, and keep the file that holds it private.");
      else if(urlPassLen < 12) add("critical", dbUrl, "DATABASE_URL", urlPassLen, "Database password inside DATABASE_URL is far too short ("+urlPassLen+" characters)", "The password embedded in the connection string can be guessed quickly. It is reported by length only.", "Use a freshly generated database password of at least 20 characters in the connection string.");
      else if(urlPassLen < 20) add("high", dbUrl, "DATABASE_URL", urlPassLen, "Database password inside DATABASE_URL is short ("+urlPassLen+" characters)", "Below the 20-character strength expected for a deployed database.", "Rotate to a freshly generated password of at least 20 characters.");
      else pass("DATABASE_URL", dbUrl, "Embedded database password is "+urlPassLen+" characters (value never shown).");
    } else {
      pass("DATABASE_URL", dbUrl, "Connection string present with no embedded password detected.");
    }
  }
  if(engine){
    var eng = engine.value.toLowerCase();
    if(eng.indexOf("sqlite")>=0){
      add("medium", engine, "DB_ENGINE", null, "SQLite selected as the database engine", "SQLite works for a small single-user instance, but it is the fragile choice for a shared or internet-facing deployment: one writer at a time and file-based backups.", "For a deployed multi-user server, use DB_ENGINE=postgres with a strong POSTGRES_PASSWORD. SQLite is fine only for a private, single-user trial.");
    } else if(eng.indexOf("postgres")>=0){
      pass("DB_ENGINE", engine, "PostgreSQL engine selected.");
      if(!pgPass && !dbUrl){
        add("critical", engine, "POSTGRES_PASSWORD", null, "PostgreSQL selected but no database password is set", "DB_ENGINE points at PostgreSQL, yet neither POSTGRES_PASSWORD nor a DATABASE_URL appears in the config. The database is either unreachable or running on a default password.", "Set POSTGRES_PASSWORD to a freshly generated value of at least 20 characters, matching the database, and restart both services.");
      }
    } else {
      add("medium", engine, "DB_ENGINE", null, "Unrecognized database engine value", "The auditor only recognizes sqlite and postgres here; anything else will not behave as documented.", "Set DB_ENGINE to postgres for a deployed server (or sqlite for a private trial).");
    }
  } else if(entries.length){
    add("medium", null, "DB_ENGINE", null, "DB_ENGINE is not set", "Mealie will fall back to its default SQLite database. That default is easy to miss in backups and migrations.", "Set DB_ENGINE explicitly — postgres for a deployed server — so the choice is deliberate.");
  }
  if(pgPass){
    checkSecret(pgPass, { label:"POSTGRES_PASSWORD (database password)", minCritical:12, minStrong:20, genFix:"Generate a fresh database password of at least 20 characters, set it in both the database and the Mealie config, and restart. Treat the old password as compromised." });
  }

  /* BASE_URL */
  var base = byKey(entries,"BASE_URL");
  if(base){
    var bv = base.value;
    if(/^http:\/\//i.test(bv)){
      if(/localhost|127\.0\.0\.1|\[::1\]/i.test(bv)) add("low", base, "BASE_URL", null, "BASE_URL uses http on a local address", "Plain http is acceptable for a localhost-only trial, but links and cookies will be wrong if this server is ever reached from another device.", "Use the https address the server is actually reached at once it leaves localhost.");
      else add("high", base, "BASE_URL", null, "BASE_URL uses plain http on a public address", "Sessions, login forms, and password-reset links will travel unencrypted, and Mealie will build insecure links and cookies from this value.", "Put Mealie behind an https reverse proxy (or TLS terminator) and set BASE_URL to the https:// address.");
    } else if(/^https:\/\//i.test(bv)){
      pass("BASE_URL", base, "BASE_URL uses https.");
    } else if(bv.length===0){
      add("medium", base, "BASE_URL", null, "BASE_URL is empty", "Mealie builds links, invitations, and reset emails from this value; empty means broken links.", "Set BASE_URL to the full public https:// address of the server.");
    } else {
      add("medium", base, "BASE_URL", null, "BASE_URL has no http/https scheme", "Without a scheme, generated links and cookies can be wrong or insecure.", "Set BASE_URL to the full address including https://.");
    }
  } else if(entries.length){
    add("medium", null, "BASE_URL", null, "BASE_URL is not set", "Mealie builds invitation and password-reset links from BASE_URL. Unset, those links break or point at the wrong host.", "Set BASE_URL to the full public https:// address of the server.");
  }

  /* ALLOW_SIGNUP */
  var signup = byKey(entries,"ALLOW_SIGNUP");
  if(signup){
    if(truthy(signup.value)) add("high", signup, "ALLOW_SIGNUP", null, "Open signup is enabled (ALLOW_SIGNUP=true)", "Anyone who can reach the server can create an account and get inside your recipe library — and every new account is another attack surface.", "Set ALLOW_SIGNUP=false, create the accounts you need as an admin, and only open signup briefly if you must.");
    else if(falsy(signup.value)) pass("ALLOW_SIGNUP", signup, "Open signup is disabled.");
    else add("low", signup, "ALLOW_SIGNUP", null, "ALLOW_SIGNUP value is not a clear true/false", "An ambiguous value may not do what you expect.", "Set ALLOW_SIGNUP explicitly to false for a deployed server.");
  }

  /* API_DOCS */
  var docs = byKey(entries,"API_DOCS");
  if(docs){
    if(truthy(docs.value)) add("medium", docs, "API_DOCS", null, "Interactive API documentation is exposed (API_DOCS=true)", "The public docs page maps every endpoint for an attacker and confirms exactly what the server is.", "Set API_DOCS=false on a deployed server. Turn it on only on a private development instance.");
    else if(falsy(docs.value)) pass("API_DOCS", docs, "API documentation is disabled.");
  }

  /* OIDC */
  var oidcOn = byKey(entries,"OIDC_AUTH_ENABLED");
  var oidcSecret = byKey(entries,"OIDC_CLIENT_SECRET");
  if(oidcOn && truthy(oidcOn.value)){
    var cid = byKey(entries,"OIDC_CLIENT_ID");
    var issuer = byKey(entries,"OIDC_ISSUER") || byKey(entries,"OIDC_CONFIGURATION_URL");
    var missing = [];
    if(!cid || cid.value.length===0) missing.push("OIDC_CLIENT_ID");
    if(!oidcSecret || oidcSecret.value.length===0) missing.push("OIDC_CLIENT_SECRET");
    if(!issuer || issuer.value.length===0) missing.push("an issuer / configuration URL");
    if(missing.length){
      add("high", oidcOn, "OIDC_AUTH_ENABLED", null, "OIDC sign-in is enabled but its configuration is incomplete", "Missing or empty: "+missing.join(", ")+". Half-configured single sign-on tends to fail open, lock everyone out, or get 'fixed' later by disabling checks.", "Either complete the OIDC setup (client ID, client secret, and the provider's https issuer/configuration URL) or set OIDC_AUTH_ENABLED=false and use Mealie accounts.");
    } else {
      if(/^http:\/\//i.test(issuer.value) && !/localhost|127\.0\.0\.1/i.test(issuer.value)) add("high", issuer, issuer.key, null, "OIDC issuer uses plain http", "Tokens and discovery documents fetched over http can be tampered with.", "Use the provider's https:// issuer / configuration URL.");
      else pass("OIDC_AUTH_ENABLED", oidcOn, "OIDC is enabled with client ID, secret, and issuer present.");
    }
  } else if(oidcOn && falsy(oidcOn.value)){
    pass("OIDC_AUTH_ENABLED", oidcOn, "OIDC sign-in is disabled (Mealie accounts are used).");
  }
  if(oidcSecret && oidcSecret.value.length>0){
    checkSecret(oidcSecret, { label:"OIDC_CLIENT_SECRET", minCritical:16, minStrong:32, genFix:"Rotate the client secret at your identity provider, put the new value (at least 32 characters) in the config, and restart Mealie." });
  }
  var oidcSignup = byKey(entries,"OIDC_SIGNUP_ENABLED");
  if(oidcSignup && truthy(oidcSignup.value)) add("medium", oidcSignup, "OIDC_SIGNUP_ENABLED", null, "OIDC auto-signup is enabled", "Anyone with an account at the identity provider can provision a Mealie account automatically.", "Set OIDC_SIGNUP_ENABLED=false unless every account at that provider should get in, and pre-create the users who should have access.");

  /* LDAP */
  var ldapOn = byKey(entries,"LDAP_AUTH_ENABLED");
  var ldapPass = byKey(entries,"LDAP_BIND_PASSWORD");
  if(ldapOn && truthy(ldapOn.value)){
    var ldapUrl = byKey(entries,"LDAP_SERVER_URL");
    if(!ldapUrl || ldapUrl.value.length===0) add("high", ldapOn, "LDAP_AUTH_ENABLED", null, "LDAP sign-in is enabled but no LDAP server URL is set", "LDAP_AUTH_ENABLED=true without LDAP_SERVER_URL cannot authenticate anyone correctly.", "Set LDAP_SERVER_URL to your directory's ldaps:// address, or set LDAP_AUTH_ENABLED=false.");
    else if(/^ldap:\/\//i.test(ldapUrl.value)) add("high", ldapUrl, "LDAP_SERVER_URL", null, "LDAP connection uses plain ldap:// (no TLS)", "Bind credentials and user passwords cross the network unencrypted on a plain LDAP connection.", "Use ldaps:// (TLS) for LDAP_SERVER_URL.");
    else pass("LDAP_AUTH_ENABLED", ldapOn, "LDAP is enabled with a server URL present.");
  } else if(ldapOn && falsy(ldapOn.value)){
    pass("LDAP_AUTH_ENABLED", ldapOn, "LDAP sign-in is disabled.");
  }
  if(ldapPass && ldapPass.value.length>0){
    checkSecret(ldapPass, { label:"LDAP_BIND_PASSWORD", minCritical:12, minStrong:20, genFix:"Rotate the LDAP bind password in the directory, put the new value (at least 20 characters) in the config, and restart Mealie." });
  }

  /* SMTP */
  var smtpHost = byKey(entries,"SMTP_HOST");
  var smtpPort = byKey(entries,"SMTP_PORT");
  var smtpPass = byKey(entries,"SMTP_PASSWORD");
  var smtpUser = byKey(entries,"SMTP_USER");
  var smtpStrategy = byKey(entries,"SMTP_AUTH_STRATEGY");
  if(smtpPass && smtpPass.value.length>0){
    checkSecret(smtpPass, { label:"SMTP_PASSWORD (mailbox password)", minCritical:12, minStrong:20, genFix:"Change the mailbox password (or app password) at your mail provider to a fresh value of at least 20 characters, update the config, and restart. A leaked SMTP password sends mail as you." });
  }
  if(smtpUser && smtpUser.value.length>0 && (!smtpPass || smtpPass.value.length===0)){
    add("high", smtpUser, "SMTP_PASSWORD", null, "SMTP user is set but SMTP_PASSWORD is missing", "Mealie will try to send mail with a username and no password, which fails — or worse, the server accepts unauthenticated relay.", "Set SMTP_PASSWORD to the mailbox (or app) password, or remove SMTP_USER if mail is intentionally unauthenticated on a private network.");
  }
  if(smtpHost){
    var strat = smtpStrategy ? smtpStrategy.value.toUpperCase() : "";
    var portNum = smtpPort ? parseInt(smtpPort.value,10) : NaN;
    if(portNum===25 && strat!=="TLS" && strat!=="SSL"){
      add("medium", smtpPort||smtpHost, "SMTP_PORT", null, "SMTP uses port 25 with no TLS strategy", "Port 25 without SMTP_AUTH_STRATEGY=TLS or SSL sends credentials and message content unencrypted, and many networks block or flag it.", "Use port 587 with SMTP_AUTH_STRATEGY=TLS (or 465 with SSL) and set the matching SMTP_PASSWORD.");
    } else if(smtpStrategy && (strat==="TLS" || strat==="SSL")){
      pass("SMTP_HOST", smtpHost, "SMTP is configured with a TLS/SSL strategy.");
    } else if(portNum===587 || portNum===465){
      add("low", smtpPort, "SMTP_AUTH_STRATEGY", null, "SMTP port implies TLS but no strategy is stated", "The port suggests encryption, but Mealie's behavior is set by SMTP_AUTH_STRATEGY, which is absent.", "Set SMTP_AUTH_STRATEGY=TLS for port 587 (or SSL for port 465) so the intent is explicit.");
    }
  }

  /* Debug / misc */
  var dbg = byKey(entries,"DEBUG");
  if(dbg && truthy(dbg.value)) add("high", dbg, "DEBUG", null, "Debug mode is enabled", "Debug output leaks paths, settings, and stack traces to anyone who can trigger an error.", "Remove DEBUG or set it to false for a deployed server.");
  var prod = byKey(entries,"PRODUCTION");
  if(prod && falsy(prod.value)) add("medium", prod, "PRODUCTION", null, "PRODUCTION is set to false", "Non-production mode can enable development behaviors and verbose errors.", "Set PRODUCTION=true for a deployed server.");

  /* Generic sweep: any other secret-shaped key not already handled */
  var handled = {"SECRET_KEY":1,"POSTGRES_PASSWORD":1,"SMTP_PASSWORD":1,"OIDC_CLIENT_SECRET":1,"LDAP_BIND_PASSWORD":1,"DATABASE_URL":1};
  for(var j=0;j<entries.length;j++){
    var e = entries[j];
    if(handled[e.key]) continue;
    if(/(PASSWORD|SECRET|TOKEN|PRIVATE_KEY|API_KEY|ACCESS_KEY)/.test(e.key) && e.value.length>0){
      (function(entry){
        checkSecret(entry, { label: entry.key, minCritical:12, minStrong:24, genFix:"Rotate this value wherever it was issued, store a fresh value of at least 24 characters in the config only, and restart the service." });
      })(e);
    }
  }

  /* Duplicates */
  var seen = {};
  for(var k=0;k<entries.length;k++){
    if(seen[entries[k].key]) add("low", entries[k], entries[k].key, null, "Key appears more than once", "Only one of the values will win, depending on the loader — the other is dead text that invites mistakes.", "Remove the duplicate line and keep the single intended value.");
    seen[entries[k].key] = 1;
  }

  /* Verdict */
  var counts = { critical:0, high:0, medium:0, low:0, info:0 };
  for(var f=0;f<findings.length;f++) counts[findings[f].severity]++;
  var verdict, verdictClass, verdictDetail;
  if(entries.length < 3 || knownCount < 2){
    verdict = "NOT ENOUGH TO GRADE"; verdictClass = "v-na";
    verdictDetail = "Only "+entries.length+" setting(s) parsed, "+knownCount+" of them recognized Mealie keys. Paste the server's environment block (or load an example) for a gradeable audit.";
  } else if(counts.critical > 0){
    verdict = "DO NOT DEPLOY"; verdictClass = "v-dnd";
    verdictDetail = counts.critical+" critical problem(s) would put accounts, the database, or the server itself at risk on day one. Fix every critical finding, then re-audit.";
  } else if(counts.high > 0 || counts.medium > 0){
    verdict = "DEPLOY WITH FIXES"; verdictClass = "v-fixes";
    verdictDetail = "No critical problems, but "+(counts.high+counts.medium)+" high/medium finding(s) should be fixed before this server faces the internet.";
  } else {
    verdict = "SAFE TO DEPLOY"; verdictClass = "v-safe";
    verdictDetail = "No critical, high, or medium findings. The audited settings follow the hardened pattern. This is a heuristic text audit, not a guarantee — keep secrets private and Mealie updated.";
  }
  var sevRank = { critical:0, high:1, medium:2, low:3, info:4 };
  findings.sort(function(a,b){ var d = sevRank[a.severity]-sevRank[b.severity]; if(d!==0) return d; return (a.line||9999)-(b.line||9999); });
  return { entries: entries, knownCount: knownCount, findings: findings, passes: passes, counts: counts, verdict: verdict, verdictClass: verdictClass, verdictDetail: verdictDetail };
}

/* ---------- Rendering (never interpolates secret values) ---------- */
var els = {};
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-mealie-server-config-safety-auditortm',
  name: 'J-Dawgs Mealie Server Config Safety Auditor',
  description: 'Host tools only tell you the server started; ours grades a pasted Mealie config offline into one deploy verdict — secrets by key name/line/length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
