'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs NiFi Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var RISKY_EXAMPLE = [
        "# Risky sample nifi.properties (demo data - not a real server)",
        "nifi.web.http.host=0.0.0.0",
        "nifi.web.http.port=8080",
        "nifi.web.http.network.interface.default=*",
        "nifi.security.needClientAuth=false",
        "nifi.security.user.authorizer=",
        "nifi.sensitive.props.key=short",
        "nifi.security.keystorePasswd=St0rePass!demo",
        "nifi.cluster.is.node=true",
        "nifi.cluster.node.protocol.port=11443",
        "nifi.cluster.node.protocol.threads=10",
        "nifi.remote.input.http.enabled=true",
        "nifi.remote.input.secure=false",
        "nifi.provenance.repository.directory.default=./provenance_repository",
        "nifi.content.repository.directory.default=./content_repository",
        "#nifi.web.https.host=nifi.internal",
        "#nifi.web.https.port=8443",
        "nifi.flow.configuration.file=./conf/flow.xml.gz",
        "nifi.flow.configuration.file=./conf/flow2.xml.gz",
        "this line has no separator and cannot be parsed"
      ].join("\n");

      var HARDENED_EXAMPLE = [
        "# Hardened sample nifi.properties (demo data - not a real server)",
        "nifi.web.https.host=nifi.internal.example",
        "nifi.web.https.port=8443",
        "nifi.security.needClientAuth=true",
        "nifi.security.user.authorizer=managed-authorizer",
        "nifi.security.user.login.identity.provider=ldap-provider",
        "nifi.sensitive.props.key=K7f9Qz2Lm8Xw4Rt6Yb1Np3Hs",
        "nifi.security.keystore=/opt/nifi/conf/keystore.jks",
        "nifi.security.keystoreType=JKS",
        "nifi.cluster.is.node=true",
        "nifi.cluster.node.protocol.port=11443",
        "nifi.cluster.protocol.is.secure=true",
        "nifi.remote.input.http.enabled=false",
        "nifi.remote.input.secure=true",
        "nifi.remote.input.socket.port=10443",
        "nifi.provenance.repository.directory.default=/data/nifi/provenance_repository",
        "nifi.content.repository.directory.default=/data/nifi/content_repository",
        "nifi.flow.configuration.file=/opt/nifi/conf/flow.xml.gz"
      ].join("\n");

      var KNOWN_EXAMPLE_KEYS = [
        "thisisabadkey", "thisisabadsensitivekey", "supersecretkey", "supersecretnifikey",
        "changeme", "change-me", "password", "examplekey", "example-key", "nifikey",
        "nifi-sensitive-key", "123456789012", "1234567890abcdef", "aaaaaaaaaaaaaaaa",
        "yourkeyhere", "insertkeyhere", "testkey123456"
      ];

      var NON_SECRET_KEY_KEYS = {
        "nifi.security.keystore": true,
        "nifi.security.keystoretype": true,
        "nifi.security.truststore": true,
        "nifi.security.truststoretype": true,
        "nifi.sensitive.props.key": true,
        "nifi.sensitive.props.algorithm": true
      };

      var SEV_ORDER = { BLOCKER: 0, HIGH: 1, MEDIUM: 2, LOW: 3, INFO: 4 };

      function $(id) { return document.getElementById(id); }
      function esc(s) {
        return String(s).replace(/[&<>"']/g, function (c) {
          return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
        });
      }
      function trim(s) { return s.replace(/^\s+|\s+$/g, ""); }

      function parseProperties(text) {
        var lines = String(text == null ? "" : text).split(/\r\n|\r|\n/);
        var entries = {};       // key -> {key, value, line}
        var order = [];
        var duplicates = [];    // {key, firstLine, line}
        var commented = [];     // {key, line}
        var notParsed = [];     // {line}
        var blank = 0;
        for (var i = 0; i < lines.length; i++) {
          var lineNo = i + 1;
          var raw = lines[i];
          var t = trim(raw);
          if (t === "") { blank++; continue; }
          var first = t.charAt(0);
          if (first === "#" || first === "!") {
            var body = trim(t.replace(/^[#!\s]+/, ""));
            var cm = body.match(/^([A-Za-z0-9_.\-]+)\s*[=:]/);
            if (cm) commented.push({ key: cm[1], line: lineNo });
            continue;
          }
          var eq = raw.indexOf("=");
          var co = raw.indexOf(":");
          var sep = -1;
          if (eq === -1) sep = co; else if (co === -1) sep = eq; else sep = Math.min(eq, co);
          if (sep === -1) { notParsed.push({ line: lineNo }); continue; }
          var key = trim(raw.slice(0, sep));
          var value = trim(raw.slice(sep + 1));
          if (key === "") { notParsed.push({ line: lineNo }); continue; }
          if (Object.prototype.hasOwnProperty.call(entries, key)) {
            duplicates.push({ key: key, firstLine: entries[key].line, line: lineNo });
            entries[key].value = value;
            entries[key].line = lineNo;
          } else {
            entries[key] = { key: key, value: value, line: lineNo };
            order.push(key);
          }
        }
        return {
          entries: entries, order: order, duplicates: duplicates,
          commented: commented, notParsed: notParsed,
          totalLines: lines.length, blankLines: blank
        };
      }

      function get(parsed, key) {
        return Object.prototype.hasOwnProperty.call(parsed.entries, key) ? parsed.entries[key] : null;
      }
      function isSet(parsed, key) {
        var e = get(parsed, key);
        return !!e && e.value !== "";
      }
      function isTrue(parsed, key) {
        var e = get(parsed, key);
        return !!e && e.value.toLowerCase() === "true";
      }
      function looksLikePath(v) {
        return v.indexOf("/") !== -1 || v.indexOf("\\") !== -1 ||
          /\.(jks|p12|pfx|pem|crt|keystore|truststore)$/i.test(v);
      }

      function audit(text) {
        var parsed = parseProperties(text);
        var findings = [];
        function add(severity, key, line, message, fix) {
          findings.push({ severity: severity, key: key || null, line: line || null, message: message, fix: fix || null });
        }

        var nifiCount = 0;
        for (var i = 0; i < parsed.order.length; i++) {
          if (parsed.order[i].indexOf("nifi.") === 0) nifiCount++;
        }

        var result = {
          parsed: parsed, findings: findings, nifiCount: nifiCount,
          verdict: "NOT ENOUGH TO GRADE", verdictClass: "unknown", why: ""
        };

        if (trim(String(text || "")) === "") {
          result.ungradeable = true;
          result.why = "The paste is empty. Paste a nifi.properties file to grade it.";
          return finish(result);
        }
        if (nifiCount === 0) {
          result.ungradeable = true;
          result.why = "No active nifi.* properties were found, so this does not look like a nifi.properties file. Commented-out lines do not count.";
          return finish(result);
        }

        /* ---- Web UI listener: plain HTTP while HTTPS is absent ---- */
        var httpsConfigured = isSet(parsed, "nifi.web.https.port") || isSet(parsed, "nifi.web.https.host");
        var httpHost = get(parsed, "nifi.web.http.host");
        var httpPort = get(parsed, "nifi.web.http.port");
        var httpActive = isSet(parsed, "nifi.web.http.port") || isSet(parsed, "nifi.web.http.host");
        if (httpActive && !httpsConfigured) {
          var hostVal = httpHost ? httpHost.value : "";
          var allInterfaces = hostVal === "" || hostVal === "0.0.0.0" || hostVal === "::";
          var anchor = httpPort && httpPort.value !== "" ? httpPort : httpHost;
          if (allInterfaces && isSet(parsed, "nifi.web.http.port")) {
            add("BLOCKER", "nifi.web.http.host", anchor.line,
              "The web UI is served over plain HTTP on all network interfaces (nifi.web.http.host is " +
              (hostVal === "" ? "blank" : hostVal) + " with an HTTP port set) and no HTTPS host/port is configured. " +
              "Credentials and flow data cross the network unencrypted, reachable by anyone who can reach the host.",
              "Serve the UI over HTTPS only: set nifi.web.https.host and nifi.web.https.port with a real keystore, and clear nifi.web.http.host / nifi.web.http.port.");
          } else {
            add("HIGH", "nifi.web.http.host", anchor.line,
              "The web UI is served over plain HTTP (nifi.web.http.host is set) and no HTTPS host/port is configured. Traffic to the UI is unencrypted.",
              "Move the UI to HTTPS: set nifi.web.https.host and nifi.web.https.port, then remove the plain HTTP listener.");
          }
        }
        if (httpActive && httpsConfigured) {
          add("MEDIUM", "nifi.web.http.port", (httpPort || httpHost).line,
            "Both a plain HTTP listener and an HTTPS listener are configured. The HTTP listener is an unencrypted way into the same UI.",
            "Remove nifi.web.http.host / nifi.web.http.port once HTTPS is confirmed working.");
        }

        /* ---- Wildcard network interfaces ---- */
        for (var k = 0; k < parsed.order.length; k++) {
          var key = parsed.order[k];
          if (key.indexOf("network.interface.") !== -1) {
            var e = parsed.entries[key];
            if (e.value === "*" || e.value === "0.0.0.0" || e.value === "::") {
              add("HIGH", key, e.line,
                "Network interface binding " + key + " is a wildcard (" + e.value + "), so the listener binds every interface on the machine, including ones you did not mean to expose.",
                "Bind the named interface explicitly (for example eth0) or leave the interface property unset and control exposure with the host setting and firewall rules.");
            }
          }
        }

        /* ---- Client auth + authorizer posture ---- */
        var nca = get(parsed, "nifi.security.needClientAuth");
        if (nca && nca.value.toLowerCase() === "false") {
          add("HIGH", "nifi.security.needClientAuth", nca.line,
            "nifi.security.needClientAuth=false: the server does not require client certificates, so anything with network reach and a login path can attempt access without a machine credential.",
            "Set nifi.security.needClientAuth=true for clustered / secured deployments, or confirm an equivalent control (identity provider plus authorizer) is deliberately in place.");
        }
        if (!nca && httpsConfigured) {
          add("INFO", "nifi.security.needClientAuth", null,
            "nifi.security.needClientAuth is not present in the paste, so this tool cannot confirm whether client certificates are required.",
            "Set nifi.security.needClientAuth explicitly so the posture is reviewed, not inherited.");
        }
        var authz = get(parsed, "nifi.security.user.authorizer");
        if (!authz || authz.value === "") {
          add("MEDIUM", "nifi.security.user.authorizer", authz ? authz.line : null,
            "No user authorizer is configured (nifi.security.user.authorizer is " + (authz ? "blank" : "missing") + "), so fine-grained access control for the UI and API is not established by this file.",
            "Set nifi.security.user.authorizer (for example managed-authorizer) and define the initial admin identity.");
        }

        /* ---- Sensitive properties key ---- */
        var spk = get(parsed, "nifi.sensitive.props.key");
        if (!spk) {
          add("BLOCKER", "nifi.sensitive.props.key", null,
            "nifi.sensitive.props.key is missing. Sensitive flow properties have no key to be protected with in this configuration.",
            "Set nifi.sensitive.props.key to a long, random, unique value kept out of source control.");
        } else if (spk.value === "") {
          add("BLOCKER", "nifi.sensitive.props.key", spk.line,
            "nifi.sensitive.props.key is present but empty (line " + spk.line + ", length 0). Sensitive properties are effectively unprotected.",
            "Set nifi.sensitive.props.key to a long, random, unique value.");
        } else if (KNOWN_EXAMPLE_KEYS.indexOf(spk.value.toLowerCase()) !== -1) {
          add("BLOCKER", "nifi.sensitive.props.key", spk.line,
            "nifi.sensitive.props.key (line " + spk.line + ", length " + spk.value.length + ") matches a known published example value. Anyone who has read the docs can decrypt the sensitive properties. The value itself is never shown by this tool.",
            "Replace it with a long, random, unique value generated for this server only.");
        } else if (spk.value.length < 12) {
          add("BLOCKER", "nifi.sensitive.props.key", spk.line,
            "nifi.sensitive.props.key (line " + spk.line + ") is only " + spk.value.length + " characters long — too short to protect sensitive properties against guessing. The value itself is never shown by this tool.",
            "Use a random value of at least 12 characters; longer is better.");
        }

        /* ---- Plaintext secrets in any password / key property ---- */
        for (var s = 0; s < parsed.order.length; s++) {
          var skey = parsed.order[s];
          var sentry = parsed.entries[skey];
          if (sentry.value === "") continue;
          if (sentry.value.indexOf("${") === 0) continue; // externalized reference, not a literal secret
          var lk = skey.toLowerCase();
          var isPasswordKey = lk.indexOf("password") !== -1 || lk.indexOf("passwd") !== -1;
          var isKeyKey = lk.indexOf("key") !== -1 && !NON_SECRET_KEY_KEYS[lk];
          if (!isPasswordKey && !isKeyKey) continue;
          if (looksLikePath(sentry.value)) continue;
          add(isPasswordKey ? "HIGH" : "MEDIUM", skey, sentry.line,
            "Plaintext secret stored in the properties file under " + skey + " (line " + sentry.line + ", value length " + sentry.value.length + "). Anyone who can read this file has the secret. The value itself is never shown by this tool.",
            "Move the secret out of the plain properties file (protected / encrypted configuration or an external secrets source) and rotate it, since it has sat in plaintext.");
        }

        /* ---- Cluster posture ---- */
        if (isTrue(parsed, "nifi.cluster.is.node")) {
          var protoPort = get(parsed, "nifi.cluster.node.protocol.port");
          var protoThreads = get(parsed, "nifi.cluster.node.protocol.threads");
          var clusterSecure = isTrue(parsed, "nifi.cluster.protocol.is.secure");
          if (protoPort && protoPort.value !== "" && !clusterSecure) {
            add("HIGH", "nifi.cluster.node.protocol.port", protoPort.line,
              "This node joins a cluster (nifi.cluster.is.node=true) with a cluster protocol port set" +
              (protoThreads ? " and nifi.cluster.node.protocol.threads set at line " + protoThreads.line : "") +
              ", but nifi.cluster.protocol.is.secure is not true — node-to-node cluster traffic runs without the secure cluster protocol settings.",
              "Set nifi.cluster.protocol.is.secure=true with the cluster keystore/truststore configured, so nodes authenticate each other over TLS.");
          }
          if (!protoPort || protoPort.value === "") {
            add("INFO", "nifi.cluster.node.protocol.port", null,
              "nifi.cluster.is.node=true but no nifi.cluster.node.protocol.port appears in the paste, so the cluster protocol listener cannot be confirmed from this file.",
              "Set nifi.cluster.node.protocol.port explicitly for clustered nodes.");
          }
        }

        /* ---- Site-to-site over plain HTTP ---- */
        if (isTrue(parsed, "nifi.remote.input.http.enabled") && !isTrue(parsed, "nifi.remote.input.secure")) {
          var rih = get(parsed, "nifi.remote.input.http.enabled");
          var ris = get(parsed, "nifi.remote.input.secure");
          add("HIGH", "nifi.remote.input.http.enabled", rih.line,
            "Site-to-site is enabled over HTTP (nifi.remote.input.http.enabled=true) while nifi.remote.input.secure is " +
            (ris ? ris.value : "not set") + " — data moving between NiFi instances crosses the network unencrypted and unauthenticated by certificate.",
            "Set nifi.remote.input.secure=true and use the secure site-to-site port with certificates, or disable HTTP site-to-site input.");
        }

        /* ---- Default repository paths (INFO) ---- */
        var repoChecks = [
          ["nifi.provenance.repository.directory.default", "./provenance_repository", "provenance repository"],
          ["nifi.content.repository.directory.default", "./content_repository", "content repository"],
          ["nifi.flowfile.repository.directory", "./flowfile_repository", "FlowFile repository"],
          ["nifi.database.directory", "./database_repository", "database repository"]
        ];
        for (var r = 0; r < repoChecks.length; r++) {
          var re = get(parsed, repoChecks[r][0]);
          if (re && re.value.replace(/\/$/, "") === repoChecks[r][1]) {
            add("INFO", repoChecks[r][0], re.line,
              "The " + repoChecks[r][2] + " sits on the default path " + repoChecks[r][1] + " inside the install directory. Not a security hole by itself, but default paths fill the install disk and are the first place anyone looks.",
              "Point it at a dedicated volume sized for retention, especially in production.");
          }
        }

        /* ---- Duplicates ---- */
        for (var d = 0; d < parsed.duplicates.length; d++) {
          var dup = parsed.duplicates[d];
          add("MEDIUM", dup.key, dup.line,
            "Duplicate key " + dup.key + ": set on line " + dup.firstLine + " and again on line " + dup.line + ". The last value wins, so the line " + dup.firstLine + " setting is silently ignored.",
            "Remove the earlier of the two lines so the file says one thing.");
        }

        return finish(result);
      }

      function finish(result) {
        var findings = result.findings;
        findings.sort(function (a, b) {
          var sa = SEV_ORDER[a.severity], sb = SEV_ORDER[b.severity];
          if (sa !== sb) return sa - sb;
          return (a.line || 0) - (b.line || 0);
        });
        if (result.ungradeable) return result;
        var blockers = 0, fixable = 0;
        for (var i = 0; i < findings.length; i++) {
          if (findings[i].severity === "BLOCKER") blockers++;
          else if (findings[i].severity !== "INFO") fixable++;
        }
        if (blockers > 0) {
          result.verdict = "DO NOT DEPLOY"; result.verdictClass = "dont";
          result.why = blockers + (blockers === 1 ? " blocker" : " blockers") + " must be resolved before this config goes anywhere near a server.";
        } else if (fixable > 0) {
          result.verdict = "DEPLOY WITH FIXES"; result.verdictClass = "fixes";
          result.why = "No blockers, but " + fixable + (fixable === 1 ? " finding needs" : " findings need") + " fixing first.";
        } else {
          result.verdict = "SAFE TO DEPLOY"; result.verdictClass = "safe";
          result.why = findings.length === 0
            ? "No check tripped on the pasted file."
            : "No blockers and nothing to fix — only informational notes below.";
        }
        return result;
      }

      function buildTextReport(result) {
        var p = result.parsed;
        var out = [];
        out.push("J-Dawgs NiFi Server Config Safety Auditor - Report");
        out.push("Verdict: " + result.verdict);
        if (result.why) out.push("Why: " + result.why);
        out.push("Lines read: " + p.totalLines + " | Active properties: " + p.order.length +
          " | nifi.* properties: " + result.nifiCount +
          " | Commented-out property lines: " + p.commented.length +
          " | Not parsed: " + p.notParsed.length +
          " | Duplicate keys: " + p.duplicates.length);
        out.push("");
        out.push("FINDINGS");
        if (result.findings.length === 0) out.push("(none)");
        for (var i = 0; i < result.findings.length; i++) {
          var f = result.findings[i];
          out.push("[" + f.severity + "] " + (f.line ? "Line " + f.line : "No line (setting absent)") +
            (f.key ? " | " + f.key : "") + " - " + f.message);
        }
        out.push("");
        out.push("FIX LIST");
        var fixes = result.findings.filter(function (f) { return f.fix && f.severity !== "INFO"; });
        if (fixes.length === 0) out.push("(nothing to fix)");
        for (var j = 0; j < fixes.length; j++) {
          out.push((j + 1) + ". " + (fixes[j].key ? fixes[j].key + ": " : "") + fixes[j].fix);
        }
        out.push("");
        out.push("COMMENTED OUT (not active, never graded as set)");
        if (p.commented.length === 0) out.push("(none)");
        for (var c = 0; c < p.commented.length; c++) {
          out.push("Line " + p.commented[c].line + ": " + p.commented[c].key + " - COMMENTED / NOT ACTIVE");
        }
        out.push("");
        out.push("NOT PARSED");
        if (p.notParsed.length === 0) out.push("(none)");
        for (var n = 0; n < p.notParsed.length; n++) {
          out.push("Line " + p.notParsed[n].line + ": NOT PARSED");
        }
        out.push("");
        out.push("Note: secret values never appear in this report. Secrets are identified by key name, line number, and value length only.");
        return out.join("\n");
      }

      function buildJsonReport(result) {
        var p = result.parsed;
        var obj = {
          tool: "J-Dawgs NiFi Server Config Safety Auditor",
          verdict: result.verdict,
          why: result.why,
          counts: {
            linesRead: p.totalLines,
            activeProperties: p.order.length,
            nifiProperties: result.nifiCount,
            commentedOutPropertyLines: p.commented.length,
            notParsedLines: p.notParsed.length,
            duplicateKeys: p.duplicates.length
          },
          findings: result.findings.map(function (f) {
            return { severity: f.severity, key: f.key, line: f.line, message: f.message, fix: f.fix };
          }),
          fixList: result.findings
            .filter(function (f) { return f.fix && f.severity !== "INFO"; })
            .map(function (f) { return { key: f.key, line: f.line, fix: f.fix }; }),
          commentedOut: p.commented.map(function (c) {
            return { key: c.key, line: c.line, status: "COMMENTED / NOT ACTIVE" };
          }),
          notParsed: p.notParsed.map(function (n) {
            return { line: n.line, status: "NOT PARSED" };
          }),
          duplicates: p.duplicates.map(function (d) {
            return { key: d.key, firstLine: d.firstLine, line: d.line, resolution: "last value wins" };
          }),
          secretHandling: "Secret values never appear in this report; secrets are identified by key name, line number, and value length only."
        };
        return JSON.stringify(obj, null, 2);
      }

      function render(result) {
        var p = result.parsed;
        $("results").classList.remove("hidden");
        $("reports-card").classList.remove("hidden");
        var box = $("verdict-box");
        box.className = "verdict " + result.verdictClass;
        $("verdict-text").textContent = result.verdict;
        $("verdict-why").textContent = result.why || "";

        var counts = { BLOCKER: 0, HIGH: 0, MEDIUM: 0, LOW: 0, INFO: 0 };
        result.findings.forEach(function (f) { counts[f.severity]++; });
        var stats = [
          ["Lines read", p.totalLines],
          ["Active properties", p.order.length],
          ["nifi.* properties", result.nifiCount],
          ["Blockers", counts.BLOCKER],
          ["High", counts.HIGH],
          ["Medium", counts.MEDIUM],
          ["Info", counts.INFO],
          ["Commented out", p.commented.length],
          ["Not parsed", p.notParsed.length],
          ["Duplicates", p.duplicates.length]
        ];
        $("stats").innerHTML = stats.map(function (s) {
          return '<span class="stat">' + esc(s[0]) + ' <b>' + esc(s[1]) + "</b></span>";
        }).join("");

        var fwrap = $("findings");
        if (result.findings.length === 0) {
          fwrap.innerHTML = "";
          $("no-findings").classList.remove("hidden");
        } else {
          $("no-findings").classList.add("hidden");
          fwrap.innerHTML = result.findings.map(function (f) {
            return '<article class="finding">' +
              '<div class="top"><span class="chip ' + f.severity + '">' + f.severity + "</span>" +
              '<span class="loc">' + (f.line ? "Line " + f.line : "Setting absent") + "</span>" +
              (f.key ? '<span class="key">' + esc(f.key) + "</span>" : "") + "</div>" +
              '<p class="msg">' + esc(f.message) + "</p>" +
              (f.fix ? '<p class="fix"><b>Fix:</b> ' + esc(f.fix) + "</p>" : "") +
              "</article>";
          }).join("");
        }

        var fixes = result.findings.filter(function (f) { return f.fix && f.severity !== "INFO"; });
        if (fixes.length === 0) {
          $("fixlist").innerHTML = "";
          $("no-fixes").classList.remove("hidden");
        } else {
          $("no-fixes").classList.add("hidden");
          $("fixlist").innerHTML = fixes.map(function (f) {
            return "<li>" + (f.key ? '<span class="mono">' + esc(f.key) + "</span> — " : "") + esc(f.fix) + "</li>";
          }).join("");
        }

        if (p.commented.length === 0) {
          $("commented-list").innerHTML = "";
          $("no-commented").classList.remove("hidden");
        } else {
          $("no-commented").classList.add("hidden");
          $("commented-list").innerHTML = p.commented.map(function (c) {
            return "<li>Line " + c.line + ': <span class="mono">' + esc(c.key) + "</span> — COMMENTED / NOT ACTIVE</li>";
          }).join("");
        }

        if (p.notParsed.length === 0) {
          $("notparsed-list").innerHTML = "";
          $("no-notparsed").classList.remove("hidden");
        } else {
          $("no-notparsed").classList.add("hidden");
          $("notparsed-list").innerHTML = p.notParsed.map(function (n) {
            return "<li>Line " + n.line + ": NOT PARSED — no key/value separator on this line.</li>";
          }).join("");
        }

        $("report-text").value = buildTextReport(result);
        $("report-json").value = buildJsonReport(result);
      }

      function grade() {
        render(audit($("input").value));
      }

      function updateStats() {
        var v = $("input").value;
        var lines = v === "" ? 0 : v.split(/\r\n|\r|\n/).length;
        $("input-stats").textContent = lines + (lines === 1 ? " line" : " lines") + " · " + v.length + " characters · graded locally, nothing leaves the page";
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined), "KNOWN_EXAMPLE_KEYS": (typeof KNOWN_EXAMPLE_KEYS !== 'undefined' ? KNOWN_EXAMPLE_KEYS : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-nifi-server-config-safety-auditortm-2',
  name: 'J-Dawgs NiFi Server Config Safety Auditor',
  description: '',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"], "KNOWN_EXAMPLE_KEYS": __core["KNOWN_EXAMPLE_KEYS"] }
};
