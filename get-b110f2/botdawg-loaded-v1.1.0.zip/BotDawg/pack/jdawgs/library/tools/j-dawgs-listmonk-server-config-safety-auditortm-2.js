'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Listmonk Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

var RISKY = [
'# RISKY EXAMPLE — for audit practice only',
'[app]',
'address = "0.0.0.0:9000"',
'root_url = "http://lists.example.com"',
'admin_username = "admin"',
'admin_password = "admin123"',
'[db]',
'host = "db.example.com"',
'port = 5432',
'user = "postgres"',
'password = "dbpass123"',
'ssl_mode = "disable"',
'tls_skip_verify = true',
'[smtp]',
'host = "mail.example.com"',
'username = "mailer@example.com"',
'password = "smtp-secret-999"',
'tls_type = "none"',
'[privacy]',
'allow_signup = true',
'[upload]',
'provider = "filesystem"',
'max_file_size = 104857600',
'allowed_extensions = "exe, sh, php, zip"',
'[cors]',
'allow_origins = "*"'
].join('\n');

var HARDENED = [
'# HARDENED EXAMPLE — secrets referenced from the environment',
'[app]',
'address = "127.0.0.1:9000"',
'root_url = "https://lists.example.com"',
'admin_username = "list-admin-ops"',
'admin_password = "${LISTMONK_ADMIN_PASSWORD}"',
'[db]',
'host = "127.0.0.1"',
'port = 5432',
'user = "listmonk_app"',
'password = "${LISTMONK_DB_PASSWORD}"',
'ssl_mode = "require"',
'tls_skip_verify = false',
'[smtp]',
'host = "mail.example.com"',
'username = "mailer@example.com"',
'password = "${LISTMONK_SMTP_PASSWORD}"',
'tls_type = "STARTTLS"',
'[privacy]',
'allow_signup = false',
'[upload]',
'provider = "s3"',
'max_file_size = 5242880',
'allowed_extensions = "png, jpg, pdf"',
'[cors]',
'allow_origins = "https://lists.example.com"'
].join('\n');

var GIBBERISH = 'the quick brown fox\nnot a config at all\njust some plain words';
var PLANTED_SECRETS = ['admin123','dbpass123','smtp-secret-999'];
var COMMON_PASSWORDS = ['admin','admin123','password','password1','password123','changeme','change-me','letmein','123456','12345678','123456789','qwerty','secret','test','demo','default','listmonk','postgres','root','welcome','mail'];
var DEFAULT_USERS = ['admin','administrator','root','user','test','demo','postgres','listmonk'];
var DANGEROUS_EXTS = ['exe','sh','bash','php','js','mjs','bat','cmd','com','jar','war','ps1','html','htm','py','rb','pl'];

function isEnvRef(v){
  if(!v) return false;
  return /^\$\{[^}]+\}$/.test(v) || /^\$[A-Za-z_][A-Za-z0-9_]*$/.test(v) || v.indexOf('env:')===0 || v.indexOf('file:')===0 || v.indexOf('vault:')===0;
}
function isSecretKey(e){
  var k=e.keyLower;
  return k.indexOf('password')>-1 || k.indexOf('passwd')>-1 || k==='pwd' || k.indexOf('secret')>-1 || k.indexOf('api_key')>-1 || k.indexOf('apikey')>-1 || k.indexOf('access_key')>-1 || k.indexOf('private_key')>-1 || k.indexOf('auth_token')>-1;
}
function parseConfig(text){
  var lines=String(text||'').split(/\r?\n/);
  var entries=[]; var section='';
  for(var i=0;i<lines.length;i++){
    var raw=lines[i]; var t=raw.trim();
    if(!t || t.charAt(0)==='#' || t.indexOf('//')===0) continue;
    var sec=t.match(/^\[([^\]]+)\]\s*$/);
    if(sec){ section=sec[1].trim().toLowerCase(); continue; }
    var eq=raw.indexOf('=');
    if(eq===-1){
      // .env style with colon is rare; also support KEY:value only if key-like
      continue;
    }
    var key=raw.slice(0,eq).trim();
    if(!key || /\s/.test(key)) continue;
    var valRaw=raw.slice(eq+1).trim();
    var val=valRaw;
    var q=valRaw.match(/^"([^"]*)"/) || valRaw.match(/^'([^']*)'/);
    if(q){ val=q[1]; }
    else{
      var hash=val.indexOf(' #');
      if(hash>-1) val=val.slice(0,hash).trim();
      val=val.replace(/,+$/,'').trim();
      var q2=val.match(/^"([^"]*)"$/) || val.match(/^'([^']*)'$/);
      if(q2) val=q2[1];
    }
    // env-style keys like LISTMONK_DB__PASSWORD imply a section
    var effSection=section;
    var keyLower=key.toLowerCase();
    var fullKey=(effSection?effSection+'.':'')+key;
    entries.push({line:i+1, section:effSection, key:key, keyLower:keyLower, fullKey:fullKey, fullLower:fullKey.toLowerCase(), value:val, valueLower:String(val).toLowerCase()});
  }
  return {entries:entries, lineCount:lines.length};
}
function recognizedCount(entries){
  var re=/(app|db|database|smtp|admin|root_url|rooturl|address|upload|media|cors|privacy|signup|sign_up|tls|ssl|host|user|password|mail)/;
  var n=0;
  entries.forEach(function(e){ if(re.test(e.fullLower)) n++; });
  return n;
}

function audit(text){
  var parsed=parseConfig(text);
  var entries=parsed.entries;
  var findings=[];
  function add(sev,line,key,issue,fix,len){
    var f={severity:sev, line:(line==null?null:line), key:key, issue:issue, fix:fix};
    if(typeof len==='number') f.valueLength=len;
    findings.push(f);
  }
  if(entries.length<3 || recognizedCount(entries)<3){
    return {verdict:'NOT ENOUGH TO GRADE', findings:[], entries:entries.length, lines:parsed.lineCount,
      note:'Fewer than three recognizable Listmonk config settings were found. Paste a fuller config.toml or .env — a verdict needs at least the app, database, or credential settings to grade.'};
  }
  function findAll(test){ return entries.filter(test); }
  function first(test){ var r=findAll(test); return r.length?r[0]:null; }
  var handledPwLines={};

  function passwordFinding(e, label, missingKey, missingLine){
    // returns nothing; pushes finding as needed. e may be null (missing).
    if(!e){
      add('HIGH', null, missingKey, 'No '+label+' password setting was found in the pasted config.', 'Set a long, unique '+label+' password — or reference one from the environment (for example password = "${LISTMONK_'+label.toUpperCase().replace(/[^A-Z]/g,'')+'_PASSWORD}") — so the credential exists without being guessed or left unset.');
      return;
    }
    handledPwLines[e.line]=true;
    var v=e.value;
    if(isEnvRef(v)) return;
    if(v===''){
      add('CRITICAL', e.line, e.fullKey, 'The '+label+' password is present but empty.', 'Set a long, unique password, or reference one from the environment instead of leaving it blank.', 0);
      return;
    }
    if(COMMON_PASSWORDS.indexOf(e.valueLower)>-1 || v.length<12){
      add('CRITICAL', e.line, e.fullKey, 'The '+label+' password is short or a well-known example value, and it is written in plaintext in the config (value hidden; length '+v.length+').', 'Replace it with a unique password of at least 16 characters from a password manager, and reference it from the environment or a secrets file instead of writing it into config.toml.', v.length);
      return;
    }
    add('HIGH', e.line, e.fullKey, 'The '+label+' password is stored in plaintext in the config file (value hidden; length '+v.length+').', 'Move the '+label+' password out of the config file into an environment variable or secrets store and reference it (for example password = "${...}") so the file itself holds no usable credential.', v.length);
  }

  // --- App address bind ---
  var addr=first(function(e){ return e.keyLower==='address' || e.keyLower==='addr' || e.keyLower.indexOf('app__address')>-1 || e.keyLower.indexOf('app_address')>-1; });
  if(addr){
    if(addr.value.indexOf('0.0.0.0')>-1 || addr.valueLower.indexOf('[::]')>-1 || addr.value.charAt(0)===':'){
      add('HIGH', addr.line, addr.fullKey, 'The app address binds Listmonk to all network interfaces, so the admin UI is reachable from anywhere the host is reachable.', 'Bind to the loopback interface instead — address = "127.0.0.1:9000" — and put an authenticated HTTPS reverse proxy in front of it.');
    }
  } else {
    add('MEDIUM', null, 'app.address', 'No app address setting was found, so the bind address cannot be confirmed from this config.', 'Set address explicitly to "127.0.0.1:9000" (behind a reverse proxy) rather than relying on a default that may listen on all interfaces.');
  }

  // --- root_url / public URL ---
  var root=first(function(e){ return e.keyLower==='root_url' || e.keyLower==='rooturl' || e.keyLower==='public_url' || e.keyLower==='publicurl' || e.keyLower.indexOf('root_url')>-1; });
  if(root){
    if(root.valueLower.indexOf('http://')===0){
      add('HIGH', root.line, root.fullKey, 'The root / public URL uses http:// instead of https://, so admin logins, password resets, and unsubscribe links travel unencrypted and can be intercepted or rewritten.', 'Serve Listmonk over HTTPS (reverse proxy with a valid certificate) and set root_url to the https:// address.');
    } else if(root.valueLower.indexOf('https://')!==0 && root.value!==''){
      add('MEDIUM', root.line, root.fullKey, 'The root / public URL does not start with https://, so its scheme cannot be confirmed as encrypted.', 'Set root_url to the full https:// address the server is actually served on.');
    }
  } else {
    add('MEDIUM', null, 'app.root_url', 'No root_url / public URL setting was found, so generated links (login, reset, unsubscribe) cannot be confirmed to use HTTPS.', 'Set root_url to the full https:// address the server is served on.');
  }

  // --- Admin username ---
  var adminUser=first(function(e){ return (e.keyLower.indexOf('admin')>-1 && (e.keyLower.indexOf('user')>-1)) || e.keyLower==='admin_username' || e.keyLower==='admin_user'; });
  if(!adminUser){
    add('HIGH', null, 'admin_username', 'No admin username setting was found in the pasted config.', 'Set an explicit, non-obvious admin username in the config (not "admin") so the login account is defined and not the well-known default.');
  } else if(DEFAULT_USERS.indexOf(adminUser.valueLower)>-1){
    add('HIGH', adminUser.line, adminUser.fullKey, 'The admin username is a well-known default / example value that attackers try first.', 'Rename the admin account to a non-obvious username that is not published anywhere.');
  }

  // --- Admin password ---
  var adminPw=first(function(e){ return e.keyLower.indexOf('admin')>-1 && e.keyLower.indexOf('password')>-1; });
  passwordFinding(adminPw, 'admin', 'admin_password', null);

  // --- Database ---
  function isDb(e){ return e.section==='db' || e.section==='database' || e.fullLower.indexOf('db.')===0 || e.keyLower.indexOf('db__')===0 || e.keyLower.indexOf('db_')===0 || e.keyLower.indexOf('database')===0; }
  var dbPw=first(function(e){ return isDb(e) && e.keyLower.indexOf('password')>-1; });
  var dbAny=findAll(isDb);
  if(dbAny.length || dbPw){
    passwordFinding(dbPw, 'database', 'db.password', null);
  }
  var dbUser=first(function(e){ return isDb(e) && (e.keyLower==='user' || e.keyLower==='username' || e.keyLower.indexOf('user')>-1); });
  if(dbUser && DEFAULT_USERS.indexOf(dbUser.valueLower)>-1){
    add('MEDIUM', dbUser.line, dbUser.fullKey, 'The database user is a default or superuser-style account, so a leaked config hands over more database power than Listmonk needs.', 'Create a dedicated database user that owns only the Listmonk database, and use that user in the config.');
  }
  var dbSsl=first(function(e){ return e.keyLower.indexOf('ssl_mode')>-1 || e.keyLower.indexOf('sslmode')>-1 || (isDb(e) && e.keyLower==='ssl'); });
  if(dbSsl && (dbSsl.valueLower==='disable' || dbSsl.valueLower==='disabled' || dbSsl.valueLower==='false' || dbSsl.valueLower==='off')){
    add('HIGH', dbSsl.line, dbSsl.fullKey, 'Database TLS is disabled (ssl_mode is off), so database traffic — including credentials and subscriber data — crosses the network unencrypted.', 'Set ssl_mode = "require" (or "verify-full" with certificates) and enable TLS on the database server.');
  }

  // --- TLS generic ---
  entries.forEach(function(e){
    if(e.keyLower.indexOf('skip_verify')>-1){
      if(e.valueLower==='true' || e.valueLower==='yes' || e.valueLower==='1'){
        add('HIGH', e.line, e.fullKey, 'TLS certificate verification is disabled (skip-verify is on), so the server will accept forged certificates and man-in-the-middle attacks.', 'Set tls_skip_verify = false and install a valid certificate chain instead of skipping verification.');
      }
      return;
    }
    if((e.keyLower.indexOf('tls')>-1 || e.keyLower.indexOf('ssl')>-1) && (e.valueLower==='none' || e.valueLower==='disabled' || e.valueLower==='disable')){
      // smtp tls_type handled with its own wording below; still one finding per line
      if(e.section==='smtp' || e.keyLower.indexOf('tls_type')>-1){
        add('HIGH', e.line, e.fullKey, 'SMTP TLS is turned off (tls_type is "none"), so mail — including password resets — is sent unencrypted and SMTP credentials can be sniffed.', 'Set tls_type = "STARTTLS" (or "TLS") and confirm the mail server presents a valid certificate.');
      } else if(e!==dbSsl){
        add('HIGH', e.line, e.fullKey, 'A TLS setting is disabled, so a connection this config controls runs unencrypted.', 'Enable TLS for this setting (for example tls_type = "STARTTLS" or ssl_mode = "require") and use a valid certificate.');
      }
      return;
    }
    if((e.keyLower==='tls_enabled' || e.keyLower==='enable_tls' || e.keyLower==='use_tls' || e.keyLower==='https_enabled') && (e.valueLower==='false' || e.valueLower==='off' || e.valueLower==='no')){
      add('HIGH', e.line, e.fullKey, 'TLS is explicitly switched off by this setting.', 'Switch TLS on for this setting and serve the affected connection over a valid certificate.');
    }
  });

  // --- SMTP ---
  function isSmtp(e){ return e.section==='smtp' || e.fullLower.indexOf('smtp.')===0 || e.keyLower.indexOf('smtp__')===0 || e.keyLower.indexOf('smtp_')===0; }
  var smtpPw=first(function(e){ return isSmtp(e) && e.keyLower.indexOf('password')>-1; });
  var smtpAny=findAll(isSmtp);
  if(smtpAny.length || smtpPw){
    if(smtpPw) passwordFinding(smtpPw, 'SMTP', 'smtp.password', null);
  }

  // --- Signup / open registration ---
  entries.forEach(function(e){
    if(e.keyLower.indexOf('signup')>-1 || e.keyLower.indexOf('sign_up')>-1 || e.keyLower.indexOf('registration')>-1 || e.keyLower.indexOf('register')>-1){
      if(e.valueLower==='true' || e.valueLower==='yes' || e.valueLower==='enabled' || e.valueLower==='open' || e.valueLower==='1'){
        add('HIGH', e.line, e.fullKey, 'Open signup / public registration is enabled, so anyone who can reach the server can create an account or subscribe endpoints can be abused.', 'Set allow_signup = false for a private instance, and only enable public signup behind rate limits and CAPTCHA if you truly run a public list.');
      }
    }
  });

  // --- CORS ---
  entries.forEach(function(e){
    if(e.keyLower.indexOf('origin')>-1 || e.keyLower.indexOf('cors')>-1){
      if(e.value.indexOf('*')>-1){
        add('HIGH', e.line, e.fullKey, 'CORS is permissive: any website origin is allowed to call this server\'s API from a visitor\'s browser.', 'Restrict CORS to your own exact origin(s) — for example allow_origins = "https://lists.example.com" — and never use "*" on an authenticated admin/API surface.');
      }
    }
  });

  // --- Upload / media ---
  entries.forEach(function(e){
    var inUpload = e.section==='upload' || e.section==='media' || e.keyLower.indexOf('upload')>-1 || e.keyLower.indexOf('media')>-1;
    if(e.keyLower.indexOf('allowed_extensions')>-1 || e.keyLower.indexOf('allowedextensions')>-1 || (inUpload && e.keyLower.indexOf('extension')>-1)){
      var toks=e.valueLower.split(/[^a-z0-9]+/);
      var bad=[];
      toks.forEach(function(t){ if(DANGEROUS_EXTS.indexOf(t)>-1) bad.push(t); });
      if(bad.length){
        add('HIGH', e.line, e.fullKey, 'Upload settings allow executable or script file types ('+bad.join(', ')+'), so an uploaded file could be run or served as code.', 'Restrict allowed upload extensions to safe media and documents only — for example "png, jpg, gif, pdf" — and serve uploads from a separate, non-executing location.');
      }
    }
    if(e.keyLower.indexOf('max_file_size')>-1 || e.keyLower.indexOf('max_upload')>-1 || e.keyLower.indexOf('maxsize')>-1 || e.keyLower.indexOf('max_size')>-1){
      var n=parseInt(e.value,10);
      if(!isNaN(n) && n>26214400){
        add('MEDIUM', e.line, e.fullKey, 'The maximum upload size is very large (over 25 MB), which invites disk-filling and abuse through the media upload endpoint.', 'Lower max_file_size to the largest file you genuinely accept (for example 5242880 — 5 MB) and enforce the same limit at the reverse proxy.');
      }
    }
    if(inUpload && e.keyLower.indexOf('public')>-1 && (e.valueLower==='true' || e.valueLower==='yes')){
      add('MEDIUM', e.line, e.fullKey, 'Uploads / media are set to public, so every uploaded file is world-readable by URL.', 'Keep uploaded media private unless it is meant to be published, and serve public files through signed or unguessable URLs.');
    }
  });

  // --- Generic sweep: any other plaintext secret not already handled ---
  entries.forEach(function(e){
    if(isSecretKey(e) && !handledPwLines[e.line]){
      var v=e.value;
      if(isEnvRef(v) || v==='') return;
      if(e===adminPw || e===dbPw || e===smtpPw) return;
      add('HIGH', e.line, e.fullKey, 'A secret value is stored in plaintext in the config file (value hidden; length '+v.length+').', 'Move this secret into an environment variable or secrets store and reference it from the config instead of writing the value into the file.', v.length);
    }
  });

  var sevRank={CRITICAL:0,HIGH:1,MEDIUM:2,LOW:3,INFO:4};
  findings.sort(function(a,b){
    var la=(a.line==null?9999:a.line), lb=(b.line==null?9999:b.line);
    if(la!==lb) return la-lb;
    return sevRank[a.severity]-sevRank[b.severity];
  });
  var verdict;
  if(findings.some(function(f){return f.severity==='CRITICAL';})) verdict='DO NOT DEPLOY';
  else if(findings.some(function(f){return f.severity==='HIGH'||f.severity==='MEDIUM';})) verdict='DEPLOY WITH FIXES';
  else verdict='SAFE TO DEPLOY';
  return {verdict:verdict, findings:findings, entries:entries.length, lines:parsed.lineCount, note:null};
}

function counts(findings){
  var c={CRITICAL:0,HIGH:0,MEDIUM:0,LOW:0,INFO:0};
  findings.forEach(function(f){ c[f.severity]=(c[f.severity]||0)+1; });
  return c;
}
function buildReport(result){
  var out=[];
  out.push('J-Dawgs Listmonk Server Config Safety Auditor™ — audit report');
  out.push('Offline paste-only audit. No server was contacted. Secret values are never shown; secrets are reported by key, line, and length only.');
  out.push('');
  out.push('VERDICT: '+result.verdict);
  out.push('Config lines scanned: '+result.lines+' · Settings parsed: '+result.entries);
  if(result.note){ out.push(''); out.push(result.note); return out.join('\n'); }
  var c=counts(result.findings);
  out.push('Findings: '+result.findings.length+' (Critical '+c.CRITICAL+', High '+c.HIGH+', Medium '+c.MEDIUM+', Low '+c.LOW+')');
  out.push('');
  if(!result.findings.length){
    out.push('No risky settings were found in the pasted config. This is a config review only — it does not verify the server runs.');
  }
  result.findings.forEach(function(f,i){
    out.push((i+1)+'. ['+f.severity+'] '+(f.line==null?'Line — (setting missing)':'Line '+f.line)+' · '+f.key+(typeof f.valueLength==='number'?' (value hidden, length '+f.valueLength+')':''));
    out.push('   Issue: '+f.issue);
    out.push('   Fix: '+f.fix);
  });
  return out.join('\n');
}
function buildJson(result){
  return JSON.stringify({
    tool:'J-Dawgs Listmonk Server Config Safety Auditor™',
    audit:'offline-paste-only',
    connectsToServer:false,
    verifiesServerRuns:false,
    secretsShown:false,
    verdict:result.verdict,
    linesScanned:result.lines,
    settingsParsed:result.entries,
    counts:counts(result.findings),
    note:result.note,
    findings:result.findings
  }, null, 2);
}

// ---------- UI ----------
var els={};
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-listmonk-server-config-safety-auditortm-2',
  name: 'J-Dawgs Listmonk Server Config Safety Auditor',
  description: '',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
