'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Mastodon Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

  "use strict";

  var RISKY = [
    "# RISKY EXAMPLE - for testing only. Do not deploy.",
    "LOCAL_DOMAIN=localhost",
    "LOCAL_HTTPS=false",
    "SECRET_KEY_BASE=abc123short",
    "OTP_SECRET=changeme",
    "VAPID_PRIVATE_KEY=",
    "DB_HOST=db",
    "DB_USER=mastodon",
    "DB_PASS=DbPlaintext!2026x",
    "REDIS_PASSWORD=RedisPlain!2026x",
    "SMTP_SERVER=mail.example.com",
    "SMTP_PORT=25",
    "SMTP_LOGIN=admin@example.com",
    "SMTP_PASSWORD=SmtpPlain!2026x",
    "SMTP_ENABLE_STARTTLS=never",
    "REGISTRATIONS_MODE=open",
    "SINGLE_USER_MODE=true",
    "S3_ENABLED=true",
    "S3_BUCKET=media-files",
    "S3_ENDPOINT=http://minio.example.com:9000",
    "TRUSTED_PROXY_IP=0.0.0.0/0"
  ].join("\n");

  var HARDENED = [
    "# HARDENED EXAMPLE - real secrets stay in the environment, referenced not pasted.",
    "LOCAL_DOMAIN=social.clearriver.net",
    "LOCAL_HTTPS=true",
    "SECRET_KEY_BASE=3f9a1c7e5b2d8046a1c3e5f7092b4d6a8c0e2f4a6b8d0c2e4f6a8b0d2c4e6f8a0b2d4c6e8f0a2b4c6d8e0f2a4b6c8d0e2f4a6b8c0d2e4f6a8b0c2d41a2b3c4d5e",
    "OTP_SECRET=c81f3a5b7d9e0f2a4c6b8d0e2f4a6c8b0d2e4f6a8c0b2d4e6f8a0c2b4d6e8f0a2c4b6d8e0f2a4c6b8d0e2f4a6c8b0d2e4f6a8c0b2d4e6f8a0c2b4d6e8f0a1b2c3d",
    "VAPID_PRIVATE_KEY=9d8c7b6a5f4e3d2c1b0a9f8e7d6c5b4a3f2e1d0c9b8a7f6e5d4c3b2a1f0e9d8c",
    "VAPID_PUBLIC_KEY=BMx9k2Qp7sT4vW8yZ1aC3eF5gH7jK9mN2pQ4rS6tU8vW0xY2zA4bC6dE8fG0hJ2kL4mN6pQ8rS0tU2vW4xY6zA8bC0dE",
    "DB_HOST=db",
    "DB_USER=mastodon",
    "DB_NAME=mastodon_production",
    "DB_PASS=${DB_PASS}",
    "REDIS_HOST=127.0.0.1",
    "REDIS_PORT=6379",
    "REDIS_PASSWORD=${REDIS_PASSWORD}",
    "SMTP_SERVER=mail.clearriver.net",
    "SMTP_PORT=587",
    "SMTP_LOGIN=noreply@clearriver.net",
    "SMTP_PASSWORD=${SMTP_PASSWORD}",
    "SMTP_ENABLE_STARTTLS=always",
    "SMTP_TLS=true",
    "REGISTRATIONS_MODE=approved",
    "SINGLE_USER_MODE=false",
    "S3_ENABLED=true",
    "S3_BUCKET=clearriver-media",
    "S3_ENDPOINT=https://s3.clearriver.net",
    "S3_PROTOCOL=https",
    "TRUSTED_PROXY_IP=127.0.0.1"
  ].join("\n");

  var EXAMPLE_WORDS = ["changeme","change-me","example","your_","your-","placeholder","replace_me","replaceme","todo","xxx","secret123","password","letmein","sample","dummy","test123","default"];
  var SECRET_KEYS = {SECRET_KEY_BASE:1, OTP_SECRET:1, VAPID_PRIVATE_KEY:1, VAPID_PUBLIC_KEY:1, DB_PASS:1, REDIS_PASSWORD:1, SMTP_PASSWORD:1, S3_SECRET_ACCESS_KEY:1, AWS_SECRET_ACCESS_KEY:1};

  function isEnvRef(v){
    if(!v) return false;
    var t = v.trim();
    return t.charAt(0) === "$" || t.indexOf("${") === 0 || /^(env|file|vault|kms|secret|op):/i.test(t) || t.indexOf("{{") === 0;
  }
  function looksExample(v){
    var low = v.toLowerCase();
    for(var i=0;i<EXAMPLE_WORDS.length;i++){ if(low.indexOf(EXAMPLE_WORDS[i]) !== -1) return true; }
    return false;
  }
  function truthy(v){ return /^(true|yes|1|on)$/i.test((v||"").trim()); }
  function falsy(v){ return /^(false|no|0|off)$/i.test((v||"").trim()); }

  function parseConfig(text){
    var lines = text.split(/\r?\n/);
    var entries = {};   // KEY -> {value, line}
    var order = [];
    var keyCount = 0;
    for(var i=0;i<lines.length;i++){
      var raw = lines[i];
      var lineNo = i+1;
      var t = raw.trim();
      if(!t || t.charAt(0) === "#") continue;
      if(t.indexOf("export ") === 0) t = t.slice(7).trim();
      var eq = t.indexOf("=");
      if(eq < 1) continue;
      var key = t.slice(0, eq).trim().toUpperCase();
      var val = t.slice(eq+1).trim();
      if(val.length >= 2 && ((val.charAt(0)==='"' && val.charAt(val.length-1)==='"') || (val.charAt(0)==="'" && val.charAt(val.length-1)==="'"))){
        val = val.slice(1, -1);
      }
      if(!(key in entries)) order.push(key);
      entries[key] = {value: val, line: lineNo};
      keyCount++;
    }
    return {entries: entries, order: order, keyCount: keyCount, lineCount: lines.length};
  }

  function audit(text){
    var parsed = parseConfig(text);
    var E = parsed.entries;
    var findings = [];
    function add(sev, key, entry, msg, fix){
      findings.push({
        severity: sev, key: key,
        line: entry ? entry.line : null,
        valueLength: (entry && SECRET_KEYS[key]) ? entry.value.length : null,
        message: msg, fix: fix || ""
      });
    }
    function get(k){ return E[k] || null; }

    if(parsed.keyCount < 4 || (!get("LOCAL_DOMAIN") && !get("SECRET_KEY_BASE"))){
      return {verdict:"NOT ENOUGH TO GRADE", findings:[{severity:"info",key:"(input)",line:null,valueLength:null,message:"Too little recognisable Mastodon config to grade. Paste at least LOCAL_DOMAIN, SECRET_KEY_BASE, and OTP_SECRET lines from .env.production.",fix:"Paste more of the config, or load a worked example."}], keyCount: parsed.keyCount};
    }

    // --- Core secrets: SECRET_KEY_BASE / OTP_SECRET ---
    ["SECRET_KEY_BASE","OTP_SECRET"].forEach(function(k){
      var e = get(k);
      if(!e){ add("critical", k, null, k+" is missing. Mastodon cannot boot safely without it.", "Generate a long random value (for example with the Mastodon setup wizard or a password generator) and set "+k+" before deploying."); return; }
      if(e.value.length === 0){ add("critical", k, e, k+" is present but empty.", "Set a long random value for "+k+"."); return; }
      if(looksExample(e.value)){ add("critical", k, e, k+" still holds an example or placeholder value.", "Replace it with a freshly generated random value and keep the real value out of shared files."); return; }
      if(e.value.length < 64){ add("critical", k, e, k+" is far too short ("+e.value.length+" characters). Short secrets can be guessed.", "Use at least 128 random characters for "+k+"."); return; }
      if(e.value.length < 128){ add("warning", k, e, k+" is short ("+e.value.length+" characters); 128 is the expected size.", "Regenerate "+k+" at 128 characters when you next rotate secrets."); return; }
      add("pass", k, e, k+" is present at full length ("+e.value.length+" characters).", "");
    });

    // --- VAPID ---
    var vap = get("VAPID_PRIVATE_KEY");
    if(!vap || vap.value.length === 0){ add("critical","VAPID_PRIVATE_KEY", vap, "VAPID_PRIVATE_KEY is missing or empty. Web push notifications cannot be signed.", "Generate a VAPID key pair and set VAPID_PRIVATE_KEY and VAPID_PUBLIC_KEY."); }
    else if(looksExample(vap.value)){ add("critical","VAPID_PRIVATE_KEY", vap, "VAPID_PRIVATE_KEY still holds an example or placeholder value.", "Replace it with a generated VAPID private key."); }
    else if(vap.value.length < 32){ add("warning","VAPID_PRIVATE_KEY", vap, "VAPID_PRIVATE_KEY looks short ("+vap.value.length+" characters) for a VAPID key.", "Confirm the full generated key was pasted, with nothing trimmed."); }
    else { add("pass","VAPID_PRIVATE_KEY", vap, "VAPID_PRIVATE_KEY is present ("+vap.value.length+" characters).", ""); }
    var vapPub = get("VAPID_PUBLIC_KEY");
    if(vap && vap.value.length > 0 && !vapPub){ add("warning","VAPID_PUBLIC_KEY", null, "VAPID_PRIVATE_KEY is set but VAPID_PUBLIC_KEY is missing; the pair must travel together.", "Set VAPID_PUBLIC_KEY from the same generated pair."); }

    // --- Passwords: plaintext vs env reference ---
    [["DB_PASS","critical"],["SMTP_PASSWORD","critical"],["REDIS_PASSWORD","warning"]].forEach(function(pair){
      var k = pair[0], sev = pair[1];
      var e = get(k);
      if(!e){ add("info", k, null, k+" is not set in this file. That is fine if the service uses another auth method (for example local peer or socket auth).", ""); return; }
      if(e.value.length === 0){ add("warning", k, e, k+" is present but empty.", "Set it, or remove the line if the service genuinely has no password."); return; }
      if(isEnvRef(e.value)){ add("pass", k, e, k+" is an environment reference, not a plaintext value — the real secret stays out of this file.", ""); return; }
      if(looksExample(e.value)){ add(sev, k, e, k+" still holds an example or placeholder value in plaintext.", "Move the real password into the environment or a secrets store and reference it here, for example "+k+"=${"+k+"}."); return; }
      add(sev, k, e, k+" is stored in plaintext in this file ("+e.value.length+" characters). Anyone who reads the file owns the account.", "Move it into the environment or a secrets store and reference it here, for example "+k+"=${"+k+"}, then rotate the password.");
    });

    // --- LOCAL_DOMAIN / HTTPS ---
    var dom = get("LOCAL_DOMAIN");
    if(!dom || dom.value.length === 0){ add("critical","LOCAL_DOMAIN", dom, "LOCAL_DOMAIN is missing. It becomes the permanent identity of the server and cannot be changed later.", "Set LOCAL_DOMAIN to your real public domain before first boot."); }
    else {
      var dv = dom.value.trim().toLowerCase();
      if(dv === "localhost" || dv.indexOf("localhost") === 0 || dv === "127.0.0.1" || dv.indexOf("example.") !== -1 || dv === "example" || /\.example$/.test(dv) || /\.local$/.test(dv) || /\.test$/.test(dv) || /\.invalid$/.test(dv)){
        add("critical","LOCAL_DOMAIN", dom, "LOCAL_DOMAIN points at a local or placeholder domain. Federation, links, and account identities would be built on a name you do not own.", "Set LOCAL_DOMAIN to the real public domain for this server.");
      } else if(dv.indexOf("://") !== -1){
        add("warning","LOCAL_DOMAIN", dom, "LOCAL_DOMAIN contains a URL scheme. It should be the bare domain only.", "Remove the http:// or https:// prefix from LOCAL_DOMAIN.");
      } else if(dv.indexOf(".") === -1){
        add("warning","LOCAL_DOMAIN", dom, "LOCAL_DOMAIN has no dot in it, so it does not look like a public domain.", "Use the full public domain, for example a subdomain of a domain you control.");
      } else {
        add("pass","LOCAL_DOMAIN", dom, "LOCAL_DOMAIN is set to a plausible public domain.", "");
      }
    }
    var https = get("LOCAL_HTTPS");
    if(https && falsy(https.value)){ add("critical","LOCAL_HTTPS", https, "LOCAL_HTTPS is switched off, so the server builds plain-http links and assumptions. Federation and logins expect HTTPS.", "Serve the domain over HTTPS and set LOCAL_HTTPS=true (or remove the line, since HTTPS is the default)."); }
    else if(https && truthy(https.value)){ add("pass","LOCAL_HTTPS", https, "LOCAL_HTTPS is on.", ""); }
    else if(!https){ add("info","LOCAL_HTTPS", null, "LOCAL_HTTPS is not set; Mastodon defaults to HTTPS, which is the safe posture.", ""); }

    // --- Registrations / single user ---
    var reg = get("REGISTRATIONS_MODE");
    var regVal = reg ? reg.value.trim().toLowerCase() : null;
    if(reg){
      if(regVal === "open"){ add("critical","REGISTRATIONS_MODE", reg, "Registrations are fully open. A new public server with open sign-ups is a spam and abuse magnet from day one.", "Use REGISTRATIONS_MODE=approved (manual approval) or =none until you have moderation capacity."); }
      else if(regVal === "approved"){ add("pass","REGISTRATIONS_MODE", reg, "Registrations require approval — the safe default for a new server.", ""); }
      else if(regVal === "none" || regVal === "closed"){ add("pass","REGISTRATIONS_MODE", reg, "Registrations are closed.", ""); }
      else { add("warning","REGISTRATIONS_MODE", reg, "REGISTRATIONS_MODE holds an unrecognised value.", "Use one of: open, approved, none."); }
    } else {
      add("info","REGISTRATIONS_MODE", null, "REGISTRATIONS_MODE is not set; check the server default (approval-based) is what you intend.", "");
    }
    var single = get("SINGLE_USER_MODE");
    if(single && truthy(single.value)){
      if(regVal === "open" || regVal === "approved"){
        add("critical","SINGLE_USER_MODE", single, "SINGLE_USER_MODE is on while REGISTRATIONS_MODE="+regVal+" — the two contradict each other: single-user mode is for a one-person server with sign-ups off.", "Pick one posture: single-user mode with registrations off, or a multi-user server with SINGLE_USER_MODE=false.");
      } else {
        add("info","SINGLE_USER_MODE", single, "SINGLE_USER_MODE is on — right for a one-person server, wrong if you expect other accounts.", "");
      }
    } else if(single){
      add("pass","SINGLE_USER_MODE", single, "SINGLE_USER_MODE is off, consistent with a multi-user server.", "");
    }

    // --- S3 / object storage ---
    var s3on = get("S3_ENABLED");
    var objStorage = get("OBJECT_STORAGE");
    if((s3on && truthy(s3on.value)) || (objStorage && truthy(objStorage.value))){
      var ep = get("S3_ENDPOINT");
      var proto = get("S3_PROTOCOL");
      var badHttp = false;
      if(ep && /^http:\/\//i.test(ep.value.trim())){ add("critical","S3_ENDPOINT", ep, "The object-storage endpoint uses plain http://. Media uploads and downloads would cross the network unencrypted.", "Use the https:// endpoint for your storage provider."); badHttp = true; }
      if(proto && proto.value.trim().toLowerCase() === "http"){ add("critical","S3_PROTOCOL", proto, "S3_PROTOCOL is http, so storage traffic is unencrypted.", "Set S3_PROTOCOL=https."); badHttp = true; }
      if(!ep){ add("warning","S3_ENDPOINT", null, "Object storage is enabled but no S3_ENDPOINT is set in this file; confirm the provider default endpoint is the one you mean to use.", "Set S3_ENDPOINT explicitly to the https:// endpoint."); }
      else if(!badHttp){ add("pass","S3_ENDPOINT", ep, "Object storage is enabled with an HTTPS endpoint.", ""); }
      var bucket = get("S3_BUCKET");
      if(!bucket){ add("warning","S3_BUCKET", null, "Object storage is enabled but S3_BUCKET is not set.", "Set S3_BUCKET to the bucket media should live in."); }
    } else {
      add("info","S3_ENABLED", s3on, "Object storage (S3) is not enabled in this file. Media will live on local disk — workable for a small server, but plan backups and disk growth.", "");
    }

    // --- SMTP TLS posture ---
    var smtpServer = get("SMTP_SERVER");
    if(!smtpServer){ add("warning","SMTP_SERVER", null, "No SMTP_SERVER is set. Confirmation and password-reset email will not go out, so new accounts cannot verify.", "Configure an SMTP server before opening registrations."); }
    var starttls = get("SMTP_ENABLE_STARTTLS");
    if(starttls){
      var sv = starttls.value.trim().toLowerCase();
      if(sv === "never" || sv === "false" || sv === "no" || sv === "off"){ add("critical","SMTP_ENABLE_STARTTLS", starttls, "STARTTLS is disabled for outgoing mail, so credentials and message content can cross the network unencrypted.", "Set SMTP_ENABLE_STARTTLS=always (or auto at minimum) with a port that supports it, usually 587."); }
      else if(sv === "always" || sv === "true"){ add("pass","SMTP_ENABLE_STARTTLS", starttls, "STARTTLS is enforced for outgoing mail.", ""); }
      else if(sv === "auto"){ add("warning","SMTP_ENABLE_STARTTLS", starttls, "STARTTLS is set to auto: encryption is attempted but not guaranteed.", "Prefer SMTP_ENABLE_STARTTLS=always so mail fails rather than sending in the clear."); }
      else { add("warning","SMTP_ENABLE_STARTTLS", starttls, "SMTP_ENABLE_STARTTLS holds an unrecognised value.", "Use always, auto, or never — and never pick never."); }
    }
    var smtpTls = get("SMTP_TLS");
    if(smtpTls && falsy(smtpTls.value)){ add("warning","SMTP_TLS", smtpTls, "SMTP_TLS is switched off.", "Turn SMTP_TLS on, or rely on enforced STARTTLS on port 587."); }
    var smtpPort = get("SMTP_PORT");
    if(smtpPort && smtpPort.value.trim() === "25" && (!starttls || starttls.value.trim().toLowerCase() === "never")){
      add("warning","SMTP_PORT", smtpPort, "SMTP is on port 25 without enforced STARTTLS — the classic plaintext mail posture.", "Move to port 587 with STARTTLS enforced, or 465 with TLS.");
    } else if(smtpPort && (smtpPort.value.trim() === "587" || smtpPort.value.trim() === "465")){
      add("pass","SMTP_PORT", smtpPort, "SMTP port matches a standard encrypted submission port.", "");
    }

    // --- Trusted proxy / whitelist, where present ---
    ["TRUSTED_PROXY_IP","TRUSTED_PROXY_IPS","IP_WHITELIST","ALLOWED_IPS","WHITELIST"].forEach(function(k){
      var e = get(k);
      if(!e) return;
      var v = e.value.trim();
      if(v === "0.0.0.0/0" || v === "::/0" || v === "*" || v === "0.0.0.0" && k.indexOf("WHITELIST") !== -1){
        add("critical", k, e, k+" trusts the entire internet. Real client IPs can be spoofed, which defeats rate limits and IP-based protections.", "Restrict "+k+" to the actual proxy addresses in front of this server, for example 127.0.0.1 for a same-host reverse proxy.");
      } else if(v.indexOf("0.0.0.0/0") !== -1 || v.indexOf("::/0") !== -1){
        add("critical", k, e, k+" includes a trust-everything range (0.0.0.0/0 or ::/0).", "Remove the wildcard range and list only your real proxies.");
      } else {
        add("pass", k, e, k+" is set to a specific address or range rather than a wildcard.", "");
      }
    });
    if(!get("TRUSTED_PROXY_IP") && !get("TRUSTED_PROXY_IPS")){
      add("info","TRUSTED_PROXY_IP", null, "No trusted-proxy setting in this file. If the server sits behind a reverse proxy, set TRUSTED_PROXY_IP to that proxy so real client IPs are logged; if there is no proxy, no action is needed.", "");
    }

    var crit = findings.filter(function(f){return f.severity==="critical";}).length;
    var warn = findings.filter(function(f){return f.severity==="warning";}).length;
    var verdict = crit > 0 ? "DO NOT DEPLOY" : (warn > 0 ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY");
    return {verdict: verdict, findings: findings, keyCount: parsed.keyCount};
  }

  function verdictWhy(v, findings){
    var crit = findings.filter(function(f){return f.severity==="critical";}).length;
    var warn = findings.filter(function(f){return f.severity==="warning";}).length;
    if(v === "SAFE TO DEPLOY") return "No critical problems and no warnings in the pasted config. This grades the file only — it does not start or test the server.";
    if(v === "DEPLOY WITH FIXES") return warn+" warning(s) to fix before this is a clean deploy. Nothing here is an outright blocker, but each warning is a real weakness.";
    if(v === "DO NOT DEPLOY") return crit+" critical problem(s) found. Fix every critical finding before starting this server in public.";
    return "Not enough recognisable Mastodon config to grade. Paste more of the .env.production file.";
  }

  function buildReport(result){
    var lines = [];
    lines.push("J-Dawgs Mastodon Server Config Safety Auditor - Audit Report");
    lines.push("Verdict: " + result.verdict);
    lines.push("Keys read: " + result.keyCount);
    var crit = result.findings.filter(function(f){return f.severity==="critical";}).length;
    var warn = result.findings.filter(function(f){return f.severity==="warning";}).length;
    var pass = result.findings.filter(function(f){return f.severity==="pass";}).length;
    var info = result.findings.filter(function(f){return f.severity==="info";}).length;
    lines.push("Counts: critical " + crit + " / warnings " + warn + " / passed " + pass + " / notes " + info);
    lines.push("Redaction: secrets are named by key, line, and value length only. No secret values are included.");
    lines.push("");
    lines.push("Findings:");
    result.findings.forEach(function(f){
      var loc = f.line ? ("line " + f.line) : "not present";
      var len = (f.valueLength !== null && f.valueLength !== undefined) ? (", value length " + f.valueLength) : "";
      lines.push("- [" + f.severity.toUpperCase() + "] " + f.key + " (" + loc + len + "): " + f.message + (f.fix ? " Fix: " + f.fix : ""));
    });
    lines.push("");
    lines.push("Scope: offline check of the pasted text only. This tool does not start a server, connect anywhere, save, or upload anything.");
    return lines.join("\n");
  }

  function buildJson(result){
    var obj = {
      tool: "J-Dawgs Mastodon Server Config Safety Auditor",
      verdict: result.verdict,
      keysRead: result.keyCount,
      counts: {
        critical: result.findings.filter(function(f){return f.severity==="critical";}).length,
        warning: result.findings.filter(function(f){return f.severity==="warning";}).length,
        pass: result.findings.filter(function(f){return f.severity==="pass";}).length,
        info: result.findings.filter(function(f){return f.severity==="info";}).length
      },
      redaction: "Secrets are reported by key name, line number, and value length only. No secret values are included.",
      findings: result.findings.map(function(f){
        return {severity: f.severity, key: f.key, line: f.line, valueLength: f.valueLength, message: f.message, fix: f.fix};
      })
    };
    return JSON.stringify(obj, null, 2);
  }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_WORDS": (typeof EXAMPLE_WORDS !== 'undefined' ? EXAMPLE_WORDS : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-mastodon-server-config-safety-auditortm-2',
  name: 'J-Dawgs Mastodon Server Config Safety Auditor',
  description: '',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_WORDS": __core["EXAMPLE_WORDS"] }
};
