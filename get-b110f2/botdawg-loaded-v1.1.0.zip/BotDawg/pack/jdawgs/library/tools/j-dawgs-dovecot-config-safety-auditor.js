'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Dovecot Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var RISKY = [
        "# Example A \u2014 risky configuration (expected verdict: DO NOT DEPLOY)",
        "protocols = imap pop3",
        "listen = *",
        "ssl = no",
        "disable_plaintext_auth = no",
        "auth_mechanisms = plain login",
        "auth_verbose = yes",
        "auth_debug = yes",
        "service imap-login {",
        "  inet_listener imap {",
        "    port = 143",
        "  }",
        "}",
        "passdb {",
        "  driver = sql",
        "  args = /etc/dovecot/dovecot-sql.conf.ext password=Sup3rSecretValue",
        "}",
        "mail home is wherever it lands"
      ].join("\n");

      var HARDENED = [
        "# Example B \u2014 hardened configuration (expected verdict: SAFE TO DEPLOY)",
        "protocols = imap lmtp",
        "listen = 192.0.2.10",
        "ssl = required",
        "ssl_cert = </etc/dovecot/ssl/mail.example.com.crt",
        "ssl_key = </etc/dovecot/ssl/mail.example.com.key",
        "disable_plaintext_auth = yes",
        "auth_mechanisms = plain login scram-sha-256",
        "auth_verbose = no",
        "auth_debug = no",
        "mail_location = maildir:~/Maildir",
        "mail_home = /var/vmail/%d/%n",
        "first_valid_uid = 1000",
        "last_valid_uid = 5000",
        "service imap-login {",
        "  inet_listener imaps {",
        "    port = 993",
        "  }",
        "}",
        "passdb {",
        "  driver = sql",
        "  args = /etc/dovecot/dovecot-sql.conf.ext",
        "}",
        "userdb {",
        "  driver = sql",
        "  args = /etc/dovecot/dovecot-sql.conf.ext",
        "}"
      ].join("\n");

      /* ---------- parsing ---------- */
      function parseConfig(text){
        var lines = text.split(/\r?\n/);
        var settings = [], notParsed = [], stack = [], blockSeq = 0;
        for (var idx = 0; idx < lines.length; idx++){
          var n = idx + 1;
          var raw = lines[idx];
          var ci = -1;
          for (var i = 0; i < raw.length; i++){
            if (raw[i] === "#" && (i === 0 || /\s/.test(raw[i-1]))){ ci = i; break; }
          }
          var line = ci >= 0 ? raw.slice(0, ci) : raw;
          var t = line.trim();
          if (!t) continue;
          if (t === "}"){
            if (stack.length) stack.pop();
            else notParsed.push({ line: n, reason: "closing brace with no open section" });
            continue;
          }
          var sec = t.match(/^([A-Za-z][\w-]*)(?:\s+([^={]+?))?\s*\{$/);
          if (sec){
            blockSeq++;
            stack.push({ name: sec[1].toLowerCase(), arg: (sec[2] || "").trim(), id: blockSeq, line: n });
            continue;
          }
          if (/^!include(_try)?\s/.test(t)){
            settings.push({ key: "!include", rawKey: "!include", value: "", line: n,
              sections: stack.map(function(s){ return s.name; }),
              block: stack.length ? stack[stack.length-1].id : 0, include: true });
            continue;
          }
          var m = t.match(/^([A-Za-z][A-Za-z0-9_]*)\s*=\s*(.*)$/);
          if (m){
            settings.push({ key: m[1].toLowerCase(), rawKey: m[1], value: m[2].trim(), line: n,
              sections: stack.map(function(s){ return s.name; }),
              sectionArgs: stack.map(function(s){ return s.arg; }),
              block: stack.length ? stack[stack.length-1].id : 0 });
            continue;
          }
          notParsed.push({ line: n, reason: "not a key = value line, a section header, or a closing brace \u2014 not guessed" });
        }
        return { settings: settings, notParsed: notParsed, unclosed: stack.length };
      }

      function passwordLike(v){
        if (/(password|passwd|pwd)\s*=\s*\S+/i.test(v)) return true;
        if (/(^|\s)pass\s*=\s*\S+/i.test(v)) return true;
        if (/\/\/[^/\s:@]+:[^@\s]+@/.test(v)) return true; /* user:pass@host in a connect string */
        return false;
      }

      /* ---------- audit ---------- */
      function audit(text){
        var parsed = parseConfig(text);
        var S = parsed.settings;
        var F = [];
        function last(key){ var r = null; for (var i = 0; i < S.length; i++) if (S[i].key === key) r = S[i]; return r; }
        function all(key){ return S.filter(function(s){ return s.key === key; }); }
        function add(sev, line, key, title, detail, fix){
          F.push({ severity: sev, line: line, key: key, title: title, detail: detail, fix: fix || null });
        }

        if (!S.length && !parsed.notParsed.length){
          return { verdict: null, findings: [], notParsed: [], empty: true };
        }

        /* listen posture */
        var listenS = last("listen");
        var listenTokens = listenS ? listenS.value.split(/[\s,]+/).filter(Boolean) : null;
        var wildcard = !listenTokens || listenTokens.some(function(t){ return t === "*" || t === "::" || t === "0.0.0.0"; });
        var loopbackOnly = !!listenTokens && listenTokens.length > 0 && listenTokens.every(function(t){
          return t === "127.0.0.1" || t === "::1" || t === "localhost";
        });
        var nonlocal = !loopbackOnly; /* Dovecot's default listen is all interfaces */

        /* ssl posture */
        var sslS = last("ssl");
        var sslVal = sslS ? sslS.value.toLowerCase() : null;
        var sslOff = sslVal === "no";
        var certS = last("ssl_cert"), keyS = last("ssl_key");
        var hasCert = !!(certS && certS.value), hasKey = !!(keyS && keyS.value);

        /* auth mechanisms */
        var mechS = last("auth_mechanisms");
        var mechs = mechS ? mechS.value.toLowerCase().split(/\s+/).filter(Boolean) : ["plain"];
        var plainMech = mechs.indexOf("plain") >= 0 || mechs.indexOf("login") >= 0;

        /* disable_plaintext_auth */
        var dpaS = last("disable_plaintext_auth");
        var dpaVal = dpaS ? dpaS.value.toLowerCase() : null;
        var plaintextAllowed = dpaVal !== "yes";
        if (plaintextAllowed && plainMech){
          var refLine = dpaS ? dpaS.line : (mechS ? mechS.line : null);
          var what = dpaS
            ? "disable_plaintext_auth = no at line " + dpaS.line
            : "disable_plaintext_auth is not set in the pasted config";
          if (nonlocal){
            add("BLOCKER", refLine, "disable_plaintext_auth",
              "Plaintext password authentication is allowed on a non-local listener",
              what + ", while auth_mechanisms offers plain/login password authentication. The listener is not loopback-only, so passwords can be sent to this server unencrypted and read by anyone on the path.",
              "Set disable_plaintext_auth = yes and require TLS with ssl = required, so password mechanisms are only offered on encrypted connections.");
          } else {
            add("WARNING", refLine, "disable_plaintext_auth",
              "Plaintext password authentication is allowed (loopback-only listener)",
              what + ", while auth_mechanisms offers plain/login password authentication. The listener is loopback-only, which limits exposure, but any local process or tunnel can still capture credentials.",
              "Set disable_plaintext_auth = yes, or keep this instance strictly loopback-only and never rebind it without fixing this first.");
          }
        }

        /* anonymous auth */
        if (mechs.indexOf("anonymous") >= 0){
          add("BLOCKER", mechS ? mechS.line : null, "auth_mechanisms",
            "Anonymous authentication mechanism is enabled",
            "auth_mechanisms includes anonymous, which lets clients authenticate with no password at all. On a mail server that is almost never intended.",
            "Remove anonymous from auth_mechanisms unless this is a deliberately public, read-only archive.");
        }

        /* ssl checks */
        if (sslOff){
          add("BLOCKER", sslS.line, "ssl",
            "TLS encryption is disabled (ssl = no)",
            "With ssl = no, IMAP, POP3 and submission traffic \u2014 including logins \u2014 crosses the network in cleartext.",
            "Set ssl = required and configure ssl_cert and ssl_key with a valid certificate.");
        } else {
          if (!hasCert || !hasKey){
            var missing = [];
            if (!hasCert) missing.push("ssl_cert");
            if (!hasKey) missing.push("ssl_key");
            add(sslVal === "required" ? "BLOCKER" : "WARNING",
              sslS ? sslS.line : (certS ? certS.line : null),
              "ssl_cert/ssl_key",
              "TLS is on but " + missing.join(" and ") + " is not configured",
              "ssl is " + (sslVal === null ? "not set explicitly" : "= " + sslVal) + ", yet the pasted config has no " + missing.join(" or ") + " line. Dovecot has nothing to serve TLS with, so encrypted service will fail or fall back. (This auditor checks presence only \u2014 it never opens or verifies a certificate file.)",
              "Add ssl_cert = </path/to/fullchain.pem and ssl_key = </path/to/privkey.pem pointing at the real certificate and key.");
          }
          if (sslVal === "yes"){
            add("WARNING", sslS.line, "ssl",
              "ssl = yes offers TLS but does not require it",
              "Clients may still connect and authenticate over plaintext connections. The protection depends on every client choosing to upgrade.",
              "Set ssl = required so plaintext connections are refused outright.");
          }
          if (sslVal === null){
            add("INFO", null, "ssl",
              "ssl is not set explicitly",
              "The pasted config never states its TLS posture; whatever default or included file applies decides it, and that is not visible in this paste.",
              "Set ssl = required explicitly so the posture survives edits and includes changing.");
          }
        }

        /* listener ports */
        var portSettings = all("port").map(function(p){
          var num = parseInt(p.value, 10);
          return { line: p.line, num: isNaN(num) ? null : num, listener: (p.sectionArgs && p.sectionArgs.length) ? p.sectionArgs[p.sectionArgs.length-1] : "" };
        }).filter(function(p){ return p.num !== null; });
        var plainPorts = portSettings.filter(function(p){ return p.num === 143 || p.num === 110; });
        var tlsPorts = portSettings.filter(function(p){ return p.num === 993 || p.num === 995; });
        if (plainPorts.length){
          var portList = plainPorts.map(function(p){ return p.num + " (line " + p.line + ")"; }).join(", ");
          if (sslOff){
            add("BLOCKER", plainPorts[0].line, "port",
              "Plaintext mail port enabled while TLS is disabled",
              "Listener port(s) " + portList + " serve IMAP/POP3 with no encryption at all, and ssl = no removes even the STARTTLS upgrade path.",
              "Disable the plaintext listener(s), or enable TLS (ssl = required) and keep only the 993/995 listeners plus STARTTLS.");
          } else if (tlsPorts.length){
            add("WARNING", plainPorts[0].line, "port",
              "Plaintext ports 143/110 run alongside encrypted 993/995",
              "Listener port(s) " + portList + " accept plaintext connections next to the encrypted listeners. Clients that pick the plaintext port get no transport encryption unless they upgrade with STARTTLS.",
              "If every client supports it, drop the 143/110 listeners; otherwise keep ssl = required and disable_plaintext_auth = yes so nothing sensitive crosses them unencrypted.");
          } else {
            add("WARNING", plainPorts[0].line, "port",
              "Only plaintext ports 143/110 are configured \u2014 no 993/995 listener",
              "Listener port(s) " + portList + " are the only mail listeners in the paste; there is no implicit-TLS listener (993/995). All transport encryption depends on STARTTLS being offered and chosen.",
              "Add inet_listener blocks for imaps (993) and, if POP3 is kept, pop3s (995).");
          }
        }
        if (!portSettings.length){
          add("INFO", null, "port",
            "No inet_listener ports appear in the pasted config",
            "Port exposure cannot be verified from this paste. Stock Dovecot listeners include 143/993 for IMAP and 110/995 for POP3, so assume the plaintext ports exist unless the full config says otherwise.",
            "Paste the service imap-login / pop3-login blocks to have the ports graded.");
        }

        /* protocols */
        var protoS = last("protocols");
        var protos = protoS ? protoS.value.toLowerCase().split(/\s+/).filter(Boolean) : [];
        if (protoS && protos.indexOf("pop3") >= 0){
          if (sslVal === "required" && !plaintextAllowed){
            add("INFO", protoS.line, "protocols",
              "POP3 is enabled, with TLS required and plaintext auth off",
              "POP3 downloads mail off the server and is often kept only for legacy clients; here it is at least behind required TLS. Confirm a real client still needs it.",
              "If no client needs POP3, remove pop3 from protocols to shrink the exposed surface.");
          } else {
            add("WARNING", protoS.line, "protocols",
              "POP3 is enabled without full TLS/auth hardening",
              "protocols includes pop3 while the config does not both require TLS and disable plaintext auth. POP3's single-connection login makes it a frequent credential brute-force and sniffing target.",
              "Remove pop3 from protocols if no client needs it; otherwise set ssl = required and disable_plaintext_auth = yes.");
          }
        }
        if (protoS && protos.indexOf("managesieve") >= 0){
          add("INFO", protoS.line, "protocols",
            "ManageSieve service is enabled",
            "protocols includes managesieve (normally port 4190). It accepts the same credentials as IMAP and lets authenticated users upload sieve scripts, so it inherits the auth posture graded above.",
            "Keep ManageSieve behind the same TLS and auth rules as IMAP, and disable it if nobody manages filters remotely.");
        }
        if (!protoS){
          add("INFO", null, "protocols",
            "protocols is not set",
            "The enabled protocol set comes from defaults or included files that are not in this paste, so the exposed protocol surface is not verified here.",
            "Set protocols explicitly (for example: protocols = imap lmtp) so the surface is deliberate.");
        }

        /* wildcard exposure escalation */
        if (wildcard && ((plaintextAllowed && plainMech) || sslOff)){
          add("BLOCKER", listenS ? listenS.line : null, "listen",
            "Wildcard listener is paired with a weak auth/encryption posture",
            listenS
              ? "listen at line " + listenS.line + " binds all interfaces, and the config also " + (sslOff ? "disables TLS" : "allows plaintext password authentication") + ". The weakest setting is reachable from every network this host touches."
              : "listen is not set, so Dovecot binds all interfaces by default, and the config also " + (sslOff ? "disables TLS" : "allows plaintext password authentication") + ". The weakest setting is reachable from every network this host touches.",
            "Either bind listen to specific addresses, or fix the posture first: ssl = required and disable_plaintext_auth = yes.");
        }

        /* verbose auth logging */
        [["auth_verbose", "auth_verbose"], ["auth_debug", "auth_debug"]].forEach(function(pair){
          var s = last(pair[0]);
          if (s && s.value.toLowerCase() === "yes"){
            add("WARNING", s.line, pair[0],
              pair[0] + " = yes leaks authentication detail into the logs",
              "Verbose auth logging records usernames, mechanisms and failure detail for every login attempt, and debug builds can capture passwords in failed-login traces. Anyone who can read the mail log learns who logs in, from where, and how.",
              "Set " + pair[0] + " = no in production; turn it on only while debugging, then turn it back off.");
          }
        });
        var adpS = last("auth_debug_passwords");
        if (adpS && adpS.value.toLowerCase() === "yes"){
          add("BLOCKER", adpS.line, "auth_debug_passwords",
            "auth_debug_passwords = yes writes passwords into the logs",
            "This setting logs the actual passwords used in login attempts. The mail log becomes a credential store.",
            "Set auth_debug_passwords = no. If it was ever on in production, treat the logs as compromised and rotate the affected passwords.");
        }

        /* passdb embedded credentials \u2014 key name and line only, value never read into output */
        var byBlock = {};
        S.forEach(function(s){
          if (s.sections.indexOf("passdb") >= 0){ (byBlock[s.block] = byBlock[s.block] || []).push(s); }
        });
        Object.keys(byBlock).forEach(function(bid){
          var items = byBlock[bid];
          var drv = null;
          items.forEach(function(i){ if (i.key === "driver") drv = i; });
          if (!drv) return;
          var dv = drv.value.toLowerCase();
          if (dv !== "pam" && dv !== "sql" && dv !== "ldap" && dv !== "passwd-file") return;
          items.forEach(function(i){
            if (i.key === "args" && passwordLike(i.value)){
              add("WARNING", i.line, "passdb args",
                "passdb args appear to embed a password (value not shown)",
                "The args line for the " + dv + " passdb at line " + i.line + " contains a password-like value written directly into the config. Config files get copied into tickets, repos and backups; an embedded credential travels with all of them. The auditor reports the key and line only \u2014 the value is not reproduced anywhere in this output.",
                "Move the credential into a root-only file (for example dovecot-sql.conf.ext with 0600 permissions, or the driver's own protected config) and reference only the file path in args.");
            }
          });
        });

        /* any other literal credential-bearing key \u2014 key name and line only */
        S.forEach(function(s){
          if (s.include) return;
          if (/(password|passwd|secret|api_?key)/i.test(s.key) && s.value){
            add("WARNING", s.line, s.rawKey,
              "Key '" + s.rawKey + "' carries a literal credential value (value not shown)",
              "A credential is written directly in the config at line " + s.line + ". The value is never reproduced in this report; the risk is the config file itself being copied, committed or backed up with the secret inside.",
              "Load the secret from a protected, root-only file or a secrets mechanism instead of a literal value in the main config.");
          }
        });

        /* mail storage posture */
        var mlS = last("mail_location");
        if (!mlS || !mlS.value){
          add("INFO", mlS ? mlS.line : null, "mail_location",
            "mail_location is not set",
            "Dovecot will try to autodetect the mailbox location, which can silently pick the wrong format or an empty directory after an upgrade or migration.",
            "Set mail_location explicitly, for example mail_location = maildir:~/Maildir or mail_location = mdbox:~/mdbox.");
        }
        var mhS = last("mail_home");
        if (!mhS || !mhS.value){
          add("INFO", null, "mail_home",
            "mail_home is not set",
            "Without mail_home, per-user state (indexes, sieve scripts, quota) lands wherever the mail location implies, which complicates backups and migrations.",
            "Set mail_home explicitly (for example mail_home = /var/vmail/%d/%n) separate from the mail storage path.");
        }
        var fuidS = last("first_valid_uid");
        if (fuidS){
          var fv = parseInt(fuidS.value, 10);
          if (!isNaN(fv) && fv < 100){
            add("WARNING", fuidS.line, "first_valid_uid",
              "first_valid_uid is very low (" + fv + ")",
              "A first_valid_uid under 100 lets system accounts (root is 0) be treated as valid mail users if a userdb ever returns them.",
              "Raise first_valid_uid to match your mail-user range \u2014 500 or 1000 are common floors.");
          } else if (!isNaN(fv)){
            add("INFO", fuidS.line, "first_valid_uid",
              "first_valid_uid = " + fv + " noted",
              "Mail users are accepted from UID " + fv + " up" + (last("last_valid_uid") ? " to the configured last_valid_uid" : "") + ". Confirm that range matches the accounts that should hold mail \u2014 system accounts below it are excluded.",
              null);
          }
        }
        var mpgS = last("mail_privileged_group");
        if (mpgS && mpgS.value){
          add("INFO", mpgS.line, "mail_privileged_group",
            "mail_privileged_group is set",
            "The named group gets privileged access to other users' mail files (used for shared delivery setups). Its membership is effectively mailbox access.",
            "Audit the group's membership like you would audit mailbox permissions; remove it if no shared delivery needs it.");
        }

        /* includes + unclosed sections */
        var inc = all("!include");
        if (inc.length){
          add("INFO", inc[0].line, "!include",
            inc.length + " include directive(s) point at files that were not pasted",
            "Settings in included files are not part of this audit, so the verdict covers the pasted text only.",
            "Paste the included files' contents too if you need their settings graded.");
        }
        if (parsed.unclosed > 0){
          add("WARNING", null, "(structure)",
            parsed.unclosed + " section(s) opened but never closed in the paste",
            "A missing closing brace usually means the paste is truncated or a block swallowed the lines after it. Findings below may be graded against an incomplete config.",
            "Check the paste for a missing } and re-run with the complete config.");
        }

        var sevRank = { BLOCKER: 0, WARNING: 1, INFO: 2 };
        F.sort(function(a, b){
          if (sevRank[a.severity] !== sevRank[b.severity]) return sevRank[a.severity] - sevRank[b.severity];
          var la = a.line === null ? 1e9 : a.line, lb = b.line === null ? 1e9 : b.line;
          return la - lb;
        });

        var blockers = F.filter(function(f){ return f.severity === "BLOCKER"; }).length;
        var warnings = F.filter(function(f){ return f.severity === "WARNING"; }).length;
        var verdict = blockers > 0 ? "DO NOT DEPLOY" : (warnings > 0 ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY");
        return { verdict: verdict, findings: F, notParsed: parsed.notParsed, empty: false };
      }

      /* ---------- output builders ---------- */
      function countsOf(r){
        return {
          blockers: r.findings.filter(function(f){ return f.severity === "BLOCKER"; }).length,
          warnings: r.findings.filter(function(f){ return f.severity === "WARNING"; }).length,
          infos: r.findings.filter(function(f){ return f.severity === "INFO"; }).length,
          notParsed: r.notParsed.length
        };
      }
      function buildReport(r){
        if (r.empty) return "No configuration pasted \u2014 nothing to audit.";
        var c = countsOf(r);
        var out = [];
        out.push("J-Dawgs Dovecot Config Safety Auditor\u2122 \u2014 Audit Report");
        out.push("Verdict: " + r.verdict);
        out.push("Counts: " + c.blockers + " BLOCKER \u00b7 " + c.warnings + " WARNING \u00b7 " + c.infos + " INFO \u00b7 " + c.notParsed + " NOT PARSED");
        out.push("Secrets: reported by key name and line only; no config values are reproduced in this report.");
        out.push("");
        if (!r.findings.length) out.push("No findings.");
        r.findings.forEach(function(f, i){
          out.push((i + 1) + ". [" + f.severity + "] " + (f.line !== null ? "Line " + f.line + " \u2014 " : "") + f.title);
          out.push("   " + f.detail);
          if (f.fix) out.push("   Fix: " + f.fix);
        });
        if (r.notParsed.length){
          out.push("");
          out.push("NOT PARSED (content never guessed, lines not reproduced):");
          r.notParsed.forEach(function(np){ out.push("- Line " + np.line + ": " + np.reason); });
        }
        return out.join("\n");
      }
      function buildJSON(r){
        if (r.empty) return JSON.stringify({ tool: "J-Dawgs Dovecot Config Safety Auditor", verdict: null, note: "No configuration pasted." }, null, 2);
        var c = countsOf(r);
        return JSON.stringify({
          tool: "J-Dawgs Dovecot Config Safety Auditor",
          verdict: r.verdict,
          counts: { blockers: c.blockers, warnings: c.warnings, infos: c.infos, notParsed: c.notParsed },
          findings: r.findings.map(function(f){
            return { severity: f.severity, line: f.line, key: f.key, title: f.title, detail: f.detail, fix: f.fix };
          }),
          notParsed: r.notParsed.map(function(np){ return { line: np.line, reason: np.reason }; }),
          secretsPolicy: "Secrets are reported by key name and line only; config values are never included."
        }, null, 2);
      }

      /* ---------- rendering ---------- */
      function esc(s){
        return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
          .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-dovecot-config-safety-auditor',
  name: 'J-Dawgs Dovecot Config Safety Auditor',
  description: 'Grades a pasted Dovecot config offline — plaintext auth, SSL posture, listener exposure — into one deploy verdict; secrets by key name and line only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
