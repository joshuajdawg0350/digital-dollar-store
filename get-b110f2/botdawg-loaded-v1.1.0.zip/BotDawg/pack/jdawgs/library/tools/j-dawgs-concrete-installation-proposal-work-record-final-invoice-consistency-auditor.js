'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Concrete Installation Proposal, Work Record & Final Invoice Consistency Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- formatting helpers ---------- */
      function round2(n) { return Math.round((n + Number.EPSILON) * 100) / 100; }
      function fmtMoney(n) {
        var v = round2(n);
        var parts = Math.abs(v).toFixed(2).split(".");
        parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        return (v < 0 ? "-$" : "$") + parts[0] + "." + parts[1];
      }
      function fmtNum(n, dec) {
        var v = n.toFixed(dec == null ? 2 : dec);
        var parts = v.split(".");
        parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        return parts.join(".");
      }
      function esc(s) {
        return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
      }

      /* ---------- tolerant field extraction ---------- */
      function cleanNum(s) {
        if (s == null) return null;
        var v = parseFloat(String(s).replace(/,/g, ""));
        return isNaN(v) ? null : v;
      }
      function findNum(text, patterns) {
        for (var i = 0; i < patterns.length; i++) {
          var m = text.match(patterns[i]);
          if (m && m[1] != null && m[1] !== "") {
            var v = cleanNum(m[1]);
            if (v != null) return v;
          }
        }
        return null;
      }
      function normName(s) {
        return String(s).toLowerCase().replace(/[^a-z0-9]+/g, " ").replace(/\s+/g, " ").trim();
      }

      var PRICE_PATTERNS = [
        /concrete\s+price[^0-9$\n]{0,20}\$?\s*(\d[\d,]*\.?\d*)/i,
        /price[^0-9$\n]{0,25}\$?\s*(\d[\d,]*\.?\d*)\s*per\s*(?:cu|cubic)/i,
        /\$\s*(\d[\d,]*\.?\d*)\s*per\s*(?:cu\.?\s*yd|cubic\s*yard)/i,
        /(\d[\d,]*\.?\d*)\s*(?:dollars\s*)?per\s*(?:cu\.?\s*yd|cubic\s*yard)/i
      ];
      var AREA_PATTERNS = [/area[^0-9\n]{0,20}(\d[\d,]*\.?\d*)/i];
      var THICK_PATTERNS = [/thickness[^0-9\n]{0,20}(\d[\d,]*\.?\d*)/i, /(\d[\d,]*\.?\d*)\s*(?:in\b|inch)/i];
      var PSI_PATTERNS = [/(\d{3,5})\s*psi/i, /psi[^0-9\n]{0,15}(\d{3,5})/i];

      /* Fee / charge lines: a line naming a fee, charge, or surcharge with a $ amount.
         Lines already owned by another check (concrete, labor, deposit, rebar, PSI premium…) are excluded. */
      function parseFees(text) {
        var fees = [];
        var lines = String(text).split(/\r?\n/);
        var exclude = /(psi|premium|high[\s-]?strength|concrete|labor|deposit|rebar|mesh|thickness|subtotal|sub-total|balance|grand total|total due)/i;
        for (var i = 0; i < lines.length; i++) {
          var line = lines[i];
          if (!/(fee|charge|surcharge)/i.test(line)) continue;
          if (exclude.test(line)) continue;
          var m = line.replace(/,/g, "").match(/\$\s*(\d+\.?\d*)/);
          if (!m) continue;
          var name = line.split(":")[0];
          if (name.indexOf("$") >= 0) name = name.split("$")[0];
          name = name.replace(/[-–—]\s*$/, "").trim();
          if (!name) continue;
          fees.push({ name: name, norm: normName(name), amount: parseFloat(m[1]) });
        }
        return fees;
      }

      /* PSI premium / high-strength surcharge lines on the invoice. */
      function parsePremium(text) {
        var total = 0, found = false;
        var lines = String(text).split(/\r?\n/);
        for (var i = 0; i < lines.length; i++) {
          if (/(premium|surcharge|high[\s-]?strength)/i.test(lines[i])) {
            var m = lines[i].replace(/,/g, "").match(/\$\s*(\d+\.?\d*)/);
            if (m) { total += parseFloat(m[1]); found = true; }
          }
        }
        return found ? round2(total) : null;
      }

      function parseDoc(text) {
        text = String(text || "");
        return {
          area: findNum(text, AREA_PATTERNS),
          thickness: findNum(text, THICK_PATTERNS),
          psi: findNum(text, PSI_PATTERNS),
          price: findNum(text, PRICE_PATTERNS),
          cuYd: findNum(text, [
            /concrete\s+(?:billed|placed|proposed)?[^0-9\n]{0,20}(\d[\d,]*\.?\d*)\s*(?:cu\.?\s*yd|cubic\s*yards?|cy\b)/i,
            /(?:billed|placed)[^0-9\n]{0,20}(\d[\d,]*\.?\d*)\s*(?:cu\.?\s*yd|cubic\s*yards?|cy\b)/i,
            /concrete[^0-9\n]{0,25}(\d[\d,]*\.?\d*)\s*(?:cu\.?\s*yd|cubic\s*yards?)/i
          ]),
          rebarAmount: findNum(text, [
            /(?:rebar|mesh)[^$\n]{0,45}?\$\s*(\d[\d,]*\.?\d*)/i
          ]),
          laborHours: findNum(text, [
            /labor\s+hours[^0-9\n]{0,20}(\d[\d,]*\.?\d*)/i,
            /labor[^0-9\n]{0,40}?(\d[\d,]*\.?\d*)\s*(?:hours|hrs)/i
          ]),
          laborRate: findNum(text, [
            /labor\s+rate[^0-9$\n]{0,20}\$?\s*(\d[\d,]*\.?\d*)/i,
            /\$\s*(\d[\d,]*\.?\d*)\s*(?:per\s*hour|\/\s*hr)/i
          ]),
          laborAmount: findNum(text, [
            /labor[^$\n]{0,70}?amount[^0-9$\n]{0,10}\$?\s*(\d[\d,]*\.?\d*)/i,
            /labor\s*(?:amount|billed|total|charge)[^$\n]{0,30}?\$\s*(\d[\d,]*\.?\d*)/i,
            /labor[^$\n]{0,45}?\$\s*(\d[\d,]*\.?\d*)/i
          ]),
          depositPaid: findNum(text, [/deposit\s+paid[^0-9$\n]{0,20}\$?\s*(\d[\d,]*\.?\d*)/i]),
          depositCredit: findNum(text, [/deposit\s+credit[^0-9$\n]{0,20}\$?\s*(\d[\d,]*\.?\d*)/i]),
          fees: parseFees(text),
          rawNorm: " " + normName(text) + " "
        };
      }

      /* Does the work record say rebar/mesh was installed? */
      function rebarInstalled(workText) {
        var lines = String(workText).split(/\r?\n/).filter(function (l) { return /(rebar|mesh)/i.test(l); });
        if (!lines.length) return { recorded: false, how: "the work record has no rebar / mesh line at all" };
        var joined = lines.join(" ");
        if (/(none|not recorded|not installed|absent|n\/a|no rebar|no mesh|not placed|omitted)/i.test(joined)) {
          return { recorded: false, how: "the work record says: “" + lines[0].trim() + "”" };
        }
        if (/(installed|placed|included|yes|complete)/i.test(joined) || /\$/.test(joined)) {
          return { recorded: true, how: "the work record records rebar / mesh as installed" };
        }
        return { recorded: false, how: "the work record mentions rebar / mesh but never records it as installed" };
      }

      /* ---------- the audit ---------- */
      function audit(pText, wText, iText, wastePct) {
        var P = parseDoc(pText), W = parseDoc(wText), I = parseDoc(iText);
        var waste = (wastePct == null || isNaN(wastePct)) ? 10 : wastePct;
        var missing = [];
        function req(docName, val, label) { if (val == null) missing.push(docName + ": " + label + " not found"); }

        req("Proposal", P.area, "Area (sq ft)");
        req("Proposal", P.thickness, "Thickness (in)");
        req("Proposal", P.psi, "PSI");
        req("Proposal", P.price, "Concrete price per cu yd");
        req("Proposal", P.laborRate, "Labor rate per hour");
        req("Work Record", W.area, "Installed area (sq ft)");
        req("Work Record", W.thickness, "Thickness (in)");
        req("Work Record", W.psi, "PSI installed");
        req("Work Record", W.laborHours, "Labor hours");
        req("Final Invoice", I.cuYd, "Concrete billed (cu yd)");
        req("Final Invoice", I.price != null ? I.price : P.price, "Concrete price per cu yd");
        req("Final Invoice", I.laborAmount, "Labor amount ($)");
        if (P.depositPaid != null && P.depositPaid > 0) req("Final Invoice", I.depositCredit, "Deposit credit ($)");

        var checks = [];
        function add(name, status, detail, over) {
          checks.push({ name: name, status: status, detail: detail, over: round2(over || 0) });
        }
        var EPS = 0.005;

        /* 1 — Concrete quantity */
        (function () {
          var price = I.price != null ? I.price : P.price;
          if (W.area == null || W.thickness == null || I.cuYd == null || price == null) {
            add("1. Concrete quantity", "na",
              "Cannot run: needs the work-record installed area and thickness, the invoice billed cu yd, and a concrete price per cu yd. Whichever of those is missing is listed above.", 0);
            return;
          }
          var placed = W.area * W.thickness / 324;
          var allowed = placed * (1 + waste / 100);
          var stated = W.cuYd != null ? " The work record states " + fmtNum(W.cuYd) + " cu yd placed." : "";
          var base = "<span class=\"arith\">Placed volume: " + fmtNum(W.area, 0) + " sq ft × " + fmtNum(W.thickness) + " in ÷ 324 = " + fmtNum(placed) + " cu yd." + stated +
            " Waste allowance " + fmtNum(waste, waste % 1 ? 1 : 0) + "% → allowed billable " + fmtNum(allowed) + " cu yd. Invoice billed " + fmtNum(I.cuYd) + " cu yd at " + fmtMoney(price) + " per cu yd.</span>";
          if (I.cuYd > allowed + EPS) {
            var excess = I.cuYd - allowed;
            var over = excess * price;
            add("1. Concrete quantity", "flag",
              base + "<br><span class=\"arith\">Excess: " + fmtNum(I.cuYd) + " − " + fmtNum(allowed) + " = " + fmtNum(excess) + " cu yd × " + fmtMoney(price) + " = " + fmtMoney(over) + " overcharge.</span> Billed yardage runs past the placed volume plus the waste allowance.",
              over);
          } else {
            add("1. Concrete quantity", "pass",
              base + "<br>Billed yardage is at or under the placed volume plus the waste allowance — nothing overbilled here.", 0);
          }
        })();

        /* 2 — Area billed vs installed */
        (function () {
          if (W.area == null) {
            add("2. Area billed vs installed", "na", "Cannot run: the work record's installed area was not found, so there is no installed figure to compare against.", 0);
            return;
          }
          var parts = [];
          var differs = [];
          if (P.area != null) { parts.push("proposal " + fmtNum(P.area, 0) + " sq ft"); if (Math.abs(P.area - W.area) > EPS) differs.push("proposal"); }
          if (I.area != null) { parts.push("invoice " + fmtNum(I.area, 0) + " sq ft"); if (Math.abs(I.area - W.area) > EPS) differs.push("invoice"); }
          var txt = "Areas on paper — " + (parts.length ? parts.join("; ") + "; " : "") + "work record installed " + fmtNum(W.area, 0) + " sq ft.";
          if (differs.length) {
            add("2. Area billed vs installed", "flag",
              txt + "<br>The " + differs.join(" and ") + " area does not match the installed area. The installed area (" + fmtNum(W.area, 0) + " sq ft) is the one used for the volume math in check 1 — any billing built on the larger paper area is caught there.", 0);
          } else {
            add("2. Area billed vs installed", "pass", txt + "<br>Every stated area matches the installed area.", 0);
          }
        })();

        /* 3 — Thickness swap */
        (function () {
          if (P.thickness == null) {
            add("3. Thickness swap", "na", "Cannot run: the proposal thickness was not found, so there is no agreed thickness to compare against.", 0);
            return;
          }
          var vals = "Proposal " + fmtNum(P.thickness) + " in" +
            (W.thickness != null ? "; work record " + fmtNum(W.thickness) + " in" : "; work record not stated") +
            (I.thickness != null ? "; invoice " + fmtNum(I.thickness) + " in" : "; invoice not stated") + ".";
          var swapped = [];
          if (W.thickness != null && Math.abs(W.thickness - P.thickness) > EPS) swapped.push("work record");
          if (I.thickness != null && Math.abs(I.thickness - P.thickness) > EPS) swapped.push("invoice");
          if (swapped.length) {
            add("3. Thickness swap", "flag",
              "Thickness — " + vals + "<br>The " + swapped.join(" and ") + " thickness differs from the proposal thickness. That is a spec change from what was agreed; the volume math in check 1 uses the work-record (installed) thickness.", 0);
          } else {
            add("3. Thickness swap", "pass", "Thickness — " + vals + "<br>No thickness change anywhere.", 0);
          }
        })();

        /* 4 — PSI / mix swap + premium */
        (function () {
          var premium = parsePremium(iText);
          if (P.psi == null) {
            add("4. PSI / mix swap", "na", "Cannot run: the proposal PSI was not found, so there is no agreed mix to compare against.", 0);
            return;
          }
          var vals = "Proposal " + fmtNum(P.psi, 0) + " PSI" +
            (W.psi != null ? "; work record " + fmtNum(W.psi, 0) + " PSI installed" : "; work record PSI not stated") +
            (I.psi != null ? "; invoice " + fmtNum(I.psi, 0) + " PSI" : "; invoice PSI not stated") + ".";
          var swapped = [];
          if (W.psi != null && W.psi !== P.psi) swapped.push("work record");
          if (I.psi != null && I.psi !== P.psi) swapped.push("invoice");
          var over = 0, premiumNote = "";
          if (premium != null && premium > 0) {
            if (W.psi != null && W.psi === P.psi) {
              over = premium;
              premiumNote = "<br><span class=\"arith\">The invoice charges a PSI premium / high-strength surcharge of " + fmtMoney(premium) + ", but the work record shows the proposal mix (" + fmtNum(P.psi, 0) + " PSI) is what was installed — premium overcharge " + fmtMoney(premium) + ".</span>";
            } else {
              premiumNote = "<br>The invoice charges a PSI premium / high-strength surcharge of " + fmtMoney(premium) + ". The work record does not confirm the proposal PSI was the installed mix, so the premium is flagged here but not counted as a documented overcharge.";
            }
          }
          if (swapped.length || over > 0) {
            add("4. PSI / mix swap", "flag",
              "Mix — " + vals + (swapped.length ? "<br>The " + swapped.join(" and ") + " PSI differs from the proposal PSI — a mix swap against the agreed spec." : "") + premiumNote, over);
          } else {
            add("4. PSI / mix swap", "pass",
              "Mix — " + vals + "<br>Same mix everywhere" + (premium != null && premium > 0 ? ", though a premium line of " + fmtMoney(premium) + " appears" : " and no PSI premium charged") + ".", over);
          }
        })();

        /* 5 — Rebar / mesh */
        (function () {
          var billed = I.rebarAmount;
          if (billed == null || billed <= 0) {
            add("5. Rebar / mesh billed but not installed", "pass",
              "The invoice bills no rebar / mesh amount, so there is nothing to charge for work the record does not show.", 0);
            return;
          }
          var st = rebarInstalled(wText);
          if (!st.recorded) {
            add("5. Rebar / mesh billed but not installed", "flag",
              "The invoice bills rebar / mesh at " + fmtMoney(billed) + ", but " + esc(st.how) + ".<br><span class=\"arith\">Billed for material the work record does not show installed: " + fmtMoney(billed) + " overcharge.</span>", billed);
          } else {
            add("5. Rebar / mesh billed but not installed", "pass",
              "The invoice bills rebar / mesh at " + fmtMoney(billed) + ", and " + esc(st.how) + " — billing matches the record.", 0);
          }
        })();

        /* 6 — Labor */
        (function () {
          var rate = P.laborRate != null ? P.laborRate : I.laborRate;
          var rateSrc = P.laborRate != null ? "proposal" : "invoice";
          if (W.laborHours == null || rate == null || I.laborAmount == null) {
            add("6. Labor", "na",
              "Cannot run: needs the work-record labor hours, an agreed labor rate per hour, and the invoice labor amount. Whichever is missing is listed above.", 0);
            return;
          }
          var allowedLabor = W.laborHours * rate;
          var hrsNote = I.laborHours != null ? " The invoice bills " + fmtNum(I.laborHours, I.laborHours % 1 ? 1 : 0) + " hours against " + fmtNum(W.laborHours, W.laborHours % 1 ? 1 : 0) + " hours on the work record." : "";
          var base = "<span class=\"arith\">Allowed labor: " + fmtNum(W.laborHours, W.laborHours % 1 ? 1 : 0) + " hrs (work record) × " + fmtMoney(rate) + " per hour (" + rateSrc + " rate) = " + fmtMoney(allowedLabor) + ". Invoice labor amount: " + fmtMoney(I.laborAmount) + ".</span>" + hrsNote;
          if (I.laborAmount > allowedLabor + EPS) {
            var over = I.laborAmount - allowedLabor;
            add("6. Labor", "flag",
              base + "<br><span class=\"arith\">" + fmtMoney(I.laborAmount) + " − " + fmtMoney(allowedLabor) + " = " + fmtMoney(over) + " overcharge.</span>", over);
          } else {
            add("6. Labor", "pass", base + "<br>Billed labor is at or under hours worked × agreed rate.", 0);
          }
        })();

        /* 7 — Deposit */
        (function () {
          if (P.depositPaid == null) {
            add("7. Deposit credit", "pass", "The proposal shows no deposit paid, so there is no deposit that has to come back as a credit.", 0);
            return;
          }
          if (P.depositPaid <= 0) {
            add("7. Deposit credit", "pass", "The proposal shows a deposit paid of " + fmtMoney(P.depositPaid) + " — nothing to credit back.", 0);
            return;
          }
          var credit = I.depositCredit;
          if (credit == null) {
            add("7. Deposit credit", "flag",
              "The proposal shows a deposit paid of " + fmtMoney(P.depositPaid) + ", but the invoice has no deposit credit line at all — treated as " + fmtMoney(0) + " credited.<br><span class=\"arith\">" + fmtMoney(P.depositPaid) + " − " + fmtMoney(0) + " = " + fmtMoney(P.depositPaid) + " overcharge.</span>",
              P.depositPaid);
            return;
          }
          if (credit < P.depositPaid - EPS) {
            var over = P.depositPaid - credit;
            add("7. Deposit credit", "flag",
              "<span class=\"arith\">Deposit paid (proposal): " + fmtMoney(P.depositPaid) + ". Deposit credit shown (invoice): " + fmtMoney(credit) + ". " + fmtMoney(P.depositPaid) + " − " + fmtMoney(credit) + " = " + fmtMoney(over) + " of the deposit never credited back.</span>", over);
          } else {
            add("7. Deposit credit", "pass",
              "<span class=\"arith\">Deposit paid (proposal): " + fmtMoney(P.depositPaid) + ". Deposit credit shown (invoice): " + fmtMoney(credit) + ".</span> The full deposit came back as a credit.", 0);
          }
        })();

        /* 8 — Duplicate fees */
        (function () {
          var groups = {};
          I.fees.forEach(function (f) { (groups[f.norm] = groups[f.norm] || []).push(f); });
          var dups = Object.keys(groups).filter(function (k) { return groups[k].length > 1; });
          if (!dups.length) {
            add("8. Duplicate fees", "pass", "No fee or charge name appears more than once on the invoice.", 0);
            return;
          }
          var over = 0, lines = [];
          dups.forEach(function (k) {
            var g = groups[k];
            var extra = 0;
            for (var j = 1; j < g.length; j++) extra += g[j].amount;
            over += extra;
            lines.push("<span class=\"arith\">“" + esc(g[0].name) + "” appears " + g.length + " times at " + fmtMoney(g[0].amount) + " — " + (g.length - 1) + " extra occurrence(s) = " + fmtMoney(extra) + " overcharge.</span>");
          });
          add("8. Duplicate fees", "flag", lines.join("<br>"), over);
        })();

        /* 9 — Invoice-only charges */
        (function () {
          var counts = {};
          I.fees.forEach(function (f) { counts[f.norm] = (counts[f.norm] || 0) + 1; });
          var only = [];
          var seen = {};
          I.fees.forEach(function (f) {
            if (counts[f.norm] > 1) return; /* already counted under duplicate fees — never double-counted */
            if (seen[f.norm]) return;
            seen[f.norm] = true;
            var inP = P.rawNorm.indexOf(" " + f.norm + " ") >= 0 || P.rawNorm.indexOf(f.norm) >= 0;
            var inW = W.rawNorm.indexOf(f.norm) >= 0;
            if (!inP && !inW) only.push(f);
          });
          if (!only.length) {
            add("9. Invoice-only charges", "pass", "Every fee or charge on the invoice also appears in the proposal or the work record — nothing was added at billing time.", 0);
            return;
          }
          var over = 0, lines = [];
          only.forEach(function (f) {
            over += f.amount;
            lines.push("<span class=\"arith\">“" + esc(f.name) + "” — " + fmtMoney(f.amount) + " — appears on the invoice only; the name is in neither the proposal nor the work record.</span>");
          });
          lines.push("Fees already counted under duplicate fees (check 8) are not counted twice here.");
          add("9. Invoice-only charges", "flag", lines.join("<br>"), over);
        })();

        var total = round2(checks.reduce(function (s, c) { return s + c.over; }, 0));
        var anyFlag = checks.some(function (c) { return c.status !== "pass"; });
        var safe = total === 0 && !anyFlag && missing.length === 0;
        return {
          checks: checks,
          total: total,
          missing: missing,
          verdict: safe ? "SAFE" : "DONOTPAY",
          missingData: missing.length > 0
        };
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-concrete-installation-proposal-work-record-final-invoice-consistency-auditor',
  name: 'J-Dawgs Concrete Installation Proposal, Work Record & Final Invoice Consistency Auditor',
  description: 'Cross-checks a concrete installation proposal against its work record and final invoice into one pay verdict, with arithmetic shown across all pastes.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
