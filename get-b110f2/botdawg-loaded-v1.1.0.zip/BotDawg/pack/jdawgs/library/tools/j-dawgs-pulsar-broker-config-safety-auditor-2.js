'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Pulsar Broker Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        /* ---------- Built-in examples (line numbers are load-bearing) ---------- */
        var RISKY_LINES = [
          "# Risky demo - standalone.conf with planted problems. Do not deploy.",
          "clusterName=standalone",
          "brokerServicePort=6650",
          "webServicePort=8080",
          "# webServicePortTls=8443",
          "authenticationEnabled=false",
          "authorizationEnabled=true",
          "authenticationProviders=org.apache.pulsar.broker.authentication.AuthenticationProviderToken",
          "tokenSecretKey=PLANTEDSECRET-7f3a9c1e-do-not-print",
          "tlsEnabled=false",
          "tlsAllowInsecureConnection=true",
          "advertisedAddress=192.168.1.50",
          "functionsWorkerEnabled=true",
          "backlogQuotaDefaultLimitGB=-1",
          "defaultRetentionTimeInMinutes=-1",
          "loadBalancerSheddingEnabled=false",
          "brokerClientAuthenticationParameters={\"token\":\"PLANTEDTOKEN-zz42\"}",
          "this line is not a setting"
        ];
        var HARDENED_LINES = [
          "# Hardened demo - broker.conf with authentication, authorization, and TLS on.",
          "clusterName=prod-east",
          "brokerServicePort=6650",
          "brokerServicePortTls=6651",
          "webServicePort=8080",
          "webServicePortTls=8443",
          "tlsEnabled=true",
          "tlsRequireTrustedClientCertOnConnect=true",
          "tlsAllowInsecureConnection=false",
          "tlsCertificateFilePath=/etc/pulsar/certs/broker.cert.pem",
          "tlsKeyFilePath=/etc/pulsar/certs/broker.key-pk8.pem",
          "tlsTrustCertsFilePath=/etc/pulsar/certs/ca.cert.pem",
          "authenticationEnabled=true",
          "authorizationEnabled=true",
          "authenticationProviders=org.apache.pulsar.broker.authentication.AuthenticationProviderToken",
          "superUserRoles=admin,ops-admin",
          "tokenSecretKey=file:///etc/pulsar/keys/token-secret.key",
          "advertisedAddress=broker1.pulsar.example.com",
          "functionsWorkerEnabled=false",
          "backlogQuotaDefaultLimitGB=50",
          "defaultRetentionTimeInMinutes=10080",
          "defaultRetentionSizeInMB=10240",
          "loadBalancerEnabled=true",
          "loadBalancerSheddingEnabled=true"
        ];

        /* ---------- Known Pulsar keys (lowercase) ---------- */
        var KNOWN_KEYS = {};
        [
          "brokerserviceport","webserviceport","brokerserviceporttls","webserviceporttls",
          "clustername","zookeeperservers","metadatastoreurl","configurationmetadatastoreurl",
          "bookkeepermetadataserviceuri","advertisedaddress","advertisedlisteners",
          "bindaddress","brokerserviceurl","webserviceurl",
          "authenticationenabled","authorizationenabled","authenticationproviders",
          "superuserroles","tokensecretkey","tokenpublickey","tokenaudience",
          "tlsenabled","tlsrequiretrustedclientcertonconnect","tlsallowinsecureconnection",
          "tlscertificatefilepath","tlskeyfilepath","tlstrustcertsfilepath","tlsprotocols","tlsciphers",
          "functionsworkerenabled","schemaregistrystorageclassname",
          "brokerclientauthenticationplugin","brokerclientauthenticationparameters",
          "brokerclienttlsenabled","brokerclienttrustcertsfilepath",
          "backlogquotadefaultlimitgb","backlogquotadefaultlimitbytes","backlogquotadefaultretentionpolicy",
          "defaultretentiontimeinminutes","defaultretentionsizeinmb",
          "loadbalancerenabled","loadbalancersheddingenabled","loadbalanceroverloadthreshold",
          "managedledgerdefaultensemblesize","managedledgerdefaultwritequorum","managedledgerdefaultackquorum",
          "defaultnumberofnamespacebundles","allowautotopiccreation","allowauto_subscriptioncreation",
          "replicationclusters","peerdiscoveryenabled","exposemanagedledgerstats","maxlistenersperbroker"
        ].forEach(function (k) { KNOWN_KEYS[k] = true; });

        var STRONG_KEYS = {};
        [
          "brokerserviceport","webserviceport","brokerserviceporttls","webserviceporttls",
          "superuserroles","tokensecretkey","tokenpublickey","advertisedlisteners",
          "functionsworkerenabled","backlogquotadefaultlimitgb","metadatastoreurl",
          "zookeeperservers","schemaregistrystorageclassname","defaultretentiontimeinminutes"
        ].forEach(function (k) { STRONG_KEYS[k] = true; });

        /* ---------- Parsing ---------- */
        function normalizeKey(rawKey) {
          var k = rawKey.replace(/^\s*export\s+/i, "").trim();
          if (/^PULSAR_PREFIX_/i.test(k)) k = k.slice("PULSAR_PREFIX_".length);
          return k;
        }
        function cleanValue(v) {
          var out = v.trim();
          if (out.length >= 2) {
            var first = out.charAt(0), last = out.charAt(out.length - 1);
            if ((first === '"' && last === '"') || (first === "'" && last === "'")) {
              out = out.slice(1, -1);
            }
          }
          return out;
        }
        function parseConfig(text) {
          var lines = String(text == null ? "" : text).split(/\r\n|\r|\n/);
          var entries = {};   // lowercase key -> {key, value, line}
          var order = [];
          var malformed = []; // {line}
          var comments = 0, blanks = 0, duplicates = [];
          for (var i = 0; i < lines.length; i++) {
            var lineNo = i + 1;
            var raw = lines[i];
            var trimmed = raw.trim();
            if (trimmed === "") { blanks++; continue; }
            if (trimmed.charAt(0) === "#") { comments++; continue; }
            var eq = raw.indexOf("=");
            if (eq === -1) { malformed.push({ line: lineNo }); continue; }
            var key = normalizeKey(raw.slice(0, eq));
            if (key === "" || /\s/.test(key)) { malformed.push({ line: lineNo }); continue; }
            var value = cleanValue(raw.slice(eq + 1));
            var lk = key.toLowerCase();
            if (entries[lk]) duplicates.push({ key: key, line: lineNo, firstLine: entries[lk].line });
            if (!entries[lk]) order.push(lk);
            entries[lk] = { key: key, value: value, line: lineNo };
          }
          return {
            totalLines: lines.length, entries: entries, order: order,
            malformed: malformed, comments: comments, blanks: blanks, duplicates: duplicates
          };
        }

        /* ---------- Helpers ---------- */
        function get(parsed, name) { return parsed.entries[name.toLowerCase()] || null; }
        function boolVal(entry) {
          if (!entry) return null;
          var v = entry.value.trim().toLowerCase();
          if (v === "true") return true;
          if (v === "false") return false;
          return null;
        }
        function numVal(entry) {
          if (!entry) return null;
          var n = Number(entry.value.trim());
          return isNaN(n) ? null : n;
        }
        function isInternalHost(host) {
          if (!host) return false;
          var h = String(host).trim().toLowerCase();
          if (h === "localhost" || h === "::1") return true;
          if (/\.(local|internal|lan|home|corp|intranet)$/.test(h)) return true;
          if (/^10\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(h)) return true;
          if (/^192\.168\.\d{1,3}\.\d{1,3}$/.test(h)) return true;
          if (/^127\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(h)) return true;
          if (/^169\.254\.\d{1,3}\.\d{1,3}$/.test(h)) return true;
          var m = h.match(/^172\.(\d{1,3})\.\d{1,3}\.\d{1,3}$/);
          if (m) { var o = Number(m[1]); if (o >= 16 && o <= 31) return true; }
          return false;
        }
        function isSecretKey(lk) {
          if (lk.indexOf("publickey") !== -1) return false;
          if (lk.indexOf("public_key") !== -1) return false;
          if (/(^|_)tokensecretkey$/.test(lk) || lk === "tokensecretkey") return true;
          if (lk.indexOf("secret") !== -1) return true;
          if (lk.indexOf("password") !== -1 || lk.indexOf("passwd") !== -1) return true;
          if (lk.indexOf("credential") !== -1) return true;
          if (lk.indexOf("privatekey") !== -1 || lk.indexOf("private_key") !== -1) return true;
          if (lk.indexOf("apikey") !== -1 || lk.indexOf("api_key") !== -1) return true;
          if (lk.indexOf("accesskey") !== -1 || lk.indexOf("access_key") !== -1) return true;
          if (lk.indexOf("authenticationparameters") !== -1) return true;
          if (lk.indexOf("token") !== -1) return true;
          return false;
        }
        function secretValueExempt(value) {
          var v = value.trim();
          if (v === "") return true;
          if (/^file:\/\//i.test(v)) return true;
          if (v.indexOf("${") === 0) return true;
          var low = v.toLowerCase();
          if (low === "changeme" || low === "redacted" || low === "***" || low === "none") return true;
          return false;
        }

        /* ---------- Audit ---------- */
        function audit(text) {
          var parsed = parseConfig(text);
          var findings = [];
          function add(severity, line, key, issue, fix) {
            findings.push({ severity: severity, line: line, key: key, issue: issue, fix: fix });
          }

          var recognized = 0, strong = 0;
          parsed.order.forEach(function (lk) {
            if (KNOWN_KEYS[lk]) recognized++;
            if (STRONG_KEYS[lk]) strong++;
          });
          var settingsCount = parsed.order.length;

          var stats = {
            totalLines: parsed.totalLines,
            settings: settingsCount,
            recognized: recognized,
            commentsSkipped: parsed.comments,
            notParsed: parsed.malformed.length
          };

          if (settingsCount === 0 || (strong === 0 && recognized < 3)) {
            return {
              verdict: "NOT ENOUGH TO GRADE",
              verdictClass: "na",
              explanation: settingsCount === 0
                ? "Nothing in this paste parses as a Pulsar broker setting. A gradeable paste is broker.conf / standalone.conf style key=value lines (commented lines start with #). Paste the broker configuration itself and run the audit again."
                : "This paste parses as key=value lines, but almost none of the keys are Apache Pulsar broker settings, so it does not look like a broker.conf / standalone.conf. Grading it would be guessing. Paste the Pulsar broker configuration itself and run the audit again.",
              findings: [], stats: stats
            };
          }

          var authEntry = get(parsed, "authenticationEnabled");
          var authOn = boolVal(authEntry) === true;
          var authzEntry = get(parsed, "authorizationEnabled");
          var authzOn = boolVal(authzEntry) === true;
          var tlsEntry = get(parsed, "tlsEnabled");
          var tlsOn = boolVal(tlsEntry) === true;

          function portActive(name) {
            var e = get(parsed, name);
            if (!e) return false;
            var v = e.value.trim();
            if (v === "" ) return false;
            var n = Number(v);
            if (!isNaN(n)) return n !== 0;
            return true;
          }

          /* --- Plaintext listeners with no TLS listener --- */
          [
            { plain: "brokerServicePort", tls: "brokerServicePortTls", label: "broker service" },
            { plain: "webServicePort", tls: "webServicePortTls", label: "web service (admin REST)" }
          ].forEach(function (pair) {
            var e = get(parsed, pair.plain);
            if (!e) return;
            if (portActive(pair.tls)) return; // TLS listener configured alongside
            if (tlsOn) {
              add("FIX", e.line, e.key,
                "The plaintext " + pair.label + " port (" + e.value.trim() + ") is enabled and tlsEnabled=true, but no " + pair.tls + " listener is configured, so TLS has no port to serve on. Pulsar binds service ports on all interfaces by default.",
                "Set " + pair.tls + " to a TLS port, or disable the plaintext port if every client can use TLS.");
            } else if (!authOn) {
              add("BLOCKER", e.line, e.key,
                "The plaintext " + pair.label + " port (" + e.value.trim() + ") is enabled with no TLS listener (" + pair.tls + " is not set) and authentication is off. Pulsar binds service ports on all interfaces by default, so this port answers anyone who can reach the host, in cleartext, with no identity check.",
                "Configure " + pair.tls + ", set tlsEnabled=true with certificate paths, enable authentication, and close or firewall the plaintext port.");
            } else {
              add("FIX", e.line, e.key,
                "The plaintext " + pair.label + " port (" + e.value.trim() + ") is enabled with no TLS listener (" + pair.tls + " is not set). Credentials and message traffic to this port cross the network unencrypted.",
                "Configure " + pair.tls + " and set tlsEnabled=true, or restrict the plaintext port to a trusted network.");
            }
          });

          /* --- Authentication / authorization posture --- */
          if (!authOn) {
            add("BLOCKER", authEntry ? authEntry.line : null, "authenticationEnabled",
              authEntry
                ? "authenticationEnabled=false. Any client that can reach the broker can produce, consume, and administer without proving an identity — the broker only learns this when it is started and clients connect."
                : "authenticationEnabled is not set, and Pulsar defaults it to false. Any client that can reach the broker can produce, consume, and administer without proving an identity.",
              "Set authenticationEnabled=true and configure an authentication provider (for example the token provider) before this broker faces any network you do not fully control.");
          }
          if (authzOn && !authOn) {
            add("BLOCKER", authzEntry.line, authzEntry.key,
              "authorizationEnabled=true while authentication is disabled. Authorization decides what an authenticated identity may do; with no authenticated identity it cannot protect anything, and the setting reads as safer than the deployment is.",
              "Enable authentication first, then keep authorizationEnabled=true so roles and tenant permissions are actually enforced.");
          }
          if (authOn && !authzOn) {
            add("FIX", authzEntry ? authzEntry.line : null, "authorizationEnabled",
              authzEntry
                ? "Authentication is on but authorizationEnabled=false. Every authenticated role can then do everything — publish, subscribe, and administer across tenants."
                : "Authentication is on but authorizationEnabled is not set, so it defaults to false. Every authenticated role can then do everything — publish, subscribe, and administer across tenants.",
              "Set authorizationEnabled=true and grant roles only the tenants and namespaces they need.");
          }

          /* --- Token / JWT posture --- */
          var providersEntry = get(parsed, "authenticationProviders");
          var providersVal = providersEntry ? providersEntry.value : "";
          var tokenProvider = /authenticationprovidertoken/i.test(providersVal);
          if (tokenProvider && !authOn) {
            add("FIX", providersEntry.line, providersEntry.key,
              "A token (JWT) authentication provider is configured, but authentication is disabled, so the provider is never invoked and no token is ever checked.",
              "Set authenticationEnabled=true so the token provider actually runs, or remove the provider so the config stops implying protection it does not provide.");
          }
          if ((authOn || tokenProvider) && providersVal !== "") {
            var superEntry = get(parsed, "superUserRoles");
            if (!superEntry || superEntry.value.trim() === "") {
              add("FIX", null, "superUserRoles",
                "Authentication is configured but superUserRoles is not set. No role holds superuser rights, so tenant and namespace administration has no authorized identity and operators tend to 'fix' that later by widening access.",
                "Set superUserRoles to the admin role name(s) your operators authenticate with, and keep the list short.");
            }
            if (tokenProvider) {
              var sk = get(parsed, "tokenSecretKey");
              var pk = get(parsed, "tokenPublicKey");
              if ((!sk || sk.value.trim() === "") && (!pk || pk.value.trim() === "")) {
                add("FIX", providersEntry.line, providersEntry.key,
                  "The token provider is configured but neither tokenSecretKey nor tokenPublicKey is set, so the broker has no key material to verify tokens against.",
                  "Set tokenSecretKey (symmetric) or tokenPublicKey (asymmetric) — preferably as a file:// reference — matching the keys your clients' tokens are signed with.");
              }
            }
          }

          /* --- TLS posture --- */
          if (tlsEntry && boolVal(tlsEntry) === false) {
            if (portActive("brokerServicePort") || portActive("webServicePort")) {
              add("BLOCKER", tlsEntry.line, tlsEntry.key,
                "tlsEnabled=false while plaintext service ports are enabled. Credentials, tokens, and message payloads cross the network unencrypted, and nothing proves the broker's identity to clients.",
                "Set tlsEnabled=true, configure tlsCertificateFilePath, tlsKeyFilePath, and tlsTrustCertsFilePath, and enable the TLS listener ports.");
            } else {
              add("FIX", tlsEntry.line, tlsEntry.key,
                "tlsEnabled=false. No TLS listener posture is configured in this paste, so any listener that is enabled elsewhere serves in cleartext.",
                "Set tlsEnabled=true and configure the certificate, key, and trust store paths before exposing the broker.");
            }
          }
          var insecureEntry = get(parsed, "tlsAllowInsecureConnection");
          if (insecureEntry && boolVal(insecureEntry) === true) {
            add("FIX", insecureEntry.line, insecureEntry.key,
              "tlsAllowInsecureConnection=true tells clients to accept the broker's certificate without proper verification. That quietly defeats the identity check TLS is supposed to provide and leaves connections open to interception.",
              "Set tlsAllowInsecureConnection=false and distribute the correct CA so clients verify the broker properly.");
          }
          var reqCertEntry = get(parsed, "tlsRequireTrustedClientCertOnConnect");
          if (reqCertEntry && boolVal(reqCertEntry) === false && tlsOn) {
            add("FIX", reqCertEntry.line, reqCertEntry.key,
              "TLS is enabled but tlsRequireTrustedClientCertOnConnect=false, so the broker does not require a trusted client certificate on connect. That is fine only when token authentication is doing the identity work on every connection.",
              "Set tlsRequireTrustedClientCertOnConnect=true for mutual TLS, or confirm token authentication is enforced on all listeners.");
          }
          if (tlsOn) {
            var certEntry = get(parsed, "tlsCertificateFilePath");
            if (!certEntry || certEntry.value.trim() === "") {
              add("FIX", null, "tlsCertificateFilePath",
                "tlsEnabled=true but no tlsCertificateFilePath is set in this paste. The broker cannot present a certificate it has not been pointed at, and it will fail or fall back at startup.",
                "Set tlsCertificateFilePath (and the key and trust store paths) to the broker's certificate files.");
            }
          }

          /* --- Plaintext secrets (key name, line, value length ONLY) --- */
          parsed.order.forEach(function (lk) {
            var e = parsed.entries[lk];
            if (isSecretKey(lk) && !secretValueExempt(e.value)) {
              add("BLOCKER", e.line, e.key,
                "Plaintext secret stored in the configuration under this key (value length: " + e.value.length + " characters; the value itself is never printed by this tool). Anyone who can read this file — a repo, a backup, a ticket, a screenshot — holds the credential.",
                "Move the secret out of the config file: reference it with a file:// path or a secrets manager, and rotate it, because it has existed in plaintext.");
              return;
            }
            var credMatch = e.value.match(/:\/\/[^\/@\s]+:[^\/@\s]+@/);
            if (credMatch) {
              add("BLOCKER", e.line, e.key,
                "This value embeds a credential inside a URL (value length: " + e.value.length + " characters; the credential itself is never printed by this tool). URL-embedded credentials leak into logs, process listings, and error messages.",
                "Remove the credential from the URL, supply it through the dedicated credential setting or a file reference, and rotate it.");
            }
          });

          /* --- Advertised listeners / address --- */
          var advAddr = get(parsed, "advertisedAddress");
          if (advAddr && isInternalHost(advAddr.value)) {
            add("FIX", advAddr.line, advAddr.key,
              "advertisedAddress points at an internal host (" + advAddr.value.trim() + "). The broker hands this address to every client after connect; clients outside this network get an address they cannot reach — or one that resolves to a different machine on their own network.",
              "Set advertisedAddress to the externally reachable hostname clients should connect to, or leave it unset on a purely internal deployment and firewall the ports.");
          }
          var advList = get(parsed, "advertisedListeners");
          if (advList) {
            var hostRe = /[a-z][a-z0-9+.-]*:\/\/([^\/:,\s]+)/gi, m, badHosts = [];
            while ((m = hostRe.exec(advList.value)) !== null) {
              if (isInternalHost(m[1]) && badHosts.indexOf(m[1]) === -1) badHosts.push(m[1]);
            }
            if (badHosts.length) {
              add("FIX", advList.line, advList.key,
                "advertisedListeners includes internal host(s): " + badHosts.join(", ") + ". Clients connecting from outside are redirected to these addresses after the initial connect and will fail — or reach the wrong machine.",
                "Advertise the externally reachable listener hostnames that match your TLS certificates.");
            }
          }

          /* --- Functions worker / schema registry exposure --- */
          var fwEntry = get(parsed, "functionsWorkerEnabled");
          if (fwEntry && boolVal(fwEntry) === true && !authOn) {
            add("FIX", fwEntry.line, fwEntry.key,
              "The functions worker is enabled while authentication is off. The worker runs submitted function code; reachable without authentication, it is a code-execution surface attached to your broker.",
              "Set functionsWorkerEnabled=false unless you run Pulsar Functions, and enable authentication and authorization before exposing the worker.");
          }
          var schemaEntry = get(parsed, "schemaRegistryStorageClassName");
          if (schemaEntry && schemaEntry.value.trim() !== "" && !authOn) {
            add("FIX", schemaEntry.line, schemaEntry.key,
              "A schema registry storage class is configured while authentication is off. Schema endpoints ride the web service, so without authentication anyone who can reach it can read and overwrite topic schemas.",
              "Enable authentication and authorization, or confirm the web service port is not reachable from untrusted networks.");
          }

          /* --- Backlog / retention / load balancer (only when present) --- */
          ["backlogQuotaDefaultLimitGB", "backlogQuotaDefaultLimitBytes"].forEach(function (name) {
            var e = get(parsed, name);
            if (e && numVal(e) === -1) {
              add("FIX", e.line, e.key,
                name + " is -1, which means no default backlog limit. A stalled or abandoned consumer lets messages pile up on broker disk until the disk, not a quota, decides what happens.",
                "Set a finite default backlog limit sized to your disk, and set per-namespace quotas for noisy topics.");
            }
          });
          [
            { name: "defaultRetentionTimeInMinutes", unit: "time" },
            { name: "defaultRetentionSizeInMB", unit: "size" }
          ].forEach(function (r) {
            var e = get(parsed, r.name);
            if (e && numVal(e) === -1) {
              add("FIX", e.line, e.key,
                r.name + " is -1, which means retained data is kept forever by default. Every namespace that does not set its own retention grows without bound.",
                "Set a finite default retention that matches your storage budget; namespaces that truly need longer retention can raise it individually.");
            }
          });
          var shedEntry = get(parsed, "loadBalancerSheddingEnabled");
          if (shedEntry && boolVal(shedEntry) === false) {
            add("FIX", shedEntry.line, shedEntry.key,
              "loadBalancerSheddingEnabled=false. An overloaded broker cannot shed bundles to healthier brokers, so a hot broker stays hot while its neighbours idle.",
              "Set loadBalancerSheddingEnabled=true, or document the manual procedure operators use to move load off a hot broker.");
          }

          /* --- Duplicates --- */
          parsed.duplicates.forEach(function (d) {
            add("NOTE", d.line, d.key,
              "This key is set more than once (first set on line " + d.firstLine + "). Only the last value takes effect, so the earlier line is dead text that future editors will misread.",
              "Remove the earlier occurrence so the file says one thing.");
          });

          /* --- Malformed lines --- */
          parsed.malformed.forEach(function (mf) {
            add("NOT_PARSED", mf.line, null,
              "This line could not be parsed as a key=value setting, so it was not graded. Whatever it was meant to set is not in effect — and a line the operator believes is set, but is not, is how silent misconfigurations happen.",
              "Fix the line to key=value form, or turn it into a comment by starting it with #.");
          });

          var blockers = findings.filter(function (f) { return f.severity === "BLOCKER"; }).length;
          var fixes = findings.filter(function (f) { return f.severity === "FIX"; }).length;
          var notes = findings.filter(function (f) { return f.severity === "NOTE"; }).length;
          var notParsed = findings.filter(function (f) { return f.severity === "NOT_PARSED"; }).length;

          var verdict, verdictClass, explanation;
          if (blockers > 0) {
            verdict = "DO NOT DEPLOY"; verdictClass = "donot";
            explanation = blockers + " blocker" + (blockers === 1 ? "" : "s") + " found. Do not start this broker on any network other people can reach until every blocker is fixed and the config is re-audited.";
          } else if (fixes > 0 || notParsed > 0) {
            verdict = "DEPLOY WITH FIXES"; verdictClass = "fixes";
            explanation = "No blockers, but " + (fixes + notParsed) + " item" + ((fixes + notParsed) === 1 ? "" : "s") + " need attention. Fix them, re-paste, and re-audit before this config goes to production.";
          } else {
            verdict = "SAFE TO DEPLOY"; verdictClass = "safe";
            explanation = "No blockers and no required fixes in the settings present in this paste. This grade covers the pasted text only — it does not test the live broker, its certificates, or its network.";
          }
          stats.blockers = blockers; stats.fixes = fixes; stats.notes = notes; stats.notParsedFindings = notParsed;
          return { verdict: verdict, verdictClass: verdictClass, explanation: explanation, findings: findings, stats: stats };
        }

        /* ---------- Report / JSON builders (never include raw config or secret values) ---------- */
        function severityLabel(f) {
          return f.severity === "NOT_PARSED" ? "NOT PARSED" : f.severity;
        }
        function buildReport(result) {
          var out = [];
          out.push("J-Dawgs Pulsar Broker Config Safety Auditor - Audit Report");
          out.push("Verdict: " + result.verdict);
          out.push(result.explanation);
          out.push("");
          out.push("Paste stats: " + result.stats.totalLines + " lines, " + result.stats.settings +
            " settings parsed, " + result.stats.commentsSkipped + " comment lines skipped, " +
            result.stats.notParsed + " line(s) not parsed.");
          out.push("Findings: " + result.findings.length + " total" +
            (typeof result.stats.blockers === "number"
              ? " (" + result.stats.blockers + " blockers, " + result.stats.fixes + " fixes, " +
                result.stats.notParsedFindings + " not parsed, " + result.stats.notes + " notes)"
              : ""));
          out.push("");
          if (!result.findings.length && result.verdict !== "NOT ENOUGH TO GRADE") {
            out.push("No findings. Nothing in the pasted settings requires a fix.");
          }
          result.findings.forEach(function (f, idx) {
            out.push((idx + 1) + ". [" + severityLabel(f) + "] " +
              (f.line ? "Line " + f.line : "Key absent") +
              (f.key ? " - " + f.key : " - (unparsed line)"));
            out.push("   Issue: " + f.issue);
            out.push("   Fix: " + f.fix);
          });
          out.push("");
          out.push("Scope: this report grades the pasted text only. It does not connect to a broker, verify signatures, or test live TLS. Secret values are never printed - secrets are reported by key name, line number, and value length only.");
          return out.join("\n");
        }
        function buildJSON(result) {
          var obj = {
            tool: "J-Dawgs Pulsar Broker Config Safety Auditor",
            verdict: result.verdict,
            explanation: result.explanation,
            stats: result.stats,
            findings: result.findings.map(function (f) {
              return {
                severity: severityLabel(f),
                line: f.line,
                key: f.key,
                issue: f.issue,
                fix: f.fix
              };
            }),
            scope: "Grades pasted text only. Does not connect to a broker, verify signatures, or test live TLS. Secret values are never included; secrets are reported by key name, line number, and value length only."
          };
          return JSON.stringify(obj, null, 2);
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-pulsar-broker-config-safety-auditor-2',
  name: 'J-Dawgs Pulsar Broker Config Safety Auditor',
  description: 'pasting an Apache Pulsar broker configuration',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
