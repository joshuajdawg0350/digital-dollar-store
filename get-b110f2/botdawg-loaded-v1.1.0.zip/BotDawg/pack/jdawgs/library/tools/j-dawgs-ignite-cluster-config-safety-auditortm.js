'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Ignite Cluster Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Worked examples (line numbers are deliberate) ---------- */
      /* Risky example — planted findings:
         line 4  example cluster name
         line 5  authenticationEnabled = false
         line 8  discovery bound to 0.0.0.0
         line 10 multicast discovery ip finder
         line 14 first exposed endpoint with no sslContextFactory anywhere
         line 16 REST enabled, no credentials
         line 22 thin-client host 0.0.0.0
         line 30 persistenceEnabled = false
         line 33 walMode = NONE
         line 39 JMX host 0.0.0.0
         line 42 commented-out password — must NOT be flagged
         line 43 plaintext secret (key adminPassword, length 14) — value never printed
         line 44 NOT PARSED                                        */
      var RISKY = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<beans xmlns="http://www.springframework.org/schema/beans">',
        '  <bean id="grid.cfg" class="org.apache.ignite.configuration.IgniteConfiguration">',
        '    <property name="igniteInstanceName" value="example-cluster"/>',
        '    <property name="authenticationEnabled" value="false"/>',
        '    <property name="discoverySpi">',
        '      <bean class="org.apache.ignite.spi.discovery.tcp.TcpDiscoverySpi">',
        '        <property name="localAddress" value="0.0.0.0"/>',
        '        <property name="ipFinder">',
        '          <bean class="org.apache.ignite.spi.discovery.tcp.ipfinder.multicast.TcpIpMulticastDiscoveryIpFinder"/>',
        '        </property>',
        '      </bean>',
        '    </property>',
        '    <property name="connectorConfiguration">',
        '      <bean class="org.apache.ignite.configuration.ConnectorConfiguration">',
        '        <property name="restEnabled" value="true"/>',
        '        <property name="port" value="8080"/>',
        '      </bean>',
        '    </property>',
        '    <property name="clientConnectorConfiguration">',
        '      <bean class="org.apache.ignite.configuration.ClientConnectorConfiguration">',
        '        <property name="host" value="0.0.0.0"/>',
        '        <property name="port" value="10800"/>',
        '      </bean>',
        '    </property>',
        '    <property name="dataStorageConfiguration">',
        '      <bean class="org.apache.ignite.configuration.DataStorageConfiguration">',
        '        <property name="defaultDataRegionConfiguration">',
        '          <bean class="org.apache.ignite.configuration.DataRegionConfiguration">',
        '            <property name="persistenceEnabled" value="false"/>',
        '          </bean>',
        '        </property>',
        '        <property name="walMode" value="NONE"/>',
        '      </bean>',
        '    </property>',
        '    <property name="metricExporterSpi">',
        '      <bean class="org.apache.ignite.spi.metric.jmx.JmxExporterSpi">',
        '        <property name="jmxDomain" value="org.apache.ignite"/>',
        '        <property name="host" value="0.0.0.0"/>',
        '      </bean>',
        '    </property>',
        '    <!-- retired example only: password=commentedOutSecret99 -->',
        '    <property name="adminPassword" value="S3cretValue!42"/>',
        '    garbage line that is not a config at all !!!',
        '  </bean>',
        '</beans>'
      ].join("\n");

      /* Hardened example — must grade SAFE TO DEPLOY (no findings). */
      var HARDENED = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<beans xmlns="http://www.springframework.org/schema/beans">',
        '  <bean id="grid.cfg" class="org.apache.ignite.configuration.IgniteConfiguration">',
        '    <property name="igniteInstanceName" value="prod-billing-cluster-01"/>',
        '    <property name="authenticationEnabled" value="true"/>',
        '    <property name="sslContextFactory">',
        '      <bean class="org.apache.ignite.ssl.SslContextFactory">',
        '        <property name="keyStoreFilePath" value="/etc/ignite/keystore.jks"/>',
        '        <property name="keyStorePassword" value="${IGNITE_KEYSTORE_PASSWORD}"/>',
        '        <property name="trustStoreFilePath" value="/etc/ignite/truststore.jks"/>',
        '        <property name="trustStorePassword" value="${IGNITE_TRUSTSTORE_PASSWORD}"/>',
        '      </bean>',
        '    </property>',
        '    <property name="discoverySpi">',
        '      <bean class="org.apache.ignite.spi.discovery.tcp.TcpDiscoverySpi">',
        '        <property name="localAddress" value="10.0.0.11"/>',
        '        <property name="ipFinder">',
        '          <bean class="org.apache.ignite.spi.discovery.tcp.ipfinder.vm.TcpIpDiscoveryIpFinder">',
        '            <property name="addresses">',
        '              <list>',
        '                <value>10.0.0.11:47500</value>',
        '                <value>10.0.0.12:47500</value>',
        '                <value>10.0.0.13:47500</value>',
        '              </list>',
        '            </property>',
        '          </bean>',
        '        </property>',
        '      </bean>',
        '    </property>',
        '    <property name="connectorConfiguration">',
        '      <bean class="org.apache.ignite.configuration.ConnectorConfiguration">',
        '        <property name="restEnabled" value="false"/>',
        '      </bean>',
        '    </property>',
        '    <property name="clientConnectorConfiguration">',
        '      <bean class="org.apache.ignite.configuration.ClientConnectorConfiguration">',
        '        <property name="host" value="10.0.0.11"/>',
        '        <property name="port" value="10800"/>',
        '      </bean>',
        '    </property>',
        '    <property name="dataStorageConfiguration">',
        '      <bean class="org.apache.ignite.configuration.DataStorageConfiguration">',
        '        <property name="defaultDataRegionConfiguration">',
        '          <bean class="org.apache.ignite.configuration.DataRegionConfiguration">',
        '            <property name="persistenceEnabled" value="true"/>',
        '          </bean>',
        '        </property>',
        '        <property name="walMode" value="DEFAULT"/>',
        '        <property name="walArchiveEnabled" value="true"/>',
        '      </bean>',
        '    </property>',
        '    <property name="metricExporterSpi">',
        '      <bean class="org.apache.ignite.spi.metric.jmx.JmxExporterSpi">',
        '        <property name="host" value="127.0.0.1"/>',
        '      </bean>',
        '    </property>',
        '  </bean>',
        '</beans>'
      ].join("\n");

      /* ---------- Comment stripping ---------- */
      function activeText(raw, state){
        var out = "", i = 0;
        while (i < raw.length){
          if (state.xml){
            var e = raw.indexOf("-->", i);
            if (e < 0){ i = raw.length; } else { state.xml = false; i = e + 3; }
          } else if (state.java){
            var e2 = raw.indexOf("*/", i);
            if (e2 < 0){ i = raw.length; } else { state.java = false; i = e2 + 2; }
          } else if (raw.substr(i, 4) === "<!--"){ state.xml = true; i += 4; }
          else if (raw.substr(i, 2) === "/*"){ state.java = true; i += 2; }
          else { out += raw.charAt(i); i++; }
        }
        return out;
      }

      function isParsable(t){
        if (t.charAt(0) === "<" && t.indexOf(">") > -1) return true;
        if (/^[A-Za-z0-9_.\-]+\s*[:=]/.test(t)) return true;
        if (/^-\s+\S/.test(t)) return true;
        if (/\w+\.\w+\s*\(/.test(t) || /^\w+\s*\(/.test(t)) return true;
        if (/^[}\])]+[;,]?$/.test(t)) return true;
        if (t.indexOf("=") > -1) return true;
        return false;
      }

      var SECRET_KEY = /(password|passwd|secret|token|api[-_]?key|access[-_]?key|credential)/i;
      var DEFAULT_CRED_VALUES = ["password","password123","admin","ignite","secret","changeme","change-me","default","example","test","123456","qwerty","letmein","passw0rd"];

      function isPlaceholder(v){
        if (!v) return true;
        if (v.indexOf("${") === 0 || v.charAt(0) === "$") return true;
        if (v.indexOf("{{") === 0) return true;
        if (/^ENC\(/i.test(v)) return true;
        if (/^vault:/i.test(v)) return true;
        if (/^env:/i.test(v)) return true;
        if (/^\*+$/.test(v)) return true;
        if (/^(null|none|""|''|)$/i.test(v)) return true;
        return false;
      }

      function extractValue(line){
        var m = line.match(/value\s*=\s*"([^"]*)"/);
        if (m) return m[1];
        m = line.match(/value\s*=\s*'([^']*)'/);
        if (m) return m[1];
        m = line.match(/[:=]\s*"?([^"\s<]+)"?/);
        if (m) return m[1];
        m = line.match(/\(\s*"([^"]*)"\s*\)/);
        if (m) return m[1];
        return null;
      }

      /* ---------- The audit ---------- */
      function audit(text){
        var rawLines = text.split(/\r?\n/);
        var state = { xml:false, java:false };
        var active = [], commentedCount = 0, i, t;
        for (i = 0; i < rawLines.length; i++){
          var a = activeText(rawLines[i], state);
          t = a.trim();
          if (t.indexOf("#") === 0 || t.indexOf("//") === 0) a = "";
          if (rawLines[i].trim() && !a.trim()) commentedCount++;
          active.push(a);
        }
        var all = active.join("\n");
        var lower = all.toLowerCase();
        var findings = [];
        function add(line, sev, check, detail, extra){
          var f = { line: line, severity: sev, check: check, detail: detail };
          if (extra){
            if (extra.keyName) f.keyName = extra.keyName;
            if (typeof extra.secretLength === "number") f.secretLength = extra.secretLength;
          }
          findings.push(f);
        }
        function firstLine(re){
          for (var j = 0; j < active.length; j++){ if (re.test(active[j])) return j + 1; }
          return 0;
        }

        /* NOT PARSED lines (reported for every paste) */
        var notParsedCount = 0;
        for (i = 0; i < active.length; i++){
          t = active[i].trim();
          if (t && !isParsable(t)){
            notParsedCount++;
            add(i + 1, "NOT PARSED", "Unparsed line",
              "This line does not match any Ignite configuration form this tool understands (Spring XML, properties, or docker-compose/env), so it was not graded.");
          }
        }

        /* Recognizable Ignite configuration? */
        var markers = ["ignite","tcpdiscovery","discoveryspi","datastorage","dataregion",
          "sslcontextfactory","authenticationenabled","connectorconfiguration",
          "clientconnector","tcpip","gridgain","metricsexporter"];
        var recog = false;
        for (i = 0; i < markers.length; i++){ if (lower.indexOf(markers[i]) > -1){ recog = true; break; } }

        var format = "Unrecognized";
        if (lower.indexOf("<bean") > -1 || text.indexOf("<?xml") > -1) format = "Spring XML";
        else if (/(^|\n)\s*services:|image\s*:|environment\s*:|IGNITE_/.test(text)) format = "docker-compose / env";
        else if (recog) format = "Properties / IgniteConfiguration style";

        if (!recog){
          add(0, "INFO", "Not enough to grade",
            "No recognizable Apache Ignite configuration was found in the active (non-commented) text, so there is nothing to grade. Paste a Spring XML, properties, or docker-compose/env Ignite configuration.");
          return finish("NOT ENOUGH TO GRADE");
        }

        var igniteCfgLine = firstLine(/IgniteConfiguration/i) || 1;

        /* --- Discovery: multicast --- */
        for (i = 0; i < active.length; i++){
          if (/multicast/i.test(active[i])){
            add(i + 1, "CRITICAL", "Discovery — multicast",
              "Multicast discovery (TcpIpMulticastDiscoveryIpFinder) is in use. It finds nodes by broadcast, which is unreliable or blocked in most clouds and can pull in nodes you did not intend. Use TcpIpDiscoveryIpFinder with an explicit address list instead.");
          }
        }

        /* --- Bindings to 0.0.0.0 (all interfaces), categorized by nearest context --- */
        for (i = 0; i < active.length; i++){
          if (active[i].indexOf("0.0.0.0") === -1) continue;
          var cat = null;
          for (var b = i; b >= Math.max(0, i - 10) && !cat; b--){
            var bl = active[b].toLowerCase();
            if (bl.indexOf("jmx") > -1 || bl.indexOf("metric") > -1) cat = "jmx";
            else if (bl.indexOf("client") > -1 || bl.indexOf("thin") > -1 || bl.indexOf("control") > -1) cat = "client";
            else if (bl.indexOf("discovery") > -1 || bl.indexOf("tcpip") > -1) cat = "discovery";
            else if (bl.indexOf("rest") > -1 || bl.indexOf("connector") > -1 || bl.indexOf("jetty") > -1) cat = "rest";
          }
          if (cat === "jmx"){
            add(i + 1, "HIGH", "Metrics / JMX — all interfaces",
              "A metrics or JMX endpoint is bound to 0.0.0.0, so it answers on every network interface. Bind it to 127.0.0.1 or one trusted management address.");
          } else if (cat === "client"){
            add(i + 1, "CRITICAL", "Thin client / control port — all interfaces",
              "A thin-client or control port host is set to 0.0.0.0, so any machine that can reach this host can attempt a client connection. Bind it to a specific interface and put it behind your firewall rules.");
          } else if (cat === "discovery"){
            add(i + 1, "HIGH", "Discovery — all interfaces",
              "Discovery is bound to 0.0.0.0 (all interfaces). Set the discovery local address to the one interface the cluster should talk on.");
          } else if (cat === "rest"){
            add(i + 1, "HIGH", "REST / connector — all interfaces",
              "A REST or connector endpoint is bound to 0.0.0.0 (all interfaces). Bind it to a specific interface.");
          } else {
            add(i + 1, "HIGH", "Network binding — all interfaces",
              "This setting binds to 0.0.0.0, which means every network interface. Bind to one specific address instead.");
          }
        }

        /* --- Authentication --- */
        var authFound = false;
        for (i = 0; i < active.length; i++){
          if (/authenticationEnabled/i.test(active[i])){
            authFound = true;
            if (/false/i.test(active[i])){
              add(i + 1, "CRITICAL", "Authentication off",
                "authenticationEnabled is set to false. Any node or client that can reach the cluster can join or connect without credentials. Set it to true and give every node the same credentials.");
            }
          }
        }
        if (!authFound){
          add(igniteCfgLine, "HIGH", "Authentication not set",
            "authenticationEnabled is never set in the active configuration, and Ignite authentication is off by default. Set authenticationEnabled to true explicitly.");
        }

        /* --- SSL vs exposed endpoints --- */
        var sslPresent = lower.indexOf("sslcontextfactory") > -1 || /sslcontext/i.test(all);
        var endpointRe = /(restEnabled|connectorConfiguration|clientConnectorConfiguration|TcpRest|ignite-rest-http|[Jj]mx|[Mm]etricExporter|10800|11211|8080)/;
        var firstEndpoint = firstLine(endpointRe);
        for (i = 0; i < active.length; i++){
          if (/sslEnabled/i.test(active[i]) && /false/i.test(active[i])){
            add(i + 1, "CRITICAL", "SSL explicitly disabled",
              "SSL is switched off in the configuration. Cluster and client traffic will cross the network unencrypted.");
          }
        }
        if (!sslPresent && firstEndpoint){
          add(firstEndpoint, "HIGH", "SSL missing while endpoints are exposed",
            "No sslContextFactory is configured anywhere in the active text, but remote endpoints (REST, connector, thin client, JMX, or metrics) are present — the first is on this line. Traffic to those endpoints is unencrypted. Add an sslContextFactory with a real keystore.");
        }

        /* --- REST enabled without credentials --- */
        var restLine = 0;
        for (i = 0; i < active.length; i++){
          if (/restEnabled/i.test(active[i]) && /true/i.test(active[i])) restLine = i + 1;
          if (/ignite-rest-http|TcpRest/i.test(active[i])) restLine = i + 1;
        }
        if (!restLine){
          var ccLine = firstLine(/connectorConfiguration/i);
          var restDisabled = false;
          for (i = 0; i < active.length; i++){ if (/restEnabled/i.test(active[i]) && /false/i.test(active[i])) restDisabled = true; }
          if (ccLine && !restDisabled) restLine = ccLine;
        }
        var restCreds = /(secretKey|restAuth|jettyConfig|basicAuth)/i.test(all);
        if (!restCreds){
          for (i = 0; i < active.length; i++){
            if (SECRET_KEY.test(active[i]) && /(rest|jetty|connector)/i.test(active[i])) restCreds = true;
          }
        }
        if (restLine && !restCreds){
          add(restLine, "CRITICAL", "REST API without credentials",
            "The REST API is enabled and no REST credentials (secret key, auth configuration, or password) appear anywhere in the configuration. Anyone who can reach the REST port can read and change cluster data. Disable REST, or put credentials on it.");
        }

        /* --- Plaintext secrets: key name, line, and length ONLY --- */
        var seenSecret = {};
        for (i = 0; i < active.length; i++){
          var line = active[i], key = null, val = null, m;
          m = line.match(/name\s*=\s*"([^"]+)"[^>]*value\s*=\s*"([^"]*)"/);
          if (m && SECRET_KEY.test(m[1])){ key = m[1]; val = m[2]; }
          if (!key){
            m = line.match(/(set[A-Za-z0-9_]*?(?:[Pp]assword|[Ss]ecret|[Tt]oken)[A-Za-z0-9_]*)\s*\(\s*"([^"]*)"\s*\)/);
            if (m){ key = m[1]; val = m[2]; }
          }
          if (!key){
            m = line.match(/([A-Za-z0-9_.\-]*(?:password|passwd|secret|token|api[-_]?key|access[-_]?key|credential)[A-Za-z0-9_.\-]*)\s*[:=]\s*["']?([^\s"'<]+)/i);
            if (m){ key = m[1]; val = m[2]; }
          }
          if (key && val !== null && !isPlaceholder(val)){
            var dedupe = (i + 1) + "|" + key.toLowerCase();
            if (!seenSecret[dedupe]){
              seenSecret[dedupe] = true;
              add(i + 1, "CRITICAL", "Plaintext secret",
                "A secret is stored in plaintext in the configuration. It is reported by key name, line, and length only — the value itself is never shown in this tool's output. Move it to an environment variable or a secrets store and reference it (for example with a ${...} placeholder).",
                { keyName: key, secretLength: val.length });
              if (DEFAULT_CRED_VALUES.indexOf(val.toLowerCase()) > -1){
                add(i + 1, "MEDIUM", "Example / default credential",
                  "This credential is a widely known example or default value. Anyone who has seen the public examples knows it. Replace it with a unique secret kept out of the file.",
                  { keyName: key, secretLength: val.length });
              }
            }
          }
        }

        /* --- Persistence and WAL --- */
        var persistenceFound = false, dsLine = firstLine(/dataStorageConfiguration/i);
        for (i = 0; i < active.length; i++){
          if (/persistenceEnabled/i.test(active[i])){
            persistenceFound = true;
            if (/false/i.test(active[i])){
              add(i + 1, "HIGH", "Persistence disabled",
                "persistenceEnabled is false for this data region. Data lives only in memory and is gone when the cluster stops. Turn persistence on for any data you cannot afford to lose.");
            }
          }
          if (/walMode/i.test(active[i])){
            var wv = (extractValue(active[i]) || "").toUpperCase();
            if (wv === "NONE"){
              add(i + 1, "CRITICAL", "WAL disabled",
                "walMode is NONE: the write-ahead log is off, so a crash can lose acknowledged writes even with persistence on. Use the DEFAULT or BACKGROUND walMode.");
            } else if (wv === "LOG_ONLY"){
              add(i + 1, "MEDIUM", "WAL mode LOG_ONLY",
                "walMode LOG_ONLY gives weaker crash-recovery guarantees than the default. Confirm that trade-off is deliberate before deploying.");
            }
          }
          if (/walArchiveEnabled/i.test(active[i]) && /false/i.test(active[i])){
            add(i + 1, "LOW", "WAL archiving off",
              "walArchiveEnabled is false. WAL archiving is what point-in-time recovery and some backup flows rely on — know that it is off.");
          }
        }
        if (!persistenceFound && dsLine){
          add(dsLine, "MEDIUM", "Persistence not set",
            "A dataStorageConfiguration is present but persistenceEnabled is never set, and persistence is off unless it is explicitly enabled. Set persistenceEnabled to true for data regions that must survive a restart.");
        }
        if (!persistenceFound && !dsLine && firstLine(/IgniteConfiguration/i)){
          add(igniteCfgLine, "MEDIUM", "No data storage configuration",
            "No dataStorageConfiguration was found, so native persistence posture is not configured at all. If this cluster holds data that matters, configure a data region with persistence and a WAL mode.");
        }
        if (dsLine && !/walMode/i.test(all)){
          add(dsLine, "LOW", "WAL mode not set",
            "walMode is never set explicitly, so Ignite's default applies. Setting it in the file makes the crash-recovery posture clear to the next reader.");
        }

        /* --- Discovery posture --- */
        if (firstLine(/IgniteConfiguration/i) && lower.indexOf("discoveryspi") === -1){
          add(igniteCfgLine, "MEDIUM", "Discovery not configured",
            "No discoverySpi is configured, so Ignite's default discovery applies — and the default finder is multicast. Configure TcpDiscoverySpi with a static TcpIpDiscoveryIpFinder address list.");
        }
        for (i = 0; i < active.length; i++){
          if (/TcpIpDiscoveryIpFinder/.test(active[i]) && !/Multicast/.test(active[i])){
            var hasAddr = false;
            for (var j = i; j < Math.min(active.length, i + 12); j++){
              if (/addresses/i.test(active[j]) || /<value>\s*\d/.test(active[j]) || /addresses\s*[:=]/.test(active[j])) hasAddr = true;
            }
            if (!hasAddr){
              add(i + 1, "MEDIUM", "Static discovery with no addresses",
                "TcpIpDiscoveryIpFinder is configured but no addresses are listed near it. With no seed addresses, nodes may not find each other — or may fall back to broader discovery than you intended.");
            }
          }
        }

        /* --- Example / default cluster names --- */
        for (i = 0; i < active.length; i++){
          var nm = active[i].match(/name\s*=\s*"(igniteInstanceName|clusterName|gridName|instanceName)"[^>]*value\s*=\s*"([^"]*)"/i);
          var nv = null, nkey = null;
          if (nm){ nkey = nm[1]; nv = nm[2]; }
          if (!nv){
            var pm = active[i].trim().match(/^(igniteInstanceName|clusterName|gridName|IGNITE_INSTANCE_NAME|IGNITE_CLUSTER_NAME)\s*[:=]\s*["']?([^\s"']+)/i);
            if (pm){ nkey = pm[1]; nv = pm[2]; }
          }
          if (nv){
            var lv = nv.toLowerCase();
            if (lv.indexOf("example") > -1 || lv.indexOf("default") > -1 || lv.indexOf("demo") > -1 ||
                lv.indexOf("sample") > -1 || lv === "test" || lv === "cluster" || lv === "ignite" ||
                lv === "mycluster" || lv === "my-cluster"){
              add(i + 1, "MEDIUM", "Example / default cluster name",
                "The cluster or instance name (key: " + nkey + ") is a known example or default name. Give the cluster a real, unique name — shared default names are how test and production clusters get mixed up.");
            }
          }
        }

        return finish(null);

        function finish(forcedVerdict){
          var rank = { "CRITICAL":0, "HIGH":1, "MEDIUM":2, "LOW":3, "NOT PARSED":4, "INFO":5 };
          findings.sort(function(x, y){
            if (x.line !== y.line) return x.line - y.line;
            return (rank[x.severity] || 9) - (rank[y.severity] || 9);
          });
          var counts = { CRITICAL:0, HIGH:0, MEDIUM:0, LOW:0, "NOT PARSED":0, INFO:0 };
          findings.forEach(function(f){ counts[f.severity] = (counts[f.severity] || 0) + 1; });
          var verdict = forcedVerdict;
          if (!verdict){
            if (counts.CRITICAL > 0) verdict = "DO NOT DEPLOY";
            else if (counts.HIGH > 0 || counts.MEDIUM > 0 || counts["NOT PARSED"] > 0) verdict = "DEPLOY WITH FIXES";
            else verdict = "SAFE TO DEPLOY";
          }
          return {
            verdict: verdict, format: format, findings: findings, counts: counts,
            totalLines: rawLines.length, commentedLines: commentedCount
          };
        }
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-ignite-cluster-config-safety-auditortm',
  name: 'J-Dawgs Ignite Cluster Config Safety Auditor',
  description: 'Grades a pasted Apache Ignite cluster configuration fully offline into one deploy verdict, with plaintext secrets shown by key name, line, and length only, never by value. Ignite only exercises a config by starting the cluster; this grades it before anything starts.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
