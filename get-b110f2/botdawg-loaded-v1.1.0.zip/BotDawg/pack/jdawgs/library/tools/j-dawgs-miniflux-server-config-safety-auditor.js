'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Miniflux Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var RECOGNIZED = {};
        [
          "LISTEN_ADDR","BASE_URL","CREATE_ADMIN","ADMIN_USERNAME","ADMIN_PASSWORD",
          "DATABASE_URL","RUN_MIGRATIONS","POLLING_FREQUENCY","POLLING_BATCH_SIZE",
          "METRICS_LISTEN_ADDR","METRICS_ALLOWED_NETWORKS","DISABLE_HTTP_SERVICE","HTTPS",
          "OAUTH2_ENABLED","OAUTH2_PROVIDER","OAUTH2_CLIENT_ID","OAUTH2_CLIENT_SECRET",
          "OAUTH2_REDIRECT_URL","PROXY_OPTION","PROXY_MEDIA_TYPES","HTTP_CLIENT_TIMEOUT",
          "HTTP_CLIENT_MAX_BODY_SIZE","WORKER_POOL_SIZE","SCHEDULER_FREQUENCY","BATCH_SIZE"
        ].forEach(function (k) { RECOGNIZED[k] = true; });

        var WEAK_PASSWORDS = ["admin","admin123","password","password123","changeme","example","miniflux","letmein","123456","12345678"];

        var RISKY_EXAMPLE = [
          "LISTEN_ADDR=0.0.0.0:8080",
          "BASE_URL=http://reader.example.com",
          "CREATE_ADMIN=1",
          "ADMIN_USERNAME=admin",
          "ADMIN_PASSWORD=admin123",
          "DATABASE_URL=postgres://miniflux:short@db.internal:5432/miniflux?sslmode=disable",
          "RUN_MIGRATIONS=1",
          "POLLING_FREQUENCY=1",
          "METRICS_LISTEN_ADDR=0.0.0.0:8081",
          "HTTP_CLIENT_TIMEOUT=30"
        ].join("\n");

        var HARDENED_EXAMPLE = [
          "LISTEN_ADDR=127.0.0.1:8080",
          "BASE_URL=https://reader.example.com",
          "CREATE_ADMIN=0",
          "ADMIN_USERNAME=admin",
          "ADMIN_PASSWORD=Xk9mQ2vLp7Rt4wNz8Hs3",
          "DATABASE_URL=postgres://miniflux:Kj8wQ2mNv9Lp4Rt7Xs3Zd6@db.internal:5432/miniflux?sslmode=require",
          "RUN_MIGRATIONS=0",
          "POLLING_FREQUENCY=60",
          "POLLING_BATCH_SIZE=100",
          "METRICS_LISTEN_ADDR=127.0.0.1:8081",
          "METRICS_ALLOWED_NETWORKS=127.0.0.1/32",
          "HTTP_CLIENT_TIMEOUT=30"
        ].join("\n");

        var input = document.getElementById("config-input");
        var statusLine = document.getElementById("status-line");
        var verdictPanel = document.getElementById("verdict-panel");
        var verdictText = document.getElementById("verdict-text");
        var countsRow = document.getElementById("counts-row");
        var lineCounts = document.getElementById("line-counts");
        var findingsWrap = document.getElementById("findings-wrap");
        var findingsBody = document.getElementById("findings-body");
        var noFindings = document.getElementById("no-findings");

        var lastResult = null;

        function setStatus(msg) { statusLine.textContent = msg; }

        function isTruthy(v) {
          var s = String(v).trim().toLowerCase();
          return s === "1" || s === "true" || s === "yes" || s === "on";
        }

        function isNumeric(v) {
          return /^-?\d+(\.\d+)?$/.test(String(v).trim());
        }

        function listenHost(v) {
          var s = String(v).trim();
          if (s.charAt(0) === "[") {
            var end = s.indexOf("]");
            return end >= 0 ? s.slice(0, end + 1) : s;
          }
          if (s.indexOf(":") === -1) return s;
          var parts = s.split(":");
          if (parts.length > 2) return s; /* bare IPv6 address, no port */
          return parts[0];
        }

        function isAllInterfaces(host) {
          return host === "" || host === "0.0.0.0" || host === "::" || host === "[::]" || host === "*";
        }

        function isLoopbackHost(host) {
          var h = String(host).toLowerCase();
          return h === "127.0.0.1" || h === "localhost" || h === "::1" || h === "[::1]";
        }

        function parseDbUrl(v) {
          var m = String(v).match(/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\/(.*)$/);
          if (!m) return null;
          var rest = m[1];
          var slash = rest.indexOf("/");
          var authority = slash === -1 ? rest : rest.slice(0, slash);
          var q = String(v).indexOf("?");
          var query = q === -1 ? "" : String(v).slice(q + 1);
          var password = null;
          var hostport = authority;
          var at = authority.lastIndexOf("@");
          if (at >= 0) {
            var ui = authority.slice(0, at);
            hostport = authority.slice(at + 1);
            var c = ui.indexOf(":");
            if (c >= 0) password = ui.slice(c + 1);
          }
          var host = hostport.replace(/:\d+$/, "").replace(/^\[/, "").replace(/\]$/, "");
          var sslmode = null;
          var sm = query.match(/sslmode=([a-zA-Z-]+)/);
          if (sm) sslmode = sm[1].toLowerCase();
          return { password: password, host: host, sslmode: sslmode };
        }

        function parseConfig(text) {
          var rawLines = text === "" ? [] : text.split("\n");
          var entries = [];
          var findings = [];
          var notParsed = 0;
          rawLines.forEach(function (raw, idx) {
            var lineNo = idx + 1;
            var t = raw.trim();
            if (t === "") return;
            if (t.charAt(0) === "#" || t.charAt(0) === ";") return;
            var m = t.match(/^([A-Za-z_][A-Za-z0-9_]*)\s*[:=]\s*(.*)$/);
            if (!m) {
              notParsed++;
              findings.push({
                line: lineNo, severity: "INFO", code: "NOT_PARSED", key: "",
                message: "This line could not be read as a KEY=VALUE or KEY: VALUE setting, so it was not checked. (Line contents are never echoed back.)",
                fix: "Rewrite the line as KEY=VALUE, comment it out with # or ;, or remove it."
              });
              return;
            }
            var key = m[1].toUpperCase();
            var value = m[2].trim();
            if (value.length >= 2) {
              var first = value.charAt(0), last = value.charAt(value.length - 1);
              if ((first === '"' && last === '"') || (first === "'" && last === "'")) {
                value = value.slice(1, -1);
              }
            }
            entries.push({ line: lineNo, key: key, value: value });
            if (!RECOGNIZED[key]) {
              findings.push({
                line: lineNo, severity: "INFO", code: "UNRECOGNIZED", key: key,
                message: "This key is not in the auditor's known Miniflux key list, so its value was not checked. Unknown keys do not fail the audit.",
                fix: "Check the spelling against the configuration reference for your Miniflux version."
              });
            }
          });
          return { entries: entries, findings: findings, totalLines: rawLines.length, parsed: entries.length, notParsed: notParsed };
        }

        function audit(text) {
          var parsed = parseConfig(text);
          var findings = parsed.findings.slice();
          var byKey = {};
          parsed.entries.forEach(function (e) {
            if (!byKey[e.key]) byKey[e.key] = [];
            byKey[e.key].push(e);
          });
          function first(key) { return byKey[key] && byKey[key].length ? byKey[key][0] : null; }
          function add(line, severity, code, key, message, fix) {
            findings.push({ line: line, severity: severity, code: code, key: key, message: message, fix: fix });
          }

          var listen = first("LISTEN_ADDR");
          var baseUrl = first("BASE_URL");
          var createAdmin = first("CREATE_ADMIN");
          var adminUser = first("ADMIN_USERNAME");
          var adminPass = first("ADMIN_PASSWORD");
          var dbUrl = first("DATABASE_URL");
          var runMig = first("RUN_MIGRATIONS");
          var createAdminOn = createAdmin ? isTruthy(createAdmin.value) : false;
          var runMigOn = runMig ? isTruthy(runMig.value) : false;

          /* 1. LISTEN_ADDR exposure */
          if (listen) {
            var host = listenHost(listen.value);
            if (isAllInterfaces(host)) {
              add(listen.line, "CRITICAL", "EXPOSED_LISTEN", "LISTEN_ADDR",
                "LISTEN_ADDR is bound to every network interface (host \"" + (host === "" ? "(empty)" : host) + "\"), so the reader — including its login page — is reachable from anywhere that can route to this machine.",
                "Bind to loopback instead (LISTEN_ADDR=127.0.0.1:8080) and reach it through a reverse proxy or tunnel, or firewall the port to trusted networks only.");
            }
          }

          /* 2. BASE_URL scheme */
          if (baseUrl) {
            if (/^http:\/\//i.test(baseUrl.value.trim())) {
              add(baseUrl.line, "CRITICAL", "INSECURE_BASE_URL", "BASE_URL",
                "BASE_URL starts with http://, so logins, session cookies, and feed credentials cross the network unencrypted.",
                "Serve the reader over HTTPS and set BASE_URL to the https:// address.");
            }
          } else if (listen && parsed.parsed > 0) {
            add(0, "MEDIUM", "MISSING_BASE_URL", "BASE_URL",
              "No BASE_URL is set even though a listener is configured. If this reader is reached through a public host name or a proxy, generated links and redirects can point at the wrong scheme or host.",
              "Set BASE_URL to the exact public address of the reader, starting with https://.");
          }

          /* 3. ADMIN_PASSWORD strength — value never rendered, length only */
          var adminPassWeak = false;
          if (adminPass) {
            var apv = adminPass.value;
            var inWeakList = WEAK_PASSWORDS.indexOf(apv.toLowerCase()) >= 0;
            if (inWeakList || apv.length < 12) {
              adminPassWeak = true;
              add(adminPass.line, "CRITICAL", "WEAK_ADMIN_PASSWORD", "ADMIN_PASSWORD",
                "ADMIN_PASSWORD (line " + adminPass.line + ", length " + apv.length + ") is too weak" + (inWeakList ? " — it is a commonly used password that appears on every guessing list." : " — it is under the 12-character minimum."),
                "Use a unique password of at least 16 characters, generated by a password manager. The value is never shown in this audit — only its length.");
            } else if (apv.length <= 15) {
              adminPassWeak = true;
              add(adminPass.line, "HIGH", "WEAK_ADMIN_PASSWORD", "ADMIN_PASSWORD",
                "ADMIN_PASSWORD (line " + adminPass.line + ", length " + apv.length + ") is only 12–15 characters — usable, but thin for an account that can administer the whole reader.",
                "Lengthen the admin password to at least 16 characters. The value is never shown in this audit — only its length.");
            }
          }

          /* 4 + 12. CREATE_ADMIN posture */
          if (createAdminOn) {
            add(createAdmin.line, "HIGH", "CREATE_ADMIN_LEFT_ON", "CREATE_ADMIN",
              "CREATE_ADMIN is switched on, so every restart re-creates or resets the admin account from this config — a standing door if the config file leaks.",
              "Turn CREATE_ADMIN off (0) after the first successful boot and remove the stored admin password from the config once the account exists.");
            if (!adminUser) {
              add(createAdmin.line, "MEDIUM", "MISSING_ADMIN_USERNAME", "ADMIN_USERNAME",
                "CREATE_ADMIN is on but no ADMIN_USERNAME is set, so the boot-time admin creation has no explicit account name to work with.",
                "Set ADMIN_USERNAME alongside CREATE_ADMIN, or turn CREATE_ADMIN off if the admin account already exists.");
            }
          }

          /* 9. Migrations + create-admin both on at boot */
          if (runMigOn && createAdminOn) {
            add(runMig.line, "MEDIUM", "MIGRATIONS_WITH_CREATE_ADMIN", "RUN_MIGRATIONS",
              "RUN_MIGRATIONS and CREATE_ADMIN are both switched on, so every boot runs schema migrations and admin-account creation automatically — two standing auto-actions that can surprise you during an incident or a rollback.",
              "Once the server is up and the admin exists, turn CREATE_ADMIN off and run migrations deliberately during upgrades instead of on every boot.");
          }

          /* 5. DATABASE_URL — embedded password never rendered, length only */
          if (dbUrl) {
            var db = parseDbUrl(dbUrl.value);
            if (db) {
              var hasPw = db.password !== null && db.password.length > 0;
              var sslOk = db.sslmode === "require" || db.sslmode === "verify-ca" || db.sslmode === "verify-full";
              if (hasPw && db.password.length < 12) {
                add(dbUrl.line, "CRITICAL", "WEAK_DB_PASSWORD", "DATABASE_URL",
                  "The password embedded in DATABASE_URL (line " + dbUrl.line + ", length " + db.password.length + ") is under the 12-character minimum, and the database account can usually reach every feed and credential the reader stores.",
                  "Rotate the database password to a unique value of at least 16 characters. The value is never shown in this audit — only its length.");
              }
              if (db.sslmode === "disable") {
                add(dbUrl.line, "HIGH", "DB_SSL", "DATABASE_URL",
                  "DATABASE_URL sets sslmode=disable, so the database connection — password included — travels unencrypted.",
                  "Use sslmode=require (or verify-full with certificates) for any database reached over a network.");
              } else if (!db.sslmode && !isLoopbackHost(db.host)) {
                add(dbUrl.line, "HIGH", "DB_SSL", "DATABASE_URL",
                  "DATABASE_URL names a non-local database host but sets no sslmode, so whether the connection is encrypted depends on defaults you do not control here.",
                  "Add sslmode=require (or verify-full) to DATABASE_URL explicitly.");
              }
              if (hasPw && !sslOk) {
                add(dbUrl.line, "MEDIUM", "DB_PASSWORD_PLAINTEXT", "DATABASE_URL",
                  "A database password sits in plaintext in DATABASE_URL (line " + dbUrl.line + ", length " + db.password.length + ") while the connection is not set to require encryption — the secret is exposed in the file and potentially on the wire.",
                  "Require SSL for the database connection, restrict who can read this config file, and consider supplying the password through your service manager's secret handling instead of the config text.");
              }
            }
          }

          /* 6. Metrics exposure */
          var metricsAddr = first("METRICS_LISTEN_ADDR");
          var metricsAllow = first("METRICS_ALLOWED_NETWORKS");
          if (metricsAddr) {
            var mHost = listenHost(metricsAddr.value);
            if (isAllInterfaces(mHost)) {
              add(metricsAddr.line, "CRITICAL", "METRICS_EXPOSED", "METRICS_LISTEN_ADDR",
                "METRICS_LISTEN_ADDR is bound to every network interface, so the metrics endpoint — which reveals usage and internals — is open to anyone who can reach this machine.",
                "Bind metrics to loopback (127.0.0.1) or a private management network only.");
            }
            if (!metricsAllow || metricsAllow.value.trim() === "") {
              add(metricsAddr.line, "HIGH", "METRICS_NO_ALLOWLIST", "METRICS_ALLOWED_NETWORKS",
                "A metrics listener is configured but METRICS_ALLOWED_NETWORKS is missing or empty, so nothing restricts which networks may read the metrics endpoint.",
                "Set METRICS_ALLOWED_NETWORKS to a tight CIDR allowlist, for example 127.0.0.1/32 for local-only scraping.");
            }
          }
          if (metricsAllow && /(^|[,\s])(0\.0\.0\.0\/0|::\/0)(\s|$|,)/.test(metricsAllow.value.trim())) {
            add(metricsAllow.line, "HIGH", "METRICS_ALLOWLIST_OPEN", "METRICS_ALLOWED_NETWORKS",
              "METRICS_ALLOWED_NETWORKS allows every network (a /0 range), which is the same as having no allowlist at all.",
              "Restrict METRICS_ALLOWED_NETWORKS to the networks that actually scrape metrics, such as 127.0.0.1/32.");
          }

          /* 7. Polling behaviour */
          var pollFreq = first("POLLING_FREQUENCY");
          if (pollFreq) {
            var pfv = pollFreq.value.trim();
            if (!isNumeric(pfv)) {
              add(pollFreq.line, "HIGH", "POLLING_INVALID", "POLLING_FREQUENCY",
                "POLLING_FREQUENCY is not a number, so the polling interval falls back to behaviour you did not choose.",
                "Set POLLING_FREQUENCY to a plain number of minutes, 15 or higher.");
            } else {
              var pf = parseFloat(pfv);
              if (pf < 5) {
                add(pollFreq.line, "HIGH", "POLLING_TOO_FREQUENT", "POLLING_FREQUENCY",
                  "POLLING_FREQUENCY is " + pfv + " — feeds would be fetched almost constantly, hammering the sites you follow and risking rate limits or bans.",
                  "Raise POLLING_FREQUENCY to at least 15 minutes; 60 is a courteous default for most feeds.");
              } else if (pf < 15) {
                add(pollFreq.line, "MEDIUM", "POLLING_TOO_FREQUENT", "POLLING_FREQUENCY",
                  "POLLING_FREQUENCY is " + pfv + " minutes — workable, but aggressive across many feeds and hard on small publishers.",
                  "Consider 15 minutes or more unless a few specific feeds genuinely need faster checks.");
              }
            }
          }
          var pollBatch = first("POLLING_BATCH_SIZE");
          if (pollBatch && isNumeric(pollBatch.value) && parseFloat(pollBatch.value) > 500) {
            add(pollBatch.line, "MEDIUM", "POLLING_BATCH_TOO_LARGE", "POLLING_BATCH_SIZE",
              "POLLING_BATCH_SIZE is " + pollBatch.value.trim() + " — very large batches can burst outbound requests and memory use at each polling run.",
              "Bring POLLING_BATCH_SIZE back to 500 or below unless you have measured a need for more.");
          }

          /* 8. HTTP client timeout */
          var timeout = first("HTTP_CLIENT_TIMEOUT");
          if (timeout) {
            var tv = timeout.value.trim();
            if (!isNumeric(tv)) {
              add(timeout.line, "MEDIUM", "HTTP_TIMEOUT_INVALID", "HTTP_CLIENT_TIMEOUT",
                "HTTP_CLIENT_TIMEOUT is not a number, so feed fetches use a fallback timeout you did not choose.",
                "Set HTTP_CLIENT_TIMEOUT to a plain number of seconds, 30 is a sane default.");
            } else if (parseFloat(tv) > 120) {
              add(timeout.line, "MEDIUM", "HTTP_TIMEOUT_TOO_LONG", "HTTP_CLIENT_TIMEOUT",
                "HTTP_CLIENT_TIMEOUT is " + tv + " seconds — a hung feed server can tie up fetch workers for over two minutes per request.",
                "Bring HTTP_CLIENT_TIMEOUT down to 120 seconds or less; 30 is a sane default.");
            }
          } else if (parsed.parsed > 0) {
            add(0, "LOW", "MISSING_HTTP_TIMEOUT", "HTTP_CLIENT_TIMEOUT",
              "HTTP_CLIENT_TIMEOUT is not set, so feed fetching relies on the built-in default rather than a limit you chose.",
              "Set HTTP_CLIENT_TIMEOUT explicitly (30 is a sane default) so slow feed servers cannot hold workers indefinitely.");
          }

          /* 10. OAuth2 / OIDC */
          var oauthOn = first("OAUTH2_ENABLED");
          if (oauthOn && isTruthy(oauthOn.value)) {
            var redirect = first("OAUTH2_REDIRECT_URL");
            if (redirect && /^http:\/\//i.test(redirect.value.trim())) {
              add(redirect.line, "HIGH", "OAUTH2_INSECURE_REDIRECT", "OAUTH2_REDIRECT_URL",
                "OAUTH2 is enabled but OAUTH2_REDIRECT_URL uses http://, so the sign-in handshake returns over an unencrypted connection.",
                "Serve the reader over HTTPS and set OAUTH2_REDIRECT_URL to the matching https:// address registered with your provider.");
            }
          }
          var oauthSecret = first("OAUTH2_CLIENT_SECRET");
          if (oauthSecret && oauthSecret.value.length < 16) {
            add(oauthSecret.line, "HIGH", "WEAK_OAUTH2_SECRET", "OAUTH2_CLIENT_SECRET",
              "OAUTH2_CLIENT_SECRET (line " + oauthSecret.line + ", length " + oauthSecret.value.length + ") is under 16 characters — unusually weak for a provider-issued secret, and a sign it may have been truncated or hand-typed.",
              "Copy the full client secret from your OAuth2 provider and store it like a password. The value is never shown in this audit — only its length.");
          }

          /* Sort findings by line (config-level findings with line 0 go last), then severity. */
          var sevRank = { CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3, INFO: 4 };
          findings.sort(function (a, b) {
            var la = a.line === 0 ? 999999 : a.line;
            var lb = b.line === 0 ? 999999 : b.line;
            if (la !== lb) return la - lb;
            return sevRank[a.severity] - sevRank[b.severity];
          });

          var counts = { CRITICAL: 0, HIGH: 0, MEDIUM: 0, LOW: 0, INFO: 0 };
          findings.forEach(function (f) { counts[f.severity]++; });

          var recognizedParsed = 0;
          parsed.entries.forEach(function (e) { if (RECOGNIZED[e.key]) recognizedParsed++; });

          var verdict;
          if (parsed.parsed === 0 || recognizedParsed < 3) {
            verdict = "NOT ENOUGH TO GRADE";
          } else if (counts.CRITICAL > 0) {
            verdict = "DO NOT DEPLOY";
          } else if (counts.HIGH > 0 || counts.MEDIUM > 0) {
            verdict = "DEPLOY WITH FIXES";
          } else {
            verdict = "SAFE TO DEPLOY";
          }

          return {
            verdict: verdict,
            counts: counts,
            totalLines: parsed.totalLines,
            parsed: parsed.parsed,
            notParsed: parsed.notParsed,
            findings: findings
          };
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-miniflux-server-config-safety-auditor',
  name: 'J-Dawgs Miniflux Server Config Safety Auditor',
  description: 'Host tools only tell you the server started; ours grades a pasted Miniflux server config (.env style) offline into one deploy verdict — secrets by key name/line/length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
