'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Sonarr Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Example fixtures ---------- */

      var RISKY_EXAMPLE = [
        "<Config>",
        "  <Port>8989</Port>",
        "  <SslPort>9898</SslPort>",
        "  <EnableSsl>False</EnableSsl>",
        "  <LaunchBrowser>True</LaunchBrowser>",
        "  <ApiKey>abc123example</ApiKey>",
        "  <AuthenticationMethod>None</AuthenticationMethod>",
        "  <BindAddress>*</BindAddress>",
        "  <LogLevel>info</LogLevel>",
        "  <Branch>main</Branch>",
        "  <UrlBase></UrlBase>",
        "  <DownloadClientPassword>hunter2secret</DownloadClientPassword>",
        "</Config>"
      ].join("\n");

      var HARDENED_EXAMPLE = [
        "<Config>",
        "  <Port>8989</Port>",
        "  <SslPort>9898</SslPort>",
        "  <EnableSsl>True</EnableSsl>",
        "  <LaunchBrowser>False</LaunchBrowser>",
        "  <ApiKey>9f2c7a41b8e04d6fa3c51e87d2b4906e</ApiKey>",
        "  <AuthenticationMethod>Forms</AuthenticationMethod>",
        "  <AuthenticationRequired>Enabled</AuthenticationRequired>",
        "  <BindAddress>127.0.0.1</BindAddress>",
        "  <LogLevel>info</LogLevel>",
        "  <Branch>main</Branch>",
        "  <UpdateMechanism>BuiltIn</UpdateMechanism>",
        "  <UrlBase></UrlBase>",
        "</Config>"
      ].join("\n");

      /* ---------- Parsing ---------- */

      function normKey(k) {
        return String(k).toLowerCase().replace(/[^a-z0-9]/g, "");
      }

      function parseConfig(text) {
        var lines = String(text).split(/\r?\n/);
        var entries = [];
        for (var i = 0; i < lines.length; i++) {
          var lineNo = i + 1;
          var t = lines[i].trim();
          if (!t) continue;
          var m = t.match(/^<([A-Za-z][A-Za-z0-9_.-]*)>([^<]*)<\/\1>$/);
          if (m) {
            entries.push({ key: normKey(m[1]), rawKey: m[1], value: m[2].trim(), line: lineNo });
            continue;
          }
          m = t.match(/^<([A-Za-z][A-Za-z0-9_.-]*)\s*\/>$/);
          if (m) {
            entries.push({ key: normKey(m[1]), rawKey: m[1], value: "", line: lineNo });
            continue;
          }
          m = t.match(/^([A-Za-z_][A-Za-z0-9_.\-]*)\s*=\s*(.*)$/);
          if (m) {
            var v = m[2].trim();
            if ((v.charAt(0) === '"' && v.charAt(v.length - 1) === '"') ||
                (v.charAt(0) === "'" && v.charAt(v.length - 1) === "'")) {
              v = v.slice(1, -1);
            }
            entries.push({ key: normKey(m[1]), rawKey: m[1], value: v, line: lineNo });
          }
        }
        return entries;
      }

      var KNOWN_KEYS = [
        "port", "sslport", "enablessl", "launchbrowser", "apikey",
        "authenticationmethod", "authenticationenabled", "authenticationrequired",
        "bindaddress", "loglevel", "branch", "urlbase", "updatemechanism",
        "instancename", "sslcertpath", "sslcertpassword", "backupfolder",
        "backupinterval", "backupretention", "proxyenabled", "proxytype",
        "proxyhostname", "proxyport", "proxyusername", "proxypassword",
        "proxypasswordbypass", "analyticsenabled", "logretention",
        "syslogserver", "syslogport", "sysloglevel", "updateallowedips"
      ];

      function isKnown(entry) {
        if (entry.rawKey.toLowerCase().indexOf("sonarr") !== -1) return true;
        for (var i = 0; i < KNOWN_KEYS.length; i++) {
          if (entry.key === KNOWN_KEYS[i] || entry.key.slice(-KNOWN_KEYS[i].length) === KNOWN_KEYS[i] && entry.key.length > KNOWN_KEYS[i].length) return true;
          if (entry.key === KNOWN_KEYS[i]) return true;
        }
        if (entry.key.indexOf("password") !== -1 || entry.key.indexOf("passwd") !== -1) return true;
        return false;
      }

      function findEntry(entries, target) {
        var i, k;
        /* Exact key match wins (last occurrence, like a real config load) —
           this keeps "port" from being shadowed by "sslport". */
        var exact = null;
        for (i = 0; i < entries.length; i++) {
          if (entries[i].key === target) exact = entries[i];
        }
        if (exact) return exact;
        /* Fall back to prefixed env-style names, e.g. SONARR__SERVER__PORT. */
        var found = null;
        for (i = 0; i < entries.length; i++) {
          k = entries[i].key;
          if (k.length > target.length && k.slice(-target.length) === target) {
            found = entries[i];
          }
        }
        return found;
      }

      function truthy(v) {
        var s = String(v).trim().toLowerCase();
        return s === "true" || s === "1" || s === "yes" || s === "on" || s === "enabled";
      }
      function falsy(v) {
        var s = String(v).trim().toLowerCase();
        return s === "false" || s === "0" || s === "no" || s === "off" || s === "disabled" || s === "none" || s === "";
      }

      var PLACEHOLDER_RE = /example|changeme|change[-_ ]?me|your[-_ ]?(api[-_ ]?)?key|placeholder|insert[-_ ]?key|replace[-_ ]?me|xxxxx+|0{6,}|123456|abcdef|dummy|sample|testkey|apikeyhere/i;

      /* ---------- Grading ---------- */

      function auditConfig(text) {
        var findings = [];
        var passed = [];
        function add(sev, key, line, msg) {
          findings.push({ severity: sev, key: key, line: line, message: msg });
        }
        function pass(label, line) {
          passed.push({ check: label, line: line });
        }

        var raw = String(text == null ? "" : text);
        if (raw.trim() === "") {
          return {
            verdict: "NOT ENOUGH TO GRADE",
            reason: "The input is empty — paste a Sonarr config.xml or KEY=VALUE settings to grade.",
            findings: [], passed: [], recognized: 0
          };
        }

        var entries = parseConfig(raw);
        var recognized = 0;
        var i, e;
        for (i = 0; i < entries.length; i++) if (isKnown(entries[i])) recognized++;

        if (recognized === 0) {
          return {
            verdict: "NOT ENOUGH TO GRADE",
            reason: "No recognizable Sonarr settings were found in the pasted text — it reads as prose or a different file, not a Sonarr config.xml or Sonarr KEY=VALUE settings.",
            findings: [], passed: [], recognized: 0
          };
        }

        /* --- Authentication --- */
        var authEnabled = findEntry(entries, "authenticationenabled");
        var authMethod = findEntry(entries, "authenticationmethod");
        var authRequired = findEntry(entries, "authenticationrequired");
        var authBlocked = false;

        if (authEnabled && falsy(authEnabled.value) && !truthy(authEnabled.value)) {
          add("BLOCKER", "AuthenticationEnabled", authEnabled.line,
            "AuthenticationEnabled is set to a disabled value — anyone who can reach the port gets full control of Sonarr with no login.");
          authBlocked = true;
        }
        if (authMethod) {
          var method = authMethod.value.trim().toLowerCase();
          if (method === "none" || method === "disabled" || method === "") {
            add("BLOCKER", "AuthenticationMethod", authMethod.line,
              "AuthenticationMethod disables authentication — the web UI and API answer with no login challenge.");
            authBlocked = true;
          } else if (method === "forms") {
            if (!authRequired) {
              add("BLOCKER", "AuthenticationMethod", authMethod.line,
                "AuthenticationMethod is Forms but AuthenticationRequired is not set — no auth challenge is configured, so the form may never be enforced.");
              authBlocked = true;
            } else if (authRequired.value.trim().toLowerCase() === "disabledforlocaladdresses") {
              add("WARNING", "AuthenticationRequired", authRequired.line,
                "AuthenticationRequired is DisabledForLocalAddresses — anything on the local network reaches Sonarr with no login.");
            }
          } else if (method === "basic" || method === "external") {
            /* challenged methods — fine */
          } else {
            add("WARNING", "AuthenticationMethod", authMethod.line,
              "Unrecognized AuthenticationMethod value — confirm Sonarr actually enforces a login with it.");
          }
        }
        if (!authEnabled && !authMethod) {
          add("BLOCKER", "AuthenticationMethod", null,
            "No authentication setting found (AuthenticationEnabled / AuthenticationMethod absent) — a fresh Sonarr config can run with no login protecting the UI and API.");
          authBlocked = true;
        }
        if (!authBlocked) {
          var authLine = authMethod ? authMethod.line : (authEnabled ? authEnabled.line : null);
          var authWhat = authMethod ? ("method \"" + authMethod.value.trim() + "\"") : "enabled";
          pass("Authentication is on (" + authWhat + ") and a challenge is configured.", authLine);
          if (authRequired && authRequired.value.trim().toLowerCase() === "enabled") {
            pass("AuthenticationRequired is Enabled — logins are challenged on all addresses.", authRequired.line);
          }
        }

        /* --- API key (length only — value never reported) --- */
        var apiKey = findEntry(entries, "apikey");
        if (!apiKey) {
          add("BLOCKER", "ApiKey", null,
            "ApiKey is missing — the config carries no API credential at all, so the deployment cannot be told apart from an unauthenticated one.");
        } else if (apiKey.value.trim() === "") {
          add("BLOCKER", "ApiKey", apiKey.line,
            "ApiKey is present but empty (length 0) — no API credential is configured.");
        } else {
          var keyLen = apiKey.value.length;
          var isPlaceholder = PLACEHOLDER_RE.test(apiKey.value) || /^(.)\1+$/.test(apiKey.value);
          if (keyLen < 32) {
            add("BLOCKER", "ApiKey", apiKey.line,
              "ApiKey is too short: length " + keyLen + " (Sonarr API keys are 32 characters). A short key is guessable and is usually a leftover example. Value not shown.");
          } else if (isPlaceholder) {
            add("BLOCKER", "ApiKey", apiKey.line,
              "ApiKey matches an example/placeholder pattern (length " + keyLen + ") — replace it with a real generated key before deploying. Value not shown.");
          } else {
            pass("ApiKey present at full length (" + keyLen + " characters) with no placeholder pattern. Value not shown.", apiKey.line);
          }
        }

        /* --- Bind address --- */
        var bind = findEntry(entries, "bindaddress");
        if (!bind) {
          add("WARNING", "BindAddress", null,
            "BindAddress is not set — Sonarr binds to all network interfaces by default, so the port is reachable from the whole network.");
        } else {
          var bv = bind.value.trim();
          if (bv === "*" || bv === "0.0.0.0" || bv === "::" || bv === "[::]") {
            add("HIGH", "BindAddress", bind.line,
              "BindAddress is \"" + bv + "\" — Sonarr listens on every network interface, exposing the UI and API to the whole network (and beyond, if the host is reachable).");
          } else {
            pass("BindAddress is restricted to \"" + bv + "\" instead of all interfaces.", bind.line);
          }
        }

        /* --- Ports --- */
        var port = findEntry(entries, "port");
        var sslPort = findEntry(entries, "sslport");
        function portNum(en) {
          if (!en) return null;
          var n = parseInt(en.value, 10);
          return isNaN(n) ? null : n;
        }
        var portVal = portNum(port);
        var sslPortVal = portNum(sslPort);
        if (port && portVal === null) {
          add("WARNING", "Port", port.line, "Port value is not a number — Sonarr may fall back to a default or fail to bind.");
        }
        if (sslPort && sslPortVal === null) {
          add("WARNING", "SslPort", sslPort.line, "SslPort value is not a number — the SSL listener cannot be set up from this value.");
        }
        if (port && sslPort && portVal !== null && sslPortVal !== null) {
          if (portVal === sslPortVal) {
            add("WARNING", "Port/SslPort", sslPort.line,
              "Port and SslPort are the same (" + portVal + ") — the plaintext and SSL listeners conflict; one of them will fail or shadow the other.");
          } else {
            pass("Port (" + portVal + ") and SslPort (" + sslPortVal + ") do not conflict.", sslPort.line);
          }
        }

        /* --- SSL --- */
        var ssl = findEntry(entries, "enablessl");
        var exposedPort = portVal !== null ? portVal : 8989;
        if (!ssl) {
          add("HIGH", "EnableSsl", null,
            "EnableSsl is not set — SSL is off by default, so port " + exposedPort + " serves the UI, the API key, and logins in plaintext.");
        } else if (falsy(ssl.value)) {
          add("HIGH", "EnableSsl", ssl.line,
            "EnableSsl is false while port " + exposedPort + " is exposed — the UI, the API key, and login credentials travel in plaintext.");
        } else {
          pass("EnableSsl is on — the SSL listener serves the UI over TLS.", ssl.line);
          if (sslPort && !ssl) { /* unreachable, kept for clarity */ }
        }
        if (sslPort && ssl && falsy(ssl.value)) {
          add("WARNING", "SslPort", sslPort.line,
            "An SslPort (" + sslPort.value.trim() + ") is configured but EnableSsl is false — that port will not serve TLS until SSL is enabled.");
        }

        /* --- URL base --- */
        var urlBase = findEntry(entries, "urlbase");
        if (urlBase) {
          var ub = urlBase.value.trim();
          if (ub === "") {
            pass("UrlBase is empty — Sonarr is served at the root path, which is consistent.", urlBase.line);
          } else if (ub.indexOf("://") !== -1 || ub.indexOf("\\") !== -1 || /\s/.test(ub)) {
            add("WARNING", "UrlBase", urlBase.line,
              "UrlBase \"" + ub + "\" is malformed — it should be a plain path segment like /sonarr, not a full URL or a path with spaces/backslashes. A wrong UrlBase breaks the UI and API routing behind a reverse proxy.");
          } else if (ub.charAt(0) !== "/") {
            add("WARNING", "UrlBase", urlBase.line,
              "UrlBase \"" + ub + "\" does not start with \"/\" — Sonarr expects a leading slash (e.g. /sonarr); without it, links and API routes can break.");
          } else {
            pass("UrlBase is a well-formed path (\"" + ub + "\").", urlBase.line);
          }
        }

        /* --- Plaintext download-client / indexer credentials (length only) --- */
        var credCount = 0;
        for (i = 0; i < entries.length; i++) {
          e = entries[i];
          var isPasswordKey = e.key.indexOf("password") !== -1 || e.key.indexOf("passwd") !== -1;
          if (isPasswordKey && e.key !== "sslcertpassword" && e.value.trim() !== "") {
            add("HIGH", e.rawKey, e.line,
              "Plaintext credential stored in the config: key \"" + e.rawKey + "\", value length " + e.value.length + " (value never shown). Anyone who reads this file owns that download-client / indexer account.");
            credCount++;
          }
          if (isPasswordKey && e.key === "sslcertpassword" && e.value.trim() !== "") {
            add("HIGH", e.rawKey, e.line,
              "Plaintext SSL certificate password stored in the config: key \"" + e.rawKey + "\", value length " + e.value.length + " (value never shown).");
            credCount++;
          }
        }
        if (credCount === 0) {
          pass("No plaintext download-client or indexer passwords found in the pasted text.", null);
        }

        /* --- Log level --- */
        var logLevel = findEntry(entries, "loglevel");
        if (logLevel) {
          var ll = logLevel.value.trim().toLowerCase();
          if (ll === "debug" || ll === "trace") {
            add("WARNING", "LogLevel", logLevel.line,
              "LogLevel is \"" + ll + "\" — debug/trace logs can record API keys, URLs with credentials, and indexer details, and they grow fast. Use info for a deployed server.");
          } else {
            pass("LogLevel is \"" + logLevel.value.trim() + "\" — not a verbose debug/trace level.", logLevel.line);
          }
        }

        /* --- Update posture (informational) --- */
        var upd = findEntry(entries, "updatemechanism");
        if (upd) {
          add("INFO", "UpdateMechanism", upd.line,
            "UpdateMechanism is \"" + upd.value.trim() + "\" — informational: make sure whoever owns this deployment knows updates arrive this way, and that the mechanism is actually run.");
        }
        var branch = findEntry(entries, "branch");
        if (branch) {
          var br = branch.value.trim().toLowerCase();
          if (br === "main" || br === "master") {
            add("INFO", "Branch", branch.line,
              "Branch is \"" + branch.value.trim() + "\" — the stable release branch. Informational only.");
          } else {
            add("INFO", "Branch", branch.line,
              "Branch is \"" + branch.value.trim() + "\" — a non-stable branch; expect pre-release builds on this server. Informational only.");
          }
        }

        /* --- Verdict --- */
        var counts = { BLOCKER: 0, HIGH: 0, WARNING: 0, INFO: 0 };
        for (i = 0; i < findings.length; i++) counts[findings[i].severity]++;

        var verdict, reason;
        if (counts.BLOCKER > 0) {
          verdict = "DO NOT DEPLOY";
          reason = counts.BLOCKER + " blocker finding(s) — the server would run without working authentication or a real API key. Fix the blockers first.";
        } else if (counts.HIGH > 0 || counts.WARNING > 0) {
          verdict = "DEPLOY WITH FIXES";
          reason = "No blockers, but " + counts.HIGH + " high and " + counts.WARNING + " warning finding(s) should be fixed before this config faces a network.";
        } else {
          verdict = "SAFE TO DEPLOY";
          reason = "No blockers, highs, or warnings — every graded check passed on the pasted text.";
        }

        var order = { BLOCKER: 0, HIGH: 1, WARNING: 2, INFO: 3 };
        findings.sort(function (a, b) {
          if (order[a.severity] !== order[b.severity]) return order[a.severity] - order[b.severity];
          var la = a.line === null ? 9999 : a.line;
          var lb = b.line === null ? 9999 : b.line;
          return la - lb;
        });

        return { verdict: verdict, reason: reason, findings: findings, passed: passed, recognized: recognized, counts: counts };
      }

      /* ---------- Reports ---------- */

      function lineLabel(line) {
        return line === null || line === undefined ? "not present" : "line " + line;
      }

      function buildTextReport(result) {
        var out = [];
        out.push("J-Dawgs Sonarr Server Config Safety Auditor — report");
        out.push("Verdict: " + result.verdict);
        out.push("Why: " + result.reason);
        if (result.counts) {
          out.push("Findings: " + result.counts.BLOCKER + " blocker, " + result.counts.HIGH + " high, " +
                   result.counts.WARNING + " warning, " + result.counts.INFO + " info. Passed checks: " + result.passed.length + ".");
        }
        out.push("");
        out.push("FINDINGS");
        if (result.findings.length === 0) out.push("(none)");
        for (var i = 0; i < result.findings.length; i++) {
          var f = result.findings[i];
          out.push("[" + f.severity + "] " + f.key + " (" + lineLabel(f.line) + "): " + f.message);
        }
        out.push("");
        out.push("PASSED CHECKS");
        if (result.passed.length === 0) out.push("(none)");
        for (var j = 0; j < result.passed.length; j++) {
          var p = result.passed[j];
          out.push("[PASS] " + p.check + (p.line ? " (" + lineLabel(p.line) + ")" : ""));
        }
        out.push("");
        out.push("Note: secret values are reported by key name, line, and length only — never by value.");
        return out.join("\n");
      }

      function buildJsonReport(result) {
        var obj = {
          tool: "J-Dawgs Sonarr Server Config Safety Auditor",
          verdict: result.verdict,
          reason: result.reason,
          counts: result.counts || { BLOCKER: 0, HIGH: 0, WARNING: 0, INFO: 0 },
          findings: result.findings.map(function (f) {
            return { severity: f.severity, key: f.key, line: f.line, message: f.message };
          }),
          passedChecks: result.passed.map(function (p) {
            return { check: p.check, line: p.line };
          }),
          secretHandling: "Secret values are reported by key name, line, and length only — never by value."
        };
        return JSON.stringify(obj, null, 2);
      }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-sonarr-server-config-safety-auditortm',
  name: 'J-Dawgs Sonarr Server Config Safety Auditor',
  description: 'Sonarr\'s own checks only answer whether the service starts on the host; ours grades a pasted Sonarr config.xml or env fully offline — authentication disabled, a short or example ApiKey, wildcard bind, SSL off, plaintext download-client and indexer passwords — into one deploy verdict, with secrets sh',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
