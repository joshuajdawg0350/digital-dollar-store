'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Calendar Invite Integrity Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var BROKEN_ICS = [
        "BEGIN:VCALENDAR",
        "VERSION:2.0",
        "PRODID:-//Example//Broken Invite//EN",
        "BEGIN:VEVENT",
        "DTSTART:20270614T150000Z",
        "DTEND:20270614T160000Z",
        "SUMMARY:Vendor call",
        "ORGANIZER:mailto:lead@example.com",
        "END:VEVENT",
        "BEGIN:VEVENT",
        "UID:overlap-b@example.com",
        "DTSTAMP:20261103T120000Z",
        "DTSTART:20270614T153000Z",
        "DTEND:20270614T163000Z",
        "SUMMARY:Site walkthrough",
        "ORGANIZER:mailto:lead@example.com",
        "END:VEVENT",
        "BEGIN:VEVENT",
        "UID:floating-c@example.com",
        "DTSTAMP:20261103T120000Z",
        "DTSTART:20270615T090000",
        "DTEND:20270615T100000",
        "SUMMARY:Floating-time crew huddle",
        "ORGANIZER:mailto:lead@example.com",
        "END:VEVENT",
        "BEGIN:VEVENT",
        "UID:daily-d@example.com",
        "DTSTAMP:20261103T120000Z",
        "DTSTART:20270616T130000Z",
        "DTEND:20270616T133000Z",
        "RRULE:FREQ=DAILY",
        "SUMMARY:Open-ended daily toolbox talk",
        "ORGANIZER:mailto:lead@example.com",
        "END:VEVENT",
        "END:VCALENDAR"
      ].join("\r\n");

      var CLEAN_ICS = [
        "BEGIN:VCALENDAR",
        "VERSION:2.0",
        "PRODID:-//Example//Clean Invite//EN",
        "BEGIN:VTIMEZONE",
        "TZID:America/Chicago",
        "BEGIN:STANDARD",
        "DTSTART:19701101T020000",
        "TZOFFSETFROM:-0500",
        "TZOFFSETTO:-0600",
        "TZNAME:CST",
        "END:STANDARD",
        "BEGIN:DAYLIGHT",
        "DTSTART:19700308T020000",
        "TZOFFSETFROM:-0600",
        "TZOFFSETTO:-0500",
        "TZNAME:CDT",
        "END:DAYLIGHT",
        "END:VTIMEZONE",
        "BEGIN:VEVENT",
        "UID:clean-1@example.com",
        "DTSTAMP:20261103T120000Z",
        "DTSTART;TZID=America/Chicago:20270614T090000",
        "DTEND;TZID=America/Chicago:20270614T100000",
        "SUMMARY:Framing inspection for the north wall and",
        "  roof tie-ins on the garage side",
        "ORGANIZER:mailto:lead@example.com",
        "END:VEVENT",
        "BEGIN:VEVENT",
        "UID:clean-2@example.com",
        "DTSTAMP:20261103T120000Z",
        "DTSTART:20270621T140000Z",
        "DTEND:20270621T150000Z",
        "RRULE:FREQ=WEEKLY;COUNT=4",
        "SUMMARY:Weekly progress check-in",
        "ORGANIZER:mailto:lead@example.com",
        "END:VEVENT",
        "END:VCALENDAR"
      ].join("\r\n");

      /* ---------- parsing ---------- */

      // RFC 5545 unfolding: a line starting with a space or tab continues the previous line.
      function unfold(text) {
        var raw = text.replace(/\r\n/g, "\n").replace(/\r/g, "\n").split("\n");
        var lines = [];
        for (var i = 0; i < raw.length; i++) {
          var l = raw[i];
          if ((l.charAt(0) === " " || l.charAt(0) === "\t") && lines.length) {
            lines[lines.length - 1] += l.slice(1);
          } else {
            lines.push(l);
          }
        }
        return lines;
      }

      function parseProp(line) {
        var idx = line.indexOf(":");
        if (idx < 0) return null;
        var left = line.slice(0, idx);
        var value = line.slice(idx + 1).trim();
        var parts = left.split(";");
        var name = parts[0].toUpperCase();
        var dot = name.lastIndexOf(".");
        if (dot >= 0) name = name.slice(dot + 1); // strip group prefix like "item1."
        var params = {};
        for (var i = 1; i < parts.length; i++) {
          var eq = parts[i].indexOf("=");
          if (eq > 0) {
            params[parts[i].slice(0, eq).toUpperCase()] = parts[i].slice(eq + 1).replace(/^"|"$/g, "");
          }
        }
        return { name: name, params: params, value: value };
      }

      function parseCalendar(text) {
        var lines = unfold(text);
        var timezones = {};   // TZID -> true, from VTIMEZONE blocks
        var events = [];      // array of { props: {NAME: [prop,...]} }
        var stack = [];
        var currentEvent = null;
        var inTimezone = false;
        for (var i = 0; i < lines.length; i++) {
          var line = lines[i];
          if (!line) continue;
          var upper = line.toUpperCase();
          if (upper.indexOf("BEGIN:") === 0) {
            var comp = upper.slice(6).trim();
            stack.push(comp);
            if (comp === "VEVENT") currentEvent = { props: {} };
            if (comp === "VTIMEZONE") inTimezone = true;
            continue;
          }
          if (upper.indexOf("END:") === 0) {
            var endComp = upper.slice(4).trim();
            if (endComp === "VEVENT" && currentEvent) { events.push(currentEvent); currentEvent = null; }
            if (endComp === "VTIMEZONE") inTimezone = false;
            var si = stack.lastIndexOf(endComp);
            if (si >= 0) stack.length = si;
            continue;
          }
          var prop = parseProp(line);
          if (!prop) continue;
          if (inTimezone && stack[stack.length - 1] === "VTIMEZONE" && prop.name === "TZID") {
            timezones[prop.value] = true;
          }
          if (currentEvent) {
            if (!currentEvent.props[prop.name]) currentEvent.props[prop.name] = [];
            currentEvent.props[prop.name].push(prop);
          }
        }
        return { timezones: timezones, events: events };
      }

      function firstProp(ev, name) {
        var arr = ev.props[name];
        return arr && arr.length ? arr[0] : null;
      }

      // Parse an iCalendar DATE or DATE-TIME value into a comparable number
      // (wall-clock components treated uniformly; Z/TZID noted separately).
      function parseDTValue(v) {
        var m = /^(\d{4})(\d{2})(\d{2})(?:T(\d{2})(\d{2})(\d{2})?)?(Z)?$/.exec(v.trim());
        if (!m) return null;
        var hasTime = m[4] !== undefined;
        var ts = Date.UTC(+m[1], +m[2] - 1, +m[3], hasTime ? +m[4] : 0, hasTime ? +m[5] : 0, hasTime ? +(m[6] || 0) : 0);
        return { ts: ts, dateOnly: !hasTime, utc: !!m[7] };
      }

      // Minimal ISO 8601 duration (PnW, PnDTnHnMnS) -> seconds, or null.
      function parseDuration(v) {
        var m = /^([+-])?P(?:(\d+)W)?(?:(\d+)D)?(?:T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?)?$/.exec(v.trim());
        if (!m) return null;
        var secs = (+(m[2] || 0)) * 604800 + (+(m[3] || 0)) * 86400 + (+(m[4] || 0)) * 3600 + (+(m[5] || 0)) * 60 + (+(m[6] || 0));
        return m[1] === "-" ? -secs : secs;
      }

      function parseRRule(v) {
        var out = {};
        var parts = v.split(";");
        for (var i = 0; i < parts.length; i++) {
          var eq = parts[i].indexOf("=");
          if (eq > 0) out[parts[i].slice(0, eq).toUpperCase()] = parts[i].slice(eq + 1).toUpperCase();
        }
        return out;
      }

      // Estimated occurrences in the first year for the simple FREQ cases.
      function estimateFirstYear(rrule) {
        var freq = rrule.FREQ || "";
        var interval = parseInt(rrule.INTERVAL || "1", 10);
        if (!(interval > 0)) interval = 1;
        switch (freq) {
          case "DAILY":
            return "≈" + Math.round(365 / interval) + " occurrences in the first year";
          case "WEEKLY": {
            var days = rrule.BYDAY ? rrule.BYDAY.split(",").length : 1;
            return "≈" + Math.round((52 / interval) * days) + " occurrences in the first year" +
              (rrule.BYDAY ? " (" + days + " day(s) per week per BYDAY)" : "");
          }
          case "MONTHLY":
            return "≈" + Math.round(12 / interval) + " occurrences in the first year" +
              (rrule.BYDAY ? " (BYDAY present; counted as one occurrence per scheduled month)" : "");
          case "YEARLY":
            return interval <= 1
              ? "≈1 occurrence per year, forever"
              : "≈1 occurrence every " + interval + " years, forever";
          default:
            return "first-year count not estimated for FREQ=" + (freq || "(missing)");
        }
      }

      function fmtDT(prop) {
        if (!prop) return "—";
        var tz = prop.params.TZID ? " [" + prop.params.TZID + "]" : "";
        var v = prop.value;
        var m = /^(\d{4})(\d{2})(\d{2})(?:T(\d{2})(\d{2})(\d{2})?)?(Z)?$/.exec(v);
        if (!m) return v + tz;
        var s = m[1] + "-" + m[2] + "-" + m[3];
        if (m[4] !== undefined) s += " " + m[4] + ":" + m[5] + (m[7] ? " UTC" : "");
        return s + tz;
      }

      /* ---------- audit ---------- */

      function audit(text, expectedTz, todayStr) {
        var parsed = parseCalendar(text);
        var events = parsed.events;
        var tzDefs = parsed.timezones;
        var todayStart = null;
        if (todayStr) {
          var tm = /^(\d{4})-(\d{2})-(\d{2})$/.exec(todayStr);
          if (tm) todayStart = Date.UTC(+tm[1], +tm[2] - 1, +tm[3]);
        }

        var results = [];
        var uidSeen = {}; // uid -> [indices]

        events.forEach(function (ev, i) {
          var issues = [];
          function err(t) { issues.push({ level: "error", text: t }); }
          function warn(t) { issues.push({ level: "warn", text: t }); }

          var summaryProp = firstProp(ev, "SUMMARY");
          var summary = summaryProp ? summaryProp.value.replace(/\\,/g, ",").replace(/\\n/gi, " ") : "(no SUMMARY)";

          var uidProp = firstProp(ev, "UID");
          var uid = uidProp ? uidProp.value : null;
          if (!uid) err("Missing UID — the event has no stable identity for updates or cancellations.");
          else {
            if (!uidSeen[uid]) uidSeen[uid] = [];
            uidSeen[uid].push(i);
          }

          if (!firstProp(ev, "DTSTAMP")) err("Missing DTSTAMP — RFC 5545 requires a creation timestamp on every VEVENT.");

          var dtstart = firstProp(ev, "DTSTART");
          var dtend = firstProp(ev, "DTEND");
          var duration = firstProp(ev, "DURATION");
          var start = null, end = null;

          if (!dtstart) {
            err("Missing DTSTART — the event has no start time.");
          } else {
            start = parseDTValue(dtstart.value);
            if (!start) {
              err("DTSTART value “" + dtstart.value + "” is not a readable iCalendar date/time.");
            } else {
              var startTzid = dtstart.params.TZID || null;
              if (!start.utc && !startTzid && !start.dateOnly) {
                warn("Floating DTSTART (“" + dtstart.value + "”) — no Z and no TZID, so the timezone is ambiguous" +
                  (expectedTz ? "; if the sender meant " + expectedTz + ", the file should say so." : "."));
              }
              if (startTzid && !tzDefs[startTzid]) {
                warn("TZID “" + startTzid + "” is used but no matching VTIMEZONE is defined in this file.");
              }
              if (expectedTz && startTzid && startTzid !== expectedTz) {
                warn("DTSTART is pinned to TZID “" + startTzid + "”, which does not match the expected timezone “" + expectedTz + "”.");
              }
              if (expectedTz && start.utc) {
                // UTC is unambiguous; nothing to flag against an expected local zone.
              }
            }
          }

          if (dtstart && !dtend && !duration) {
            err("No DTEND and no DURATION — the event's length is undefined.");
          }
          if (dtend) {
            end = parseDTValue(dtend.value);
            if (!end) err("DTEND value “" + dtend.value + "” is not a readable iCalendar date/time.");
            var endTzid = dtend.params.TZID || null;
            if (endTzid && !tzDefs[endTzid]) {
              warn("DTEND uses TZID “" + endTzid + "” with no matching VTIMEZONE in this file.");
            }
          } else if (duration && start) {
            var secs = parseDuration(duration.value);
            if (secs === null) err("DURATION value “" + duration.value + "” is not a readable ISO 8601 duration.");
            else end = { ts: start.ts + secs * 1000, dateOnly: start.dateOnly, utc: start.utc };
          }

          if (start && end && end.ts <= start.ts) {
            err("DTEND is not after DTSTART — the event ends at or before it begins.");
          }

          var rruleProp = firstProp(ev, "RRULE");
          if (rruleProp) {
            var rr = parseRRule(rruleProp.value);
            if (!rr.UNTIL && !rr.COUNT) {
              warn("Open-ended RRULE (FREQ=" + (rr.FREQ || "?") + ", no UNTIL and no COUNT) — this recurrence never ends. Estimated " + estimateFirstYear(rr) + ".");
            }
          }

          if (!firstProp(ev, "ORGANIZER")) {
            warn("Missing ORGANIZER — nobody is named as the sender of this invite.");
          }

          if (todayStart !== null && end && end.ts <= todayStart) {
            warn("This event is entirely in the past relative to “today” (" + todayStr + ").");
          } else if (todayStart !== null && !end && start && start.ts < todayStart) {
            warn("This event starts in the past relative to “today” (" + todayStr + ") and has no readable end.");
          }

          results.push({
            index: i, summary: summary, uid: uid, issues: issues,
            startProp: dtstart, endProp: dtend, start: start, end: end
          });
        });

        // Duplicate UIDs across events.
        Object.keys(uidSeen).forEach(function (uid) {
          if (uidSeen[uid].length > 1) {
            uidSeen[uid].forEach(function (idx) {
              results[idx].issues.push({
                level: "error",
                text: "Duplicate UID “" + uid + "” — shared by events " + uidSeen[uid].map(function (n) { return "#" + (n + 1); }).join(", ") + ". Importers may merge or overwrite these."
              });
            });
          }
        });

        // Overlaps: pairs whose [start, end) intervals intersect, on stated wall-clock times.
        var pairs = [];
        for (var a = 0; a < results.length; a++) {
          for (var b = a + 1; b < results.length; b++) {
            var A = results[a], B = results[b];
            if (A.start && A.end && B.start && B.end && A.start.ts < B.end.ts && B.start.ts < A.end.ts) {
              pairs.push({ a: a, b: b });
              A.issues.push({ level: "warn", text: "Overlaps event #" + (b + 1) + " (“" + B.summary + "”) — the two events double-book the same time." });
              B.issues.push({ level: "warn", text: "Overlaps event #" + (a + 1) + " (“" + A.summary + "”) — the two events double-book the same time." });
            }
          }
        }

        var errCount = 0, warnCount = 0;
        results.forEach(function (r) {
          r.issues.forEach(function (is) { if (is.level === "error") errCount++; else warnCount++; });
          r.status = r.issues.some(function (x) { return x.level === "error"; }) ? "error"
            : (r.issues.length ? "warn" : "ok");
        });

        var verdict;
        if (!events.length) verdict = "DO NOT IMPORT";
        else if (errCount > 0) verdict = "DO NOT IMPORT";
        else if (warnCount > 0) verdict = "IMPORT WITH FIXES";
        else verdict = "IMPORTABLE";

        return {
          verdict: verdict, results: results, pairs: pairs,
          errCount: errCount, warnCount: warnCount,
          eventCount: events.length, tzCount: Object.keys(tzDefs).length
        };
      }

      /* ---------- rendering ---------- */

      function esc(s) {
        return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
      }

      function buildReport(out, todayStr, expectedTz) {
        var L = [];
        L.push("J-Dawgs Calendar Invite Integrity Auditor™ — audit report");
        L.push("Verdict: " + out.verdict);
        L.push("Events audited: " + out.eventCount + " | Errors: " + out.errCount + " | Warnings: " + out.warnCount +
          " | VTIMEZONE definitions in file: " + out.tzCount);
        L.push("“Today” used for the past-event check: " + (todayStr || "(not set)"));
        if (expectedTz) L.push("Expected timezone supplied: " + expectedTz);
        L.push("");
        if (!out.eventCount) {
          L.push("No VEVENT blocks were found in the pasted text. Nothing here can be imported as an event.");
        }
        out.results.forEach(function (r) {
          L.push("Event #" + (r.index + 1) + ": " + r.summary);
          L.push("  Starts: " + fmtDT(r.startProp) + " | Ends: " + fmtDT(r.endProp) + (r.uid ? " | UID: " + r.uid : " | UID: (missing)"));
          if (!r.issues.length) L.push("  OK — no issues found.");
          r.issues.forEach(function (is) {
            L.push("  [" + (is.level === "error" ? "ERROR" : "WARNING") + "] " + is.text);
          });
        });
        if (out.pairs.length) {
          L.push("");
          L.push("Overlapping pairs:");
          out.pairs.forEach(function (p) {
            L.push("  - Event #" + (p.a + 1) + " (“" + out.results[p.a].summary + "”) overlaps event #" + (p.b + 1) + " (“" + out.results[p.b].summary + "”)");
          });
        }
        L.push("");
        L.push("Text audit only — nothing was imported into any calendar. RRULE counts are estimates for simple FREQ cases.");
        return L.join("\n");
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-calendar-invite-integrity-auditor',
  name: 'J-Dawgs Calendar Invite Integrity Auditor',
  description: 'Audits a pasted .ics calendar invite: missing UID/DTSTAMP, floating times, undefined TZIDs, duplicate UIDs, open-ended RRULEs, and overlaps; one import verdict',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
