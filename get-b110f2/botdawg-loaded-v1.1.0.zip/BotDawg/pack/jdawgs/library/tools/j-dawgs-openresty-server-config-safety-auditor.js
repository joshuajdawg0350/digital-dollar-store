'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs OpenResty Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

    "use strict";
    /* ============================================================
       J-Dawgs OpenResty Server Config Safety Auditor
       Heuristic text audit only. Runs entirely client-side.
       Secret values are never copied into findings, report or JSON.
       ============================================================ */

    var RISKY_EXAMPLE = [
      "# Risky OpenResty example — expected verdict: DO NOT DEPLOY",
      "worker_processes  1;",
      "",
      "events {",
      "    worker_connections  1024;",
      "}",
      "",
      "http {",
      "    server_tokens  on;",
      "    lua_code_cache  off;",
      "",
      "    server {",
      "        listen       0.0.0.0:80;",
      "        server_name  shop.example.com;",
      "        autoindex    on;",
      "",
      "        location /files/ {",
      "            root       /var/www;",
      "            autoindex  on;",
      "        }",
      "",
      "        location /api/ {",
      "            access_by_lua_block {",
      "                local api_token = \"tok_live_9f27SECRETvalue\"",
      "                ngx.req.set_header(\"X-Api-Token\", api_token)",
      "            }",
      "            proxy_pass  http://127.0.0.1:9000;",
      "        }",
      "    }",
      "",
      "    server {",
      "        listen               443 ssl;",
      "        server_name          shop.example.com;",
      "        ssl_certificate      /etc/ssl/shop/fullchain.pem;",
      "        ssl_certificate_key  /etc/ssl/shop/privkey.pem;",
      "        ssl_protocols        TLSv1 TLSv1.2;",
      "    }",
      "}"
    ].join("\n");

    var HARDENED_EXAMPLE = [
      "# Hardened OpenResty example — expected verdict: SAFE TO DEPLOY",
      "worker_processes  auto;",
      "",
      "events {",
      "    worker_connections  1024;",
      "}",
      "",
      "http {",
      "    server_tokens        off;",
      "    lua_code_cache       on;",
      "    underscores_in_headers  off;",
      "    client_max_body_size 10m;",
      "",
      "    resolver        1.1.1.1 8.8.8.8 valid=30s;",
      "    resolver_timeout  5s;",
      "",
      "    ssl_protocols           TLSv1.2 TLSv1.3;",
      "    ssl_prefer_server_ciphers  on;",
      "    ssl_session_cache       shared:SSL:10m;",
      "    ssl_session_timeout     1d;",
      "    ssl_session_tickets     off;",
      "",
      "    server {",
      "        listen       80;",
      "        server_name  example.com;",
      "        return 301 https://$host$request_uri;",
      "    }",
      "",
      "    server {",
      "        listen               443 ssl;",
      "        server_name          example.com;",
      "        ssl_certificate      /etc/ssl/example.com/fullchain.pem;",
      "        ssl_certificate_key  /etc/ssl/example.com/privkey.pem;",
      "        autoindex            off;",
      "",
      "        location / {",
      "            proxy_pass  https://127.0.0.1:8443;",
      "        }",
      "    }",
      "}"
    ].join("\n");

    /* ---------- tokenizer ---------- */
    function tokenize(text) {
      var tokens = [];
      var i = 0, line = 1, n = text.length;
      while (i < n) {
        var c = text.charAt(i);
        if (c === "\n") { line++; i++; continue; }
        if (c === " " || c === "\t" || c === "\r" || c === "\f" || c === "\v") { i++; continue; }
        if (c === "#") { while (i < n && text.charAt(i) !== "\n") i++; continue; }
        if (c === "{" || c === "}" || c === ";") { tokens.push({ type: c, value: c, line: line }); i++; continue; }
        if (c === "\"" || c === "'") {
          var q = c, startLine = line, j = i + 1, buf = "";
          while (j < n && text.charAt(j) !== q) {
            if (text.charAt(j) === "\n") line++;
            if (text.charAt(j) === "\\" && j + 1 < n) { buf += text.charAt(j + 1); j += 2; continue; }
            buf += text.charAt(j); j++;
          }
          tokens.push({ type: "word", value: buf, line: startLine });
          i = (j < n) ? j + 1 : j;
          continue;
        }
        var s = "", sLine = line;
        while (i < n) {
          var ch = text.charAt(i);
          if (ch === " " || ch === "\t" || ch === "\r" || ch === "\n" || ch === "{" || ch === "}" || ch === ";" || ch === "#") break;
          s += ch; i++;
        }
        if (s.length) tokens.push({ type: "word", value: s, line: sLine });
      }
      return tokens;
    }

    /* ---------- parser: builds a block tree, records structural errors ---------- */
    function parseConfig(tokens) {
      var pos = 0, lastLine = 1, errors = [];
      function consume() { var t = tokens[pos++]; if (t) lastLine = t.line; return t; }
      function parseBlock(isTop) {
        var nodes = [];
        while (pos < tokens.length) {
          var t = tokens[pos];
          if (t.type === "}") {
            consume();
            if (isTop) errors.push({ line: t.line, msg: "closing brace with no matching opening brace" });
            return { nodes: nodes, closed: true };
          }
          if (t.type === "{" || t.type === ";") {
            errors.push({ line: t.line, msg: "stray '" + t.type + "' with no directive in front of it" });
            consume(); continue;
          }
          var nameTok = consume();
          var node = { name: nameTok.value, args: [], line: nameTok.line, endLine: nameTok.line, block: false, children: [] };
          var isBlock = false, done = false;
          while (pos < tokens.length && !done) {
            var a = tokens[pos];
            if (a.type === ";") { consume(); done = true; }
            else if (a.type === "{") { consume(); isBlock = true; done = true; }
            else if (a.type === "}") { done = true; }
            else { node.args.push(consume().value); }
          }
          node.block = isBlock;
          if (isBlock) {
            var inner = parseBlock(false);
            node.children = inner.nodes;
            node.endLine = lastLine;
            if (!inner.closed) {
              errors.push({ line: node.line, msg: "block '" + node.name + "' opened here is never closed" });
              node.endLine = lastLine;
              nodes.push(node);
              return { nodes: nodes, closed: false };
            }
          } else {
            node.endLine = lastLine;
          }
          nodes.push(node);
        }
        return { nodes: nodes, closed: false };
      }
      var root = parseBlock(true);
      return { root: root.nodes, errors: errors };
    }

    /* ---------- known directives (core nginx + common modules + OpenResty) ---------- */
    var KNOWN = {};
    ("worker_processes worker_connections worker_rlimit_nofile worker_priority worker_shutdown_timeout user pid daemon master_process " +
     "error_log access_log env lock_file timer_resolution events http server location upstream stream mail types map geo split_clients " +
     "include listen server_name server_tokens root alias index try_files return rewrite set if break error_page internal " +
     "proxy_pass proxy_set_header proxy_hide_header proxy_pass_header proxy_http_version proxy_read_timeout proxy_connect_timeout " +
     "proxy_send_timeout proxy_buffering proxy_buffer proxy_buffers proxy_busy_buffers_size proxy_request_buffering proxy_cache " +
     "proxy_cache_path proxy_cache_key proxy_cache_valid proxy_redirect proxy_next_upstream proxy_ssl_certificate proxy_ssl_protocols " +
     "proxy_ssl_server_name proxy_ssl_verify proxy_intercept_errors proxy_method proxy_body " +
     "fastcgi_pass fastcgi_param fastcgi_index fastcgi_read_timeout uwsgi_pass grpc_pass memcached_pass scgi_pass " +
     "resolver resolver_timeout client_max_body_size client_body_buffer_size client_body_in_file_only client_body_temp_path " +
     "client_header_buffer_size client_header_timeout client_body_timeout large_client_header_buffers keepalive_timeout " +
     "keepalive_requests keepalive_disable send_timeout sendfile tcp_nopush tcp_nodelay aio directio output_buffers " +
     "gzip gzip_types gzip_min_length gzip_proxied gzip_vary gzip_disable gzip_comp_level gzip_buffers gzip_static " +
     "autoindex autoindex_exact_size autoindex_localtime underscores_in_headers merge_slashes server_names_hash_bucket_size " +
     "server_names_hash_max_size limit_req limit_req_zone limit_req_status limit_conn limit_conn_zone limit_conn_status limit_rate " +
     "auth_basic auth_basic_user_file auth_request auth_request_set allow deny satisfy all " +
     "expires add_header add_trailer more_set_headers more_clear_headers default_type charset charset_types etag if_modified_since " +
     "open_file_cache open_file_cache_errors open_file_cache_min_uses open_file_cache_valid postpone_output reset_timedout_connection " +
     "lingering_close lingering_time lingering_timeout max_ranges msie_padding msie_refresh port_in_redirect recursive_error_pages " +
     "server_name_in_redirect absolute_redirect hash ip_hash least_conn random zone state queue keepalive sticky health_check " +
     "ssl_certificate ssl_certificate_key ssl_protocols ssl_ciphers ssl_prefer_server_ciphers ssl_session_cache ssl_session_timeout " +
     "ssl_session_tickets ssl_session_ticket_key ssl_stapling ssl_stapling_verify ssl_trusted_certificate ssl_dhparam ssl_ecdh_curve " +
     "ssl_verify_client ssl_verify_depth ssl_client_certificate ssl_password_file ssl_buffer_size ssl_conf_command " +
     "http2 http2_max_field_size http2_max_header_size http3 quic_retry js njs perl xslt_stylesheet subs_filter image_filter " +
     "real_ip_header set_real_ip_from real_ip_recursive proxy_protocol proxy_protocol_timeout " +
     "thread_pool load_module pcre_jit ssl_engine debug_points working_directory chroot cpu_affinity " +
     "accept_mutex accept_mutex_delay multi_accept resolver_file error_log_per_sbin syslog").split(/\s+/).forEach(function (d) { KNOWN[d] = true; });
    function isKnownDirective(name) {
      if (KNOWN[name]) return true;
      if (/^lua_/.test(name)) return true;
      if (/_by_lua(_block)?$/.test(name)) return true;
      if (/^ssl_/.test(name)) return true;
      if (/^proxy_/.test(name)) return true;
      if (/^grpc_/.test(name)) return true;
      if (/^fastcgi_/.test(name)) return true;
      if (/^uwsgi_/.test(name)) return true;
      if (/^scgi_/.test(name)) return true;
      if (/^http2_/.test(name)) return true;
      if (/^auth_/.test(name)) return true;
      if (/^limit_/.test(name)) return true;
      return false;
    }
    var SKIP_CHILD_AUDIT = { map: true, geo: true, split_clients: true, types: true };

    /* ---------- helpers ---------- */
    function walk(nodes, ancestors, fn) {
      nodes.forEach(function (nd) {
        fn(nd, ancestors);
        if (nd.block && !/_by_lua_block$/.test(nd.name) && !SKIP_CHILD_AUDIT[nd.name]) {
          walk(nd.children, ancestors.concat([nd.name]), fn);
        }
      });
    }
    function subtreeNodes(node) {
      var out = [];
      (function rec(nd) {
        out.push(nd);
        if (nd.block && !/_by_lua_block$/.test(nd.name)) nd.children.forEach(rec);
      })(node);
      return out;
    }
    function fmtNum(n) { return String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ","); }
    function parseSizeBytes(v) {
      var m = /^(\d+(?:\.\d+)?)\s*([kKmMgG]?)$/.exec(String(v).trim());
      if (!m) return null;
      var mult = { "": 1, k: 1024, m: 1024 * 1024, g: 1024 * 1024 * 1024 }[m[2].toLowerCase()];
      return { num: parseFloat(m[1]), mult: mult, bytes: Math.round(parseFloat(m[1]) * mult), suffix: m[2].toLowerCase() };
    }
    function parseListen(firstArg) {
      if (!firstArg) return null;
      if (firstArg.indexOf("unix:") === 0) return { unix: true, raw: firstArg };
      var port = null, addr = null, mm = /:(\d+)$/.exec(firstArg);
      if (/^\d+$/.test(firstArg)) { port = parseInt(firstArg, 10); addr = null; }
      else if (mm) { port = parseInt(mm[1], 10); addr = firstArg.slice(0, firstArg.length - mm[0].length); }
      else if (/^\*$/.test(firstArg) || firstArg === "*") { addr = "*"; }
      else { addr = firstArg; }
      return { unix: false, raw: firstArg, addr: addr, port: port };
    }
    var SECRET_KW = /(password|passwd|pwd|secret|token|api_?key|access_?key|auth_?token|private_?key)/i;
    function secretCategory(lineText) {
      var m = /([A-Za-z_][A-Za-z0-9_.]*?(password|passwd|pwd|secret|token|api_?key|access_?key|auth_?token)[A-Za-z0-9_]*)\s*[:=]/i.exec(lineText);
      return m ? m[2].toLowerCase().replace(/_/g, " ") : null;
    }

    /* ---------- the audit ---------- */
    function auditConfig(text) {
      var findings = [];
      function add(sev, line, check, title, detail, fix) {
        findings.push({ severity: sev, line: (line == null ? null : line), check: check, title: title, detail: detail, fix: fix || null });
      }
      var rawLines = text.split(/\r?\n/);
      var tokens = tokenize(text);
      var parsed = parseConfig(tokens);
      var root = parsed.root;
      var parseOk = parsed.errors.length === 0;

      parsed.errors.forEach(function (e) {
        add("NOT AUDITED", e.line, "structure",
          "Config structure NOT PARSED at this point",
          "Problem: " + e.msg + " (line " + e.line + "). Checks that depend on block structure may be incomplete from here — this auditor reports that honestly instead of guessing.",
          "Balance the braces so every block opened with { is closed with }, then re-run the audit.");
      });

      var flat = [];       // {node, ancestors}
      walk(root, [], function (nd, anc) { flat.push({ node: nd, ancestors: anc }); });
      function byName(name) { return flat.filter(function (f) { return f.node.name === name; }); }
      function hasDirective(name) { return byName(name).length > 0; }

      var httpNode = null;
      root.forEach(function (nd) { if (nd.name === "http") httpNode = nd; });
      var anchorLine = httpNode ? httpNode.line : 1;

      /* unknown directives */
      flat.forEach(function (f) {
        var nm = f.node.name;
        if (f.ancestors.indexOf("upstream") >= 0 && nm === "server") return;
        if (!isKnownDirective(nm)) {
          add("NOT AUDITED", f.node.line, "unknown-directive",
            "Unknown directive '" + nm + "' — not audited",
            "'" + nm + "' at line " + f.node.line + " is not a directive this auditor knows (core nginx / OpenResty set). It may belong to a third-party module; its effect on safety was not assessed.",
            "Confirm which module provides '" + nm + "' and review its documentation before deploying.");
        }
      });

      /* server records */
      var servers = [];
      flat.forEach(function (f) {
        var parent = f.ancestors.length ? f.ancestors[f.ancestors.length - 1] : null;
        if (f.node.name === "server" && f.node.block && parent !== "upstream") {
          var sub = subtreeNodes(f.node);
          var rec = {
            node: f.node, line: f.node.line, sub: sub,
            listens: sub.filter(function (n) { return n.name === "listen"; }),
            names: [], hasCert: false, hasRedirect: false, nameLine: null
          };
          sub.forEach(function (n) {
            if (n.name === "server_name" && rec.names.length === 0) { rec.names = n.args.slice(); rec.nameLine = n.line; }
            if (n.name === "ssl_certificate") rec.hasCert = true;
            if (n.name === "return" && n.args.length >= 2 && /^(301|302|307|308)$/.test(n.args[0]) && n.args[1].indexOf("https://") === 0) rec.hasRedirect = true;
            if (n.name === "rewrite" && n.args.join(" ").indexOf("https://") >= 0) rec.hasRedirect = true;
          });
          servers.push(rec);
        }
      });
      var httpLevelCert = flat.some(function (f) {
        return f.node.name === "ssl_certificate" && f.ancestors.length === 1 && f.ancestors[0] === "http";
      });
      var anySslListen = false;
      servers.forEach(function (s) { s.listens.forEach(function (l) { if (l.args.slice(1).indexOf("ssl") >= 0) anySslListen = true; }); });

      /* --- listen checks --- */
      servers.forEach(function (s) {
        s.listens.forEach(function (l) {
          var info = parseListen(l.args[0]);
          if (!info || info.unix) {
            if (info && info.unix) add("NOTE", l.line, "listen", "Unix-socket listen",
              "listen " + info.raw + " serves over a local socket file — not reachable from the network by itself; exposure depends on the proxy in front of it.", null);
            return;
          }
          var isSsl = l.args.slice(1).indexOf("ssl") >= 0;
          var allIfaces = (info.addr === null || info.addr === "" || info.addr === "*" || info.addr === "0.0.0.0" || info.addr === "[::]" || info.addr === "::");
          if (allIfaces) {
            add("NOTE", l.line, "listen",
              "listen " + info.raw + " binds all interfaces",
              "This socket listens on every network interface of the host (address " + (info.addr ? info.addr : "not specified — nginx default is all interfaces") + "). Exposure pairing: " +
              (isSsl ? "it is paired with TLS on this socket, so traffic is encrypted, but the port is still reachable from anywhere the firewall allows." :
                       "it is paired with plain HTTP on this socket, so anything sent to it crosses the network unencrypted and the port is reachable from anywhere the firewall allows."),
              null);
          } else {
            add("NOTE", l.line, "listen",
              "listen " + info.raw + " bound to " + info.addr,
              "Binding to " + info.addr + " limits this socket to that interface/address — a narrower exposure than binding all interfaces.", null);
          }
          if (!isSsl) {
            if (s.hasRedirect) {
              add("NOTE", l.line, "listen", "Plain-HTTP listen redirects to HTTPS",
                "This server listens on plain HTTP port " + (info.port != null ? info.port : "?") + " but answers with an HTTP→HTTPS redirect (return 301/308 to an https:// URL), so no content is served unencrypted. Named good.", null);
            } else if (anySslListen) {
              add("WARNING", l.line, "listen", "Plain HTTP served with no redirect to the TLS server",
                "This server serves content over plain HTTP (listen " + info.raw + ") and the config does define a TLS server — but this block never redirects visitors to it, so anyone landing here stays on unencrypted HTTP.",
                "Add 'return 301 https://$host$request_uri;' to this server block, or serve the content only on the TLS listen.");
            } else {
              add("WARNING", l.line, "listen", "Plain HTTP with no TLS anywhere in the config",
                "listen " + info.raw + " serves plain HTTP and no server in this config listens with ssl at all — all traffic, including any logins or tokens, crosses the network unencrypted.",
                "Add a TLS server (listen 443 ssl with ssl_certificate / ssl_certificate_key) and redirect this port to it.");
            }
          } else {
            if (!s.hasCert && !httpLevelCert) {
              add("BLOCKER", l.line, "listen", "TLS listen with no ssl_certificate — incomplete",
                "This server listens with ssl (line " + l.line + ") but neither it nor the enclosing http block sets ssl_certificate. The TLS server is incomplete: nginx/OpenResty would refuse to load this configuration.",
                "Add ssl_certificate and ssl_certificate_key pointing at the certificate and key files for this server_name.");
            }
          }
        });
      });

      /* --- TLS protocols --- */
      var protoOcc = byName("ssl_protocols");
      protoOcc.forEach(function (f) {
        var bad = f.node.args.filter(function (a) { return a === "TLSv1" || a === "TLSv1.1"; });
        if (bad.length) {
          add("BLOCKER", f.node.line, "tls", "Obsolete TLS enabled: " + bad.join(" "),
            "ssl_protocols at line " + f.node.line + " enables " + bad.join(" and ") + ", which are deprecated (broken/beast-era cryptography, formally deprecated by RFC 8996) and fail modern compliance scans.",
            "Set ssl_protocols to 'TLSv1.2 TLSv1.3' only.");
        } else if (f.node.args.length) {
          add("NOTE", f.node.line, "tls", "ssl_protocols restricted to modern TLS — named good",
            "ssl_protocols at line " + f.node.line + " is '" + f.node.args.join(" ") + "' — TLSv1.2+ only, no obsolete protocol versions.", null);
        }
      });
      if (anySslListen && protoOcc.length === 0) {
        add("NOTE", anchorLine, "tls", "ssl_protocols not set explicitly",
          "A TLS listen exists but ssl_protocols is never set, so the OpenResty build's compiled-in default decides which protocol versions are on. Defaults vary by build — pin it down.",
          "Add 'ssl_protocols TLSv1.2 TLSv1.3;' to the http block.");
      }
      var preferOcc = byName("ssl_prefer_server_ciphers");
      preferOcc.forEach(function (f) {
        var v = (f.node.args[0] || "").toLowerCase();
        if (v === "on") add("NOTE", f.node.line, "tls", "ssl_prefer_server_ciphers on — noted",
          "The server enforces its own cipher preference order during the TLS handshake. With TLSv1.3 this matters less (ciphers are fixed), but it is a deliberate, visible setting.", null);
        else if (v === "off") add("WARNING", f.node.line, "tls", "ssl_prefer_server_ciphers off",
          "The client's cipher preference wins the handshake, so a weak-but-offered client cipher can be selected over the server's stronger order.",
          "Set ssl_prefer_server_ciphers on (for TLSv1.2 cipher control).");
      });
      if (anySslListen && preferOcc.length === 0) {
        add("NOTE", anchorLine, "tls", "ssl_prefer_server_ciphers not set",
          "Not configured; the default applies. Worth setting explicitly so the handshake policy is visible in the config, not inherited.", null);
      }
      var sessionBits = [];
      if (hasDirective("ssl_session_cache")) sessionBits.push("ssl_session_cache");
      if (hasDirective("ssl_session_timeout")) sessionBits.push("ssl_session_timeout");
      if (hasDirective("ssl_session_tickets")) sessionBits.push("ssl_session_tickets");
      if (anySslListen) {
        if (sessionBits.length) {
          add("NOTE", anchorLine, "tls", "TLS session settings configured: " + sessionBits.join(", "),
            "Session resumption settings are present (" + sessionBits.join(", ") + "), so returning clients can resume TLS sessions instead of paying a full handshake every time.", null);
        } else {
          add("NOTE", anchorLine, "tls", "TLS session settings not configured",
            "No ssl_session_cache / ssl_session_timeout / ssl_session_tickets anywhere — defaults apply and session resumption is whatever the build ships with. Not a vulnerability, but an unexamined default.",
            "Set ssl_session_cache and ssl_session_timeout explicitly (and decide ssl_session_tickets on or off on purpose).");
        }
      }

      /* --- server_tokens --- */
      var stOcc = byName("server_tokens");
      var stOn = stOcc.filter(function (f) { return (f.node.args[0] || "").toLowerCase() === "on"; });
      var stOff = stOcc.filter(function (f) { return (f.node.args[0] || "").toLowerCase() === "off"; });
      if (stOn.length) {
        add("WARNING", stOn[0].node.line, "server_tokens", "server_tokens on — version banner disclosed",
          "server_tokens on puts the exact OpenResty/nginx version in Server response headers and error pages, handing version-specific exploit shopping to anyone who asks.",
          "Set 'server_tokens off;' in the http block.");
      } else if (stOff.length) {
        add("NOTE", stOff[0].node.line, "server_tokens", "server_tokens off — named good",
          "Error pages and the Server header carry no version number. Attackers get less free reconnaissance.", null);
      } else {
        add("WARNING", anchorLine, "server_tokens", "server_tokens not set — defaults to on",
          "server_tokens never appears in this config. In nginx/OpenResty the compiled default is on, so version banners are disclosed exactly as if it were set to on.",
          "Add 'server_tokens off;' to the http block.");
      }

      /* --- lua_code_cache --- */
      var lccOcc = byName("lua_code_cache");
      var lccOff = lccOcc.filter(function (f) { return (f.node.args[0] || "").toLowerCase() === "off"; });
      var lccOn = lccOcc.filter(function (f) { return (f.node.args[0] || "").toLowerCase() === "on"; });
      if (lccOff.length) {
        add("WARNING", lccOff[0].node.line, "lua_code_cache", "lua_code_cache off",
          "With the code cache off, every request re-loads and re-compiles the Lua code (a real per-request performance cost), and module-level Lua state is re-initialised per request — code that assumes shared state behaves surprisingly, and bugs hide until traffic arrives. Off is a debugging setting, not a production one.",
          "Set 'lua_code_cache on;' for production; keep off only on a developer's local instance.");
      } else if (lccOn.length) {
        add("NOTE", lccOn[0].node.line, "lua_code_cache", "lua_code_cache on — named good",
          "Lua code is compiled once and cached across requests, and module state behaves the way production code expects.", null);
      } else if (flat.some(function (f) { return /_by_lua/.test(f.node.name) || /^lua_/.test(f.node.name); })) {
        add("NOTE", anchorLine, "lua_code_cache", "lua_code_cache not set — defaults to on",
          "Lua directives are in use and lua_code_cache never appears; the OpenResty default is on, which is the production-correct behaviour. Setting it explicitly removes the doubt.", null);
      }

      /* --- autoindex --- */
      byName("autoindex").forEach(function (f) {
        var v = (f.node.args[0] || "").toLowerCase();
        if (v === "on") {
          add("BLOCKER", f.node.line, "autoindex", "autoindex on — directory listing exposed",
            "autoindex on (line " + f.node.line + ") makes the server hand out a browsable listing of every file in the affected directories — backup files, .git contents, stray exports and anything else dropped there becomes public.",
            "Set 'autoindex off;' (or remove the directive — off is the default) anywhere files are served.");
        } else if (v === "off") {
          add("NOTE", f.node.line, "autoindex", "autoindex off — named good",
            "Directory listings are explicitly disabled at line " + f.node.line + "; requests for a directory without an index file get an error, not a file inventory.", null);
        }
      });

      /* --- client_max_body_size --- */
      var cmbsOcc = byName("client_max_body_size");
      cmbsOcc.forEach(function (f) {
        var raw = f.node.args[0] || "";
        if (raw === "0") {
          add("WARNING", f.node.line, "client_max_body_size", "client_max_body_size 0 — unlimited request bodies",
            "A value of 0 disables the request-body size limit entirely: anyone can POST bodies of any size until disk or memory gives out.",
            "Set a deliberate limit, e.g. client_max_body_size 10m, sized to the largest legitimate upload.");
          return;
        }
        var sz = parseSizeBytes(raw);
        if (sz) {
          add("NOTE", f.node.line, "client_max_body_size",
            "client_max_body_size " + raw + " = " + fmtNum(sz.bytes) + " bytes",
            "Arithmetic: " + sz.num + " × " + fmtNum(sz.mult) + (sz.suffix ? " (suffix '" + sz.suffix + "')" : " (no suffix — raw bytes)") + " = " + fmtNum(sz.bytes) + " bytes. Requests with bodies larger than this get a 413 error.", null);
        } else {
          add("NOT AUDITED", f.node.line, "client_max_body_size",
            "client_max_body_size value '" + raw + "' could not be interpreted",
            "The value at line " + f.node.line + " does not match the number[k|m|g] form this auditor can evaluate, so its byte size was not audited.",
            "Use the plain form, e.g. 512k, 10m or 1g.");
        }
      });
      if (cmbsOcc.length === 0) {
        add("NOTE", anchorLine, "client_max_body_size", "client_max_body_size not set — nginx default applies",
          "The default is 1m = 1 × 1,048,576 = 1,048,576 bytes. Uploads larger than about a megabyte will fail with 413 unless a location sets its own limit.", null);
      }

      /* --- underscores_in_headers --- */
      byName("underscores_in_headers").forEach(function (f) {
        var v = (f.node.args[0] || "").toLowerCase();
        add("NOTE", f.node.line, "underscores_in_headers", "underscores_in_headers " + v + " — noted",
          v === "on"
            ? "Headers whose names contain underscores (e.g. X_Custom_Header) are accepted. Some backends and frameworks disagree about underscore vs hyphen handling, which has historically enabled header-smuggling mismatches — on should be a deliberate choice."
            : "Headers whose names contain underscores are dropped (the nginx default, stated explicitly at line " + f.node.line + "). Backends expecting underscore headers will never see them.", null);
      });

      /* --- server_name: wildcards, catch-all, absence --- */
      servers.forEach(function (s) {
        if (!s.names.length) {
          add("NOTE", s.line, "server_name", "Server block with no server_name",
            "The server block at line " + s.line + " sets no server_name. On its listen socket it behaves as the default server: it answers requests for any Host header that no other server claims.",
            "Give the server an explicit server_name, and keep one deliberate default server per socket to drop unknown hosts.");
          return;
        }
        s.names.forEach(function (nm) {
          if (nm.indexOf("*") >= 0) {
            add("NOTE", s.nameLine, "server_name", "Wildcard server_name '" + nm + "' — noted",
              "A wildcard name matches any sub-domain in one shot. Convenient, but it also means hosts you never planned (staging leftovers, tenant sub-domains) are served by this block and its rules.",
              null);
          }
          if (nm === "_") {
            add("NOTE", s.nameLine, "server_name", "server_name _ — deliberate catch-all",
              "'_' never matches a real Host header, which makes this block the catch-all/default for its socket — fine when deliberate (e.g. to drop unknown hosts), surprising when not.", null);
          }
        });
      });

      /* --- duplicate listen + server_name conflicts --- */
      for (var a = 0; a < servers.length; a++) {
        for (var b = a + 1; b < servers.length; b++) {
          var sharedNames = servers[a].names.filter(function (n) { return servers[b].names.indexOf(n) >= 0; });
          if (!sharedNames.length) continue;
          var socksA = servers[a].listens.map(function (l) { var i = parseListen(l.args[0]); return i ? (i.unix ? i.raw : ((i.addr || "*") + ":" + i.port)) : l.args[0]; });
          var sharedSock = null;
          servers[b].listens.forEach(function (l) {
            var i = parseListen(l.args[0]); var key = i ? (i.unix ? i.raw : ((i.addr || "*") + ":" + i.port)) : l.args[0];
            if (socksA.indexOf(key) >= 0) sharedSock = key;
          });
          if (sharedSock) {
            add("WARNING", servers[b].line, "duplicates",
              "Conflicting server_name '" + sharedNames[0] + "' on listen " + sharedSock + " (lines " + servers[a].line + " and " + servers[b].line + ")",
              "Two server blocks (starting at lines " + servers[a].line + " and " + servers[b].line + ") claim the same server_name on the same socket. nginx logs a 'conflicting server name' warning and silently ignores one of them — which one serves traffic is not the one you'd guess at 2 a.m.",
              "Rename one server_name or move one block to a different listen socket, so exactly one block owns each name+socket pair.");
          }
        }
      }

      /* --- resolver need --- */
      var dnsNeed = [];
      flat.forEach(function (f) {
        if (f.node.name === "proxy_pass") {
          f.node.args.forEach(function (arg) {
            if (arg.indexOf("$") >= 0) dnsNeed.push({ line: f.node.line, why: "proxy_pass at line " + f.node.line + " contains a variable, so its hostname is resolved at request time" });
          });
        }
      });
      var luaDnsLines = [];
      flat.forEach(function (f) {
        if (/_by_lua(_block)?$/.test(f.node.name)) {
          var from = f.node.line, to = f.node.endLine || f.node.line;
          for (var ln = from; ln <= to && ln <= rawLines.length; ln++) {
            if (/resty\.http|ngx\.socket|cosocket/.test(rawLines[ln - 1])) luaDnsLines.push(ln);
          }
          var argText = f.node.args.join(" ");
          if (/resty\.http|ngx\.socket|cosocket/.test(argText)) luaDnsLines.push(f.node.line);
        }
      });
      luaDnsLines.forEach(function (ln) {
        dnsNeed.push({ line: ln, why: "Lua code around line " + ln + " makes outbound HTTP/cosocket calls, which resolve hostnames through the nginx resolver" });
      });
      var resolverOcc = byName("resolver");
      if (dnsNeed.length && resolverOcc.length === 0) {
        add("WARNING", dnsNeed[0].line, "resolver", "Runtime DNS resolution needed but no resolver configured",
          "Why this matters: " + dnsNeed[0].why + ". nginx/OpenResty cannot use the system /etc/resolv.conf for runtime resolution — without a 'resolver' directive those requests fail at runtime with 'no resolver defined to resolve …', even though the config parses cleanly.",
          "Add e.g. 'resolver 1.1.1.1 8.8.8.8 valid=30s;' to the http block (or your VPC DNS), matched to where this server actually runs.");
      }
      resolverOcc.forEach(function (f) {
        var validArg = f.node.args.filter(function (x) { return x.indexOf("valid=") === 0; })[0];
        add("NOTE", f.node.line, "resolver", "resolver configured" + (validArg ? " with " + validArg : ""),
          "A resolver is set (" + f.node.args.join(" ") + ")." + (validArg
            ? " The " + validArg + " setting controls how long DNS answers are cached regardless of their TTL — noted, since a stale answer can outlive a failover by that long."
            : " No valid= is given, so DNS answers are cached for their own TTL."), null);
      });

      /* --- lua_need_request_body --- */
      byName("lua_need_request_body").forEach(function (f) {
        var v = (f.node.args[0] || "").toLowerCase();
        if (v !== "on") {
          add("NOTE", f.node.line, "lua_need_request_body", "lua_need_request_body off — noted",
            "Request bodies are not force-read into memory by the Lua phases; Lua code that needs the body must read it explicitly (ngx.req.read_body()).", null);
          return;
        }
        var inIf = f.ancestors.indexOf("if") >= 0;
        var locNode = null;
        /* find enclosing location node by re-walking ancestry is approximate; use flat context: check sibling proxy_pass in any location on nearby lines is unreliable — instead scan whole config for locations containing both directives */
        var misuse = inIf;
        var where = "";
        flat.forEach(function (g) {
          if (g.node.name === "location" && g.node.block) {
            var names = subtreeNodes(g.node).map(function (n) { return n.name; });
            if (names.indexOf("lua_need_request_body") >= 0 && names.indexOf("proxy_pass") >= 0) { misuse = true; locNode = g.node; }
          }
        });
        if (misuse) {
          add("WARNING", f.node.line, "lua_need_request_body", "lua_need_request_body on — misuse risk",
            "lua_need_request_body on forces the entire request body to be read and buffered before the access/content phase" +
            (inIf ? ", and here it sits inside an 'if' block, where nginx phase behaviour is famously surprising ('if is evil')" : "") +
            (locNode ? ". In the location at line " + locNode.line + " the same block also proxies the request onward, so every upload is fully buffered by Lua first — large bodies spill to temp files and latency doubles up." : "."),
            "Prefer reading the body only where Lua truly needs it (ngx.req.read_body() inside the handler, scoped to that location), and keep it out of 'if' blocks and proxying locations.");
        } else {
          add("NOTE", f.node.line, "lua_need_request_body", "lua_need_request_body on — noted",
            "Every request body in scope is read before Lua handlers run. Fine where handlers genuinely need the body; wasteful (and temp-file-prone on big uploads) everywhere else.", null);
        }
      });

      /* --- secrets: raw key material anywhere --- */
      var beginLines = {};
      rawLines.forEach(function (lt, idx) {
        if (lt.indexOf("-----BEGIN") >= 0) beginLines[idx + 1] = true;
      });
      Object.keys(beginLines).forEach(function (ln) {
        add("BLOCKER", parseInt(ln, 10), "secrets", "Key/certificate material pasted directly into the config (line " + ln + ")",
          "Line " + ln + " contains a PEM '-----BEGIN' marker: raw key or certificate material embedded in the config text itself. Flagged by line only — the material is never reproduced here. Config files get committed, pasted and logged; private keys must live in their own files with tight permissions.",
          "Move the material into its own .pem/.key file, reference it by path (ssl_certificate / ssl_certificate_key), restrict the file to the server user, and rotate anything that was pasted around.");
      });

      /* --- secrets: ssl_certificate_key with embedded-looking value --- */
      byName("ssl_certificate_key").forEach(function (f) {
        var v = f.node.args[0] || "";
        var embedded = v.indexOf("BEGIN") >= 0 || (v.length > 80 && v.indexOf("/") < 0 && /^[A-Za-z0-9+/=]+$/.test(v));
        if (embedded) {
          add("BLOCKER", f.node.line, "secrets", "ssl_certificate_key appears to embed the key instead of a path (line " + f.node.line + ")",
            "ssl_certificate_key normally takes a file path. The value at line " + f.node.line + " does not look like a path — it looks like key material inline. Flagged by directive name and line only; the value is never shown.",
            "Put the private key in its own file (permissions 600, owned by the server user) and point ssl_certificate_key at that path. Rotate the key if it was ever shared as text.");
        } else if (v) {
          add("NOTE", f.node.line, "secrets", "ssl_certificate_key references a key file path",
            "The key is referenced by path at line " + f.node.line + " (the path itself is not secret, and this auditor does not open or verify the file — permissions and validity are NOT AUDITED here).", null);
        }
      });

      /* --- secrets: assignments inside lua code --- */
      flat.forEach(function (f) {
        if (!/_by_lua(_block)?$/.test(f.node.name)) return;
        var hitLines = {};
        if (/_block$/.test(f.node.name)) {
          for (var ln = f.node.line; ln <= (f.node.endLine || f.node.line) && ln <= rawLines.length; ln++) {
            var cat = secretCategory(rawLines[ln - 1]);
            if (cat && /["']/.test(rawLines[ln - 1])) hitLines[ln] = cat;
          }
        } else {
          var catA = secretCategory(f.node.args.join(" "));
          if (catA) hitLines[f.node.line] = catA;
        }
        Object.keys(hitLines).forEach(function (ln2) {
          add("BLOCKER", parseInt(ln2, 10), "secrets",
            "Secret-like " + hitLines[ln2] + " assignment inside " + f.node.name + " (line " + ln2 + ")",
            "The Lua code in " + f.node.name + " assigns a literal value to a " + hitLines[ln2] + "-like variable at line " + ln2 + ". Hard-coded credentials in config are one repo leak away from production. Flagged by directive name and line only — the value is never shown in this audit, the report, or the JSON.",
            "Move the credential out of the config: read it from an environment-provided file or a secrets store at init_by_lua time, keep the config free of literal secrets, and rotate the exposed value.");
        });
      });

      /* --- sort, count, verdict --- */
      var rank = { "BLOCKER": 0, "WARNING": 1, "NOT AUDITED": 2, "NOTE": 3 };
      findings.sort(function (x, y) {
        return (rank[x.severity] - rank[y.severity]) || ((x.line || 0) - (y.line || 0));
      });
      var counts = { "BLOCKER": 0, "WARNING": 0, "NOTE": 0, "NOT AUDITED": 0 };
      findings.forEach(function (f) { counts[f.severity]++; });
      var verdict, vclass, vwhy;
      if (counts.BLOCKER > 0) {
        verdict = "DO NOT DEPLOY"; vclass = "no";
        vwhy = counts.BLOCKER + " BLOCKER finding" + (counts.BLOCKER === 1 ? "" : "s") + " must be fixed before this config goes anywhere near production.";
      } else if (counts.WARNING > 0) {
        verdict = "DEPLOY WITH FIXES"; vclass = "fixes";
        vwhy = "No BLOCKERs, but " + counts.WARNING + " WARNING" + (counts.WARNING === 1 ? "" : "s") + " should be fixed first — each one is a real exposure or a runtime surprise, listed below with its fix.";
      } else {
        verdict = "SAFE TO DEPLOY"; vclass = "safe";
        vwhy = "No BLOCKERs and no WARNINGs in the checks this auditor runs. NOTEs below are observations, not defects. This is a heuristic text audit, not a guarantee — still run openresty -t on the target host before reloading.";
      }
      if (verdict === "SAFE TO DEPLOY" && (!parseOk || counts["NOT AUDITED"] > 0)) {
        verdict = "DEPLOY WITH FIXES"; vclass = "fixes";
        vwhy = !parseOk
          ? "No BLOCKERs or WARNINGs were found in what could be read, but the config structure could not be fully parsed (see NOT AUDITED findings), so a clean verdict cannot honestly be given — " + counts["NOT AUDITED"] + " item" + (counts["NOT AUDITED"] === 1 ? "" : "s") + " remain unaudited."
          : "No BLOCKERs or WARNINGs were found in what was audited, but " + counts["NOT AUDITED"] + " item" + (counts["NOT AUDITED"] === 1 ? "" : "s") + " could not be audited (see NOT AUDITED findings) — an auditor that never guesses cannot call a config fully safe while part of it went unchecked.";
      }
      var fixes = findings.filter(function (f) { return (f.severity === "BLOCKER" || f.severity === "WARNING") && f.fix; })
        .map(function (f) { return { line: f.line, severity: f.severity, fix: f.fix, title: f.title }; });
      return {
        verdict: verdict, vclass: vclass, vwhy: vwhy, counts: counts, findings: findings,
        fixes: fixes, parseOk: parseOk, linesAudited: rawLines.length
      };
    }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-openresty-server-config-safety-auditor',
  name: 'J-Dawgs OpenResty Server Config Safety Auditor',
  description: 'Grades a pasted OpenResty nginx.conf offline — TLS versions, server_tokens, lua_code_cache, autoindex, secrets by directive/line only — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
