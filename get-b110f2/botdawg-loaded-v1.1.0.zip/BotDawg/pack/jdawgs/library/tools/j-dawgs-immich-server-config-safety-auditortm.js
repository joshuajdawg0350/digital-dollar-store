'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Immich Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";
var RISKY = [
"# Risky example — do not deploy this",
"DB_PASSWORD=password",
"DB_USERNAME=immich",
"DB_DATABASE_NAME=immich",
"DB_HOSTNAME=0.0.0.0",
"UPLOAD_LOCATION=./uploads",
"REDIS_HOSTNAME=redis",
"IMMICH_MACHINE_LEARNING_URL=http://203.0.113.44:3003",
"OPENAI_API_KEY=sk-demo-1234567890abcdef",
"\"0.0.0.0:5432:5432\"",
"\"0.0.0.0:2283:2283\"",
"this line cannot be parsed at all"
].join("\n");

var HARDENED = [
"# Hardened example",
"DB_PASSWORD=${DB_PASSWORD}",
"DB_USERNAME=immich_db_user_01",
"DB_DATABASE_NAME=immich_photo_library",
"DB_HOSTNAME=database",
"DB_PORT=5432",
"UPLOAD_LOCATION=/data/immich-uploads",
"REDIS_HOSTNAME=redis",
"IMMICH_MACHINE_LEARNING_URL=http://immich-machine-learning:3003",
"TYPESENSE_API_KEY=${TYPESENSE_API_KEY}",
"DB_PASSWORD_FILE=/run/secrets/db_password",
"\"127.0.0.1:2283:2283\""
].join("\n");

var RECOGNIZED = {
  DB_PASSWORD:1, DB_USERNAME:1, DB_DATABASE_NAME:1, DB_HOSTNAME:1, DB_PORT:1,
  UPLOAD_LOCATION:1, REDIS_HOSTNAME:1, REDIS_PORT:1, REDIS_PASSWORD:1,
  TYPESENSE_HOST:1, TYPESENSE_PORT:1, TYPESENSE_API_KEY:1, TYPESENSE_ENABLED:1,
  IMMICH_SERVER_URL:1, IMMICH_MACHINE_LEARNING_URL:1, IMMICH_VERSION:1,
  IMMICH_CONFIG_FILE:1, IMMICH_PORT:1, IMMICH_HOST:1, IMMICH_ENV:1,
  MACHINE_LEARNING_URL:1, ML_URL:1, OPENAI_API_KEY:1, OPENAI_BASE_URL:1,
  DB_PASSWORD_FILE:1, POSTGRES_PASSWORD:1, POSTGRES_USER:1, POSTGRES_DB:1,
  TZ:1, NODE_ENV:1, LOG_LEVEL:1, PUBLIC_LOGIN_PAGE_MESSAGE:1,
  AUTH_SECRET:1, JWT_SECRET:1, SESSION_SECRET:1, API_KEY:1, SECRET_KEY:1
};
var EXAMPLES = {password:1, changeme:1, example:1, immich:1, postgres:0, admin:0, "123456":1, secret:1, "letmein":1, "db_password":1};
var SECRET_WORDS = ["PASSWORD","SECRET","TOKEN","KEY"];

function isSecretKey(k){ for(var i=0;i<SECRET_WORDS.length;i++){ if(k.indexOf(SECRET_WORDS[i])!==-1) return true; } return false; }
function isReference(v){ return /^\$\{[^}]+\}$/.test(v) || /^\$[A-Za-z_][A-Za-z0-9_]*$/.test(v); }
function isLocalHost(h){
  if(!h) return true;
  h=h.toLowerCase();
  if(h==="localhost"||h==="127.0.0.1"||h==="::1") return true;
  if(h.indexOf(".")===-1) return true; // single-label docker service name = internal network
  if(/^10\./.test(h)||/^192\.168\./.test(h)||/^172\.(1[6-9]|2\d|3[01])\./.test(h)) return true;
  return false;
}
function hostOf(url){
  var m = url.match(/^https?:\/\/([^\/:?#]+)/i);
  return m ? m[1] : "";
}

function parseLine(raw){
  var t = raw.replace(/^\s+|\s+$/g,"");
  if(!t) return {type:"blank"};
  if(t.charAt(0)==="#") return {type:"comment"};
  // strip leading "- " (compose list item) and surrounding quotes for port lines
  var s = t.replace(/^-\s+/,"");
  // JSON pair: "KEY": "value"  or  "KEY": value  (quoted values may contain ${...} references)
  var jm = s.match(/^"([^"]+)"\s*:\s*(?:"([^"]*)"|([^,}]+?))\s*,?$/);
  if(jm && /^[A-Za-z_][A-Za-z0-9_]*$/.test(jm[1])){
    var jv = (jm[2]!==undefined ? jm[2] : jm[3]).replace(/^\s+|\s+$/g,"");
    return {type:"kv", key:jm[1].toUpperCase(), value:jv};
  }
  // port mapping line (quoted or bare): [ip:]hostPort:containerPort
  var unq = s.replace(/^["']|["']$/g,"");
  var pm = unq.match(/^(?:(\d{1,3}(?:\.\d{1,3}){3})|\*)?:?(\d{1,5}):(\d{1,5})(?:\/(tcp|udp))?$/);
  if(pm) return {type:"port", bind:pm[1]||"", hostPort:pm[2], containerPort:pm[3], raw:unq};
  if(/^\d{1,5}:\d{1,5}$/.test(unq)) return {type:"port", bind:"", hostPort:unq.split(":")[0], containerPort:unq.split(":")[1], raw:unq};
  // KEY=VALUE  or  KEY: VALUE
  var km = s.match(/^([A-Za-z_][A-Za-z0-9_]*)\s*[:=]\s*(.*)$/);
  if(km){
    var v = km[2].replace(/^\s+|\s+$/g,"");
    if(v.length>=2 && ((v.charAt(0)==='"'&&v.charAt(v.length-1)==='"')||(v.charAt(0)==="'"&&v.charAt(v.length-1)==="'"))) v=v.slice(1,-1);
    return {type:"kv", key:km[1].toUpperCase(), value:v};
  }
  return {type:"unparsed"};
}

function audit(text){
  var lines = text.split(/\r?\n/);
  var findings = []; // {severity, line, key, message}
  var entries = {};  // key -> {line, value}
  var entryList = [];
  var recognized = 0;
  function add(sev, line, key, msg){ findings.push({severity:sev, line:line, key:key||"", message:msg}); }

  for(var i=0;i<lines.length;i++){
    var ln = i+1;
    var p = parseLine(lines[i]);
    if(p.type==="blank") continue;
    if(p.type==="comment"){ add("INFO", ln, "", "COMMENTED / NOT ACTIVE — this line is commented out and was not graded as set."); continue; }
    if(p.type==="unparsed"){ add("INFO", ln, "", "NOT PARSED — this line could not be read as a key/value, JSON pair, or port mapping. It was not guessed."); continue; }
    if(p.type==="port"){
      var cp = parseInt(p.containerPort,10);
      var isDbRedis = (cp===5432||cp===6379);
      var allIface = (p.bind==="0.0.0.0" || p.bind==="");
      // A bare hostPort:containerPort with no bind IP publishes on all interfaces in Compose by default.
      if(allIface){
        if(isDbRedis) add("HIGH", ln, "PORT "+p.raw, "Port mapping \""+p.raw+"\" publishes a database/Redis port on all interfaces (0.0.0.0). Bind it to 127.0.0.1 or keep it on the internal Docker network only.");
        else add("WARNING", ln, "PORT "+p.raw, "Port mapping \""+p.raw+"\" publishes an app service port on all interfaces (0.0.0.0). Confirm this service is meant to be reachable from outside this host.");
      } else {
        add("INFO", ln, "PORT "+p.raw, "Port mapping \""+p.raw+"\" is bound to "+p.bind+" only — not published on all interfaces.");
      }
      continue;
    }
    // kv
    var key=p.key, val=p.value;
    entries[key]={line:ln, value:val};
    entryList.push({key:key, value:val, line:ln});
    if(RECOGNIZED[key]) recognized++;
  }

  // --- Database identity checks ---
  var coreKeys=["DB_PASSWORD","DB_USERNAME","DB_DATABASE_NAME"];
  for(var c=0;c<coreKeys.length;c++){
    var ck=coreKeys[c], e=entries[ck];
    if(recognized>=3){
      if(!e){ add("BLOCKER", null, ck, ck+" is missing from the pasted config. Immich needs it set to a real, non-example value before deploy."); continue; }
      if(e.value===""){ add("BLOCKER", e.line, ck, ck+" is set but empty (value length 0). Set a real value before deploy."); continue; }
      if(!isSecretKey(ck) && isReference(e.value)) { add("INFO", e.line, ck, ck+" uses a variable reference — treated as a safe reference, value not graded."); continue; }
      if(isSecretKey(ck) && (isReference(e.value) || /_FILE$/.test(ck))) continue; // handled below
      var low=e.value.toLowerCase();
      if(EXAMPLES[low]===1){ add("BLOCKER", e.line, ck, ck+" is set to a known example/default value (value length "+e.value.length+"). Change it to a unique value before deploy — the value itself is never shown in this report."); continue; }
      if(e.value.length<12 && !isReference(e.value)){
        add("HIGH", e.line, ck, ck+" is short — value length "+e.value.length+", under the 12-character minimum. Use a longer, unique value.");
      }
    }
  }

  // --- DB hostname / port ---
  var dh=entries["DB_HOSTNAME"];
  if(dh && (dh.value==="0.0.0.0"||dh.value==="*"||dh.value==="0.0.0.0/0")){
    add("WARNING", dh.line, "DB_HOSTNAME", "DB_HOSTNAME points at an all-interface value ("+dh.value+"). The database should be reached by its internal service name, not exposed on all interfaces.");
  }

  // --- Upload location ---
  var up=entries["UPLOAD_LOCATION"];
  if(recognized>=3 && !up){
    add("HIGH", null, "UPLOAD_LOCATION", "UPLOAD_LOCATION is missing. Without it, uploads default inside the container/app area and can be lost when the container is rebuilt. Point it at a persistent volume outside the app folder.");
  } else if(up){
    var uv=up.value;
    var isAbs = /^\//.test(uv) || /^[A-Za-z]:[\\/]/.test(uv);
    if(!isAbs || /^\.\.?\//.test(uv) || /(^|\/)app(\/|$)/i.test(uv) || /usr\/src\/app/i.test(uv)){
      add("WARNING", up.line, "UPLOAD_LOCATION", "UPLOAD_LOCATION points at a relative or app-internal path ("+uv+"). Use an absolute path on a persistent volume outside the app folder so photos survive rebuilds.");
    } else {
      add("INFO", up.line, "UPLOAD_LOCATION", "UPLOAD_LOCATION is an absolute path outside the app folder ("+uv+").");
    }
  }

  // --- Per-entry checks: secrets, http URLs ---
  for(var j=0;j<entryList.length;j++){
    var en=entryList[j];
    (function(en){
      var k=en.key, v=en.value;
      var fileRef = /_FILE$/.test(k);
      if(isSecretKey(k)){
        if(fileRef){ add("INFO", en.line, k, k+" is a *_FILE reference — the secret is loaded from a file, treated as safe. (Value length "+v.length+".)"); return; }
        if(isReference(v)){ add("INFO", en.line, k, k+" uses a variable reference — treated as safe; the actual secret is not in this config. (Value length "+v.length+".)"); return; }
        if(v===""){ return; } // empty already covered for core keys
        if(k==="DB_PASSWORD" && EXAMPLES[v.toLowerCase()]===1) return; // already BLOCKER, don't double-report
        add("HIGH", en.line, k, k+" has a plaintext secret value in the config (value length "+v.length+"). Move it to a variable reference or a *_FILE secret. The value is never shown in this report.");
        return;
      }
      // http:// to non-localhost for URL/host keys
      if(/^http:\/\//i.test(v)){
        var h=hostOf(v);
        if(!isLocalHost(h)){
          add("WARNING", en.line, k, k+" uses plain http:// to a non-localhost host ("+h+"). Use https://, or keep the service on the internal network only.");
        } else {
          add("INFO", en.line, k, k+" uses http:// to an internal/local host ("+(h||"internal")+") — acceptable inside a private Docker network.");
        }
      }
    })(en);
  }

  // Redis hostname sanity (info only if internal)
  var rh=entries["REDIS_HOSTNAME"];
  if(rh && /^http:\/\//i.test(rh.value) && !isLocalHost(hostOf(rh.value))){
    add("WARNING", rh.line, "REDIS_HOSTNAME", "REDIS_HOSTNAME points outside the local network over plain http. Redis should stay on the internal network.");
  }

  var counts={BLOCKER:0,HIGH:0,WARNING:0,INFO:0};
  findings.forEach(function(f){ counts[f.severity]++; });

  var verdict;
  if(recognized<3) verdict="NOT ENOUGH TO GRADE";
  else if(counts.BLOCKER>0) verdict="DO NOT DEPLOY";
  else if(counts.HIGH>0||counts.WARNING>0) verdict="DEPLOY WITH FIXES";
  else verdict="SAFE TO DEPLOY";

  return {verdict:verdict, findings:findings, counts:counts, recognized:recognized, lines:lines.length};
}

function esc(s){ return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"); }
var lastResult=null;
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLES": (typeof EXAMPLES !== 'undefined' ? EXAMPLES : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-immich-server-config-safety-auditortm',
  name: 'J-Dawgs Immich Server Config Safety Auditor',
  description: 'Host tools only tell you the container started; ours grades a pasted Immich .env/config offline into one serve verdict — default or weak database passwords, exposed secrets by key name/line/length only, and upload-location and port-exposure posture.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLES": __core["EXAMPLES"] }
};
