'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Rocket.Chat Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var RISKY = [
        "# Risky example — review before deploying",
        "ROOT_URL=http://chat.example.com",
        "PORT=3000",
        "MONGO_URL=mongodb://rocketchat:R1skyPassw0rd!@mongo.internal:27017/rocketchat?replicaSet=rs0",
        "MONGO_OPLOG_URL=mongodb://rocketchat:R1skyPassw0rd!@mongo.internal:27017/local?replicaSet=rs0",
        "Accounts_AllowUserRegistration=true",
        "ADMIN_PASS=admin123",
        "OVERWRITE_SETTING_FileUpload_Enabled=true",
        "Livechat_enabled=true",
        "ROOT_URL=http://chat.example.com",
        "# Accounts_AllowUserRegistration=false",
        "this line is not a setting at all"
      ].join("\n");

      var HARDENED = [
        "# Hardened example — reviewed for production",
        "ROOT_URL=https://chat.example.com",
        "PORT=3000",
        "MONGO_URL=mongodb://mongo.internal:27017/rocketchat?replicaSet=rs0",
        "MONGO_OPLOG_URL=mongodb://mongo.internal:27017/local?replicaSet=rs0",
        "Accounts_AllowUserRegistration=false",
        "Accounts_ManuallyApproveNewUsers=true",
        "Accounts_RegistrationDomainWhiteList=example.com",
        "OVERWRITE_SETTING_FileUpload_Enabled=false",
        "Livechat_enabled=false"
      ].join("\n");

      var input = document.getElementById("configInput");
      var gutter = document.getElementById("gutter");
      var inputStats = document.getElementById("inputStats");
      var verdictBox = document.getElementById("verdictBox");
      var verdictText = document.getElementById("verdictText");
      var verdictWhy = document.getElementById("verdictWhy");
      var countChips = document.getElementById("countChips");
      var findingsList = document.getElementById("findingsList");
      var textReportEl = document.getElementById("textReport");
      var jsonReportEl = document.getElementById("jsonReport");

      var lastTextReport = "";
      var lastJsonReport = "";

      /* ---------- parsing ---------- */

      var KNOWN_EXACT = {
        ROOT_URL:1, MONGO_URL:1, MONGO_OPLOG_URL:1, PORT:1, NODE_ENV:1, BIND_IP:1,
        ADMIN_PASS:1, ADMIN_USERNAME:1, ADMIN_EMAIL:1, DEPLOY_METHOD:1, DEPLOY_PLATFORM:1,
        INSTANCE_IP:1, CREATE_TOKENS_ON_LOGIN:1
      };

      function isRecognized(key){
        if (KNOWN_EXACT[key]) return true;
        if (/^(Accounts_|Livechat|FileUpload|OVERWRITE_SETTING_|Site_|SMTP_|LDAP_|CAS_|SAML_|OAuth|Registration)/.test(key)) return true;
        if (key.indexOf("_") !== -1 && /^[A-Z][A-Za-z0-9_]*$/.test(key)) return true;
        return false;
      }

      function splitKV(body){
        var m = body.match(/^"?([A-Za-z_][A-Za-z0-9_.\-]*)"?\s*(=|:)\s*(.*)$/);
        if (!m) return null;
        var val = (m[3] || "").trim();
        if (val.charAt(val.length - 1) === ",") val = val.slice(0, -1).trim();
        if (val.length >= 2 &&
            ((val.charAt(0) === '"' && val.charAt(val.length - 1) === '"') ||
             (val.charAt(0) === "'" && val.charAt(val.length - 1) === "'"))) {
          val = val.slice(1, -1);
        }
        return { key: m[1], value: val };
      }

      function parseLine(raw){
        var t = raw.trim();
        if (t === "") return { type: "blank" };
        if (t.charAt(0) === "#" || t.indexOf("//") === 0) {
          var inner = t.replace(/^#+\s?/, "").replace(/^\/\/\s?/, "");
          var kv = splitKV(inner);
          return { type: "comment", key: kv ? kv.key : null };
        }
        var body = t;
        if (/^export\s+/.test(body)) body = body.replace(/^export\s+/, "");
        var parsed = splitKV(body);
        if (!parsed) return { type: "unparsed" };
        return { type: "entry", key: parsed.key, value: parsed.value };
      }

      function truthy(v){
        var s = String(v).trim().toLowerCase();
        return s === "true" || s === "1" || s === "yes" || s === "on";
      }
      function falsy(v){
        var s = String(v).trim().toLowerCase();
        return s === "false" || s === "0" || s === "no" || s === "off";
      }
      function isPlaceholder(v){
        return /^\$\{[^}]*\}$/.test(v) || /^\{\{[^}]*\}\}$/.test(v) || v === "***" || /^<[^>]*>$/.test(v) || /^\$[A-Z_]+$/.test(v);
      }
      function isSecretKey(key){
        return /(PASS|PASSWORD|SECRET|TOKEN|API_?KEY|PRIVATE_?KEY|CREDENTIAL)/i.test(key);
      }
      var WEAK_EXACT = ["admin","password","passw0rd","changeme","letmein","rocketchat","secret","admin123","123456","12345678","qwerty","default","test123"];
      function isWeakSecret(v){
        var low = v.toLowerCase();
        if (WEAK_EXACT.indexOf(low) !== -1) return true;
        if (low.indexOf("example") !== -1) return true;
        if (low.indexOf("changeme") !== -1 || low.indexOf("change-me") !== -1 || low.indexOf("change_me") !== -1) return true;
        return false;
      }
      function mongoPassword(url){
        var m = String(url).match(/^mongodb(?:\+srv)?:\/\/[^:\/?#@\s]+:([^@\/?#\s]+)@/);
        if (!m) return null;
        var pw = m[1];
        try { pw = decodeURIComponent(pw); } catch (e) { /* keep raw length */ }
        return pw;
      }
      function hostOf(u){
        var m = String(u).match(/^[a-z][a-z0-9+.-]*:\/\/([^\/?#:]+)/i);
        return m ? m[1].toLowerCase() : "";
      }
      function isLocalHost(h){
        return h === "localhost" || h === "127.0.0.1" || h === "::1" || h === "[::1]" || h.indexOf("127.") === 0;
      }
      function baseKey(key){
        return key.replace(/^OVERWRITE_SETTING_/, "");
      }

      /* ---------- audit ---------- */

      function audit(text){
        var lines = String(text).split(/\r?\n/);
        var findings = [];
        var entries = [];       // active entries {key,value,line}
        var commented = 0;
        var notParsed = 0;

        function add(line, level, tag, key, message){
          findings.push({ line: line, level: level, tag: tag, key: key || null, message: message });
        }

        for (var i = 0; i < lines.length; i++){
          var ln = i + 1;
          var p = parseLine(lines[i]);
          if (p.type === "blank") continue;
          if (p.type === "comment"){
            commented++;
            if (p.key){
              add(ln, "INFO", "COMMENTED", p.key, p.key + " appears on a commented-out line — COMMENTED / NOT ACTIVE. It was not graded as an active setting.");
            } else {
              add(ln, "INFO", "COMMENTED", null, "Commented-out line — COMMENTED / NOT ACTIVE. It was not graded as an active setting.");
            }
            continue;
          }
          if (p.type === "unparsed"){
            notParsed++;
            add(ln, "WARNING", "NOT PARSED", null, "Line could not be read as a KEY=value setting or a known settings-dump entry — NOT PARSED. It was not graded; fix the line or remove it so nothing hides in it.");
            continue;
          }
          entries.push({ key: p.key, value: p.value, line: ln });
        }

        var recognized = 0;
        entries.forEach(function(e){ if (isRecognized(e.key)) recognized++; });

        /* NOT ENOUGH TO GRADE: empty input, or no recognizable Rocket.Chat config at all */
        if (String(text).trim() === "" || entries.length === 0 || recognized === 0){
          var why = String(text).trim() === ""
            ? "The input is empty — there is nothing to grade."
            : "No recognizable Rocket.Chat settings were found. Prose or unrelated text cannot be graded as a server configuration.";
          var f2 = findings.filter(function(f){ return f.tag === "NOT PARSED" || f.tag === "COMMENTED"; });
          return {
            verdict: "NOT ENOUGH TO GRADE",
            why: why,
            findings: f2,
            stats: { lines: lines.length, active: entries.length, commented: commented, notParsed: notParsed, recognized: recognized },
            counts: countLevels(f2)
          };
        }

        /* index active entries by key */
        var byKey = {};
        entries.forEach(function(e){
          if (!byKey[e.key]) byKey[e.key] = [];
          byKey[e.key].push(e);
        });
        function lastEntry(key){ var a = byKey[key]; return a ? a[a.length - 1] : null; }
        function anyEntry(pred){
          for (var j = 0; j < entries.length; j++){ if (pred(entries[j])) return entries[j]; }
          return null;
        }

        /* duplicate keys */
        Object.keys(byKey).forEach(function(k){
          var a = byKey[k];
          if (a.length > 1){
            var lineNums = a.map(function(e){ return e.line; });
            add(a[a.length - 1].line, "WARNING", "DUPLICATE", k,
              "Duplicate key " + k + " is defined on lines " + lineNums.join(" and ") + ". The last value wins (line " + a[a.length - 1].line + "); the earlier definition is dead text and a common source of \"I already fixed that\" confusion. Keep one definition.");
          }
        });

        /* ROOT_URL */
        var rootEntries = byKey["ROOT_URL"] || [];
        if (rootEntries.length === 0){
          add(null, "WARNING", "ROOT_URL", "ROOT_URL",
            "ROOT_URL is missing. Rocket.Chat builds links, emails, and OAuth redirects from it; a missing or wrong ROOT_URL breaks invites and integrations after deploy. Set it to the exact public URL of the server.");
        }
        rootEntries.forEach(function(e){
          var v = e.value.trim();
          var host = hostOf(v);
          if (/^http:\/\//i.test(v) && host && !isLocalHost(host)){
            add(e.line, "HIGH", "ROOT_URL", "ROOT_URL",
              "ROOT_URL uses plain http:// on a non-localhost host (" + host + "). Session cookies, login tokens, and chat content cross the network unencrypted. Switch to https:// behind a TLS-terminating proxy before deploying.");
          } else if (/^https:\/\//i.test(v)){
            add(e.line, "PASS", "ROOT_URL", "ROOT_URL", "ROOT_URL uses https:// — transport is encrypted.");
          } else if (/^http:\/\//i.test(v)){
            add(e.line, "PASS", "ROOT_URL", "ROOT_URL", "ROOT_URL uses http:// on a local host only — acceptable for local development, not for a public deploy.");
          } else {
            add(e.line, "WARNING", "ROOT_URL", "ROOT_URL", "ROOT_URL is set but does not start with http:// or https://, so its effective scheme cannot be confirmed from the pasted text.");
          }
        });

        /* MongoDB URLs: embedded plaintext passwords (redacted) */
        ["MONGO_URL", "MONGO_OPLOG_URL"].forEach(function(k){
          (byKey[k] || []).forEach(function(e){
            var pw = mongoPassword(e.value);
            if (pw !== null && pw !== ""){
              if (isPlaceholder(pw)){
                add(e.line, "PASS", k, k, k + " references its password through a placeholder rather than a literal value — no plaintext password graded. Password value never printed.");
              } else {
                add(e.line, "HIGH", k, k,
                  k + " embeds a plaintext password in the connection string (password length: " + pw.length + "). The value is redacted and never printed here. Anyone who can read this config owns the database: move the credential to a secrets store or restricted environment file, and rotate the password if this text was ever shared.");
              }
            } else if (/^mongodb(\+srv)?:\/\//i.test(e.value.trim())){
              add(e.line, "PASS", k, k, k + " carries no embedded password in the pasted text.");
            } else {
              add(e.line, "WARNING", k, k, k + " is set but does not look like a mongodb:// connection string, so its credential posture cannot be confirmed from the pasted text.");
            }
          });
        });

        /* Open registration */
        var regEntry = anyEntry(function(e){ return baseKey(e.key) === "Accounts_AllowUserRegistration"; });
        if (regEntry){
          if (truthy(regEntry.value)){
            var restriction = anyEntry(function(e){
              var bk = baseKey(e.key);
              if (/ManuallyApproveNewUsers/i.test(bk) && truthy(e.value)) return true;
              if (/RegistrationDomainWhiteList|RegistrationAllowedDomains|AllowedRegistrationDomains/i.test(bk) && e.value.trim() !== "") return true;
              if (/RequireApproval|ManualApproval/i.test(bk) && truthy(e.value)) return true;
              return false;
            });
            if (restriction){
              add(regEntry.line, "WARNING", "REGISTRATION", regEntry.key,
                "Open registration is on (" + regEntry.key + "=true), but an approval or domain restriction is also present (line " + restriction.line + "), which limits the exposure. Confirm the restriction is enforced before deploying.");
            } else {
              add(regEntry.line, "HIGH", "REGISTRATION", regEntry.key,
                "Accounts_AllowUserRegistration=true with no manual-approval or domain restriction anywhere in the pasted config. Anyone on the internet can create an account on this server. Set it to false, or pair it with manual approval / a registration domain whitelist.");
            }
          } else if (falsy(regEntry.value)){
            add(regEntry.line, "PASS", "REGISTRATION", regEntry.key, "Self-registration is disabled (" + regEntry.key + "=false). New accounts must be created or invited by an admin.");
          }
        }

        /* Secret keys (redacted: key + line + length only) */
        entries.forEach(function(e){
          if (!isSecretKey(e.key)) return;
          if (e.key === "MONGO_URL" || e.key === "MONGO_OPLOG_URL") return;
          var v = e.value;
          if (isPlaceholder(v)){
            add(e.line, "PASS", "SECRET", e.key, e.key + " is a placeholder reference, not a literal secret (length: " + v.length + "). Value never printed.");
          } else if (v.length < 12 || isWeakSecret(v)){
            add(e.line, "HIGH", "SECRET", e.key,
              e.key + " is a short or example-style secret (length: " + v.length + "). The value is redacted and never printed here. Replace it with a long, unique, generated secret before deploying — short and example passwords are the first thing an attacker tries.");
          } else {
            add(e.line, "PASS", "SECRET", e.key, e.key + " is present with a usable length (length: " + v.length + "). Value redacted and never printed.");
          }
        });

        /* File upload posture */
        var fuEntry = anyEntry(function(e){ return baseKey(e.key) === "FileUpload_Enabled"; });
        if (fuEntry){
          if (truthy(fuEntry.value)){
            add(fuEntry.line, "WARNING", "FILE UPLOAD", fuEntry.key,
              "File uploads are ENABLED (" + fuEntry.key + "=true). That is a malware and storage-abuse surface: confirm upload size limits, allowed file types, and virus scanning are set before this faces the public.");
          } else if (falsy(fuEntry.value)){
            add(fuEntry.line, "PASS", "FILE UPLOAD", fuEntry.key, "File uploads are disabled (" + fuEntry.key + "=false) — the upload attack surface is closed.");
          }
        }

        /* Livechat posture */
        var lcEntry = anyEntry(function(e){ return baseKey(e.key) === "Livechat_enabled"; });
        if (lcEntry){
          if (truthy(lcEntry.value)){
            add(lcEntry.line, "WARNING", "LIVECHAT", lcEntry.key,
              "Livechat is ENABLED (" + lcEntry.key + "=true). The public widget lets anonymous visitors open conversations with your team — staff it, restrict it, or turn it off if this server is internal-only.");
          } else if (falsy(lcEntry.value)){
            add(lcEntry.line, "PASS", "LIVECHAT", lcEntry.key, "Livechat is disabled (" + lcEntry.key + "=false) — no public anonymous chat widget is exposed.");
          }
        }

        /* sort findings by line (global findings last), stable */
        findings.sort(function(a, b){
          var la = a.line === null ? 1e9 : a.line;
          var lb = b.line === null ? 1e9 : b.line;
          return la - lb;
        });

        var counts = countLevels(findings);
        var verdict, why;
        if (counts.HIGH > 0){
          verdict = "DO NOT DEPLOY";
          why = counts.HIGH + " high-severity finding" + (counts.HIGH === 1 ? "" : "s") + " must be fixed before this configuration goes live.";
        } else if (counts.WARNING > 0){
          verdict = "DEPLOY WITH FIXES";
          why = "No high-severity findings, but " + counts.WARNING + " warning" + (counts.WARNING === 1 ? "" : "s") + " should be fixed before or immediately after deploy.";
        } else {
          verdict = "SAFE TO DEPLOY";
          why = "No high-severity findings and no warnings in the pasted text. This grades the pasted configuration only — admin-UI database overrides are outside its view.";
        }

        return {
          verdict: verdict,
          why: why,
          findings: findings,
          stats: { lines: lines.length, active: entries.length, commented: commented, notParsed: notParsed, recognized: recognized },
          counts: counts
        };
      }

      function countLevels(findings){
        var c = { HIGH: 0, WARNING: 0, INFO: 0, PASS: 0 };
        findings.forEach(function(f){ if (c[f.level] !== undefined) c[f.level]++; });
        return c;
      }

      /* ---------- reports ---------- */

      function levelLabel(f){
        if (f.tag === "COMMENTED") return "COMMENTED / NOT ACTIVE";
        if (f.tag === "NOT PARSED") return "NOT PARSED";
        return f.level;
      }
      function lineLabel(f){
        return f.line === null ? "Global" : "Line " + f.line;
      }

      function buildTextReport(r){
        var out = [];
        out.push("J-Dawgs Rocket.Chat Server Config Safety Auditor — Text Report");
        out.push("Verdict: " + r.verdict);
        out.push("Why: " + r.why);
        out.push("Lines reviewed: " + r.stats.lines + " | Active settings: " + r.stats.active +
                 " | Commented lines: " + r.stats.commented + " | Not parsed: " + r.stats.notParsed);
        out.push("Counts: HIGH " + r.counts.HIGH + " · WARNING " + r.counts.WARNING +
                 " · INFO " + r.counts.INFO + " · PASS " + r.counts.PASS);
        out.push("");
        out.push("Findings:");
        if (r.findings.length === 0){
          out.push("(none)");
        }
        r.findings.forEach(function(f){
          out.push("[" + levelLabel(f) + "] " + lineLabel(f) + (f.key ? " · " + f.key : "") + " — " + f.message);
        });
        out.push("");
        out.push("Redaction: secrets are reported by key name, line number, and value length only. Secret values never appear in this report.");
        out.push("Scope: text audit only. This report does not start Rocket.Chat, does not connect to MongoDB, and cannot verify settings applied in the admin UI (database overrides).");
        return out.join("\n");
      }

      function buildJsonReport(r){
        var obj = {
          tool: "J-Dawgs Rocket.Chat Server Config Safety Auditor",
          verdict: r.verdict,
          why: r.why,
          stats: r.stats,
          counts: r.counts,
          redaction: "Secrets are reported by key name, line, and length only; values are never included.",
          scope: "Text audit only. Does not start Rocket.Chat, does not connect to MongoDB, cannot verify admin-UI database overrides.",
          findings: r.findings.map(function(f){
            return {
              line: f.line,
              level: levelLabel(f),
              check: f.tag,
              key: f.key,
              message: f.message
            };
          })
        };
        return JSON.stringify(obj, null, 2);
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-rocket-chat-server-config-safety-auditortm',
  name: 'J-Dawgs Rocket.Chat Server Config Safety Auditor',
  description: 'Grades a pasted Rocket.Chat server config fully offline into one deploy verdict — SAFE TO DEPLOY / DEPLOY WITH FIXES / DO NOT DEPLOY / NOT ENOUGH TO GRADE — http ROOT_URL, open registration, and plaintext Mongo and admin passwords, with secrets shown by key name, line, and length only, never by valu',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
