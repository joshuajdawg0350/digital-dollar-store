'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Homebox Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

/* ---------- Worked examples (line numbers are part of the contract) ---------- */
var RISKY_LINES = [
  "HBOX_MODE=demo",
  "HBOX_BASE_URL=http://homebox.example.com",
  "HBOX_ALLOW_REGISTRATION=true",
  "HBOX_LOG_LEVEL=debug",
  "HBOX_MAILER_HOST=smtp.example.com",
  "HBOX_MAILER_PASSWORD=Plant3d-Secret!98765",
  "HBOX_STORAGE_URL=postgres://homebox:DbPass!445566@db.example.com:5432/homebox",
  "HBOX_HOST=0.0.0.0",
  "HBOX_ALLOWED_HOSTS=*",
  "HBOX_SESSION_SECURE=false"
];
var RISKY_EXAMPLE = RISKY_LINES.join("\n");

var HARDENED_LINES = [
  "HBOX_MODE=production",
  "HBOX_BASE_URL=https://homebox.example.com",
  "HBOX_ALLOW_REGISTRATION=false",
  "HBOX_DISABLE_REGISTRATION=true",
  "HBOX_LOG_LEVEL=info",
  "HBOX_MAILER_HOST=smtp.example.com",
  "HBOX_MAILER_PASSWORD=${MAILER_SECRET_FROM_VAULT}",
  "HBOX_STORAGE_URL=postgres://homebox@db.example.com:5432/homebox",
  "HBOX_HOST=127.0.0.1",
  "HBOX_ALLOWED_HOSTS=homebox.example.com",
  "HBOX_SESSION_SECURE=true",
  "HBOX_TLS_ENABLED=true",
  "HBOX_COOKIE_SECURE=true"
];
var HARDENED_EXAMPLE = HARDENED_LINES.join("\n");

/* ---------- Parsing ---------- */
function stripQuotes(v){
  if (v.length >= 2){
    var a = v.charAt(0), b = v.charAt(v.length - 1);
    if ((a === '"' && b === '"') || (a === "'" && b === "'")) return v.slice(1, -1);
  }
  return v;
}
function parseConfig(text){
  var rawLines = String(text == null ? "" : text).split(/\r?\n/);
  var entries = [];
  for (var i = 0; i < rawLines.length; i++){
    var lineNo = i + 1;
    var t = rawLines[i].trim();
    if (!t) continue;
    if (t.charAt(0) === "#" || t.indexOf("//") === 0 || t.charAt(0) === ";") continue;
    if (t.indexOf("export ") === 0) t = t.slice(7).trim();
    var m = t.match(/^([A-Za-z_][A-Za-z0-9_.\-]*)\s*=\s*(.*)$/);
    if (!m) continue;
    entries.push({ line: lineNo, key: m[1], keyUp: m[1].toUpperCase(), value: stripQuotes(m[2].trim()) });
  }
  return { totalLines: rawLines.length, entries: entries };
}
function isTruthy(v){ var s = String(v).toLowerCase(); return s === "true" || s === "1" || s === "yes" || s === "on" || s === "enabled"; }
function isFalsy(v){ var s = String(v).toLowerCase(); return s === "false" || s === "0" || s === "no" || s === "off" || s === "disabled"; }
function isReference(v){
  var s = String(v).trim();
  if (!s) return true;
  if (s.indexOf("${") === 0 || s.indexOf("{{") === 0 || s.charAt(0) === "$") return true;
  var low = s.toLowerCase();
  var placeholders = ["changeme","change-me","change_me","example","placeholder","redacted","your-password","your_password","xxx","***","todo","none","null"];
  for (var i = 0; i < placeholders.length; i++){ if (low === placeholders[i]) return true; }
  if (low.indexOf("vault:") === 0 || low.indexOf("secret:") === 0 || low.indexOf("file:") === 0 || low.indexOf("env:") === 0) return true;
  return false;
}
function isSecretKey(keyUp){
  return keyUp.indexOf("PASSWORD") !== -1 || keyUp.indexOf("PASSWD") !== -1 ||
         keyUp.indexOf("SECRET") !== -1 || keyUp.indexOf("API_KEY") !== -1 ||
         keyUp.indexOf("APIKEY") !== -1 || keyUp.indexOf("PRIVATE_KEY") !== -1 ||
         keyUp.indexOf("ACCESS_TOKEN") !== -1 || keyUp.indexOf("CREDENTIAL") !== -1;
}

/* ---------- Audit ---------- */
function auditConfig(text){
  var parsed = parseConfig(text);
  var entries = parsed.entries;
  var findings = [];
  function add(line, severity, code, key, valueLength, title, detail){
    findings.push({ line: line, severity: severity, code: code, key: key || null,
      valueLength: (typeof valueLength === "number" ? valueLength : null), title: title, detail: detail });
  }

  if (entries.length < 2){
    return { verdict: "NOT ENOUGH TO GRADE", totalLines: parsed.totalLines,
      keyCount: entries.length, findings: findings,
      verdictDetail: entries.length === 0
        ? "No config lines were found. Paste at least two KEY=value lines from an env-style Homebox config to get a grade."
        : "Only " + entries.length + " config line was found. Paste the fuller env-style config (at least two KEY=value lines) to get a grade." };
  }

  var hasHttps = false, hasSecureFlag = false, hasUrlEntry = false;

  for (var i = 0; i < entries.length; i++){
    var e = entries[i], k = e.keyUp, v = e.value, lv = v.toLowerCase();

    if (/^https:\/\//i.test(v)) hasHttps = true;
    if (/^https?:\/\//i.test(v)) hasUrlEntry = true;
    if ((k.indexOf("SECURE") !== -1 || k.indexOf("TLS") !== -1 || k.indexOf("SSL") !== -1) && isTruthy(v)) hasSecureFlag = true;

    /* Demo mode */
    if ((k.indexOf("MODE") !== -1 && lv === "demo") || (k.indexOf("DEMO") !== -1 && isTruthy(v))){
      add(e.line, "critical", "DEMO_MODE", e.key, null,
        "Demo mode is switched on",
        "Key " + e.key + " turns demo mode on. A deployed server must run in production mode, with real data and real accounts only.");
    }

    /* Open registration */
    if (k.indexOf("REGISTRATION") !== -1 || k.indexOf("REGISTER") !== -1){
      var disables = k.indexOf("DISABLE") !== -1;
      if (disables && isFalsy(v)){
        add(e.line, "high", "OPEN_REGISTRATION", e.key, null,
          "Registration is effectively open",
          "Key " + e.key + " is set to false, which switches the registration block off. Anyone who can reach the server can create an account.");
      } else if (!disables && isTruthy(v)){
        add(e.line, "high", "OPEN_REGISTRATION", e.key, null,
          "Open registration is switched on",
          "Key " + e.key + " allows anyone who can reach the server to register an account. Close registration once your own accounts exist.");
      }
    }

    /* Plain http URL */
    if (/^http:\/\//i.test(v)){
      add(e.line, "high", "INSECURE_HTTP_URL", e.key, null,
        "Address uses http, not https",
        "Key " + e.key + " points at an http:// address. Logins and session cookies cross the network unencrypted. Serve the deployment over https and update this address.");
    }

    /* Password embedded in a URL (mailer / storage / database) */
    var urlPw = v.match(/^[a-z][a-z0-9+.\-]*:\/\/[^\/\s:@]+:([^@\s]+)@/i);
    if (urlPw){
      add(e.line, "critical", "EMBEDDED_URL_PASSWORD", e.key, urlPw[1].length,
        "Password embedded in a connection URL",
        "Key " + e.key + " carries a password inside its URL (password length " + urlPw[1].length + "; the value itself is never shown here). Move the credential into a secrets store and reference it instead of writing it into the URL.");
    } else if (isSecretKey(k) && v !== "" && !isReference(v)){
      /* Plaintext secret in a password-style key */
      add(e.line, "critical", "PLAINTEXT_SECRET", e.key, v.length,
        "Plaintext password in config",
        "Key " + e.key + " holds a plaintext value (length " + v.length + "; the value itself is never shown here). Anyone who can read this file has the credential. Move it to a secrets store or an injected environment secret.");
    }

    /* Debug logging */
    if (((k.indexOf("LOG_LEVEL") !== -1 || k.indexOf("LOGLEVEL") !== -1) && (lv === "debug" || lv === "trace")) ||
        (k.indexOf("DEBUG") !== -1 && isTruthy(v))){
      add(e.line, "medium", "DEBUG_LOGGING", e.key, null,
        "Debug logging is switched on",
        "Key " + e.key + " enables debug-level output. Debug logs leak internals and can capture credentials. Run production at info level or higher.");
    }

    /* Secure session / TLS explicitly off */
    if ((k.indexOf("SECURE") !== -1 || k.indexOf("TLS") !== -1 || k.indexOf("SSL") !== -1 || k.indexOf("HTTPS") !== -1) && isFalsy(v)){
      add(e.line, "high", "INSECURE_SESSION_TLS", e.key, null,
        "Secure session / TLS posture switched off",
        "Key " + e.key + " is set to a disabled value. Secure cookies and TLS protections should be on for any deployment reachable beyond your own machine.");
    }

    /* Wildcard hosts */
    if (k.indexOf("HOST") !== -1 || k.indexOf("CORS") !== -1 || k.indexOf("ORIGIN") !== -1 || k.indexOf("ALLOWED") !== -1){
      var parts = v.split(/[,\s]+/);
      var star = (v === "*") || parts.indexOf("*") !== -1;
      if (star){
        add(e.line, "high", "WILDCARD_HOSTS", e.key, null,
          "Wildcard host accepted",
          "Key " + e.key + " accepts every host (*). Name the exact hostnames this deployment serves so other sites cannot ride on it.");
      } else if (v === "0.0.0.0"){
        add(e.line, "medium", "WILDCARD_HOSTS", e.key, null,
          "Bound to every network interface",
          "Key " + e.key + " binds the server to 0.0.0.0 (every interface). That is fine behind a hardened reverse proxy, but risky on its own — bind to loopback or a named interface where you can.");
      }
    } else if (v === "0.0.0.0"){
      add(e.line, "medium", "WILDCARD_HOSTS", e.key, null,
        "Bound to every network interface",
        "Key " + e.key + " binds the server to 0.0.0.0 (every interface). That is fine behind a hardened reverse proxy, but risky on its own — bind to loopback or a named interface where you can.");
    }
  }

  /* Missing secure posture altogether */
  if (!hasUrlEntry && !hasHttps && !hasSecureFlag){
    add(1, "medium", "MISSING_SECURE_POSTURE", null, null,
      "No secure session / TLS posture in config",
      "No https address and no secure-session or TLS flag appears anywhere in the pasted config. Confirm the deployment is served over https with secure cookies before it goes live.");
  }

  findings.sort(function(a, b){ return a.line - b.line; });

  var hasCritical = findings.some(function(f){ return f.severity === "critical"; });
  var hasFix = findings.some(function(f){ return f.severity === "high" || f.severity === "medium"; });
  var verdict, detail;
  if (hasCritical){
    verdict = "DO NOT DEPLOY";
    detail = "Critical findings are present. Fix every critical and high finding before this config goes on a reachable server.";
  } else if (hasFix){
    verdict = "DEPLOY WITH FIXES";
    detail = "No critical findings, but high or medium findings remain. Work through the list below, then audit again.";
  } else {
    verdict = "SAFE TO DEPLOY";
    detail = "No check in the list fired on the pasted config. This grades the pasted text only — it does not prove the server starts.";
  }
  return { verdict: verdict, verdictDetail: detail, totalLines: parsed.totalLines,
    keyCount: entries.length, findings: findings };
}

/* ---------- Report / JSON (built only from safe finding fields) ---------- */
function buildReport(result){
  var out = [];
  out.push("J-Dawgs Homebox Server Config Safety Auditor — Report");
  out.push("Verdict: " + result.verdict);
  out.push("Lines scanned: " + result.totalLines + " · Keys parsed: " + result.keyCount + " · Findings: " + result.findings.length);
  out.push("Note: " + result.verdictDetail);
  out.push("");
  if (!result.findings.length){
    out.push("Findings: none.");
  } else {
    out.push("Findings:");
    for (var i = 0; i < result.findings.length; i++){
      var f = result.findings[i];
      var head = "- [Line " + f.line + "] [" + f.severity.toUpperCase() + "] " + f.code + " — " + f.title;
      if (f.key) head += " (key: " + f.key + (f.valueLength != null ? ", value length: " + f.valueLength : "") + ")";
      out.push(head);
      out.push("  " + f.detail);
    }
  }
  out.push("");
  out.push("Generated locally in your browser. The pasted config was not uploaded or saved. Secret values are never included in this report.");
  return out.join("\n");
}
function buildJson(result){
  return JSON.stringify({
    tool: "J-Dawgs Homebox Server Config Safety Auditor",
    verdict: result.verdict,
    verdictDetail: result.verdictDetail,
    linesScanned: result.totalLines,
    keysParsed: result.keyCount,
    findings: result.findings.map(function(f){
      return { line: f.line, severity: f.severity, code: f.code, key: f.key,
        valueLength: f.valueLength, title: f.title, detail: f.detail };
    })
  }, null, 2);
}

/* ---------- UI ---------- */
var lastResult = null;
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-homebox-server-config-safety-auditortm',
  name: 'J-Dawgs Homebox Server Config Safety Auditor',
  description: 'Grades a pasted Homebox config offline into one deploy verdict — demo mode, open registration, http base URL, and plaintext credentials graded.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
