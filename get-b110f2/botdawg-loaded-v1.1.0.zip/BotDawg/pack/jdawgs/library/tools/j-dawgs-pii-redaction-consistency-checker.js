'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs PII Redaction Consistency Checker".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the analyze function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

var LEAKY = [
"INCIDENT REPORT — Q3 Review",
"Date: 2026-10-14",
"Client: J*** D***",
"Contact email: j***@examplemail.com",
"Alt contact: jordan.***@examplemail.com",
"Notes: Client [REDACTED] called about billing and asked for a callback.",
"Phone on file: (555) 014-2289",
"Billing address: [REDACTED]",
"",
"— Footer —",
"Prepared for Jordan Davis — jordan.davis@examplemail.com — Springfield office."
].join("\n");

var CLEAN = [
"SUMMARY REPORT",
"Client: [REDACTED]",
"Contact: [REDACTED]",
"Phone: [REDACTED]",
"Address: [REDACTED]",
"Notes: The client confirmed delivery on schedule. No identifiers are included in this summary.",
"All names, emails, and numbers were removed consistently using [REDACTED]."
].join("\n");

var input = document.getElementById('docInput');
input.value = LEAKY;

function abbr(v){
  if(!v) return "";
  if(v.length<=2) return v.charAt(0)+"…";
  return v.charAt(0)+"…"+v.charAt(v.length-1)+" ("+v.length+" chars)";
}
function esc(s){return s.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");}
function initialsOf(name){
  return name.split(/\s+/).map(function(w){return w.charAt(0).toUpperCase();}).join("");
}
function emailKey(email){
  var parts = email.toLowerCase().split("@");
  if(parts.length<2) return null;
  var domain = parts[1].replace(/\*/g,"");
  if(!domain) return null;
  return parts[0].charAt(0)+"@"+domain;
}
function maskedEmailKey(token){
  var t = token.toLowerCase();
  var at = t.indexOf("@");
  if(at<0) return null;
  var first = "";
  for(var i=0;i<t.length;i++){ if(/[a-z0-9]/.test(t.charAt(i))){ first=t.charAt(i); break; } }
  var domain = t.slice(at+1).replace(/\*/g,"");
  if(!first||!domain||domain.indexOf(".")<0) return null;
  return first+"@"+domain;
}
function maskedNameInitials(token){
  // e.g. "J*** D***" -> "JD" ; "J***" alone -> "J"
  var parts = token.trim().split(/\s+/);
  var out = "";
  for(var i=0;i<parts.length;i++){
    var m = parts[i].match(/^([A-Za-z])\*{2,}$/);
    if(m) out += m[1].toUpperCase();
    else return null;
  }
  return out.length? out : null;
}

var STOP_NAMES = ["Incident Report","Summary Report","Q3 Review","Springfield Office","Billing Address","Alt Contact","Contact Email","Phone On","Prepared For"];
function isStopName(n){
  for(var i=0;i<STOP_NAMES.length;i++){ if(n.toLowerCase()===STOP_NAMES[i].toLowerCase()) return true; }
  return false;
}

function analyze(text){
  var lines = text.split("\n");
  var markers = [];   // {raw, style, line}
  var visible = [];   // {type, value, line, key}
  var maskedNameKeys = {};  // initials -> [{raw,line}]
  var maskedEmailKeys = {}; // key -> [{raw,line}]
  var hasPhoneMask = false;

  var emailRe = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b/g;
  var phoneRe = /(?:\+?1[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b/g;
  var addrRe = /\b\d{1,6}\s+(?:[A-Z][a-z]+\s+){0,3}[A-Z][a-z]+\s+(?:St|Street|Ave|Avenue|Blvd|Boulevard|Rd|Road|Dr|Drive|Ln|Lane|Ct|Court|Way|Hwy|Highway)\b/g;
  var ssnRe = /\b\d{3}-\d{2}-\d{4}\b/g;
  var cardRe = /\b\d{4}[- ]\d{4}[- ]\d{4}[- ]\d{4}\b/g;
  var acctRe = /\b(?:Acct|Account|Member|Customer|Case|ID)\b\s*(?:No\.?|#|:)?\s*([A-Z0-9][A-Z0-9-]{4,})\b/gi;
  var longNumRe = /\b\d{7,}\b/g;
  var nameRe = /\b[A-Z][a-z]{1,}\s+[A-Z][a-z]{1,}(?:\s+[A-Z][a-z]{1,})?\b/g;
  var bracketRe = /\[[^\]\n]{0,40}\]/g;
  var blockRe = /█{2,}/g;
  var starTokenRe = /[A-Za-z0-9._%+-]*\*{2,}[A-Za-z0-9._%+@*-]*/g;
  var initialsRe = /\b[A-Z]\.(?:\s?[A-Z]\.)+\b/g;
  var phoneMaskRe = /(?:\*|\d){0,3}[-.\s]?\(\?\*{3}\)?[-.\s]?\*{3,4}[-.\s]?\d{0,4}|\*{3}[-.\s]\*{3}[-.\s]\d{4}/g;

  lines.forEach(function(line, idx){
    var ln = idx+1;
    var m, i;

    // --- markers ---
    var bracketSpans = [];
    bracketRe.lastIndex=0;
    while((m=bracketRe.exec(line))!==null){
      bracketSpans.push([m.index, m.index+m[0].length]);
      if(/redact|hidden|removed|name|email|phone|address/i.test(m[0])){
        markers.push({raw:m[0], style:"Bracketed placeholder", line:ln});
      }
    }
    blockRe.lastIndex=0;
    while((m=blockRe.exec(line))!==null){ markers.push({raw:m[0], style:"Block characters (██)", line:ln}); }

    // phone-style mask (contains stars in phone shape)
    phoneMaskRe.lastIndex=0;
    while((m=phoneMaskRe.exec(line))!==null){ hasPhoneMask = true; }

    starTokenRe.lastIndex=0;
    while((m=starTokenRe.exec(line))!==null){
      var tok = m[0];
      if(!/[A-Za-z0-9]/.test(tok) && /^\*+$/.test(tok)){
        markers.push({raw:tok, style:"Asterisks only (***)", line:ln});
        continue;
      }
      // multi-word partial name mask like "J*** D***" — capture following word too
      var rest = line.slice(m.index+tok.length);
      var follow = rest.match(/^\s+([A-Za-z]\*{2,})/);
      var fullTok = tok;
      if(follow && /^[A-Za-z]\*{2,}$/.test(tok)){ fullTok = tok + " " + follow[1]; }
      if(tok.indexOf("@")>=0){
        markers.push({raw:fullTok, style:"Partial email mask", line:ln});
        var k = maskedEmailKey(tok);
        if(k){ (maskedEmailKeys[k]=maskedEmailKeys[k]||[]).push({raw:fullTok, line:ln}); }
      } else {
        markers.push({raw:fullTok, style:"Partial mask (letters + ***)", line:ln});
        var ini = maskedNameInitials(fullTok);
        if(ini){ (maskedNameKeys[ini]=maskedNameKeys[ini]||[]).push({raw:fullTok, line:ln}); }
      }
      if(follow && /^[A-Za-z]\*{2,}$/.test(tok)){ starTokenRe.lastIndex = m.index + fullTok.length; }
    }

    initialsRe.lastIndex=0;
    while((m=initialsRe.exec(line))!==null){
      markers.push({raw:m[0], style:"Initials only", line:ln});
      var ini = m[0].replace(/[^A-Za-z]/g,"").toUpperCase();
      (maskedNameKeys[ini]=maskedNameKeys[ini]||[]).push({raw:m[0], line:ln});
    }

    // --- visible identifiers ---
    function inBracket(pos){ for(var b=0;b<bracketSpans.length;b++){ if(pos>=bracketSpans[b][0]&&pos<bracketSpans[b][1]) return true; } return false; }

    emailRe.lastIndex=0;
    while((m=emailRe.exec(line))!==null){
      if(line.charAt(m.index-1)==="*"||m[0].indexOf("*")>=0) continue;
      visible.push({type:"Email", value:m[0], line:ln, key:emailKey(m[0])});
    }
    ssnRe.lastIndex=0;
    while((m=ssnRe.exec(line))!==null){ visible.push({type:"ID number (SSN format)", value:m[0], line:ln, key:null}); }
    cardRe.lastIndex=0;
    while((m=cardRe.exec(line))!==null){ visible.push({type:"Card / account number", value:m[0], line:ln, key:null}); }
    phoneRe.lastIndex=0;
    while((m=phoneRe.exec(line))!==null){
      if(/^\d{3}-\d{2}-\d{4}$/.test(m[0])) continue; // SSN handled above
      visible.push({type:"Phone number", value:m[0], line:ln, key:"phone"});
    }
    addrRe.lastIndex=0;
    while((m=addrRe.exec(line))!==null){ visible.push({type:"Street address", value:m[0], line:ln, key:null}); }
    acctRe.lastIndex=0;
    while((m=acctRe.exec(line))!==null){
      if(m[1] && m[1].length>=5 && /\d/.test(m[1])) visible.push({type:"Account / ID number", value:m[1], line:ln, key:null});
    }
    longNumRe.lastIndex=0;
    while((m=longNumRe.exec(line))!==null){
      var dup=false;
      for(i=0;i<visible.length;i++){ if(visible[i].line===ln && visible[i].value.indexOf(m[0])>=0) dup=true; }
      if(!dup) visible.push({type:"Long number (possible ID)", value:m[0], line:ln, key:null});
    }
    nameRe.lastIndex=0;
    while((m=nameRe.exec(line))!==null){
      if(inBracket(m.index)) continue;
      if(isStopName(m[0])) continue;
      if(/^(Street|Avenue|Road|Drive|Lane|Court)$/.test(m[0].split(" ").pop()) && /\d/.test(line.slice(0,m.index))) continue;
      visible.push({type:"Full name", value:m[0], line:ln, key:initialsOf(m[0])});
    }
  });

  // --- cross-checks ---
  var findings = []; // {sev, line, msg, abbrVal}
  var seenCrit = {};
  visible.forEach(function(v){
    var isCrit = false, critWhy = "";
    if(v.type==="Full name" && v.key && maskedNameKeys[v.key]){
      isCrit = true; critWhy = "masked as “"+maskedNameKeys[v.key][0].raw+"” on line "+maskedNameKeys[v.key][0].line;
    }
    if(v.type==="Email" && v.key && maskedEmailKeys[v.key]){
      isCrit = true; critWhy = "masked on line "+maskedEmailKeys[v.key][0].line;
    }
    if(isCrit){
      var ck = v.type+"|"+v.value.toLowerCase();
      if(!seenCrit[ck]){
        seenCrit[ck]=true;
        findings.push({sev:"CRITICAL", line:v.line, text:v.type+" "+abbr(v.value)+" is fully visible here but "+critWhy+" — the mask is undone by this line. Remove or mask this occurrence the same way."});
      }
    } else if(v.type==="Phone number"){
      if(!hasPhoneMask){
        findings.push({sev:"REVIEW", line:v.line, text:"Phone number "+abbr(v.value)+" is visible and no masked phone appears anywhere. If this document leaves your hands, mask or remove it."});
      } else {
        findings.push({sev:"REVIEW", line:v.line, text:"Phone number "+abbr(v.value)+" is visible. Confirm it is meant to stay visible."});
      }
    } else {
      findings.push({sev:"REVIEW", line:v.line, text:v.type+" "+abbr(v.value)+" is visible with no masked counterpart found. Confirm it is cleared to share, or mask it."});
    }
  });

  // same entity masked two ways -> WARNING
  Object.keys(maskedEmailKeys).forEach(function(k){
    var arr = maskedEmailKeys[k];
    var distinct = {};
    arr.forEach(function(x){ distinct[x.raw]=x.line; });
    var raws = Object.keys(distinct);
    if(raws.length>=2){
      findings.push({sev:"WARNING", line:distinct[raws[1]], text:"Same email masked two different ways: “"+raws[0]+"” (line "+distinct[raws[0]]+") and “"+raws[1]+"” (line "+distinct[raws[1]]+"). The fuller mask leaks more of the address. Pick one mask style and use it everywhere."});
    }
  });
  Object.keys(maskedNameKeys).forEach(function(k){
    var arr = maskedNameKeys[k];
    var distinct = {};
    arr.forEach(function(x){ distinct[x.raw]=x.line; });
    var raws = Object.keys(distinct);
    if(raws.length>=2){
      findings.push({sev:"WARNING", line:distinct[raws[1]], text:"Same person (initials "+k+") masked two different ways: “"+raws[0]+"” (line "+distinct[raws[0]]+") and “"+raws[1]+"” (line "+distinct[raws[1]]+"). Use one mask style consistently."});
    }
  });

  findings.sort(function(a,b){
    var order={CRITICAL:0,WARNING:1,REVIEW:2};
    if(order[a.sev]!==order[b.sev]) return order[a.sev]-order[b.sev];
    return a.line-b.line;
  });

  var crit = findings.filter(function(f){return f.sev==="CRITICAL";}).length;
  var warn = findings.filter(function(f){return f.sev==="WARNING";}).length;
  var rev  = findings.filter(function(f){return f.sev==="REVIEW";}).length;
  var verdict = crit>0 ? "DO NOT SHARE" : (warn>0||rev>0 ? "FIX BEFORE SHARING" : "SAFE TO SHARE");
  return {markers:markers, visible:visible, findings:findings, crit:crit, warn:warn, rev:rev, verdict:verdict};
}
  return { "analyze": (typeof analyze !== 'undefined' ? analyze : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["analyze"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-pii-redaction-consistency-checker',
  name: 'J-Dawgs PII Redaction Consistency Checker',
  description: 'Checks whether personal data is redacted consistently through a whole document; masked-here/visible-there is a CRITICAL leak; SAFE TO SHARE / DO NOT SHARE verdict with a fix list',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["analyze"]) return { ok: false, output: null, summary: 'Extracted core has no analyze function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
