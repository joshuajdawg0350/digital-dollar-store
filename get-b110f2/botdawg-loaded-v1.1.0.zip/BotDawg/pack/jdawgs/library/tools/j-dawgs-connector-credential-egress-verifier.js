'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Connector Credential & Egress Verifier".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the analyze function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var $ = function (id) { return document.getElementById(id); };
        var errEl = $("errtext"),
            schemeEl = $("f-scheme"),
            placementEl = $("f-placement"),
            hostEl = $("f-host"),
            connectedEl = $("f-connected"),
            msgEl = $("bench-msg"),
            resultsEl = $("results"),
            verdictEl = $("verdict"),
            vLabel = $("v-label"),
            vWord = $("v-word"),
            vWhy = $("v-why"),
            evidenceEl = $("evidence"),
            fixTitle = $("fix-title"),
            fixList = $("fixlist"),
            copyNote = $("copy-note"),
            fallbackWrap = $("reportFallback"),
            reportText = $("reportText");

        var lastReport = "";

        /* ---------------- examples ---------------- */
        var EXAMPLES = {
          placeholder: {
            text: 'HTTP 403 Forbidden\n{\n  "error": {\n    "code": 403,\n    "message": "Invalid API key provided: hsurr:9f2c-placeholder-token",\n    "type": "invalid_request_error"\n  }\n}',
            scheme: "api_key", placement: "bearer", host: "yes", connected: "yes"
          },
          masked: {
            text: 'HTTP 401 Unauthorized\n{\n  "error": {\n    "message": "Invalid API key provided: rk_live_...Xk8c",\n    "code": "api_key_invalid",\n    "type": "authentication_error"\n  }\n}',
            scheme: "api_key", placement: "bearer", host: "yes", connected: "yes"
          },
          scope: {
            text: 'HTTP 403 Forbidden\n{\n  "error": {\n    "status": "PERMISSION_DENIED",\n    "message": "The API key provided was accepted, but it does not have permission to perform this action. Insufficient scope: this key is read-only and cannot create resources.",\n    "code": "insufficient_permissions"\n  }\n}',
            scheme: "api_key", placement: "bearer", host: "yes", connected: "yes"
          }
        };

        /* ---------------- pattern helpers ---------------- */
        function find(re, text) {
          var m = text.match(re);
          return m ? m[0] : null;
        }
        function snippet(text, matchStr) {
          if (!matchStr) return "";
          var i = text.indexOf(matchStr);
          if (i < 0) return matchStr;
          var start = Math.max(0, i - 30), end = Math.min(text.length, i + matchStr.length + 30);
          var s = text.slice(start, end).replace(/\s+/g, " ").trim();
          if (start > 0) s = "…" + s;
          if (end < text.length) s = s + "…";
          return s;
        }

        /* ---------------- the diagnosis catalogue ---------------- */
        var DIAG = {
          1: {
            word: "Placeholder token reached the provider unswapped",
            tone: "d-fault",
            why: "The provider's error echoes back a surrogate / placeholder value instead of anything shaped like a real credential. That means the request left with the connector's stand-in token still in it: the credential handoff layer — the step that swaps the placeholder for the stored key at send time — never engaged. The stored key itself was never tested by this call, so re-pasting it fixes nothing.",
            fixes: [
              "<strong>Do not re-paste the key.</strong> The provider never received it; this call says nothing about whether the stored key is good or bad.",
              "<strong>Confirm the credential is actually saved in the connector's secure setup</strong> (the vault entry exists and shows the expected tail characters) — the swap can only substitute a value that is stored.",
              "<strong>Re-run the failing call from the context where the connector's credential swap is active</strong> — some calling contexts (background tasks, a different agent surface) carry the placeholder but never perform the swap.",
              "<strong>Read the new error's echoed value.</strong> If it still echoes a placeholder-shaped value, the handoff layer is still not engaging in that context — move the call to a context where it does, or re-register the connector so its credential binding is rebuilt.",
              "<strong>Only blame the key itself once the echoed value changes</strong> to something shaped like the real credential — at that point the swap is engaging and any remaining failure is a different diagnosis."
            ]
          },
          2: {
            word: "No credential was attached to the request",
            tone: "d-fault",
            why: "The provider's error says, in its own words, that no key / token arrived with the request at all. This is not a bad key — it is a missing one. Either the connector sent the call without attaching its credential, or the call bypassed the connector entirely.",
            fixes: [
              "<strong>Check the connector has a credential saved at all</strong> — open its secure setup and confirm a value exists (length and tail characters), without copying it anywhere.",
              "<strong>Confirm the connector shows as connected</strong> and is the thing actually making the call — a raw hand-built HTTP request bypasses the connector and carries no credential with it.",
              "<strong>Re-save the credential through the connector's secure setup page</strong> if the saved entry is empty or was never completed, then retry.",
              "<strong>Retry a harmless read.</strong> If the error stops saying “missing” and changes character, the credential is now attached and any remaining failure is a different diagnosis."
            ]
          },
          3: {
            word: "Placement mismatch — the key was sent where the provider doesn't read",
            tone: "d-setup",
            why: "The evidence points to the credential arriving somewhere the provider never looks: providers read exactly one location (a specific header, a query parameter, the path), and a valid key in any other location reads to them as no key — or as an invalid one. The error text or your setup facts put the sent location and the expected location in different places.",
            fixes: [
              "<strong>Open the provider's own authentication docs and find the one location it names</strong> — the exact header name, query parameter, or path position. Do not infer it from another provider's habits.",
              "<strong>Set the connector's credential placement to exactly that location</strong>, including the exact custom header name if that is what the docs specify (header names are not interchangeable).",
              "<strong>Remove the credential from the old location</strong> if the connector lets both be set — a key sitting in two places masks which one the provider actually read.",
              "<strong>Retry a harmless read.</strong> A placement fix changes the error immediately: success, or a new error that is about the key itself rather than its delivery."
            ]
          },
          4: {
            word: "Provider host not registered for the connector's egress",
            tone: "d-setup",
            why: "The request never got a fair hearing: the provider's host was not on the connector's registered egress list (or the error shows the call dying at the host / DNS / egress layer). When egress registration is missing, calls fail before authentication is even evaluated — no credential, good or bad, can change the outcome.",
            fixes: [
              "<strong>Register the provider's exact API host</strong> in the connector's host / egress settings — scheme and host exactly as the API uses them (for example <code>https://api.provider.com</code>), with no path and no extra subdomain guesses.",
              "<strong>Check for the classic near-misses:</strong> live host vs sandbox host, regional hosts, and <code>api.</code> prefixes — the registered host must be the one the failing request actually used.",
              "<strong>Retry a harmless read.</strong> An egress failure disappears the moment the right host is registered; whatever error remains after that is the next real layer.",
              "<strong>If the host was already registered</strong> and the error persists, capture the failing request's full URL — the mismatch is between the URL actually called and the host actually registered."
            ]
          },
          5: {
            word: "Key accepted, but its scope / permissions are insufficient",
            tone: "d-setup",
            why: "This is the good-news failure: the credential arrived, was properly formed, and was accepted as genuine — the provider refused the <em>action</em>, not the key. A 403 with permission / scope language means the key's granted permissions don't cover the operation that was attempted (read-only keys attempting writes are the classic case).",
            fixes: [
              "<strong>Name the exact operation that failed</strong> and find, in the provider's docs, the permission or scope that operation requires.",
              "<strong>Open the key's settings in the provider's dashboard</strong> and compare its granted permissions against that requirement — restricted keys frequently default to read-only.",
              "<strong>Widen the key's permissions, or mint a key that carries the needed scope</strong>, and store the replacement through the connector's secure setup page. For OAuth 2.0, re-run the consent flow and confirm the granted scopes include the one the error named.",
              "<strong>Retry the same call.</strong> The credential delivery is already proven — if the retry still 403s, the scope change did not take effect on the key the connector is actually using."
            ]
          },
          6: {
            word: "Malformed credential — a masked stub was stored instead of the full key",
            tone: "d-fault",
            why: "The provider's error echoes back a masked value — a key-shaped stub with its middle replaced by an ellipsis or mask characters. That is the shape providers and dashboards <em>display</em>, never a shape that works. At setup time, someone copied the masked display value (from an email notification, a screenshot, or a settings list) instead of the full key from its one-time reveal, and the stub is what got stored.",
            fixes: [
              "<strong>Accept that the stored value is unrecoverable.</strong> A masked stub cannot be unmasked — the middle characters exist nowhere except the provider's one-time reveal, which has closed.",
              "<strong>Mint a fresh key in the provider's dashboard</strong> (revoke or delete the stub's key while you are there, so a useless credential isn't left live).",
              "<strong>This time, copy from the one-time reveal dialog only</strong> — tap Copy before closing it — and paste straight into the connector's secure setup page in the same motion. Never copy a key from an email, a screenshot, or a list view: those only ever carry the masked form.",
              "<strong>Verify by tail, then by call:</strong> the stored entry's last characters should match the new key's, and the retried call's error should no longer echo a masked value."
            ]
          },
          7: {
            word: "Provider account not activated — verification still pending",
            tone: "d-info",
            why: "The error's language is about the <em>account</em>, not the credential: activation, verification, or onboarding is incomplete on the provider's side. Until the provider finishes verifying the account, API access stays restricted no matter how correct the key and its delivery are.",
            fixes: [
              "<strong>Open the provider's dashboard and find the activation / verification banner</strong> — it names the exact step that is outstanding (identity, business details, payout information).",
              "<strong>Complete that step on the provider's own pages only.</strong> Identity and banking details go into the provider's forms, never into a chat, a document, or this page.",
              "<strong>Wait for the provider to mark the account active.</strong> Verification is the provider's clock, not yours — calls keep failing the same way until it clears.",
              "<strong>Retry a harmless read once the dashboard shows the account active.</strong> If it still fails, the activation was never the whole story and the new error is a fresh diagnosis."
            ]
          },
          8: {
            word: "Inconclusive — the pasted evidence doesn't isolate one cause",
            tone: "d-info",
            why: "Nothing in the pasted text carries one of the decisive signatures: no echoed placeholder, no masked stub, no missing-key wording, no host or egress language, no account-activation language, and no clear permission refusal. Rather than guess, here is the specific evidence that would separate the remaining causes.",
            fixes: []
          }
        };

        /* ---------------- analysis ---------------- */
        function analyze(text, facts) {
          var t = text;
          var low = t.toLowerCase();
          var evidence = [];
          var statusM = t.match(/\b([1-5]\d\d)\b/);
          var status = statusM ? parseInt(statusM[1], 10) : null;
          if (status) evidence.push({ tag: "Status", text: "HTTP " + status + " present in the pasted output." });

          /* --- 1 · placeholder / surrogate echoed --- */
          var ph = find(/hsurr\s*:[^\s"']*/i, t) ||
                   find(/\bsurrogate\b[^\n"]{0,40}/i, t) ||
                   find(/\bplaceholder\b[^\n"]{0,40}/i, t) ||
                   find(/\{\{[^}]{1,60}\}\}/, t) ||
                   find(/\b(REPLACE_ME|YOUR[_ ]?API[_ ]?KEY|INSERT[_ ]?KEY[_ ]?HERE|CHANGE[_ ]?ME|XXX+)\b/i, t) ||
                   find(/<[a-z_ ]{0,20}(api[_ ]?key|token|key)[a-z_ ]{0,20}>/i, t);
          if (ph) {
            evidence.push({ tag: "Echo", text: "The error echoes a placeholder-shaped value: “" + snippet(t, ph) + "” — no real credential looks like that." });
            return { id: 1, evidence: evidence };
          }

          /* --- 6 · masked / truncated credential echoed --- */
          var masked = find(/[A-Za-z0-9][A-Za-z0-9_\-]{1,}(?:\.\.\.|…|\. \. \.)[A-Za-z0-9_\-]{2,}/, t) ||
                       find(/[A-Za-z0-9_\-]{2,}(?:\*{3,}|•{3,}|●{3,})[A-Za-z0-9_\-]{0,}/, t);
          if (masked) {
            evidence.push({ tag: "Echo", text: "The error echoes a masked value — “" + snippet(t, masked) + "” — the display shape of a key, with its middle removed. That shape can only have arrived if the masked stub itself was stored." });
            return { id: 6, evidence: evidence };
          }
          var malformed = find(/\b(malformed|truncated|invalid format|not a valid (api[- ]?key|token) format)\b/i, t);
          if (malformed && /(key|token|credential)/i.test(t)) {
            evidence.push({ tag: "Wording", text: "The provider calls the credential itself “" + malformed + "” — a shape problem in the stored value, not a delivery or permission problem." });
            return { id: 6, evidence: evidence };
          }

          /* --- 4 · host not registered / egress --- */
          var hostHit = find(/host[^\n"]{0,50}(not (registered|allowed|permitted|whitelisted)|isn'?t (registered|allowed))/i, t) ||
                        find(/(domain|hostname)[^\n"]{0,40}(not (allowed|registered)|blocked|denied)/i, t) ||
                        find(/egress[^\n"]{0,50}(blocked|denied|not (registered|allowed|configured)|refused)/i, t) ||
                        find(/not (in|on) the (allowlist|whitelist|egress list)/i, t) ||
                        find(/ENOTFOUND|getaddrinfo|could not resolve host|name or service not known/i, t);
          if (hostHit) {
            evidence.push({ tag: "Wording", text: "Host / egress language in the error: “" + snippet(t, hostHit) + "”." });
            return { id: 4, evidence: evidence };
          }
          if (facts.host === "no") {
            evidence.push({ tag: "Setup fact", text: "You recorded that the provider's host was never registered for this connector — calls fail at egress before authentication is evaluated, whatever the error text says." });
            return { id: 4, evidence: evidence };
          }

          /* --- 7 · account not activated / verification pending --- */
          var actHit = find(/account[^\n"]{0,50}(not (activated|verified|complete|enabled)|pending|inactive|restricted)/i, t) ||
                       find(/verification[^\n"]{0,40}(pending|required|incomplete|needed)/i, t) ||
                       find(/pending verification/i, t) ||
                       find(/(complete|finish)[^\n"]{0,40}(onboarding|verification|account setup|your account)/i, t) ||
                       find(/identity verification/i, t) ||
                       find(/charges?[^\n"]{0,30}not (yet )?(enabled|active)/i, t);
          if (actHit) {
            evidence.push({ tag: "Wording", text: "Account-activation language in the error: “" + snippet(t, actHit) + "”." });
            return { id: 7, evidence: evidence };
          }

          /* --- 2 · no credential attached --- */
          var missHit = find(/missing (an? )?(api[- ]?key|access token|token|credentials?|authentication|authorization)/i, t) ||
                        find(/(api[- ]?key|access token|token|credentials?|authorization header)[^\n"]{0,30}(is )?(required|missing|not provided|absent|not set)/i, t) ||
                        find(/no (api[- ]?key|auth(entication|orization)? (header|token|credentials?)?|credentials?) (was )?(provided|sent|found|attached)/i, t) ||
                        find(/authorization header[^\n"]{0,30}(missing|absent|not (set|provided))/i, t) ||
                        find(/authentication (is )?required/i, t) ||
                        find(/please provide (an? )?(api[- ]?key|access token|token)/i, t);
          if (missHit) {
            evidence.push({ tag: "Wording", text: "The provider states the credential never arrived: “" + snippet(t, missHit) + "”." });
            if (facts.connected === "no") {
              evidence.push({ tag: "Setup fact", text: "The connector also shows as not connected — consistent with a call going out with nothing attached." });
            }
            return { id: 2, evidence: evidence };
          }

          /* --- 3 · placement mismatch --- */
          var expectedLoc = null, expectedHit = null;
          var hHit = find(/(in|as|via|using) (the |a |an )?[^\n"]{0,30}header/i, t) || find(/authorization header/i, t) || find(/x-[a-z\-]*key[^\n"]{0,20}header/i, t);
          var qHit = find(/(in|as) (the |a )?query (string|parameter|param)/i, t);
          var pHit = find(/(in|as part of) (the )?url path/i, t) || find(/path parameter/i, t);
          if (hHit && /(must|should|expected|provide|send|use)/i.test(t)) { expectedLoc = "header"; expectedHit = hHit; }
          else if (qHit && /(must|should|expected|provide|send|use)/i.test(t)) { expectedLoc = "query"; expectedHit = qHit; }
          else if (pHit && /(must|should|expected|provide|send|use)/i.test(t)) { expectedLoc = "path"; expectedHit = pHit; }
          var sentLoc = null;
          if (facts.placement === "bearer" || facts.placement === "custom_header") sentLoc = "header";
          else if (facts.placement === "query") sentLoc = "query";
          else if (facts.placement === "path") sentLoc = "path";
          var explicitPlace = find(/(wrong|incorrect) (location|placement|parameter location)/i, t) ||
                              find(/not accepted in (the )?(query|header|path)/i, t) ||
                              find(/key (was )?sent (in|as)[^\n"]{0,30}(wrong|incorrect)/i, t);
          if (explicitPlace) {
            evidence.push({ tag: "Wording", text: "The provider names a placement problem directly: “" + snippet(t, explicitPlace) + "”." });
            return { id: 3, evidence: evidence };
          }
          if (expectedLoc && sentLoc && expectedLoc !== sentLoc) {
            evidence.push({ tag: "Mismatch", text: "The error points at the " + expectedLoc + " (“" + snippet(t, expectedHit) + "”), but your setup facts say the connector sends the credential in the " + (sentLoc === "header" ? "header" : sentLoc === "query" ? "query string" : "URL path") + "." });
            return { id: 3, evidence: evidence };
          }

          /* --- 5 · scope / permissions insufficient --- */
          var scopeHit = find(/insufficient[_ ](scope|permissions?|privileges?)/i, t) ||
                         find(/(permission|scope|privilege)[^\n"]{0,40}(denied|insufficient|required|missing|not granted)/i, t) ||
                         find(/not authorized to[^\n"]{0,50}/i, t) ||
                         find(/does not have permission[^\n"]{0,50}/i, t) ||
                         find(/access denied/i, t);
          if (scopeHit && (status === 403 || /scope|permission/i.test(t))) {
            evidence.push({ tag: "Wording", text: "Permission / scope language in the error: “" + snippet(t, scopeHit) + "” — the refusal is about the action, not the credential's delivery." });
            if (status === 403) evidence.push({ tag: "Status", text: "A 403 (not 401) fits an accepted credential being refused for this operation." });
            return { id: 5, evidence: evidence };
          }

          /* --- 8 · inconclusive, with targeted evidence to gather --- */
          var gather = [];
          if (!status) gather.push("<strong>The full HTTP status code.</strong> 401 vs 403 alone separates “credential problem” from “permission problem” — re-capture the response with its status line.");
          if (facts.placement === "unknown") gather.push("<strong>Where the connector sends the credential</strong> (header, query, path). Set it in the facts above — a placement mismatch cannot be ruled in or out without it.");
          if (facts.host === "unknown") gather.push("<strong>Whether the provider's host is registered</strong> for the connector's egress. An unregistered host outranks every credential theory.");
          if (facts.connected === "no") gather.push("<strong>A connector that shows as connected.</strong> Right now it shows not connected — restore the connection first, then re-capture the error; this error may be a symptom, not the cause.");
          gather.push("<strong>The exact value the provider echoed back</strong>, if any. Its shape is decisive: placeholder-shaped points at the handoff layer never swapping, an ellipsis-masked shape (<code>rk_live_...Xk8c</code>) means a masked stub was stored, and the real key's tail means delivery worked and the key or its scopes are the problem.");
          gather.push("<strong>The provider's authentication docs line</strong> stating where the key goes and what scope the failed operation needs — it arbitrates every remaining theory.");
          gather.push("<strong>A retry of a harmless read</strong> (list / get / status) with the same connector, error captured in full — write-operation errors mix permission and payload problems that a read separates.");
          return { id: 8, evidence: evidence, gather: gather };
        }

        /* ---------------- rendering ---------------- */
        function esc(s) {
          return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
        }
  return { "analyze": (typeof analyze !== 'undefined' ? analyze : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLES": (typeof EXAMPLES !== 'undefined' ? EXAMPLES : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["analyze"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-connector-credential-egress-verifier',
  name: 'J-Dawgs Connector Credential & Egress Verifier',
  description: 'Paste a failed connector or API call\'s error output plus its setup facts; get the failure classified — placeholder token unswapped, missing credential, placement mismatch, unregistered host, insufficient key scope, malformed or masked credential, account not activated — with a fix checklist and a fi',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["analyze"]) return { ok: false, output: null, summary: 'Extracted core has no analyze function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLES": __core["EXAMPLES"] }
};
