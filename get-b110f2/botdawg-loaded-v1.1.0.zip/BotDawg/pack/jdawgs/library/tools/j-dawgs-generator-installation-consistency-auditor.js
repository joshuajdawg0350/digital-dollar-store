'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Generator Installation Estimate, Work Record & Final Invoice Consistency Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";
/* ---------- Examples ---------- */
var EXAMPLE_BAD = {
estimate:
"GENERATOR INSTALLATION ESTIMATE \u2014 APPROVED\n" +
"Generator: Generac Guardian 24 kW, Model 7210 \u2014 $8,200.00\n" +
"Transfer switch: 200A automatic transfer switch \u2014 $1,150.00\n" +
"Concrete pad \u2014 $425.00\n" +
"Battery \u2014 $289.00\n" +
"Labor: $95.00 per hour, estimated 12 hours \u2014 $1,140.00\n" +
"Permit fee \u2014 $350.00\n" +
"Estimate total: $11,554.00\n" +
"Deposit paid by customer: $2,000.00",
work:
"INSTALLER WORK RECORD\n" +
"Generator installed: Generac Guardian 22 kW, Model 7043\n" +
"Transfer switch installed: 100A automatic transfer switch\n" +
"Hours worked: 10 hours\n" +
"Parts installed: concrete pad\n" +
"Permit obtained: yes",
invoice:
"FINAL INVOICE\n" +
"Generator: Generac Guardian 24 kW, Model 7210 \u2014 $8,200.00\n" +
"Transfer switch: 200A \u2014 $1,150.00\n" +
"Concrete pad \u2014 $425.00\n" +
"Battery \u2014 $289.00\n" +
"Labor \u2014 $1,425.00\n" +
"Permit fee \u2014 $350.00\n" +
"Inspection fee \u2014 $350.00\n" +
"Expedited scheduling fee \u2014 $499.00\n" +
"Invoice total: $12,688.00"
};
var EXAMPLE_GOOD = {
estimate:
"GENERATOR INSTALLATION ESTIMATE \u2014 APPROVED\n" +
"Generator: Generac Guardian 24 kW, Model 7210 \u2014 $8,200.00\n" +
"Transfer switch: 200A automatic transfer switch \u2014 $1,150.00\n" +
"Concrete pad \u2014 $425.00\n" +
"Battery \u2014 $289.00\n" +
"Labor: $95.00 per hour, estimated 10 hours \u2014 $950.00\n" +
"Permit fee \u2014 $350.00\n" +
"Estimate total: $11,364.00\n" +
"Deposit paid by customer: $2,000.00",
work:
"INSTALLER WORK RECORD\n" +
"Generator installed: Generac Guardian 24 kW, Model 7210\n" +
"Transfer switch installed: 200A automatic transfer switch\n" +
"Hours worked: 10 hours\n" +
"Parts installed: concrete pad, battery\n" +
"Permit obtained: yes",
invoice:
"FINAL INVOICE\n" +
"Generator: Generac Guardian 24 kW, Model 7210 \u2014 $8,200.00\n" +
"Transfer switch: 200A \u2014 $1,150.00\n" +
"Concrete pad \u2014 $425.00\n" +
"Battery \u2014 $289.00\n" +
"Labor \u2014 $950.00\n" +
"Permit fee \u2014 $350.00\n" +
"Deposit credit \u2014 -$2,000.00\n" +
"Invoice total: $9,364.00"
};

/* ---------- Parsing helpers ---------- */
function money(n){ return "$" + n.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ","); }
function parseAmt(s){ return parseFloat(String(s).replace(/,/g,"")); }
function linesOf(t){ return String(t||"").split(/\n/).map(function(x){return x.trim();}).filter(Boolean); }
function firstMoneyIn(line){
  var m = line.match(/-?\$\s*([\d,]+\.\d{2}|[\d,]+)/);
  return m ? parseAmt(m[1]) * (line.match(/-\s*\$/)? -1 : 1) : null;
}
/* Line items: lines containing a $ amount, excluding total/subtotal/estimate-total lines */
function lineItems(text){
  var out=[];
  linesOf(text).forEach(function(ln){
    if(/total/i.test(ln)) return;
    var a=firstMoneyIn(ln);
    if(a===null) return;
    out.push({label: ln.replace(/[\u2014\-:]?\s*-?\$.*$/,"").trim() || ln, raw: ln, amount: a});
  });
  return out;
}
function statedTotal(text){
  var found=null;
  linesOf(text).forEach(function(ln){
    if(/total/i.test(ln)){ var a=firstMoneyIn(ln); if(a!==null) found=a; }
  });
  return found;
}
function kwNear(text){
  var m=String(text||"").match(/(\d+(?:\.\d+)?)\s*kW/i);
  return m?parseFloat(m[1]):null;
}
function modelNear(text){
  var m=String(text||"").match(/model[:\s#]*([A-Za-z0-9\-]{3,})/i);
  return m?m[1].toUpperCase():null;
}
function ampsNear(text){
  var ls=linesOf(text), i, m;
  for(i=0;i<ls.length;i++){ if(/transfer/i.test(ls[i])){ m=ls[i].match(/(\d+)\s*A\b/i); if(m) return parseInt(m[1],10); } }
  m=String(text||"").match(/(\d+)\s*A\b[^.\n]*transfer/i);
  return m?parseInt(m[1],10):null;
}
function laborRate(text){
  var m=String(text||"").match(/\$\s*([\d,]+\.?\d*)\s*(?:per|\/)\s*(?:hour|hr)/i);
  return m?parseAmt(m[1]):null;
}
function hoursIn(text){
  var m=String(text||"").match(/(\d+(?:\.\d+)?)\s*(?:hours|hrs)\b/i);
  return m?parseFloat(m[1]):null;
}
function amountOnLines(text, re){
  var sum=0, found=[];
  linesOf(text).forEach(function(ln){ if(re.test(ln)){ var a=firstMoneyIn(ln); if(a!==null){ sum+=a; found.push({label:ln, amount:a}); } } });
  return {sum:sum, lines:found};
}
function normWords(s){
  return String(s||"").toLowerCase().replace(/[^a-z0-9 ]/g," ").split(/\s+/).filter(function(w){return w.length>3 && ["generator","generac","guardian","final","invoice","estimate","approved","automatic","switch","model"].indexOf(w)<0;});
}

/* ---------- The auditor ---------- */
function audit(est, work, inv){
  var docs={estimate: !!(est&&est.trim().length>10), work: !!(work&&work.trim().length>10), invoice: !!(inv&&inv.trim().length>10)};
  var present=(docs.estimate?1:0)+(docs.work?1:0)+(docs.invoice?1:0);
  var missing=[]; if(!docs.estimate)missing.push("approved installation estimate"); if(!docs.work)missing.push("installer's work record"); if(!docs.invoice)missing.push("final invoice");
  var checks=[];
  function add(id,title,status,severity,detail,math){ checks.push({id:id,title:title,status:status,severity:severity,detail:detail,math:math}); }

  if(present<=1){
    add("docs","Documents present","flag","severe",
      present===0 ? "No documents pasted. Nothing can be compared." : "Only one document pasted. A single document can only be graded in isolation \u2014 the cross-check this tool exists for needs at least two, and a full check needs all three.",
      "Documents present: "+present+" of 3. Missing: "+missing.join(", ")+".");
    return finish(docs,present,missing,checks);
  }

  /* 1. Generator identity */
  (function(){
    var bKw=kwNear(inv||est), iKw=kwNear(work), bM=modelNear(inv||est), iM=modelNear(work);
    if(!docs.work || (!docs.invoice && !docs.estimate)){ add("generator","Generator model / kW: billed vs installed","skip","none","Needs the work record plus the estimate or invoice to compare.",""); return; }
    if(bKw===null||iKw===null||bM===null||iM===null){ add("generator","Generator model / kW: billed vs installed","warn","minor","One side does not state a model number or kW rating in a form the tool can read, so identity could not be fully confirmed. Ask the installer to confirm the installed unit's model and serial in writing.","Billed: "+(bKw===null?"kW not found":bKw+" kW")+", Model "+(bM||"not found")+". Installed (work record): "+(iKw===null?"kW not found":iKw+" kW")+", Model "+(iM||"not found")+"."); return; }
    var same=(bKw===iKw && bM===iM);
    add("generator","Generator model / kW: billed vs installed", same?"pass":"flag", same?"none":"severe",
      same ? "The billed generator matches the installed generator on both kW and model." : "IDENTITY MISMATCH: the generator billed is not the generator the work record says was installed. A smaller or different unit may have been fitted while the larger unit was billed \u2014 or the paperwork may simply be wrong. Either way, resolve it before paying.",
      "Billed: "+bKw+" kW, Model "+bM+".\nInstalled per work record: "+iKw+" kW, Model "+iM+".\nDifference: "+(bKw-iKw)+" kW; model match: "+(bM===iM?"yes":"NO")+".");
  })();

  /* 2. Transfer switch */
  (function(){
    var bA=ampsNear(inv||est), rA=ampsNear(work);
    if(!docs.work || (!docs.invoice && !docs.estimate)){ add("transfer","Transfer switch: billed vs recorded","skip","none","Needs the work record plus the estimate or invoice.",""); return; }
    if(bA===null||rA===null){ add("transfer","Transfer switch: billed vs recorded","warn","minor","An amp rating for the transfer switch could not be read on one side. Ask for the fitted switch's rating in writing.","Billed: "+(bA===null?"not found":bA+"A")+". Recorded: "+(rA===null?"not found":rA+"A")+"."); return; }
    var same=bA===rA;
    add("transfer","Transfer switch: billed vs recorded", same?"pass":"flag", same?"none":"severe",
      same?"The billed transfer switch rating matches the recorded fitted switch.":"MISMATCH: the billed transfer-switch rating differs from the rating the work record says was fitted.",
      "Billed: "+bA+"A. Recorded installed: "+rA+"A. Difference: "+(bA-rA)+"A.");
  })();

  /* 3. Labor */
  (function(){
    var rate=laborRate(est), hrs=hoursIn(work);
    var lab=amountOnLines(inv,/labor/i);
    if(!docs.estimate||!docs.work||!docs.invoice){ add("labor","Labor: billed vs recorded hours \u00D7 estimate rate","skip","none","Needs all three: the rate from the estimate, the hours from the work record, and the billed amount from the invoice.","Rate: "+(rate===null?"not found":money(rate)+"/hr")+"; recorded hours: "+(hrs===null?"not found":hrs)+"; labor billed: "+(lab.lines.length?money(lab.sum):"not found")+"."); return; }
    if(rate===null||hrs===null||!lab.lines.length){ add("labor","Labor: billed vs recorded hours \u00D7 estimate rate","warn","minor","Labor could not be fully priced: the estimate rate, the recorded hours, or the billed labor line was not found. Ask for the rate, hours, and billed labor in writing.","Rate: "+(rate===null?"not found":money(rate)+"/hr")+"; recorded hours: "+(hrs===null?"not found":hrs)+"; labor billed: "+(lab.lines.length?money(lab.sum):"not found")+"."); return; }
    var expected=hrs*rate, over=lab.sum-expected;
    var bad=over>1;
    add("labor","Labor: billed vs recorded hours \u00D7 estimate rate", bad?"flag":"pass", bad?(over>250?"severe":"minor"):"none",
      bad?("Labor billed is "+money(over)+" above recorded hours at the estimate's own rate. Ask which extra hours were worked, when, and why they are not on the work record."):"Labor billed does not exceed recorded hours at the estimate's rate.",
      "Recorded hours: "+hrs+" \u00D7 estimate rate "+money(rate)+"/hr = "+money(expected)+" expected.\nLabor billed on invoice: "+money(lab.sum)+".\nDifference: "+money(lab.sum)+" \u2212 "+money(expected)+" = "+money(over)+(bad?" over.":" (not over)."));
  })();

  /* 4. Permit / inspection double charge */
  (function(){
    if(!docs.invoice){ add("permit","Permit / inspection fee charged twice","skip","none","Needs the final invoice.",""); return; }
    var p=amountOnLines(inv,/permit|inspection/i);
    var permitLines=p.lines.filter(function(x){return /permit/i.test(x.label);});
    var inspLines=p.lines.filter(function(x){return /inspection/i.test(x.label);});
    var dup = p.lines.length>=2 && p.sum>0;
    add("permit","Permit / inspection fee charged twice", dup?"flag":"pass", dup?"minor":"none",
      dup?("The invoice carries "+p.lines.length+" permit/inspection lines totalling "+money(p.sum)+". Some jurisdictions genuinely charge both a permit and a separate inspection fee \u2014 and some invoices bill the same fee twice under two names. Ask for the actual permit receipt amounts."):"Only one permit/inspection charge (or none) appears on the invoice.",
      p.lines.length? p.lines.map(function(x){return x.label+" \u2192 "+money(x.amount);}).join("\n")+"\nPermit lines: "+permitLines.length+"; inspection lines: "+inspLines.length+"; combined: "+money(p.sum)+"." : "No permit or inspection line found on the invoice.");
  })();

  /* 5. Deposit credit */
  (function(){
    var dep=amountOnLines(est,/deposit/i);
    var cred=amountOnLines(inv,/deposit/i);
    var depPaid=dep.lines.length?Math.abs(dep.sum):0;
    var depCredited=cred.lines.length?Math.abs(cred.sum):0;
    if(!docs.estimate||!docs.invoice){ add("deposit","Deposit paid credited on the invoice","skip","none","Needs the estimate (deposit paid) and the invoice (deposit credit).","Deposit on estimate: "+(dep.lines.length?money(depPaid):"not found")+"; credit on invoice: "+(cred.lines.length?money(depCredited):"not found")+"."); return; }
    if(!dep.lines.length){ add("deposit","Deposit paid credited on the invoice","pass","none","No deposit is shown on the estimate, so no credit is owed on the invoice.","Deposit on estimate: $0.00 found."); return; }
    var short=depPaid-depCredited;
    var bad=short>1;
    add("deposit","Deposit paid credited on the invoice", bad?"flag":"pass", bad?"severe":"none",
      bad?("The estimate shows a "+money(depPaid)+" deposit paid, but the invoice credits only "+money(depCredited)+" of it. "+money(short)+" of money already paid is missing from the bill."):"The deposit shown on the estimate is fully credited on the invoice.",
      "Deposit paid (estimate): "+money(depPaid)+".\nDeposit credited (invoice): "+money(depCredited)+".\nShortfall: "+money(depPaid)+" \u2212 "+money(depCredited)+" = "+money(short)+".");
  })();

  /* 6 & 7. Parts billed-not-installed + invoice-only charges */
  (function(){
    if(!docs.invoice){ add("parts","Parts billed that the work record never records as installed","skip","none","Needs the invoice (and the work record for a full check).",""); add("invoiceonly","Invoice-only charges (in neither other document)","skip","none","Needs the invoice.",""); return; }
    var items=lineItems(inv).filter(function(it){
      return !/generator|transfer|labor|permit|inspection|deposit|tax/i.test(it.label) && it.amount>0;
    });
    var workText=String(work||"").toLowerCase(), estText=String(est||"").toLowerCase();
    var notInstalled=[], onlyInvoice=[];
    items.forEach(function(it){
      var words=normWords(it.label);
      var inWork = words.length && words.some(function(w){return workText.indexOf(w)>=0;});
      var inEst = words.length && words.some(function(w){return estText.indexOf(w)>=0;});
      if(docs.work && !inWork) notInstalled.push(it);
      if(!inWork && !inEst) onlyInvoice.push(it);
    });
    if(!docs.work){ add("parts","Parts billed that the work record never records as installed","skip","none","No work record pasted, so billed parts cannot be checked against installed parts.","Billed part lines checked: "+items.length+"."); }
    else{
      var badP=notInstalled.length>0;
      add("parts","Parts billed that the work record never records as installed", badP?"flag":"pass", badP?"minor":"none",
        badP?("Billed but never recorded as installed: "+notInstalled.map(function(x){return x.label+" ("+money(x.amount)+")";}).join("; ")+". The part may have been fitted and simply not written down \u2014 ask for it to be confirmed in writing."):"Every billed part line has a matching mention in the work record.",
        "Billed part lines: "+items.length+". Not found in work record: "+notInstalled.length+(notInstalled.length?" \u2192 "+notInstalled.map(function(x){return x.label+" "+money(x.amount);}).join("; "):"")+".");
    }
    var badO=onlyInvoice.length>0;
    add("invoiceonly","Invoice-only charges (in neither other document)", badO?"flag":"pass", badO?"minor":"none",
      badO?("These charges appear only on the invoice \u2014 in neither the approved estimate nor the work record: "+onlyInvoice.map(function(x){return x.label+" ("+money(x.amount)+")";}).join("; ")+". A charge you never approved and nobody recorded doing needs an explanation before it is paid."):"No invoice line is unique to the invoice; every billed line traces back to the estimate or the work record.",
      "Invoice-only lines: "+onlyInvoice.length+(onlyInvoice.length?" \u2192 "+onlyInvoice.map(function(x){return x.label+" "+money(x.amount)+"; total "+money(onlyInvoice.reduce(function(s,x){return s+x.amount;},0));}).join(""):"")+".");
  })();

  /* 8. Invoice math */
  (function(){
    if(!docs.invoice){ add("math","Invoice line items sum to its stated total","skip","none","Needs the final invoice.",""); return; }
    var items=lineItems(inv), total=statedTotal(inv);
    if(total===null){ add("math","Invoice line items sum to its stated total","warn","minor","No stated total was found on the invoice, so its arithmetic cannot be checked. Ask for a totalled invoice.","Line items found: "+items.length+"; sum: "+money(items.reduce(function(s,x){return s+x.amount;},0))+"."); return; }
    var sum=items.reduce(function(s,x){return s+x.amount;},0);
    var diff=sum-total;
    var bad=Math.abs(diff)>1;
    add("math","Invoice line items sum to its stated total", bad?"flag":"pass", bad?"severe":"none",
      bad?("The invoice's own numbers do not add up: its line items sum to "+money(sum)+" but it states a total of "+money(total)+", a "+money(Math.abs(diff))+" difference. Do not pay a total the invoice itself cannot support."):"The invoice's line items sum exactly to its stated total (within $1 rounding).",
      items.map(function(x){return x.label+" \u2192 "+money(x.amount);}).join("\n")+"\nSum of line items: "+money(sum)+".\nStated total: "+money(total)+".\nDifference: "+money(sum)+" \u2212 "+money(total)+" = "+money(diff)+".");
  })();

  return finish(docs,present,missing,checks);
}
function finish(docs,present,missing,checks){
  var severe=checks.filter(function(c){return c.status==="flag"&&c.severity==="severe";}).length;
  var anyFlag=checks.filter(function(c){return c.status==="flag";}).length;
  var anyWarn=checks.filter(function(c){return c.status==="warn";}).length;
  var verdict, why;
  if(present<=1){ verdict="NOT ENOUGH TO COMPARE"; why="Only "+present+" of 3 documents pasted. Missing: "+missing.join(", ")+". A cross-check needs at least two documents; a full check needs all three."; }
  else if(severe>0){ verdict="DO NOT PAY YET"; why=severe+" serious mismatch"+(severe>1?"es":"")+" found. Resolve the flagged items in writing before paying."+(present===2?" Note: the "+missing[0]+" is also missing, so this check is incomplete.":""); }
  else if(present===2){ verdict="PAY WITH FIXES"; why="Only two of three documents pasted \u2014 the missing "+missing[0]+" caps this verdict at PAY WITH FIXES no matter how clean the rest looks. Paste it for a full check."+(anyFlag?" "+anyFlag+" flagged item(s) also need answers.":""); }
  else if(anyFlag>0||anyWarn>0){ verdict="PAY WITH FIXES"; why=anyFlag+" flagged item(s)"+(anyWarn?" and "+anyWarn+" item(s) that could not be fully read":"")+" need answers or corrections in writing, then pay."; }
  else { verdict="SAFE TO PAY"; why="All three documents agree on every check this tool runs: same generator, same transfer switch, labor within recorded hours at the estimate rate, no duplicate permit/inspection fee, deposit fully credited, every billed part recorded as installed, no invoice-only charges, and the invoice adds up. Still confirm the physical installation separately \u2014 this tool checks text only."; }
  return {verdict:verdict, why:why, documentsPresent:present, missing:missing, checks:checks,
    counts:{flags:anyFlag, severe:severe, warnings:anyWarn, passes:checks.filter(function(c){return c.status==="pass";}).length}};
}

/* ---------- Rendering ---------- */
var lastResult=null;
function esc(s){ return String(s||"").replace(/&/g,"&amp;").replace(/</g,"&lt;"); }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_BAD": (typeof EXAMPLE_BAD !== 'undefined' ? EXAMPLE_BAD : undefined), "EXAMPLE_GOOD": (typeof EXAMPLE_GOOD !== 'undefined' ? EXAMPLE_GOOD : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-generator-installation-consistency-auditor',
  name: 'J-Dawgs Generator Installation Estimate, Work Record & Final Invoice Consistency Auditor',
  description: 'holding a generator installation estimate, its work record, and a final invoice',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_BAD": __core["EXAMPLE_BAD"], "EXAMPLE_GOOD": __core["EXAMPLE_GOOD"] }
};
