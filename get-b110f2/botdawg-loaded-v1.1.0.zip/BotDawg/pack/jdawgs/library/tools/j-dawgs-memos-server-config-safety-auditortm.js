'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Memos Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ================= Examples (single source of truth) ================= */
      var RISKY_LINES = [
        "# Memos server config - production (copied from the dev laptop)",
        "MEMOS_MODE=dev",
        "MEMOS_ADDR=0.0.0.0",
        "MEMOS_PORT=5230",
        "MEMOS_DATA=/var/lib/memos",
        "MEMOS_DRIVER=postgres",
        "MEMOS_DSN=postgres://memos:Sup3rSecretPW@db.internal:5432/memos",
        "MEMOS_INSTANCE_URL=http://memos.example.com",
        "MEMOS_DEBUG=true"
      ];
      var HARDENED_LINES = [
        "# Memos server config - production, hardened",
        "MEMOS_MODE=prod",
        "MEMOS_ADDR=127.0.0.1",
        "MEMOS_PORT=5230",
        "MEMOS_DATA=/var/lib/memos",
        "MEMOS_DRIVER=postgres",
        "MEMOS_DSN=postgres://memos@db.internal:5432/memos?sslmode=require",
        "MEMOS_INSTANCE_URL=https://memos.example.com",
        "MEMOS_DEBUG=false"
      ];
      var RISKY = RISKY_LINES.join("\n");
      var HARDENED = HARDENED_LINES.join("\n");

      var PITCHES = {
        "pitch-tool": "J-Dawgs Memos Server Config Safety Auditor \u2014 paste a self-hosted Memos config and get one deploy verdict with line-numbered findings, secrets reported by length only, fully offline. Get it at the J-Dawgs AI Tool Store: https://muse.ai/s/ai-tool-store-xng6xkxwjkxl2xab/UoF72OkKI7j33Q2ITxmrZyIr4nv40QtYfj2AgESh_k8",
        "pitch-exchange": "J-Dawgs Agent Exchange \u2014 where agents list, find, and hand off working tools and services built for agent buyers: https://muse.ai/s/j-dawgs-agent-exchange-ih6xlnihzxdhxc/ZbleqxFHRE0NcswaBkyN13y9lLp5rPAgHTb6t8ii-PY",
        "pitch-bundle": "Serve It, Sync It, Ship It Right Stack \u2014 Joplin Server Config Safety Auditor + Memos Server Config Safety Auditor + Podcast Episode Consistency Auditor: grade the sync server, grade the notes server, prove the episode matches its brief."
      };

      /* ================= Parsing ================= */
      var FLAG_MAP = {
        "mode": "MEMOS_MODE",
        "addr": "MEMOS_ADDR",
        "port": "MEMOS_PORT",
        "data": "MEMOS_DATA",
        "dsn": "MEMOS_DSN",
        "driver": "MEMOS_DRIVER",
        "instance-url": "MEMOS_INSTANCE_URL",
        "debug": "MEMOS_DEBUG"
      };

      function cleanVal(v){
        v = String(v).trim();
        if (v.length >= 2 && ((v.charAt(0) === '"' && v.charAt(v.length-1) === '"') || (v.charAt(0) === "'" && v.charAt(v.length-1) === "'"))) {
          v = v.slice(1, -1);
        } else {
          var hashIdx = v.indexOf(" #");
          if (hashIdx > -1) v = v.slice(0, hashIdx);
          v = v.replace(/,\s*$/, "").trim();
        }
        return v;
      }

      function parseConfig(text){
        var entries = [];
        var lines = String(text).split(/\r?\n/);
        for (var i = 0; i < lines.length; i++){
          var lineNo = i + 1;
          var raw = lines[i];
          var line = raw.trim();
          if (!line || line.charAt(0) === "#") continue;
          var work = line;
          if (work.indexOf("- ") === 0) work = work.slice(2).trim();

          var m = work.match(/^(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/);
          if (m) {
            entries.push({ key: m[1].toUpperCase(), value: cleanVal(m[2]), line: lineNo });
          } else {
            var ym = work.match(/^([A-Za-z_][A-Za-z0-9_]*)\s*:\s+(.+)$/);
            if (ym && ym[2].indexOf("//") !== 0) {
              entries.push({ key: ym[1].toUpperCase(), value: cleanVal(ym[2]), line: lineNo });
            }
          }

          var flagRe = /--([a-z][a-z0-9-]*)(?:=|\s+)?("[^"]*"|'[^']*'|[^\s]+)?/gi;
          var fm;
          while ((fm = flagRe.exec(raw)) !== null) {
            var fname = fm[1].toLowerCase();
            if (FLAG_MAP[fname]) {
              entries.push({
                key: FLAG_MAP[fname],
                value: fm[2] !== undefined ? cleanVal(fm[2]) : "true",
                line: lineNo
              });
            }
          }
        }
        return entries;
      }

      /* ================= Checks ================= */
      function isTruthy(v){
        var s = String(v).toLowerCase();
        return s === "true" || s === "1" || s === "yes" || s === "on";
      }
      function isPlaceholder(v){
        var s = String(v).trim();
        return s === "" || s.charAt(0) === "$" || s === "***" || s.toLowerCase() === "redacted";
      }
      function dsnPassword(dsn){
        var s = String(dsn);
        var m = s.match(/^[a-z][a-z0-9+.-]*:\/\/[^/@\s]*:([^@\s]+)@/i);
        if (m) return m[1];
        if (s.indexOf("://") === -1) {
          m = s.match(/^[^:\s]+:([^@\s]+)@/);
          if (m) return m[1];
        }
        m = s.match(/(?:password|passwd|pwd)\s*=\s*([^\s;]+)/i);
        if (m) return m[1];
        return null;
      }

      function audit(text){
        var entries = parseConfig(text);
        var byKey = {};
        entries.forEach(function(e){
          (byKey[e.key] = byKey[e.key] || []).push(e);
        });
        var memosCount = entries.filter(function(e){ return e.key.indexOf("MEMOS_") === 0; }).length;
        if (memosCount === 0) {
          return {
            verdict: "NOT ENOUGH TO GRADE",
            reason: "No recognizable Memos settings (MEMOS_* keys or memos flags) were found in the pasted text, so there is nothing to grade.",
            findings: [],
            settingsFound: 0
          };
        }

        var findings = [];
        function add(severity, line, key, check, title, message, fix, secretLength){
          var f = { severity: severity, line: line, key: key, check: check, title: title, message: message, fix: fix };
          if (secretLength !== undefined && secretLength !== null) f.secretLength = secretLength;
          findings.push(f);
        }

        /* --- MEMOS_MODE --- */
        var modes = byKey["MEMOS_MODE"] || [];
        if (modes.length === 0) {
          add("MEDIUM", null, "MEMOS_MODE", "missing-production-mode",
            "Production mode is not set",
            "No MEMOS_MODE setting was found, so there is no proof the server will run in production mode \u2014 an unset mode silently falls back to defaults.",
            "Add MEMOS_MODE=prod to the config before deploying.");
        } else {
          modes.forEach(function(e){
            var v = e.value.toLowerCase();
            if (v === "dev" || v === "demo" || v === "development") {
              add("CRITICAL", e.line, "MEMOS_MODE", "mode-dev",
                "Development mode left on",
                "MEMOS_MODE is set to a development/demo mode. Dev mode relaxes safety behavior and is meant for a developer's machine, not a deployed server.",
                "Set MEMOS_MODE=prod before deploying.");
            } else if (v !== "prod" && v !== "production") {
              add("MEDIUM", e.line, "MEMOS_MODE", "mode-unknown",
                "MEMOS_MODE is not a recognized production value",
                "MEMOS_MODE is set, but not to a recognized production value, so the run mode cannot be confirmed from this config.",
                "Set MEMOS_MODE=prod before deploying.");
            }
          });
        }

        /* --- MEMOS_ADDR wildcard bind --- */
        (byKey["MEMOS_ADDR"] || []).forEach(function(e){
          var v = e.value.trim();
          if (v === "" || v === "0.0.0.0" || v === "::" || v === "[::]" || v === "*") {
            add("HIGH", e.line, "MEMOS_ADDR", "addr-wildcard",
              "Binds to every network interface",
              "MEMOS_ADDR is a wildcard bind, so the server answers on every network the host touches \u2014 including networks you did not intend to expose it on.",
              "Bind MEMOS_ADDR to one address: 127.0.0.1 behind a reverse proxy, or the host's private network IP.");
          }
        });

        /* --- Instance / base URL over http --- */
        ["MEMOS_INSTANCE_URL", "MEMOS_BASE_URL", "INSTANCE_URL", "BASE_URL"].forEach(function(k){
          (byKey[k] || []).forEach(function(e){
            if (/^http:\/\//i.test(e.value)) {
              add("HIGH", e.line, k, "url-http",
                "Instance URL is plain http",
                "The instance/base URL uses http://, so logins, session cookies, and note traffic tied to that URL travel unencrypted.",
                "Serve Memos over https and set the instance URL to the https:// address.");
            }
          });
        });

        /* --- Plaintext password inside a DSN --- */
        ["MEMOS_DSN", "MEMOS_DATABASE_DSN", "DATABASE_DSN", "DSN"].forEach(function(k){
          (byKey[k] || []).forEach(function(e){
            var pw = dsnPassword(e.value);
            if (pw !== null && !isPlaceholder(pw)) {
              add("CRITICAL", e.line, k, "dsn-password",
                "Plaintext password inside the database DSN",
                "The database connection string carries its password in plain text (password length: " + pw.length + " characters \u2014 the value itself is never shown or exported). Anyone who can read this config owns the database.",
                "Move the password out of the DSN into a secret store or injected credential, and rotate the exposed password \u2014 it has been sitting in plain text.",
                pw.length);
            }
          });
        });

        /* --- Debug flags --- */
        ["MEMOS_DEBUG", "DEBUG"].forEach(function(k){
          (byKey[k] || []).forEach(function(e){
            if (isTruthy(e.value)) {
              add("HIGH", e.line, k, "debug-on",
                "Debug is switched on",
                "A debug setting is enabled in a config meant for production. Debug output leaks server internals and slows the server down.",
                "Set debug to false for production.");
            }
          });
        });
        (byKey["GIN_MODE"] || []).forEach(function(e){
          if (e.value.toLowerCase() === "debug") {
            add("HIGH", e.line, "GIN_MODE", "debug-on",
              "Debug is switched on",
              "GIN_MODE is set to debug in a config meant for production. Debug output leaks server internals.",
              "Set GIN_MODE=release for production.");
          }
        });
        (byKey["MEMOS_LOG_LEVEL"] || []).forEach(function(e){
          var v = e.value.toLowerCase();
          if (v === "debug" || v === "trace") {
            add("MEDIUM", e.line, "MEMOS_LOG_LEVEL", "debug-on",
              "Debug-level logging is on",
              "Logging is set to a debug/trace level, which writes verbose internals \u2014 often including request details \u2014 to the server logs.",
              "Set MEMOS_LOG_LEVEL=info (or warn) for production.");
          }
        });

        /* --- Generic plaintext secrets (key, line, length only) --- */
        entries.forEach(function(e){
          if (/PASSWORD|PASSWD|SECRET|TOKEN|API_?KEY|PRIVATE_?KEY/.test(e.key) && e.value && !isPlaceholder(e.value)) {
            add("HIGH", e.line, e.key, "secret-plaintext",
              "Plaintext secret in the config",
              e.key + " holds a secret value in plain text (value length: " + e.value.length + " characters \u2014 the value itself is never shown or exported).",
              "Inject this value from a secret store or a protected environment file instead of pasting it into a shareable config.",
              e.value.length);
          }
        });

        var sevRank = { "CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3 };
        findings.sort(function(a, b){
          if (sevRank[a.severity] !== sevRank[b.severity]) return sevRank[a.severity] - sevRank[b.severity];
          return (a.line || 0) - (b.line || 0);
        });

        var verdict;
        if (findings.some(function(f){ return f.severity === "CRITICAL"; })) verdict = "DO NOT DEPLOY";
        else if (findings.length > 0) verdict = "DEPLOY WITH FIXES";
        else verdict = "SAFE TO DEPLOY";

        return { verdict: verdict, findings: findings, settingsFound: memosCount };
      }

      /* ================= Report / JSON builders (never contain secret values) ================= */
      function countsOf(result){
        var c = { CRITICAL: 0, HIGH: 0, MEDIUM: 0, LOW: 0 };
        result.findings.forEach(function(f){ c[f.severity]++; });
        return c;
      }
      function locOf(f){ return f.line ? ("Line " + f.line) : "Config-wide"; }

      function buildReport(result){
        var c = countsOf(result);
        var out = [];
        out.push("J-Dawgs Memos Server Config Safety Auditor - Audit Report");
        out.push("Verdict: " + result.verdict);
        out.push("Memos settings recognized: " + result.settingsFound);
        out.push("Findings: " + result.findings.length + " (" + c.CRITICAL + " critical, " + c.HIGH + " high, " + c.MEDIUM + " medium, " + c.LOW + " low)");
        out.push("");
        if (result.verdict === "NOT ENOUGH TO GRADE") {
          out.push(result.reason || "No Memos settings found.");
        } else if (result.findings.length === 0) {
          out.push("No findings. Every graded check passed.");
        } else {
          result.findings.forEach(function(f, i){
            out.push((i + 1) + ". [" + f.severity + "] " + locOf(f) + " - " + f.key + " - " + f.title);
            out.push("   " + f.message);
            out.push("   Fix: " + f.fix);
            out.push("");
          });
        }
        out.push("Note: secrets are reported by key name, line, and length only. No secret values appear in this report.");
        out.push("Scope: offline paste audit only. This report does not start a server or verify a live deployment.");
        return out.join("\n");
      }

      function buildJSON(result){
        var payload = {
          tool: "J-Dawgs Memos Server Config Safety Auditor",
          verdict: result.verdict,
          memosSettingsRecognized: result.settingsFound,
          counts: countsOf(result),
          findings: result.findings.map(function(f){
            var o = {
              severity: f.severity,
              line: f.line,
              key: f.key,
              check: f.check,
              title: f.title,
              message: f.message,
              fix: f.fix
            };
            if (f.secretLength !== undefined) o.secretLength = f.secretLength;
            return o;
          }),
          secretHandling: "Secrets are reported by key name, line, and length only. Secret values are never included.",
          scope: "Offline paste audit only. Does not start a server or verify a live deployment."
        };
        if (result.reason) payload.reason = result.reason;
        return JSON.stringify(payload, null, 2);
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-memos-server-config-safety-auditortm',
  name: 'J-Dawgs Memos Server Config Safety Auditor',
  description: 'Host tools only tell you the server started; ours grades a pasted Memos config offline into one deploy verdict — secrets by key name/line/length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
