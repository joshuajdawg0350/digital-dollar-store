'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Chunk Boundary Damage Bench".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the analyze function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ================= Worked example document ================= */
      var EXAMPLE_DOC = [
        "# Deploying the Inventory Service",
        "",
        "The inventory service keeps track of every part on the shelf and every part on a truck. When a crew lead opens the morning board, the service answers one question: what do we actually have, and where is it right now? That answer has to be fast, and it has to be right, because a wrong count sends a crew across town for a fitting that is not there.",
        "",
        "## Morning startup procedure",
        "",
        "Follow these steps in order every morning before the first truck rolls:",
        "",
        "1. Open the inventory board and confirm yesterday's counts were posted.",
        "2. Walk the fastener aisle and scan any bin that looks low.",
        "3. Reconcile the scan against the board and flag every mismatch.",
        "4. Print the pick list for today's jobs and stage the parts by the door.",
        "5. Lock the board so no count changes after the trucks leave.",
        "",
        "## Sync configuration",
        "",
        "The sync worker runs on a timer and pushes local counts to the shared store. Keep the batch small and the retry honest:",
        "",
        "```yaml",
        "sync:",
        "  interval_seconds: 45",
        "  batch_size: 200",
        "  retry:",
        "    max_attempts: 4",
        "    backoff_seconds: 10",
        "  conflict_policy: newest_wins",
        "```",
        "",
        "If a sync fails four times in a row, the worker stops and raises an alert instead of guessing. A stale count that admits it is stale beats a fresh-looking count that is quietly wrong, every single time."
      ].join("\n");

      /* ================= Helpers ================= */
      function $(id){ return document.getElementById(id); }
      function estTokens(chars){ return Math.max(1, Math.round(chars / 4)); }
      function clampInt(v, lo, hi, fallback){
        v = parseInt(v, 10);
        if (isNaN(v)) return fallback;
        return Math.min(hi, Math.max(lo, v));
      }
      function esc(s){
        return s.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
      }
      function median(nums){
        if (!nums.length) return 0;
        var s = nums.slice().sort(function(a,b){return a-b;});
        var m = Math.floor(s.length/2);
        return s.length % 2 ? s[m] : Math.round((s[m-1]+s[m])/2);
      }

      /* ================= Chunking strategies ================= */

      // Fixed-character with overlap: cut at exactly `size`, step back by `overlap`.
      function chunkFixed(text, size, overlap){
        var step = Math.max(1, size - overlap);
        var chunks = [];
        for (var i = 0; i < text.length; i += step){
          chunks.push(text.slice(i, i + size));
          if (i + size >= text.length) break;
        }
        return chunks;
      }

      // Recursive separator: split on \n\n, then \n, then sentence ends, then
      // spaces, then hard characters; merge pieces back up to `size`, carrying
      // a character tail of `overlap` into the next chunk.
      function recursivePieces(text, size){
        var seps = ["\n\n", "\n", ". ", " ", ""];
        function rec(t, idx){
          if (t.length <= size) return t.length ? [t] : [];
          if (idx >= seps.length - 1){
            var out = [];
            for (var i = 0; i < t.length; i += size) out.push(t.slice(i, i + size));
            return out;
          }
          var sep = seps[idx];
          if (sep === "" || t.indexOf(sep) === -1) return rec(t, idx + 1);
          var raw = t.split(sep);
          var parts = [];
          for (var j = 0; j < raw.length; j++){
            var p = raw[j] + (j < raw.length - 1 ? sep : "");
            if (p.length) parts.push(p);
          }
          var out2 = [];
          parts.forEach(function(p){
            if (p.length > size) out2 = out2.concat(rec(p, idx + 1));
            else out2.push(p);
          });
          return out2;
        }
        return rec(text, 0);
      }
      function mergeCharOverlap(pieces, size, overlap){
        var chunks = [], cur = "";
        pieces.forEach(function(p){
          if (cur && cur.length + p.length > size){
            chunks.push(cur);
            var tail = overlap > 0 ? cur.slice(-overlap) : "";
            if (tail.length + p.length > size) tail = "";
            cur = tail + p;
          } else {
            cur += p;
          }
        });
        if (cur.length) chunks.push(cur);
        return chunks;
      }
      function chunkRecursive(text, size, overlap){
        return mergeCharOverlap(recursivePieces(text, size), size, overlap);
      }

      // Sentence-aware: pack whole sentences (and whole lines) up to `size`;
      // carry trailing whole sentences forward as the overlap.
      function sentenceUnits(text){
        var units = [];
        var lines = text.split("\n");
        lines.forEach(function(line, li){
          var withNl = li < lines.length - 1 ? line + "\n" : line;
          if (!withNl) return;
          var parts = withNl.match(/[^.!?]+[.!?]+["')\]]*\s*|[^.!?]+$/g);
          if (parts) parts.forEach(function(p){ if (p.length) units.push(p); });
          else units.push(withNl);
        });
        return units;
      }
      function chunkSentence(text, size, overlap){
        var units = sentenceUnits(text);
        var chunks = [], cur = "", curUnits = [];
        function flush(){
          if (cur.length) chunks.push(cur);
          // Build the next chunk's seed from trailing units, up to `overlap` chars.
          var seed = "", seedUnits = [];
          for (var i = curUnits.length - 1; i >= 0; i--){
            if (seed.length + curUnits[i].length > overlap) break;
            seed = curUnits[i] + seed;
            seedUnits.unshift(curUnits[i]);
          }
          cur = seed; curUnits = seedUnits;
        }
        units.forEach(function(u){
          if (u.length > size){
            // A single unit longer than the target: hard-cut it.
            if (cur.length) { chunks.push(cur); cur = ""; curUnits = []; }
            for (var i = 0; i < u.length; i += size) chunks.push(u.slice(i, i + size));
            return;
          }
          if (cur && cur.length + u.length > size) flush();
          cur += u; curUnits.push(u);
        });
        if (cur.length) chunks.push(cur);
        return chunks;
      }

      var STRATEGIES = {
        fixed:     { name: "Fixed-character with overlap", run: chunkFixed },
        recursive: { name: "Recursive separator",          run: chunkRecursive },
        sentence:  { name: "Sentence-aware",               run: chunkSentence }
      };

      /* ================= Damage detection ================= */
      var FLAG_ORDER = ["MID-SENTENCE CUT","BROKEN CODE FENCE","ORPHANED HEADING","SEVERED PROCEDURE","TINY FRAGMENT"];
      var FLAG_CLASS = {
        "MID-SENTENCE CUT":"red", "BROKEN CODE FENCE":"red",
        "ORPHANED HEADING":"amber", "SEVERED PROCEDURE":"amber", "TINY FRAGMENT":"amber"
      };

      function nonEmptyLines(s){
        return s.split("\n").filter(function(l){ return l.trim().length > 0; });
      }
      function isListItem(line){
        return /^\s*(\d{1,3}[.)]|[-*+])\s+/.test(line);
      }

      function analyze(chunks, target){
        var flags = chunks.map(function(){ return []; });

        chunks.forEach(function(c, i){
          // BROKEN CODE FENCE — odd number of ``` markers in one chunk.
          var fences = (c.match(/```/g) || []).length;
          if (fences % 2 === 1){
            flags[i].push({ type:"BROKEN CODE FENCE",
              detail:"a ``` fence opens in this chunk and closes in another chunk — or never closes at all" });
          }

          // ORPHANED HEADING — last non-empty line is a Markdown heading.
          var lines = nonEmptyLines(c);
          var lastLine = lines.length ? lines[lines.length - 1] : "";
          if (/^\s*#{1,6}\s+\S/.test(lastLine)){
            flags[i].push({ type:"ORPHANED HEADING",
              detail:"heading \"" + lastLine.trim().slice(0, 60) + "\" sits at the end of this chunk, separated from its body" });
          }

          // TINY FRAGMENT — under 15% of target size.
          if (c.length < target * 0.15){
            flags[i].push({ type:"TINY FRAGMENT",
              detail:"only " + c.length + " chars — under 15% of the " + target + "-char target" });
          }

          if (i < chunks.length - 1){
            var next = chunks[i + 1];
            var trimmedEnd = c.replace(/\s+$/, "");
            var endsSentence = /[.!?]["')\]]?$/.test(trimmedEnd) || trimmedEnd.slice(-3) === "```";
            var nextStarts = next.replace(/^\s+/, "");
            // MID-SENTENCE CUT — no sentence-ending punctuation here,
            // and the next chunk opens mid-sentence (lowercase continuation).
            if (!endsSentence && /^[a-z]/.test(nextStarts)){
              flags[i].push({ type:"MID-SENTENCE CUT",
                detail:"this chunk ends mid-thought and the next chunk opens with \"" +
                  esc(nextStarts.slice(0, 24)) + "…\" — the sentence lives in two chunks" });
            }
            // SEVERED PROCEDURE — a step list runs across the boundary.
            var nextLines = nonEmptyLines(next);
            var nextFirst = nextLines.length ? nextLines[0] : "";
            if (isListItem(lastLine) && isListItem(nextFirst)){
              flags[i].push({ type:"SEVERED PROCEDURE",
                detail:"a step list is split here — steps continue in chunk " + (i + 2) });
            }
          }
        });

        var byType = {};
        FLAG_ORDER.forEach(function(t){ byType[t] = 0; });
        var total = 0, worstIdx = -1, worstCount = 0;
        flags.forEach(function(fl, i){
          fl.forEach(function(f){ byType[f.type]++; total++; });
          if (fl.length > worstCount){ worstCount = fl.length; worstIdx = i; }
        });
        var sizes = chunks.map(function(c){ return c.length; });
        var verdict, verdictClass;
        if (total === 0){ verdict = "CLEAN"; verdictClass = "clean"; }
        else if (total <= Math.max(1, Math.ceil(chunks.length / 2))){ verdict = "USABLE WITH DAMAGE"; verdictClass = "usable"; }
        else { verdict = "DAMAGE HEAVY"; verdictClass = "heavy"; }

        return {
          flags: flags, byType: byType, total: total,
          sizes: sizes,
          min: sizes.length ? Math.min.apply(null, sizes) : 0,
          max: sizes.length ? Math.max.apply(null, sizes) : 0,
          med: median(sizes),
          verdict: verdict, verdictClass: verdictClass,
          worstIdx: worstIdx, worstCount: worstCount
        };
      }

      /* ================= Rendering ================= */
      function readConfig(prefix){
        var strat = $("strat" + prefix).value;
        var size = clampInt($("size" + prefix).value, 60, 10000, 300);
        var overlap = clampInt($("overlap" + prefix).value, 0, 5000, 0);
        if (overlap >= size) overlap = size - 1;
        return { key: strat, size: size, overlap: overlap };
      }

      function scoreboardHTML(label, cfg, chunks, a){
        var h = "";
        h += '<div class="strat-head"><span class="strat-badge">' + label + '</span><h3>' +
             esc(STRATEGIES[cfg.key].name) + '</h3></div>';
        h += '<p class="hint" style="margin:0 0 12px">Target ' + cfg.size + ' chars · overlap ' + cfg.overlap + ' chars</p>';
        h += '<div class="verdict ' + a.verdictClass + '">' + a.verdict + '</div>';
        h += '<div class="stats">' +
               '<div class="stat"><div class="v">' + chunks.length + '</div><div class="l">Chunks</div></div>' +
               '<div class="stat"><div class="v">' + a.min + ' / ' + a.med + ' / ' + a.max + '</div><div class="l">Size min / median / max (chars)</div></div>' +
               '<div class="stat"><div class="v">' + a.total + '</div><div class="l">Damage flags</div></div>' +
             '</div>';
        h += '<div class="flagcounts">';
        FLAG_ORDER.forEach(function(t){
          h += '<div class="row"><span><span class="chip ' + FLAG_CLASS[t] + '">' + t + '</span></span>' +
               '<span class="n">' + a.byType[t] + '</span></div>';
        });
        h += '</div>';
        if (a.worstIdx >= 0){
          var wf = a.flags[a.worstIdx].map(function(f){ return f.type; }).join(", ");
          h += '<div class="worst"><span class="k">Worst chunk</span>Chunk ' + (a.worstIdx + 1) +
               ' — ' + a.worstCount + (a.worstCount === 1 ? ' flag' : ' flags') + ': ' + esc(wf) +
               ' (' + chunks[a.worstIdx].length + ' chars, ~' + estTokens(chunks[a.worstIdx].length) + ' est. tokens)</div>';
        } else {
          h += '<div class="worst"><span class="k">Worst chunk</span>No damaged chunks. Every cut landed on a boundary this bench checks.</div>';
        }
        return h;
      }

      function chunksHTML(cfg, chunks, a){
        var h = "";
        chunks.forEach(function(c, i){
          var fl = a.flags[i];
          var pct = Math.min(100, Math.round(c.length / cfg.size * 100));
          h += '<div class="chunk' + (fl.length ? ' damaged' : '') + '">';
          h += '<div class="chunk-top"><span class="chunk-id">Chunk ' + (i + 1) + ' of ' + chunks.length + '</span>' +
               '<span class="chunk-meta">' + c.length + ' chars · ~' + estTokens(c.length) +
               ' est. tokens <span style="color:var(--ink-faint)">(estimate, ~4 chars/token)</span></span></div>';
          h += '<pre>' + esc(c) + '</pre>';
          h += '<div class="bar"><i style="width:' + pct + '%"></i></div>';
          if (fl.length){
            h += '<div class="flags">';
            fl.forEach(function(f){ h += '<span class="chip ' + FLAG_CLASS[f.type] + '">' + f.type + '</span>'; });
            h += '</div>';
            fl.forEach(function(f){
              h += '<p class="legend-note" style="margin:6px 0 0">' + esc(f.detail) + '</p>';
            });
          } else {
            h += '<div class="ok">✓ No damage flags on this chunk</div>';
          }
          h += '</div>';
        });
        return h;
      }
  return { "analyze": (typeof analyze !== 'undefined' ? analyze : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_DOC": (typeof EXAMPLE_DOC !== 'undefined' ? EXAMPLE_DOC : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["analyze"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-chunk-boundary-damage-bench',
  name: 'J-Dawgs Chunk Boundary Damage Bench',
  description: 'Benches two RAG chunking strategies side by side on a pasted document and scores boundary damage — mid-sentence cuts, broken code fences, orphaned headings, severed procedures, tiny fragments — before you buy embeddings',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["analyze"]) return { ok: false, output: null, summary: 'Extracted core has no analyze function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_DOC": __core["EXAMPLE_DOC"] }
};
