'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Baserow Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var RISKY = [
        "BASEROW_PUBLIC_URL=http://baserow.example.internal",
        "SECRET_KEY=Qw!z9",
        "DATABASE_PASSWORD=Pz#4ab",
        "DATABASE_URL=postgres://baserow:Pz#4ab@db.internal:5432/baserow",
        "REDIS_URL=redis://:RdPass!482@redis.internal:6379/0",
        "EMAIL_SMTP_PASSWORD=Sm!p739",
        "EMAIL_SMTP_USE_TLS=false",
        "BASEROW_HOSTNAME=0.0.0.0",
        "DEBUG=true",
        "SESSION_COOKIE_SECURE=false",
        "CSRF_COOKIE_SECURE=false",
        "BASEROW_ALLOW_SIGNUP=true",
        "SYNC_TEMPLATES_ON_STARTUP=true",
        "BASEROW_FILE_UPLOAD_MAX_SIZE_MB=500",
        "BASEROW_AMOUNT_OF_WORKERS=2"
      ].join("\n");

      var HARDENED = [
        "BASEROW_PUBLIC_URL=https://baserow.acme-ops.net",
        "SECRET_KEY=N7vQ2xL9pR4sT8wZ1yH6jK3mB5cD0fG2hJ4kL6nP8q",
        "DATABASE_PASSWORD=X9mQ4vL7pR2sT8wZ5yH1jK6nB3cD",
        "DATABASE_URL=postgres://baserow@db.internal:5432/baserow?sslmode=require",
        "REDIS_URL=rediss://:R8kM2xQ9vL4pS7wN1z@redis.internal:6380/0",
        "EMAIL_SMTP_PASSWORD=S6tY9wQ2mK8xP4vL7n",
        "EMAIL_SMTP_USE_TLS=true",
        "BASEROW_HOSTNAME=baserow.acme-ops.net",
        "DEBUG=false",
        "SESSION_COOKIE_SECURE=true",
        "CSRF_COOKIE_SECURE=true",
        "SECURE_SSL_REDIRECT=true",
        "BASEROW_ALLOW_SIGNUP=false",
        "SYNC_TEMPLATES_ON_STARTUP=false",
        "BASEROW_FILE_UPLOAD_MAX_SIZE_MB=25",
        "BASEROW_AMOUNT_OF_WORKERS=4"
      ].join("\n");

      var PROSE = "We run Baserow behind a proxy on our own server and it seems fine. " +
        "The team likes the tables, logins work, and we plan to open it up to the whole company next week.";

      var KNOWN_KEYS = {
        BASEROW_PUBLIC_URL:1, SECRET_KEY:1, DATABASE_PASSWORD:1, DATABASE_URL:1, DATABASE_HOST:1,
        DATABASE_USER:1, DATABASE_NAME:1, DATABASE_PORT:1, REDIS_URL:1, REDIS_PASSWORD:1,
        EMAIL_SMTP_HOST:1, EMAIL_SMTP_PORT:1, EMAIL_SMTP_USER:1, EMAIL_SMTP_PASSWORD:1,
        EMAIL_SMTP_USE_TLS:1, EMAIL_SMTP_USE_SSL:1, BASEROW_HOSTNAME:1, BASEROW_BIND_HOST:1,
        HOST:1, BIND_HOST:1, DEBUG:1, BASEROW_DEBUG:1, DJANGO_DEBUG:1, DEV_MODE:1,
        ENVIRONMENT:1, BASEROW_ENVIRONMENT:1, SYNC_TEMPLATES_ON_STARTUP:1,
        BASEROW_AMOUNT_OF_WORKERS:1, SESSION_COOKIE_SECURE:1, CSRF_COOKIE_SECURE:1,
        SECURE_SSL_REDIRECT:1, BASEROW_ALLOW_SIGNUP:1, ALLOW_SIGNUP:1, ALLOW_NEW_SIGNUPS:1,
        BASEROW_FILE_UPLOAD_MAX_SIZE_MB:1, FILE_UPLOAD_MAX_SIZE_MB:1, MAX_UPLOAD_SIZE_MB:1
      };
      var PLACEHOLDER_TOKENS = ["changeme","change-me","change_me","example","placeholder",
        "insecure","default","replace","todo","letmein","password123","secret123","your-","your_"];
      var TRUTHY = {true:1,"1":1,yes:1,on:1};
      var FALSY = {false:1,"0":1,no:1,off:1};

      function isTruthy(v){ return !!TRUTHY[String(v).trim().toLowerCase()]; }
      function isFalsy(v){ return !!FALSY[String(v).trim().toLowerCase()]; }
      function hasPlaceholder(v){
        var s = String(v).toLowerCase();
        for (var i=0;i<PLACEHOLDER_TOKENS.length;i++){ if (s.indexOf(PLACEHOLDER_TOKENS[i]) !== -1) return true; }
        return false;
      }
      function isEnvRef(v){ var s=String(v).trim(); return s.indexOf("${")===0 || s.indexOf("$(")===0; }

      function parseConfig(text){
        var entries = [];
        var rawLines = String(text).split(/\r?\n/);
        for (var i=0;i<rawLines.length;i++){
          var t = rawLines[i].trim();
          if (!t || t.charAt(0) === "#") continue;
          if (t.indexOf("export ") === 0) t = t.slice(7).trim();
          var m = t.match(/^([A-Za-z_][A-Za-z0-9_]*)\s*[:=]\s*(.*)$/);
          if (!m) continue;
          var v = m[2].trim();
          if (v.length >= 2 && ((v.charAt(0)==='"' && v.charAt(v.length-1)==='"') ||
              (v.charAt(0)==="'" && v.charAt(v.length-1)==="'"))) v = v.slice(1,-1);
          entries.push({ key: m[1].toUpperCase(), value: v, line: i+1 });
        }
        return entries;
      }
      function isRecognized(key){ return !!KNOWN_KEYS[key] || key.indexOf("BASEROW_") === 0; }
      function findKey(entries, keys){
        for (var i=0;i<entries.length;i++){ if (keys.indexOf(entries[i].key) !== -1) return entries[i]; }
        return null;
      }
      // Extract an embedded password length from a URL without ever returning the password.
      function embeddedPasswordLength(url){
        var m = String(url).match(/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\/([^\/]*)/);
        if (!m) return -1;
        var userinfo = m[1];
        var at = userinfo.lastIndexOf("@");
        if (at === -1) return -1;
        userinfo = userinfo.slice(0, at);
        var colon = userinfo.indexOf(":");
        if (colon === -1) return -1;
        var pw = userinfo.slice(colon+1);
        if (isEnvRef(pw)) return -1;
        return pw.length;
      }
      function urlScheme(url){
        var m = String(url).match(/^([a-zA-Z][a-zA-Z0-9+.-]*):\/\//);
        return m ? m[1].toLowerCase() : "";
      }

      function auditConfig(text){
        var entries = parseConfig(text);
        var recognized = 0, i, e;
        for (i=0;i<entries.length;i++){ if (isRecognized(entries[i].key)) recognized++; }
        var findings = [];
        function add(severity, key, line, length, issue, fix){
          var f = { severity: severity, key: key, line: line, issue: issue, fix: fix };
          if (typeof length === "number" && length >= 0) f.length = length;
          findings.push(f);
        }

        if (recognized < 3){
          return { verdict: "NOT ENOUGH TO GRADE", recognized: recognized,
            parsed: entries.length, findings: [],
            note: "Only " + recognized + " recognizable Baserow setting(s) found. Paste at least three KEY=value settings (for example BASEROW_PUBLIC_URL, SECRET_KEY and a database setting) to get a grade." };
        }

        var byKey = {};
        for (i=0;i<entries.length;i++){ byKey[entries[i].key] = entries[i]; }

        // R1 — SECRET_KEY strength.
        e = byKey["SECRET_KEY"];
        if (!e){
          add("HIGH","SECRET_KEY",null,null,
            "No SECRET_KEY setting was found in the pasted config.",
            "Set a long, random SECRET_KEY (32+ characters) that exists nowhere else.");
        } else if (!isEnvRef(e.value)){
          var reasons = [];
          if (e.value.length < 32) reasons.push("only " + e.value.length + " characters long");
          if (hasPlaceholder(e.value)) reasons.push("it matches an example/placeholder pattern");
          if (reasons.length){
            add("BLOCKER","SECRET_KEY",e.line,e.value.length,
              "SECRET_KEY is weak: " + reasons.join(" and ") + ".",
              "Generate a fresh random SECRET_KEY of at least 32 characters and keep it out of shared examples.");
          }
        }

        // R2 — DATABASE_PASSWORD strength.
        e = byKey["DATABASE_PASSWORD"];
        if (e && !isEnvRef(e.value)){
          var r2 = [];
          if (e.value.length < 16) r2.push("only " + e.value.length + " characters long");
          if (hasPlaceholder(e.value)) r2.push("it matches an example/placeholder pattern");
          if (r2.length){
            add("BLOCKER","DATABASE_PASSWORD",e.line,e.value.length,
              "Plaintext database password is weak: " + r2.join(" and ") + ".",
              "Use a database password of at least 16 random characters, supplied from a secrets store at deploy time.");
          }
        }

        // R3 — DATABASE_URL embedded credential.
        e = byKey["DATABASE_URL"];
        if (e){
          var pwLen = embeddedPasswordLength(e.value);
          if (pwLen >= 0 && pwLen < 16){
            add("BLOCKER","DATABASE_URL",e.line,pwLen,
              "DATABASE_URL embeds a database password that is only " + pwLen + " characters long.",
              "Give the database user a password of at least 16 random characters, or pass the credential via a secret reference instead of the URL.");
          }
        }
        if (!byKey["DATABASE_PASSWORD"] && !byKey["DATABASE_URL"]){
          add("MEDIUM","DATABASE_PASSWORD / DATABASE_URL",null,null,
            "No database credential setting was found in the pasted config.",
            "Confirm how the database password is supplied; if it is hardcoded elsewhere, grade that file too.");
        }

        // R4 — Public URL transport.
        var publicUrl = byKey["BASEROW_PUBLIC_URL"];
        var publicIsHttps = false;
        if (!publicUrl){
          add("MEDIUM","BASEROW_PUBLIC_URL",null,null,
            "No BASEROW_PUBLIC_URL setting was found, so the public transport posture cannot be confirmed.",
            "Set BASEROW_PUBLIC_URL to the exact https:// address users will open.");
        } else {
          var scheme = urlScheme(publicUrl.value);
          publicIsHttps = (scheme === "https");
          if (scheme === "http"){
            add("HIGH","BASEROW_PUBLIC_URL",publicUrl.line,null,
              "BASEROW_PUBLIC_URL uses plain http:// — logins, sessions and data travel unencrypted.",
              "Serve Baserow over https:// (directly or behind a TLS-terminating proxy) and update BASEROW_PUBLIC_URL to match.");
          }
        }

        // R5 — All-interface bind without TLS posture.
        var bindKeys = ["BASEROW_HOSTNAME","BASEROW_BIND_HOST","HOST","BIND_HOST"];
        for (i=0;i<entries.length;i++){
          e = entries[i];
          if (bindKeys.indexOf(e.key) === -1) continue;
          var bv = e.value.trim().toLowerCase();
          if (bv === "0.0.0.0" || bv === "::" || bv === "*" || bv === "[::]"){
            if (!publicIsHttps){
              add("HIGH",e.key,e.line,null,
                "The server binds to all network interfaces while the public URL shows no TLS (https) posture — the app is exposed on every interface without confirmed encryption.",
                "Bind to a specific host or localhost behind a TLS proxy, or serve https so the all-interface bind is covered by TLS.");
            } else {
              add("MEDIUM",e.key,e.line,null,
                "The server binds to all network interfaces. HTTPS is configured, but confirm a firewall or proxy is intended to face the network.",
                "Prefer binding to a specific interface or localhost behind a reverse proxy.");
            }
          }
        }

        // R6 — Debug / dev mode.
        var debugKeys = ["DEBUG","BASEROW_DEBUG","DJANGO_DEBUG","DEV_MODE","BASEROW_DEV_MODE"];
        for (i=0;i<entries.length;i++){
          e = entries[i];
          if (debugKeys.indexOf(e.key) !== -1 && isTruthy(e.value)){
            add("BLOCKER",e.key,e.line,null,
              "Debug/development mode is switched on. Debug output can leak settings, paths and request data to anyone who can reach the server.",
              "Set the debug flag to false for any deployable config.");
          }
          if ((e.key === "ENVIRONMENT" || e.key === "BASEROW_ENVIRONMENT") &&
              ["dev","development","local","debug"].indexOf(e.value.trim().toLowerCase()) !== -1){
            add("HIGH",e.key,e.line,null,
              "The environment is set to a development value, which can enable relaxed checks and verbose errors.",
              "Set the environment to production for deployment.");
          }
        }

        // R7 — Redis credentials / transport.
        e = byKey["REDIS_URL"];
        if (e){
          var rs = urlScheme(e.value);
          var rpw = embeddedPasswordLength(e.value);
          if (rs === "redis" && rpw >= 0){
            add("HIGH","REDIS_URL",e.line,rpw,
              "REDIS_URL carries a credential over an unencrypted redis:// connection — the credential and cache traffic travel in plaintext.",
              "Use rediss:// (TLS) for Redis, or keep Redis on a private network segment with no credential in the URL.");
          } else if (rs === "redis"){
            add("MEDIUM","REDIS_URL",e.line,null,
              "REDIS_URL uses unencrypted redis:// — cache traffic travels in plaintext.",
              "Use rediss:// (TLS) or confirm Redis is reachable only on a private network.");
          }
        }
        e = byKey["REDIS_PASSWORD"];
        if (e && !isEnvRef(e.value) && e.value.length < 16){
          add("HIGH","REDIS_PASSWORD",e.line,e.value.length,
            "REDIS_PASSWORD is only " + e.value.length + " characters long.",
            "Use a Redis password of at least 16 random characters.");
        }

        // R8 — SMTP credentials / transport.
        var smtpPw = byKey["EMAIL_SMTP_PASSWORD"];
        if (smtpPw && !isEnvRef(smtpPw.value) && smtpPw.value.length < 16){
          add("HIGH","EMAIL_SMTP_PASSWORD",smtpPw.line,smtpPw.value.length,
            "EMAIL_SMTP_PASSWORD is only " + smtpPw.value.length + " characters long.",
            "Use a dedicated SMTP credential of at least 16 characters, issued for this server only.");
        }
        e = byKey["EMAIL_SMTP_USE_TLS"];
        if (e && isFalsy(e.value) && smtpPw){
          add("HIGH","EMAIL_SMTP_USE_TLS",e.line,null,
            "SMTP TLS is switched off while an SMTP password is set — mail credentials and message content can travel in plaintext.",
            "Set EMAIL_SMTP_USE_TLS=true (and the matching SMTP port) so mail is sent over TLS.");
        }

        // R9 — Secure cookie / session posture, where shown.
        e = byKey["SESSION_COOKIE_SECURE"];
        if (e && isFalsy(e.value)){
          add("HIGH","SESSION_COOKIE_SECURE",e.line,null,
            "SESSION_COOKIE_SECURE is switched off — session cookies may travel over plain HTTP.",
            "Set SESSION_COOKIE_SECURE=true once the site is served over https.");
        }
        e = byKey["CSRF_COOKIE_SECURE"];
        if (e && isFalsy(e.value)){
          add("HIGH","CSRF_COOKIE_SECURE",e.line,null,
            "CSRF_COOKIE_SECURE is switched off — the CSRF cookie may travel over plain HTTP.",
            "Set CSRF_COOKIE_SECURE=true once the site is served over https.");
        }
        e = byKey["SECURE_SSL_REDIRECT"];
        if (e && isFalsy(e.value)){
          add("MEDIUM","SECURE_SSL_REDIRECT",e.line,null,
            "SECURE_SSL_REDIRECT is switched off — plain-HTTP requests are not forced to HTTPS.",
            "Set SECURE_SSL_REDIRECT=true, or enforce the redirect at the proxy.");
        }

        // R10 — Open signup.
        var signupKeys = ["BASEROW_ALLOW_SIGNUP","ALLOW_SIGNUP","ALLOW_NEW_SIGNUPS","BASEROW_ALLOW_NEW_USER_SIGNUPS"];
        for (i=0;i<entries.length;i++){
          e = entries[i];
          if (signupKeys.indexOf(e.key) !== -1 && isTruthy(e.value)){
            add("MEDIUM",e.key,e.line,null,
              "Open signup is enabled — anyone who can reach the server can register an account.",
              "Disable open signup, or restrict registration by invite or domain, unless public signup is deliberate.");
          }
        }

        // R11 — Template sync on startup.
        e = byKey["SYNC_TEMPLATES_ON_STARTUP"];
        if (e && isTruthy(e.value)){
          add("LOW","SYNC_TEMPLATES_ON_STARTUP",e.line,null,
            "Template sync on startup is enabled — templates are pulled in every time the server boots.",
            "Confirm the synced template source is trusted, or sync templates deliberately instead of on every startup.");
        }

        // R12 — File-upload ceiling.
        var uploadKeys = ["BASEROW_FILE_UPLOAD_MAX_SIZE_MB","FILE_UPLOAD_MAX_SIZE_MB","MAX_UPLOAD_SIZE_MB"];
        for (i=0;i<entries.length;i++){
          e = entries[i];
          if (uploadKeys.indexOf(e.key) === -1) continue;
          var n = parseInt(e.value, 10);
          if (e.value.trim().toLowerCase() === "unlimited" || n === 0 || (!isNaN(n) && n > 100)){
            add("MEDIUM",e.key,e.line,null,
              "The file-upload size limit is effectively unbounded or far above a sane default, inviting disk exhaustion.",
              "Set an upload limit that matches the real use case (tens of MB, not hundreds).");
          }
        }

        // R13 — Worker count sanity.
        e = byKey["BASEROW_AMOUNT_OF_WORKERS"];
        if (e){
          var w = parseInt(e.value, 10);
          if (!isNaN(w) && (w <= 0 || w > 32)){
            add("LOW","BASEROW_AMOUNT_OF_WORKERS",e.line,null,
              "The worker count is outside a sane range, which can starve or overload the server.",
              "Set BASEROW_AMOUNT_OF_WORKERS to a small positive number matched to the host's CPU.");
          }
        }

        var order = { BLOCKER:0, HIGH:1, MEDIUM:2, LOW:3 };
        findings.sort(function(a,b){
          if (order[a.severity] !== order[b.severity]) return order[a.severity]-order[b.severity];
          return (a.line||0)-(b.line||0);
        });

        var verdict, note;
        var blockers = findings.filter(function(f){return f.severity==="BLOCKER";}).length;
        if (blockers > 0){
          verdict = "DO NOT DEPLOY";
          note = blockers + " blocker(s) present. Fix every blocker before this config goes anywhere near a server.";
        } else if (findings.length > 0){
          verdict = "DEPLOY WITH FIXES";
          note = "No blockers, but " + findings.length + " finding(s) to fix before deploying.";
        } else {
          verdict = "SAFE TO DEPLOY";
          note = "No findings. The pasted settings show none of the checked dangers — this grades the text only, not a running server.";
        }
        return { verdict: verdict, recognized: recognized, parsed: entries.length, findings: findings, note: note };
      }

      function buildReports(result){
        var counts = { BLOCKER:0, HIGH:0, MEDIUM:0, LOW:0 };
        result.findings.forEach(function(f){ counts[f.severity]++; });
        var lines = [];
        lines.push("J-Dawgs Baserow Server Config Safety Auditor — text report");
        lines.push("Verdict: " + result.verdict);
        lines.push("Recognized Baserow settings: " + result.recognized + " | Findings: " + result.findings.length +
          " (BLOCKER " + counts.BLOCKER + ", HIGH " + counts.HIGH + ", MEDIUM " + counts.MEDIUM + ", LOW " + counts.LOW + ")");
        lines.push("Secrets are reported by key name, line number and length only.");
        lines.push("");
        if (result.findings.length === 0){
          lines.push(result.verdict === "NOT ENOUGH TO GRADE" ? result.note : "No findings.");
        } else {
          result.findings.forEach(function(f, idx){
            lines.push((idx+1) + ". [" + f.severity + "] " + f.key +
              " — line " + (f.line === null ? "not present" : f.line) +
              (typeof f.length === "number" ? " — value length " + f.length : ""));
            lines.push("    " + f.issue);
            lines.push("    Fix: " + f.fix);
          });
        }
        var jsonObj = {
          tool: "J-Dawgs Baserow Server Config Safety Auditor",
          verdict: result.verdict,
          recognizedSettings: result.recognized,
          counts: counts,
          findings: result.findings.map(function(f){
            var o = { severity: f.severity, key: f.key, line: f.line, issue: f.issue, fix: f.fix };
            if (typeof f.length === "number") o.valueLength = f.length;
            return o;
          })
        };
        return { text: lines.join("\n"), json: JSON.stringify(jsonObj, null, 2), counts: counts };
      }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-baserow-server-config-safety-auditortm',
  name: 'J-Dawgs Baserow Server Config Safety Auditor',
  description: 'Host tools only tell you the server started; ours grades a pasted Baserow env config offline into one deploy verdict — secrets reported by key name/line/length only, never the secret value.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
