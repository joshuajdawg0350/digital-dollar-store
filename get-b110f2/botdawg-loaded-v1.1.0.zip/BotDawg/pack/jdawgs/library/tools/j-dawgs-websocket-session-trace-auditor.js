'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs WebSocket Session Trace Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------------- samples ---------------- */
      var DYING_SAMPLE = [
        '12:00:00.000 -> text {"type":"subscribe","channel":"orders","token":"tk_live_9f27c41d88ab"}',
        '12:00:00.182 <- text {"type":"subscribed","channel":"orders"}',
        '12:00:01.240 <- text {"type":"order","id":1042,"status":"open"}',
        '12:00:04.610 <- text {"type":"order","id":1043,"status":"open"}',
        '12:00:10.000 -> ping',
        '12:00:10.041 <- pong',
        '12:00:20.000 -> ping',
        '12:00:20.038 <- pong',
        '12:00:30.000 -> ping',
        '12:00:30.044 <- pong',
        '12:00:40.000 -> ping',
        '12:00:52.315 <- text {"type":"order","id":1044,"status":"filled"}',
        '12:01:52.400 -> text {"type":"heartbeat-check","note":"anyone there?"}'
      ].join("\n");

      var HEALTHY_SAMPLE = [
        '0 -> text {"type":"subscribe","channel":"prices"}',
        '95 <- text {"type":"subscribed","channel":"prices"}',
        '1200 <- text {"type":"tick","symbol":"ACME","price":182.44}',
        '10000 -> ping',
        '10038 <- pong',
        '18200 <- text {"type":"tick","symbol":"ACME","price":182.51}',
        '20000 -> ping',
        '20041 <- pong',
        '26400 <- text {"type":"tick","symbol":"ACME","price":182.47}',
        '30000 -> ping',
        '30036 <- pong',
        '33500 -> close 1000 done',
        '33580 <- close 1000 bye'
      ].join("\n");

      /* ---------------- close-code table (RFC 6455) ---------------- */
      var CLOSE_CODES = {
        1000: { name: "Normal Closure", note: "The purpose of the connection has been fulfilled." },
        1001: { name: "Going Away", note: "An endpoint is going away — server shutdown or page navigation." },
        1002: { name: "Protocol Error", note: "A frame violated the protocol." },
        1003: { name: "Unsupported Data", note: "A data type was received that the endpoint cannot accept." },
        1005: { name: "No Status Received", note: "Reserved code: it must not appear on the wire. Seeing it logged means the close frame carried no code.", reserved: true },
        1006: { name: "Abnormal Closure", note: "Reserved code: it is never sent on the wire. It means NO close frame arrived — the connection dropped.", reserved: true },
        1007: { name: "Invalid Payload Data", note: "Payload inconsistent with the frame type (e.g. non-UTF-8 in a text frame)." },
        1008: { name: "Policy Violation", note: "The message violated the receiving endpoint's policy." },
        1009: { name: "Message Too Big", note: "A message was too big for the endpoint to process." },
        1010: { name: "Mandatory Extension", note: "The client expected an extension the server did not negotiate." },
        1011: { name: "Server Error", note: "The server hit an unexpected condition." },
        1012: { name: "Service Restart", note: "The service is restarting; the client may reconnect." },
        1013: { name: "Try Again Later", note: "Temporary condition; the client may reconnect later." },
        1015: { name: "TLS Handshake Failure", note: "Reserved code: it is never sent on the wire. TLS failed before a close frame could exist.", reserved: true }
      };
      var ERROR_CLOSE = { 1002: 1, 1003: 1, 1007: 1, 1008: 1, 1009: 1, 1010: 1, 1011: 1 };

      function decodeClose(code) {
        if (CLOSE_CODES[code]) return { known: true, reserved: !!CLOSE_CODES[code].reserved, name: CLOSE_CODES[code].name, note: CLOSE_CODES[code].note };
        if (code >= 3000 && code <= 3999) return { known: true, name: "Library / framework range", note: "Codes 3000–3999 are registered for use by libraries, frameworks, and applications." };
        if (code >= 4000 && code <= 4999) return { known: true, name: "Private use range", note: "Codes 4000–4999 are reserved for private, application-defined meanings." };
        if (code >= 1016 && code <= 2999) return { known: false, name: "Unassigned range", note: "Codes 1016–2999 are not assigned by RFC 6455 and are reserved for future use." };
        return { known: false, name: "Unknown code", note: "This code is not defined by RFC 6455." };
      }

      /* ---------------- helpers ---------------- */
      function esc(s) {
        return String(s).replace(/[&<>"']/g, function (c) {
          return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
        });
      }
      function fmtSec(ms) {
        var s = ms / 1000;
        if (s < 10) return (Math.round(s * 100) / 100).toString() + " s";
        if (s < 100) return (Math.round(s * 10) / 10).toString() + " s";
        return Math.round(s).toString() + " s";
      }
      function fmtDur(ms) {
        if (ms < 1000) return Math.round(ms) + " ms";
        if (ms < 60000) return (Math.round(ms / 10) / 100) + " s";
        var m = Math.floor(ms / 60000), s = Math.round((ms % 60000) / 100) / 10;
        return m + "m " + s + "s (" + (Math.round(ms / 100) / 10) + " s)";
      }
      function clockLabel(ms) {
        var t = Math.floor(ms / 1000), h = Math.floor(t / 3600), m = Math.floor((t % 3600) / 60), s = t % 60, f = Math.floor(ms % 1000);
        function p(n, w) { n = String(n); while (n.length < w) n = "0" + n; return n; }
        return p(h, 2) + ":" + p(m, 2) + ":" + p(s, 2) + "." + p(f, 3);
      }

      /* secret masking: keys named token/key/secret/password/session */
      var SECRET_KEY = /token|secret|password|session|(^|_)key(_|$)|apikey/i;
      function maskValue(v) {
        var s = typeof v === "string" ? v : JSON.stringify(v);
        if (s == null) s = String(v);
        return s.slice(0, 2) + "••• (" + s.length + " chars, masked)";
      }
      function maskSecrets(node, hits) {
        if (Array.isArray(node)) return node.map(function (x) { return maskSecrets(x, hits); });
        if (node && typeof node === "object") {
          var out = {};
          Object.keys(node).forEach(function (k) {
            if (SECRET_KEY.test(k)) { hits.push(k); out[k] = maskValue(node[k]); }
            else out[k] = maskSecrets(node[k], hits);
          });
          return out;
        }
        return node;
      }

      /* ---------------- parsing ---------------- */
      var LINE_RE = /^(\S+)\s+(->|<-)\s+(text|binary|ping|pong|close)(?:\s+([\s\S]*))?$/i;
      function parseTimestamp(tok) {
        var m = tok.match(/^(\d{1,2}):(\d{2}):(\d{2})(?:\.(\d{1,3}))?$/);
        if (m) {
          var frac = m[4] ? parseInt((m[4] + "000").slice(0, 3), 10) : 0;
          return { ms: ((+m[1]) * 3600 + (+m[2]) * 60 + (+m[3])) * 1000 + frac, kind: "clock" };
        }
        if (/^\d+(?:\.\d+)?$/.test(tok)) return { ms: parseFloat(tok), kind: "offset" };
        return null;
      }

      function parseTranscript(text) {
        var lines = text.split(/\r?\n/);
        var frames = [], unparsable = [], kinds = {};
        lines.forEach(function (raw, i) {
          var lineNo = i + 1;
          if (!raw.trim()) return;
          var m = raw.match(LINE_RE);
          if (!m) { unparsable.push({ line: lineNo, raw: raw }); return; }
          var ts = parseTimestamp(m[1]);
          if (!ts) { unparsable.push({ line: lineNo, raw: raw }); return; }
          kinds[ts.kind] = true;
          frames.push({
            line: lineNo, tsRaw: m[1], ts: ts.ms, kind: ts.kind,
            dir: m[2], type: m[3].toLowerCase(),
            payload: (m[4] || "").trim()
          });
        });
        var fmt = Object.keys(kinds).length > 1 ? "mixed" : (kinds.clock ? "clock" : (kinds.offset ? "offset" : "none"));
        return { frames: frames, unparsable: unparsable, format: fmt, totalLines: lines.filter(function (l) { return l.trim(); }).length };
      }

      /* ---------------- audit ---------------- */
      function audit(text, cap) {
        var parsed = parseTranscript(text);
        var frames = parsed.frames;
        var findings = [];
        function add(sev, line, title, detail) { findings.push({ sev: sev, line: line, title: title, detail: detail || "" }); }

        if (!text.trim()) return { empty: true };
        if (frames.length === 0) {
          parsed.unparsable.forEach(function (u) {
            add("fault", u.line, "Line could not be parsed", "Excluded from the audit. It does not match TIMESTAMP DIRECTION TYPE PAYLOAD: " + truncate(u.raw));
          });
          return finish(parsed, frames, findings, {
            noFrames: true,
            stats: { byDir: { "->": 0, "<-": 0 }, byType: { text: 0, binary: 0, ping: 0, pong: 0, close: 0 }, binary: 0, maskedLines: [] },
            gaps: [], longest: null, duration: 0, closeFrames: [], missingClose: false,
            handshakeDone: false, pendingPings: [], maxPayload: { len: 0, line: null }
          });
        }

        /* per-frame pass: lifecycle, payload checks, close decode */
        var stats = {
          byDir: { "->": 0, "<-": 0 },
          byType: { text: 0, binary: 0, ping: 0, pong: 0, close: 0 },
          binary: 0, maskedLines: []
        };
        var closeFrames = [], seenClose = null, handshakeDone = false;
        var pendingPings = []; /* {frame} awaiting a pong from the opposite direction */
        var maxPayload = { len: 0, line: null };

        frames.forEach(function (f, idx) {
          stats.byDir[f.dir]++; stats.byType[f.type]++;
          if (f.payload.length > maxPayload.len) maxPayload = { len: f.payload.length, line: f.line };

          /* lifecycle: anything after a close */
          if (seenClose && !handshakeDone) {
            if (f.type === "close" && f.dir !== seenClose.dir) {
              handshakeDone = true;
              add("info", f.line, "Close handshake completed",
                "The second close came from the other side — this is the normal two-sided close handshake, not a fault.");
            } else {
              add("fault", f.line, "Frame after a close frame",
                "A " + f.type + " frame appears after the close on line " + seenClose.line + ". Once a close frame is sent, the only legitimate next frame is the other side's closing reply.");
            }
          } else if (seenClose && handshakeDone) {
            add("fault", f.line, "Frame after the close handshake completed",
              "The session was fully closed by line " + closeFrames[closeFrames.length - 1].line + "; nothing should follow.");
          }

          /* heartbeat pairing */
          if (f.type === "ping") {
            pendingPings.push(f);
          } else if (f.type === "pong") {
            var pi = -1;
            for (var j = 0; j < pendingPings.length; j++) { if (pendingPings[j].dir !== f.dir) { pi = j; break; } }
            if (pi >= 0) { f.answeredPing = pendingPings[pi]; pendingPings.splice(pi, 1); }
            else add("fault", f.line, "Pong with no preceding ping", "A pong arrived from " + dirName(f.dir) + " but no unanswered ping from the other side precedes it in the transcript.");
          }

          /* payload checks */
          if (f.type === "text") {
            var p = f.payload;
            if (p.charAt(0) === "{" || p.charAt(0) === "[") {
              try {
                var obj = JSON.parse(p);
                f.json = obj;
                var hits = [];
                f.masked = maskSecrets(obj, hits);
                f.secretKeys = hits;
                if (hits.length) stats.maskedLines.push(f.line);
              } catch (e) {
                add("fault", f.line, "Invalid JSON in text frame",
                  "The payload starts with '" + p.charAt(0) + "' so it claims to be JSON, but it does not parse (" + e.message + "). The raw payload is not echoed here.");
              }
            }
          }
          if (f.type === "binary") stats.binary++;
          if (f.payload.length > cap) {
            add("fault", f.line, "Oversized frame",
              "Payload is " + f.payload.length.toLocaleString() + " characters, over the cap of " + cap.toLocaleString() + ". Oversized frames are a classic trigger for 1009 (Message Too Big) closes and proxy buffer limits.");
          }

          /* close decode */
          if (f.type === "close") {
            closeFrames.push(f);
            if (!seenClose) seenClose = f;
            var cm = f.payload.match(/^(\d{3,4})\b\s*([\s\S]*)$/);
            if (cm) {
              f.closeCode = parseInt(cm[1], 10); f.closeReason = cm[2] || "";
              var d = decodeClose(f.closeCode);
              f.closeDecode = d;
              if (!d.known) {
                add("fault", f.line, "Unknown close code " + f.closeCode, d.note + (f.closeReason ? " Logged reason: " + f.closeReason : ""));
              } else if (d.reserved) {
                add("fault", f.line, "Reserved close code " + f.closeCode + " (" + d.name + ") appears in the log", d.note);
              }
              if (ERROR_CLOSE[f.closeCode]) {
                add("fault", f.line, "Session closed with error code " + f.closeCode + " (" + d.name + ")",
                  d.note + (f.closeReason ? " Reason given: " + f.closeReason : " No reason string was logged."));
              }
            } else if (f.payload === "") {
              f.closeCode = null;
              add("info", f.line, "Close frame carried no code",
                "A close with no status code is what the receiving side reports as 1005 (No Status Received) — 1005 itself must never appear on the wire.");
            } else {
              add("warning", f.line, "Close frame payload has no numeric code",
                "The close payload does not start with a 3–4 digit code, so no code can be decoded: " + truncate(f.payload));
            }
          }
        });

        /* gaps */
        var gaps = [];
        for (var i = 1; i < frames.length; i++) {
          gaps.push({ ms: frames[i].ts - frames[i - 1].ts, from: frames[i - 1], to: frames[i] });
        }
        var longest = null;
        gaps.forEach(function (g) { if (!longest || g.ms > longest.ms) longest = g; });
        var duration = frames.length > 1 ? frames[frames.length - 1].ts - frames[0].ts : 0;

        /* unanswered pings left at end of transcript */
        pendingPings.forEach(function (pf) {
          var later = frames.filter(function (x) { return x.line > pf.line; });
          add("fault", pf.line, "Ping never answered",
            "This ping from " + dirName(pf.dir) + " has no following pong anywhere in the transcript." +
            (later.length ? "" : " It is the last frame of the session — the peer had already stopped responding."));
        });

        /* missing close frame */
        var missingClose = closeFrames.length === 0;
        if (missingClose && frames.length) {
          add("major", frames[frames.length - 1].line, "No close frame — abnormal termination (the 1006 pattern)",
            "The transcript ends without any close frame from either side. In RFC 6455 terms the receiving endpoint would report this as 1006 Abnormal Closure: no close frame arrived, the connection simply dropped or was cut.");
        }

        /* heartbeat absent */
        if (duration > 60000 && stats.byType.ping + stats.byType.pong === 0) {
          add("warning", null, "No heartbeat in a " + fmtSec(duration) + " session",
            "The session ran longer than 60 seconds with zero ping/pong frames. Nothing kept the connection warm, so any idle timeout along the path — proxy, load balancer, NAT — could kill it silently and neither endpoint would know until the next send failed.");
        }

        /* idle-timeout pattern heuristic */
        var bigGaps = gaps.filter(function (g) { return g.ms >= 20000; });
        var boundary = gaps.filter(function (g) { return g.ms >= 55000 && g.ms <= 65000; });
        if (boundary.length && (missingClose || pendingPings.length)) {
          var bg = boundary[0];
          add("warning", bg.to.line, "Suspected idle timeout at a ~60 s boundary (pattern heuristic)",
            "The session went silent for " + fmtSec(bg.ms) + " between lines " + bg.from.line + " and " + bg.to.line + " — a near-exact 60-second boundary — and then " +
            (missingClose ? "never closed cleanly." : "the heartbeat was never answered.") +
            " Death at a round 60 s silence is the classic signature of a proxy or load-balancer idle timeout. This is a pattern heuristic, not proof: the capture alone cannot see the middlebox.");
        } else if (bigGaps.length >= 2) {
          var tol = 1000, repeated = null;
          for (var a = 0; a < bigGaps.length && !repeated; a++)
            for (var b = a + 1; b < bigGaps.length; b++)
              if (Math.abs(bigGaps[a].ms - bigGaps[b].ms) <= tol) { repeated = bigGaps[a]; break; }
          if (repeated) {
            add("warning", repeated.to.line, "Repeated near-identical silences of ~" + fmtSec(repeated.ms) + " (pattern heuristic)",
              "Two or more long gaps in this session match within a second of each other. Repeated identical silences are the fingerprint of a fixed idle timeout — a proxy, load balancer, or NAT table entry expiring on schedule. Labeled as a pattern heuristic.");
          }
        }

        /* unparsable lines */
        parsed.unparsable.forEach(function (u) {
          add("fault", u.line, "Line could not be parsed",
            "Excluded from the audit — never silently dropped, but not counted as a frame either. It does not match TIMESTAMP DIRECTION TYPE PAYLOAD: " + truncate(u.raw));
        });

        /* secret hygiene note */
        if (stats.maskedLines.length) {
          add("info", stats.maskedLines[0], "Possible secrets masked in output",
            "Parseable JSON on line" + (stats.maskedLines.length > 1 ? "s " + stats.maskedLines.join(", ") : " " + stats.maskedLines[0]) +
            " carries keys named token/key/secret/password/session. Their values are masked (first 2 characters + length) in every output of this audit; the raw values are never echoed.");
        }

        return finish(parsed, frames, findings, {
          stats: stats, gaps: gaps, longest: longest, duration: duration,
          closeFrames: closeFrames, missingClose: missingClose, handshakeDone: handshakeDone,
          pendingPings: pendingPings, maxPayload: maxPayload
        });
      }

      function dirName(d) { return d === "->" ? "the client (->)" : "the server (<-)"; }
      function truncate(s) { s = String(s); return s.length > 90 ? s.slice(0, 90) + "…" : s; }

      function finish(parsed, frames, findings, extra) {
        var majors = findings.filter(function (f) { return f.sev === "major"; }).length;
        var faults = findings.filter(function (f) { return f.sev === "fault"; }).length;
        var warns = findings.filter(function (f) { return f.sev === "warning"; }).length;
        var verdict, vclass;
        if (extra.noFrames || majors > 0) { verdict = "DEAD OR DYING SESSION"; vclass = "dead"; }
        else if (faults > 0 || warns > 0) { verdict = "SESSION WITH FAULTS"; vclass = "faults"; }
        else { verdict = "HEALTHY SESSION"; vclass = "healthy"; }
        if (extra.noFrames) verdict = "DEAD OR DYING SESSION";
        var result = {
          parsed: parsed, frames: frames, findings: findings,
          verdict: verdict, vclass: vclass, counts: { major: majors, fault: faults, warning: warns }
        };
        Object.keys(extra).forEach(function (k) { result[k] = extra[k]; });
        return result;
      }

      /* ---------------- timeline ---------------- */
      function buildTimeline(r) {
        var frames = r.frames, out = [];
        if (!frames.length) return out;
        var first = frames[0], last = frames[frames.length - 1];
        function when(f) { return f.kind === "offset" ? "+" + (Math.round(f.ts * 10) / 10) + " ms" : f.tsRaw; }
        out.push({ when: when(first), text: "Session opens on line " + first.line + " with a " + first.type + " frame from " + dirName(first.dir) + "." });
        if (r.longest && r.longest.ms >= 1000) {
          out.push({ when: when(r.longest.to), text: "Longest silence: " + fmtSec(r.longest.ms) + " of quiet between line " + r.longest.from.line + " and line " + r.longest.to.line + "." });
        }
        var pings = frames.filter(function (f) { return f.type === "ping"; }).length;
        var pongs = frames.filter(function (f) { return f.type === "pong"; }).length;
        if (pings + pongs > 0) out.push({ when: "heartbeat", text: pings + " ping" + (pings === 1 ? "" : "s") + " / " + pongs + " pong" + (pongs === 1 ? "" : "s") + " exchanged" + (r.pendingPings && r.pendingPings.length ? "; " + r.pendingPings.length + " ping(s) never answered." : "; every ping answered.") });
        if (r.closeFrames && r.closeFrames.length) {
          r.closeFrames.forEach(function (cf) {
            out.push({ when: when(cf), text: "Close from " + dirName(cf.dir) + " on line " + cf.line + (cf.closeCode ? " — code " + cf.closeCode + " (" + (cf.closeDecode ? cf.closeDecode.name : "") + ")" + (cf.closeReason ? ", reason: " + cf.closeReason : "") + "." : " — no code carried.") });
          });
          if (r.handshakeDone) out.push({ when: when(last), text: "Close handshake completed on both sides — the textbook ending." });
        } else {
          out.push({ when: when(last), text: "Transcript ends on line " + last.line + " with no close frame from either side. The session has no ending — it just stops." });
        }
        return out;
      }

      /* ---------------- outputs ---------------- */
      function framePreview(f) {
        if (!f.payload) return "";
        if (f.type === "close") return f.payload;
        if (f.json !== undefined) {
          var hits = [];
          var masked = maskSecrets(f.json, hits);
          var s = JSON.stringify(masked);
          return truncate(s);
        }
        return truncate(f.payload);
      }

      function buildSummary(r) {
        var L = [];
        L.push("WebSocket session audit — J-Dawgs WebSocket Session Trace Auditor™");
        L.push("Verdict: " + r.verdict);
        L.push("Frames parsed: " + r.frames.length + " (" + r.stats.byDir["->"] + " client ->, " + r.stats.byDir["<-"] + " <- server)" +
          (r.parsed.unparsable.length ? "; " + r.parsed.unparsable.length + " line(s) unparsable and excluded" : ""));
        L.push("Timestamp format detected: " + (r.parsed.format === "clock" ? "clock times" : r.parsed.format === "offset" ? "millisecond offsets" : r.parsed.format));
        L.push("Duration: " + fmtDur(r.duration) + " · Longest silence: " + (r.longest ? fmtSec(r.longest.ms) : "n/a"));
        if (r.closeFrames.length) {
          var cf = r.closeFrames[0];
          L.push("Close: " + (cf.closeCode ? "code " + cf.closeCode + " (" + (cf.closeDecode ? cf.closeDecode.name : "") + ")" + (cf.closeReason ? " — " + cf.closeReason : "") : "close frame with no code") +
            (r.handshakeDone ? " · handshake completed by both sides" : " · only one side closed"));
        } else {
          L.push("Close: none — no close frame in the transcript (abnormal termination, the 1006 pattern)");
        }
        L.push("");
        if (r.findings.length) {
          L.push("Findings (" + r.findings.length + "):");
          r.findings.forEach(function (f) {
            L.push("- [" + f.sev.toUpperCase() + "]" + (f.line ? " Line " + f.line + ":" : "") + " " + f.title + (f.detail ? " — " + f.detail : ""));
          });
        } else {
          L.push("Findings: none. Heartbeats answered, payloads valid, close handshake completed cleanly.");
        }
        L.push("");
        L.push("Audited locally from the pasted transcript only; frames the capture did not record are invisible to this audit. Secret values in JSON payloads are masked in this summary.");
        return L.join("\n");
      }

      function buildJSON(r) {
        return {
          tool: "J-Dawgs WebSocket Session Trace Auditor™",
          verdict: r.verdict,
          timestampFormatDetected: r.parsed.format,
          stats: {
            framesParsed: r.frames.length,
            unparsableLines: r.parsed.unparsable.map(function (u) { return u.line; }),
            durationMs: r.duration,
            longestGapMs: r.longest ? r.longest.ms : null,
            byDirection: { clientToServer: r.stats.byDir["->"], serverToClient: r.stats.byDir["<-"] },
            byType: r.stats.byType,
            binaryFrames: r.stats.binary,
            largestPayloadChars: r.maxPayload.len,
            close: r.closeFrames.length ? r.closeFrames.map(function (cf) {
              return { line: cf.line, direction: cf.dir, code: cf.closeCode, name: cf.closeDecode ? cf.closeDecode.name : null, reason: cf.closeReason || "" };
            }) : null,
            closeHandshakeCompleted: !!r.handshakeDone,
            missingCloseFrame: !!r.missingClose
          },
          timeline: buildTimeline(r).map(function (t) { return { at: t.when, event: t.text }; }),
          frames: r.frames.map(function (f) {
            return { line: f.line, timestamp: f.tsRaw, timestampMs: f.ts, direction: f.dir, type: f.type, payloadPreviewMasked: framePreview(f) };
          }),
          findings: r.findings.map(function (f) {
            return { severity: f.sev, line: f.line, title: f.title, detail: f.detail };
          })
        };
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "DYING_SAMPLE": (typeof DYING_SAMPLE !== 'undefined' ? DYING_SAMPLE : undefined), "HEALTHY_SAMPLE": (typeof HEALTHY_SAMPLE !== 'undefined' ? HEALTHY_SAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-websocket-session-trace-auditor',
  name: 'J-Dawgs WebSocket Session Trace Auditor',
  description: 'Live debuggers only see an open socket; ours audits a pasted session transcript that already ended — unanswered pings, the fatal silence, close codes decoded, missing close frame — one verdict: HEALTHY / FAULTS / DEAD OR DYING.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "DYING_SAMPLE": __core["DYING_SAMPLE"], "HEALTHY_SAMPLE": __core["HEALTHY_SAMPLE"] }
};
