'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Elasticsearch Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var RISKY = [
        "# Risky example - expected verdict: DO NOT DEPLOY",
        "cluster.name: jdawgs-search",
        "node.name: node-1",
        "network.host: 0.0.0.0",
        "xpack.security.enabled: false",
        "action.destructive_requires_name: false",
        'reindex.remote.whitelist: ["*"]',
        "xpack.security.authc.realms.file.file1.users.admin.password: FakePassword_DoNotUse_123"
      ].join("\n");

      var HARDENED = [
        "# Hardened example - expected verdict: SAFE TO DEPLOY",
        "cluster.name: jdawgs-search",
        "node.name: node-1",
        "network.host: _site_",
        "xpack.security.enabled: true",
        "xpack.security.transport.ssl.enabled: true",
        "xpack.security.http.ssl.enabled: true",
        "discovery.type: single-node",
        "bootstrap.memory_lock: true",
        "action.destructive_requires_name: true",
        "script.allowed_types: none"
      ].join("\n");

      var PASS_IT_ON = [
        "Pass it on - more J-Dawgs tools worth handing to your AI:",
        "",
        "AI Tool Store - the tool store where the AI is the customer. Practical, tested tools an agent can pick up and use right away:",
        "https://muse.ai/s/ai-tool-store-xng6xkxwjkxl2xab/UoF72OkKI7j33Q2ITxmrZyIr4nv40QtYfj2AgESh_k8",
        "",
        "Agent Exchange - where AI agents hire verified human hands for the parts of a job that need a person in the physical world:",
        "https://muse.ai/s/j-dawgs-agent-exchange-ih6xlnihzxdhxc/ZbleqxFHRE0NcswaBkyN13y9lLp5rPAgHTb6t8ii-PY",
        "",
        "Stream It, Search It, Revoke It Right Stack - Kafka Config Safety Auditor + Elasticsearch Config Safety Auditor + Employee Offboarding Access Revocation Auditor: grade the broker, grade the search cluster, prove every access is revoked"
      ].join("\n");

      var KNOWN_KEYS = {
        "network.host": 1, "network.bind_host": 1, "network.publish_host": 1,
        "xpack.security.enabled": 1,
        "xpack.security.transport.ssl.enabled": 1,
        "xpack.security.http.ssl.enabled": 1,
        "discovery.type": 1, "discovery.seed_hosts": 1,
        "cluster.initial_master_nodes": 1, "cluster.name": 1,
        "http.port": 1, "transport.port": 1,
        "path.data": 1, "path.logs": 1,
        "bootstrap.memory_lock": 1,
        "action.destructive_requires_name": 1,
        "reindex.remote.whitelist": 1,
        "script.allowed_types": 1,
        "node.name": 1, "node.roles": 1
      };
      var LIST_KEYS = {
        "discovery.seed_hosts": 1, "cluster.initial_master_nodes": 1,
        "reindex.remote.whitelist": 1, "network.host": 1,
        "path.data": 1, "path.logs": 1, "node.roles": 1
      };
      var SECRET_RE = /password|secret|keystore|token|api_key|api-key/;

      function $(id) { return document.getElementById(id); }
      function esc(s) {
        return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
      }
      function cleanScalar(s) {
        var v = String(s).trim();
        v = v.replace(/\s+#.*$/, "");
        if ((v.charAt(0) === '"' && v.charAt(v.length - 1) === '"') ||
            (v.charAt(0) === "'" && v.charAt(v.length - 1) === "'")) {
          v = v.slice(1, -1);
        }
        return v.trim();
      }
      function stripInlineComment(v) {
        var t = String(v).trim();
        if (t.charAt(0) === '"' || t.charAt(0) === "'") {
          var q = t.charAt(0), end = t.indexOf(q, 1);
          return end === -1 ? t : t.slice(0, end + 1);
        }
        return t.replace(/\s+#.*$/, "").trim();
      }
      function isTrue(v) { return String(v).toLowerCase() === "true"; }
      function isFalse(v) { return String(v).toLowerCase() === "false"; }

      function parseConfig(text) {
        var lines = String(text).split(/\r\n|\r|\n/);
        var entries = [], notParsed = [], commented = [], lastKey = null;
        for (var i = 0; i < lines.length; i++) {
          var raw = lines[i], n = i + 1, trimmed = raw.trim();
          if (trimmed === "") { continue; }
          if (trimmed.charAt(0) === "#") {
            var cm = trimmed.slice(1).trim().match(/^([A-Za-z0-9_.\-]+)\s*:/);
            if (cm) { commented.push({ key: cm[1], line: n }); }
            continue;
          }
          var indented = /^\s/.test(raw);
          var lm = trimmed.match(/^-\s+(.*)$/);
          if (lm) {
            if (lastKey && LIST_KEYS[lastKey.key] && lastKey.blockList) {
              lastKey.items.push(cleanScalar(lm[1]));
            } else {
              notParsed.push({ line: n, reason: lastKey
                ? "List item under a key this auditor does not read as a list (" + lastKey.key + ")"
                : "List item with no parent key above it" });
            }
            continue;
          }
          if (indented) {
            notParsed.push({ line: n, reason: "Indented line - nested YAML is outside this line-based audit" });
            continue;
          }
          var kv = raw.match(/^([A-Za-z0-9_.\-]+)\s*:\s*(.*)$/);
          if (!kv) {
            notParsed.push({ line: n, reason: "Not a key: value line, a comment, or a list item" });
            continue;
          }
          var key = kv[1];
          var val = stripInlineComment(kv[2]);
          var entry = { key: key, value: val, line: n, items: null, blockList: val === "" };
          if (val.charAt(0) === "[") {
            var inner = val.replace(/^\[/, "").replace(/\]$/, "");
            entry.items = inner === "" ? [] : inner.split(",").map(cleanScalar).filter(function (x) { return x !== ""; });
            entry.value = entry.items.join(", ");
            entry.blockList = false;
          } else if (val !== "") {
            entry.value = cleanScalar(val);
          }
          entries.push(entry);
          lastKey = entry;
        }
        return { entries: entries, notParsed: notParsed, commented: commented };
      }

      function listOf(entry) {
        if (!entry) { return []; }
        if (entry.items && entry.items.length) { return entry.items.slice(); }
        if (entry.value === "" || entry.value == null) { return []; }
        return String(entry.value).split(/[,\s]+/).map(cleanScalar).filter(function (x) { return x !== ""; });
      }
      function classifyBind(tokens) {
        if (!tokens.length) { return "unset"; }
        var nonLoop = false;
        for (var i = 0; i < tokens.length; i++) {
          var s = String(tokens[i]).toLowerCase();
          if (s === "localhost" || s === "_local_" || s === "_loopback_" || s === "::1" || s.indexOf("127.") === 0) { continue; }
          nonLoop = true;
        }
        return nonLoop ? "non-loopback" : "loopback";
      }
      function normHost(h) { return String(h).toLowerCase().replace(/:\d+$/, ""); }

      function audit(text, version) {
        var parsed = parseConfig(text);
        var entries = parsed.entries;
        var findings = [];
        function add(sev, lines, title, short, detail, fix) {
          findings.push({ sev: sev, lines: lines, title: title, short: short, detail: detail, fix: fix });
        }
        var eff = {}, byKey = {}, i, e;
        for (i = 0; i < entries.length; i++) {
          e = entries[i];
          eff[e.key] = e;
          (byKey[e.key] = byKey[e.key] || []).push(e);
        }
        function val(key) { var en = eff[key]; return en && en.value !== "" ? en.value : null; }

        // Secrets: flagged by key name and line only; the value is never read into any output.
        for (i = 0; i < entries.length; i++) {
          e = entries[i];
          if (SECRET_RE.test(e.key.toLowerCase())) {
            add("WARNING", [e.line], "Secret material in plain config: " + e.key,
              "Secret stored in plain config (key name only)",
              "Key \"" + e.key + "\" on line " + e.line + " holds secret material in a plain-text config file. Its value is intentionally not shown anywhere in this tool's findings, report, or summary.",
              "Move it to the keystore or an environment/secret manager, and rotate it - it has been sitting in plain text.");
          }
        }
        // Duplicates: last value wins, both lines named.
        Object.keys(byKey).forEach(function (k) {
          var arr = byKey[k];
          if (arr.length > 1) {
            var ls = arr.map(function (x) { return x.line; });
            add("WARNING", ls, "Duplicate key: " + k,
              "Duplicate key (last value wins)",
              "\"" + k + "\" is set on lines " + ls.join(" and ") + ". YAML last-value-wins: the setting on line " + ls[ls.length - 1] + " is the one that takes effect; the earlier line is silently ignored.",
              "Delete the stale line so the config says one thing in one place.");
          }
        });

        var netEntry = eff["network.host"];
        var bindTokens = listOf(netEntry);
        var bindClass = classifyBind(bindTokens);
        var secEntry = eff["xpack.security.enabled"];
        var secVal = val("xpack.security.enabled");
        var secState = secVal == null ? "unset" : (isTrue(secVal) ? "true" : (isFalse(secVal) ? "false" : "other"));
        var discoveryType = val("discovery.type");
        var seedEntry = eff["discovery.seed_hosts"], masterEntry = eff["cluster.initial_master_nodes"];
        var seedHosts = listOf(seedEntry), masterNodes = listOf(masterEntry);
        var multiNode = discoveryType !== "single-node" &&
          (seedHosts.length > 1 || masterNodes.length > 1 || (seedHosts.length >= 1 && masterNodes.length >= 1));

        // Public bind without security confirmed on.
        if (bindClass === "non-loopback" && secState !== "true") {
          var bindLines = secEntry && secState === "false" ? [netEntry.line, secEntry.line] : [netEntry.line];
          if (secState === "false") {
            add("BLOCKER", bindLines, "Public bind with security switched off",
              "Public bind without security",
              "network.host is \"" + bindTokens.join(", ") + "\" (line " + netEntry.line + "), which binds beyond this machine, and xpack.security.enabled is false (line " + secEntry.line + "). Anyone who can reach the port gets full, unauthenticated access to every index.",
              "Set xpack.security.enabled: true and configure users/TLS - or bind to loopback until security is on.");
          } else if (secState === "unset") {
            if (version === "es7") {
              add("BLOCKER", bindLines, "Public bind, security off by the 7.x default",
                "Public bind without security",
                "network.host is \"" + bindTokens.join(", ") + "\" (line " + netEntry.line + ") and xpack.security.enabled is not set. On Elasticsearch 7.x security is disabled by default, so this node would serve unauthenticated traffic on a non-loopback interface.",
                "Set xpack.security.enabled: true explicitly and configure authentication before this binds publicly.");
            } else if (version === "es8" || version === "opensearch") {
              add("WARNING", bindLines, "Public bind relying on the version default for security",
                "Public bind relying on a silent security default",
                "network.host is \"" + bindTokens.join(", ") + "\" (line " + netEntry.line + ") and xpack.security.enabled is not set. The version you selected enables security by default, so the node is probably protected - but the config itself does not say so, and a version change would silently change the grade.",
                "Set xpack.security.enabled: true explicitly so the posture survives version changes.");
            } else {
              add("BLOCKER", bindLines, "Public bind, security state NOT SETTLED (version unknown)",
                "Public bind without confirmed security (NOT SETTLED)",
                "network.host is \"" + bindTokens.join(", ") + "\" (line " + netEntry.line + ") and xpack.security.enabled is not set. Whether security is on depends on the version - enabled by default in Elasticsearch 8.x, disabled by default in 7.x - and no version was given, so this grade is NOT SETTLED and is counted as a blocker until it is.",
                "Pick the cluster version above, or set xpack.security.enabled: true explicitly.");
            }
          } else {
            add("BLOCKER", bindLines, "Public bind, security not confirmed on",
              "Public bind without security",
              "network.host is \"" + bindTokens.join(", ") + "\" (line " + netEntry.line + ") binds beyond this machine, and xpack.security.enabled is \"" + secVal + "\", not true.",
              "Set xpack.security.enabled: true before this node binds beyond loopback.");
          }
        }
        // Security explicitly off where check 1 did not already cover it.
        if (secState === "false" && bindClass !== "non-loopback") {
          if (bindClass === "loopback") {
            add("WARNING", [secEntry.line], "Security explicitly disabled on a loopback bind",
              "Security disabled (loopback bind)",
              "xpack.security.enabled is false (line " + secEntry.line + "). The bind is loopback-only today, so exposure is limited to this machine - but the moment network.host widens, this becomes a blocker.",
              "Turn security on, or keep this node loopback-only and treat it as a throwaway dev node.");
          } else {
            add("WARNING", [secEntry.line], "Security explicitly disabled, bind not set",
              "Security disabled (bind not set)",
              "xpack.security.enabled is false (line " + secEntry.line + ") and network.host is not set. If this node is ever given a non-loopback bind, it is wide open.",
              "Set xpack.security.enabled: true before any non-loopback bind is added.");
          }
        }
        // Single-node discovery.
        if (discoveryType === "single-node") {
          add("INFO", [eff["discovery.type"].line], "Single-node discovery",
            "Single-node discovery",
            "discovery.type is single-node (line " + eff["discovery.type"].line + "): no cluster formation, no replicas, no failover. It is a legitimate dev/small-setup choice, but it does not make an exposed node safe - a single node with security off and a public bind is still fully open.",
            "Fine for local/dev use. For production, form a real cluster or keep the bind on loopback with security on.");
        }
        // Seed hosts vs initial master nodes.
        if (seedEntry && masterEntry && seedHosts.length && masterNodes.length) {
          var seedSet = {};
          seedHosts.forEach(function (h) { seedSet[normHost(h)] = 1; });
          var missing = masterNodes.filter(function (m) { return !seedSet[normHost(m)]; });
          if (missing.length) {
            add("WARNING", [masterEntry.line, seedEntry.line], "Master nodes missing from seed hosts",
              "Master nodes not in seed hosts",
              "cluster.initial_master_nodes (line " + masterEntry.line + ") names " + missing.join(", ") + ", which do" + (missing.length === 1 ? "es" : "") + " not appear in discovery.seed_hosts (line " + seedEntry.line + "). A node that cannot be discovered cannot join or be elected cleanly, and the mismatch usually means one list was edited without the other.",
              "Make the two lists agree: every initial master node should also be reachable through discovery.seed_hosts.");
          }
        }
        // Ports.
        var hp = eff["http.port"];
        if (hp && hp.value !== "") {
          add("INFO", [hp.line], "Custom http.port: " + hp.value,
            "Custom http.port noted",
            "http.port is set to " + hp.value + " (line " + hp.line + ")" + (hp.value === "9200" ? " - the standard default, set explicitly." : " instead of the default 9200.") + " Not a risk by itself; clients, firewalls, and load balancers must expect the same port.",
            "No change needed if every client and firewall rule already uses this port.");
        }
        var tp = eff["transport.port"];
        if (tp && tp.value !== "") {
          add("INFO", [tp.line], "Custom transport.port: " + tp.value,
            "Custom transport.port noted",
            "transport.port is set to " + tp.value + " (line " + tp.line + ")" + (tp.value === "9300" ? " - the standard default, set explicitly." : " instead of the default 9300.") + " Every node in the cluster must agree on it, and it must never be exposed outside the cluster network.",
            "Confirm all nodes use the same transport port and that it is firewalled from outside the cluster.");
        }
        // Paths on root or world-writable locations.
        ["path.data", "path.logs"].forEach(function (k) {
          var en = eff[k];
          if (!en) { return; }
          listOf(en).forEach(function (p) {
            var lp = p.toLowerCase();
            if (lp === "/" || lp === "c:\\" || lp === "c:/" || lp.indexOf("/tmp") === 0 || lp.indexOf("/var/tmp") === 0) {
              add("WARNING", [en.line], k + " on a root or world-writable path",
                k + " on a risky path",
                k + " points at \"" + p + "\" (line " + en.line + ") - the filesystem root or a world-writable shared directory. Data there is exposed to every local user and can vanish with temp cleanup.",
                "Move it to a dedicated directory owned by the service account, e.g. /var/lib/elasticsearch or /var/log/elasticsearch.");
            }
          });
        });
        // Memory lock.
        var ml = val("bootstrap.memory_lock");
        if (ml != null && isFalse(ml)) {
          if (bindClass === "non-loopback") {
            add("WARNING", [eff["bootstrap.memory_lock"].line], "bootstrap.memory_lock is off on a non-loopback node",
              "Memory lock off",
              "bootstrap.memory_lock is false (line " + eff["bootstrap.memory_lock"].line + ") while the node binds beyond loopback. The JVM heap can be swapped to disk, which hurts performance and can leave index data in the swap file.",
              "Set bootstrap.memory_lock: true (and grant the service the memlock limit it needs).");
          } else {
            add("INFO", [eff["bootstrap.memory_lock"].line], "bootstrap.memory_lock is off",
              "Memory lock off (local bind)",
              "bootstrap.memory_lock is false (line " + eff["bootstrap.memory_lock"].line + "). Acceptable on a local/dev node; on a production node the heap can be swapped to disk.",
              "Set it to true for production nodes.");
          }
        }
        // Wildcard deletion.
        var drn = val("action.destructive_requires_name");
        if (drn != null && isFalse(drn)) {
          add("BLOCKER", [eff["action.destructive_requires_name"].line], "Wildcard index deletion allowed",
            "Wildcard index deletion allowed",
            "action.destructive_requires_name is false (line " + eff["action.destructive_requires_name"].line + "). A single DELETE /* - by accident, script, or attacker - can destroy every index at once.",
            "Set action.destructive_requires_name: true so destructive calls must name their targets.");
        }
        // Reindex whitelist.
        var rw = eff["reindex.remote.whitelist"];
        if (rw) {
          var rwTokens = listOf(rw);
          var star = rwTokens.some(function (t) { return t.indexOf("*") !== -1; });
          if (star) {
            add("BLOCKER", [rw.line], "Reindex remote whitelist is wide open",
              "Reindex whitelist contains *",
              "reindex.remote.whitelist (line " + rw.line + ") contains a wildcard, so this node will pull reindex data from any remote host it can reach - an open door for data movement to or from anywhere.",
              "List only the specific host:port pairs you actually reindex from.");
          }
        }
        // Scripting posture.
        var sat = val("script.allowed_types");
        if (sat != null) {
          var satLow = sat.toLowerCase();
          var posture = satLow === "none"
            ? "No script types are allowed - the safest posture."
            : (satLow.indexOf("inline") !== -1
              ? "Inline scripts are allowed: any user who can reach the API can run arbitrary code in queries - a real risk on a shared or exposed node."
              : "Posture: " + sat + ". Stored-only scripting is the middle ground; inline is the risky end.");
          add("INFO", [eff["script.allowed_types"].line], "Scripting posture: " + sat,
            "Scripting posture noted",
            "script.allowed_types is \"" + sat + "\" (line " + eff["script.allowed_types"].line + "). " + posture,
            satLow === "none" ? "No change needed." : "If nothing depends on inline scripts, tighten this to stored or none.");
        }
        // TLS explicitly off.
        [["xpack.security.transport.ssl.enabled", "Transport (node-to-node)"],
         ["xpack.security.http.ssl.enabled", "HTTP (client-to-node)"]].forEach(function (pair) {
          var v = val(pair[0]);
          if (v == null || !isFalse(v)) { return; }
          var en = eff[pair[0]];
          if (multiNode) {
            add("WARNING", [en.line], pair[1] + " TLS is off on a multi-node setup",
              pair[1] + " TLS off (multi-node)",
              pair[0] + " is false (line " + en.line + ") while this config describes more than one node. " + pair[1] + " traffic - which can include credentials and index data - crosses the network unencrypted.",
              "Enable " + pair[0] + " and distribute certificates to every node.");
          } else {
            add("INFO", [en.line], pair[1] + " TLS is off",
              pair[1] + " TLS off",
              pair[0] + " is false (line " + en.line + "). Tolerable on a single local node; on anything multi-node or non-loopback it leaves traffic unencrypted.",
              "Enable TLS before this config grows beyond one local node.");
          }
        });

        // Silent defaults: security-relevant keys not set at all (commented counts as not set).
        var defaults = [];
        if (!secEntry) {
          defaults.push({
            key: "xpack.security.enabled", settled: version !== "unknown",
            note: version === "es8" || version === "opensearch"
              ? "Not set. For the version you selected, security is enabled by default - settled - but say it explicitly so the posture survives version changes."
              : version === "es7"
                ? "Not set. On Elasticsearch 7.x security is disabled by default - settled - so an unset key means security is off."
                : "Not set. Whether security is on depends entirely on the version - enabled by default in Elasticsearch 8.x, disabled by default in 7.x - and no version was given, so this is NOT SETTLED and nothing here assumes it is on."
          });
        }
        if (!netEntry) {
          defaults.push({ key: "network.host", settled: true,
            note: "Not set. The usual default binds loopback only (development mode). Set it explicitly so the deployment mode is a decision, not an accident." });
        }
        if (!eff["xpack.security.transport.ssl.enabled"]) {
          defaults.push({ key: "xpack.security.transport.ssl.enabled", settled: false,
            note: "Not set. On a multi-node setup this auditor does not assume transport TLS is on - confirm it and set it explicitly." });
        }
        if (!eff["xpack.security.http.ssl.enabled"]) {
          defaults.push({ key: "xpack.security.http.ssl.enabled", settled: false,
            note: "Not set. This auditor does not assume HTTP TLS is on - confirm it and set it explicitly." });
        }
        if (!eff["action.destructive_requires_name"]) {
          defaults.push({ key: "action.destructive_requires_name", settled: false,
            note: "Not set. The safe behavior (destructive calls must name their targets) is version-dependent - set it to true explicitly rather than trusting a default." });
        }
        if (!eff["bootstrap.memory_lock"]) {
          defaults.push({ key: "bootstrap.memory_lock", settled: false,
            note: "Not set. This auditor does not assume the heap is locked in memory - set it to true for production nodes." });
        }
        if (!eff["script.allowed_types"]) {
          defaults.push({ key: "script.allowed_types", settled: false,
            note: "Not set. The effective scripting posture depends on version defaults - set it explicitly (none is the safest)." });
        }

        var notAudited = entries.filter(function (en) {
          return !KNOWN_KEYS[en.key] && !SECRET_RE.test(en.key.toLowerCase());
        }).map(function (en) { return { key: en.key, line: en.line }; });

        var sevRank = { BLOCKER: 0, WARNING: 1, INFO: 2 };
        findings.sort(function (a, b) {
          return sevRank[a.sev] - sevRank[b.sev] || a.lines[0] - b.lines[0];
        });
        var counts = { BLOCKER: 0, WARNING: 0, INFO: 0 };
        findings.forEach(function (f) { counts[f.sev]++; });
        var verdict = counts.BLOCKER > 0 ? "DO NOT DEPLOY" : (counts.WARNING > 0 ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY");
        return {
          parsed: parsed, findings: findings, counts: counts, verdict: verdict,
          defaults: defaults, notAudited: notAudited, version: version,
          empty: entries.length === 0
        };
      }

      function lineLabel(lines) {
        return lines.length === 1 ? "Line " + lines[0] : "Lines " + lines.join(", ");
      }
      var VERSION_LABEL = {
        unknown: "Unknown (default-dependent grades NOT SETTLED)",
        es7: "Elasticsearch 7.x", es8: "Elasticsearch 8.x", opensearch: "OpenSearch"
      };

      function buildReport(r) {
        var out = [];
        out.push("J-Dawgs Elasticsearch Config Safety Auditor - Audit Report");
        out.push("Verdict: " + r.verdict);
        out.push("Cluster version: " + VERSION_LABEL[r.version]);
        out.push("Counts: " + r.counts.BLOCKER + " BLOCKER / " + r.counts.WARNING + " WARNING / " + r.counts.INFO + " INFO / " +
          r.parsed.notParsed.length + " NOT PARSED / " + r.notAudited.length + " NOT AUDITED");
        out.push("");
        out.push("Findings:");
        if (!r.findings.length) { out.push("  (none)"); }
        r.findings.forEach(function (f) {
          out.push("[" + f.sev + "] " + lineLabel(f.lines) + " - " + f.title);
          out.push("  " + f.detail);
          out.push("  Fix: " + f.fix);
        });
        if (r.parsed.notParsed.length) {
          out.push("");
          out.push("NOT PARSED (excluded from grading):");
          r.parsed.notParsed.forEach(function (np) { out.push("  Line " + np.line + " - " + np.reason); });
        }
        if (r.notAudited.length) {
          out.push("");
          out.push("NOT AUDITED keys (listed by name and line only):");
          r.notAudited.forEach(function (na) { out.push("  " + na.key + " (line " + na.line + ")"); });
        }
        if (r.parsed.commented.length) {
          out.push("");
          out.push("Commented-out keys (treated as unset):");
          r.parsed.commented.forEach(function (c) { out.push("  " + c.key + " (line " + c.line + ")"); });
        }
        if (r.defaults.length) {
          out.push("");
          out.push("Silent defaults (security-relevant keys not set):");
          r.defaults.forEach(function (d) { out.push("  " + d.key + " - " + d.note); });
        }
        out.push("");
        out.push("Note: secret values never appear in this report. Secret-named keys are flagged by key name and line only.");
        return out.join("\n");
      }

      function buildSummary(r) {
        var parts = [];
        parts.push("Elasticsearch / OpenSearch config audit: " + r.verdict + " - " +
          r.counts.BLOCKER + " blocker(s), " + r.counts.WARNING + " warning(s), " + r.counts.INFO + " info note(s).");
        if (r.findings.length) {
          parts.push("Issues by line: " + r.findings.map(function (f) {
            return lineLabel(f.lines) + " - " + f.short;
          }).join("; ") + ".");
        } else {
          parts.push("No findings.");
        }
        if (r.version === "unknown" && r.defaults.some(function (d) { return !d.settled; })) {
          parts.push("Some default-dependent grades are NOT SETTLED - no cluster version was provided.");
        }
        parts.push("Audited locally with the J-Dawgs Elasticsearch Config Safety Auditor. This summary contains no config values and no secrets.");
        return parts.join(" ");
      }

      var lastResult = null;

      function render(r) {
        var card = $("resultsCard"), body = $("resultsBody");
        card.classList.remove("hidden");
        if (r.empty && !r.parsed.notParsed.length) {
          lastResult = null;
          body.innerHTML = '<div class="empty-note"><b>No audit ran.</b> The paste contains no <span class="mono">key: value</span> settings to grade - only blanks or comments. Paste an elasticsearch.yml, or load one of the worked examples.</div>';
          return;
        }
        lastResult = r;
        var vClass = r.verdict === "SAFE TO DEPLOY" ? "safe" : (r.verdict === "DEPLOY WITH FIXES" ? "fixes" : "no");
        var vWhy = r.verdict === "DO NOT DEPLOY"
          ? "At least one BLOCKER finding. Do not start this node on a real network until every blocker is fixed."
          : r.verdict === "DEPLOY WITH FIXES"
            ? "No blockers, but WARNING findings remain. Fix them before this faces real traffic."
            : "Zero BLOCKERs and zero WARNINGs in the audited keys. INFO notes and NOT SETTLED defaults below are still worth a read.";
        var html = "";
        html += '<div class="verdict ' + vClass + '"><div class="v-label">Verdict</div><div class="v-word">' + r.verdict + '</div><p>' + vWhy + "</p></div>";
        html += '<div class="counts">' +
          '<span class="count-chip">' + r.counts.BLOCKER + " BLOCKER</span>" +
          '<span class="count-chip">' + r.counts.WARNING + " WARNING</span>" +
          '<span class="count-chip">' + r.counts.INFO + " INFO</span>" +
          '<span class="count-chip">' + r.parsed.notParsed.length + " NOT PARSED</span>" +
          '<span class="count-chip">' + r.notAudited.length + " NOT AUDITED</span></div>";
        if (r.findings.length) {
          html += "<h3>Findings</h3>";
          r.findings.forEach(function (f) {
            html += '<div class="finding"><div class="finding-head"><span class="sev ' + f.sev.toLowerCase() + '">' + f.sev +
              '</span><span class="f-line">' + lineLabel(f.lines) + '</span><span class="f-title">' + esc(f.title) + "</span></div>" +
              "<p>" + esc(f.detail) + '</p><p class="fix"><b>Fix:</b> ' + esc(f.fix) + "</p></div>";
          });
        } else {
          html += '<div class="empty-note"><b>No findings.</b> Every audited key passed its check.</div>';
        }
        if (r.parsed.notParsed.length) {
          html += "<h3>NOT PARSED - excluded from grading</h3><ul class=\"plain-list\">";
          r.parsed.notParsed.forEach(function (np) {
            html += "<li><b>Line " + np.line + "</b> - " + esc(np.reason) + "</li>";
          });
          html += "</ul>";
        }
        if (r.notAudited.length) {
          html += "<h3>NOT AUDITED keys</h3><p>These keys are outside the audited set. They are listed by name and line only - no values shown.</p><ul class=\"plain-list\">";
          r.notAudited.forEach(function (na) {
            html += "<li><b>" + esc(na.key) + "</b> - line " + na.line + "</li>";
          });
          html += "</ul>";
        }
        if (r.parsed.commented.length) {
          html += "<h3>Commented-out keys - treated as unset</h3><ul class=\"plain-list\">";
          r.parsed.commented.forEach(function (c) {
            html += "<li><b>" + esc(c.key) + "</b> - line " + c.line + "</li>";
          });
          html += "</ul>";
        }
        if (r.defaults.length) {
          html += "<h3>Silent defaults - security-relevant keys you did not set</h3><ul class=\"plain-list\">";
          r.defaults.forEach(function (d) {
            html += "<li><b>" + esc(d.key) + "</b> - " + esc(d.note) + "</li>";
          });
          html += "</ul>";
        }
        body.innerHTML = html;
      }

      function runAudit() {
        var text = $("input").value;
        $("copyStatus").textContent = "";
        if (!text.trim()) {
          $("resultsCard").classList.remove("hidden");
          lastResult = null;
          $("resultsBody").innerHTML = '<div class="empty-note"><b>Nothing to audit.</b> The input is empty - paste an elasticsearch.yml above, or load one of the worked examples.</div>';
          return;
        }
        render(audit(text, $("versionSel").value));
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-elasticsearch-config-safety-auditor',
  name: 'J-Dawgs Elasticsearch Config Safety Auditor',
  description: 'Grades a pasted elasticsearch.yml (Elasticsearch/OpenSearch) offline: public bind with security off, wildcard deletion, reindex whitelist, secrets by key name only — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
