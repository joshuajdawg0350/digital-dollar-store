'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs DragonflyDB Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Example configurations ---------- */
      var RISKY_EXAMPLE = [
        "# Risky example — one flag per line",
        "--port=6379",
        "--bind=0.0.0.0",
        "--requirepass=hunter2",
        "--admin_port=9999",
        "--snapshot_cron=",
        "--cache_mode=true",
        "--mystery_flag=on",
        "this line is not a flag at all"
      ].join("\n");

      var HARDENED_EXAMPLE = [
        "# Hardened example — one flag per line",
        "--port=6380",
        "--bind=127.0.0.1",
        "--requirepass=${DRAGONFLY_PASSWORD}",
        "--tls=true",
        "--tls_cert_file=/etc/dragonfly/tls.crt",
        "--tls_key_file=/etc/dragonfly/tls.key",
        "--dbfilename=dump",
        "--snapshot_cron=0 * * * *",
        "--maxmemory=4GB",
        "--proactor_threads=4"
      ].join("\n");

      /* ---------- Flag knowledge (Dragonfly flag family only) ---------- */
      var VALUE_FLAGS = {
        port:1, bind:1, requirepass:1, admin_port:1, admin_bind:1, dbfilename:1, dir:1,
        snapshot_cron:1, maxmemory:1, proactor_threads:1, dbnum:1, tls_cert_file:1,
        tls_key_file:1, tls_ca_cert_file:1, tls_ca_cert_dir:1, log_file:1, logfile:1,
        verbosity:1, pidfile:1, masteruser:1, masterauth:1, replicaof:1, replica_of:1,
        announce_ip:1, announce_port:1, hz:1, tcp_keepalive:1, aclfile:1,
        keys_output_limit:1, serialization_max_chunk_size:1, shrink_coefficient:1
      };
      var BOOL_FLAGS = {
        tls:1, cache_mode:1, daemonize:1, logtostderr:1, alsologtostderr:1,
        cluster_mode:1, repl_cluster_mode:1, enable_multi_shard_sync:1,
        experimental_io_loop_v2:1, primary_port_http_enabled:1
      };
      function isKnown(norm){ return !!(VALUE_FLAGS[norm] || BOOL_FLAGS[norm]); }
      /* Bare "key value" lines (config-file style, no dashes) are never graded
         as Dragonfly flags; keys in this set are reported NOT RECOGNIZED. */
      var BARE_KEYS = {
        port:1, bind:1, requirepass:1, save:1, appendonly:1, appendfilename:1,
        maxmemory:1, "maxmemory-policy":1, daemonize:1, "protected-mode":1, dir:1,
        dbfilename:1, logfile:1, pidfile:1, timeout:1, databases:1, tls:1,
        "tls-port":1, masterauth:1, replicaof:1, "slaveof":1, aclfile:1, hz:1,
        "tcp-keepalive":1, snapshot_cron:1, cache_mode:1, admin_port:1
      };
      var PLACEHOLDERS = ["password","passw0rd","changeme","change-me","example","dragonfly",
        "redis","secret","test","test123","123456","12345678","admin","letmein","default",
        "yourpassword","your-password","placeholder","xxx","***","pw","abc123"];
      var MULTI_TOKEN_FLAGS = { snapshot_cron:1 };

      function isSecretFlag(norm){
        return norm.indexOf("pass") !== -1 || norm.indexOf("secret") !== -1 ||
               norm.indexOf("token") !== -1 || norm === "masterauth";
      }
      function isEnvRef(v){
        return /^\$\{[A-Za-z_][A-Za-z0-9_]*\}$/.test(v) || /^\$\([A-Za-z_][A-Za-z0-9_]*\)$/.test(v) ||
               /^\$[A-Za-z_][A-Za-z0-9_]*$/.test(v);
      }
      function truthy(v){
        if (v === null || v === undefined) return false;
        var s = String(v).trim().toLowerCase();
        return s === "true" || s === "1" || s === "yes" || s === "on";
      }
      function falsyExplicit(v){
        if (v === null || v === undefined) return false;
        var s = String(v).trim().toLowerCase();
        return s === "false" || s === "0" || s === "no" || s === "off" || s === "";
      }

      function tokenize(line){
        var out = [], re = /"([^"]*)"|'([^']*)'|(\S+)/g, m;
        while ((m = re.exec(line)) !== null){
          out.push(m[1] !== undefined ? m[1] : (m[2] !== undefined ? m[2] : m[3]));
        }
        return out;
      }

      /* ---------- Parser ---------- */
      function parseConfig(text){
        var flags = {};       // norm -> {value, line, raw}
        var order = [];
        var findings = [];
        var recognized = 0;
        var lines = String(text).split(/\r?\n/);
        for (var ln = 0; ln < lines.length; ln++){
          var lineNo = ln + 1;
          var rawLine = lines[ln];
          var trimmed = rawLine.trim();
          if (!trimmed) continue;
          if (trimmed.charAt(0) === "#" || trimmed.charAt(0) === ";") continue;
          var tokens = tokenize(trimmed);
          if (!tokens.length) continue;
          var first = tokens[0];
          /* Strip a leading program name, e.g. "dragonfly --port ..." */
          if (!/^-/.test(first) && /^(dragonfly|dragonflydb|\.\/dragonfly|\/usr\/.*dragonfly.*)$/i.test(first)){
            tokens = tokens.slice(1);
            if (!tokens.length) continue;
            first = tokens[0];
          }
          if (!/^-/.test(first)){
            /* Bare config-file style line: never graded as a Dragonfly flag. */
            var key = first.toLowerCase();
            if (BARE_KEYS[key] || BARE_KEYS[key.replace(/_/g,"-")]){
              findings.push({line:lineNo, severity:"UNRECOGNIZED", flag:first,
                title:"Not a Dragonfly startup flag as pasted",
                detail:"Line " + lineNo + " uses bare config-key style (\"" + first + "\") with no leading dashes. This auditor grades the Dragonfly flag family as pasted (for example --" + key.replace(/-/g,"_") + "); the bare key was NOT RECOGNIZED and was not graded.",
                fix:"Re-paste the setting in Dragonfly flag form (--flag=value) if it is meant to be graded."});
            } else {
              findings.push({line:lineNo, severity:"UNPARSED", flag:null,
                title:"Line could not be parsed",
                detail:"Line " + lineNo + " is not a recognizable flag line and was NOT PARSED. Its text is not reproduced here.",
                fix:"Rewrite line " + lineNo + " as one Dragonfly flag per line (--flag=value), or remove it."});
            }
            continue;
          }
          var stray = false;
          var i = 0;
          while (i < tokens.length){
            var tok = tokens[i];
            if (!/^--?[A-Za-z]/.test(tok)){
              stray = true; i++; continue;
            }
            var body = tok.replace(/^--?/, "");
            var eq = body.indexOf("=");
            var rawName, value = null;
            if (eq >= 0){ rawName = body.slice(0, eq); value = body.slice(eq + 1); }
            else rawName = body;
            var norm = rawName.toLowerCase().replace(/-/g, "_");
            if (value === null){
              if (MULTI_TOKEN_FLAGS[norm]){
                value = tokens.slice(i + 1).join(" ");
                i = tokens.length;
              } else if (BOOL_FLAGS[norm]){
                var nxt = tokens[i + 1];
                if (nxt !== undefined && /^(true|false|1|0|yes|no|on|off)$/i.test(nxt)){ value = nxt; i += 2; }
                else { value = "true"; i += 1; }
              } else {
                var nxt2 = tokens[i + 1];
                if (nxt2 !== undefined && !/^--?[A-Za-z]/.test(nxt2)){ value = nxt2; i += 2; }
                else { value = ""; i += 1; }
              }
            } else {
              i += 1;
              if (MULTI_TOKEN_FLAGS[norm] && i < tokens.length){
                value = value + " " + tokens.slice(i).join(" ");
                i = tokens.length;
              }
            }
            if (isKnown(norm)){
              recognized++;
              if (!flags[norm]) order.push(norm);
              flags[norm] = { value: value, line: lineNo, raw: "--" + rawName };
            } else {
              findings.push({line:lineNo, severity:"UNRECOGNIZED", flag:"--" + rawName,
                title:"Flag not recognized",
                detail:"--" + rawName + " on line " + lineNo + " is NOT RECOGNIZED as a Dragonfly flag by this auditor. It was not graded and its meaning was not guessed." + (isSecretFlag(norm) ? " Its value is not shown." : ""),
                fix:"Check the spelling of --" + rawName + " against the Dragonfly flag list, or remove it if it belongs to a different tool."});
            }
          }
          if (stray){
            findings.push({line:lineNo, severity:"UNPARSED", flag:null,
              title:"Part of the line could not be parsed",
              detail:"Line " + lineNo + " contains text outside any flag that was NOT PARSED. The text is not reproduced here.",
              fix:"Put one flag per line (--flag=value) so every setting on line " + lineNo + " is graded."});
          }
        }
        return { flags: flags, order: order, findings: findings, recognized: recognized };
      }

      /* ---------- Grading ---------- */
      function audit(text){
        var parsed = parseConfig(text);
        var flags = parsed.flags;
        var F = parsed.findings.slice();
        function add(sev, line, flag, title, detail, fix){
          F.push({line:line, severity:sev, flag:flag, title:title, detail:detail, fix:fix});
        }
        function get(n){ return flags[n] || null; }

        if (parsed.recognized === 0){
          return finish("NOT ENOUGH TO GRADE", F, parsed.recognized,
            "No recognizable Dragonfly flags were found in the paste, so there is nothing to grade.");
        }

        /* Bind classification */
        var bindF = get("bind");
        var bindEntries = bindF ? String(bindF.value).split(/[,\s]+/).filter(Boolean) : [];
        var LOCAL = { "127.0.0.1":1, "::1":1, "localhost":1 };
        var ALL = { "0.0.0.0":1, "::":1, "*":1 };
        var bindAll = false, bindLocal = false;
        if (bindF){
          if (bindEntries.length === 0) bindAll = true;
          bindAll = bindAll || bindEntries.some(function(e){ return !!ALL[e]; });
          bindLocal = bindEntries.length > 0 && bindEntries.every(function(e){ return !!LOCAL[e]; });
        }
        var nonLocal = !bindF || bindAll || !bindLocal;

        /* Auth state (values never echoed) */
        var authF = get("requirepass");
        var authVal = authF ? String(authF.value) : "";
        var authPresent = !!authF && authVal.trim() !== "";
        var authEnv = authPresent && isEnvRef(authVal.trim());
        var authPlaceholder = authPresent && !authEnv &&
          (PLACEHOLDERS.indexOf(authVal.trim().toLowerCase()) !== -1 || /^(.)\1+$/.test(authVal.trim()));
        var authEffective = authPresent && !authPlaceholder;

        var tlsF = get("tls");
        var tlsOn = tlsF ? truthy(tlsF.value) : false;
        var portF = get("port");
        var portVal = portF ? parseInt(portF.value, 10) : 6379;
        if (isNaN(portVal)) portVal = null;

        /* --- Bind / port --- */
        if (!bindF){
          add("WARNING", null, "--bind", "No --bind flag pasted",
            "With no --bind flag in the paste, Dragonfly listens on all interfaces by default. Nothing in the paste restricts the listener to localhost.",
            "Set --bind=127.0.0.1 if only local clients should connect, or name the specific interface to bind.");
        } else if (bindAll){
          add("HIGH", bindF.line, "--bind", "Binds all interfaces",
            "--bind on line " + bindF.line + " listens on every network interface (0.0.0.0 / empty / *), so the listener is reachable from beyond this machine.",
            "Bind to 127.0.0.1 or a private interface unless remote clients genuinely need access — and then require auth and TLS.");
        } else if (bindLocal){
          add("INFO", bindF.line, "--bind", "Localhost bind",
            "--bind on line " + bindF.line + " restricts the listener to localhost, which is the safer posture.",
            "No change needed for the bind itself.");
        } else {
          add("INFO", bindF.line, "--bind", "Specific interface bind",
            "--bind on line " + bindF.line + " names specific interface(s) rather than all interfaces.",
            "Confirm the named interface is not a public one.");
        }
        if (portVal === 6379 && nonLocal){
          add("WARNING", portF ? portF.line : null, "--port", "Default port on a reachable listener",
            "Port 6379 (the well-known default) is exposed on a listener that reaches beyond localhost, which makes it a first stop for scanners.",
            "Move to a non-default port and restrict the bind; do not rely on the port change alone for safety.");
        }

        /* --- Auth --- */
        if (!authPresent){
          if (nonLocal){
            add("HIGH", bindF ? bindF.line : (portF ? portF.line : null), "--requirepass",
              "No password on a non-localhost listener",
              "No --requirepass was found, and the listener reaches beyond localhost. Anyone who can reach the port can read and write the store.",
              "Set --requirepass to a long, unique password — ideally an environment-variable reference such as --requirepass=${DRAGONFLY_PASSWORD}.");
          } else {
            add("INFO", null, "--requirepass", "No password, localhost only",
              "No --requirepass was found, but the bind is localhost-only, so the listener is not reachable from other machines.",
              "Set --requirepass anyway if anything else on this machine is untrusted.");
          }
          if (authF){
            add("WARNING", authF.line, "--requirepass", "Password flag present but empty",
              "--requirepass on line " + authF.line + " has an empty value, which is the same as no password. The value (none) is not shown.",
              "Give --requirepass a real value or an environment-variable reference.");
          }
        } else if (authEnv){
          add("INFO", authF.line, "--requirepass", "Password supplied by environment reference",
            "--requirepass on line " + authF.line + " uses an environment-variable reference rather than a plaintext value. That is treated as a safe reference; the underlying secret is never shown or graded here.",
            "Make sure the referenced variable is set in the server environment and not committed anywhere.");
        } else if (authPlaceholder){
          add("HIGH", authF.line, "--requirepass", "Example / placeholder password",
            "--requirepass on line " + authF.line + " is an example or placeholder-style password (length " + authVal.length + "). The value itself is never shown.",
            "Replace it with a long, unique password or an environment-variable reference such as ${DRAGONFLY_PASSWORD}.");
        } else if (authVal.length < 12){
          add(nonLocal ? "HIGH" : "WARNING", authF.line, "--requirepass", "Short password",
            "--requirepass on line " + authF.line + " is only " + authVal.length + " characters long. The value itself is never shown.",
            "Use a password of at least 16 characters, or an environment-variable reference.");
        } else {
          add("INFO", authF.line, "--requirepass", "Password set",
            "--requirepass is set on line " + authF.line + " (length " + authVal.length + "). The value itself is never shown.",
            "No change needed for length; rotate it if it has ever been shared.");
        }

        /* --- Combination blocker: reachable + unauthenticated --- */
        if (nonLocal && !authEffective){
          add("BLOCKER", bindF ? bindF.line : (portF ? portF.line : null), "--bind / --requirepass",
            "Reachable listener with no working authentication",
            "The listener reaches beyond localhost" + (portVal ? " on port " + portVal : "") + " and there is no effective --requirepass (missing, empty, or a placeholder). This combination means an unauthenticated, network-reachable in-memory store.",
            "Do not start this server on a network until --requirepass is set to a real secret and the bind is restricted or TLS is on.");
        }

        /* --- TLS --- */
        var certF = get("tls_cert_file"), keyF = get("tls_key_file");
        if (tlsOn){
          if (!certF || !keyF || String(certF.value).trim() === "" || String(keyF.value).trim() === ""){
            add("BLOCKER", tlsF.line, "--tls", "TLS on but certificate / key flags missing",
              "--tls is enabled on line " + tlsF.line + ", but " +
              (!certF || String(certF.value).trim() === "" ? "--tls_cert_file " : "") +
              (!keyF || String(keyF.value).trim() === "" ? "--tls_key_file " : "") +
              "is missing or empty, so the server cannot present a certificate as configured.",
              "Set both --tls_cert_file and --tls_key_file to real certificate and key paths, or turn --tls off only for a localhost-only listener.");
          } else {
            add("INFO", tlsF.line, "--tls", "TLS on with certificate and key flags",
              "--tls is enabled and both --tls_cert_file and --tls_key_file are present. The files themselves are not opened or verified by this tool.",
              "No change needed in the paste; verify the files exist on the server before starting it.");
          }
        } else {
          if (nonLocal){
            add("HIGH", tlsF ? tlsF.line : null, "--tls", "No TLS on a non-localhost listener",
              tlsF ? "--tls on line " + tlsF.line + " is off, and the listener reaches beyond localhost, so traffic — including the password — crosses the network in plaintext."
                   : "No --tls flag was found and the listener reaches beyond localhost, so traffic — including the password — crosses the network in plaintext.",
              "Enable --tls=true and set --tls_cert_file and --tls_key_file.");
          } else {
            add("INFO", tlsF ? tlsF.line : null, "--tls", "TLS off, localhost only",
              "TLS is off, but the bind is localhost-only, so traffic does not leave this machine.",
              "Enable TLS before widening the bind beyond localhost.");
          }
        }

        /* --- Admin interface --- */
        var adminF = get("admin_port");
        if (adminF){
          var adminPort = parseInt(adminF.value, 10);
          if (!isNaN(adminPort) && adminPort > 0){
            if (nonLocal && !(tlsOn && authEffective)){
              add("HIGH", adminF.line, "--admin_port", "Admin interface exposed without full protection",
                "--admin_port on line " + adminF.line + " enables the admin / HTTP interface on a listener that reaches beyond localhost, without both TLS and a working password in place.",
                "Disable --admin_port, bind it to localhost only, or put it behind both TLS and a real --requirepass.");
            } else if (nonLocal){
              add("WARNING", adminF.line, "--admin_port", "Admin interface enabled on a reachable listener",
                "--admin_port on line " + adminF.line + " enables the admin / HTTP interface beyond localhost. TLS and a password are in place, but the surface is still worth questioning.",
                "Disable --admin_port unless the admin interface is genuinely needed remotely.");
            } else {
              add("INFO", adminF.line, "--admin_port", "Admin interface on localhost",
                "--admin_port on line " + adminF.line + " is set while the bind is localhost-only.",
                "Keep the admin interface off any non-localhost bind.");
            }
          } else if (adminPort === 0){
            add("INFO", adminF.line, "--admin_port", "Admin interface disabled",
              "--admin_port on line " + adminF.line + " is 0, so no separate admin listener is configured.",
              "No change needed.");
          }
        }

        /* --- Persistence posture --- */
        var cronF = get("snapshot_cron"), dbfF = get("dbfilename");
        var snapDisabled = false;
        if (cronF && falsyExplicit(cronF.value)){
          snapDisabled = true;
          add("WARNING", cronF.line, "--snapshot_cron", "Snapshotting disabled",
            "--snapshot_cron on line " + cronF.line + " is empty/off, which disables scheduled snapshots, and no other persistence setting appears in the paste. A restart loses the data.",
            "Set --snapshot_cron to a schedule (for example --snapshot_cron=0 * * * *) and keep --dbfilename set, or document another persistence plan.");
        }
        if (dbfF && falsyExplicit(dbfF.value)){
          snapDisabled = true;
          add("WARNING", dbfF.line, "--dbfilename", "Snapshot file disabled",
            "--dbfilename on line " + dbfF.line + " is empty/off, which disables snapshot files, and no other persistence setting appears in the paste.",
            "Set --dbfilename to a snapshot file name (for example --dbfilename=dump) in a writable --dir.");
        }
        if (!snapDisabled && (cronF || dbfF)){
          add("INFO", (dbfF || cronF).line, "--dbfilename", "Snapshot persistence configured",
            "Snapshot settings are present in the paste, so the store is configured to persist to disk on a schedule.",
            "Confirm the snapshot directory is writable and backed up.");
        }
        if (!snapDisabled && !cronF && !dbfF){
          add("INFO", null, "--dbfilename", "No snapshot flags pasted",
            "No snapshot flags appear in the paste, so Dragonfly defaults apply. This tool cannot verify what the running server will actually do.",
            "Paste the snapshot flags explicitly if you want them graded.");
        }

        /* --- Memory posture --- */
        var mmF = get("maxmemory");
        if (!mmF){
          add("WARNING", null, "--maxmemory", "No memory cap set",
            "No --maxmemory flag was found. Without a cap the store can grow until the host runs out of memory.",
            "Set --maxmemory to a cap sized for the host, for example --maxmemory=4GB.");
        } else {
          var mmRaw = String(mmF.value).trim();
          var mmMatch = mmRaw.match(/^(\d+(?:\.\d+)?)\s*(b|kb|mb|gb|tb|k|m|g)?$/i);
          if (!mmMatch || parseFloat(mmMatch[1]) === 0){
            add("WARNING", mmF.line, "--maxmemory", "Memory cap is zero or unreadable",
              "--maxmemory on line " + mmF.line + " is set to zero or a value this tool cannot read as a size, which means no effective cap.",
              "Set --maxmemory to a real size, for example --maxmemory=4GB.");
          } else {
            add("INFO", mmF.line, "--maxmemory", "Memory cap set",
              "--maxmemory on line " + mmF.line + " sets an explicit memory cap.",
              "Confirm the cap leaves headroom for snapshots and replication on this host.");
          }
        }

        /* --- Cache mode / threads (notes) --- */
        var cacheF = get("cache_mode");
        if (cacheF && truthy(cacheF.value)){
          add("INFO", cacheF.line, "--cache_mode", "Cache mode on",
            "--cache_mode on line " + cacheF.line + " is on: Dragonfly runs as a cache and may evict keys under memory pressure instead of refusing writes.",
            "Fine for a pure cache; do not rely on it as the only copy of data.");
        }
        var ptF = get("proactor_threads");
        if (ptF){
          var pt = parseInt(ptF.value, 10);
          if (isNaN(pt) || pt <= 0){
            add("WARNING", ptF.line, "--proactor_threads", "Thread count unreadable or zero",
              "--proactor_threads on line " + ptF.line + " is not a positive number, so the sizing cannot be graded.",
              "Set --proactor_threads to a positive count matched to the host's cores.");
          } else {
            add("INFO", ptF.line, "--proactor_threads", "Thread count set",
              "--proactor_threads on line " + ptF.line + " sets the I/O thread count to " + pt + ".",
              "Confirm the count matches the cores actually available to the server.");
          }
        }

        /* --- Replica auth note --- */
        var repF = get("replicaof") || get("replica_of");
        var maF = get("masterauth");
        if (repF && !maF){
          add("WARNING", repF.line, "--replicaof", "Replica with no --masterauth",
            "A replica flag appears on line " + repF.line + " but no --masterauth was found, so the replica may be unable to authenticate to a password-protected primary.",
            "Set --masterauth to match the primary's password, ideally as an environment reference.");
        }
        if (maF){
          var maVal = String(maF.value);
          if (isEnvRef(maVal.trim())){
            add("INFO", maF.line, "--masterauth", "Master auth by environment reference",
              "--masterauth on line " + maF.line + " uses an environment-variable reference. The secret is never shown.",
              "Make sure the referenced variable is set in the replica's environment.");
          } else if (maVal.length < 12){
            add("WARNING", maF.line, "--masterauth", "Short master password",
              "--masterauth on line " + maF.line + " is only " + maVal.length + " characters long. The value itself is never shown.",
              "Use a longer master password or an environment-variable reference.");
          }
        }

        /* --- Verdict --- */
        var hasBlocker = F.some(function(f){ return f.severity === "BLOCKER"; });
        var hasHigh = F.some(function(f){ return f.severity === "HIGH"; });
        var hasWarn = F.some(function(f){ return f.severity === "WARNING"; });
        var verdict, sub;
        if (hasBlocker || hasHigh){
          verdict = "DO NOT DEPLOY";
          sub = "Blockers or high-severity findings are present. Fix them before this configuration goes anywhere near a network.";
        } else if (hasWarn){
          verdict = "DEPLOY WITH FIXES";
          sub = "No blockers or high-severity findings, but warnings remain. Apply the fix list first.";
        } else {
          verdict = "SAFE TO DEPLOY";
          sub = "No blockers, high-severity findings, or warnings in the pasted flags. This grades the paste only — it does not verify a running server.";
        }
        return finish(verdict, F, parsed.recognized, sub);
      }

      var SEV_RANK = { BLOCKER:0, HIGH:1, WARNING:2, UNRECOGNIZED:3, UNPARSED:3, INFO:4 };
      function finish(verdict, findings, recognized, sub){
        findings.sort(function(a, b){
          var r = SEV_RANK[a.severity] - SEV_RANK[b.severity];
          if (r !== 0) return r;
          var la = a.line === null ? 9999 : a.line, lb = b.line === null ? 9999 : b.line;
          return la - lb;
        });
        var fixes = [], seen = {};
        findings.forEach(function(f){
          if ((f.severity === "BLOCKER" || f.severity === "HIGH" || f.severity === "WARNING") && f.fix && !seen[f.fix]){
            seen[f.fix] = 1; fixes.push(f.fix);
          }
        });
        var counts = { BLOCKER:0, HIGH:0, WARNING:0, INFO:0, UNRECOGNIZED:0, UNPARSED:0 };
        findings.forEach(function(f){ counts[f.severity]++; });
        return { verdict:verdict, sub:sub, findings:findings, fixes:fixes, counts:counts, recognized:recognized };
      }

      /* ---------- Rendering ---------- */
      var lastResult = null;
      function esc(s){
        return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
      }
      function sevLabel(sev){
        if (sev === "UNRECOGNIZED") return "NOT RECOGNIZED";
        if (sev === "UNPARSED") return "NOT PARSED";
        return sev;
      }
      function buildReport(r){
        var out = [];
        out.push("J-Dawgs DragonflyDB Server Config Safety Auditor™ — report");
        out.push("Verdict: " + r.verdict);
        out.push("Recognized Dragonfly flags: " + r.recognized);
        out.push("Counts: BLOCKER " + r.counts.BLOCKER + " · HIGH " + r.counts.HIGH + " · WARNING " + r.counts.WARNING +
                 " · INFO " + r.counts.INFO + " · NOT RECOGNIZED " + r.counts.UNRECOGNIZED + " · NOT PARSED " + r.counts.UNPARSED);
        out.push("Note: secret values are never printed in this report — findings name the flag, the line, and the length only.");
        out.push("");
        out.push("Findings:");
        if (!r.findings.length) out.push("  (none)");
        r.findings.forEach(function(f, idx){
          out.push((idx + 1) + ". [" + sevLabel(f.severity) + "] " + (f.line ? "Line " + f.line : "Whole config") +
                   (f.flag ? " · " + f.flag : "") + " — " + f.title);
          out.push("   " + f.detail);
          out.push("   Fix: " + f.fix);
        });
        out.push("");
        out.push("Fix list:");
        if (!r.fixes.length) out.push("  (no fixes required by the findings)");
        r.fixes.forEach(function(fx, idx){ out.push((idx + 1) + ". " + fx); });
        out.push("");
        out.push("Limits: this grades pasted text only. It never connected to a server and does not verify a running deployment.");
        return out.join("\n");
      }
      function buildJSON(r){
        return {
          tool: "J-Dawgs DragonflyDB Server Config Safety Auditor™",
          verdict: r.verdict,
          recognized_flags: r.recognized,
          counts: {
            blocker: r.counts.BLOCKER, high: r.counts.HIGH, warning: r.counts.WARNING,
            info: r.counts.INFO, not_recognized: r.counts.UNRECOGNIZED, not_parsed: r.counts.UNPARSED
          },
          findings: r.findings.map(function(f){
            return { line: f.line, severity: sevLabel(f.severity), flag: f.flag, title: f.title, detail: f.detail, fix: f.fix };
          }),
          fixes: r.fixes,
          note: "Secret values are never included in this export; password findings carry flag name, line, and length only."
        };
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-dragonflydb-server-config-safety-auditortm',
  name: 'J-Dawgs DragonflyDB Server Config Safety Auditor',
  description: 'Grades a pasted Dragonfly flag list fully offline into one deploy verdict — Dragonfly flag family only — with secrets shown by key name, line, and length only, never by value.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
