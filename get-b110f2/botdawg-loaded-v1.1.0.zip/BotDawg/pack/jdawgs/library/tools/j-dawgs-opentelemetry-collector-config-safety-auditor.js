'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs OpenTelemetry Collector Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

    "use strict";

    var RISKY = [
      "receivers:",
      "  otlp:",
      "    protocols:",
      "      grpc:",
      "        endpoint: 0.0.0.0:4317",
      "      http:",
      "        endpoint: 0.0.0.0:4318",
      "",
      "processors:",
      "  batch:",
      "",
      "exporters:",
      "  otlphttp:",
      "    endpoint: https://ingest.example.com:4318",
      "    headers:",
      "      authorization: \"sk-live-4f8c2e91b7a04d55PLANTED\"",
      "",
      "extensions:",
      "  pprof:",
      "    endpoint: 0.0.0.0:1777",
      "",
      "service:",
      "  extensions: [pprof]",
      "  pipelines:",
      "    traces:",
      "      receivers: [otlp]",
      "      processors: [batch]",
      "      exporters: [otlphttp]"
    ].join("\n");

    var HARDENED = [
      "receivers:",
      "  otlp:",
      "    protocols:",
      "      grpc:",
      "        endpoint: 127.0.0.1:4317",
      "        tls:",
      "          cert_file: /etc/collector/tls/server.crt",
      "          key_file: /etc/collector/tls/server.key",
      "        auth:",
      "          authenticator: basicauth",
      "      http:",
      "        endpoint: 127.0.0.1:4318",
      "        tls:",
      "          cert_file: /etc/collector/tls/server.crt",
      "          key_file: /etc/collector/tls/server.key",
      "        auth:",
      "          authenticator: basicauth",
      "",
      "processors:",
      "  memory_limiter:",
      "    check_interval: 1s",
      "    limit_percentage: 80",
      "    spike_limit_percentage: 20",
      "  batch:",
      "  tail_sampling:",
      "    policies:",
      "      - name: keep-errors",
      "        type: status_code",
      "        status_code:",
      "          status_codes: [ERROR]",
      "",
      "exporters:",
      "  otlphttp:",
      "    endpoint: https://ingest.example.com:4318",
      "    headers:",
      "      authorization: ${env:INGEST_API_KEY}",
      "    tls:",
      "      insecure_skip_verify: false",
      "",
      "extensions:",
      "  basicauth:",
      "    client_auth:",
      "      username: collector",
      "      password: ${env:COLLECTOR_PASSWORD}",
      "  health_check:",
      "    endpoint: 127.0.0.1:13133",
      "",
      "service:",
      "  extensions: [basicauth, health_check]",
      "  pipelines:",
      "    traces:",
      "      receivers: [otlp]",
      "      processors: [memory_limiter, batch, tail_sampling]",
      "      exporters: [otlphttp]",
      "    metrics:",
      "      receivers: [otlp]",
      "      processors: [memory_limiter, batch]",
      "      exporters: [otlphttp]"
    ].join("\n");

    function esc(s){ return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;"); }
    function stripQuotes(v){ v = String(v||"").trim(); if(v.length>=2 && ((v.charAt(0)==='"'&&v.charAt(v.length-1)==='"')||(v.charAt(0)==="'"&&v.charAt(v.length-1)==="'"))) v = v.slice(1,-1); return v; }
    function isEnvOrFileRef(v){ v = stripQuotes(v); return /^\$\{(env|file):/.test(v); }
    function baseType(name){ return String(name).split("/")[0]; }

    function parseConfig(text){
      var rawLines = String(text).split(/\r?\n/);
      var entries = [], notParsed = [];
      rawLines.forEach(function(raw, i){
        var lineNo = i + 1;
        if(/^\s*$/.test(raw)) return;
        if(/^\s*#/.test(raw)) return;
        var lead = raw.match(/^[ \t]*/)[0];
        if(lead.indexOf("\t") !== -1){ notParsed.push(lineNo); return; }
        var indent = lead.length;
        var mList = raw.match(/^\s*-\s+(.+)$/);
        if(mList){ entries.push({line:lineNo, indent:indent, list:true, key:null, value:mList[1].trim()}); return; }
        var mKey = raw.match(/^\s*([A-Za-z0-9_][A-Za-z0-9_\/\.\-]*)\s*:\s*(.*)$/);
        if(mKey){ entries.push({line:lineNo, indent:indent, list:false, key:mKey[1], value:mKey[2].trim()}); return; }
        notParsed.push(lineNo);
      });
      // paths + duplicate detection
      var stack = [], seen = {}, duplicates = [];
      entries.forEach(function(e){
        if(e.list){ e.path = stack.map(function(s){return s.key;}).join("."); return; }
        while(stack.length && stack[stack.length-1].indent >= e.indent) stack.pop();
        e.parentPath = stack.map(function(s){return s.key;}).join(".");
        e.path = (e.parentPath ? e.parentPath + "." : "") + e.key;
        if(seen[e.path] !== undefined){ duplicates.push({key:e.key, path:e.path, firstLine:seen[e.path], line:e.line}); }
        else { seen[e.path] = e.line; }
        stack.push({indent:e.indent, key:e.key});
      });
      return {entries:entries, notParsed:notParsed, duplicates:duplicates};
    }

    function topSections(entries){
      var sections = {};
      var current = null;
      entries.forEach(function(e){
        if(!e.list && e.indent === 0){ current = e.key; if(!sections[current]) sections[current] = {entry:e, body:[]}; }
        else if(current){ sections[current].body.push(e); }
      });
      return sections;
    }

    function instancesOf(section){
      if(!section || !section.body.length) return [];
      var keyEntries = section.body.filter(function(e){ return !e.list; });
      if(!keyEntries.length) return [];
      var minIndent = Math.min.apply(null, keyEntries.map(function(e){ return e.indent; }));
      var insts = [];
      section.body.forEach(function(e, idx){
        if(!e.list && e.indent === minIndent){
          var desc = [];
          for(var j = idx + 1; j < section.body.length; j++){
            var d = section.body[j];
            if(!d.list && d.indent <= minIndent) break;
            if(d.list && d.indent <= minIndent) break;
            desc.push(d);
          }
          insts.push({name:e.key, type:baseType(e.key), line:e.line, indent:e.indent, descendants:desc});
        }
      });
      return insts;
    }

    function listForKey(entry, allEntries){
      var vals = [];
      var v = stripQuotes(entry.value || "");
      if(v.charAt(0) === "["){
        v.replace(/^\[|\]$/g,"").split(",").forEach(function(p){ p = stripQuotes(p.trim()); if(p) vals.push(p); });
        return vals;
      }
      if(v){ vals.push(v); return vals; }
      var idx = allEntries.indexOf(entry);
      for(var j = idx + 1; j < allEntries.length; j++){
        var d = allEntries[j];
        if(d.indent <= entry.indent) break;
        if(d.list) vals.push(stripQuotes(d.value));
      }
      return vals;
    }

    function descendantsOf(entry, allEntries){
      var out = [], idx = allEntries.indexOf(entry);
      for(var j = idx + 1; j < allEntries.length; j++){
        var d = allEntries[j];
        if(!d.list && d.indent <= entry.indent) break;
        if(d.list && d.indent <= entry.indent) break;
        out.push(d);
      }
      return out;
    }

    function hostOf(endpointVal){
      var v = stripQuotes(endpointVal);
      var m = v.match(/^\[([^\]]*)\]:(\d+)$/);
      if(m) return m[1];
      var idx = v.lastIndexOf(":");
      if(idx === -1) return v;
      return v.slice(0, idx);
    }
    function isAllInterfaces(host){ return host === "" || host === "0.0.0.0" || host === "::"; }

    function audit(text){
      var findings = [];
      function add(sev, line, check, message){ findings.push({severity:sev, line:line, check:check, message:message}); }
      var trimmed = String(text||"").trim();
      var parsed = parseConfig(text||"");
      var entries = parsed.entries;

      if(!trimmed){
        return {verdict:"NOT ENOUGH TO GRADE", reason:"Nothing was pasted. Paste a collector config.yaml to get a verdict.", findings:findings, notParsed:[], duplicates:[], gradeable:false};
      }

      var sections = topSections(entries);
      var hasPipelinesKey = entries.some(function(e){ return e.key === "pipelines"; });
      var hasStructure = !!(sections.receivers || sections.service || sections.exporters || sections.processors || sections.extensions || hasPipelinesKey);
      if(!hasStructure){
        return {verdict:"NOT ENOUGH TO GRADE", reason:"No collector structure was found — no receivers, processors, exporters, extensions, service, or pipelines evidence. The tool will not guess a verdict for this paste.", findings:findings, notParsed:parsed.notParsed, duplicates:parsed.duplicates, gradeable:false};
      }

      // ---- duplicates ----
      parsed.duplicates.forEach(function(d){
        add("WARNING", d.line, "Duplicate key", "Key '" + d.key + "' is set at line " + d.firstLine + " and again at line " + d.line + " (path: " + d.path + "). YAML readers take the last value — remove one so the effective setting is the one you meant.");
      });

      // ---- plaintext secrets (values never rendered) ----
      var secretKeyRe = /(api[-_]?key|password|passwd|secret|access[-_]?token|auth[-_]?token|private[-_]?key|^authorization$|^token$|^credentials?$)/i;
      entries.forEach(function(e){
        if(e.list || !e.key) return;
        var val = stripQuotes(e.value || "");
        if(!val) return;
        if(e.key === "endpoint" || e.key === "url"){
          var cred = val.match(/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\/[^\/\s:@]+:([^\/\s@]+)@/);
          if(cred){ add("BLOCKER", e.line, "Plaintext secret", "Key '" + e.key + "' at line " + e.line + " embeds a password in the endpoint URL (password length: " + cred[1].length + " characters; value never shown). Move credentials out of the endpoint and into an ${env:...} or ${file:...} reference."); }
          return;
        }
        if(secretKeyRe.test(e.key)){
          if(isEnvOrFileRef(val)) return;
          if(/^(true|false)$/i.test(val)) return;
          add("BLOCKER", e.line, "Plaintext secret", "Key '" + e.key + "' at line " + e.line + " holds a plaintext value (length: " + val.length + " characters; value never shown). Replace it with an ${env:...} or ${file:...} reference so the secret is not stored in the config.");
        }
      });

      // ---- component inventories ----
      var receivers = instancesOf(sections.receivers);
      var processors = instancesOf(sections.processors);
      var exporters = instancesOf(sections.exporters);
      var extensions = instancesOf(sections.extensions);

      // ---- service: enabled extensions + pipelines ----
      var enabledExtensions = [];
      var pipelines = [];
      if(sections.service){
        var svcBody = sections.service.body;
        svcBody.forEach(function(e){
          if(!e.list && e.key === "extensions"){ enabledExtensions = listForKey(e, entries); }
        });
        var pipeKey = null;
        svcBody.forEach(function(e){ if(!e.list && e.key === "pipelines") pipeKey = e; });
        if(pipeKey){
          var pipeBody = descendantsOf(pipeKey, entries);
          var pipeIndent = null;
          pipeBody.forEach(function(e){ if(!e.list && (pipeIndent === null || e.indent < pipeIndent)) pipeIndent = e.indent; });
          pipeBody.forEach(function(e){
            if(!e.list && e.indent === pipeIndent){
              var p = {name:e.key, line:e.line, receivers:[], processors:[], exporters:[]};
              descendantsOf(e, entries).forEach(function(d){
                if(d.list) return;
                if(d.key === "receivers") p.receivers = listForKey(d, entries);
                if(d.key === "processors") p.processors = listForKey(d, entries);
                if(d.key === "exporters") p.exporters = listForKey(d, entries);
              });
              pipelines.push(p);
            }
          });
        }
      }
      var enabledExtTypes = enabledExtensions.map(baseType);
      function extEnabled(type){ return enabledExtTypes.indexOf(type) !== -1; }

      // ---- receiver checks ----
      var exposedReceivers = {}; // instance name -> true when bound to all interfaces with no TLS and no auth
      receivers.forEach(function(r){
        var desc = r.descendants;
        var endpoints = desc.filter(function(d){ return !d.list && d.key === "endpoint"; });
        var hasAuth = desc.some(function(d){ return !d.list && (d.key === "auth" || d.key === "authenticator"); });
        var tlsEntries = desc.filter(function(d){ return !d.list && d.key === "tls"; });
        var hasCert = desc.some(function(d){ return !d.list && d.key === "cert_file"; });
        var tlsInsecureOnly = false;
        if(tlsEntries.length){
          var tlsDesc = descendantsOf(tlsEntries[0], entries);
          tlsInsecureOnly = tlsDesc.some(function(d){ return d.key === "insecure" && stripQuotes(d.value) === "true"; }) && !hasCert;
        }
        var hasTls = hasCert || (tlsEntries.length > 0 && !tlsInsecureOnly);
        var allIfaceLines = [];
        endpoints.forEach(function(ep){ if(isAllInterfaces(hostOf(ep.value))) allIfaceLines.push(ep.line); });
        if(!endpoints.length && r.type === "otlp"){
          // The otlp receiver serves 0.0.0.0:4317 (grpc) and 0.0.0.0:4318 (http) when no endpoint is set.
          if(!hasTls && !hasAuth){
            exposedReceivers[r.name] = true;
            add("BLOCKER", r.line, "Exposed receiver", "Receiver '" + r.name + "' (line " + r.line + ") sets no endpoint, so the otlp receiver serves on all interfaces (default 0.0.0.0:4317 grpc / 0.0.0.0:4318 http) with no TLS settings and no auth extension referenced. Anyone who can reach the host can push telemetry in.");
          } else {
            add("WARNING", r.line, "Receiver bound to all interfaces", "Receiver '" + r.name + "' (line " + r.line + ") sets no endpoint, so it serves on all interfaces by default — but TLS or auth is configured. Prefer an explicit loopback or private-interface endpoint.");
          }
          return;
        }
        if(allIfaceLines.length){
          if(!hasTls && !hasAuth){
            exposedReceivers[r.name] = true;
            add("BLOCKER", allIfaceLines[0], "Exposed receiver", "Receiver '" + r.name + "' is bound to all interfaces (endpoint at line " + allIfaceLines[0] + ") with no TLS settings and no auth extension referenced. Anyone who can reach this port can push telemetry into your pipelines. Bind to a private interface, or add TLS and an auth extension.");
          } else {
            add("WARNING", allIfaceLines[0], "Receiver bound to all interfaces", "Receiver '" + r.name + "' is bound to all interfaces (endpoint at line " + allIfaceLines[0] + "). TLS/auth settings are present, which reduces the risk — still prefer a private interface where the deployment allows it.");
          }
        }
      });

      // ---- exporter checks ----
      var exporterByName = {};
      exporters.forEach(function(x){ exporterByName[x.name] = x; });
      exporters.forEach(function(x){
        x.descendants.forEach(function(d){
          if(d.list || !d.key) return;
          if(d.key === "insecure_skip_verify" && stripQuotes(d.value) === "true"){
            add("HIGH", d.line, "TLS verification off", "Exporter '" + x.name + "' sets insecure_skip_verify: true (line " + d.line + "). The exporter will accept any certificate from the endpoint, so a man-in-the-middle can intercept or alter the telemetry stream. Remove it or set it to false and fix the certificate chain instead.");
          }
          if(d.key === "insecure" && stripQuotes(d.value) === "true"){
            add("HIGH", d.line, "TLS disabled on exporter", "Exporter '" + x.name + "' sets insecure: true (line " + d.line + "), which turns TLS off for this exporter. Telemetry — which can carry sensitive payloads — travels in plaintext. Configure real TLS instead.");
          }
        });
      });

      // pipelines flattened membership
      var usedReceivers = {}, usedProcessors = {}, usedExporters = {};
      pipelines.forEach(function(p){
        p.receivers.forEach(function(n){ usedReceivers[n] = true; });
        p.processors.forEach(function(n){ usedProcessors[n] = true; });
        p.exporters.forEach(function(n){ usedExporters[n] = true; });
      });

      // debug / logging exporters
      exporters.forEach(function(x){
        if(x.type === "debug"){
          var detailed = x.descendants.some(function(d){ return d.key === "verbosity" && stripQuotes(d.value) === "detailed"; });
          if(usedExporters[x.name]){
            if(detailed) add("WARNING", x.line, "Debug exporter at detailed verbosity", "Exporter '" + x.name + "' (line " + x.line + ") runs the debug exporter with verbosity: detailed inside a live pipeline. Detailed debug output dumps full telemetry payloads to the collector log — noisy, slow, and a place sensitive data should not land in production. Drop it from the pipeline or lower the verbosity.");
            else add("WARNING", x.line, "Debug exporter in pipeline", "Exporter '" + x.name + "' (line " + x.line + ") leaves the debug exporter in a live pipeline. It writes telemetry to the collector log instead of a real destination. Remove it before deploying.");
          } else {
            add("INFO", x.line, "Debug exporter defined but unused", "Exporter '" + x.name + "' (line " + x.line + ") is defined but no pipeline uses it. Harmless, but worth removing so the next reader is not confused.");
          }
        }
        if(x.type === "logging"){
          if(usedExporters[x.name]) add("WARNING", x.line, "Logging exporter in pipeline", "Exporter '" + x.name + "' (line " + x.line + ") leaves the logging exporter in a live pipeline. It only writes to the collector log — telemetry sent there goes nowhere durable. Point the pipeline at a real exporter before deploying.");
          else add("INFO", x.line, "Logging exporter defined but unused", "Exporter '" + x.name + "' (line " + x.line + ") is defined but no pipeline uses it. Harmless, but worth removing.");
        }
      });

      // ---- processor checks ----
      var procTypes = processors.map(function(p){ return p.type; });
      var sectionLine = function(sec){ return sec ? sec.entry.line : 1; };
      var memLimiters = processors.filter(function(p){ return p.type === "memory_limiter"; });
      if(!memLimiters.length){
        add("HIGH", sectionLine(sections.processors), "memory_limiter missing", "No memory_limiter processor is defined. Without it, a traffic spike or a backed-up exporter can grow the collector's memory until the process is killed and buffered telemetry is lost. Add a memory_limiter as the first processor in every pipeline.");
      } else {
        memLimiters.forEach(function(ml){
          var keys = {};
          ml.descendants.forEach(function(d){ if(!d.list && d.key) keys[d.key] = d; });
          if(!keys.limit_mib && !keys.limit_percentage){
            add("WARNING", ml.line, "memory_limiter has no limit", "Processor '" + ml.name + "' (line " + ml.line + ") sets neither limit_mib nor limit_percentage, so it enforces no memory ceiling. Set an explicit limit sized for the host.");
          }
          if(keys.limit_percentage && parseFloat(stripQuotes(keys.limit_percentage.value)) > 90){
            add("WARNING", keys.limit_percentage.line, "memory_limiter limit very high", "Processor '" + ml.name + "' sets limit_percentage to " + stripQuotes(keys.limit_percentage.value) + " (line " + keys.limit_percentage.line + "). Above roughly 90% of host memory there is little headroom left for the rest of the process when a spike hits. Lower it.");
          }
          if(keys.check_interval){
            var cv = stripQuotes(keys.check_interval.value);
            var secs = null;
            var mm = cv.match(/^(\d+(?:\.\d+)?)s$/); if(mm) secs = parseFloat(mm[1]);
            var mmin = cv.match(/^(\d+(?:\.\d+)?)m$/); if(mmin) secs = parseFloat(mmin[1]) * 60;
            if(secs !== null && secs > 10){
              add("WARNING", keys.check_interval.line, "memory_limiter checks too slowly", "Processor '" + ml.name + "' sets check_interval to " + cv + " (line " + keys.check_interval.line + "). Memory can grow a long way between checks that far apart; 1s is the common setting. Shorten it.");
            }
          }
          if(pipelines.length && !usedProcessors[ml.name]){
            add("WARNING", ml.line, "memory_limiter not in any pipeline", "Processor '" + ml.name + "' (line " + ml.line + ") is defined but no pipeline lists it, so it limits nothing. Add it as the first processor in each pipeline.");
          }
        });
      }
      if(procTypes.indexOf("batch") === -1){
        add("INFO", sectionLine(sections.processors), "Batch processor absent", "No batch processor is defined. This is not unsafe — it only means telemetry is exported in many small requests instead of efficient batches. Add a batch processor if export volume or cost matters.");
      }
      var hasSampling = procTypes.some(function(t){ return t.indexOf("sampling") !== -1 || t === "probabilistic_sampler"; });
      if(!hasSampling){
        add("INFO", sectionLine(sections.processors), "No sampling processor", "No sampling processor (such as tail_sampling or probabilistic_sampler) is defined. Not a safety problem by itself — it means every span is kept, which can raise storage and export cost on busy services.");
      }

      // ---- extension checks ----
      extensions.forEach(function(x){
        if(x.type === "pprof"){
          if(extEnabled("pprof")) add("HIGH", x.line, "pprof extension enabled", "Extension '" + x.name + "' (line " + x.line + ") enables pprof and the service turns it on. pprof serves Go profiling endpoints (heap, goroutine, CPU) over HTTP with no authentication — useful while debugging, an information leak in production. Remove it from service extensions for a deploy.");
          else add("INFO", x.line, "pprof extension defined but not enabled", "Extension '" + x.name + "' (line " + x.line + ") defines pprof but the service does not enable it, so it is not running. No action needed unless you meant to turn it on.");
        }
        if(x.type === "zpages"){
          if(extEnabled("zpages")) add("WARNING", x.line, "zpages extension enabled", "Extension '" + x.name + "' (line " + x.line + ") enables zpages and the service turns it on. zpages serves live internal diagnostics pages over HTTP with no authentication. Fine on a trusted network while debugging; remove it or restrict its endpoint for a production deploy.");
          else add("INFO", x.line, "zpages extension defined but not enabled", "Extension '" + x.name + "' (line " + x.line + ") defines zpages but the service does not enable it, so it is not running.");
        }
        if(x.type === "health_check" && extEnabled("health_check")){
          var hcEndpoints = x.descendants.filter(function(d){ return !d.list && d.key === "endpoint"; });
          hcEndpoints.forEach(function(ep){
            if(isAllInterfaces(hostOf(ep.value))){
              add("WARNING", ep.line, "health_check bound to all interfaces", "The health_check extension endpoint (line " + ep.line + ") is bound to all interfaces. Health endpoints are usually safe to expose to a load balancer, but binding them to every interface announces the collector's status to the whole network. Bind it to the interface your checker actually uses.");
            }
          });
        }
      });

      // ---- pipeline data-path check ----
      pipelines.forEach(function(p){
        var badIn = p.receivers.filter(function(n){ return exposedReceivers[n]; });
        var externalOut = p.exporters.filter(function(n){
          var x = exporterByName[n]; var t = x ? x.type : baseType(n);
          return ["debug","logging","nop"].indexOf(t) === -1;
        });
        if(badIn.length && externalOut.length){
          add("HIGH", p.line, "Unauthenticated input flows to an external exporter", "Pipeline '" + p.name + "' (line " + p.line + ") receives from '" + badIn.join(", ") + "', which accepts unauthenticated traffic from all interfaces, and exports through '" + externalOut.join(", ") + "'. Anyone who can reach the receiver can inject fabricated traces, logs, or metrics that land in your backend as if they were real. Authenticate or restrict the receiver before deploying this pipeline.");
        }
      });

      // ---- verdict ----
      var rank = {BLOCKER:0, HIGH:1, WARNING:2, INFO:3};
      findings.sort(function(a,b){ return rank[a.severity] - rank[b.severity] || a.line - b.line; });
      var verdict, reason;
      if(findings.some(function(f){ return f.severity === "BLOCKER"; })){ verdict = "DO NOT DEPLOY"; reason = "At least one BLOCKER finding must be fixed before this config is safe to run."; }
      else if(findings.some(function(f){ return f.severity === "HIGH" || f.severity === "WARNING"; })){ verdict = "DEPLOY WITH FIXES"; reason = "No blockers, but HIGH or WARNING findings need attention first."; }
      else { verdict = "SAFE TO DEPLOY"; reason = "No BLOCKER, HIGH, or WARNING findings. INFO notes, if any, are optional reading."; }
      return {verdict:verdict, reason:reason, findings:findings, notParsed:parsed.notParsed, duplicates:parsed.duplicates, gradeable:true};
    }

    function countsOf(findings){
      var c = {BLOCKER:0, HIGH:0, WARNING:0, INFO:0};
      findings.forEach(function(f){ c[f.severity]++; });
      return c;
    }

    function buildReport(r){
      var c = countsOf(r.findings);
      var out = [];
      out.push("J-Dawgs OpenTelemetry Collector Config Safety Auditor\u2122 — Audit Report");
      out.push("Verdict: " + r.verdict);
      out.push("Why: " + r.reason);
      out.push("Findings: " + c.BLOCKER + " BLOCKER, " + c.HIGH + " HIGH, " + c.WARNING + " WARNING, " + c.INFO + " INFO");
      out.push("");
      if(r.findings.length){
        r.findings.forEach(function(f){ out.push("[" + f.severity + "] Line " + f.line + " — " + f.check + ": " + f.message); });
      } else { out.push("No findings."); }
      if(r.notParsed && r.notParsed.length){
        out.push("");
        out.push("NOT PARSED (heuristic audit could not settle these lines): lines " + r.notParsed.join(", "));
      }
      out.push("");
      out.push("Notes: heuristic line/indentation audit, not a full YAML parser and not a live schema validation. Secret values are never shown — plaintext secrets are reported by key name, line, and value length only. ${env:...} and ${file:...} references are treated as safe.");
      return out.join("\n");
    }

    function buildJson(r){
      var c = countsOf(r.findings);
      return JSON.stringify({
        tool: "J-Dawgs OpenTelemetry Collector Config Safety Auditor\u2122",
        verdict: r.verdict,
        verdict_reason: r.reason,
        gradeable: r.gradeable,
        counts: c,
        findings: r.findings.map(function(f){ return {severity:f.severity, line:f.line, check:f.check, message:f.message}; }),
        not_parsed_lines: r.notParsed || [],
        duplicates: (r.duplicates || []).map(function(d){ return {key:d.key, path:d.path, first_line:d.firstLine, duplicate_line:d.line, note:"last value wins"}; }),
        parser_note: "Heuristic line/indentation audit, not a full YAML parser. Secret values are never included; plaintext secrets are reported by key name, line, and value length only."
      }, null, 2);
    }

    var lastReport = "", lastJson = "";
    var SEV_ORDER = ["BLOCKER","HIGH","WARNING","INFO"];
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-opentelemetry-collector-config-safety-auditor',
  name: 'J-Dawgs OpenTelemetry Collector Config Safety Auditor',
  description: 'Grades a pasted OpenTelemetry Collector config.yaml offline into one deploy verdict — receivers, processors, and exporters checked, secrets shown by key name, line, and length only. The collector only exercises a config by starting on it; this grades it before anything starts.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
