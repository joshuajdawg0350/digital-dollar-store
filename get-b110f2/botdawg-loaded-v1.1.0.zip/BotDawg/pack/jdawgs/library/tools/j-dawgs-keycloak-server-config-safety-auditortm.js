'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Keycloak Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

    "use strict";

    var RISKY_EXAMPLE = [
      "# Keycloak server configuration - production (pasted for audit)",
      "db=postgres",
      "db-username=keycloak",
      "db-password=CanaryValue-7341-do-not-print",
      "db-url=jdbc:postgresql://db.internal:5432/keycloak",
      "http-enabled=true",
      "hostname=auth.example.com",
      "hostname-strict=false",
      "metrics-enabled=true",
      "features=preview"
    ].join("\n");

    var HARDENED_EXAMPLE = [
      "# Keycloak server configuration - hardened example",
      "db=postgres",
      "db-username=keycloak",
      "db-password=${env:KC_DB_PASSWORD}",
      "db-url=jdbc:postgresql://db.internal:5432/keycloak",
      "http-enabled=false",
      "https-certificate-file=/run/secrets/tls.crt",
      "https-certificate-key-file=/run/secrets/tls.key",
      "hostname=auth.example.com",
      "hostname-strict=true",
      "hostname-strict-https=true",
      "proxy=none",
      "cache=ispn",
      "metrics-enabled=false",
      "health-enabled=true"
    ].join("\n");

    var SENSITIVE_RE = /password|secret|token/i;
    var TLS_CERT_KEYS = ["https-certificate-file", "https-certificate-key-file", "https-key-store-file"];
    var KNOWN_EXACT = {};
    ("db,db-url,db-username,db-password,cache,features,features-disabled,profile,proxy,hostname," +
     "metrics-enabled,health-enabled,http-enabled,transaction-xa-enabled,log-level,vault," +
     "bootstrap-admin-username,bootstrap-admin-password,https-certificate-file,https-certificate-key-file," +
     "https-key-store-file,https-key-store-password,https-trust-store-file,https-client-auth," +
     "hostname-strict,hostname-strict-https,hostname-strict-backchannel,hostname-admin,hostname-admin-url,hostname-url"
    ).split(",").forEach(function(k){ KNOWN_EXACT[k] = true; });
    var KNOWN_PREFIXES = ["db-", "http-", "https-", "hostname", "cache-", "spi-", "log-", "proxy-", "bootstrap-"];

    function isKnownKey(key){
      if (KNOWN_EXACT[key]) return true;
      for (var i = 0; i < KNOWN_PREFIXES.length; i++){
        if (key.indexOf(KNOWN_PREFIXES[i]) === 0) return true;
      }
      return false;
    }
    function isSensitive(key){ return SENSITIVE_RE.test(key); }
    function truthy(v){ return v != null && ["true","yes","on","1"].indexOf(String(v).toLowerCase()) !== -1; }
    function falsy(v){ return v != null && ["false","no","off","0"].indexOf(String(v).toLowerCase()) !== -1; }
    function isExternalized(v){ return /^\$\{[^}]+\}$/.test(v || ""); }
    function isLocalHost(v){
      var h = String(v || "").toLowerCase();
      return h === "localhost" || h === "127.0.0.1" || h === "::1" ||
             h.slice(-6) === ".local" || h.indexOf(".") === -1;
    }

    function parseConfig(text){
      var rawLines = String(text).split(/\r?\n/);
      var entries = [];
      var notParsed = [];
      var keyMap = {};
      var commentLines = 0;
      var blankLines = 0;
      rawLines.forEach(function(raw, i){
        var lineNo = i + 1;
        var t = raw.replace(/^\s+|\s+$/g, "");
        if (!t){ blankLines++; return; }
        if (t.charAt(0) === "#" || t.charAt(0) === "!"){ commentLines++; return; }
        var idx = t.indexOf("=");
        if (idx === -1) idx = t.indexOf(":");
        if (idx <= 0){ notParsed.push(lineNo); return; }
        var key = t.slice(0, idx).replace(/^\s+|\s+$/g, "").toLowerCase();
        var value = t.slice(idx + 1).replace(/^\s+|\s+$/g, "");
        if (!key || /\s/.test(key)){ notParsed.push(lineNo); return; }
        if (key.indexOf("kc.") === 0) key = key.slice(3);
        var e = { line: lineNo, key: key, value: value };
        entries.push(e);
        if (!keyMap[key]) keyMap[key] = [];
        keyMap[key].push(e);
      });
      return {
        entries: entries, notParsed: notParsed, keyMap: keyMap,
        totalLines: rawLines.length, commentLines: commentLines, blankLines: blankLines
      };
    }

    function eff(keyMap, key){
      var a = keyMap[key];
      return a && a.length ? a[a.length - 1] : null;
    }
    function tlsConfigured(keyMap){
      for (var i = 0; i < TLS_CERT_KEYS.length; i++){
        var e = eff(keyMap, TLS_CERT_KEYS[i]);
        if (e && e.value) return e;
      }
      return null;
    }

    function audit(text){
      var parsed = parseConfig(text);
      var keyMap = parsed.keyMap;
      var findings = [];
      function add(sev, lines, key, title, detail, fix){
        findings.push({ sev: sev, lines: lines, key: key, title: title, detail: detail, fix: fix });
      }

      var httpE = eff(keyMap, "http-enabled");
      var httpOn = !!(httpE && truthy(httpE.value));
      var tlsE = tlsConfigured(keyMap);
      var proxyE = eff(keyMap, "proxy");
      var proxyMode = proxyE ? proxyE.value.toLowerCase() : null;
      var proxyTerminates = proxyMode === "edge" || proxyMode === "reencrypt";
      var hostnameE = eff(keyMap, "hostname");

      /* Duplicate keys: grade the effective (last) value, name every line. */
      Object.keys(keyMap).forEach(function(key){
        var arr = keyMap[key];
        if (arr.length < 2) return;
        var lines = arr.map(function(e){ return e.line; });
        var first = arr[0].value, last = arr[arr.length - 1].value;
        var differs = first !== last;
        var detail = "Key '" + key + "' is set on lines " + lines.join(" and ") +
          ". Only the last value (line " + arr[arr.length - 1].line + ") takes effect, and that is the value graded here." +
          (isSensitive(key) ? " Values of secret keys are never shown in this audit." :
            (differs ? " The repeated lines disagree, which is how a config quietly stops meaning what its author thinks it means."
                     : " The repeated lines agree, so this is clutter rather than a contradiction."));
        add(differs ? "WARNING" : "INFO", lines, key,
          "Repeated key: " + key,
          detail,
          "Delete the stale line(s) and keep exactly one setting for '" + key + "'.");
      });

      /* Plain HTTP / TLS posture. */
      if (httpE && httpOn){
        if (!tlsE){
          add("BLOCKER", [httpE.line], "http-enabled",
            "Plain HTTP is on and no TLS certificate is configured",
            "http-enabled=true on line " + httpE.line + ", and this paste contains no https-certificate-file, https-certificate-key-file, or https-key-store-file. Login pages, tokens, and session cookies would cross the network unencrypted.",
            "Set http-enabled=false and configure https-certificate-file + https-certificate-key-file (or a key store). If TLS is terminated by a proxy instead, say so with the proxy setting below and make sure Keycloak is reachable only through that proxy.");
        } else {
          add("WARNING", [httpE.line], "http-enabled",
            "Plain HTTP is enabled alongside HTTPS",
            "TLS is configured in this paste, but http-enabled=true on line " + httpE.line + " still serves the same login and token endpoints over plain HTTP to anyone who asks on the HTTP port.",
            "Set http-enabled=false unless the HTTP port is firewalled to a redirect-only front end that you control.");
        }
      }

      /* Hostname present, external-looking, no TLS in file. */
      if (hostnameE && hostnameE.value && !isLocalHost(hostnameE.value) && !tlsE && !proxyTerminates){
        add("WARNING", [hostnameE.line], "hostname",
          "Public hostname with no TLS configured in this file",
          "hostname is set to '" + hostnameE.value + "' on line " + hostnameE.line + ", which reads as a public deployment, but no TLS certificate is configured in this paste. If a proxy or load balancer terminates TLS in front of Keycloak, this paste alone cannot prove it — that part is NOT SETTLED from the file alone.",
          "Configure the TLS certificate in Keycloak, or set the proxy mode that matches your TLS-terminating front end so the setup is stated, not assumed.");
      }

      /* Hostname verification. */
      ["hostname-strict", "hostname-strict-https"].forEach(function(key){
        var e = eff(keyMap, key);
        if (e && falsy(e.value)){
          if (httpOn){
            add("BLOCKER", [e.line], key,
              "Hostname verification is off while plain HTTP is on",
              key + "=false on line " + e.line + " disables Keycloak's hostname checking, and http-enabled=true means those unchecked requests also travel unencrypted. Together they let the server answer for names it was never configured to serve.",
              "Set " + key + "=true, set hostname to the real public name, and turn http-enabled off.");
          } else {
            add("WARNING", [e.line], key,
              "Hostname verification is off",
              key + "=false on line " + e.line + " tells Keycloak to accept requests for hostnames other than the configured one. That weakens the link between the URL a user sees and the realm that answers.",
              "Set " + key + "=true and set hostname to the exact public hostname.");
          }
        }
      });

      /* Proxy posture. */
      if (proxyE && proxyMode){
        if (proxyMode === "edge"){
          add("WARNING", [proxyE.line], "proxy",
            "proxy=edge: TLS terminates at the edge proxy",
            "This mode is named, not silently passed: with proxy=edge on line " + proxyE.line + ", the edge proxy terminates TLS and Keycloak trusts the forwarded headers it sends (X-Forwarded-For, X-Forwarded-Proto, X-Forwarded-Host) to decide what the user's request really was. Anyone who can reach Keycloak directly, bypassing the proxy, can forge those headers.",
            "Keep proxy=edge only if Keycloak's ports are reachable solely through the edge proxy (firewall or private network), and confirm the proxy strips client-supplied X-Forwarded-* headers.");
        } else if (proxyMode === "reencrypt"){
          add("WARNING", [proxyE.line], "proxy",
            "proxy=reencrypt: TLS terminates at the proxy, then is re-encrypted to Keycloak",
            "With proxy=reencrypt on line " + proxyE.line + ", the proxy terminates the user's TLS and opens a second TLS connection to Keycloak, which trusts the proxy's forwarded headers. The exposure question is the same as edge mode: who else can reach Keycloak and inject those headers?",
            "Confirm Keycloak itself holds a valid certificate for the re-encrypted hop and that only the proxy can reach Keycloak's ports.");
        } else if (proxyMode === "passthrough"){
          add("WARNING", [proxyE.line], "proxy",
            "proxy=passthrough: TLS passes through the proxy untouched",
            "With proxy=passthrough on line " + proxyE.line + ", the proxy does not terminate TLS — Keycloak itself must hold the certificate and do the encryption. Forwarded-header trust is not the issue here; an absent or expired Keycloak certificate is.",
            "Make sure https-certificate-file and https-certificate-key-file are set in Keycloak and renewed like any other production certificate.");
        } else if (proxyMode === "none"){
          add("INFO", [proxyE.line], "proxy",
            "proxy=none: no proxy header trust declared",
            "proxy=none on line " + proxyE.line + " states that no reverse proxy fronts Keycloak, so forwarded headers are not part of the trust picture.",
            "No change needed. If a proxy is added later, update this setting in the same change.");
        } else {
          add("WARNING", [proxyE.line], "proxy",
            "Unrecognized proxy mode",
            "The proxy value on line " + proxyE.line + " is not one of the documented modes (none, edge, reencrypt, passthrough), so this auditor cannot settle what header trust it creates.",
            "Set proxy to the documented mode that matches your deployment.");
        }
      }
      var proxyHeadersE = eff(keyMap, "proxy-headers");
      if (proxyHeadersE && proxyHeadersE.value && proxyHeadersE.value.toLowerCase() !== "none"){
        add("WARNING", [proxyHeadersE.line], "proxy-headers",
          "Forwarded proxy headers are trusted",
          "proxy-headers on line " + proxyHeadersE.line + " tells Keycloak to trust X-Forwarded-* (or Forwarded) headers when building URLs and reading client addresses. That is correct behind a proxy that sets them — and spoofable by anyone who can reach Keycloak directly.",
          "Restrict network access to Keycloak so only the proxy can reach it, and have the proxy overwrite, not append, client-supplied forwarded headers.");
      }

      /* Dev / preview posture. */
      var featuresE = eff(keyMap, "features");
      if (featuresE && /(^|[,\s])preview([,\s]|$)/i.test(featuresE.value)){
        add("WARNING", [featuresE.line], "features",
          "Preview features are enabled",
          "The features setting on line " + featuresE.line + " turns on Keycloak's preview feature set: behavior that upstream has not finished stabilizing, in a config that is otherwise shaped like production.",
          "Remove 'preview' from features for production, and enable individual preview features by name only after testing them.");
      }
      var profileE = eff(keyMap, "profile");
      if (profileE && /dev|preview/i.test(profileE.value)){
        add("WARNING", [profileE.line], "profile",
          "A dev/preview profile is selected",
          "The profile setting on line " + profileE.line + " selects a development or preview posture rather than the production one.",
          "Run production with the prod profile (kc.sh start, not start-dev) and keep dev profiles on dev machines.");
      }

      /* Metrics / health exposure: never a blocker on its own. */
      var metricsE = eff(keyMap, "metrics-enabled");
      if (metricsE && truthy(metricsE.value)){
        add("WARNING", [metricsE.line], "metrics-enabled",
          "Metrics endpoint is enabled",
          "metrics-enabled=true on line " + metricsE.line + " exposes operational metrics (request counts, timings, pool sizes). Useful to your monitoring, revealing to anyone else who can reach the endpoint.",
          "Keep metrics enabled only if the metrics path is restricted to your monitoring network or management interface; otherwise set metrics-enabled=false.");
      }
      var healthE = eff(keyMap, "health-enabled");
      if (healthE && truthy(healthE.value)){
        add("INFO", [healthE.line], "health-enabled",
          "Health endpoint is enabled",
          "health-enabled=true on line " + healthE.line + " exposes liveness/readiness checks, which orchestrators normally need. The exposure is small, but it still answers strangers who ask.",
          "No change needed if health is reachable only from your orchestrator or management network.");
      }

      /* Secret-bearing keys: flagged by key name and line only, value never read into output. */
      Object.keys(keyMap).forEach(function(key){
        if (!isSensitive(key)) return;
        var e = eff(keyMap, key);
        if (!e) return;
        if (key.indexOf("bootstrap") !== -1){
          add("WARNING", [e.line], key,
            "Bootstrap admin credential sits in the config",
            "The key '" + key + "' on line " + e.line + " holds the bootstrap admin credential in the standing configuration. (Its value is never shown in this audit.) A bootstrap secret is meant to create the first admin once — left in place, it stays a standing way in for anyone who reads this file.",
            "Create the admin, then remove this line from the config and rotate the admin password. If automation truly needs it, inject it at deploy time and delete it after first start.");
        } else if (!e.value){
          add("INFO", [e.line], key,
            "Secret key is set but empty",
            "The key '" + key + "' on line " + e.line + " has no value in this paste, so there is no plaintext secret to grade. Where the real value comes from is NOT SETTLED from this file alone.",
            "Confirm the value is injected at deploy time from your secret store or environment.");
        } else if (isExternalized(e.value)){
          add("INFO", [e.line], key,
            "Secret is an externalized reference",
            "The key '" + key + "' on line " + e.line + " points at an external reference instead of holding a plaintext value in the file, so there is no secret in the paste to expose. (The reference itself is not printed.)",
            "No change needed. Keep the referenced secret in the vault/environment and out of the config file.");
        } else if (key === "db-password" || /db.*password/.test(key)){
          add("WARNING", [e.line], key,
            "Plaintext database password in the config file",
            "The key '" + key + "' on line " + e.line + " holds a plaintext database password. (Its value is never shown in this audit.) Plainly: config files legitimately hold this — Keycloak has to read it to reach the database — so this is a hygiene warning, not an accusation. The risk is everywhere the file travels: repos, backups, tickets, screenshots.",
            "Prefer an externalized reference (for example an environment or vault lookup) where your deployment supports it; otherwise lock the file's permissions down, keep it out of version control, and rotate the password if the file has been shared.");
        } else {
          add("WARNING", [e.line], key,
            "Plaintext secret in the config file",
            "The key '" + key + "' on line " + e.line + " holds a plaintext secret value. (Its value is never shown in this audit.) Anyone who can read this file holds the secret.",
            "Move the value to your secret store or environment and reference it from the config; rotate the secret if this file has been shared.");
        }
      });

      /* Weak hashing posture where stated. */
      Object.keys(keyMap).forEach(function(key){
        if (!/hash/i.test(key)) return;
        var e = eff(keyMap, key);
        if (e && /md5|sha-?1\b|plain/i.test(e.value)){
          add("WARNING", [e.line], key,
            "Weak password hashing is stated in the config",
            "The hashing setting on line " + e.line + " names a weak or obsolete algorithm. Password hashes are only as strong as the algorithm that produced them.",
            "Use Keycloak's current default password hashing (PBKDF2 with the recommended iteration count) and let old hashes upgrade at next login.");
        }
      });

      /* Cache / clustering contradiction shown by the paste itself. */
      var cacheE = eff(keyMap, "cache");
      if (cacheE && cacheE.value.toLowerCase() === "local"){
        var stackE = eff(keyMap, "cache-stack");
        var remoteE = eff(keyMap, "cache-remote-host");
        var other = stackE || remoteE;
        if (other){
          add("WARNING", [cacheE.line, other.line], "cache",
            "Cache posture contradicts itself",
            "cache=local on line " + cacheE.line + " says this node keeps its cache to itself, but '" + other.key + "' on line " + other.line + " describes clustered/remote caching. Both cannot be the operating picture; one of them is leftover.",
            "Pick one posture: cache=local for a genuine single node, or a clustered cache (for example cache=ispn with a stack) for multiple nodes — and delete the lines that describe the other.");
        }
      }

      /* Unknown keys: counted, never audited by name. */
      var unknownKeys = Object.keys(keyMap).filter(function(k){ return !isKnownKey(k); });

      /* NOT SET IN FILE list. */
      var notSet = [];
      if (!httpE){
        notSet.push("http-enabled — NOT SET IN FILE. Keycloak's documented default is false, so plain HTTP stays off unless a line turns it on (secure default).");
      }
      if (!tlsE){
        notSet.push("https-certificate-file / https-certificate-key-file — NOT SET IN FILE. No TLS certificate is configured in this paste. TLS may still terminate at a proxy or load balancer, but that lives outside this file, so the end-to-end posture is NOT SETTLED from the paste alone.");
      }
      if (!hostnameE){
        notSet.push("hostname — NOT SET IN FILE. By default Keycloak builds URLs from the incoming request's host, which is only as safe as the proxy in front of it (NOT SETTLED from this file alone).");
      }
      if (!eff(keyMap, "hostname-strict")){
        notSet.push("hostname-strict — NOT SET IN FILE. Keycloak's documented default is true (strict hostname checking on).");
      }
      if (!proxyE && !proxyHeadersE){
        notSet.push("proxy — NOT SET IN FILE. No proxy mode is declared; whether forwarded headers are trusted then depends on the Keycloak version's defaults and the separate proxy-headers setting (NOT SETTLED).");
      }
      if (!eff(keyMap, "metrics-enabled")){
        notSet.push("metrics-enabled — NOT SET IN FILE. Keycloak's documented default is false (metrics endpoint off).");
      }
      var hasBootstrap = Object.keys(keyMap).some(function(k){ return k.indexOf("bootstrap") !== -1 && isSensitive(k); });
      if (!hasBootstrap){
        notSet.push("bootstrap-admin-password — NOT SET IN FILE. Good: no bootstrap admin secret is sitting in this configuration.");
      }

      var sevRank = { BLOCKER: 0, WARNING: 1, INFO: 2 };
      findings.sort(function(a, b){
        if (sevRank[a.sev] !== sevRank[b.sev]) return sevRank[a.sev] - sevRank[b.sev];
        return a.lines[0] - b.lines[0];
      });

      var blockers = findings.filter(function(f){ return f.sev === "BLOCKER"; }).length;
      var warnings = findings.filter(function(f){ return f.sev === "WARNING"; }).length;
      var infos = findings.filter(function(f){ return f.sev === "INFO"; }).length;
      var verdict = null;
      if (parsed.entries.length){
        verdict = blockers > 0 ? "DO NOT DEPLOY" : (warnings > 0 ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY");
      }

      return {
        parsed: parsed, findings: findings, notSet: notSet,
        unknownCount: unknownKeys.length,
        blockers: blockers, warnings: warnings, infos: infos,
        verdict: verdict
      };
    }

    function buildReport(r){
      var out = [];
      out.push("KEYCLOAK SERVER CONFIG SAFETY AUDIT");
      out.push("J-Dawgs Keycloak Server Config Safety Auditor\u2122");
      out.push("");
      if (!r.verdict){
        out.push("Verdict: NO CONFIG TO GRADE (no key=value lines were parsed)");
      } else {
        out.push("Verdict: " + r.verdict);
      }
      out.push("Blockers: " + r.blockers + " | Warnings: " + r.warnings + " | Info: " + r.infos);
      out.push("Lines read: " + r.parsed.totalLines +
               " | Keys parsed: " + r.parsed.entries.length +
               " | Comment lines ignored: " + r.parsed.commentLines +
               " | Unknown keys NOT AUDITED: " + r.unknownCount);
      out.push("");
      out.push("FINDINGS");
      if (!r.findings.length) out.push("(none)");
      r.findings.forEach(function(f){
        out.push("[" + f.sev + "] Line" + (f.lines.length > 1 ? "s" : "") + " " + f.lines.join(", ") + " | " + f.key + " - " + f.title);
        out.push("  " + f.detail);
        out.push("  Fix: " + f.fix);
      });
      out.push("");
      out.push("NOT PARSED");
      if (!r.parsed.notParsed.length) out.push("(none)");
      r.parsed.notParsed.forEach(function(n){
        out.push("Line " + n + ": NOT PARSED (no key=value on this line) - excluded from grading.");
      });
      out.push("");
      out.push("NOT SET IN FILE");
      r.notSet.forEach(function(s){ out.push("- " + s); });
      out.push("");
      out.push("Secret values never appear in this report: secret keys are flagged by key name and line number only. Commented-out keys count as NOT SET. Unknown keys are NOT AUDITED by name.");
      return out.join("\n");
    }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-keycloak-server-config-safety-auditortm',
  name: 'J-Dawgs Keycloak Server Config Safety Auditor',
  description: 'Keycloak startup only answers whether the config loads; this grades a pasted keycloak.conf offline, anywhere — HTTP/TLS posture, hostname settings, exposure, and credentials named by key name and line only — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
