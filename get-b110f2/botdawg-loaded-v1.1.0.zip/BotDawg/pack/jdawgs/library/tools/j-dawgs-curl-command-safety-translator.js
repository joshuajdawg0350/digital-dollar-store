'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Curl Command Safety & Translation Bench".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the analyze function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var BAD_SAMPLE = "curl -k -X POST http://api.example.com/v1/charges \\\n  -H \"Authorization: Bearer sk_live_9f2KxQ7exampleTOKEN\" \\\n  -H \"Content-Type: application/json\" \\\n  -d '{\"amount\": 2500, \"currency\": \"usd\"}'";
        var GOOD_SAMPLE = "curl https://api.example.com/v1/widgets \\\n  -H \"Accept: application/json\"";

        var input = document.getElementById("curlInput");
        var errorBox = document.getElementById("errorBox");
        var results = document.getElementById("results");
        var verdictBox = document.getElementById("verdictBox");
        var parsedGrid = document.getElementById("parsedGrid");
        var findingsList = document.getElementById("findingsList");
        var fetchOut = document.getElementById("fetchOut");
        var curlOut = document.getElementById("curlOut");
        var reportOut = document.getElementById("reportOut");

        var lastFetch = "", lastCurl = "", lastReport = "";

        function mask(value) {
          if (!value) return "";
          if (value.length <= 2) return value.charAt(0) + "••";
          return value.slice(0, 2) + "••• (" + value.length + " chars, masked)";
        }

        // ---- Tokenizer: handles line continuations, single/double quotes, escapes ----
        function tokenize(str) {
          var tokens = [];
          var cur = "";
          var has = false;
          var i = 0;
          var quote = null;
          while (i < str.length) {
            var c = str.charAt(i);
            if (quote === "'") {
              if (c === "'") { quote = null; i++; }
              else { cur += c; i++; }
              continue;
            }
            if (quote === '"') {
              if (c === '"') { quote = null; i++; }
              else if (c === "\\" && i + 1 < str.length) {
                var n = str.charAt(i + 1);
                if (n === "\n") { i += 2; }
                else if (n === '"' || n === "\\" || n === "$" || n === "`") { cur += n; i += 2; }
                else { cur += c; i++; }
              } else { cur += c; i++; }
              continue;
            }
            // unquoted
            if (c === "\\" && i + 1 < str.length) {
              var nx = str.charAt(i + 1);
              if (nx === "\n") { i += 2; continue; } // line continuation
              cur += nx; has = true; i += 2; continue;
            }
            if (c === "'") { quote = "'"; has = true; i++; continue; }
            if (c === '"') { quote = '"'; has = true; i++; continue; }
            if (c === "$" && str.charAt(i + 1) === "'") { quote = "'"; has = true; i += 2; continue; }
            if (/\s/.test(c)) {
              if (has || cur.length) { tokens.push(cur); cur = ""; has = false; }
              i++; continue;
            }
            cur += c; has = true; i++;
          }
          if (has || cur.length) tokens.push(cur);
          if (quote !== null) {
            return { tokens: tokens, unterminated: true };
          }
          return { tokens: tokens, unterminated: false };
        }

        var FLAGS_WITH_VALUE = {
          "-X": "method", "--request": "method",
          "-H": "header", "--header": "header",
          "-d": "data", "--data": "data", "--data-raw": "data", "--data-ascii": "data",
          "--data-binary": "data", "--data-urlencode": "dataUrlencode",
          "-u": "user", "--user": "user",
          "-A": "userAgent", "--user-agent": "userAgent",
          "-e": "referer", "--referer": "referer",
          "-b": "cookie", "--cookie": "cookie",
          "--url": "url",
          "-o": "outputFile", "--output": "outputFile",
          "--max-time": "maxTime", "--connect-timeout": "connectTimeout",
          "-m": "maxTime",
          "--retry": "retry"
        };
        var FLAGS_NO_VALUE = {
          "-k": "insecure", "--insecure": "insecure",
          "-L": "follow", "--location": "follow",
          "-i": "include", "--include": "include",
          "-v": "verbose", "--verbose": "verbose",
          "-s": "silent", "--silent": "silent",
          "-S": "showError", "--show-error": "showError",
          "-f": "fail", "--fail": "fail",
          "-G": "get", "--get": "get",
          "--compressed": "compressed",
          "--json": "json",
          "-g": "globoff", "--globoff": "globoff",
          "-N": "noBuffer", "--no-buffer": "noBuffer"
        };
        var SHORT_WITH_VALUE = { "X": 1, "H": 1, "d": 1, "u": 1, "A": 1, "e": 1, "b": 1, "o": 1, "m": 1 };
        var SHORT_NO_VALUE = { "k": "insecure", "L": "follow", "i": "include", "v": "verbose", "s": "silent", "S": "showError", "f": "fail", "G": "get", "g": "globoff", "N": "noBuffer" };

        function parseCurl(tokens) {
          var p = {
            method: null, url: null, headers: [], dataParts: [],
            dataUrlencodeParts: [], insecure: false, follow: false,
            user: null, userAgent: null, referer: null, cookie: null,
            json: false, get: false, outputFile: null,
            notParsed: [], extraUrls: [], hasDataFlag: false
          };
          var i = 1; // skip "curl"
          while (i < tokens.length) {
            var t = tokens[i];
            if (t === "--") { i++; continue; }
            if (t.charAt(0) === "-" && t !== "-" && !/^-\d/.test(t)) {
              if (t.charAt(1) === "-") {
                // long flag
                var eq = t.indexOf("=");
                var name = eq >= 0 ? t.slice(0, eq) : t;
                var inlineVal = eq >= 0 ? t.slice(eq + 1) : null;
                if (Object.prototype.hasOwnProperty.call(FLAGS_WITH_VALUE, name)) {
                  var kind = FLAGS_WITH_VALUE[name];
                  var val = inlineVal;
                  if (val === null) {
                    if (i + 1 >= tokens.length) { p.notParsed.push(name + " (missing value)"); i++; continue; }
                    val = tokens[i + 1]; i++;
                  }
                  applyValue(p, kind, val);
                  i++; continue;
                }
                if (Object.prototype.hasOwnProperty.call(FLAGS_NO_VALUE, name)) {
                  applyFlag(p, FLAGS_NO_VALUE[name]);
                  i++; continue;
                }
                p.notParsed.push(t);
                i++; continue;
              }
              // short flag cluster, e.g. -skL or -X POST attached/separate
              var cluster = t.slice(1);
              var j = 0; var consumedNext = false; var clusterOk = true;
              while (j < cluster.length) {
                var ch = cluster.charAt(j);
                if (Object.prototype.hasOwnProperty.call(SHORT_NO_VALUE, ch)) {
                  applyFlag(p, SHORT_NO_VALUE[ch]);
                  j++; continue;
                }
                if (Object.prototype.hasOwnProperty.call(SHORT_WITH_VALUE, ch)) {
                  var rest = cluster.slice(j + 1);
                  var v2;
                  if (rest.length) { v2 = rest; }
                  else if (i + 1 < tokens.length) { v2 = tokens[i + 1]; consumedNext = true; }
                  else { p.notParsed.push("-" + ch + " (missing value)"); j = cluster.length; break; }
                  applyValue(p, FLAGS_WITH_VALUE["-" + ch], v2);
                  j = cluster.length; break;
                }
                p.notParsed.push("-" + ch);
                clusterOk = false;
                j++;
              }
              void clusterOk;
              if (consumedNext) i++;
              i++; continue;
            }
            // bare token: URL (or value out of place)
            if (!p.url) { p.url = t; }
            else { p.extraUrls.push(t); }
            i++;
          }
          return p;
        }

        function applyFlag(p, kind) {
          if (kind === "insecure") p.insecure = true;
          else if (kind === "follow") p.follow = true;
          else if (kind === "json") p.json = true;
          else if (kind === "get") p.get = true;
        }

        function applyValue(p, kind, val) {
          switch (kind) {
            case "method": p.method = val.toUpperCase(); break;
            case "header": p.headers.push(val); break;
            case "data": p.dataParts.push(val); p.hasDataFlag = true; break;
            case "dataUrlencode": p.dataUrlencodeParts.push(val); p.hasDataFlag = true; break;
            case "user": p.user = val; break;
            case "userAgent": p.userAgent = val; break;
            case "referer": p.referer = val; break;
            case "cookie": p.cookie = val; break;
            case "url": if (!p.url) p.url = val; else p.extraUrls.push(val); break;
            case "outputFile": p.outputFile = val; break;
            default: break; // maxTime / connectTimeout / retry: parsed, noted not translated
          }
        }

        var PASSWORD_FIELDS = ["password", "passwd", "pwd", "pass", "secret", "client_secret", "api_key", "apikey", "api-key", "token", "access_token", "refresh_token", "auth", "private_key"];

        function findPasswordFields(body) {
          var found = [];
          if (!body) return found;
          // JSON-ish "field": "value" and form field=value
          var re = /"?([A-Za-z0-9_\-\.]+)"?\s*[:=]\s*"?([^"&,}\s]+)"?/g;
          var m;
          while ((m = re.exec(body)) !== null) {
            var name = m[1].toLowerCase();
            for (var k = 0; k < PASSWORD_FIELDS.length; k++) {
              if (name === PASSWORD_FIELDS[k] || name.slice(-PASSWORD_FIELDS[k].length - 1) === "_" + PASSWORD_FIELDS[k] || name.indexOf(PASSWORD_FIELDS[k]) !== -1) {
                found.push({ field: m[1], value: m[2] });
                break;
              }
            }
          }
          return found;
        }

        function splitHeader(h) {
          var idx = h.indexOf(":");
          if (idx < 0) return { name: h.trim(), value: "" };
          return { name: h.slice(0, idx).trim(), value: h.slice(idx + 1).trim() };
        }

        function authType(value) {
          var first = value.split(/\s+/)[0];
          if (/^Bearer$/i.test(first)) return "Bearer token";
          if (/^Basic$/i.test(first)) return "Basic (base64 user:password)";
          if (/^Digest$/i.test(first)) return "Digest credential";
          if (/^ApiKey$/i.test(first) || /^Api-Key$/i.test(first)) return "API key";
          return "credential (" + first + " scheme)";
        }

        function authSecret(value) {
          var parts = value.split(/\s+/);
          return parts.length > 1 ? parts.slice(1).join(" ") : value;
        }

        function parseUrlInfo(url) {
          var info = { scheme: null, host: null, userinfo: null, user: null, pass: null, clean: url };
          var m = /^([A-Za-z][A-Za-z0-9+.\-]*):\/\/([^/?#]*)([\s\S]*)$/.exec(url);
          if (!m) return info;
          info.scheme = m[1].toLowerCase();
          var authority = m[2];
          var rest = m[3] || "";
          var at = authority.lastIndexOf("@");
          if (at >= 0) {
            info.userinfo = authority.slice(0, at);
            var hostPart = authority.slice(at + 1);
            var colon = info.userinfo.indexOf(":");
            if (colon >= 0) {
              info.user = decodeSafe(info.userinfo.slice(0, colon));
              info.pass = decodeSafe(info.userinfo.slice(colon + 1));
            } else {
              info.user = decodeSafe(info.userinfo);
            }
            info.host = hostPart;
            info.clean = m[1] + "://" + hostPart + rest;
          } else {
            info.host = authority;
          }
          return info;
        }

        function decodeSafe(s) {
          try { return decodeURIComponent(s); } catch (e) { return s; }
        }

        function jsString(s) {
          return '"' + String(s).replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\n/g, "\\n").replace(/\r/g, "\\r") + '"';
        }

        function shellQuote(s) {
          return "'" + String(s).replace(/'/g, "'\\''") + "'";
        }

        function analyze(tokens, unterminated) {
          var findings = [];
          function add(sev, title, detail) { findings.push({ sev: sev, title: title, detail: detail }); }

          var p = parseCurl(tokens);
          var urlInfo = p.url ? parseUrlInfo(p.url) : { scheme: null, host: null, userinfo: null, clean: p.url };
          var body = p.dataParts.join("&");
          var method = p.method;
          if (!method) {
            if (p.get) method = "GET";
            else if (p.hasDataFlag || p.json) method = "POST";
            else method = "GET";
          }

          // Headers parse
          var headerObjs = p.headers.map(splitHeader);
          var authHeaders = headerObjs.filter(function (h) { return /^authorization$/i.test(h.name); });

          // ---- AUDIT ----
          if (p.insecure) {
            add("critical", "-k / --insecure present — TLS verification is OFF",
              "The command tells curl not to verify the server's certificate. Anyone positioned between the agent and the server can intercept or alter the request and response, including any credentials it carries. The cleaned curl below removes this flag.");
          }
          if (urlInfo.userinfo) {
            var credDesc = urlInfo.pass !== null && urlInfo.pass !== undefined
              ? "username \"" + mask(urlInfo.user || "") + "…\" with a password embedded"
              : "a username embedded (no password portion)";
            add("critical", "Credentials embedded in the URL — " + credDesc,
              "Credentials in a URL leak into shell history, logs, and screenshots, and get sent on redirects. Value masked to its first 2 characters. The translations below strip the credentials out of the URL entirely.");
          }
          authHeaders.forEach(function (h) {
            var type = authType(h.value);
            var secret = authSecret(h.value);
            add("critical", "Authorization header carries a " + type,
              "Credential type: " + type + ". Value masked: " + mask(secret) + ". Anyone who can read this pasted command owns this credential — treat a real one as compromised if it was shared in a ticket or chat. Translations replace it with a placeholder.");
          });
          if (p.user) {
            var uParts = p.user.split(":");
            add("critical", "-u / --user embeds credentials in the command",
              uParts.length > 1
                ? "Username \"" + mask(uParts[0]) + "…\" with a password in plain text (masked: " + mask(uParts.slice(1).join(":")) + "). It lands in shell history and process lists."
                : "Username supplied via -u (masked: " + mask(uParts[0]) + ").");
          }
          var isHttp = urlInfo.scheme === "http";
          if (isHttp && (authHeaders.length > 0 || p.user)) {
            add("critical", "Credentials sent over plain http:// (no TLS)",
              "The URL uses http:// while the command carries an Authorization credential. That credential crosses the network readable by anyone on the path. Move to the https:// endpoint before running anything.");
          } else if (isHttp && body) {
            add("critical", "Request body sent over plain http:// (no TLS)",
              "The URL uses http:// and the command sends a request body. Body contents cross the network unencrypted. Move to the https:// endpoint before running anything.");
          } else if (isHttp) {
            add("review", "Plain http:// URL (no TLS)",
              "No credentials or body were found in this command, but the traffic itself is unencrypted. Prefer the https:// endpoint if one exists.");
          }
          var pwFields = findPasswordFields(body).concat(findPasswordFields(p.dataUrlencodeParts.join("&")));
          pwFields.forEach(function (f) {
            add("review", "Password-like field in the request body: \"" + f.field + "\"",
              "The --data payload includes a field named \"" + f.field + "\" with value masked: " + mask(f.value) + ". If that is a real secret, it is now in shell history and wherever this command was pasted from. Translations replace it with a placeholder.");
          });
          if (method === "DELETE" || method === "PUT") {
            add("review", "REVIEW — destructive method: " + method,
              method === "DELETE"
                ? "DELETE removes whatever the URL points at. Confirm the exact target resource before running; there is usually no undo."
                : "PUT replaces the target resource wholesale. Confirm the URL and the full body represent the intended final state before running.");
          }
          if (method === "PATCH") {
            add("note", "Method is PATCH — partial update",
              "PATCH modifies part of the target resource. Lower risk than DELETE/PUT, but confirm the target URL before running.");
          }
          if (p.notParsed.length) {
            add("note", "NOT PARSED: " + p.notParsed.join(", "),
              "These flags are not in the set this bench understands. They were not silently dropped — they are listed here, excluded from the translations, and the verdict does not account for whatever they do. Check them against `curl --help` before running.");
          }
          if (p.extraUrls.length) {
            add("note", "Extra URL-like arguments ignored: " + p.extraUrls.join(", "),
              "curl accepts multiple URLs; this bench audits the first one. The extras are listed here, not dropped silently.");
          }
          if (p.outputFile) {
            add("note", "Output is written to a file (-o " + p.outputFile + ")",
              "fetch() has no direct equivalent; the translation below returns the response in code instead of saving it to disk.");
          }
          if (unterminated) {
            add("note", "Unterminated quote in the pasted command",
              "A quote opens and never closes. The parse above is a best effort — the original shell would reject this command as pasted.");
          }

          var hasCritical = findings.some(function (f) { return f.sev === "critical"; });
          var hasReview = findings.some(function (f) { return f.sev === "review"; });
          var verdict, verdictClass, verdictWhy;
          if (hasCritical) {
            verdict = "DO NOT RUN AS PASTED"; verdictClass = "danger";
            verdictWhy = "At least one critical problem above must be fixed first. Use the cleaned curl or the fetch() translation — both already apply the fixes.";
          } else if (hasReview || p.notParsed.length) {
            verdict = "RUN WITH FIXES"; verdictClass = "fixes";
            verdictWhy = hasReview
              ? "Nothing critical, but review the items above before running — a destructive method or a secret in the body deserves a deliberate look."
              : "Nothing dangerous was found in what could be parsed, but some flags were NOT PARSED. Account for them before running.";
          } else {
            verdict = "SAFE TO RUN"; verdictClass = "safe";
            verdictWhy = "No problems found in the checks this bench performs. (It cannot vouch for the destination server — see Honest limits.)";
            if (!findings.length) {
              add("ok", "No findings", "Method, URL, headers, body, and flags all parsed cleanly. No insecure flag, no embedded credentials, no plain-http exposure, no password-like body fields, no destructive method.");
            }
          }

          // ---- TRANSLATE: fetch ----
          var cleanUrl = urlInfo.clean || p.url;
          var fetchHeaders = [];
          headerObjs.forEach(function (h) {
            if (/^authorization$/i.test(h.name)) {
              var scheme = h.value.split(/\s+/)[0];
              var isSchemeOnly = h.value.trim().split(/\s+/).length > 1;
              fetchHeaders.push({ name: h.name, value: isSchemeOnly ? scheme + " YOUR_TOKEN_HERE" : "YOUR_TOKEN_HERE" });
            } else if (/^cookie$/i.test(h.name) && p.cookie) {
              fetchHeaders.push({ name: h.name, value: h.value });
            } else {
              fetchHeaders.push({ name: h.name, value: h.value });
            }
          });
          if (p.userAgent) fetchHeaders.push({ name: "User-Agent", value: p.userAgent });
          if (p.referer) fetchHeaders.push({ name: "Referer", value: p.referer });
          if (p.cookie && !headerObjs.some(function (h) { return /^cookie$/i.test(h.name); })) {
            fetchHeaders.push({ name: "Cookie", value: p.cookie });
          }
          if (p.user) {
            var up = p.user.split(":");
            fetchHeaders.push({ name: "Authorization", value: "Basic " + "YOUR_TOKEN_HERE" });
            void up;
          }
          if (p.json && !headerObjs.some(function (h) { return /^content-type$/i.test(h.name); })) {
            fetchHeaders.push({ name: "Content-Type", value: "application/json" });
            fetchHeaders.push({ name: "Accept", value: "application/json" });
          }

          var fetchBody = null;
          var rawBody = body;
          if (p.dataUrlencodeParts.length) {
            rawBody = (rawBody ? rawBody + "&" : "") + p.dataUrlencodeParts.map(function (part) {
              var eq = part.indexOf("=");
              if (eq < 0) return part;
              return part.slice(0, eq) + "=" + encodeURIComponent(part.slice(eq + 1));
            }).join("&");
          }
          if (rawBody) {
            fetchBody = rawBody;
            pwFields.forEach(function (f) {
              fetchBody = fetchBody.split(f.value).join("YOUR_TOKEN_HERE");
            });
          }
          if (p.get && fetchBody) {
            var sep = cleanUrl.indexOf("?") >= 0 ? "&" : "?";
            cleanUrl = cleanUrl + sep + fetchBody;
            fetchBody = null;
          }

          var fetchLines = [];
          var needsOpts = method !== "GET" || fetchHeaders.length || fetchBody || p.follow;
          if (!needsOpts) {
            fetchLines.push("const response = await fetch(" + jsString(cleanUrl) + ");");
          } else {
            fetchLines.push("const response = await fetch(" + jsString(cleanUrl) + ", {");
            var opts = [];
            if (method !== "GET") opts.push("  method: " + jsString(method));
            if (fetchHeaders.length) {
              var hLines = fetchHeaders.map(function (h) { return "    " + jsString(h.name) + ": " + jsString(h.value); });
              opts.push("  headers: {\n" + hLines.join(",\n") + "\n  }");
            }
            if (fetchBody) opts.push("  body: " + jsString(fetchBody));
            if (p.follow === false) { /* default fetch follows redirects, like curl without -L does not; note below */ }
            fetchLines.push(opts.join(",\n"));
            fetchLines.push("});");
          }
          if (!p.follow) {
            fetchLines.push("// Note: fetch() follows redirects by default; curl without -L does not.");
            fetchLines.push("// Add redirect: \"manual\" above if you need curl's exact behavior.");
          }
          fetchLines.push("const text = await response.text();");
          fetchLines.push("console.log(response.status, text);");
          var fetchCode = fetchLines.join("\n");

          // ---- TRANSLATE: cleaned curl ----
          var curlParts = ["curl"];
          if (p.follow) curlParts.push("-L");
          if (method !== "GET" || p.hasDataFlag) curlParts.push("-X " + method);
          curlParts.push(shellQuote(cleanUrl));
          headerObjs.forEach(function (h) {
            if (/^authorization$/i.test(h.name)) {
              var scheme2 = h.value.split(/\s+/)[0];
              var two = h.value.trim().split(/\s+/).length > 1;
              curlParts.push("-H " + shellQuote(h.name + ": " + (two ? scheme2 + " $TOKEN" : "$TOKEN")));
            } else {
              curlParts.push("-H " + shellQuote(h.name + ": " + h.value));
            }
          });
          if (p.user) curlParts.push("-H " + shellQuote("Authorization: Basic $TOKEN"));
          if (p.userAgent) curlParts.push("-A " + shellQuote(p.userAgent));
          if (p.referer) curlParts.push("-e " + shellQuote(p.referer));
          if (p.cookie) curlParts.push("-b " + shellQuote(p.cookie));
          if (p.json) curlParts.push("--json");
          if (fetchBody) {
            curlParts.push("--data " + shellQuote(fetchBody.split("YOUR_TOKEN_HERE").join("$TOKEN")));
          } else if (p.dataUrlencodeParts.length && !p.get) {
            // already folded into fetchBody above; nothing extra
          }
          var cleanedCurl = curlParts.join(" \\\n  ");

          // ---- Report ----
          var rep = [];
          rep.push("J-Dawgs Curl Command Safety & Translation Bench — Report");
          rep.push("Verdict: " + verdict);
          rep.push("Method: " + method + "  |  URL: " + cleanUrl + "  |  Headers: " + headerObjs.length + "  |  Body: " + (body ? "yes" : "no"));
          rep.push("");
          rep.push("Findings:");
          findings.forEach(function (f, idx) {
            rep.push((idx + 1) + ". [" + f.sev.toUpperCase() + "] " + f.title);
            rep.push("   " + f.detail);
          });
          rep.push("");
          rep.push("fetch() translation:");
          rep.push(fetchCode);
          rep.push("");
          rep.push("Cleaned curl:");
          rep.push(cleanedCurl);
          var report = rep.join("\n");

          return {
            parsed: p, urlInfo: urlInfo, method: method, findings: findings,
            verdict: verdict, verdictClass: verdictClass, verdictWhy: verdictWhy,
            fetchCode: fetchCode, cleanedCurl: cleanedCurl, report: report,
            headerCount: headerObjs.length, hasBody: !!body
          };
        }

        function showError(msg) {
          errorBox.textContent = msg;
          errorBox.classList.add("show");
          results.classList.remove("show");
        }
        function clearError() {
          errorBox.textContent = "";
          errorBox.classList.remove("show");
        }
  return { "analyze": (typeof analyze !== 'undefined' ? analyze : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "BAD_SAMPLE": (typeof BAD_SAMPLE !== 'undefined' ? BAD_SAMPLE : undefined), "GOOD_SAMPLE": (typeof GOOD_SAMPLE !== 'undefined' ? GOOD_SAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["analyze"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-curl-command-safety-translator',
  name: 'J-Dawgs Curl Command Safety & Translation Bench',
  description: 'Paste a curl command and get it audited before anyone runs it — the -k flag that switches off certificate checks, credentials embedded in the URL or headers, auth sent over plain http — then translated: the same request as fetch() code, and a cleaned-up curl with placeholders where the secrets were.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["analyze"]) return { ok: false, output: null, summary: 'Extracted core has no analyze function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "BAD_SAMPLE": __core["BAD_SAMPLE"], "GOOD_SAMPLE": __core["GOOD_SAMPLE"] }
};
