'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Vendor Contract Renewal & Notice-Window Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

  "use strict";
  var MS_DAY = 86400000;

  var inputText = document.getElementById("inputText");
  var decisionInput = document.getElementById("decisionDate");
  var inputStatus = document.getElementById("inputStatus");
  var resultsCard = document.getElementById("resultsCard");
  var reportCard = document.getElementById("reportCard");
  var verdictBox = document.getElementById("verdictBox");
  var verdictValue = document.getElementById("verdictValue");
  var verdictDetail = document.getElementById("verdictDetail");
  var atRiskEq = document.getElementById("atRiskEq");
  var resultsBody = document.getElementById("resultsBody");
  var emptyNote = document.getElementById("emptyNote");
  var reportText = document.getElementById("reportText");
  var copyStatus = document.getElementById("copyStatus");
  var passStatus = document.getElementById("passStatus");

  function pad2(n){ return (n < 10 ? "0" : "") + n; }
  function todayLocalString(){
    var d = new Date();
    return d.getFullYear() + "-" + pad2(d.getMonth()+1) + "-" + pad2(d.getDate());
  }
  decisionInput.value = todayLocalString();

  /* ---------- date helpers (all UTC, so no timezone drift) ---------- */
  function parseDateStrict(s){
    if(typeof s !== "string") return null;
    var m = /^\s*(\d{4})-(\d{2})-(\d{2})\s*$/.exec(s);
    if(!m) return null;
    var y = parseInt(m[1],10), mo = parseInt(m[2],10), da = parseInt(m[3],10);
    if(mo < 1 || mo > 12 || da < 1 || da > 31) return null;
    var d = new Date(Date.UTC(y, mo-1, da));
    if(d.getUTCFullYear() !== y || d.getUTCMonth() !== mo-1 || d.getUTCDate() !== da) return null;
    return d;
  }
  function fmtDate(d){
    return d.getUTCFullYear() + "-" + pad2(d.getUTCMonth()+1) + "-" + pad2(d.getUTCDate());
  }
  function addDays(d, n){ return new Date(d.getTime() + n * MS_DAY); }
  function diffDays(a, b){ return Math.round((a.getTime() - b.getTime()) / MS_DAY); }
  function addMonthsClamped(d, months){
    var y = d.getUTCFullYear(), mo = d.getUTCMonth(), da = d.getUTCDate();
    var total = (y * 12 + mo) + months;
    var ny = Math.floor(total / 12), nmo = total - ny * 12;
    var lastDay = new Date(Date.UTC(ny, nmo+1, 0)).getUTCDate();
    var nd = Math.min(da, lastDay);
    return { date: new Date(Date.UTC(ny, nmo, nd)), clamped: nd !== da, lastDay: lastDay };
  }
  function fmtMoney(n){
    var neg = n < 0; var abs = Math.abs(n);
    var s = String(Math.round(abs));
    var out = "";
    while(s.length > 3){ out = "," + s.slice(-3) + out; s = s.slice(0, -3); }
    out = s + out;
    return (neg ? "-$" : "$") + out;
  }

  /* ---------- parsing ---------- */
  function parseBlocks(text){
    // Pull out a DECISION_DATE line wherever it appears.
    var decisionRaw = null, decisionFound = false;
    var lines = text.split(/\r?\n/);
    var kept = [];
    for(var i = 0; i < lines.length; i++){
      var dm = /^\s*DECISION_DATE\s*:\s*(.*?)\s*$/i.exec(lines[i]);
      if(dm && !decisionFound){
        decisionFound = true;
        decisionRaw = dm[1];
        kept.push(""); // keep block separation where the line was
      } else if(dm && decisionFound){
        kept.push(lines[i]); // a second DECISION_DATE line stays as an unknown line in its block
      } else {
        kept.push(lines[i]);
      }
    }
    var blocks = kept.join("\n").split(/\n[ \t]*\n/);
    var contracts = [];
    for(var b = 0; b < blocks.length; b++){
      var block = blocks[b];
      if(!/^\s*CONTRACT\s*:/im.test(block)) continue;
      contracts.push(parseContractBlock(block, contracts.length + 1));
    }
    return { decisionFound: decisionFound, decisionRaw: decisionRaw, contracts: contracts };
  }

  function parseContractBlock(block, index){
    var fields = {};
    var rawLines = {};
    var blines = block.split(/\r?\n/);
    for(var i = 0; i < blines.length; i++){
      var m = /^\s*([A-Za-z_]+)\s*:\s*(.*?)\s*$/.exec(blines[i]);
      if(!m) continue;
      var key = m[1].toUpperCase();
      if(!(key in fields)){ fields[key] = m[2]; rawLines[key] = blines[i].trim(); }
    }
    var problems = []; // {field, reason, line}
    var c = { index: index, name: null, renewal: null, renewalRaw: null,
              noticeDays: null, autoRenew: null, termMonths: null,
              value: null, valuePresent: false, problems: problems };

    // CONTRACT
    if(!("CONTRACT" in fields) || fields.CONTRACT === ""){
      problems.push({field:"CONTRACT", reason:"missing", line:null});
    } else { c.name = fields.CONTRACT; }

    // RENEWAL
    if(!("RENEWAL" in fields) || fields.RENEWAL === ""){
      problems.push({field:"RENEWAL", reason:"missing", line:null});
    } else {
      var rd = parseDateStrict(fields.RENEWAL);
      if(!rd){ problems.push({field:"RENEWAL", reason:"unparsable (expected YYYY-MM-DD)", line:rawLines.RENEWAL}); }
      else { c.renewal = rd; c.renewalRaw = fields.RENEWAL; }
    }

    // NOTICE_DAYS
    if(!("NOTICE_DAYS" in fields) || fields.NOTICE_DAYS === ""){
      problems.push({field:"NOTICE_DAYS", reason:"missing", line:null});
    } else if(!/^\d+$/.test(fields.NOTICE_DAYS)){
      problems.push({field:"NOTICE_DAYS", reason:"unparsable (expected a whole number of days)", line:rawLines.NOTICE_DAYS});
    } else { c.noticeDays = parseInt(fields.NOTICE_DAYS, 10); }

    // AUTO_RENEW
    if(!("AUTO_RENEW" in fields) || fields.AUTO_RENEW === ""){
      problems.push({field:"AUTO_RENEW", reason:"missing", line:null});
    } else {
      var av = fields.AUTO_RENEW.toLowerCase();
      if(av === "yes"){ c.autoRenew = true; }
      else if(av === "no"){ c.autoRenew = false; }
      else { problems.push({field:"AUTO_RENEW", reason:"unparsable (expected yes or no)", line:rawLines.AUTO_RENEW}); }
    }

    // TERM_MONTHS
    if(!("TERM_MONTHS" in fields) || fields.TERM_MONTHS === ""){
      problems.push({field:"TERM_MONTHS", reason:"missing", line:null});
    } else if(!/^\d+$/.test(fields.TERM_MONTHS) || parseInt(fields.TERM_MONTHS,10) < 1){
      problems.push({field:"TERM_MONTHS", reason:"unparsable (expected a whole number of months, 1 or more)", line:rawLines.TERM_MONTHS});
    } else { c.termMonths = parseInt(fields.TERM_MONTHS, 10); }

    // VALUE (optional)
    if("VALUE" in fields){
      c.valuePresent = true;
      var vraw = fields.VALUE.replace(/^\$/, "").replace(/,/g, "").trim();
      if(!/^\d+(\.\d+)?$/.test(vraw)){
        problems.push({field:"VALUE", reason:"unparsable (expected a plain number)", line:rawLines.VALUE});
      } else { c.value = parseFloat(vraw); }
    }
    c.displayName = c.name ? c.name : ("Unnamed contract (block " + index + ")");
    return c;
  }

  /* ---------- audit ---------- */
  function audit(text){
    var parsed = parseBlocks(text);
    var decision = null, decisionSource = "", decisionError = null;
    if(parsed.decisionFound){
      var dd = parseDateStrict(parsed.decisionRaw || "");
      if(dd){ decision = dd; decisionSource = "DECISION_DATE line in the pasted text (takes precedence over the date picker)"; }
      else { decisionError = "The DECISION_DATE line in the pasted text could not be read as YYYY-MM-DD: \u201C" + (parsed.decisionRaw || "") + "\u201D. Fix that line, or remove it to use the date picker."; }
    } else {
      var pd = parseDateStrict(decisionInput.value || "");
      if(pd){ decision = pd; decisionSource = "date picker (no DECISION_DATE line in the pasted text)"; }
      else { decisionError = "No usable decision date: the date picker is empty or invalid, and the pasted text has no DECISION_DATE line."; }
    }

    var results = [];
    for(var i = 0; i < parsed.contracts.length; i++){
      var c = parsed.contracts[i];
      var r = { c: c, grade: null, noticeBy: null, daysLeft: null, missedBy: null,
                newRenewal: null, clamped: false };
      if(c.problems.length > 0 || !decision){
        r.grade = "NOT SETTLED";
      } else if(c.autoRenew === false){
        r.grade = "NO AUTO-RENEW";
      } else {
        r.noticeBy = addDays(c.renewal, -c.noticeDays);
        if(decision.getTime() > r.noticeBy.getTime()){
          r.grade = "NOTICE WINDOW CLOSED";
          r.missedBy = diffDays(decision, r.noticeBy);
          var proj = addMonthsClamped(c.renewal, c.termMonths);
          r.newRenewal = proj.date; r.clamped = proj.clamped;
        } else {
          r.grade = "READY TO ACT";
          r.daysLeft = diffDays(r.noticeBy, decision);
        }
      }
      results.push(r);
    }

    // Summary verdict, in the specified order.
    var settled = results.filter(function(r){ return r.grade !== "NOT SETTLED"; });
    var autoSettled = settled.filter(function(r){ return r.c.autoRenew === true; });
    var verdict, verdictDetail;
    var urgent = autoSettled.filter(function(r){ return r.grade === "READY TO ACT" && r.daysLeft <= 30; });
    var closed = autoSettled.filter(function(r){ return r.grade === "NOTICE WINDOW CLOSED"; });
    if(decisionError){
      verdict = "NOTHING SETTLED";
      verdictDetail = decisionError;
    } else if(settled.length === 0){
      verdict = "NOTHING SETTLED";
      verdictDetail = results.length === 0
        ? "No contracts were settled \u2014 no contract blocks were found in the pasted text."
        : "No contracts were settled \u2014 every contract is NOT SETTLED. Fix the named fields and run the audit again.";
    } else if(urgent.length > 0){
      verdict = "ACT NOW";
      verdictDetail = urgent.map(function(r){ return r.c.displayName + " has " + r.daysLeft + (r.daysLeft === 1 ? " day" : " days") + " left (notice by " + fmtDate(r.noticeBy) + ")"; }).join("; ") + ". At least one auto-renew window closes within 30 days of the decision date.";
    } else if(closed.length > 0){
      verdict = "WINDOWS ALREADY MISSED";
      verdictDetail = closed.map(function(r){ return r.c.displayName + " was missed by " + r.missedBy + (r.missedBy === 1 ? " day" : " days"); }).join("; ") + ". No other window is due within 30 days.";
    } else {
      verdict = "ALL WINDOWS OPEN";
      verdictDetail = autoSettled.length === 0
        ? "Every settled contract is NO AUTO-RENEW, so no notice window can close. Nothing is due within 30 days."
        : "Every settled auto-renew contract is READY TO ACT with more than 30 days left.";
    }

    // At-risk total: NOTICE WINDOW CLOSED only.
    var closedAll = results.filter(function(r){ return r.grade === "NOTICE WINDOW CLOSED"; });
    var parts = [], total = 0, closedNoValue = [];
    closedAll.forEach(function(r){
      if(r.c.value !== null && r.c.value !== undefined){ parts.push(r.c.value); total += r.c.value; }
      else { closedNoValue.push(r.c.displayName); }
    });
    var atRiskEq;
    if(parts.length === 0){ atRiskEq = "$0"; }
    else { atRiskEq = parts.map(fmtMoney).join(" + ") + " = " + fmtMoney(total); }

    return { decision: decision, decisionSource: decisionSource, decisionError: decisionError,
             results: results, verdict: verdict, verdictDetail: verdictDetail,
             atRiskEq: atRiskEq, atRiskTotal: total, closedNoValue: closedNoValue };
  }

  /* ---------- rendering ---------- */
  function gradeClass(g){
    if(g === "READY TO ACT") return "grade g-ready";
    if(g === "NOTICE WINDOW CLOSED") return "grade g-closed";
    if(g === "NO AUTO-RENEW") return "grade g-noauto";
    return "grade g-notsettled";
  }
  function esc(s){
    return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
  }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-vendor-contract-renewal-notice-window-auditortm',
  name: 'J-Dawgs Vendor Contract Renewal & Notice-Window Auditor',
  description: 'Cross-checks each pasted contract\'s auto-renewal clause and notice period against one decision date: notice-by arithmetic per contract, missed windows named, at-risk annual value summed with the addition spelled out. Pasted clauses only, not legal advice.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
