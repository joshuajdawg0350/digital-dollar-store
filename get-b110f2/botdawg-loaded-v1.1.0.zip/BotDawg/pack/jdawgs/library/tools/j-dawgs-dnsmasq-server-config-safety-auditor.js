'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Dnsmasq Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var RISKY_EXAMPLE = [
        "# Risky dnsmasq.conf - worked example, do not deploy",
        "port=53",
        "listen-address=0.0.0.0",
        "dhcp-range=192.168.0.50,192.168.0.250,255.255.255.0,12h",
        "dhcp-option=3,192.168.0.1",
        "log-queries",
        "server=8.8.8.8",
        "password=abc123",
        "# interface=eth0",
        "this is not a valid directive !!!",
        "dhcp-authoritative"
      ].join("\n");

      var HARDENED_EXAMPLE = [
        "interface=eth0",
        "listen-address=192.168.1.1",
        "bind-interfaces",
        "no-resolv",
        "server=1.1.1.1",
        "dnssec",
        "trust-anchor=.,20326,8,2,E06D44B80B8F1D39A95C0B0D7C65D08458E880409BBC683457104237C7F8EC8D",
        "dhcp-range=192.168.1.100,192.168.1.120,255.255.255.0,12h",
        "dhcp-option=3,192.168.1.1",
        "domain-needed",
        "bogus-priv",
        "cache-size=1000"
      ].join("\n");

      var VALUE_KEYS = {
        "interface":1,"except-interface":1,"no-dhcp-interface":1,"listen-address":1,
        "dhcp-range":1,"dhcp-option":1,"dhcp-option-force":1,"dhcp-host":1,"dhcp-boot":1,
        "dhcp-leasefile":1,"dhcp-script":1,"dhcp-ignore":1,"dhcp-broadcast":1,"dhcp-match":1,
        "address":1,"server":1,"local":1,"domain":1,"resolv-file":1,"conf-dir":1,"conf-file":1,
        "user":1,"group":1,"pid-file":1,"log-facility":1,"cache-size":1,"port":1,"query-port":1,
        "min-port":1,"max-port":1,"trust-anchor":1,"addn-hosts":1,"hostsdir":1,"txt-record":1,
        "ptr-record":1,"cname":1,"host-record":1,"srv-host":1,"mx-host":1,"localmx":1,
        "tftp-root":1,"pxe-service":1,"edns-packet-max":1,"local-ttl":1,"neg-ttl":1,
        "interface-name":1,"auth-zone":1,"auth-server":1,"ipset":1,"nftset":1,"ra-param":1,
        "dhcp-fqdn":1,"leasefile-ro":1,"listen-backlog":1,"dns-forward-max":1,"rev-server":1,
        "rebind-domain-ok":1,"tftp-port-range":1,"dhcp-sequential-ip":1,"script-on-renewal":1
      };
      var FLAG_KEYS = {
        "bind-interfaces":1,"bind-dynamic":1,"no-resolv":1,"no-poll":1,"log-queries":1,
        "log-dhcp":1,"log-async":1,"dnssec":1,"dnssec-check-unsigned":1,"dnssec-no-timecheck":1,
        "proxy-dnssec":1,"domain-needed":1,"bogus-priv":1,"filterwin2k":1,"expand-hosts":1,
        "dhcp-authoritative":1,"enable-tftp":1,"tftp-secure":1,"read-ethers":1,"no-hosts":1,
        "no-negcache":1,"all-servers":1,"clear-on-reload":1,"stop-dns-rebind":1,
        "rebind-localhost-ok":1,"quiet-dhcp":1,"quiet-dhcp6":1,"quiet-ra":1,"script-arp":1,
        "conntrack":1,"dhcp-client-update":1,"no-ping":1,"dhcp-generate-names":1,
        "enable-ra":1,"enable-dbus":1,"loop-detect":1,"strict-order":1,"bogus-nxdomain":1
      };
      var SECRET_RE = /(password|passwd|secret|token|api[-_]?key|private[-_]?key|credential|auth[-_]?key|access[-_]?key)/i;

      function ipv4ToInt(s){
        var p = s.split(".");
        if (p.length !== 4) return null;
        var n = 0;
        for (var i = 0; i < 4; i++){
          if (!/^\d{1,3}$/.test(p[i])) return null;
          var v = parseInt(p[i], 10);
          if (v > 255) return null;
          n = n * 256 + v;
        }
        return n;
      }
      function isIPv4(s){ return ipv4ToInt(s) !== null; }

      function audit(text){
        var findings = [];
        function add(severity, code, line, title, detail, fix){
          findings.push({severity:severity, code:code, line:line, title:title, detail:detail, fix:fix || ""});
        }

        var lines = text.split(/\r?\n/);
        var state = {
          hasInterface:false, interfaceLines:[],
          listenAddrs:[], hasSpecificListen:false,
          bindInterfaces:false, dnssec:false, trustAnchor:false,
          noResolv:false, hasServer:false, logQueries:false,
          dhcpRanges:[]
        };

        for (var i = 0; i < lines.length; i++){
          var lineNo = i + 1;
          var raw = lines[i];
          var trimmed = raw.trim();
          if (trimmed === "") continue;

          if (trimmed.charAt(0) === "#"){
            var body = trimmed.replace(/^#+\s*/, "");
            var cm = body.match(/^([A-Za-z][A-Za-z0-9_-]*)\s*(?:=(.*))?$/);
            if (cm && (VALUE_KEYS[cm[1].toLowerCase()] || FLAG_KEYS[cm[1].toLowerCase()] || SECRET_RE.test(cm[1]))){
              var ckey = cm[1];
              if (SECRET_RE.test(ckey)){
                add("INFO","COMMENTED",lineNo,"COMMENTED — commented-out secret-like key",
                  "Line " + lineNo + " is commented out, so the key \"" + ckey + "\" is not active. Its value is not shown.",
                  "Delete commented-out secrets from the file entirely; history and backups keep them readable.");
              } else {
                add("INFO","COMMENTED",lineNo,"COMMENTED — directive is not active",
                  "Line " + lineNo + " is commented out: \"" + ckey + "\" will not take effect while it starts with #.",
                  "If you rely on this setting for safety, uncomment it — a commented restriction protects nothing.");
              }
            }
            continue;
          }

          var kv = trimmed.match(/^([A-Za-z][A-Za-z0-9_-]*)=(.*)$/);
          var bare = trimmed.match(/^([A-Za-z][A-Za-z0-9_-]*)$/);

          if (kv){
            var key = kv[1].toLowerCase();
            var value = kv[2];

            if (SECRET_RE.test(key)){
              var len = value.length;
              if (len < 12){
                add("CRITICAL","SECRET_SHORT",lineNo,"Short plaintext secret in config",
                  "Key \"" + kv[1] + "\" on line " + lineNo + " holds a plaintext value of only " + len + " characters. The value itself is never shown in this report.",
                  "Remove secrets from dnsmasq.conf, rotate this one now that it has been pasted around, and load credentials from a root-only file outside the config.");
              } else {
                add("HIGH","SECRET_PLAINTEXT",lineNo,"Plaintext secret in config",
                  "Key \"" + kv[1] + "\" on line " + lineNo + " holds a plaintext value of " + len + " characters. The value itself is never shown in this report.",
                  "Move the secret out of the main config into a root-only include file, and rotate it if the config has been shared.");
              }
              continue;
            }

            if (!VALUE_KEYS[key] && !FLAG_KEYS[key]){
              add("WARNING","UNKNOWN_DIRECTIVE",lineNo,"Unrecognized directive",
                "Line " + lineNo + " sets \"" + kv[1] + "\", which this audit does not recognize as a dnsmasq option. dnsmasq may refuse to start, or silently ignore it.",
                "Check the spelling against the dnsmasq documentation for your version, or remove the line.");
              continue;
            }

            if (key === "interface"){
              state.hasInterface = true; state.interfaceLines.push(lineNo);
              if (value.trim() === "*" || value.trim() === ""){
                add("CRITICAL","INTERFACE_WILDCARD",lineNo,"Wildcard interface",
                  "Line " + lineNo + " sets interface to a wildcard, so dnsmasq listens on every interface.",
                  "Name the one LAN interface dnsmasq should serve, e.g. interface=eth0.");
              }
            }
            if (key === "listen-address"){
              var addrs = value.split(",");
              for (var a = 0; a < addrs.length; a++){
                var addr = addrs[a].trim();
                state.listenAddrs.push(addr);
                if (addr === "0.0.0.0" || addr === "::" || addr === "*"){
                  add("CRITICAL","LISTEN_WILDCARD",lineNo,"Wildcard listen address",
                    "Line " + lineNo + " sets listen-address=" + addr + ", which binds dnsmasq to every address on the box — including any WAN or untrusted interface.",
                    "Bind to the specific LAN address instead, e.g. listen-address=192.168.1.1, and pair it with interface= and bind-interfaces.");
                } else if (addr !== ""){
                  state.hasSpecificListen = true;
                }
              }
            }
            if (key === "dhcp-range"){
              var parts = value.split(",");
              var start = (parts[0] || "").trim(), end = (parts[1] || "").trim();
              state.dhcpRanges.push({line:lineNo, start:start, end:end});
              if (isIPv4(start) && isIPv4(end)){
                var size = ipv4ToInt(end) - ipv4ToInt(start) + 1;
                if (size > 100){
                  add("HIGH","DHCP_WIDE_RANGE",lineNo,"DHCP enabled with a wide range",
                    "Line " + lineNo + " hands out " + size + " addresses (" + start + " – " + end + "). A pool that large serves far more clients than a home or small-office LAN has, and every one of them gets DNS and gateway settings from this box.",
                    "Shrink dhcp-range to the pool you actually need (a few dozen addresses is typical) and reserve static leases for known devices.");
                } else if (size < 1){
                  add("WARNING","DHCP_RANGE_ORDER",lineNo,"DHCP range looks inverted",
                    "Line " + lineNo + " has a range end below its start (" + start + " – " + end + ").",
                    "Fix the dhcp-range order so the start address is lower than the end address.");
                }
              }
            }
            if (key === "server"){ state.hasServer = true; }
            if (key === "trust-anchor"){ state.trustAnchor = true; }
            if (key === "conf-dir"){
              add("INFO","CONF_DIR",lineNo,"conf-dir pulls in files this audit cannot see",
                "Line " + lineNo + " loads extra configuration from a directory. Those files were not pasted, so this verdict covers only what is above.",
                "Audit the files in that directory with the same checks before deploying.");
            }
            if (key === "cache-size" && value.trim() === "0"){
              add("INFO","CACHE_DISABLED",lineNo,"DNS cache disabled",
                "Line " + lineNo + " sets cache-size=0, turning off caching. Not a hole, but every lookup goes upstream.",
                "Leave a modest cache (e.g. cache-size=1000) unless you disabled it on purpose.");
            }
            continue;
          }

          if (bare){
            var bkey = bare[1].toLowerCase();
            if (FLAG_KEYS[bkey]){
              if (bkey === "bind-interfaces") state.bindInterfaces = true;
              if (bkey === "dnssec") state.dnssec = true;
              if (bkey === "no-resolv") state.noResolv = true;
              if (bkey === "log-queries"){
                state.logQueries = true;
                add("WARNING","LOG_QUERIES_UNBOUNDED",lineNo,"log-queries is on with no bound",
                  "Line " + lineNo + " enables full query logging. dnsmasq.conf sets no size cap or rotation for it, so the log grows unbounded, fills disks, and builds a permanent record of every name every client looked up.",
                  "Turn log-queries off outside of short debugging sessions, or send logs to a facility with rotation (log-facility plus logrotate/syslog limits).");
              }
              if (bkey === "enable-tftp" && !text.match(/^\s*tftp-secure\s*$/m)){
                add("WARNING","TFTP_NO_SECURE",lineNo,"TFTP enabled without tftp-secure",
                  "Line " + lineNo + " enables the built-in TFTP server and no tftp-secure directive was found, so file access checks are weaker.",
                  "Add tftp-secure, or disable TFTP if nothing net-boots from this box.");
              }
              continue;
            }
            if (VALUE_KEYS[bkey]){
              add("WARNING","MISSING_VALUE",lineNo,"Directive is missing its value",
                "Line " + lineNo + " names \"" + bare[1] + "\" with no =value. dnsmasq will reject or misread this line.",
                "Give the directive its value, e.g. " + bare[1] + "=<value>, or delete the line.");
              continue;
            }
            add("WARNING","NOT_PARSED",lineNo,"NOT PARSED — unrecognized line",
              "Line " + lineNo + " is not a recognized dnsmasq directive, so it was NOT PARSED. The line's contents are not echoed here.",
              "Fix the spelling or remove the line — dnsmasq typically refuses to start on a line it cannot parse.");
            continue;
          }

          add("WARNING","NOT_PARSED",lineNo,"NOT PARSED — line is not a directive",
            "Line " + lineNo + " does not match the key=value or flag shape of a dnsmasq directive, so it was NOT PARSED. The line's contents are not echoed here.",
            "Rewrite the line as a valid directive, comment it out with #, or delete it.");
        }

        if (!state.hasInterface && !state.hasSpecificListen){
          add("CRITICAL","NO_INTERFACE_RESTRICTION",null,"No interface restriction — open resolver / DHCP exposure",
            "No active interface= directive restricts dnsmasq, and listening is not limited to a specific address. dnsmasq will answer DNS queries — and offer DHCP — on every interface it can reach, which is the classic open-resolver and rogue-DHCP exposure on any box with an untrusted side.",
            "Add interface=<lan-iface>, listen-address=<lan-ip>, and bind-interfaces so dnsmasq only serves the trusted LAN.");
        }
        if (state.hasInterface && !state.bindInterfaces){
          add("WARNING","NO_BIND_INTERFACES",null,"interface= set without bind-interfaces",
            "An interface is named, but bind-interfaces is missing. Without it, dnsmasq can still open wildcard sockets and answer on addresses beyond the named interface.",
            "Add bind-interfaces on its own line.");
        }
        if (!state.dnssec){
          add("WARNING","DNSSEC_OFF",null,"DNSSEC validation is off",
            "No dnssec directive (and " + (state.trustAnchor ? "although a trust-anchor is present, it is unused without dnssec" : "no trust-anchor") + ") was found, so upstream answers are accepted without DNSSEC validation. Spoofed answers can poison the cache for every client on the LAN.",
            "Add dnssec and a current trust-anchor for the root, and confirm your upstream resolvers return DNSSEC data.");
        }
        if (state.hasServer && !state.noResolv){
          add("WARNING","RESOLV_ALSO_USED",null,"server= set but resolv.conf is still read",
            "Upstream servers are configured with server=, but no-resolv is missing, so dnsmasq also uses the system resolv.conf upstreams — which may not be the resolvers you intended.",
            "Add no-resolv if the server= lines are meant to be the only upstreams.");
        }

        findings.sort(function(x, y){
          var lx = (x.line === null ? 100000 : x.line), ly = (y.line === null ? 100000 : y.line);
          return lx - ly;
        });

        var counts = {CRITICAL:0, HIGH:0, WARNING:0, INFO:0};
        findings.forEach(function(f){ counts[f.severity]++; });

        var verdict, verdictClass, verdictDetail;
        if (counts.CRITICAL > 0 || counts.HIGH > 0){
          verdict = "DO NOT DEPLOY"; verdictClass = "v-deny";
          verdictDetail = "Blocking findings (" + (counts.CRITICAL + counts.HIGH) + ") would expose this DNS/DHCP server or leak credentials. Fix them and re-audit before this file goes anywhere near a live box.";
        } else if (counts.WARNING > 0){
          verdict = "DEPLOY WITH FIXES"; verdictClass = "v-fix";
          verdictDetail = "No blocking findings, but " + counts.WARNING + " warning(s) should be fixed before this config is trusted in production.";
        } else {
          verdict = "SAFE TO DEPLOY"; verdictClass = "v-safe";
          verdictDetail = "No critical, high, or warning findings. Interface is restricted, listening is bound to a specific address, the DHCP pool is sized sanely, and DNSSEC validation is on. This verdict covers only the text pasted above.";
        }
        return {verdict:verdict, verdictClass:verdictClass, verdictDetail:verdictDetail,
                counts:counts, findings:findings, lineCount:lines.length};
      }

      function esc(s){
        return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
      }

      var lastResult = null;
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-dnsmasq-server-config-safety-auditor',
  name: 'J-Dawgs Dnsmasq Server Config Safety Auditor',
  description: 'Grades a pasted dnsmasq.conf offline into one deploy verdict — wildcard listens, wide DHCP ranges, and short plaintext secrets that pass a will-it-start check silently.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
