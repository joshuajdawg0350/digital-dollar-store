'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Package Hallucination & Slopsquat Risk Checker".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      function el(id) { return document.getElementById(id); }

      // ---------- Built-in reference list of well-known packages ----------
      // [canonical name, ecosystem]. This is the entire universe this page can
      // vouch for by name; anything else is VERIFY by design, not by suspicion.
      var REF_LIST = [
        // Python / PyPI
        ["requests", "pypi"], ["numpy", "pypi"], ["pandas", "pypi"], ["flask", "pypi"],
        ["django", "pypi"], ["fastapi", "pypi"], ["pytest", "pypi"], ["pillow", "pypi"],
        ["beautifulsoup4", "pypi"], ["sqlalchemy", "pypi"], ["pydantic", "pypi"],
        ["uvicorn", "pypi"], ["httpx", "pypi"], ["aiohttp", "pypi"], ["celery", "pypi"],
        ["redis", "pypi"], ["boto3", "pypi"], ["scipy", "pypi"], ["matplotlib", "pypi"],
        ["scikit-learn", "pypi"], ["pyyaml", "pypi"], ["click", "pypi"], ["tqdm", "pypi"],
        ["lxml", "pypi"], ["cryptography", "pypi"], ["openpyxl", "pypi"], ["gunicorn", "pypi"],
        ["tornado", "pypi"], ["attrs", "pypi"], ["rich", "pypi"], ["python-dotenv", "pypi"],
        ["python-dateutil", "pypi"], ["pyjwt", "pypi"], ["opencv-python", "pypi"],
        ["setuptools", "pypi"], ["wheel", "pypi"],
        // JavaScript / npm
        ["react", "npm"], ["react-dom", "npm"], ["lodash", "npm"], ["express", "npm"],
        ["axios", "npm"], ["typescript", "npm"], ["jest", "npm"], ["next", "npm"],
        ["vue", "npm"], ["zod", "npm"], ["prettier", "npm"], ["eslint", "npm"],
        ["webpack", "npm"], ["vite", "npm"], ["tailwindcss", "npm"], ["chalk", "npm"],
        ["commander", "npm"], ["dotenv", "npm"], ["uuid", "npm"], ["three", "npm"],
        ["svelte", "npm"], ["rxjs", "npm"], ["redux", "npm"], ["mongoose", "npm"],
        ["debug", "npm"], ["cors", "npm"], ["moment", "npm"], ["socket.io", "npm"]
      ];
      // Normalized (PEP 503-style: lowercase, runs of -_. collapsed to -) lookup.
      function normName(n) {
        return String(n).toLowerCase().replace(/[-_.]+/g, "-").replace(/\s+/g, "");
      }
      var REF = {}; // norm -> { name, eco }
      REF_LIST.forEach(function (pair) { REF[normName(pair[0])] = { name: pair[0], eco: pair[1] }; });
      var REF_NORMS = Object.keys(REF);

      // Standard, documented import-module -> package mappings. Only mappings
      // that are the package's own documented import name are listed; each use
      // is labeled "mapped" in the output, never presented as a detection.
      var IMPORT_MAP = {
        "PIL": "Pillow",
        "bs4": "beautifulsoup4",
        "sklearn": "scikit-learn",
        "yaml": "PyYAML",
        "cv2": "opencv-python",
        "dateutil": "python-dateutil",
        "dotenv": "python-dotenv",
        "jwt": "PyJWT",
        "Crypto": "pycryptodome",
        "serial": "pyserial"
      };

      // Language built-ins: importable with nothing installed.
      var PY_STDLIB = {};
      ("os sys re json math time datetime date calendar collections itertools functools typing " +
       "pathlib subprocess threading multiprocessing logging random string io abc enum dataclasses " +
       "contextlib urllib http socket sqlite3 csv argparse unittest hashlib hmac base64 binascii " +
       "copy operator heapq bisect array queue glob shutil tempfile uuid decimal fractions statistics " +
       "textwrap pprint inspect ast keyword tokenize warnings weakref gc traceback types zipfile tarfile " +
       "gzip zlib bz2 lzma pickle shelve dbm configparser getpass secrets signal struct codecs locale " +
       "gettext difflib html xml email mimetypes ftplib smtplib ssl asyncio concurrent venv site sysconfig platform")
        .split(" ").forEach(function (m) { PY_STDLIB[m] = true; });
      var JS_BUILTIN = {};
      ("fs path http https url util os crypto events stream buffer querystring child_process cluster " +
       "assert zlib readline net dns tls process console timers vm perf_hooks worker_threads module " +
       "punycode string_decoder v8 inspector tty dgram domain freelist internalBinding")
        .split(" ").forEach(function (m) { JS_BUILTIN[m] = true; });

      // ---------- Edit distance (Levenshtein) ----------
      function editDistance(a, b) {
        if (a === b) return 0;
        var la = a.length, lb = b.length;
        if (Math.abs(la - lb) > 2) return 3; // callers only care about 1..2
        var prev = [], cur = [], i, j;
        for (j = 0; j <= lb; j++) prev[j] = j;
        for (i = 1; i <= la; i++) {
          cur[0] = i;
          for (j = 1; j <= lb; j++) {
            var cost = a.charAt(i - 1) === b.charAt(j - 1) ? 0 : 1;
            cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost);
          }
          var tmp = prev; prev = cur; cur = tmp;
        }
        return prev[lb];
      }
      // Closest reference name within edit distance 1-2, or null.
      function nearestRef(norm) {
        var best = null, bestD = 3;
        for (var i = 0; i < REF_NORMS.length; i++) {
          var rn = REF_NORMS[i];
          if (rn === norm) continue;
          var d = editDistance(norm, rn);
          if (d >= 1 && d < bestD) { bestD = d; best = rn; if (d === 1) break; }
        }
        return best ? { norm: best, dist: bestD } : null;
      }
      // Does the name mash-combine two reference names? Returns [a, b] or null.
      function mashupParts(norm) {
        var squashed = norm.replace(/-/g, "");
        // Hyphenated form: every segment is itself a well-known package.
        var segs = norm.split("-").filter(function (s) { return s.length > 0; });
        if (segs.length >= 2) {
          var allRef = segs.every(function (s) { return !!REF[normName(s)]; });
          if (allRef) return segs.map(function (s) { return REF[normName(s)].name; });
        }
        // Concatenated form: split point where both halves are well-known.
        for (var i = 3; i <= squashed.length - 3; i++) {
          var left = squashed.slice(0, i), right = squashed.slice(i);
          if (REF[normName(left)] && REF[normName(right)]) {
            return [REF[normName(left)].name, REF[normName(right)].name];
          }
        }
        return null;
      }

      // ---------- Version pinning ----------
      // pinned: an exact version. floating: a range / wildcard / tag / nothing.
      function pinState(spec) {
        if (spec === null || spec === undefined || spec === "") {
          return { state: "none", label: "no version given" };
        }
        var s = String(spec).trim();
        if (s === "*" || /^x$/i.test(s) || /^latest$/i.test(s)) {
          return { state: "floating", label: "floating tag “" + s + "”" };
        }
        var m = s.match(/^===?\s*(.+)$/);
        if (m) {
          var v = m[1].trim();
          if (/[*<>,|~^]/.test(v) || /\sx\s/.test(v)) return { state: "floating", label: "range “" + s + "”" };
          return { state: "pinned", label: "pinned " + s };
        }
        if (/^(>=|<=|!=|~=|>|<)/.test(s) || s.indexOf(",") !== -1 || /[<>=~^|]/.test(s) ||
            /[*]/.test(s) || /\s-\s/.test(s) || /(^|\s)x(\s|$|\.)/i.test(s)) {
          return { state: "floating", label: "range “" + s + "”" };
        }
        if (/^\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?$/.test(s)) {
          return { state: "pinned", label: "pinned " + s }; // bare exact semver (npm name@1.2.3)
        }
        if (/^\d+(?:\.\d+){0,3}(?:[-+][0-9A-Za-z.-]+)?$/.test(s)) {
          return { state: "pinned", label: "pinned " + s }; // bare exact version, e.g. 2.31 or 1.0
        }
        return { state: "floating", label: "range “" + s + "”" };
      }

      // ---------- Extraction ----------
      // Entry: { name, spec, source: 'registry'|'git'|'url', sourceText,
      //          line, form, mappedFrom, builtin }
      function newEntry(name, spec, source, sourceText, line, form, mappedFrom, builtin) {
        return { name: name, spec: spec, source: source, sourceText: sourceText || "",
                 line: line, form: form, mappedFrom: mappedFrom || null, builtin: builtin || null };
      }

      function extractNameFromUrl(tok) {
        var egg = tok.match(/#egg=([A-Za-z0-9._-]+)/);
        if (egg) return egg[1];
        var clean = tok.split("#")[0].split("?")[0].replace(/\/+$/, "");
        var seg = clean.split("/").pop() || "";
        seg = seg.replace(/\.git$/i, "").replace(/\.(tar\.gz|tgz|zip|whl)$/i, "");
        return seg || null;
      }
      // Parse one token from an install command or requirements line.
      // Returns {name, spec} or {url:true, name} or null.
      function parseSpecToken(tok) {
        tok = tok.replace(/[,;]+$/, "").replace(/^["']|["']$/g, "");
        if (!tok) return null;
        // Direct reference: name @ URL (PEP 508) or bare URL
        var atUrl = tok.match(/^([A-Za-z0-9._-]+)\s*@\s*(\S+)$/);
        if (atUrl && /^(https?|git)/i.test(atUrl[2])) {
          return { name: atUrl[1], spec: null, url: atUrl[2] };
        }
        if (/^(git\+|https?:\/\/|git:\/\/|ssh:\/\/)/i.test(tok) || /\.git(#|$)/i.test(tok) ||
            /^(github|gitlab|bitbucket):/i.test(tok)) {
          return { name: extractNameFromUrl(tok), spec: null, url: tok };
        }
        // pip style: name[extras]<ops> with ; marker stripped by caller
        var m = tok.match(/^([A-Za-z0-9._-]+)((?:\[[^\]]*\])?\s*(?:===?|>=|<=|!=|~=|>|<).*)$/);
        if (m) return { name: m[1], spec: m[2].replace(/^\[[^\]]*\]/, "").trim() || m[2].trim(), rawSpec: m[2] };
        // Extras with no version: name[extra]
        var ex = tok.match(/^([A-Za-z0-9._-]+)\[[^\]]*\]$/);
        if (ex) return { name: ex[1], spec: null };
        // npm style: name@version (scoped names start with @)
        var at = tok.lastIndexOf("@");
        if (at > 0) {
          return { name: tok.slice(0, at), spec: tok.slice(at + 1) || null };
        }
        if (/^[A-Za-z0-9@][A-Za-z0-9._\/-]*$/.test(tok) && !/^(https?|ftp):/i.test(tok)) {
          return { name: tok, spec: null };
        }
        return null;
      }

      function parseRequirementsLine(raw, lineNo, entries, notes) {
        var line = raw.trim();
        if (/^-e\s+/.test(line) || /^--editable\s+/.test(line)) {
          var target = line.replace(/^-e\s+/, "").replace(/^--editable\s+/, "").trim();
          var p = parseSpecToken(target);
          if (p && p.name) {
            entries.push(newEntry(p.name, null, p.url ? (String(p.url).indexOf("git") !== -1 ? "git" : "url") : "url",
              target, lineNo, "requirements.txt (editable install)", null, null));
          } else {
            notes.push({ line: lineNo, text: raw.trim(), reason: "Editable install whose target could not be read as a package — check it yourself." });
          }
          return true;
        }
        if (/^--?(r|requirement|index-url|extra-index-url|find-links|f|constraint|c)\b/.test(line) || /^--(hash|trusted-host|proxy|timeout|retries)\b/.test(line)) {
          notes.push({ line: lineNo, text: line, reason: "A pip option line, not a package — its target is outside this paste, so it was not audited." });
          return true;
        }
        // Environment markers: everything after ';' is a condition, not part of the spec.
        var main = line.split(";")[0].trim();
        var p = parseSpecToken(main.replace(/\s+/g, " ").replace(/([A-Za-z0-9._-]+)\s*@\s*/, "$1 @ "));
        if (p && p.name && /^[A-Za-z0-9@][A-Za-z0-9._-]*$/.test(p.name.replace(/^@[^/]+\//, ""))) {
          var src = "registry", srcText = "";
          if (p.url) { src = /git/i.test(p.url) ? "git" : "url"; srcText = p.url; }
          entries.push(newEntry(p.name, p.spec != null ? p.spec : null, src, srcText, lineNo, "requirements.txt", null, null));
          return true;
        }
        return false;
      }

      function parseInstallCommand(line, lineNo, entries, notes) {
        var m = line.match(/^(?:\$\s*)?(?:sudo\s+)?(?:python3?\s+-m\s+)?(?:uv\s+)?(pip3?|npm|yarn|pnpm|bun)\s+(install|i|add)\s*(.*)$/i);
        if (!m) return false;
        var mgr = m[1].toLowerCase();
        var rest = (m[3] || "").trim();
        var form = mgr + " " + m[2].toLowerCase() + " command";
        if (!rest) {
          notes.push({ line: lineNo, text: line, reason: "An install command with no packages named on it (a bare project install) — nothing on this line to audit." });
          return true;
        }
        var tokens = rest.split(/\s+/);
        var skipNext = false;
        tokens.forEach(function (tok) {
          if (skipNext) { skipNext = false; return; }
          if (/^(-r|--requirement|--index-url|--extra-index-url|-i|--target|-t|--prefix|--constraint|-c)$/.test(tok)) {
            skipNext = true;
            notes.push({ line: lineNo, text: tok, reason: "Install option on line " + lineNo + " — its value names a file or index outside this paste, so it was not audited." });
            return;
          }
          if (tok.charAt(0) === "-" && !/^--editable/.test(tok)) return; // other flags: no package named
          if (tok === "." || tok === "./" || /^\.{1,2}\//.test(tok)) {
            notes.push({ line: lineNo, text: tok, reason: "A local path on line " + lineNo + ", not a registry package — not audited." });
            return;
          }
          var p = parseSpecToken(tok);
          if (p && p.name) {
            var src = "registry", srcText = "";
            if (p.url) { src = /git/i.test(p.url) ? "git" : "url"; srcText = p.url; }
            entries.push(newEntry(p.name, p.spec != null ? p.spec : null, src, srcText, lineNo, form, null, null));
          } else {
            notes.push({ line: lineNo, text: tok, reason: "Token on line " + lineNo + " could not be read as a package name — excluded from the audit." });
          }
        });
        return true;
      }

      function parsePythonImport(line, lineNo, entries, notes) {
        if (/['"]/.test(line)) return false; // quoted module paths are JS, not Python
        var m = line.match(/^import\s+(.+)$/) || line.match(/^from\s+([A-Za-z_][\w.]*)\s+import\s+/);
        if (!m) return false;
        var mods;
        if (/^from\s/.test(line)) {
          mods = [m[1]];
        } else {
          mods = m[1].split(",").map(function (s) { return s.trim().split(/\s+as\s+/)[0].trim(); }).filter(Boolean);
        }
        mods.forEach(function (mod) {
          var top = mod.split(".")[0];
          if (!top) return;
          if (PY_STDLIB[top]) {
            entries.push(newEntry(top, null, "registry", "", lineNo, "Python import", null, "Python standard library"));
            return;
          }
          if (IMPORT_MAP[top]) {
            entries.push(newEntry(IMPORT_MAP[top], null, "registry", "", lineNo, "Python import", top, null));
            return;
          }
          entries.push(newEntry(top, null, "registry", "", lineNo, "Python import", null, null));
        });
        return true;
      }

      function parseJsImport(line, lineNo, entries, notes) {
        var spec = null;
        var m = line.match(/from\s+['"]([^'"]+)['"]/) ||
                line.match(/^\s*import\s+['"]([^'"]+)['"]/) ||
                line.match(/require\s*\(\s*['"]([^'"]+)['"]\s*\)/) ||
                line.match(/import\s*\(\s*['"]([^'"]+)['"]\s*\)/);
        if (!m) return false;
        spec = m[1];
        if (spec.charAt(0) === "." || spec.charAt(0) === "/") {
          notes.push({ line: lineNo, text: line.trim(), reason: "A local file import (relative path) — not an installable package, so it is excluded." });
          return true;
        }
        var bare = spec.replace(/^node:/, "");
        var top;
        if (bare.charAt(0) === "@") {
          var parts = bare.split("/");
          top = parts.length >= 2 ? parts[0] + "/" + parts[1] : bare;
        } else {
          top = bare.split("/")[0];
        }
        if (JS_BUILTIN[top] || JS_BUILTIN[bare]) {
          entries.push(newEntry(top, null, "registry", "", lineNo, "JS import", null, "Node.js built-in"));
          return true;
        }
        entries.push(newEntry(top, null, "registry", "", lineNo, "JS import / require", null, null));
        return true;
      }

      // JSON fragments: dependencies blocks at any nesting, with line numbers.
      function parseJsonBlocks(text, entries) {
        var re = /"(dependencies|devDependencies|peerDependencies|optionalDependencies)"\s*:\s*\{/g;
        var match, found = false;
        function lineOf(idx) { return text.slice(0, idx).split("\n").length; }
        while ((match = re.exec(text)) !== null) {
          found = true;
          var kind = match[1];
          var i = re.lastIndex, depth = 1, start = i;
          while (i < text.length && depth > 0) {
            if (text.charAt(i) === "{") depth++;
            else if (text.charAt(i) === "}") depth--;
            i++;
          }
          var body = text.slice(start, i - 1);
          var entryRe = /"((?:@[^"]+?\/)?[^"]+?)"\s*:\s*"([^"]*)"/g, em;
          while ((em = entryRe.exec(body)) !== null) {
            var name = em[1], spec = em[2];
            var src = "registry", srcText = "";
            if (/^(git\+|https?:\/\/|git:|file:|github:)/i.test(spec)) {
              src = /git/i.test(spec) ? "git" : "url"; srcText = spec; spec = null;
            }
            entries.push(newEntry(name, spec === "" ? null : spec, src, srcText,
              lineOf(start + em.index), "package.json " + kind, null, null));
          }
        }
        return found;
      }

      function parseInput(text) {
        var entries = [], notes = [];
        var jsonFound = parseJsonBlocks(text, entries);
        var lines = text.split("\n");
        var inJsonBlock = false, depth = 0;
        lines.forEach(function (raw, idx) {
          var lineNo = idx + 1;
          var line = raw.trim();
          // Track dependencies-block spans so their lines are not re-parsed.
          if (/"(dependencies|devDependencies|peerDependencies|optionalDependencies)"\s*:\s*\{/.test(line)) {
            inJsonBlock = true;
            depth = 0;
            for (var c = 0; c < line.length; c++) {
              if (line.charAt(c) === "{") depth++;
              else if (line.charAt(c) === "}") depth--;
            }
            if (depth <= 0) inJsonBlock = false;
            return;
          }
          if (inJsonBlock) {
            for (var c2 = 0; c2 < line.length; c2++) {
              if (line.charAt(c2) === "{") depth++;
              else if (line.charAt(c2) === "}") depth--;
            }
            if (depth <= 0) inJsonBlock = false;
            return;
          }
          if (line === "" ) return;
          if (/^#/.test(line) || /^\/\//.test(line)) return; // comments
          if (/^[{}\[\],]$/.test(line)) return; // bare JSON punctuation
          if (parseInstallCommand(line, lineNo, entries, notes)) return;
          if (parseJsImport(line, lineNo, entries, notes)) return;
          if (/^(import|from)\s/.test(line) && parsePythonImport(line, lineNo, entries, notes)) return;
          if (parseRequirementsLine(raw, lineNo, entries, notes)) return;
          if (/^"(name|version|private|description|main|scripts|author|license|type)"\s*:/.test(line)) {
            notes.push({ line: lineNo, text: line, reason: "A package.json field that is not a dependency — not a package line." });
            return;
          }
          notes.push({ line: lineNo, text: line, reason: "Could not be read as a package in any supported form — excluded from the audit. Check it yourself." });
        });
        return { entries: entries, notes: notes, jsonFound: jsonFound };
      }

      // ---------- Audit ----------
      function audit(entries) {
        var rows = {}, order = [];
        entries.forEach(function (e) {
          var key = (e.builtin ? "builtin:" : "pkg:") + normName(e.name) + "|" + (e.builtin || "");
          if (!rows[key]) {
            rows[key] = { key: key, name: e.name, norm: normName(e.name), builtin: e.builtin,
                          occurrences: [], specs: [], sources: [], forms: [], mappedFrom: e.mappedFrom };
            order.push(key);
          }
          var r = rows[key];
          r.occurrences.push(e);
          if (e.spec != null && r.specs.indexOf(e.spec) === -1) r.specs.push(e.spec);
          if (e.source !== "registry") r.sources.push(e);
          if (r.forms.indexOf(e.form) === -1) r.forms.push(e.form);
        });

        var out = order.map(function (key) {
          var r = rows[key];
          r.flags = [];      // { kind: 'risk'|'pin'|'note', label, why }
          r.reasons = [];    // plain-language strings for the Why column
          r.cls = null;

          if (r.builtin) {
            r.cls = "BUILT-IN";
            r.pin = { state: "na", label: "nothing to install" };
            r.reasons.push("Ships with the " + r.builtin + " — no install, no registry entry, no slopsquat risk.");
            return r;
          }

          // Worst pinning state across occurrences.
          var pinStates = r.occurrences.map(function (e) { return pinState(e.spec); });
          if (r.occurrences.every(function (e) { return e.spec == null; })) {
            r.pin = { state: "none", label: "no version given" };
          } else if (pinStates.some(function (p) { return p.state === "floating"; })) {
            r.pin = { state: "floating", label: pinStates.filter(function (p) { return p.state === "floating"; })[0].label };
          } else if (pinStates.some(function (p) { return p.state === "none"; })) {
            r.pin = { state: "none", label: "pinned in one place, unpinned in another" };
          } else {
            r.pin = { state: "pinned", label: pinStates[0].label };
          }
          var anyImportOnly = r.occurrences.every(function (e) { return /import/.test(e.form); });

          var risk = false;

          // Non-registry source
          if (r.sources.length) {
            risk = true;
            var s0 = r.sources[0];
            var isHttp = /^http:\/\//i.test(s0.sourceText);
            r.flags.push({ kind: "risk", label: isHttp ? "plain-http source" : "non-registry source" });
            r.reasons.push("Installed from " + (s0.source === "git" ? "a git URL" : "a direct URL") +
              " (" + s0.sourceText + "), not from the registry — whatever that URL serves is what gets installed, with no registry review, signing, or takedown protection.");
          }

          // Duplicates
          if (r.occurrences.length > 1) {
            if (r.specs.length > 1) {
              risk = true;
              r.flags.push({ kind: "risk", label: "conflicting duplicate" });
              r.reasons.push("Listed " + r.occurrences.length + " times with conflicting version specs (" +
                r.specs.join(" vs ") + ") — which one wins depends on the installer, so the result is not reproducible.");
            } else {
              r.flags.push({ kind: "risk", label: "listed twice" });
              risk = true;
              r.reasons.push("Listed " + r.occurrences.length + " times (lines " +
                r.occurrences.map(function (e) { return e.line; }).join(", ") +
                "). Duplicates in a generated list are a smell — merge them into one pinned entry before installing.");
            }
          }

          // Name classification
          var refHit = REF[r.norm];
          if (refHit) {
            r.cls = "KNOWN";
            r.reasons.push("Exact match to “" + refHit.name + "” on the built-in reference list of well-known packages.");
          } else {
            var mash = mashupParts(r.norm);
            var near = mash ? null : nearestRef(r.norm);
            if (mash) {
              risk = true;
              r.cls = "HIGH-RISK PATTERN";
              r.flags.push({ kind: "risk", label: "mashup name" });
              r.reasons.push("Name mash-combines two well-known packages: “" + r.name + "” = “" + mash[0] + "” + “" + mash[1] +
                "”. AI generators invent names exactly like this, and squatters register them.");
            } else if (near) {
              risk = true;
              r.cls = "HIGH-RISK PATTERN";
              r.flags.push({ kind: "risk", label: "look-alike name" });
              r.nearRef = REF[near.norm];
              r.nearDist = near.dist;
              r.reasons.push("Possible typosquat: “" + r.name + "” sits at edit distance " + near.dist +
                " from the well-known “" + REF[near.norm].name + "”. Side by side: " + r.name + "  vs  " + REF[near.norm].name + ".");
            } else {
              r.cls = "VERIFY";
              r.reasons.push("Not on this page's small built-in reference list. That does not make it fake — it means this page cannot vouch for it, so it must be checked at the registry before installing.");
            }
          }
          if (risk) r.cls = "HIGH-RISK PATTERN";

          // Pinning flag (kept separate from the name verdict, per design)
          if (r.pin.state !== "pinned") {
            r.flags.push({ kind: "pin", label: "pinning risk" });
            if (anyImportOnly && r.pin.state === "none") {
              r.reasons.push("Pinning risk: this came from an import line, and imports carry no version — nothing pins which release gets installed. Pin it in a requirements file or lockfile.");
            } else {
              r.reasons.push("Pinning risk: " + r.pin.label + " — the installer will resolve whatever the newest matching release is on install day, which is exactly how a freshly-registered slopsquat gets in.");
            }
          } else {
            r.reasons.push("Version is pinned exactly (" + r.specs.join(", ") + "), so the installer cannot drift to a newer release on its own.");
          }

          if (r.mappedFrom) {
            r.flags.push({ kind: "note", label: "mapped import" });
            r.reasons.push("Mapping: “import " + r.mappedFrom + "” is the standard, documented import name for the " + r.name +
              " package. This is a known mapping applied by this page, not a detection — the package itself still gets the verdict above.");
          }
          return r;
        });

        return out;
      }

      function overallVerdict(rows) {
        var pkgs = rows.filter(function (r) { return !r.builtin; });
        if (!pkgs.length) {
          return { kind: "", text: "Nothing to install",
            sub: "No registry packages were found in that paste — everything parsed is built into the language, or nothing parsed at all — so there is nothing to install and nothing to verify." };
        }
        var risk = pkgs.filter(function (r) { return r.cls === "HIGH-RISK PATTERN"; });
        var verify = pkgs.filter(function (r) { return r.cls === "VERIFY"; });
        var pinRisk = pkgs.filter(function (r) { return r.pin.state !== "pinned"; });
        if (risk.length) {
          return { kind: "fix", text: "DO NOT INSTALL YET",
            sub: risk.length + " package" + (risk.length === 1 ? "" : "s") + " matched a high-risk pattern. Work the Step 3 checklist for each flagged package first — a look-alike or mashup name is fixed by correcting the name, never by installing it to see what happens." };
        }
        if (verify.length || pinRisk.length) {
          var bits = [];
          if (verify.length) bits.push(verify.length + " package" + (verify.length === 1 ? "" : "s") + " not on the reference list");
          if (pinRisk.length) bits.push(pinRisk.length + " pinning risk" + (pinRisk.length === 1 ? "" : "s"));
          return { kind: "ask", text: "VERIFY BEFORE INSTALL",
            sub: "No high-risk name patterns, but there is unfinished homework: " + bits.join(" and ") + ". Work the Step 3 checklist, pin every version, and install from a reviewed lockfile." };
        }
        return { kind: "safe", text: "INSTALL WITH CONFIDENCE",
          sub: "Every package is an exact match to the reference list and every version is pinned exactly. Install from this list as written — confidence covers the names and pins, not the packages' own code." };
      }

      // ---------- Rendering ----------
      function esc(s) {
        return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
      }
      function badgeClass(cls) {
        return cls === "KNOWN" ? "known" : cls === "VERIFY" ? "verify" : cls === "BUILT-IN" ? "builtin" : "risk";
      }
      function setVerdict(kind, text, sub) {
        var v = el("verdict");
        v.className = "verdict" + (kind ? " " + kind : "");
        el("verdict-text").textContent = text;
        el("verdict-sub").textContent = sub;
      }

      function registryHint(r) {
        var refHit = REF[r.norm];
        var eco = refHit ? refHit.eco : (/npm|package\.json|JS import/.test(r.forms.join(" ")) ? "npm" : "pypi");
        if (eco === "npm") return { label: "npm", url: "www.npmjs.com/package/" + r.name };
        return { label: "PyPI", url: "pypi.org/project/" + r.name + "/" };
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-package-hallucination-checker',
  name: 'J-Dawgs Package Hallucination & Slopsquat Risk Checker',
  description: 'Audits package.json, requirements.txt, install commands, and imports before install: typosquat near-misses named side by side, mashup names, unpinned versions, and git/URL installs flagged with a verify-before-install checklist — pattern checks only, it does not query a live registry.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
