'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Prowlarr Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var RISKY_EXAMPLE = [
        '<?xml version="1.0" encoding="utf-8"?>',
        '<Config>',
        '  <BindAddress>*</BindAddress>',
        '  <Port>9696</Port>',
        '  <SslPort>6969</SslPort>',
        '  <EnableSsl>False</EnableSsl>',
        '  <LaunchBrowser>True</LaunchBrowser>',
        '  <ApiKey>abc123</ApiKey>',
        '  <AuthenticationMethod>Disabled</AuthenticationMethod>',
        '  <AuthenticationRequired>DisabledForLocalAddresses</AuthenticationRequired>',
        '  <Branch>develop</Branch>',
        '  <LogLevel>Debug</LogLevel>',
        '  <UrlBase>http://prowlarr.home.lan</UrlBase>',
        '  <InstanceName>Prowlarr</InstanceName>',
        '  <AnalyticsEnabled>True</AnalyticsEnabled>',
        '  <Applications>',
        '    <Application>',
        '      <Name>Radarr</Name>',
        '      <ApiKey>radarr-plain-key-0042</ApiKey>',
        '    </Application>',
        '    <Application>',
        '      <Name>Sonarr</Name>',
        '      <ApiKey>sonarr-plain-key-9981</ApiKey>',
        '    </Application>',
        '  </Applications>',
        '</Config>'
      ].join("\n");

      var HARDENED_EXAMPLE = [
        '<?xml version="1.0" encoding="utf-8"?>',
        '<Config>',
        '  <BindAddress>127.0.0.1</BindAddress>',
        '  <Port>9696</Port>',
        '  <SslPort>6969</SslPort>',
        '  <EnableSsl>True</EnableSsl>',
        '  <SslCertPath>/config/certs/prowlarr.pfx</SslCertPath>',
        '  <LaunchBrowser>False</LaunchBrowser>',
        '  <ApiKey>7f3a9c1e5b8d2046a7c9e1f3b5d708294a6c8e0f2b4d6a8c1e3f507294a6b8c0d2</ApiKey>',
        '  <AuthenticationMethod>Forms</AuthenticationMethod>',
        '  <AuthenticationRequired>Enabled</AuthenticationRequired>',
        '  <Branch>master</Branch>',
        '  <LogLevel>Info</LogLevel>',
        '  <UrlBase>https://prowlarr.home.lan</UrlBase>',
        '  <InstanceName>Prowlarr</InstanceName>',
        '  <AnalyticsEnabled>False</AnalyticsEnabled>',
        '  <!-- Downstream app keys live inside each app (Radarr, Sonarr) and in Prowlarr\'s',
        '       protected database — they are never pasted into shared config text. -->',
        '</Config>'
      ].join("\n");

      var PITCHES = {
        short: "Before you start that Prowlarr server, paste its config.xml into the J-Dawgs Prowlarr Server Config Safety Auditor\u2122. It grades the config offline \u2014 API key, auth, bind, TLS, update branch \u2014 and gives you one verdict: safe to deploy, deploy with fixes, or do not deploy. Secrets are reported by name and length only, never shown. AI Tool Store: https://muse.ai/s/ai-tool-store-xng6xkxwjkxl2xab/UoF72OkKI7j33Q2ITxmrZyIr4nv40QtYfj2AgESh_k8 \u00b7 J-Dawgs Agent Exchange: https://muse.ai/s/j-dawgs-agent-exchange-ih6xlnihzxdhxc/ZbleqxFHRE0NcswaBkyN13y9lLp5rPAgHTb6t8ii-PY \u00b7 Part of the Index It, Manage It, Install It Right Stack bundle.",
        full: "Prowlarr's own tooling only exercises a config by starting the server, so a short example API key, disabled authentication, an all-interfaces bind, plaintext downstream app keys, and a develop update branch all pass silently. The J-Dawgs Prowlarr Server Config Safety Auditor\u2122 grades a pasted config offline in the browser, returns one deploy verdict with line-numbered findings and fixes, and never renders a secret value. AI Tool Store: https://muse.ai/s/ai-tool-store-xng6xkxwjkxl2xab/UoF72OkKI7j33Q2ITxmrZyIr4nv40QtYfj2AgESh_k8 \u00b7 J-Dawgs Agent Exchange: https://muse.ai/s/j-dawgs-agent-exchange-ih6xlnihzxdhxc/ZbleqxFHRE0NcswaBkyN13y9lLp5rPAgHTb6t8ii-PY \u00b7 Also available in the Index It, Manage It, Install It Right Stack bundle."
      };

      /* ---------- Parsing ---------- */

      function parseEntries(text) {
        var entries = [];
        var lines = String(text || "").split(/\r?\n/);
        var tagRe = /<([A-Za-z][A-Za-z0-9._-]*)>\s*([^<>]*?)\s*<\/[A-Za-z][A-Za-z0-9._-]*>/;
        var jsonRe = /"([A-Za-z][A-Za-z0-9._-]*)"\s*:\s*"([^"]*)"/;
        var bareRe = /^\s*([A-Za-z][A-Za-z0-9._-]*)\s*=\s*(\S.*?)\s*$/;
        for (var i = 0; i < lines.length; i++) {
          var lineText = lines[i];
          var m = lineText.match(tagRe);
          if (m) { entries.push({ name: m[1], value: m[2], line: i + 1 }); continue; }
          var j = lineText.match(jsonRe);
          if (j) { entries.push({ name: j[1], value: j[2], line: i + 1 }); continue; }
          if (lineText.indexOf("<") === -1) {
            var b = lineText.match(bareRe);
            if (b) entries.push({ name: b[1], value: b[2], line: i + 1 });
          }
        }
        return entries;
      }

      function findEntry(entries, name) {
        var target = name.toLowerCase();
        for (var i = 0; i < entries.length; i++) {
          if (entries[i].name.toLowerCase() === target) return entries[i];
        }
        return null;
      }

      function isTruthy(v) {
        var s = String(v).trim().toLowerCase();
        return s === "true" || s === "1" || s === "yes" || s === "enabled";
      }
      function isFalsy(v) {
        var s = String(v).trim().toLowerCase();
        return s === "false" || s === "0" || s === "no" || s === "disabled";
      }

      var PLACEHOLDER_PATTERNS = [
        "changeme", "change-me", "example", "placeholder", "your-api-key", "yourapikey",
        "insert", "todo", "xxxxx", "000000", "123456", "abcdef", "testkey", "demo"
      ];
      function looksPlaceholder(v) {
        var s = String(v).toLowerCase();
        for (var i = 0; i < PLACEHOLDER_PATTERNS.length; i++) {
          if (s.indexOf(PLACEHOLDER_PATTERNS[i]) !== -1) return true;
        }
        if (/^(.)\1+$/.test(s)) return true; /* one repeated character */
        return false;
      }

      /* ---------- Audit ---------- */

      function auditConfig(text) {
        var findings = [];
        function add(severity, line, title, detail, fix, secret) {
          var f = { severity: severity, line: line || null, title: title, detail: detail, fix: fix };
          if (secret) f.secret = secret;
          findings.push(f);
        }

        var raw = String(text || "");
        if (!raw.trim()) {
          add("critical", null, "Nothing to audit",
            "The pasted config is empty, so there is no API key, no authentication, and nothing safe to start a server with.",
            "Paste the full contents of config.xml (or load a worked example) and run the audit again.");
          return finish(findings);
        }

        var entries = parseEntries(raw);

        /* --- Main API key --- */
        var apiKeys = entries.filter(function (e) { return e.name.toLowerCase() === "apikey"; });
        var mainKey = apiKeys.length ? apiKeys[0] : null;
        if (!mainKey) {
          add("critical", null, "No API key found",
            "No <ApiKey> setting appears in the pasted config. Without one, anything that can reach the port can drive Prowlarr's API.",
            "Start Prowlarr once in a safe, local-only state to generate a key, or set a fresh random key of at least 32 characters in config.xml before exposing the server.");
        } else {
          var secretRef = { keyName: mainKey.name, line: mainKey.line, length: mainKey.value.length };
          if (looksPlaceholder(mainKey.value)) {
            add("critical", mainKey.line, "API key is an example / placeholder value",
              "The main API key matches a known placeholder pattern, so anyone who has seen the example it came from knows your key.",
              "Replace it with a fresh random key of at least 32 characters and update every app that uses it.",
              secretRef);
          } else if (mainKey.value.length < 32) {
            add("critical", mainKey.line, "API key is too short",
              "The main API key is only " + mainKey.value.length + " characters long. Prowlarr keys are normally 32 characters; a short key is guessable and often a leftover sample.",
              "Generate a new random API key of at least 32 characters in Settings \u2192 General \u2192 Security, then update Radarr/Sonarr and any other clients.",
              secretRef);
          } else {
            add("pass", mainKey.line, "API key present and full length",
              "A main API key is set at full length. Its value is never shown by this tool.",
              "No change needed. Rotate it if it has ever been pasted into a chat, ticket, or screenshot.",
              secretRef);
          }
        }

        /* --- Downstream app API keys in plaintext --- */
        var downstream = [];
        entries.forEach(function (e, idx) {
          var n = e.name.toLowerCase();
          var isKeyLike = n === "apikey" || /apikey$/.test(n) || n === "appapikey";
          if (!isKeyLike) return;
          if (mainKey && e === mainKey) return;
          downstream.push(e);
        });
        downstream.forEach(function (e) {
          add("high", e.line, "Downstream app API key stored in plaintext config text",
            "An extra API key (" + e.name + ") appears in the pasted text. Downstream app keys (Radarr, Sonarr, Lidarr, and friends) sitting in shareable config text get copied into tickets, chats, and repos — and each one opens that app's full API.",
            "Remove downstream keys from any config text you share or store. Keep them inside each app and in Prowlarr's own protected database, and rotate any key that has been pasted around.",
            { keyName: e.name, line: e.line, length: e.value.length });
        });

        /* --- Plaintext password fields --- */
        entries.forEach(function (e) {
          var n = e.name.toLowerCase();
          if ((n === "password" || /password$/.test(n)) && e.value.length > 0) {
            add("high", e.line, "Password stored in plaintext in pasted config text",
              "A password field (" + e.name + ") has a value in the pasted text. Anyone who gets this text gets the password.",
              "Move the credential into the app's own credential store, remove it from shared config text, and rotate it if the text has left your machine.",
              { keyName: e.name, line: e.line, length: e.value.length });
          }
        });

        /* --- Authentication --- */
        var authMethod = findEntry(entries, "AuthenticationMethod");
        var authRequired = findEntry(entries, "AuthenticationRequired");
        if (!authMethod) {
          add("warning", null, "Authentication method not stated",
            "No <AuthenticationMethod> setting appears in the pasted config, so this audit cannot confirm the web UI asks anyone to log in.",
            "Set AuthenticationMethod to Forms (or Basic) in Settings \u2192 General \u2192 Security and confirm the setting lands in config.xml.");
        } else {
          var am = authMethod.value.trim().toLowerCase();
          if (am === "disabled" || am === "none" || am === "") {
            add("critical", authMethod.line, "Authentication is disabled",
              "AuthenticationMethod is set to \"" + "Disabled" + "\". Anyone who can reach Prowlarr's port gets the full UI and API — every indexer credential and downstream app key it manages included.",
              "Set AuthenticationMethod to Forms, create an admin username and password, and restart Prowlarr before the port is reachable by anything you do not fully trust.");
          } else if (am === "forms" || am === "basic") {
            add("pass", authMethod.line, "Authentication is on (" + (am === "forms" ? "Forms" : "Basic") + ")",
              "The web UI requires a login.",
              "Keep it that way, and use a unique password for the Prowlarr admin account.");
          } else {
            add("info", authMethod.line, "Unrecognized authentication method value",
              "AuthenticationMethod holds a value this auditor does not recognize, so it cannot confirm the login behavior.",
              "Confirm in Settings \u2192 General \u2192 Security that authentication is enabled and set to Forms or Basic.");
          }
        }
        if (authRequired) {
          var ar = authRequired.value.trim().toLowerCase();
          if (ar.indexOf("disabledforlocal") !== -1 || ar === "disabled") {
            var sev = (authMethod && authMethod.value.trim().toLowerCase() === "disabled") ? "high" : "high";
            add(sev, authRequired.line, "Local addresses bypass authentication",
              "AuthenticationRequired is set so local addresses need no login. Anything on your LAN — a compromised smart TV, a guest phone, malware on any home device — reaches Prowlarr with no password at all.",
              "Set AuthenticationRequired to Enabled so every address, local or not, must log in. If you truly need the bypass, pair it with a bind address locked to localhost.");
          } else {
            add("pass", authRequired.line, "Authentication required for all addresses",
              "Local addresses are not exempt from logging in.",
              "No change needed.");
          }
        } else if (authMethod && authMethod.value.trim().toLowerCase() !== "disabled") {
          add("info", null, "AuthenticationRequired setting not found",
            "The pasted config does not state whether local addresses must authenticate.",
            "In Settings \u2192 General \u2192 Security, set Authentication Required to Enabled and confirm it appears in config.xml.");
        }

        /* --- Bind address --- */
        var bind = findEntry(entries, "BindAddress");
        var bindsAll = false;
        if (!bind) {
          add("warning", null, "Bind address not stated",
            "No <BindAddress> setting appears in the pasted config. Prowlarr's default listens on all network interfaces, so the UI and API are reachable from the whole LAN (and beyond, if the port is forwarded).",
            "Set BindAddress to 127.0.0.1 if Prowlarr is only used on this machine or through a reverse proxy, or to one specific LAN address.");
        } else {
          var bv = bind.value.trim();
          if (bv === "*" || bv === "0.0.0.0" || bv === "::" || bv === "") {
            bindsAll = true;
            add("high", bind.line, "Binds to all network interfaces",
              "BindAddress is \"" + (bv === "" ? "(empty)" : bv) + "\", so Prowlarr listens on every interface — LAN, Wi-Fi, VPN, and any forwarded port all reach it.",
              "Bind to 127.0.0.1 (plus a reverse proxy with its own login if you need remote access), or to the single LAN address that actually needs it.");
          } else if (bv === "127.0.0.1" || bv.toLowerCase() === "localhost" || bv === "::1") {
            add("pass", bind.line, "Binds to localhost only",
              "Prowlarr only answers on this machine. Remote access has to come through something else (reverse proxy, VPN, SSH tunnel) that can carry its own authentication.",
              "No change needed.");
          } else {
            add("info", bind.line, "Binds to a specific address",
              "BindAddress is set to a specific interface address rather than all interfaces.",
              "Confirm that address is on a network you trust, and that the port is not forwarded from the internet.");
          }
        }

        /* --- TLS / URL base --- */
        var ssl = findEntry(entries, "EnableSsl");
        var cert = findEntry(entries, "SslCertPath");
        var urlBase = findEntry(entries, "UrlBase");
        var sslOn = ssl && isTruthy(ssl.value);
        if (ssl && isFalsy(ssl.value)) {
          add(bindsAll ? "high" : "warning", ssl.line, "TLS (HTTPS) is off",
            bindsAll
              ? "EnableSsl is False while the server binds to all interfaces, so logins and the API key cross the network in clear text where anything on the path can read them."
              : "EnableSsl is False, so logins and the API key travel in clear text on whatever network the bind address exposes.",
            "Put Prowlarr behind a reverse proxy that terminates HTTPS (Caddy, Nginx, Traefik), or set EnableSsl to True with a valid SslCertPath. Do not log in over plain HTTP off the local machine.");
        } else if (sslOn) {
          if (cert && cert.value.trim()) {
            add("pass", ssl.line, "TLS is on with a certificate path set",
              "EnableSsl is True and an SslCertPath is configured.",
              "Keep the certificate renewed and the private key file readable only by the Prowlarr service account.");
          } else {
            add("warning", ssl.line, "TLS is on but no certificate path is stated",
              "EnableSsl is True but no SslCertPath appears in the pasted config, so the audit cannot confirm a certificate is actually loaded.",
              "Set SslCertPath to your certificate file (or terminate TLS at a reverse proxy instead) and restart, then confirm the UI loads over HTTPS without warnings.");
          }
        } else if (!ssl) {
          add("warning", null, "No TLS setting stated",
            "No <EnableSsl> setting appears in the pasted config, so this audit cannot confirm the UI is served over HTTPS.",
            "Serve Prowlarr over HTTPS — EnableSsl with a certificate, or a reverse proxy that terminates TLS — before logging in from any other device.");
        }
        if (urlBase) {
          var ub = urlBase.value.trim();
          if (/^http:\/\//i.test(ub)) {
            add("high", urlBase.line, "URL base uses plain HTTP",
              "UrlBase points at an http:// address, so the address you hand to browsers and apps sends credentials and the API key unencrypted.",
              "Use the https:// address (reverse proxy or EnableSsl) everywhere the URL base is referenced.");
          } else if (/^https:\/\//i.test(ub)) {
            add("pass", urlBase.line, "URL base uses HTTPS",
              "UrlBase points at an https:// address.",
              "No change needed.");
          }
        }

        /* --- Update branch --- */
        var branch = findEntry(entries, "Branch");
        if (!branch) {
          add("info", null, "Update branch not stated",
            "No <Branch> setting appears in the pasted config, so the audit cannot tell which update channel this install follows.",
            "Set the branch explicitly to master (stable) under Settings \u2192 General \u2192 Updates unless you are deliberately testing pre-releases.");
        } else {
          var brv = branch.value.trim().toLowerCase();
          if (brv === "develop" || brv === "nightly") {
            add("warning", branch.line, "Update branch is \"" + branch.value.trim() + "\" (pre-release)",
              "The " + branch.value.trim() + " branch ships pre-release builds. A bad nightly can break indexer sync or change security defaults before anyone has reviewed them — on the box that holds every indexer and app key you own.",
              "Switch Branch to master for the stable channel. Run develop/nightly only on a throwaway test instance with no real keys in it.");
          } else if (brv === "master" || brv === "main") {
            add("pass", branch.line, "Update branch is stable (" + branch.value.trim() + ")",
              "This install follows the stable update channel.",
              "No change needed.");
          } else {
            add("info", branch.line, "Unrecognized update branch value",
              "Branch holds a value this auditor does not recognize.",
              "Confirm under Settings \u2192 General \u2192 Updates that the branch is master unless you deliberately track pre-releases.");
          }
        }

        /* --- Log level --- */
        var log = findEntry(entries, "LogLevel");
        if (log) {
          var lv = log.value.trim().toLowerCase();
          if (lv === "trace" || lv === "debug") {
            add("warning", log.line, "Log level is " + log.value.trim() + " — logs can capture sensitive detail",
              "Debug and Trace logs can record request URLs and headers, which is exactly where API keys travel. Those log files then sit on disk, get pasted into support threads, and get bundled into diagnostics.",
              "Run at Info level day to day. Raise it only while troubleshooting, then lower it and rotate the API key if logs were shared.");
          } else {
            add("pass", log.line, "Log level is " + log.value.trim(),
              "A production-sane log level.",
              "No change needed.");
          }
        }

        /* --- Analytics --- */
        var analytics = findEntry(entries, "AnalyticsEnabled");
        if (analytics && isTruthy(analytics.value)) {
          add("info", analytics.line, "Analytics sharing is on",
            "AnalyticsEnabled is True, so this install sends anonymous usage data to the Prowlarr project.",
            "Optional: set AnalyticsEnabled to False if you prefer the install to phone home with nothing at all.");
        }

        return finish(findings);
      }

      function finish(findings) {
        var counts = { critical: 0, high: 0, warning: 0, info: 0, pass: 0 };
        findings.forEach(function (f) { counts[f.severity] = (counts[f.severity] || 0) + 1; });
        var verdict, verdictClass;
        if (counts.critical > 0 || counts.high > 0) { verdict = "DO NOT DEPLOY"; verdictClass = "danger"; }
        else if (counts.warning > 0) { verdict = "DEPLOY WITH FIXES"; verdictClass = "fixes"; }
        else { verdict = "SAFE TO DEPLOY"; verdictClass = "safe"; }
        findings.sort(function (a, b) {
          var order = { critical: 0, high: 1, warning: 2, info: 3, pass: 4 };
          if (order[a.severity] !== order[b.severity]) return order[a.severity] - order[b.severity];
          return (a.line || 0) - (b.line || 0);
        });
        return { verdict: verdict, verdictClass: verdictClass, counts: counts, findings: findings };
      }

      /* ---------- Report / JSON ---------- */

      function buildReport(result) {
        var lines = [];
        lines.push("J-Dawgs Prowlarr Server Config Safety Auditor\u2122 \u2014 Audit Report");
        lines.push("Verdict: " + result.verdict);
        lines.push("Findings: " + result.counts.critical + " critical, " + result.counts.high + " high, " +
          result.counts.warning + " warning, " + result.counts.info + " info, " + result.counts.pass + " pass");
        lines.push("Secrets are reported by key name, line, and length only. Values are never included.");
        lines.push("");
        result.findings.forEach(function (f, i) {
          lines.push((i + 1) + ". [" + f.severity.toUpperCase() + "] " + (f.line ? "Line " + f.line + " \u2014 " : "") + f.title);
          lines.push("   " + f.detail);
          if (f.secret) lines.push("   Secret reference: key \"" + f.secret.keyName + "\", line " + f.secret.line + ", length " + f.secret.length + " characters (value not shown).");
          lines.push("   Fix: " + f.fix);
        });
        lines.push("");
        lines.push("Scope: offline grade of pasted config text only. No live server was contacted and no key was verified.");
        return lines.join("\n");
      }

      function buildJson(result) {
        return JSON.stringify({
          tool: "J-Dawgs Prowlarr Server Config Safety Auditor\u2122",
          verdict: result.verdict,
          counts: result.counts,
          secretHandling: "Secrets are reported by key name, line, and length only. Values are never included.",
          findings: result.findings.map(function (f) {
            var o = { severity: f.severity, line: f.line, title: f.title, detail: f.detail, fix: f.fix };
            if (f.secret) o.secret = f.secret;
            return o;
          })
        }, null, 2);
      }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-prowlarr-server-config-safety-auditortm',
  name: 'J-Dawgs Prowlarr Server Config Safety Auditor',
  description: 'Prowlarr\'s own checks only answer whether the service starts on the host; ours grades a pasted Prowlarr config.xml or env fully offline — authentication disabled, a short or example ApiKey, wildcard bind, SSL off, plaintext indexer and application credentials — into one deploy verdict, with secrets ',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
