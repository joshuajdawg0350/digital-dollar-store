'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Env File Safety & Drift Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

  "use strict";

  var RISKY_ENV = [
    "# Production config — copied from the live server",
    "APP_NAME=My Trading App",
    "APP_ENV=production",
    "DATABASE_URL=postgres://admin:Tr7kP9sQ2wXz@db.prod.internal:5432/appdb",
    "STRIPE_SECRET_KEY=sk_live_4eC39HqLyjWDarjtT1zdp7dc8fK2mN9pQrSt",
    "SESSION_SECRET=9f2ac47be01d4c8a93f5e6b7d0a1c2e3",
    "api_token=abc123",
    "SMTP_PASSWORD=changeme",
    "EMPTY_KEY=",
    "APP_NAME=My Trading App Copy",
    "WELCOME_MESSAGE=Welcome to the shop #1 store",
    ""
  ].join("\n");

  var RISKY_EX = [
    "# Copy this file to .env and fill in real values",
    "APP_NAME=your-app-name",
    "APP_ENV=development",
    "DATABASE_URL=postgres://localhost:5432/example_db",
    "STRIPE_SECRET_KEY=your-key-here",
    "SESSION_SECRET=your-session-secret-here",
    "API_TOKEN=your-token-here",
    "SMTP_PASSWORD=changeme",
    "WELCOME_MESSAGE=your-welcome-message",
    "REDIS_URL=redis://localhost:6379",
    ""
  ].join("\n");

  var CLEAN_ENV = [
    "# Example config — safe to commit",
    "APP_NAME=example-app",
    "APP_ENV=development",
    "DATABASE_URL=postgres://localhost:5432/example_db",
    "STRIPE_SECRET_KEY=your-key-here",
    "SESSION_SECRET=changeme",
    "API_TOKEN=your-token-here",
    "SMTP_PASSWORD=your-password-here",
    "WELCOME_MESSAGE=your-welcome-message",
    "REDIS_URL=redis://localhost:6379",
    ""
  ].join("\n");

  var CLEAN_EX = [
    "# Copy this file to .env and fill in real values",
    "APP_NAME=your-app-name",
    "APP_ENV=development",
    "DATABASE_URL=postgres://localhost:5432/example_db",
    "STRIPE_SECRET_KEY=your-key-here",
    "SESSION_SECRET=your-session-secret-here",
    "API_TOKEN=your-token-here",
    "SMTP_PASSWORD=changeme",
    "WELCOME_MESSAGE=your-welcome-message",
    "REDIS_URL=redis://localhost:6379",
    ""
  ].join("\n");

  var envIn = document.getElementById("envIn");
  var exIn  = document.getElementById("exIn");
  var results = document.getElementById("results");
  var sanOut = document.getElementById("sanOut");

  /* ---------- parsing ---------- */
  function parseEnv(text){
    var entries = [], comments = [];
    var lines = String(text || "").split(/\r?\n/);
    for (var i = 0; i < lines.length; i++){
      var raw = lines[i];
      var lineNo = i + 1;
      var trimmed = raw.trim();
      if (trimmed === ""){ comments.push({line: lineNo, type:"blank"}); continue; }
      if (trimmed.charAt(0) === "#"){ comments.push({line: lineNo, type:"comment", text: raw}); continue; }
      var body = trimmed.replace(/^export\s+/, "");
      var eq = body.indexOf("=");
      if (eq === -1){
        entries.push({line: lineNo, key: body, rawKey: body, hasEq:false, value:"", rawValue:"", quoted:false});
        continue;
      }
      var rawKey = body.slice(0, eq);
      var key = rawKey.trim();
      var rawValue = body.slice(eq + 1);
      var leadTrim = rawValue.replace(/^\s+/, "");
      var quoted = false, value = leadTrim;
      var q = leadTrim.charAt(0);
      if ((q === '"' || q === "'") && leadTrim.length >= 2 && leadTrim.charAt(leadTrim.length - 1) === q){
        quoted = true;
        value = leadTrim.slice(1, -1);
      } else {
        value = leadTrim.replace(/\s+$/, "");
      }
      entries.push({line: lineNo, key: key, rawKey: rawKey, hasEq:true, value: value, rawValue: rawValue, quoted: quoted});
    }
    return {entries: entries, structure: comments.concat(entries).sort(function(a,b){return a.line-b.line;})};
  }

  /* ---------- detection helpers ---------- */
  var PLACEHOLDER_PATTERNS = ["changeme","change-me","change_me","todo","example","your-key-here","your_key_here",
    "your-","your_","placeholder","replace-me","replace_me","replace-with","xxx","dummy","sample","<","insert-","put-your","mysecret","not-a-real"];
  function isPlaceholder(v){
    var lv = String(v).toLowerCase();
    for (var i = 0; i < PLACEHOLDER_PATTERNS.length; i++){
      if (lv.indexOf(PLACEHOLDER_PATTERNS[i]) !== -1) return true;
    }
    return false;
  }
  function entropy(s){
    if (!s) return 0;
    var counts = {}, n = s.length, e = 0, k;
    for (var i = 0; i < n; i++){ counts[s[i]] = (counts[s[i]] || 0) + 1; }
    for (k in counts){ var p = counts[k] / n; e -= p * (Math.log(p) / Math.log(2)); }
    return e;
  }
  var KNOWN_PREFIXES = [
    {re:/^sk_live_[A-Za-z0-9]{8,}/, label:"live Stripe-style secret key"},
    {re:/^sk_(live|prod)_/, label:"live secret key"},
    {re:/^rk_live_/, label:"live restricted API key"},
    {re:/^ghp_[A-Za-z0-9]{20,}/, label:"GitHub personal access token"},
    {re:/^github_pat_[A-Za-z0-9_]{20,}/, label:"GitHub fine-grained token"},
    {re:/^gho_[A-Za-z0-9]{20,}/, label:"GitHub OAuth token"},
    {re:/^AKIA[0-9A-Z]{16}$/, label:"AWS access key ID"},
    {re:/^xox[baprs]-[A-Za-z0-9-]{8,}/, label:"Slack token"},
    {re:/^AIza[A-Za-z0-9_-]{20,}/, label:"Google API key"},
    {re:/^glpat-[A-Za-z0-9_-]{15,}/, label:"GitLab personal access token"},
    {re:/^hf_[A-Za-z0-9]{20,}/, label:"Hugging Face token"},
    {re:/^npm_[A-Za-z0-9]{30,}/, label:"npm token"},
    {re:/^-----BEGIN [A-Z ]*PRIVATE KEY-----/, label:"private key block"},
    {re:/^eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{5,}/, label:"JSON Web Token (JWT)"}
  ];
  var SENSITIVE_KEY = /(SECRET|TOKEN|PASSWORD|PASSWD|PWD|API_?KEY|PRIVATE|CREDENTIAL|AUTH|SESSION|ACCESS_?KEY|SIGNING)/i;

  function mask(v){
    var s = String(v);
    if (s.length <= 2) return "•• (" + s.length + " chars)";
    return s.slice(0, 2) + "•••• (" + s.length + " chars)";
  }
  function esc(s){
    return String(s).replace(/[&<>"']/g, function(c){
      return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c];
    });
  }
  function findUrlCreds(v){
    var m = String(v).match(/^([a-zA-Z][a-zA-Z0-9+.-]*):\/\/([^:\/?#@\s]+):([^@\/?#\s]*)@([^/?#\s]+)/);
    if (!m) return null;
    return {scheme: m[1], user: m[2], host: m[4]};
  }
  function looksSecret(e){
    var v = e.value;
    if (!v || isPlaceholder(v)) return null;
    var i;
    for (i = 0; i < KNOWN_PREFIXES.length; i++){
      if (KNOWN_PREFIXES[i].re.test(v)) return "matches the pattern of a " + KNOWN_PREFIXES[i].label;
    }
    if (SENSITIVE_KEY.test(e.key) && v.length >= 8 && !/^(true|false|null|none)$/i.test(v)){
      return "a non-placeholder value of " + v.length + " characters sitting in a secret-named key";
    }
    if (v.length >= 24 && entropy(v) >= 3.6 && /[a-z]/.test(v) && /[A-Z0-9]/.test(v) && !/\s/.test(v)){
      return "a long, high-entropy value (" + v.length + " chars) with the mixed character set typical of generated secrets";
    }
    if (/^[0-9a-f]{32,}$/i.test(v)){
      return "a long hex string (" + v.length + " chars) of the kind used for secrets and hashes";
    }
    return null;
  }

  /* ---------- audit ---------- */
  function audit(envText, exText){
    var env = parseEnv(envText);
    var findings = []; // {sev:'crit'|'warn'|'note', line, key, html}
    function add(sev, line, key, html){ findings.push({sev:sev, line:line, key:key, html:html}); }

    var seen = {};
    var envKeys = {}, exKeys = {}, exEntries = [];
    var i, e;

    for (i = 0; i < env.entries.length; i++){
      e = env.entries[i];
      envKeys[e.key] = true;

      if (!e.hasEq){
        add("warn", e.line, e.key, "Line has no <code>=</code> sign — most parsers will skip it or fail on it. Give it the form <code>KEY=value</code>.");
        continue;
      }
      /* key format */
      if (/\s/.test(e.rawKey) || e.key !== e.rawKey){
        add("warn", e.line, e.key, "Key contains spaces or is padded with whitespace. Parsers disagree on this — write it as one clean word, e.g. <code>" + esc(e.key.replace(/\s+/g, "_").toUpperCase()) + "</code>.");
      } else if (/[a-z]/.test(e.key)){
        add("warn", e.line, e.key, "Key contains lowercase letters. Environment variables are conventionally <code>UPPER_SNAKE_CASE</code>; some tools and shells will not pick this key up as written.");
      } else if (!/^[A-Z_][A-Z0-9_]*$/.test(e.key)){
        add("warn", e.line, e.key, "Key contains characters outside <code>A–Z, 0–9, _</code>. Rename it in <code>UPPER_SNAKE_CASE</code> so every parser reads it the same way.");
      }

      /* duplicates */
      if (seen[e.key]){
        add("warn", e.line, e.key, "Duplicate key — first set on line " + seen[e.key] + ". Which value wins depends on the parser; the other one is silently ignored. Delete one of them.");
      } else {
        seen[e.key] = e.line;
      }

      /* URL credentials — checked before generic secret test */
      var creds = findUrlCreds(e.value);
      if (creds && !isPlaceholder(e.value)){
        add("crit", e.line, e.key, "URL with an embedded password: <span class=\"mask\">" + esc(creds.scheme) + "://" + esc(creds.user) + ":••••@" + esc(creds.host) + "</span> — the host is <code>" + esc(creds.host) + "</code>; the password itself is never shown here. Anyone who can read this file has the database login. <span class=\"heuristic\">HEURISTIC</span>");
      }

      /* secret-looking (skipped when the URL-credentials finding already covers this line) */
      var why = creds ? null : looksSecret(e);
      if (why){
        add("crit", e.line, e.key, "Value looks like a real secret: <span class=\"mask\">" + esc(mask(e.value)) + "</span> — " + esc(why) + ". If this file is committed, treat the secret as exposed and rotate it. <span class=\"heuristic\">HEURISTIC</span>");
      }

      /* empty + placeholder */
      if (e.value === ""){
        add("note", e.line, e.key, "Empty value. Fine in an example file; in a real <code>.env</code> the app will read an empty string, which often fails later and confusingly.");
      } else if (isPlaceholder(e.value)){
        add("note", e.line, e.key, "Placeholder value — exactly what belongs in a committed example file, but this key still needs a real value in the deployed environment.");
      }

      /* unquoted parse hazards */
      if (!e.quoted && e.value !== ""){
        if (/#/.test(e.value)){
          add("warn", e.line, e.key, "Unquoted value contains a <code>#</code>. Many parsers treat everything after <code>#</code> as a comment, so the value will be silently cut short. Wrap it in double quotes.");
        }
        if (/\s/.test(e.value) && !creds){
          add("warn", e.line, e.key, "Unquoted value contains spaces. Some parsers keep them, some truncate at the first space, some error out. Wrap it in double quotes to be safe.");
        }
      }
    }

    /* drift */
    var drift = [];
    if (String(exText || "").trim() !== ""){
      var ex = parseEnv(exText);
      for (i = 0; i < ex.entries.length; i++){
        if (ex.entries[i].hasEq){ exKeys[ex.entries[i].key] = true; exEntries.push(ex.entries[i]); }
      }
      var allKeys = [];
      var pushed = {};
      env.entries.forEach(function(en){ if (!pushed[en.key]){ pushed[en.key] = true; allKeys.push(en.key); } });
      exEntries.forEach(function(en){ if (!pushed[en.key]){ pushed[en.key] = true; allKeys.push(en.key); } });
      allKeys.sort();
      allKeys.forEach(function(k){
        var inEnv = !!envKeys[k], inEx = !!exKeys[k];
        var status = inEnv && inEx ? "match" : (inEx ? "missing" : "extra");
        drift.push({key:k, inEnv:inEnv, inEx:inEx, status:status});
        if (status === "missing"){
          var ln = 0; exEntries.forEach(function(en){ if (en.key === k) ln = en.line; });
          add("warn", ln, k, "Listed in <code>.env.example</code> (line " + ln + " there) but <strong>missing from your .env</strong> — the app may start without a value it expects, or a teammate's setup will differ from yours.");
        } else if (status === "extra"){
          add("warn", seen[k] || 0, k, "Present in your <code>.env</code> but <strong>not in .env.example</strong> — anyone cloning the project won't know this key exists. Add it (as a placeholder) to the example.");
        }
      });
    }
    return {findings: findings, drift: drift, parsed: env, hasExample: String(exText || "").trim() !== ""};
  }

  /* ---------- sanitized example ---------- */
  function placeholderFor(key){
    var k = key.toUpperCase();
    if (/(URL|URI|ENDPOINT|HOST)/.test(k) && /URL|URI|ENDPOINT/.test(k)) return "https://example.com";
    if (/EMAIL/.test(k)) return "you@example.com";
    if (/PASSWORD|PASSWD|PWD/.test(k)) return "changeme";
    if (/SECRET/.test(k)) return "your-secret-here";
    if (/TOKEN/.test(k)) return "your-token-here";
    if (/KEY/.test(k)) return "your-key-here";
    if (/PORT/.test(k)) return "your-port-here";
    if (/NAME|APP|ENV|MODE|REGION|USER/.test(k)) return "your-value-here";
    return "your-value-here";
  }
  function sanitize(envText){
    var env = parseEnv(envText);
    var out = ["# Generated by J-Dawgs Env File Safety & Drift Auditor(TM)", "# Every value replaced with a placeholder — safe to commit as .env.example", ""];
    var emitted = {};
    env.structure.forEach(function(item){
      if (item.type === "comment"){ out.push(item.text); return; }
      if (item.type === "blank"){ out.push(""); return; }
      if (item.key === undefined) return;
      if (!item.hasEq){ return; }
      if (emitted[item.key]) return;
      emitted[item.key] = true;
      var cleanKey = item.key.replace(/\s+/g, "_").toUpperCase();
      out.push(cleanKey + "=" + placeholderFor(item.key));
    });
    while (out.length && out[out.length - 1] === "") out.pop();
    return out.join("\n") + "\n";
  }

  /* ---------- rendering ---------- */
  function render(){
    var res = audit(envIn.value, exIn.value);
    sanOut.textContent = sanitize(envIn.value);

    var crit = res.findings.filter(function(f){ return f.sev === "crit"; });
    var warn = res.findings.filter(function(f){ return f.sev === "warn"; });
    var note = res.findings.filter(function(f){ return f.sev === "note"; });
    var keyCount = {};
    res.parsed.entries.forEach(function(e){ if (e.hasEq) keyCount[e.key] = true; });
    var dupCount = res.parsed.entries.length - Object.keys(keyCount).length;
    var driftCount = res.drift.filter(function(d){ return d.status !== "match"; }).length;

    var verdict, vclass, vwhy;
    if (crit.length){
      verdict = "DO NOT COMMIT — REAL SECRETS PRESENT";
      vclass = "crit";
      vwhy = crit.length + " critical finding" + (crit.length === 1 ? "" : "s") + ": value(s) in this file look like live production secrets. Committing it would expose them to everyone with repo access — and to git history forever. Move the real values into a file that stays out of version control, commit the sanitized example below instead, and rotate any secret that has already been shared.";
    } else if (warn.length){
      verdict = "FIX BEFORE COMMITTING";
      vclass = "warnv";
      vwhy = "No live-looking secrets were found, but there " + (warn.length === 1 ? "is 1 problem" : "are " + warn.length + " problems") + " to fix first — duplicates, parse hazards, bad key formatting, or drift from the example. Fix the warnings below, then this file's sanitized example is safe to commit.";
    } else {
      verdict = "SAFE TO COMMIT EXAMPLE";
      vclass = "okv";
      vwhy = "No secrets, duplicates, parse hazards, or drift found. Values are empty or placeholders — exactly what a committed <code>.env.example</code> should hold. (Heuristic check only: a clean result is not proof, so give it one human read before pushing.)";
    }
    if (res.parsed.entries.length === 0){
      verdict = "NOTHING TO AUDIT YET";
      vclass = "warnv";
      vwhy = "Paste a .env file into the box above — or load one of the two examples — and the verdict will appear here.";
    }

    function sevBlock(title, color, list){
      var h = '<div class="sev"><div class="sev-head"><span class="sev-dot" style="background:' + color + '"></span><h3>' + title + '</h3><span class="count">' + list.length + (list.length === 1 ? " finding" : " findings") + '</span></div>';
      if (!list.length){ h += '<div class="empty-note">Nothing in this group.</div></div>'; return h; }
      h += '<ul class="findings">';
      list.forEach(function(f){
        h += '<li><span class="ln">line ' + f.line + '</span><span class="key">' + esc(f.key) + '</span> — ' + f.html + '</li>';
      });
      h += '</ul></div>';
      return h;
    }

    var driftHtml = "";
    if (res.hasExample){
      driftHtml = '<div class="card"><h2>Drift — .env vs .env.example</h2>';
      if (!res.drift.length){
        driftHtml += '<p class="muted">No keys found on either side to compare.</p>';
      } else {
        driftHtml += '<div class="tablewrap"><table><thead><tr><th>Key</th><th>In .env</th><th>In .env.example</th><th>Status</th></tr></thead><tbody>';
        res.drift.forEach(function(d){
          var label = d.status === "match" ? "In both" : (d.status === "missing" ? "Missing from .env" : "Extra in .env");
          driftHtml += '<tr><td class="k">' + esc(d.key) + '</td><td>' + (d.inEnv ? "Yes" : "—") + '</td><td>' + (d.inEx ? "Yes" : "—") + '</td><td><span class="pill ' + d.status + '">' + label + '</span></td></tr>';
        });
        driftHtml += '</tbody></table></div>';
        if (!driftCount) driftHtml += '<p class="small muted" style="margin-top:8px">No drift — the two files carry exactly the same keys.</p>';
      }
      driftHtml += '</div>';
    } else {
      driftHtml = '<div class="card flat"><h2>Drift — .env vs .env.example</h2><p class="muted">No <code>.env.example</code> pasted, so there is nothing to compare against. Paste one above to get the drift table and the missing / extra key checks.</p></div>';
    }

    results.innerHTML =
      '<div class="verdict ' + vclass + '"><div class="vlabel">Verdict</div><div class="vtext">' + verdict + '</div><div class="vwhy">' + vwhy + '</div></div>' +
      '<div class="stats">' +
        '<div class="stat"><div class="n">' + Object.keys(keyCount).length + '</div><div class="l">keys in .env</div></div>' +
        '<div class="stat"><div class="n">' + crit.length + '</div><div class="l">critical — secret-looking</div></div>' +
        '<div class="stat"><div class="n">' + dupCount + '</div><div class="l">duplicate key lines</div></div>' +
        '<div class="stat"><div class="n">' + (res.hasExample ? driftCount : "—") + '</div><div class="l">drifted keys vs example</div></div>' +
      '</div>' +
      '<div class="card"><h2>Findings, by severity</h2><p class="small muted">Every finding carries the line number in your pasted <code>.env</code> (drift findings point at the example\'s line where noted). Secret values are shown masked only — first 2 characters plus length.</p>' +
      sevBlock("Critical — real-looking secrets", "var(--crit)", crit) +
      sevBlock("Warnings — fix before committing", "var(--warn)", warn) +
      sevBlock("Notes — placeholders &amp; empties", "var(--note)", note) +
      '</div>' +
      driftHtml;
  }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-env-file-safety-auditor',
  name: 'J-Dawgs Env File Safety & Drift Auditor',
  description: 'You\'re about to commit a .env and the config might contain real secrets',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
