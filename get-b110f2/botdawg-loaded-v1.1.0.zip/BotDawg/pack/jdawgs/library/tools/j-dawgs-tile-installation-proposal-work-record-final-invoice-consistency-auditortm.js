'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Tile Installation Proposal, Work Record & Final Invoice Consistency Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";
/* ---------- money helpers ---------- */
function round2(n){ return Math.round((n + Number.EPSILON) * 100) / 100; }
function money(n){ return "$" + round2(n).toLocaleString("en-US",{minimumFractionDigits:2, maximumFractionDigits:2}); }
function parseNum(s){ return parseFloat(String(s).replace(/,/g,"")) || 0; }

/* ---------- document parsing ---------- */
var KEY_TERMS = ["underlayment","cement board","backer board","thinset","membrane","disposal","delivery","permit","labor","labour","tile","grout","mortar","trim","sealant","caulk","shower pan","niche","bullnose"];
function keyFor(desc){
  var d = " " + desc.toLowerCase() + " ";
  for (var i=0;i<KEY_TERMS.length;i++){ if (d.indexOf(KEY_TERMS[i]) !== -1) return KEY_TERMS[i].replace("labour","labor"); }
  var words = desc.toLowerCase().replace(/[^a-z0-9 ]/g," ").split(/\s+/).filter(function(w){ return w && ["installed","the","and","for"].indexOf(w)===-1; });
  return words.slice(0,2).join(" ") || "item";
}
function normUnit(u){
  u = (u||"").toLowerCase().replace(/\./g,"").replace(/\s+/g,"");
  if (u.indexOf("sq") === 0 || u === "sf") return "sqft";
  if (u === "h" || u.indexOf("hr") === 0 || u.indexOf("hour") === 0) return "h";
  if (u.indexOf("sheet") === 0) return "sheets";
  if (u.indexOf("bag") === 0) return "bags";
  if (u.indexOf("roll") === 0) return "rolls";
  if (u.indexOf("gal") === 0) return "gal";
  if (u === "ea" || u.indexOf("each") === 0) return "each";
  if (u.indexOf("board") === 0) return "boards";
  return u || "each";
}
var UNIT_RE = "(sq\\.?\\s?ft|sqft|sheets?|hours?|hrs?|h|each|ea|bags?|rolls?|gal|gallons?|boards?|lf|ft|pcs?|pieces?)";
function moneyAmounts(line){
  var out = [], m, re = /\$\s*([\d,]+(?:\.\d{1,2})?)/g;
  while ((m = re.exec(line)) !== null) out.push(parseNum(m[1]));
  return out;
}
function parseDoc(text){
  var doc = { items: [], depositPaid: 0, depositCredited: 0, hasDepositLine: false };
  if (!text) return doc;
  var lines = text.split(/\r?\n/);
  for (var li=0; li<lines.length; li++){
    var raw = lines[li].trim();
    if (!raw) continue;
    var lower = raw.toLowerCase();
    if (/^(sub)?total\b/.test(lower) || /^balance\b/.test(lower) || /^amount due\b/.test(lower) || /^tax\b/.test(lower)) continue;
    var amounts = moneyAmounts(raw);
    if (lower.indexOf("deposit") !== -1){
      doc.hasDepositLine = true;
      var amt = amounts.length ? amounts[amounts.length-1] : 0;
      if (lower.indexOf("credit") !== -1 || lower.indexOf("applied") !== -1 || lower.indexOf("less") !== -1) doc.depositCredited = amt;
      else doc.depositPaid = amt;
      continue;
    }
    /* description: text before the first number, @, $, or = */
    var desc = raw.split(/[\d@$=]/)[0].replace(/[—–\-:·•]+$/,"").trim();
    if (!desc) desc = raw.replace(/[\d$,.@=]/g," ").replace(/\s+/g," ").trim().split(" ").slice(0,3).join(" ");
    var qty = null, unit = "", unitPrice = 0, lineTotal = null;
    var atM = raw.match(new RegExp("([\\d,]+\\.?\\d*)\\s*" + UNIT_RE + "?\\s*@\\s*\\$?\\s*([\\d,]+\\.?\\d*)", "i"));
    if (atM){
      qty = parseNum(atM[1]); unit = normUnit(atM[2] || ""); unitPrice = parseNum(atM[3]);
    } else {
      var qM = raw.match(new RegExp("([\\d,]+\\.?\\d*)\\s*" + UNIT_RE + "\\b", "i"));
      if (qM){ qty = parseNum(qM[1]); unit = normUnit(qM[2]); }
    }
    var eqM = raw.match(/=\s*\$?\s*([\d,]+(?:\.\d{1,2})?)/);
    if (eqM) lineTotal = parseNum(eqM[1]);
    else if (amounts.length) lineTotal = amounts[amounts.length-1];
    if (qty === null && lineTotal !== null){ qty = 1; unit = "each"; unitPrice = lineTotal; }
    if (qty !== null && unitPrice && lineTotal === null) lineTotal = round2(qty * unitPrice);
    if (qty !== null && !unitPrice && lineTotal !== null && qty) unitPrice = round2(lineTotal / qty);
    if (qty === null) continue;
    doc.items.push({ desc: desc, key: keyFor(desc), qty: qty, unit: unit || "each", unitPrice: unitPrice || 0, total: lineTotal === null ? 0 : lineTotal, raw: raw });
  }
  return doc;
}

/* ---------- the audit ---------- */
function audit(pText, wText, iText){
  var names = ["Proposal","Work Record","Final Invoice"];
  var texts = [pText, wText, iText];
  var present = texts.map(function(t){ return (t||"").trim().length > 0; });
  var missing = names.filter(function(_,idx){ return !present[idx]; });
  var presentCount = present.filter(Boolean).length;
  var findings = [];
  var proposal = parseDoc(pText), work = parseDoc(wText), invoice = parseDoc(iText);

  if (presentCount < 2){
    findings.push({ type:"missing", title:"Not enough documents to compare",
      math:"Documents provided: " + (presentCount === 0 ? "none" : names.filter(function(_,idx){return present[idx];}).join(", ")) + ". Missing: " + missing.join(", ") + ". A cross-check needs at least two of the three documents.",
      amount: 0 });
    return { verdict:"NOT ENOUGH TO COMPARE", overcharge:0, missing:missing, findings:findings,
      parsed:{ proposal:proposal, work:work, invoice:invoice } };
  }

  function byKey(doc){ var m = {}; doc.items.forEach(function(it){ if (!(it.key in m)) m[it.key] = it; }); return m; }
  var pMap = byKey(proposal), wMap = byKey(work), iMap = byKey(invoice);

  /* duplicates in the invoice */
  var groups = {};
  invoice.items.forEach(function(it){ var g = it.key + "|" + it.total; (groups[g] = groups[g] || []).push(it); });
  Object.keys(groups).forEach(function(g){
    var arr = groups[g];
    if (arr.length > 1){
      var extra = round2((arr.length - 1) * arr[0].total);
      findings.push({ type:"duplicate", title:"Duplicate line: " + arr[0].desc,
        math:"\"" + arr[0].desc + "\" appears " + arr.length + " times on the invoice at " + money(arr[0].total) + " each.\n" + arr.length + " × " + money(arr[0].total) + " = " + money(arr.length * arr[0].total) + " billed; only one line is documented.\nDuplicate overcharge: (" + arr.length + " − 1) × " + money(arr[0].total) + " = " + money(extra),
        amount: extra });
    }
  });

  /* quantities + labor billed above recorded, and line arithmetic */
  Object.keys(iMap).forEach(function(key){
    var inv = iMap[key];
    var recorded = null, recordedLabel = "";
    if (present[1] && wMap[key]){ recorded = wMap[key]; recordedLabel = "work record"; }
    else if (present[0] && pMap[key]){ recorded = pMap[key]; recordedLabel = "proposal"; }
    if (recorded && inv.qty > recorded.qty){
      var price = inv.unitPrice || recorded.unitPrice || 0;
      var diff = round2(inv.qty - recorded.qty);
      if (price > 0){
        var amt = round2(diff * price);
        var isLabor = key === "labor";
        findings.push({ type: isLabor ? "labor-qty" : "qty", title:(isLabor ? "Labor billed above recorded hours: " : "Quantity billed above recorded: ") + inv.desc,
          math:"Invoice bills " + inv.qty + " " + inv.unit + " @ " + money(price) + ".\n" + (recordedLabel === "work record" ? "Work record shows " : "Proposal shows ") + recorded.qty + " " + inv.unit + ".\nDifference: " + inv.qty + " − " + recorded.qty + " = " + diff + " " + inv.unit + " × " + money(price) + " = " + money(amt),
          amount: amt });
      }
    }
    if (inv.qty && inv.unitPrice && inv.total && Math.abs(round2(inv.qty * inv.unitPrice) - inv.total) > 0.01){
      var should = round2(inv.qty * inv.unitPrice);
      if (inv.total > should){
        findings.push({ type:"arithmetic", title:"Line arithmetic does not add up: " + inv.desc,
          math: inv.qty + " " + inv.unit + " × " + money(inv.unitPrice) + " = " + money(should) + ", but the invoice line total is " + money(inv.total) + ".\nOverstated by " + money(inv.total) + " − " + money(should) + " = " + money(round2(inv.total - should)),
          amount: round2(inv.total - should) });
      }
    }
  });

  /* invoice-only fees */
  var seenFee = {};
  invoice.items.forEach(function(it){
    var isFee = /fee|charge|disposal|delivery|trip/i.test(it.desc);
    if (!isFee || seenFee[it.key]) return;
    seenFee[it.key] = true;
    if (!pMap[it.key] && !wMap[it.key]){
      findings.push({ type:"fee", title:"Invoice-only fee, in neither other document: " + it.desc,
        math:"\"" + it.desc + "\" is billed on the invoice at " + money(it.total) + ".\nIt appears in neither the proposal nor the work record, so nothing documents it.\nUndocumented fee: " + money(it.total),
        amount: it.total });
    }
  });

  /* deposit */
  var propDeposit = proposal.depositPaid || 0;
  if (present[0] && present[2] && propDeposit > 0){
    var credited = invoice.depositCredited || 0;
    if (credited < propDeposit){
      var short = round2(propDeposit - credited);
      findings.push({ type:"deposit", title:"Deposit not fully credited on the invoice",
        math:"Proposal records a deposit of " + money(propDeposit) + ".\nInvoice credits " + money(credited) + " of it.\nUncredited deposit: " + money(propDeposit) + " − " + money(credited) + " = " + money(short),
        amount: short });
    }
  }

  var overcharge = round2(findings.reduce(function(s,f){ return s + f.amount; }, 0));
  var verdict;
  if (presentCount === 2){
    verdict = "PAY WITH FIXES";
    findings.unshift({ type:"missing", title:"Missing document: " + missing.join(", "),
      math:"Only two of the three documents were provided, so this comparison is incomplete.\nMissing: " + missing.join(", ") + " — get it and re-run the cross-check before treating this verdict as final.",
      amount: 0 });
  } else if (overcharge === 0){
    verdict = "SAFE TO PAY";
  } else if (overcharge >= 300){
    verdict = "DO NOT PAY YET";
  } else {
    verdict = "PAY WITH FIXES";
  }
  return { verdict:verdict, overcharge:overcharge, missing:missing, findings:findings,
    parsed:{ proposal:proposal, work:work, invoice:invoice } };
}

/* ---------- example documents ---------- */
var EX_BAD_P = "Tile — 200 sqft @ $8.00 = $1,600.00\nUnderlayment — 10 sheets @ $45.00 = $450.00\nLabor — 16 h @ $75.00 = $1,200.00\nDeposit paid: $500.00";
var EX_BAD_W = "Tile installed — 180 sqft\nUnderlayment installed — 9 sheets\nLabor on site — 14 h";
var EX_BAD_I = "Tile — 200 sqft @ $8.00 = $1,600.00\nUnderlayment — 10 sheets @ $45.00 = $450.00\nLabor — 16 h @ $75.00 = $1,200.00\nGrout — $120.00\nGrout — $120.00\nDisposal fee — $85.00\nDeposit credited: $0.00";
var EX_GOOD_P = EX_BAD_P;
var EX_GOOD_W = "Tile installed — 200 sqft\nUnderlayment installed — 10 sheets\nLabor on site — 16 h";
var EX_GOOD_I = "Tile — 200 sqft @ $8.00 = $1,600.00\nUnderlayment — 10 sheets @ $45.00 = $450.00\nLabor — 16 h @ $75.00 = $1,200.00\nLess deposit credited: $500.00";
var EX_TWO_I = EX_GOOD_I;

/* ---------- UI ---------- */
var lastResult = null;
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-tile-installation-proposal-work-record-final-invoice-consistency-auditortm',
  name: 'J-Dawgs Tile Installation Proposal, Work Record & Final Invoice Consistency Auditor',
  description: 'Cross-checks a tile installation proposal against the work record and final invoice into one pay verdict, with the documented overcharge shown.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
