'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Docker Daemon Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

var RISKY = {
  "hosts": ["tcp://0.0.0.0:2375", "unix:///var/run/docker.sock"],
  "tlsverify": false,
  "insecure-registries": ["registry.local:5000", "10.0.0.0/8"],
  "debug": true,
  "experimental": true,
  "log-driver": "json-file",
  "icc": true
};
var HARDENED = {
  "hosts": ["tcp://0.0.0.0:2376", "unix:///var/run/docker.sock"],
  "tls": true,
  "tlsverify": true,
  "tlscacert": "/etc/docker/ca.pem",
  "tlscert": "/etc/docker/server-cert.pem",
  "tlskey": "/etc/docker/server-key.pem",
  "log-driver": "json-file",
  "log-opts": {"max-size": "10m", "max-file": "3"},
  "userns-remap": "default",
  "no-new-privileges": true,
  "icc": false,
  "live-restore": true,
  "debug": false,
  "experimental": false
};
document.getElementById('riskyPre').textContent = JSON.stringify(RISKY, null, 2);
document.getElementById('hardenedPre').textContent = JSON.stringify(HARDENED, null, 2);

var KNOWN_KEYS = {
  "hosts":1,"tls":1,"tlsverify":1,"tlscacert":1,"tlscert":1,"tlskey":1,"tls-min-version":1,"tls-max-version":1,
  "insecure-registries":1,"registry-mirrors":1,"disable-legacy-registry":1,
  "debug":1,"experimental":1,"log-driver":1,"log-opts":1,"log-level":1,
  "userns-remap":1,"no-new-privileges":1,"icc":1,"live-restore":1,
  "storage-driver":1,"storage-opts":1,"data-root":1,"exec-root":1,"pidfile":1,"group":1,
  "default-address-pools":1,"bip":1,"fixed-cidr":1,"fixed-cidr-v6":1,"mtu":1,"dns":1,"dns-opts":1,"dns-search":1,
  "labels":1,"max-concurrent-downloads":1,"max-concurrent-uploads":1,"max-download-attempts":1,
  "default-shm-size":1,"default-ulimits":1,"init":1,"init-path":1,"ipv6":1,"ip-forward":1,"ip-masq":1,"iptables":1,"ip6tables":1,
  "bridge":1,"cgroup-parent":1,"cluster-store":1,"cluster-store-opts":1,"cluster-advertise":1,"cluster-opts":1,
  "swarm-default-advertise-addr":1,"authorization-plugins":1,"containerd":1,"containerd-namespace":1,"containerd-plugins-namespace":1,
  "runtimes":1,"default-runtime":1,"shutdown-timeout":1,"node-generic-resources":1,"network-diagnostic-port":1,
  "features":1,"builder":1,"seccomp-profile":1,"selinux-enabled":1,"default-cgroupns-mode":1,"rootless":1,
  "proxies":1,"http-proxy":1,"https-proxy":1,"no-proxy":1,"exec-opts":1,"oom-score-adjust":1,"metrics-addr":1,
  "allow-nondistributable-artifacts":1,"watchdog":1,"cdi-spec-dirs":1,"registry-opts":1
};
var SECRET_NAME = /(password|passwd|pwd|token|secret|api[-_]?key|private[-_]?key|credential|auth[-_]?key)/i;

function isBool(v){ return typeof v === 'boolean'; }

// Minimal JSON scanner used only to locate the first syntax error position
// when JSON.parse fails (parser messages do not reliably carry a position).
function findJsonErrorPos(text){
  var i = 0, n = text.length;
  function ws(){ while(i<n && (text[i]===' '||text[i]==='\n'||text[i]==='\r'||text[i]==='\t')) i++; }
  function fail(){ throw {pos:i}; }
  function parseString(){
    if(text[i] !== '"') fail(); i++;
    while(i<n){
      var c = text[i];
      if(c === '"'){ i++; return; }
      if(c === '\\'){ i += 2; continue; }
      if(c < ' '){ fail(); }
      i++;
    }
    fail();
  }
  function parseNumber(){
    var start = i;
    if(text[i]==='-') i++;
    while(i<n && /[0-9]/.test(text[i])) i++;
    if(text[i]==='.'){ i++; while(i<n && /[0-9]/.test(text[i])) i++; }
    if(text[i]==='e'||text[i]==='E'){ i++; if(text[i]==='+'||text[i]==='-') i++; while(i<n && /[0-9]/.test(text[i])) i++; }
    if(i===start) fail();
  }
  function parseLit(word){ if(text.substr(i, word.length) === word){ i += word.length; } else fail(); }
  function parseValue(){
    ws(); if(i>=n) fail();
    var c = text[i];
    if(c === '{') parseObject();
    else if(c === '[') parseArray();
    else if(c === '"') parseString();
    else if(c === 't') parseLit('true');
    else if(c === 'f') parseLit('false');
    else if(c === 'n') parseLit('null');
    else parseNumber();
  }
  function parseObject(){
    i++; ws(); if(text[i]==='}'){ i++; return; }
    while(true){
      ws(); parseString(); ws();
      if(text[i] !== ':') fail(); i++;
      parseValue(); ws();
      if(text[i] === ','){ i++; continue; }
      if(text[i] === '}'){ i++; return; }
      fail();
    }
  }
  function parseArray(){
    i++; ws(); if(text[i]===']'){ i++; return; }
    while(true){
      parseValue(); ws();
      if(text[i] === ','){ i++; continue; }
      if(text[i] === ']'){ i++; return; }
      fail();
    }
  }
  try { parseValue(); ws(); if(i < n) return i; return -1; }
  catch(e){ if(e && typeof e.pos === 'number') return e.pos; return -1; }
}

function audit(text){
  var findings = [];
  function add(sev, title, detail, fix){ findings.push({sev:sev, title:title, detail:detail, fix:fix||''}); }

  if(!text || !text.trim()){
    add('BLOCKER','No config pasted','The input is empty, so there is nothing to deploy.','Paste the full contents of daemon.json, then audit again.');
    return finish(findings, null);
  }
  var cfg;
  try { cfg = JSON.parse(text); }
  catch(e){
    var msg = (e && e.message) ? e.message : String(e);
    var pos = null, m = msg.match(/position\s+(\d+)/i);
    if(m) pos = parseInt(m[1],10);
    if(pos === null || isNaN(pos)){ var scanned = findJsonErrorPos(text); if(scanned >= 0) pos = scanned; }
    var where = '';
    if(pos !== null && !isNaN(pos)){
      var upto = text.slice(0,pos);
      var line = upto.split('\n').length;
      var col = pos - upto.lastIndexOf('\n');
      where = ' Character position ' + pos + ' (line ' + line + ', column ' + col + ').';
    }
    add('BLOCKER','JSON parse error — file will not load','dockerd refuses a daemon.json it cannot parse.' + where + ' Parser message: ' + msg,'Fix the JSON syntax at the reported position — common causes are a trailing comma, an unquoted key, or a missing closing brace — then audit again.');
    return finish(findings, null);
  }
  if(cfg === null || typeof cfg !== 'object' || Array.isArray(cfg)){
    add('BLOCKER','Top level is not a JSON object','daemon.json must be a single JSON object of daemon settings. The paste parsed as ' + (Array.isArray(cfg)?'an array':typeof cfg) + '.','Wrap the settings in one { … } object and audit again.');
    return finish(findings, cfg);
  }

  var has = function(k){ return Object.prototype.hasOwnProperty.call(cfg,k); };

  // Secret-like keys anywhere at top level: key name only, value never rendered.
  Object.keys(cfg).forEach(function(k){
    if(SECRET_NAME.test(k)){
      add('WARNING','Secret-like key present: "' + k + '"','A key with this name does not belong in daemon.json — registry credentials live in the Docker client config, not the daemon config. The value was not read into this report and is never rendered.','Remove the secret from daemon.json, rotate it if it was ever committed or shared, and store registry credentials in a credential helper instead.');
    }
  });

  // Malformed types for audited keys + unknown keys
  var boolKeys = ['tls','tlsverify','debug','experimental','icc','live-restore','no-new-privileges','ipv6','ip-forward','ip-masq','iptables','selinux-enabled','init','disable-legacy-registry'];
  boolKeys.forEach(function(k){
    if(has(k) && !isBool(cfg[k])){
      add('WARNING','Malformed value for "' + k + '" — NOT AUDITED beyond type','This key expects true or false; the pasted value is a ' + (Array.isArray(cfg[k])?'array':typeof cfg[k]) + ', so its posture was not graded.','Set "' + k + '" to true or false and audit again.');
    }
  });
  if(has('hosts') && !Array.isArray(cfg.hosts)){
    add('WARNING','Malformed value for "hosts" — NOT AUDITED beyond type','"hosts" expects an array of listen addresses; the pasted value is a ' + typeof cfg.hosts + ', so listener exposure was not graded from it.','Set "hosts" to an array such as ["unix:///var/run/docker.sock"] and audit again.');
  }
  if(has('insecure-registries') && !Array.isArray(cfg['insecure-registries'])){
    add('WARNING','Malformed value for "insecure-registries" — NOT AUDITED beyond type','"insecure-registries" expects an array of registry addresses; the pasted value is a ' + typeof cfg['insecure-registries'] + '.','Set it to an array (or remove it) and audit again.');
  }
  Object.keys(cfg).forEach(function(k){
    if(!KNOWN_KEYS[k] && !SECRET_NAME.test(k)){
      add('INFO','Unknown key NOT AUDITED: "' + k + '"','This tool does not recognize this daemon.json key, so it was not graded. Unknown keys can also make dockerd refuse to start on some versions.','Confirm the key is a real daemon.json setting for your Docker version, or remove it.');
    }
  });

  // ---- hosts exposure paired with TLS ----
  var tlsverify = has('tlsverify') ? cfg.tlsverify : undefined;
  var tlsOn = has('tls') ? cfg.tls : undefined;
  var verifiedTLS = (tlsverify === true);
  var tcpHosts = [];
  if(!has('hosts')){
    add('INFO','"hosts" NOT SET IN FILE','No listen addresses are set in this file. The daemon’s effective listeners then come from its defaults (normally the local unix socket) and any dockerd command-line flags — neither is visible in this file, so exposure from flags is NOT VERIFIED.','If the daemon must be reachable over TCP, set "hosts" explicitly here so the exposure is on the record.');
  } else if(Array.isArray(cfg.hosts)){
    if(cfg.hosts.length === 0){
      add('WARNING','"hosts" is an empty array','An empty hosts list can leave the daemon with no usable listener, or silently fall back to defaults depending on version.','List the intended listeners explicitly, e.g. ["unix:///var/run/docker.sock"].');
    }
    cfg.hosts.forEach(function(h){
      if(typeof h !== 'string'){ add('WARNING','Non-string entry in "hosts" — NOT AUDITED','One hosts entry is a ' + typeof h + ', not an address string, so it was not graded.','Use address strings such as "unix:///var/run/docker.sock" or "tcp://127.0.0.1:2376".'); return; }
      var lower = h.toLowerCase();
      if(lower.indexOf('tcp://') === 0){
        tcpHosts.push(h);
        var rest = h.slice(6);
        var hostPart = rest, port = null;
        var colon = rest.lastIndexOf(':');
        if(colon >= 0){ hostPart = rest.slice(0,colon); var p = parseInt(rest.slice(colon+1),10); if(!isNaN(p)) port = p; }
        var wildcard = (hostPart === '0.0.0.0' || hostPart === '' || hostPart === '::' || hostPart === '[::]');
        var loopback = (hostPart === '127.0.0.1' || hostPart === 'localhost' || hostPart === '::1' || hostPart === '[::1]');
        if(port === 2375){
          add('BLOCKER','Plaintext Docker API exposed: ' + h,'Port 2375 is the unencrypted Docker API. Anyone who can reach it can start containers with the host filesystem mounted — that is unauthenticated root-equivalent access to the host. tlsverify does not encrypt 2375 by convention; this listener is plaintext.','Remove the 2375 listener. Serve the API on 2376 with "tlsverify": true and a CA, or keep the API on the local unix socket only.');
        } else if(port === 2376){
          if(!verifiedTLS){
            add('BLOCKER','TLS port without verified TLS: ' + h,'Port 2376 is the TLS Docker API port, but "tlsverify" is ' + (has('tlsverify') ? String(tlsverify) : 'NOT SET IN FILE') + ' — clients are not verified, so the listener is exposed without mutual TLS.','Set "tlsverify": true and provide "tlscacert", "tlscert", and "tlskey", or remove the TCP listener.');
          } else {
            add('PASS','TLS listener with client verification: ' + h,'The 2376 listener is paired with "tlsverify": true, so clients must present a certificate signed by the configured CA.','No change needed for this listener. Keep the CA private key off the host’s shared storage.');
          }
        } else if(wildcard && !verifiedTLS){
          add('BLOCKER','Wildcard TCP listener without verified TLS: ' + h,'This listener binds every network interface and "tlsverify" is not true, so the Docker API is reachable from the network without client-certificate verification.','Bind to 127.0.0.1, require "tlsverify": true with a full certificate set, or remove the TCP listener.');
        } else if(!loopback && !verifiedTLS){
          add('WARNING','Network TCP listener without verified TLS: ' + h,'This listener is reachable beyond the local host and "tlsverify" is not true.','Require "tlsverify": true with a full certificate set, or restrict the listener to localhost / the unix socket.');
        } else if(loopback && !verifiedTLS && tlsOn !== true){
          add('WARNING','Localhost TCP listener without TLS: ' + h,'Bound to localhost, so exposure is limited to local users — but any local process can then drive the daemon, which is root-equivalent.','Prefer the unix socket (whose group controls access), or add TLS even for local TCP.');
        } else {
          add('PASS','TCP listener graded with TLS posture: ' + h,'This listener is either localhost-only with TLS on, or paired with "tlsverify": true.','No change needed for this listener.');
        }
      } else if(lower.indexOf('unix://') === 0 || lower.indexOf('npipe://') === 0){
        add('PASS','Local socket listener: ' + h,'A local socket is not reachable from the network. Access is governed by the socket’s file permissions and group — those live outside this file and are NOT VERIFIED here.','Keep the socket group limited to operators who should have root-equivalent daemon access.');
      } else if(lower.indexOf('fd://') === 0){
        add('INFO','systemd socket listener: ' + h,'Activation is delegated to systemd; the socket unit’s own ListenStream setting decides exposure and is NOT VERIFIED from this file.','Check the docker.socket unit if the daemon should not be network-reachable.');
      } else {
        add('WARNING','Unrecognized hosts entry — NOT AUDITED: scheme not graded','One hosts entry does not start with tcp://, unix://, npipe://, or fd://, so its exposure was not graded.','Use a documented listener scheme, or remove the entry.');
      }
    });
  }

  // ---- TLS pairing ----
  var hasCA = has('tlscacert'), hasCert = has('tlscert'), hasKey = has('tlskey');
  if(tlsverify === true){
    if(!hasCA) add('WARNING','"tlsverify" is on but "tlscacert" is NOT SET IN FILE','Client verification needs a CA certificate to verify against. Without one, the tlsverify setting cannot do its job as written.','Set "tlscacert" to the CA certificate path.');
    if(!hasCert || !hasKey) add('WARNING','"tlsverify" is on but the server certificate pair is incomplete','"tlscert" is ' + (hasCert?'set':'NOT SET IN FILE') + ' and "tlskey" is ' + (hasKey?'set':'NOT SET IN FILE') + '. Mutual TLS needs both.','Set both "tlscert" and "tlskey" to the server’s certificate and key paths.');
    if(hasCA && hasCert && hasKey) add('PASS','Complete TLS set for verified TLS','tlsverify is on and tlscacert, tlscert, and tlskey are all set. The certificates’ contents and expiry are outside this file and NOT VERIFIED.','Rotate the certificates before they expire and keep the key file readable only by root.');
  }
  if(tlsverify === false && tcpHosts.length){
    add('WARNING','"tlsverify" is explicitly false with a TCP listener present','Client certificates are not verified on the TCP API. Combined with the listener findings above, treat the API as unauthenticated wherever it is reachable.','Set "tlsverify": true with a complete certificate set, or remove the TCP listener.');
  }
  if(tlsOn === false && (hasCA || hasCert || hasKey)){
    add('WARNING','Certificate paths set while "tls" is false','tlscacert / tlscert / tlskey entries are present but TLS is switched off, so they protect nothing.','Either set "tls": true (and "tlsverify": true) or remove the unused certificate paths.');
  }
  if(tlsOn === true && tlsverify !== true && tcpHosts.length){
    add('WARNING','"tls" is on but "tlsverify" is not true','The channel is encrypted, but clients are not verified — anyone with network reach can still drive the API.','Set "tlsverify": true and provide tlscacert, tlscert, and tlskey.');
  }
  if(!has('tls') && !has('tlsverify') && !hasCA && !hasCert && !hasKey){
    add('INFO','No TLS keys set in file','Neither "tls" nor "tlsverify" nor any tls* certificate path appears in this file. That is fine for a unix-socket-only daemon; it is graded together with the "hosts" findings above if any TCP listener exists.','For any TCP listener, add the full verified-TLS set.');
  }

  // ---- insecure registries & mirrors ----
  if(has('insecure-registries') && Array.isArray(cfg['insecure-registries'])){
    var regs = cfg['insecure-registries'];
    if(regs.length === 0){
      add('PASS','"insecure-registries" is set and empty','No registry is exempted from verification.','No change needed.');
    } else {
      regs.forEach(function(r){
        add('WARNING','Insecure registry listed: ' + String(r),'Docker will pull from this registry without full TLS verification. A network attacker — or a compromised registry — can serve altered images that then run with whatever privileges your containers get.','Remove this entry and serve the registry over HTTPS with a certificate Docker trusts, or restrict the exception to an isolated build network.');
      });
    }
  } else if(!has('insecure-registries')){
    add('INFO','"insecure-registries" NOT SET IN FILE','No insecure-registry exceptions are declared in this file, so no registry is exempted here.','Leave it unset unless a private registry genuinely cannot present a trusted certificate.');
  }
  if(has('registry-mirrors') && Array.isArray(cfg['registry-mirrors'])){
    cfg['registry-mirrors'].forEach(function(mUrl){
      if(typeof mUrl === 'string' && mUrl.toLowerCase().indexOf('http://') === 0){
        add('WARNING','Registry mirror over plaintext HTTP: ' + mUrl,'Images pulled through an http:// mirror can be altered in transit.','Use an https:// mirror.');
      }
    });
  }

  // ---- debug / experimental ----
  if(cfg.debug === true) add('WARNING','"debug": true','Debug mode floods daemon logs with verbose detail and is a production hazard — log volume and information disclosure both grow.','Set "debug": false for production; turn it on only while actively diagnosing.');
  else if(cfg.debug === false) add('PASS','"debug": false','Debug logging is off.','No change needed.');
  else if(!has('debug')) add('INFO','"debug" NOT SET IN FILE','Debug mode is not set in this file; the daemon default (off) and any flags decide it — flags are NOT VERIFIED here.','Set "debug": false explicitly if you want the posture on the record.');

  if(cfg.experimental === true) add('WARNING','"experimental": true','Experimental daemon features are not supported for production and can change or vanish between releases.','Set "experimental": false on production hosts.');
  else if(cfg.experimental === false) add('PASS','"experimental": false','Experimental features are off.','No change needed.');
  else if(!has('experimental')) add('INFO','"experimental" NOT SET IN FILE','Experimental mode is not set in this file; the daemon default (off) and any build/flags decide it — NOT VERIFIED here.','Set "experimental": false explicitly if you want the posture on the record.');

  // ---- logging posture ----
  if(!has('log-driver')){
    add('INFO','"log-driver" NOT SET IN FILE','The logging driver is not set here, so the daemon default (json-file) applies — and under that default, the max-size finding below is the one that matters.','Set "log-driver" and "log-opts" explicitly so the posture survives a default change.');
  } else if(cfg['log-driver'] === 'none'){
    add('WARNING','"log-driver": "none" — container logs are discarded','With the "none" driver, docker logs returns nothing. Incident response and debugging lose the record entirely.','Use "json-file" with rotation caps, or a real log pipeline (journald, fluentd, gelf) instead of "none".');
  } else if(typeof cfg['log-driver'] === 'string'){
    add('INFO','"log-driver": "' + cfg['log-driver'] + '"','Driver named in file. Destination-side retention for remote drivers (journald, syslog, fluentd, gelf, awslogs, gcplogs) lives outside this file and is NOT VERIFIED.');
  }
  var drv = has('log-driver') ? cfg['log-driver'] : 'json-file (daemon default)';
  var effectiveJsonFile = !has('log-driver') || cfg['log-driver'] === 'json-file';
  if(effectiveJsonFile){
    var opts = (has('log-opts') && cfg['log-opts'] && typeof cfg['log-opts'] === 'object' && !Array.isArray(cfg['log-opts'])) ? cfg['log-opts'] : null;
    if(!opts || !Object.prototype.hasOwnProperty.call(opts,'max-size')){
      add('WARNING','json-file logging has no "max-size" cap (driver: ' + drv + ')','Without log-opts.max-size, a chatty or looping container grows its log file until the disk fills — a classic self-inflicted Docker outage.','Add "log-opts": {"max-size": "10m", "max-file": "3"} (tune the size to your disk).');
    } else {
      add('PASS','json-file log rotation cap set: max-size = ' + String(opts['max-size']),'A max-size cap is present' + (Object.prototype.hasOwnProperty.call(opts,'max-file') ? ' with max-file = ' + String(opts['max-file']) : ' (max-file NOT SET IN FILE — the daemon default applies)') + ', so a single container log cannot grow without bound.','No change needed. Re-check the cap against your disk size when you tune it.');
    }
  }

  // ---- hardening posture (honest: absence = NOT SET IN FILE = INFO) ----
  if(!has('userns-remap')){
    add('INFO','"userns-remap" NOT SET IN FILE','User-namespace remapping is not declared here. Absence in this file is not proof it is off — it can only be judged from the running daemon — so this is reported, not penalized.','Consider "userns-remap": "default" so container root maps to an unprivileged host user, after checking your images tolerate it.');
  } else {
    add('PASS','"userns-remap" is set','Container root is remapped into a user namespace (value graded by presence; the named mapping itself is an operations choice).','Confirm the subordinate UID/GID ranges exist for the named user.');
  }
  if(!has('no-new-privileges')){
    add('INFO','"no-new-privileges" NOT SET IN FILE','The daemon-wide no-new-privileges default is not declared here. Containers can still set it per-container; absence in this file is reported, not assumed insecure.','Set "no-new-privileges": true if you want the default on the record.');
  } else if(cfg['no-new-privileges'] === true){
    add('PASS','"no-new-privileges": true','Containers cannot gain privileges via setuid binaries or file capabilities by default.','No change needed.');
  } else if(cfg['no-new-privileges'] === false){
    add('WARNING','"no-new-privileges": false','The file explicitly turns off the no-new-privileges default, so setuid escalation inside containers stays available unless each container opts in.','Set it to true unless a named workload genuinely needs setuid behavior.');
  }
  if(!has('icc')){
    add('INFO','"icc" NOT SET IN FILE','Inter-container communication is not declared here; the daemon default and flags decide it — NOT VERIFIED from this file.','Set "icc": false and link only the containers that must talk, if your workloads allow it.');
  } else if(cfg.icc === false){
    add('PASS','"icc": false','Containers on the default bridge cannot talk to each other unless explicitly linked or placed on a shared user-defined network.','No change needed.');
  } else if(cfg.icc === true){
    add('WARNING','"icc": true — unrestricted inter-container communication','Every container on the default bridge can reach every other container. One compromised container can probe them all.','Set "icc": false and connect containers deliberately with user-defined networks.');
  }
  if(!has('live-restore')){
    add('INFO','"live-restore" NOT SET IN FILE','Live restore is not declared here. It is an availability trade-off, not a pure security switch: on keeps containers running through a daemon restart; off ties container lifetime to the daemon. Reported, not penalized.','Choose deliberately: true for hosts whose workloads must survive daemon upgrades.');
  } else if(cfg['live-restore'] === true){
    add('INFO','"live-restore": true','Containers keep running when the daemon restarts. Availability improves; note a stopped or upgraded daemon also cannot inspect or stop those containers until it is back.','No change required — keep daemon upgrades prompt so the blind window stays short.');
  } else if(cfg['live-restore'] === false){
    add('INFO','"live-restore": false','Containers stop when the daemon stops. Simpler control, at the cost of downtime on every daemon restart or upgrade.','Consider true if daemon-upgrade downtime is a problem.');
  }

  // metrics-addr exposure (bonus, honest)
  if(has('metrics-addr') && typeof cfg['metrics-addr'] === 'string'){
    var ma = cfg['metrics-addr'];
    if(ma.indexOf('0.0.0.0') === 0 || ma.indexOf(':') === 0){
      add('WARNING','"metrics-addr" binds all interfaces: ' + ma,'The daemon metrics endpoint is reachable from the network without authentication.','Bind metrics to 127.0.0.1 and scrape it locally.');
    }
  }

  return finish(findings, cfg);
}

function finish(findings, cfg){
  var counts = {BLOCKER:0, WARNING:0, INFO:0, PASS:0};
  findings.forEach(function(f){ counts[f.sev]++; });
  var verdict, cls, why;
  if(counts.BLOCKER > 0){ verdict='DO NOT DEPLOY'; cls='blocked'; why = counts.BLOCKER + ' BLOCKER finding' + (counts.BLOCKER===1?'':'s') + ' must be fixed before this daemon config goes on a host.'; }
  else if(counts.WARNING > 0){ verdict='DEPLOY WITH FIXES'; cls='fixes'; why = 'No BLOCKERs, but ' + counts.WARNING + ' WARNING finding' + (counts.WARNING===1?'':'s') + ' should be fixed before or immediately after deploy.'; }
  else { verdict='SAFE TO DEPLOY'; cls='safe'; why='No BLOCKERs and no WARNINGs in the audited keys. INFO and PASS findings above record the posture that was graded — and what was NOT SET IN FILE or NOT VERIFIED.'; }
  return {verdict:verdict, cls:cls, why:why, counts:counts, findings:findings};
}

var lastResult = null;
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-docker-daemon-config-safety-auditortm',
  name: 'J-Dawgs Docker Daemon Config Safety Auditor',
  description: 'dockerd --validate only answers will-it-load; ours grades a pasted daemon.json offline — plaintext 2375 / 2376-without-tlsverify BLOCKERs, insecure registries, TLS pairing — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
