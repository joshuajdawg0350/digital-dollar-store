'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs ArangoDB Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

    "use strict";

    /* ============================================================
       ArangoDB Server Config Safety Auditor — pure audit engine.
       No DOM access in this section, so the engine can be tested
       headlessly. Secret VALUES are never copied into findings:
       secret-bearing keys are reported by name, line, length only.
       ============================================================ */

    var KNOWN_PREFIXES = {
      server:1, database:1, ssl:1, javascript:1, foxx:1, cluster:1,
      agency:1, log:1, replication:1, http:1, wal:1, rocksdb:1,
      encryption:1, ldap:1, threads:1, console:1, audit:1
    };
    var MULTI_KEYS = { "server.endpoint":1 }; /* arangod legitimately accepts several endpoints */
    var EXAMPLE_SECRETS = {
      "secret":1, "jwt-secret":1, "jwtsecret":1, "changeme":1, "change-me":1,
      "password":1, "test":1, "example":1, "mysecret":1, "supersecret":1,
      "arangodb":1, "letmein":1, "default":1, "demo":1
    };

    function isFalseVal(v){ return /^(false|no|off|0)$/i.test(String(v).trim()); }
    function isTrueVal(v){ return /^(true|yes|on|1)$/i.test(String(v).trim()); }
    function isEnvRef(v){ return /^\$\{?[A-Za-z_]/.test(v) && (v.indexOf("ENV") !== -1 || /^\$\{/.test(v)); }
    function isFileRef(v){ return /^(\/|~\/|[A-Za-z]:[\\/])/.test(v); }
    function isEphemeralPath(v){
      return /^(\/tmp|\/var\/tmp|\/dev\/shm|\/run\/user)(\/|$)/.test(v) || v === "/tmp";
    }
    function isRelativePath(v){ return !/^(\/|~\/|[A-Za-z]:[\\/])/.test(v); }
    function isSecretKey(key){
      var last = key.split(".").pop();
      return /(password|passwd|secret)/.test(last) || /(password|passwd)/.test(key);
    }

    function canonKey(section, rawKey){
      var k = String(rawKey).trim().toLowerCase().replace(/_/g, "-");
      if (section && k.indexOf(".") === -1) return section + "." + k;
      return k;
    }

    /* Parse INI-style conf text and/or arangod CLI option lists.
       Returns { entries:[{key,value,line}], sectionsSeen:{}, recognized:int } */
    function parseConfig(text){
      var entries = [];
      var sectionsSeen = {};
      var lines = String(text).replace(/^\uFEFF/, "").split(/\r?\n/);
      var section = "";
      var pendingCli = null; /* {key, line} waiting for its value token */

      function pushCliValue(tok){
        if (pendingCli){
          entries.push({ key: pendingCli.key, value: tok, line: pendingCli.line });
          pendingCli = null;
        }
      }
      function flushCli(){
        if (pendingCli){
          entries.push({ key: pendingCli.key, value: "true", line: pendingCli.line });
          pendingCli = null;
        }
      }

      for (var i = 0; i < lines.length; i++){
        var lineNo = i + 1;
        var raw = lines[i];
        var trimmed = raw.trim();

        if (trimmed === "") { continue; }
        if (/^[#;]/.test(trimmed)) { continue; } /* commented out = NOT active, never graded */

        var isCliLine = /^--/.test(trimmed) || (/^arangod\b/.test(trimmed) && /--/.test(trimmed)) ||
                        (pendingCli !== null && !/^\[/.test(trimmed) && trimmed.indexOf("=") === -1 && !/^[#;]/.test(trimmed) && section === "" && /^--/.test(trimmed));

        if (/--/.test(trimmed) && !/^\[/.test(trimmed) && trimmed.indexOf("=") !== -1 && /^--/.test(trimmed) === false && /^[A-Za-z]/.test(trimmed) && trimmed.indexOf(" --") === -1 && !/^--/.test(trimmed)){
          isCliLine = false; /* plain INI key = value */
        }
        if (/^--/.test(trimmed) || (/--/.test(trimmed) && trimmed.indexOf(" --") !== -1 && !/^[A-Za-z][\w.-]*\s*=/.test(trimmed))){
          isCliLine = true;
        }

        if (isCliLine){
          var tokens = trimmed.split(/\s+/);
          for (var t = 0; t < tokens.length; t++){
            var tok = tokens[t];
            if (tok === "\\") continue;
            if (/^--/.test(tok)){
              flushCli();
              var body = tok.slice(2);
              var eq = body.indexOf("=");
              if (eq !== -1){
                entries.push({ key: canonKey("", body.slice(0, eq)), value: body.slice(eq + 1).replace(/\\$/, ""), line: lineNo });
              } else {
                pendingCli = { key: canonKey("", body), line: lineNo };
              }
            } else if (pendingCli){
              pushCliValue(tok.replace(/\\$/, ""));
            }
            /* bare tokens (program name, stray words) are ignored */
          }
          continue;
        }

        var secMatch = trimmed.match(/^\[([^\]]+)\]\s*$/);
        if (secMatch){
          section = secMatch[1].trim().toLowerCase();
          sectionsSeen[section] = true;
          continue;
        }

        var eqIdx = trimmed.indexOf("=");
        if (eqIdx !== -1){
          flushCli();
          var rawKey = trimmed.slice(0, eqIdx).trim();
          var val = trimmed.slice(eqIdx + 1).trim();
          if ((val.charAt(0) === '"' && val.charAt(val.length - 1) === '"') ||
              (val.charAt(0) === "'" && val.charAt(val.length - 1) === "'")){
            val = val.slice(1, -1);
          }
          if (rawKey){
            entries.push({ key: canonKey(section, rawKey), value: val, line: lineNo });
          }
          continue;
        }
        /* line with no '=' and no '--' : prose / unparseable, ignored */
      }
      flushCli();

      var recognized = 0;
      entries.forEach(function(e){
        var prefix = e.key.split(".")[0];
        if (KNOWN_PREFIXES[prefix]) recognized++;
      });
      Object.keys(sectionsSeen).forEach(function(s){
        if (KNOWN_PREFIXES[s]) recognized++;
      });

      return { entries: entries, sectionsSeen: sectionsSeen, recognized: recognized, lineCount: lines.length };
    }

    function parseEndpoint(value){
      var m = String(value).match(/^([a-z][a-z0-9+]*):\/\/(.*)$/i);
      if (!m) return { scheme: "", host: "", raw: value };
      var scheme = m[1].toLowerCase();
      var rest = m[2];
      var host = "";
      if (rest.charAt(0) === "["){
        var close = rest.indexOf("]");
        host = close !== -1 ? rest.slice(1, close) : rest;
      } else if (scheme !== "unix"){
        host = rest.split(/[:/]/)[0];
      }
      return { scheme: scheme, host: host, raw: value };
    }

    function auditConfig(text){
      var findings = [];
      function add(severity, line, key, title, detail, fix){
        findings.push({ severity: severity, line: (line == null ? null : line), key: key || "", title: title, detail: detail, fix: fix });
      }

      if (!text || String(text).trim() === ""){
        return { verdict: "NOT ENOUGH TO GRADE", reason: "The paste was empty — there is nothing to audit yet.", findings: [], stats: { entries: 0, recognized: 0 } };
      }
      var parsed = parseConfig(text);
      if (parsed.entries.length === 0 || parsed.recognized === 0){
        return {
          verdict: "NOT ENOUGH TO GRADE",
          reason: "No recognizable ArangoDB settings were found. This auditor grades arangod.conf sections ([server], [database], [ssl], [javascript], [foxx], [cluster], [log]) and arangod command-line options (--server.endpoint, --server.authentication, …). Prose, and config files for other software, cannot be graded.",
          findings: [], stats: { entries: parsed.entries.length, recognized: parsed.recognized }
        };
      }

      var byKey = {};
      parsed.entries.forEach(function(e){
        if (!byKey[e.key]) byKey[e.key] = [];
        byKey[e.key].push(e);
      });
      function last(key){ var a = byKey[key]; return a ? a[a.length - 1] : null; }
      function all(key){ return byKey[key] || []; }

      /* ---------- duplicates (last value wins) ---------- */
      Object.keys(byKey).forEach(function(key){
        var a = byKey[key];
        if (a.length > 1 && !MULTI_KEYS[key]){
          var linesList = a.map(function(e){ return e.line; }).join(", ");
          add("WARNING", a[a.length - 1].line, key,
            "Duplicate key: " + key,
            "This key is set " + a.length + " times (lines " + linesList + "). arangod uses the last value (line " + a[a.length - 1].line + "); the earlier setting" + (a.length > 2 ? "s are" : " is") + " dead text that can mislead the next reader.",
            "Delete all but one " + key + " line and keep the value you actually mean.");
        }
      });

      /* ---------- authentication ---------- */
      var authEntry = last("server.authentication");
      var authOff = false, authKnown = false;
      if (authEntry){
        authKnown = true;
        authOff = isFalseVal(authEntry.value);
        if (authOff){
          add("BLOCKER", authEntry.line, "server.authentication",
            "Authentication is switched off",
            "server.authentication is false. Anyone who can reach this server gets full access — read, write, and drop every database — with no password at all.",
            "Set server.authentication = true and restart arangod. Create real users with passwords in arangosh or the web interface before exposing the server.");
        }
      } else {
        add("INFO", null, "server.authentication",
          "Authentication is not set in this file",
          "server.authentication does not appear in the paste. arangod's built-in default is enabled, so the posture is probably fine — but it rests on a default, not on anything written down here.",
          "Write server.authentication = true explicitly so the posture survives upgrades and is visible to the next reader. Note: whether the root password itself was changed lives in the database, not in this file — this audit cannot see it.");
      }

      var sysOnly = last("server.authentication-system-only");
      if (sysOnly && isTrueVal(sysOnly.value)){
        add("INFO", sysOnly.line, "server.authentication-system-only",
          "System-only authentication is on",
          "server.authentication-system-only is true: credentials are checked against the _system database only. That is the stricter posture for servers whose users are managed centrally.",
          "No change needed. Make sure every application user exists in the _system database, or logins will fail.");
      }
      var unixAuth = last("server.authentication-unix-sockets");
      if (unixAuth){
        add("INFO", unixAuth.line, "server.authentication-unix-sockets",
          "Unix-socket authentication posture is set explicitly",
          "server.authentication-unix-sockets is " + (isTrueVal(unixAuth.value) ? "true — connections over the unix socket still require credentials" : "false — connections over the unix socket skip credential checks, so the socket file's OS permissions are the only gate") + ". This setting covers sockets only; it does not change TCP behavior.",
          isTrueVal(unixAuth.value)
            ? "No change needed."
            : "If any untrusted local account exists on this host, set server.authentication-unix-sockets = true and restrict the socket file to the arangod user.");
      }

      /* ---------- endpoints ---------- */
      var endpoints = all("server.endpoint");
      var plaintextEndpoints = [];
      var encryptedEndpoints = [];
      endpoints.forEach(function(ep){
        var p = parseEndpoint(ep.value);
        if (p.scheme === "unix"){
          add("INFO", ep.line, "server.endpoint",
            "Endpoint is a unix socket",
            "This endpoint (" + ep.value + ") is local to the machine — it cannot be reached over the network at all.",
            "No change needed for network exposure. Guard the socket file with OS permissions.");
          return;
        }
        var isPlain = (p.scheme === "tcp" || p.scheme === "http" || p.scheme === "");
        if (isPlain) plaintextEndpoints.push(ep); else encryptedEndpoints.push(ep);
        var allIface = (p.host === "0.0.0.0" || p.host === "::" || p.host === "");
        var loopback = (p.host === "127.0.0.1" || p.host === "::1" || p.host.toLowerCase() === "localhost");
        if (allIface){
          if (authOff){
            add("BLOCKER", ep.line, "server.endpoint",
              "Server listens on every interface with authentication off",
              "Endpoint " + ep.value + " binds all network interfaces, and server.authentication is false. Together that means anyone on the network — or the internet, if this host is reachable — owns this database.",
              "Bind to a specific interface (for example tcp://127.0.0.1:8529 for local-only, or the host's private IP) AND set server.authentication = true. Do not deploy until both are done.");
          } else {
            add("HIGH", ep.line, "server.endpoint",
              "Server listens on every network interface",
              "Endpoint " + ep.value + " binds 0.0.0.0 / all interfaces. The database port answers on every network this host touches, including any public one.",
              "Bind to the one interface that needs it (a private IP, or 127.0.0.1 for local-only), and put a firewall rule on port 8529 as a second line of defense.");
          }
        } else if (loopback){
          add("INFO", ep.line, "server.endpoint",
            "Endpoint is bound to localhost only",
            "Endpoint " + ep.value + " answers on this machine only. Remote clients cannot reach it directly.",
            "No change needed. If remote apps need access later, prefer a reverse proxy or SSH tunnel over rebinding to 0.0.0.0.");
        }
      });
      if (endpoints.length === 0){
        add("INFO", null, "server.endpoint",
          "No endpoint is set in this file",
          "With no server.endpoint in the paste, arangod falls back to its default of tcp://127.0.0.1:8529 — this machine only.",
          "No change needed for a local server. Set the endpoint explicitly before running arangod on a shared host so the binding is a decision, not a default.");
      }

      /* ---------- JWT secret (value NEVER reported) ---------- */
      var jwt = last("server.jwt-secret");
      var jwtKeyfile = last("server.jwt-secret-keyfile");
      var clusterPresent = Object.keys(byKey).some(function(k){ return k.indexOf("cluster.") === 0 || k.indexOf("agency.") === 0; });
      if (jwtKeyfile){
        add("INFO", jwtKeyfile.line, "server.jwt-secret-keyfile",
          "JWT secret is loaded from a keyfile",
          "server.jwt-secret-keyfile points arangod at a file holding the secret, so no secret value sits in this config. (This audit does not open that file.)",
          "No change needed. Keep the keyfile readable only by the arangod user.");
      }
      if (jwt){
        var jv = jwt.value;
        if (isEnvRef(jv)){
          add("INFO", jwt.line, "server.jwt-secret",
            "JWT secret comes from an environment reference",
            "server.jwt-secret is set from an environment reference rather than a literal value, so no secret appears in this file.",
            "No change needed. Make sure the variable is set in arangod's environment on every node.");
        } else if (isFileRef(jv)){
          add("INFO", jwt.line, "server.jwt-secret",
            "JWT secret is a file reference, not a literal value",
            "server.jwt-secret holds a path rather than the secret itself, so no secret value appears in this config.",
            "No change needed. Restrict that file to the arangod user.");
        } else if (jv === ""){
          add("WARNING", jwt.line, "server.jwt-secret",
            "JWT secret key is present but empty",
            "server.jwt-secret is set to an empty value on this line. An empty or unset secret means tokens are signed with a per-start random secret — sessions die on every restart and nodes cannot validate each other's tokens.",
            "Set a long random secret (32+ characters) directly, via ${ENV:…}, or via server.jwt-secret-keyfile.");
        } else {
          var isExample = !!EXAMPLE_SECRETS[jv.toLowerCase()];
          if (isExample || jv.length < 32){
            add("HIGH", jwt.line, "server.jwt-secret",
              isExample ? "JWT secret matches a well-known example value" : "JWT secret is too short (" + jv.length + " characters)",
              "server.jwt-secret on this line is " + (isExample ? "a commonly copied example value" : "only " + jv.length + " characters long") + ". Anyone who knows or guesses it can forge admin tokens for this server. (The value itself is never shown in this report — only its length.)",
              "Replace it with a random secret of at least 32 characters, ideally loaded from a keyfile or ${ENV:…} reference, and use the same secret on every cluster node.");
          } else {
            add("INFO", jwt.line, "server.jwt-secret",
              "JWT secret length looks adequate (" + jv.length + " characters)",
              "server.jwt-secret is set inline with a length of " + jv.length + " characters. Inline secrets work, but they sit in every copy of this file. (The value itself is never shown in this report.)",
              "Consider moving it to server.jwt-secret-keyfile or an ${ENV:…} reference so the config file can be shared and committed safely.");
          }
        }
      } else if (!jwtKeyfile){
        if (clusterPresent){
          add("WARNING", null, "server.jwt-secret",
            "No JWT secret is pinned, but cluster settings are present",
            "This paste has cluster/agency settings but no server.jwt-secret. Without one shared secret, each node signs tokens with its own random secret and authentication breaks across the cluster.",
            "Set the same long random server.jwt-secret (or keyfile) on every coordinator and DBserver before starting the cluster.");
        } else {
          add("INFO", null, "server.jwt-secret",
            "No JWT secret is pinned in this file",
            "With no server.jwt-secret set, arangod generates a random secret at each start — fine for a single server (existing sessions simply end at restart), but it must be pinned and shared before this config grows into a cluster.",
            "No change needed for a single server. Pin a 32+ character secret before clustering.");
        }
      }

      /* ---------- any other plaintext password/secret keys (value NEVER reported) ---------- */
      Object.keys(byKey).forEach(function(key){
        if (key === "server.jwt-secret" || key === "server.jwt-secret-keyfile") return;
        if (!isSecretKey(key)) return;
        var e = last(key);
        var v = e.value;
        if (isEnvRef(v) || isFileRef(v)) {
          add("INFO", e.line, key,
            "Secret-bearing key uses a reference, not a literal value",
            key + " is set from an environment or file reference, so no secret value appears in this config.",
            "No change needed.");
        } else if (v === ""){
          add("WARNING", e.line, key,
            "Secret-bearing key is set but empty",
            key + " has an empty value. An empty password or secret usually means the feature falls back to a default or to no protection at all.",
            "Set a real value, or remove the key so the intended behavior is explicit.");
        } else {
          add("HIGH", e.line, key,
            "Plaintext secret stored in the config file",
            key + " holds a literal secret value (" + v.length + " characters) in plain text. Anyone who can read this file — backups, repos, screenshots — has the secret. (The value itself is never shown in this report — only its length.)",
            "Move the secret out of the file: use an ${ENV:…} reference or a keyfile with tight permissions, and rotate the exposed secret since it has been sitting in plain text.");
        }
      });

      /* ---------- SSL ---------- */
      var sslProto = last("ssl.protocol");
      if (sslProto){
        var pv = sslProto.value.trim().toLowerCase();
        var num = parseInt(pv, 10);
        var outdated = false, protoDesc = sslProto.value;
        if (/ssl/.test(pv)) outdated = true;
        else if (/tlsv?1(\.0|\.1)?\b/.test(pv) && !/1\.2|1\.3/.test(pv)) outdated = true;
        else if (!isNaN(num) && num < 5) outdated = true;
        if (outdated){
          add("WARNING", sslProto.line, "ssl.protocol",
            "SSL protocol setting allows outdated protocol versions",
            "ssl.protocol is set to " + protoDesc + ". Settings below the current top value permit TLS versions older than 1.2 (or SSL itself), which have known weaknesses and fail most compliance checks.",
            "Set ssl.protocol = 5 (TLS 1.2 and newer) unless a legacy client truly cannot — and fix that client instead.");
        }
      }
      var sslKeyfile = last("ssl.keyfile");
      if (sslKeyfile && plaintextEndpoints.length > 0){
        add("WARNING", sslKeyfile.line, "ssl.keyfile",
          "SSL is configured, but the endpoint still serves plaintext",
          "An ssl.keyfile is configured on this line, yet server.endpoint (line " + plaintextEndpoints[0].line + ") uses a plain tcp:// / http:// scheme. Clients will keep connecting unencrypted and the certificate protects nothing.",
          "Change the endpoint scheme to ssl:// (for example ssl://127.0.0.1:8529) so the configured keyfile is actually used, or front the server with a TLS-terminating proxy.");
      }
      if (!sslKeyfile){
        encryptedEndpoints.forEach(function(ep){
          add("WARNING", ep.line, "server.endpoint",
            "Encrypted endpoint with no SSL keyfile configured",
            "Endpoint " + ep.value + " uses an encrypted scheme, but no ssl.keyfile appears in this paste. arangod cannot serve TLS without a keyfile and will refuse or fall back depending on version.",
            "Set ssl.keyfile to your combined certificate/key PEM file, readable only by the arangod user.");
        });
      }

      /* ---------- JavaScript / Foxx execution surfaces ---------- */
      ["javascript.execute", "javascript.execute-string"].forEach(function(key){
        var e = last(key);
        if (e){
          add("WARNING", e.line, key,
            "Startup option executes a JavaScript file/string",
            key + " makes arangod run script code at startup. Anyone who can edit this config — or the file it points at — gets code execution as the arangod user.",
            "Remove " + key + " from production configs. Run one-off scripts with arangosh instead of baking execution into the server config.");
        }
      });
      var adminExec = last("javascript.allow-admin-execute");
      if (adminExec && isTrueVal(adminExec.value)){
        add("HIGH", adminExec.line, "javascript.allow-admin-execute",
          "Admin JavaScript execution endpoint is enabled",
          "javascript.allow-admin-execute is true. Any admin credential can execute arbitrary JavaScript inside the server process via the /_admin/execute API — full server-side code execution, not just queries.",
          "Set javascript.allow-admin-execute = false in production. Almost no deployment needs it outside development.");
      }
      Object.keys(byKey).forEach(function(key){
        if (!/^(javascript|foxx)\./.test(key)) return;
        if (!/(app-path|startup-directory|app-directory|directory|path)$/.test(key)) return;
        if (key === "javascript.execute") return;
        var e = last(key);
        var v = e.value;
        if (isEphemeralPath(v) || isRelativePath(v) || /^\/home\//.test(v)){
          add("WARNING", e.line, key,
            "App/startup directory sits on a shared or relative path",
            key + " points at " + v + ". arangod loads and runs the JavaScript/Foxx code it finds there. A directory under /tmp, a home folder, or a relative path is writable by people and processes beyond the arangod service account — whoever writes there, runs code in your database server.",
            "Move it to a root-owned system path (for example /var/lib/arangodb3-apps) writable only by the arangod user.");
        }
      });

      /* ---------- cluster / agency ---------- */
      ["cluster.agency-endpoint", "agency.endpoint"].forEach(function(key){
        all(key).forEach(function(e){
          var p = parseEndpoint(e.value);
          if (p.scheme === "tcp" || p.scheme === "http"){
            add("WARNING", e.line, key,
              "Agency endpoint uses a plaintext scheme",
              key + " (" + e.value + ") talks to the agency over an unencrypted endpoint. Agency traffic carries the cluster's whole configuration and coordination state.",
              "Use ssl:// agency endpoints with certificates on any network you do not fully control.");
          } else {
            add("INFO", e.line, key,
              "Agency endpoint is configured",
              key + " points this node at an agency endpoint (" + e.value + "). The agency is the cluster's source of truth — a wrong or hostile agency endpoint hands control of the cluster to whoever answers there.",
              "Confirm the endpoint resolves to your own agency nodes and nothing else.");
          }
        });
      });
      ["cluster.agency-size", "agency.size"].forEach(function(key){
        var e = last(key);
        if (!e) return;
        var n = parseInt(e.value, 10);
        if (isNaN(n)) return;
        if (n === 1){
          add("WARNING", e.line, key,
            "Agency size is 1 — no fault tolerance",
            key + " is 1. A single agency node means the whole cluster stops coordinating the moment that one node is lost.",
            "Run an agency of 3 (or 5) nodes for any cluster you depend on.");
        } else if (n % 2 === 0){
          add("WARNING", e.line, key,
            "Agency size is even (" + n + ")",
            key + " is " + n + ". The agency decides by majority vote, and an even size tolerates no more failures than " + (n - 1) + " nodes would — the extra node adds cost, not safety.",
            "Use an odd agency size: 3 for most clusters, 5 for large ones.");
        }
      });
      var rpi = last("cluster.require-persisted-id");
      if (rpi && isFalseVal(rpi.value)){
        add("WARNING", rpi.line, "cluster.require-persisted-id",
          "Persisted node identity is not required",
          "cluster.require-persisted-id is false. On hosts with ephemeral storage, a restarted node can come back with a fresh identity and confuse cluster membership — the classic cause of 'ghost node' agency problems.",
          "Set cluster.require-persisted-id = true and make sure each node's data directory survives restarts.");
      }

      /* ---------- database directory ---------- */
      var dbDir = last("database.directory");
      if (dbDir){
        if (isEphemeralPath(dbDir.value)){
          add("WARNING", dbDir.line, "database.directory",
            "Database directory is on an ephemeral path",
            "database.directory points at " + dbDir.value + ". /tmp and friends are wiped on reboot on many systems and are shared with every local process — your entire database can vanish or be tampered with.",
            "Move database.directory to a dedicated persistent path such as /var/lib/arangodb3, owned by the arangod user.");
        } else if (isRelativePath(dbDir.value)){
          add("WARNING", dbDir.line, "database.directory",
            "Database directory is a relative path",
            "database.directory is " + dbDir.value + " — relative to wherever arangod happens to be started from. A different working directory means a different (empty) database, or an old one silently abandoned.",
            "Use an absolute path such as /var/lib/arangodb3 so the data location never depends on the start directory.");
        }
      }

      /* ---------- logging posture ---------- */
      var logLevel = last("log.level");
      if (logLevel){
        var lv = logLevel.value.trim().toLowerCase();
        var globalLevel = lv.indexOf("=") === -1 ? lv : null;
        if (globalLevel && /^(error|fatal|none|off|crash)$/.test(globalLevel)){
          add("INFO", logLevel.line, "log.level",
            "Log level hides security-relevant events",
            "log.level is set to " + logLevel.value + ". Authentication failures, rejected connections, and configuration warnings are logged at lower levels — at this setting you would have no record of someone probing or attacking the server.",
            "Run production at log.level = info (warning at the strictest) and ship the log somewhere it is actually read.");
        }
      }

      /* ---------- verdict ---------- */
      var rank = { BLOCKER: 0, HIGH: 1, WARNING: 2, INFO: 3 };
      findings.sort(function(a, b){
        if (rank[a.severity] !== rank[b.severity]) return rank[a.severity] - rank[b.severity];
        var la = a.line == null ? 99999 : a.line, lb = b.line == null ? 99999 : b.line;
        return la - lb;
      });
      var counts = { BLOCKER: 0, HIGH: 0, WARNING: 0, INFO: 0 };
      findings.forEach(function(f){ counts[f.severity]++; });

      var verdict, reason;
      if (counts.BLOCKER > 0){
        verdict = "DO NOT DEPLOY";
        reason = counts.BLOCKER + " blocker" + (counts.BLOCKER > 1 ? "s" : "") + " would expose this server the moment it starts. Fix every BLOCKER before this config goes anywhere near a real host.";
      } else if (counts.HIGH > 0 || counts.WARNING > 0){
        verdict = "DEPLOY WITH FIXES";
        reason = "No blockers, but " + (counts.HIGH + counts.WARNING) + " finding" + ((counts.HIGH + counts.WARNING) > 1 ? "s" : "") + " should be fixed before or immediately after deploy — each one below names the line and the fix.";
      } else {
        verdict = "SAFE TO DEPLOY";
        reason = findings.length
          ? "No blockers, highs, or warnings. The notes below are informational only — defaults worth writing down and postures worth confirming."
          : "No risky ArangoDB settings were found in this paste.";
      }
      return { verdict: verdict, reason: reason, findings: findings, counts: counts, stats: { entries: parsed.entries.length, recognized: parsed.recognized } };
    }

    function buildReport(result){
      var out = [];
      out.push("ARANGODB SERVER CONFIG SAFETY AUDIT");
      out.push("Verdict: " + result.verdict);
      if (result.stats) out.push("Active settings parsed: " + result.stats.entries);
      if (result.reason) out.push(result.reason);
      out.push("");
      if (!result.findings || result.findings.length === 0){
        out.push("No findings.");
      } else {
        result.findings.forEach(function(f, i){
          out.push((i + 1) + ". [" + f.severity + "] " + (f.line != null ? "Line " + f.line : "Not set in file") + (f.key ? " — " + f.key : ""));
          out.push("   " + f.title);
          out.push("   " + f.detail);
          out.push("   Fix: " + f.fix);
          out.push("");
        });
      }
      out.push("Limits: heuristic text audit of the pasted config only. This tool does not start ArangoDB, does not inspect a live server, and cannot tell whether the root password was changed — that lives in the database, not the file. Secret values are never printed; secrets are reported by key name, line, and length only.");
      return out.join("\n");
    }

    function buildJSON(result){
      return JSON.stringify({
        tool: "J-Dawgs ArangoDB Server Config Safety Auditor",
        verdict: result.verdict,
        reason: result.reason,
        counts: result.counts || null,
        findings: (result.findings || []).map(function(f){
          return { severity: f.severity, line: f.line, key: f.key, title: f.title, detail: f.detail, fix: f.fix };
        })
      }, null, 2);
    }

    /* ============================================================
       Example configs
       ============================================================ */
    var RISKY_EXAMPLE = [
      "# arangod.conf — copied off a test VM (risky)",
      "[database]",
      "directory = /tmp/arangodb-data",
      "",
      "[server]",
      "endpoint = tcp://0.0.0.0:8529",
      "authentication = false",
      "jwt-secret = Tr0pic@lThunder99",
      "storage-engine = auto",
      "storage-engine = rocksdb",
      "",
      "[ssl]",
      "keyfile = /etc/arangodb3/server.pem",
      "protocol = 4",
      "",
      "[javascript]",
      "app-path = /tmp/foxx-apps",
      "allow-admin-execute = true",
      "",
      "[cluster]",
      "agency-size = 2",
      "require-persisted-id = false",
      "",
      "[log]",
      "level = error"
    ].join("\n");

    var HARDENED_EXAMPLE = [
      "# arangod.conf — hardened single server",
      "[database]",
      "directory = /var/lib/arangodb3",
      "",
      "[server]",
      "endpoint = ssl://127.0.0.1:8529",
      "authentication = true",
      "authentication-system-only = true",
      "jwt-secret-keyfile = /etc/arangodb3/jwt-secret",
      "",
      "[ssl]",
      "keyfile = /etc/arangodb3/server.pem",
      "protocol = 5",
      "",
      "[javascript]",
      "startup-directory = /usr/share/arangodb3/js",
      "app-path = /var/lib/arangodb3-apps",
      "allow-admin-execute = false",
      "",
      "[log]",
      "level = info",
      "output = /var/log/arangodb3/arangod.log"
    ].join("\n");
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_SECRETS": (typeof EXAMPLE_SECRETS !== 'undefined' ? EXAMPLE_SECRETS : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-arangodb-server-config-safety-auditortm',
  name: 'J-Dawgs ArangoDB Server Config Safety Auditor',
  description: 'Grades a pasted arangod.conf — or an arangod command line — fully offline into one deploy verdict — endpoint and TLS exposure, authentication posture, and plaintext secrets shown by key name, line, and length only. ArangoDB only exercises a config by starting the server; this grades it before anythi',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_SECRETS": __core["EXAMPLE_SECRETS"], "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
