'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Uptime Kuma Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var PLACEHOLDERS = ["changeme","change-me","change_me","password","passw0rd","admin","admin123",
        "default","letmein","123456","12345678","123456789","secret","test","example","placeholder",
        "kuma","uptime","root","qwerty","your_password","your-password","yourpassword","todo","xxx","none","null"];
      var TOKEN_PARAMS = ["token","access_token","apikey","api_key","key","secret","auth","password","passwd","bottoken","webhook_token"];
      var SECRET_KEY_RE = /PASS|SECRET|TOKEN|API_?KEY|PRIVATE|CREDENTIAL/i;

      function isTruthy(v){
        v = String(v).trim().toLowerCase().replace(/^["']|["']$/g,"");
        return ["true","1","yes","on","enabled","enable"].indexOf(v) !== -1;
      }
      function isFalsy(v){
        v = String(v).trim().toLowerCase().replace(/^["']|["']$/g,"");
        return ["false","0","no","off","disabled","disable"].indexOf(v) !== -1;
      }
      function unquote(v){
        v = String(v).trim();
        if (v.length >= 2 && ((v.charAt(0)==='"' && v.charAt(v.length-1)==='"') || (v.charAt(0)==="'" && v.charAt(v.length-1)==="'"))) {
          return v.slice(1,-1);
        }
        return v;
      }

      function audit(text){
        var findings = [];
        function add(sev, line, key, check, message, fix){
          findings.push({severity:sev, line:(line==null?null:line), key:key||null, check:check, message:message, fix:fix});
        }

        if (!text || !text.trim()){
          return {verdict:"NOT ENOUGH TO GRADE", format:"—", linesChecked:0, findings:[], fixes:[]};
        }

        var rawLines = text.replace(/\r\n?/g,"\n").split("\n");
        var entries = {};        // KEY -> {value, line}
        var entryOrder = [];
        var portMappings = [];   // {line, ip (string|null), hostPort, containerPort}
        var hasDataVolume = false, dataLine = null, dataEphemeral = false;
        var tlsNote = false, backupNote = false, headersNote = false;
        var notParsedCount = 0;
        var composeSignals = 0, envSignals = 0;

        rawLines.forEach(function(raw, idx){
          var lineNo = idx + 1;
          var line = raw.replace(/\s+$/,"");
          var trimmed = line.trim();
          if (!trimmed) return;

          // Comment lines: scan for notes only.
          if (/^\s*(#|\/\/)/.test(line)){
            if (/tls|ssl|https|reverse proxy|proxy|cert/i.test(trimmed)) tlsNote = true;
            if (/backup/i.test(trimmed)) backupNote = true;
            if (/security headers/i.test(trimmed)) headersNote = true;
            return;
          }
          if (/backup/i.test(trimmed)) backupNote = true;

          var m;
          // docker-compose port mapping inside a list item, e.g. - "127.0.0.1:3001:3001"
          var pm = trimmed.match(/^-\s*["']?(?:(\d{1,3}(?:\.\d{1,3}){3}):)?(\d{1,5}):(\d{1,5})["']?\s*$/);
          if (pm){
            portMappings.push({line:lineNo, ip:pm[1]||null, hostPort:pm[2], containerPort:pm[3]});
            return;
          }
          // Volume / data-dir content on any line.
          if (/\/app\/data/.test(trimmed) || /uptime-kuma-data/.test(trimmed)){
            hasDataVolume = true; dataLine = lineNo;
            if (/\/tmp\b|tmpfs/.test(trimmed)) dataEphemeral = true;
          }

          // env assignment: KEY=VALUE, optionally "- KEY=VALUE" or "export KEY=VALUE"
          m = trimmed.match(/^(?:export\s+)?(?:-\s*)?([A-Za-z_][A-Za-z0-9_.-]*)\s*=\s*(.*)$/);
          if (m){
            envSignals++;
            var k = m[1].toUpperCase();
            var v = unquote(m[2]);
            if (!(k in entries)) entryOrder.push(k);
            entries[k] = {value:v, line:lineNo, rawKey:m[1]};
            return;
          }
          // YAML pair: key: value
          m = trimmed.match(/^(?:-\s*)?([A-Za-z_][A-Za-z0-9_.-]*)\s*:\s+(\S.*)$/);
          if (m){
            composeSignals++;
            var k2 = m[1].toUpperCase();
            var v2 = unquote(m[2]);
            if (k2 === "PORTS" || k2 === "VOLUMES") return;
            if (!(k2 in entries)) entryOrder.push(k2);
            entries[k2] = {value:v2, line:lineNo, rawKey:m[1]};
            return;
          }
          // YAML bare key or service name: "services:", "uptime-kuma:", "environment:"
          if (/^(?:-\s*)?[A-Za-z0-9_][A-Za-z0-9_.-]*:\s*$/.test(trimmed)){
            composeSignals++;
            return;
          }
          // Any other list item (volume strings, port strings with extra text, etc.)
          if (/^-\s+\S/.test(trimmed)){
            var pm2 = trimmed.match(/(?:(\d{1,3}(?:\.\d{1,3}){3}):)?(\d{1,5}):(\d{1,5})/);
            if (pm2 && /port/i.test(rawLines.slice(Math.max(0,idx-6),idx).join(" "))) {
              portMappings.push({line:lineNo, ip:pm2[1]||null, hostPort:pm2[2], containerPort:pm2[3]});
            }
            return;
          }
          // Nothing matched — never guess.
          notParsedCount++;
          add("NOT PARSED", lineNo, null, "parse",
            "This line could not be read as a setting, a list item, or a comment, so it was not graded. Nothing about it was guessed.",
            "Rewrite the line as KEY=value, a YAML key: value pair, or a comment starting with # — then re-run the audit.");
        });

        // Notes can also live in key names.
        Object.keys(entries).forEach(function(k){
          if (/TLS|SSL|CERT|PROXY/.test(k)) tlsNote = true;
        });

        function has(k){ return k in entries; }

        // ---- HOST / bind posture ----
        var allInterfaceLines = [];
        var hostEntry = entries["HOST"];
        if (hostEntry){
          var hv = hostEntry.value.trim();
          if (hv === "0.0.0.0" || hv === "::" || hv === "*" || hv === ""){
            allInterfaceLines.push(hostEntry.line);
          } else if (hv === "127.0.0.1" || hv === "localhost" || hv === "::1"){
            add("PASS", hostEntry.line, "HOST", "bind",
              "HOST binds the dashboard to localhost (" + hv + ") — it is not reachable from other machines unless a proxy in front of it says so.",
              "No change needed for this setting.");
          } else {
            add("PASS", hostEntry.line, "HOST", "bind",
              "HOST is set to a specific address (" + hv + ") rather than all interfaces.",
              "No change needed for this setting — just confirm that address is the one you mean to expose.");
          }
        } else {
          allInterfaceLines.push(null);
        }
        portMappings.forEach(function(p){
          if (!p.ip || p.ip === "0.0.0.0") allInterfaceLines.push(p.line);
          else if (p.ip === "127.0.0.1"){
            add("PASS", p.line, "ports", "bind",
              "The published port " + p.hostPort + ":" + p.containerPort + " is bound to 127.0.0.1 only.",
              "No change needed for this mapping.");
          }
        });
        if (allInterfaceLines.length){
          var firstLine = null;
          for (var i=0;i<allInterfaceLines.length;i++){ if (allInterfaceLines[i] != null){ firstLine = allInterfaceLines[i]; break; } }
          var where = hostEntry ? "HOST" : "ports/HOST";
          if (tlsNote){
            add("WARNING", firstLine, where, "bind",
              "The dashboard listens on all network interfaces" + (hostEntry ? "" : " (HOST is not set, so it inherits the all-interfaces default)") + ". A TLS / reverse-proxy note is present, which lowers the risk — but anything that can reach the port can reach the login page if the proxy is ever bypassed.",
              "Bind to 127.0.0.1 and let the reverse proxy be the only public door, or firewall the port to the proxy only.");
          } else {
            add("BLOCKER", firstLine, where, "bind",
              "The dashboard listens on all network interfaces" + (hostEntry ? " (HOST is 0.0.0.0 or unset)" : " (HOST is not set, so it inherits the all-interfaces default)") + ", and nothing in the paste mentions TLS or a reverse proxy. Anyone who can reach this machine can reach the dashboard login over plain HTTP.",
              "Set HOST=127.0.0.1 and put a reverse proxy with HTTPS/TLS in front, or set HOST to a private address only — and note the proxy/TLS arrangement in the config.");
          }
        }
        if (tlsNote){
          add("PASS", null, null, "tls",
            "A TLS / reverse-proxy note is present in the paste, so the encrypted front door is accounted for.",
            "No change needed — keep the note with the config so the next reader knows where HTTPS ends.");
        }

        // ---- PORT posture ----
        var portEntry = entries["PORT"];
        if (portEntry){
          var pv = portEntry.value.trim();
          if (!/^\d+$/.test(pv)){
            add("BLOCKER", portEntry.line, "PORT", "port",
              "PORT is set to a value that is not a number (length " + pv.length + " characters), so the server may not start on the port you expect.",
              "Set PORT to a plain number, for example PORT=3001.");
          } else {
            var pn = parseInt(pv,10);
            if (pn < 1 || pn > 65535){
              add("BLOCKER", portEntry.line, "PORT", "port",
                "PORT=" + pn + " is outside the valid 1–65535 range.",
                "Set PORT to a valid number, for example PORT=3001.");
            } else if (pn < 1024){
              add("WARNING", portEntry.line, "PORT", "port",
                "PORT=" + pn + " is a privileged port (below 1024). The server may need elevated rights to bind it, and it invites scanning.",
                "Prefer an unprivileged port such as 3001 and let the reverse proxy own 80/443.");
            } else {
              add("PASS", portEntry.line, "PORT", "port",
                "PORT is set on purpose to " + pn + ".",
                "No change needed for this setting.");
            }
          }
        } else if (!portMappings.length){
          add("WARNING", null, "PORT", "port",
            "PORT is not set anywhere in the paste. The server will fall back to its built-in default (3001) — fine only if that is what you meant.",
            "Set PORT explicitly, for example PORT=3001, so the deployment says what it does.");
        }

        // ---- Secrets in URLs + short/placeholder secrets (values never printed) ----
        entryOrder.forEach(function(k){
          var e = entries[k];
          var val = e.value;

          // URLs with embedded credentials or token parameters.
          if (/:\/\//.test(val)){
            var um = val.match(/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\/([^\/\s:@]+):([^@\s]+)@/);
            if (um){
              add("BLOCKER", e.line, k, "url-secret",
                "The URL in " + k + " carries an embedded password in the address itself (credential length " + um[2].length + " characters). The value is never printed by this tool. Anyone who can read this config — or any log the URL lands in — has the credential.",
                "Remove the password from the URL in " + k + " and supply it through a secret store or a separate protected setting; rotate the credential, since it has been sitting in plain text.");
            }
            var q = val.split("?")[1];
            if (q){
              q.split("&").forEach(function(pair){
                var kv = pair.split("=");
                if (kv.length >= 2 && TOKEN_PARAMS.indexOf(kv[0].toLowerCase()) !== -1){
                  var tokVal = kv.slice(1).join("=");
                  try { tokVal = decodeURIComponent(tokVal); } catch(_){}
                  if (tokVal.length){
                    add("BLOCKER", e.line, k, "url-secret",
                      "The URL in " + k + " carries an embedded token in its \"" + kv[0] + "\" parameter (value length " + tokVal.length + " characters). The token itself is never printed by this tool. URLs get logged, cached, and copied — the token travels with all of them.",
                      "Move the token out of the URL in " + k + " (use a header or a secret store instead) and rotate the token, since it has been sitting in plain text.");
                  }
                }
              });
            }
          }

          // Short / placeholder secrets in secret-looking keys.
          if (SECRET_KEY_RE.test(k) || /WEBHOOK|NOTIF/i.test(k) && /token/i.test(k)){
            if (/:\/\//.test(val)) return; // URL values are handled above, not length-graded as secrets.
            var lv = val.trim().toLowerCase();
            if (PLACEHOLDERS.indexOf(lv) !== -1 || /changeme|your[-_ ]|example|placeholder/.test(lv)){
              add("BLOCKER", e.line, k, "secret",
                k + " is set to a placeholder or well-known default value (length " + val.length + " characters). The value is never printed by this tool. Placeholder credentials are the first thing an attacker tries.",
                "Set " + k + " to a long, unique value (16+ characters) that appears nowhere else, and store it in a secret store rather than the config file.");
            } else if (val.length < 12){
              add("BLOCKER", e.line, k, "secret",
                k + " is short — " + val.length + " characters. The value is never printed by this tool. Short secrets fall to guessing and brute force, and an admin credential guards every monitor and notification channel behind it.",
                "Lengthen " + k + " to at least 16 characters, unique to this deployment.");
            } else if (val.length < 16){
              add("WARNING", e.line, k, "secret",
                k + " is " + val.length + " characters — past the minimum, but 16+ is the safer bar for a credential that guards the whole dashboard. The value is never printed by this tool.",
                "Consider lengthening " + k + " to 16+ characters.");
            }
          }
        });

        // ---- Demo / guest / disabled auth ----
        entryOrder.forEach(function(k){
          var e = entries[k];
          if (/DEMO/.test(k) && isTruthy(e.value)){
            add("BLOCKER", e.line, k, "access",
              k + " turns demo access on. A demo dashboard shows your monitors and status history to anyone who can reach the page — that is your infrastructure, published.",
              "Turn demo mode off (" + k + "=false) for any real deployment.");
          }
          if (/(GUEST|ANON)/.test(k) && isTruthy(e.value)){
            add("BLOCKER", e.line, k, "access",
              k + " allows guest / anonymous access. Unauthenticated viewers can see monitor names, uptime, and incident history.",
              "Disable guest access (" + k + "=false) unless this dashboard is deliberately public.");
          }
          if (/(DISABLE_AUTH|AUTH_DISABLED|NO_AUTH)/.test(k) && isTruthy(e.value)){
            add("BLOCKER", e.line, k, "access",
              k + " disables authentication entirely. The dashboard — including settings and notification channels — is open to anyone who can reach it.",
              "Re-enable authentication (" + k + "=false) before this faces any network.");
          }
        });

        // ---- Security headers ----
        var headersBlocked = false;
        entryOrder.forEach(function(k){
          var e = entries[k];
          if (/DISABLE.*HEADER|HEADERS.*DISABLED/.test(k) && isTruthy(e.value)){
            headersBlocked = true;
            add("BLOCKER", e.line, k, "headers",
              k + " switches security headers off. Without them the dashboard is easier to frame, sniff, and script against in a browser.",
              "Remove " + k + " or set it to false so the security headers stay on.");
          }
          if (/ENABLE.*HEADER|SECURITY_HEADERS/.test(k) && isFalsy(e.value)){
            headersBlocked = true;
            add("BLOCKER", e.line, k, "headers",
              k + " is set to off, which disables the security headers that protect the dashboard in the browser.",
              "Set " + k + "=true so the security headers stay on.");
          }
        });
        if (!headersBlocked){
          var headersOn = entryOrder.some(function(k){ return /ENABLE.*HEADER|SECURITY_HEADERS/.test(k) && isTruthy(entries[k].value); });
          if (headersOn || headersNote){
            add("PASS", null, null, "headers",
              "Security headers are accounted for (enabled in the settings or noted in the config).",
              "No change needed for this item.");
          } else {
            add("WARNING", null, null, "headers",
              "Nothing in the paste confirms the security headers are on. They are a quiet default that a stray setting or proxy can strip without anyone noticing.",
              "Confirm the security headers are enabled and add a short note to the config saying so.");
          }
        }

        // ---- Persistence / data dir ----
        var dataEntry = entries["DATA_DIR"] || entries["UPTIME_KUMA_DATA_DIR"] || entries["DATA_PATH"];
        if (dataEntry){
          if (/^\/tmp\b|^tmpfs|^\.\/tmp/.test(dataEntry.value.trim()) || dataEphemeral && dataEntry.line === dataLine){
            add("WARNING", dataEntry.line, "DATA_DIR", "persistence",
              "The data directory points at a temporary location (" + dataEntry.value.trim() + "). Everything in it — monitors, history, settings — disappears when the machine or container cleans up.",
              "Point the data directory at a persistent volume, for example ./data:/app/data, and keep it out of /tmp.");
          } else {
            add("PASS", dataEntry.line, "DATA_DIR", "persistence",
              "A data directory is set (" + dataEntry.value.trim() + "), so monitors and history have a home that survives restarts.",
              "No change needed for this setting.");
          }
        } else if (hasDataVolume){
          if (dataEphemeral){
            add("WARNING", dataLine, "volumes", "persistence",
              "The /app/data volume is backed by a temporary location, so the data will not survive a cleanup or reboot.",
              "Back the /app/data volume with a real persistent directory or named volume.");
          } else {
            add("PASS", dataLine, "volumes", "persistence",
              "A persistent volume is mounted at /app/data, so monitors and history survive container recreation.",
              "No change needed for this mount.");
          }
        } else {
          add("WARNING", null, "DATA_DIR", "persistence",
            "No data directory and no /app/data volume appear in the paste. Without one, monitors, settings, and history live inside the container and are lost when it is recreated.",
            "Add a persistent data directory or volume, for example ./data:/app/data, before deploying.");
        }

        // ---- Backup note ----
        if (backupNote){
          add("PASS", null, null, "backup",
            "A backup note for the data volume is present in the paste.",
            "No change needed — keep the note next to the config and test a restore now and then.");
        } else {
          add("WARNING", null, null, "backup",
            "Nothing in the paste mentions a backup for the data volume. Uptime Kuma's data is the whole product — monitors, history, and notification settings — and a disk failure takes all of it at once.",
            "Add a backup for the data volume (a scheduled copy off the box) and note it in the config.");
        }

        // ---- Verdict ----
        var blockers = findings.filter(function(f){return f.severity==="BLOCKER";}).length;
        var warnings = findings.filter(function(f){return f.severity==="WARNING";}).length;
        var verdict = blockers ? "DO NOT DEPLOY" : (warnings || notParsedCount) ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY";
        var format = composeSignals > envSignals ? "docker-compose YAML" : envSignals ? ".env / environment list" : "mixed / plain lines";

        var rank = {"BLOCKER":0,"WARNING":1,"NOT PARSED":2,"PASS":3};
        findings.sort(function(a,b){
          if (rank[a.severity] !== rank[b.severity]) return rank[a.severity]-rank[b.severity];
          var la = a.line==null?9999:a.line, lb = b.line==null?9999:b.line;
          return la-lb;
        });

        var fixes = [];
        findings.forEach(function(f){
          if (f.severity === "PASS") return;
          if (fixes.indexOf(f.fix) === -1) fixes.push(f.fix);
        });

        return {verdict:verdict, format:format, linesChecked:rawLines.length,
          counts:{blockers:blockers, warnings:warnings, notParsed:notParsedCount,
            passes:findings.filter(function(f){return f.severity==="PASS";}).length},
          findings:findings, fixes:fixes};
      }

      function buildReport(r){
        if (r.verdict === "NOT ENOUGH TO GRADE"){
          return "J-Dawgs Uptime Kuma Server Config Safety Auditor™ — Audit Report\nVerdict: NOT ENOUGH TO GRADE\n\nNo configuration was pasted, so there is nothing to grade. Paste environment variables, a docker-compose snippet, or .env-style lines and run the audit again.";
        }
        var out = [];
        out.push("J-Dawgs Uptime Kuma Server Config Safety Auditor™ — Audit Report");
        out.push("Verdict: " + r.verdict);
        out.push("Format detected: " + r.format);
        out.push("Lines checked: " + r.linesChecked + " · Blockers: " + r.counts.blockers + " · Warnings: " + r.counts.warnings + " · Not parsed: " + r.counts.notParsed + " · Passes: " + r.counts.passes);
        out.push("");
        out.push("FINDINGS");
        r.findings.forEach(function(f){
          out.push("[" + f.severity + "] " + (f.line != null ? "Line " + f.line : "Whole config") + (f.key ? " — " + f.key : "") + ": " + f.message);
        });
        out.push("");
        out.push("FIX LIST");
        if (r.fixes.length){
          r.fixes.forEach(function(fx,i){ out.push((i+1) + ". " + fx); });
        } else {
          out.push("Nothing to fix. Every check passed.");
        }
        out.push("");
        out.push("Note: secret and token values are never printed by this tool — findings name the setting, its line, and the value's length only.");
        return out.join("\n");
      }

      function buildJson(r){
        var obj = {
          tool: "J-Dawgs Uptime Kuma Server Config Safety Auditor™",
          verdict: r.verdict,
          formatDetected: r.format,
          linesChecked: r.linesChecked,
          counts: r.counts || {blockers:0,warnings:0,notParsed:0,passes:0},
          findings: r.findings.map(function(f){
            return {severity:f.severity, line:f.line, key:f.key, check:f.check, message:f.message, fix:f.fix};
          }),
          fixes: r.fixes
        };
        return JSON.stringify(obj, null, 2);
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-uptime-kuma-server-config-safety-auditortm',
  name: 'J-Dawgs Uptime Kuma Server Config Safety Auditor',
  description: 'Uptime Kuma\'s own checks only answer whether the server starts on the host; ours grades a pasted Uptime Kuma server config/environment fully offline — port and hostname exposure, TLS posture, demo and privacy settings, tokens shown by key name/line/length only — into one deploy verdict: SAFE TO DEPL',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
