'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs LiveKit Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

  "use strict";

  var WELL_KNOWN_KEYS = ["devkey","dev","test","testkey","example","demo","default","changeme","secret","livekit","apikey","mykey","key","password"];
  var LIVEKIT_TOP = ["port","bind_addresses","development","keys","rtc","turn","redis","logging","room","webhook","tls","video","audio","ingress","egress","node_ip","prometheus","debug"];

  function $(id){ return document.getElementById(id); }

  function stripQuotes(v){
    v = v.trim();
    if(v.length >= 2 && ((v.charAt(0)==='"' && v.charAt(v.length-1)==='"') || (v.charAt(0)==="'" && v.charAt(v.length-1)==="'"))){
      return v.slice(1,-1);
    }
    return v;
  }
  function cleanValue(v){
    v = v.trim();
    if(v.charAt(0)==='"' || v.charAt(0)==="'"){
      var q = v.charAt(0), end = v.indexOf(q,1);
      if(end > 0) return v.slice(1,end);
      return stripQuotes(v);
    }
    var hash = v.indexOf(" #");
    if(hash >= 0) v = v.slice(0,hash);
    return v.trim();
  }
  function isExternalRef(v){ return /^\$\{[^}]+\}$/.test(v) || /^\$[A-Za-z_][A-Za-z0-9_]*$/.test(v) || /^env:/i.test(v) || /^<.*>$/.test(v); }
  function isTrue(v){ return /^(true|yes|on)$/i.test(v); }
  function isFalse(v){ return /^(false|no|off)$/i.test(v); }

  // Line-based heuristic YAML reader. Returns entries with section paths,
  // plus a list of lines it could not parse. Secret values are carried only
  // inside this function scope and are never copied into findings.
  function parseConfig(text){
    var rawLines = text.split(/\r?\n/);
    var entries = [];
    var bad = [];
    var stack = []; // {indent, key}
    var blockScalarIndent = -1;

    function pathFor(indent){
      while(stack.length && stack[stack.length-1].indent >= indent) stack.pop();
      return stack.map(function(s){ return s.key; });
    }

    for(var i=0;i<rawLines.length;i++){
      var raw = rawLines[i];
      var lineNo = i+1;
      if(/^\s*$/.test(raw)) continue;
      if(/^\s*#/.test(raw)) continue;
      if(/^\s*(---|\.\.\.)\s*$/.test(raw)) continue;
      var leadWS = raw.match(/^\s*/)[0];
      if(blockScalarIndent >= 0){
        if(leadWS.length > blockScalarIndent) continue;
        blockScalarIndent = -1;
      }
      if(leadWS.indexOf("\t") >= 0){
        bad.push({line:lineNo, reason:"Tab character used for indentation — YAML requires spaces, so this line's place in the structure can't be trusted."});
        continue;
      }
      var indent = leadWS.length;
      var trimmed = raw.trim();

      if(trimmed === "-" || trimmed.indexOf("- ") === 0){
        var itemVal = trimmed === "-" ? "" : cleanValue(trimmed.slice(2));
        var p = pathFor(indent);
        entries.push({line:lineNo, indent:indent, key:"(list item)", rawValue:itemVal, path:p.slice(), listItem:true});
        continue;
      }

      var m = trimmed.match(/^(['"]?)([A-Za-z0-9_.\-\/]+)\1\s*:\s*(.*)$/);
      if(!m){
        bad.push({line:lineNo, reason:"This line is not a YAML key: value line, a list item, or a comment, so its meaning can't be read."});
        continue;
      }
      var key = m[2];
      var value = cleanValue(m[3] || "");
      var path = pathFor(indent);
      entries.push({line:lineNo, indent:indent, key:key, rawValue:value, path:path.slice(), listItem:false});
      if(value === "" || value === "|" || value === ">" || value === "|-" || value === ">" ){
        stack.push({indent:indent, key:key});
        if(value.charAt(0) === "|" || value.charAt(0) === ">") blockScalarIndent = indent;
      }
    }
    return {entries:entries, bad:bad, totalLines:rawLines.length};
  }

  function findAll(entries, pred){ return entries.filter(pred); }
  function topKey(e, name){ return e.path.length === 0 && e.key === name && !e.listItem; }
  function inSection(e, name){ return e.path.length > 0 && e.path[0] === name && !e.listItem; }

  function audit(text){
    var findings = [];
    function add(sev, line, check, title, detail, fix){
      findings.push({severity:sev, line:(typeof line === "number" ? line : null), check:check, title:title, detail:detail, fix:fix});
    }

    if(!text || !text.trim()){
      return {verdict:"NOT ENOUGH TO GRADE", reason:"The paste is empty — there is no config to grade.", findings:findings};
    }
    if(/^\s*[[{]/.test(text)){
      return {verdict:"NOT ENOUGH TO GRADE", reason:"This paste starts like JSON, not YAML. LiveKit reads livekit.yaml as YAML — paste the YAML text of the config instead.", findings:findings};
    }

    var parsed = parseConfig(text);

    if(parsed.bad.length){
      parsed.bad.forEach(function(b){
        add("NOT PARSED", b.line, "parse", "Line " + b.line + " — NOT PARSED", b.reason + " The line's content is not echoed here, in case it holds a secret.", "Fix the line so it is a plain YAML key: value line, a list item, or a comment, then paste the config again.");
      });
      return {verdict:"NOT ENOUGH TO GRADE", reason:parsed.bad.length + " line(s) could not be parsed, so the config was not graded — this tool never guesses past a line it can't read.", findings:findings};
    }

    var entries = parsed.entries;
    var tops = {};
    entries.forEach(function(e){ if(e.path.length === 0 && !e.listItem) tops[e.key] = true; });
    var recognized = LIVEKIT_TOP.some(function(k){ return tops[k]; });
    if(!recognized || entries.length === 0){
      return {verdict:"NOT ENOUGH TO GRADE", reason:"No recognizable LiveKit settings were found in this paste (looked for top-level keys such as port, keys, rtc, turn, redis, logging, room). This doesn't look like a livekit.yaml — nothing was graded.", findings:findings};
    }

    var i, e, v;

    // ---- development mode ----
    var devEntries = findAll(entries, function(x){ return topKey(x,"development"); });
    if(devEntries.length){
      e = devEntries[0];
      if(isTrue(e.rawValue)){
        add("BLOCKER", e.line, "development", "Development mode is ON", "development: true is stated at line " + e.line + ". Dev mode is for a laptop, not a deploy: it relaxes token and origin checks that production relies on.", "Set development: false (or remove the line) in any config that real clients will connect to.");
      } else {
        add("INFO", e.line, "development", "Development mode stated OFF", "development is stated as \"" + e.rawValue + "\" at line " + e.line + " — the production posture.", "No change needed.");
      }
    } else {
      add("INFO", null, "development", "Development mode NOT STATED", "No development: line appears in the paste. LiveKit's default is off, but an unstated posture is one copied line away from changing.", "State development: false explicitly so the posture survives copy-paste.");
    }

    // ---- API keys ----
    var keysHeader = findAll(entries, function(x){ return topKey(x,"keys"); });
    var keyEntries = findAll(entries, function(x){ return inSection(x,"keys"); });
    if(!keysHeader.length){
      add("HIGH", null, "keys", "No keys: section in this paste", "No API key/secret pairs are stated. Keys can also be supplied at launch (flags or environment), so this may be covered outside the file — but nothing in the paste proves it, and token generation fails without at least one pair.", "Either add a keys: section with a non-example key name and a secret of 32+ characters, or document where the keys are injected at launch.");
    } else if(!keyEntries.length){
      add("HIGH", keysHeader[0].line, "keys", "keys: section is empty", "The keys: section at line " + keysHeader[0].line + " names no key/secret pairs, so token generation has nothing to sign with.", "Add at least one pair: a key name that isn't an example name, with a secret of 32+ characters.");
    }
    keyEntries.forEach(function(k){
      var name = k.key;
      var secretVal = k.rawValue;
      var lower = name.toLowerCase();
      var wellKnown = WELL_KNOWN_KEYS.indexOf(lower) >= 0 || lower.indexOf("example") >= 0 || lower.indexOf("devkey") >= 0 || lower.indexOf("changeme") >= 0 || lower.indexOf("testkey") >= 0;
      if(isExternalRef(secretVal)){
        add("INFO", k.line, "keys", "Key \"" + name + "\" uses an external secret reference", "Key \"" + name + "\" at line " + k.line + " points at an external reference instead of a pasted secret — the secret itself stays out of the file.", "Make sure the reference resolves in the deploy environment before launch.");
        if(wellKnown){
          add("HIGH", k.line, "keys", "Key name \"" + name + "\" is an obvious example name", "Even with the secret held elsewhere, the key name at line " + k.line + " is a well-known example name that appears in public docs and tutorials.", "Rename the key to something deployment-specific that doesn't appear in any example.");
        }
        return;
      }
      var len = secretVal.length;
      if(wellKnown && len < 32){
        add("BLOCKER", k.line, "keys", "Example key \"" + name + "\" with a short secret", "Key \"" + name + "\" at line " + k.line + " is a well-known example key name, and its secret is " + len + " characters long (reported by length only — the value is never shown). Anyone who has read the public examples can try this pair.", "Generate a fresh pair: a key name that appears in no example, and a random secret of at least 32 characters. Rotate anywhere the old pair was used.");
      } else if(wellKnown){
        add("BLOCKER", k.line, "keys", "Key name \"" + name + "\" is an obvious example name", "The key name at line " + k.line + " appears in public LiveKit examples and tutorials. Its secret is " + len + " characters (length only), but a guessed key name halves what an attacker has to brute-force.", "Rename the key to something deployment-specific that doesn't appear in any example or doc.");
      } else if(len < 32){
        add("HIGH", k.line, "keys", "Secret for key \"" + name + "\" is short — " + len + " characters", "The secret for key \"" + name + "\" at line " + k.line + " is " + len + " characters long (length only — the value is never shown). Short secrets are guessable and brute-forceable.", "Replace it with a random secret of at least 32 characters and rotate it anywhere the short one was used.");
      } else {
        add("INFO", k.line, "keys", "Key \"" + name + "\" — secret length OK", "Key \"" + name + "\" at line " + k.line + " is not an example name and its secret is " + len + " characters (length only). Length is all this check can see — it can't judge randomness.", "Keep the secret out of source control even so; prefer an external reference or launch-time injection.");
      }
    });

    // ---- bind addresses & ports ----
    var bindHeader = findAll(entries, function(x){ return topKey(x,"bind_addresses"); });
    var bindItems = findAll(entries, function(x){ return x.listItem && x.path[0] === "bind_addresses"; });
    var bindValues = [];
    if(bindHeader.length && bindHeader[0].rawValue){
      var inline = bindHeader[0].rawValue.replace(/^\[|\]$/g,"");
      inline.split(",").forEach(function(s){ s = stripQuotes(s.trim()); if(s) bindValues.push({value:s, line:bindHeader[0].line}); });
    }
    bindItems.forEach(function(b){ bindValues.push({value:stripQuotes(b.rawValue), line:b.line}); });
    var allIface = bindValues.filter(function(b){ return b.value === "0.0.0.0" || b.value === "::" || b.value === ""; });
    if(allIface.length){
      allIface.forEach(function(b){
        add("HIGH", b.line, "bind", "Bound to all interfaces (" + (b.value || "empty entry") + ")", "bind_addresses at line " + b.line + " listens on every network interface — the HTTP/WebSocket port and the RTC ports answer on public and private networks alike, whether or not that was intended.", "Bind to the specific interface address(es) clients and peers actually use, and let the firewall — not hope — decide what else can reach the ports.");
      });
    } else if(bindValues.length){
      add("INFO", bindValues[0].line, "bind", "Bound to named interface address(es)", "bind_addresses names specific address(es) starting at line " + bindValues[0].line + " — a stated, deliberate network posture.", "Confirm the named address(es) match the interfaces clients and peers really arrive on.");
    } else {
      add("WARNING", null, "bind", "Bind posture NOT STATED", "No bind_addresses appear in the paste. With nothing stated, the server listens wherever its defaults put it — on every interface — and the paste gives a reviewer no posture to approve.", "State bind_addresses explicitly, even if the deliberate choice is all interfaces behind a firewall.");
    }

    var portEntry = findAll(entries, function(x){ return topKey(x,"port"); })[0];
    if(portEntry){
      add("INFO", portEntry.line, "bind", "HTTP/WebSocket port stated: " + portEntry.rawValue, "The signaling port is stated as " + portEntry.rawValue + " at line " + portEntry.line + " (7880 is the LiveKit default). Clients and any reverse proxy must agree on it.", "No change needed if your proxy and firewall rules use this same port.");
    }
    var rtcRangeStart = findAll(entries, function(x){ return inSection(x,"rtc") && x.key === "port_range_start"; })[0];
    var rtcRangeEnd = findAll(entries, function(x){ return inSection(x,"rtc") && x.key === "port_range_end"; })[0];
    if(rtcRangeStart && rtcRangeEnd){
      var s = parseInt(rtcRangeStart.rawValue,10), en = parseInt(rtcRangeEnd.rawValue,10);
      if(!isNaN(s) && !isNaN(en) && en >= s){
        add("INFO", rtcRangeStart.line, "bind", "RTC UDP port range stated: " + s + "–" + en + " (" + (en - s + 1) + " ports)", "The media port range is stated at lines " + rtcRangeStart.line + "–" + rtcRangeEnd.line + ". Every port in it has to be open in the firewall for media to flow.", "Open exactly this UDP range in the firewall — no wider, no narrower.");
      }
    }

    // ---- TURN ----
    var rtcPresent = !!findAll(entries, function(x){ return topKey(x,"rtc"); }).length;
    var turnHeader = findAll(entries, function(x){ return topKey(x,"turn"); })[0];
    var turnEnabled = findAll(entries, function(x){ return inSection(x,"turn") && x.key === "enabled"; })[0];
    var externalImplied = rtcPresent || !!portEntry || findAll(entries, function(x){ return inSection(x,"rtc") && x.key === "use_external_ip"; }).length > 0;
    if(!turnHeader){
      add("WARNING", null, "turn", "TURN posture NOT STATED", "No turn: section appears in the paste. Without a TURN relay, clients behind strict NATs and corporate firewalls commonly fail to connect media even when signaling works.", "If any client connects from outside your own network, configure TURN (or LiveKit's embedded TURN) and state it here.");
    } else if(turnEnabled && isFalse(turnEnabled.rawValue)){
      if(externalImplied){
        add("HIGH", turnEnabled.line, "turn", "TURN is disabled while outside clients are implied", "turn.enabled is false at line " + turnEnabled.line + ", but the rest of the config (signaling port / rtc section) is built for clients connecting in — clients behind strict NATs or firewalls will reach signaling and then fail media with no relay to fall back on.", "Enable TURN and give it a reachable domain and ports, or document the private-network-only posture where a reviewer will find it.");
      } else {
        add("WARNING", turnEnabled.line, "turn", "TURN is disabled", "turn.enabled is false at line " + turnEnabled.line + ". That's a defensible posture for a private-network-only deploy — but the paste itself doesn't say that's the intent.", "If every client is on your own network, note that next to the setting. Otherwise enable TURN.");
      }
    } else if(turnEnabled && isTrue(turnEnabled.rawValue)){
      add("INFO", turnEnabled.line, "turn", "TURN stated enabled", "turn.enabled is true at line " + turnEnabled.line + " — a relay path exists for clients behind strict NATs.", "Confirm the TURN domain resolves publicly and its ports are open; this audit can't test reachability.");
      var credKeys = findAll(entries, function(x){ return inSection(x,"turn") && (x.key === "password" || x.key === "username" || x.key === "credential" || x.key === "user"); });
      credKeys.forEach(function(c){
        if(c.key === "password" && !isExternalRef(c.rawValue)){
          add("WARNING", c.line, "turn", "Plaintext TURN credential in the paste", "A TURN password sits in plaintext at line " + c.line + " (key name \"password\", value length " + c.rawValue.length + " — the value is never shown). Anyone who reads this file holds the relay credential.", "Move the coturn credential into a secret store or an external reference, and rotate the one that was pasted.");
        } else if(c.key !== "password"){
          add("WARNING", c.line, "turn", "TURN credential material in the paste", "A TURN \"" + c.key + "\" is stated in plaintext at line " + c.line + ". Credential material for the relay belongs outside the config file.", "Move TURN credentials to the coturn secret store or external references so the config alone grants nothing.");
        }
      });
      var turnDomain = findAll(entries, function(x){ return inSection(x,"turn") && x.key === "domain"; })[0];
      if(!turnDomain){
        add("INFO", null, "turn", "TURN domain NOT STATED", "TURN is enabled but no turn.domain is stated in the paste — clients need a reachable name for the relay.", "State turn.domain so reviewers can confirm it's the public name clients will use.");
      }
    } else if(turnHeader){
      add("INFO", turnHeader.line, "turn", "turn: section present, enabled NOT STATED", "A turn: section starts at line " + turnHeader.line + " but no enabled: line is stated inside it.", "State turn.enabled explicitly so the relay posture is reviewable.");
    }

    // ---- TLS & webhooks ----
    var tlsKeys = findAll(entries, function(x){ return !x.listItem && (x.key === "cert_file" || x.key === "key_file" || x.key === "tls" || x.key === "tls_port"); });
    var webhookUrls = findAll(entries, function(x){ return x.listItem && x.path[0] === "webhook"; });
    var webhookUrlKey = findAll(entries, function(x){ return inSection(x,"webhook") && (x.key === "urls" || x.key === "url"); });
    var hasHttps = false, httpLines = [];
    webhookUrls.forEach(function(u){
      if(/^https:\/\//i.test(u.rawValue)) hasHttps = true;
      else if(/^http:\/\//i.test(u.rawValue)) httpLines.push(u.line);
    });
    webhookUrlKey.forEach(function(u){
      if(u.rawValue){
        if(/^https:\/\//i.test(u.rawValue)) hasHttps = true;
        else if(/^http:\/\//i.test(u.rawValue)) httpLines.push(u.line);
      }
    });
    httpLines.forEach(function(ln){
      add("HIGH", ln, "tls", "Webhook URL uses plaintext http", "The webhook URL at line " + ln + " is http, not https. Webhook payloads carry room and participant events — over http they travel readable and forgeable.", "Point webhooks at an https endpoint.");
    });
    if(tlsKeys.length){
      var firstTls = tlsKeys[0];
      add("INFO", firstTls.line, "tls", "TLS material stated in the paste", "TLS-related settings (cert_file / key_file / tls_port) are stated, first at line " + firstTls.line + " — the config itself shows where TLS terminates.", "Confirm the referenced certificate files exist on the host and are in date; this audit can't open them.");
    }
    if(hasHttps){
      add("INFO", null, "tls", "Webhook URL(s) use https", "At least one webhook URL in the paste is https — webhook traffic is encrypted in transit.", "No change needed.");
    }
    if(!tlsKeys.length && !hasHttps && !httpLines.length){
      add("WARNING", null, "tls", "TLS posture NOT STATED", "Nothing in the paste states a TLS posture: no cert_file / key_file / tls settings and no https webhook URLs. TLS may well be terminated by a reverse proxy in front of LiveKit — but that lives outside this file, and the paste alone doesn't show it.", "Either state the TLS settings in the config, or note in the deploy runbook that TLS terminates at the proxy — and make webhook URLs https either way.");
    }

    // ---- Redis ----
    var redisHeader = findAll(entries, function(x){ return topKey(x,"redis"); })[0];
    if(!redisHeader){
      add("INFO", null, "redis", "Redis NOT STATED", "No redis: section appears in the paste. That's the normal posture for a single-node deploy; a multi-node cluster needs Redis stated.", "If this config will ever run as more than one node, add the redis: section before scaling out.");
    } else {
      var redisPw = findAll(entries, function(x){ return inSection(x,"redis") && x.key === "password"; })[0];
      if(redisPw){
        if(isExternalRef(redisPw.rawValue)){
          add("INFO", redisPw.line, "redis", "Redis password is an external reference", "The redis password at line " + redisPw.line + " is an external reference (key name \"password\" — no value in the file to leak).", "Make sure the reference resolves in the deploy environment before launch.");
        } else if(redisPw.rawValue === ""){
          add("WARNING", redisPw.line, "redis", "Redis password line is empty", "The redis password key at line " + redisPw.line + " states no value — Redis is effectively running without a password while looking configured.", "Set a real password via an external reference, or remove the empty line and treat Redis as unauthenticated (and network-isolated).");
        } else {
          add("HIGH", redisPw.line, "redis", "Redis password in plaintext", "The redis password sits in plaintext at line " + redisPw.line + " (key name \"password\", value length " + redisPw.rawValue.length + " — the value is never shown). Every copy of this file is a copy of the Redis credential.", "Move the Redis password to a secret store or an external reference like ${REDIS_PASSWORD}, and rotate the password that was pasted.");
        }
      } else {
        add("WARNING", redisHeader.line, "redis", "Redis section sets no password", "The redis: section starting at line " + redisHeader.line + " states no password. Anyone who can reach the Redis port owns the data plane LiveKit coordinates through.", "Set a Redis password (via an external reference) or prove Redis is reachable only from the LiveKit nodes — and write that proof in the runbook.");
      }
    }

    // ---- logging ----
    var logLevel = findAll(entries, function(x){ return inSection(x,"logging") && x.key === "level"; })[0];
    if(logLevel){
      var lv = logLevel.rawValue.toLowerCase();
      if(lv === "debug" || lv === "trace"){
        add("WARNING", logLevel.line, "logging", "Logging level is \"" + lv + "\"", "logging.level is stated as " + lv + " at line " + logLevel.line + ". Debug-grade logging in production means huge log volume, real cost, and participant detail you didn't mean to keep.", "Ship with level: info (warn if you run lean). Raise it temporarily while diagnosing, then put it back.");
      } else {
        add("INFO", logLevel.line, "logging", "Logging level stated: " + lv, "logging.level is stated as \"" + logLevel.rawValue + "\" at line " + logLevel.line + " — a production-sane level.", "No change needed.");
      }
    } else {
      add("INFO", null, "logging", "Logging level NOT STATED", "No logging.level appears in the paste; LiveKit's default applies. An unstated level is one less thing a reviewer can sign off.", "State logging.level explicitly (info is the usual production choice).");
    }

    // ---- rtc external IP posture ----
    var useExtIp = findAll(entries, function(x){ return inSection(x,"rtc") && x.key === "use_external_ip"; })[0];
    if(useExtIp){
      add("INFO", useExtIp.line, "rtc", "rtc.use_external_ip stated as " + useExtIp.rawValue, "use_external_ip is quoted exactly as stated at line " + useExtIp.line + ": \"" + useExtIp.rawValue + "\". " + (isTrue(useExtIp.rawValue) ? "Behind NAT, this is what lets the node advertise its public address." : "Off means the node advertises its local address — right for same-network clients, wrong for internet clients."), isTrue(useExtIp.rawValue) ? "No change needed for an internet-facing node." : "If any client connects over the internet, set use_external_ip: true (or state node_ip) — otherwise remote clients get an unreachable media address.");
    } else {
      add("INFO", null, "rtc", "rtc.use_external_ip NOT STATED", "The paste doesn't state use_external_ip, so a reviewer can't tell which address the node will advertise to clients.", "State rtc.use_external_ip explicitly for the network this node serves.");
    }
    var nodeIp = findAll(entries, function(x){ return (inSection(x,"rtc") && x.key === "node_ip") || topKey(x,"node_ip"); })[0];
    if(nodeIp){
      add("INFO", nodeIp.line, "rtc", "rtc.node_ip stated", "node_ip is stated at line " + nodeIp.line + " — the node advertises a fixed address to clients.", "Confirm that address is the one clients can actually route to.");
    } else {
      add("INFO", null, "rtc", "rtc.node_ip NOT STATED", "No node_ip is stated in the paste. That's fine when use_external_ip or plain local addressing does the job — but it is a posture a reviewer should see chosen, not absent.", "If this node sits behind NAT with a fixed public address, state rtc.node_ip; otherwise note why it's intentionally unset.");
    }

    // ---- room sanity (INFO) ----
    var roomHeader = findAll(entries, function(x){ return topKey(x,"room"); })[0];
    if(!roomHeader){
      add("INFO", null, "room", "Room settings NOT STATED", "No room: section appears in the paste, so empty-room timeouts and participant caps are whatever the defaults are.", "State room.empty_timeout and room.max_participants if your deploy depends on them.");
    } else {
      var et = findAll(entries, function(x){ return inSection(x,"room") && x.key === "empty_timeout"; })[0];
      if(et){
        var etv = parseInt(et.rawValue,10);
        var etNote = isNaN(etv) ? "The stated value isn't a plain number this heuristic check can sanity-read." :
          etv === 0 ? "0 means empty rooms are not timed out by this setting — idle rooms can linger and hold state." :
          etv < 60 ? "Under a minute: rooms will close almost immediately after the last participant leaves — confirm reconnects won't race the close." :
          "A sane-looking value: empty rooms close " + etv + " seconds after the last participant leaves.";
        add("INFO", et.line, "room", "room.empty_timeout stated: " + et.rawValue, etNote, "Confirm this matches the product behavior you want; INFO only — no severity, just a number worth a human's eyes.");
      }
      var mp = findAll(entries, function(x){ return inSection(x,"room") && x.key === "max_participants"; })[0];
      if(mp){
        var mpv = parseInt(mp.rawValue,10);
        var mpNote = isNaN(mpv) ? "The stated value isn't a plain number this heuristic check can sanity-read." :
          mpv === 0 ? "0 states no per-room participant cap — a single room can grow until the node runs out of resources." :
          "A stated cap of " + mpv + " participants per room — capacity planning can work with a number like this.";
        add("INFO", mp.line, "room", "room.max_participants stated: " + mp.rawValue, mpNote, "Confirm the cap matches your node sizing; INFO only — no severity, just a number worth a human's eyes.");
      }
      if(!et && !mp){
        add("INFO", roomHeader.line, "room", "Room section states neither timeout nor cap", "The room: section at line " + roomHeader.line + " states neither empty_timeout nor max_participants.", "State both numbers if your deploy depends on them; defaults otherwise apply.");
      }
    }

    // ---- verdict ----
    var sevRank = {"BLOCKER":0,"HIGH":1,"WARNING":2,"INFO":3,"NOT PARSED":4};
    findings.sort(function(a,b){
      var d = sevRank[a.severity] - sevRank[b.severity];
      if(d) return d;
      var la = a.line === null ? 9999 : a.line, lb = b.line === null ? 9999 : b.line;
      return la - lb;
    });
    var counts = {"BLOCKER":0,"HIGH":0,"WARNING":0,"INFO":0};
    findings.forEach(function(f){ if(counts.hasOwnProperty(f.severity)) counts[f.severity]++; });
    var verdict, reason;
    if(counts.BLOCKER > 0){ verdict = "DO NOT DEPLOY"; reason = counts.BLOCKER + " BLOCKER finding(s) must be fixed before this config goes anywhere near real clients."; }
    else if(counts.HIGH > 0 || counts.WARNING > 0){ verdict = "DEPLOY WITH FIXES"; reason = "No BLOCKERs, but " + (counts.HIGH + counts.WARNING) + " HIGH/WARNING finding(s) should be fixed — or consciously accepted — before deploy."; }
    else { verdict = "SAFE TO DEPLOY"; reason = "No BLOCKER, HIGH, or WARNING findings in the pasted text. INFO items are stated postures read back for a human's confirmation — and this verdict covers the paste, not the running server."; }
    return {verdict:verdict, reason:reason, findings:findings, counts:counts};
  }

  // ---- rendering ----
  var lastResult = null;
  var lastCounts = null;
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-livekit-server-config-safety-auditor',
  name: 'J-Dawgs LiveKit Server Config Safety Auditor',
  description: 'Grades a pasted LiveKit server config fully offline — API key posture, port and TURN exposure, and TLS all graded, with secrets shown by name, line, and length only — into one deploy verdict: SAFE TO DEPLOY / DEPLOY WITH FIXES / DO NOT DEPLOY.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
