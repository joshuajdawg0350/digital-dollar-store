'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Container Build Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

var BAD_EXAMPLE = [
"FROM node",
"",
"WORKDIR /app",
"ADD . /app",
"",
"ENV API_KEY=sk-fake-EXAMPLE-000000000000",
"",
"RUN curl -fsSL https://example.com/install.sh | sh",
"RUN npm install",
"",
"EXPOSE 22",
"",
"CMD npm start"
].join("\n");

var GOOD_EXAMPLE = [
"# Stage 1: build",
"FROM node:20.11.1-bookworm-slim AS build",
"WORKDIR /app",
"COPY package.json package-lock.json ./",
"RUN npm ci",
"COPY src ./src",
"RUN npm run build",
"",
"# Stage 2: runtime",
"FROM node:20.11.1-bookworm-slim",
"RUN apt-get update \\",
"    && apt-get install -y --no-install-recommends curl=7.88.1-10+deb12u5 \\",
"    && rm -rf /var/lib/apt/lists/*",
"WORKDIR /app",
"COPY --from=build /app/dist ./dist",
"COPY --from=build /app/node_modules ./node_modules",
"USER node",
"EXPOSE 3000",
"HEALTHCHECK --interval=30s --timeout=5s CMD curl -f http://localhost:3000/health || exit 1",
"CMD [\"node\", \"dist/index.js\"]"
].join("\n");

var SECRET_NAME = /(API_?KEY|ACCESS_?KEY|SECRET|PASSWORD|PASSWD|PWD|TOKEN|PRIVATE_?KEY|CREDENTIAL|AUTH_?KEY|CLIENT_?SECRET|SESSION_?KEY)/i;
var SENSITIVE_PORTS = {"22":1, "2375":1, "3389":1};

function maskValue(v){
  var clean = String(v == null ? "" : v).replace(/^["']|["']$/g, "");
  if (!clean) return "";
  if (clean.length <= 2) return "••";
  return clean.slice(0, 2) + "•••";
}

/* Join backslash continuations, drop blank/full-comment lines.
   Returns [{line, keyword, args, raw}] with 1-based start lines. */
function parseInstructions(text){
  var rawLines = String(text).replace(/\r\n?/g, "\n").split("\n");
  var logical = [];
  var buf = null, startLine = 0;
  for (var i = 0; i < rawLines.length; i++){
    var line = rawLines[i];
    if (buf === null){
      if (/^\s*$/.test(line) || /^\s*#/.test(line)) continue;
      buf = line; startLine = i + 1;
    } else {
      buf += "\n" + line;
    }
    if (/\\\s*$/.test(line)){
      buf = buf.replace(/\\\s*$/, "");
      continue;
    }
    logical.push({ line: startLine, text: buf });
    buf = null;
  }
  if (buf !== null) logical.push({ line: startLine, text: buf });
  var out = [];
  for (var j = 0; j < logical.length; j++){
    var m = logical[j].text.match(/^\s*([A-Za-z]+)\s*([\s\S]*)$/);
    if (!m) continue;
    out.push({ line: logical[j].line, keyword: m[1].toUpperCase(), args: (m[2] || "").trim(), raw: logical[j].text });
  }
  return out;
}

function splitTokens(s){
  var tokens = [], cur = "", inS = false, inD = false;
  for (var i = 0; i < s.length; i++){
    var c = s.charAt(i);
    if (c === "'" && !inD){ inS = !inS; cur += c; continue; }
    if (c === '"' && !inS){ inD = !inD; cur += c; continue; }
    if (!inS && !inD && /\s/.test(c)){ if (cur){ tokens.push(cur); cur = ""; } continue; }
    cur += c;
  }
  if (cur) tokens.push(cur);
  return tokens;
}

function copyText(t, noteEl){
  function done(){ if (noteEl){ noteEl.textContent = "Copied."; setTimeout(function(){ noteEl.textContent = ""; }, 2200); } }
  function fallback(){
    var ta = document.createElement("textarea");
    ta.value = t; ta.style.position = "fixed"; ta.style.opacity = "0";
    document.body.appendChild(ta); ta.select();
    try { document.execCommand("copy"); done(); } catch(e){}
    document.body.removeChild(ta);
  }
  if (navigator.clipboard && navigator.clipboard.writeText){
    navigator.clipboard.writeText(t).then(done, fallback);
  } else { fallback(); }
}

function audit(text){
  var findings = [];
  function add(sev, line, title, detail, fix){
    findings.push({ sev: sev, line: line, title: title, detail: detail, fix: fix });
  }

  var ins = parseInstructions(text);
  var stages = {};           // stage name (lowercase) -> true
  var fromCount = 0;
  var finalStageFromLine = 0;
  var finalStageUser = null; // {value, line}
  var hasHealthcheck = false;
  var prevKeyword = null;

  for (var idx = 0; idx < ins.length; idx++){
    var it = ins[idx];
    var kw = it.keyword, args = it.args;

    if (kw === "FROM"){
      fromCount++;
      finalStageFromLine = it.line;
      finalStageUser = null;
      var ftoks = splitTokens(args).filter(function(t){ return t.indexOf("--") !== 0; });
      var image = ftoks[0] || "";
      var stageName = null;
      for (var f = 1; f < ftoks.length - 1; f++){
        if (/^as$/i.test(ftoks[f])) stageName = ftoks[f + 1];
      }
      var lower = image.toLowerCase();
      var isStageRef = !!stages[lower];
      var isScratch = lower === "scratch";
      var isVar = image.indexOf("$") !== -1;
      if (image && !isStageRef && !isScratch && !isVar){
        var hasDigest = image.indexOf("@") !== -1;
        if (!hasDigest){
          var lastSlash = image.lastIndexOf("/");
          var lastColon = image.lastIndexOf(":");
          var tag = lastColon > lastSlash ? image.slice(lastColon + 1) : null;
          if (tag === null || tag === "" || tag.toLowerCase() === "latest"){
            add("error", it.line, "Unpinned base image",
              "FROM " + image + (tag ? ":" + tag : "") + " does not pin an exact version, so the same Dockerfile can build a different image on any given day.",
              "Pin an exact tag or digest, e.g. FROM " + image.split(":")[0] + ":<version> or " + image.split(":")[0] + "@sha256:<digest>.");
          }
        }
      }
      if (stageName) stages[stageName.toLowerCase()] = true;
    }

    if (kw === "USER"){
      var uval = (splitTokens(args)[0] || "").toLowerCase();
      finalStageUser = { value: uval, line: it.line };
    }

    if (kw === "HEALTHCHECK") hasHealthcheck = true;

    if (kw === "ENV" || kw === "ARG"){
      var pairs = [];
      var pairRe = /([A-Za-z_][A-Za-z0-9_]*)=("[^"]*"|'[^']*'|[^\s]+)/g, pm;
      while ((pm = pairRe.exec(args)) !== null) pairs.push({ key: pm[1], value: pm[2] });
      if (!pairs.length){
        var lt = splitTokens(args);
        if (lt.length >= 2) pairs.push({ key: lt[0], value: lt.slice(1).join(" ") });
        else if (lt.length === 1) pairs.push({ key: lt[0], value: "" });
      }
      for (var p = 0; p < pairs.length; p++){
        var kv = pairs[p];
        if (!SECRET_NAME.test(kv.key)) continue;
        var rawVal = String(kv.value || "").replace(/^["']|["']$/g, "");
        if (rawVal && rawVal.indexOf("$") !== 0){
          add("error", it.line, "Secret baked into " + kw + ": " + kv.key,
            "The key " + kv.key + " is set with a literal value (" + maskValue(rawVal) + ", masked). " + (kw === "ENV"
              ? "ENV values ship inside the image for anyone who pulls it."
              : "ARG values are recorded in the image's build history."),
            "Remove the value from the Dockerfile. Pass secrets at build time with --secret mounts, or at runtime from your orchestrator's secret store.");
        } else {
          add("warning", it.line, "Credential declared in " + kw + ": " + kv.key,
            "The key " + kv.key + " is declared with no literal value here — but anything passed to it at build time can still leak into history or layers.",
            "Prefer --secret mounts over build args for credentials, and never commit a real value next to this key name.");
        }
      }
    }

    if (kw === "ADD" || kw === "COPY"){
      var ctoks = splitTokens(args).filter(function(t){ return t.indexOf("--") !== 0; });
      var sources = ctoks.slice(0, Math.max(0, ctoks.length - 1));
      var whole = sources.some(function(s){ return s === "." || s === "./" || s === "*" || s === "./*"; });
      if (whole){
        add("warning", it.line, "Whole build context copied",
          kw + " copies the entire build context into the image. Anything in that folder — local env files, keys, .git — ships with it unless a .dockerignore keeps it out, and this audit cannot see your .dockerignore.",
          "Copy only the paths the image needs, by name, and keep a .dockerignore that excludes secrets, .git, and local config.");
      }
      if (kw === "ADD"){
        var localNonArchive = sources.some(function(s){
          if (/^https?:\/\//i.test(s)) return false;
          if (/\.(tar|tar\.gz|tgz|tar\.bz2|tar\.xz|tar\.zst)$/i.test(s)) return false;
          return true;
        });
        if (localNonArchive){
          add("warning", it.line, "ADD used for local files",
            "ADD silently unpacks local archives and can fetch remote URLs, which makes its behavior hard to predict from the Dockerfile alone.",
            "Use COPY for ordinary local files and folders; keep ADD only for tar archives or remote URLs you actually intend.");
        }
      }
    }

    if (kw === "RUN"){
      if (/(curl|wget)\b[^|]*\|\s*(sudo\s+)?(ba)?sh\b/.test(args)){
        add("error", it.line, "Remote script piped to a shell",
          "This RUN downloads a script and executes it sight unseen, as root, at build time. If that URL is compromised, so is every image built from it.",
          "Download the file, verify its checksum, and run the pinned copy — or install the tool from a pinned package instead.");
      }
      if (/apt-get\s+install/.test(args)){
        if (args.indexOf("--no-install-recommends") === -1){
          add("warning", it.line, "apt-get install without --no-install-recommends",
            "apt will pull in every recommended extra package, bloating the image and widening its attack surface.",
            "Add --no-install-recommends to the apt-get install command.");
        }
        if (!/rm\s+[^&;]*\/var\/lib\/apt\/lists/.test(args)){
          add("warning", it.line, "apt cache not cleaned in the same layer",
            "The apt package lists stay in this layer. Deleting them in a later RUN does not remove them from the image — the bytes are already in history.",
            "Append && rm -rf /var/lib/apt/lists/* to the same RUN instruction.");
        }
      }
      var unpinned = [];
      function collectUnpinned(segment, isPinned){
        var toks = splitTokens(segment);
        for (var t = 0; t < toks.length; t++){
          var tok = toks[t];
          if (!tok || tok.charAt(0) === "-" || tok.indexOf("$") !== -1) continue;
          if (tok === "install" || tok === "add" || tok === "apt-get" || tok === "apk" || tok === "pip" || tok === "pip3" || tok === "npm") continue;
          if (!isPinned(tok)) unpinned.push(tok);
        }
      }
      var mApt = args.match(/apt-get\s+install\s+([^&;|]+)/);
      if (mApt) collectUnpinned(mApt[1], function(tok){ return tok.indexOf("=") !== -1; });
      var mApk = args.match(/\bapk\s+add\s+([^&;|]+)/);
      if (mApk) collectUnpinned(mApk[1], function(tok){ return tok.indexOf("=") !== -1; });
      var mPip = args.match(/\bpip3?\s+install\s+([^&;|]+)/);
      if (mPip) collectUnpinned(mPip[1], function(tok){ return tok.indexOf("==") !== -1 || tok.indexOf("/") !== -1 || tok.indexOf(":") !== -1; });
      var mNpm = args.match(/\bnpm\s+(install|i)\s+([^&;|]+)/);
      if (mNpm){
        var npmToks = splitTokens(mNpm[2]).filter(function(t){ return t.charAt(0) !== "-"; });
        if (npmToks.length){
          collectUnpinned(mNpm[2], function(tok){
            if (tok.charAt(0) === "@"){ var slash = tok.indexOf("/"); return slash !== -1 && tok.indexOf("@", slash) !== -1; }
            return tok.indexOf("@") > 0;
          });
        }
      }
      if (unpinned.length){
        add("warning", it.line, "Package installs without version pins",
          "Unpinned packages in this RUN: " + unpinned.join(", ") + ". The next build can silently pull a newer — or broken, or compromised — release.",
          "Pin exact versions (package=1.2.3 for apt/apk, package==1.2.3 for pip, package@1.2.3 for npm), or install from a committed lockfile.");
      }
      if (prevKeyword === "RUN"){
        add("info", it.line, "Consecutive RUN instructions",
          "This RUN directly follows another RUN. Each one is its own image layer.",
          "Where it makes sense, chain the commands with && in a single RUN to cut a layer and keep related cleanup in the same layer.");
      }
    }

    if (kw === "CMD" || kw === "ENTRYPOINT"){
      if (args.charAt(0) !== "["){
        add("warning", it.line, kw + " in shell form",
          "Shell form runs the command through /bin/sh, which becomes PID 1 and does not forward signals — docker stop has to time out and kill the container.",
          "Use JSON exec form, e.g. " + kw + " [\"node\", \"server.js\"], so the app itself is PID 1 and receives SIGTERM directly.");
      }
    }

    if (kw === "EXPOSE"){
      var etoks = splitTokens(args);
      for (var e = 0; e < etoks.length; e++){
        var base = etoks[e].split("/")[0];
        var hit = null;
        if (SENSITIVE_PORTS[base]) hit = base;
        else if (/^\d+-\d+$/.test(base)){
          var parts = base.split("-"), lo = +parts[0], hi = +parts[1];
          for (var sp in SENSITIVE_PORTS){ var n = +sp; if (n >= lo && n <= hi) hit = sp; }
        }
        if (hit){
          add("warning", it.line, "Sensitive port " + hit + " exposed",
            "Port " + hit + (hit === "22" ? " (SSH)" : hit === "2375" ? " (Docker daemon, unencrypted)" : " (RDP)") + " is declared in EXPOSE. Publishing it invites direct attacks on a service that should never face a network from an app image.",
            "Remove the EXPOSE line; reach the service through your orchestrator's private networking instead.");
        }
      }
    }

    prevKeyword = kw;
  }

  if (fromCount === 0){
    add("error", 1, "No FROM instruction found",
      "Nothing in the pasted text starts with FROM, so this does not parse as a buildable Dockerfile.",
      "Start the file with a FROM line naming a pinned base image (or FROM scratch).");
  } else {
    if (!finalStageUser){
      add("error", finalStageFromLine, "No USER in the final stage — runs as root",
        "The final build stage never sets USER, so the container's process runs as root (UID 0) by default.",
        "Create a non-root user in the final stage and add USER <name> before CMD/ENTRYPOINT.");
    } else if (finalStageUser.value === "root" || finalStageUser.value === "0" || finalStageUser.value === "0:0" || finalStageUser.value === "root:root" || finalStageUser.value === "0:root" || finalStageUser.value === "root:0"){
      add("error", finalStageUser.line, "Final USER is root",
        "The final stage sets USER " + finalStageUser.value + ", so the container runs with full root privileges.",
        "Switch to a dedicated non-root user (e.g. USER node, or a user you create with useradd) for the runtime stage.");
    }
  }

  if (!hasHealthcheck && fromCount > 0){
    add("info", 0, "No HEALTHCHECK defined",
      "Without a HEALTHCHECK, Docker and your orchestrator can only tell a running container from a dead one — not a hung one from a healthy one.",
      "Add a HEALTHCHECK that hits a real readiness endpoint or checks the process does useful work.");
  }

  var order = { error: 0, warning: 1, info: 2 };
  findings.sort(function(a, b){
    if (order[a.sev] !== order[b.sev]) return order[a.sev] - order[b.sev];
    return (a.line || 0) - (b.line || 0);
  });

  var errors = findings.filter(function(f){ return f.sev === "error"; }).length;
  var warnings = findings.filter(function(f){ return f.sev === "warning"; }).length;
  var infos = findings.filter(function(f){ return f.sev === "info"; }).length;
  var verdict = errors > 0 ? "DO NOT BUILD" : (warnings > 0 ? "BUILD WITH FIXES" : "SAFE TO BUILD");
  return { verdict: verdict, errors: errors, warnings: warnings, infos: infos, findings: findings };
}
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "BAD_EXAMPLE": (typeof BAD_EXAMPLE !== 'undefined' ? BAD_EXAMPLE : undefined), "GOOD_EXAMPLE": (typeof GOOD_EXAMPLE !== 'undefined' ? GOOD_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-container-build-safety-auditor',
  name: 'J-Dawgs Container Build Safety Auditor',
  description: 'Install-first Dockerfile linters stop at per-line style rules; ours also grades the runtime posture (root user, secrets in build args, remote-script pipes) and returns one ship verdict with a fix list — no install',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "BAD_EXAMPLE": __core["BAD_EXAMPLE"], "GOOD_EXAMPLE": __core["GOOD_EXAMPLE"] }
};
