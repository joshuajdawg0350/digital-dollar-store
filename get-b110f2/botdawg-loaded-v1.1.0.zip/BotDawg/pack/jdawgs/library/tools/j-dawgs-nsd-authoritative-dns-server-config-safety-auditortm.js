'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs NSD Authoritative DNS Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

var RISKY = [
'# Risky NSD example - do not use in production',
'server:',
'    ip-address: 0.0.0.0',
'    port: 53',
'    do-ip4: yes',
'    do-ip6: yes',
'    zonesdir: "/var/lib/nsd/zones"',
'',
'remote-control:',
'    control-enable: yes',
'    control-interface: 0.0.0.0',
'',
'zone:',
'    name: "example.com"',
'    zonefile: "example.com.zone"',
'    provide-xfr: 0.0.0.0/0 NOKEY',
'    notify: 0.0.0.0/0 NOKEY',
'',
'key:',
'    name: "transfer-key"',
'    algorithm: hmac-md5',
'    secret: "abc123"',
'',
'# provide-xfr: 0.0.0.0/0 NOKEY',
'this line is not valid nsd.conf syntax at all'
].join('\n');

var HARDENED = [
'# Hardened NSD example - restricted and TSIG-protected',
'server:',
'    ip-address: 192.0.2.10',
'    port: 53',
'    do-ip4: yes',
'    do-ip6: no',
'    zonesdir: "/var/lib/nsd/zones"',
'',
'remote-control:',
'    control-enable: yes',
'    control-interface: 127.0.0.1',
'    server-key-file: "/etc/nsd/nsd_server.key"',
'    server-cert-file: "/etc/nsd/nsd_server.pem"',
'    control-key-file: "/etc/nsd/nsd_control.key"',
'    control-cert-file: "/etc/nsd/nsd_control.pem"',
'',
'zone:',
'    name: "example.com"',
'    zonefile: "example.com.zone.signed"',
'    provide-xfr: 198.51.100.2 transfer-key',
'    request-xfr: 198.51.100.1 transfer-key',
'    notify: 198.51.100.2 transfer-key',
'',
'key:',
'    name: "transfer-key"',
'    algorithm: hmac-sha256',
'    secret: "kX7vQ2mP9wR4tY8nB3sD6fG1hJ5aZ0cV2bN9mQ4wExY7"'
].join('\n');

var SECTIONS = { 'server':1, 'remote-control':1, 'zone':1, 'key':1 };
var KNOWN = {};
['ip-address','port','do-ip4','do-ip6','zonesdir','database','username','verbosity','server-count','ip-transparent','reuseport','hide-version','version','identity','nsid','logfile','pidfile','xfrdfile','zonelistfile','xfrdir','statistics','control-enable','control-interface','control-port','server-key-file','server-cert-file','control-key-file','control-cert-file','name','zonefile','provide-xfr','request-xfr','notify','algorithm','secret','include','zonefile-pattern','outgoing-interface','allow-notify','request-xfr-pattern'].forEach(function(k){ KNOWN[k]=1; });

function stripQuotes(v){ v = (v||'').trim(); if (v.length>=2 && ((v.charAt(0)==='"' && v.charAt(v.length-1)==='"') || (v.charAt(0)==="'" && v.charAt(v.length-1)==="'"))) return v.slice(1,-1); return v; }
function isYes(v){ v = stripQuotes(v).toLowerCase(); return v==='yes'||v==='true'||v==='1'; }
function isLocalhost(v){ v = stripQuotes(v).toLowerCase().split('@')[0]; return v==='127.0.0.1'||v==='::1'||v==='localhost'||v==='127.0.0.0/8'; }
function isWildcard(v){ v = stripQuotes(v).toLowerCase().split('@')[0]; return v==='0.0.0.0'||v==='::'||v==='::0'||v==='*'||v==='0.0.0.0/0'||v==='any'; }
function isOpenTarget(v){ var t = stripQuotes(v).toLowerCase(); return t==='0.0.0.0/0'||t==='::/0'||t==='any'||t==='0.0.0.0'||t==='::'; }

function audit(text){
  var findings = [];
  function add(line, severity, status, check, detail, fix){
    findings.push({ line: line, severity: severity, status: status, check: check, detail: detail, fix: fix || '' });
  }
  var rawLines = text.replace(/\r\n/g,'\n').replace(/\r/g,'\n').split('\n');
  // Drop a single trailing empty line produced by a final newline for line counting honesty
  var lines = rawLines.slice();
  while (lines.length && lines[lines.length-1].trim()==='') lines.pop();

  if (!text.trim()){
    add(1,'CRITICAL','FAIL','Empty input','No config text was provided, so there is nothing safe to serve.','Paste an nsd.conf, or load the hardened example to see a passing config.');
    return finish(lines.length, findings);
  }

  var section = null;
  var serverDirs = [], remoteDirs = [];
  var zones = [], keys = [];
  var curZone = null, curKey = null;
  var sawServer = false;

  for (var i=0;i<lines.length;i++){
    var lineNo = i+1;
    var raw = lines[i];
    var trimmed = raw.trim();
    if (trimmed==='') continue;

    if (trimmed.charAt(0)==='#'){
      var body = trimmed.slice(1).trim();
      var cm = body.match(/^([a-zA-Z][a-zA-Z0-9_-]*)\s*:/);
      if (cm && (KNOWN[cm[1]] || SECTIONS[cm[1]])){
        var cname = cm[1];
        if (cname==='secret'){
          add(lineNo,'INFO','COMMENTED','Commented line','Line ' + lineNo + ' is a commented-out secret directive. It is inactive and its value is not shown.','Leave it commented, or replace it with a fresh, strong secret if the key is re-enabled.');
        } else {
          add(lineNo,'INFO','COMMENTED','Commented line','Line ' + lineNo + ' is a commented-out "' + cname + '" directive. It is inactive and was not counted as live configuration.','No action needed while it stays commented. Re-audit before uncommenting it.');
        }
      }
      continue;
    }

    var secMatch = trimmed.match(/^([a-zA-Z][a-zA-Z0-9_-]*)\s*:\s*$/);
    if (secMatch && SECTIONS[secMatch[1]]){
      section = secMatch[1];
      if (section==='server') sawServer = true;
      if (section==='zone'){ curZone = { startLine: lineNo, dirs: [] }; zones.push(curZone); curKey = null; }
      else if (section==='key'){ curKey = { startLine: lineNo, dirs: [] }; keys.push(curKey); curZone = null; }
      else { curZone = null; curKey = null; }
      continue;
    }

    var dirMatch = trimmed.match(/^([a-zA-Z][a-zA-Z0-9_-]*)\s*:\s*(.+)$/);
    if (!dirMatch || !KNOWN[dirMatch[1]]){
      add(lineNo,'MEDIUM','NOT PARSED','Unparseable line','Line ' + lineNo + ' is NOT PARSED: it does not match nsd.conf directive syntax, so this auditor cannot tell what NSD would do with it. The line text is not reproduced here.','Fix or remove line ' + lineNo + ', then re-audit. NSD may reject the whole file over a malformed line.');
      continue;
    }

    var dname = dirMatch[1], dval = dirMatch[2].trim();
    var rec = { name: dname, value: dval, line: lineNo };
    if (section==='server') serverDirs.push(rec);
    else if (section==='remote-control') remoteDirs.push(rec);
    else if (section==='zone' && curZone) curZone.dirs.push(rec);
    else if (section==='key' && curKey) curKey.dirs.push(rec);
    else {
      // Directive outside any known block
      if (section===null){
        add(lineNo,'MEDIUM','NOT PARSED','Directive outside a block','Line ' + lineNo + ' ("' + dname + '") appears before any server:, remote-control:, zone:, or key: block, so it was NOT PARSED as part of a block.','Move it under the correct block header and re-audit.');
      }
    }
  }

  function find(dirs, name){ var out=[]; for (var j=0;j<dirs.length;j++) if (dirs[j].name===name) out.push(dirs[j]); return out; }
  function first(dirs, name){ var f = find(dirs,name); return f.length ? f[0] : null; }

  /* ---- server: checks ---- */
  if (!sawServer){
    add(1,'MEDIUM','FAIL','Missing server block','No server: block was found. NSD falls back to compiled-in defaults, including listening behavior you did not choose.','Add an explicit server: block with the ip-address values you actually intend to serve on.');
  }
  var ips = find(serverDirs,'ip-address');
  if (sawServer && ips.length===0){
    add(serverDirs.length?serverDirs[0].line:1,'HIGH','FAIL','No ip-address set','The server: block sets no ip-address, so NSD binds its default interfaces instead of an address you picked.','Set ip-address explicitly for each intended interface.');
  }
  ips.forEach(function(rec){
    if (isWildcard(rec.value)){
      add(rec.line,'CRITICAL','FAIL','Wildcard listen address','Line ' + rec.line + ' sets ip-address to a wildcard address, so NSD answers on every interface - and nsd.conf has no source ACL for the DNS service itself to narrow that exposure.','Bind a specific interface address (for example the host public or loopback address) and firewall UDP/TCP 53 to match.');
    } else {
      add(rec.line,'PASS','PASS','Listen address restricted','Line ' + rec.line + ' binds a specific ip-address rather than a wildcard.','');
    }
  });
  var dip4 = first(serverDirs,'do-ip4'), dip6 = first(serverDirs,'do-ip6');
  if (dip4 && dip6 && !isYes(dip4.value) && !isYes(dip6.value)){
    add(dip6.line,'HIGH','FAIL','No IP family enabled','do-ip4 and do-ip6 are both disabled (lines ' + dip4.line + ' and ' + dip6.line + '), so NSD would serve nothing.','Enable at least one address family.');
  }
  var port = first(serverDirs,'port');
  if (port && stripQuotes(port.value)!=='53'){
    add(port.line,'INFO','NOTE','Non-standard port','Line ' + port.line + ' sets port to ' + stripQuotes(port.value) + ' instead of 53. That is not unsafe by itself, but resolvers expect authoritative service on port 53.','Confirm the non-standard port is deliberate (for example, behind a redirect).');
  }
  if (sawServer && !first(serverDirs,'zonesdir')){
    add(ips.length?ips[0].line:1,'INFO','NOTE','zonesdir not set','No zonesdir is set, so zone files resolve against the NSD default directory. Not a vulnerability - just confirm it is where you think it is.','');
  }

  /* ---- remote-control: checks ---- */
  var ce = first(remoteDirs,'control-enable');
  if (ce && isYes(ce.value)){
    var ci = first(remoteDirs,'control-interface');
    var tlsNames = ['server-key-file','server-cert-file','control-key-file','control-cert-file'];
    var missingTls = tlsNames.filter(function(n){ return !first(remoteDirs,n); });
    if (!ci){
      add(ce.line,'INFO','NOTE','Remote control on default interface','control-enable is yes (line ' + ce.line + ') with no control-interface set, so NSD uses its localhost default. Keep it that way unless you mean otherwise.','');
      if (missingTls.length){
        add(ce.line,'MEDIUM','FAIL','Remote control TLS incomplete','Remote control is enabled but these TLS file settings are missing: ' + missingTls.join(', ') + '. nsd-control setup generates all four.','Run nsd-control-setup (or set all four file paths) so control traffic is authenticated and encrypted.');
      }
    } else if (isLocalhost(ci.value)){
      if (missingTls.length){
        add(ci.line,'MEDIUM','FAIL','Remote control TLS incomplete','Remote control listens on localhost (line ' + ci.line + '), which limits exposure, but these TLS file settings are missing: ' + missingTls.join(', ') + '.','Set all four TLS file paths so nsd-control is authenticated even for local users you do not trust.');
      } else {
        add(ci.line,'PASS','PASS','Remote control contained','Remote control is enabled on a localhost interface (line ' + ci.line + ') with all four TLS file settings present.','');
      }
    } else {
      if (missingTls.length){
        add(ci.line,'CRITICAL','FAIL','Remote control exposed without TLS','control-enable is yes and control-interface (line ' + ci.line + ') is not localhost, while these TLS file settings are missing: ' + missingTls.join(', ') + '. That is unauthenticated, unencrypted remote control of your DNS server over the network.','Bind control-interface to 127.0.0.1 and tunnel instead, or set server-key-file, server-cert-file, control-key-file, and control-cert-file before enabling it.');
      } else {
        add(ci.line,'HIGH','FAIL','Remote control on network interface','control-enable is yes on a non-localhost interface (line ' + ci.line + '). TLS files are present, but remote control still does not belong on a reachable interface if it can be avoided.','Prefer 127.0.0.1 plus an SSH tunnel. If it must stay, firewall the control port to admin hosts only.');
      }
    }
  } else if (ce){
    add(ce.line,'PASS','PASS','Remote control disabled','control-enable is not yes (line ' + ce.line + '), so nsd-control has no listening control channel.','');
  }

  /* ---- zone: checks ---- */
  if (zones.length===0){
    add(1,'MEDIUM','FAIL','No zones defined','No zone: block was found, so this config serves no zones.','Add a zone: block with name and zonefile for each zone NSD should answer for.');
  }
  zones.forEach(function(z){
    var znameRec = first(z.dirs,'name');
    var zlabel = znameRec ? stripQuotes(znameRec.value) : '(unnamed zone at line ' + z.startLine + ')';
    if (!znameRec) add(z.startLine,'MEDIUM','FAIL','Zone without a name','The zone: block at line ' + z.startLine + ' has no name, so NSD cannot load it as a zone.','Add name: for the zone.');
    if (!first(z.dirs,'zonefile')) add(z.startLine,'MEDIUM','FAIL','Zone without a zonefile','Zone "' + zlabel + '" (line ' + z.startLine + ') has no zonefile, so there is nothing for NSD to serve.','Add zonefile: pointing at the (signed, if applicable) zone file.');

    var pxfr = find(z.dirs,'provide-xfr');
    if (pxfr.length===0){
      add(z.startLine,'INFO','NOTE','No provide-xfr for zone','Zone "' + zlabel + '" has no provide-xfr lines. With none set, NSD does not offer zone transfers for this zone - a safe default, noted so you know it was checked.','');
    }
    pxfr.forEach(function(rec){
      var parts = stripQuotes(rec.value).split(/\s+/).filter(Boolean);
      var target = parts[0]||'', mode = (parts[1]||'').toUpperCase();
      if (isOpenTarget(target)){
        add(rec.line,'CRITICAL','FAIL','Open zone transfer','Line ' + rec.line + ' provides zone transfers (provide-xfr) to ' + target + ' - anyone on the internet can download the full zone "' + zlabel + '", including every hostname you would rather not enumerate.','Restrict provide-xfr to your secondary servers only, each paired with a TSIG key name.');
      } else if (mode==='NOKEY'){
        add(rec.line,'HIGH','FAIL','Zone transfer without TSIG','Line ' + rec.line + ' provides zone transfers to ' + target + ' with NOKEY - the only thing protecting the transfer is the source IP.','Pair the address with a TSIG key name so transfers are authenticated.');
      } else if (mode==='BLOCKED'){
        add(rec.line,'PASS','PASS','Zone transfer blocked','Line ' + rec.line + ' sets provide-xfr to BLOCKED for its target, so transfers are refused there.','');
      } else if (parts.length>=2){
        add(rec.line,'PASS','PASS','Zone transfer restricted','Line ' + rec.line + ' restricts provide-xfr to ' + target + ' with a TSIG key reference.','');
      } else {
        add(rec.line,'MEDIUM','FAIL','Zone transfer without TSIG','Line ' + rec.line + ' provides zone transfers to ' + target + ' with no TSIG key named.','Add the TSIG key name after the address so transfers are authenticated.');
      }
    });
    ['request-xfr','notify'].forEach(function(dn){
      find(z.dirs,dn).forEach(function(rec){
        var parts = stripQuotes(rec.value).split(/\s+/).filter(Boolean);
        var target = parts[0]||'', mode = (parts[1]||'').toUpperCase();
        if (isOpenTarget(target)){
          add(rec.line,'HIGH','FAIL','Open ' + dn,'Line ' + rec.line + ' sets ' + dn + ' to ' + target + ', an open/wildcard target.','Restrict ' + dn + ' to the specific primary/secondary addresses, paired with a TSIG key name.');
        } else if (mode==='NOKEY'){
          add(rec.line,'MEDIUM','FAIL', dn + ' without TSIG','Line ' + rec.line + ' sets ' + dn + ' to ' + target + ' with NOKEY, so it is authenticated by source IP only.','Pair the address with a TSIG key name.');
        }
      });
    });
  });

  /* ---- key: (TSIG) checks - secret VALUES are never copied anywhere ---- */
  var EXAMPLE_HINTS = ['example','changeme','change-me','password','letmein','supersecret','testtest','123456','qwerty','dnssecret','mysecret','secretkey','placeholder','default'];
  keys.forEach(function(k){
    var nameRec = first(k.dirs,'name');
    var kname = nameRec ? stripQuotes(nameRec.value) : '(unnamed key at line ' + k.startLine + ')';
    if (!nameRec) add(k.startLine,'MEDIUM','FAIL','TSIG key without a name','The key: block at line ' + k.startLine + ' has no name, so zones cannot reference it.','Add name: for the key.');
    var alg = first(k.dirs,'algorithm');
    if (!alg){
      add(k.startLine,'MEDIUM','FAIL','TSIG key without algorithm','Key "' + kname + '" sets no algorithm, so NSD falls back to its default instead of one you chose.','Set algorithm: hmac-sha256 (or hmac-sha512).');
    } else {
      var a = stripQuotes(alg.value).toLowerCase();
      if (a==='hmac-md5') add(alg.line,'HIGH','FAIL','Weak TSIG algorithm','Key "' + kname + '" uses hmac-md5 (line ' + alg.line + '). MD5-based TSIG is long past its sell-by date.','Regenerate the key with hmac-sha256 or hmac-sha512 and update every server that shares it.');
      else if (a==='hmac-sha1') add(alg.line,'MEDIUM','FAIL','Aging TSIG algorithm','Key "' + kname + '" uses hmac-sha1 (line ' + alg.line + '). It still functions, but SHA-256 is the current baseline.','Plan a rollover to hmac-sha256.');
      else if (a==='hmac-sha256'||a==='hmac-sha512') add(alg.line,'PASS','PASS','TSIG algorithm sound','Key "' + kname + '" uses ' + a + ' (line ' + alg.line + ').','');
      else add(alg.line,'MEDIUM','FAIL','Unrecognized TSIG algorithm','Key "' + kname + '" names algorithm "' + stripQuotes(alg.value) + '" (line ' + alg.line + '), which this auditor does not recognize as a standard NSD TSIG algorithm.','Use hmac-sha256 or hmac-sha512.');
    }
    var sec = first(k.dirs,'secret');
    if (!sec){
      add(k.startLine,'HIGH','FAIL','TSIG key without a secret','Key "' + kname + '" (line ' + k.startLine + ') has no secret at all, so it cannot authenticate anything.','Generate a real secret with a tool such as tsig-keygen or ddns-confgen and distribute it only to the servers that need it.');
    } else {
      var sval = stripQuotes(sec.value);
      var slen = sval.length;
      var lower = sval.toLowerCase();
      var isExample = EXAMPLE_HINTS.some(function(h){ return lower.indexOf(h)!==-1; }) || /^(a{6,}|0{6,}|1{6,})/.test(lower);
      var looksBase64 = /^[A-Za-z0-9+/=_-]+$/.test(sval) && slen>=16;
      if (slen < 24){
        add(sec.line,'CRITICAL','FAIL','TSIG secret too short','Key "' + kname + '", line ' + sec.line + ': the secret is only ' + slen + ' characters long. Short TSIG secrets can be brute-forced offline from a single captured transfer. The secret value is not shown in this report.','Generate a fresh secret of at least 32 characters of base64 (a 256-bit key encodes to 44) and roll it onto every server sharing this key.');
      } else if (isExample){
        add(sec.line,'CRITICAL','FAIL','TSIG secret looks like an example','Key "' + kname + '", line ' + sec.line + ': the secret (' + slen + ' characters) matches common example/placeholder patterns published in documentation - anyone who read the same docs knows it. The secret value is not shown in this report.','Replace it with a freshly generated random secret and roll it onto every server sharing this key.');
      } else if (!looksBase64){
        add(sec.line,'HIGH','FAIL','TSIG secret looks like plaintext','Key "' + kname + '", line ' + sec.line + ': the secret (' + slen + ' characters) does not look like base64 key material - it reads like a human-chosen word or phrase, which is far weaker than its length suggests. The secret value is not shown in this report.','Replace it with machine-generated base64 key material, not a memorable phrase.');
      } else {
        add(sec.line,'PASS','PASS','TSIG secret shape sound','Key "' + kname + '", line ' + sec.line + ': secret is ' + slen + ' characters and base64-shaped. Its value was not printed anywhere in this report. Strength beyond shape cannot be proven from the config alone.','');
      }
    }
  });

  /* ---- DNSSEC honesty note (always, INFO only) ---- */
  add(zones.length?zones[0].startLine:1,'INFO','NOTE','DNSSEC not determinable from nsd.conf','No DNSSEC signing verdict is given: NSD serves pre-signed zone files and signing is configured outside nsd.conf, so this file alone cannot prove zones are signed or unsigned. A zonefile name ending in .signed is a hint, not proof.','Check the signing pipeline and validate with a resolver-side tool (for example delv) if DNSSEC matters for these zones.');

  return finish(lines.length, findings);
}

function finish(lineCount, findings){
  findings.sort(function(a,b){ return a.line - b.line; });
  var crit = findings.filter(function(f){return f.severity==='CRITICAL';}).length;
  var fix = findings.filter(function(f){return f.severity==='HIGH'||f.severity==='MEDIUM';}).length;
  var commented = findings.filter(function(f){return f.status==='COMMENTED';}).length;
  var garbage = findings.filter(function(f){return f.status==='NOT PARSED';}).length;
  var verdict, vclass, vdetail;
  if (crit>0){ verdict='DO NOT SERVE'; vclass='v-crit'; vdetail = crit + ' critical finding' + (crit===1?'':'s') + ' - this config would expose the server or the zone as-is. Fix the critical items, then re-audit.'; }
  else if (fix>0){ verdict='SERVE WITH FIXES'; vclass='v-fix'; vdetail = fix + ' finding' + (fix===1?'':'s') + ' need fixing before this config is something to rely on. Nothing critical was found.'; }
  else { verdict='SAFE TO SERVE'; vclass='v-ok'; vdetail = 'No critical, high, or medium findings in the active configuration. Commented lines were treated as inactive, and the DNSSEC note above is informational only. Still run nsd-checkconf before reloading NSD.'; }
  return { lineCount: lineCount, findings: findings, crit: crit, fix: fix, commented: commented, garbage: garbage, verdict: verdict, vclass: vclass, vdetail: vdetail };
}

var lastResult = null;
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_HINTS": (typeof EXAMPLE_HINTS !== 'undefined' ? EXAMPLE_HINTS : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-nsd-authoritative-dns-server-config-safety-auditortm',
  name: 'J-Dawgs NSD Authoritative DNS Server Config Safety Auditor',
  description: 'Grades a pasted nsd.conf offline into one serve verdict — wildcard binds, remote-control without TLS, open zone transfers, and short TSIG secrets that pass silently.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_HINTS": __core["EXAMPLE_HINTS"] }
};
