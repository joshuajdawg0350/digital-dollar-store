'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs HedgeDoc Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

/* ---------- Worked examples (line numbers are part of the lesson) ---------- */
var RISKY_LINES = [
  '{',
  '  "domain": "http://notes.example.com",',
  '  "host": "0.0.0.0",',
  '  "port": 3000,',
  '  "sessionSecret": "changeme123",',
  '  "allowAnonymous": true,',
  '  "allowAnonymousEdits": true,',
  '  "allowFreeURL": true,',
  '  "requireFreeURLAuthentication": false,',
  '  "protocolUseSSL": false,',
  '  "db": {',
  '    "username": "hedgedoc",',
  '    "password": "pw123!",',
  '    "database": "hedgedoc"',
  '  },',
  '  "csp": {',
  '    "enable": false,',
  '    "reportOnly": true',
  '  },',
  '  "loglevel": "debug"',
  '}'
];
var RISKY = RISKY_LINES.join("\n");
var PLANTED_SESSION_SECRET = "changeme123";
var PLANTED_DB_PASSWORD = "pw123!";

var HARDENED_LINES = [
  '{',
  '  "domain": "https://notes.example.com",',
  '  "host": "127.0.0.1",',
  '  "port": 3000,',
  '  "urlPath": "notes",',
  '  "sessionSecret": "k7Qm2xV9pL4wN8tY3hJ6sD1fG0zXcVbNqW5eR8uI2oP4aS7d",',
  '  "allowAnonymous": false,',
  '  "allowAnonymousEdits": false,',
  '  "allowFreeURL": false,',
  '  "requireFreeURLAuthentication": true,',
  '  "protocolUseSSL": true,',
  '  "db": {',
  '    "username": "hedgedoc",',
  '    "password": "M9kQ2mP7vR4wN8tY3hJ6sD1fG0zXcVbNq",',
  '    "database": "hedgedoc"',
  '  },',
  '  "csp": {',
  '    "enable": true,',
  '    "reportOnly": false',
  '  },',
  '  "loglevel": "info"',
  '}'
];
var HARDENED = HARDENED_LINES.join("\n");

var PROSE = "Our team met on Tuesday to plan the office move. The notes were long, the coffee was strong, and nobody mentioned a server at all. We talked about paint colors, parking, and who is bringing the ladder on Saturday.";

/* ---------- Parsing ---------- */
var EXAMPLE_TOKENS = ["changeme","change-me","change_me","change me","example","placeholder","your-secret","your_secret","yoursecret","supersecret","secret123","password123","default","hedgedoc","testsecret","insecure","pleasechange","please-change","replace-me","replaceme","todo","123456","letmein"];

function looksExample(value){
  var v = String(value).toLowerCase();
  for (var i=0;i<EXAMPLE_TOKENS.length;i++){ if (v.indexOf(EXAMPLE_TOKENS[i]) !== -1) return true; }
  if (/^(.)\1+$/.test(v)) return true; /* one repeated character */
  return false;
}
function isEnvRef(value){
  var v = String(value).trim();
  return v.indexOf("${") === 0 || v.indexOf("env:") === 0 || v.indexOf("process.env") === 0;
}
function normKey(raw){
  return String(raw).toLowerCase().replace(/[^a-z0-9]/g,"");
}
function canonKey(rawKey, parentCanon){
  var k = normKey(rawKey);
  var original = String(rawKey);
  if (/^cmd/i.test(original)) { /* CMD_ prefix already removed by normKey letters: cmdsessionsecret */
    if (k.indexOf("cmd") === 0) k = k.slice(3);
  }
  if (parentCanon === "csp"){
    if (k === "enable" || k === "enabled") return "cspenable";
    if (k === "reportonly") return "cspreportonly";
  }
  if (parentCanon === "db" || parentCanon === "database"){
    if (k === "password" || k === "pass") return "dbpassword";
    if (k === "username" || k === "user") return "dbusername";
  }
  var map = {
    "domain":"domain", "urlpath":"urlpath", "port":"port",
    "host":"host", "hostname":"host", "bind":"host", "bindaddress":"host", "address":"host",
    "sessionsecret":"sessionsecret",
    "allowanonymous":"allowanonymous", "allowanonymousedits":"allowanonymousedits",
    "allowfreeurl":"allowfreeurl", "requirefreeurlauthentication":"requirefreeurlauthentication",
    "protocolusessl":"protocolusessl", "usessl":"protocolusessl",
    "cspenable":"cspenable", "cspenabled":"cspenable", "enablecsp":"cspenable",
    "cspreportonly":"cspreportonly", "reportonly":"cspreportonly",
    "loglevel":"loglevel",
    "dbpassword":"dbpassword", "databasepassword":"dbpassword", "password":"dbpassword",
    "dbusername":"dbusername", "databaseusername":"dbusername", "dbuser":"dbusername", "username":"dbusername",
    "dburl":"dburl", "databaseurl":"dburl", "db":"db", "database":"dbdatabase", "csp":"csp"
  };
  return map[k] || null;
}
function cleanValue(raw){
  var v = String(raw).trim();
  v = v.replace(/,\s*$/,"").trim();
  if (v.length >= 2 && ((v.charAt(0)==='"' && v.charAt(v.length-1)==='"') || (v.charAt(0)==="'" && v.charAt(v.length-1)==="'"))){
    v = v.slice(1,-1);
  }
  return v;
}
function parseConfig(text){
  var lines = String(text).split(/\r?\n/);
  var entries = [];
  var stack = []; /* {canon, depth} */
  var depth = 0;
  for (var i=0;i<lines.length;i++){
    var lineNo = i+1;
    var line = lines[i];
    var parent = stack.length ? stack[stack.length-1].canon : null;

    /* object keys opened on this line: "db": { */
    var objMatches = [];
    var om; var objRe = /"([^"]+)"\s*:\s*\{/g;
    while ((om = objRe.exec(line)) !== null){ objMatches.push({key: om[1], index: om.index}); }

    var foundOnLine = false;

    /* JSON pairs (handles several pairs on one line) */
    var pairRe = /"([^"]+)"\s*:\s*("(?:[^"\\]|\\.)*"|true|false|null|-?\d+(?:\.\d+)?)/gi;
    var pm; var pairs = [];
    while ((pm = pairRe.exec(line)) !== null){ pairs.push({key: pm[1], rawVal: pm[2], index: pm.index}); }
    if (pairs.length){
      foundOnLine = true;
      for (var p=0;p<pairs.length;p++){
        var par = parent;
        for (var o=0;o<objMatches.length;o++){ if (objMatches[o].index < pairs[p].index) par = normKey(objMatches[o].key); }
        var canon = canonKey(pairs[p].key, par);
        if (canon){
          var val = cleanValue(pairs[p].rawVal.replace(/\\"/g,'"'));
          entries.push({canon: canon, key: pairs[p].key, line: lineNo, value: val});
        }
      }
    }

    if (!foundOnLine){
      var m = null;
      m = line.match(/^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_.]*)\s*=\s*(.*)$/);
      if (!m) m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_.-]*)\s*:\s+(.+)$/);
      if (m){
        var canon2 = canonKey(m[1], parent);
        if (canon2 && canon2 !== "db" && canon2 !== "csp"){
          entries.push({canon: canon2, key: m[1], line: lineNo, value: cleanValue(m[2])});
        }
        if (canon2 === "db" || canon2 === "csp"){
          entries.push({canon: canon2, key: m[1], line: lineNo, value: ""});
        }
      }
    }

    /* object keys with no pair (e.g. "db": {) still count as recognized */
    for (var q=0;q<objMatches.length;q++){
      var oc = canonKey(objMatches[q].key, parent);
      if (oc === "db" || oc === "csp"){
        var already = false;
        for (var e=0;e<entries.length;e++){ if (entries[e].line === lineNo && entries[e].canon === oc) already = true; }
        if (!already) entries.push({canon: oc, key: objMatches[q].key, line: lineNo, value: ""});
      }
    }

    /* update brace stack */
    var opens = (line.match(/\{/g) || []).length;
    var closes = (line.match(/\}/g) || []).length;
    depth += opens - closes;
    for (var s=0;s<objMatches.length;s++){
      stack.push({canon: normKey(objMatches[s].key), depth: depth});
    }
    while (stack.length && stack[stack.length-1].depth > depth) stack.pop();
    if (depth < 0) depth = 0;
  }
  return entries;
}
function firstEntry(entries, canon){
  for (var i=0;i<entries.length;i++){ if (entries[i].canon === canon) return entries[i]; }
  return null;
}
function isTrue(entry){ return !!entry && String(entry.value).toLowerCase() === "true"; }
function isFalse(entry){ return !!entry && String(entry.value).toLowerCase() === "false"; }

/* ---------- Audit ---------- */
var SEV_RANK = {BLOCKER:0, HIGH:1, WARNING:2, INFO:3};
function audit(text){
  var entries = parseConfig(text || "");
  var recognizedSet = {};
  entries.forEach(function(e){ recognizedSet[e.canon] = true; });
  var recognized = Object.keys(recognizedSet);
  var findings = [];
  function add(sev, key, line, message, fix, valueLength){
    var f = {severity: sev, key: key, line: (line == null ? null : line), message: message, fix: fix};
    if (typeof valueLength === "number") f.valueLength = valueLength;
    findings.push(f);
  }

  if (recognized.length < 3){
    add("INFO","(input)",null,
      "Not enough HedgeDoc settings were recognized to grade this text (" + recognized.length + " recognized: " + (recognized.length ? recognized.join(", ") : "none") + "). This is expected for plain prose, a partial snippet, or a config in a format the auditor does not read.",
      "Paste a fuller config.json or an env-style block with at least three HedgeDoc settings, one setting per line.");
    return {verdict:"NOT ENOUGH TO GRADE", findings: findings, recognized: recognized, entries: entries};
  }

  /* sessionSecret — value NEVER rendered; key, line, length only */
  var ss = firstEntry(entries,"sessionsecret");
  if (!ss || ss.value === ""){
    add("BLOCKER","sessionSecret", ss ? ss.line : null,
      "sessionSecret is " + (ss ? "empty" : "missing") + ". Without a long random session secret, login sessions can be forged.",
      "Set sessionSecret to a random value of at least 32 characters and keep it out of version control.");
  } else if (!isEnvRef(ss.value)){
    var ssReasons = [];
    if (ss.value.length < 32) ssReasons.push("too short at " + ss.value.length + " characters (minimum 32)");
    if (looksExample(ss.value)) ssReasons.push("it matches a published example / placeholder pattern");
    if (ssReasons.length){
      add("BLOCKER","sessionSecret", ss.line,
        "sessionSecret is not safe: " + ssReasons.join("; ") + ". Reported by key name, line, and length only — the value is never shown.",
        "Replace sessionSecret with a fresh random value of at least 32 characters that appears in no example or tutorial.",
        ss.value.length);
    }
  } else {
    add("INFO","sessionSecret", ss.line,
      "sessionSecret is supplied as an environment reference, so its length is not graded from this text.",
      "Make sure the referenced environment value is random and at least 32 characters.");
  }

  /* anonymous access */
  var aa = firstEntry(entries,"allowanonymous");
  if (isTrue(aa)){
    add("HIGH","allowAnonymous", aa.line,
      "allowAnonymous is true — anyone on the internet can read and create notes without signing in.",
      "Set allowAnonymous to false unless this instance is deliberately public.");
  }
  var aae = firstEntry(entries,"allowanonymousedits");
  if (isTrue(aae)){
    add("BLOCKER","allowAnonymousEdits", aae.line,
      "allowAnonymousEdits is true — anonymous visitors can edit notes without signing in. That is an open door to vandalism and abuse.",
      "Set allowAnonymousEdits to false.");
  }

  /* free URL */
  var afu = firstEntry(entries,"allowfreeurl");
  var rfu = firstEntry(entries,"requirefreeurlauthentication");
  if (isTrue(afu) && !isTrue(rfu)){
    add("HIGH","allowFreeURL", afu.line,
      "allowFreeURL is true but requireFreeURLAuthentication is " + (rfu ? "not true (line " + rfu.line + ")" : "missing") + " — anyone can create notes at free URLs with no sign-in.",
      "Set requireFreeURLAuthentication to true, or set allowFreeURL to false.");
  }

  /* domain scheme */
  var dom = firstEntry(entries,"domain");
  if (dom && /^http:\/\//i.test(dom.value)){
    add("HIGH","domain", dom.line,
      "domain uses an http:// URL (" + dom.value + ") — logins, session cookies, and note content travel unencrypted.",
      "Serve the instance over HTTPS and set domain to the https:// URL.");
  }

  /* host binding */
  var host = firstEntry(entries,"host");
  if (host && host.value === "0.0.0.0"){
    add("HIGH","host", host.line,
      "host is 0.0.0.0 with port " + (firstEntry(entries,"port") ? firstEntry(entries,"port").value : "configured") + " — the app binds to every network interface, so the raw app port is reachable directly if no reverse proxy blocks it.",
      "Bind to 127.0.0.1 and put a reverse proxy in front, or firewall the app port so only the proxy can reach it.");
  }

  /* database password — value NEVER rendered; key, line, length only */
  var dbp = firstEntry(entries,"dbpassword");
  if (dbp && dbp.value !== "" && !isEnvRef(dbp.value)){
    var dbReasons = [];
    if (dbp.value.length < 16) dbReasons.push("too short at " + dbp.value.length + " characters (16 or more recommended)");
    if (looksExample(dbp.value)) dbReasons.push("it matches a published example / placeholder pattern");
    if (dbReasons.length){
      add("BLOCKER","db.password", dbp.line,
        "The database password is not safe: " + dbReasons.join("; ") + ". It also sits in plain text in this config. Reported by key name, line, and length only — the value is never shown.",
        "Use a long random database password (16+ characters), store it in an environment variable or secrets file, and rotate it if this config was ever shared.",
        dbp.value.length);
    }
  }

  /* protocolUseSSL */
  var ssl = firstEntry(entries,"protocolusessl");
  if (isFalse(ssl)){
    add("WARNING","protocolUseSSL", ssl.line,
      "protocolUseSSL is false. If this instance is reached over HTTPS (directly or behind a proxy), generated links and cookie handling should match the secure scheme.",
      "Set protocolUseSSL to true when the public URL is HTTPS.");
  }

  /* CSP */
  var cspEnable = firstEntry(entries,"cspenable");
  var cspObj = firstEntry(entries,"csp");
  if (isFalse(cspEnable)){
    add("WARNING","csp.enable", cspEnable.line,
      "CSP is disabled (csp.enable is false). Content Security Policy is a main defense against injected scripts running in readers' browsers.",
      "Set csp.enable to true.");
  } else if (!cspEnable && !cspObj){
    add("WARNING","csp.enable", null,
      "No csp.enable setting was found, so CSP cannot be confirmed as on.",
      "Set csp.enable to true explicitly in the config.");
  }
  var cspRO = firstEntry(entries,"cspreportonly");
  if (isTrue(cspRO)){
    add("INFO","csp.reportOnly", cspRO.line,
      "csp.reportOnly is true — CSP violations are only reported, not blocked. Fine while tuning a policy; it is not enforcement.",
      "Switch csp.reportOnly to false once the policy is tuned.");
  }

  /* loglevel */
  var ll = firstEntry(entries,"loglevel");
  if (ll && String(ll.value).toLowerCase() === "debug"){
    add("WARNING","loglevel", ll.line,
      "loglevel is debug — debug logs are verbose and can leak note metadata, tokens, and request details into log files that get kept and shared.",
      "Set loglevel to info (or warn) for a deployed instance.");
  }

  findings.sort(function(a,b){
    if (SEV_RANK[a.severity] !== SEV_RANK[b.severity]) return SEV_RANK[a.severity] - SEV_RANK[b.severity];
    var la = a.line == null ? 9999 : a.line, lb = b.line == null ? 9999 : b.line;
    return la - lb;
  });

  var counts = {BLOCKER:0, HIGH:0, WARNING:0, INFO:0};
  findings.forEach(function(f){ counts[f.severity]++; });
  var verdict;
  if (counts.BLOCKER > 0) verdict = "DO NOT DEPLOY";
  else if (counts.HIGH > 0 || counts.WARNING > 0) verdict = "DEPLOY WITH FIXES";
  else verdict = "SAFE TO DEPLOY";
  return {verdict: verdict, findings: findings, recognized: recognized, entries: entries, counts: counts};
}

/* ---------- Reports (never contain input text or secret values) ---------- */
function countsOf(result){
  var c = {BLOCKER:0, HIGH:0, WARNING:0, INFO:0};
  result.findings.forEach(function(f){ c[f.severity]++; });
  return c;
}
function lineLabel(line){ return line == null ? "not found" : "line " + line; }
function buildTextReport(result){
  var c = countsOf(result);
  var out = [];
  out.push("J-Dawgs HedgeDoc Server Config Safety Auditor - Text Report");
  out.push("Verdict: " + result.verdict);
  out.push("Findings: " + c.BLOCKER + " blocker(s), " + c.HIGH + " high, " + c.WARNING + " warning(s), " + c.INFO + " info");
  out.push("Recognized HedgeDoc settings: " + (result.recognized.length ? result.recognized.join(", ") : "none"));
  out.push("");
  out.push("--- Findings ---");
  if (!result.findings.length) out.push("No findings. No known risky patterns were found in the pasted text.");
  result.findings.forEach(function(f, idx){
    var line = "[" + f.severity + "] " + (f.line == null ? "Line: not found" : "Line " + f.line) + " - " + f.key;
    if (typeof f.valueLength === "number") line += " (value length: " + f.valueLength + " characters; value never shown)";
    out.push((idx+1) + ". " + line);
    out.push("    " + f.message);
    out.push("    Fix: " + f.fix);
  });
  out.push("");
  out.push("Notes: Heuristic text audit only. This tool did not start HedgeDoc, connect anywhere, or verify any secret. Secret values are never included in this report; secrets are reported by key name, line, and length only.");
  return out.join("\n");
}
function buildJsonReport(result){
  var c = countsOf(result);
  var obj = {
    tool: "J-Dawgs HedgeDoc Server Config Safety Auditor",
    verdict: result.verdict,
    counts: {blocker: c.BLOCKER, high: c.HIGH, warning: c.WARNING, info: c.INFO},
    recognizedSettings: result.recognized,
    findings: result.findings.map(function(f){
      var o = {severity: f.severity, key: f.key, line: f.line, message: f.message, fix: f.fix};
      if (typeof f.valueLength === "number"){ o.valueLength = f.valueLength; o.valueShown = false; }
      return o;
    }),
    notes: "Heuristic text audit only. This tool did not start HedgeDoc, connect anywhere, or verify any secret. Secret values are never included; secrets are reported by key name, line, and length only."
  };
  return JSON.stringify(obj, null, 2);
}
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_TOKENS": (typeof EXAMPLE_TOKENS !== 'undefined' ? EXAMPLE_TOKENS : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-hedgedoc-server-config-safety-auditortm',
  name: 'J-Dawgs HedgeDoc Server Config Safety Auditor',
  description: 'Host tools only tell you the server started; ours grades a pasted HedgeDoc config offline into one deploy verdict — secrets by key name/line/length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_TOKENS": __core["EXAMPLE_TOKENS"] }
};
