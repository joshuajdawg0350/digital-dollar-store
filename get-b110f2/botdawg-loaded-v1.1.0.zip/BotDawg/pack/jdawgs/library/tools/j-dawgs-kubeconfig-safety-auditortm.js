'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Kubeconfig Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var RISKY_EXAMPLE = [
        "apiVersion: v1",
        "kind: Config",
        "clusters:",
        "  - name: prod",
        "    cluster:",
        "      server: https://api.prod.example.com:6443",
        "      insecure-skip-tls-verify: true",
        "      certificate-authority-data: RkFLRS1DQURBVGEtRk9SLURFTU8tT05MWQ==",
        "users:",
        "  - name: prod-admin",
        "    user:",
        "      token: FAKE-DEMO-TOKEN-9f8e7d6c5b4a3210",
        "      client-key-data: RkFLRS1QUklWQVRFLUtFWS1EQVRBLURFTU8=",
        "  - name: deployer",
        "    user:",
        "      exec:",
        "        command: /tmp/get-creds.sh",
        "        interactiveMode: IfAvailable",
        "contexts:",
        "  - name: prod",
        "    context:",
        "      cluster: prod",
        "      user: prod-admin",
        "  - name: staging",
        "    context:",
        "      cluster: staging-missing",
        "      user: deployer",
        "current-context: prod",
        "preferences: {}",
        ""
      ].join("\n");

      var CLEAN_EXAMPLE = [
        "apiVersion: v1",
        "kind: Config",
        "clusters:",
        "  - name: home",
        "    cluster:",
        "      server: https://192.168.1.50:6443",
        "      certificate-authority: /home/user/.kube/ca.crt",
        "users:",
        "  - name: home-admin",
        "    user:",
        "      client-certificate: /home/user/.kube/client.crt",
        "      client-key: /home/user/.kube/client.key",
        "contexts:",
        "  - name: home",
        "    context:",
        "      cluster: home",
        "      user: home-admin",
        "      namespace: default",
        "current-context: home",
        ""
      ].join("\n");

      var inputEl = document.getElementById("input");
      var emptyMsg = document.getElementById("empty-msg");
      var resultsEl = document.getElementById("results");
      var verdictBox = document.getElementById("verdict-box");
      var verdictWord = document.getElementById("verdict-word");
      var verdictWhy = document.getElementById("verdict-why");
      var verdictCounts = document.getElementById("verdict-counts");
      var findingsEl = document.getElementById("findings");
      var reportEl = document.getElementById("report");
      var copyNote = document.getElementById("copy-note");

      function stripComment(v) {
        var idx = v.indexOf(" #");
        if (idx >= 0 && v.charAt(0) !== '"' && v.charAt(0) !== "'") return v.slice(0, idx);
        return v;
      }
      function cleanValue(v) {
        v = stripComment(String(v == null ? "" : v)).trim();
        if (v.length >= 2) {
          var a = v.charAt(0), b = v.charAt(v.length - 1);
          if ((a === '"' && b === '"') || (a === "'" && b === "'")) v = v.slice(1, -1);
        }
        return v.trim();
      }
      function esc(s) {
        return String(s).replace(/[&<>"']/g, function (c) {
          return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
        });
      }
      function hostOnly(url) {
        try {
          var u = new URL(url);
          return u.host || u.hostname || "";
        } catch (e) {
          var s = String(url).replace(/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//, "");
          var at = s.lastIndexOf("@");
          if (at >= 0) s = s.slice(at + 1);
          var slash = s.indexOf("/");
          if (slash >= 0) s = s.slice(0, slash);
          return s;
        }
      }

      /* ---------- Tolerant line/indentation parser (honest subset) ---------- */
      function parseKube(text) {
        var lines = text.split(/\r?\n/);
        var doc = {
          clusters: [], users: [], contexts: [],
          currentContext: null, currentContextLine: null,
          preferencesLine: null, notParsed: []
        };
        var section = null;        // 'clusters' | 'users' | 'contexts' | 'preferences' | 'other' | null
        var entry = null;          // current list entry
        var listIndent = null;
        var stack = [];            // [{key, indent}] container blocks inside entry
        var blockScalarIndent = -1; // >=0 while swallowing a block scalar's lines
        var sawContent = false;

        function np(line, msg) { doc.notParsed.push({ line: line, message: msg }); }
        function parentKey() { return stack.length ? stack[stack.length - 1].key : "entry"; }

        function handleField(entryObj, key, rawValue, lineNo, indent) {
          var value = cleanValue(rawValue);
          while (stack.length && indent <= stack[stack.length - 1].indent) stack.pop();
          var parent = parentKey();
          var isContainerValue = (value === "");
          var containers = { cluster: 1, user: 1, context: 1, exec: 1, "auth-provider": 1, config: 1, env: 1, args: 1 };
          if (/[&*][A-Za-z0-9_-]+/.test(rawValue) && /(^|\s)[&*]/.test(rawValue)) {
            np(lineNo, "YAML anchor/alias on key “" + key + "” — the parser cannot settle its resolved value.");
          }
          if (value === "|" || value === ">" || value === "|-" || value === ">-" || value === "|+" || value === ">+") {
            np(lineNo, "Block scalar value for key “" + key + "” — multi-line values are not parsed and this entry’s block was excluded from grading.");
            blockScalarIndent = indent;
          }
          if (!isContainerValue && (value.charAt(0) === "{" || value.charAt(0) === "[")) {
            np(lineNo, "Flow-style value for key “" + key + "” inside an entry — flow style is not parsed and was excluded from grading.");
          }
          entryObj.fields.push({ key: key, value: value, line: lineNo, parent: parent });
          if (key === "name" && parent === "entry" && entryObj.name === null) {
            entryObj.name = value; entryObj.nameLine = lineNo;
          }
          if (key === "exec" && isContainerValue) entryObj.hasExec = true;
          if (isContainerValue && containers[key]) stack.push({ key: key, indent: indent });
        }

        for (var i = 0; i < lines.length; i++) {
          var lineNo = i + 1;
          var raw = lines[i];
          if (/^\t/.test(raw) || /^ +\t/.test(raw)) {
            np(lineNo, "Tab indentation — YAML forbids tabs and the parser cannot settle this line’s level.");
          }
          var trimmed = raw.replace(/^\s+/, "").replace(/\s+$/, "");
          var indent = raw.length - raw.replace(/^ +/, "").length;
          if (trimmed === "" || trimmed.charAt(0) === "#") continue;
          if (trimmed === "---") {
            if (sawContent) np(lineNo, "Additional YAML document marker — only the first document is graded; later documents are not parsed.");
            continue;
          }
          if (trimmed === "...") continue;
          if (blockScalarIndent >= 0) {
            if (indent > blockScalarIndent) continue; // part of the block scalar already reported
            blockScalarIndent = -1;
          }
          sawContent = true;

          var isDash = (trimmed === "-" || trimmed.indexOf("- ") === 0);

          if (indent === 0 && !isDash) {
            var mTop = trimmed.match(/^([A-Za-z0-9_.-]+):\s*(.*)$/);
            entry = null; stack = []; listIndent = null;
            if (!mTop) {
              np(lineNo, "Top-level line is not a “key: value” pair — not parsed.");
              section = "other";
              continue;
            }
            var topKey = mTop[1], topVal = cleanValue(mTop[2]);
            if (topKey === "clusters" || topKey === "users" || topKey === "contexts") {
              section = topKey;
            } else if (topKey === "current-context") {
              doc.currentContext = topVal === "" ? null : topVal;
              doc.currentContextLine = lineNo;
              section = "other";
            } else if (topKey === "preferences") {
              doc.preferencesLine = lineNo;
              section = "preferences";
            } else {
              section = "other";
            }
            continue;
          }

          if (section === "clusters" || section === "users" || section === "contexts") {
            if (isDash) {
              if (listIndent === null) listIndent = indent;
              if (indent === listIndent) {
                entry = { section: section, line: lineNo, name: null, nameLine: null, fields: [], listItems: [], hasExec: false };
                doc[section].push(entry);
                stack = [];
                var rest = trimmed === "-" ? "" : trimmed.slice(2).replace(/^\s+/, "");
                if (rest) {
                  var mRest = rest.match(/^([A-Za-z0-9_.-]+):\s*(.*)$/);
                  if (mRest) handleField(entry, mRest[1], mRest[2], lineNo, indent + 2);
                  else np(lineNo, "List entry does not start with a “key: value” pair — not parsed.");
                }
                continue;
              }
              if (indent > listIndent) {
                if (entry) {
                  var itemVal = trimmed === "-" ? "" : trimmed.slice(2);
                  entry.listItems.push({ value: cleanValue(itemVal), line: lineNo, parent: parentKey() });
                }
                continue;
              }
              np(lineNo, "List item dedented below the list level — not parsed.");
              continue;
            }
            var mField = trimmed.match(/^([A-Za-z0-9_.-]+):\s*(.*)$/);
            if (!entry) {
              np(lineNo, "Field appears before any list entry under “" + section + "” — not parsed.");
              continue;
            }
            if (!mField) {
              np(lineNo, "Line inside “" + section + "” is not a “key: value” pair — not parsed and excluded from grading.");
              continue;
            }
            if (mField[1] === "<<") {
              np(lineNo, "YAML merge key — merged content is not parsed and was excluded from grading.");
              continue;
            }
            handleField(entry, mField[1], mField[2], lineNo, indent);
            continue;
          }

          if (section === "preferences" || section === "other" || section === null) {
            // Nested content of top-level blocks we do not grade (preferences, extensions…): tolerated, not findings.
            continue;
          }
        }
        return doc;
      }

      function fieldsOf(entry, key, parent) {
        var out = [];
        for (var i = 0; i < entry.fields.length; i++) {
          var f = entry.fields[i];
          if (f.key === key && (parent === undefined || f.parent === parent)) out.push(f);
        }
        return out;
      }
      function firstField(entry, key, parent) {
        var r = fieldsOf(entry, key, parent);
        return r.length ? r[0] : null;
      }

      /* ---------- Grading ---------- */
      function audit(text) {
        var doc = parseKube(text);
        var findings = [];
        function add(sev, entryLabel, line, message) {
          findings.push({ sev: sev, entry: entryLabel, line: line, message: message });
        }
        function nameOf(e) { return e.name === null || e.name === "" ? "(unnamed entry)" : e.name; }

        var sections = [["clusters", "cluster"], ["users", "user"], ["contexts", "context"]];
        var nameMaps = {};
        sections.forEach(function (pair) {
          var sec = pair[0], kind = pair[1];
          var map = {};
          doc[sec].forEach(function (e) {
            if (e.name !== null && e.name !== "") {
              if (map[e.name]) {
                add("WARNING", kind + " “" + e.name + "”", e.nameLine,
                  "Duplicate " + kind + " name “" + e.name + "”: first defined at line " + map[e.name].nameLine + ", again at line " + e.nameLine + ". kubectl will use one of them unpredictably — rename or remove one.");
              } else {
                map[e.name] = e;
              }
            } else {
              add("WARNING", kind + " entry at line " + e.line, e.line,
                "This " + kind + " entry has no name the parser could settle, so nothing can reference it reliably.");
            }
          });
          nameMaps[sec] = map;
        });

        /* Check 1 — current-context and context references */
        var ctxNames = Object.keys(nameMaps.contexts);
        if (doc.currentContext === null) {
          add("BLOCKER", "file (current-context)", doc.currentContextLine,
            "current-context is missing or empty. kubectl would not know which cluster and credentials to use — set current-context to one of the defined contexts" + (ctxNames.length ? " (" + ctxNames.join(", ") + ")" : "") + ".");
        } else if (!nameMaps.contexts[doc.currentContext]) {
          add("BLOCKER", "file (current-context)", doc.currentContextLine,
            "current-context names “" + doc.currentContext + "”, but no context with that name is defined. kubectl will fail until this is fixed.");
        }
        doc.contexts.forEach(function (ctx) {
          var label = "context “" + nameOf(ctx) + "”";
          var cf = firstField(ctx, "cluster", "context");
          var uf = firstField(ctx, "user", "context");
          if (!cf || cf.value === "") {
            add("BLOCKER", label, ctx.line, "This context does not name a cluster.");
          } else if (!nameMaps.clusters[cf.value]) {
            add("BLOCKER", label, cf.line, "This context references cluster “" + cf.value + "”, which is not defined in this file.");
          }
          if (uf && uf.value !== "" && !nameMaps.users[uf.value]) {
            add("BLOCKER", label, uf.line, "This context references user “" + uf.value + "”, which is not defined in this file.");
          }
          /* Check 7a — namespace */
          var ns = firstField(ctx, "namespace", "context");
          if (!ns || ns.value === "") {
            add("INFO", label, ctx.line, "This context sets no namespace, so it defaults to “default”. Fine if intended — set namespace explicitly to be sure.");
          }
        });

        /* Checks 2, 3, 6 — clusters */
        doc.clusters.forEach(function (cl) {
          var label = "cluster “" + nameOf(cl) + "”";
          var tls = firstField(cl, "insecure-skip-tls-verify", "cluster");
          if (tls && /^true$/i.test(tls.value)) {
            add("BLOCKER", label, tls.line, "insecure-skip-tls-verify is true: TLS certificate verification is switched off for this cluster, so anything on the network path can impersonate the API server. Remove it and use a proper certificate authority instead.");
          }
          var srv = firstField(cl, "server", "cluster");
          if (!srv || srv.value === "") {
            add("WARNING", label, cl.line, "This cluster has no server URL the parser could settle.");
          } else if (/^http:\/\//i.test(srv.value)) {
            var host = hostOnly(srv.value);
            var bare = host.replace(/:\d+$/, "").replace(/^\[|\]$/g, "").toLowerCase();
            if (bare === "localhost" || bare === "127.0.0.1" || bare === "::1") {
              add("WARNING", label, srv.line, "server uses plain http:// on " + host + " — local-development only. Acceptable for a cluster on your own machine; never for a shared or remote cluster.");
            } else {
              add("BLOCKER", label, srv.line, "server uses plain http:// (" + host + "): API traffic and credentials cross the network unencrypted. Use the cluster’s https:// endpoint.");
            }
          }
          var caData = firstField(cl, "certificate-authority-data", "cluster");
          if (caData) {
            add("INFO", label, caData.line, "certificate-authority-data is embedded (value hidden; " + caData.value.length + " characters). This is public CA material and is safe to carry in the file.");
          }
          var px = firstField(cl, "proxy-url", "cluster");
          if (px && px.value !== "") {
            add("REVIEW", label, px.line, "proxy-url is set: ALL API traffic for this cluster is routed through proxy host “" + hostOnly(px.value) + "”. Make sure you trust whoever runs that proxy — they can see and alter the traffic.");
          }
        });

        /* Checks 4, 5 — users */
        doc.users.forEach(function (us) {
          var label = "user “" + nameOf(us) + "”";
          var ckd = firstField(us, "client-key-data", "user");
          if (ckd) add("BLOCKER", label, ckd.line, "client-key-data is present: a private key embedded in a shareable file (value never shown; " + ckd.value.length + " characters). Anyone holding this file holds the key — move it to a separate key file (client-key) with tight permissions and treat the embedded copy as compromised.");
          var pw = firstField(us, "password", "user");
          if (pw) add("BLOCKER", label, pw.line, "password is present: a plaintext password embedded in the file (value never shown; " + pw.value.length + " characters). Remove it and use a token, certificate, or exec credential plugin instead.");
          var tok = firstField(us, "token", "user");
          if (tok) add("WARNING", label, tok.line, "token is present: a bearer token embedded in plaintext (value never shown; " + tok.value.length + " characters). Anyone holding this file can act as this user until the token expires or is revoked.");
          var ccd = firstField(us, "client-certificate-data", "user");
          if (ccd) add("WARNING", label, ccd.line, "client-certificate-data is present (value never shown; " + ccd.value.length + " characters). A certificate embedded alongside key material makes this file a complete, ready-to-use credential.");
          ["access-token", "id-token"].forEach(function (k) {
            fieldsOf(us, k).forEach(function (f) {
              if (f.parent === "config" || f.parent === "auth-provider" || f.parent === "user") {
                add("WARNING", label, f.line, "auth-provider entry carries a “" + k + "” value (value never shown; " + f.value.length + " characters). Stored tokens in a kubeconfig are live credentials — expect them to work for anyone holding the file.");
              }
            });
          });

          /* exec plugins */
          if (us.hasExec) {
            var cmd = firstField(us, "command", "exec");
            var im = firstField(us, "interactiveMode", "exec");
            if (!cmd || cmd.value === "") {
              add("WARNING", label, us.line, "This user has an exec: credential plugin, but no command the parser could settle. That plugin will run a program on your machine when the config is used — inspect the raw text before trusting it.");
            } else {
              var cmdVal = cmd.value;
              var args = us.listItems.filter(function (it) { return it.parent === "args"; }).map(function (it) { return it.value; });
              fieldsOf(us, "args").forEach(function () {});
              var tokens = cmdVal.split(/\s+/);
              var base = tokens[0].replace(/^.*[\\\/]/, "").toLowerCase();
              var shellNames = { sh: 1, bash: 1, zsh: 1, dash: 1, ash: 1, "cmd.exe": 1, cmd: 1, powershell: 1, "powershell.exe": 1, pwsh: 1 };
              var hasDashC = tokens.indexOf("-c") >= 0 || args.indexOf("-c") >= 0;
              var isAbs = cmdVal.charAt(0) === "/" || /^[A-Za-z]:[\\\/]/.test(cmdVal) || cmdVal.indexOf("\\\\") === 0;
              var underTmp = /^\/tmp(\/|$)/.test(cmdVal) || /^\/private\/tmp(\/|$)/.test(cmdVal) || /^\/var\/folders\//.test(cmdVal);
              var reason = null;
              if (underTmp) reason = "the command lives under /tmp, where any local process could have planted or replaced it";
              else if (shellNames[base] && hasDashC) reason = "the command is a shell invocation (" + tokens[0] + " -c …), i.e. arbitrary shell code runs when this config is used";
              else if (!isAbs) reason = "the command is a relative path, so which program actually runs depends on your PATH and working directory";
              if (reason) {
                add("BLOCKER", label, cmd.line, "Exec credential plugin command “" + cmdVal + "” escalates to a blocker: " + reason + ". Do not use or share this config until the plugin is replaced with a trusted, absolute-path binary you installed yourself.");
              } else {
                add("WARNING", label, cmd.line, "Exec credential plugin: command “" + cmdVal + "” will run on your machine every time this config fetches credentials. Trust it like a shell script — only use it if you know exactly what it is and where it came from.");
              }
            }
            if (im && /^always$/i.test(im.value)) {
              add("REVIEW", label, im.line, "exec interactiveMode is “Always”: the plugin may prompt interactively whenever credentials are fetched. Expected for some SSO flows, disruptive (and phishable) in scripts — confirm this is the plugin you intended.");
            }
          }
        });

        /* Check 7b — unused entries */
        var usedClusters = {}, usedUsers = {};
        doc.contexts.forEach(function (ctx) {
          var cf = firstField(ctx, "cluster", "context");
          var uf = firstField(ctx, "user", "context");
          if (cf && cf.value) usedClusters[cf.value] = true;
          if (uf && uf.value) usedUsers[uf.value] = true;
        });
        doc.clusters.forEach(function (cl) {
          if (cl.name && !usedClusters[cl.name]) add("INFO", "cluster “" + cl.name + "”", cl.line, "Unused entry candidate: no context references this cluster. Safe to remove if it is not kept for another file.");
        });
        doc.users.forEach(function (us) {
          if (us.name && !usedUsers[us.name]) add("INFO", "user “" + nameOf(us) + "”", us.line, "Unused entry candidate: no context references this user. If it carries credentials, removing it shrinks what a leaked file would expose.");
        });

        /* NOT PARSED */
        doc.notParsed.forEach(function (n) {
          add("NOT PARSED", "line " + n.line, n.line, n.message + " This part of the file was excluded from grading — it was not treated as safe.");
        });

        var counts = { BLOCKER: 0, WARNING: 0, REVIEW: 0, INFO: 0, "NOT PARSED": 0 };
        findings.forEach(function (f) { counts[f.sev]++; });

        var verdict, cls;
        if (counts.BLOCKER > 0) { verdict = "DO NOT USE OR SHARE"; cls = "dont"; }
        else if (counts.WARNING > 0 || counts.REVIEW > 0 || counts["NOT PARSED"] > 0) { verdict = "USE WITH FIXES"; cls = "fix"; }
        else { verdict = "SAFE TO USE"; cls = "safe"; }

        return { verdict: verdict, cls: cls, counts: counts, findings: findings };
      }

      function buildReport(r) {
        var out = [];
        out.push("J-Dawgs Kubeconfig Safety Auditor™ — audit report");
        out.push("Verdict: " + r.verdict);
        out.push("Counts: " + r.counts.BLOCKER + " blocker(s), " + r.counts.WARNING + " warning(s), " + r.counts.REVIEW + " review, " + r.counts.INFO + " info, " + r.counts["NOT PARSED"] + " not parsed.");
        out.push("Credential values are never shown in this report — findings name keys, entries, and line numbers only.");
        out.push("");
        var order = ["BLOCKER", "WARNING", "REVIEW", "INFO", "NOT PARSED"];
        order.forEach(function (sev) {
          var group = r.findings.filter(function (f) { return f.sev === sev; });
          if (!group.length) return;
          out.push("== " + sev + " (" + group.length + ") ==");
          group.forEach(function (f) {
            out.push("[" + sev + "] " + f.entry + (f.line ? " — line " + f.line : "") + ": " + f.message);
          });
          out.push("");
        });
        if (!r.findings.length) out.push("No findings. Nothing dangerous was found in the text of this file.", "");
        out.push("Limits: heuristic text audit only. This tool never connected to a cluster, never ran kubectl, and never executed anything in the file. It cannot judge whether a credential is still valid or what permissions it carries (RBAC lives server-side).");
        return out.join("\n");
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "CLEAN_EXAMPLE": (typeof CLEAN_EXAMPLE !== 'undefined' ? CLEAN_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-kubeconfig-safety-auditortm',
  name: 'J-Dawgs Kubeconfig Safety Auditor',
  description: 'Paste a kubeconfig file; get one verdict (SAFE TO USE / USE WITH FIXES / DO NOT USE OR SHARE) — embedded private keys and tokens flagged by key name only (values never shown), insecure-skip-tls-verify, exec credential plugins, and contexts pointing at missing clusters or users, each located by entry',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "CLEAN_EXAMPLE": __core["CLEAN_EXAMPLE"] }
};
