'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Ansible Playbook Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var RISKY = [
        "---",
        "- name: Risky demo playbook",
        "  hosts: webservers",
        "  become: true",
        "  vars:",
        "    app_dir: /srv/myapp",
        "    admin_password: \"FakePass-4821\"",
        "  tasks:",
        "    - name: Wipe the app directory",
        "      ansible.builtin.shell: rm -rf {{ app_dir }}/*",
        "    - name: Install vendor tool from the internet",
        "      ansible.builtin.shell: curl -fsSL https://example.invalid/install.sh | sh",
        "    - name: Download release archive",
        "      ansible.builtin.get_url:",
        "        url: https://example.invalid/myapp.tar.gz",
        "        dest: /tmp/myapp.tar.gz",
        "    - name: Write the admin config",
        "      ansible.builtin.copy:",
        "        dest: /etc/myapp/admin.conf",
        "        content: \"admin_password={{ admin_password }}\"",
        "      notify: Restart myapp",
        "    - name: Clone helper repo",
        "      ansible.builtin.git:",
        "        repo: https://example.invalid/helper.git",
        "        dest: /opt/helper",
        "  roles:",
        "    - role: vendor.webserver",
        "  handlers:",
        "    - name: Restart other service",
        "      ansible.builtin.service:",
        "        name: othersvc",
        "        state: restarted"
      ].join("\n");

      var CLEAN = [
        "---",
        "- name: Clean demo playbook",
        "  hosts: webservers",
        "  become: false",
        "  vars:",
        "    app_version: \"1.4.2\"",
        "    db_password: \"{{ lookup('ansible.builtin.env', 'APP_DB_PASSWORD') }}\"",
        "  tasks:",
        "    - name: Download release archive",
        "      ansible.builtin.get_url:",
        "        url: https://example.invalid/myapp-1.4.2.tar.gz",
        "        dest: /tmp/myapp-1.4.2.tar.gz",
        "        checksum: sha256:9f2c1a4b5e6d7f8091a2b3c4d5e6f708192a3b4c5d6e7f8091a2b3c4d5e6f7081",
        "    - name: Unpack the release",
        "      ansible.builtin.command: tar -xzf /tmp/myapp-1.4.2.tar.gz -C /opt/myapp",
        "      args:",
        "        creates: /opt/myapp/bin/myapp",
        "    - name: Clone helper repo at a pinned version",
        "      ansible.builtin.git:",
        "        repo: https://example.invalid/helper.git",
        "        dest: /opt/helper",
        "        version: v2.1.0",
        "    - name: Write the app config",
        "      ansible.builtin.template:",
        "        src: myapp.conf.j2",
        "        dest: /etc/myapp/myapp.conf",
        "      no_log: true",
        "      notify: Restart myapp",
        "  roles:",
        "    - role: vendor.webserver",
        "      version: 3.2.1",
        "  handlers:",
        "    - name: Restart myapp",
        "      ansible.builtin.service:",
        "        name: myapp",
        "        state: restarted"
      ].join("\n");

      var SECRET_KEY = /(password|passwd|pwd|token|secret|api[_-]?key|private[_-]?key|access[_-]?key|auth[_-]?token)/i;
      var CMD_MODULES = { shell:1, command:1, raw:1 };
      var KNOWN_MODULES = { shell:1, command:1, raw:1, get_url:1, git:1, copy:1, template:1, file:1,
        user:1, group:1, apt:1, yum:1, dnf:1, package:1, service:1, systemd:1, debug:1, set_fact:1,
        lineinfile:1, blockinfile:1, unarchive:1, archive:1, uri:1, url:1, stat:1, fail:1, assert:1,
        cron:1, mount:1, sysctl:1, pip:1, npm:1, docker_container:1, wait_for:1, pause:1,
        include_tasks:1, import_tasks:1, include_role:1, import_role:1, meta:1, reboot:1 };

      function esc(s){
        return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")
          .replace(/"/g,"&quot;").replace(/'/g,"&#39;");
      }
      function stripQuotes(v){
        v = v.replace(/\s+#.*$/,"").trim();
        if ((v.charAt(0)==='"' && v.charAt(v.length-1)==='"') ||
            (v.charAt(0)==="'" && v.charAt(v.length-1)==="'")){
          v = v.slice(1,-1);
          }
        return v;
      }
      function redact(value){
        var v = stripQuotes(value);
        var head = v.length >= 2 ? v.slice(0,2) : v.slice(0,1);
        return head + "••• (" + v.length + " chars, value not shown)";
      }
      function redactSecretLine(text){
        var m = text.match(/^(\s*[A-Za-z_][\w.-]*\s*:\s*)(\S.*)$/);
        if (m && SECRET_KEY.test(m[1])) return m[1] + redact(m[2]);
        return text;
      }

      function audit(text){
        var findings = [];   // {sev, line, where, msg, fix}
        var notParsed = [];  // {line, name, where}
        var rawLines = String(text).split(/\r?\n/);

        function add(sev, line, where, msg, fix){ findings.push({sev:sev, line:line, where:where, msg:msg, fix:fix}); }
        function addNP(line, name, where){ notParsed.push({line:line, name:name, where:where}); }

        if (!text || !text.replace(/\s/g,"")){
          return { couldNot:true, problemLine:0, problemText:"", reason:"No playbook text was provided — the input is empty." };
        }

        // ---- malformed checks: tabs, unbalanced flow brackets ----
        var i, raw, trimmed, indent;
        var bracketDepth = 0, bracketLine = 0;
        for (i = 0; i < rawLines.length; i++){
          raw = rawLines[i];
          var lead = raw.match(/^[ \t]*/)[0];
          if (lead.indexOf("\t") !== -1){
            return { couldNot:true, problemLine:i+1, problemText:redactSecretLine(raw),
              reason:"Line " + (i+1) + " uses a TAB character for indentation. YAML forbids tabs — replace them with spaces and audit again." };
          }
          var noq = raw.replace(/"[^"]*"/g,'""').replace(/'[^']*'/g,"''");
          for (var c = 0; c < noq.length; c++){
            if (noq.charAt(c) === "["){ if (bracketDepth === 0) bracketLine = i+1; bracketDepth++; }
            if (noq.charAt(c) === "]"){ bracketDepth--; if (bracketDepth < 0){
              return { couldNot:true, problemLine:i+1, problemText:redactSecretLine(raw),
                reason:"Line " + (i+1) + " closes a flow list with ] that was never opened — the YAML structure is broken there." };
            }}
          }
        }
        if (bracketDepth > 0){
          return { couldNot:true, problemLine:bracketLine, problemText:redactSecretLine(rawLines[bracketLine-1] || ""),
            reason:"The flow list opened on line " + bracketLine + " is never closed with ] — the YAML structure is incomplete." };
        }

        // ---- structural scan ----
        var plays = [], tasks = [], entries = [];
        var sawStructure = false;
        var curPlay = null, curSection = null, sectionIndent = -1, curTask = null, curEntry = null;
        var TASK_SECTIONS = { tasks:1, handlers:1, pre_tasks:1, post_tasks:1 };
        var SECTION_KEYS = { tasks:1, handlers:1, pre_tasks:1, post_tasks:1, vars:1, roles:1, collections:1, vars_files:1 };

        function flushTask(){ if (curTask){ tasks.push(curTask); curTask = null; } }
        function flushEntry(){ if (curEntry){ entries.push(curEntry); curEntry = null; } }

        for (i = 0; i < rawLines.length; i++){
          raw = rawLines[i];
          trimmed = raw.replace(/^\s+/,"").replace(/\s+$/,"");
          indent = raw.match(/^ */)[0].length;
          var lineNo = i + 1;
          if (!trimmed || trimmed.charAt(0) === "#") continue;
          if (trimmed === "---" || trimmed === "..."){ continue; }

          // new play: dash item at indent 0
          if (indent === 0 && /^-\s/.test(trimmed)){
            flushTask(); flushEntry();
            sawStructure = true;
            curPlay = { name:"(unnamed play)", line:lineNo, keyIndent:2, lines:[] };
            plays.push(curPlay);
            curSection = null; sectionIndent = -1;
            var pm = trimmed.match(/^-\s+name\s*:\s*(.+)$/);
            if (pm) curPlay.name = stripQuotes(pm[1]);
            curPlay.lines.push({ n:lineNo, raw:raw, trimmed:trimmed, indent:indent });
            continue;
          }
          if (!curPlay){
            // content before any play: start an implicit play context
            curPlay = { name:"(playbook)", line:lineNo, keyIndent:indent + 2, lines:[] };
            plays.push(curPlay);
          }
          var keyIndent = curPlay.keyIndent;

          // play-level key? (play keys sit at keyIndent, shallower than any task or entry content,
          // so this also terminates the current task / entry when a new play key begins)
          var keyMatch = trimmed.match(/^([A-Za-z_][\w.-]*)\s*:\s*(.*)$/);
          if (keyMatch && indent === keyIndent){
            var key = keyMatch[1];
            flushTask(); flushEntry();
            if (key === "name" && curSection === null && curPlay.line !== lineNo){
              curPlay.name = stripQuotes(keyMatch[2]);
            }
            if (key === "hosts" || SECTION_KEYS[key]) sawStructure = true;
            if (SECTION_KEYS[key]){
              curSection = key; sectionIndent = indent;
              curPlay.lines.push({ n:lineNo, raw:raw, trimmed:trimmed, indent:indent });
              continue;
            }
            curSection = null; sectionIndent = -1;
            curPlay.lines.push({ n:lineNo, raw:raw, trimmed:trimmed, indent:indent });
            continue;
          }

          // section content
          if (curSection && TASK_SECTIONS[curSection] && indent > sectionIndent && /^-\s/.test(trimmed)){
            flushTask();
            curTask = { name:null, line:lineNo, section:curSection,
              play:curPlay.name, itemIndent:indent, lines:[] };
            var nm = trimmed.match(/^-\s+name\s*:\s*(.+)$/);
            if (nm) curTask.name = stripQuotes(nm[1]);
            curTask.lines.push({ n:lineNo, raw:raw, trimmed:trimmed, indent:indent });
            continue;
          }
          if (curSection && (curSection === "roles" || curSection === "collections") && indent > sectionIndent && /^-\s/.test(trimmed)){
            flushEntry();
            curEntry = { kind:curSection, line:lineNo, play:curPlay.name, lines:[], name:null };
            var rm1 = trimmed.match(/^-\s+(?:role|src|name)\s*:\s*(\S+)/);
            if (rm1) curEntry.name = rm1[1];
            else { var rm2 = trimmed.match(/^-\s+(\S+)/); if (rm2) curEntry.name = rm2[1]; }
            curEntry.lines.push({ n:lineNo, raw:raw, trimmed:trimmed, indent:indent });
            continue;
          }
          if (curTask && indent > sectionIndent){
            if (!curTask.name && indent === curTask.itemIndent + 2){
              var nm2 = trimmed.match(/^name\s*:\s*(.+)$/);
              if (nm2) curTask.name = stripQuotes(nm2[1]);
            }
            curTask.lines.push({ n:lineNo, raw:raw, trimmed:trimmed, indent:indent });
            continue;
          }
          if (curEntry && indent > sectionIndent){
            curEntry.lines.push({ n:lineNo, raw:raw, trimmed:trimmed, indent:indent });
            continue;
          }
          // play-level line (vars, become, etc.)
          curPlay.lines.push({ n:lineNo, raw:raw, trimmed:trimmed, indent:indent });
        }
        flushTask(); flushEntry();

        if (!tasks.length && !sawStructure){
          var firstBad = 0, firstText = "";
          for (i = 0; i < rawLines.length; i++){
            if (rawLines[i].trim()){ firstBad = i+1; firstText = rawLines[i]; break; }
          }
          return { couldNot:true, problemLine:firstBad, problemText:redactSecretLine(firstText),
            reason:"No play, task, or play-level structure could be found in the pasted text — it does not read as an Ansible playbook." };
        }

        function taskLabel(t){ return 'task "' + (t.name || "(unnamed task)") + '"'; }
        function blockText(lines){ return lines.map(function(l){ return l.trimmed; }).join("\n"); }

        // ---- NOT PARSED constructs ----
        var allContexts = [];
        tasks.forEach(function(t){ t.lines.forEach(function(l){ allContexts.push({ l:l, where:taskLabel(t) }); }); });
        plays.forEach(function(p){ p.lines.forEach(function(l){ allContexts.push({ l:l, where:'play "' + p.name + '"' }); }); });
        var npSeen = {};
        allContexts.forEach(function(ctx){
          var l = ctx.l, key = l.n + ":" + l.trimmed;
          if (npSeen[key]) return;
          if (/\{%/.test(l.trimmed)){
            npSeen[key] = 1;
            addNP(l.n, "Jinja statement block {% … %}", ctx.where);
          }
          var inc = l.trimmed.match(/^(import_playbook|include_tasks|import_tasks|include_role|import_role)\s*:/);
          if (inc){
            npSeen[key] = 1;
            addNP(l.n, inc[1] + " (content lives outside the pasted text)", ctx.where);
          }
        });

        // ---- play-level checks: become, become_user ----
        plays.forEach(function(p){
          p.lines.forEach(function(l){
            if (/^become\s*:\s*true\b/i.test(l.trimmed)){
              add("WARNING", l.n, 'play "' + p.name + '"',
                "Privilege escalation is switched on for the whole play (become: true). Every task in this play runs with elevated rights, including any task added later.",
                "Scope become: true to only the tasks that need it, or drop it and let individual tasks escalate.");
            }
            if (/^become\s*:\s*false\b/i.test(l.trimmed)){
              add("INFO", l.n, 'play "' + p.name + '"',
                "Privilege escalation is explicitly off at play level (become: false).",
                "No change needed.");
            }
            if (/^become_user\s*:\s*root\b/i.test(l.trimmed)){
              add("WARNING", l.n, 'play "' + p.name + '"',
                "The play escalates to the root user (become_user: root).",
                "Escalate to a named service account with only the rights the tasks need, not root.");
            }
          });
        });

        // ---- secrets hygiene: scan every line for secret-named keys ----
        var secretLines = [];
        function scanSecrets(lines, where){
          lines.forEach(function(l){
            var m = l.trimmed.match(/^([A-Za-z_][\w.-]*)\s*:\s*(\S.*)$/);
            if (!m) return;
            if (!SECRET_KEY.test(m[1])) return;
            var val = m[2].trim();
            if (!val || val === "|" || val === ">" || val === "|-" || val === ">-") return;
            if (val.indexOf("{{") !== -1 || val.indexOf("{%") !== -1) return; // reference, not plaintext
            if (/lookup\s*\(/i.test(val) || /vault/i.test(val)) return;
            secretLines.push(l.n);
            add("BLOCKER", l.n, where,
              "Plaintext secret in the playbook: the key \"" + m[1] + "\" is assigned a literal value (" + redact(val) + "). Anyone who can read this playbook — repo history included — has the secret.",
              "Move the value into Ansible Vault or an environment lookup, e.g. " + m[1] + ": \"{{ lookup('ansible.builtin.env', 'NAME') }}\", and rotate the exposed secret.");
          });
        }
        plays.forEach(function(p){ scanSecrets(p.lines, 'play "' + p.name + '" (play level)'); });
        tasks.forEach(function(t){ scanSecrets(t.lines, taskLabel(t)); });

        // ---- per-task checks ----
        var handlerNames = {};
        tasks.forEach(function(t){ if (t.section === "handlers" && t.name) handlerNames[t.name] = true; });

        tasks.forEach(function(t){
          var where = taskLabel(t);
          var text = blockText(t.lines);

          // task-level become / become_user
          t.lines.forEach(function(l){
            if (/^become\s*:\s*true\b/i.test(l.trimmed)){
              add("WARNING", l.n, where,
                "This task escalates privileges (become: true).",
                "Confirm this task truly needs elevation; if it does, keep it and note why in the task name or a comment.");
            }
            if (/^become_user\s*:\s*root\b/i.test(l.trimmed)){
              add("WARNING", l.n, where,
                "This task escalates to the root user (become_user: root).",
                "Use a named service account with only the rights this task needs.");
            }
          });

          // module detection
          var module = null, moduleLine = 0;
          t.lines.forEach(function(l){
            if (module) return;
            var mm = l.trimmed.match(/^(?:-\s+)?([A-Za-z_][\w.]*)\s*:\s*(.*)$/);
            if (!mm) return;
            var base = mm[1].split(".").pop();
            if (KNOWN_MODULES[base] && mm[1] !== "name"){ module = base; moduleLine = l.n; }
          });

          if (module && CMD_MODULES[module]){
            var hasGuard = /\bcreates\s*:/.test(text) || /\bremoves\s*:/.test(text) || /^when\s*:/m.test(text);
            t.lines.forEach(function(l){
              var s = l.trimmed;
              // remote code first
              if (/\b(curl|wget)\b[^|]*\|\s*(sudo\s+)?(sh|bash)\b/.test(s)){
                add("BLOCKER", l.n, where,
                  "Remote code executed blind: this task pipes a curl/wget download straight into a shell. Whatever that URL serves at run time runs on the target with this task's privileges.",
                  "Download the file with get_url plus a checksum, inspect it, and only then run it — or install the software from a pinned package instead.");
                return;
              }
              if (/\bsudo\b/.test(s)){
                add("WARNING", l.n, where,
                  "Sudo-style escalation inside a command line (sudo …) instead of Ansible's become mechanism, so it bypasses Ansible's privilege logging and prompting.",
                  "Drop the inline sudo and use become: true with become_user on this task if elevation is really needed.");
              }
              var dest = null, label = null;
              if (/\brm\s+(-[a-zA-Z]*[rf][a-zA-Z]*\s+)+/.test(s) || /\brm\s+--(recursive|force)\b/.test(s)){ label = "recursive / forced delete (rm)"; }
              else if (/\bdd\b[^#]*\bof=\/dev\//.test(s)){ label = "raw disk write (dd of=/dev/…)"; }
              else if (/\bmkfs(\.[a-z0-9]+)?\b/.test(s)){ label = "filesystem format (mkfs)"; }
              else if (/\bshred\b/.test(s)){ label = "secure erase (shred)"; }
              else if (/\buserdel\b/.test(s)){ label = "account deletion (userdel)"; }
              else if (/>>?\s*\/(etc|boot|usr|bin|sbin|lib|var)\//.test(s) || /\btee\s+(-a\s+)?\/(etc|boot|usr|bin|sbin)\//.test(s)){ label = "write into a system path"; }
              if (label){
                if (s.indexOf("{{") !== -1){
                  add("BLOCKER", l.n, where,
                    "Destructive operation — " + label + " — aimed at a target containing a variable. If that variable expands to empty or \"/\", this command can wipe far more than intended.",
                    "Assert the variable first (assert that it is defined, non-empty, and under an expected prefix), or hard-code the exact target path.");
                } else {
                  add("WARNING", l.n, where,
                    "Destructive operation — " + label + " — in a " + module + " task.",
                    "Prefer the purpose-built Ansible module (file, user) for this, and double-check the target path is exactly what should be removed or overwritten.");
                }
              }
            });
            if (!hasGuard){
              add("WARNING", moduleLine, where,
                "This " + module + " task has no creates:, removes:, or when: guard, so it runs again on every playbook run whether or not anything changed — an idempotency risk that can repeat side effects.",
                "Add args: creates: (or removes:) naming the artifact the command produces, or a when: condition that skips it when the work is already done.");
            } else {
              add("INFO", moduleLine, where,
                "This " + module + " task carries an idempotency guard (creates / removes / when).",
                "No change needed.");
            }
          }

          if (module === "get_url"){
            if (/\bchecksum\s*:/.test(text)){
              add("INFO", moduleLine, where,
                "Download is verified: this get_url task pins a checksum.",
                "No change needed.");
            } else {
              add("WARNING", moduleLine, where,
                "get_url downloads a file with no checksum:, so a changed or compromised file at that URL is installed without any verification.",
                "Add checksum: sha256:… with the digest published by the vendor for that exact file.");
            }
          }

          if (module === "git"){
            if (/\bversion\s*:/.test(text)){
              add("INFO", moduleLine, where,
                "Git checkout is pinned to a version.",
                "No change needed.");
            } else {
              add("WARNING", moduleLine, where,
                "git task checks out whatever the repository's default branch holds at run time — no version: pin, so the code that runs can change between runs.",
                "Add version: with the exact tag or commit you have reviewed.");
            }
          }

          // missing no_log on secret-handling tasks
          var handlesSecret = t.lines.some(function(l){
            var km = l.trimmed.match(/^([A-Za-z_][\w.-]*)\s*:/);
            if (km && SECRET_KEY.test(km[1])) return true;
            var vm = l.trimmed.match(/\{\{[^}]*\}\}/g);
            if (vm){ for (var q = 0; q < vm.length; q++){ if (SECRET_KEY.test(vm[q])) return true; } }
            return false;
          });
          if (handlesSecret && !/no_log\s*:\s*true/i.test(text)){
            add("WARNING", t.line, where,
              "This task handles a secret-named variable but has no no_log: true, so the secret can land in Ansible's console output and logs.",
              "Add no_log: true to this task so the value is masked in output.");
          }
          if (handlesSecret && /no_log\s*:\s*true/i.test(text)){
            add("INFO", t.line, where,
              "Task handles a secret-named variable and correctly sets no_log: true.",
              "No change needed.");
          }

          // notify wiring
          for (var ni = 0; ni < t.lines.length; ni++){
            var nl = t.lines[ni];
            var ntf = nl.trimmed.match(/^notify\s*:\s*(.*)$/);
            if (!ntf) continue;
            var names = [];
            if (ntf[1]){ names.push({ name:stripQuotes(ntf[1]), line:nl.n }); }
            else {
              for (var nj = ni + 1; nj < t.lines.length; nj++){
                var sub = t.lines[nj];
                if (sub.indent > nl.indent && /^-\s+/.test(sub.trimmed)){
                  names.push({ name:stripQuotes(sub.trimmed.replace(/^-\s+/,"")), line:sub.n });
                } else break;
              }
            }
            names.forEach(function(nm2){
              if (nm2.name.indexOf("{{") !== -1){
                addNP(nm2.line, "notify target built from a variable (" + nm2.name + ")", where);
              } else if (!handlerNames[nm2.name]){
                add("WARNING", nm2.line, where,
                  "notify: names the handler \"" + nm2.name + "\", but no handler with that name is defined in the pasted playbook — Ansible fails at run time when this task changes something.",
                  "Define a handler named \"" + nm2.name + "\" in the handlers: section, or fix the notify name to match an existing handler.");
              }
            });
          }
        });

        // ---- roles / collections pinning ----
        entries.forEach(function(e){
          var etext = blockText(e.lines);
          var label = e.kind === "roles" ? "Role" : "Collection";
          if (!/\bversion\s*:/.test(etext)){
            add("WARNING", e.line, 'play "' + e.play + '" (' + e.kind + ")",
              label + " \"" + (e.name || "(unnamed)") + "\" is referenced with no version, so whatever its publisher ships latest is what runs.",
              "Pin it with version: set to the exact release you have reviewed.");
          } else {
            add("INFO", e.line, 'play "' + e.play + '" (' + e.kind + ")",
              label + " \"" + (e.name || "(unnamed)") + "\" is pinned to a version.",
              "No change needed.");
          }
        });

        var counts = { BLOCKER:0, WARNING:0, INFO:0 };
        findings.forEach(function(f){ counts[f.sev]++; });
        findings.sort(function(a,b){ return a.line - b.line; });
        var verdict = counts.BLOCKER > 0 ? "DO NOT RUN" : (counts.WARNING > 0 ? "RUN WITH FIXES" : "SAFE TO RUN");
        return { couldNot:false, verdict:verdict, counts:counts, findings:findings, notParsed:notParsed,
          plays:plays.length, tasks:tasks.length };
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-ansible-playbook-safety-auditor',
  name: 'J-Dawgs Ansible Playbook Safety Auditor',
  description: 'ansible-lint needs an install inside your project and stops at style and correctness diagnostics; ours audits a pasted playbook anywhere and grades whether it is safe to RUN — privilege posture, destructive commands, plaintext secrets by key name only, idempotency — into one run verdict (SAFE TO RUN',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
