'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Loki Log Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var RISKY_CONFIG = [
        "auth_enabled: false",
        "server:",
        "  http_listen_address: 0.0.0.0",
        "  http_listen_port: 3100",
        "  grpc_listen_address: 0.0.0.0",
        "  grpc_listen_port: 9096",
        "limits_config:",
        "  ingestion_rate_mb: 9999",
        "  ingestion_burst_size_mb: 9999",
        "  max_query_lookback: 8760h",
        "compactor:",
        "  retention_enabled: false",
        "storage_config:",
        "  aws:",
        "    bucketnames: my-log-bucket",
        "    access_key_id: AKIAEXAMPLE12345",
        "    secret_access_key: supersecretvalue123",
        "ruler:",
        "  alertmanager_url: http://alertmanager.example.com:9093"
      ].join("\n");

      var HARDENED_CONFIG = [
        "auth_enabled: true",
        "server:",
        "  http_listen_address: 127.0.0.1",
        "  http_listen_port: 3100",
        "  grpc_listen_address: 127.0.0.1",
        "  grpc_listen_port: 9096",
        "  http_tls_config:",
        "    cert_file: /etc/loki/tls.crt",
        "    key_file: /etc/loki/tls.key",
        "  grpc_tls_config:",
        "    cert_file: /etc/loki/tls.crt",
        "    key_file: /etc/loki/tls.key",
        "limits_config:",
        "  ingestion_rate_mb: 4",
        "  ingestion_burst_size_mb: 6",
        "  max_query_lookback: 720h",
        "  retention_period: 720h",
        "compactor:",
        "  retention_enabled: true",
        "storage_config:",
        "  aws:",
        "    bucketnames: my-log-bucket",
        "    region: us-east-1",
        "ruler:",
        "  alertmanager_url: https://alertmanager.example.com:9093"
      ].join("\n");

      function $(id) { return document.getElementById(id); }

      var KNOWN_TOP = {
        "auth_enabled": 1, "server": 1, "limits_config": 1, "compactor": 1,
        "storage_config": 1, "schema_config": 1, "ruler": 1, "distributor": 1,
        "querier": 1, "query_range": 1, "query_scheduler": 1, "ingester": 1,
        "ingester_client": 1, "frontend": 1, "query_frontend": 1, "memberlist": 1,
        "common": 1, "chunk_store_config": 1, "table_manager": 1, "tracing": 1,
        "pattern_ingester": 1, "operational_config": 1, "analytics": 1, "runtime_config": 1
      };
      var KNOWN_CHILD = {
        "http_listen_address": 1, "grpc_listen_address": 1, "retention_enabled": 1,
        "ingestion_rate_mb": 1, "ingestion_rate": 1, "alertmanager_url": 1,
        "http_listen_port": 1, "grpc_listen_port": 1
      };
      var SECRET_KEYS = {
        "access_key_id": 1, "secret_access_key": 1, "secret_key": 1, "password": 1,
        "passwd": 1, "token": 1, "api_key": 1, "client_secret": 1,
        "aws_secret": 1, "secret": 1, "access_key": 1
      };

      function cleanValue(v) {
        v = String(v == null ? "" : v).trim();
        if (v.charAt(0) === '"' || v.charAt(0) === "'") {
          var q = v.charAt(0);
          var end = v.indexOf(q, 1);
          if (end > 0) return v.slice(1, end);
          return v.replace(/^["']|["']$/g, "");
        }
        var hash = v.indexOf(" #");
        if (hash >= 0) v = v.slice(0, hash);
        if (v.charAt(0) === "#") v = "";
        return v.trim().replace(/^["']|["']$/g, "");
      }

      function parseBool(v) {
        var s = String(v == null ? "" : v).toLowerCase();
        if (s === "true" || s === "yes" || s === "on") return true;
        if (s === "false" || s === "no" || s === "off") return false;
        return null;
      }

      // Returns "absent" (key not in file), "all" (all interfaces),
      // "loopback", or "specific" (one named non-loopback interface).
      function classifyAddr(raw) {
        if (raw === null || raw === undefined) return "absent";
        var h = String(raw).trim();
        if (h.charAt(0) === "[") {
          var close = h.indexOf("]");
          if (close >= 0) h = h.slice(1, close);
        } else {
          var first = h.indexOf(":"), last = h.lastIndexOf(":");
          if (first >= 0 && first === last) h = h.slice(0, first);
        }
        h = h.toLowerCase();
        if (h === "" || h === "0.0.0.0" || h === "::" || h === "*" || h === "0:0:0:0:0:0:0:0") return "all";
        if (h === "127.0.0.1" || h === "localhost" || h === "::1" || h === "0:0:0:0:0:0:0:1" || h.indexOf("127.") === 0) return "loopback";
        return "specific";
      }

      function parseHours(v) {
        var m = /^(\d+(?:\.\d+)?)(ms|s|m|h|d|w|y)?$/.exec(String(v == null ? "" : v).trim());
        if (!m) return null;
        var n = parseFloat(m[1]);
        if (!m[2]) return n === 0 ? 0 : null;
        var mult = { ms: 1 / 3600000, s: 1 / 3600, m: 1 / 60, h: 1, d: 24, w: 168, y: 8760 };
        return n * mult[m[2]];
      }

      function audit(text) {
        var findings = [];
        function add(sev, lines, key, msg, fix) {
          var sorted = (lines || []).slice().sort(function (a, b) { return a - b; });
          findings.push({ sev: sev, lines: sorted, key: key || "", msg: msg, fix: fix || "" });
        }

        var rawText = String(text == null ? "" : text);
        var rawLines = rawText.split(/\r?\n/);

        /* ---- Secret scan: EVERY line, key name + line only. The value is
           never copied into any finding, report, or export string. ---- */
        var secretLines = {}; // line number -> key name (lowercase, last segment)
        rawLines.forEach(function (raw, i) {
          var n = i + 1;
          var t = raw.trim();
          if (t === "" || t.charAt(0) === "#") return;
          var m = /^(?:-\s*)?["']?([A-Za-z0-9_.\/-]+)["']?\s*:\s*(.*)$/.exec(t);
          if (!m) return;
          var keyName = m[1].split(".").pop().toLowerCase();
          if (/_file$/.test(keyName) || /_path$/.test(keyName)) return;
          var val = m[2].trim();
          if (val === "" || val === '""' || val === "''") return;
          var unquoted = val.replace(/^["']/, "");
          if (unquoted.charCodeAt(0) === 36) return; // env reference: ${...} or $VAR
          var flagged = !!SECRET_KEYS[keyName] ||
            keyName.indexOf("secret") >= 0 || keyName.indexOf("password") >= 0 ||
            keyName.indexOf("token") >= 0 || keyName.indexOf("access_key") >= 0;
          if (flagged) secretLines[n] = keyName;
        });

        /* ---- Subset structural parse: line-by-line, indentation stack ---- */
        var entries = {};   // path -> {value, line, key, path}
        var entryList = [];
        var stack = [];
        var topSeen = {};
        var recognisedTop = 0;
        var anyKnownChild = false;

        rawLines.forEach(function (raw, i) {
          var n = i + 1;
          var t = raw.trim();
          if (t === "" || t.charAt(0) === "#" || t === "---" || t === "...") return;

          var indentStr = /^[ \t]*/.exec(raw)[0];
          if (indentStr.indexOf("\t") >= 0) {
            add("NOT PARSED", [n], "", "Line " + n + " is indented with a tab. YAML forbids tab indentation and this subset reader does not guess at tab-indented structure, so the line was NOT AUDITED.",
              "Rewrite the indentation with spaces so the line can be graded.");
            return;
          }
          var indent = indentStr.length;

          if (t.charAt(0) === "-" && (t.length === 1 || t.charAt(1) === " ")) {
            add("NOT PARSED", [n], "", "Line " + n + " is a YAML list item. List structures are outside the subset this reader grades, so the line was NOT AUDITED.",
              "If this list carries security-relevant settings, grade them by hand; the rest of the file was still audited.");
            return;
          }

          var km = /^([A-Za-z0-9_.\/-]+)\s*:\s*(.*)$/.exec(t);
          if (!km) {
            add("NOT PARSED", [n], "", "Line " + n + " does not look like a key: value line in the subset this reader understands, so it was NOT AUDITED.",
              "Check the line for typos or unsupported YAML syntax.");
            return;
          }
          var key = km[1];
          var rawVal = km[2];

          if (key === "<<") {
            add("NOT PARSED", [n], key, "Line " + n + " uses a YAML merge key (<<:). Merge keys are NOT PARSED by this subset reader, so anything pulled in by the merge was NOT AUDITED.",
              "Write the merged keys out explicitly so they can be graded.");
            return;
          }

          var unsupported = "";
          var vtrim = rawVal.trim();
          if (vtrim.charAt(0) === "{" || vtrim.charAt(0) === "[") unsupported = "flow-style value";
          else if (/^&[A-Za-z0-9_-]/.test(vtrim) || /^\*[A-Za-z0-9_-]/.test(vtrim)) unsupported = "anchor or alias";
          else if (/^[|>]/.test(vtrim)) unsupported = "multiline string";
          if (unsupported) {
            add("NOT PARSED", [n], key, "Line " + n + " (key \"" + key + "\") uses a " + unsupported + ", which is outside the subset this reader grades. The value was NOT AUDITED.",
              "Rewrite it in plain block style, one key per line, so it can be graded.");
          }
          var value = unsupported ? "" : cleanValue(rawVal);

          while (stack.length && stack[stack.length - 1].indent >= indent) stack.pop();
          var parts = stack.map(function (s) { return s.key; });
          parts.push(key);
          var path = parts.join(".");
          stack.push({ indent: indent, key: key });

          if (indent === 0) {
            if (Object.prototype.hasOwnProperty.call(topSeen, key)) {
              add("NOT PARSED", [topSeen[key], n], key, "Duplicate top-level key \"" + key + "\": first defined at line " + topSeen[key] + ", repeated at line " + n + ". YAML loaders differ on which value wins, so the repeated section is NOT AUDITED as a separate section.",
                "Keep exactly one \"" + key + "\" section and merge the settings into it.");
            } else {
              topSeen[key] = n;
              if (KNOWN_TOP[key]) recognisedTop++;
            }
          }
          if (KNOWN_CHILD[key]) anyKnownChild = true;

          var entry = { value: value, line: n, key: key, path: path };
          entries[path] = entry;
          entryList.push(entry);
        });

        function getE(path) { return entries[path] || null; }

        var recognisedEnough = recognisedTop > 0 || anyKnownChild || !!getE("auth_enabled");

        if (!recognisedEnough) {
          if (rawText.trim() === "") {
            add("INFO", [], "", "The config box was empty - nothing was pasted, so there is nothing to grade.",
              "Paste a Loki config.yaml, or load one of the built-in examples.");
          } else {
            add("INFO", [], "", "No recognisable Loki configuration keys were found in the pasted text, so there is too little to grade. This verdict is not SAFE and not DO NOT DEPLOY - the text simply does not look like a Loki config.",
              "Paste a Loki config.yaml with keys such as auth_enabled, server, limits_config, or compactor.");
          }
        } else {

          /* ---- A. Tenant auth + bind exposure ---- */
          var authE = getE("auth_enabled");
          var authVal = authE ? parseBool(authE.value) : null;
          var httpAddrE = getE("server.http_listen_address");
          var grpcAddrE = getE("server.grpc_listen_address");
          var httpClass = classifyAddr(httpAddrE ? httpAddrE.value : null);
          var grpcClass = classifyAddr(grpcAddrE ? grpcAddrE.value : null);

          function exposedList() {
            var out = [];
            if (httpClass === "all" || httpClass === "specific") out.push({ label: "server.http_listen_address", proto: "HTTP", e: httpAddrE });
            if (grpcClass === "all" || grpcClass === "specific") out.push({ label: "server.grpc_listen_address", proto: "gRPC", e: grpcAddrE });
            return out;
          }

          if (authE && authVal === false) {
            var exposed = exposedList();
            if (exposed.length) {
              exposed.forEach(function (x) {
                add("BLOCKER", [authE.line, x.e.line], "auth_enabled + " + x.label,
                  "auth_enabled is false (line " + authE.line + ") and " + x.label + " binds \"" + x.e.value + "\" (line " + x.e.line + ") - a non-loopback bind. With tenant auth off, anyone who can reach this " + x.proto + " listener can read and write every tenant's logs.",
                  "Set auth_enabled: true so requests must carry a tenant ID, or bind the listener to 127.0.0.1 and reach it only through a controlled, authenticating proxy.");
              });
            } else if (httpClass === "loopback" || grpcClass === "loopback") {
              add("WARNING", [authE.line], "auth_enabled",
                "auth_enabled is false (line " + authE.line + "), but every listen address shown in this file binds loopback only, so the unauthenticated API is reachable only from this host. The posture still breaks the moment any listener is bound wider.",
                "Set auth_enabled: true so tenant isolation does not depend on the bind address staying loopback.");
            } else {
              add("WARNING", [authE.line], "auth_enabled",
                "auth_enabled is false (line " + authE.line + ") and no listen address appears in this file, so this audit cannot prove the bind is loopback-only. If the server binds all interfaces, anyone who can reach it can read and write every tenant's logs.",
                "Set auth_enabled: true, and pin the server listen addresses to 127.0.0.1 unless the server sits behind an authenticating proxy.");
            }
          } else if (authE && authVal === true) {
            add("INFO", [authE.line], "auth_enabled",
              "auth_enabled is true (line " + authE.line + "): tenant authentication is on, so requests must carry a tenant ID (X-Scope-OrgID) and tenants are isolated from each other.",
              "No change needed.");
          } else {
            var exposedAny = exposedList();
            var amsg = "auth_enabled is not set in this file" +
              (authE ? " (the value at line " + authE.line + " was not a recognisable true/false)" : "") +
              ". Loki applies its own built-in default, and this audit cannot confirm the tenant-auth posture from the pasted file - auth is NOT AUDITED from this file.";
            if (exposedAny.length) {
              var x0 = exposedAny[0];
              amsg += " That matters here: " + x0.label + " binds \"" + x0.e.value + "\" (line " + x0.e.line + "), a non-loopback bind, so if the running default has auth off, the server is open to anyone who can reach it. Treat it as exposed until proven otherwise.";
            }
            add("WARNING", authE ? [authE.line] : [], "auth_enabled", amsg,
              "Set auth_enabled: true explicitly in the config so the posture is stated in the file, not left to a default.");
          }

          /* ---- B. TLS posture ---- */
          function tlsCheck(proto, sectionPath, addrClass) {
            var sec = getE(sectionPath);
            var cert = getE(sectionPath + ".cert_file") || getE(sectionPath + ".cert_path");
            var keyf = getE(sectionPath + ".key_file") || getE(sectionPath + ".key_path");
            var hasCert = !!(cert && cert.value !== "");
            var hasKey = !!(keyf && keyf.value !== "");
            if (!sec) {
              var sev = (authVal === false && (addrClass === "all" || addrClass === "specific")) ? "BLOCKER" : "WARNING";
              add(sev, [], sectionPath,
                "No " + sectionPath + " in this file: the " + proto + " listener serves plaintext, so log data and any credentials cross the network unencrypted" +
                (sev === "BLOCKER" ? " - and combined with auth off on a non-loopback bind, that is open, unencrypted access to every tenant's logs." : "."),
                "Add " + sectionPath + " with cert_file and key_file (or cert_path and key_path) pointing at the TLS certificate and key.");
              return;
            }
            if (hasCert && hasKey) {
              add("INFO", [sec.line], sectionPath,
                sectionPath + " is configured with both a certificate (line " + cert.line + ") and a key (line " + keyf.line + "): the " + proto + " listener serves TLS.",
                "No change needed. Keep the key file's permissions tight on the host.");
            } else if (hasCert || hasKey) {
              add("WARNING", [sec.line], sectionPath,
                sectionPath + " is only partly configured: " + (hasCert ? "a certificate is set but no key appears" : "a key is set but no certificate appears") + " in this file. TLS is NOT fully configured.",
                "Set both cert_file and key_file (or cert_path and key_path) under " + sectionPath + ".");
            } else {
              add("WARNING", [sec.line], sectionPath,
                sectionPath + " is present but names no certificate or key in this file, so TLS is NOT fully configured.",
                "Add cert_file and key_file (or cert_path and key_path) under " + sectionPath + ".");
            }
          }
          tlsCheck("HTTP", "server.http_tls_config", httpClass);
          tlsCheck("gRPC", "server.grpc_tls_config", grpcClass);

          /* ---- C. limits_config posture ---- */
          var limitsSec = getE("limits_config");
          var retentionPeriodE = getE("limits_config.retention_period") || getE("compactor.retention_period");
          if (!limitsSec) {
            add("WARNING", [], "limits_config",
              "No limits_config section in this file: ingestion and query limits are not explicitly set. Loki's built-in defaults apply, but the posture is not stated in this file and was NOT AUDITED beyond that.",
              "Add a limits_config section with explicit ingestion_rate_mb, ingestion_burst_size_mb, and max_query_lookback values sized for your host.");
          } else {
            var ingKeys = ["ingestion_rate_mb", "ingestion_rate", "ingestion_burst_size_mb", "ingestion_burst_size"];
            var anyIng = false;
            ingKeys.forEach(function (k) {
              var e = getE("limits_config." + k);
              if (!e) return;
              anyIng = true;
              var num = parseFloat(e.value);
              if (isNaN(num)) return;
              if (num >= 1000) {
                add("WARNING", [e.line], "limits_config." + k,
                  k + " is " + e.value + " at line " + e.line + " - so high it is effectively wide open. One noisy tenant can flood ingestion and fill the disk.",
                  "Set " + k + " to a bounded value sized for your host and tenants.");
              } else {
                add("INFO", [e.line], "limits_config." + k,
                  k + " is set to a bounded value (" + e.value + ") at line " + e.line + ".",
                  "No change needed.");
              }
            });
            if (!anyIng) {
              add("INFO", [limitsSec.line], "limits_config",
                "limits_config is present but sets no ingestion rate limit in this file (ingestion_rate_mb / ingestion_burst_size_mb are not set in this file).",
                "Set explicit ingestion limits if you want the posture stated in the file.");
            }
            var lb = getE("limits_config.max_query_lookback");
            if (!lb) {
              add("INFO", [limitsSec.line], "limits_config.max_query_lookback",
                "max_query_lookback is not set in this file, so queries are not bounded by an explicit lookback here.",
                "Set max_query_lookback (for example 720h) to bound how far back a single query can reach.");
            } else {
              var hrs = parseHours(lb.value);
              if (hrs !== null && hrs >= 8760) {
                add("WARNING", [lb.line], "limits_config.max_query_lookback",
                  "max_query_lookback is " + lb.value + " at line " + lb.line + " - a year or more. A single query can scan a year of logs and swamp the querier.",
                  "Lower max_query_lookback to the longest window anyone legitimately queries.");
              } else if (hrs !== null && hrs === 0) {
                add("INFO", [lb.line], "limits_config.max_query_lookback",
                  "max_query_lookback is 0 at line " + lb.line + ", so this setting applies no explicit lookback bound.",
                  "Set a bounded max_query_lookback if you want query reach limited by the file.");
              } else if (hrs !== null) {
                add("INFO", [lb.line], "limits_config.max_query_lookback",
                  "max_query_lookback is bounded at " + lb.value + " (line " + lb.line + ").",
                  "No change needed.");
              }
            }
            var qp = getE("limits_config.max_query_parallelism");
            if (qp) {
              add("INFO", [qp.line], "limits_config.max_query_parallelism",
                "max_query_parallelism is set to " + qp.value + " at line " + qp.line + " (recorded as context).",
                "No change needed.");
            }
          }

          /* ---- D. Retention / compactor posture ---- */
          var reE = getE("compactor.retention_enabled");
          var compSec = getE("compactor");
          var reVal = reE ? parseBool(reE.value) : null;
          if (!reE) {
            add("WARNING", compSec ? [compSec.line] : [], "compactor.retention_enabled",
              "compactor.retention_enabled is not set in this file, so log retention is not enabled here. Unless retention is handled somewhere this file cannot show, stored logs are never expired and disk usage grows without bound - retention NOT AUDITED beyond this file.",
              "Set compactor.retention_enabled: true and a retention_period so old logs expire on schedule.");
          } else if (reVal === false) {
            add("WARNING", [reE.line], "compactor.retention_enabled",
              "retention_enabled is false at line " + reE.line + ": retention is disabled, so log data is never expired and disk fills forever.",
              "Set retention_enabled: true and a retention_period (in limits_config or compactor) sized to how long you keep logs.");
          } else if (reVal === true) {
            if (retentionPeriodE) {
              add("INFO", [reE.line, retentionPeriodE.line], "compactor.retention_enabled",
                "retention_enabled is true (line " + reE.line + ") and a retention_period of " + retentionPeriodE.value + " is set at line " + retentionPeriodE.line + ": old logs expire on schedule.",
                "No change needed.");
            } else {
              add("WARNING", [reE.line], "compactor.retention_enabled",
                "retention_enabled is true at line " + reE.line + ", but no retention_period appears anywhere in this file, so the retention window is NOT AUDITED from this file.",
                "Set retention_period in limits_config (or compactor) so the expiry window is explicit.");
            }
          } else {
            add("WARNING", [reE.line], "compactor.retention_enabled",
              "retention_enabled at line " + reE.line + " has a value this reader could not grade as true or false - retention posture NOT AUDITED.",
              "Set retention_enabled: true with an explicit retention_period.");
          }

          /* ---- F. Ruler / Alertmanager endpoints ---- */
          var amFound = false;
          entryList.forEach(function (e) {
            if (e.key !== "alertmanager_url") return;
            amFound = true;
            if (/^http:\/\//i.test(e.value)) {
              add("WARNING", [e.line], e.path,
                "alertmanager_url at line " + e.line + " uses plain http:// - alert traffic to Alertmanager crosses the network unencrypted.",
                "Use an https:// alertmanager_url.");
            } else if (/^https:\/\//i.test(e.value)) {
              add("INFO", [e.line], e.path,
                "alertmanager_url at line " + e.line + " uses https:// - the ruler reaches Alertmanager over TLS.",
                "No change needed.");
            } else {
              add("INFO", [e.line], e.path,
                "alertmanager_url is set at line " + e.line + " (its scheme was not graded from this value).",
                "Prefer an https:// URL.");
            }
          });
          var rulerSec = getE("ruler");
          if (!rulerSec) {
            add("INFO", [], "ruler",
              "No ruler section in this file: the ruler is not configured here. That is not a failure - alerting rules may live elsewhere or be unused.",
              "No change needed.");
          } else if (!amFound) {
            add("INFO", [rulerSec.line], "ruler",
              "A ruler section is present but sets no alertmanager_url in this file, so no Alertmanager endpoint was graded.",
              "No change needed.");
          }

          /* ---- G. Ports recorded; missing sections are NOT AUDITED, not failures ---- */
          [["server.http_listen_port", "HTTP"], ["server.grpc_listen_port", "gRPC"]].forEach(function (p) {
            var e = getE(p[0]);
            if (e) {
              add("INFO", [e.line], p[0],
                p[1] + " listen port " + e.value + " recorded at line " + e.line + ".",
                "No change needed.");
            }
          });
          if (!getE("schema_config")) {
            add("INFO", [], "schema_config",
              "schema_config is not present in the pasted file - NOT AUDITED. A pasted partial config may rely on defaults or another file.",
              "Paste the full config if you want the schema graded.");
          }
          if (!getE("storage_config")) {
            add("INFO", [], "storage_config",
              "storage_config is not present in the pasted file - NOT AUDITED. A pasted partial config may rely on defaults or another file.",
              "Paste the full config if you want the storage settings graded.");
          }
        }

        /* ---- E. Inline credentials (findings built from key names only) ---- */
        Object.keys(secretLines).forEach(function (ln) {
          var n = parseInt(ln, 10);
          add("BLOCKER", [n], secretLines[ln],
            "Plaintext credential under key \"" + secretLines[ln] + "\" at line " + n + ". The value is never shown by this tool. A secret written into config.yaml is exposed to anyone who can read the file or any repo, backup, or ticket it has passed through.",
            "Remove the inline value and inject the credential from the environment or a secret manager instead; rotate the credential, because it has been written down in plaintext.");
        });

        /* ---- Sort, count, verdict ---- */
        var order = { "BLOCKER": 0, "WARNING": 1, "NOT PARSED": 2, "INFO": 3 };
        findings.sort(function (a, b) {
          if (order[a.sev] !== order[b.sev]) return order[a.sev] - order[b.sev];
          var la = a.lines.length ? Math.min.apply(null, a.lines) : 99999;
          var lb2 = b.lines.length ? Math.min.apply(null, b.lines) : 99999;
          return la - lb2;
        });

        var counts = { "BLOCKER": 0, "WARNING": 0, "INFO": 0, "NOT PARSED": 0 };
        findings.forEach(function (f) { counts[f.sev]++; });

        var verdict, verdictClass, verdictNote;
        if (!recognisedEnough) {
          verdict = "NOT ENOUGH TO GRADE"; verdictClass = "not-enough";
          verdictNote = "Too little recognisable Loki configuration was found in the pasted text to grade it. That is an honest no-grade, not a pass and not a fail.";
        } else if (counts["BLOCKER"] > 0) {
          verdict = "DO NOT DEPLOY"; verdictClass = "do-not";
          verdictNote = counts["BLOCKER"] + " blocker" + (counts["BLOCKER"] === 1 ? "" : "s") + " must be fixed before this config goes live.";
        } else if (counts["WARNING"] > 0) {
          verdict = "DEPLOY WITH FIXES"; verdictClass = "with-fixes";
          verdictNote = "No blockers, but " + counts["WARNING"] + " warning" + (counts["WARNING"] === 1 ? "" : "s") + " should be fixed before or alongside deploy.";
        } else if (counts["NOT PARSED"] > 0) {
          verdict = "DEPLOY WITH FIXES"; verdictClass = "with-fixes";
          verdictNote = "Everything parsed graded clean, but " + counts["NOT PARSED"] + " line" + (counts["NOT PARSED"] === 1 ? "" : "s") + " could not be parsed by the subset reader and were NOT AUDITED - an unparsed remainder is never hidden behind a clean verdict.";
        } else {
          var authOk = !!getE("auth_enabled") && parseBool(getE("auth_enabled").value) === true;
          var listenerOk = !!getE("server.http_listen_address") || !!getE("server.grpc_listen_address");
          var otherOk = !!getE("limits_config") || !!getE("compactor") || !!getE("storage_config") || !!getE("schema_config") || !!getE("ruler");
          if (authOk && listenerOk && otherOk) {
            verdict = "SAFE TO DEPLOY"; verdictClass = "safe";
            verdictNote = "No graded risks found in the pasted text. That is not proof the deployment is secure - see Honest limits.";
          } else {
            verdict = "DEPLOY WITH FIXES"; verdictClass = "with-fixes";
            verdictNote = "Everything parsed graded clean, but too little of the config (auth, listeners, and at least one more section) was present in the pasted text to call it safe.";
          }
        }

        return {
          verdict: verdict, verdictClass: verdictClass, verdictNote: verdictNote,
          findings: findings, counts: counts
        };
      }

      function whereOf(f) {
        if (!f.lines.length) return "File";
        if (f.lines.length === 1) return "Line " + f.lines[0];
        return "Lines " + f.lines.join(" & ");
      }

      function buildReport(result) {
        var lines = [];
        lines.push("J-Dawgs Loki Log Server Config Safety Auditor - audit report");
        lines.push("Verdict: " + result.verdict);
        lines.push("Counts: " + result.counts["BLOCKER"] + " BLOCKER, " + result.counts["WARNING"] + " WARNING, " +
                   result.counts["NOT PARSED"] + " NOT PARSED, " + result.counts["INFO"] + " INFO");
        lines.push("");
        if (result.findings.length === 0) {
          lines.push("No findings.");
        } else {
          result.findings.forEach(function (f) {
            lines.push("[" + f.sev + "] " + whereOf(f) + (f.key ? " (" + f.key + ")" : "") + " - " + f.msg + (f.fix ? " Fix: " + f.fix : ""));
          });
        }
        lines.push("");
        lines.push("Limits: subset YAML reading of the pasted file only - not a full YAML parser, and not a grade of the running server, network, or firewall. Secret values are never printed; credentials are flagged by key name and line only.");
        return lines.join("\n");
      }

      function buildJson(result) {
        var obj = {
          tool: "J-Dawgs Loki Log Server Config Safety Auditor",
          verdict: result.verdict,
          counts: {
            "BLOCKER": result.counts["BLOCKER"],
            "WARNING": result.counts["WARNING"],
            "INFO": result.counts["INFO"],
            "NOT PARSED": result.counts["NOT PARSED"]
          },
          findings: result.findings.map(function (f) {
            return {
              severity: f.sev,
              lines: f.lines,
              key: f.key,
              finding: f.msg,
              fix: f.fix
            };
          })
        };
        return JSON.stringify(obj, null, 2);
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-loki-log-server-config-safety-auditor',
  name: 'J-Dawgs Loki Log Server Config Safety Auditor',
  description: 'Loki\'s config checks only answer will-it-load; ours grades a pasted config.yaml anywhere — tenant auth, listener exposure, TLS, retention — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
