'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Emby Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Worked examples ---------- */
      var RISKY_EXAMPLE = [
        '<?xml version="1.0" encoding="utf-8"?>',
        '<ServerConfiguration>',
        '  <ServerName>Home Media Server</ServerName>',
        '  <BindAddress>0.0.0.0</BindAddress>',
        '  <AllowRemoteAccess>true</AllowRemoteAccess>',
        '  <RequireHttps>false</RequireHttps>',
        '  <CustomCertificatePath></CustomCertificatePath>',
        '  <PublicPort>8096</PublicPort>',
        '  <PublicBaseUrl>http://media.example-home.net:8096</PublicBaseUrl>',
        '  <EnableUPnP>true</EnableUPnP>',
        '  <EnableAutomaticPortMapping>true</EnableAutomaticPortMapping>',
        '  <EnableDlna>true</EnableDlna>',
        '  <EnableEasyPassword>true</EnableEasyPassword>',
        '  <PasswordPolicy>none</PasswordPolicy>',
        '  <BypassAuthenticationOnLocalNetwork>true</BypassAuthenticationOnLocalNetwork>',
        '  <EnableDebugLogging>true</EnableDebugLogging>',
        '  <LogLevel>Debug</LogLevel>',
        '  <EnableAutomaticPluginInstall>true</EnableAutomaticPluginInstall>',
        '  <EnableAutoUpdate>true</EnableAutoUpdate>',
        '  <ApiKey>emby_example_key_123</ApiKey>',
        '  <AdminPassword>PlaintextPass!2026</AdminPassword>',
        '  <RemoteAccessToken>tok_abc123</RemoteAccessToken>',
        '</ServerConfiguration>'
      ].join("\n");

      var HARDENED_EXAMPLE = [
        '<?xml version="1.0" encoding="utf-8"?>',
        '<ServerConfiguration>',
        '  <ServerName>Home Media Server</ServerName>',
        '  <BindAddress>192.168.1.20</BindAddress>',
        '  <AllowRemoteAccess>false</AllowRemoteAccess>',
        '  <RequireHttps>true</RequireHttps>',
        '  <CustomCertificatePath>/etc/emby/certs/server.pfx</CustomCertificatePath>',
        '  <PublicPort>8920</PublicPort>',
        '  <EnableUPnP>false</EnableUPnP>',
        '  <EnableAutomaticPortMapping>false</EnableAutomaticPortMapping>',
        '  <EnableDlna>false</EnableDlna>',
        '  <EnableEasyPassword>false</EnableEasyPassword>',
        '  <PasswordPolicy>strong</PasswordPolicy>',
        '  <MinimumPasswordLength>14</MinimumPasswordLength>',
        '  <BypassAuthenticationOnLocalNetwork>false</BypassAuthenticationOnLocalNetwork>',
        '  <EnableDebugLogging>false</EnableDebugLogging>',
        '  <LogLevel>Information</LogLevel>',
        '  <EnableAutomaticPluginInstall>false</EnableAutomaticPluginInstall>',
        '  <EnableAutoUpdate>false</EnableAutoUpdate>',
        '</ServerConfiguration>'
      ].join("\n");

      /* Planted secret values in the risky example. The self-test proves none
         of these strings ever reach a finding, the report, or the JSON. */
      var PLANTED_SECRETS = ["emby_example_key_123", "PlaintextPass!2026", "tok_abc123"];

      /* ---------- Parsing helpers ---------- */
      function isTrue(v) { return /^(true|yes|on|enabled|enable|1)$/i.test(String(v).trim()); }
      function isFalse(v) { return /^(false|no|off|disabled|disable|0)$/i.test(String(v).trim()); }

      function parseLine(raw) {
        var line = raw.trim();
        if (!line) return null;
        var m = line.match(/<([A-Za-z][\w.\-]*)>([^<]*)<\/\1>/);
        if (m) return { key: m[1], value: m[2].trim() };
        m = line.match(/^"?([A-Za-z][\w.\-]*)"?\s*[:=]\s*"?([^",}]+)"?,?$/);
        if (m) return { key: m[1], value: m[2].trim() };
        return null;
      }

      function looksLikeConfigLine(raw) {
        var line = raw.trim();
        if (!line) return false;
        if (/^<\/?[A-Za-z][^>]*>$/.test(line) || /^<\?xml/.test(line)) return true;
        if (parseLine(line)) return true;
        return false;
      }

      /* ---------- The audit ---------- */
      function auditConfig(text) {
        var lines = String(text == null ? "" : text).split(/\r?\n/);
        var entries = [];
        var configLines = 0;
        var nonEmpty = 0;
        for (var i = 0; i < lines.length; i++) {
          if (lines[i].trim()) nonEmpty++;
          if (looksLikeConfigLine(lines[i])) configLines++;
          var p = parseLine(lines[i]);
          if (p) entries.push({ key: p.key, keyLower: p.key.toLowerCase(), value: p.value, line: i + 1 });
        }

        if (nonEmpty === 0 || configLines === 0) {
          return {
            verdict: "NOT ENOUGH TO GRADE",
            reason: nonEmpty === 0
              ? "The paste is empty — there is nothing to grade."
              : "The paste reads as plain prose, not a config: no settings lines (XML elements or key = value pairs) were found.",
            findings: [],
            linesAudited: lines.length,
            settingsFound: entries.length
          };
        }

        var findings = [];
        function add(line, severity, check, key, detail, fix) {
          findings.push({ line: line, severity: severity, check: check, key: key || null, detail: detail, fix: fix });
        }
        function find(keyLower) {
          for (var j = 0; j < entries.length; j++) if (entries[j].keyLower === keyLower) return entries[j];
          return null;
        }
        function findMatching(re) {
          var out = [];
          for (var j = 0; j < entries.length; j++) if (re.test(entries[j].keyLower)) out.push(entries[j]);
          return out;
        }

        var remoteEntries = findMatching(/remoteaccess/);
        var remoteOn = null;
        for (var r = 0; r < remoteEntries.length; r++) if (isTrue(remoteEntries[r].value)) remoteOn = remoteEntries[r];

        var requireHttps = find("requirehttps");
        var httpsRequired = !!(requireHttps && isTrue(requireHttps.value));
        var certPath = find("customcertificatepath") || find("certificatepath");
        var hasCert = !!(certPath && certPath.value.length > 0);

        entries.forEach(function (e) {
          var k = e.keyLower, v = e.value;

          /* Wildcard / all-interface bind */
          if (/(bind|listen|interface|hostaddress|localnetworkaddress)/.test(k) &&
              /(^|\s|["'])(0\.0\.0\.0|::|\*|all)(["']|\s|$)/i.test(v)) {
            add(e.line, "CRITICAL", "Wildcard / all-interface bind", e.key,
              "This bind setting listens on every network interface, not just the local machine or LAN.",
              "Bind to one specific LAN address, or leave remote exposure to a hardened reverse proxy.");
          }

          /* Remote access flag on its own */
          if (/remoteaccess/.test(k) && isTrue(v)) {
            add(e.line, "HIGH", "Remote access enabled", e.key,
              "Remote access is switched on, so the server accepts connections from outside the local network.",
              "Turn remote access off unless you actively need it, and put any remote use behind HTTPS and strong sign-in.");
          }

          /* RequireHttps explicitly off */
          if (k === "requirehttps" && isFalse(v)) {
            add(e.line, "HIGH", "HTTPS not required", e.key,
              "RequireHttps is off, so sessions — including sign-in — can run over plain HTTP.",
              "Set RequireHttps to true and configure a certificate the clients trust.");
          }

          /* Certificate path present but empty */
          if ((k === "customcertificatepath" || k === "certificatepath") && v.length === 0) {
            add(e.line, "MEDIUM", "No custom certificate configured", e.key,
              "The custom certificate path is empty, so the server has no certificate of its own for HTTPS.",
              "Point this at a valid certificate file, or terminate HTTPS at a reverse proxy that has one.");
          }

          /* Public address over plain HTTP */
          if (/(public|wan|external|ddns|baseurl|remoteurl)/.test(k) && /^http:\/\//i.test(v)) {
            add(e.line, "HIGH", "Public address over plain HTTP", e.key,
              "A public-facing address is written as an http:// URL, so traffic to it is unencrypted.",
              "Use an https:// address for anything reachable from outside the LAN.");
          }

          /* Authentication weaknesses */
          if (/(easypassword|easylogin|pinlogin|pinmode)/.test(k) && isTrue(v)) {
            add(e.line, "HIGH", "Easy-password / PIN-style sign-in enabled", e.key,
              "A simplified sign-in mode is on, which weakens account protection — especially with remote access.",
              "Disable easy-password sign-in and require full passwords.");
          }
          if (k === "requirepassword" && isFalse(v)) {
            add(e.line, "HIGH", "Passwords not required", e.key,
              "Accounts are not required to have a password.",
              "Require a password on every account.");
          }
          if (k === "passwordpolicy" && /^(none|off|disabled|weak|no)$/i.test(v)) {
            add(e.line, "HIGH", "No password policy", e.key,
              "The password policy is effectively switched off, so weak passwords are accepted.",
              "Set a real password policy and a minimum length of at least 12 characters.");
          }
          if (/minimumpasswordlength|minpasswordlength/.test(k)) {
            var n = parseInt(v, 10);
            if (!isNaN(n) && n < 10) {
              add(e.line, "MEDIUM", "Short minimum password length", e.key,
                "The minimum password length is set below 10 characters.",
                "Raise the minimum password length to at least 12.");
            }
          }
          if (/(disabledauth|authenticationdisabled|noauthentication)/.test(k) && isTrue(v)) {
            add(e.line, "CRITICAL", "Authentication disabled", e.key,
              "Authentication is disabled outright — anyone who can reach the server is effectively signed in.",
              "Re-enable authentication before this config goes anywhere near a network.");
          }
          if (/(allowblankpassword|blankpasswordallowed|emptypassword)/.test(k) && isTrue(v)) {
            add(e.line, "CRITICAL", "Blank passwords allowed", e.key,
              "Blank passwords are permitted, which is the same as no password on affected accounts.",
              "Disallow blank passwords.");
          }
          if (/(guest|anonymous)/.test(k) && /(access|login|enabled)/.test(k) && isTrue(v)) {
            add(e.line, "HIGH", "Guest / anonymous access enabled", e.key,
              "Unauthenticated guest or anonymous access is switched on.",
              "Disable guest and anonymous access; give every viewer a named account.");
          }

          /* Local-network authentication bypass */
          if ((/bypass/.test(k) && /(auth|login|local)/.test(k) && isTrue(v)) ||
              (/(localnetwork|lan)/.test(k) && /(bypass|skipauth|noauth|trusted)/.test(k) && isTrue(v)) ||
              (k === "enablelocalnetworkauthentication" && isFalse(v))) {
            add(e.line, "CRITICAL", "Local-network authentication bypass", e.key,
              "Clients on the local network skip or bypass authentication, so anything on the LAN — including a compromised device or a guest — reaches the library unauthenticated.",
              "Require authentication on the local network too; treat the LAN as untrusted.");
          }

          /* Discovery & mapping exposure */
          if (/upnp/.test(k) && isTrue(v)) {
            add(e.line, "HIGH", "UPnP exposure enabled", e.key,
              "UPnP is on, letting the server ask the router to open inbound paths automatically.",
              "Disable UPnP on the server and the router; open ports deliberately, if at all.");
          }
          if (/(portmapping|automaticport)/.test(k) && isTrue(v)) {
            add(e.line, "HIGH", "Automatic port mapping enabled", e.key,
              "Automatic port mapping can publish the server to the internet without a manual, reviewed change.",
              "Turn automatic port mapping off and manage any forwarding by hand.");
          }
          if (/dlna/.test(k) && isTrue(v)) {
            add(e.line, "MEDIUM", "DLNA media sharing enabled", e.key,
              "DLNA advertises and serves media to devices on the network with no account sign-in.",
              "Disable DLNA unless you deliberately use it on a trusted LAN.");
          }

          /* Change control */
          if (/(automaticplugininstall|installpluginsautomatically|autoplugin)/.test(k) && isTrue(v)) {
            add(e.line, "MEDIUM", "Automatic plugin installation enabled", e.key,
              "Plugins can be installed automatically, changing what the server runs without a reviewed step.",
              "Install plugins manually so every addition is a deliberate choice.");
          }
          if (/(autoupdate|automaticupdate|automaticupdates)/.test(k) && isTrue(v)) {
            add(e.line, "MEDIUM", "Automatic updates enabled", e.key,
              "The server can update itself automatically, so the running version can change without review.",
              "Update on your own schedule, after reading what changed.");
          }

          /* Debug / verbose logging */
          if (/(debug|verbose)/.test(k) && isTrue(v)) {
            add(e.line, "MEDIUM", "Debug / verbose logging on", e.key,
              "Verbose logging is on; debug logs commonly record paths, usernames, and request details you do not want sitting on disk.",
              "Return logging to the normal level for day-to-day running.");
          }
          if (k === "loglevel" && /^(debug|verbose|trace)$/i.test(v)) {
            add(e.line, "MEDIUM", "Debug log level set", e.key,
              "The log level is set to a debug-class level, which records far more detail than normal operation needs.",
              "Set the log level back to Information (or your platform's normal level).");
          }

          /* Secrets — reported by key name, line, and length ONLY */
          var isSecretKey = /(apikey|api_key|accesstoken|refreshtoken|token|secret|password|passwd|credential|privatekey)/.test(k) &&
                            !/(policy|length|require|easy|bypass|history|hint|reset|policy)/.test(k);
          if (isSecretKey && v.length > 0 && !/^(true|false)$/i.test(v)) {
            var len = v.length;
            var looksExample = /(example|changeme|change_me|default|sample|test|1234|xxxx|your[-_ ]?key)/i.test(v);
            if (/key/.test(k) && (len < 24 || looksExample)) {
              add(e.line, "CRITICAL", "Short or example API key", e.key,
                "Key \"" + e.key + "\" on this line holds a value of length " + len + (looksExample ? " that looks like a placeholder/example value" : ", shorter than a real generated key") + ". The value itself is never shown in this audit.",
                "Replace it with a freshly generated key, store it outside the config file, and rotate any key that was ever shared.");
            } else if (looksExample) {
              add(e.line, "HIGH", "Example / placeholder credential in config", e.key,
                "Key \"" + e.key + "\" on this line holds a value of length " + len + " that looks like a placeholder. The value itself is never shown in this audit.",
                "Replace placeholder credentials with real, unique ones kept outside the config.");
            } else {
              add(e.line, "HIGH", "Plaintext credential in config", e.key,
                "Key \"" + e.key + "\" on this line holds a plaintext credential value of length " + len + ". The value itself is never shown in this audit.",
                "Move credentials out of the pasted/shared config, prefer environment or vault storage, and rotate anything that has been copied around.");
            }
          }
        });

        /* Cross-check: remote access on, but HTTPS not enforced */
        if (remoteOn && !httpsRequired) {
          add(remoteOn.line, "CRITICAL", "Remote access enabled with no HTTPS", remoteOn.key,
            "Remote access is on while RequireHttps is " + (requireHttps ? "off" : "not set") + (hasCert ? "" : " and no custom certificate is configured") + " — sign-in and media traffic can cross the internet unencrypted.",
            "Require HTTPS with a valid certificate before allowing any remote access, or turn remote access off.");
        }

        var sevRank = { CRITICAL: 0, HIGH: 1, MEDIUM: 2 };
        findings.sort(function (a, b) {
          if (sevRank[a.severity] !== sevRank[b.severity]) return sevRank[a.severity] - sevRank[b.severity];
          return a.line - b.line;
        });

        var counts = { CRITICAL: 0, HIGH: 0, MEDIUM: 0 };
        findings.forEach(function (f) { counts[f.severity]++; });

        var verdict, reason;
        if (counts.CRITICAL > 0) {
          verdict = "DO NOT DEPLOY";
          reason = counts.CRITICAL + " critical finding(s) would expose this server as configured. Fix the critical items before this config runs anywhere reachable.";
        } else if (findings.length > 0) {
          verdict = "DEPLOY WITH FIXES";
          reason = "No critical findings, but " + findings.length + " item(s) should be fixed before this config is treated as hardened.";
        } else {
          verdict = "SAFE TO DEPLOY";
          reason = "No risky settings were found in the pasted config by the checks above. That is a statement about these settings only — it is not a promise the server will start or behave.";
        }

        return { verdict: verdict, reason: reason, findings: findings, counts: counts, linesAudited: lines.length, settingsFound: entries.length };
      }

      /* ---------- Report builders (secret-safe by construction) ---------- */
      function buildReport(result) {
        var out = [];
        out.push("J-Dawgs Emby Server Config Safety Auditor(tm) - Audit Report");
        out.push("==============================================================");
        out.push("Verdict: " + result.verdict);
        out.push("Why: " + result.reason);
        out.push("Lines audited: " + result.linesAudited + " | Settings recognised: " + result.settingsFound);
        if (result.counts) {
          out.push("Findings: " + result.findings.length + " total (Critical " + result.counts.CRITICAL + ", High " + result.counts.HIGH + ", Medium " + result.counts.MEDIUM + ")");
        } else {
          out.push("Findings: 0");
        }
        out.push("");
        if (result.findings.length === 0) {
          out.push("No findings to list.");
        } else {
          result.findings.forEach(function (f, idx) {
            out.push((idx + 1) + ". Line " + f.line + " [" + f.severity + "] " + f.check + (f.key ? " (key: " + f.key + ")" : ""));
            out.push("   " + f.detail);
            out.push("   Fix: " + f.fix);
          });
        }
        out.push("");
        out.push("Note: secret values are never printed in this report. Credential findings");
        out.push("name the key, the line, and the value length only. This audit ran fully");
        out.push("offline in the browser; nothing was uploaded or saved.");
        return out.join("\n");
      }

      function buildJSON(result) {
        return JSON.stringify({
          tool: "J-Dawgs Emby Server Config Safety Auditor",
          verdict: result.verdict,
          reason: result.reason,
          linesAudited: result.linesAudited,
          settingsRecognised: result.settingsFound,
          counts: result.counts || { CRITICAL: 0, HIGH: 0, MEDIUM: 0 },
          findings: result.findings.map(function (f) {
            return { line: f.line, severity: f.severity, check: f.check, key: f.key, detail: f.detail, fix: f.fix };
          }),
          secretHandling: "Findings reference credentials by key name, line, and value length only. Secret values are never included."
        }, null, 2);
      }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-emby-server-config-safety-auditortm',
  name: 'J-Dawgs Emby Server Config Safety Auditor',
  description: 'Grades a pasted Emby media server config offline into one deploy verdict: authentication and remote-access posture, bind exposure, and plaintext credentials caught before anything runs; secrets reported by key name, line, and length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
