'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Epoxy Flooring Installation Proposal, Work Record & Final Invoice Consistency Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

/* ---------- worked examples (exact) ---------- */
var EX_BAD = {
  proposal: "EPOXY FLOORING PROPOSAL\nArea: 500 sq ft\nCoating: $4.00 per sq ft\nLabor rate: $75.00 per hour\nLabor estimate: 20 hours\nPrep fee: $200.00\nDeposit paid: $500.00",
  work: "WORK RECORD\nInstalled: 450 sq ft\nLabor hours: 18 hours\nPrep completed: yes",
  invoice: "FINAL INVOICE\nBilled: 500 sq ft\nCoating: $4.50 per sq ft\nCoating total: $2,250.00\nLabor billed: $1,650.00\nPrep fee: $200.00\nPrep fee: $200.00\nDisposal fee: $150.00\nDeposit credit: $0.00\nTotal due: $4,200.00"
};
var EX_GOOD = {
  proposal: "EPOXY FLOORING PROPOSAL\nArea: 400 sq ft\nCoating: $5.00 per sq ft\nLabor rate: $80.00 per hour\nLabor estimate: 16 hours\nPrep fee: $200.00\nDeposit paid: $400.00",
  work: "WORK RECORD\nInstalled: 400 sq ft\nLabor hours: 16 hours",
  invoice: "FINAL INVOICE\nBilled: 400 sq ft\nCoating: $5.00 per sq ft\nCoating total: $2,000.00\nLabor billed: $1,280.00\nPrep fee: $200.00\nDeposit credit: $400.00\nTotal due: $3,080.00"
};

/* ---------- formatting ---------- */
function money(n){
  var v = Math.round((Number(n)||0)*100)/100;
  var neg = v < 0; v = Math.abs(v);
  var parts = v.toFixed(2).split(".");
  parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return (neg ? "-$" : "$") + parts[0] + "." + parts[1];
}
function num(n){
  var v = Number(n)||0;
  return (Math.round(v*100)/100).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}
function parseAmt(s){ return parseFloat(String(s).replace(/[$,]/g,"")) || 0; }

/* ---------- parsing ---------- */
function findSqFt(text, keywords){
  var i, m, re;
  for (i=0;i<keywords.length;i++){
    re = new RegExp(keywords[i] + "[^0-9$\\n]*([\\d,]+\\.?\\d*)\\s*sq\\.?\\s*ft", "i");
    m = text.match(re);
    if (m) return parseAmt(m[1]);
  }
  /* generic: a number followed by sq ft, not preceded by a $ */
  var all = text.matchAll(/(^|[^$\d])(\d[\d,]*\.?\d*)\s*sq\.?\s*ft/gi), r;
  for (r of all){ return parseAmt(r[2]); }
  return null;
}
function findUnitPrice(text){
  var m = text.match(/\$\s*([\d,]+\.?\d*)\s*(?:per|\/)\s*sq\.?\s*ft/i);
  return m ? parseAmt(m[1]) : null;
}
function findLaborRate(text){
  var m = text.match(/labor[^$\n]*\$\s*([\d,]+\.?\d*)\s*(?:per|\/)\s*(?:hour|hr)/i);
  if (m) return parseAmt(m[1]);
  m = text.match(/\$\s*([\d,]+\.?\d*)\s*(?:per|\/)\s*(?:hour|hr)/i);
  return m ? parseAmt(m[1]) : null;
}
function findFees(text){
  var fees = [], lines = text.split(/\r?\n/), i, line, m;
  for (i=0;i<lines.length;i++){
    line = lines[i];
    if (/fee/i.test(line) && /\$/.test(line)){
      m = line.match(/\$\s*(-?[\d,]+\.?\d*)/);
      if (!m) continue;
      var name = line.slice(0, line.indexOf("$")).replace(/[:\-–—]\s*$/,"").trim();
      if (!name) name = line.replace(/\$.*$/,"").trim();
      fees.push({ name: name, key: name.toLowerCase().replace(/\s+/g," "), amount: Math.abs(parseAmt(m[1])) });
    }
  }
  return fees;
}
function findDeposit(text, kind){
  var re = new RegExp("deposit\\s*" + kind + "[^\\n$]*?(-)?\\s*\\$?\\s*(-?[\\d,]+\\.?\\d*)", "i");
  var m = text.match(re);
  return m ? Math.abs(parseAmt(m[2])) : null;
}
function findLaborHours(text){
  var m = text.match(/labor\s*hours?\s*[:\-]?\s*([\d,]+\.?\d*)/i);
  if (m) return parseAmt(m[1]);
  m = text.match(/([\d,]+\.?\d*)\s*(?:hours?|hrs?)\b/i);
  return m ? parseAmt(m[1]) : null;
}
function findLaborBilled(text){
  var m = text.match(/labor\s*billed\s*[:\-]?\s*\$\s*([\d,]+\.?\d*)/i);
  if (m) return parseAmt(m[1]);
  var lines = text.split(/\r?\n/), i;
  for (i=0;i<lines.length;i++){
    if (/labor/i.test(lines[i]) && /\$/.test(lines[i]) && !/per\s*(hour|hr)/i.test(lines[i]) && !/rate/i.test(lines[i])){
      var mm = lines[i].match(/\$\s*([\d,]+\.?\d*)/);
      if (mm) return parseAmt(mm[1]);
    }
  }
  return null;
}
function findTotalDue(text){
  var m = text.match(/total\s*due[^$\n]*\$\s*([\d,]+\.?\d*)/i);
  return m ? parseAmt(m[1]) : null;
}

function parseProposal(t){
  return {
    area: findSqFt(t, ["area"]),
    unit: findUnitPrice(t),
    rate: findLaborRate(t),
    fees: findFees(t),
    depositPaid: findDeposit(t, "paid")
  };
}
function parseWork(t){
  return { installed: findSqFt(t, ["installed"]), hours: findLaborHours(t) };
}
function parseInvoice(t){
  return {
    billed: findSqFt(t, ["billed","area"]),
    unit: findUnitPrice(t),
    laborBilled: findLaborBilled(t),
    fees: findFees(t),
    depositCredit: findDeposit(t, "credit"),
    totalDue: findTotalDue(t)
  };
}

/* ---------- audit ---------- */
function audit(pText, wText, iText){
  var docs = [
    { name:"Proposal", text:pText },
    { name:"Work Record", text:wText },
    { name:"Final Invoice", text:iText }
  ];
  var present = docs.filter(function(d){ return d.text && d.text.trim().length>0; });
  var missing = docs.filter(function(d){ return !(d.text && d.text.trim().length>0); })
                    .map(function(d){ return d.name; });

  var P = parseProposal(pText||""), W = parseWork(wText||""), I = parseInvoice(iText||"");

  /* Check 1 — quantity */
  var c1 = 0, line1;
  if (I.billed!=null && W.installed!=null && P.unit!=null){
    var diff = I.billed - W.installed;
    c1 = diff > 0 ? Math.round(diff * P.unit * 100)/100 : 0;
    line1 = "(" + num(I.billed) + " − " + num(W.installed) + ") × " + money(P.unit) + " = " + num(Math.max(diff,0)) + " × " + money(P.unit) + " = " + money(c1);
    if (diff <= 0) line1 = "(" + num(I.billed) + " − " + num(W.installed) + ") × " + money(P.unit) + " — billed quantity does not exceed installed = " + money(0);
  } else { line1 = "Not enough data (needs billed sq ft, installed sq ft, and proposal unit price) = " + money(0); }

  /* Check 2 — unit price (billed qty, so components sum to billed coating total − fair coating total) */
  var c2 = 0, line2;
  if (I.billed!=null && I.unit!=null && P.unit!=null){
    var pdiff = I.unit - P.unit;
    c2 = pdiff > 0 ? Math.round(I.billed * pdiff * 100)/100 : 0;
    line2 = num(I.billed) + " × (" + money(I.unit) + " − " + money(P.unit) + ") = " + num(I.billed) + " × " + money(Math.max(pdiff,0)) + " = " + money(c2);
    if (pdiff <= 0) line2 = num(I.billed) + " × (" + money(I.unit) + " − " + money(P.unit) + ") — billed unit price does not exceed proposal = " + money(0);
  } else { line2 = "Not enough data (needs billed sq ft, billed unit price, and proposal unit price) = " + money(0); }

  /* Check 3 — labor */
  var c3 = 0, line3;
  if (I.laborBilled!=null && W.hours!=null && P.rate!=null){
    var fairLabor = Math.round(W.hours * P.rate * 100)/100;
    c3 = I.laborBilled - fairLabor > 0 ? Math.round((I.laborBilled - fairLabor)*100)/100 : 0;
    line3 = money(I.laborBilled) + " − (" + num(W.hours) + " × " + money(P.rate) + " = " + money(fairLabor) + ") = " + money(c3);
  } else { line3 = "Not enough data (needs labor billed, actual hours, and proposal labor rate) = " + money(0); }

  /* Check 4 — duplicate fees */
  var c4 = 0, dupNotes = [], seen = {};
  I.fees.forEach(function(f){
    var k = f.key + "|" + f.amount.toFixed(2);
    if (seen[k]){ c4 += f.amount; dupNotes.push(f.name + " charged twice, duplicate = " + money(f.amount)); }
    else seen[k] = true;
  });
  c4 = Math.round(c4*100)/100;
  var line4 = dupNotes.length ? dupNotes.join("; ") : "No fee charged twice = " + money(0);

  /* Check 5 — invoice-only fees (first occurrence each; extra occurrences are counted in Check 4) */
  var propKeys = {};
  P.fees.forEach(function(f){ propKeys[f.key] = true; });
  var c5 = 0, onlyNotes = [], seenOnly = {};
  I.fees.forEach(function(f){
    if (!propKeys[f.key]){
      var k = f.key + "|" + f.amount.toFixed(2);
      if (!seenOnly[k]){ seenOnly[k] = true; c5 += f.amount; onlyNotes.push(f.name + " " + money(f.amount) + " (never in proposal) = " + money(f.amount)); }
    }
  });
  c5 = Math.round(c5*100)/100;
  var line5 = onlyNotes.length ? onlyNotes.join("; ") : "No invoice-only fees = " + money(0);

  /* Check 6 — deposit */
  var c6 = 0, line6;
  var paid = P.depositPaid!=null ? P.depositPaid : 0;
  var credit = I.depositCredit!=null ? I.depositCredit : 0;
  c6 = paid - credit > 0 ? Math.round((paid - credit)*100)/100 : 0;
  line6 = money(paid) + " − " + money(credit) + " = " + money(c6);

  var comps = [c1,c2,c3,c4,c5,c6];
  var total = Math.round(comps.reduce(function(a,b){return a+b;},0)*100)/100;
  var sumLine = comps.map(money).join(" + ") + " = " + money(total) + " total overcharge";

  /* Fair amount: total due on the invoice, minus the overcharge */
  var fair = null;
  if (I.totalDue!=null) fair = Math.round((I.totalDue - total)*100)/100;
  else if (present.length===3){
    var gross = 0;
    if (I.billed!=null && I.unit!=null) gross += I.billed * I.unit;
    if (I.laborBilled!=null) gross += I.laborBilled;
    I.fees.forEach(function(f){ gross += f.amount; });
    gross -= credit;
    fair = Math.round((gross - total)*100)/100;
  }

  /* Verdict */
  var verdict;
  if (present.length <= 1) verdict = "NOT ENOUGH TO COMPARE";
  else if (present.length === 2) verdict = "PAY WITH FIXES";
  else if (total === 0) verdict = "SAFE TO PAY";
  else if (total < 1000) verdict = "PAY WITH FIXES";
  else verdict = "DO NOT PAY YET";

  var checks = [
    { title:"1. Quantity billed above installed", line:line1, amount:c1 },
    { title:"2. Unit price above proposal", line:line2, amount:c2 },
    { title:"3. Labor billed above hours × rate", line:line3, amount:c3 },
    { title:"4. Duplicate fees", line:line4, amount:c4 },
    { title:"5. Invoice-only fees", line:line5, amount:c5 },
    { title:"6. Deposit paid but not credited", line:line6, amount:c6 }
  ];

  return { verdict:verdict, checks:checks, components:comps, total:total, sumLine:sumLine,
           missing:missing, docCount:present.length, fair:fair, totalDue:I.totalDue,
           parsed:{ P:P, W:W, I:I } };
}

function buildReport(r){
  var out = [];
  out.push("EPOXY FLOORING CONSISTENCY AUDIT");
  out.push("Verdict: " + r.verdict);
  if (r.missing.length){
    r.missing.forEach(function(m){ out.push("Missing: " + m + " — cannot complete cross-check without it."); });
  }
  out.push("");
  r.checks.forEach(function(c){ out.push(c.title + ": " + c.line + "  [" + money(c.amount) + "]"); });
  out.push("");
  out.push(r.sumLine);
  out.push("Total overcharge: " + money(r.total));
  out.push("Amount that would be fair: " + (r.fair!=null ? money(r.fair) : "—"));
  if (r.totalDue!=null) out.push("Total due on invoice: " + money(r.totalDue));
  return out.join("\n");
}
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-epoxy-flooring-installation-proposal-work-record-final-invoice-consistency-auditortm',
  name: 'J-Dawgs Epoxy Flooring Installation Proposal, Work Record & Final Invoice Consistency Auditor',
  description: '',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
