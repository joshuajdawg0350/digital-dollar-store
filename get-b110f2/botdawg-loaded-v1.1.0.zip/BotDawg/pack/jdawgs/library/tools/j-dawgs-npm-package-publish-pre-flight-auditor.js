'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs npm Package Publish Pre-Flight Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var WORKED_PKG = [
          '{',
          '  "name": "@jdawgs/demo-tool",',
          '  "version": "1.2",',
          '  "main": "dist/index.js",',
          '  "types": "dist/index.d.ts",',
          '  "scripts": {',
          '    "test": "echo ok"',
          '  }',
          '}'
        ].join("\n");

        var WORKED_FILES = [
          "src/index.ts",
          "dist/index.js",
          ".env",
          "README.md"
        ].join("\n");

        var CLEAN_PKG = [
          '{',
          '  "name": "@jdawgs/clean-tool",',
          '  "version": "1.0.0",',
          '  "description": "A tidy demo package that passes every pre-flight check.",',
          '  "main": "dist/index.js",',
          '  "types": "dist/index.d.ts",',
          '  "files": [',
          '    "dist"',
          '  ],',
          '  "license": "MIT",',
          '  "repository": {',
          '    "type": "git",',
          '    "url": "https://example.com/jdawgs/clean-tool.git"',
          '  },',
          '  "engines": {',
          '    "node": ">=18"',
          '  },',
          '  "publishConfig": {',
          '    "access": "public"',
          '  },',
          '  "scripts": {',
          '    "build": "tsc",',
          '    "prepack": "npm run build"',
          '  }',
          '}'
        ].join("\n");

        var CLEAN_FILES = [
          "package.json",
          "README.md",
          "LICENSE",
          "dist/index.js",
          "dist/index.d.ts",
          "src/index.ts"
        ].join("\n");

        var pkgInput = document.getElementById("pkgInput");
        var filesInput = document.getElementById("filesInput");
        var verdictBox = document.getElementById("verdictBox");
        var verdictTitle = document.getElementById("verdictTitle");
        var verdictCounts = document.getElementById("verdictCounts");
        var verdictNote = document.getElementById("verdictNote");
        var findingsWrap = document.getElementById("findingsWrap");
        var findingsList = document.getElementById("findingsList");
        var reportCard = document.getElementById("reportCard");
        var reportText = document.getElementById("reportText");

        function normalizePath(p) {
          var s = String(p).trim().replace(/\\/g, "/");
          while (s.indexOf("./") === 0) s = s.slice(2);
          return s;
        }

        function parseFileList(text) {
          var files = [];   // {path, line}
          var bad = [];     // {line, raw}
          var lines = String(text).split(/\r?\n/);
          for (var i = 0; i < lines.length; i++) {
            var raw = lines[i];
            var line = raw.trim();
            if (!line) continue;
            var pathPart = line;
            var m = line.match(/^(.*?)[\s]+(\d+(?:\.\d+)?\s*(?:B|KB|MB|GB|TB|bytes))$/i);
            if (m) {
              pathPart = m[1].trim();
            } else {
              var m2 = line.match(/^(.*\S)[\s]+(\d+)$/);
              if (m2 && /[./\\]/.test(m2[1])) pathPart = m2[1].trim();
            }
            if (pathPart.charAt(0) === '"' && pathPart.charAt(pathPart.length - 1) === '"') {
              pathPart = pathPart.slice(1, -1);
            }
            var isJustSize = /^\d+(\.\d+)?\s*(B|KB|MB|GB|TB|bytes)?$/i.test(pathPart);
            if (!pathPart || isJustSize || /\s/.test(pathPart) || !/[A-Za-z0-9]/.test(pathPart)) {
              bad.push({ line: i + 1, raw: raw });
            } else {
              files.push({ path: normalizePath(pathPart), line: i + 1 });
            }
          }
          return { files: files, bad: bad };
        }

        function keyLine(text, key) {
          var re = new RegExp('"' + key.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + '"\\s*:');
          var m = re.exec(text);
          if (!m) return null;
          return text.slice(0, m.index).split("\n").length;
        }

        var SEMVER_RE = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-((?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*)(?:\.(?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*))*))?(?:\+([0-9a-zA-Z-]+(?:\.[0-9a-zA-Z-]+)*))?$/;
        var NAME_RE = /^(?:@[a-z0-9-~][a-z0-9-._~]*\/)?[a-z0-9-~][a-z0-9-._~]*$/;

        function sensitiveReason(p) {
          var base = p.split("/").pop();
          if (base === ".env" || base.indexOf(".env.") === 0) return "environment file — files like this typically hold secrets";
          if (/\.key$/i.test(base)) return "private key file (matched by extension)";
          if (/\.pem$/i.test(base)) return "certificate / private key file (matched by extension)";
          if (/\.p12$/i.test(base) || /\.pfx$/i.test(base)) return "key / certificate bundle (matched by extension)";
          if (/credential/i.test(base)) return "credentials file (matched by name only — contents never read)";
          if (base === ".npmrc") return "npm config file — it can hold an auth token (flagged by name only; contents never read)";
          if (base === "id_rsa" || base === "id_dsa" || base === "id_ed25519" || base === "id_ecdsa") return "SSH private key (matched by name)";
          return null;
        }

        function shipsUnderFiles(p, filesArr) {
          for (var i = 0; i < filesArr.length; i++) {
            var e = normalizePath(String(filesArr[i])).replace(/\/+$/, "");
            if (!e) continue;
            if (e === p) return true;
            if (p.indexOf(e + "/") === 0) return true;
            if (e.indexOf("*") >= 0) {
              var re = new RegExp("^" + e.replace(/[.+^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*") + "$");
              if (re.test(p)) return true;
            }
          }
          // npm always includes these, allowlist or not.
          var base = p.split("/").pop();
          if (p === "package.json" || /^readme/i.test(base) || /^licen[cs]e/i.test(base)) return true;
          return false;
        }

        function collectExports(node, trail, out) {
          if (typeof node === "string") {
            out.push({ field: '"exports"' + trail, value: node });
          } else if (Object.prototype.toString.call(node) === "[object Array]") {
            for (var i = 0; i < node.length; i++) collectExports(node[i], trail + "[" + i + "]", out);
          } else if (node && typeof node === "object") {
            var keys = Object.keys(node);
            for (var j = 0; j < keys.length; j++) collectExports(node[keys[j]], trail + "." + keys[j], out);
          }
        }

        function audit(pkgText, filesText) {
          var findings = [];
          function add(sev, loc, msg, fix) {
            findings.push({ sev: sev, loc: loc, msg: msg, fix: fix });
          }

          var pkg;
          try {
            pkg = JSON.parse(pkgText);
          } catch (err) {
            var emsg = err && err.message ? err.message : String(err);
            var pos = null, lineCol = "";
            var pm = emsg.match(/position\s+(\d+)/i);
            if (pm) {
              pos = parseInt(pm[1], 10);
              var upto = pkgText.slice(0, pos);
              var ln = upto.split("\n").length;
              var col = pos - upto.lastIndexOf("\n");
              lineCol = " (line " + ln + ", column " + col + ")";
            }
            add("BLOCKER", "package.json" + (pos !== null ? " · position " + pos + lineCol : ""),
              "package.json is not valid JSON. The parser reported: " + emsg,
              "Fix the JSON at the reported position, then run the audit again. No other checks were run — nothing below is guessed.");
            return { verdict: "COULD NOT AUDIT", findings: findings, fileCount: 0, couldNot: true };
          }
          if (!pkg || typeof pkg !== "object" || Object.prototype.toString.call(pkg) === "[object Array]") {
            add("BLOCKER", "package.json", "package.json parsed, but its top level is not a JSON object.",
              "A package.json must be a single JSON object. Fix the file shape, then run the audit again.");
            return { verdict: "COULD NOT AUDIT", findings: findings, fileCount: 0, couldNot: true };
          }

          var parsed = parseFileList(filesText);
          var fileSet = {};
          parsed.files.forEach(function (f) { fileSet[f.path] = f.line; });
          parsed.bad.forEach(function (b) {
            add("WARNING", "file list · line " + b.line,
              "This file-list line could not be read as a path and was excluded from the audit.",
              "Use one path per line, with an optional size after it (e.g. dist/index.js  12.4 KB).");
          });

          function locFor(key) {
            var ln = keyLine(pkgText, key);
            return "package.json" + (ln ? " · line " + ln : "") + ' · "' + key + '"';
          }

          // (1) private
          if (pkg.private === true) {
            add("BLOCKER", locFor("private"),
              '"private": true is set. npm refuses to publish a private package, and this audit assumes a public publish.',
              'Remove "private": true (or set it to false) before publishing publicly.');
          }

          // (2) name
          var scoped = false;
          if (typeof pkg.name !== "string" || !pkg.name.trim()) {
            add("BLOCKER", locFor("name"),
              'No "name" field. npm cannot publish a package without a name.',
              'Add a "name" — lowercase, URL-safe, e.g. "my-tool" or "@scope/my-tool".');
          } else {
            var nm = pkg.name;
            scoped = nm.charAt(0) === "@";
            if (nm.length > 214 || !NAME_RE.test(nm)) {
              add("BLOCKER", locFor("name"),
                'Name "' + nm + '" is not a valid npm package name shape.',
                "Use only lowercase letters, numbers, hyphens, dots, underscores or tildes; no leading dot or underscore; a scope looks like @scope/name; 214 characters max.");
            }
          }

          // (2) version
          if (typeof pkg.version !== "string" || !pkg.version.trim()) {
            add("BLOCKER", locFor("version"),
              'No "version" field. Every publish needs a version.',
              'Add a valid semver version, e.g. "1.0.0".');
          } else if (!SEMVER_RE.test(pkg.version.trim())) {
            add("BLOCKER", locFor("version"),
              'Version "' + pkg.version + '" is not valid semver.',
              'Use the full three-part form MAJOR.MINOR.PATCH, e.g. "1.2.0" — "1.2" is not publishable.');
          }

          // (3) entry points
          var entries = [];
          ["main", "module", "types", "typings"].forEach(function (k) {
            if (typeof pkg[k] === "string" && pkg[k].trim()) entries.push({ field: '"' + k + '"', value: pkg[k] });
          });
          if (pkg.exports !== undefined) {
            var ex = [];
            collectExports(pkg.exports, "", ex);
            ex.forEach(function (e) { entries.push(e); });
          }
          entries.forEach(function (e) {
            var target = e.value.trim();
            if (target.charAt(0) !== "." && target.indexOf("/") !== 0) {
              // Not a relative file target (e.g. a bare condition value) — nothing to check on disk.
              if (target.indexOf("/") === -1 && target.indexOf(".") === -1) return;
            }
            var norm = normalizePath(target);
            if (norm.indexOf("*") >= 0) {
              var prefix = norm.split("*")[0];
              var any = parsed.files.some(function (f) { return f.path.indexOf(prefix) === 0; });
              if (!any) {
                add("BLOCKER", locFor(e.field.replace(/"/g, "")) + " → " + target,
                  "Entry point target pattern " + target + " matches nothing in the file list.",
                  "Build the output, fix the path, or add the matching files to the package.");
              }
              return;
            }
            if (!(norm in fileSet)) {
              add("BLOCKER", locFor(e.field.replace(/"/g, "")) + " → " + norm,
                "Entry point " + e.field + ' points to "' + norm + '", which is MISSING from the file list.',
                "The published package would be broken on install. Build it, fix the path, or add the file to the package before publishing.");
            }
          });

          // (4) files allowlist + sensitive paths
          var hasFiles = Object.prototype.toString.call(pkg.files) === "[object Array]" && pkg.files.length > 0;
          if (!hasFiles) {
            add("WARNING", locFor("files"),
              'No "files" allowlist. npm will ship everything in the package folder (minus its built-in ignores) — including anything sensitive in your file list.',
              'Add a "files" array naming only what should ship, e.g. ["dist"].');
          }
          parsed.files.forEach(function (f) {
            var reason = sensitiveReason(f.path);
            if (!reason) return;
            if (!hasFiles) {
              add("BLOCKER", "file list · line " + f.line + " → " + f.path,
                "Sensitive file " + f.path + " WOULD SHIP — there is no \"files\" allowlist to stop it (" + reason + ").",
                'Remove it from the package folder, or add a "files" allowlist that excludes it. Flagged by name only — its contents were never read.');
            } else if (shipsUnderFiles(f.path, pkg.files)) {
              add("BLOCKER", "file list · line " + f.line + " → " + f.path,
                "Sensitive file " + f.path + " would STILL SHIP — it is inside the \"files\" allowlist (" + reason + ").",
                "Move it out of the allowlisted paths or rename it. Flagged by name only — its contents were never read.");
            } else {
              add("INFO", "file list · line " + f.line + " → " + f.path,
                "Sensitive file " + f.path + " is in the folder but excluded by the \"files\" allowlist — it will not ship.",
                "No action needed. Keep it out of the allowlist.");
            }
          });

          // (5) scripts
          var scripts = (pkg.scripts && typeof pkg.scripts === "object") ? pkg.scripts : {};
          var hasPre = ["prepublish", "prepublishOnly", "prepack", "prepare"].some(function (k) {
            return typeof scripts[k] === "string" && scripts[k].trim();
          });
          if (!hasPre) {
            add("WARNING", locFor("scripts"),
              "No prepublish, prepack, or prepare script. Nothing builds or checks the package before it publishes — stale or missing build output ships as-is.",
              'Add a "prepack" script that builds (and ideally tests) the package.');
          }
          var SECRET_KEY_RE = /\b([A-Za-z][A-Za-z0-9_]*(?:TOKEN|SECRET|PASSWORD|PASSWD|API_?KEY|PRIVATE_?KEY|ACCESS_?KEY|AUTH)[A-Za-z0-9_]*)\s*[:=]/g;
          Object.keys(scripts).forEach(function (sname) {
            var body = scripts[sname];
            if (typeof body !== "string") return;
            var seen = {};
            var mm;
            SECRET_KEY_RE.lastIndex = 0;
            while ((mm = SECRET_KEY_RE.exec(body)) !== null) {
              var keyName = mm[1];
              if (seen[keyName]) continue;
              seen[keyName] = true;
              add("WARNING", locFor("scripts") + " · scripts." + sname,
                'Script "' + sname + '" contains an assignment to a secret-looking key named ' + keyName + " (flagged by key name only — the value is never shown).",
                "Move the value into an environment variable or a secret store that is not part of the published package, and rotate it if it was ever real.");
            }
          });

          // (6) license
          if (typeof pkg.license !== "string" || !pkg.license.trim()) {
            add("WARNING", locFor("license"),
              'No "license" field. A public package without a license leaves reuse rights unclear and looks unfinished on the registry.',
              'Add a license, e.g. "license": "MIT", and ship the license text file.');
          } else if (pkg.license.trim().toUpperCase() === "UNLICENSED") {
            add("WARNING", locFor("license"),
              'License is "UNLICENSED" but this audit assumes a public publish — the code would be public to read yet all-rights-reserved.',
              'If that is deliberate, keep it. Otherwise switch to a real license, e.g. "MIT".');
          }

          // (7) repository
          if (!pkg.repository || (typeof pkg.repository === "string" && !pkg.repository.trim()) ||
              (typeof pkg.repository === "object" && !pkg.repository.url)) {
            add("INFO", locFor("repository"),
              'No "repository" field. The registry page will have no source link.',
              'Add "repository": { "type": "git", "url": "…" } so users can find the source.');
          }

          // (8) scoped publishConfig
          if (scoped) {
            var access = pkg.publishConfig && typeof pkg.publishConfig === "object" ? pkg.publishConfig.access : undefined;
            if (access !== "public") {
              add("WARNING", locFor("publishConfig"),
                'Scoped package "' + pkg.name + '" has no publishConfig.access set to "public". A first publish of a scoped package defaults to restricted (paid plan required) — or fails — instead of going public.',
                'Add "publishConfig": { "access": "public" }.');
            }
          }

          // (9) engines
          if (!pkg.engines || typeof pkg.engines !== "object" || !Object.keys(pkg.engines).length) {
            add("INFO", locFor("engines"),
              'No "engines" field. Users get no hint of the Node version this package needs.',
              'Add e.g. "engines": { "node": ">=18" } if the package has a minimum runtime.');
          }

          var blockers = findings.filter(function (f) { return f.sev === "BLOCKER"; }).length;
          var warnings = findings.filter(function (f) { return f.sev === "WARNING"; }).length;
          var verdict = blockers > 0 ? "DO NOT PUBLISH YET" : (warnings > 0 ? "PUBLISH WITH FIXES" : "SAFE TO PUBLISH");
          return { verdict: verdict, findings: findings, fileCount: parsed.files.length, couldNot: false };
        }

        function severityRank(s) { return s === "BLOCKER" ? 0 : (s === "WARNING" ? 1 : 2); }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-npm-package-publish-pre-flight-auditor',
  name: 'J-Dawgs npm Package Publish Pre-Flight Auditor',
  description: 'publint-style linters need an install and a built package on disk; ours pre-flights a pasted package.json against the pasted file list anywhere, before publish, and returns one publish verdict — entry-point targets checked against the file list, files-allowlist leaks flagged by name, scoped-package ',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
