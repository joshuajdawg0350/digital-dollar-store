'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs PostHog Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Examples (line numbers are part of the test contract) ---------- */
      var RISKY_EXAMPLE = [
        "# Example only — a risky PostHog config",
        "SECRET_KEY=secret",
        "DEBUG=True",
        "SITE_URL=http://analytics.example.com",
        "ALLOWED_HOSTS=*",
        "DATABASE_URL=postgres://posthog:dbpass123@db.internal:5432/posthog",
        "REDIS_URL=redis://:redispass9@cache.internal:6379/0",
        "DISABLE_SIGNUPS=false",
        "EMAIL_VERIFICATION_ENABLED=false",
        "API_TOKEN=tok123"
      ].join("\n");

      var HARDENED_EXAMPLE = [
        "# Example only — a hardened PostHog config",
        "SECRET_KEY=${POSTHOG_SECRET_KEY}",
        "DEBUG=False",
        "SITE_URL=https://analytics.example.com",
        "ALLOWED_HOSTS=analytics.example.com",
        "DATABASE_URL=${DATABASE_URL}",
        "REDIS_URL=${REDIS_URL}",
        "DISABLE_SIGNUPS=true",
        "EMAIL_VERIFICATION_ENABLED=true",
        "CLICKHOUSE_PASSWORD=${CLICKHOUSE_PASSWORD}"
      ].join("\n");

      var PROSE_EXAMPLE = "These are just some working notes about the analytics server. Nothing here is a setting, and there is nothing to grade yet.";

      var GARBAGE_EXAMPLE = [
        "SECRET_KEY=${SECRET_KEY}",
        "this line is not a setting at all",
        "DEBUG=False",
        "SITE_URL=https://analytics.example.com"
      ].join("\n");

      var PLANTED_SECRET = "XQ9PLANTED7SECRET3VALUE5";
      var PLANTED_EXAMPLE = [
        "SECRET_KEY=${SECRET_KEY}",
        "DEBUG=False",
        "SITE_URL=https://analytics.example.com",
        "ALLOWED_HOSTS=analytics.example.com",
        "DATABASE_URL=postgres://posthog:" + PLANTED_SECRET + "@db.internal:5432/posthog",
        "API_TOKEN=" + PLANTED_SECRET
      ].join("\n");

      /* ---------- Parsing ---------- */
      var KNOWN_KEYS = {
        SECRET_KEY:1, DEBUG:1, SITE_URL:1, ALLOWED_HOSTS:1, DATABASE_URL:1, REDIS_URL:1,
        CLICKHOUSE_HOST:1, CLICKHOUSE_USER:1, CLICKHOUSE_PASSWORD:1, CLICKHOUSE_DATABASE:1,
        CLICKHOUSE_SECURE:1, DISABLE_SIGNUPS:1, EMAIL_VERIFICATION_ENABLED:1,
        REQUIRE_EMAIL_VERIFICATION:1, EMAIL_VERIFICATION:1, EMAIL_HOST:1, EMAIL_PORT:1,
        EMAIL_HOST_USER:1, EMAIL_HOST_PASSWORD:1, EMAIL_USE_TLS:1, DEFAULT_FROM_EMAIL:1,
        KAFKA_HOSTS:1, SENTRY_DSN:1, PRIMARY_DB:1, IS_BEHIND_PROXY:1, TRUSTED_PROXIES:1,
        SECURE_COOKIES:1, SESSION_COOKIE_SECURE:1, CSRF_TRUSTED_ORIGINS:1,
        DATABASE_PASSWORD:1, DB_PASSWORD:1, POSTGRES_PASSWORD:1, PGPASSWORD:1,
        CAPTURE_INTERNAL_API_KEY:1, PERSONAL_API_KEY:1, SOCIAL_AUTH_GITHUB_KEY:1,
        SOCIAL_AUTH_GITHUB_SECRET:1, SOCIAL_AUTH_GOOGLE_KEY:1, SOCIAL_AUTH_GOOGLE_SECRET:1,
        BASE_URL:1, APP_URL:1, WEB_URL:1, PUBLIC_URL:1, POSTHOG_SITE_URL:1, TRUSTED_HOSTS:1,
        POSTHOG_ALLOWED_HOSTS:1, API_TOKEN:1
      };

      function cleanValue(raw) {
        var v = raw.replace(/\s+$/, "");
        if (v.length >= 2) {
          var first = v.charAt(0), last = v.charAt(v.length - 1);
          if ((first === '"' && last === '"') || (first === "'" && last === "'")) {
            return v.slice(1, -1);
          }
        }
        var hashIdx = v.indexOf(" #");
        if (hashIdx > -1) v = v.slice(0, hashIdx);
        return v.replace(/\s+$/, "");
      }

      function parseConfig(text) {
        var entries = [];
        var notParsed = [];
        var lines = String(text == null ? "" : text).split(/\r?\n/);
        for (var i = 0; i < lines.length; i++) {
          var lineNo = i + 1;
          var t = lines[i].replace(/^\s+|\s+$/g, "");
          if (t === "") continue;
          if (t.charAt(0) === "#" || t.indexOf("//") === 0) continue;
          var s = t.replace(/^export\s+/i, "");
          var m = s.match(/^([A-Za-z_][A-Za-z0-9_.\-]*)\s*[:=]\s*(.*)$/);
          if (!m) { notParsed.push(lineNo); continue; }
          entries.push({ key: m[1].toUpperCase(), value: cleanValue(m[2]), line: lineNo });
        }
        return { entries: entries, notParsed: notParsed };
      }

      function findEntry(entries, key) {
        for (var i = 0; i < entries.length; i++) if (entries[i].key === key) return entries[i];
        return null;
      }
      function findEntries(entries, key) {
        var out = [];
        for (var i = 0; i < entries.length; i++) if (entries[i].key === key) out.push(entries[i]);
        return out;
      }

      /* ---------- Value classification (values never leave these helpers) ---------- */
      function isReference(v) {
        if (v.indexOf("${") > -1) return true;
        if (/^\$[A-Za-z_][A-Za-z0-9_]*$/.test(v)) return true;
        if (/^(vault|env|ssm|secret|arn):/i.test(v)) return true;
        if (/^<[^>]*>$/.test(v)) return true;
        return false;
      }
      var EXAMPLE_WORDS = ["secret","changeme","change_me","change-me","example","test","dev","default","password","insecure","placeholder","letmein"];
      function isExampleValue(v) {
        var lower = v.toLowerCase();
        for (var i = 0; i < EXAMPLE_WORDS.length; i++) if (lower === EXAMPLE_WORDS[i]) return true;
        if (lower.indexOf("changeme") > -1 || lower.indexOf("change_me") > -1 || lower.indexOf("change-me") > -1) return true;
        if (lower.indexOf("example") > -1) return true;
        if (lower.indexOf("django-insecure") === 0) return true;
        if (lower.indexOf("your-") === 0 || lower.indexOf("your_") === 0) return true;
        return false;
      }
      function isTruthy(v) { return /^(true|1|yes|on)$/i.test(v.replace(/\s+$/,"")); }
      function isFalsy(v) { return /^(false|0|no|off)$/i.test(v.replace(/\s+$/,"")); }
      function isLocalUrl(v) {
        var lower = v.toLowerCase();
        return lower.indexOf("localhost") > -1 || lower.indexOf("127.0.0.1") > -1 ||
               lower.indexOf("0.0.0.0") > -1 || lower.indexOf("[::1]") > -1 || lower.indexOf(".local") > -1;
      }
      function urlPassword(v) {
        var m = v.match(/^[a-z][a-z0-9+.\-]*:\/\/[^\/@]*:([^@]*)@/i);
        return m ? m[1] : null;
      }

      /* ---------- Audit ---------- */
      var SEV_RANK = { BLOCKER: 0, HIGH: 1, WARNING: 2 };

      function audit(text) {
        var parsed = parseConfig(text);
        var entries = parsed.entries;
        var findings = [];
        var handled = {};
        function add(sev, line, key, message, fix) {
          findings.push({ severity: sev, line: line, key: key, message: message, fix: fix });
        }

        var recognized = 0;
        for (var i = 0; i < entries.length; i++) {
          if (KNOWN_KEYS[entries[i].key] || entries[i].key.indexOf("POSTHOG_") === 0) recognized++;
        }

        /* 1 — SECRET_KEY */
        var sk = findEntry(entries, "SECRET_KEY");
        handled["SECRET_KEY"] = 1;
        if (!sk) {
          add("BLOCKER", null, "SECRET_KEY",
            "SECRET_KEY is missing entirely.",
            "Set SECRET_KEY to a long random value (32 characters or more) loaded from your secret store, e.g. SECRET_KEY=${SECRET_KEY}.");
        } else if (!isReference(sk.value)) {
          if (isExampleValue(sk.value)) {
            add("BLOCKER", sk.line, "SECRET_KEY",
              "SECRET_KEY is set to a known example/placeholder word (value length " + sk.value.length + ").",
              "Replace it with a unique random value of at least 32 characters that appears in no example or tutorial.");
          }
          if (sk.value.length < 32) {
            add("BLOCKER", sk.line, "SECRET_KEY",
              "SECRET_KEY is only " + sk.value.length + " characters long; 32 is the minimum.",
              "Generate a fresh random SECRET_KEY of 32+ characters (50 is a good target) and load it by reference.");
          }
        }

        /* 2 — DEBUG in a non-local context */
        var dbg = findEntry(entries, "DEBUG");
        handled["DEBUG"] = 1;
        var site = findEntry(entries, "SITE_URL");
        if (dbg && isTruthy(dbg.value)) {
          var local = site ? isLocalUrl(site.value) : false;
          if (!local) {
            add("HIGH", dbg.line, "DEBUG",
              site ? "DEBUG is enabled while SITE_URL is not a local address — this reads as a production-facing deploy."
                   : "DEBUG is enabled and no local SITE_URL is set — this reads as a production-facing deploy.",
              "Set DEBUG=False for anything reachable beyond your own machine.");
          }
        }

        /* 3 — http:// on the primary URL keys */
        var URL_KEYS = ["SITE_URL","BASE_URL","APP_URL","WEB_URL","PUBLIC_URL","POSTHOG_SITE_URL"];
        for (var u = 0; u < URL_KEYS.length; u++) {
          var urlEntries = findEntries(entries, URL_KEYS[u]);
          for (var ue = 0; ue < urlEntries.length; ue++) {
            var e = urlEntries[ue];
            handled[e.key] = 1;
            if (/^http:\/\//i.test(e.value) && !isLocalUrl(e.value)) {
              add("HIGH", e.line, e.key,
                e.key + " uses plain http:// — traffic, cookies, and credentials cross the network unencrypted.",
                "Serve the site over https and set " + e.key + " to the https:// address.");
            }
          }
        }

        /* 4 — ALLOWED_HOSTS / trusted hosts */
        var HOST_KEYS = ["ALLOWED_HOSTS","TRUSTED_HOSTS","POSTHOG_ALLOWED_HOSTS","CSRF_TRUSTED_ORIGINS"];
        for (var h = 0; h < HOST_KEYS.length; h++) {
          var hostEntries = findEntries(entries, HOST_KEYS[h]);
          for (var he = 0; he < hostEntries.length; he++) {
            var he2 = hostEntries[he];
            handled[he2.key] = 1;
            if (he2.value === "") {
              add("HIGH", he2.line, he2.key,
                he2.key + " is set but empty — host checking is effectively undefined.",
                "List the exact hostnames this deploy answers to, e.g. " + he2.key + "=analytics.example.com.");
            } else if (he2.value.indexOf("*") > -1) {
              add("HIGH", he2.line, he2.key,
                he2.key + " contains the wildcard * — any Host header is trusted.",
                "Replace * with the exact hostnames this deploy serves.");
            }
          }
        }

        /* 5 — DATABASE_URL / database passwords in plaintext */
        var db = findEntry(entries, "DATABASE_URL");
        handled["DATABASE_URL"] = 1;
        if (db && !isReference(db.value)) {
          var dbPw = urlPassword(db.value);
          if (dbPw !== null && dbPw !== "" && !isReference(dbPw)) {
            add("HIGH", db.line, "DATABASE_URL",
              "DATABASE_URL embeds a plaintext database password (password length " + dbPw.length + ").",
              "Move the password into your secret store and reference it, e.g. DATABASE_URL=${DATABASE_URL}.");
          }
        }
        var DB_PW_KEYS = ["DATABASE_PASSWORD","DB_PASSWORD","POSTGRES_PASSWORD","CLICKHOUSE_PASSWORD","PGPASSWORD"];
        for (var d = 0; d < DB_PW_KEYS.length; d++) {
          var pwEntries = findEntries(entries, DB_PW_KEYS[d]);
          for (var pe = 0; pe < pwEntries.length; pe++) {
            var pwe = pwEntries[pe];
            handled[pwe.key] = 1;
            if (pwe.value !== "" && !isReference(pwe.value)) {
              add("HIGH", pwe.line, pwe.key,
                pwe.key + " stores a database password in plaintext (value length " + pwe.value.length + ").",
                "Load it by reference instead, e.g. " + pwe.key + "=${" + pwe.key + "}.");
            }
          }
        }

        /* 6 — REDIS_URL password */
        var redis = findEntry(entries, "REDIS_URL");
        handled["REDIS_URL"] = 1;
        if (redis && !isReference(redis.value)) {
          var rPw = urlPassword(redis.value);
          if (rPw !== null && rPw !== "" && !isReference(rPw)) {
            var weak = isExampleValue(rPw) || rPw.length < 8;
            add(weak ? "HIGH" : "WARNING", redis.line, "REDIS_URL",
              "REDIS_URL embeds a plaintext Redis password (password length " + rPw.length + ")" + (weak ? " that is also short or an example word." : "."),
              "Move the Redis password into your secret store and reference the whole URL, e.g. REDIS_URL=${REDIS_URL}.");
          }
        }

        /* 7 — Open signup + email verification disabled */
        var disable = findEntry(entries, "DISABLE_SIGNUPS");
        handled["DISABLE_SIGNUPS"] = 1;
        var verifyKeys = ["EMAIL_VERIFICATION_ENABLED","REQUIRE_EMAIL_VERIFICATION","EMAIL_VERIFICATION"];
        var verifyOff = null;
        for (var v = 0; v < verifyKeys.length; v++) {
          var ve = findEntry(entries, verifyKeys[v]);
          if (ve) {
            handled[ve.key] = 1;
            if (isFalsy(ve.value) || /^(disabled|off|none)$/i.test(ve.value)) verifyOff = ve;
          }
        }
        if (disable && isFalsy(disable.value) && verifyOff) {
          add("WARNING", verifyOff.line, verifyOff.key,
            "Signups are open (DISABLE_SIGNUPS=false, line " + disable.line + ") while email verification is disabled (" + verifyOff.key + ", line " + verifyOff.line + ") — anyone can register with any address.",
            "Either set DISABLE_SIGNUPS=true, or turn email verification on so new accounts must prove their address.");
        }

        /* 8 — Any other secret-like key, graded by length */
        for (var g = 0; g < entries.length; g++) {
          var ge = entries[g];
          if (handled[ge.key]) continue;
          if (!/(SECRET|TOKEN|PASSWORD|KEY)/.test(ge.key)) continue;
          if (ge.value === "" || isReference(ge.value)) continue;
          if (isExampleValue(ge.value)) {
            add("HIGH", ge.line, ge.key,
              ge.key + " is set to a known example/placeholder word (value length " + ge.value.length + ").",
              "Replace it with a unique random value of at least 32 characters, loaded by reference.");
          } else if (ge.value.length < 16) {
            add("HIGH", ge.line, ge.key,
              ge.key + " is only " + ge.value.length + " characters long.",
              "Use a random value of at least 32 characters for " + ge.key + ", loaded by reference.");
          } else if (ge.value.length < 32) {
            add("WARNING", ge.line, ge.key,
              ge.key + " is " + ge.value.length + " characters long — usable, but short for a secret.",
              "Rotate " + ge.key + " to a random value of 32+ characters when you next change it.");
          }
        }

        findings.sort(function (a, b) {
          var r = SEV_RANK[a.severity] - SEV_RANK[b.severity];
          if (r !== 0) return r;
          var la = a.line == null ? 0 : a.line, lb = b.line == null ? 0 : b.line;
          return la - lb;
        });

        var verdict;
        if (recognized < 3) {
          verdict = "NOT ENOUGH TO GRADE";
          findings = [];
        } else if (findings.some(function (f) { return f.severity === "BLOCKER" || f.severity === "HIGH"; })) {
          verdict = "DO NOT DEPLOY";
        } else if (findings.length > 0) {
          verdict = "DEPLOY WITH FIXES";
        } else {
          verdict = "SAFE TO DEPLOY";
        }

        return {
          verdict: verdict,
          findings: findings,
          notParsed: parsed.notParsed,
          recognizedKeys: recognized,
          parsedLines: entries.length
        };
      }

      /* ---------- Report + JSON (secret values are never included) ---------- */
      function buildTextReport(result) {
        var out = [];
        out.push("J-Dawgs PostHog Server Config Safety Auditor — Audit Report");
        out.push("Verdict: " + result.verdict);
        out.push("Recognized PostHog keys: " + result.recognizedKeys + " · Parsed lines: " + result.parsedLines +
                 " · Not parsed: " + (result.notParsed.length ? "lines " + result.notParsed.join(", ") : "none"));
        out.push("");
        if (result.verdict === "NOT ENOUGH TO GRADE") {
          out.push("Too few recognizable PostHog keys to grade (found " + result.recognizedKeys + ", need at least 3).");
        } else if (result.findings.length === 0) {
          out.push("Findings: none. No graded problems found in the pasted config.");
        } else {
          out.push("Findings (" + result.findings.length + "):");
          for (var i = 0; i < result.findings.length; i++) {
            var f = result.findings[i];
            out.push("[" + f.severity + "] " + (f.line == null ? "Line — (key absent)" : "Line " + f.line) + " · " + f.key + " — " + f.message);
            out.push("    Fix: " + f.fix);
          }
        }
        if (result.notParsed.length) {
          out.push("");
          out.push("NOT PARSED (excluded from grading): lines " + result.notParsed.join(", "));
        }
        out.push("");
        out.push("Note: secret values are never shown. Findings list key name, line number, and character length only.");
        return out.join("\n");
      }

      function buildJSON(result) {
        return JSON.stringify({
          tool: "J-Dawgs PostHog Server Config Safety Auditor",
          verdict: result.verdict,
          recognizedPostHogKeys: result.recognizedKeys,
          parsedLines: result.parsedLines,
          notParsedLines: result.notParsed,
          findings: result.findings.map(function (f) {
            return { severity: f.severity, line: f.line, key: f.key, message: f.message, fix: f.fix };
          })
        }, null, 2);
      }

      /* ---------- UI ---------- */
      var lastResult = null;
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined), "PROSE_EXAMPLE": (typeof PROSE_EXAMPLE !== 'undefined' ? PROSE_EXAMPLE : undefined), "GARBAGE_EXAMPLE": (typeof GARBAGE_EXAMPLE !== 'undefined' ? GARBAGE_EXAMPLE : undefined), "PLANTED_EXAMPLE": (typeof PLANTED_EXAMPLE !== 'undefined' ? PLANTED_EXAMPLE : undefined), "EXAMPLE_WORDS": (typeof EXAMPLE_WORDS !== 'undefined' ? EXAMPLE_WORDS : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-posthog-server-config-safety-auditortm',
  name: 'J-Dawgs PostHog Server Config Safety Auditor',
  description: 'Grades a pasted self-hosted PostHog config offline into one deploy verdict — short/example SECRET_KEY, DEBUG on, http URL, wildcard hosts, and plaintext DB/Redis passwords graded, secrets by key name/line/length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"], "PROSE_EXAMPLE": __core["PROSE_EXAMPLE"], "GARBAGE_EXAMPLE": __core["GARBAGE_EXAMPLE"], "PLANTED_EXAMPLE": __core["PLANTED_EXAMPLE"], "EXAMPLE_WORDS": __core["EXAMPLE_WORDS"] }
};
