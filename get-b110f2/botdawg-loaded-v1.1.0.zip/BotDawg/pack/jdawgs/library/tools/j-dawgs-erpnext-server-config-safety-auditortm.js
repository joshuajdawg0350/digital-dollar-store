'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs ERPNext Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ============================================================
         J-Dawgs ERPNext Server Config Safety Auditor
         Runs entirely on this page. No storage, no network calls.
         Secret values are NEVER copied into any finding, report,
         or export — only key name, location, and value length.
         ============================================================ */

      var PLANTED_SECRET = "PLANTED-SECRET-7f3a9-do-not-leak";

      var RISKY_EXAMPLE = [
        '{',
        '  "db_name": "erpnext_prod",',
        '  "db_type": "mariadb",',
        '  "db_host": "203.0.113.45",',
        '  "db_port": 3306,',
        '  "db_user": "root",',
        '  "db_password": "' + PLANTED_SECRET + '",',
        '  "developer_mode": 1,',
        '  "debug": true,',
        '  "allow_tests": true,',
        '  "encryption_key": "abc123",',
        '  "admin_password": "admin",',
        '  "redis_cache": "redis://:shortpw@127.0.0.1:13000",',
        '  "redis_queue": "redis://127.0.0.1:11000",',
        '  "socketio_port": 9000,',
        '  "webserver_port": 8000,',
        '  "maintenance_mode": 1,',
        '  "pause_scheduler": 0,',
        '  "mute_emails": 0',
        '}'
      ].join("\n");

      var HARDENED_EXAMPLE = [
        '{',
        '  "db_name": "erpnext_prod",',
        '  "db_type": "mariadb",',
        '  "db_host": "127.0.0.1",',
        '  "db_port": 3306,',
        '  "db_user": "erpnext_app",',
        '  "db_password": "Xk9mQ2vL8pR4nT7wZ1bH6s",',
        '  "developer_mode": 0,',
        '  "debug": false,',
        '  "allow_tests": false,',
        '  "encryption_key": "9f2c7a1e4b8d03f6a5c9e2b7d41f08a63c5e9b02d47f18a6c3e5b90d27f41a68",',
        '  "redis_cache": "redis://127.0.0.1:13000",',
        '  "redis_queue": "redis://127.0.0.1:11000",',
        '  "redis_socketio": "redis://127.0.0.1:12000",',
        '  "socketio_port": 9000,',
        '  "webserver_port": 8000,',
        '  "maintenance_mode": 0,',
        '  "pause_scheduler": 0,',
        '  "mute_emails": 0',
        '}'
      ].join("\n");

      /* Keys that mark a paste as recognizably ERPNext / Frappe. */
      var KNOWN_KEYS = {
        db_name: 1, db_type: 1, db_host: 1, db_port: 1, db_user: 1, db_password: 1,
        db_socket: 1, developer_mode: 1, debug: 1, allow_tests: 1, encryption_key: 1,
        redis_cache: 1, redis_queue: 1, redis_socketio: 1, socketio_port: 1,
        webserver_port: 1, http_port: 1, maintenance_mode: 1, pause_scheduler: 1,
        mute_emails: 1, admin_password: 1, administrator_password: 1, bench_id: 1,
        frappe_user: 1, serve_default_site: 1, dns_multitenant: 1, shallow_clone: 1,
        restart_supervisor_on_update: 1, restart_systemd_on_update: 1,
        mail_server: 1, auto_email_id: 1, host_name: 1, root_password: 1,
        mariadb_root_password: 1, mysql_root_password: 1, use_mysqlclient: 1,
        logging: 1, server_script_enabled: 1, disable_scheduler: 1
      };

      /* Known default / example secret values (compared lower-cased). */
      var KNOWN_BAD_SECRETS = {
        "admin": 1, "administrator": 1, "password": 1, "password123": 1,
        "123456": 1, "12345678": 1, "changeme": 1, "change-me": 1,
        "secret": 1, "letmein": 1, "root": 1, "erpnext": 1, "frappe": 1,
        "admin123": 1, "test": 1, "test123": 1, "example": 1, "qwerty": 1,
        "your-password": 1, "your_password": 1, "yourpassword": 1,
        "db_password": 1, "mysql": 1, "mariadb": 1, "default": 1, "passw0rd": 1
      };

      function isExampleValue(v) {
        var s = String(v).toLowerCase();
        if (KNOWN_BAD_SECRETS[s]) return true;
        if (s.indexOf("example") !== -1) return true;
        if (s.indexOf("changeme") !== -1 || s.indexOf("change-me") !== -1 || s.indexOf("change_me") !== -1) return true;
        if (s.indexOf("your-") === 0 || s.indexOf("your_") === 0) return true;
        if (s.indexOf("placeholder") !== -1) return true;
        if (/^(.)\1+$/.test(s) && s.length >= 4) return true; /* aaaa…, 1111… */
        return false;
      }

      function isTruthy(v) {
        if (v === true || v === 1) return true;
        if (typeof v === "string") {
          var s = v.trim().toLowerCase();
          return s === "true" || s === "1" || s === "yes" || s === "on";
        }
        return false;
      }

      function isFalsy(v) {
        if (v === false || v === 0) return true;
        if (typeof v === "string") {
          var s = v.trim().toLowerCase();
          return s === "false" || s === "0" || s === "no" || s === "off" || s === "";
        }
        return false;
      }

      function isPrivateHost(host) {
        var h = String(host).trim().toLowerCase();
        if (h === "localhost" || h === "127.0.0.1" || h === "::1" || h === "0.0.0.0") return true;
        if (h === "host.docker.internal" || /\.local$/.test(h) || /\.internal$/.test(h) || /\.lan$/.test(h)) return true;
        var m = h.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
        if (m) {
          var a = parseInt(m[1], 10), b = parseInt(m[2], 10);
          if (a === 10) return true;
          if (a === 192 && b === 168) return true;
          if (a === 172 && b >= 16 && b <= 31) return true;
          if (a === 169 && b === 254) return true;
          return false;
        }
        return false; /* a public-looking hostname */
      }

      function looksLikeHost(host) {
        var h = String(host).trim();
        return /^[A-Za-z0-9._:-]+$/.test(h) && h.length > 0;
      }

      /* Extract the password length from a redis URL without keeping the value. */
      function redisUrlPasswordLength(url) {
        var m = String(url).match(/^rediss?:\/\/([^@/?#]*)@/);
        if (!m) return -1;
        var userinfo = m[1];
        var idx = userinfo.indexOf(":");
        if (idx === -1) return -1;
        var pw = userinfo.slice(idx + 1);
        return pw.length;
      }

      function redisUrlPasswordIsExample(url) {
        var m = String(url).match(/^rediss?:\/\/([^@/?#]*)@/);
        if (!m) return false;
        var idx = m[1].indexOf(":");
        if (idx === -1) return false;
        return isExampleValue(m[1].slice(idx + 1));
      }

      var SEV_ORDER = { BLOCKER: 0, HIGH: 1, WARNING: 2, INFO: 3 };

      function makeFinding(severity, location, key, message, fix) {
        return { severity: severity, location: location, key: key, message: message, fix: fix };
      }

      /* Generic secret rule — reports length only, never the value. */
      function checkSecretValue(findings, key, location, value, label) {
        if (typeof value !== "string") return;
        var len = value.length;
        if (isExampleValue(value)) {
          findings.push(makeFinding("BLOCKER", location, key,
            label + " is set to a known default or example value (" + len + " characters). Anyone who has read the public examples can guess it.",
            "Replace it with a unique random value of at least 16 characters from a password generator, store it in a password manager, and update every service that uses it."));
        } else if (len < 12) {
          findings.push(makeFinding("HIGH", location, key,
            label + " is only " + len + " characters long. Short secrets fall quickly to guessing and brute force.",
            "Replace it with a unique random value of at least 16 characters and update every service that uses it."));
        } else {
          findings.push(makeFinding("INFO", location, key,
            label + " is stored in this file (" + len + " characters). That is how Frappe reads it, so the file itself becomes the secret: keep it owner-only and out of version control.",
            "Set the config file permissions to owner-only (chmod 600), confirm it is excluded from git, and rotate the value if the file was ever shared."));
        }
      }

      /* Run all checks over a normalized entry list.
         entries: [{key, value, location}] */
      function runChecks(entries, recognized) {
        var findings = [];
        var byKey = {};
        entries.forEach(function (e) { byKey[e.key] = e; });

        function has(key) { return Object.prototype.hasOwnProperty.call(byKey, key); }
        function entry(key) { return byKey[key]; }

        /* developer_mode / debug */
        ["developer_mode", "debug"].forEach(function (key) {
          if (has(key) && isTruthy(entry(key).value)) {
            findings.push(makeFinding("BLOCKER", entry(key).location, key,
              key === "developer_mode"
                ? "Developer mode is ON. On a production bench this exposes developer tooling, verbose errors, and unsafe shortcuts to anyone who can reach the site."
                : "Debug mode is ON. Debug output leaks internal paths, settings, and stack traces to visitors.",
              "Set \"" + key + "\" to 0 (or false) in the config, then restart the bench (bench restart) before deploying."));
          }
        });

        /* allow_tests */
        if (has("allow_tests") && isTruthy(entry("allow_tests").value)) {
          findings.push(makeFinding("HIGH", entry("allow_tests").location, "allow_tests",
            "Test running is enabled (allow_tests). A production bench should never be able to execute the test suite — it can create, change, and delete data.",
            "Set \"allow_tests\" to false (or remove the key) and restart the bench."));
        }

        /* encryption_key */
        if (recognized && !has("encryption_key")) {
          findings.push(makeFinding("HIGH", "(missing)", "encryption_key",
            "No encryption_key is set. Frappe uses this key to encrypt stored credentials and secrets; without it those values are protected by nothing, and some features fail or fall back insecurely.",
            "Generate a long random key (for example with: python3 -c \"import secrets; print(secrets.token_hex(32))\"), set it as \"encryption_key\", and keep a copy in your password manager — data encrypted with it cannot be read without it."));
        } else if (has("encryption_key")) {
          var ek = entry("encryption_key").value;
          if (typeof ek === "string" && isExampleValue(ek)) {
            findings.push(makeFinding("BLOCKER", entry("encryption_key").location, "encryption_key",
              "The encryption_key is a known example value (" + ek.length + " characters). Anyone can copy it from public examples and decrypt everything this key protects.",
              "Generate a fresh random key of at least 32 characters, set it as \"encryption_key\", and re-encrypt or rotate the stored secrets it protects."));
          } else if (typeof ek !== "string" || ek.length < 32) {
            var ekLen = typeof ek === "string" ? ek.length : 0;
            findings.push(makeFinding("HIGH", entry("encryption_key").location, "encryption_key",
              "The encryption_key is only " + ekLen + " characters long. Frappe expects a strong key of at least 32 characters; a short one can be brute-forced.",
              "Generate a fresh random key of at least 32 characters (64 hex characters is a good target) and set it as \"encryption_key\"."));
          }
        }

        /* administrator password present at all */
        ["admin_password", "administrator_password"].forEach(function (key) {
          if (has(key)) {
            var v = entry(key).value;
            var extra = "";
            if (typeof v === "string" && isExampleValue(v)) {
              extra = " Worse, the value is a known default or example (" + v.length + " characters), so the Administrator account is effectively open.";
            } else if (typeof v === "string" && v.length < 12) {
              extra = " The value is also short (" + v.length + " characters).";
            }
            findings.push(makeFinding("HIGH", entry(key).location, key,
              "An administrator password is written in the config file." + extra + " Config files get copied, backed up, and committed — the master password should not live in one.",
              "Log in as Administrator, change the password to a unique one of at least 16 characters stored in a password manager, then delete the \"" + key + "\" line from the config and restart the bench."));
          }
        });

        /* generic password / secret keys (excluding ones handled above) */
        var handled = { admin_password: 1, administrator_password: 1, encryption_key: 1 };
        entries.forEach(function (e) {
          if (handled[e.key]) return;
          if (/(password|passwd|secret|api[_-]?key|private[_-]?key|access[_-]?key)/i.test(e.key)) {
            var label = e.key === "db_password" ? "The database password" : "The value of \"" + e.key + "\"";
            checkSecretValue(findings, e.key, e.location, e.value, label);
          }
        });

        /* redis passwords inside URLs */
        ["redis_cache", "redis_queue", "redis_socketio"].forEach(function (key) {
          if (!has(key) || typeof entry(key).value !== "string") return;
          var pwLen = redisUrlPasswordLength(entry(key).value);
          if (pwLen === -1) {
            findings.push(makeFinding("INFO", entry(key).location, key,
              "This Redis connection URL carries no password. That is fine on a private, local-only Redis — dangerous if Redis is reachable from any other machine.",
              "If Redis listens beyond localhost, set a strong requirepass and put it in the URL; otherwise confirm Redis binds to 127.0.0.1 only."));
          } else if (redisUrlPasswordIsExample(entry(key).value)) {
            findings.push(makeFinding("BLOCKER", entry(key).location, key,
              "The password inside this Redis URL is a known default or example value (" + pwLen + " characters).",
              "Set a unique random Redis password of at least 16 characters and update this URL to match."));
          } else if (pwLen < 12) {
            findings.push(makeFinding("HIGH", entry(key).location, key,
              "The password inside this Redis URL is only " + pwLen + " characters long.",
              "Set a unique random Redis password of at least 16 characters and update this URL to match."));
          } else {
            findings.push(makeFinding("INFO", entry(key).location, key,
              "This Redis URL embeds a password (" + pwLen + " characters). Anyone who can read this file has it.",
              "Keep this config owner-only (chmod 600) and out of version control."));
          }
        });

        /* DB user root-equivalent */
        if (has("db_user") && typeof entry("db_user").value === "string") {
          var u = entry("db_user").value.trim().toLowerCase();
          if (u === "root" || u === "admin" || u === "sa" || u === "postgres" || u === "mariadb.sys") {
            findings.push(makeFinding("BLOCKER", entry("db_user").location, "db_user",
              "The bench connects to the database as \"" + entry("db_user").value + "\", a root-equivalent superuser. If the app is ever compromised, the attacker gets the entire database server, not just this site's database.",
              "Create a dedicated database user that owns only this site's database (for example \"erpnext_app\"), set it as \"db_user\" with its own strong password, and restart the bench."));
          }
        }

        /* db_host public */
        if (has("db_host") && typeof entry("db_host").value === "string" && looksLikeHost(entry("db_host").value)) {
          if (!isPrivateHost(entry("db_host").value)) {
            findings.push(makeFinding("HIGH", entry("db_host").location, "db_host",
              "db_host points at a public-looking address (" + entry("db_host").value + "). Database traffic — including credentials and your business data — would cross the open internet, and the database port becomes a target.",
              "Run the database on the same machine (127.0.0.1) or on a private network / VPN address. If a remote database is unavoidable, restrict its firewall to the bench server only and require TLS."));
          }
        }

        /* ports without TLS posture */
        ["socketio_port", "webserver_port", "http_port"].forEach(function (key) {
          if (has(key)) {
            findings.push(makeFinding("INFO", entry(key).location, key,
              "This config sets " + key + " but carries no TLS settings — a config file cannot tell you whether traffic is encrypted. If users reach these ports directly, logins and data travel unencrypted.",
              "Confirm a TLS-terminating reverse proxy (such as nginx with a valid certificate) sits in front of the bench, and that the raw bench ports are not exposed to the public internet."));
          }
        });

        /* scheduler / maintenance states — INFO so intent is confirmed */
        if (has("maintenance_mode")) {
          var mm = entry("maintenance_mode").value;
          findings.push(makeFinding("INFO", entry("maintenance_mode").location, "maintenance_mode",
            isTruthy(mm)
              ? "Maintenance mode is ON. The site will show a maintenance page to every visitor — correct during an upgrade, a nasty surprise if it was left on by accident."
              : "Maintenance mode is OFF. The site is live to visitors, as expected for a running production site.",
            "Confirm this matches your intent for deploy day; toggle it with bench --site <site> set-maintenance-mode on/off."));
        }
        if (has("pause_scheduler")) {
          var ps = entry("pause_scheduler").value;
          findings.push(makeFinding("INFO", entry("pause_scheduler").location, "pause_scheduler",
            isTruthy(ps)
              ? "The scheduler is PAUSED. Scheduled jobs — email digests, backups, cleanup, integrations — will not run until it is resumed."
              : "The scheduler is running (not paused). Scheduled jobs such as backups and email will fire on schedule.",
            "Confirm this matches your intent; resume with bench --site <site> enable-scheduler if jobs should run."));
        }
        if (has("disable_scheduler") && isTruthy(entry("disable_scheduler").value)) {
          findings.push(makeFinding("INFO", entry("disable_scheduler").location, "disable_scheduler",
            "The scheduler is disabled in this config. No scheduled jobs will run for this site.",
            "Confirm this is deliberate; remove the key or set it to false if scheduled jobs should run."));
        }
        if (has("mute_emails")) {
          var me = entry("mute_emails").value;
          findings.push(makeFinding("INFO", entry("mute_emails").location, "mute_emails",
            isTruthy(me)
              ? "Emails are MUTED. The site will silently send no email at all — password resets, invoices, and notifications included."
              : "Emails are NOT muted. This site will send real email to real people as soon as it runs — right for production, a problem on a test copy full of real addresses.",
            "Confirm the setting matches this environment: muted on staging copies, unmuted on production."));
        }

        findings.sort(function (a, b) { return SEV_ORDER[a.severity] - SEV_ORDER[b.severity]; });
        return findings;
      }

      function computeVerdict(recognized, findings) {
        if (!recognized) return "NOT ENOUGH TO GRADE";
        var hasBlocker = findings.some(function (f) { return f.severity === "BLOCKER"; });
        var hasFix = findings.some(function (f) { return f.severity === "HIGH" || f.severity === "WARNING"; });
        if (hasBlocker) return "DO NOT DEPLOY";
        if (hasFix) return "DEPLOY WITH FIXES";
        return "SAFE TO DEPLOY";
      }

      function audit(text) {
        var findings = [];
        var entries = [];
        var recognized = false;
        var format = "none";
        var trimmed = String(text || "").trim();

        if (!trimmed) {
          return { recognized: false, format: "none", verdict: "NOT ENOUGH TO GRADE", findings: findings };
        }

        if (trimmed.charAt(0) === "{" || trimmed.charAt(0) === "[") {
          format = "JSON";
          var parsed = null;
          try { parsed = JSON.parse(trimmed); } catch (err) { parsed = null; }
          if (parsed === null || typeof parsed !== "object" || Array.isArray(parsed)) {
            findings.push(makeFinding("WARNING", "JSON document", "(unparsable)",
              "NOT PARSED: this looks like JSON but could not be parsed as a JSON object, so nothing in it was graded. A trailing comma or a missing quote is the usual cause.",
              "Fix the JSON syntax (a JSON validator will point at the exact spot), then paste it again."));
            return { recognized: false, format: format, verdict: "NOT ENOUGH TO GRADE", findings: findings };
          }
          Object.keys(parsed).forEach(function (k) {
            var key = k.toLowerCase();
            entries.push({ key: key, value: parsed[k], location: "$." + k });
            if (KNOWN_KEYS[key]) recognized = true;
          });
        } else {
          format = "KEY=VALUE";
          var lines = String(text).split(/\r?\n/);
          lines.forEach(function (raw, i) {
            var loc = "Line " + (i + 1);
            var line = raw.trim();
            if (!line) return;
            if (line.charAt(0) === "#" || line.charAt(0) === ";" || line.indexOf("//") === 0) return;
            var eq = line.indexOf("=");
            if (eq === -1) {
              findings.push(makeFinding("WARNING", loc, "(line " + (i + 1) + ")",
                "NOT PARSED: this line is not a KEY=VALUE pair and was not guessed at. It played no part in the grade.",
                "Rewrite the line as KEY=VALUE, comment it out with a leading #, or remove it, then audit again."));
              return;
            }
            var key = line.slice(0, eq).trim().toLowerCase().replace(/^export\s+/, "");
            var val = line.slice(eq + 1).trim();
            if ((val.charAt(0) === '"' && val.charAt(val.length - 1) === '"') ||
                (val.charAt(0) === "'" && val.charAt(val.length - 1) === "'")) {
              val = val.slice(1, -1);
            }
            var coerced = val;
            if (/^(true|false)$/i.test(val)) coerced = val.toLowerCase() === "true";
            else if (/^-?\d+$/.test(val)) coerced = parseInt(val, 10);
            entries.push({ key: key, value: coerced, location: loc });
            if (KNOWN_KEYS[key]) recognized = true;
          });
        }

        var checkFindings = runChecks(entries, recognized);
        var all = findings.concat(checkFindings);
        all.sort(function (a, b) { return SEV_ORDER[a.severity] - SEV_ORDER[b.severity]; });
        return { recognized: recognized, format: format, verdict: computeVerdict(recognized, all), findings: all };
      }

      function countBy(findings, sev) {
        return findings.filter(function (f) { return f.severity === sev; }).length;
      }

      function buildTextReport(result) {
        var out = [];
        out.push("J-Dawgs ERPNext Server Config Safety Auditor — findings report");
        out.push("Input format: " + result.format);
        out.push("VERDICT: " + result.verdict);
        out.push("Findings: " + result.findings.length +
          " (BLOCKER " + countBy(result.findings, "BLOCKER") +
          ", HIGH " + countBy(result.findings, "HIGH") +
          ", WARNING " + countBy(result.findings, "WARNING") +
          ", INFO " + countBy(result.findings, "INFO") + ")");
        out.push("");
        if (!result.findings.length) {
          out.push("No findings. Nothing on the check list was tripped by the pasted config.");
        }
        result.findings.forEach(function (f, i) {
          out.push((i + 1) + ". [" + f.severity + "] " + f.key + " — " + f.location);
          out.push("   " + f.message);
          out.push("   Fix: " + f.fix);
          out.push("");
        });
        out.push("Note: secret values are never printed in this report — only key names, locations, and lengths.");
        return out.join("\n");
      }

      function buildJSONExport(result) {
        var payload = {
          tool: "J-Dawgs ERPNext Server Config Safety Auditor",
          input_format: result.format,
          recognized_as_erpnext_frappe_config: result.recognized,
          verdict: result.verdict,
          counts: {
            BLOCKER: countBy(result.findings, "BLOCKER"),
            HIGH: countBy(result.findings, "HIGH"),
            WARNING: countBy(result.findings, "WARNING"),
            INFO: countBy(result.findings, "INFO")
          },
          findings: result.findings.map(function (f) {
            return { severity: f.severity, location: f.location, key: f.key, message: f.message, fix: f.fix };
          }),
          note: "Secret values are never included in this export — only key names, locations, and lengths."
        };
        return JSON.stringify(payload, null, 2);
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-erpnext-server-config-safety-auditortm',
  name: 'J-Dawgs ERPNext Server Config Safety Auditor',
  description: 'Grades a pasted ERPNext/Frappe bench config (site_config.json style) fully offline into one deploy verdict — SAFE TO DEPLOY / DEPLOY WITH FIXES / DO NOT DEPLOY / NOT ENOUGH TO GRADE — with secrets shown by key name, location, and length only, never by value.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
