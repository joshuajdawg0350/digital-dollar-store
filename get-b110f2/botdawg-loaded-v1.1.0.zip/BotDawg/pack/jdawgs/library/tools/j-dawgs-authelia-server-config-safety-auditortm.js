'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Authelia Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------------- Worked examples (line numbers are load-bearing) ---------------- */

      var RISKY_LINES = [
        "# Authelia configuration - RISKY worked example",
        "server:",
        "    host: 0.0.0.0",
        "    port: 9091",
        "",
        "jwt_secret: shortsecret",
        "",
        "storage:",
        "    encryption_key: tinypass",
        "    local:",
        "        path: /config/db.sqlite3",
        "",
        "session:",
        "    name: authelia_session",
        "    domain: example.com",
        "",
        "authentication_backend:",
        "    ldap:",
        "        url: ldap://dc.example.com",
        "        base_dn: dc=example,dc=com",
        "",
        "access_control:",
        "    default_policy: bypass"
      ];
      // Planted problems, for the record:
      // line 3  host 0.0.0.0 with no TLS (escalated: default policy is permissive)
      // line 6  jwt_secret plaintext, 11 chars (short)
      // line 9  storage.encryption_key plaintext, 8 chars (short)
      // line 19 ldap:// plaintext directory connection
      // line 23 access_control.default_policy: bypass

      var HARDENED_LINES = [
        "# Authelia configuration - HARDENED worked example",
        "server:",
        "    host: 127.0.0.1",
        "    port: 9091",
        "    tls:",
        "        key: /config/certs/server.key",
        "        certificate: /config/certs/server.crt",
        "",
        "jwt_secret_file: /run/secrets/authelia_jwt_secret",
        "",
        "storage:",
        "    encryption_key_file: /run/secrets/authelia_storage_key",
        "    postgres:",
        "        address: tcp://db.internal:5432",
        "        database: authelia",
        "        username: authelia",
        "        password_file: /run/secrets/authelia_storage_password",
        "",
        "session:",
        "    name: authelia_session",
        "    secret_file: /run/secrets/authelia_session_secret",
        "    domain: example.com",
        "    expiration: 1h",
        "    inactivity: 5m",
        "    remember_me: 1M",
        "",
        "authentication_backend:",
        "    file:",
        "        path: /config/users_database.yml",
        "        password:",
        "            algorithm: argon2id",
        "            iterations: 3",
        "            memory: 64",
        "            parallelism: 4",
        "            key_length: 32",
        "            salt_length: 16",
        "",
        "password_policy:",
        "    standard:",
        "        enabled: true",
        "        min_length: 12",
        "        require_uppercase: true",
        "        require_lowercase: true",
        "        require_number: true",
        "        require_special: true",
        "",
        "regulation:",
        "    max_retries: 3",
        "    find_time: 2m",
        "    ban_time: 5m",
        "",
        "notifier:",
        "    smtp:",
        "        address: smtps://mail.example.com:465",
        "        username: authelia@example.com",
        "        password_file: /run/secrets/authelia_smtp_password",
        "        sender: Authelia <authelia@example.com>",
        "",
        "access_control:",
        "    default_policy: two_factor",
        "    rules:",
        "        - domain: secure.example.com",
        "          policy: two_factor"
      ];

      /* ---------------- Heuristic YAML reader ----------------
         A line-and-indent reader, not a real YAML parser. It tracks
         key paths by indentation, understands block scalars well
         enough to skip their content, and reports anything it cannot
         place as NOT PARSED with the line number. */

      function unquote(v) {
        if (v == null) return v;
        v = String(v).trim();
        if (v.length >= 2) {
          var a = v.charAt(0), b = v.charAt(v.length - 1);
          if ((a === '"' && b === '"') || (a === "'" && b === "'")) return v.slice(1, -1);
        }
        return v;
      }

      function stripComment(v) {
        // Only for unquoted scalars: a " #" starts a trailing comment.
        if (!v) return v;
        var first = v.charAt(0);
        if (first === '"' || first === "'") return v;
        var idx = v.indexOf(" #");
        if (idx >= 0) return v.slice(0, idx).replace(/\s+$/, "");
        return v;
      }

      function joinPath(stack, key) {
        var parts = [];
        for (var i = 0; i < stack.length; i++) parts.push(stack[i].segment);
        if (key != null) parts.push(key);
        var out = "";
        for (var j = 0; j < parts.length; j++) {
          var s = parts[j];
          if (s.charAt(0) === "[") out += s;
          else out += (out ? "." : "") + s;
        }
        return out;
      }

      function parseConfig(text) {
        var rawLines = String(text).split(/\r?\n/);
        var entries = [];     // {kind:'kv'|'item', path, key, value, line}
        var notParsed = [];   // line numbers
        var stack = [];       // frames {indent, segment, isItem}
        var itemCounters = {}; // parentPath -> next index
        var blockIndent = -1; // >=0 while consuming a block scalar

        function popForKey(indent) {
          while (stack.length && stack[stack.length - 1].indent >= indent) stack.pop();
        }
        function popForItem(indent) {
          while (stack.length) {
            var top = stack[stack.length - 1];
            if (top.indent > indent || (top.indent === indent && top.isItem)) stack.pop();
            else break;
          }
        }

        function handleKey(content, effIndent, lineNo) {
          var m = content.match(/^([^:\s][^:]*?):(?:\s+(.*))?$/);
          if (!m) return false;
          var key = m[1].trim();
          var value = m[2] != null ? stripComment(m[2].trim()) : "";
          popForKey(effIndent);
          var path = joinPath(stack, key);
          entries.push({ kind: "kv", path: path, key: key, value: unquote(value), rawValue: value, line: lineNo });
          if (value === "" || /^[|>][+-]?$/.test(value)) {
            stack.push({ indent: effIndent, segment: key, isItem: false });
            if (/^[|>][+-]?$/.test(value)) blockIndent = effIndent;
          }
          return true;
        }

        for (var i = 0; i < rawLines.length; i++) {
          var lineNo = i + 1;
          var raw = rawLines[i];

          if (blockIndent >= 0) {
            if (raw.trim() === "") continue; // blank lines belong to the scalar
            var bind = raw.match(/^ */)[0].length;
            if (bind > blockIndent) continue;  // scalar content, not keys
            blockIndent = -1;                  // scalar ended; process this line
          }

          if (raw.trim() === "") continue;
          if (raw.replace(/^\s+/, "").charAt(0) === "#") continue;
          if (/^\t/.test(raw) || /^ +\t/.test(raw)) { notParsed.push(lineNo); continue; }

          var indent = raw.match(/^ */)[0].length;
          var content = raw.trim();

          if (content === "---" || content === "...") continue;

          if (content === "-" || content.indexOf("- ") === 0) {
            popForItem(indent);
            var parentPath = joinPath(stack, null);
            var idx = itemCounters[parentPath] || 0;
            itemCounters[parentPath] = idx + 1;
            stack.push({ indent: indent, segment: "[" + idx + "]", isItem: true });
            var rest = content === "-" ? "" : content.slice(2).trim();
            if (rest === "") continue;
            if (/^[^:\s][^:]*?:(\s+.*)?$/.test(rest)) {
              if (!handleKey(rest, indent + 2, lineNo)) notParsed.push(lineNo);
            } else {
              entries.push({ kind: "item", path: joinPath(stack.slice(0, -1), null) === "" ? joinPath(stack, null) : parentPath, key: null, value: unquote(stripComment(rest)), line: lineNo, itemPath: parentPath });
            }
            continue;
          }

          if (!handleKey(content, indent, lineNo)) notParsed.push(lineNo);
        }

        return { entries: entries, notParsed: notParsed, lineCount: rawLines.length };
      }

      /* ---------------- Lookup helpers ---------------- */

      function findEntry(parsed, path) {
        for (var i = 0; i < parsed.entries.length; i++) {
          var e = parsed.entries[i];
          if (e.kind === "kv" && e.path === path) return e;
        }
        return null;
      }
      function hasSection(parsed, prefix) {
        for (var i = 0; i < parsed.entries.length; i++) {
          var p = parsed.entries[i].path;
          if (p === prefix || p.indexOf(prefix + ".") === 0 || p.indexOf(prefix + "[") === 0) return true;
        }
        return false;
      }
      function entriesUnder(parsed, prefix) {
        var out = [];
        for (var i = 0; i < parsed.entries.length; i++) {
          var p = parsed.entries[i].path;
          if (p === prefix || p.indexOf(prefix + ".") === 0 || p.indexOf(prefix + "[") === 0) out.push(parsed.entries[i]);
        }
        return out;
      }

      function parseDurationSeconds(v) {
        if (v == null) return null;
        var s = String(v).trim();
        if (s === "") return null;
        if (/^-?\d+$/.test(s)) return parseInt(s, 10);
        var mult = { y: 31536000, M: 2592000, w: 604800, d: 86400, h: 3600, m: 60, s: 1 };
        var total = 0, matched = false, re = /(-?\d+)\s*(y|M|w|d|h|m|s)/g, m;
        var cleaned = s.replace(re, function () { matched = true; return ""; });
        re.lastIndex = 0;
        while ((m = re.exec(s)) !== null) total += parseInt(m[1], 10) * mult[m[2]];
        if (!matched || cleaned.trim() !== "") return null;
        return total;
      }

      function isInternalNetwork(n) {
        var s = String(n).split("/")[0].trim();
        if (/^127\./.test(s) || s === "::1") return true;
        if (/^10\./.test(s)) return true;
        if (/^192\.168\./.test(s)) return true;
        var m = s.match(/^172\.(\d+)\./);
        if (m && +m[1] >= 16 && +m[1] <= 31) return true;
        if (/^(fc|fd|fe80)/i.test(s)) return true;
        return false;
      }
      function isWildcardNetwork(n) {
        var s = String(n).trim();
        return s === "0.0.0.0/0" || s === "::/0" || s === "0.0.0.0" || s === "::";
      }

      var PLACEHOLDER_PATTERNS = ["changeme", "change_me", "change-me", "change me", "example", "placeholder", "insecure", "your_", "your-", "please-change", "please_change", "todo", "xxx", "default-secret", "default_secret"];
      function looksPlaceholder(v) {
        var s = String(v).toLowerCase();
        for (var i = 0; i < PLACEHOLDER_PATTERNS.length; i++) {
          if (s.indexOf(PLACEHOLDER_PATTERNS[i]) >= 0) return true;
        }
        return false;
      }

      /* ---------------- The audit ---------------- */

      var AUTHELIA_TOP_KEYS = ["access_control", "authentication_backend", "session", "storage", "notifier", "regulation", "jwt_secret", "identity_providers", "totp", "webauthn", "duo_api", "password_policy", "server", "ntp", "telemetry", "theme", "log", "default_2fa_method", "identity_validation"];

      function audit(text) {
        var findings = [];   // {severity, line, title, detail}
        var oks = [];        // strings
        var notVerified = []; // strings

        function add(severity, line, title, detail) {
          findings.push({ severity: severity, line: line, title: title, detail: detail });
        }

        if (text == null || String(text).trim() === "") {
          return { verdict: "NOT ENOUGH TO GRADE", reason: "The paste box is empty. Paste an Authelia configuration.yml — or load a worked example — to get a verdict.", findings: findings, oks: oks, notVerified: notVerified, enough: false };
        }

        var parsed = parseConfig(text);

        // Is this an Authelia config at all?
        var topKeys = {};
        parsed.entries.forEach(function (e) {
          var top = e.path.split(/[.[]/)[0];
          topKeys[top] = true;
        });
        var markerCount = 0;
        AUTHELIA_TOP_KEYS.forEach(function (k) { if (topKeys[k]) markerCount++; });
        var strongMarker = !!(topKeys["access_control"] || topKeys["jwt_secret"] || topKeys["authentication_backend"]);
        if (markerCount < 2 && !strongMarker) {
          return { verdict: "NOT ENOUGH TO GRADE", reason: "This paste does not look like an Authelia configuration.yml — none of the recognizable Authelia sections (access_control, authentication_backend, session, storage, notifier, regulation, jwt_secret) were found, so there is nothing honest to grade.", findings: findings, oks: oks, notVerified: notVerified, enough: false };
        }

        /* NOT PARSED lines */
        parsed.notParsed.forEach(function (ln) {
          add("WARNING", ln, "NOT PARSED — line " + ln, "The heuristic reader could not place this line in the configuration structure, so anything it sets is not graded. Check it by hand and confirm with authelia validate-config.");
        });

        /* Duplicate keys */
        var byPath = {};
        parsed.entries.forEach(function (e) {
          if (e.kind !== "kv") return;
          if (!byPath[e.path]) byPath[e.path] = [];
          byPath[e.path].push(e.line);
        });
        Object.keys(byPath).forEach(function (p) {
          var lines = byPath[p];
          if (lines.length > 1) {
            add("WARNING", lines[0], "Duplicate key: " + p, "The key “" + p + "” appears at lines " + lines.join(" and ") + ". Most YAML loaders silently keep only the last value, so the setting you think is live may not be the one Authelia reads. Remove all but one.");
          }
        });

        /* (1) access_control default policy + bypass rules */
        var defaultPolicy = null, defaultPolicyLine = null;
        var dpEntry = findEntry(parsed, "access_control.default_policy");
        if (dpEntry) {
          defaultPolicy = String(dpEntry.value).toLowerCase();
          defaultPolicyLine = dpEntry.line;
          if (defaultPolicy === "bypass") {
            add("BLOCKER", dpEntry.line, "access_control.default_policy is “bypass”", "The default policy lets every request through with no authentication at all. On the server that guards every other app, the guard door is open by default — any route a rule forgets to cover is public. Set the default to deny or two_factor, and open specific routes deliberately.");
          } else if (defaultPolicy === "one_factor") {
            add("HIGH", dpEntry.line, "access_control.default_policy is “one_factor”", "By default, a single password is enough to reach anything a rule does not tighten. For the server that guards every other app, prefer a default of deny or two_factor and relax only the routes that truly need it.");
          } else if (defaultPolicy === "deny" || defaultPolicy === "two_factor") {
            oks.push("access_control.default_policy is “" + defaultPolicy + "” (line " + dpEntry.line + ") — the default posture fails closed.");
          } else {
            add("WARNING", dpEntry.line, "access_control.default_policy has an unrecognized value", "The value at line " + dpEntry.line + " is not one of bypass / one_factor / two_factor / deny, so this auditor cannot grade the default posture. Check the spelling and confirm with authelia validate-config.");
          }
        } else if (hasSection(parsed, "access_control")) {
          add("WARNING", null, "access_control.default_policy is not set in the paste", "The access_control section is present but sets no default_policy, so the auditor cannot confirm the default posture from the paste.");
        } else {
          notVerified.push("access_control: NOT VERIFIED — no access_control section appears in the paste, so the default policy cannot be graded.");
        }
        var permissiveDefault = (defaultPolicy === "bypass" || defaultPolicy === "one_factor");

        // Rules: rebuild each rule object from its entries.
        var ruleMap = {};
        parsed.entries.forEach(function (e) {
          var m = e.path.match(/^access_control\.rules\[(\d+)\](?:\.(.*))?$/);
          if (!m) return;
          var idx = m[1];
          if (!ruleMap[idx]) ruleMap[idx] = { networks: [], hasNetworks: false };
          var sub = m[2] || "";
          if (e.kind === "kv" && sub === "policy") { ruleMap[idx].policy = String(e.value).toLowerCase(); ruleMap[idx].policyLine = e.line; }
          if (e.kind === "kv" && sub === "networks") {
            ruleMap[idx].hasNetworks = true; ruleMap[idx].networksLine = e.line;
            var v = String(e.value).trim();
            if (v.charAt(0) === "[") {
              v.replace(/^\[|\]$/g, "").split(",").forEach(function (n) { n = unquote(n.trim()); if (n) ruleMap[idx].networks.push(n); });
            } else if (v) ruleMap[idx].networks.push(unquote(v));
          }
          if (e.kind === "item" && e.itemPath && /networks$/.test(e.itemPath)) {
            ruleMap[idx].hasNetworks = true;
            if (!ruleMap[idx].networksLine) ruleMap[idx].networksLine = e.line;
            ruleMap[idx].networks.push(String(e.value));
          }
        });
        Object.keys(ruleMap).forEach(function (idx) {
          var r = ruleMap[idx];
          if (r.policy !== "bypass") return;
          var line = r.policyLine || null;
          if (!r.hasNetworks) {
            add("HIGH", line, "Access rule bypasses authentication for every source", "A rule with policy “bypass” and no networks restriction (line " + line + ") lets any source on the internet skip authentication for its domain. Restrict bypass rules to internal networks, or remove them.");
            return;
          }
          var wild = r.networks.filter(isWildcardNetwork);
          var external = r.networks.filter(function (n) { return !isInternalNetwork(n); });
          if (wild.length) {
            add("HIGH", line, "Access rule bypasses authentication for all networks", "A bypass rule (line " + line + ") lists " + wild.join(", ") + ", which matches every source address. That is an unauthenticated public route through the guard server.");
          } else if (external.length) {
            add("HIGH", line, "Access rule bypasses authentication for non-internal networks", "A bypass rule (line " + line + ") covers " + external.join(", ") + ", which is not an internal/private range. Anyone on those networks reaches the app with no login at all.");
          } else if (r.networks.length) {
            oks.push("A bypass rule (line " + line + ") is limited to internal networks (" + r.networks.join(", ") + ") — confirm those ranges really are trusted-only.");
          }
        });

        /* (2) Secrets posture — values are NEVER printed; key, line, length only */
        function secretCheck(path, label, parentPrefix) {
          var entry = findEntry(parsed, path);
          var fileEntry = findEntry(parsed, path + "_file");
          if (entry && String(entry.value).trim() !== "") {
            var v = String(entry.value);
            var isBlock = /^[|>][+-]?$/.test(String(entry.rawValue).trim());
            var ph = !isBlock && looksPlaceholder(v);
            if (isBlock) {
              add("HIGH", entry.line, label + " is embedded in plaintext in the config file", "The key material for " + label + " is written directly into configuration.yml (line " + entry.line + ", multi-line block value). Anyone who reads the config — a backup, a screenshot, a repo — has the secret. Move it to a file reference and restrict that file’s permissions.");
            } else if (ph) {
              add("BLOCKER", entry.line, label + " looks like a placeholder value left in plaintext", label + " is present in plaintext at line " + entry.line + " (value length " + v.length + " characters) and matches a known placeholder/example pattern. A placeholder secret is no secret at all. Replace it with a generated value of at least 32 characters, supplied via a file reference.");
            } else if (v.length < 32) {
              add("BLOCKER", entry.line, label + " is plaintext in the config — and short", label + " is stored in plaintext at line " + entry.line + " with a value length of only " + v.length + " characters (under the 32-character floor this auditor applies). Anyone with the file has it, and its short length makes it guessable. Generate a long random value and supply it via a file reference.");
            } else {
              add("HIGH", entry.line, label + " is plaintext in the config file", label + " is stored in plaintext at line " + entry.line + " (value length " + v.length + " characters — the value itself is never shown in this report). Anyone who reads the config has the secret. Supply it via a file reference (a *_file key) and restrict that file’s permissions.");
            }
            return;
          }
          if (fileEntry) {
            oks.push(label + " is supplied via a file reference (" + path + "_file, line " + fileEntry.line + ") — the value is not in the pasted config.");
            return;
          }
          if (parentPrefix && hasSection(parsed, parentPrefix)) {
            notVerified.push(label + ": NOT VERIFIED — neither the key nor a *_file reference appears in the paste, so this auditor cannot tell how it is supplied.");
          }
        }

        secretCheck("jwt_secret", "jwt_secret", null);
        if (!findEntry(parsed, "jwt_secret") && !findEntry(parsed, "jwt_secret_file")) {
          notVerified.push("jwt_secret: NOT VERIFIED — neither jwt_secret nor jwt_secret_file appears in the paste.");
        }
        secretCheck("session.secret", "session secret", "session");
        secretCheck("storage.encryption_key", "storage.encryption_key", "storage");
        secretCheck("identity_providers.oidc.issuer_private_key", "OIDC issuer private key", "identity_providers.oidc");
        secretCheck("notifier.smtp.password", "notifier SMTP password", "notifier.smtp");
        secretCheck("authentication_backend.ldap.password", "LDAP bind password", "authentication_backend.ldap");
        secretCheck("storage.mysql.password", "MySQL storage password", "storage.mysql");
        secretCheck("storage.postgres.password", "Postgres storage password", "storage.postgres");

        /* (3) Session — only what the paste itself sets */
        if (hasSection(parsed, "session")) {
          notVerified.push("Session domain match: NOT VERIFIED — whether session.domain truly matches the domains your rules protect cannot be checked from a paste; it needs the live deployment.");
          var exp = findEntry(parsed, "session.expiration");
          if (exp) {
            var es = parseDurationSeconds(exp.value);
            if (es != null && es <= 0) add("WARNING", exp.line, "session.expiration disables session expiry", "session.expiration is set at line " + exp.line + " to a value that turns expiry off, so sessions can live indefinitely once issued. Set a finite expiration.");
            else if (es != null && es > 7 * 86400) add("WARNING", exp.line, "session.expiration is very long", "session.expiration at line " + exp.line + " allows sessions to live longer than 7 days. On the authentication server, shorter sessions shrink the value of a stolen cookie.");
          }
          var ina = findEntry(parsed, "session.inactivity");
          if (ina) {
            var isec = parseDurationSeconds(ina.value);
            if (isec != null && isec <= 0) add("INFO", ina.line, "session.inactivity is disabled in the paste", "session.inactivity at line " + ina.line + " is set to a value that disables the inactivity timeout, so an idle session stays live until expiration. That is a posture choice — noted because the paste sets it.");
            else if (isec != null && isec > 86400) add("WARNING", ina.line, "session.inactivity is very long", "session.inactivity at line " + ina.line + " lets an idle session stay live for more than a day. Consider a shorter idle timeout for an authentication server.");
          }
          var rm = findEntry(parsed, "session.remember_me");
          if (rm) {
            var rsec = parseDurationSeconds(rm.value);
            var rv = String(rm.value).toLowerCase();
            if (rv === "false" || rsec === 0 || rsec === -1) {
              add("INFO", rm.line, "Remember-me is disabled in the paste", "session.remember_me at line " + rm.line + " disables remember-me, which is stricter than Authelia’s default (the default keeps a remembered session for about a month). Users will sign in more often; the posture is safer, and it is noted only because the paste sets it explicitly.");
            } else if (rsec != null && rsec > 90 * 86400) {
              add("WARNING", rm.line, "session.remember_me is very long", "session.remember_me at line " + rm.line + " keeps remembered sessions alive for more than 90 days. A remembered cookie is a long-lived credential — keep its lifetime deliberate.");
            } else {
              add("INFO", rm.line, "session.remember_me is set in the paste", "session.remember_me is explicitly set at line " + rm.line + ". Authelia’s default is about one month when the key is absent; the paste’s own setting governs here.");
            }
          }
        }

        /* (4) Server exposure + TLS */
        var hostEntry = findEntry(parsed, "server.host");
        var addrEntry = findEntry(parsed, "server.address");
        var bindValue = hostEntry ? String(hostEntry.value) : (addrEntry ? String(addrEntry.value) : null);
        var bindLine = hostEntry ? hostEntry.line : (addrEntry ? addrEntry.line : null);
        var tlsConfigured = !!findEntry(parsed, "server.tls.key") || !!findEntry(parsed, "server.tls.certificate");
        var exposed = bindValue != null && (bindValue.indexOf("0.0.0.0") >= 0 || bindValue === "::" || bindValue.indexOf("[::]") >= 0);
        if (exposed && !tlsConfigured) {
          if (permissiveDefault) {
            add("BLOCKER", bindLine, "Server listens on all interfaces with no TLS — and the default policy is permissive", "The server binds " + bindValue + " (line " + bindLine + ") with no server.tls key/certificate in the paste, so login traffic can cross the network unencrypted — while access_control.default_policy is “" + defaultPolicy + "”. Bind to localhost behind a TLS-terminating proxy, or configure TLS, before this faces any network.");
          } else {
            add("HIGH", bindLine, "Server listens on all interfaces with no TLS configured", "The server binds " + bindValue + " (line " + bindLine + ") and no server.tls key/certificate appears in the paste. Unless a reverse proxy in front terminates TLS, credentials and session cookies cross the network in the clear. Bind to localhost behind the proxy, or configure server.tls.");
          }
        } else if (exposed && tlsConfigured) {
          oks.push("Server binds all interfaces but server.tls is configured (line " + bindLine + ") — confirm the certificate is valid for the public name; certificates are NOT VERIFIED by this auditor.");
        } else if (bindValue != null && (bindValue === "127.0.0.1" || bindValue === "localhost" || bindValue === "::1")) {
          oks.push("Server binds a loopback address only (line " + bindLine + ") — it is not directly exposed to the network.");
        }
        if (tlsConfigured) oks.push("server.tls key/certificate are configured in the paste — the certificate itself is NOT VERIFIED (a paste cannot prove validity).");

        /* (5) Authentication backend */
        var ldapUrl = findEntry(parsed, "authentication_backend.ldap.url");
        if (ldapUrl) {
          var lu = String(ldapUrl.value).toLowerCase();
          if (lu.indexOf("ldaps://") === 0) {
            oks.push("LDAP backend uses ldaps:// (line " + ldapUrl.line + ") — directory traffic is encrypted.");
          } else if (lu.indexOf("ldap://") === 0) {
            add("HIGH", ldapUrl.line, "LDAP backend uses plaintext ldap://", "authentication_backend.ldap.url at line " + ldapUrl.line + " uses ldap://, so bind credentials and user passwords cross the network to the directory unencrypted. Switch to ldaps:// (or StartTLS where the directory requires it).");
          }
        }
        if (hasSection(parsed, "authentication_backend.file")) {
          var algo = findEntry(parsed, "authentication_backend.file.password.algorithm");
          var iterE = findEntry(parsed, "authentication_backend.file.password.iterations");
          var memE = findEntry(parsed, "authentication_backend.file.password.memory");
          if (!algo && !iterE && !memE) {
            var filePathE = findEntry(parsed, "authentication_backend.file.path");
            add("WARNING", filePathE ? filePathE.line : null, "File backend has no password hashing parameters in the paste", "authentication_backend.file sets no password algorithm/argon2 parameters in the paste, so the strength of the stored password hashes cannot be confirmed. Set the argon2id parameters explicitly (iterations, memory, parallelism, key/salt length).");
          } else if (algo && String(algo.value).toLowerCase() !== "argon2id") {
            add("WARNING", algo.line, "File backend password algorithm is not argon2id", "authentication_backend.file.password.algorithm at line " + algo.line + " is not argon2id. Argon2id is Authelia’s recommended password hash; weaker algorithms make a stolen users file far cheaper to crack.");
          } else if (!iterE || !memE) {
            add("WARNING", algo ? algo.line : null, "Argon2 parameters are incomplete in the paste", "The file backend names an algorithm but the paste does not set the full argon2 parameter set (iterations / memory / parallelism / key_length / salt_length), so the hashing cost cannot be confirmed.");
          } else {
            oks.push("File backend password hashing uses argon2id with explicit parameters (line " + algo.line + ").");
          }
          var stdEnabled = findEntry(parsed, "password_policy.standard.enabled");
          var stdMin = findEntry(parsed, "password_policy.standard.min_length");
          if (stdEnabled && String(stdEnabled.value).toLowerCase() === "false") {
            add("WARNING", stdEnabled.line, "Standard password policy is disabled", "password_policy.standard.enabled is false (line " + stdEnabled.line + "), so Authelia applies no length/composition floor to new passwords on the server that guards everything else.");
          }
          if (stdMin && parseInt(stdMin.value, 10) < 8) {
            add("WARNING", stdMin.line, "password_policy.standard.min_length is under 8", "password_policy.standard.min_length at line " + stdMin.line + " is below 8 characters. Raise it — 12 or more is the sensible floor for an authentication server.");
          }
          if (!hasSection(parsed, "password_policy")) {
            add("WARNING", null, "No password_policy in the paste", "The paste sets no password_policy, so no minimum password length or composition rule can be confirmed for the file backend. Add a standard policy with min_length of at least 8 (12+ preferred).");
          } else if (stdEnabled && String(stdEnabled.value).toLowerCase() !== "false" && (!stdMin || parseInt(stdMin.value, 10) >= 8)) {
            oks.push("Password policy is enabled with a minimum length of at least 8 (line " + (stdMin ? stdMin.line : stdEnabled.line) + ").");
          }
        }

        /* (6) Storage engine notes */
        if (hasSection(parsed, "storage.local")) {
          var localPath = findEntry(parsed, "storage.local.path");
          if (exposed) {
            add("INFO", localPath ? localPath.line : null, "SQLite single-file storage on a network-exposed host", "Storage is a single SQLite file (storage.local) while the server binds all interfaces. That pairing is workable for a small single-host deployment, but the database file holds every user and session — protect it like a secret file and back it up.");
          } else {
            add("INFO", localPath ? localPath.line : null, "SQLite single-file storage", "Storage is a single SQLite file (storage.local). Fine for a small single-host setup; the file holds every user and session, so protect it like a secret and back it up.");
          }
        }
        if (hasSection(parsed, "storage.postgres")) oks.push("Storage uses Postgres — a network database suited to larger or multi-host deployments.");
        if (hasSection(parsed, "storage.mysql")) oks.push("Storage uses MySQL — a network database suited to larger or multi-host deployments.");

        /* (7) Regulation */
        var regMax = findEntry(parsed, "regulation.max_retries");
        var regFind = findEntry(parsed, "regulation.find_time");
        var regBan = findEntry(parsed, "regulation.ban_time");
        if (!hasSection(parsed, "regulation")) {
          add("WARNING", null, "No regulation section in the paste", "Brute-force regulation (max_retries / find_time / ban_time) does not appear in the paste, so this auditor cannot confirm any throttle on repeated failed logins. Add a regulation section — it is the main brake on password guessing.");
        } else {
          if (regMax && parseInt(regMax.value, 10) === 0) {
            add("WARNING", regMax.line, "regulation.max_retries is 0 — brute-force regulation is off", "regulation.max_retries at line " + regMax.line + " is 0, which disables Authelia’s failed-login regulation. Set a small positive number (for example 3) with find_time and ban_time.");
          }
          if (!regFind || !regBan) {
            add("WARNING", regMax ? regMax.line : null, "regulation find_time / ban_time are not both set", "The regulation section is present but find_time and/or ban_time are missing from the paste, so the ban window cannot be confirmed. Set both (for example find_time 2m, ban_time 5m).");
          }
          if (regMax && parseInt(regMax.value, 10) > 0 && regFind && regBan) {
            oks.push("Regulation is on: max_retries " + regMax.value + " with find_time and ban_time set (line " + regMax.line + ") — failed logins get throttled and banned.");
          }
        }

        /* (8) Notifier SMTP transport */
        if (hasSection(parsed, "notifier.smtp")) {
          var smtpPw = findEntry(parsed, "notifier.smtp.password");
          var smtpPwFile = findEntry(parsed, "notifier.smtp.password_file");
          if (!smtpPw && !smtpPwFile) {
            // no credential to grade; nothing to say
          }
          var dv = findEntry(parsed, "notifier.smtp.disable_verify_tls");
          if (dv && String(dv.value).toLowerCase() === "true") {
            add("WARNING", dv.line, "SMTP TLS certificate verification is disabled", "notifier.smtp.disable_verify_tls is true (line " + dv.line + "), so Authelia will not verify the mail server’s certificate — password-reset mail can be intercepted. Turn verification back on and fix the certificate instead.");
          }
          var drt = findEntry(parsed, "notifier.smtp.disable_require_tls");
          if (drt && String(drt.value).toLowerCase() === "true") {
            add("WARNING", drt.line, "SMTP TLS is not required", "notifier.smtp.disable_require_tls is true (line " + drt.line + "), so mail — including password-reset links — may be sent unencrypted. Require TLS.");
          }
          var addrE = findEntry(parsed, "notifier.smtp.address");
          var hostE = findEntry(parsed, "notifier.smtp.host");
          var portE = findEntry(parsed, "notifier.smtp.port");
          var smtpTls = entriesUnder(parsed, "notifier.smtp.tls").length > 0;
          var scheme = null, port = null;
          if (addrE) {
            var av = String(addrE.value);
            var sm = av.match(/^([a-z]+):\/\//i);
            if (sm) scheme = sm[1].toLowerCase();
            var pm = av.match(/:(\d+)\/?$/);
            if (pm) port = parseInt(pm[1], 10);
          } else if (portE) {
            port = parseInt(portE.value, 10);
          }
          if (scheme === "smtps" || port === 465) {
            oks.push("SMTP notifier uses an encrypted submission channel (line " + (addrE ? addrE.line : portE.line) + ").");
          } else if (port === 25 && scheme !== "smtps" && !smtpTls) {
            add("WARNING", addrE ? addrE.line : (portE ? portE.line : null), "SMTP notifier sends on port 25 with no TLS setting", "The SMTP notifier targets port 25 and the paste sets no TLS configuration for it, so password-reset and notification mail can cross the network unencrypted. Use an smtps:// submission endpoint (465) or a TLS-required submission port (587).");
          } else if (scheme === "smtp" && !smtpTls) {
            add("WARNING", addrE ? addrE.line : null, "SMTP notifier uses a plaintext smtp:// address with no TLS block", "notifier.smtp.address uses smtp:// and the paste has no notifier.smtp.tls settings, so the auditor cannot confirm encrypted mail transport. Prefer smtps:// or require TLS.");
          }
          if (hostE && !addrE && port == null) {
            notVerified.push("SMTP transport security: NOT VERIFIED — the notifier uses a legacy host setting with no port in the paste, so its TLS posture cannot be graded.");
          }
        }

        /* Verdict */
        var sevRank = { BLOCKER: 4, HIGH: 3, WARNING: 2, INFO: 1 };
        findings.sort(function (a, b) {
          var r = sevRank[b.severity] - sevRank[a.severity];
          if (r !== 0) return r;
          var la = a.line == null ? 9999 : a.line, lb = b.line == null ? 9999 : b.line;
          return la - lb;
        });
        var has = function (s) { return findings.some(function (f) { return f.severity === s; }); };
        var verdict, reason;
        if (has("BLOCKER")) {
          verdict = "DO NOT DEPLOY";
          reason = "Blocking problems were found — the configuration would run, but its guard posture is open or its core secrets are exposed. Fix every BLOCKER before this faces a network.";
        } else if (has("HIGH")) {
          verdict = "DO NOT DEPLOY";
          reason = "High-severity problems were found — plaintext secrets, unencrypted directory traffic, or an exposed login surface. Fix every HIGH finding before deploying the server that guards everything else.";
        } else if (has("WARNING")) {
          verdict = "DEPLOY WITH FIXES";
          reason = "Nothing here is wide open, but the warnings below are real weaknesses or unverified settings. Fix them, then re-run this audit.";
        } else {
          verdict = "SAFE TO DEPLOY";
          reason = "No blocking, high, or warning findings. The checks that passed are listed below — still run authelia validate-config on the host, and remember the NOT VERIFIED items a paste can never prove.";
        }
        return { verdict: verdict, reason: reason, findings: findings, oks: oks, notVerified: notVerified, enough: true };
      }

      /* ---------------- Rendering, report, JSON ---------------- */

      var SEV_ORDER = ["BLOCKER", "HIGH", "WARNING", "INFO"];
      var lastResult = null;

      function countsOf(r) {
        var c = { BLOCKER: 0, HIGH: 0, WARNING: 0, INFO: 0, OK: r.oks.length };
        r.findings.forEach(function (f) { c[f.severity]++; });
        return c;
      }

      function buildReport(r) {
        var c = countsOf(r);
        var out = [];
        out.push("J-DAWGS AUTHELIA SERVER CONFIG SAFETY AUDITOR - REPORT");
        out.push("Verdict: " + r.verdict);
        out.push(r.reason);
        out.push("Counts: " + c.BLOCKER + " BLOCKER / " + c.HIGH + " HIGH / " + c.WARNING + " WARNING / " + c.INFO + " INFO / " + c.OK + " checks passed");
        out.push("");
        if (r.findings.length) {
          out.push("FINDINGS");
          r.findings.forEach(function (f) {
            out.push("[" + f.severity + "] " + (f.line != null ? "Line " + f.line + " - " : "") + f.title);
            out.push("    " + f.detail);
          });
          out.push("");
        }
        if (r.oks.length) {
          out.push("CHECKS THAT PASSED");
          r.oks.forEach(function (o) { out.push("- " + o); });
          out.push("");
        }
        if (r.notVerified.length) {
          out.push("NOT VERIFIED FROM A PASTE");
          r.notVerified.forEach(function (n) { out.push("- " + n); });
          out.push("");
        }
        out.push("Method: heuristic YAML text audit run entirely in the browser. Not a real YAML parser and not a replacement for authelia validate-config. Secret values are never included in this report - findings cite key name, line, and value length only.");
        return out.join("\n");
      }

      function buildJSON(r) {
        var c = countsOf(r);
        return JSON.stringify({
          tool: "J-Dawgs Authelia Server Config Safety Auditor",
          version: 1,
          verdict: r.verdict,
          verdict_reason: r.reason,
          counts: { blocker: c.BLOCKER, high: c.HIGH, warning: c.WARNING, info: c.INFO, ok_checks: c.OK },
          findings: r.findings.map(function (f) {
            return { severity: f.severity, line: f.line, title: f.title, detail: f.detail };
          }),
          ok_checks: r.oks,
          not_verified: r.notVerified,
          note: "Heuristic YAML text audit run in the browser. Secret values are never included; findings cite key name, line, and value length only."
        }, null, 2);
      }

      function escapeHtml(s) {
        return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-authelia-server-config-safety-auditortm',
  name: 'J-Dawgs Authelia Server Config Safety Auditor',
  description: 'Authelia\'s own validate-config only answers will-it-load, so a bypass default policy, plaintext JWT/storage secrets, and ldap:// pass on the SSO server itself; paste a configuration.yml and get one deploy verdict with line-numbered findings; secrets by key name, line, and length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
