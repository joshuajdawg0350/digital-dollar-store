'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs GitHub Actions Workflow Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Built-in knowledge (snapshot, November 2026) ---------- */
      var SNAPSHOT_LABEL = "snapshot, November 2026";
      // Well-known actions: lowest major still considered current in the snapshot.
      // Anything pinned by tag below this major is flagged as possibly deprecated.
      var ACTION_MIN_MAJOR = {
        "actions/checkout": 4,
        "actions/setup-node": 4,
        "actions/setup-python": 5,
        "actions/setup-go": 5,
        "actions/setup-java": 4,
        "actions/setup-dotnet": 4,
        "actions/cache": 4,
        "actions/upload-artifact": 4,
        "actions/download-artifact": 4,
        "actions/github-script": 7,
        "docker/login-action": 3,
        "docker/build-push-action": 5,
        "docker/setup-buildx-action": 3,
        "aws-actions/configure-aws-credentials": 4,
        "azure/login": 2,
        "google-github-actions/auth": 2
      };
      // Owners whose actions are first-party; everything else counts as third-party.
      var FIRST_PARTY_OWNERS = { actions: 1, github: 1, docker: 1, "aws-actions": 1, "azure": 1, "google-github-actions": 1, "hashicorp": 1, "microsoft": 1 };
      var KNOWN_CONTEXTS = ["github", "env", "secrets", "vars", "matrix", "strategy", "needs", "steps", "inputs", "job", "jobs", "runner"];
      var KNOWN_FUNCTIONS = ["hashfiles", "contains", "startswith", "endswith", "format", "join", "tojson", "fromjson", "success", "failure", "cancelled", "always"];
      var EXPR_KEYWORDS = ["true", "false", "null"];

      /* ---------- Examples ---------- */
      var EXAMPLE_BAD = [
        "name: Nightly build and release check",
        "",
        "on:",
        "  push:",
        "    branches: [ main ]",
        "  schedule:",
        "    - cron: \"17 3 * * *\"",
        "",
        "permissions: write-all",
        "",
        "jobs:",
        "  build:",
        "    runs-on: ubuntu-latest",
        "    steps:",
        "      - uses: actions/checkout@v2",
        "      - name: Say what we are building",
        "        run: echo \"Building ${{ githb.ref_name }} for ${{ github.repository }}\"",
        "      - name: Publish the package",
        "        uses: example-labs/publish-package@main",
        "",
        "  verify:",
        "    runs-on: ubuntu-latest",
        "    permissions:",
        "      contents: read",
        "    steps:",
        "      - uses: actions/checkout@08eba0b27e820071cde6df949e0beb9ba4906955",
        "      - name: Run the test suite",
        "        run: npm test"
      ].join("\n");

      var EXAMPLE_CLEAN = [
        "name: CI",
        "",
        "on:",
        "  push:",
        "  workflow_dispatch:",
        "    inputs:",
        "      verbose:",
        "        description: \"Verbose test output\"",
        "        required: false",
        "        default: \"false\"",
        "",
        "permissions:",
        "  contents: read",
        "",
        "jobs:",
        "  test:",
        "    runs-on: ubuntu-latest",
        "    steps:",
        "      - uses: actions/checkout@08eba0b27e820071cde6df949e0beb9ba4906955",
        "      - name: Install dependencies",
        "        run: npm ci",
        "      - name: Run tests",
        "        run: npm test",
        "        env:",
        "          API_TOKEN: ${{ secrets.API_TOKEN }}"
      ].join("\n");

      /* ---------- Small honest subset YAML parser ----------
         Supports: block mappings, block sequences, plain / single- / double-quoted
         scalars, one-line flow maps and sequences, block scalars (| and >),
         comments. Anything else (anchors, aliases, multi-document files,
         inconsistent indentation, unbalanced flow) throws {line, message}
         and the audit reports "could not parse" instead of guessing. */

      function stripComment(line) {
        var inS = false, inD = false;
        for (var i = 0; i < line.length; i++) {
          var c = line.charAt(i);
          if (inD) { if (c === "\\") { i++; } else if (c === '"') { inD = false; } continue; }
          if (inS) { if (c === "'") { inS = false; } continue; }
          if (c === '"') { inD = true; continue; }
          if (c === "'") { inS = true; continue; }
          if (c === "#" && (i === 0 || line.charAt(i - 1) === " " || line.charAt(i - 1) === "\t")) {
            return line.slice(0, i);
          }
        }
        return line;
      }

      function unquote(s) {
        s = s.replace(/^\s+|\s+$/g, "");
        if (s.length >= 2 && s.charAt(0) === '"' && s.charAt(s.length - 1) === '"') {
          try { return JSON.parse(s); } catch (e) { return s.slice(1, -1); }
        }
        if (s.length >= 2 && s.charAt(0) === "'" && s.charAt(s.length - 1) === "'") {
          return s.slice(1, -1).replace(/''/g, "'");
        }
        return s;
      }

      // Recursive-descent parse of a one-line flow value: [a, b], {k: v}, scalars.
      function parseFlow(str, lineNo) {
        var pos = 0;
        function fail(msg) { throw { line: lineNo, message: msg }; }
        function skipWs() { while (pos < str.length && str.charAt(pos) === " ") { pos++; } }
        function parseValue() {
          skipWs();
          if (pos >= str.length) { fail("empty flow value"); }
          var c = str.charAt(pos);
          if (c === "[") {
            pos++;
            var items = [];
            skipWs();
            if (str.charAt(pos) === "]") { pos++; return { t: "seq", items: items }; }
            for (;;) {
              items.push(parseValue());
              skipWs();
              if (str.charAt(pos) === ",") { pos++; continue; }
              if (str.charAt(pos) === "]") { pos++; break; }
              fail("unbalanced flow sequence");
            }
            return { t: "seq", items: items };
          }
          if (c === "{") {
            pos++;
            var entries = [];
            skipWs();
            if (str.charAt(pos) === "}") { pos++; return { t: "map", entries: entries }; }
            for (;;) {
              skipWs();
              var key = parseFlowKey();
              skipWs();
              if (str.charAt(pos) !== ":") { fail("expected ':' in flow mapping"); }
              pos++;
              var val = parseValue();
              entries.push({ key: key, value: val });
              skipWs();
              if (str.charAt(pos) === ",") { pos++; continue; }
              if (str.charAt(pos) === "}") { pos++; break; }
              fail("unbalanced flow mapping");
            }
            return { t: "map", entries: entries };
          }
          return { t: "scalar", value: parseFlowScalar() };
        }
        function parseFlowKey() {
          skipWs();
          var c = str.charAt(pos);
          if (c === '"' || c === "'") { return unquote(parseQuoted()); }
          var start = pos;
          while (pos < str.length && str.charAt(pos) !== ":" && str.charAt(pos) !== ",") { pos++; }
          return str.slice(start, pos).replace(/\s+$/g, "");
        }
        function parseQuoted() {
          var q = str.charAt(pos), start = pos;
          pos++;
          while (pos < str.length) {
            var ch = str.charAt(pos);
            if (q === '"' && ch === "\\") { pos += 2; continue; }
            if (ch === q) {
              if (q === "'" && str.charAt(pos + 1) === "'") { pos += 2; continue; }
              pos++;
              return str.slice(start, pos);
            }
            pos++;
          }
          fail("unterminated quoted string in flow value");
        }
        function parseFlowScalar() {
          if (str.charAt(pos) === '"' || str.charAt(pos) === "'") { return unquote(parseQuoted()); }
          var start = pos;
          while (pos < str.length && ",]}".indexOf(str.charAt(pos)) === -1) { pos++; }
          return str.slice(start, pos).replace(/^\s+|\s+$/g, "");
        }
        var result = parseValue();
        skipWs();
        if (pos < str.length) { fail("trailing characters after flow value"); }
        return result;
      }

      function scalarOrFlow(text, lineNo) {
        var t = text.replace(/^\s+|\s+$/g, "");
        if (t.charAt(0) === "[" || t.charAt(0) === "{") { return parseFlow(t, lineNo); }
        if (/^[&*][A-Za-z0-9_-]+/.test(t)) {
          throw { line: lineNo, message: "anchors and aliases (&name / *name) are outside this parser's subset" };
        }
        return { t: "scalar", value: unquote(t) };
      }

      function splitKey(content) {
        // Returns {key, rest} for "key: rest" / "key:" lines, else null.
        var inS = false, inD = false;
        for (var i = 0; i < content.length; i++) {
          var c = content.charAt(i);
          if (inD) { if (c === "\\") { i++; } else if (c === '"') { inD = false; } continue; }
          if (inS) { if (c === "'") { inS = false; } continue; }
          if (c === '"') { inD = true; continue; }
          if (c === "'") { inS = true; continue; }
          if (c === ":" && (i === content.length - 1 || content.charAt(i + 1) === " ")) {
            return { key: unquote(content.slice(0, i)), rest: content.slice(i + 1).replace(/^ /, "") };
          }
        }
        return null;
      }

      // Turns raw text into content lines: {indent, content, line}.
      // Throws {line, message} on tabs in indentation and multi-document input.
      function lexLines(text) {
        var raw = text.split(/\r\n|\r|\n/);
        var out = [];
        var docStarts = 0;
        for (var i = 0; i < raw.length; i++) {
          var lineNo = i + 1;
          var rawLine = raw[i];
          var leadMatch = rawLine.match(/^[ \t]*/);
          var lead = leadMatch ? leadMatch[0] : "";
          if (lead.indexOf("\t") !== -1 && rawLine.replace(/^\s+/, "") !== "") {
            throw { line: lineNo, tab: true, message: "tab character in indentation" };
          }
          var noComment = stripComment(rawLine);
          var trimmed = noComment.replace(/\s+$/g, "");
          if (trimmed.replace(/^\s+/, "") === "") { continue; }
          var indent = trimmed.match(/^ */)[0].length;
          var content = trimmed.slice(indent);
          if (content === "---") {
            docStarts++;
            if (docStarts > 1 || out.length > 0) {
              throw { line: lineNo, message: "multi-document YAML (---) is outside this parser's subset" };
            }
            continue;
          }
          if (content === "...") { continue; }
          out.push({ indent: indent, content: content, line: lineNo });
        }
        return out;
      }

      // Parses lexed lines into a node tree.
      // Node shapes: {t:'map', entries:[{key,value,line}]}, {t:'seq', items:[{value,line}]},
      // {t:'scalar', value:string}, {t:'null'}.
      function parseBlock(lines, start, indent) {
        var first = lines[start];
        if (!first || first.indent < indent) { return { node: { t: "null" }, next: start }; }
        if (first.indent > indent) {
          throw { line: first.line, message: "unexpected indentation — no parent key owns this line" };
        }
        if (first.content === "-" || first.content.indexOf("- ") === 0) {
          return parseSeq(lines, start, indent);
        }
        if (splitKey(first.content)) {
          return parseMap(lines, start, indent);
        }
        // A bare scalar block (e.g. the value of a key written on following lines).
        var parts = [first.content];
        var i = start + 1;
        while (i < lines.length && lines[i].indent >= indent && !splitKey(lines[i].content) && lines[i].content.indexOf("- ") !== 0 && lines[i].content !== "-") {
          parts.push(lines[i].content);
          i++;
        }
        return { node: scalarOrFlow(parts.join(" "), first.line), next: i };
      }

      function parseMap(lines, start, indent) {
        var entries = [];
        var i = start;
        while (i < lines.length) {
          var L = lines[i];
          if (L.indent < indent) { break; }
          if (L.indent > indent) {
            throw { line: L.line, message: "unexpected indentation inside a mapping" };
          }
          var kv = splitKey(L.content);
          if (!kv) { break; }
          var entry = { key: kv.key, value: null, line: L.line };
          i++;
          if (kv.rest === "|" || kv.rest === ">" || kv.rest === "|-" || kv.rest === ">-" || kv.rest === "|+" || kv.rest === ">+") {
            // Block scalar: swallow every more-indented line as literal text.
            var body = [];
            while (i < lines.length && lines[i].indent > indent) {
              body.push(lines[i].content);
              i++;
            }
            entry.value = { t: "scalar", value: body.join("\n") };
          } else if (kv.rest !== "") {
            entry.value = scalarOrFlow(kv.rest, L.line);
          } else if (i < lines.length && lines[i].indent > indent) {
            var sub = parseBlock(lines, i, lines[i].indent);
            entry.value = sub.node;
            i = sub.next;
          } else if (i < lines.length && lines[i].indent === indent && (lines[i].content === "-" || lines[i].content.indexOf("- ") === 0)) {
            // YAML allows a block sequence at the same indent as its key.
            var sub2 = parseSeq(lines, i, indent);
            entry.value = sub2.node;
            i = sub2.next;
          } else {
            entry.value = { t: "null" };
          }
          entries.push(entry);
        }
        return { node: { t: "map", entries: entries }, next: i };
      }

      function parseSeq(lines, start, indent) {
        var items = [];
        var i = start;
        while (i < lines.length) {
          var L = lines[i];
          if (L.indent !== indent) { break; }
          if (!(L.content === "-" || L.content.indexOf("- ") === 0)) { break; }
          var rest = L.content === "-" ? "" : L.content.slice(2);
          var dashLine = L.line;
          i++;
          if (rest === "") {
            if (i < lines.length && lines[i].indent > indent) {
              var sub = parseBlock(lines, i, lines[i].indent);
              items.push({ value: sub.node, line: dashLine });
              i = sub.next;
            } else {
              items.push({ value: { t: "null" }, line: dashLine });
            }
          } else if (rest === "|" || rest === ">" || rest === "|-" || rest === ">-") {
            var body = [];
            while (i < lines.length && lines[i].indent > indent) { body.push(lines[i].content); i++; }
            items.push({ value: { t: "scalar", value: body.join("\n") }, line: dashLine });
          } else if (splitKey(rest)) {
            // Inline first key of a mapping item: "- name: x" with sibling keys
            // on following lines at indent + 2. Re-lex the item as its own lines.
            var virtual = [{ indent: indent + 2, content: rest, line: dashLine }];
            while (i < lines.length && lines[i].indent > indent) {
              virtual.push(lines[i]);
              i++;
            }
            var parsed = parseBlock(virtual, 0, indent + 2);
            if (parsed.next < virtual.length) {
              throw { line: virtual[parsed.next].line, message: "could not parse this sequence item" };
            }
            items.push({ value: parsed.node, line: dashLine });
          } else {
            items.push({ value: scalarOrFlow(rest, dashLine), line: dashLine });
          }
        }
        return { node: { t: "seq", items: items }, next: i };
      }

      function parseWorkflow(text) {
        var lines = lexLines(text);
        if (lines.length === 0) { throw { line: 1, message: "the input is empty" }; }
        var parsed = parseBlock(lines, 0, lines[0].indent);
        if (parsed.next < lines.length) {
          throw { line: lines[parsed.next].line, message: "could not parse from here — structure is outside this parser's subset" };
        }
        if (parsed.node.t !== "map") {
          throw { line: lines[0].line, message: "a workflow file must be a top-level mapping (name / on / jobs …)" };
        }
        return parsed.node;
      }

      function mapGet(node, key) {
        if (!node || node.t !== "map") { return null; }
        for (var i = 0; i < node.entries.length; i++) {
          if (node.entries[i].key === key) { return node.entries[i]; }
        }
        return null;
      }
      function scalarText(node) {
        if (!node) { return null; }
        if (node.t === "scalar") { return node.value; }
        return null;
      }

      /* ---------- Audit checks ---------- */

      function lineOfIndex(text, idx) {
        var n = 1;
        for (var i = 0; i < idx && i < text.length; i++) { if (text.charAt(i) === "\n") { n++; } }
        return n;
      }

      function checkExpressions(text, errors, notes) {
        var secretNames = {};
        var re = /\$\{\{/g;
        var m;
        while ((m = re.exec(text)) !== null) {
          var start = m.index;
          var line = lineOfIndex(text, start);
          var close = text.indexOf("}}", start + 3);
          var nextOpen = text.indexOf("${{", start + 3);
          if (close === -1 || (nextOpen !== -1 && nextOpen < close)) {
            var snippet = text.slice(start, start + 40).split("\n")[0];
            errors.push({
              title: "Unbalanced expression delimiters",
              loc: "line " + line,
              body: "An expression opens with ${{ but no matching }} closes it: “" + snippet + "…” GitHub rejects the workflow before anything runs.",
              fix: "Fix: close the expression with }} on the same logical line."
            });
            continue;
          }
          var inner = text.slice(start + 3, close);
          var trimmed = inner.replace(/^\s+|\s+$/g, "");
          if (trimmed === "") {
            errors.push({
              title: "Empty expression",
              loc: "line " + line,
              body: "A ${{ }} with nothing inside it evaluates to nothing and usually means a value was deleted by accident.",
              fix: "Fix: put the intended context back, e.g. ${{ github.sha }}, or remove the expression."
            });
            continue;
          }
          var exprSrc = "${{ " + trimmed + " }}";
          // Root contexts: identifiers not preceded by a dot.
          var idRe = /[A-Za-z_][A-Za-z0-9_]*/g;
          var im;
          var reported = {};
          while ((im = idRe.exec(inner)) !== null) {
            var name = im[0];
            var before = inner.slice(0, im.index).replace(/\s+$/g, "");
            if (before.charAt(before.length - 1) === ".") { continue; } // property, not a root
            var restAfter = inner.slice(im.index + name.length).replace(/^\s+/g, "");
            var lower = name.toLowerCase();
            if (restAfter.charAt(0) === "(") {
              if (KNOWN_FUNCTIONS.indexOf(lower) === -1 && !reported["f:" + lower]) {
                reported["f:" + lower] = 1;
                errors.push({
                  title: "Unknown function “" + name + "()” in expression",
                  loc: "line " + line,
                  body: "In " + exprSrc + " — GitHub Actions has no function named " + name + ". Known functions include hashFiles, contains, startsWith, format, join, toJSON, success, failure, cancelled, always.",
                  fix: "Fix: correct the function name, or replace the call with a supported function."
                });
              }
              continue;
            }
            if (EXPR_KEYWORDS.indexOf(lower) !== -1) { continue; }
            if (KNOWN_CONTEXTS.indexOf(lower) !== -1) {
              if (lower === "secrets") {
                var sm = inner.slice(im.index).match(/^secrets\.([A-Za-z_][A-Za-z0-9_]*)/);
                if (sm) { secretNames[sm[1]] = 1; }
              }
              continue;
            }
            if (!reported["c:" + lower]) {
              reported["c:" + lower] = 1;
              errors.push({
                title: "Unknown context “" + name + "” in expression",
                loc: "line " + line,
                body: "In " + exprSrc + " — “" + name + "” is not a GitHub Actions context. Valid roots are: " + KNOWN_CONTEXTS.join(", ") + ". A typo here fails the run or silently empties the value.",
                fix: "Fix: use a valid context root — did you mean one of: " + KNOWN_CONTEXTS.join(", ") + "?"
              });
            }
          }
        }
        // Stray closers with no opener.
        var stripped = text.replace(/\$\{\{[\s\S]*?\}\}/g, "");
        var strayIdx = stripped.indexOf("}}");
        if (strayIdx !== -1) {
          errors.push({
            title: "Stray }} with no opening ${{",
            loc: "line " + lineOfIndex(text, strayIdx),
            body: "A closing }} appears without a matching opening ${{. GitHub treats the workflow as malformed.",
            fix: "Fix: remove the stray }}, or open the expression properly with ${{."
          });
        }
        var names = Object.keys(secretNames).sort();
        if (names.length > 0) {
          notes.push({
            title: "Secrets referenced (names only)",
            loc: names.length + (names.length === 1 ? " secret" : " secrets"),
            body: "Referenced by name: " + names.join(", ") + ". This audit never sees or shows secret values — the names are listed so you can confirm each one exists in the repo or environment settings before the run."
          });
        }
      }

      function auditPermissions(permsEntry, where, risks, notes) {
        if (!permsEntry) { return false; }
        var node = permsEntry.value;
        var loc = "line " + permsEntry.line;
        var text = scalarText(node);
        if (text !== null) {
          var v = text.replace(/\s+/g, "");
          if (v === "write-all") {
            risks.push({
              title: "permissions: write-all " + where,
              loc: loc,
              body: "write-all hands the GITHUB_TOKEN write access to every scope — contents, packages, deployments, pull requests, all of it — for " + (where === "at the top level" ? "every job in the workflow" : where) + ". A compromised step or action inherits all of it.",
              fix: "Fix: replace write-all with only the scopes this workflow truly writes, e.g.\npermissions:\n  contents: read"
            });
          } else if (v === "read-all") {
            notes.push({
              title: "permissions: read-all " + where,
              loc: loc,
              body: "read-all is explicit and read-only — a reasonable posture when no job needs to write."
            });
          } else {
            risks.push({
              title: "Unusual permissions value “" + text + "” " + where,
              loc: loc,
              body: "Permissions should be read-all, write-all, or a mapping of individual scopes. This value does not parse as any of those.",
              fix: "Fix: use a scope mapping, e.g.\npermissions:\n  contents: read"
            });
          }
          return true;
        }
        if (node.t === "map") {
          var writes = [];
          for (var i = 0; i < node.entries.length; i++) {
            var e = node.entries[i];
            var sv = scalarText(e.value);
            if (sv !== null && sv.replace(/\s+/g, "") === "write") { writes.push(e.key + " (line " + e.line + ")"); }
          }
          if (writes.length > 0) {
            risks.push({
              title: "Write permission granted " + where + ": " + writes.map(function (w) { return w.split(" (")[0]; }).join(", "),
              loc: loc,
              body: "These scopes are set to write " + where + ": " + writes.join(", ") + ". Write scopes are sometimes necessary (releases, comments, deployments) — but each one is a standing capability every step in scope can use, including third-party actions.",
              fix: "Fix: keep only the write scopes the job genuinely uses; drop the rest to read or none."
            });
          }
          return true;
        }
        return true;
      }

      function auditUses(usesText, line, jobId, risks, notes) {
        var loc = "line " + line;
        var where = jobId ? " in job “" + jobId + "”" : "";
        if (/^docker:\/\//.test(usesText)) {
          notes.push({
            title: "Docker image step: " + usesText,
            loc: loc,
            body: "This step runs a Docker image directly" + where + ". Image tags are mutable — prefer pinning by digest (image@sha256:…) for the same reason actions are pinned by commit SHA."
          });
          return;
        }
        if (usesText.indexOf("./") === 0 || usesText.indexOf("/") === -1 && usesText.indexOf("@") === -1 && usesText.indexOf(":") === -1) {
          notes.push({
            title: "Local action: " + usesText,
            loc: loc,
            body: "This step calls an action from the same repository" + where + ", so there is no external ref to pin."
          });
          return;
        }
        var at = usesText.lastIndexOf("@");
        var path = at === -1 ? usesText : usesText.slice(0, at);
        var ref = at === -1 ? null : usesText.slice(at + 1);
        var owner = path.split("/")[0];
        var repoPath = path.split("/").slice(0, 2).join("/");
        var thirdParty = !FIRST_PARTY_OWNERS[owner];
        if (ref === null || ref === "") {
          risks.push({
            title: "Action with no pinned ref: " + path,
            loc: loc,
            body: "“uses: " + usesText + "”" + where + " names no version at all. GitHub resolves the action's default branch — code you never reviewed, which can change under you at any time.",
            fix: "Fix: pin it to a full-length commit SHA:\nuses: " + path + "@<full-length commit SHA>"
          });
          return;
        }
        if (/^[0-9a-f]{40}$/i.test(ref)) {
          return; // Pinned to a full-length commit SHA — the safe form.
        }
        var majorMatch = ref.match(/^v?(\d+)(?:\.(\d+))?(?:\.(\d+))?$/);
        if (majorMatch) {
          var major = parseInt(majorMatch[1], 10);
          risks.push({
            title: "Action pinned to a mutable tag: " + usesText,
            loc: loc,
            body: "“" + ref + "” is a tag" + where + ". Tags can be re-pointed by the action's maintainer — deliberately or after a compromise — so the code that runs is not fixed. " + (thirdParty ? "This is a third-party action, which raises the stakes." : ""),
            fix: "Fix: pin to the tag's full-length commit SHA and keep the tag as a comment:\nuses: " + path + "@<full-length commit SHA> # " + ref
          });
          var minMajor = ACTION_MIN_MAJOR[repoPath.toLowerCase()];
          if (minMajor !== undefined && major < minMajor) {
            risks.push({
              title: "Possibly deprecated action version: " + usesText,
              loc: loc,
              body: repoPath + " is at major v" + major + "; the built-in version snapshot (" + SNAPSHOT_LABEL + ") treats v" + minMajor + " as the oldest current major. Older majors typically stop receiving security fixes and may rely on deprecated runner features.",
              fix: "Fix: upgrade to at least " + repoPath + "@v" + minMajor + " (then pin that release by commit SHA). Verify the current version — this page does not fetch anything."
            });
          }
          return;
        }
        risks.push({
          title: "Action pinned to a branch: " + usesText,
          loc: loc,
          body: "“" + ref + "” is a branch name" + where + ". Every push to that branch changes the code your workflow runs — the classic Actions supply-chain hole" + (thirdParty ? ", and this is a third-party action" : "") + ".",
          fix: "Fix: pin to a full-length commit SHA instead:\nuses: " + path + "@<full-length commit SHA> # was @" + ref
        });
      }

      function audit(text) {
        var errors = [], risks = [], notes = [];
        checkExpressions(text, errors, notes);

        var root;
        try {
          root = parseWorkflow(text);
        } catch (e) {
          if (e && e.tab) {
            errors.push({
              title: "Tab character in YAML indentation",
              loc: "line " + e.line,
              body: "YAML forbids tabs for indentation. This line starts with a tab, so GitHub's parser rejects the file.",
              fix: "Fix: replace the leading tab with spaces (two per level)."
            });
            // Retry with tabs expanded so the rest of the audit can still run.
            try {
              root = parseWorkflow(text.replace(/^\t+/gm, function (s) { return s.replace(/\t/g, "  "); }));
            } catch (e2) {
              errors.push({
                title: "Could not parse this file",
                loc: "line " + (e2.line || 1),
                body: "After expanding tabs, the subset parser still stopped: " + (e2.message || "unknown structure") + ". The audit cannot judge structure it cannot read, so treat the verdict as do-not-run until the file parses.",
                fix: "Fix: correct the YAML at the reported line, then re-run the audit."
              });
              return { errors: errors, risks: risks, notes: notes, parseFailed: true };
            }
          } else {
            errors.push({
              title: "Could not parse this file",
              loc: "line " + (e.line || 1),
              body: "The page's subset YAML parser stopped here: " + (e.message || "unknown structure") + ". Rather than guess, the audit reports the failure — GitHub's own parser is stricter still.",
              fix: "Fix: correct the YAML at the reported line, then re-run the audit."
            });
            return { errors: errors, risks: risks, notes: notes, parseFailed: true };
          }
        }

        // Tabs anywhere else (e.g. after spaces) — catch remaining tab-indented lines.
        var rawLines = text.split(/\r\n|\r|\n/);
        for (var ti = 0; ti < rawLines.length; ti++) {
          var lm = rawLines[ti].match(/^[ \t]+/);
          if (lm && lm[0].indexOf("\t") !== -1 && rawLines[ti].replace(/^\s+/, "") !== "") {
            var already = false;
            for (var ei = 0; ei < errors.length; ei++) {
              if (errors[ei].title.indexOf("Tab character") === 0 && errors[ei].loc === "line " + (ti + 1)) { already = true; }
            }
            if (!already) {
              errors.push({
                title: "Tab character in YAML indentation",
                loc: "line " + (ti + 1),
                body: "This line's indentation contains a tab. YAML forbids tabs for indentation, and GitHub rejects the file.",
                fix: "Fix: replace the tab with spaces (two per level)."
              });
            }
          }
        }

        // --- Triggers: schedule + workflow_dispatch notes ---
        var onEntry = mapGet(root, "on") || mapGet(root, "true"); // YAML 1.1 reads bare `on` as true in some parsers; we keep it a string, but check both.
        if (onEntry && onEntry.value.t === "map") {
          var sched = mapGet(onEntry.value, "schedule");
          if (sched && sched.value.t === "seq") {
            for (var si = 0; si < sched.value.items.length; si++) {
              var item = sched.value.items[si];
              var cron = item.value.t === "map" ? scalarText((mapGet(item.value, "cron") || {}).value) : null;
              notes.push({
                title: "Scheduled workflow" + (cron ? ": cron “" + cron + "”" : ""),
                loc: "line " + item.line,
                body: "This workflow runs on a schedule" + (cron ? " (" + cron + ", in UTC)" : "") + ". Scheduled runs use the default branch and the workflow's permissions — make sure the permission audit above is a posture you want running unattended."
              });
            }
          }
          var wd = mapGet(onEntry.value, "workflow_dispatch");
          if (wd && wd.value.t === "map") {
            var inputs = mapGet(wd.value, "inputs");
            if (inputs && inputs.value.t === "map" && inputs.value.entries.length > 0) {
              var names = inputs.value.entries.map(function (en) { return en.key; });
              notes.push({
                title: "workflow_dispatch inputs: " + names.join(", "),
                loc: "line " + wd.line,
                body: "Manual runs accept these inputs: " + names.join(", ") + ". Anyone with write access to the repo can supply them — if an input flows into a run: command, treat it as untrusted input."
              });
            } else {
              notes.push({
                title: "Manual trigger: workflow_dispatch",
                loc: "line " + wd.line,
                body: "This workflow can be started by hand from the Actions tab or the API by anyone with write access."
              });
            }
          }
        }

        // --- Top-level permissions ---
        var topPerms = mapGet(root, "permissions");
        if (!topPerms) {
          risks.push({
            title: "No top-level permissions block",
            loc: "whole file",
            body: "Without a top-level permissions: block, every job runs with the repository's default GITHUB_TOKEN permissions — on many repos that default is permissive read/write. The workflow inherits whatever the repo allows instead of declaring what it needs.",
            fix: "Fix: add a restrictive default at the top level and widen per job only where needed:\npermissions:\n  contents: read"
          });
        } else {
          auditPermissions(topPerms, "at the top level", risks, notes);
        }

        // --- Jobs ---
        var jobsEntry = mapGet(root, "jobs");
        if (!jobsEntry || jobsEntry.value.t !== "map") {
          errors.push({
            title: "No jobs defined",
            loc: jobsEntry ? "line " + jobsEntry.line : "whole file",
            body: "A workflow must define at least one job under jobs:. GitHub rejects a workflow with no jobs.",
            fix: "Fix: add a jobs: section with at least one job that has runs-on and steps."
          });
        } else {
          var seenJobs = {};
          for (var ji = 0; ji < jobsEntry.value.entries.length; ji++) {
            var jobEntry = jobsEntry.value.entries[ji];
            var jobId = jobEntry.key;
            if (seenJobs[jobId]) {
              errors.push({
                title: "Duplicate job id: “" + jobId + "”",
                loc: "line " + jobEntry.line,
                body: "Job id “" + jobId + "” is defined twice (first at line " + seenJobs[jobId] + "). Duplicate keys make the workflow invalid — GitHub refuses to run it.",
                fix: "Fix: rename one of the two “" + jobId + "” jobs so every job id is unique."
              });
              continue;
            }
            seenJobs[jobId] = jobEntry.line;
            var job = jobEntry.value;
            if (job.t !== "map") {
              errors.push({
                title: "Job “" + jobId + "” is not a mapping",
                loc: "line " + jobEntry.line,
                body: "Each job must be a mapping with runs-on and steps. This one parses as a scalar or list.",
                fix: "Fix: give job “" + jobId + "” a runs-on: line and a steps: list."
              });
              continue;
            }
            var runsOn = mapGet(job, "runs-on");
            var roText = runsOn ? scalarText(runsOn.value) : null;
            if (!runsOn || (roText !== null && roText.replace(/\s+/g, "") === "") || (runsOn.value.t === "null")) {
              errors.push({
                title: "Job “" + jobId + "” has no runs-on",
                loc: "line " + jobEntry.line,
                body: "Every job needs runs-on to name its runner (for example ubuntu-latest). Without it GitHub cannot schedule the job and rejects the workflow.",
                fix: "Fix: add under job “" + jobId + "”:\n  runs-on: ubuntu-latest"
              });
            }
            var jobPerms = mapGet(job, "permissions");
            if (jobPerms) {
              auditPermissions(jobPerms, "in job “" + jobId + "”", risks, notes);
            }
            var stepsEntry = mapGet(job, "steps");
            if (stepsEntry && stepsEntry.value.t === "seq") {
              for (var sti = 0; sti < stepsEntry.value.items.length; sti++) {
                var stepItem = stepsEntry.value.items[sti];
                var step = stepItem.value;
                var stepName = null;
                if (step.t === "map") {
                  var nameEntry = mapGet(step, "name");
                  if (nameEntry) { stepName = scalarText(nameEntry.value); }
                  var usesEntry = mapGet(step, "uses");
                  var runEntry = mapGet(step, "run");
                  var hasUses = !!(usesEntry && scalarText(usesEntry.value) !== null && scalarText(usesEntry.value) !== "");
                  var hasRun = !!(runEntry && runEntry.value.t !== "null");
                  if (!hasUses && !hasRun) {
                    errors.push({
                      title: "Step with neither uses nor run" + (stepName ? ": “" + stepName + "”" : ""),
                      loc: "line " + stepItem.line,
                      body: "A step in job “" + jobId + "” has no uses: (an action to call) and no run: (a command to execute). GitHub rejects steps that do nothing.",
                      fix: "Fix: give the step a uses: action or a run: command — or delete the step."
                    });
                  }
                  if (hasUses) {
                    auditUses(scalarText(usesEntry.value), usesEntry.line, jobId, risks, notes);
                  }
                } else {
                  errors.push({
                    title: "Step is not a mapping in job “" + jobId + "”",
                    loc: "line " + stepItem.line,
                    body: "Each step must be a mapping with uses: or run:. This step parses as a plain value.",
                    fix: "Fix: rewrite the step as a mapping, e.g.\n  - name: Do the thing\n    run: echo hello"
                  });
                }
              }
            }
          }
        }

        return { errors: errors, risks: risks, notes: notes, parseFailed: false };
      }

      /* ---------- Rendering ---------- */
      var lastReport = "";
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_BAD": (typeof EXAMPLE_BAD !== 'undefined' ? EXAMPLE_BAD : undefined), "EXAMPLE_CLEAN": (typeof EXAMPLE_CLEAN !== 'undefined' ? EXAMPLE_CLEAN : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-github-actions-workflow-safety-auditor',
  name: 'J-Dawgs GitHub Actions Workflow Safety Auditor',
  description: 'Install-first workflow linters stop at syntax; ours audits a pasted GitHub Actions workflow in the browser — expression mistakes, permission excess, unpinned actions, deprecated versions — and returns one verdict plus a fix list',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_BAD": __core["EXAMPLE_BAD"], "EXAMPLE_CLEAN": __core["EXAMPLE_CLEAN"] }
};
