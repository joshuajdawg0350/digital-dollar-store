'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Bundler Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        'use strict';

        var FLAWED_CONFIG = [
          "import { defineConfig } from 'vite'",
          "import react from '@vitejs/plugin-react'",
          "",
          "export default defineConfig({",
          "  plugins: [react()],",
          "  server: {",
          "    host: '0.0.0.0',",
          "    port: 5173,",
          "    cors: {",
          "      origin: '*'",
          "    }",
          "  },",
          "  build: {",
          "    sourcemap: true",
          "  }",
          "})"
        ].join("\n");
        var FLAWED_ENV = "VITE_API_URL\nVITE_STRIPE_SECRET_KEY";

        var CLEAN_CONFIG = [
          "import { defineConfig } from 'vite'",
          "import react from '@vitejs/plugin-react'",
          "",
          "export default defineConfig({",
          "  plugins: [react()],",
          "  server: {",
          "    host: 'localhost',",
          "    port: 5173",
          "  },",
          "  build: {",
          "    sourcemap: false",
          "    minify: 'esbuild'",
          "  }",
          "})"
        ].join("\n");
        var CLEAN_ENV = "VITE_API_URL\nVITE_PUBLISHABLE_KEY";

        var configInput = document.getElementById('configInput');
        var envInput = document.getElementById('envInput');
        var resultsCard = document.getElementById('resultsCard');
        var verdictBox = document.getElementById('verdictBox');
        var verdictLabel = document.getElementById('verdictLabel');
        var verdictSub = document.getElementById('verdictSub');
        var findingsList = document.getElementById('findingsList');
        var noFindings = document.getElementById('noFindings');
        var reportText = document.getElementById('reportText');
        var runStatus = document.getElementById('runStatus');
        var copyStatus = document.getElementById('copyStatus');

        function findLine(lines, re) {
          for (var i = 0; i < lines.length; i++) {
            if (re.test(lines[i])) return i;
          }
          return -1;
        }

        function audit(configText, envText) {
          var lines = configText.split(/\r?\n/);
          var findings = [];
          function add(sev, lineIdx, locLabel, msg) {
            findings.push({
              sev: sev,
              line: (typeof lineIdx === 'number' && lineIdx >= 0) ? lineIdx + 1 : null,
              loc: locLabel,
              msg: msg
            });
          }

          /* ---------- detection ---------- */
          var viteSignals = [/defineConfig/, /from\s+['"]vite['"]/, /require\(\s*['"]vite['"]/, /@vitejs\//, /envPrefix/, /import\.meta\.env/];
          var webpackSignals = [/devtool/, /DefinePlugin/, /EnvironmentPlugin/, /\bwebpack\b/, /module\.exports/, /\bentry\s*:/];
          function countSignals(list) {
            var n = 0;
            for (var i = 0; i < list.length; i++) if (list[i].test(configText)) n++;
            return n;
          }
          var vScore = countSignals(viteSignals);
          var wScore = countSignals(webpackSignals);
          var bundler = null;
          if (vScore > 0 && vScore >= wScore) bundler = 'Vite';
          else if (wScore > 0) bundler = 'webpack';

          var knownKeys = [/\bhost\s*:/, /\bcors\s*:/, /\bproxy\s*:/, /\bhttps\s*:/, /\bsourcemap\s*:/, /\bdevtool\s*:/, /\bminify\s*:/, /envPrefix/, /DefinePlugin/, /EnvironmentPlugin/, /\bplugins\s*:/, /\bserver\s*:/, /\bbuild\s*:/, /\bmode\s*:/, /\bentry\s*:/, /\boutput\s*:/];
          var knownFound = 0;
          for (var k = 0; k < knownKeys.length; k++) if (knownKeys[k].test(configText)) knownFound++;

          if (!bundler || knownFound === 0) {
            return { couldNot: true, bundler: null, findings: [] };
          }

          var productionLooking = /mode\s*:\s*['"]production['"]/.test(configText) ||
            /NODE_ENV\s*[:=]\s*['"]production['"]/.test(configText) ||
            /process\.env\.NODE_ENV\s*===?\s*['"]production['"]/.test(configText);

          /* ---------- check 5: eval( anywhere ---------- */
          for (var e = 0; e < lines.length; e++) {
            if (/(^|[^\w$.])eval\s*\(/.test(lines[e])) {
              add('BLOCKER', e, 'Line ' + (e + 1),
                'eval( is used in this config. eval executes arbitrary code at runtime — a config that evals must never ship. Remove it and use a plain value or an explicit lookup instead.');
            }
          }

          /* ---------- check 1: dev server on all interfaces ---------- */
          var hostIdx = -1, hostVal = '';
          for (var h = 0; h < lines.length; h++) {
            var hm = lines[h].match(/host\s*:\s*(?:'([^']*)'|"([^"]*)"|(true)\b)/);
            if (hm) {
              var hv = hm[1] || hm[2] || hm[3] || '';
              if (hv === '0.0.0.0' || hv === '::' || hv === true || hv === 'true') { hostIdx = h; hostVal = hv; break; }
            }
          }
          if (hostIdx >= 0) {
            var openIdx = findLine(lines, /open\s*:\s*true/);
            var corsIdx = -1;
            for (var c = 0; c < lines.length; c++) {
              if (/origin\s*:/.test(lines[c]) && (/['"]\*['"]/.test(lines[c]))) { corsIdx = c; break; }
              if (/cors\s*:\s*['"]\*['"]/.test(lines[c])) { corsIdx = c; break; }
            }
            if (openIdx >= 0 || corsIdx >= 0) {
              var partner = corsIdx >= 0
                ? "a CORS origin of '*' (line " + (corsIdx + 1) + ') lets any website make requests to it'
                : 'server.open (line ' + (openIdx + 1) + ') is enabled alongside it';
              add('BLOCKER', hostIdx, 'Line ' + (hostIdx + 1),
                "Dev server is bound to all interfaces (host: '" + hostVal + "') and " + partner +
                '. Anyone on the local network can reach this dev server. Bind to localhost and restrict CORS origins before shipping or sharing this setup.');
            } else {
              add('WARNING', hostIdx, 'Line ' + (hostIdx + 1),
                "Dev server is bound to all interfaces (host: '" + hostVal + "') — the dev server is reachable from the local network. Bind to 'localhost' unless you deliberately need LAN access.");
            }
          }

          /* ---------- check 2a: client-prefixed secret-named env vars ---------- */
          var prefix = bundler === 'Vite' ? 'VITE_' : null;
          var envNames = envText.split(/[\s,;]+/).filter(function (s) { return s.length > 0; });
          var seen = {};
          envNames.forEach(function (raw) {
            var name = raw.trim();
            if (!name || seen[name]) return;
            seen[name] = true;
            if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(name)) return;
            if (prefix && name.indexOf(prefix) !== 0) return;
            if (!prefix) return;
            if (/_PUBLIC$/.test(name)) return;
            if (name.indexOf('PUBLISHABLE') >= 0) return;
            if (/(SECRET|TOKEN|PASSWORD|PRIVATE|KEY)/.test(name)) {
              add('BLOCKER', -1, 'Env names list',
                name + ' starts with the ' + prefix + ' client prefix, so its value is embedded in the shipped client bundle where anyone can read it — and its name marks it as a secret. Named here only; no value was provided or shown. Move the secret behind a server and expose only a publishable, public-safe key to the client.');
            }
          });

          /* ---------- check 2b: envPrefix widened (Vite) ---------- */
          if (bundler === 'Vite') {
            var epIdx = findLine(lines, /envPrefix\s*:/);
            if (epIdx >= 0) {
              var epLine = lines[epIdx];
              var isDefaultOnly = /envPrefix\s*:\s*(?:'VITE_'|"VITE_"|\[\s*'VITE_'\s*\]|\[\s*"VITE_"\s*\])/.test(epLine);
              if (!isDefaultOnly) {
                add('WARNING', epIdx, 'Line ' + (epIdx + 1),
                  "envPrefix is set wider than Vite's default ('VITE_'). Every environment variable matching the widened prefix is embedded in the shipped client bundle. Keep the default prefix unless every additionally exposed variable is public-safe.");
              }
            }
          }

          /* ---------- check 3: webpack wholesale process.env ---------- */
          if (bundler === 'webpack') {
            var wsIdx = findLine(lines, /JSON\.stringify\(\s*process\.env\s*\)/);
            if (wsIdx < 0 && /(DefinePlugin|EnvironmentPlugin)/.test(configText)) {
              wsIdx = findLine(lines, /process\.env(?![\w.])/);
            }
            if (wsIdx >= 0) {
              add('BLOCKER', wsIdx, 'Line ' + (wsIdx + 1),
                'This config embeds process.env wholesale into the bundle (DefinePlugin / EnvironmentPlugin with the whole environment). Every variable present at build time — including secrets — gets baked into the shipped client code. Pass an explicit allowlist of public-safe variables instead.');
            }
          }

          /* ---------- check 4: production sourcemaps / devtool ---------- */
          if (bundler === 'Vite') {
            var smIdx = findLine(lines, /sourcemap\s*:\s*true/);
            if (smIdx >= 0) {
              add('WARNING', smIdx, 'Line ' + (smIdx + 1),
                'build.sourcemap: true ships production sourcemaps with the bundle. Sourcemaps hand anyone your original source code. Turn sourcemaps off for production, or emit them separately and keep them private.');
            }
          }
          if (bundler === 'webpack') {
            var dtIdx = -1, dtVal = '';
            for (var d = 0; d < lines.length; d++) {
              var dm = lines[d].match(/devtool\s*:\s*['"]([^'"]+)['"]/);
              if (dm) { dtIdx = d; dtVal = dm[1]; break; }
            }
            if (dtIdx >= 0) {
              if (dtVal.indexOf('eval') >= 0) {
                add('BLOCKER', dtIdx, 'Line ' + (dtIdx + 1),
                  "devtool is '" + dtVal + "', an eval-based devtool. Eval-based devtools must never ship — they execute bundled code through eval in the browser. Use 'source-map' for a separate debug build or false for production.");
              } else if (dtVal.indexOf('source-map') >= 0 && productionLooking) {
                add('WARNING', dtIdx, 'Line ' + (dtIdx + 1),
                  "devtool is '" + dtVal + "' in a production-looking config. Production sourcemaps expose your original source to anyone who downloads the bundle. Set devtool to false for the production build.");
              }
            }
          }

          /* ---------- check 6: URL / unpinned plugin or loader specifiers ---------- */
          for (var u = 0; u < lines.length; u++) {
            var ln = lines[u];
            var refContext = /(require\s*\(|from\s+['"]|import\s|loader|plugin)/i.test(ln);
            if (!refContext) continue;
            var urlMatch = ln.match(/https?:\/\/([^\s/'"]+)/);
            var latestMatch = /@latest\b/.test(ln) || /[:=]\s*['"]latest['"]/.test(ln);
            if (urlMatch) {
              add('WARNING', u, 'Line ' + (u + 1),
                'A plugin or loader is referenced from a URL (host: ' + urlMatch[1] + '). Code loaded from a URL can change or disappear at any time and bypasses your lockfile. Install it from the registry and pin an exact version instead.');
            } else if (latestMatch) {
              add('WARNING', u, 'Line ' + (u + 1),
                "A plugin or loader uses an unpinned 'latest' specifier. 'latest' can pull in changed or compromised code on any install. Pin an exact version instead.");
            }
          }

          /* ---------- check 7: minify disabled ---------- */
          var mfIdx = findLine(lines, /minify\s*:\s*false/);
          if (mfIdx >= 0) {
            add('INFO', mfIdx, 'Line ' + (mfIdx + 1),
              'minify: false disables minification. The shipped bundle stays larger and easier to read. That is fine for debugging, but turn minification back on for a production build.');
          }

          /* ---------- check 8: https false / plaintext proxy targets ---------- */
          var httpsIdx = findLine(lines, /https\s*:\s*false/);
          if (httpsIdx >= 0) {
            add('WARNING', httpsIdx, 'Line ' + (httpsIdx + 1),
              'server.https: false turns off TLS for the dev server, so its traffic runs in plaintext on the network. Enable HTTPS for the dev server, especially on a shared network.');
          }
          for (var p = 0; p < lines.length; p++) {
            var pm = lines[p].match(/target\s*:\s*['"]http:\/\/([^/'":]+)/);
            if (pm) {
              var ph = pm[1];
              if (ph !== 'localhost' && ph !== '127.0.0.1' && ph !== '[::1]') {
                add('WARNING', p, 'Line ' + (p + 1),
                  'Proxy target uses plaintext http:// to ' + ph + ' (host named only). Requests and responses through this proxy travel unencrypted. Point the proxy at the https:// endpoint instead.');
              }
            }
          }

          var order = { BLOCKER: 0, WARNING: 1, INFO: 2 };
          findings.sort(function (a, b) {
            if (order[a.sev] !== order[b.sev]) return order[a.sev] - order[b.sev];
            var la = a.line === null ? 0 : a.line;
            var lb = b.line === null ? 0 : b.line;
            return la - lb;
          });

          return { couldNot: false, bundler: bundler, findings: findings };
        }

        function verdictFor(findings) {
          var hasBlocker = findings.some(function (f) { return f.sev === 'BLOCKER'; });
          var hasWarning = findings.some(function (f) { return f.sev === 'WARNING'; });
          if (hasBlocker) return { label: 'DO NOT SHIP', cls: 'bad' };
          if (hasWarning) return { label: 'SHIP WITH FIXES', cls: 'warn' };
          return { label: 'SAFE TO SHIP', cls: 'ok' };
        }

        function counts(findings) {
          var c = { BLOCKER: 0, WARNING: 0, INFO: 0 };
          findings.forEach(function (f) { c[f.sev]++; });
          return c;
        }

        var lastReport = '';
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-bundler-config-safety-auditortm',
  name: 'J-Dawgs Bundler Config Safety Auditor',
  description: 'Bundler checks only prove a config loads; this audits a pasted Vite or webpack config without executing it — dev-server exposure, client-prefixed secret-named env vars (BLOCKER, names only), wholesale process.env embedding, production sourcemaps and eval devtools — into one ship verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
