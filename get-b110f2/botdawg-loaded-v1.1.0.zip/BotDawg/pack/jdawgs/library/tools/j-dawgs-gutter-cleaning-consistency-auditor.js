'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Gutter Cleaning Service Proposal, Work Record & Final Invoice Consistency Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------------- Worked example documents ---------------- */
      var PROPOSAL_AB = [
        "J-Dawgs Gutter Cleaning - Approved Proposal",
        "Property: 142 Maple Street - 2 stories",
        "Gutter cleaning: 180 linear feet at $2.00 per linear foot - $360.00",
        "Downspout flushing: 6 downspouts at $15.00 per downspout - $90.00",
        "Labor rate: $80.00 per hour (for any approved extra labor)",
        "Story surcharge: $50.00 per story above the first story",
        "Service fee (one-time): $25.00",
        "Deposit paid on approval: $150.00",
        "Approved services: gutter cleaning and downspout flushing only.",
        "No gutter-guard work, no roof blow-off, and no repairs are approved."
      ].join("\n");

      var RECORD_AB = [
        "Crew Work Record - 142 Maple Street",
        "Linear feet cleaned: 180 linear feet",
        "Stories: 2 stories",
        "Downspouts flushed: 6 downspouts",
        "Labor: 3.0 hours on site",
        "Deposit received: $150.00",
        "Work completed: gutter cleaning and downspout flushing.",
        "No gutter-guard work, no roof blow-off, and no repairs were performed."
      ].join("\n");

      var INVOICE_A = [
        "Final Invoice - 142 Maple Street",
        "Gutter cleaning - 220 linear feet at $2.00 per linear foot: $440.00",
        "Downspout flushing - 8 downspouts at $15.00 per downspout: $120.00",
        "Story surcharge - 3 stories billed: $100.00",
        "Labor - 5 hours at $80.00 per hour: $400.00",
        "Gutter-guard inspection and adjustment: $85.00",
        "Roof blow-off: $75.00",
        "Service fee: $25.00",
        "Service fee: $25.00",
        "Disposal fee: $40.00",
        "Total due: $1,370.00",
        "(No deposit credit shown.)"
      ].join("\n");

      var INVOICE_B = [
        "Final Invoice - 142 Maple Street",
        "Gutter cleaning - 180 linear feet at $2.00 per linear foot: $360.00",
        "Downspout flushing - 6 downspouts at $15.00 per downspout: $90.00",
        "Story surcharge - 2 stories billed: $50.00",
        "Labor - 3 hours at $80.00 per hour: $240.00",
        "Service fee: $25.00",
        "Subtotal: $765.00",
        "Less deposit credit: -$150.00",
        "Total due: $615.00"
      ].join("\n");

      var EXAMPLES = {
        A: { proposal: PROPOSAL_AB, record: RECORD_AB, invoice: INVOICE_A },
        B: { proposal: PROPOSAL_AB, record: RECORD_AB, invoice: INVOICE_B },
        C: { proposal: PROPOSAL_AB, record: "", invoice: INVOICE_B }
      };

      var PITCHES = {
        tool: "Before anyone pays a gutter-cleaning bill, cross-check the proposal, the crew work record, and the invoice in the J-Dawgs Gutter Cleaning Consistency Auditor - one verdict, arithmetic shown. AI Tool Store: https://muse.ai/s/ai-tool-store-xng6xkxwjkxl2xab/UoF72OkKI7j33Q2ITxmrZyIr4nv40QtYfj2AgESh_k8",
        exchange: "Trade agent-ready tools and services with other agents at the J-Dawgs Agent Exchange: https://muse.ai/s/j-dawgs-agent-exchange-ih6xlnihzxdhxc/ZbleqxFHRE0NcswaBkyN13y9lLp5rPAgHTb6t8ii-PY",
        bundle: "Shelf It, Budget It, Clean It Right Stack \u2014 BookStack Config Safety Auditor + Firefly III Config Safety Auditor + Gutter Cleaning Consistency Auditor: grade the wiki config, grade the finance config, cross-check the gutter invoice."
      };

      /* ---------------- Small helpers ---------------- */
      function money(n){
        var neg = n < 0; var v = Math.abs(n).toFixed(2).split(".");
        v[0] = v[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        return (neg ? "-$" : "$") + v[0] + "." + v[1];
      }
      function round2(n){ return Math.round(n * 100) / 100; }
      function firstNum(text, patterns){
        for (var i = 0; i < patterns.length; i++){
          var m = text.match(patterns[i]);
          if (m) { var v = parseFloat(m[1]); if (!isNaN(v)) return v; }
        }
        return null;
      }
      function linearFeet(text){
        return firstNum(text, [
          /(\d+(?:\.\d+)?)[ \t]*(?:linear[ \t]*feet|linear[ \t]*foot|lin\.?[ \t]*ft\.?|\bLF\b)/i,
          /linear[ \t]*(?:feet|foot)[^0-9\n]{0,24}(\d+(?:\.\d+)?)/i
        ]);
      }
      function stories(text){
        return firstNum(text, [
          /(\d+)[ \t]*[- ]?[ \t]*stor(?:y|ies)\b/i,
          /stor(?:y|ies)[^0-9\n]{0,20}(\d+)/i,
          /(\d+)[ \t]*[- ]?[ \t]*floors?\b/i,
          /floors?[^0-9\n]{0,20}(\d+)/i
        ]);
      }
      function downspouts(text){
        return firstNum(text, [
          /(\d+)[ \t]*downspouts?/i,
          /downspouts?[^0-9\n]{0,20}(\d+)/i
        ]);
      }
      function hours(text){
        return firstNum(text, [
          /(\d+(?:\.\d+)?)[ \t]*hours?\b/i,
          /hours?[^0-9\n]{0,20}(\d+(?:\.\d+)?)/i
        ]);
      }
      function hourlyRate(text){
        return firstNum(text, [
          /\$\s*(\d+(?:\.\d+)?)\s*(?:per\s*hour|\/\s*(?:hour|hr)\b)/i,
          /labor\s*rate[^$\n]*\$\s*(\d+(?:\.\d+)?)/i,
          /rate[^$\n]*\$\s*(\d+(?:\.\d+)?)\s*(?:\/|per)/i
        ]);
      }
      function perLFRate(text){
        return firstNum(text, [
          /\$\s*(\d+(?:\.\d+)?)\s*(?:per\s*(?:linear\s*(?:foot|feet)|LF)|\/\s*(?:LF|linear))/i
        ]);
      }
      function perDownspoutRate(text){
        return firstNum(text, [
          /\$\s*(\d+(?:\.\d+)?)\s*(?:per\s*downspout|\/\s*downspout)/i
        ]);
      }
      function perStoryRate(text){
        return firstNum(text, [
          /\$\s*(\d+(?:\.\d+)?)\s*per\s*stor(?:y|ies)/i
        ]);
      }
      function depositAmount(text){
        return firstNum(text, [
          /(?:deposit|prepayment|prepaid)[^$\n]{0,48}\$\s*([\d,]+(?:\.\d{1,2})?)/i
        ]);
      }

      /* Parse the invoice into charge lines, credits, and a stated total. */
      function parseInvoice(text){
        var lines = text.split(/\n/), items = [], statedTotal = null, i, line, low, amounts, amt;
        for (i = 0; i < lines.length; i++){
          line = lines[i].trim();
          if (!line) continue;
          amounts = [];
          var re = /\$\s*([\d,]+(?:\.\d{1,2})?)/g, m;
          while ((m = re.exec(line)) !== null){ amounts.push(parseFloat(m[1].replace(/,/g, ""))); }
          if (!amounts.length) continue;
          amt = amounts[amounts.length - 1]; /* a line's own total is its last $ figure */
          low = line.toLowerCase();
          if (/subtotal/.test(low)) continue;
          if (/\b(total|amount due|balance due|grand total)\b/.test(low)){ statedTotal = amt; continue; }
          var isCredit = /(credit|prepayment applied|deposit applied)/.test(low) || /\bless\b/.test(low) || /[-]\s*\$/.test(line) || /\u2212\s*\$/.test(line);
          items.push({ label: line, amount: isCredit ? -amt : amt, credit: !!isCredit });
        }
        return { items: items, statedTotal: statedTotal };
      }

      function normalizedLabel(label){
        return label.toLowerCase()
          .replace(/\$\s*[\d,]+(?:\.\d{1,2})?/g, " ")
          .replace(/\d+(?:\.\d+)?/g, " ")
          .replace(/[^a-z\s-]/g, " ")
          .replace(/\s+/g, " ").trim();
      }

      var ADDON_SERVICES = [
        { key: "guard",  label: "Gutter-guard work",        re: /gutter[\s-]*guard|leaf[\s-]*guard/i },
        { key: "roof",   label: "Roof blow-off",            re: /roof[\s-]*blow|blow[\s-]*off/i },
        { key: "repair", label: "Repair work",              re: /\brepair/i },
        { key: "seal",   label: "Sealing / reseal work",    re: /\bsealant\b|\breseal\b|\bsealing\b/i }
      ];
      function recordShowsService(recordText, re){
        var lines = recordText.split(/\n/);
        for (var i = 0; i < lines.length; i++){
          if (re.test(lines[i]) && !/\b(no|not|never|none|without)\b/i.test(lines[i])) return true;
        }
        return false;
      }

      var STOPWORDS = { fee:1, fees:1, charge:1, charges:1, service:1, services:1, per:1, each:1, with:1, from:1, billed:1, bill:1, work:1, done:1, completed:1, total:1, the:1, and:1, for:1, at:1 };

      /* ---------------- The auditor ---------------- */
      function audit(proposal, record, invoice){
        proposal = (proposal || "").trim();
        record = (record || "").trim();
        invoice = (invoice || "").trim();
        var docs = {
          "Approved Proposal": proposal.length >= 10,
          "Crew Work Record": record.length >= 10,
          "Final Invoice": invoice.length >= 10
        };
        var missing = Object.keys(docs).filter(function(k){ return !docs[k]; });
        var findings = [];
        function add(check, title, math, amount){
          findings.push({ check: check, title: title, arithmetic: math, overcharge: amount == null ? null : round2(amount) });
        }

        if (missing.length){
          add("missing-document",
            "Missing document: " + missing.join(", "),
            "Documents pasted: " + (3 - missing.length) + " of 3. A cross-check needs all three; with " + missing.join(", ") + " missing, the best possible verdict is PAY WITH FIXES. Checks that need the missing document were skipped.",
            null);
        }

        var inv = parseInvoice(invoice);
        var hasProp = docs["Approved Proposal"], hasRec = docs["Crew Work Record"], hasInv = docs["Final Invoice"];
        var addonFlagged = {}; /* invoice item indexes already counted as unrecorded add-ons */

        if (hasInv && hasRec){
          /* 1 - Linear feet */
          var lfBilled = linearFeet(invoice), lfCleaned = linearFeet(record);
          if (lfBilled != null && lfCleaned != null && lfBilled > lfCleaned){
            var rateLF = perLFRate(proposal) || perLFRate(invoice);
            var lfLine = null;
            inv.items.forEach(function(it){ if (!it.credit && /linear|gutter\s*clean/i.test(it.label) && lfLine === null) lfLine = it.amount; });
            if (rateLF == null && lfLine != null && lfBilled) rateLF = round2(lfLine / lfBilled);
            var excessLF = lfBilled - lfCleaned;
            var overLF = rateLF != null ? round2(excessLF * rateLF) : null;
            add("linear-feet", "Linear feet billed above linear feet cleaned",
              "Invoice bills " + lfBilled + " linear feet; work record shows " + lfCleaned + " linear feet cleaned. Excess = " + lfBilled + " - " + lfCleaned + " = " + excessLF + " ft" +
              (rateLF != null ? " x " + money(rateLF) + " per ft (proposal rate) = " + money(overLF) + " overcharge." : ". No per-foot rate found, so no dollar amount is counted."),
              overLF);
          }
          /* 2 - Stories */
          var stBilled = stories(invoice), stRecorded = stories(record);
          if (stBilled != null && stRecorded != null && stBilled > stRecorded){
            var storyLine = null;
            inv.items.forEach(function(it){ if (!it.credit && /stor|floor/i.test(it.label) && storyLine === null) storyLine = it.amount; });
            var rateStory = perStoryRate(proposal);
            var earned = null, overStory = null, mathStory;
            if (rateStory != null){
              earned = round2(Math.max(0, stRecorded - 1) * rateStory);
              mathStory = "Invoice bills " + stBilled + " stories; work record shows " + stRecorded + " stories. Surcharge earned at the proposal rate = (" + stRecorded + " - 1) x " + money(rateStory) + " = " + money(earned) + ".";
              if (storyLine != null && storyLine > earned){ overStory = round2(storyLine - earned); mathStory += " Story surcharge billed = " + money(storyLine) + "; " + money(storyLine) + " - " + money(earned) + " = " + money(overStory) + " overcharge."; }
              else if (storyLine == null){ overStory = round2((stBilled - stRecorded) * rateStory); mathStory += " Excess stories = " + (stBilled - stRecorded) + " x " + money(rateStory) + " = " + money(overStory) + " overcharge."; }
            } else {
              mathStory = "Invoice bills " + stBilled + " stories; work record shows " + stRecorded + " stories - " + (stBilled - stRecorded) + " story billed above recorded. No per-story rate found in the proposal, so no dollar amount is counted.";
            }
            add("stories", "Stories billed above stories recorded", mathStory, overStory);
          }
          /* 3 - Downspouts */
          var dsBilled = downspouts(invoice), dsDone = downspouts(record);
          if (dsBilled != null && dsDone != null && dsBilled > dsDone){
            var rateDS = perDownspoutRate(proposal) || perDownspoutRate(invoice);
            var dsLine = null;
            inv.items.forEach(function(it){ if (!it.credit && /downspout/i.test(it.label) && dsLine === null) dsLine = it.amount; });
            if (rateDS == null && dsLine != null && dsBilled) rateDS = round2(dsLine / dsBilled);
            var excessDS = dsBilled - dsDone;
            var overDS = rateDS != null ? round2(excessDS * rateDS) : null;
            add("downspouts", "Downspouts billed above downspouts flushed/cleaned",
              "Invoice bills " + dsBilled + " downspouts; work record shows " + dsDone + " flushed/cleaned. Excess = " + dsBilled + " - " + dsDone + " = " + excessDS +
              (rateDS != null ? " x " + money(rateDS) + " per downspout = " + money(overDS) + " overcharge." : ". No per-downspout rate found, so no dollar amount is counted."),
              overDS);
          }
          /* 5 - Labor (checked before add-ons so its arithmetic stands alone) */
          var recHours = hours(record), propRate = hourlyRate(proposal) || hourlyRate(invoice);
          var laborBilled = 0, hasLabor = false;
          inv.items.forEach(function(it){ if (!it.credit && /labor|labour/i.test(it.label)){ laborBilled += it.amount; hasLabor = true; } });
          if (hasLabor && recHours != null && propRate != null){
            var expectedLabor = round2(recHours * propRate);
            if (laborBilled > expectedLabor + 0.5){
              var billedHours = hours(invoice);
              add("labor", "Labor billed above recorded hours x proposal rate",
                "Work record shows " + recHours + " hours; proposal rate is " + money(propRate) + " per hour. Earned labor = " + recHours + " x " + money(propRate) + " = " + money(expectedLabor) + ". Invoice bills " + money(laborBilled) + " for labor" +
                (billedHours != null ? " (" + billedHours + " hours)" : "") + ". " + money(laborBilled) + " - " + money(expectedLabor) + " = " + money(round2(laborBilled - expectedLabor)) + " overcharge.",
                round2(laborBilled - expectedLabor));
            }
          }
          /* 4 - Unrecorded add-ons */
          inv.items.forEach(function(it, idx){
            if (it.credit) return;
            ADDON_SERVICES.forEach(function(svc){
              if (addonFlagged[idx]) return;
              if (svc.re.test(it.label) && !recordShowsService(record, svc.re)){
                addonFlagged[idx] = true;
                add("unrecorded-addon", "Unrecorded add-on billed: " + svc.label,
                  "Invoice line \"" + it.label.trim() + "\" charges " + money(it.amount) + " for " + svc.label.toLowerCase() + ", but the crew work record never shows that work being performed (any mention in the record is a \"not performed\" note). Full line amount counted: " + money(it.amount) + ".",
                  it.amount);
              }
            });
          });
        }

        if (hasInv){
          /* 6 - Deposit / prepayment credit */
          var depositExpected = null;
          [depositAmount(proposal), depositAmount(record)].forEach(function(v){ if (v != null) depositExpected = depositExpected == null ? v : Math.max(depositExpected, v); });
          if (depositExpected != null && depositExpected > 0){
            var credited = 0;
            inv.items.forEach(function(it){ if (it.credit && /deposit|prepay/i.test(it.label)) credited += -it.amount; });
            if (credited < depositExpected - 0.5){
              var uncredited = round2(depositExpected - credited);
              add("deposit", "Deposit / prepayment not credited on the invoice",
                "Proposal/record show a deposit of " + money(depositExpected) + ". Deposit credit on the invoice = " + money(credited) + ". Uncredited = " + money(depositExpected) + " - " + money(credited) + " = " + money(uncredited) + " overcharge.",
                uncredited);
            }
          }
          /* 7 - Duplicate fee */
          var seen = {};
          inv.items.forEach(function(it){
            if (it.credit) return;
            var key = normalizedLabel(it.label);
            if (!key) return;
            if (!seen[key]) seen[key] = [];
            seen[key].push(it);
          });
          Object.keys(seen).forEach(function(key){
            var group = seen[key];
            if (group.length > 1){
              var amt = group[0].amount;
              var dupOver = round2(amt * (group.length - 1));
              add("duplicate", "Same fee charged " + group.length + " times: \"" + group[0].label.trim() + "\"",
                "The charge \"" + key + "\" appears " + group.length + " times at " + money(amt) + " each. Only one can stand; extra charges = (" + group.length + " - 1) x " + money(amt) + " = " + money(dupOver) + " overcharge.",
                dupOver);
            }
          });
          /* 8 - Invoice-only charges */
          if (hasProp || hasRec){
            var combined = (proposal + "\n" + record).toLowerCase();
            inv.items.forEach(function(it, idx){
              if (it.credit || addonFlagged[idx]) return;
              var words = normalizedLabel(it.label).split(/[\s-]+/).filter(function(w){ return w.length >= 4 && !STOPWORDS[w]; });
              var found = words.some(function(w){
                var stem = w.replace(/s$/, "");
                return combined.indexOf(w) !== -1 || (stem.length >= 4 && combined.indexOf(stem) !== -1);
              });
              if (words.length && !found){
                add("invoice-only", "Invoice-only charge: \"" + it.label.trim() + "\"",
                  "This " + money(it.amount) + " charge appears on the invoice, but none of its identifying words (" + words.join(", ") + ") appear in the proposal or the work record. Full amount counted: " + money(it.amount) + ".",
                  it.amount);
              } else if (!words.length && /service\s*fee/i.test(it.label) && combined.indexOf("service fee") === -1){
                add("invoice-only", "Invoice-only charge: \"" + it.label.trim() + "\"",
                  "This " + money(it.amount) + " service fee appears on the invoice but in neither the proposal nor the work record. Full amount counted: " + money(it.amount) + ".",
                  it.amount);
              }
            });
          }
          /* 9 - Line sum vs stated total */
          if (inv.statedTotal != null && inv.items.length){
            var lineSum = round2(inv.items.reduce(function(s, it){ return s + it.amount; }, 0));
            var diff = round2(inv.statedTotal - lineSum);
            if (Math.abs(diff) > 0.51){
              add("total-mismatch", "Invoice line sum does not match the stated total",
                "Invoice lines (charges minus credits) add to " + money(lineSum) + "; the invoice states a total of " + money(inv.statedTotal) + ". Difference = " + money(inv.statedTotal) + " - " + money(lineSum) + " = " + money(diff) + (diff > 0 ? ", counted as overcharge because the stated total is the higher figure." : ". The stated total is lower than the line sum, so no overcharge is counted, but the bill still has to be corrected before paying."),
                diff > 0 ? diff : null);
            }
          }
        }

        var overcharge = round2(findings.reduce(function(s, f){ return s + (f.overcharge || 0); }, 0));
        var verdict;
        if (!hasInv && !hasProp && !hasRec) verdict = "NO VERDICT";
        else if (findings.length === 0) verdict = "SAFE TO PAY";
        else if (overcharge >= 100) verdict = "DO NOT PAY YET";
        else verdict = "PAY WITH FIXES";
        if (missing.length && verdict === "SAFE TO PAY") verdict = "PAY WITH FIXES";

        return {
          verdict: verdict,
          documentsPresent: docs,
          missingDocuments: missing,
          findings: findings,
          documentedOvercharge: overcharge,
          invoiceLineSum: hasInv && inv.items.length ? round2(inv.items.reduce(function(s, it){ return s + it.amount; }, 0)) : null,
          invoiceStatedTotal: hasInv ? inv.statedTotal : null
        };
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLES": (typeof EXAMPLES !== 'undefined' ? EXAMPLES : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-gutter-cleaning-consistency-auditor',
  name: 'J-Dawgs Gutter Cleaning Service Proposal, Work Record & Final Invoice Consistency Auditor',
  description: 'holding a gutter cleaning proposal, its work record, and a final invoice',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLES": __core["EXAMPLES"] }
};
