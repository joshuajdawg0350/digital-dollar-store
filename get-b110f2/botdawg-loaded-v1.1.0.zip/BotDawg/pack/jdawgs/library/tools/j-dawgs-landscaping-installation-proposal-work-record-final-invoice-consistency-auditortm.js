'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Landscaping Installation Proposal, Work Record & Final Invoice Consistency Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        /* ---------- Samples (exact texts) ---------- */
        var BAD = {
          proposal: [
            "ITEM Sod Pallet | qty 10 | unit pallet | price 40.00",
            "ITEM Rose Bush | qty 5 | unit each | price 20.00",
            "ITEM Mulch Bag | qty 20 | unit bag | price 5.00",
            "LABOR | hours 8 | rate 50.00",
            "DEPOSIT 200.00",
            "FEE Delivery 50.00"
          ].join("\n"),
          work: [
            "ITEM Sod Pallet | qty 10 | unit pallet | price 40.00",
            "ITEM Shrub Generic | qty 5 | unit each | price 20.00",
            "ITEM Mulch Bag | qty 18 | unit bag | price 5.00",
            "LABOR | hours 8 | rate 50.00",
            "DEPOSIT 200.00"
          ].join("\n"),
          invoice: [
            "ITEM Sod Pallet | qty 10 | unit pallet | price 40.00",
            "ITEM Rose Bush | qty 5 | unit each | price 20.00",
            "ITEM Mulch Bag | qty 20 | unit bag | price 5.00",
            "ITEM Fertilizer Bag | qty 2 | unit bag | price 15.00",
            "LABOR | hours 10 | rate 50.00",
            "FEE Delivery 50.00",
            "FEE Delivery 50.00",
            "FEE Disposal 25.00"
          ].join("\n")
        };
        var GOOD_DOC = [
          "ITEM Sod Pallet | qty 10 | unit pallet | price 40.00",
          "ITEM Rose Bush | qty 5 | unit each | price 20.00",
          "LABOR | hours 8 | rate 50.00",
          "FEE Delivery 50.00"
        ].join("\n");
        var GOOD = {
          proposal: GOOD_DOC + "\nDEPOSIT 200.00",
          work: GOOD_DOC + "\nDEPOSIT 200.00",
          invoice: GOOD_DOC + "\nDEPOSIT 200.00"
        };
        var PITCHES = {
          "pitch-store": "AI Tool Store — every J-Dawgs auditor and agent tool in one store: https://muse.ai/s/ai-tool-store-xng6xkxwjkxl2xab/UoF72OkKI7j33Q2ITxmrZyIr4nv40QtYfj2AgESh_k8",
          "pitch-exchange": "J-Dawgs Agent Exchange — agents for hire and agent-built tools: https://muse.ai/s/j-dawgs-agent-exchange-ih6xlnihzxdhxc/ZbleqxFHRE0NcswaBkyN13y9lLp5rPAgHTb6t8ii-PY",
          "pitch-bundle": "Serve It, Support It, Mail It Right Stack — Chatwoot Config Safety Auditor + Mautic Config Safety Auditor + Landscaping Installation Consistency Auditor: grade the support server, grade the mail server, cross-check the landscaping job."
        };

        /* ---------- Money helpers (integer cents, no float drift) ---------- */
        function toCents(s){ return Math.round(parseFloat(String(s).replace(/[$,]/g, "")) * 100); }
        function money(cents){
          var neg = cents < 0; var a = Math.abs(cents);
          var d = Math.floor(a / 100), c = a % 100;
          return (neg ? "-$" : "$") + d + "." + (c < 10 ? "0" : "") + c;
        }
        function qtyStr(n){ return (Math.round(n * 1000) / 1000).toString(); }
        function norm(name){ return String(name).trim().replace(/\s+/g, " ").toLowerCase(); }

        /* ---------- Parser ---------- */
        var RE_ITEM = /^ITEM\s+(.+?)\s*\|\s*qty\s+([0-9]*\.?[0-9]+)\s*\|\s*unit\s+(.+?)\s*\|\s*price\s+\$?([0-9][0-9,]*(?:\.[0-9]+)?)$/i;
        var RE_LABOR = /^LABOR\s*\|\s*hours\s+([0-9]*\.?[0-9]+)\s*\|\s*rate\s+\$?([0-9][0-9,]*(?:\.[0-9]+)?)$/i;
        var RE_DEPOSIT = /^DEPOSIT\s+\$?([0-9][0-9,]*(?:\.[0-9]+)?)$/i;
        var RE_FEE = /^FEE\s+(.+?)\s+\$?([0-9][0-9,]*(?:\.[0-9]+)?)$/i;

        function parseDoc(docName, text){
          var doc = { name: docName, items: [], laborLines: [], laborTotalCents: 0,
                      depositCents: 0, depositLines: 0, fees: [], unparsable: [] };
          var lines = String(text == null ? "" : text).split(/\r?\n/);
          for (var i = 0; i < lines.length; i++){
            var raw = lines[i]; var line = raw.trim(); var m;
            if (!line) continue;
            if ((m = line.match(RE_ITEM))){
              doc.items.push({ name: m[1].trim(), qty: parseFloat(m[2]), unit: m[3].trim(), priceCents: toCents(m[4]), line: i + 1 });
            } else if ((m = line.match(RE_LABOR))){
              var h = parseFloat(m[1]), r = toCents(m[2]);
              doc.laborLines.push({ hours: h, rateCents: r, line: i + 1 });
              doc.laborTotalCents += Math.round(h * r);
            } else if ((m = line.match(RE_DEPOSIT))){
              doc.depositCents += toCents(m[1]); doc.depositLines++;
            } else if ((m = line.match(RE_FEE))){
              doc.fees.push({ name: m[1].trim(), amountCents: toCents(m[2]), line: i + 1 });
            } else {
              doc.unparsable.push({ document: docName, line: i + 1, text: line });
            }
          }
          return doc;
        }
        function findByName(list, name){
          var n = norm(name);
          for (var i = 0; i < list.length; i++){ if (norm(list[i].name) === n) return list[i]; }
          return null;
        }
        function countByName(list, name){
          var n = norm(name), c = 0;
          for (var i = 0; i < list.length; i++){ if (norm(list[i].name) === n) c++; }
          return c;
        }
        function laborExpr(doc){
          if (!doc.laborLines.length) return "no LABOR line (total $0.00)";
          return doc.laborLines.map(function(l){
            return qtyStr(l.hours) + " × " + money(l.rateCents) + " = " + money(Math.round(l.hours * l.rateCents));
          }).join("; ");
        }

        /* ---------- Cross-check auditor ---------- */
        function audit(pText, wText, iText){
          var P = parseDoc("Proposal", pText);
          var W = parseDoc("Work Record", wText);
          var I = parseDoc("Final Invoice", iText);
          var findings = [];
          var hasInvoiceOnly = false, hasUncreditedDeposit = false;
          function add(check, title, detail, cents){ findings.push({ check: check, title: title, detail: detail, overchargeCents: cents }); }

          /* 1. Quantities billed above recorded */
          I.items.forEach(function(inv){
            var w = findByName(W.items, inv.name);
            if (w && inv.qty > w.qty){
              var cents = Math.round((inv.qty - w.qty) * inv.priceCents);
              add("Quantity billed above recorded", "Quantity overage — " + inv.name,
                "Final Invoice qty " + qtyStr(inv.qty) + " vs Work Record qty " + qtyStr(w.qty) +
                ": (" + qtyStr(inv.qty) + " − " + qtyStr(w.qty) + ") × " + money(inv.priceCents) + " = " + money(cents) + ".",
                cents);
            }
          });

          /* 2. Swaps by slot position */
          function swaps(a, b, label){
            var n = Math.min(a.items.length, b.items.length);
            for (var s = 0; s < n; s++){
              var x = a.items[s], y = b.items[s];
              if (norm(x.name) !== norm(y.name)){
                var over = 0, arith;
                if (y.priceCents !== x.priceCents){
                  var diff = Math.round((y.priceCents - x.priceCents) * y.qty);
                  if (diff > 0) over = diff;
                  arith = "Price difference proven from the pastes: (" + money(y.priceCents) + " − " + money(x.priceCents) +
                          ") × qty " + qtyStr(y.qty) + " = " + money(diff) + (diff > 0 ? "." : " — not positive, so $0.00 counted.");
                } else {
                  arith = "Both are priced at " + money(x.priceCents) + " in the pastes, so no price difference is proven — overcharge $0.00.";
                }
                add("Plant/material swap", "Swap at ITEM slot " + (s + 1) + " (" + label + ")",
                  a.name + " slot " + (s + 1) + " is \u201C" + x.name + "\u201D but " + b.name + " slot " + (s + 1) +
                  " is \u201C" + y.name + "\u201D. " + arith, over);
              }
            }
          }
          swaps(P, W, "Proposal → Work Record");
          swaps(W, I, "Work Record → Final Invoice");

          /* 3. Labor billed above recorded */
          if (I.laborTotalCents > W.laborTotalCents){
            var lc = I.laborTotalCents - W.laborTotalCents;
            add("Labor billed above recorded", "Labor overage",
              "Final Invoice labor: " + laborExpr(I) + " (total " + money(I.laborTotalCents) + "). " +
              "Work Record labor: " + laborExpr(W) + " (total " + money(W.laborTotalCents) + "). " +
              money(I.laborTotalCents) + " − " + money(W.laborTotalCents) + " = " + money(lc) + ".", lc);
          }

          /* 4. Deposit paid but not credited */
          var paid = Math.max(P.depositCents, W.depositCents);
          var credited = I.depositCents;
          if (paid > credited){
            hasUncreditedDeposit = true;
            var srcs = [];
            if (P.depositLines) srcs.push("Proposal DEPOSIT " + money(P.depositCents));
            if (W.depositLines) srcs.push("Work Record DEPOSIT " + money(W.depositCents));
            add("Deposit paid but not credited", "Uncredited deposit",
              "Deposit paid per " + srcs.join(" and ") + " = " + money(paid) +
              "; credited on the Final Invoice = " + money(credited) +
              ". " + money(paid) + " − " + money(credited) + " = " + money(paid - credited) + ".",
              paid - credited);
          }

          /* 5. Duplicate fees */
          var seen = {};
          I.fees.forEach(function(fee){
            var n = norm(fee.name);
            seen[n] = (seen[n] || 0) + 1;
            if (seen[n] > 1){
              var total = countByName(I.fees, fee.name);
              var pCount = countByName(P.fees, fee.name);
              var note = "Fee \u201C" + fee.name + "\u201D appears " + total + " times on the Final Invoice; this is occurrence #" +
                seen[n] + ". Occurrence #1 is the billed fee; each later occurrence is charged again: " + money(fee.amountCents) + ".";
              if (pCount >= 1 && total > pCount){
                note += " The Proposal lists \u201C" + fee.name + "\u201D " + pCount + (pCount === 1 ? " time" : " times") +
                        ", so the invoice bills it " + (total - pCount) + " extra time(s) beyond the proposal.";
              }
              add("Duplicate fee", "Duplicate fee — " + fee.name + " (occurrence #" + seen[n] + ")", note, fee.amountCents);
            }
          });

          /* 6. Invoice-only items and fees */
          I.items.forEach(function(inv){
            if (!findByName(P.items, inv.name) && !findByName(W.items, inv.name)){
              hasInvoiceOnly = true;
              var cents = Math.round(inv.qty * inv.priceCents);
              add("Invoice-only item", "Invoice-only item — " + inv.name,
                "\u201C" + inv.name + "\u201D appears in neither the Proposal nor the Work Record. Full billed amount: " +
                qtyStr(inv.qty) + " × " + money(inv.priceCents) + " = " + money(cents) + ".", cents);
            }
          });
          I.fees.forEach(function(fee){
            if (!findByName(P.fees, fee.name) && !findByName(W.fees, fee.name)){
              hasInvoiceOnly = true;
              add("Invoice-only fee", "Invoice-only fee — " + fee.name,
                "Fee \u201C" + fee.name + "\u201D appears in neither the Proposal nor the Work Record. Full billed amount: " +
                money(fee.amountCents) + ".", fee.amountCents);
            }
          });

          var totalCents = findings.reduce(function(sum, f){ return sum + f.overchargeCents; }, 0);
          var unparsable = P.unparsable.concat(W.unparsable, I.unparsable);
          var hasSwap = findings.some(function(f){ return f.check === "Plant/material swap"; });
          var verdict, reasons = [];
          if (hasInvoiceOnly) reasons.push("the invoice bills items/fees that appear in neither earlier document");
          if (hasUncreditedDeposit) reasons.push("a deposit was paid but not credited on the invoice");
          if (hasInvoiceOnly || hasUncreditedDeposit){
            verdict = "DO NOT PAY YET";
          } else if (totalCents > 0){
            verdict = "PAY WITH CORRECTIONS";
            reasons.push("proven overcharges are documented below; every billed line is accounted for against an earlier document");
          } else if (hasSwap || unparsable.length){
            verdict = "PAY WITH CORRECTIONS";
            if (hasSwap) reasons.push("item swaps between documents need correction even though no price difference is proven");
            if (unparsable.length) reasons.push("unparsable lines were excluded, so those lines could not be checked");
          } else {
            verdict = "PAY AS BILLED";
            reasons.push("every billed line matches the proposal and the work record, and the deposit is credited");
          }
          return { verdict: verdict, reasons: reasons, totalCents: totalCents,
                   findings: findings, unparsable: unparsable,
                   hasInvoiceOnly: hasInvoiceOnly, hasUncreditedDeposit: hasUncreditedDeposit };
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-landscaping-installation-proposal-work-record-final-invoice-consistency-auditortm',
  name: 'J-Dawgs Landscaping Installation Proposal, Work Record & Final Invoice Consistency Auditor',
  description: 'Cross-checks a landscaping installation proposal vs work record vs final invoice into one pay verdict with arithmetic shown.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
