'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs SAML Response Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";
      var $ = function (id) { return document.getElementById(id); };
      var lastReport = null;

      function esc(s) {
        return String(s).replace(/[&<>"']/g, function (c) {
          return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
        });
      }

      /* ---------- decoding ---------- */

      function looksLikeXml(s) {
        if (!s) return false;
        var t = s.replace(/^\uFEFF/, "").replace(/^\s+/, "");
        t = t.replace(/^<\?xml[^>]*\?>/, "").replace(/^\s+/, "");
        return t.charAt(0) === "<" && /[A-Za-z]/.test(t.charAt(1) || "");
      }

      function b64ToBytes(b64) {
        var clean = b64.replace(/\s+/g, "").replace(/-/g, "+").replace(/_/g, "/");
        while (clean.length % 4) clean += "=";
        if (!/^[A-Za-z0-9+/=]+$/.test(clean)) return null;
        try {
          var bin = atob(clean);
          var bytes = new Uint8Array(bin.length);
          for (var i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
          return bytes;
        } catch (e) { return null; }
      }

      function bytesToText(bytes) {
        try { return new TextDecoder("utf-8", { fatal: false }).decode(bytes); }
        catch (e) { return ""; }
      }

      async function inflate(bytes, format) {
        var ds = new DecompressionStream(format);
        var stream = new Blob([bytes]).stream().pipeThrough(ds);
        var buf = await new Response(stream).arrayBuffer();
        return new Uint8Array(buf);
      }

      async function decodeInput(rawInput) {
        var steps = [];
        var raw = (rawInput || "").trim();
        if (!raw) { steps.push("Input was empty — nothing to decode."); return { ok: false, steps: steps }; }

        var value = raw;
        var paramMatch = raw.match(/SAMLResponse=([^&\s]+)/);
        if (paramMatch && raw.indexOf("<") !== 0) {
          value = paramMatch[1];
          steps.push("Found a SAMLResponse= parameter and extracted its value.");
        }

        if (looksLikeXml(value)) {
          steps.push("Input starts with '<' — treated as raw XML.");
          return { ok: true, xml: value, binding: "raw XML", steps: steps };
        }
        steps.push("Raw XML check: input does not start with '<', so it is not raw XML.");

        var candidates = [];
        var seen = {};
        function addCandidate(label, s) {
          if (s && !seen[s]) { seen[s] = true; candidates.push({ label: label, value: s }); }
        }
        addCandidate("as pasted", value);
        try { addCandidate("after URL-decoding", decodeURIComponent(value)); }
        catch (e) { steps.push("URL-decode step: decodeURIComponent failed (" + e.message + ") — continued with the raw value."); }
        addCandidate("with '+' read as a space (form encoding)", value.replace(/\+/g, " "));
        try { addCandidate("URL-decoded, '+' as space", decodeURIComponent(value.replace(/\+/g, " "))); } catch (e) {}

        for (var c = 0; c < candidates.length; c++) {
          var cand = candidates[c].value;
          if (looksLikeXml(cand)) {
            steps.push("After URL-decoding, the value is XML — treated as decoded XML.");
            return { ok: true, xml: cand, binding: "URL-decoded XML", steps: steps };
          }
          var bytes = b64ToBytes(cand);
          if (!bytes) {
            steps.push("Base64 decode (" + candidates[c].label + "): not valid Base64, skipped.");
            continue;
          }
          var text = bytesToText(bytes);
          if (looksLikeXml(text)) {
            steps.push("Base64 decode (" + candidates[c].label + ") produced XML — POST binding.");
            return { ok: true, xml: text, binding: "Base64 (POST binding)", steps: steps };
          }
          steps.push("Base64 decode (" + candidates[c].label + ") produced " + bytes.length + " bytes that are not XML — trying DEFLATE inflation (Redirect binding).");
          if (typeof DecompressionStream === "undefined") {
            steps.push("DEFLATE inflation: this browser has no DecompressionStream, so the Redirect-binding value cannot be inflated here. Try a current Chrome, Edge, or Safari, or paste the inflated XML / the POST-binding Base64 instead.");
            continue;
          }
          var formats = ["deflate-raw", "deflate"];
          for (var f = 0; f < formats.length; f++) {
            try {
              var inflated = await inflate(bytes, formats[f]);
              var itext = bytesToText(inflated);
              if (looksLikeXml(itext)) {
                steps.push("Inflated the bytes as " + formats[f] + " via DecompressionStream and got XML — Redirect binding.");
                return { ok: true, xml: itext, binding: "Base64 + DEFLATE (Redirect binding)", steps: steps };
              }
              steps.push("Inflation as " + formats[f] + " produced bytes that are not XML.");
            } catch (e) {
              steps.push("Inflation as " + formats[f] + " failed (" + (e && e.message ? e.message : e) + ").");
            }
          }
        }
        return { ok: false, steps: steps };
      }

      /* ---------- XML helpers (heuristic text parsing) ---------- */

      function formatXml(xml) {
        var s = String(xml).replace(/\r\n?/g, "\n").trim();
        s = s.replace(/>\s+</g, ">\n<");
        var lines = s.split("\n");
        var out = [], depth = 0;
        for (var i = 0; i < lines.length; i++) {
          var line = lines[i].trim();
          if (!line) continue;
          if (/^<\//.test(line)) depth = Math.max(0, depth - 1);
          out.push(new Array(depth + 1).join("  ") + line);
          var isOpen = /^<[^!?\/][^>]*[^\/]>$/.test(line) && line.indexOf("</") === -1;
          if (isOpen) depth++;
        }
        return out.join("\n");
      }

      function parseAttrs(tagText) {
        var attrs = {};
        var re = /([A-Za-z_][\w:.-]*)\s*=\s*(?:"([^"]*)"|'([^']*)')/g;
        var m;
        while ((m = re.exec(tagText)) !== null) attrs[m[1]] = (m[2] !== undefined ? m[2] : m[3]);
        return attrs;
      }

      function maskValue(v) {
        if (v == null) return "(absent)";
        if (v.length === 0) return "(empty)";
        if (v.length <= 2) return "•• (" + v.length + " chars)";
        return v.slice(0, 2) + "… (" + v.length + " chars)";
      }

      function fmtTime(d) {
        if (!d || isNaN(d.getTime())) return "—";
        return d.toISOString().replace("T", " ").replace(/\.\d{3}Z$/, " UTC");
      }

      function algShort(uri) {
        if (!uri) return null;
        var parts = String(uri).split("#");
        return parts[parts.length - 1] || uri;
      }

      var SENSITIVE_RE = /password|passwd|secret|token|session|api[-_]?key|private[-_]?key|credential/i;

      /* ---------- audit ---------- */

      function audit(xml, expectedAud, expectedAcs) {
        var now = new Date();
        var fx = formatXml(xml);
        var findings = [];
        function F(sev, check, msg, line) { findings.push({ severity: sev, check: check, message: msg, line: line || null }); }
        function lineAt(idx) { return fx.slice(0, idx).split("\n").length; }
        function findAll(re) {
          var out = [], m;
          re.lastIndex = 0;
          while ((m = re.exec(fx)) !== null) out.push({ text: m[0], groups: m, index: m.index, line: lineAt(m.index) });
          return out;
        }

        var meta = { auditedAt: now, binding: null, issuer: null, audience: null, windowText: null, nameIdMasked: null, assertionCount: 0 };

        /* Response + Assertion scaffolding */
        var respTags = findAll(/<(?:[\w.-]+:)?Response\b[^>]*>/g);
        var respAttrs = respTags.length ? parseAttrs(respTags[0].text) : {};
        var assertionTags = findAll(/<(?:[\w.-]+:)?Assertion\b[^>]*>/g);
        meta.assertionCount = assertionTags.length;
        var assertionIdx = assertionTags.length ? assertionTags[0].index : Infinity;
        if (!respTags.length) F("warning", "Document shape", "No Response element found — the paste decoded as XML but does not look like a SAML response.", null);
        if (assertionTags.length > 1) F("note", "Document shape", assertionTags.length + " Assertion elements found; the checks below audit the first one.", assertionTags[1].line);
        if (assertionTags.length === 0) F("blocker", "Document shape", "No Assertion element found — there is nothing here to trust.", null);

        /* Issuer */
        var issuers = findAll(/<(?:[\w.-]+:)?Issuer\b[^>]*>([^<]*)<\/(?:[\w.-]+:)?Issuer\s*>/g);
        var respIssuer = null, assertIssuer = null;
        issuers.forEach(function (it) {
          if (it.index < assertionIdx && respIssuer === null) respIssuer = it;
          else if (it.index >= assertionIdx && assertIssuer === null) assertIssuer = it;
        });
        var issuerShown = respIssuer || assertIssuer;
        if (issuerShown) {
          meta.issuer = issuerShown.groups[1].trim();
          F("note", "Issuer", "The response was issued by " + meta.issuer + ".", issuerShown.line);
          if (respIssuer && assertIssuer && respIssuer.groups[1].trim() !== assertIssuer.groups[1].trim()) {
            F("warning", "Issuer", "Response Issuer (" + respIssuer.groups[1].trim() + ") differs from Assertion Issuer (" + assertIssuer.groups[1].trim() + ").", assertIssuer.line);
          }
        } else {
          F("warning", "Issuer", "No Issuer element found.", null);
        }

        /* Status */
        var statusTags = findAll(/<(?:[\w.-]+:)?StatusCode\b[^>]*>/g);
        if (!statusTags.length) {
          F("warning", "Status", "No StatusCode element found — the IdP's result is unstated.", null);
        } else {
          var topVal = parseAttrs(statusTags[0].text).Value || "(no Value attribute)";
          if (/:Success$/.test(topVal) || topVal === "Success") {
            F("pass", "Status", "Top-level StatusCode is Success (" + topVal + ").", statusTags[0].line);
          } else {
            F("blocker", "Status", "The IdP returned a failure StatusCode: " + topVal, statusTags[0].line);
          }
          if (statusTags.length > 1) {
            var rest = statusTags.slice(1).map(function (t) { return parseAttrs(t.text).Value || "(no Value)"; });
            F("note", "Status", "Additional nested StatusCode value(s): " + rest.join(", ") + ".", statusTags[1].line);
          }
        }

        /* Signatures */
        var sigTags = findAll(/<(?:[\w.-]+:)?Signature(?=[\s>])[^>]*>/g);
        function sigAlg(sig) {
          var windowText = fx.slice(sig.index, sig.index + 6000);
          var m = windowText.match(/<(?:[\w.-]+:)?SignatureMethod\b[^>]*>/);
          if (!m) return null;
          return algShort(parseAttrs(m[0]).Algorithm);
        }
        var respSigs = sigTags.filter(function (s) { return s.index < assertionIdx; });
        var assertSigs = sigTags.filter(function (s) { return s.index >= assertionIdx; });
        if (respSigs.length) {
          var a1 = sigAlg(respSigs[0]);
          F("pass", "Response signature", "Response-level Signature element present" + (a1 ? " (SignatureMethod: " + a1 + ")" : "") + ". Presence only — not cryptographically verified.", respSigs[0].line);
        } else {
          F("warning", "Response signature", "No response-level Signature element. (Not fatal if the assertion itself is signed, but the response as a whole is unsigned.)", respTags.length ? respTags[0].line : null);
        }
        if (assertSigs.length) {
          var a2 = sigAlg(assertSigs[0]);
          F("pass", "Assertion signature", "Assertion-level Signature element present" + (a2 ? " (SignatureMethod: " + a2 + ")" : "") + ". Presence only — not cryptographically verified.", assertSigs[0].line);
        } else {
          F("blocker", "Assertion signature", "No assertion-level Signature element — the assertion itself is unsigned, so nothing binds its contents to the IdP.", assertionTags.length ? assertionTags[0].line : null);
        }

        /* Conditions window */
        var condTags = findAll(/<(?:[\w.-]+:)?Conditions\b[^>]*>/g);
        var condNb = null, condNoa = null;
        if (!condTags.length) {
          F("warning", "Conditions window", "No Conditions element — the assertion states no validity window.", assertionTags.length ? assertionTags[0].line : null);
          meta.windowText = "no Conditions element";
        } else {
          var ca = parseAttrs(condTags[0].text);
          condNb = ca.NotBefore ? new Date(Date.parse(ca.NotBefore)) : null;
          condNoa = ca.NotOnOrAfter ? new Date(Date.parse(ca.NotOnOrAfter)) : null;
          meta.windowText = fmtTime(condNb) + " → " + fmtTime(condNoa);
          var bad = false;
          if (condNoa && !isNaN(condNoa.getTime()) && now >= condNoa) {
            F("blocker", "Conditions window", "EXPIRED: NotOnOrAfter is " + fmtTime(condNoa) + " and the audit time is " + fmtTime(now) + ".", condTags[0].line); bad = true;
          }
          if (condNb && !isNaN(condNb.getTime()) && now < condNb) {
            F("blocker", "Conditions window", "NOT YET VALID: NotBefore is " + fmtTime(condNb) + " and the audit time is " + fmtTime(now) + ".", condTags[0].line); bad = true;
          }
          if (!ca.NotOnOrAfter) { F("warning", "Conditions window", "Conditions has no NotOnOrAfter — the assertion never expires on its face.", condTags[0].line); bad = true; }
          if (condNb && condNoa && !isNaN(condNb.getTime()) && !isNaN(condNoa.getTime())) {
            var hrs = (condNoa - condNb) / 3600000;
            if (hrs > 24) { F("warning", "Conditions window", "Validity window spans " + hrs.toFixed(1) + " hours — longer than 24 hours is unusually generous for an assertion.", condTags[0].line); bad = true; }
          }
          if (!bad) F("pass", "Conditions window", "In window: " + meta.windowText + " (audit time " + fmtTime(now) + ").", condTags[0].line);
        }

        /* SubjectConfirmationData */
        var scdTags = findAll(/<(?:[\w.-]+:)?SubjectConfirmationData\b[^>]*>/g);
        if (!scdTags.length) {
          F("warning", "SubjectConfirmationData", "No SubjectConfirmationData — bearer confirmation carries no recipient or expiry to check.", null);
        } else {
          var sa = parseAttrs(scdTags[0].text);
          var scdBad = false;
          if (sa.NotOnOrAfter) {
            var scdExp = new Date(Date.parse(sa.NotOnOrAfter));
            if (!isNaN(scdExp.getTime()) && now >= scdExp) {
              F("blocker", "SubjectConfirmationData", "EXPIRED: SubjectConfirmationData NotOnOrAfter is " + fmtTime(scdExp) + " (audit time " + fmtTime(now) + ").", scdTags[0].line); scdBad = true;
            }
          } else {
            F("warning", "SubjectConfirmationData", "SubjectConfirmationData has no NotOnOrAfter expiry.", scdTags[0].line); scdBad = true;
          }
          if (sa.Recipient) {
            if (expectedAcs) {
              if (sa.Recipient === expectedAcs) F("pass", "Recipient", "Recipient matches the expected ACS URL exactly: " + sa.Recipient, scdTags[0].line);
              else F("blocker", "Recipient", "Recipient mismatch — response says " + sa.Recipient + " but the expected ACS URL is " + expectedAcs + ".", scdTags[0].line);
            } else {
              F("unchecked", "Recipient", "Recipient is " + sa.Recipient + " — NOT CHECKED (no expected ACS URL supplied).", scdTags[0].line);
            }
          } else {
            F("warning", "Recipient", "SubjectConfirmationData has no Recipient attribute — the assertion is not tied to your ACS URL.", scdTags[0].line);
          }
          if (sa.NotOnOrAfter && !scdBad) { /* expiry pass folded into window line below */ }
          if (sa.NotOnOrAfter && !scdBad) F("pass", "SubjectConfirmationData", "SubjectConfirmationData expires " + fmtTime(new Date(Date.parse(sa.NotOnOrAfter))) + " — still ahead of the audit time.", scdTags[0].line);
        }

        /* AudienceRestriction */
        var audResHit = findAll(/<(?:[\w.-]+:)?AudienceRestriction\b[^>]*>/g);
        var audHit = findAll(/<(?:[\w.-]+:)?Audience\b[^>]*>([^<]*)<\/(?:[\w.-]+:)?Audience\s*>/g);
        if (!audResHit.length || !audHit.length) {
          F("warning", "Audience", "No AudienceRestriction / Audience found — the assertion is not restricted to a named SP on its face.", assertionTags.length ? assertionTags[0].line : null);
        } else {
          meta.audience = audHit[0].groups[1].trim();
          if (expectedAud) {
            if (meta.audience === expectedAud) F("pass", "Audience", "Audience matches the expected SP entity ID exactly: " + meta.audience, audHit[0].line);
            else F("blocker", "Audience", "Audience mismatch — response says " + meta.audience + " but the expected SP entity ID is " + expectedAud + ". This assertion was issued for a different service provider.", audHit[0].line);
          } else {
            F("unchecked", "Audience", "Audience is " + meta.audience + " — NOT CHECKED (no expected SP entity ID supplied).", audHit[0].line);
          }
        }

        /* Destination */
        if (respAttrs.Destination) {
          if (expectedAcs) {
            if (respAttrs.Destination === expectedAcs) F("pass", "Destination", "Response Destination matches the expected ACS URL exactly: " + respAttrs.Destination, respTags[0].line);
            else F("blocker", "Destination", "Destination mismatch — response says " + respAttrs.Destination + " but the expected ACS URL is " + expectedAcs + ".", respTags[0].line);
          } else {
            F("unchecked", "Destination", "Destination is " + respAttrs.Destination + " — NOT CHECKED (no expected ACS URL supplied).", respTags[0].line);
          }
        } else if (respTags.length) {
          F("note", "Destination", "Response carries no Destination attribute.", respTags[0].line);
        }

        /* InResponseTo */
        if (respAttrs.InResponseTo) {
          F("note", "InResponseTo", "Response InResponseTo is present (" + respAttrs.InResponseTo + "). Whether it matches the request you actually sent can only be judged against your own request log — this tool cannot correlate it.", respTags[0].line);
        } else if (respTags.length) {
          F("note", "InResponseTo", "No InResponseTo on the Response — consistent with an IdP-initiated (unsolicited) flow. Whether that is acceptable for your SP cannot be judged from the response alone.", respTags[0].line);
        }

        /* NameID */
        var nameIdHit = findAll(/<(?:[\w.-]+:)?NameID\b[^>]*>([^<]*)<\/(?:[\w.-]+:)?NameID\s*>/g);
        if (nameIdHit.length) {
          var nid = nameIdHit[0].groups[1];
          meta.nameIdMasked = maskValue(nid);
          F("note", "NameID", "NameID present — masked everywhere in this output as " + meta.nameIdMasked + ".", nameIdHit[0].line);
        } else {
          F("note", "NameID", "No NameID element found in the Subject.", null);
        }

        /* Attributes */
        var attributes = [];
        var attrRe = /<(?:[\w.-]+:)?Attribute\b([^>]*?)>([\s\S]*?)<\/(?:[\w.-]+:)?Attribute\s*>/g;
        var am;
        attrRe.lastIndex = 0;
        while ((am = attrRe.exec(fx)) !== null) {
          var at = parseAttrs(am[1]);
          var name = at.Name || at.FriendlyName || "(unnamed attribute)";
          var vals = [];
          var vre = /<(?:[\w.-]+:)?AttributeValue\b[^>]*>([^<]*)<\/(?:[\w.-]+:)?AttributeValue\s*>/g;
          var vm;
          while ((vm = vre.exec(am[2])) !== null) vals.push(vm[1]);
          var totalLen = vals.join("").length;
          var sensitive = SENSITIVE_RE.test(name);
          attributes.push({ name: name, sensitive: sensitive, valueLength: totalLen, line: lineAt(am.index) });
          if (sensitive) {
            F("note", "Sensitive attribute", "Attribute \"" + name + "\" has a sensitive-looking name — its value is never rendered here (length only: " + totalLen + " chars).", lineAt(am.index));
          }
        }
        var selfClosedAttrs = findAll(/<(?:[\w.-]+:)?Attribute\b[^>]*\/>/g);
        selfClosedAttrs.forEach(function (t) {
          var at2 = parseAttrs(t.text);
          attributes.push({ name: at2.Name || at2.FriendlyName || "(unnamed attribute)", sensitive: SENSITIVE_RE.test(at2.Name || ""), valueLength: 0, line: t.line });
        });
        if (attributes.length) {
          F("note", "Attributes", "AttributeStatement lists " + attributes.length + " attribute(s), named in the panel below. Names only — values are not part of the audit output" + (attributes.some(function (a) { return a.sensitive; }) ? ", and sensitive values are masked by design." : "."), attributes[0].line);
        } else {
          F("note", "Attributes", "No AttributeStatement attributes found.", null);
        }

        /* Duplicate IDs (signature-wrapping heuristic) */
        var idHits = findAll(/\bID\s*=\s*"([^"]+)"/g);
        var idCounts = {}, idLines = {};
        idHits.forEach(function (h) {
          var v = h.groups[1];
          idCounts[v] = (idCounts[v] || 0) + 1;
          if (!idLines[v]) idLines[v] = h.line;
        });
        var dupes = Object.keys(idCounts).filter(function (k) { return idCounts[k] > 1; });
        if (dupes.length) {
          dupes.forEach(function (d) {
            F("warning", "Duplicate IDs", "ID value \"" + d + "\" appears " + idCounts[d] + " times in the document — duplicate IDs are a signature-wrapping risk indicator (heuristic).", idLines[d]);
          });
        } else if (idHits.length) {
          F("pass", "Duplicate IDs", "All " + idHits.length + " ID attribute values in the document are unique.", null);
        }

        /* Verdict */
        var counts = { blocker: 0, warning: 0, unchecked: 0, note: 0, pass: 0 };
        findings.forEach(function (f) { counts[f.severity] = (counts[f.severity] || 0) + 1; });
        var verdict, verdictClass;
        if (counts.blocker > 0) { verdict = "DO NOT TRUST"; verdictClass = "dont"; }
        else if (counts.warning > 0 || counts.unchecked > 0) { verdict = "TRUST WITH FIXES"; verdictClass = "fixes"; }
        else { verdict = "SAFE TO TRUST"; verdictClass = "safe"; }

        return {
          findings: findings, counts: counts, verdict: verdict, verdictClass: verdictClass,
          meta: meta, attributes: attributes, formattedXml: fx
        };
      }

      /* ---------- masking the decoded XML for display ---------- */

      function maskXml(fx) {
        var out = fx.replace(/(<(?:[\w.-]+:)?NameID\b[^>]*>)([^<]*)(<\/(?:[\w.-]+:)?NameID\s*>)/g, function (_, a, v, b) {
          return a + maskValue(v) + b;
        });
        out = out.replace(/<(?:[\w.-]+:)?Attribute\b([^>]*?)>([\s\S]*?)<\/(?:[\w.-]+:)?Attribute\s*>/g, function (whole, attrText, inner) {
          var at = parseAttrs(attrText);
          var name = at.Name || at.FriendlyName || "";
          if (!SENSITIVE_RE.test(name)) return whole;
          var maskedInner = inner.replace(/(<(?:[\w.-]+:)?AttributeValue\b[^>]*>)([^<]*)(<\/(?:[\w.-]+:)?AttributeValue\s*>)/g, function (_, a, v, b) {
            return a + "[value hidden — " + v.length + " chars]" + b;
          });
          return whole.replace(inner, maskedInner);
        });
        return out;
      }

      /* ---------- rendering ---------- */

      var SEV_LABEL = { blocker: "BLOCKER", warning: "WARNING", unchecked: "NOT CHECKED", note: "NOTE", pass: "PASS" };

      function countsLine(c) {
        return c.blocker + " blocker(s) · " + c.warning + " warning(s) · " + c.unchecked + " not checked · " + c.note + " note(s) · " + c.pass + " passed";
      }

      function buildSummary(r) {
        var lines = [];
        lines.push("J-Dawgs SAML Response Safety Auditor™ — share-safe summary");
        lines.push("Verdict: " + r.verdict);
        lines.push("Audited at: " + fmtTime(r.meta.auditedAt) + " (browser clock)");
        lines.push("Decoded via: " + (r.meta.binding || "—"));
        lines.push("Issuer: " + (r.meta.issuer || "(not found)"));
        lines.push("Audience: " + (r.meta.audience || "(not found)"));
        lines.push("Validity window: " + (r.meta.windowText || "—"));
        lines.push("NameID: " + (r.meta.nameIdMasked || "(not found)"));
        lines.push("Findings: " + countsLine(r.counts));
        lines.push("Note: signature presence reported only — no signature was cryptographically verified.");
        return lines.join("\n");
      }

      function buildReport(r, summary) {
        var out = [summary, "", "FINDINGS (line numbers refer to the decoded XML view)"];
        r.findings.forEach(function (f) {
          out.push("[" + SEV_LABEL[f.severity] + "] " + f.check + (f.line ? " (line " + f.line + ")" : "") + " — " + f.message);
        });
        out.push("");
        out.push("Attributes (names only): " + (r.attributes.length ? r.attributes.map(function (a) {
          return a.name + (a.sensitive ? " (sensitive — value hidden, " + a.valueLength + " chars)" : "");
        }).join(", ") : "none"));
        out.push("");
        out.push("Limits: heuristic text parsing, not a full XML parser. Decoding is not authentication; a present signature is not a verified signature.");
        return out.join("\n");
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-saml-response-safety-auditor',
  name: 'J-Dawgs SAML Response Safety Auditor',
  description: 'Decoders only decode; ours audits a pasted SAML response — expiry window, audience, recipient, signature presence, sensitive attributes masked — and returns one trust verdict: SAFE TO TRUST / TRUST WITH FIXES / DO NOT TRUST.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
