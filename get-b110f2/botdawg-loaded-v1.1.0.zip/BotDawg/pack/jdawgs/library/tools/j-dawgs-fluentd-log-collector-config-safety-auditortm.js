'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Fluentd Log Collector Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Worked examples ---------- */

      var RISKY_EXAMPLE = [
        "# Risky example - a collector config that starts fine and leaks anyway.",
        "<source>",
        "  @type forward",
        "  port 24224",
        "  bind 0.0.0.0",
        "</source>",
        "",
        "<source>",
        "  @type http",
        "  port 9880",
        "  bind 0.0.0.0",
        "</source>",
        "",
        "<filter app.**>",
        "  @type record_transformer",
        "  <record>",
        "    hostname ${hostname}",
        "    service app",
        "  </record>",
        "</filter>",
        "",
        "<match app.**>",
        "  @type http",
        "  endpoint http://logs.example.net/ingest",
        "  <auth>",
        "    method basic",
        "    username collector",
        "    password FakePass-DoNotUse-123",
        "  </auth>",
        "  <buffer>",
        "    @type memory",
        "  </buffer>",
        "</match>",
        "",
        "<system>",
        "  log_level debug",
        "</system>",
        "",
        "@include extra.conf"
      ].join("\n");

      var HARDENED_EXAMPLE = [
        "# Hardened example - same pipeline, locked down.",
        "<source>",
        "  @type forward",
        "  port 24224",
        "  bind 127.0.0.1",
        "  <security>",
        "    self_hostname collector.internal",
        "    shared_key #{ENV['FLUENTD_SHARED_KEY']}",
        "  </security>",
        "</source>",
        "",
        "<source>",
        "  @type syslog",
        "  port 5140",
        "  bind 127.0.0.1",
        "  protocol_type tcp",
        "  <transport tls>",
        "    cert_path /etc/fluentd/tls/server.crt",
        "    private_key_path /etc/fluentd/tls/server.key",
        "    client_cert_auth false",
        "  </transport>",
        "</source>",
        "",
        "<match app.**>",
        "  @type elasticsearch",
        "  host logs.internal",
        "  port 9200",
        "  scheme https",
        "  ssl_verify true",
        "  user collector",
        "  password #{ENV['ES_PASSWORD']}",
        "  <buffer>",
        "    @type file",
        "    path /var/log/fluentd/buffer/app",
        "    chunk_limit_size 8m",
        "    queue_limit_length 512",
        "    total_limit_size 2g",
        "  </buffer>",
        "</match>",
        "",
        "<system>",
        "  log_level info",
        "</system>"
      ].join("\n");

      /* ---------- Parser ---------- */

      var CRED_KEYS = {
        "password": true, "passwd": true, "api_key": true, "apikey": true,
        "secret_key": true, "secret_access_key": true, "aws_secret_access_key": true,
        "access_key": true, "auth_token": true, "token": true
      };
      /* shared_key is an authentication secret: it counts as an inline
         credential too (its value is still never printed). */

      function isPlaceholderValue(v) {
        if (!v) return true;
        var t = v.replace(/^\s+|\s+$/g, "");
        if (t.indexOf("#{") === 0 || t.indexOf("${") === 0) return true;
        if (/^env\s*\(/i.test(t)) return true;
        return false;
      }

      function looksFluentd(lines) {
        for (var i = 0; i < lines.length; i++) {
          var t = lines[i].replace(/^\s+/, "");
          if (/^<(source|match|filter|store|system|label)\b/i.test(t)) return true;
          if (/^@type\s+\S+/i.test(t)) return true;
          if (/^@include\s+\S+/i.test(t)) return true;
        }
        return false;
      }

      /* Parse into a tree of sections. Node:
         { tag, arg, line, directives: [{key,value,line}], children: [] } */
      function parseConfig(lines, findings) {
        var root = { tag: "(root)", arg: "", line: 0, directives: [], children: [] };
        var stack = [root];
        function top() { return stack[stack.length - 1]; }

        for (var i = 0; i < lines.length; i++) {
          var lineNo = i + 1;
          var raw = lines[i];
          var t = raw.replace(/^\s+|\s+$/g, "");
          if (t === "") continue;
          if (t.charAt(0) === "#") continue;

          var inc = t.match(/^@include\s+(\S+)/i);
          if (inc) {
            findings.push({
              severity: "NOT CHECKED", line: lineNo,
              check: "@include not audited",
              message: "Line " + lineNo + " pulls in another file with @include " + inc[1] + ". Included files are not part of the pasted text, so nothing in them was checked — audit that file separately before deploying."
            });
            continue;
          }

          var open = t.match(/^<([A-Za-z][A-Za-z0-9_-]*)(?:\s+([^>]*))?>$/);
          if (open) {
            var node = {
              tag: open[1].toLowerCase(),
              arg: (open[2] || "").replace(/\s+$/, ""),
              line: lineNo, directives: [], children: []
            };
            top().children.push(node);
            stack.push(node);
            continue;
          }

          var close = t.match(/^<\/([A-Za-z][A-Za-z0-9_-]*)>$/);
          if (close) {
            var ctag = close[1].toLowerCase();
            if (stack.length > 1 && top().tag === ctag) {
              stack.pop();
            } else {
              findings.push({
                severity: "NOT PARSED", line: lineNo,
                check: "Unbalanced section tag",
                message: "Closing tag </" + ctag + "> on line " + lineNo + " does not match the section currently open" + (stack.length > 1 ? " (<" + top().tag + "> opened on line " + top().line + ")" : "") + ". Fluentd would refuse or misread this structure; the auditor could not trust the nesting below this point."
              });
              /* Recovery: pop until a match is found, if any. */
              for (var s = stack.length - 1; s >= 1; s--) {
                if (stack[s].tag === ctag) { stack.length = s; break; }
              }
            }
            continue;
          }

          var dir = t.match(/^(@?[A-Za-z_][A-Za-z0-9_.-]*)\s+(.+)$/);
          if (dir) {
            top().directives.push({ key: dir[1].toLowerCase(), value: dir[2].replace(/\s+$/, ""), line: lineNo });
            continue;
          }

          var bare = t.match(/^(@?[A-Za-z_][A-Za-z0-9_.-]*)$/);
          if (bare) {
            top().directives.push({ key: bare[1].toLowerCase(), value: "", line: lineNo });
            continue;
          }

          findings.push({
            severity: "NOT PARSED", line: lineNo,
            check: "Unparseable line",
            message: "Line " + lineNo + " is not a recognizable Fluentd section tag or \"key value\" directive, so it was not parsed and nothing on it was checked."
          });
        }

        for (var u = 1; u < stack.length; u++) {
          findings.push({
            severity: "NOT PARSED", line: stack[u].line,
            check: "Unclosed section",
            message: "The <" + stack[u].tag + "> section opened on line " + stack[u].line + " is never closed. Fluentd would reject this file; fix the nesting and re-audit."
          });
        }
        return root;
      }

      /* ---------- Tree helpers ---------- */

      function walk(node, fn) {
        fn(node);
        for (var i = 0; i < node.children.length; i++) walk(node.children[i], fn);
      }
      function getDir(node, key) {
        for (var i = 0; i < node.directives.length; i++) {
          if (node.directives[i].key === key) return node.directives[i];
        }
        return null;
      }
      function findDesc(node, tag) {
        var out = [];
        walk(node, function (n) { if (n !== node && n.tag === tag) out.push(n); });
        return out;
      }
      function subtreeHasCred(node) {
        var found = false;
        walk(node, function (n) {
          for (var i = 0; i < n.directives.length; i++) {
            var d = n.directives[i];
            if ((CRED_KEYS[d.key] || d.key === "shared_key") && d.value && !isPlaceholderValue(d.value)) found = true;
          }
        });
        return found;
      }
      function typeOf(node) {
        var d = getDir(node, "@type");
        return d ? d.value.toLowerCase().replace(/\s+$/, "") : "";
      }
      function baseType(t) {
        return t.replace(/^(in_|out_|fluent-plugin-)/, "");
      }
      function bindInfo(node) {
        var b = getDir(node, "bind");
        if (!b || !b.value) return { restricted: false, desc: "no bind directive (Fluentd listens on all interfaces by default)" };
        var v = b.value.toLowerCase();
        if (v === "0.0.0.0" || v === "::" || v === "*") return { restricted: false, desc: "bind " + b.value + " (all interfaces)" };
        return { restricted: true, desc: "bind " + b.value };
      }
      function sourceHasAuth(node) {
        var secs = findDesc(node, "security");
        for (var i = 0; i < secs.length; i++) {
          var sk = getDir(secs[i], "shared_key");
          if (sk) return true;
          if (secs[i].directives.length > 0) return true;
        }
        var direct = getDir(node, "shared_key");
        if (direct) return true;
        var authKeys = ["auth", "user_auth", "authentication", "require_auth"];
        for (var j = 0; j < authKeys.length; j++) {
          var d = getDir(node, authKeys[j]);
          if (d && d.value && d.value.toLowerCase() !== "none" && d.value.toLowerCase() !== "false") return true;
        }
        /* in_http style: a <auth> child section counts as an auth attempt */
        if (findDesc(node, "auth").length > 0) return true;
        return false;
      }
      function hasTLS(node) {
        var ok = false;
        walk(node, function (n) {
          if (n.tag === "transport" && /\btls\b/i.test(n.arg)) ok = true;
          for (var i = 0; i < n.directives.length; i++) {
            var d = n.directives[i];
            if ((d.key === "tls" || d.key === "use_tls" || d.key === "use_ssl") &&
                /^(true|yes|on|tls)$/i.test(d.value)) ok = true;
            if (d.key === "cert_path" || d.key === "tls_cert_path" || d.key === "ca_path") ok = true;
          }
        });
        return ok;
      }

      /* ---------- Checks ---------- */

      function runChecks(root, findings) {
        /* Inline credentials — anywhere in the file. */
        walk(root, function (n) {
          for (var i = 0; i < n.directives.length; i++) {
            var d = n.directives[i];
            if ((CRED_KEYS[d.key] || d.key === "shared_key") && d.value && !isPlaceholderValue(d.value)) {
              findings.push({
                severity: "WARNING", line: d.line,
                check: "Inline credential in config",
                message: "The \"" + d.key + "\" directive on line " + d.line + " carries a secret value written directly in the config (value length: " + d.value.length + " characters — the value itself is never shown by this tool). Anyone who can read this file owns the credential. Move it to an environment placeholder such as #{ENV['NAME']} or a secrets file outside the config."
              });
            }
          }
        });

        /* Sources */
        var sources = findDesc(root, "source");
        sources.forEach(function (src) {
          var t = baseType(typeOf(src));
          var typeDir = getDir(src, "@type");
          var atLine = typeDir ? typeDir.line : src.line;
          var bind = bindInfo(src);

          if (t === "forward" || t === "http") {
            if (!bind.restricted && !sourceHasAuth(src)) {
              findings.push({
                severity: "BLOCKER", line: atLine,
                check: "Unauthenticated network input (" + t + ")",
                message: "The <source> @" + "type " + t + " input starting on line " + src.line + " is reachable over the network (" + bind.desc + ") and has no <security> shared_key and no authentication. Anyone who can reach the port can inject forged log events into this pipeline. Bind it to a private interface, or add a <security> section with a shared_key, before deploying."
              });
            } else if (bind.restricted && !sourceHasAuth(src)) {
              findings.push({
                severity: "WARNING", line: atLine,
                check: "Network input without authentication (" + t + ")",
                message: "The <source> @" + "type " + t + " input starting on line " + src.line + " has no <security> shared_key and no authentication. It is bound to a restricted address (" + bind.desc + "), which limits exposure, but anything that can reach that address can still inject events. Add authentication if the bind is ever widened."
              });
            }
          } else if (t === "tcp" || t === "syslog" || t === "udp") {
            if (!hasTLS(src)) {
              if (!bind.restricted) {
                findings.push({
                  severity: "BLOCKER", line: atLine,
                  check: "Network input without TLS, bound to all interfaces (" + t + ")",
                  message: "The <source> @" + "type " + t + " input starting on line " + src.line + " takes events over the network with no TLS transport (" + bind.desc + "). Log content crosses the network in plaintext and events can be spoofed. Add a <transport tls> section with certificates, or restrict the bind."
                });
              } else {
                findings.push({
                  severity: "WARNING", line: atLine,
                  check: "Network input without TLS (" + t + ")",
                  message: "The <source> @" + "type " + t + " input starting on line " + src.line + " has no TLS transport (" + bind.desc + "). Events arrive in plaintext; add a <transport tls> section if this traffic ever leaves a trusted local segment."
                });
              }
            }
          }
        });

        /* Outputs: <match> and nested <store> */
        var outputs = [];
        findDesc(root, "match").forEach(function (n) { outputs.push(n); });
        findDesc(root, "store").forEach(function (n) { outputs.push(n); });
        outputs.forEach(function (out) {
          var t = baseType(typeOf(out));
          if (["http", "elasticsearch", "s3", "gcs"].indexOf(t) === -1) return;
          var creds = subtreeHasCred(out);

          /* plaintext endpoint */
          var urlKeys = ["endpoint", "url", "endpoint_url", "urls"];
          for (var i = 0; i < urlKeys.length; i++) {
            var u = getDir(out, urlKeys[i]);
            if (u && /^http:\/\//i.test(u.value)) {
              if (creds) {
                findings.push({
                  severity: "BLOCKER", line: u.line,
                  check: "Plaintext output carrying credentials (" + t + ")",
                  message: "The " + t + " output sends events to an http:// (plaintext) endpoint on line " + u.line + ", and the same output carries an inline credential. Both the log data and the credential cross the network readable by anyone on the path. Switch the endpoint to https:// and move the credential out of the file."
                });
              } else {
                findings.push({
                  severity: "WARNING", line: u.line,
                  check: "Plaintext output endpoint (" + t + ")",
                  message: "The " + t + " output sends events to an http:// (plaintext) endpoint on line " + u.line + ". Log records cross the network unencrypted. Switch to https:// unless this hop never leaves a trusted local segment."
                });
              }
            }
          }
          var scheme = getDir(out, "scheme");
          if (scheme && scheme.value.toLowerCase() === "http") {
            findings.push({
              severity: creds ? "BLOCKER" : "WARNING", line: scheme.line,
              check: "Plaintext output scheme (" + t + ")",
              message: "The " + t + " output sets scheme http on line " + scheme.line + ", so events are sent unencrypted" + (creds ? ", and this output also carries an inline credential that would travel with them" : "") + ". Use scheme https."
            });
          }

          /* TLS verification disabled / insecure flags */
          var verifyKeys = { "tls_verify": true, "ssl_verify": true, "verify_ssl": true, "tls_verify_hostname": true, "ssl_verification": true };
          walk(out, function (n) {
            for (var j = 0; j < n.directives.length; j++) {
              var d = n.directives[j];
              var off = false;
              if (verifyKeys[d.key] && /^(false|no|none|off)$/i.test(d.value)) off = true;
              if ((d.key === "insecure" || d.key === "skip_verify" || d.key === "no_verify") && /^(true|yes|on)$/i.test(d.value)) off = true;
              if (d.key === "use_ssl" && /^(false|no|off)$/i.test(d.value)) off = true;
              if (off) {
                findings.push({
                  severity: creds ? "BLOCKER" : "WARNING", line: d.line,
                  check: "TLS verification disabled (" + t + ")",
                  message: "The \"" + d.key + "\" directive on line " + d.line + " turns off TLS certificate verification for the " + t + " output. The connection may be encrypted, but nothing proves the far end is the real destination — a man-in-the-middle can take the stream" + (creds ? ", including the inline credential this output carries" : "") + ". Restore verification and fix the certificate chain instead."
                });
              }
            }
          });
        });

        /* Buffers with no limits */
        findDesc(root, "buffer").forEach(function (buf) {
          var limitKeys = { "chunk_limit_size": true, "chunk_limit_records": true, "total_limit_size": true, "queue_limit_length": true, "queue_limit_records": true };
          var has = false;
          for (var i = 0; i < buf.directives.length; i++) {
            if (limitKeys[buf.directives[i].key]) has = true;
          }
          if (!has) {
            findings.push({
              severity: "INFO", line: buf.line,
              check: "Buffer with no chunk or queue limits",
              message: "The <buffer> section on line " + buf.line + " sets no chunk_limit_size, total_limit_size, or queue_limit_length. If the destination stalls, buffered chunks can grow until the disk or memory gives out. Set explicit limits sized to the host."
            });
          }
        });

        /* log_level debug + record content */
        var debugLine = 0;
        walk(root, function (n) {
          for (var i = 0; i < n.directives.length; i++) {
            var d = n.directives[i];
            if ((d.key === "log_level" || d.key === "@log_level") && /^(debug|trace)$/i.test(d.value)) debugLine = d.line;
          }
        });
        var hasRecordContent = false;
        walk(root, function (n) {
          if (n.tag === "record") hasRecordContent = true;
          var tt = baseType(typeOf(n));
          if (tt === "record_transformer" || tt === "record_modifier") hasRecordContent = true;
        });
        if (debugLine && hasRecordContent) {
          findings.push({
            severity: "WARNING", line: debugLine,
            check: "Debug logging with record content",
            message: "log_level is set to debug on line " + debugLine + " while this config builds record content (<record> sections / record_transformer). At debug level Fluentd logs event payloads, so full log records — including anything sensitive inside them — can land in the Fluentd log itself. Run at info in production and raise verbosity only while actively debugging."
          });
        } else if (debugLine) {
          findings.push({
            severity: "INFO", line: debugLine,
            check: "Debug log level",
            message: "log_level is set to debug on line " + debugLine + ". Debug output is verbose and can include event detail; prefer info for a production collector."
          });
        }
      }

      /* ---------- Audit orchestration ---------- */

      var SEV_ORDER = { "BLOCKER": 0, "WARNING": 1, "NOT PARSED": 2, "NOT CHECKED": 3, "INFO": 4 };

      function audit(text) {
        var findings = [];
        var trimmed = (text || "").replace(/\s+$/g, "");
        if (!trimmed) {
          return {
            verdict: "NOT ENOUGH TO GRADE",
            gradeable: false,
            message: "Nothing to audit yet. Paste the text of a Fluentd config (fluent.conf / td-agent.conf) — or load one of the worked examples — and run the audit.",
            findings: [], lines: 0
          };
        }
        var lines = text.replace(/\r\n?/g, "\n").split("\n");
        /* Drop a single trailing empty line from line counting */
        if (lines.length && lines[lines.length - 1] === "") lines.pop();

        if (!looksFluentd(lines)) {
          return {
            verdict: "NOT ENOUGH TO GRADE",
            gradeable: false,
            message: "This text does not look like a Fluentd configuration: no <source>, <match>, <filter>, or <system> sections and no @type directives were found. Nothing was graded and no findings were invented — paste a fluent.conf / td-agent.conf to get a verdict.",
            findings: [], lines: lines.length
          };
        }

        var root = parseConfig(lines, findings);
        runChecks(root, findings);

        findings.sort(function (a, b) {
          var s = SEV_ORDER[a.severity] - SEV_ORDER[b.severity];
          return s !== 0 ? s : a.line - b.line;
        });

        var counts = { "BLOCKER": 0, "WARNING": 0, "INFO": 0, "NOT CHECKED": 0, "NOT PARSED": 0 };
        findings.forEach(function (f) { counts[f.severity]++; });

        var verdict;
        if (counts["BLOCKER"] > 0) verdict = "DO NOT DEPLOY";
        else if (counts["WARNING"] > 0 || counts["NOT PARSED"] > 0) verdict = "DEPLOY WITH FIXES";
        else verdict = "SAFE TO DEPLOY";

        return { verdict: verdict, gradeable: true, message: "", findings: findings, lines: lines.length, counts: counts };
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-fluentd-log-collector-config-safety-auditortm',
  name: 'J-Dawgs Fluentd Log Collector Config Safety Auditor',
  description: 'Grades a pasted Fluentd config offline: unauthenticated network inputs, plaintext output credentials by name, line, and length only — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
