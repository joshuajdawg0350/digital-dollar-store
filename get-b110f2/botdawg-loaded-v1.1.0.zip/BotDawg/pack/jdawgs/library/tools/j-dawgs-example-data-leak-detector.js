'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Example-Data Leak Detector".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the scan function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var EXAMPLE_TEXT = [
          "Customer onboarding export — draft v2",
          "Account holder: John Doe",
          "Backup contact: test@example.com",
          "Support line: (800) 555-0142",
          "Notes: Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
          "API_KEY=your-api-key-here",
          "Mailing address: 123 Main St, Springfield, MO 65806",
          "Project: Riverside duplex framing, start Nov 9, budget approved by crew lead.",
          "Real customer: Maria Alvarez, maria.alvarez@alvarezroofing.com, (417) 862-4400"
        ].join("\n");

        var CLS_LABEL = {
          certain: "CERTAIN PLACEHOLDER",
          likely: "LIKELY SAMPLE",
          review: "REVIEW"
        };

        // Rules run in priority order; a span already claimed by an earlier
        // rule on the same line is not reported twice.
        var RULES = [
          {
            cls: "certain",
            signal: "Reserved example domain (example.com / example.org / example.net / .test) — these domains can never belong to a real contact.",
            re: /(?:[A-Za-z0-9._%+-]+@)?(?:[A-Za-z0-9-]+\.)*example\.(?:com|org|net)(?:\/[^\s"'<>]*)?|\b(?:[A-Za-z0-9-]+\.)+(?:test|example|invalid)\b(?:\/[^\s"'<>]*)?/gi
          },
          {
            cls: "certain",
            signal: "555-01XX phone number — the 0100–0199 range after 555 is reserved for fictional use and never rings a real line.",
            re: /(?:\+?1[-.\s]?)?(?:\(\d{3}\)\s?|\d{3}[-.\s])?555[-.\s]01\d{2}\b|\b555[-.\s]01\d{2}\b/g
          },
          {
            cls: "certain",
            signal: "Lorem ipsum — filler text that was never replaced with real copy.",
            re: /lorem ipsum(?:\s+dolor sit amet)?/gi
          },
          {
            cls: "certain",
            signal: "Stock sample ID number (123-45-6789 / 000-00-0000) used in documentation examples everywhere — not a real person's number.",
            re: /\b(?:123-45-6789|000-00-0000)\b/g
          },
          {
            cls: "certain",
            signal: "Dummy credential placeholder — a stand-in value where a real key, token, or password belongs.",
            re: /your[-_ ]?api[-_ ]?key(?:[-_ ]?here)?|your[-_ ]?(?:api[-_ ]?)?(?:key|token|secret|password)\b|insert[-_ ]?(?:your[-_ ]?)?(?:api[-_ ]?)?key|replace[-_ ]?me\b|change[-_ ]?me\b|changeme\b|password123\b|passw0rd\b|dummy[-_ ]?(?:key|token|password|secret)|<your[^>\n]*>/gi
          },
          {
            cls: "certain",
            signal: "Unfinished-content marker (TODO / TBD / XXX / [insert …] / <placeholder>) — the draft itself says this part was never filled in.",
            re: /\bTODO\b|\bTBD\b|\bXXX\b|\[insert[^\]\n]*\]|\[placeholder\]|<placeholder[^>\n]*>|\{\{[^}\n]+\}\}/g
          },
          {
            cls: "likely",
            signal: "John Doe / Jane Doe — the classic placeholder name used in forms and examples.",
            re: /\b(?:John|Jane|Jon)\s+Doe\b/g
          },
          {
            cls: "likely",
            signal: "Acme — the stock sample company name from documentation and demos.",
            re: /\bAcme\s+(?:Corp|Corporation|Inc|Company|Co)\b\.?/g
          },
          {
            cls: "likely",
            signal: "Foo / Foobar — the standard nonsense placeholder word from code samples.",
            re: /\bFoo(?:bar)?\b/gi
          },
          {
            cls: "likely",
            signal: "Generic test/demo/user mailbox name — an address pattern used for samples, not a named real person.",
            re: /\b(?:user|test|demo|sample)@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b/gi
          },
          {
            cls: "review",
            signal: "555 phone number outside the reserved fictional 0100–0199 range — 555 numbers are often used as stand-ins, but this one could be real.",
            re: /\b\d{3}[-.\s]555[-.\s]\d{4}\b|\b555[-.\s](?!01\d{2})\d{4}\b/g
          },
          {
            cls: "review",
            signal: "The word pair reads like a labeled sample (\"sample data\", \"dummy record\", etc.) — worth an eyeball, may be intentional.",
            re: /\b(?:sample|dummy|mock|fake)\s+(?:data|record|entry|account|customer|user|value|name|address)\b/gi
          }
        ];

        // REVIEW-only and corroboration-gated: a stock sample street address.
        // Alone it proves nothing (real 123 Main Streets exist); it is only
        // reported when other sample signals appear in the same text.
        var ADDRESS_RE = /\b123\s+(?:Main|First|Oak|Elm)\s+(?:St|Street|Ave|Avenue|Blvd|Road|Rd)\b|\bAnytown\b/gi;

        function overlaps(spans, start, end) {
          for (var i = 0; i < spans.length; i++) {
            if (start < spans[i][1] && end > spans[i][0]) return true;
          }
          return false;
        }

        function scan(text) {
          var lines = text.split(/\r?\n/);
          var findings = [];
          var i, j, rule, m;
          for (i = 0; i < lines.length; i++) {
            var line = lines[i];
            var claimed = [];
            for (j = 0; j < RULES.length; j++) {
              rule = RULES[j];
              rule.re.lastIndex = 0;
              while ((m = rule.re.exec(line)) !== null) {
                if (m[0].length === 0) { rule.re.lastIndex++; continue; }
                var start = m.index, end = m.index + m[0].length;
                if (overlaps(claimed, start, end)) continue;
                // "Bar" only counts alongside Foo on the same line.
                claimed.push([start, end]);
                findings.push({
                  lineNo: i + 1, lineText: line, match: m[0],
                  start: start, end: end, cls: rule.cls, signal: rule.signal
                });
              }
            }
            // Foo/Bar pair: flag a standalone "Bar" only when Foo is present.
            if (/\bFoo/i.test(line)) {
              var barRe = /\bBar\b/g, bm;
              while ((bm = barRe.exec(line)) !== null) {
                if (!overlaps(claimed, bm.index, bm.index + 3)) {
                  claimed.push([bm.index, bm.index + 3]);
                  findings.push({
                    lineNo: i + 1, lineText: line, match: bm[0],
                    start: bm.index, end: bm.index + 3, cls: "likely",
                    signal: "Bar paired with Foo — the standard foo/bar placeholder pair from code samples."
                  });
                }
              }
            }
          }
          // Corroboration-gated sample street addresses.
          if (findings.length > 0) {
            for (i = 0; i < lines.length; i++) {
              ADDRESS_RE.lastIndex = 0;
              var am;
              while ((am = ADDRESS_RE.exec(lines[i])) !== null) {
                findings.push({
                  lineNo: i + 1, lineText: lines[i], match: am[0],
                  start: am.index, end: am.index + am[0].length, cls: "review",
                  signal: "Stock sample street address (123 Main St / Anytown). Weak on its own — real ones exist — but reported because other sample signals appear in this text."
                });
              }
            }
          }
          findings.sort(function (a, b) {
            if (a.lineNo !== b.lineNo) return a.lineNo - b.lineNo;
            return a.start - b.start;
          });
          return { findings: findings, lineCount: lines.length };
        }

        function verdictFor(findings) {
          var c = { certain: 0, likely: 0, review: 0 };
          findings.forEach(function (f) { c[f.cls]++; });
          if (c.certain > 0) return { key: "bad", text: "DO NOT SHIP — PLACEHOLDERS PRESENT", counts: c };
          if (c.likely > 0 || c.review > 0) return { key: "warn", text: "REVIEW BEFORE SENDING", counts: c };
          return { key: "good", text: "NO PLACEHOLDERS FOUND", counts: c };
        }

        function buildReport(text, result) {
          var v = verdictFor(result.findings);
          var out = [];
          out.push("J-Dawgs Example-Data Leak Detector™ — Scan Report");
          out.push("Verdict: " + v.text);
          out.push("Counts: " + v.counts.certain + " CERTAIN PLACEHOLDER · " +
                   v.counts.likely + " LIKELY SAMPLE · " + v.counts.review + " REVIEW" +
                   "  (" + result.lineCount + " lines scanned)");
          out.push("");
          if (result.findings.length === 0) {
            out.push("No example or placeholder patterns were found in this text.");
            out.push("Note: this scan is pattern-based only. A clean result is not proof the data is real.");
          } else {
            out.push("FINDINGS");
            result.findings.forEach(function (f) {
              out.push("Line " + f.lineNo + " [" + CLS_LABEL[f.cls] + "] \"" + f.match + "\"");
              out.push("  Line text: " + f.lineText.trim());
              out.push("  Signal: " + f.signal);
            });
            out.push("");
            out.push("REPLACEMENT CHECKLIST");
            result.findings.forEach(function (f) {
              out.push("[ ] Line " + f.lineNo + ": Replace \"" + f.match + "\" (" + CLS_LABEL[f.cls] + ") with the real value, or delete it before sending.");
            });
          }
          out.push("");
          out.push("Pattern-based scan only — not a verification that any value is real.");
          return out.join("\n");
        }
  return { "scan": (typeof scan !== 'undefined' ? scan : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_TEXT": (typeof EXAMPLE_TEXT !== 'undefined' ? EXAMPLE_TEXT : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["scan"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-example-data-leak-detector',
  name: 'J-Dawgs Example-Data Leak Detector',
  description: 'Scans drafts and datasets for placeholder/example data classified CERTAIN / LIKELY / REVIEW before it ships as real',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["scan"]) return { ok: false, output: null, summary: 'Extracted core has no scan function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_TEXT": __core["EXAMPLE_TEXT"] }
};
