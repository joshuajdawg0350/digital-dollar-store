'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Healthchecks Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

/* ---------- Worked examples (line numbers are part of the spec) ---------- */
var RISKY_LINES = [
  "# RISKY worked example - copied from a tutorial, never reviewed",   // 1
  "SECRET_KEY=changeme-example-secret",                                 // 2
  "DEBUG=True",                                                         // 3
  "ALLOWED_HOSTS=*",                                                    // 4
  "SITE_ROOT=http://checks.example.com",                                // 5
  "REGISTRATION_OPEN=True",                                             // 6
  "EMAIL_HOST=mail.example.com",                                        // 7
  "EMAIL_HOST_PASSWORD=PlainMailPass!2024xyz",                          // 8
  "EMAIL_BACKEND=django.core.mail.backends.console.EmailBackend",       // 9
  "DB_PASSWORD=PlainDbPass!2024xyz",                                    // 10
  "SUPERUSER_EMAIL=admin@example.com",                                  // 11
  "SUPERUSER_PASSWORD=admin123examplepass",                             // 12
  "DEFAULT_FROM_EMAIL=healthchecks@example.com"                         // 13
];
var RISKY = RISKY_LINES.join("\n");

var HARDENED_LINES = [
  "# HARDENED worked example - reviewed production posture",            // 1
  "SECRET_KEY=k7F9xQ2mZ8pL4vN6wR1tY3sD5aH0jK9xB2cV7nM4qW6eR8tY1u",       // 2
  "DEBUG=False",                                                        // 3
  "ALLOWED_HOSTS=status.northwind-ops.com",                             // 4
  "SITE_ROOT=https://status.northwind-ops.com",                         // 5
  "REGISTRATION_OPEN=False",                                            // 6
  "EMAIL_BACKEND=django.core.mail.backends.smtp.EmailBackend",          // 7
  "EMAIL_HOST=smtp.northwind-ops.com",                                  // 8
  "EMAIL_PORT=587",                                                     // 9
  "EMAIL_USE_TLS=True",                                                 // 10
  "EMAIL_HOST_USER=alerts@northwind-ops.com",                           // 11
  "EMAIL_HOST_PASSWORD=${EMAIL_HOST_PASSWORD}",                         // 12
  "DEFAULT_FROM_EMAIL=alerts@northwind-ops.com",                        // 13
  "DB=postgres",                                                        // 14
  "DB_HOST=db.internal",                                                // 15
  "DB_NAME=healthchecks",                                               // 16
  "DB_USER=hc_app",                                                     // 17
  "DB_PASSWORD=${DB_PASSWORD}",                                        // 18
  "SUPERUSER_EMAIL=ops@northwind-ops.com",                              // 19
  "PING_EMAIL_DOMAIN=northwind-ops.com"                                 // 20
];
var HARDENED = HARDENED_LINES.join("\n");

/* Planted secret values in the risky example — used ONLY by the leak check.
   They are never written into any finding, report, or export. */
var PLANTED_SECRETS = ["changeme-example-secret","PlainMailPass!2024xyz","PlainDbPass!2024xyz","admin123examplepass"];

/* ---------- Parsing ---------- */
var RECOGNIZED = {
  SECRET_KEY:1, DEBUG:1, ALLOWED_HOSTS:1, SITE_ROOT:1, SITE_NAME:1,
  REGISTRATION_OPEN:1, EMAIL_BACKEND:1, EMAIL_HOST:1, EMAIL_PORT:1,
  EMAIL_HOST_USER:1, EMAIL_HOST_PASSWORD:1, EMAIL_USE_TLS:1, EMAIL_USE_SSL:1,
  EMAIL_TIMEOUT:1, DEFAULT_FROM_EMAIL:1, DB:1, DB_HOST:1, DB_PORT:1,
  DB_NAME:1, DB_USER:1, DB_PASSWORD:1, DATABASE_URL:1,
  SUPERUSER_EMAIL:1, SUPERUSER_PASSWORD:1, PING_EMAIL_DOMAIN:1,
  PING_BODY_LIMIT:1, USE_PAYMENTS:1, MASTER_BADGE_LABEL:1
};
var SECRET_KEYS = { SECRET_KEY:1, EMAIL_HOST_PASSWORD:1, DB_PASSWORD:1, SUPERUSER_PASSWORD:1, DATABASE_URL:1 };

var EXAMPLE_MARKERS = ["example","changeme","change-me","change_me","your-secret","your_secret",
  "django-insecure","placeholder","replace-me","replace_me","todo","xxxxx","letmein","admin123"];

function stripQuotes(v){
  v = v.replace(/\s+#.*$/,"").trim();
  if ((v.charAt(0)==='"' && v.charAt(v.length-1)==='"') || (v.charAt(0)==="'" && v.charAt(v.length-1)==="'")){
    v = v.slice(1,-1);
  }
  return v.replace(/,\s*$/,"").trim();
}
function parseConfig(text){
  var entries = {};   /* key -> {value, line, length} (first occurrence wins) */
  var order = [];
  var lines = String(text||"").split(/\r?\n/);
  for (var i=0;i<lines.length;i++){
    var raw = lines[i];
    var t = raw.trim();
    if (!t || t.charAt(0)==="#" || t.charAt(0)===";") continue;
    t = t.replace(/^export\s+/,"");
    var m = t.match(/^([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/);
    if (!m) continue;
    var key = m[1].toUpperCase();
    var val = stripQuotes(m[2]);
    if (!(key in entries)){ entries[key] = { value: val, line: i+1, length: val.length }; order.push(key); }
  }
  return { entries: entries, order: order, lineCount: lines.length };
}
function isTrue(v){ return /^(true|1|yes|on)$/i.test(String(v||"").trim()); }
function isFalse(v){ return /^(false|0|no|off)$/i.test(String(v||"").trim()); }
function isReference(v){
  var s = String(v||"").trim();
  return /^\$\{[^}]*\}$/.test(s) || /^\$[A-Za-z_][A-Za-z0-9_]*$/.test(s) ||
         s.indexOf("os.environ") === 0 || s.indexOf("environ[") !== -1 ||
         s.indexOf("getenv(") !== -1 || s.indexOf("vault:") === 0 ||
         s.indexOf("env:") === 0 || /^<[^>]*>$/.test(s);
}
function hasExampleMarker(v){
  var s = String(v||"").toLowerCase();
  for (var i=0;i<EXAMPLE_MARKERS.length;i++){ if (s.indexOf(EXAMPLE_MARKERS[i]) !== -1) return true; }
  return /(^|\.)example\.(com|org|net)$/.test(s) || s.indexOf("@example.") !== -1 || s === "example.com";
}
function isExampleDomainValue(v){
  var s = String(v||"").toLowerCase();
  return s.indexOf("example.com") !== -1 || s.indexOf("example.org") !== -1 || s.indexOf("example.net") !== -1;
}

/* ---------- Audit ---------- */
function audit(text){
  var parsed = parseConfig(text);
  var e = parsed.entries;
  var findings = [];
  function add(sev, line, key, message, fix, secretLength){
    var f = { severity: sev, line: (line==null? null : line), key: key, message: message, fix: fix };
    if (typeof secretLength === "number") f.secret_length = secretLength;
    findings.push(f);
  }
  var recognizedCount = 0;
  for (var k in e){ if (RECOGNIZED[k]) recognizedCount++; }

  if (recognizedCount < 3){
    add("INFO", null, "(input)",
      "This paste contains " + recognizedCount + " recognized Healthchecks setting(s). At least 3 are needed to grade a configuration, so no deploy verdict can be issued.",
      "Paste the Healthchecks server configuration itself (SECRET_KEY, DEBUG, ALLOWED_HOSTS, SITE_ROOT, EMAIL_* and DB settings).");
    return finish(parsed, findings, true);
  }

  /* SECRET_KEY */
  if (!e.SECRET_KEY){
    add("BLOCKER", null, "SECRET_KEY",
      "SECRET_KEY is missing. Healthchecks signs sessions and links with it; a server without one is not deployable.",
      "Set SECRET_KEY to a freshly generated random value of at least 32 characters, supplied through the environment or a secrets manager.");
  } else {
    var sk = e.SECRET_KEY;
    var skProblems = [];
    if (sk.length < 32) skProblems.push("it is too short (length " + sk.length + "; minimum 32)");
    if (hasExampleMarker(sk.value)) skProblems.push("it matches a known example / placeholder value");
    if (skProblems.length){
      add("BLOCKER", sk.line, "SECRET_KEY",
        "SECRET_KEY on line " + sk.line + " is unsafe: " + skProblems.join(" and ") + ". The value itself is never shown here — key name, line, and length only.",
        "Replace SECRET_KEY with a freshly generated random value of at least 32 characters that appears in no tutorial or example.", sk.length);
    } else {
      add("INFO", sk.line, "SECRET_KEY",
        "SECRET_KEY is present on line " + sk.line + " with an adequate length (" + sk.length + " characters). Value not shown.",
        "", sk.length);
    }
  }

  /* DEBUG */
  if (!e.DEBUG){
    add("WARNING", null, "DEBUG",
      "DEBUG is not set. Its effective value then depends on defaults you have not stated in this paste.",
      "Set DEBUG=False explicitly for production.");
  } else if (isTrue(e.DEBUG.value)){
    add("BLOCKER", e.DEBUG.line, "DEBUG",
      "DEBUG is True on line " + e.DEBUG.line + ". In production posture this exposes stack traces and internals to visitors.",
      "Set DEBUG=False for any deployed server.");
  } else if (isFalse(e.DEBUG.value)){
    add("INFO", e.DEBUG.line, "DEBUG", "DEBUG is off (line " + e.DEBUG.line + ").", "");
  }

  /* ALLOWED_HOSTS */
  if (!e.ALLOWED_HOSTS){
    add("WARNING", null, "ALLOWED_HOSTS",
      "ALLOWED_HOSTS is not set, so the host names this server will answer to are unstated.",
      "Set ALLOWED_HOSTS to the exact host name(s) the server serves, with no wildcard.");
  } else {
    var ah = e.ALLOWED_HOSTS.value.replace(/[\[\]"']/g,"");
    if (ah.trim() === ""){
      add("BLOCKER", e.ALLOWED_HOSTS.line, "ALLOWED_HOSTS",
        "ALLOWED_HOSTS is empty on line " + e.ALLOWED_HOSTS.line + ". The server will reject requests or fall back to unsafe defaults.",
        "Set ALLOWED_HOSTS to the exact host name(s) the server serves.");
    } else if (ah.split(/[,\s]+/).indexOf("*") !== -1){
      add("BLOCKER", e.ALLOWED_HOSTS.line, "ALLOWED_HOSTS",
        "ALLOWED_HOSTS contains a wildcard on line " + e.ALLOWED_HOSTS.line + ", so the server answers to any Host header — an invitation to host-header attacks.",
        "Replace the wildcard with the exact host name(s) the server serves.");
    } else {
      add("INFO", e.ALLOWED_HOSTS.line, "ALLOWED_HOSTS",
        "ALLOWED_HOSTS names specific host(s) on line " + e.ALLOWED_HOSTS.line + ", with no wildcard.", "");
    }
  }

  /* SITE_ROOT */
  if (!e.SITE_ROOT){
    add("WARNING", null, "SITE_ROOT",
      "SITE_ROOT is not set. Links in alert emails and integrations are built from it, so they may point at the wrong place.",
      "Set SITE_ROOT to the server's public https address.");
  } else if (/^http:\/\//i.test(e.SITE_ROOT.value)){
    add("HIGH", e.SITE_ROOT.line, "SITE_ROOT",
      "SITE_ROOT uses plain http on line " + e.SITE_ROOT.line + ". Links carrying check tokens would travel unencrypted.",
      "Change SITE_ROOT to the https address of the server and put the server behind TLS.");
  } else if (/^https:\/\//i.test(e.SITE_ROOT.value)){
    add("INFO", e.SITE_ROOT.line, "SITE_ROOT", "SITE_ROOT uses https (line " + e.SITE_ROOT.line + ").", "");
  }

  /* REGISTRATION_OPEN */
  if (e.REGISTRATION_OPEN && isTrue(e.REGISTRATION_OPEN.value)){
    add("WARNING", e.REGISTRATION_OPEN.line, "REGISTRATION_OPEN",
      "Registration is open (REGISTRATION_OPEN is True, line " + e.REGISTRATION_OPEN.line + "). Anyone who finds the server can create an account.",
      "Set REGISTRATION_OPEN=False once your team has accounts, unless this is a deliberately public instance.");
  } else if (e.REGISTRATION_OPEN && isFalse(e.REGISTRATION_OPEN.value)){
    add("INFO", e.REGISTRATION_OPEN.line, "REGISTRATION_OPEN", "Registration is closed (line " + e.REGISTRATION_OPEN.line + ").", "");
  }

  /* Email posture */
  if (e.EMAIL_BACKEND){
    var be = e.EMAIL_BACKEND.value.toLowerCase();
    if (be.indexOf("console") !== -1){
      add("WARNING", e.EMAIL_BACKEND.line, "EMAIL_BACKEND",
        "The email backend on line " + e.EMAIL_BACKEND.line + " is the console backend: outgoing mail is printed to a log instead of delivered, so alerts and invites never arrive.",
        "Use the SMTP email backend with a real mail host for a deployed server.");
    } else if (be.indexOf("filebased") !== -1){
      add("WARNING", e.EMAIL_BACKEND.line, "EMAIL_BACKEND",
        "The email backend on line " + e.EMAIL_BACKEND.line + " writes mail to files instead of delivering it.",
        "Use the SMTP email backend with a real mail host for a deployed server.");
    } else if (be.indexOf("smtp") !== -1){
      add("INFO", e.EMAIL_BACKEND.line, "EMAIL_BACKEND", "The SMTP email backend is configured (line " + e.EMAIL_BACKEND.line + ").", "");
      if (e.EMAIL_HOST && !isTrue((e.EMAIL_USE_TLS||{}).value) && !isTrue((e.EMAIL_USE_SSL||{}).value)){
        add("WARNING", e.EMAIL_HOST.line, "EMAIL_USE_TLS",
          "SMTP is configured but neither EMAIL_USE_TLS nor EMAIL_USE_SSL is True, so mail credentials and content may cross the network unencrypted.",
          "Set EMAIL_USE_TLS=True (typically with EMAIL_PORT=587) or EMAIL_USE_SSL=True.");
      }
    }
  }
  if (e.EMAIL_HOST && isExampleDomainValue(e.EMAIL_HOST.value)){
    add("WARNING", e.EMAIL_HOST.line, "EMAIL_HOST",
      "EMAIL_HOST on line " + e.EMAIL_HOST.line + " still carries an example domain, so it points at a host that is not yours.",
      "Set EMAIL_HOST to your real mail server's host name.");
  }
  if (e.EMAIL_HOST_PASSWORD){
    var mp = e.EMAIL_HOST_PASSWORD;
    if (isReference(mp.value)){
      add("INFO", mp.line, "EMAIL_HOST_PASSWORD",
        "EMAIL_HOST_PASSWORD on line " + mp.line + " is referenced from the environment rather than written out. Value not shown.", "", mp.length);
    } else if (mp.value.trim() !== ""){
      add("HIGH", mp.line, "EMAIL_HOST_PASSWORD",
        "EMAIL_HOST_PASSWORD is written in plaintext in this configuration (line " + mp.line + ", length " + mp.length + "). Anyone who can read the config owns the mailbox. The value itself is never shown here.",
        "Move EMAIL_HOST_PASSWORD into the environment or a secrets manager and reference it (for example ${EMAIL_HOST_PASSWORD}); rotate the password, since it has been written down.", mp.length);
    }
  }
  ["DEFAULT_FROM_EMAIL","SUPERUSER_EMAIL"].forEach(function(key){
    if (e[key] && isExampleDomainValue(e[key].value)){
      add("WARNING", e[key].line, key,
        key + " on line " + e[key].line + " still uses an example domain, so mail or the admin account points somewhere that is not yours.",
        "Set " + key + " to a real address on a domain you control.");
    }
  });

  /* Database password */
  ["DB_PASSWORD","DATABASE_URL"].forEach(function(key){
    if (e[key]){
      var dp = e[key];
      if (isReference(dp.value)){
        add("INFO", dp.line, key,
          key + " on line " + dp.line + " is referenced from the environment rather than written out. Value not shown.", "", dp.length);
      } else if (dp.value.trim() !== ""){
        add("HIGH", dp.line, key,
          key + " is written in plaintext in this configuration (line " + dp.line + ", length " + dp.length + "). A pasted config is exactly the kind of file that gets copied, committed, and forwarded. The value itself is never shown here.",
          "Move " + key + " into the environment or a secrets manager and reference it (for example ${" + key + "}); rotate the database password, since it has been written down.", dp.length);
      }
    }
  });

  /* Superuser password */
  if (e.SUPERUSER_PASSWORD){
    var sp = e.SUPERUSER_PASSWORD;
    if (!isReference(sp.value) && sp.value.trim() !== ""){
      var extra = hasExampleMarker(sp.value) ? " It also matches a known example / placeholder value." : "";
      add("HIGH", sp.line, "SUPERUSER_PASSWORD",
        "SUPERUSER_PASSWORD is written in plaintext in this configuration (line " + sp.line + ", length " + sp.length + ")." + extra + " The value itself is never shown here.",
        "Create the superuser interactively at first boot instead of storing its password in the config; if a password was written down, change it.", sp.length);
    }
  }
  if (e.SUPERUSER_EMAIL){
    add("INFO", e.SUPERUSER_EMAIL.line, "SUPERUSER_EMAIL",
      isExampleDomainValue(e.SUPERUSER_EMAIL.value) ? "SUPERUSER_EMAIL is set (line " + e.SUPERUSER_EMAIL.line + "); see the example-domain warning above." :
      "SUPERUSER_EMAIL is set to an address on a non-example domain (line " + e.SUPERUSER_EMAIL.line + ").", "");
  }

  return finish(parsed, findings, false);
}

function finish(parsed, findings, notEnough){
  var rank = { BLOCKER:0, HIGH:1, WARNING:2, INFO:3 };
  findings.sort(function(a,b){
    if (rank[a.severity] !== rank[b.severity]) return rank[a.severity] - rank[b.severity];
    var la = (a.line == null ? 0 : a.line), lb = (b.line == null ? 0 : b.line);
    return la - lb;
  });
  var counts = { BLOCKER:0, HIGH:0, WARNING:0, INFO:0 };
  findings.forEach(function(f){ counts[f.severity]++; });
  var verdict;
  if (notEnough) verdict = "NOT ENOUGH TO GRADE";
  else if (counts.BLOCKER > 0) verdict = "DO NOT DEPLOY";
  else if (counts.HIGH > 0 || counts.WARNING > 0) verdict = "DEPLOY WITH FIXES";
  else verdict = "SAFE TO DEPLOY";
  var fixes = findings.filter(function(f){ return f.severity !== "INFO" && f.fix; })
    .map(function(f){ return { line: f.line, key: f.key, severity: f.severity, fix: f.fix }; })
    .sort(function(a,b){ var la = (a.line == null ? 0 : a.line), lb = (b.line == null ? 0 : b.line); return la - lb; });
  return { verdict: verdict, counts: counts, findings: findings, fixes: fixes,
           recognized_lines: parsed.lineCount };
}

/* ---------- Rendering ---------- */
function esc(s){ return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"); }
var lastResult = null, lastReport = "", lastJson = "";

function buildReport(r){
  var out = [];
  out.push("J-Dawgs Healthchecks Server Config Safety Auditor - Audit Report");
  out.push("Verdict: " + r.verdict);
  out.push("Findings: " + r.counts.BLOCKER + " BLOCKER, " + r.counts.HIGH + " HIGH, " +
           r.counts.WARNING + " WARNING, " + r.counts.INFO + " INFO");
  out.push("Secrets are reported by key name, line number, and length only. No secret values appear in this report.");
  out.push("");
  out.push("FINDINGS");
  r.findings.forEach(function(f){
    out.push("[" + f.severity + "] " + (f.line ? "Line " + f.line : "No line (setting absent)") + " - " + f.key + ": " + f.message);
  });
  out.push("");
  out.push("FIX LIST");
  if (!r.fixes.length) out.push("No fixes required.");
  r.fixes.forEach(function(f,i){
    out.push((i+1) + ". " + (f.line ? "Line " + f.line : "Setting absent") + " (" + f.key + "): " + f.fix);
  });
  return out.join("\n");
}
function buildJson(r){
  return JSON.stringify({
    tool: "J-Dawgs Healthchecks Server Config Safety Auditor",
    verdict: r.verdict,
    counts: r.counts,
    findings: r.findings,
    fixes: r.fixes,
    note: "Secrets are reported by key name, line number, and length only. No secret values are included."
  }, null, 2);
}
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_MARKERS": (typeof EXAMPLE_MARKERS !== 'undefined' ? EXAMPLE_MARKERS : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-healthchecks-server-config-safety-auditortm',
  name: 'J-Dawgs Healthchecks Server Config Safety Auditor',
  description: 'Host tools only tell you the server started; ours grades a pasted Healthchecks cron-monitoring server config offline into one deploy verdict — secrets by key name/line/length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_MARKERS": __core["EXAMPLE_MARKERS"] }
};
