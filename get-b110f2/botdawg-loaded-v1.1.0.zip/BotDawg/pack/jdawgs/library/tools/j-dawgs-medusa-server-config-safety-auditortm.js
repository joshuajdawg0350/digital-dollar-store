'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Medusa Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------------- Planted worked examples ---------------- */

      var RISKY_EXAMPLE = [
        "# RISKY EXAMPLE — a Medusa config that should never ship",
        "NODE_ENV=development",
        "JWT_SECRET=dev-jwt-secret-change-me",
        "COOKIE_SECRET=cookie123",
        "DATABASE_URL=postgres://medusa_app:dbpass!medusa@db.example.com:5432/medusa_prod",
        "REDIS_URL=redis://:redispass99@cache.example.com:6379",
        "ADMIN_CORS=*",
        "STORE_CORS=http://shop.example.com,https://shop.example.com",
        "AUTH_CORS=*",
        "DATABASE_SSL=false"
      ].join("\n");

      var HARDENED_EXAMPLE = [
        "# HARDENED EXAMPLE — the shape of a deployable Medusa config",
        "NODE_ENV=production",
        "JWT_SECRET=a3f9c1e7b5d24806f1a9c3e5b7d20914f6a8c0e2b4d6f8a1c3e5b7d9f0a2c4e6",
        "COOKIE_SECRET=71bd04f9c2e6a8153d7f90b4c6e2a81f5d3b709c4e6a2f81d5b3c709e4a6f2d8",
        "DATABASE_URL=postgres://medusa_app:Xk9!mQ2$vL8pR4&zN7w@db.example.com:5432/medusa_prod?sslmode=require",
        "REDIS_URL=rediss://:Rd7!sK3wP9mZ5&xQ2v@cache.example.com:6380",
        "ADMIN_CORS=https://admin.example.com",
        "STORE_CORS=https://shop.example.com",
        "AUTH_CORS=https://shop.example.com",
        "DATABASE_SSL=true"
      ].join("\n");

      var MALFORMED_EXAMPLE = [
        "The quick brown fox jumps over the lazy dog.",
        "Lunch is at noon, bring your own sandwich,",
        "and the meeting moved to the big room upstairs."
      ].join("\n");

      /* ---------------- Auditor ---------------- */

      var KNOWN_KEYS = {
        JWT_SECRET:1, COOKIE_SECRET:1, DATABASE_URL:1, REDIS_URL:1,
        ADMIN_CORS:1, STORE_CORS:1, AUTH_CORS:1, NODE_ENV:1, DATABASE_SSL:1
      };
      var CAMEL_KEYS = {
        jwtSecret:"JWT_SECRET", cookieSecret:"COOKIE_SECRET",
        databaseUrl:"DATABASE_URL", redisUrl:"REDIS_URL",
        adminCors:"ADMIN_CORS", storeCors:"STORE_CORS", authCors:"AUTH_CORS",
        nodeEnv:"NODE_ENV"
      };
      var WEAK_SECRET_EXACT = ["secret","supersecret","changeme","change-me","change_me",
        "test","testing","dev","development","default","password","medusa","example",
        "todo","xxx","123456","jwtsecret","cookiesecret","letmein","admin","root"];
      var WEAK_SECRET_SUBS = ["example","change-me","changeme","change_me","your-","your_",
        "placeholder","replace-me","replace_me","insert-","todo","sample-"];
      var WEAK_PASSWORDS = ["password","postgres","admin","root","letmein","changeme",
        "medusa","secret","123456","qwerty","default","redis","pass"];
      var SEV_RANK = { CRITICAL:0, HIGH:1, MEDIUM:2, LOW:3, INFO:4 };
      var MIN_SECRET_LEN = 32;

      function cleanVal(v){
        v = String(v).replace(/^\s+|\s+$/g,"").replace(/;\s*$/,"").replace(/,\s*$/,"");
        if (v.length >= 2){
          var a = v.charAt(0), b = v.charAt(v.length - 1);
          if ((a === '"' && b === '"') || (a === "'" && b === "'")) v = v.slice(1, -1);
        }
        return v;
      }

      function parseLine(raw){
        var t = String(raw).replace(/^\s+|\s+$/g,"");
        if (!t) return null;
        if (t.charAt(0) === "#") return null;
        if (t.indexOf("//") === 0) return null;
        var m = t.match(/^(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/);
        if (m) return { key:m[1], value:cleanVal(m[2]), envRef:null };
        m = t.match(/^"?([A-Za-z_][A-Za-z0-9_]*)"?\s*:\s*(.+)$/);
        if (m){
          var v = m[2].replace(/,\s*$/,"").replace(/^\s+|\s+$/g,"");
          var em = v.match(/^process\.env\.([A-Za-z_][A-Za-z0-9_]*)$/);
          if (em) return { key:m[1], value:null, envRef:em[1] };
          return { key:m[1], value:cleanVal(v), envRef:null };
        }
        return null;
      }

      function canonicalKey(k){
        if (KNOWN_KEYS[k]) return k;
        var up = k.toUpperCase();
        if (KNOWN_KEYS[up]) return up;
        if (CAMEL_KEYS[k]) return CAMEL_KEYS[k];
        return null;
      }

      function isLocalHost(h){
        if (!h) return true;
        h = h.toLowerCase();
        return h === "localhost" || h === "127.0.0.1" || h === "::1" || /\.local$/.test(h);
      }

      function looksPlaceholder(v){
        var s = v.toLowerCase();
        if (WEAK_SECRET_EXACT.indexOf(s) >= 0) return true;
        for (var i = 0; i < WEAK_SECRET_SUBS.length; i++){
          if (s.indexOf(WEAK_SECRET_SUBS[i]) >= 0) return true;
        }
        return false;
      }

      function auditConfig(text){
        var findings = [];
        function add(line, key, severity, issue, detail){
          findings.push({ line:line, key:key, severity:severity, issue:issue, detail:detail });
        }

        var rawText = (text === null || text === undefined) ? "" : String(text);
        var lines = rawText.split(/\r?\n/);
        var entries = {};   // canonical or raw key -> {value, line, envRef}
        var order = [];

        lines.forEach(function(raw, i){
          var lineNo = i + 1;
          var p = parseLine(raw);
          if (p){
            var canon = canonicalKey(p.key);
            var storeKey = canon || p.key;
            if (!entries[storeKey]){
              entries[storeKey] = { value:p.value, line:lineNo, envRef:p.envRef, canon:canon };
              order.push(storeKey);
            }
          }
          // Code-level TLS kill switches, wherever they appear in the paste.
          if (/rejectUnauthorized\s*:\s*false/.test(raw)){
            add(lineNo, "DATABASE_SSL", "HIGH",
              "TLS certificate verification is disabled (rejectUnauthorized: false)",
              "With verification off, the database connection can be intercepted. Remove this setting or set it to true.");
          } else if (/\bssl\s*:\s*false/.test(raw)){
            add(lineNo, "DATABASE_SSL", "HIGH",
              "Database SSL is disabled in code (ssl: false)",
              "The database connection is configured without TLS. Enable SSL for any non-local database.");
          }
        });

        var signals = 0;
        Object.keys(KNOWN_KEYS).forEach(function(k){ if (entries[k]) signals++; });

        if (signals === 0){
          return { verdict:"NOT ENOUGH TO GRADE", findings:[], counts:countSev([]), signals:0 };
        }

        /* --- JWT_SECRET / COOKIE_SECRET --- */
        ["JWT_SECRET","COOKIE_SECRET"].forEach(function(key){
          var e = entries[key];
          if (!e){
            add(null, key, "HIGH", key + " is missing from the pasted config",
              "Medusa needs a strong " + key + " in production. If it is set somewhere the paste does not cover, this finding does not apply — otherwise set one before deploying.");
            return;
          }
          if (e.envRef){
            if (!entries[e.envRef]){
              add(e.line, key, "INFO", key + " is read from the environment and is not in the paste",
                key + " comes from process.env." + e.envRef + ", whose value was not pasted, so its strength was not graded.");
            }
            return;
          }
          var v = e.value || "";
          if (v.length === 0){
            add(e.line, key, "CRITICAL", key + " is set but empty",
              key + " has a value length of 0. Set a long random value before deploying.");
            return;
          }
          if (looksPlaceholder(v)){
            add(e.line, key, "CRITICAL", key + " looks like an example or placeholder value",
              "Value length: " + v.length + " characters. Example and placeholder secrets are public knowledge — replace with a long random value. (The value itself is never printed.)");
          }
          if (v.length < MIN_SECRET_LEN){
            add(e.line, key, "CRITICAL", key + " is too short (" + v.length + " characters)",
              "Value length: " + v.length + " characters; " + MIN_SECRET_LEN + " or more is the floor for a production secret. Use a long random value. (The value itself is never printed.)");
          }
        });
        var j = entries.JWT_SECRET, c = entries.COOKIE_SECRET;
        if (j && c && !j.envRef && !c.envRef && j.value && j.value === c.value){
          add(c.line, "COOKIE_SECRET", "HIGH", "COOKIE_SECRET reuses the same value as JWT_SECRET",
            "The two secrets match exactly (value length: " + c.value.length + "). Generate a separate random value for each.");
        }

        /* --- DATABASE_URL / REDIS_URL --- */
        function checkUrl(key, e){
          var v = e.value || "";
          if (v.length === 0){
            add(e.line, key, "HIGH", key + " is set but empty",
              "An empty connection string will not connect. Set a full URL or remove the key.");
            return;
          }
          var m = v.match(/^([a-zA-Z][a-zA-Z0-9+.-]*):\/\/([^\/?#]*)([\s\S]*)$/);
          if (!m){
            add(e.line, key, "MEDIUM", key + " is not in URL form",
              "The value does not parse as a scheme://host URL, so its password and TLS posture could not be checked.");
            return;
          }
          var scheme = m[1].toLowerCase();
          var authority = m[2];
          var rest = m[3] || "";
          var at = authority.lastIndexOf("@");
          var userinfo = at >= 0 ? authority.slice(0, at) : "";
          var hostport = at >= 0 ? authority.slice(at + 1) : authority;
          var host = hostport.replace(/:\d+$/,"").replace(/^\[/,"").replace(/\]$/,"");
          var local = isLocalHost(host);
          var pw = null;
          if (userinfo){
            var ci = userinfo.indexOf(":");
            if (ci >= 0) pw = userinfo.slice(ci + 1);
          }
          var sslRequired = /sslmode=(require|verify-ca|verify-full)/i.test(rest);

          if (pw !== null && pw.length > 0){
            var weakPw = WEAK_PASSWORDS.indexOf(pw.toLowerCase()) >= 0 || pw.length < 8;
            if (weakPw){
              add(e.line, key, "CRITICAL", "Default or weak password embedded in " + key,
                "Password length: " + pw.length + " characters. Default and short passwords are guessed first — rotate this credential and use a long random password. (The password itself is never printed.)");
            } else if (key === "DATABASE_URL"){
              if (sslRequired){
                add(e.line, key, "LOW", "Password embedded in DATABASE_URL, with TLS required",
                  "Password length: " + pw.length + " characters, and the URL requires TLS (sslmode), so the credential is not sent in the clear. A secrets manager is still cleaner than a password inside a URL. (The password itself is never printed.)");
              } else if (local){
                add(e.line, key, "LOW", "Password embedded in DATABASE_URL for a local database",
                  "Password length: " + pw.length + " characters; the host is local, which is normal for development. Do not reuse this URL shape in production without sslmode=require. (The password itself is never printed.)");
              } else {
                add(e.line, key, "HIGH", "Plaintext password embedded in DATABASE_URL without required TLS",
                  "Password length: " + pw.length + " characters, sent to a non-localhost host with no sslmode=require in the URL — the credential can travel unencrypted. Add sslmode=require and rotate the password. (The password itself is never printed.)");
              }
            } else { // REDIS_URL
              if (scheme === "rediss"){
                add(e.line, key, "LOW", "Password embedded in REDIS_URL, over TLS (rediss://)",
                  "Password length: " + pw.length + " characters, and rediss:// encrypts the connection. A secrets manager is still cleaner than a password inside a URL. (The password itself is never printed.)");
              } else if (local){
                add(e.line, key, "LOW", "Password embedded in REDIS_URL for a local cache",
                  "Password length: " + pw.length + " characters; the host is local, which is normal for development. Use rediss:// for any remote cache. (The password itself is never printed.)");
              } else {
                add(e.line, key, "HIGH", "Plaintext password embedded in REDIS_URL over unencrypted redis://",
                  "Password length: " + pw.length + " characters, sent to a non-localhost host over plain redis:// — the credential travels unencrypted. Switch to rediss:// and rotate the password. (The password itself is never printed.)");
              }
            }
          } else {
            if (key === "DATABASE_URL" && !local && !sslRequired){
              add(e.line, key, "MEDIUM", "DATABASE_URL does not require TLS",
                "No sslmode=require in the URL and the host is not localhost. Add sslmode=require so the database connection is encrypted.");
            }
            if (key === "REDIS_URL" && !local && scheme === "redis"){
              add(e.line, key, "MEDIUM", "REDIS_URL has no password and uses unencrypted redis:// to a remote host",
                "A remote cache with no password and no TLS is open to anyone who can reach it. Use rediss:// with a password.");
            }
          }
        }
        if (entries.DATABASE_URL && !entries.DATABASE_URL.envRef) checkUrl("DATABASE_URL", entries.DATABASE_URL);
        if (entries.REDIS_URL && !entries.REDIS_URL.envRef) checkUrl("REDIS_URL", entries.REDIS_URL);

        /* --- CORS --- */
        ["ADMIN_CORS","STORE_CORS","AUTH_CORS"].forEach(function(key){
          var e = entries[key];
          if (!e || e.envRef) return;
          var parts = String(e.value || "").split(",");
          var wild = false;
          var httpRemote = [];
          parts.forEach(function(p){
            var o = p.replace(/^\s+|\s+$/g,"").replace(/^['"]|['"]$/g,"");
            if (o === "*") wild = true;
            else if (/^http:\/\//i.test(o)){
              var h = o.slice(7).split(/[:\/]/)[0];
              if (!isLocalHost(h)) httpRemote.push(o);
            }
          });
          if (wild){
            add(e.line, key, "HIGH", "Wildcard CORS origin (*) in " + key,
              key + " allows any website origin. List the exact https:// origins the app actually serves.");
          }
          if (httpRemote.length){
            add(e.line, key, "MEDIUM", "Plain http:// origin allowed in " + key,
              "Non-localhost http:// origin(s): " + httpRemote.join(", ") + ". Browsers and attackers both treat http as unprotected — switch these origins to https://.");
          }
        });

        /* --- DATABASE_SSL --- */
        var dbs = entries.DATABASE_SSL;
        if (dbs && !dbs.envRef){
          var dv = String(dbs.value || "").toLowerCase();
          if (dv === "false" || dv === "0" || dv === "no" || dv === "off"){
            add(dbs.line, "DATABASE_SSL", "HIGH", "DATABASE_SSL is disabled",
              "DATABASE_SSL=false turns off encrypted database connections. Enable SSL for any non-local database.");
          }
        }

        /* --- NODE_ENV --- */
        var ne = entries.NODE_ENV;
        if (!ne){
          add(null, "NODE_ENV", "LOW", "NODE_ENV is not set in the pasted config",
            "Set NODE_ENV=production for a production deploy so the server runs with production behavior.");
        } else if (!ne.envRef && String(ne.value || "").toLowerCase() !== "production"){
          add(ne.line, "NODE_ENV", "MEDIUM", "NODE_ENV is not production",
            "NODE_ENV is set to \"" + String(ne.value || "") + "\" in the paste. Development mode can leak debug detail and skips production hardening — set NODE_ENV=production for the deploy.");
        }

        /* --- Other password-bearing keys (admin / default passwords) --- */
        order.forEach(function(k){
          var e = entries[k];
          if (!e || e.envRef || e.canon) return;
          if (!/PASSWORD|PASSWD/.test(k.toUpperCase())) return;
          var v = e.value || "";
          if (looksPlaceholder(v) || v.length < 12){
            add(e.line, k, "HIGH", "Weak or default password set in " + k,
              "Value length: " + v.length + " characters. A password stored in the config at this strength is a default waiting to be guessed — replace it with a long random value. (The value itself is never printed.)");
          } else {
            add(e.line, k, "LOW", "Password stored directly in the config (" + k + ")",
              "Value length: " + v.length + " characters. Prefer injecting passwords from a secrets manager or the host's environment instead of the config file. (The value itself is never printed.)");
          }
        });
        order.forEach(function(k){
          var e = entries[k];
          if (!e || e.envRef) return;
          if (!/REJECT_UNAUTHORIZED/.test(k.toUpperCase())) return;
          var v = String(e.value || "").toLowerCase();
          if (v === "false" || v === "0"){
            add(e.line, k, "HIGH", "TLS certificate verification is disabled (" + k + ")",
              "With verification off, the database connection can be intercepted. Remove this setting or set it to true.");
          }
        });

        findings.sort(function(a, b){
          var r = SEV_RANK[a.severity] - SEV_RANK[b.severity];
          if (r !== 0) return r;
          var la = (a.line === null ? 9999 : a.line), lb = (b.line === null ? 9999 : b.line);
          return la - lb;
        });

        var counts = countSev(findings);
        var verdict;
        if (counts.CRITICAL > 0 || counts.HIGH > 0) verdict = "DO NOT DEPLOY";
        else if (counts.MEDIUM > 0) verdict = "DEPLOY WITH FIXES";
        else verdict = "SAFE TO DEPLOY";
        return { verdict:verdict, findings:findings, counts:counts, signals:signals };
      }

      function countSev(findings){
        var counts = { CRITICAL:0, HIGH:0, MEDIUM:0, LOW:0, INFO:0, total:findings.length };
        findings.forEach(function(f){ counts[f.severity]++; });
        return counts;
      }

      /* ---------------- Report / JSON builders ---------------- */

      function buildReport(result, when){
        var out = [];
        out.push("J-Dawgs Medusa Server Config Safety Auditor™ — Config Audit Report");
        out.push("Audited: " + when.toLocaleString());
        out.push("Verdict: " + result.verdict);
        if (result.verdict === "NOT ENOUGH TO GRADE"){
          out.push("");
          out.push("The pasted text did not contain any recognizable Medusa configuration");
          out.push("(no JWT_SECRET, COOKIE_SECRET, DATABASE_URL, REDIS_URL, ADMIN_CORS,");
          out.push("STORE_CORS, AUTH_CORS, NODE_ENV, or DATABASE_SSL entries), so there is");
          out.push("nothing to grade. Paste an env-style config or a medusa-config file's text.");
        } else {
          var c = result.counts;
          out.push("Findings: " + c.total + " (" + c.CRITICAL + " critical, " + c.HIGH + " high, " +
                   c.MEDIUM + " medium, " + c.LOW + " low, " + c.INFO + " info)");
          out.push("");
          if (result.findings.length === 0){
            out.push("No findings. Every check passed on the pasted text.");
          }
          result.findings.forEach(function(f){
            var where = (f.line === null) ? "Not in paste" : "Line " + f.line;
            out.push("[" + where + "] " + f.severity + " · " + f.key + " — " + f.issue);
            out.push("    " + f.detail);
          });
        }
        out.push("");
        out.push("Masking: secrets are reported by key name, line, and value length only.");
        out.push("Secret values never appear in this report or the JSON export.");
        out.push("Scope: heuristic text audit of a pasted config. This tool does not start");
        out.push("Medusa, connect to a database, or verify secrets against a live server.");
        return out.join("\n");
      }

      function buildJson(result, when){
        var obj = {
          tool: "J-Dawgs Medusa Server Config Safety Auditor™",
          auditedAt: when.toISOString(),
          verdict: result.verdict,
          counts: result.counts,
          findings: result.findings.map(function(f){
            return { line:f.line, severity:f.severity, key:f.key, issue:f.issue, detail:f.detail };
          }),
          masking: "Secrets are reported by key name, line, and value length only; secret values are never included."
        };
        return JSON.stringify(obj, null, 2);
      }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined), "MALFORMED_EXAMPLE": (typeof MALFORMED_EXAMPLE !== 'undefined' ? MALFORMED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-medusa-server-config-safety-auditortm',
  name: 'J-Dawgs Medusa Server Config Safety Auditor',
  description: 'Grades a pasted Medusa server config offline into one deploy verdict (SAFE TO DEPLOY / DEPLOY WITH FIXES / DO NOT DEPLOY / NOT ENOUGH TO GRADE) — short or example JWT_SECRET and COOKIE_SECRET, plaintext DATABASE_URL and REDIS_URL passwords, and wildcard or http CORS flagged; secrets reported by key ',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"], "MALFORMED_EXAMPLE": __core["MALFORMED_EXAMPLE"] }
};
