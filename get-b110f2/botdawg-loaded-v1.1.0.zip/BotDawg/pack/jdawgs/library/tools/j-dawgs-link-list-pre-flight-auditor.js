'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Link List Pre-Flight Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var LONG_URL_LIMIT = 2000;

        var TRACKING_EXACT = {
          fbclid: 1, gclid: 1, dclid: 1, msclkid: 1, yclid: 1, ttclid: 1,
          mc_cid: 1, mc_eid: 1, igshid: 1, _hsenc: 1, _hsmi: 1, vero_id: 1,
          spm: 1, si: 1, ref_src: 1, wbraid: 1, gbraid: 1, twclid: 1,
          li_fat_id: 1, s_cid: 1, cmpid: 1, icid: 1
        };
        function isTrackingParam(name) {
          var n = name.toLowerCase();
          return n.indexOf("utm_") === 0 || !!TRACKING_EXACT[n];
        }

        var SHORTENERS = {
          "bit.ly": 1, "tinyurl.com": 1, "t.co": 1, "goo.gl": 1, "ow.ly": 1,
          "buff.ly": 1, "is.gd": 1, "v.gd": 1, "rb.gy": 1, "tiny.cc": 1,
          "cutt.ly": 1, "shorturl.at": 1, "rebrand.ly": 1, "bl.ink": 1,
          "bit.do": 1, "mcaf.ee": 1, "x.co": 1, "lnkd.in": 1, "dlvr.it": 1,
          "db.tt": 1, "qr.ae": 1, "s.id": 1, "short.io": 1, "t2m.io": 1,
          "yourls.org": 1, "su.pr": 1, "budurl.com": 1, "bc.vc": 1,
          "twitthis.com": 1, "u.nu": 1, "cli.re": 1, "shorte.st": 1,
          "go2l.ink": 1, "rb.gy": 1, "plu.sh": 1, "fold.am": 1
        };

        var TWO_PART_SUFFIXES = {
          "co.uk": 1, "org.uk": 1, "ac.uk": 1, "com.au": 1, "net.au": 1,
          "co.nz": 1, "com.br": 1, "co.jp": 1, "com.cn": 1, "com.tw": 1,
          "co.kr": 1, "com.mx": 1, "com.ar": 1, "co.za": 1, "com.sg": 1,
          "com.hk": 1, "co.in": 1, "com.co": 1, "com.pl": 1, "com.tr": 1
        };

        function regDomain(host) {
          var parts = String(host || "").toLowerCase().replace(/\.$/, "").split(".").filter(Boolean);
          if (parts.length <= 2) return parts.join(".");
          var lastTwo = parts.slice(-2).join(".");
          if (TWO_PART_SUFFIXES[lastTwo]) return parts.slice(-3).join(".");
          return lastTwo;
        }

        function stripTags(s) {
          return s.replace(/<[^>]*>/g, "");
        }

        function parseLine(raw) {
          var line = raw.replace(/^\s*(?:[-*•]|\d+[.)])\s+/, "").trim();
          if (!line) return null;
          var m;
          // Markdown: [label](url "optional title")
          m = line.match(/\[([^\]]*)\]\(\s*<?([^)\s>]+)>?(?:\s+["'][^"']*["'])?\s*\)/);
          if (m) return { label: m[1].trim(), url: m[2].trim(), format: "Markdown" };
          // HTML anchor
          m = line.match(/<a\b[^>]*?href\s*=\s*(?:"([^"]*)"|'([^']*)')[^>]*>([\s\S]*?)<\/a\s*>/i);
          if (m) return { label: stripTags(m[3]).trim(), url: (m[1] !== undefined ? m[1] : m[2]).trim(), format: "HTML" };
          // label | URL  (URL is after the last pipe)
          if (line.indexOf("|") !== -1) {
            var idx = line.lastIndexOf("|");
            var urlPart = line.slice(idx + 1).trim();
            var labelPart = line.slice(0, idx).trim();
            if (urlPart) return { label: labelPart, url: urlPart, format: "Label | URL" };
          }
          // Bare URL with scheme, possibly embedded in a plain line
          m = line.match(/https?:\/\/[^\s<>"']+/i);
          if (m) {
            var u = m[0].replace(/[.,;:!?)\]]+$/, "");
            var rest = line.replace(m[0], "").trim();
            return { label: rest, url: u, format: "Bare URL" };
          }
          // Bare domain / path without a scheme
          m = line.match(/\b(?:www\.)?[a-z0-9](?:[a-z0-9-]*[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)+(?:\/[^\s<>"']*)?/i);
          if (m && m[0].indexOf(".") !== -1) {
            var rest2 = line.replace(m[0], "").replace(/\|\s*$/, "").trim();
            return { label: rest2, url: m[0].replace(/[.,;:!?)\]]+$/, ""), format: "Bare URL" };
          }
          return { label: line, url: "", format: "No URL found" };
        }

        var TYPE_ORDER = [
          "malformed", "no-url", "credentials", "mismatch",
          "http", "tracking", "duplicate", "label-clash",
          "shortener", "long"
        ];
        var TYPE_NAMES = {
          "malformed": "Malformed URL",
          "no-url": "No URL found",
          "credentials": "Embedded credentials",
          "mismatch": "Label names a different domain",
          "http": "http:// instead of https://",
          "tracking": "Tracking parameters",
          "duplicate": "Duplicate destination",
          "label-clash": "Same label, different destination",
          "shortener": "URL shortener",
          "long": "Excessively long URL"
        };
        var BLOCKERS = { "malformed": 1, "no-url": 1, "credentials": 1, "mismatch": 1 };

        function findLabelDomains(label) {
          var found = [];
          var re = /\b(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+(?:com|net|org|io|co|gov|edu|info|biz|me|tv|app|dev|shop|store|us|uk|ca|au|de|jp|fr|es|it|nl|ai|gg|ly)\b/gi;
          var m;
          while ((m = re.exec(label)) !== null) found.push(m[0].toLowerCase());
          // Label that is itself a URL
          var um = label.match(/https?:\/\/([^\s/]+)/i);
          if (um) found.push(um[1].toLowerCase());
          return found;
        }

        function audit(text) {
          var rawLines = text.split(/\r?\n/);
          var entries = [];
          rawLines.forEach(function (raw, i) {
            if (!raw.trim()) return;
            var parsed = parseLine(raw);
            if (!parsed) return;
            entries.push({
              lineNo: i + 1,
              raw: raw,
              label: parsed.label || "",
              url: parsed.url || "",
              format: parsed.format,
              findings: [],
              parsedUrl: null,
              cleanedUrl: "",
              destKey: "",
              trackingParams: []
            });
          });

          entries.forEach(function (e) {
            if (!e.url) {
              e.findings.push({ type: "no-url", detail: "This line contains no URL to check." });
              return;
            }
            var u = null;
            try { u = new URL(e.url); } catch (err) { u = null; }
            if (!u || !u.hostname) {
              var why;
              if (!/^[a-z][a-z0-9+.-]*:/i.test(e.url)) {
                why = "No scheme (https://) in front of the address, so browsers will not treat it as a link.";
              } else if (/\s/.test(e.url)) {
                why = "The URL contains spaces.";
              } else {
                why = "The address cannot be parsed as a URL as written.";
              }
              e.findings.push({ type: "malformed", detail: why });
              return;
            }
            e.parsedUrl = u;

            if (u.username || u.password) {
              e.findings.push({
                type: "credentials",
                detail: "The URL embeds credentials (\"" + decodeURIComponent(u.username || "user") + "…@\") before the host. Anyone who gets the list gets the login — and browsers often strip or block such links."
              });
            }

            if (u.protocol === "http:") {
              e.findings.push({ type: "http", detail: "Uses http:// — unencrypted. If the site supports https:// (most do), publish the https:// version." });
            }

            // Tracking parameters
            var names = [];
            u.searchParams.forEach(function (v, k) { if (isTrackingParam(k)) names.push(k); });
            e.trackingParams = names;
            if (names.length) {
              e.findings.push({
                type: "tracking",
                detail: "Tracking parameters present: " + names.join(", ") + ". They are stripped in the cleaned list."
              });
            }

            // Cleaned URL + destination key
            var c = new URL(u.href);
            e.trackingParams.forEach(function (k) { c.searchParams.delete(k); });
            e.cleanedUrl = c.href;
            e.destKey = c.href.replace(/\/$/, "");

            // Shortener
            if (SHORTENERS[u.hostname.toLowerCase()]) {
              e.findings.push({
                type: "shortener",
                detail: u.hostname + " is a URL shortener — readers cannot see where this link really goes, and neither can this audit."
              });
            }

            // Long URL
            if (e.url.length > LONG_URL_LIMIT) {
              e.findings.push({
                type: "long",
                detail: "This URL is " + e.url.length.toLocaleString() + " characters long (limit used here: " + LONG_URL_LIMIT.toLocaleString() + "). URLs this long break in some email clients and chat apps."
              });
            }

            // Label/domain mismatch
            if (e.label) {
              var labelDomains = findLabelDomains(e.label);
              var destReg = regDomain(u.hostname);
              for (var j = 0; j < labelDomains.length; j++) {
                var ld = labelDomains[j].replace(/^www\./, "");
                if (regDomain(ld) !== destReg) {
                  e.findings.push({
                    type: "mismatch",
                    detail: "The label names \"" + ld + "\" but the link actually goes to \"" + u.hostname + "\". Readers will expect one site and land on another."
                  });
                  break;
                }
              }
            }
          });

          // Duplicate destinations (compare cleaned URLs)
          var byDest = {};
          entries.forEach(function (e) {
            if (!e.destKey) return;
            (byDest[e.destKey] = byDest[e.destKey] || []).push(e);
          });
          Object.keys(byDest).forEach(function (key) {
            var group = byDest[key];
            if (group.length < 2) return;
            var first = group[0];
            group.forEach(function (e, idx) {
              if (idx === 0) return;
              var diffLabel = e.label && first.label && e.label.toLowerCase() !== first.label.toLowerCase();
              e.findings.push({
                type: "duplicate",
                detail: "Same destination as line " + first.lineNo +
                  (diffLabel ? " — but under a different label (\"" + first.label + "\" vs. \"" + e.label + "\")" : "") +
                  ". Marked as a duplicate in the cleaned list, not deleted."
              });
              e.duplicateOf = first.lineNo;
            });
          });

          // Same label, different destinations
          var byLabel = {};
          entries.forEach(function (e) {
            if (!e.label || !e.destKey) return;
            var key = e.label.trim().toLowerCase();
            (byLabel[key] = byLabel[key] || []).push(e);
          });
          Object.keys(byLabel).forEach(function (key) {
            var group = byLabel[key];
            var dests = {};
            group.forEach(function (e) { dests[e.destKey] = 1; });
            if (Object.keys(dests).length < 2) return;
            var others = group.map(function (e) { return "line " + e.lineNo; }).join(", ");
            group.forEach(function (e) {
              e.findings.push({
                type: "label-clash",
                detail: "The label \"" + e.label + "\" is used for more than one destination (" + others + "). A reader cannot tell which one a given entry means."
              });
            });
          });

          return entries;
        }

        function buildCleaned(entries) {
          return entries.map(function (e) {
            if (!e.url || !e.parsedUrl) {
              return e.raw.trim() + "   [COULD NOT BE CHECKED — left exactly as pasted]";
            }
            var label = e.label || "(no label)";
            var out = label + " | " + e.cleanedUrl;
            if (e.duplicateOf) out += "   [DUPLICATE — same destination as line " + e.duplicateOf + "; kept, not deleted]";
            return out;
          }).join("\n");
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-link-list-pre-flight-auditor',
  name: 'J-Dawgs Link List Pre-Flight Auditor',
  description: 'Audits a pasted link list before publishing — malformed URLs, plain-http links, tracking parameters, duplicates, and label/host mismatches — with a publish verdict and fix list. It never fetches any URL',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
