'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Unbound DNS Resolver Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ================= Rule tables ================= */

      var KNOWN_CLAUSES = { "server": 1, "remote-control": 1, "forward-zone": 1, "stub-zone": 1 };

      function setFrom(str) {
        var o = {}, parts = str.split(/\s+/), i;
        for (i = 0; i < parts.length; i++) { if (parts[i]) o[parts[i]] = 1; }
        return o;
      }

      /* Directives this auditor recognises. Anything else in a known clause
         is reported NOT AUDITED by name. */
      var KNOWN = setFrom(
        "include verbosity num-threads interface interface-automatic port tls-port https-port " +
        "do-ip4 do-ip6 do-udp do-tcp do-daemonize so-reuseport so-rcvbuf so-sndbuf ip-transparent ip-dscp ip-freebind " +
        "chroot username directory logfile pidfile use-syslog log-time-ascii log-queries log-replies log-tag-queryreply " +
        "log-local-actions log-servfail val-log-level hide-identity hide-version hide-trustanchor identity version " +
        "domain-insecure qname-minimisation qname-minimisation-strict minimal-responses rrset-roundrobin aggressive-nsec " +
        "harden-short-bufsize harden-large-queries harden-glue harden-dnssec-stripped harden-below-nxdomain " +
        "harden-referral-path harden-algo-downgrade harden-unknown-additional use-caps-for-id caps-exempt " +
        "prefetch prefetch-key cache-max-ttl cache-min-ttl cache-max-negative-ttl serve-expired serve-expired-ttl " +
        "serve-expired-ttl-reset serve-expired-reply-ttl serve-original-ttl msg-cache-size rrset-cache-size " +
        "key-prime-cache-size neg-cache-size infra-host-ttl infra-cache-numhosts infra-cache-min-rtt infra-cache-max-rtt " +
        "infra-keep-probing unwanted-reply-threshold jostle-timeout delay-close access-control access-control-tag " +
        "access-control-tag-action access-control-tag-data access-control-view private-address private-domain " +
        "local-zone local-data local-data-ptr local-zone-tag local-zone-override define-tag deny-any " +
        "tls-service-key tls-service-pem tls-service-ocsp tls-session-ticket-keys tls-additional-port tls-cert-bundle " +
        "tls-win-cert tls-ciphers tls-ciphersuites tls-prefer-server-ciphers proxy-ips http-nodelay http-max-streams " +
        "http-query-buffer-size http-response-buffer-size edns-buffer-size max-udp-size stream-wait-size " +
        "extended-statistics statistics-interval statistics-cumulative root-hints trust-anchor-file trust-anchor " +
        "trusted-keys-file auto-trust-anchor-file dlv-anchor dlv-anchor-file permit-small-holddown add-holddown " +
        "del-holddown keep-missing val-bogus-overwrite val-permissive-mode val-clean-additional val-max-restart " +
        "target-fetch-policy max-sent-count max-query-restarts root-key-sentinel logtrustquery trust-anchor-signaling " +
        "ratelimit ratelimit-size ratelimit-for-domain ratelimit-below-domain ratelimit-backoff ratelimit-factor " +
        "ip-ratelimit ip-ratelimit-size ip-ratelimit-backoff ip-ratelimit-factor outgoing-range outgoing-port-permit " +
        "outgoing-port-avoid outgoing-num-tcp incoming-num-tcp msg-buffer-size module-config dns64-prefix dns64-synthall " +
        "nat64-prefix nat64-synthall dnstap-identity dnstap-version dnstap-socket-path send-dnstap tls-use-sni ede " +
        "ede-serve-expired name forward-addr forward-host forward-first forward-tls-upstream forward-ssl-upstream " +
        "forward-no-cache stub-addr stub-host stub-first stub-prime stub-tls-upstream stub-ssl-upstream " +
        "control-enable control-interface control-port control-use-cert control-key-file control-cert-file " +
        "server-key-file server-cert-file"
      );

      /* Directives Unbound treats as single-value: a repeat overrides, it
         does not add. Multi-value directives (interface, access-control,
         private-address, forward-addr, ...) are deliberately absent. */
      var SINGLE_VALUE = setFrom(
        "verbosity num-threads port tls-port https-port qname-minimisation qname-minimisation-strict " +
        "hide-identity hide-version hide-trustanchor identity version do-ip4 do-ip6 do-udp do-tcp do-daemonize " +
        "chroot directory username pidfile logfile use-syslog log-time-ascii log-queries log-replies log-servfail " +
        "tls-cert-bundle edns-buffer-size cache-max-ttl cache-min-ttl cache-max-negative-ttl prefetch " +
        "minimal-responses rrset-roundrobin module-config interface-automatic " +
        "control-enable control-port control-use-cert " +
        "forward-tls-upstream forward-ssl-upstream forward-first forward-no-cache name " +
        "stub-tls-upstream stub-ssl-upstream stub-first stub-prime"
      );

      /* Secret-bearing directives: flagged by NAME and line only. The value
         is never copied into any finding, report, or output. */
      var SECRET_RE = /(key|cert|pem|secret|passwd|password|token)/i;
      var SECRET_EXEMPT = { "control-use-cert": 1 }; /* a yes/no switch, not a secret */

      var AC_ACTIONS = setFrom("deny refuse drop allow allow_setrd allow_snoop static redirect inform inform_redirect always_refuse always_nxdomain always_deny always_transparent");
      var OPEN_ACTIONS = setFrom("allow allow_snoop allow_setrd");
      var STD_PRIVATE = ["10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "169.254.0.0/16", "fd00::/8", "fe80::/10", "::1/128"];

      /* ================= Small helpers ================= */

      function stripComment(line) {
        var inQ = false, i, c;
        for (i = 0; i < line.length; i++) {
          c = line.charAt(i);
          if (c === '"') { inQ = !inQ; }
          else if (c === "#" && !inQ) { return line.slice(0, i); }
        }
        return line;
      }
      function unquote(v) {
        v = v.replace(/^\s+|\s+$/g, "");
        if (v.length >= 2 && v.charAt(0) === '"' && v.charAt(v.length - 1) === '"') { return v.slice(1, -1); }
        return v;
      }
      function isYes(v) { return String(v).toLowerCase() === "yes"; }
      function isLoopback(v) {
        v = String(v).split("@")[0].replace(/^\[|\]$/g, "").toLowerCase();
        return v === "127.0.0.1" || v === "::1" || v === "localhost" || v.indexOf("127.") === 0;
      }
      function isAllInterfaces(v) {
        var base = String(v).split("@")[0].replace(/^\[|\]$/g, "");
        return base === "0.0.0.0" || base === "::0" || base === "::";
      }
      function isPublicAll(net) {
        return net === "0.0.0.0/0" || net === "::0/0" || net === "::/0";
      }

      function ipToBytes(ip) {
        var p, i, v, halves, head, tail, groups, full, bytes, g, li, vb;
        ip = String(ip).replace(/^\s+|\s+$/g, "");
        if (ip.indexOf(":") < 0) {
          p = ip.split(".");
          if (p.length !== 4) { return null; }
          bytes = [];
          for (i = 0; i < 4; i++) {
            v = parseInt(p[i], 10);
            if (isNaN(v) || v < 0 || v > 255) { return null; }
            bytes.push(v);
          }
          return bytes;
        }
        vb = null;
        if (ip.indexOf(".") >= 0) {
          li = ip.lastIndexOf(":");
          vb = ipToBytes(ip.slice(li + 1));
          if (!vb) { return null; }
          ip = ip.slice(0, li + 1) + "0:0";
        }
        halves = ip.split("::");
        if (halves.length > 2) { return null; }
        head = halves[0] ? halves[0].split(":") : [];
        tail = (halves.length === 2 && halves[1]) ? halves[1].split(":") : [];
        groups = head.concat(tail);
        if (halves.length === 2) {
          full = head.slice();
          for (i = 0; i < 8 - groups.length; i++) { full.push("0"); }
          full = full.concat(tail);
        } else {
          full = head;
        }
        if (full.length !== 8) { return null; }
        bytes = [];
        for (i = 0; i < 8; i++) {
          g = parseInt(full[i], 16);
          if (isNaN(g) || g < 0 || g > 65535) { return null; }
          bytes.push(g >> 8, g & 255);
        }
        if (vb) { bytes[12] = vb[0]; bytes[13] = vb[1]; bytes[14] = vb[2]; bytes[15] = vb[3]; }
        return bytes;
      }
      function parseCidr(s) {
        var parts = String(s).split("/"), bytes = ipToBytes(parts[0]), bits;
        if (!bytes) { return null; }
        bits = parts.length > 1 ? parseInt(parts[1], 10) : bytes.length * 8;
        if (isNaN(bits) || bits < 0 || bits > bytes.length * 8) { return null; }
        return { bytes: bytes, bits: bits };
      }
      function cidrContains(outer, inner) {
        var full, rem, i, mask;
        if (!outer || !inner || outer.bytes.length !== inner.bytes.length) { return false; }
        if (outer.bits > inner.bits) { return false; }
        full = Math.floor(outer.bits / 8);
        rem = outer.bits % 8;
        for (i = 0; i < full; i++) { if (outer.bytes[i] !== inner.bytes[i]) { return false; } }
        if (rem) {
          mask = (0xFF << (8 - rem)) & 0xFF;
          if ((outer.bytes[full] & mask) !== (inner.bytes[full] & mask)) { return false; }
        }
        return true;
      }

      /* ================= The audit ================= */

      function auditConfig(text) {
        var findings = [];
        function add(sev, line, msg) { findings.push({ sev: sev, line: line, text: msg }); }

        var clean = String(text).replace(/\r\n?/g, "\n").replace(/\s+$/, "");
        var rawLines = clean === "" ? [] : clean.split("\n");
        var entries = [];
        var clause = null, block = -1, i, n, raw, stripped, m;
        var unknownClauses = [];

        for (i = 0; i < rawLines.length; i++) {
          n = i + 1;
          raw = rawLines[i];
          stripped = stripComment(raw);
          if (!stripped.replace(/\s/g, "")) { continue; }
          if (!/^\s/.test(stripped)) {
            m = stripped.match(/^([A-Za-z][A-Za-z0-9_-]*)\s*:\s*$/);
            if (m) {
              clause = m[1].toLowerCase();
              block++;
              if (!KNOWN_CLAUSES[clause]) { unknownClauses.push({ name: clause, line: n, block: block }); }
              continue;
            }
          }
          m = stripped.match(/^\s*([A-Za-z][A-Za-z0-9_-]*)\s*:\s*(.*)$/);
          if (m) {
            entries.push({ line: n, clause: clause, block: block, name: m[1].toLowerCase(), value: unquote(m[2]) });
            continue;
          }
          add("INFO", n, "Line " + n + " could not be parsed as a clause header or a directive — NOT AUDITED.");
        }

        function inKnown(e) { return e.clause !== null && !!KNOWN_CLAUSES[e.clause]; }
        function of(clauseName, dirName) {
          return entries.filter(function (e) { return e.clause === clauseName && e.name === dirName; });
        }
        function lastOf(clauseName, dirName) {
          var list = of(clauseName, dirName);
          return list.length ? list[list.length - 1] : null;
        }

        /* Unknown clauses: contents not graded */
        for (i = 0; i < unknownClauses.length; i++) {
          add("INFO", unknownClauses[i].line, "Line " + unknownClauses[i].line + " — clause \"" + unknownClauses[i].name +
            ":\" is not a server:, remote-control:, forward-zone:, or stub-zone: clause — its contents are NOT AUDITED.");
        }

        /* include: lines — contents are not in the paste */
        entries.forEach(function (e) {
          if (e.name === "include") {
            add("INFO", e.line, "Line " + e.line + " — include: \"" + e.value + "\" pulls in another file. Its contents are NOT CHECKED — they are not in the paste, so nothing in that file is graded.");
          }
        });

        /* Directives outside any known clause */
        entries.forEach(function (e) {
          if (e.name === "include") { return; }
          if (e.clause === null) {
            add("WARNING", e.line, "Line " + e.line + " — directive \"" + e.name + "\" appears outside any server:, remote-control:, forward-zone:, or stub-zone: clause. Unbound may reject the file or ignore the line — it is not graded as part of a clause.");
          } else if (!KNOWN_CLAUSES[e.clause]) {
            /* covered by the unknown-clause note */
          }
        });

        /* Unknown directives in known clauses: NOT AUDITED by name */
        entries.forEach(function (e) {
          if (!inKnown(e) || e.name === "include") { return; }
          if (!KNOWN[e.name]) {
            add("INFO", e.line, "Line " + e.line + " — directive \"" + e.name + "\" is not in this auditor's rule set — NOT AUDITED. (It may be valid for your Unbound version; this tool simply has no check for it.)");
          }
        });

        /* Secret-bearing directives: name + line only, value never shown */
        entries.forEach(function (e) {
          if (!inKnown(e)) { return; }
          if (SECRET_RE.test(e.name) && !SECRET_EXEMPT[e.name]) {
            add("INFO", e.line, "Line " + e.line + " — \"" + e.name + "\" is a key/certificate-related directive. Flagged by directive name and line only — its value is never shown in any finding or report.");
          }
        });

        /* Duplicate single-value directives: last in file wins, both lines named */
        (function () {
          var groups = {}, order = [];
          entries.forEach(function (e) {
            if (!inKnown(e) || !SINGLE_VALUE[e.name]) { return; }
            var scope = (e.clause === "forward-zone" || e.clause === "stub-zone") ? e.clause + "#" + e.block : e.clause;
            var key = scope + "|" + e.name;
            if (!groups[key]) { groups[key] = []; order.push(key); }
            groups[key].push(e);
          });
          order.forEach(function (key) {
            var g = groups[key];
            if (g.length > 1) {
              var last = g[g.length - 1];
              var lines = g.map(function (e) { return "line " + e.line; }).join(" and ");
              add("WARNING", last.line, "Duplicate single-value directive \"" + g[0].name + "\" at " + lines +
                " — Unbound resolves this last-in-file, so the value on line " + last.line + " is the one in force and the earlier one is ignored. All checks below use line " + last.line + ".");
            }
          });
        })();

        /* ---------- access-control ---------- */
        var acEntries = of("server", "access-control");
        var openResolver = false, openLine = null;
        acEntries.forEach(function (e) {
          var tokens = e.value.split(/\s+/).filter(Boolean);
          var net = tokens[0] || "";
          var action = "";
          for (var k = 1; k < tokens.length; k++) { if (AC_ACTIONS[tokens[k]]) { action = tokens[k]; break; } }
          if (!action && tokens.length > 1) { action = tokens[1]; }
          if (isPublicAll(net) && OPEN_ACTIONS[action]) {
            openResolver = true;
            openLine = e.line;
            add("BLOCKER", e.line, "Line " + e.line + " — access-control grants " + net + " (the whole Internet) the action \"" + action +
              "\" — anyone anywhere can use this host as a resolver. This is an OPEN RESOLVER: it will be found, abused for DNS amplification attacks, and likely get the host blocklisted. Restrict the netblock to your own networks or change the action to refuse.");
          }
          add("INFO", e.line, "Line " + e.line + " — access-control inventoried: " + net + (action ? " " + action : " (no recognised action)") + ".");
        });
        if (!acEntries.length) {
          add("INFO", null, "No access-control directives in the paste — who may query this resolver is decided by Unbound defaults or by included files (NOT CHECKED).");
        }

        /* ---------- interface ---------- */
        var ifEntries = of("server", "interface");
        if (ifEntries.length) {
          var ifSummary = ifEntries.map(function (e) { return "line " + e.line + ": " + e.value; }).join("; ");
          add("INFO", null, "Listening interfaces inventoried — " + ifSummary + ".");
          ifEntries.forEach(function (e) {
            if (isAllInterfaces(e.value)) {
              if (openResolver) {
                add("BLOCKER", e.line, "Line " + e.line + " — interface: " + e.value.split("@")[0] + " listens on ALL interfaces, and the permissive access-control on line " + openLine +
                  " lets the whole Internet use it. The combination is an Internet-facing open resolver — bind the resolver to loopback/LAN addresses, or lock access-control down.");
              } else {
                add("WARNING", e.line, "Line " + e.line + " — interface: " + e.value.split("@")[0] + " listens on ALL interfaces. That is safe only if access-control refuses everyone you do not serve — check the access-control lines before deploying.");
              }
            }
          });
        } else {
          add("INFO", null, "No interface: directives in the paste — listening addresses come from Unbound defaults or included files (NOT CHECKED).");
        }

        /* ---------- Rebinding protection ---------- */
        var paEntries = of("server", "private-address");
        if (!paEntries.length) {
          add("WARNING", null, "No private-address directives at all — DNS REBINDING EXPOSURE: answers from public names can point at private/LAN addresses, letting a web page or attacker reach inside your network through this resolver. Add private-address lines for the standard private ranges.");
        } else {
          var presentCidrs = [];
          paEntries.forEach(function (e) { var c = parseCidr(e.value); if (c) { presentCidrs.push(c); } });
          var missing = STD_PRIVATE.filter(function (std) {
            var sc = parseCidr(std);
            return !presentCidrs.some(function (pc) { return cidrContains(pc, sc); });
          });
          var paLines = paEntries.map(function (e) { return e.line; }).join(", ");
          if (!missing.length) {
            add("GOOD", paEntries[0].line, "Rebinding protection on — private-address (lines " + paLines + ") covers the standard private ranges (" + STD_PRIVATE.join(", ") + "), so public answers cannot point back into private address space.");
          } else {
            add("WARNING", paEntries[0].line, "private-address is present (lines " + paLines + ") but does NOT cover these standard private ranges: " + missing.join(", ") + " — rebinding protection is partial. Add private-address lines for the missing ranges.");
          }
        }
        of("server", "private-domain").forEach(function (e) {
          add("INFO", e.line, "Line " + e.line + " — private-domain inventoried: \"" + e.value + "\" (names under it may legitimately resolve to private addresses).");
        });

        /* ---------- Privacy ---------- */
        var qm = lastOf("server", "qname-minimisation");
        if (qm && isYes(qm.value)) {
          add("GOOD", qm.line, "Line " + qm.line + " — qname-minimisation: yes. Upstream servers only learn the part of each name they need — good privacy posture.");
        } else if (qm) {
          add("WARNING", qm.line, "Line " + qm.line + " — qname-minimisation is set to \"" + qm.value + "\", not yes. Upstreams see full query names. Set qname-minimisation: yes.");
        } else {
          add("WARNING", null, "qname-minimisation is not set — whether full query names leak to upstreams depends on build defaults. Set qname-minimisation: yes to be sure.");
        }
        [["hide-identity", "identity"], ["hide-version", "version"]].forEach(function (pair) {
          var e = lastOf("server", pair[0]);
          if (e && isYes(e.value)) {
            add("GOOD", e.line, "Line " + e.line + " — " + pair[0] + ": yes. The resolver does not volunteer its " + pair[1] + " to strangers.");
          } else if (e) {
            add("WARNING", e.line, "Line " + e.line + " — " + pair[0] + " is set to \"" + e.value + "\", not yes — the resolver discloses its " + pair[1] + " to anyone who asks. Set " + pair[0] + ": yes.");
          } else {
            add("WARNING", null, pair[0] + " is not set — the resolver will answer " + pair[1] + " queries from strangers (version disclosure). Set " + pair[0] + ": yes.");
          }
        });
        var ht = lastOf("server", "hide-trustanchor");
        if (ht) {
          add("INFO", ht.line, "Line " + ht.line + " — hide-trustanchor: " + ht.value + " — noted.");
        } else {
          add("INFO", null, "hide-trustanchor is not set — noted (minor: trust-anchor queries can reveal which DNSSEC roots this resolver validates).");
        }

        /* ---------- TLS upstream posture + zones ---------- */
        of("server", "domain-insecure").forEach(function (e) {
          add("INFO", e.line, "Line " + e.line + " — domain-insecure inventoried: \"" + e.value + "\" (DNSSEC validation is skipped for this domain — a deliberate posture choice, noted, not graded).");
        });

        var zoneTlsCount = 0;
        ["forward-zone", "stub-zone"].forEach(function (zc) {
          var blocks = {};
          entries.forEach(function (e) { if (e.clause === zc) { (blocks[e.block] = blocks[e.block] || []).push(e); } });
          Object.keys(blocks).forEach(function (b) {
            var list = blocks[b];
            var nameE = null, addrName = zc === "forward-zone" ? "forward-addr" : "stub-addr";
            var addrs = [], tlsE = null, firstLine = list[0].line, lastLine = list[list.length - 1].line;
            list.forEach(function (e) {
              if (e.name === "name") { nameE = e; }
              if (e.name === addrName) { addrs.push(e); }
              if (e.name === "forward-tls-upstream" || e.name === "stub-tls-upstream" || e.name === "forward-ssl-upstream" || e.name === "stub-ssl-upstream") { tlsE = e; }
            });
            var zname = nameE ? nameE.value : "(no name: directive)";
            var tlsDeclared = tlsE && isYes(tlsE.value);
            if (tlsDeclared) { zoneTlsCount++; }
            add("INFO", firstLine, zc + " \"" + zname + "\" inventoried (lines " + firstLine + "–" + lastLine + "): " + addrs.length + " " + addrName +
              " entr" + (addrs.length === 1 ? "y" : "ies") + ", TLS upstream " + (tlsE ? (tlsDeclared ? "declared (line " + tlsE.line + ")" : "set to \"" + tlsE.value + "\" (line " + tlsE.line + ")") : "not declared") + ".");
            if (zc === "forward-zone" && zname === "." && addrs.length === 1 && !tlsDeclared) {
              var a = addrs[0], portM = a.value.match(/@(\d+)/);
              if (!portM || portM[1] !== "853") {
                add("WARNING", a.line, "Line " + a.line + " — forward-zone \".\" sends ALL queries to a single plaintext upstream (" + a.value + "). One provider sees every lookup and the traffic is unencrypted. Add forward-tls-upstream: yes with port 853, and/or a second upstream.");
              }
            }
          });
        });
        if (zoneTlsCount > 0) {
          add("INFO", null, "Upstream TLS posture: NOT SETTLED. The file declares TLS upstream for " + zoneTlsCount + " zone(s), but a pasted file cannot prove the upstream servers actually answer over TLS, or that the path is uncompromised — verify live before relying on it.");
        } else {
          add("INFO", null, "Upstream TLS posture: NOT SETTLED. Nothing in the paste declares encrypted (TLS) upstream transport, and a pasted file alone cannot prove what upstreams do — if this resolver recurses from the root, that traffic is plaintext by design.");
        }

        /* ---------- DoT / DoH listeners ---------- */
        of("server", "tls-port").forEach(function (e) {
          add("INFO", e.line, "Line " + e.line + " — tls-port: " + e.value + " — DNS-over-TLS (DoT) listener configured; inventoried.");
        });
        of("server", "https-port").forEach(function (e) {
          add("INFO", e.line, "Line " + e.line + " — https-port: " + e.value + " — DNS-over-HTTPS (DoH) listener configured; inventoried.");
        });

        /* ---------- remote-control ---------- */
        var hasRcClause = entries.some(function (e) { return e.clause === "remote-control"; }) ||
          rawLines.some(function (l) { return /^remote-control\s*:/.test(l); });
        if (!hasRcClause) {
          add("INFO", null, "No remote-control: clause in the paste — the Unbound control channel is not configured in this file.");
        } else {
          var ce = lastOf("remote-control", "control-enable");
          if (!ce) {
            add("GOOD", null, "remote-control: clause present but control-enable is not set — the control channel defaults to off.");
          } else if (!isYes(ce.value)) {
            add("GOOD", ce.line, "Line " + ce.line + " — control-enable is not yes (\"" + ce.value + "\") — the remote-control channel is off in this file.");
          } else {
            var ciEntries = of("remote-control", "control-interface");
            var cuc = lastOf("remote-control", "control-use-cert");
            var certOn = cuc && isYes(cuc.value);
            if (!ciEntries.length) {
              add("INFO", ce.line, "Line " + ce.line + " — control-enable: yes with no explicit control-interface — Unbound binds the control channel to localhost by default. posture noted; set control-interface explicitly so the file says what it does.");
            }
            ciEntries.forEach(function (e) {
              if (!isLoopback(e.value)) {
                add("BLOCKER", e.line, "Line " + e.line + " — control-enable: yes (line " + ce.line + ") with control-interface on a NON-LOOPBACK address (" + e.value.split("@")[0] +
                  "). The control channel can start/stop and reconfigure the resolver; exposed off-box it is a remote-administration hole. Bind it to 127.0.0.1 / ::1" + (certOn ? " (certificate auth is on, which limits but does not remove the exposure)" : "") + ".");
              } else if (certOn) {
                add("GOOD", e.line, "Line " + e.line + " — remote control is enabled on loopback (" + e.value.split("@")[0] + ") with control-use-cert: yes (line " + cuc.line + ") — certificate-authenticated and local-only.");
              } else {
                add("WARNING", e.line, "Line " + e.line + " — control-enable: yes with control-interface on loopback (" + e.value.split("@")[0] + "), but control-use-cert is not yes — any local process could connect to the control channel without a client certificate. Set control-use-cert: yes.");
              }
            });
          }
        }

        /* ---------- Verdict ---------- */
        var counts = { BLOCKER: 0, WARNING: 0, INFO: 0, GOOD: 0 };
        findings.forEach(function (f) { counts[f.sev]++; });
        var verdict, verdictClass;
        if (counts.BLOCKER > 0) {
          verdict = openResolver ? "DO NOT DEPLOY — OPEN RESOLVER RISK" : "DO NOT DEPLOY";
          verdictClass = "no";
        } else if (counts.WARNING > 0) {
          verdict = "DEPLOY WITH FIXES";
          verdictClass = "fixes";
        } else {
          verdict = "SAFE TO DEPLOY";
          verdictClass = "safe";
        }
        var rank = { BLOCKER: 0, WARNING: 1, INFO: 2, GOOD: 3 };
        findings.sort(function (a, b) {
          if (rank[a.sev] !== rank[b.sev]) { return rank[a.sev] - rank[b.sev]; }
          var la = a.line === null ? 99999 : a.line, lb = b.line === null ? 99999 : b.line;
          return la - lb;
        });
        return {
          verdict: verdict, verdictClass: verdictClass, openResolver: openResolver,
          counts: counts, findings: findings,
          totalLines: rawLines.length,
          directiveCount: entries.length
        };
      }

      /* ================= Preloaded examples ================= */

      var RISKY_EXAMPLE = [
        "# Risky example — a resolver opened to the whole Internet",
        "server:",
        "    verbosity: 1",
        "    interface: 0.0.0.0",
        "    port: 53",
        "    do-ip4: yes",
        "    do-udp: yes",
        "    do-tcp: yes",
        "    access-control: 0.0.0.0/0 allow",
        "    qname-minimisation: no",
        "    hide-identity: no"
      ].join("\n");

      var HARDENED_EXAMPLE = [
        "# Hardened example — LAN-only resolver with rebinding + privacy protections",
        "server:",
        "    verbosity: 1",
        "    interface: 127.0.0.1",
        "    interface: 192.168.1.53",
        "    port: 53",
        "    do-ip4: yes",
        "    do-udp: yes",
        "    do-tcp: yes",
        "    access-control: 127.0.0.0/8 allow",
        "    access-control: 192.168.1.0/24 allow",
        "    access-control: 0.0.0.0/0 refuse",
        "    private-address: 10.0.0.0/8",
        "    private-address: 172.16.0.0/12",
        "    private-address: 192.168.0.0/16",
        "    private-address: 169.254.0.0/16",
        "    private-address: fd00::/8",
        "    private-address: fe80::/10",
        "    private-address: ::1/128",
        "    private-domain: \"home.arpa\"",
        "    qname-minimisation: yes",
        "    hide-identity: yes",
        "    hide-version: yes",
        "    hide-trustanchor: yes",
        "    tls-cert-bundle: \"/etc/ssl/certs/ca-certificates.crt\"",
        "",
        "forward-zone:",
        "    name: \".\"",
        "    forward-tls-upstream: yes",
        "    forward-addr: 1.1.1.1@853",
        "    forward-addr: 9.9.9.9@853",
        "",
        "remote-control:",
        "    control-enable: no"
      ].join("\n");

      var WORKED_EXAMPLE = [
        "server:",
        "    interface: 0.0.0.0",
        "    access-control: 0.0.0.0/0 allow"
      ].join("\n");
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined), "WORKED_EXAMPLE": (typeof WORKED_EXAMPLE !== 'undefined' ? WORKED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-unbound-dns-resolver-config-safety-auditortm',
  name: 'J-Dawgs Unbound DNS Resolver Config Safety Auditor',
  description: 'Grades a pasted unbound.conf offline: open-resolver access-control, rebinding/private-address protection, qname minimisation and version disclosure, into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"], "WORKED_EXAMPLE": __core["WORKED_EXAMPLE"] }
};
