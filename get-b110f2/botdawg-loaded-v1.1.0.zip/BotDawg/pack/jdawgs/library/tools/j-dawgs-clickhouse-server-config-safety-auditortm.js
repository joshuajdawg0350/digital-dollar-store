'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs ClickHouse Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

  "use strict";

  var RISKY = [
    '<?xml version="1.0"?>',
    '<clickhouse>',
    '    <listen_host>0.0.0.0</listen_host>',
    '    <http_port>8123</http_port>',
    '    <tcp_port>9000</tcp_port>',
    '    <interserver_http_port>9009</interserver_http_port>',
    '    <users>',
    '        <default>',
    '            <password></password>',
    '            <profile>default</profile>',
    '            <quota>default</quota>',
    '            <access_management>1</access_management>',
    '        </default>',
    '    </users>',
    '    <profiles>',
    '        <default></default>',
    '    </profiles>',
    '    <quotas>',
    '        <default></default>',
    '    </quotas>',
    '</clickhouse>'
  ].join('\n');

  var HARDENED = [
    '<?xml version="1.0"?>',
    '<clickhouse>',
    '    <listen_host>127.0.0.1</listen_host>',
    '    <http_port>8123</http_port>',
    '    <tcp_port>9000</tcp_port>',
    '    <interserver_http_port>9009</interserver_http_port>',
    '    <users>',
    '        <default>',
    '            <password_sha256_hex>e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855</password_sha256_hex>',
    '            <networks>',
    '                <ip>127.0.0.1</ip>',
    '                <ip>::1</ip>',
    '                <ip>10.0.0.0/8</ip>',
    '                <ip>192.168.0.0/16</ip>',
    '            </networks>',
    '            <profile>default</profile>',
    '            <quota>default</quota>',
    '        </default>',
    '        <reporting>',
    '            <password_sha256_hex>e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855</password_sha256_hex>',
    '            <networks>',
    '                <ip>127.0.0.1</ip>',
    '                <ip>172.16.0.0/12</ip>',
    '            </networks>',
    '            <profile>readonly</profile>',
    '            <quota>default</quota>',
    '        </reporting>',
    '    </users>',
    '    <profiles>',
    '        <default></default>',
    '        <readonly></readonly>',
    '    </profiles>',
    '    <quotas>',
    '        <default></default>',
    '    </quotas>',
    '</clickhouse>'
  ].join('\n');

  var HASH_TAGS = ['password_sha256_hex','password_sha256','password_double_sha1_hex','password_double_sha1'];
  var PASSWORD_TAGS = ['password','password_sha256_hex','password_sha256','password_double_sha1_hex','password_double_sha1','password_ldap'];
  var SINGLETONS = ['http_port','https_port','tcp_port','tcp_port_secure','interserver_http_port','interserver_https_port','mysql_port','postgresql_port','timezone','umask','max_connections','listen_backlog'];
  var PORT_TAGS = ['http_port','https_port','tcp_port','tcp_port_secure','interserver_http_port','interserver_https_port','mysql_port','postgresql_port','raft_port','keeper_server_port'];
  var WILDCARD_NETWORKS = ['::/0','0.0.0.0/0','::','0.0.0.0','*'];
  var WILDCARD_HOSTS = ['0.0.0.0','::','::0','*'];

  var input = document.getElementById('configInput');
  var findingsEl = document.getElementById('findings');
  var verdictEl = document.getElementById('verdictText');
  var statusEl = document.getElementById('statusLine');
  var lastReport = '';
  var lastFindings = [];

  function lineStarts(text){
    var starts = [0];
    for (var i = 0; i < text.length; i++){
      if (text.charAt(i) === '\n') starts.push(i + 1);
    }
    return starts;
  }
  function lineOf(starts, pos){
    var lo = 0, hi = starts.length - 1, ans = 0;
    while (lo <= hi){
      var mid = (lo + hi) >> 1;
      if (starts[mid] <= pos){ ans = mid; lo = mid + 1; } else { hi = mid - 1; }
    }
    return ans + 1;
  }
  function parseAttrs(tagInner){
    var attrs = {};
    var re = /([A-Za-z0-9_:\-\.]+)\s*=\s*"([^"]*)"|([A-Za-z0-9_:\-\.]+)\s*=\s*'([^']*)'/g;
    var m;
    while ((m = re.exec(tagInner)) !== null){
      if (m[1]) attrs[m[1]] = m[2]; else attrs[m[3]] = m[4];
    }
    return attrs;
  }

  function parseConfig(text){
    var starts = lineStarts(text);
    var root = { tag: '(root)', line: 1, children: [], text: '', attrs: {}, parent: null };
    var stack = [root];
    var errors = [];
    var pos = 0;
    var n = text.length;
    function top(){ return stack[stack.length - 1]; }
    while (pos < n){
      var lt = text.indexOf('<', pos);
      if (lt === -1){
        top().text += text.slice(pos);
        pos = n;
        break;
      }
      if (lt > pos) top().text += text.slice(pos, lt);
      if (text.slice(lt, lt + 4) === '<!--'){
        var cEnd = text.indexOf('-->', lt + 4);
        if (cEnd === -1){ errors.push({ line: lineOf(starts, lt), msg: 'Unterminated comment starting at line ' + lineOf(starts, lt) + '.' }); pos = n; break; }
        pos = cEnd + 3;
        continue;
      }
      if (text.slice(lt, lt + 9) === '<![CDATA['){
        var cdEnd = text.indexOf(']]>', lt + 9);
        if (cdEnd === -1){ errors.push({ line: lineOf(starts, lt), msg: 'Unterminated CDATA section starting at line ' + lineOf(starts, lt) + '.' }); pos = n; break; }
        top().text += text.slice(lt + 9, cdEnd);
        pos = cdEnd + 3;
        continue;
      }
      if (text.slice(lt, lt + 2) === '<?'){
        var piEnd = text.indexOf('?>', lt + 2);
        if (piEnd === -1){ errors.push({ line: lineOf(starts, lt), msg: 'Unterminated processing instruction at line ' + lineOf(starts, lt) + '.' }); pos = n; break; }
        pos = piEnd + 2;
        continue;
      }
      if (text.slice(lt, lt + 2) === '<!'){
        var dtEnd = text.indexOf('>', lt + 2);
        if (dtEnd === -1){ errors.push({ line: lineOf(starts, lt), msg: 'Unterminated declaration at line ' + lineOf(starts, lt) + '.' }); pos = n; break; }
        pos = dtEnd + 1;
        continue;
      }
      var gt = text.indexOf('>', lt + 1);
      if (gt === -1){
        errors.push({ line: lineOf(starts, lt), msg: 'Unterminated tag starting at line ' + lineOf(starts, lt) + '.' });
        pos = n;
        break;
      }
      var inner = text.slice(lt + 1, gt);
      var line = lineOf(starts, lt);
      if (inner.charAt(0) === '/'){
        var closeName = inner.slice(1).replace(/^\s+|\s+$/g, '').split(/\s+/)[0];
        if (top().tag === closeName){
          stack.pop();
        } else {
          var found = -1;
          for (var s = stack.length - 1; s >= 1; s--){
            if (stack[s].tag === closeName){ found = s; break; }
          }
          if (found === -1){
            errors.push({ line: line, msg: 'Closing tag </' + closeName + '> at line ' + line + ' has no matching opening tag.' });
          } else {
            errors.push({ line: line, msg: 'Tag <' + top().tag + '> opened at line ' + top().line + ' is closed out of order by </' + closeName + '> at line ' + line + '.' });
            stack.length = found;
          }
        }
        pos = gt + 1;
        continue;
      }
      var selfClose = /\/\s*$/.test(inner);
      if (selfClose) inner = inner.replace(/\/\s*$/, '');
      var nameMatch = /^([A-Za-z0-9_:\-\.]+)/.exec(inner.replace(/^\s+/, ''));
      if (!nameMatch){
        errors.push({ line: line, msg: 'Malformed tag at line ' + line + '.' });
        pos = gt + 1;
        continue;
      }
      var node = { tag: nameMatch[1], line: line, children: [], text: '', attrs: parseAttrs(inner), parent: top() };
      top().children.push(node);
      if (!selfClose) stack.push(node);
      pos = gt + 1;
    }
    for (var u = 1; u < stack.length; u++){
      errors.push({ line: stack[u].line, msg: 'Tag <' + stack[u].tag + '> opened at line ' + stack[u].line + ' is never closed.' });
    }
    return { root: root, errors: errors };
  }

  function descendants(node, tag, out){
    out = out || [];
    for (var i = 0; i < node.children.length; i++){
      var c = node.children[i];
      if (c.tag === tag) out.push(c);
      descendants(c, tag, out);
    }
    return out;
  }
  function allNodes(node, out){
    out = out || [];
    for (var i = 0; i < node.children.length; i++){
      out.push(node.children[i]);
      allNodes(node.children[i], out);
    }
    return out;
  }
  function firstChild(node, tag){
    for (var i = 0; i < node.children.length; i++){
      if (node.children[i].tag === tag) return node.children[i];
    }
    return null;
  }
  function childrenNamed(node, tag){
    var out = [];
    for (var i = 0; i < node.children.length; i++){
      if (node.children[i].tag === tag) out.push(node.children[i]);
    }
    return out;
  }
  function isInside(node, ancestor){
    var p = node.parent;
    while (p){ if (p === ancestor) return true; p = p.parent; }
    return false;
  }
  function trim(s){ return s.replace(/^\s+|\s+$/g, ''); }

  function addFinding(list, severity, lineLabel, lineNum, title, detail, fix){
    list.push({ severity: severity, lineLabel: lineLabel, lineNum: lineNum, title: title, detail: detail, fix: fix });
  }

  function audit(text){
    var findings = [];
    var parsed = parseConfig(text);
    var i, j;

    if (parsed.errors.length){
      for (i = 0; i < parsed.errors.length; i++){
        addFinding(findings, 'BLOCKER', 'Line ' + parsed.errors[i].line, parsed.errors[i].line,
          'NOT PARSED — the XML could not be settled',
          parsed.errors[i].msg + ' The audit does not guess at structure it cannot parse, so no further checks were run on this text.',
          'Fix the XML structure at the line named above, then paste and audit again.');
      }
      return { findings: findings, verdict: 'DO NOT DEPLOY', notParsed: true };
    }

    var root = parsed.root;

    /* ---- Collect users ---- */
    var usersContainers = descendants(root, 'users');
    var userRecs = [];
    var seenNodes = [];
    function pushUser(name, node){
      if (seenNodes.indexOf(node) !== -1) return;
      seenNodes.push(node);
      userRecs.push({ name: name, node: node, line: node.line });
    }
    for (i = 0; i < usersContainers.length; i++){
      var kids = usersContainers[i].children;
      for (j = 0; j < kids.length; j++){
        if (kids[j].tag === 'user'){
          pushUser(kids[j].attrs.name ? kids[j].attrs.name : '(unnamed user)', kids[j]);
        } else {
          pushUser(kids[j].tag, kids[j]);
        }
      }
    }
    var looseUsers = descendants(root, 'user');
    for (i = 0; i < looseUsers.length; i++){
      var inside = false;
      for (j = 0; j < usersContainers.length; j++){
        if (isInside(looseUsers[i], usersContainers[j])) inside = true;
      }
      if (!inside) pushUser(looseUsers[i].attrs.name ? looseUsers[i].attrs.name : '(unnamed user)', looseUsers[i]);
    }

    if (!usersContainers.length && !userRecs.length){
      addFinding(findings, 'INFO', 'Line 1', 1,
        'No users section found in the pasted text',
        'No <users> element and no user definitions were found, so the user checks had nothing to grade. A config.xml on its own is normal — paste the users.xml alongside it to grade the users too.',
        'If this server has users defined in a separate users.xml, paste that text in with the config and audit again.');
    }

    /* ---- Per-user password and network posture ---- */
    var defaultRec = null;
    var userStates = [];
    for (i = 0; i < userRecs.length; i++){
      var rec = userRecs[i];
      var node = rec.node;
      var state = { rec: rec, hasCredential: false, passwordless: true, restricted: false, networksState: 'absent', networksLine: null };
      var pwEls = [];
      for (j = 0; j < PASSWORD_TAGS.length; j++){
        var found = childrenNamed(node, PASSWORD_TAGS[j]);
        for (var k = 0; k < found.length; k++) pwEls.push(found[k]);
      }
      var plainEl = firstChild(node, 'password');
      if (plainEl){
        if (trim(plainEl.text).length){
          state.hasCredential = true; state.passwordless = false;
          addFinding(findings, 'WARNING', 'Line ' + plainEl.line, plainEl.line,
            'Plaintext password value present for user "' + rec.name + '"',
            'A value is set in the <password> element for user "' + rec.name + '" at line ' + plainEl.line + '. The value itself is never shown in this audit. A plaintext password in a config file is readable by anyone who can read the file.',
            'Replace the <password> element at line ' + plainEl.line + ' with <password_sha256_hex> holding the SHA-256 hash of the password, and restrict who can read the config file.');
        } else {
          addFinding(findings, rec.name === 'default' ? 'BLOCKER' : 'WARNING', 'Line ' + plainEl.line, plainEl.line,
            (rec.name === 'default' ? 'Default user' : 'User "' + rec.name + '"') + ' has an empty password',
            'The <password> element for user "' + rec.name + '" at line ' + plainEl.line + ' is present but empty, so this account can be used with no password at all.',
            'Set a real credential at line ' + plainEl.line + ': use <password_sha256_hex> with the SHA-256 hash of a strong password, or remove the user if it is not needed.');
        }
      }
      for (j = 0; j < HASH_TAGS.length; j++){
        var hashEls = childrenNamed(node, HASH_TAGS[j]);
        for (k = 0; k < hashEls.length; k++){
          if (trim(hashEls[k].text).length){
            state.hasCredential = true; state.passwordless = false;
            addFinding(findings, 'INFO', 'Line ' + hashEls[k].line, hashEls[k].line,
              'Hashed credential set for user "' + rec.name + '"',
              'The <' + HASH_TAGS[j] + '> element for user "' + rec.name + '" at line ' + hashEls[k].line + ' holds a value. It is noted as hashed, not graded as plaintext, and the value is never shown in this audit.',
              'No change needed for this element. Keep the config file itself readable only by the service account.');
          }
        }
      }
      var ldapEl = firstChild(node, 'password_ldap');
      if (ldapEl){ state.hasCredential = true; state.passwordless = false; }
      if (!pwEls.length && !ldapEl){
        state.passwordless = true;
        if (rec.name === 'default'){
          addFinding(findings, 'BLOCKER', 'Line ' + rec.line, rec.line,
            'Default user has no password element at all',
            'The default user is defined at line ' + rec.line + ' with no password element of any kind, so it can be used with no password.',
            'Add <password_sha256_hex> with the SHA-256 hash of a strong password inside the default user at line ' + rec.line + ', or remove the default user entirely.');
        } else {
          addFinding(findings, 'WARNING', 'Line ' + rec.line, rec.line,
            'User "' + rec.name + '" has no password element',
            'User "' + rec.name + '" is defined at line ' + rec.line + ' with no password element of any kind, so it can be used with no password.',
            'Add a <password_sha256_hex> credential inside user "' + rec.name + '" at line ' + rec.line + ', or remove the user.');
        }
      }

      /* networks */
      var netEl = firstChild(node, 'networks');
      if (netEl){
        state.networksLine = netEl.line;
        var ips = childrenNamed(netEl, 'ip');
        if (!ips.length){
          state.networksState = 'unrestricted';
        } else {
          state.networksState = 'restricted';
          for (j = 0; j < ips.length; j++){
            if (WILDCARD_NETWORKS.indexOf(trim(ips[j].text)) !== -1){
              state.networksState = 'unrestricted';
            }
          }
        }
        state.restricted = state.networksState === 'restricted';
      } else {
        state.networksState = 'absent';
        state.restricted = false;
      }

      if (rec.name === 'default' && state.passwordless){
        if (state.networksState === 'absent'){
          addFinding(findings, 'BLOCKER', 'Line ' + rec.line, rec.line,
            'ESCALATED — passwordless default user has no networks restriction',
            'The default user at line ' + rec.line + ' has no working password and no <networks> element at all. With no networks restriction, ClickHouse accepts this account from any network that can reach the server, which escalates the empty-password problem from a local risk to a remote one.',
            'Add a <networks> element inside the default user at line ' + rec.line + ' listing only trusted addresses (for example 127.0.0.1, ::1, and your private ranges), and set a hashed password.');
        } else if (state.networksState === 'unrestricted'){
          addFinding(findings, 'BLOCKER', 'Line ' + rec.line, rec.line,
            'ESCALATED — passwordless default user is open to all networks',
            'The default user at line ' + rec.line + ' has no working password, and its <networks> element at line ' + state.networksLine + ' allows every network. Anyone who can reach the server can use this account, which escalates the empty-password problem to full remote exposure.',
            'Restrict the <networks> element at line ' + state.networksLine + ' to trusted addresses only, and set a hashed password on the default user.');
        }
      }

      if (state.networksState === 'absent' && !(rec.name === 'default' && state.passwordless)){
        addFinding(findings, 'WARNING', 'Line ' + rec.line, rec.line,
          'User "' + rec.name + '" has no networks restriction',
          'User "' + rec.name + '" is defined at line ' + rec.line + ' with no <networks> element, so the account is accepted from any network that can reach the server.',
          'Add a <networks> element inside user "' + rec.name + '" at line ' + rec.line + ' listing only the addresses this account should connect from.');
      }
      if (state.networksState === 'unrestricted' && !(rec.name === 'default' && state.passwordless)){
        addFinding(findings, 'WARNING', 'Line ' + state.networksLine, state.networksLine,
          'User "' + rec.name + '" networks element allows all networks',
          'The <networks> element for user "' + rec.name + '" at line ' + state.networksLine + ' includes an allow-everything entry, so the restriction does not restrict anything.',
          'Replace the allow-everything entry in the <networks> element at line ' + state.networksLine + ' with the specific addresses or private ranges this account needs.');
      }

      if (!firstChild(node, 'profile')){
        addFinding(findings, 'INFO', 'Line ' + rec.line, rec.line,
          'User "' + rec.name + '" names no profile',
          'User "' + rec.name + '" at line ' + rec.line + ' has no <profile> element, so it silently inherits whatever the server default profile allows.',
          'Add a <profile> element inside user "' + rec.name + '" at line ' + rec.line + ' naming the settings profile this account should run under.');
      }
      if (!firstChild(node, 'quota')){
        addFinding(findings, 'INFO', 'Line ' + rec.line, rec.line,
          'User "' + rec.name + '" names no quota',
          'User "' + rec.name + '" at line ' + rec.line + ' has no <quota> element, so no per-user quota is applied by name.',
          'Add a <quota> element inside user "' + rec.name + '" at line ' + rec.line + ' naming the quota this account should be limited by.');
      }

      userStates.push(state);
      if (rec.name === 'default') defaultRec = state;
    }

    /* ---- Default-user posture for listener grading ---- */
    var defaultRisk = false;
    var defaultRiskReason = '';
    if (defaultRec){
      if (defaultRec.passwordless){
        defaultRisk = true;
        defaultRiskReason = 'the default user (line ' + defaultRec.rec.line + ') has no working password';
      } else if (!defaultRec.restricted){
        defaultRisk = true;
        defaultRiskReason = 'the default user (line ' + defaultRec.rec.line + ') has no effective networks restriction';
      }
    }

    /* ---- listen_host exposure ---- */
    var listenHosts = descendants(root, 'listen_host');
    if (!listenHosts.length){
      addFinding(findings, 'INFO', 'Line 1', 1,
        'No listen_host element found',
        'No <listen_host> element appears in the pasted text, so the listener address is left to whatever the server or its other config files set.',
        'If this config is the whole story, add an explicit <listen_host> naming only the interfaces this server should answer on.');
    }
    for (i = 0; i < listenHosts.length; i++){
      var hv = trim(listenHosts[i].text);
      if (WILDCARD_HOSTS.indexOf(hv) !== -1){
        if (defaultRisk){
          addFinding(findings, 'BLOCKER', 'Line ' + listenHosts[i].line, listenHosts[i].line,
            'listen_host ' + hv + ' exposes the server on every interface — and the default user is not locked down',
            'The <listen_host> at line ' + listenHosts[i].line + ' binds every network interface. This is graded BLOCKER because ' + defaultRiskReason + ', so the exposed listener and the weak account combine into remote, unauthenticated-grade access.',
            'Change the <listen_host> at line ' + listenHosts[i].line + ' to 127.0.0.1 or a specific internal address, or lock the default user down with a hashed password and a restricted <networks> list first.');
        } else {
          addFinding(findings, 'WARNING', 'Line ' + listenHosts[i].line, listenHosts[i].line,
            'listen_host ' + hv + ' exposes the server on every interface',
            'The <listen_host> at line ' + listenHosts[i].line + ' binds every network interface. This is graded WARNING rather than BLOCKER because no passwordless or network-unrestricted default user was found in the pasted text — but the server will still answer connection attempts from any network that can route to it, so firewalling and per-user networks lists carry the whole load.',
            'If this server does not need to serve other machines, change the <listen_host> at line ' + listenHosts[i].line + ' to 127.0.0.1 or a specific internal address; otherwise confirm the firewall and every user\'s <networks> list are tight.');
        }
      } else {
        addFinding(findings, 'INFO', 'Line ' + listenHosts[i].line, listenHosts[i].line,
          'listen_host restricted to ' + (hv ? hv : '(empty value)'),
          'The <listen_host> at line ' + listenHosts[i].line + ' names a specific address rather than every interface, so the listener itself is not the exposure.',
          'No change needed for this element.');
      }
    }

    /* ---- Ports ---- */
    var anyPort = false;
    for (i = 0; i < PORT_TAGS.length; i++){
      var portEls = descendants(root, PORT_TAGS[i]);
      for (j = 0; j < portEls.length; j++){
        anyPort = true;
        addFinding(findings, 'INFO', 'Line ' + portEls[j].line, portEls[j].line,
          'Port noted: <' + PORT_TAGS[i] + '> is ' + (trim(portEls[j].text) || '(empty)'),
          'The <' + PORT_TAGS[i] + '> element at line ' + portEls[j].line + ' sets the port this service listens on. Noted so the deployment record shows exactly which ports this config opens; make sure the firewall treats them the way the listener posture assumes.',
          'No change needed. Confirm the firewall rules for this port match the intended exposure.');
      }
    }
    if (!anyPort){
      addFinding(findings, 'INFO', 'Line 1', 1,
        'No explicit port elements found',
        'No http_port, tcp_port, or interserver port elements appear in the pasted text, so ClickHouse defaults or other config files decide which ports open.',
        'If this config is the whole story, set http_port, tcp_port, and interserver_http_port explicitly so the opened ports are a decision, not a default.');
    }

    /* ---- Profiles / quotas sections ---- */
    if (userRecs.length && !descendants(root, 'profiles').length){
      addFinding(findings, 'INFO', 'Line 1', 1,
        'No profiles section found',
        'The pasted text defines users but carries no <profiles> section, so profile names the users point at are not defined here.',
        'Paste the profiles section in with the rest of the config, or confirm the profiles are defined in a file that ships with this one.');
    }
    if (userRecs.length && !descendants(root, 'quotas').length){
      addFinding(findings, 'INFO', 'Line 1', 1,
        'No quotas section found',
        'The pasted text defines users but carries no <quotas> section, so no quotas are defined here to limit what accounts can consume.',
        'Add a <quotas> section with limits for these users, or confirm quotas are defined in a file that ships with this one.');
    }

    /* ---- Duplicate users ---- */
    var byName = {};
    for (i = 0; i < userRecs.length; i++){
      if (!byName[userRecs[i].name]) byName[userRecs[i].name] = [];
      byName[userRecs[i].name].push(userRecs[i].line);
    }
    for (var name in byName){
      if (Object.prototype.hasOwnProperty.call(byName, name) && byName[name].length > 1){
        addFinding(findings, 'WARNING', 'Lines ' + byName[name].join(' and '), byName[name][0],
          'Duplicate user definition: "' + name + '"',
          'User "' + name + '" is defined more than once, at lines ' + byName[name].join(' and ') + '. ClickHouse merges or overrides duplicated definitions in ways that are easy to misread, so the effective account may not be the one you think you audited.',
          'Keep one definition of user "' + name + '" — merge the two blocks at lines ' + byName[name].join(' and ') + ' into a single user element.');
      }
    }

    /* ---- Duplicate singleton elements under the same parent ---- */
    var nodes = allNodes(root);
    for (i = 0; i < nodes.length; i++){
      var groups = {};
      for (j = 0; j < nodes[i].children.length; j++){
        var ct = nodes[i].children[j].tag;
        if (SINGLETONS.indexOf(ct) === -1 && PASSWORD_TAGS.indexOf(ct) === -1) continue;
        if (!groups[ct]) groups[ct] = [];
        groups[ct].push(nodes[i].children[j].line);
      }
      for (var gt in groups){
        if (Object.prototype.hasOwnProperty.call(groups, gt) && groups[gt].length > 1){
          addFinding(findings, 'WARNING', 'Lines ' + groups[gt].join(' and '), groups[gt][0],
            'Duplicate element definition: <' + gt + '>',
            'The <' + gt + '> element is defined more than once under the same parent, at lines ' + groups[gt].join(' and ') + '. Only one of them can win, and which one is not obvious from the file.',
            'Delete the stale <' + gt + '> definition so a single value remains across lines ' + groups[gt].join(' and ') + '.');
        }
      }
    }

    /* ---- Password elements outside any user ---- */
    var allPasswords = descendants(root, 'password');
    for (i = 0; i < allPasswords.length; i++){
      var inUser = false;
      for (j = 0; j < userRecs.length; j++){
        if (isInside(allPasswords[i], userRecs[j].node) || allPasswords[i].parent === userRecs[j].node) inUser = true;
      }
      if (!inUser && trim(allPasswords[i].text).length){
        addFinding(findings, 'WARNING', 'Line ' + allPasswords[i].line, allPasswords[i].line,
          'Password value present outside a user definition',
          'A <password> element with a value set appears at line ' + allPasswords[i].line + ', outside any user block this audit could attribute it to. The value is never shown here.',
          'Check the <password> element at line ' + allPasswords[i].line + ': if it guards a real connection, move it to hashed storage or a secrets file with tight read permissions.');
      }
    }

    var rank = { BLOCKER: 0, WARNING: 1, INFO: 2 };
    findings.sort(function(a, b){
      if (rank[a.severity] !== rank[b.severity]) return rank[a.severity] - rank[b.severity];
      return a.lineNum - b.lineNum;
    });

    var verdict = 'SAFE TO DEPLOY';
    for (i = 0; i < findings.length; i++){
      if (findings[i].severity === 'BLOCKER'){ verdict = 'DO NOT DEPLOY'; break; }
      if (findings[i].severity === 'WARNING') verdict = 'DEPLOY WITH FIXES';
    }
    return { findings: findings, verdict: verdict, notParsed: false };
  }

  function buildReport(result){
    var lines = [];
    lines.push('J-Dawgs ClickHouse Server Config Safety Auditor — audit report');
    lines.push('Verdict: ' + result.verdict + (result.notParsed ? ' (NOT PARSED)' : ''));
    var b = 0, w = 0, inf = 0, i;
    for (i = 0; i < result.findings.length; i++){
      if (result.findings[i].severity === 'BLOCKER') b++;
      else if (result.findings[i].severity === 'WARNING') w++;
      else inf++;
    }
    lines.push('Findings: ' + b + ' blocker(s), ' + w + ' warning(s), ' + inf + ' info.');
    lines.push('Note: no secret values appear in this report. Passwords are named by element and line only.');
    lines.push('');
    for (i = 0; i < result.findings.length; i++){
      var f = result.findings[i];
      lines.push('[' + f.severity + '] ' + f.lineLabel + ' — ' + f.title);
      lines.push('  ' + f.detail);
      lines.push('  Fix: ' + f.fix);
      lines.push('');
    }
    lines.push('Scope: heuristic text audit run locally in the browser. It does not connect to any ClickHouse server and does not prove the XML is schema-valid.');
    return lines.join('\n');
  }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-clickhouse-server-config-safety-auditortm',
  name: 'J-Dawgs ClickHouse Server Config Safety Auditor',
  description: 'Grades a pasted ClickHouse config.xml / users.xml offline: default user with an empty password escalated by unrestricted networks, listen_host exposure, secrets by element name and line only — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
