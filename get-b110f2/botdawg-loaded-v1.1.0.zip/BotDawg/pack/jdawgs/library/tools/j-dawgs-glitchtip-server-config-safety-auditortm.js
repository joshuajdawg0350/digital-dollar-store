'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs GlitchTip Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Worked examples (input fixtures — these are pasted INTO the auditor) ---------- */
      var RISKY_LINES = [
        "# Risky example — every silent failure in one file. Do not deploy anything like this.",
        "SECRET_KEY=django-insecure-abc123",
        "GLITCHTIP_DOMAIN=http://errors.example.com",
        "DATABASE_URL=postgres://glitchtip:riskypass987@db.example.com:5432/glitchtip",
        "REDIS_URL=redis://:redispass123@redis.example.com:6379/0",
        "CELERY_BROKER_URL=redis://:brokerpass456@redis.example.com:6379/1",
        "ENABLE_USER_REGISTRATION=True",
        "DEBUG=True",
        "ALLOWED_HOSTS=*",
        "EMAIL_URL=smtp://alerts:mailpass789@smtp.example.com:587",
        "EMAIL_USE_TLS=False"
      ];
      var HARDENED_LINES = [
        "# Hardened example — grades SAFE TO DEPLOY.",
        "SECRET_KEY=aK9$mR2!vQ8#zX4&pL7*wN3^sD6%hJ5@tY1(uB0)cF9~gH2+xE4=",
        "GLITCHTIP_DOMAIN=https://errors.example.com",
        "DATABASE_URL=postgres://glitchtip:${DATABASE_PASSWORD}@db.internal:5432/glitchtip?sslmode=require",
        "REDIS_URL=redis://glitchtip:${REDIS_PASSWORD}@redis.internal:6379/0",
        "CELERY_BROKER_URL=redis://glitchtip:${REDIS_PASSWORD}@redis.internal:6379/1",
        "ENABLE_USER_REGISTRATION=False",
        "DEBUG=False",
        "ALLOWED_HOSTS=errors.example.com",
        "EMAIL_URL=smtps://glitchtip-mail@mail.example.com:465",
        "EMAIL_USE_TLS=True"
      ];
      var RISKY_TEXT = RISKY_LINES.join("\n");
      var HARDENED_TEXT = HARDENED_LINES.join("\n");

      /* ---------- Parsing ---------- */
      var RECOGNIZED = {};
      ["SECRET_KEY","GLITCHTIP_DOMAIN","DOMAIN","DATABASE_URL","REDIS_URL","CELERY_BROKER_URL",
       "CELERY_RESULT_BACKEND","BROKER_URL","ENABLE_USER_REGISTRATION","ENABLE_REGISTRATION",
       "OPEN_REGISTRATION","ALLOW_REGISTRATION","DEBUG","GLITCHTIP_DEBUG","DJANGO_DEBUG",
       "ALLOWED_HOSTS","EMAIL_URL","EMAIL_HOST","EMAIL_BACKEND","EMAIL_HOST_PASSWORD",
       "EMAIL_USE_TLS","EMAIL_USE_SSL","EMAIL_PORT","DEFAULT_FROM_EMAIL",
       "POSTGRES_PASSWORD","SESSION_COOKIE_SECURE","CSRF_COOKIE_SECURE"].forEach(function(k){ RECOGNIZED[k]=true; });

      function parseConfig(text){
        var entries = [];
        var lines = String(text == null ? "" : text).split(/\r?\n/);
        for (var i = 0; i < lines.length; i++){
          var t = lines[i].trim();
          if (!t || t.charAt(0) === "#") continue;
          if (t.indexOf("- ") === 0) t = t.slice(2).trim();
          var m = t.match(/^(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*[:=]\s*(.*)$/);
          if (!m) continue;
          var key = m[1].toUpperCase();
          var val = (m[2] || "").trim();
          if (val.indexOf("://") === -1){
            var ci = val.indexOf(" #");
            if (ci > -1) val = val.slice(0, ci).trim();
          }
          if (val.length >= 2){
            var q = val.charAt(0);
            if ((q === '"' || q === "'") && val.charAt(val.length - 1) === q) val = val.slice(1, -1);
          }
          entries.push({ key: key, value: val, line: i + 1 });
        }
        return entries;
      }
      function getEntry(entries, key){
        for (var i = 0; i < entries.length; i++) if (entries[i].key === key) return entries[i];
        return null;
      }
      function isTruthy(v){
        return ["true","1","yes","on","open","enabled","y","t"].indexOf(String(v).trim().toLowerCase()) > -1;
      }
      function isFalsy(v){
        return ["false","0","no","off","closed","disabled","n","f"].indexOf(String(v).trim().toLowerCase()) > -1;
      }
      /* Returns the password portion of a URL's userinfo, or null. The value is
         used ONLY for its length and placeholder test — it is never rendered. */
      function urlPassword(value){
        var m = String(value).match(/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\/([^/?#]*)/);
        if (!m) return null;
        var authority = m[1];
        var at = authority.lastIndexOf("@");
        if (at < 0) return null;
        var userinfo = authority.slice(0, at);
        var colon = userinfo.indexOf(":");
        if (colon < 0) return null;
        var pw = userinfo.slice(colon + 1);
        return pw === "" ? null : pw;
      }
      function isPlaceholder(pw){
        if (!pw) return true;
        if (/^\*+$/.test(pw)) return true;
        if (/^\$\{.*\}$/.test(pw)) return true;
        if (/^\$[A-Za-z_][A-Za-z0-9_]*$/.test(pw)) return true;
        if (/^<.*>$/.test(pw)) return true;
        var low = pw.toLowerCase();
        return ["changeme","change_me","change-me","redacted","placeholder","password","xxx","xxxx","example"].indexOf(low) > -1;
      }

      /* ---------- Audit ---------- */
      var SEV_ORDER = { BLOCKER: 0, HIGH: 1, WARNING: 2, INFO: 3 };
      function countSeverities(findings){
        var c = { BLOCKER: 0, HIGH: 0, WARNING: 0, INFO: 0 };
        findings.forEach(function(f){ if (c.hasOwnProperty(f.severity)) c[f.severity]++; });
        return c;
      }

      function auditConfig(text){
        var entries = parseConfig(text);
        var recognizedCount = 0;
        entries.forEach(function(e){ if (RECOGNIZED[e.key]) recognizedCount++; });
        if (recognizedCount === 0){
          return { gradeable: false, verdict: "NOT ENOUGH TO GRADE", findings: [],
                   counts: countSeverities([]), settingsParsed: entries.length, recognized: 0 };
        }
        var findings = [];
        function add(line, severity, key, check, detail, fix, extra){
          var f = { line: line, severity: severity, key: key, check: check, detail: detail, fix: fix };
          if (extra) for (var k in extra) f[k] = extra[k];
          findings.push(f);
        }

        /* SECRET_KEY */
        var sk = getEntry(entries, "SECRET_KEY");
        if (!sk){
          add(null, "BLOCKER", "SECRET_KEY", "secret-key-missing",
            "SECRET_KEY is not set anywhere in the pasted config. Without it, session signing and signed links fall back to a predictable or empty key.",
            "Generate a long random key (50+ characters, e.g. openssl rand -hex 32) and set it as SECRET_KEY. Keep the real value in your host's secret store, out of git.");
        } else if (sk.value.indexOf("${") === 0 || sk.value.charAt(0) === "$"){
          add(sk.line, "INFO", "SECRET_KEY", "secret-key-by-reference",
            "SECRET_KEY is supplied by reference rather than written out, so its strength cannot be graded from the pasted text.",
            "Confirm the injected value is a unique random key of 50+ characters that appears in no example or repository.");
        } else {
          var low = sk.value.toLowerCase();
          var known = low.indexOf("insecure") > -1 || low.indexOf("changeme") > -1 ||
                      low.indexOf("change-me") > -1 || low.indexOf("change_me") > -1 ||
                      low.indexOf("your-secret") > -1 || low.indexOf("your_secret") > -1 ||
                      low === "secret" || low === "secretkey" || low === "glitchtip" || low === "development";
          if (known){
            add(sk.line, "BLOCKER", "SECRET_KEY", "secret-key-example",
              "SECRET_KEY matches a known example or placeholder value of the kind published in docs and sample configs. Anyone can guess it, so anyone can forge sessions.",
              "Replace it with a unique random key of 50+ characters that has never appeared in any example, tutorial, or repository.");
          } else if (sk.value.length < 32){
            add(sk.line, "BLOCKER", "SECRET_KEY", "secret-key-short",
              "SECRET_KEY is only " + sk.value.length + " characters long — under the 32-character minimum. Short keys are brute-forceable. (The key itself is never shown here.)",
              "Replace it with a unique random key of 50+ characters.");
          } else if (sk.value.length < 50){
            add(sk.line, "WARNING", "SECRET_KEY", "secret-key-adequate",
              "SECRET_KEY is " + sk.value.length + " characters. It clears the 32-character minimum, but 50+ characters is the safer target for a production signing key.",
              "Rotate to a unique random key of 50+ characters at the next maintenance window.");
          }
        }

        /* GLITCHTIP_DOMAIN */
        var dom = getEntry(entries, "GLITCHTIP_DOMAIN") || getEntry(entries, "DOMAIN");
        if (!dom){
          add(null, "HIGH", "GLITCHTIP_DOMAIN", "domain-missing",
            "GLITCHTIP_DOMAIN is not set. GlitchTip builds links, redirects, and cookie scope from it; leaving it unset invites wrong-host and insecure defaults.",
            "Set GLITCHTIP_DOMAIN to the public https address of the server, e.g. GLITCHTIP_DOMAIN=https://errors.example.com.");
        } else if (/^http:\/\//i.test(dom.value)){
          add(dom.line, "BLOCKER", "GLITCHTIP_DOMAIN", "domain-http",
            "GLITCHTIP_DOMAIN uses http://. Logins, session cookies, and error-report links cross the network unencrypted, and browsers will flag the site.",
            "Put the server behind HTTPS (a reverse proxy with a real certificate is fine) and set GLITCHTIP_DOMAIN to the https:// address.");
        } else if (!/^https:\/\//i.test(dom.value)){
          add(dom.line, "WARNING", "GLITCHTIP_DOMAIN", "domain-no-scheme",
            "GLITCHTIP_DOMAIN has no https:// scheme in front of it, so the scheme GlitchTip assumes is ambiguous.",
            "Write the full address with the scheme: GLITCHTIP_DOMAIN=https://your-domain.");
        }

        /* DATABASE_URL */
        var db = getEntry(entries, "DATABASE_URL");
        if (!db){
          add(null, "WARNING", "DATABASE_URL", "database-missing",
            "DATABASE_URL is not set in the pasted config, so the database posture cannot be graded and the server may fall back to a development default.",
            "Set DATABASE_URL to the production PostgreSQL connection string, with the password injected by reference (see the hardened example).");
        } else {
          var dbpw = urlPassword(db.value);
          if (dbpw && !isPlaceholder(dbpw)){
            add(db.line, "BLOCKER", "DATABASE_URL", "database-plaintext-password",
              "DATABASE_URL embeds a plaintext password (" + dbpw.length + " characters) in the connection string. The password itself is never shown in this report. Anyone who can read this config — a repo, a paste, a screenshot — owns the database.",
              "Take the password out of the written config: write the URL with a reference such as ${DATABASE_PASSWORD} and inject the real value from your host's secret store at deploy time. Rotate the exposed password, since it has been written down.",
              { passwordLength: dbpw.length });
          }
          if (/^sqlite/i.test(db.value)){
            add(db.line, "WARNING", "DATABASE_URL", "database-sqlite",
              "DATABASE_URL points at SQLite. That is a development database; a production GlitchTip instance expects PostgreSQL.",
              "Point DATABASE_URL at PostgreSQL for production.");
          }
        }

        /* REDIS_URL */
        var redis = getEntry(entries, "REDIS_URL");
        if (!redis){
          add(null, "WARNING", "REDIS_URL", "redis-missing",
            "REDIS_URL is not set in the pasted config. GlitchTip's background workers (Celery) need Redis; without it, event processing silently stalls.",
            "Set REDIS_URL to the production Redis instance, with any password injected by reference.");
        } else {
          var rpw = urlPassword(redis.value);
          if (rpw && !isPlaceholder(rpw)){
            add(redis.line, "HIGH", "REDIS_URL", "redis-plaintext-password",
              "REDIS_URL embeds a plaintext password (" + rpw.length + " characters). The password itself is never shown in this report.",
              "Reference the password as ${REDIS_PASSWORD} in the written config and inject the real value at deploy time. Rotate the exposed password.",
              { passwordLength: rpw.length });
          }
        }

        /* Celery / broker URLs */
        ["CELERY_BROKER_URL","CELERY_RESULT_BACKEND","BROKER_URL"].forEach(function(key){
          var e = getEntry(entries, key);
          if (!e) return;
          var pw = urlPassword(e.value);
          if (pw && !isPlaceholder(pw)){
            add(e.line, "HIGH", key, "broker-plaintext-password",
              key + " embeds a plaintext password (" + pw.length + " characters) in the broker URL. The password itself is never shown in this report.",
              "Reference the password as a variable (e.g. ${REDIS_PASSWORD}) in the written config and inject the real value at deploy time. Rotate the exposed password.",
              { passwordLength: pw.length });
          }
        });

        /* Open registration */
        ["ENABLE_USER_REGISTRATION","ENABLE_REGISTRATION","OPEN_REGISTRATION","ALLOW_REGISTRATION"].forEach(function(key){
          var e = getEntry(entries, key);
          if (e && isTruthy(e.value)){
            add(e.line, "HIGH", key, "registration-open",
              key + " is on. Anyone on the internet can create an account on your error-tracking server — and read every stack trace, user email, and secret your apps have ever reported.",
              "Create your admin and team accounts, then set " + key + "=False. Invite teammates individually after that.");
          }
        });

        /* Debug mode */
        ["DEBUG","GLITCHTIP_DEBUG","DJANGO_DEBUG"].forEach(function(key){
          var e = getEntry(entries, key);
          if (e && isTruthy(e.value)){
            add(e.line, "BLOCKER", key, "debug-on",
              key + " is on. Debug mode serves detailed error pages with settings, environment values, and source code to whoever triggers an error.",
              "Set " + key + "=False for anything reachable by other people. Debug belongs on a local development copy only.");
          }
        });

        /* ALLOWED_HOSTS wildcard */
        var ah = getEntry(entries, "ALLOWED_HOSTS");
        if (ah && ah.value.indexOf("*") > -1){
          add(ah.line, "HIGH", "ALLOWED_HOSTS", "allowed-hosts-wildcard",
            "ALLOWED_HOSTS contains a wildcard (*). The server will answer to any Host header, which enables host-header attacks and cache poisoning against your login pages.",
            "List the real hostnames only, e.g. ALLOWED_HOSTS=errors.example.com.");
        }

        /* Email posture */
        var emailUrl = getEntry(entries, "EMAIL_URL");
        var emailHost = getEntry(entries, "EMAIL_HOST");
        var emailPw = getEntry(entries, "EMAIL_HOST_PASSWORD");
        var useTls = getEntry(entries, "EMAIL_USE_TLS");
        var useSsl = getEntry(entries, "EMAIL_USE_SSL");
        if (emailPw && emailPw.value && !isPlaceholder(emailPw.value)){
          add(emailPw.line, "HIGH", "EMAIL_HOST_PASSWORD", "email-plaintext-password",
            "EMAIL_HOST_PASSWORD is written out in plaintext (" + emailPw.value.length + " characters). The password itself is never shown in this report.",
            "Inject the mail password from your host's secret store instead of writing it in the config, and rotate the exposed one.",
            { passwordLength: emailPw.value.length });
        }
        if (emailUrl){
          var epw = urlPassword(emailUrl.value);
          if (epw && !isPlaceholder(epw)){
            add(emailUrl.line, "HIGH", "EMAIL_URL", "email-plaintext-password",
              "EMAIL_URL embeds a plaintext mail password (" + epw.length + " characters). The password itself is never shown in this report.",
              "Reference the mail password as a variable in the written config and inject the real value at deploy time. Rotate the exposed password.",
              { passwordLength: epw.length });
          }
          var scheme = (emailUrl.value.split(":")[0] || "").toLowerCase();
          var tlsOff = useTls && isFalsy(useTls.value) && !(useSsl && isTruthy(useSsl.value));
          if ((scheme === "smtp" && emailUrl.value.toLowerCase().indexOf("tls") === -1) || tlsOff){
            add(emailUrl.line, "WARNING", "EMAIL_URL", "email-no-tls",
              "The email setup sends mail without TLS. Password-reset links and alert mail — and the mail account's credentials — cross the network in the clear.",
              "Use an smtps:// EMAIL_URL or a TLS-enabled SMTP endpoint (port 587 with EMAIL_USE_TLS=True).");
          }
        } else if (!emailHost){
          add(null, "WARNING", "EMAIL_URL", "email-missing",
            "No email configuration was found (no EMAIL_URL and no EMAIL_HOST). Password resets and alert mail will not be sent, and account recovery becomes a manual chore.",
            "Configure EMAIL_URL for your mail provider over TLS, with the password injected by reference.");
        }
        if (emailHost && useTls && isFalsy(useTls.value) && !(useSsl && isTruthy(useSsl.value))){
          add(useTls.line, "HIGH", "EMAIL_USE_TLS", "email-tls-off",
            "EMAIL_USE_TLS is off while a real mail host is configured. Mail credentials and message contents are sent unencrypted.",
            "Set EMAIL_USE_TLS=True (or use EMAIL_USE_SSL=True on an SSL port) for the production mail host.");
        }

        /* Generic plaintext secrets in other keys (reported by length only) */
        var covered = { SECRET_KEY: 1, EMAIL_HOST_PASSWORD: 1, DATABASE_URL: 1, REDIS_URL: 1,
                        CELERY_BROKER_URL: 1, CELERY_RESULT_BACKEND: 1, BROKER_URL: 1, EMAIL_URL: 1 };
        entries.forEach(function(e){
          if (covered[e.key]) return;
          if (!/(_PASSWORD|_SECRET|_TOKEN|API_KEY|ACCESS_KEY)$/.test(e.key)) return;
          if (!e.value || isPlaceholder(e.value) || e.value.charAt(0) === "$") return;
          add(e.line, "HIGH", e.key, "plaintext-secret",
            e.key + " is written out in plaintext (" + e.value.length + " characters). The value itself is never shown in this report.",
            "Move the value into your host's secret store and reference it from the config. Rotate it, since it has been written down.",
            { passwordLength: e.value.length });
        });

        findings.sort(function(a, b){
          var d = SEV_ORDER[a.severity] - SEV_ORDER[b.severity];
          if (d !== 0) return d;
          return (a.line == null ? 9999 : a.line) - (b.line == null ? 9999 : b.line);
        });
        var counts = countSeverities(findings);
        var verdict = counts.BLOCKER > 0 ? "DO NOT DEPLOY"
                    : (counts.HIGH > 0 || counts.WARNING > 0) ? "DEPLOY WITH FIXES"
                    : "SAFE TO DEPLOY";
        return { gradeable: true, verdict: verdict, findings: findings, counts: counts,
                 settingsParsed: entries.length, recognized: recognizedCount };
      }

      /* ---------- Report / JSON (built only from finding metadata — no raw input, no secret values) ---------- */
      function verdictSub(result){
        if (!result.gradeable) return "No recognizable GlitchTip settings were found in the pasted text, so there is nothing to grade. Paste KEY=value or YAML-style setting lines.";
        if (result.verdict === "SAFE TO DEPLOY") return "No blockers, high-severity findings, or warnings in the pasted settings. This grades the pasted lines only — it does not verify a live deployment.";
        if (result.verdict === "DEPLOY WITH FIXES") return "Nothing here is an outright stopper, but the findings below should be fixed before this config faces other people.";
        return "One or more blockers were found. Fix every BLOCKER before deploying this configuration.";
      }
      function buildReport(result){
        var out = [];
        out.push("J-Dawgs GlitchTip Server Config Safety Auditor\u2122 \u2014 Audit Report");
        out.push("Verdict: " + result.verdict);
        out.push("Findings: " + result.counts.BLOCKER + " BLOCKER \u00B7 " + result.counts.HIGH + " HIGH \u00B7 " +
                 result.counts.WARNING + " WARNING \u00B7 " + result.counts.INFO + " INFO");
        out.push("Settings parsed: " + result.settingsParsed);
        out.push("");
        out.push(verdictSub(result));
        if (result.findings.length){
          out.push("");
          result.findings.forEach(function(f, i){
            out.push((i + 1) + ". [" + f.severity + "] " + (f.line == null ? "Line \u2014 (setting missing)" : "Line " + f.line) + " \u00B7 " + f.key);
            out.push("   " + f.detail);
            out.push("   Fix: " + f.fix);
          });
        }
        out.push("");
        out.push("Scope: offline text audit of pasted configuration only. This tool never connects to a server and does not verify a live deployment. Secret values are never shown; passwords are reported by key name, line, and length only.");
        return out.join("\n");
      }
      function buildJSON(result){
        var obj = {
          tool: "J-Dawgs GlitchTip Server Config Safety Auditor\u2122",
          verdict: result.verdict,
          gradeable: result.gradeable,
          settingsParsed: result.settingsParsed,
          counts: result.counts,
          findings: result.findings.map(function(f){
            var o = { line: f.line, severity: f.severity, key: f.key, check: f.check, detail: f.detail, fix: f.fix };
            if (typeof f.passwordLength === "number") o.passwordLength = f.passwordLength;
            return o;
          }),
          scope: "Offline text audit of pasted configuration only. Never connects to a server; does not verify a live deployment. Secret values are never included; passwords are reported by key, line, and length only."
        };
        return JSON.stringify(obj, null, 2);
      }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-glitchtip-server-config-safety-auditortm',
  name: 'J-Dawgs GlitchTip Server Config Safety Auditor',
  description: 'Grades a pasted GlitchTip server config offline into one deploy verdict: short or default secret key values, a plain-HTTP domain, and open registration all graded, with secrets reported by key name, line, and length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
