'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Email Header & Deliverability Pre-Flight Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var STORE_URL = "https://muse.ai/s/ai-tool-store-xng6xkxwjkxl2xab/UoF72OkKI7j33Q2ITxmrZyIr4nv40QtYfj2AgESh_k8";
      var EXCHANGE_URL = "https://muse.ai/s/j-dawgs-agent-exchange-ih6xlnihzxdhxc/ZbleqxFHRE0NcswaBkyN13y9lLp5rPAgHTb6t8ii-PY";
      var PITCH_TEXT =
        "Deploy It, Link It, Deliver It Stack — Kubernetes Manifest Safety Auditor + Markdown Anchor Integrity Auditor + Email Header Deliverability Auditor (grade the manifest, prove the anchors, check the headers — before anything ships).\n\n" +
        "AI Tool Store: " + STORE_URL + "\n" +
        "J-Dawgs Agent Exchange: " + EXCHANGE_URL;

      var FLAWED_EXAMPLE = [
        "Return-Path: <bounce-8841@trk.sendgrid-offers.net>",
        "Received: from mail.trk.sendgrid-offers.net (mail.trk.sendgrid-offers.net [203.0.113.44])",
        "\tby mx.example.org with ESMTP id abc123",
        "\tfor <reader@example.net>; Mon, 02 Nov 2026 06:14:52 -0600",
        "Received: from vps-771.hosting.example (vps-771.hosting.example [198.51.100.23])",
        "\tby mail.trk.sendgrid-offers.net with ESMTP id def456",
        "\tfor <bounce-8841@trk.sendgrid-offers.net>; Sun, 01 Nov 2026 04:02:11 -0600",
        "Authentication-Results: mx.example.org;",
        "\tspf=fail (sender IP is 198.51.100.23) smtp.mailfrom=trk.sendgrid-offers.net;",
        "\tdkim=none (message not signed);",
        "\tdmarc=fail (p=REJECT) header.from=mega-deals.example",
        "From: \"MEGA DEALS\" <deals@mega-deals.example>",
        "Reply-To: <support@totally-different.example>",
        "Subject: FREE MONEY ACT NOW LIMITED TIME OFFER!!!",
        "Precedence: bulk",
        "List-Id: Mega Deals Weekly <weekly.mega-deals.example>",
        "Date: Mon, 02 Nov 2026 06:15:03 -0600",
        "Content-Type: multipart/alternative; boundary=\"----=_Part_991\"",
        "X-Spam-Flag: YES",
        "X-Spam-Status: Yes, score=9.4 required=5.0"
      ].join("\n");

      var CLEAN_EXAMPLE = [
        "Return-Path: <news@jdawgs.example>",
        "Received: from mail.jdawgs.example (mail.jdawgs.example [192.0.2.10])",
        "\tby mx.example.org with ESMTPS id xyz789",
        "\tfor <reader@example.net>; Wed, 04 Nov 2026 09:02:41 -0600",
        "Received: from app.jdawgs.example (app.jdawgs.example [192.0.2.11])",
        "\tby mail.jdawgs.example with ESMTP id uvw456",
        "\tfor <news@jdawgs.example>; Wed, 04 Nov 2026 09:01:05 -0600",
        "Authentication-Results: mx.example.org;",
        "\tspf=pass (sender IP is 192.0.2.10) smtp.mailfrom=jdawgs.example;",
        "\tdkim=pass header.d=jdawgs.example;",
        "\tdmarc=pass (p=REJECT) header.from=jdawgs.example",
        "From: \"J-Dawgs Trading Post\" <news@jdawgs.example>",
        "Reply-To: <news@jdawgs.example>",
        "To: reader@example.net",
        "Subject: This week's new arrivals at the Trading Post",
        "Message-ID: <20261104090105.7f3a@mail.jdawgs.example>",
        "Date: Wed, 04 Nov 2026 09:01:12 -0600",
        "MIME-Version: 1.0",
        "Content-Type: multipart/alternative; boundary=\"----=_Part_100\"",
        "List-Unsubscribe: <https://jdawgs.example/unsubscribe>, <mailto:unsubscribe@jdawgs.example>",
        "List-Id: J-Dawgs Weekly <weekly.jdawgs.example>",
        "Precedence: bulk"
      ].join("\n");

      /* ---------- parsing ---------- */

      // Unfold continuation lines, then split into {name, lower, value} records.
      // Stops at the first blank line (start of the body), per RFC 5322.
      function parseHeaders(raw) {
        var lines = raw.replace(/\r\n/g, "\n").replace(/\r/g, "\n").split("\n");
        var records = [];
        var current = null;
        for (var i = 0; i < lines.length; i++) {
          var line = lines[i];
          if (line === "") {
            if (records.length || current) { break; }
            continue;
          }
          if ((line.charAt(0) === " " || line.charAt(0) === "\t") && current) {
            current.value += " " + line.replace(/^[ \t]+/, "");
            continue;
          }
          var colon = line.indexOf(":");
          if (colon <= 0) { current = null; continue; }
          var name = line.slice(0, colon).trim();
          current = { name: name, lower: name.toLowerCase(), value: line.slice(colon + 1).trim() };
          records.push(current);
        }
        return records;
      }

      function getAll(records, lowerName) {
        var out = [];
        for (var i = 0; i < records.length; i++) {
          if (records[i].lower === lowerName) { out.push(records[i]); }
        }
        return out;
      }
      function getFirst(records, lowerName) {
        var all = getAll(records, lowerName);
        return all.length ? all[0] : null;
      }

      // Redact long token-like runs so secrets are never echoed beyond a fragment.
      function redact(value) {
        return String(value).replace(/[A-Za-z0-9+/=_-]{28,}/g, function (m) {
          return m.slice(0, 8) + "…[redacted]";
        });
      }
      function quoteOf(record) {
        return record.name + ": " + redact(record.value);
      }

      function extractEmailDomain(value) {
        var m = String(value).match(/<?\s*([A-Za-z0-9._%+-]+)@([A-Za-z0-9.-]+\.[A-Za-z]{2,})\s*>?/);
        if (!m) { return null; }
        return { address: m[1] + "@" + m[2], domain: m[2].toLowerCase() };
      }
      // Naive organizational domain (last two labels) — heuristic, labeled as such.
      function orgDomain(domain) {
        var parts = domain.split(".");
        if (parts.length <= 2) { return domain; }
        return parts.slice(parts.length - 2).join(".");
      }
      function parseDateValue(value) {
        var cleaned = String(value).replace(/\([^)]*\)/g, " ").replace(/\s+/g, " ").trim();
        var t = Date.parse(cleaned);
        return isNaN(t) ? null : t;
      }
      function fmtHours(ms) {
        var h = ms / 3600000;
        return (Math.round(h * 10) / 10).toString();
      }

      /* ---------- audit ---------- */

      function audit(raw) {
        var findings = [];
        function add(sev, title, detail, quote) {
          findings.push({ sev: sev, title: title, detail: detail, quote: quote || null });
        }

        var records = parseHeaders(raw);
        if (!records.length) {
          add("warning", "No headers parsed",
            "Nothing in the pasted text looked like an email header block (lines of the form \"Name: value\"). Paste the full headers from one message and run the audit again.", null);
          return findings;
        }

        /* Duplicate headers, by name and count */
        var counts = {}, order = [], displayName = {};
        records.forEach(function (r) {
          if (!(r.lower in counts)) { counts[r.lower] = 0; order.push(r.lower); displayName[r.lower] = r.name; }
          counts[r.lower]++;
        });
        var dupes = order.filter(function (k) { return counts[k] > 1; });
        if (dupes.length) {
          var dupeText = dupes.map(function (k) { return displayName[k] + " × " + counts[k]; }).join(", ");
          var singletonDupes = dupes.filter(function (k) {
            return ["from", "subject", "date", "message-id", "content-type", "mime-version", "return-path"].indexOf(k) !== -1;
          });
          if (singletonDupes.length) {
            add("warning", "Duplicate headers",
              "These headers appear more than once: " + dupeText + ". Duplicated " +
              singletonDupes.map(function (k) { return displayName[k]; }).join(", ") +
              " header(s) are a red flag — receivers may use either copy, and mismatched copies are a classic spoofing/phishing artifact. (Repeated Received: headers are normal — one per relay hop.)", null);
          } else {
            add("info", "Duplicate headers",
              "Repeated headers found: " + dupeText + ". Repetition of these is expected (one Received: per relay hop, one Authentication-Results: per checking server) and is not a defect by itself.", null);
          }
        }

        /* Authentication-Results */
        var arRecords = getAll(records, "authentication-results");
        if (!arRecords.length) {
          add("warning", "Authentication-Results missing — NOT CHECKABLE",
            "No Authentication-Results header is present, so the recorded SPF / DKIM / DMARC outcomes cannot be graded from these headers. This tool never queries DNS, so it cannot fill that gap itself — it grades the results a receiving server recorded. If your pasted block was trimmed, re-copy the full headers; the receiving server normally stamps this header at the top.", null);
        } else {
          var mechOrder = ["spf", "dkim", "dmarc"];
          var mechLabel = { spf: "SPF", dkim: "DKIM", dmarc: "DMARC" };
          var found = {};
          arRecords.forEach(function (rec) {
            var re = /\b(spf|dkim|dmarc)\s*=\s*([a-z]+)/gi;
            var m;
            while ((m = re.exec(rec.value)) !== null) {
              var mech = m[1].toLowerCase(), result = m[2].toLowerCase();
              // Keep the worst result seen per mechanism: fail > none/other > pass.
              var rank = function (r) { return r === "fail" ? 3 : (r === "pass" ? 1 : 2); };
              if (!found[mech] || rank(result) > rank(found[mech].result)) {
                found[mech] = { result: result, fragment: m[1] + "=" + m[2], record: rec };
              }
            }
          });
          mechOrder.forEach(function (mech) {
            var label = mechLabel[mech];
            if (!found[mech]) {
              add("info", label + " result not recorded",
                "The Authentication-Results header does not record a " + mech + "= result. This audit can only grade what the receiving server wrote down.",
                arRecords.length ? quoteOf(arRecords[0]) : null);
              return;
            }
            var f = found[mech];
            if (f.result === "fail") {
              add("blocker", label + " FAIL",
                "The receiving server recorded " + f.fragment + ". A failed " + label + " check is a hard deliverability blocker: strict receivers reject or spam-folder the message, and a DMARC policy can turn an SPF/DKIM failure into an outright rejection.",
                f.fragment + "  —  from header: " + f.record.name);
            } else if (f.result === "none" && (mech === "spf" || mech === "dkim")) {
              add("warning", label + " result: none",
                "The receiving server recorded " + f.fragment + " — no " + label + (mech === "spf" ? " record/result existed for the sending domain" : " signature was present on the message") + ". Mail can still deliver, but it carries no " + label + " authentication weight, and DMARC cannot pass on this mechanism.",
                f.fragment + "  —  from header: " + f.record.name);
            } else if (f.result === "pass") {
              add("pass", label + " pass",
                "The receiving server recorded " + f.fragment + ".",
                f.fragment + "  —  from header: " + f.record.name);
            } else {
              add("info", label + " result: " + f.result,
                "The receiving server recorded " + f.fragment + ". This audit treats only pass / fail / none specially; any other recorded result is reported as-is.",
                f.fragment + "  —  from header: " + f.record.name);
            }
          });
        }

        /* Domain alignment (heuristic) */
        var fromRec = getFirst(records, "from");
        var rpRec = getFirst(records, "return-path");
        var rtRec = getFirst(records, "reply-to");
        var fromInfo = fromRec ? extractEmailDomain(fromRec.value) : null;
        var rpInfo = rpRec ? extractEmailDomain(rpRec.value) : null;
        var rtInfo = rtRec ? extractEmailDomain(rtRec.value) : null;
        if (fromRec && !fromInfo) {
          add("info", "From address not parseable",
            "No email address could be extracted from the From header, so alignment checks against it were skipped.", quoteOf(fromRec));
        }
        if (fromInfo && rpInfo) {
          if (orgDomain(fromInfo.domain) === orgDomain(rpInfo.domain)) {
            add("pass", "SPF alignment (heuristic)",
              "Return-Path domain " + rpInfo.domain + " aligns with the From domain " + fromInfo.domain + " — the bounce path and the visible sender live under the same organizational domain, which is what SPF alignment asks for. Heuristic only: this compares domains printed in the headers; it is not a cryptographic verification.",
              quoteOf(rpRec));
          } else {
            add("warning", "SPF alignment REVIEW — Return-Path / From mismatch",
              "The Return-Path domain (" + rpInfo.domain + ", from " + rpInfo.address + ") does not match the From domain (" + fromInfo.domain + ", from " + fromInfo.address + "). In plain words: SPF authenticates the Return-Path (bounce) domain, but readers and DMARC judge the From domain — when the two point at different organizations, the SPF result does not vouch for the sender people actually see, and DMARC-style alignment fails. Send from an address whose domain matches the bounce domain, or set up the sending service as an authorized subdomain of your own domain. Heuristic only: domains compared as printed in the headers, not a cryptographic verification.",
              quoteOf(rpRec) + "\n" + quoteOf(fromRec));
          }
        } else if (fromInfo && !rpRec) {
          add("info", "No Return-Path header",
            "SPF alignment cannot be reviewed without a Return-Path. Most receiving servers add one (or an equivalent envelope record) at delivery; its absence here usually means the pasted block was trimmed.", null);
        }
        if (fromInfo && rtInfo) {
          if (orgDomain(fromInfo.domain) === orgDomain(rtInfo.domain)) {
            add("pass", "Reply-To alignment (heuristic)",
              "Reply-To domain " + rtInfo.domain + " aligns with the From domain " + fromInfo.domain + ". Replies stay inside the sender's own organization.",
              quoteOf(rtRec));
          } else {
            add("warning", "Reply-To / From domain mismatch",
              "Replies go to " + rtInfo.address + " (domain " + rtInfo.domain + "), which is a different organization from the From domain " + fromInfo.domain + ". A Reply-To that leaves the sender's domain is a common phishing pattern and a spam-filter signal, and under DMARC-style alignment thinking it breaks the chain of identity: the address readers see is not the address that receives their replies. If this is legitimate (a helpdesk on another domain), make sure that domain is set up and authenticated for it. Heuristic only: domains compared as printed in the headers, not a cryptographic verification.",
              quoteOf(rtRec) + "\n" + quoteOf(fromRec));
          }
        }

        /* Message-ID */
        var midRec = getFirst(records, "message-id");
        if (!midRec) {
          add("warning", "Missing Message-ID",
            "Every message should carry a unique Message-ID header. Without one, some receivers assign their own (hiding threading and duplicate problems), threading breaks, and its absence is itself a mild spam signal — legitimate mail software always adds one.", null);
        } else {
          add("pass", "Message-ID present", "Message-ID: " + redact(midRec.value), null);
        }

        /* Date */
        var dateRec = getFirst(records, "date");
        if (!dateRec) {
          add("warning", "Missing Date header",
            "The Date header is required by the email standards. Its absence is a spam signal and can make the message display with the receiving time instead of the sending time.", null);
        } else if (parseDateValue(dateRec.value) === null) {
          add("warning", "Date header not parseable",
            "A Date header is present but its value could not be parsed as a date, so it is reported as NOT PARSED rather than guessed. Malformed dates are a spam signal and can break sorting and threading.", quoteOf(dateRec));
        } else {
          add("pass", "Date present and parseable", "Date: " + dateRec.value, null);
        }

        /* MIME-Version vs multipart */
        var ctRec = getFirst(records, "content-type");
        var mimeRec = getFirst(records, "mime-version");
        if (ctRec && /multipart\//i.test(ctRec.value) && !mimeRec) {
          add("info", "MIME-Version missing on a multipart message",
            "The Content-Type is multipart but there is no MIME-Version header. Most clients cope, but the MIME standards expect \"MIME-Version: 1.0\" on any MIME message, and strict parsers may render the parts incorrectly.", quoteOf(ctRec));
        }

        /* Received chain */
        var received = getAll(records, "received");
        if (!received.length) {
          add("info", "No Received headers",
            "No Received chain was found, so relay hops and transit time cannot be reviewed. A delivered message normally carries one Received header per relay; their absence usually means the block was trimmed.", null);
        } else {
          var times = [], unparsed = 0;
          received.forEach(function (rec) {
            var semi = rec.value.lastIndexOf(";");
            var ts = semi >= 0 ? parseDateValue(rec.value.slice(semi + 1)) : null;
            if (ts === null) { unparsed++; } else { times.push(ts); }
          });
          var detail = "The chain records " + received.length + " hop" + (received.length === 1 ? "" : "s") + " (one Received header per relay).";
          var sev = "pass";
          if (times.length >= 2) {
            var newest = Math.max.apply(null, times), oldest = Math.min.apply(null, times);
            var transit = newest - oldest;
            detail += " Newest Received timestamp: " + new Date(newest).toUTCString() +
              ". Oldest: " + new Date(oldest).toUTCString() +
              ". Total transit = " + fmtHours(transit) + " hours (" + Math.round(transit / 60000) + " minutes).";
            if (transit > 24 * 3600000) {
              sev = "warning";
              detail += " That is over 24 hours in transit — mail that old arrives stale, can trip time-based filters, and usually means a queue was stuck or a relay retried for a day or more. Investigate the slow hop before the next send.";
            } else {
              detail += " That is within the normal under-24-hours range.";
            }
          } else if (times.length === 1) {
            detail += " Only one Received timestamp could be parsed, so total transit time cannot be computed.";
          }
          if (unparsed > 0) {
            detail += " " + unparsed + " Received timestamp" + (unparsed === 1 ? " was" : "s were") + " NOT PARSED (reported, never guessed) and excluded from the transit arithmetic.";
            if (sev === "pass") { sev = "info"; }
          }
          add(sev, "Received chain — " + received.length + " hop" + (received.length === 1 ? "" : "s"), detail, null);
        }

        /* List-Unsubscribe / bulk signals */
        var precedenceRec = getFirst(records, "precedence");
        var listIdRec = getFirst(records, "list-id");
        var listUnsubRec = getFirst(records, "list-unsubscribe");
        var bulkPrecedence = precedenceRec && /\b(bulk|list)\b/i.test(precedenceRec.value);
        var bulkLooking = !!(bulkPrecedence || listIdRec);
        if (bulkLooking && !listUnsubRec) {
          add("warning", "Bulk message without List-Unsubscribe",
            "This message looks like bulk/list mail (" +
            (bulkPrecedence ? "Precedence: " + precedenceRec.value : "") +
            (bulkPrecedence && listIdRec ? "; " : "") +
            (listIdRec ? "List-Id present" : "") +
            ") but carries no List-Unsubscribe header. Gmail and Yahoo require bulk senders to offer one-click unsubscribe (a List-Unsubscribe header with an https URL, backed by List-Unsubscribe-Post), and receivers increasingly bulk-folder or reject senders without it. Readers who cannot unsubscribe in one click hit \"Report spam\" instead — which damages the sending domain's reputation far more." +
            (listIdRec ? " Note: a List-Id without a List-Unsubscribe identifies the list but gives the reader no way off it." : ""),
            listIdRec ? quoteOf(listIdRec) : (precedenceRec ? quoteOf(precedenceRec) : null));
        } else if (listUnsubRec) {
          add("pass", "List-Unsubscribe present",
            "A List-Unsubscribe header is present, so readers get the one-click unsubscribe path bulk senders are expected to provide.",
            quoteOf(listUnsubRec));
        }

        /* Subject */
        var subjRec = getFirst(records, "subject");
        if (!subjRec || subjRec.value.trim() === "") {
          add("info", "Empty or missing Subject",
            "An empty subject is an INFO-level issue only: the message can still deliver, but empty subjects read as careless or machine-generated and depress opens. This audit never fails a message on subject alone.", subjRec ? quoteOf(subjRec) : null);
        } else {
          var letters = subjRec.value.replace(/[^A-Za-z]/g, "");
          var upper = subjRec.value.replace(/[^A-Z]/g, "").length;
          if (letters.length >= 8 && upper / letters.length > 0.7) {
            add("info", "Subject in excessive caps",
              "More than 70% of the letters in the Subject are capitals. Shouting subjects are a classic spam-filter nudge and hurt opens — but on their own they are an INFO-level signal here, never a failure.", quoteOf(subjRec));
          } else {
            add("pass", "Subject looks normal", "Subject: " + redact(subjRec.value), null);
          }
        }

        /* Spam headers */
        var spamFlagRec = getFirst(records, "x-spam-flag");
        if (spamFlagRec && /^\s*yes\b/i.test(spamFlagRec.value)) {
          add("blocker", "X-Spam-Flag: YES",
            "A spam filter on the receiving side has already flagged this exact message as spam. Whatever else the headers say, a recorded YES means this delivery landed (or would land) in the spam folder.", quoteOf(spamFlagRec));
        }
        var spamStatusRec = getFirst(records, "x-spam-status");
        if (spamStatusRec) {
          var scoreM = spamStatusRec.value.match(/score\s*=\s*([0-9]+(?:\.[0-9]+)?)/i);
          var reqM = spamStatusRec.value.match(/required\s*=\s*([0-9]+(?:\.[0-9]+)?)/i);
          if (scoreM && reqM) {
            var score = parseFloat(scoreM[1]), required = parseFloat(reqM[1]);
            if (score >= required) {
              add("blocker", "Spam score at/above the required threshold",
                "X-Spam-Status records score=" + scoreM[1] + " against required=" + reqM[1] + ". At or above the stated threshold, the filtering server classifies the message as spam.", quoteOf(spamStatusRec));
            } else {
              add("pass", "Spam score below threshold",
                "X-Spam-Status records score=" + scoreM[1] + " against required=" + reqM[1] + " — below the spam threshold.", quoteOf(spamStatusRec));
            }
          }
        }

        return findings;
      }

      function verdictOf(findings) {
        var blockers = 0, warnings = 0;
        findings.forEach(function (f) {
          if (f.sev === "blocker") { blockers++; }
          if (f.sev === "warning") { warnings++; }
        });
        if (blockers > 0) {
          return { key: "fail", text: "WILL FAIL OR LAND IN SPAM",
            sub: blockers + " blocker" + (blockers === 1 ? "" : "s") + (warnings ? " and " + warnings + " warning" + (warnings === 1 ? "" : "s") : "") + " found. Fix the blockers before sending again — as recorded, this message fails authentication or has already been flagged as spam." };
        }
        if (warnings > 0) {
          return { key: "fix", text: "DELIVER WITH FIXES",
            sub: "No hard blockers, but " + warnings + " warning" + (warnings === 1 ? "" : "s") + " to fix. The message can deliver, yet each warning is a real spam-folder or rejection risk on the next send." };
        }
        return { key: "ok", text: "DELIVERABLE",
          sub: "No blockers and no warnings in the recorded headers. Authentication passed as recorded, the domains align, and the deliverability signals are clean." };
      }

      /* ---------- rendering ---------- */

      var SEV_LABEL = { blocker: "BLOCKER", warning: "WARNING", info: "INFO", pass: "PASS" };
      var SEV_ORDER = { blocker: 0, warning: 1, info: 2, pass: 3 };

      function escapeHtml(s) {
        return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
      }

      function buildReport(findings, verdict) {
        var lines = [];
        lines.push("J-Dawgs Email Header & Deliverability Pre-Flight Auditor™ — audit report");
        lines.push("Verdict: " + verdict.text);
        lines.push(verdict.sub);
        lines.push("");
        findings.slice().sort(function (a, b) { return SEV_ORDER[a.sev] - SEV_ORDER[b.sev]; }).forEach(function (f) {
          lines.push("[" + SEV_LABEL[f.sev] + "] " + f.title);
          lines.push("  " + f.detail);
          if (f.quote) { lines.push("  Deciding header: " + f.quote.replace(/\n/g, "\n  ")); }
          lines.push("");
        });
        lines.push("Scope: graded from the recorded headers only. No DNS lookups, no sending, no cryptographic signature verification.");
        return lines.join("\n");
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "FLAWED_EXAMPLE": (typeof FLAWED_EXAMPLE !== 'undefined' ? FLAWED_EXAMPLE : undefined), "CLEAN_EXAMPLE": (typeof CLEAN_EXAMPLE !== 'undefined' ? CLEAN_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-email-header-deliverability-auditor',
  name: 'J-Dawgs Email Header & Deliverability Pre-Flight Auditor',
  description: 'Live mail testers grade one test delivery; this audits the headers of a message you already hold — SPF/DKIM/DMARC results, alignment, spam flags — before the next send.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "FLAWED_EXAMPLE": __core["FLAWED_EXAMPLE"], "CLEAN_EXAMPLE": __core["CLEAN_EXAMPLE"] }
};
