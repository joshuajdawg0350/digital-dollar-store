'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Screenshot & Screen-Share Leakage Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var LEAKY = [
          "Tab: Project Nightjar \u2014 Internal Roadmap (confidential)",
          "Slack #eng-alerts: deploy finished, staging is green",
          "Deploy log: API key: sk-fake7X9Q2mZ8pL4vN6bR3tY1wZ5",
          "Mail preview: Dana \u2014 reach me at dana.fake@example.com",
          "Admin dashboard open at http://192.168.1.42:8080/internal-admin",
          "File saved to /Users/danafake/Documents/payroll-q4.xlsx",
          "Notification \u2014 Venmo: You received a payment from Marcus"
        ].join("\n");

        var CLEAN = [
          "Tab: Weather in Springfield \u2014 weekend forecast",
          "Headline: City park cleanup draws a crowd on Saturday",
          "Photo caption: Volunteers planting flowers by the main gate",
          "Footer: Shared from the public events page"
        ].join("\n");

        var AUDIENCE_NAMES = { public: "Public", team: "Team", client: "Private client" };
        var audience = "public";

        var input = document.getElementById("inputText");
        var gutter = document.getElementById("gutter");
        var resultsBody = document.getElementById("resultsBody");
        var checklistBody = document.getElementById("checklistBody");
        var reportText = document.getElementById("reportText");
        var checklistFallback = document.getElementById("checklistFallback");
        var statusLine = document.getElementById("statusLine");
        var copyStatus = document.getElementById("copyStatus");
        var pitchStatus = document.getElementById("pitchStatus");

        document.getElementById("leakySample").textContent = LEAKY;
        document.getElementById("cleanSample").textContent = CLEAN;

        /* ---------- masking helpers ---------- */
        function maskSecret(v) {
          if (!v) return "\u2022\u2022\u2022\u2022";
          return v.slice(0, 2) + "\u2022\u2022\u2022\u2022";
        }
        function maskEmail(e) {
          var at = e.indexOf("@");
          if (at < 1) return "\u2022\u2022\u2022@\u2022\u2022\u2022";
          return e.slice(0, Math.min(2, at)) + "\u2022\u2022\u2022" + e.slice(at);
        }
        function maskPhone(p) {
          var digits = p.replace(/\D/g, "");
          var tail = digits.slice(-2);
          return "\u2022\u2022\u2022-\u2022\u2022\u2022-\u2022\u2022" + tail;
        }
        function maskHost(host) {
          var ip = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(host);
          if (ip) return ip[1] + ".\u2022\u2022\u2022.\u2022\u2022\u2022.\u2022\u2022\u2022";
          var parts = host.split(".");
          if (parts.length > 1) return parts[0] + ".\u2022\u2022\u2022." + parts[parts.length - 1];
          return host;
        }
        function maskPath(p) {
          return p.replace(/(\/Users\/|\/home\/|\\Users\\)(.)[^\/\\\s]*/i, function (m, pre, first) {
            return pre + first + "\u2022\u2022\u2022";
          });
        }

        /* ---------- detection patterns (original heuristics) ---------- */
        var SECRET_LABEL = /(api[\s_-]?key|access[\s_-]?token|auth[\s_-]?token|session[\s_-]?token|secret|password|passwd|private[\s_-]?key|bearer)\s*[:=]\s*["']?([^\s"']{4,})/gi;
        var SECRET_PREFIX = /\b(sk-[A-Za-z0-9_-]{8,}|sk_live_[A-Za-z0-9]{8,}|sk_test_[A-Za-z0-9]{8,}|ghp_[A-Za-z0-9]{8,}|gho_[A-Za-z0-9]{8,}|github_pat_[A-Za-z0-9_]{8,}|AKIA[A-Z0-9]{12,}|xox[baprs]-[A-Za-z0-9-]{8,}|AIza[A-Za-z0-9_-]{10,}|eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{6,})/g;
        var EMAIL_RE = /[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g;
        var PHONE_RE = /(\+?1[\s.\-]?)?\(?\d{3}\)?[\s.\-]\d{3}[\s.\-]\d{4}\b/g;
        var URL_RE = /https?:\/\/[^\s)"'<>]+/gi;
        var BARE_IP_RE = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/g;
        var PATH_RE = /(\/Users\/[^\s"'<>]+|\/home\/[^\s"'<>]+|[A-Za-z]:\\Users\\[^\s"'<>]+)/g;
        var PAYMENT_KW = /\b(payment|paid you|invoice|venmo|paypal|cash app|salary|paycheck|wire transfer|bank account|refund|billing|credit card|debit card)\b/i;
        var HEALTH_KW = /\b(doctor|appointment|prescription|diagnosis|clinic|therapy|lab results?|blood pressure|medication|hospital|pharmacy|vaccine)\b/i;
        var NOTIF_CTX = /\b(notification|preview|slack|messages|message|whatsapp|telegram|signal|imessage|chat|alert|banner)\b/i;
        var TAB_CTX = /\btab\b/i;
        var TAB_INTERNAL = /\b(internal|confidential|roadmap|unreleased|sprint|backlog)\b|\bproject\s+[A-Z][\w-]*/i;

        function isPrivateHost(host) {
          host = host.toLowerCase();
          if (host === "localhost" || host === "127.0.0.1" || host === "::1") return true;
          if (/\.(local|internal|corp|lan|home|intranet)$/.test(host)) return true;
          if (host.indexOf("intranet") !== -1 || host.indexOf("internal") !== -1) return true;
          var ip = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(host);
          if (ip) {
            var a = parseInt(ip[1], 10), b = parseInt(ip[2], 10);
            if (a === 10 || a === 127) return true;
            if (a === 192 && b === 168) return true;
            if (a === 172 && b >= 16 && b <= 31) return true;
            if (a === 169 && b === 254) return true;
          }
          return false;
        }
        function isAnyIp(host) {
          return /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(host);
        }

        /* ---------- audit engine ---------- */
        function audit(text, aud) {
          var lines = text.split(/\r?\n/);
          var findings = [];

          function add(f) {
            var sev = f.base;
            var escalated = false;
            if (aud === "public" && sev === "WARNING") { sev = "BLOCKER"; escalated = true; }
            f.severity = sev;
            f.escalated = escalated;
            findings.push(f);
          }

          lines.forEach(function (line, idx) {
            var n = idx + 1;
            if (!line.trim()) return;
            var spans = []; // [start, end] regions already claimed on this line

            function claimed(s, e) {
              for (var i = 0; i < spans.length; i++) {
                if (s < spans[i][1] && e > spans[i][0]) return true;
              }
              return false;
            }

            var m, i;

            /* Secrets by label */
            SECRET_LABEL.lastIndex = 0;
            while ((m = SECRET_LABEL.exec(line)) !== null) {
              var valStart = m.index + m[0].length - m[2].length;
              spans.push([valStart, valStart + m[2].length]);
              add({
                line: n, kind: "secret", base: "BLOCKER",
                title: "Secret-shaped value (label: \u201C" + m[1].toLowerCase().replace(/\s+/g, " ") + "\u201D)",
                masked: maskSecret(m[2]),
                detail: "A credential is visible on screen. Anyone who sees this frame can copy it. Crop it out and rotate the credential \u2014 treat it as exposed.",
                action: "Crop or blur the credential on line " + n + ", then rotate it \u2014 it was visible on screen."
              });
            }

            /* Secrets by known prefix */
            SECRET_PREFIX.lastIndex = 0;
            while ((m = SECRET_PREFIX.exec(line)) !== null) {
              if (claimed(m.index, m.index + m[0].length)) continue;
              spans.push([m.index, m.index + m[0].length]);
              add({
                line: n, kind: "secret", base: "BLOCKER",
                title: "Secret-shaped value (key prefix \u201C" + m[0].slice(0, 3) + "\u2026\u201D)",
                masked: maskSecret(m[0]),
                detail: "This matches a well-known API-key / token prefix. Crop it out and rotate the credential \u2014 treat it as exposed.",
                action: "Crop or blur the key on line " + n + ", then rotate it \u2014 it was visible on screen."
              });
            }

            /* Emails */
            EMAIL_RE.lastIndex = 0;
            while ((m = EMAIL_RE.exec(line)) !== null) {
              add({
                line: n, kind: "email", base: "WARNING",
                title: "Email address",
                masked: maskEmail(m[0]),
                detail: "An email address is readable in the frame. It invites spam, phishing, and unwanted contact for whoever it belongs to.",
                action: "Blur the email address on line " + n + "."
              });
            }

            /* URLs: internal hosts and raw-IP hosts */
            var urlSpans = [];
            URL_RE.lastIndex = 0;
            while ((m = URL_RE.exec(line)) !== null) {
              urlSpans.push([m.index, m.index + m[0].length]);
              var hostMatch = /^https?:\/\/([^\/?#:]+)/i.exec(m[0]);
              if (!hostMatch) continue;
              var host = hostMatch[1];
              if (isPrivateHost(host)) {
                add({
                  line: n, kind: "internal-url", base: "WARNING",
                  title: "Private / internal URL",
                  masked: m[0].split("//")[0] + "//" + maskHost(host) + "/\u2026",
                  detail: "This address only resolves inside a private network. Sharing it maps your internal systems and invites probing.",
                  action: "Crop the internal address on line " + n + " \u2014 it maps your network."
                });
              } else if (isAnyIp(host)) {
                add({
                  line: n, kind: "internal-url", base: "WARNING",
                  title: "Raw IP address in URL",
                  masked: m[0].split("//")[0] + "//" + maskHost(host) + "/\u2026",
                  detail: "A bare IP address exposes a specific machine. Prefer a public name if one exists, or crop it.",
                  action: "Crop the IP-based address on line " + n + "."
                });
              }
            }

            /* Bare IPs outside URLs */
            BARE_IP_RE.lastIndex = 0;
            while ((m = BARE_IP_RE.exec(line)) !== null) {
              var inUrl = false;
              for (i = 0; i < urlSpans.length; i++) {
                if (m.index >= urlSpans[i][0] && m.index < urlSpans[i][1]) inUrl = true;
              }
              if (inUrl) continue;
              if (/^\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(line.slice(Math.max(0, m.index - 12), m.index))) continue;
              add({
                line: n, kind: "internal-url", base: "WARNING",
                title: isPrivateHost(m[0]) ? "Private IP address" : "IP address",
                masked: maskHost(m[0]),
                detail: "An IP address is visible. Private ranges reveal your network layout; any address pins down a specific machine.",
                action: "Crop the IP address on line " + n + "."
              });
            }

            /* Localhost mentions without a URL scheme */
            if (/\blocalhost\b/i.test(line) && !URL_RE.test(line)) {
              add({
                line: n, kind: "internal-url", base: "WARNING",
                title: "Localhost reference",
                masked: "localhost",
                detail: "A localhost reference signals a development machine and local services. Harmless alone, but it confirms the frame came from a workstation, not a public page.",
                action: "Crop the localhost reference on line " + n + " if this leaves your team."
              });
            }
            URL_RE.lastIndex = 0;

            /* Home-directory paths */
            PATH_RE.lastIndex = 0;
            while ((m = PATH_RE.exec(line)) !== null) {
              add({
                line: n, kind: "home-path", base: "WARNING",
                title: "File path through a home directory",
                masked: maskPath(m[0]),
                detail: "This path hands out a real username plus the folder structure under it \u2014 useful raw material for guessing other paths and accounts.",
                action: "Crop the file path on line " + n + " \u2014 it reveals a username and folder layout."
              });
            }

            /* Phone numbers */
            PHONE_RE.lastIndex = 0;
            while ((m = PHONE_RE.exec(line)) !== null) {
              if (claimed(m.index, m.index + m[0].length)) continue;
              add({
                line: n, kind: "phone", base: "WARNING",
                title: "Phone number",
                masked: maskPhone(m[0]),
                detail: "A phone number is readable in the frame. It follows a person everywhere \u2014 blur it unless they agreed to publish it.",
                action: "Blur the phone number on line " + n + "."
              });
            }

            /* Notification / chat previews with payment or health keywords */
            if (NOTIF_CTX.test(line)) {
              var cls = null;
              if (PAYMENT_KW.test(line)) cls = "payment";
              else if (HEALTH_KW.test(line)) cls = "health";
              if (cls) {
                add({
                  line: n, kind: "notification", base: "WARNING",
                  title: "Notification / chat preview \u2014 keyword class: " + cls,
                  masked: "keyword class: " + cls + " (content not quoted)",
                  detail: "A preview line mentions a " + cls + " topic. Previews are written for the device owner, not for whoever receives the screenshot. Dismiss notifications before capturing.",
                  action: "Dismiss or crop the " + cls + " notification preview on line " + n + " before capturing."
                });
              }
            }

            /* Internal project tab titles (heuristic) */
            if (TAB_CTX.test(line) && TAB_INTERNAL.test(line)) {
              add({
                line: n, kind: "tab-title", base: "REVIEW",
                title: "Tab title may name an internal project (heuristic)",
                masked: "tab title (not quoted)",
                detail: "This is a heuristic guess, not a certainty: the tab title appears to reference an internal or confidential project. If it does, close the tab or crop the tab bar.",
                action: "Check the tab on line " + n + ": close it or crop the tab bar if it names internal work."
              });
            }
          });

          var sevRank = { BLOCKER: 0, WARNING: 1, REVIEW: 2 };
          findings.sort(function (a, b) {
            if (sevRank[a.severity] !== sevRank[b.severity]) return sevRank[a.severity] - sevRank[b.severity];
            return a.line - b.line;
          });

          var counts = { BLOCKER: 0, WARNING: 0, REVIEW: 0 };
          findings.forEach(function (f) { counts[f.severity]++; });

          var verdict, verdictClass, verdictWhy;
          if (counts.BLOCKER > 0) {
            verdict = "DO NOT SHARE"; verdictClass = "do-not";
            verdictWhy = "Blockers are present for a " + AUDIENCE_NAMES[aud] + " audience. Fix every blocker, re-capture, and audit again before this frame goes anywhere.";
          } else if (counts.WARNING > 0 || counts.REVIEW > 0) {
            verdict = "SHARE AFTER REDACTIONS"; verdictClass = "after";
            verdictWhy = "Nothing here is an outright blocker for a " + AUDIENCE_NAMES[aud] + " audience, but the items below should be removed or checked first.";
          } else {
            verdict = "SAFE TO SHARE"; verdictClass = "safe";
            verdictWhy = "No leaks found in the pasted text for a " + AUDIENCE_NAMES[aud] + " audience. Remember: this grades only the text you pasted \u2014 pixels the text doesn\u2019t mention were never checked.";
          }
          return { findings: findings, counts: counts, verdict: verdict, verdictClass: verdictClass, verdictWhy: verdictWhy };
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-screenshot-share-leakage-auditor',
  name: 'J-Dawgs Screenshot & Screen-Share Leakage Auditor',
  description: 'Viewers show what is in a screenshot; ours grades the pasted OCR/description text for leaks before sharing (masked secrets, emails, internal URLs, home paths) with audience escalation, into one share verdict plus a redaction checklist. It does not process images or do OCR — it grades the pasted text',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
