'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Graylog Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

var RISKY_EXAMPLE = [
"# Graylog server.conf - risky worked example (do not deploy)",
"is_master = false",
"http_bind_address = 0.0.0.0:9000",
"#http_enable_tls = true",
"http_publish_uri = http://logs.example.internal:9000/",
"password_secret = short123",
"root_password_sha2 = 8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918",
"mongodb_uri = mongodb://admin:Sup3rMongoSecret99@10.0.0.5:27017/graylog",
"elasticsearch_hosts = http://elastic:ElasticPassw0rd77@10.0.0.6:9200",
"allow_leading_wildcard_searches = true",
"allow_highlighting = true",
"message_journal_enabled = false",
"this line is not a setting at all"
].join("\n");

var HARDENED_EXAMPLE = [
"# Graylog server.conf - hardened worked example",
"is_master = true",
"http_bind_address = 127.0.0.1:9000",
"http_enable_tls = true",
"http_publish_uri = https://logs.example.com/",
"password_secret = kX9f2mQ7vL4pR8sT1wY6zA3bN5cD0eFh",
"root_password_sha2 = 3f9a1c7e5b2d8046f1a9c3e57b2d6084a7c9e1f35b7d902468ace02468bdf135",
"mongodb_uri = mongodb://127.0.0.1:27017/graylog",
"elasticsearch_hosts = https://127.0.0.1:9200",
"allow_leading_wildcard_searches = false",
"allow_highlighting = false",
"message_journal_enabled = true",
"rotation_strategy = time",
"retention_strategy = delete",
"elasticsearch_max_number_of_indices = 20"
].join("\n");

var KNOWN_KEYS = {};
["is_master","http_bind_address","http_enable_tls","http_enable_cors","http_publish_uri","http_external_uri",
"tls_key_file","tls_cert_file","tls_key_password","password_secret","root_username","root_password_sha2","root_email",
"mongodb_uri","mongodb_max_connections","mongodb_threads_allowed_to_block_multiplier",
"elasticsearch_hosts","elasticsearch_connect_timeout","elasticsearch_socket_timeout","elasticsearch_max_total_connections",
"elasticsearch_max_total_connections_per_route","elasticsearch_max_retries","elasticsearch_index_prefix","elasticsearch_analyzer",
"elasticsearch_shards","elasticsearch_replicas","elasticsearch_index_field_types_enabled",
"elasticsearch_max_time_per_index","elasticsearch_max_docs_per_index","elasticsearch_max_number_of_indices",
"elasticsearch_max_size_per_index","elasticsearch_warmup_timeout","elasticsearch_request_timeout","elasticsearch_output_fault_tolerance",
"elasticsearch_output_batch_size","elasticsearch_output_flush_empty","elasticsearch_disable_version_check","elasticsearch_version_probe_attempts",
"allow_leading_wildcard_searches","allow_highlighting","message_journal_enabled","message_journal_dir","message_journal_max_age",
"message_journal_max_size","message_journal_flush_age","message_journal_flush_interval","message_journal_segment_age",
"message_journal_segment_size","rotation_strategy","retention_strategy","node_id_file","plugin_dir","data_dir",
"rest_listen_uri","web_listen_uri","web_endpoint_uri","web_enable_cors","rest_enable_cors","rest_transport_uri",
"output_batch_size","output_flush_interval","processbuffer_processors","outputbuffer_processors","inputbuffer_processors",
"ring_size","inputbuffer_ring_size","journal_max_age","journal_max_size","content_packs_loader_enabled",
"content_packs_dir","proxied_requests_thread_pool_size","http_thread_pool_size","http_max_initial_line_length",
"http_max_header_size","http_max_chunk_size","http_idle_timeout","stream_aware_message_compression_enabled",
"disable_sigar","exit_code","daemon","version","elasticsearch_template_name","elasticsearch_rotate_after_empty"
].forEach(function(k){ KNOWN_KEYS[k]=true; });

var KNOWN_ROOT_HASHES = {
  "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855": "the SHA-256 of an empty string",
  "8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918": "the widely published SHA-256 of a one-word password",
  "5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8": "the widely published SHA-256 of a common dictionary password",
  "0000000000000000000000000000000000000000000000000000000000000000": "an all-zeros placeholder"
};

function isSensitiveKey(key){
  return key === "password_secret" || key === "root_password_sha2" || key === "mongodb_uri" ||
         key === "elasticsearch_hosts" || key === "tls_key_password" ||
         /password|secret|token|credential/.test(key);
}
function extractUriPasswords(value){
  // Passwords only — usernames are not secret values, and redacting a short
  // common word like "admin" would mangle ordinary words in the report.
  var out = [], re = /:\/\/([^:\/@\s]+):([^@\/\s]+)@/g, m;
  while((m = re.exec(value)) !== null){ out.push(m[2]); }
  return out;
}
function hasEmbeddedCredentials(value){
  return /:\/\/[^:\/@\s]+:[^@\/\s]+@/.test(value) || /^[^:\/@\s]+:[^@\/\s]+@/.test(value);
}

var SEV_RANK = {CRITICAL:0, HIGH:1, MEDIUM:2, LOW:3, INFO:4, PASS:5};

function audit(text){
  var findings = [];
  var active = {};       // key -> {value, line}
  var activeOrder = [];
  var sensitiveValues = [];
  var lines = String(text == null ? "" : text).split(/\r?\n/);
  var parsedCount = 0, recognizedCount = 0, commentedCount = 0, notParsedCount = 0, nonEmpty = 0;

  function add(sev, line, key, status, message, valueLength){
    var f = {severity: sev, line: (typeof line === "number" ? line : null), key: key || null,
             status: status || null, message: message};
    if(typeof valueLength === "number") f.valueLength = valueLength;
    findings.push(f);
  }

  for(var i = 0; i < lines.length; i++){
    var lineNo = i + 1;
    var raw = lines[i];
    var trimmed = raw.trim();
    if(trimmed === "") continue;
    nonEmpty++;
    if(trimmed.charAt(0) === "#" || trimmed.charAt(0) === ";"){
      commentedCount++;
      var cbody = trimmed.replace(/^[#;]\s*/, "");
      var ceq = cbody.indexOf("=");
      var ckey = ceq > 0 ? cbody.substring(0, ceq).trim() : null;
      if(ckey && /^[A-Za-z0-9_.-]+$/.test(ckey)){
        add("INFO", lineNo, ckey, "COMMENTED / NOT ACTIVE",
          "Commented-out setting — COMMENTED / NOT ACTIVE. It is not graded as an active setting and does not change any other finding.");
      } else {
        add("INFO", lineNo, null, "COMMENTED / NOT ACTIVE",
          "Comment line — COMMENTED / NOT ACTIVE. It is not graded as an active setting.");
      }
      continue;
    }
    var eq = trimmed.indexOf("=");
    if(eq <= 0){
      notParsedCount++;
      add("INFO", lineNo, null, "NOT PARSED",
        "NOT PARSED — this line is not a key = value setting, so it was not graded.");
      continue;
    }
    var key = trimmed.substring(0, eq).trim();
    var value = trimmed.substring(eq + 1).trim();
    // Strip surrounding quotes for value checks (length is reported on the raw value as pasted).
    var unquoted = value;
    if(unquoted.length >= 2 && ((unquoted.charAt(0) === '"' && unquoted.charAt(unquoted.length-1) === '"') ||
        (unquoted.charAt(0) === "'" && unquoted.charAt(unquoted.length-1) === "'"))){
      unquoted = unquoted.substring(1, unquoted.length - 1);
    }
    if(!/^[A-Za-z0-9_.-]+$/.test(key)){
      notParsedCount++;
      add("INFO", lineNo, null, "NOT PARSED",
        "NOT PARSED — the text before '=' is not a valid setting name, so this line was not graded.");
      continue;
    }
    parsedCount++;
    if(KNOWN_KEYS[key]) recognizedCount++;
    if(!active[key]) activeOrder.push(key);
    active[key] = {value: unquoted, rawValue: value, line: lineNo};
    if(isSensitiveKey(key) && unquoted.length >= 3){
      sensitiveValues.push(unquoted);
      extractUriPasswords(unquoted).forEach(function(p){ if(p.length >= 3) sensitiveValues.push(p); });
    }
    if(!KNOWN_KEYS[key]){
      add("INFO", lineNo, key, "UNRECOGNIZED KEY",
        "This setting name is not one this auditor grades. It was recorded as present but given no safety grade.");
    }
  }

  // Not enough to grade: empty, prose, or almost nothing recognizable as Graylog settings.
  if(nonEmpty === 0 || parsedCount === 0 || recognizedCount < 2){
    add("INFO", null, null, "NOT ENOUGH TO GRADE",
      "Not enough recognizable Graylog server.conf settings were found to grade this text. Paste key = value lines from a server.conf (at least a couple of recognized settings) and audit again.");
    findings.sort(sortFindings);
    return finish("NOT ENOUGH TO GRADE", findings, {parsed: parsedCount, recognized: recognizedCount,
      commented: commentedCount, notParsed: notParsedCount}, sensitiveValues);
  }

  function get(k){ return active[k] || null; }
  function lower(k){ var e = get(k); return e ? e.value.toLowerCase() : null; }

  // --- is_master posture ---
  var im = get("is_master");
  if(!im){
    add("MEDIUM", null, "is_master", "MISSING",
      "is_master is not set in the active config. Master election posture is left to defaults — set it explicitly on every node.");
  } else if(lower("is_master") === "false"){
    add("HIGH", im.line, "is_master", "FAIL",
      "is_master is false. If every node says false, no node runs master-only jobs (index cycling, scheduling, cleanup). A single-node deploy should be true; a cluster needs at least one true.");
  } else if(lower("is_master") === "true"){
    add("PASS", im.line, "is_master", "PASS",
      "is_master is true — this node can run master-only jobs.");
  } else {
    add("MEDIUM", im.line, "is_master", "UNRECOGNIZED VALUE",
      "is_master is set to something other than true or false, so its posture could not be confirmed.");
  }

  // --- Bind address + TLS ---
  var bind = get("http_bind_address");
  var tls = get("http_enable_tls");
  var tlsOn = tls ? (tls.value.toLowerCase() === "true") : false;
  var bindHost = null, bindAll = false, bindLocal = false;
  if(bind){
    var bv = bind.value;
    var ci = bv.lastIndexOf(":");
    bindHost = ci > 0 ? bv.substring(0, ci) : bv;
    if(bindHost === "0.0.0.0" || bindHost === "::" || bindHost === "[::]" || bindHost === "" || bindHost === "*") bindAll = true;
    if(bindHost === "127.0.0.1" || bindHost === "localhost" || bindHost === "::1" || bindHost === "[::1]") bindLocal = true;
  }
  if(!bind){
    add("LOW", null, "http_bind_address", "MISSING",
      "http_bind_address is not set, so the bind posture relies on the built-in default. Set it explicitly so the exposure is a decision, not a default.");
  } else if(bindAll && !tlsOn){
    add("CRITICAL", bind.line, "http_bind_address", "FAIL",
      "http_bind_address binds all interfaces (0.0.0.0) and TLS is not active (http_enable_tls is " + (tls ? "set to false" : "not set in the active config") + "). The web interface and REST API are reachable from the network in plaintext. Bind to a specific or loopback address, or enable TLS — ideally both.");
  } else if(bindAll && tlsOn){
    add("MEDIUM", bind.line, "http_bind_address", "CHECK",
      "http_bind_address binds all interfaces (0.0.0.0) with TLS on. That can be right behind a firewall or load balancer, but confirm the port is not reachable from untrusted networks.");
  } else if(!bindLocal && !tlsOn){
    add("HIGH", bind.line, "http_bind_address", "FAIL",
      "http_bind_address is bound to a non-loopback address and TLS is not active, so traffic to the web interface and REST API is plaintext. Enable TLS or bind to loopback behind a TLS-terminating proxy.");
  } else {
    add("PASS", bind.line, "http_bind_address", "PASS",
      bindLocal ? "http_bind_address is loopback-only, so the interface is not exposed to the network directly."
                : "http_bind_address is set and TLS is active.");
  }
  if(tls && tls.value.toLowerCase() === "false" && bind && bindLocal){
    add("LOW", tls.line, "http_enable_tls", "CHECK",
      "http_enable_tls is false. Acceptable only because the bind address is loopback — if the bind address ever widens, this becomes a plaintext exposure.");
  }

  // --- Publish URI ---
  var pub = get("http_publish_uri") || get("http_external_uri");
  if(pub){
    var pv = pub.value.toLowerCase();
    if(pv.indexOf("http://") === 0){
      add("HIGH", pub.line, pub === get("http_publish_uri") ? "http_publish_uri" : "http_external_uri", "FAIL",
        "The published URI uses plaintext http://. Browsers and API clients are sent to an unencrypted address, and session traffic can be read or tampered with in transit. Publish an https:// URI.");
    } else if(pv.indexOf("https://") === 0){
      add("PASS", pub.line, "http_publish_uri", "PASS", "The published URI uses https://.");
    } else {
      add("LOW", pub.line, "http_publish_uri", "CHECK",
        "The published URI does not start with http:// or https://, so its scheme could not be confirmed.");
    }
  } else {
    add("LOW", null, "http_publish_uri", "MISSING",
      "http_publish_uri is not set. Graylog will derive the published address from the bind address, which can leak an internal address or a plaintext scheme into links and redirects.");
  }

  // --- password_secret ---
  var ps = get("password_secret");
  if(!ps){
    add("CRITICAL", null, "password_secret", "MISSING",
      "password_secret is missing. Graylog needs a long, random password_secret to sign session and API tokens — without one the deploy is not safe. Reported by key name only; there is no value to measure.");
  } else {
    var psLow = ps.value.toLowerCase();
    var psExample = /(example|change[-_ ]?me|please|insert|your[-_]|todo|replace|placeholder|xxxx)/.test(psLow) || psLow === "secret" || psLow === "password";
    if(psExample){
      add("CRITICAL", ps.line, "password_secret", "FAIL",
        "password_secret looks like an example or placeholder value, not a real secret. Anyone who has seen the sample config knows it. Replace it with a long random value. (Value never shown — length: " + ps.value.length + " characters.)",
        ps.value.length);
    } else if(ps.value.length < 16){
      add("CRITICAL", ps.line, "password_secret", "FAIL",
        "password_secret is too short — " + ps.value.length + " characters, under the 16-character minimum. Use a long random value (32+ characters is a sane target). (Value never shown.)",
        ps.value.length);
    } else {
      add("PASS", ps.line, "password_secret", "PASS",
        "password_secret is present at " + ps.value.length + " characters and is not a known example value. (Value never shown.)",
        ps.value.length);
    }
  }

  // --- root_password_sha2 ---
  var rp = get("root_password_sha2");
  if(!rp){
    add("CRITICAL", null, "root_password_sha2", "MISSING",
      "root_password_sha2 is missing. The built-in admin account has no password hash set by this file, so admin access posture is undefined. Set a SHA-256 hash of a strong, unique admin password. Reported by key name only; there is no value to measure.");
  } else {
    var rpLow = rp.value.toLowerCase();
    var known = KNOWN_ROOT_HASHES[rpLow];
    var isHex64 = /^[0-9a-f]{64}$/.test(rpLow);
    var repeated = /^(.)\1+$/.test(rpLow);
    var rpExample = /(example|change|placeholder|insert|your[-_])/.test(rpLow);
    if(known){
      add("CRITICAL", rp.line, "root_password_sha2", "FAIL",
        "root_password_sha2 matches a known/example hash — " + known + ". Anyone can look that hash up and sign in as admin. Hash a strong, unique password instead. (Hash never shown — length: " + rp.value.length + " characters.)",
        rp.value.length);
    } else if(rpExample || repeated){
      add("CRITICAL", rp.line, "root_password_sha2", "FAIL",
        "root_password_sha2 looks like a placeholder rather than a real SHA-256 hash. Hash a strong, unique admin password instead. (Value never shown — length: " + rp.value.length + " characters.)",
        rp.value.length);
    } else if(!isHex64){
      add("HIGH", rp.line, "root_password_sha2", "FAIL",
        "root_password_sha2 is not a 64-character hexadecimal SHA-256 hash (length: " + rp.value.length + " characters). Graylog expects the SHA-256 hex digest of the admin password. (Value never shown.)",
        rp.value.length);
    } else {
      add("PASS", rp.line, "root_password_sha2", "PASS",
        "root_password_sha2 is present as a 64-character hex hash and is not a known/example hash. (Hash never shown.)",
        rp.value.length);
    }
  }

  // --- MongoDB credentials ---
  var mongo = get("mongodb_uri");
  if(!mongo){
    add("MEDIUM", null, "mongodb_uri", "MISSING",
      "mongodb_uri is not set in the active config, so the MongoDB connection posture cannot be checked from this file.");
  } else if(hasEmbeddedCredentials(mongo.value)){
    add("HIGH", mongo.line, "mongodb_uri", "FAIL",
      "mongodb_uri embeds plaintext connection credentials (a username and password inside the URI). Anyone who reads this file owns the database account. Prefer a secrets store or a restricted file, use a least-privilege database user, and enable TLS on the connection. (Value never shown — length: " + mongo.value.length + " characters.)",
      mongo.value.length);
  } else {
    add("PASS", mongo.line, "mongodb_uri", "PASS",
      "mongodb_uri carries no embedded username/password credentials. (Value not shown.)", mongo.value.length);
  }

  // --- Elasticsearch hosts ---
  var es = get("elasticsearch_hosts");
  if(!es){
    add("MEDIUM", null, "elasticsearch_hosts", "MISSING",
      "elasticsearch_hosts is not set in the active config, so the search-backend connection posture cannot be checked from this file.");
  } else {
    var esCreds = hasEmbeddedCredentials(es.value);
    var esPlain = /(^|,)\s*http:\/\//i.test(es.value) || es.value.toLowerCase().indexOf("http://") === 0;
    if(esCreds){
      add("HIGH", es.line, "elasticsearch_hosts", "FAIL",
        "elasticsearch_hosts embeds plaintext connection credentials (a username and password inside a host URI)" + (esPlain ? " over plaintext http://" : "") + ". Anyone who reads this file gets those credentials. Move them to a secrets store, use a least-privilege user, and prefer https:// hosts. (Value never shown — length: " + es.value.length + " characters.)",
        es.value.length);
    } else if(esPlain){
      add("MEDIUM", es.line, "elasticsearch_hosts", "CHECK",
        "elasticsearch_hosts uses plaintext http://. On a trusted private network or loopback that can be acceptable; across hosts it exposes search traffic. Prefer https:// where the backend supports it. (Value not shown.)",
        es.value.length);
    } else {
      add("PASS", es.line, "elasticsearch_hosts", "PASS",
        "elasticsearch_hosts carries no embedded credentials and does not use plaintext http://. (Value not shown.)", es.value.length);
    }
  }

  // --- Performance-risk switches ---
  var wl = get("allow_leading_wildcard_searches");
  if(wl && wl.value.toLowerCase() === "true"){
    add("MEDIUM", wl.line, "allow_leading_wildcard_searches", "RISK",
      "allow_leading_wildcard_searches is true. Leading-wildcard searches are the expensive kind — they scan far more of the index and can be used to bog the cluster down. Leave it false unless users genuinely need it.");
  } else if(wl){
    add("PASS", wl.line, "allow_leading_wildcard_searches", "PASS",
      "allow_leading_wildcard_searches is false — the expensive search pattern stays off.");
  }
  var hl = get("allow_highlighting");
  if(hl && hl.value.toLowerCase() === "true"){
    add("LOW", hl.line, "allow_highlighting", "RISK",
      "allow_highlighting is true. Search-term highlighting costs CPU on every result page and is a known performance drag on busy nodes. Keep it false unless the team relies on highlighted results.");
  } else if(hl){
    add("PASS", hl.line, "allow_highlighting", "PASS",
      "allow_highlighting is false — the highlighting performance cost stays off.");
  }

  // --- Message journal + retention posture ---
  var mj = get("message_journal_enabled");
  if(!mj){
    add("LOW", null, "message_journal_enabled", "MISSING",
      "message_journal_enabled is not set. The journal is what lets Graylog survive a restart or a backend hiccup without dropping messages — set it explicitly.");
  } else if(mj.value.toLowerCase() === "false"){
    add("MEDIUM", mj.line, "message_journal_enabled", "FAIL",
      "message_journal_enabled is false. With the journal off, messages in flight are lost if the node stops or the search backend stalls. Enable the journal on ingest nodes.");
  } else if(mj.value.toLowerCase() === "true"){
    add("PASS", mj.line, "message_journal_enabled", "PASS",
      "message_journal_enabled is true — in-flight messages are journaled to disk.");
  }
  var retentionKeys = ["rotation_strategy","retention_strategy","elasticsearch_max_number_of_indices",
    "elasticsearch_max_time_per_index","elasticsearch_max_docs_per_index","elasticsearch_max_size_per_index","message_journal_max_age"];
  var foundRetention = null, foundRetentionKey = null;
  for(var r = 0; r < retentionKeys.length; r++){ if(active[retentionKeys[r]]){ foundRetention = active[retentionKeys[r]]; foundRetentionKey = retentionKeys[r]; break; } }
  if(foundRetention){
    add("PASS", foundRetention.line, foundRetentionKey, "PASS",
      "A rotation / retention posture is present in the active config, so index growth has a stated limit. Confirm the numbers match your disk and your keep-history needs.");
  } else {
    add("LOW", null, "retention_strategy", "MISSING",
      "No index rotation / retention posture was found (no rotation_strategy, retention_strategy, or index count / age / size limit). Without one, indices grow until the disk decides for you.");
  }

  findings.sort(sortFindings);
  var counts = countSev(findings);
  var verdict;
  if(counts.CRITICAL > 0) verdict = "DO NOT DEPLOY";
  else if(counts.HIGH > 0 || counts.MEDIUM > 0) verdict = "DEPLOY WITH FIXES";
  else verdict = "SAFE TO DEPLOY";
  return finish(verdict, findings, {parsed: parsedCount, recognized: recognizedCount,
    commented: commentedCount, notParsed: notParsedCount}, sensitiveValues);
}

function sortFindings(a, b){
  var la = a.line === null ? 99999 : a.line, lb = b.line === null ? 99999 : b.line;
  if(la !== lb) return la - lb;
  return (SEV_RANK[a.severity] || 9) - (SEV_RANK[b.severity] || 9);
}
function countSev(findings){
  var c = {CRITICAL:0, HIGH:0, MEDIUM:0, LOW:0, INFO:0, PASS:0};
  findings.forEach(function(f){ if(c.hasOwnProperty(f.severity)) c[f.severity]++; });
  return c;
}
function redact(str, sensitiveValues){
  var out = String(str);
  // Longest first so full values are removed before their substrings.
  var vals = sensitiveValues.slice().sort(function(a,b){ return b.length - a.length; });
  vals.forEach(function(v){
    if(v && v.length >= 6){
      out = out.split(v).join("[redacted — value never shown]");
    }
  });
  return out;
}
function finish(verdict, findings, meta, sensitiveValues){
  var counts = countSev(findings);
  var reportLines = [];
  reportLines.push("J-Dawgs Graylog Server Config Safety Auditor — Report");
  reportLines.push("Verdict: " + verdict);
  reportLines.push("Findings: " + findings.length + " total — Critical " + counts.CRITICAL +
    " · High " + counts.HIGH + " · Medium " + counts.MEDIUM + " · Low " + counts.LOW +
    " · Info " + counts.INFO + " · Pass " + counts.PASS);
  reportLines.push("Active settings parsed: " + meta.parsed + " (" + meta.recognized + " recognized) · Commented lines: " +
    meta.commented + " · Not parsed lines: " + meta.notParsed);
  reportLines.push("Secret handling: findings name the key, the line, and the value length only. Secret values are never printed.");
  reportLines.push("");
  reportLines.push("Findings:");
  findings.forEach(function(f){
    var loc = f.line === null ? "Line — (not present in file)" : "Line " + f.line;
    var keyPart = f.key ? " · " + f.key : "";
    var statusPart = f.status ? " · " + f.status : "";
    var lenPart = (typeof f.valueLength === "number" && f.message.indexOf("length") === -1 && f.message.indexOf("characters") === -1) ? " · value length: " + f.valueLength + " characters" : "";
    reportLines.push("[" + f.severity + "] " + loc + keyPart + statusPart + " — " + f.message + lenPart);
  });
  reportLines.push("");
  reportLines.push("Scope: this report grades only the pasted config text. No server was contacted and nothing was uploaded or saved.");
  var report = redact(reportLines.join("\n"), sensitiveValues);

  var jsonObj = {
    tool: "J-Dawgs Graylog Server Config Safety Auditor",
    verdict: verdict,
    counts: {critical: counts.CRITICAL, high: counts.HIGH, medium: counts.MEDIUM, low: counts.LOW, info: counts.INFO, pass: counts.PASS},
    parsedActiveSettings: meta.parsed,
    recognizedSettings: meta.recognized,
    commentedLines: meta.commented,
    notParsedLines: meta.notParsed,
    secretHandling: "Findings report key name, line, and value length only. Secret values are never included.",
    findings: findings.map(function(f){
      var o = {severity: f.severity, line: f.line, key: f.key, status: f.status, message: f.message};
      if(typeof f.valueLength === "number") o.valueLength = f.valueLength;
      return o;
    })
  };
  var json = redact(JSON.stringify(jsonObj, null, 2), sensitiveValues);
  return {verdict: verdict, findings: findings, counts: counts, meta: meta, report: report, json: json};
}
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-graylog-server-config-safety-auditortm',
  name: 'J-Dawgs Graylog Server Config Safety Auditor',
  description: '',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
