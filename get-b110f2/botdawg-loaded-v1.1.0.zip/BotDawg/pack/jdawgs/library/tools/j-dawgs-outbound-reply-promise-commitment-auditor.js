'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Outbound Reply Promise & Commitment Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the analyze function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Exact copy-paste pitches (byte-exact; do not edit casually) ---------- */
      var PITCHES = {
        store: "AI Tool Store — browser tools built for AI agents, free tools included: https://muse.ai/s/ai-tool-store-xng6xkxwjkxl2xab/UoF72OkKI7j33Q2ITxmrZyIr4nv40QtYfj2AgESh_k8",
        exchange: "J-Dawgs Agent Exchange — the machine-readable catalog of every J-Dawgs tool: https://muse.ai/s/j-dawgs-agent-exchange-ih6xlnihzxdhxc/ZbleqxFHRE0NcswaBkyN13y9lLp5rPAgHTb6t8ii-PY",
        bundle: "Manifest, Rules, Reply Stack — audit the extension manifest, the database rules, and the outbound reply before any of them ship: the Browser Extension Manifest & Permission Auditor, the Firestore Security Rules Auditor, and the Outbound Reply Promise & Commitment Auditor."
      };

      /* ---------- Worked examples ---------- */
      var EXAMPLE_FACTS = "Refunds: full refund within 30 days of purchase\nShipping: replacement ships in 5-7 business days\nWarranty: 1 year parts only";
      var EXAMPLE_A_DRAFT = "We'll refund you in full. Your replacement will arrive within 2 days, guaranteed. We'll also upgrade you to the premium model free.";
      var EXAMPLE_B_DRAFT = "We'll refund you in full under our 30-day policy and ship your replacement within 5-7 business days.";

      /* ---------- Detection patterns ---------- */
      var MONEY_RE = /(refund|credit|discount|waiv|rebate|reimburs|money\s+back|\$\s?\d|\d+(?:\.\d+)?\s?%|\d+(?:\.\d+)?\s?percent)/i;
      var TIME_RE = /(within\s+\d|by\s+(monday|tuesday|wednesday|thursday|friday|saturday|sunday|tomorrow|tonight)|\b(monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b|\b(january|february|march|april|june|july|august|september|october|november|december)\b|tomorrow|tonight|arriv|deliver|ship|deadline|\beta\b|\d+(?:\.\d+)?\s*-?\s*(business\s+)?(days?|hours?|weeks?|months?|years?)\b)/i;
      var SCOPE_RE = /(replac|repair|warrant|upgrad|expedit|\bcover(s|ed|age)?\b|\bfree\b|exchange|brand[- ]new|on\s+us\b|send\s+you\s+a\s+new)/i;
      var CERT_RES = [
        /guaranteed/i, /guarantee/i, /definitely/i, /certainly/i, /absolutely/i,
        /will\s+arrive/i, /i\s+promise/i, /we\s+promise/i, /\bpromise[ds]?\b/i,
        /\bassure[ds]?\b/i, /no\s+doubt/i, /for\s+sure/i
      ];
      var STEMS = ["refund","credit","discount","waiv","rebate","reimburs","ship","deliver","arriv","replac","repair","warrant","upgrad","expedit","cover","fee","charge","price","premium","free","return","payment","exchange","policy"];
      var WEEKDAYS = ["monday","tuesday","wednesday","thursday","friday","saturday","sunday"];
      var MONTHS = ["january","february","march","april","june","july","august","september","october","november","december"];
      var WORD_NUMS = {one:1,two:2,three:3,four:4,five:5,six:6,seven:7,eight:8,nine:9,ten:10,eleven:11,twelve:12,fourteen:14,fifteen:15,twenty:20,thirty:30};

      function $(id) { return document.getElementById(id); }
      function esc(s) {
        return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
      }

      function classesOf(text) {
        var c = {};
        if (MONEY_RE.test(text)) c.money = true;
        if (TIME_RE.test(text)) c.time = true;
        if (SCOPE_RE.test(text)) c.scope = true;
        return c;
      }

      function stemsOf(text) {
        var t = " " + text.toLowerCase() + " ";
        var out = {};
        for (var i = 0; i < STEMS.length; i++) {
          if (new RegExp("\\b" + STEMS[i]).test(t)) out[STEMS[i]] = true;
        }
        if (/\d/.test(t) && /%|percent/.test(t) && /\boff\b/.test(t)) out.discount = true; /* "25% off" is a discount promise */
        return out;
      }

      function normalizeWordNums(t) {
        return t.replace(/\b(one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|fourteen|fifteen|twenty|thirty)\s+(business\s+)?(days?|hours?|weeks?|months?|years?)\b/g,
          function (m, w, b, u) { return WORD_NUMS[w] + " " + (b || "") + u; });
      }

      function familyOf(u) {
        u = u.toLowerCase();
        if (u.indexOf("hour") === 0) return "hours";
        if (u.indexOf("day") === 0) return "days";
        if (u.indexOf("week") === 0) return "weeks";
        if (u.indexOf("month") === 0) return "months";
        return "years";
      }

      function boundBefore(t, idx, matchText) {
        var pre = t.slice(Math.max(0, idx - 18), idx);
        if (/\b(within|up to|no more than|no later than|at most|max|under|before)\b/.test(pre)) return true;
        if (/^\d+(?:\.\d+)?\s*-\s*(business\s+)?(day|hour|week|month|year)/.test(matchText)) return true; /* "30-day window" phrasing */
        return false;
      }

      /* Extract numbers with unit families from a text (analysis copy only). */
      function extractNums(text) {
        var t = normalizeWordNums(text.toLowerCase());
        var nums = [];
        var m, i;
        var usdRe = /\$\s?(\d[\d,]*(?:\.\d{1,2})?)/g;
        while ((m = usdRe.exec(t)) !== null) {
          var v = parseFloat(m[1].replace(/,/g, ""));
          nums.push({ family: "usd", min: v, max: v, isRange: false, bound: boundBefore(t, m.index, m[0]), raw: m[0] });
        }
        var pctRe = /(\d+(?:\.\d+)?)\s?%|(\d+(?:\.\d+)?)\s?percent/g;
        while ((m = pctRe.exec(t)) !== null) {
          var pv = parseFloat(m[1] || m[2]);
          nums.push({ family: "pct", min: pv, max: pv, isRange: false, bound: boundBefore(t, m.index, m[0]), raw: m[0] });
        }
        var rangeRe = /(\d+(?:\.\d+)?)\s*(?:-|–|—|\bto\b)\s*(\d+(?:\.\d+)?)\s*(business\s+)?(days?|hours?|weeks?|months?|years?)\b/g;
        var ranges = [];
        while ((m = rangeRe.exec(t)) !== null) {
          ranges.push({ family: familyOf(m[4]), min: parseFloat(m[1]), max: parseFloat(m[2]), isRange: true, bound: false, raw: m[0] });
        }
        for (i = 0; i < ranges.length; i++) nums.push(ranges[i]);
        var work = t.replace(/(\d+(?:\.\d+)?)\s*(?:-|–|—|\bto\b)\s*(\d+(?:\.\d+)?)\s*(business\s+)?(days?|hours?|weeks?|months?|years?)\b/g, " ");
        var singleRe = /(\d+(?:\.\d+)?)\s*-?\s*(business\s+)?(days?|hours?|weeks?|months?|years?)\b/g;
        while ((m = singleRe.exec(work)) !== null) {
          var sv = parseFloat(m[1]);
          nums.push({ family: familyOf(m[3]), min: sv, max: sv, isRange: false, bound: boundBefore(work, m.index, m[0]), raw: m[0] });
        }
        return nums;
      }

      function parseFacts(raw) {
        var lines = raw.split(/\n+/);
        var facts = [];
        for (var i = 0; i < lines.length; i++) {
          var line = lines[i].trim();
          if (!line) continue;
          facts.push({ line: line, classes: classesOf(line), stems: stemsOf(line), nums: extractNums(line) });
        }
        return facts;
      }

      function splitUnits(draft) {
        var rawSentences = draft.replace(/\r/g, "").split(/(?<=[.!?])\s+|\n+/);
        var units = [];
        for (var i = 0; i < rawSentences.length; i++) {
          var s = rawSentences[i].trim();
          if (!s) continue;
          var parts = s.split(/\s+and\s+|;\s*/i);
          for (var j = 0; j < parts.length; j++) {
            var q = parts[j].trim();
            if (q) units.push(q);
          }
        }
        return units;
      }

      function certPhrases(text) {
        var found = [];
        for (var i = 0; i < CERT_RES.length; i++) {
          var m = text.match(CERT_RES[i]);
          if (m && found.indexOf(m[0].toLowerCase()) === -1) found.push(m[0].toLowerCase());
        }
        /* Drop phrases that are just a substring of a longer hit ("guarantee" inside "guaranteed"). */
        return found.filter(function (p) {
          return !found.some(function (q) { return q !== p && q.indexOf(p) !== -1; });
        });
      }

      function dateToken(text) {
        var t = text.toLowerCase();
        var i;
        for (i = 0; i < WEEKDAYS.length; i++) if (t.indexOf(WEEKDAYS[i]) !== -1) return WEEKDAYS[i];
        for (i = 0; i < MONTHS.length; i++) if (t.indexOf(MONTHS[i]) !== -1) return MONTHS[i];
        return null;
      }

      function numOk(d, f) {
        if (f.isRange) return d.min >= f.min && d.max <= f.max;
        if (f.bound) return d.max <= f.max;
        return d.min === f.min && d.max === f.max;
      }

      function classLabel(cls) {
        return { money: "Money", time: "Time", scope: "Scope", certainty: "Certainty" }[cls] || cls;
      }

      function gradeCommitment(cm, facts) {
        var scored = [];
        for (var i = 0; i < facts.length; i++) {
          var f = facts[i];
          var overlap = 0;
          for (var s in cm.stems) if (cm.stems[s] && f.stems[s]) overlap++;
          if (overlap > 0) scored.push({ f: f, overlap: overlap, inClass: f.classes[cm.cls] ? 1 : 0 });
        }
        scored.sort(function (a, b) { return (b.inClass - a.inClass) || (b.overlap - a.overlap); });

        if (!scored.length) {
          cm.grade = "NOT ON FILE";
          cm.note = "nofact";
          cm.evidence = "No fact on file covers this promise.";
          return cm;
        }
        var fact = scored[0].f;
        cm.factLine = fact.line;

        if (cm.cls === "scope") {
          cm.grade = "SUPPORTED";
          cm.evidence = "Covered by fact: “" + fact.line + "”";
          return cm;
        }

        var fams = cm.cls === "money" ? ["usd", "pct"] : ["hours", "days", "weeks", "months", "years"];
        var dNums = cm.nums.filter(function (n) { return fams.indexOf(n.family) !== -1; });
        var factNums = fact.nums.filter(function (n) { return fams.indexOf(n.family) !== -1; });

        if (cm.cls === "time") {
          var tok = dateToken(cm.text);
          if (tok && fact.line.toLowerCase().indexOf(tok) === -1) {
            cm.grade = "NOT ON FILE";
            cm.note = "date";
            cm.evidence = "The covering fact states a window, not “" + tok + "”: “" + fact.line + "”";
            return cm;
          }
        }

        if (!dNums.length) {
          cm.grade = "SUPPORTED";
          cm.evidence = "Covered by fact: “" + fact.line + "”";
          return cm;
        }

        var sawComparable = false;
        var notComparable = null;
        for (var k = 0; k < dNums.length; k++) {
          var d = dNums[k];
          var fNums = fact.nums.filter(function (n) { return n.family === d.family; });
          if (!fNums.length) { if (!notComparable) notComparable = d; continue; }
          sawComparable = true;
          var ok = false;
          for (var q = 0; q < fNums.length; q++) if (numOk(d, fNums[q])) { ok = true; break; }
          if (!ok) {
            cm.grade = "CONTRADICTED";
            cm.note = "numbers";
            cm.dRaw = d.raw;
            cm.fRaw = fNums[0].raw;
            cm.evidence = "Draft states “" + d.raw + "”; fact states “" + fNums[0].raw + "” — “" + fact.line + "”";
            return cm;
          }
        }
        if (!sawComparable) {
          if (factNums.length) {
            cm.grade = "NOT ON FILE";
            cm.note = "notcomparable";
            cm.dRaw = notComparable.raw;
            cm.fRaw = factNums[0].raw;
            cm.evidence = "NOT COMPARABLE: draft states “" + notComparable.raw + "”; the covering fact states “" + factNums[0].raw + "” — different units, so this number is not covered. Fact: “" + fact.line + "”";
          } else {
            cm.grade = "NOT ON FILE";
            cm.note = "nonum";
            cm.dRaw = dNums[0].raw;
            cm.evidence = "The covering fact states no " + (cm.cls === "money" ? "amount" : "window") + " for this: “" + fact.line + "”";
          }
          return cm;
        }
        cm.grade = "SUPPORTED";
        cm.evidence = "Covered by fact: “" + fact.line + "” (draft: " +
          dNums.map(function (n) { return n.raw; }).join(", ") + " · fact: " +
          factNums.map(function (n) { return n.raw; }).join(", ") + ")";
        return cm;
      }

      function analyze(draftText, facts) {
        var units = splitUnits(draftText);
        var commitments = [];
        var order = ["money", "time", "scope"];
        for (var i = 0; i < units.length; i++) {
          var u = units[i];
          var cls = classesOf(u);
          var stems = stemsOf(u);
          var nums = extractNums(u);
          for (var j = 0; j < order.length; j++) {
            if (cls[order[j]]) {
              commitments.push(gradeCommitment(
                { quote: u, text: u, cls: order[j], stems: stems, nums: nums }, facts));
            }
          }
          var certs = certPhrases(u);
          if (certs.length) {
            commitments.push({
              quote: u, text: u, cls: "certainty", grade: "TONE RISK", phrases: certs,
              evidence: "Certainty wording: " + certs.map(function (x) { return "“" + x + "”"; }).join(", ") +
                ". Tone risk only — the facts neither confirm nor deny the wording, but it raises the cost of being wrong."
            });
          }
        }
        return commitments;
      }

      function computeVerdict(commitments, facts) {
        var incomplete = facts.length === 0;
        var classOrder = ["money", "time", "scope"];
        for (var i = 0; i < classOrder.length; i++) {
          var c = classOrder[i];
          var hasCommit = commitments.some(function (x) { return x.cls === c; });
          var hasFact = facts.some(function (f) { return f.classes[c]; });
          if (hasCommit && !hasFact) incomplete = true;
        }
        var contrad = commitments.filter(function (x) { return x.grade === "CONTRADICTED"; }).length;
        var nofHard = commitments.filter(function (x) { return x.grade === "NOT ON FILE" && (x.cls === "money" || x.cls === "time"); }).length;
        var nofSoft = commitments.filter(function (x) { return x.grade === "NOT ON FILE" && x.cls === "scope"; }).length;
        var tone = commitments.filter(function (x) { return x.cls === "certainty"; }).length;
        var verdict = "SAFE TO SEND";
        if (contrad > 0 || nofHard > 0) verdict = "DO NOT SEND";
        else if (nofSoft > 0 || tone > 0) verdict = "SEND WITH FIXES";
        return { verdict: verdict, incomplete: incomplete, contrad: contrad, nofHard: nofHard, nofSoft: nofSoft, tone: tone };
      }

      function fixFor(cm) {
        var label = classLabel(cm.cls).toLowerCase();
        if (cm.grade === "CONTRADICTED") {
          return "Change the " + label + " promise in “" + cm.quote + "” — the draft states " + cm.dRaw +
            " but the facts on file state " + cm.fRaw + ". Make the draft match the fact, or correct the fact first if the fact is the wrong one.";
        }
        if (cm.grade === "NOT ON FILE") {
          if (cm.note === "notcomparable") {
            return "Fix the " + label + " promise in “" + cm.quote + "” — its number (" + cm.dRaw +
              ") is in units no fact states (" + cm.fRaw + "), so it cannot be checked or backed. Restate the promise in the units the facts use, or add a fact in those units.";
          }
          if (cm.note === "date") {
            return "Fix the " + label + " promise in “" + cm.quote + "” — it names a specific day or date that no fact on file backs. Drop the specific date or add a fact that covers it.";
          }
          if (cm.note === "nonum") {
            return "Fix the " + label + " promise in “" + cm.quote + "” — it states a number (" + cm.dRaw +
              ") that the covering fact never states. Remove the number, or add a fact that states it.";
          }
          return "Remove the " + label + " promise in “" + cm.quote +
            "”, or add a fact on file that covers it before sending — right now nothing on file backs it.";
        }
        if (cm.grade === "TONE RISK") {
          return "Soften the certainty wording in “" + cm.quote + "” (" +
            cm.phrases.map(function (x) { return "“" + x + "”"; }).join(", ") +
            ") — keep the promise only as strong as the facts behind it.";
        }
        return "";
      }

      function badgeClass(grade) {
        if (grade === "SUPPORTED") return "b-supported";
        if (grade === "CONTRADICTED") return "b-contradicted";
        if (grade === "NOT ON FILE") return "b-notonfile";
        return "b-tone";
      }

      function runAudit() {
        var factsRaw = $("facts").value;
        var draftRaw = $("draft").value;
        var note = $("run-note");
        if (!draftRaw.trim()) {
          note.textContent = "Paste a draft reply first — there is nothing to audit yet.";
          $("results").className = "";
          return;
        }
        note.textContent = "";
        var facts = parseFacts(factsRaw);
        var commitments = analyze(draftRaw, facts);
        var v = computeVerdict(commitments, facts);

        /* Verdict banner */
        var box = $("verdict-box");
        box.className = "verdict " + (v.verdict === "SAFE TO SEND" ? "safe" : v.verdict === "SEND WITH FIXES" ? "fixes" : "donot");
        $("verdict-text").textContent = v.verdict;
        var reason = "";
        if (v.verdict === "DO NOT SEND") {
          var parts = [];
          if (v.contrad) parts.push(v.contrad + " contradicted");
          if (v.nofHard) parts.push(v.nofHard + " not on file (money/time)");
          reason = "Unsupported promises present: " + parts.join(", ") + ". Do not send this draft as written.";
        } else if (v.verdict === "SEND WITH FIXES") {
          var p2 = [];
          if (v.nofSoft) p2.push(v.nofSoft + " scope promise(s) not on file");
          if (v.tone) p2.push(v.tone + " certainty flag(s)");
          reason = "Nothing here contradicts the record, but fix these first: " + p2.join(", ") + ".";
        } else {
          reason = commitments.length
            ? "Every commitment found is covered by a fact on file."
            : "No commitments were detected in the draft.";
        }
        if (v.incomplete && facts.length === 0) reason += " The facts box is empty, so no promise could be graded SUPPORTED.";
        else if (v.incomplete) reason += " At least one commitment class has no facts on file, so its promises were graded NOT ON FILE.";
        $("verdict-reason").textContent = reason;
        $("incomplete-badge").style.display = v.incomplete ? "inline-block" : "none";

        /* Counts */
        var classOrder = ["money", "time", "scope", "certainty"];
        var countsHtml = "";
        var totals = { n: 0, s: 0, c: 0, nof: 0, t: 0 };
        classOrder.forEach(function (c) {
          var rows = commitments.filter(function (x) { return x.cls === c; });
          var s = rows.filter(function (x) { return x.grade === "SUPPORTED"; }).length;
          var ct = rows.filter(function (x) { return x.grade === "CONTRADICTED"; }).length;
          var nf = rows.filter(function (x) { return x.grade === "NOT ON FILE"; }).length;
          var tn = rows.filter(function (x) { return x.grade === "TONE RISK"; }).length;
          totals.n += rows.length; totals.s += s; totals.c += ct; totals.nof += nf; totals.t += tn;
          countsHtml += "<tr><td data-label='Class'><span class='badge b-class'>" + classLabel(c).toUpperCase() + "</span></td>" +
            "<td data-label='Found'>" + rows.length + "</td><td data-label='Supported'>" + s + "</td>" +
            "<td data-label='Contradicted'>" + ct + "</td><td data-label='Not on file'>" + nf + "</td>" +
            "<td data-label='Tone risk'>" + tn + "</td></tr>";
        });
        countsHtml += "<tr><td data-label='Class'><strong>TOTAL</strong></td><td data-label='Found'><strong>" + totals.n +
          "</strong></td><td data-label='Supported'><strong>" + totals.s + "</strong></td><td data-label='Contradicted'><strong>" +
          totals.c + "</strong></td><td data-label='Not on file'><strong>" + totals.nof + "</strong></td><td data-label='Tone risk'><strong>" +
          totals.t + "</strong></td></tr>";
        $("counts-body").innerHTML = countsHtml;

        /* Commitment table */
        var html = "";
        commitments.forEach(function (cm) {
          html += "<tr><td class='quote' data-label='Draft quote'>“" + esc(cm.quote) + "”</td>" +
            "<td data-label='Class'><span class='badge b-class'>" + classLabel(cm.cls).toUpperCase() + "</span></td>" +
            "<td data-label='Grade'><span class='badge " + badgeClass(cm.grade) + "'>" + cm.grade + "</span></td>" +
            "<td data-label='Fact evidence'>" + esc(cm.evidence) + "</td></tr>";
        });
        $("commit-body").innerHTML = html;
        $("commit-table").style.display = commitments.length ? "" : "none";
        $("no-commits").style.display = commitments.length ? "none" : "block";

        /* Fix list */
        var fixes = [];
        commitments.forEach(function (cm) { if (cm.grade !== "SUPPORTED") fixes.push(fixFor(cm)); });
        $("fix-list").innerHTML = fixes.map(function (f) { return "<li>" + esc(f) + "</li>"; }).join("");
        $("fix-list").style.display = fixes.length ? "" : "none";
        $("no-fixes").style.display = fixes.length ? "none" : "block";

        /* Plain-text report */
        var lines = [];
        lines.push("J-DAWGS OUTBOUND REPLY PROMISE & COMMITMENT AUDITOR — REPORT");
        lines.push("Verdict: " + v.verdict + (v.incomplete ? " — FACTS INCOMPLETE" : ""));
        lines.push("Reason: " + reason);
        lines.push("");
        lines.push("COUNTS (class: found / supported / contradicted / not on file / tone risk)");
        classOrder.forEach(function (c) {
          var rows = commitments.filter(function (x) { return x.cls === c; });
          lines.push("- " + classLabel(c) + ": " + rows.length + " / " +
            rows.filter(function (x) { return x.grade === "SUPPORTED"; }).length + " / " +
            rows.filter(function (x) { return x.grade === "CONTRADICTED"; }).length + " / " +
            rows.filter(function (x) { return x.grade === "NOT ON FILE"; }).length + " / " +
            rows.filter(function (x) { return x.grade === "TONE RISK"; }).length);
        });
        lines.push("");
        lines.push("COMMITMENTS");
        if (!commitments.length) lines.push("- None detected.");
        commitments.forEach(function (cm, idx) {
          lines.push((idx + 1) + ". [" + classLabel(cm.cls) + " · " + cm.grade + "] “" + cm.quote + "”");
          lines.push("   Evidence: " + cm.evidence);
        });
        lines.push("");
        lines.push("FIX LIST");
        if (!fixes.length) lines.push("- Nothing to fix.");
        fixes.forEach(function (f, idx) { lines.push((idx + 1) + ". " + f); });
        lines.push("");
        lines.push("Limits: this report compares the draft only against the facts pasted at audit time. Heuristic reading — a clean verdict is not a guarantee. Nothing was sent or stored.");
        $("report").value = lines.join("\n");

        $("results").className = "show";
        $("results").scrollIntoView({ behavior: "smooth", block: "start" });
      }
  return { "analyze": (typeof analyze !== 'undefined' ? analyze : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_FACTS": (typeof EXAMPLE_FACTS !== 'undefined' ? EXAMPLE_FACTS : undefined), "EXAMPLE_A_DRAFT": (typeof EXAMPLE_A_DRAFT !== 'undefined' ? EXAMPLE_A_DRAFT : undefined), "EXAMPLE_B_DRAFT": (typeof EXAMPLE_B_DRAFT !== 'undefined' ? EXAMPLE_B_DRAFT : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["analyze"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-outbound-reply-promise-commitment-auditor',
  name: 'J-Dawgs Outbound Reply Promise & Commitment Auditor',
  description: 'Nobody cross-checks the reply you are about to send; ours grades every promise in a draft against the facts on file — supported, contradicted with both figures quoted, or not on file — into one send verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["analyze"]) return { ok: false, output: null, summary: 'Extracted core has no analyze function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_FACTS": __core["EXAMPLE_FACTS"], "EXAMPLE_A_DRAFT": __core["EXAMPLE_A_DRAFT"], "EXAMPLE_B_DRAFT": __core["EXAMPLE_B_DRAFT"] }
};
