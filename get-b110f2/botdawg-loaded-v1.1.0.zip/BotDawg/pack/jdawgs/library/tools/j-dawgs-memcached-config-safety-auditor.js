'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Memcached Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

var RISKY = [
"# RISKY EXAMPLE — not for production",
"-l 0.0.0.0",
"-l ::",
"-p 11211",
"-U 11211",
"-m 8192",
"-c 20480",
"-u root",
"--disable-sasl",
"sasl_password=Plant3d-Secret-DoNotShow-7391",
"this line cannot be parsed at all !!!",
"-o modern"
].join("\n");

var HARDENED = [
"# HARDENED EXAMPLE — localhost only, SASL on, UDP off",
"-l 127.0.0.1",
"-l ::1",
"-p 11211",
"-U 0",
"-m 256",
"-c 1024",
"-t 4",
"-u memcache",
"-S",
"-o modern"
].join("\n");

var cfgEl = document.getElementById("cfg");
var metaEl = document.getElementById("cfgmeta");
var findingsEl = document.getElementById("findings");
var reportEl = document.getElementById("report");
var verdictEl = document.getElementById("verdict");
var verdictText = document.getElementById("verdict-text");
var verdictNote = document.getElementById("verdict-note");
var loadStatus = document.getElementById("loadstatus");
var copyStatus = document.getElementById("copystatus");
var pitchStatus = document.getElementById("pitchstatus");
var lastReport = "";

var SECRET_RE = /(password|passwd|passphrase|secret|token|api[_-]?key|sasl[_-]?pw|private[_-]?key)/i;
var NOARG = {"S":1,"d":1,"v":1,"V":1,"h":1,"k":1,"L":1,"F":1,"M":1,"a":1,"s":1,"i":1,"D":0};
var ARGFLAGS = {"l":1,"p":1,"U":1,"m":1,"c":1,"t":1,"u":1,"o":1,"P":1,"n":1,"f":1,"D":1,"R":1,"b":1,"B":1,"I":1,"Y":1,"Z":1,"E":1,"e":1,"H":1,"A":1,"C":1,"T":1,"r":1,"X":1,"N":1,"O":1};
var INFOFLAGS = {"L":"Large memory pages requested (-L). Noted as INFO only — a tuning choice, not a fault.","n":"Slab minimum item size set (-n). Noted as INFO only — a slab tuning choice, not a fault.","f":"Slab growth factor set (-f). Noted as INFO only — a slab tuning choice, not a fault.","I":"Max item size set (-I). Noted as INFO only — a tuning choice, not a fault."};

function isNum(s){ return /^-?\d+$/.test(String(s).trim()); }
function fmtGB(mb){ var gb = mb/1024; return (Math.round(gb*100)/100).toString(); }

function newState(){
  return { listens:[], tcp:[], udp:[], mem:[], conns:[], threads:[], users:[],
    saslOn:[], saslOff:[], ext:[], infoFlags:[], secrets:[], notParsed:[], notParsedLines:{}, totalLines:0, contentLines:0 };
}
function markNotParsed(st, line){ if(!st.notParsedLines[line]){ st.notParsedLines[line]=1; st.notParsed.push(line); } }

function applyValue(st, kind, value, line){
  if(value===null || value===undefined || value===""){ markNotParsed(st, line); return; }
  value = String(value).trim();
  if(kind==="listen"){ value.split(",").forEach(function(v){ v=v.trim(); if(v) st.listens.push({value:v, line:line}); }); }
  else if(kind==="tcp"){ if(isNum(value)) st.tcp.push({value:parseInt(value,10), line:line}); else markNotParsed(st,line); }
  else if(kind==="udp"){ if(isNum(value)) st.udp.push({value:parseInt(value,10), line:line}); else markNotParsed(st,line); }
  else if(kind==="mem"){ if(isNum(value)) st.mem.push({value:parseInt(value,10), line:line}); else markNotParsed(st,line); }
  else if(kind==="conns"){ if(isNum(value)) st.conns.push({value:parseInt(value,10), line:line}); else markNotParsed(st,line); }
  else if(kind==="threads"){ if(isNum(value)) st.threads.push({value:parseInt(value,10), line:line}); else markNotParsed(st,line); }
  else if(kind==="user"){ st.users.push({value:value, line:line}); }
  else if(kind==="ext"){ st.ext.push({line:line}); }
}

function parseFlagTokens(st, tokens, line){
  var i = 0;
  if(tokens[0]==="memcached"){ i = 1; }
  var sawAny = false;
  while(i < tokens.length){
    var tok = tokens[i];
    if(tok.indexOf("--")===0){
      sawAny = true;
      var body = tok.slice(2), name = body, val = null, eq = body.indexOf("=");
      if(eq>=0){ name = body.slice(0,eq); val = body.slice(eq+1); }
      var lname = name.toLowerCase();
      function needVal(){ if(val!==null) return val; if(i+1<tokens.length){ i++; return tokens[i]; } return null; }
      if(lname==="enable-sasl"){ st.saslOn.push(line); }
      else if(lname==="disable-sasl"){ st.saslOff.push(line); }
      else if(lname==="listen"||lname==="listen-addr"){ applyValue(st,"listen",needVal(),line); }
      else if(lname==="port"||lname==="tcp-port"){ applyValue(st,"tcp",needVal(),line); }
      else if(lname==="udp-port"){ applyValue(st,"udp",needVal(),line); }
      else if(lname==="memory"||lname==="max-memory"){ applyValue(st,"mem",needVal(),line); }
      else if(lname==="max-connections"){ applyValue(st,"conns",needVal(),line); }
      else if(lname==="threads"){ applyValue(st,"threads",needVal(),line); }
      else if(lname==="user"){ applyValue(st,"user",needVal(),line); }
      else if(lname==="extended-option"||lname==="options"){ applyValue(st,"ext",needVal(),line); }
      else if(lname==="help"||lname==="version"||lname==="daemon"||lname==="verbose"){ /* known no-arg */ }
      else { markNotParsed(st, line); }
      i++;
    } else if(tok.charAt(0)==="-" && tok.length>=2 && /[A-Za-z]/.test(tok.charAt(1))){
      sawAny = true;
      var letter = tok.charAt(1);
      var attached = tok.slice(2);
      if(letter==="S"){ st.saslOn.push(line); if(attached){ tokens.splice(i+1,0,"-"+attached); } }
      else if(INFOFLAGS[letter] && !ARGFLAGS[letter]){ st.infoFlags.push({line:line, label:INFOFLAGS[letter]}); }
      else if(letter==="n"||letter==="f"||letter==="I"){
        var v1 = attached || (i+1<tokens.length ? tokens[++i] : null);
        if(v1===null || v1===undefined || !isNum(String(v1).replace(/^[a-z]$/i,"")) && letter==="I" ? false : v1===null){ /* fallthrough */ }
        st.infoFlags.push({line:line, label:INFOFLAGS[letter]});
      }
      else if(ARGFLAGS[letter]){
        var v = attached;
        if(!v){ if(i+1<tokens.length){ i++; v = tokens[i]; } else { v = null; } }
        if(letter==="l") applyValue(st,"listen",v,line);
        else if(letter==="p") applyValue(st,"tcp",v,line);
        else if(letter==="U") applyValue(st,"udp",v,line);
        else if(letter==="m") applyValue(st,"mem",v,line);
        else if(letter==="c") applyValue(st,"conns",v,line);
        else if(letter==="t") applyValue(st,"threads",v,line);
        else if(letter==="u") applyValue(st,"user",v,line);
        else if(letter==="o") applyValue(st,"ext",v,line);
        /* other known arg flags: parsed, no graded finding */
      }
      else if(NOARG[letter]){ if(attached){ tokens.splice(i+1,0,"-"+attached); } }
      else { markNotParsed(st, line); }
      i++;
    } else {
      markNotParsed(st, line);
      i++;
    }
  }
  if(!sawAny){ markNotParsed(st, line); }
}

var KEYMAP = {
  "listen":"listen","listen_address":"listen","listen_addr":"listen","l":"listen",
  "port":"tcp","tcp_port":"tcp","p":"tcp",
  "udp_port":"udp","udp":"udp","u_udp":"udp",
  "memory":"mem","memory_limit":"mem","max_memory":"mem","mem_limit":"mem","m":"mem",
  "max_connections":"conns","maxconnections":"conns","max_conn":"conns","connections":"conns","c":"conns",
  "threads":"threads","t":"threads",
  "user":"user","run_as":"user",
  "extended_options":"ext","options":"ext","o":"ext"
};

function parseKeyLine(st, trimmed, line){
  var m = trimmed.match(/^([A-Za-z_][A-Za-z0-9_-]*)\s*[=:]\s*(.+)$/) || trimmed.match(/^([A-Za-z_][A-Za-z0-9_-]*)\s+(.+)$/);
  if(!m){ markNotParsed(st, line); return; }
  var key = m[1].toLowerCase().replace(/-/g,"_");
  var val = m[2].trim();
  if(key==="sasl"||key==="enable_sasl"||key==="sasl_enabled"||key==="auth"||key==="authentication"){
    if(/^(true|yes|on|enabled|1)$/i.test(val)) st.saslOn.push(line);
    else if(/^(false|no|off|disabled|0)$/i.test(val)) st.saslOff.push(line);
    else markNotParsed(st, line);
    return;
  }
  if(key==="disable_large_pages"||key==="no_large_pages"||key==="large_pages"){
    st.infoFlags.push({line:line, label:"Large-pages setting present ("+m[1]+"). Noted as INFO only — a tuning choice, not a fault."});
    return;
  }
  if(key==="slab_factor"||key==="slab_chunk"||key==="slab"||key==="chunk_size"){
    st.infoFlags.push({line:line, label:"Slab setting present ("+m[1]+"). Noted as INFO only — a slab tuning choice, not a fault."});
    return;
  }
  var kind = KEYMAP[key];
  if(!kind){ markNotParsed(st, line); return; }
  applyValue(st, kind, val, line);
}

function parse(text){
  var st = newState();
  var lines = text.split(/\r?\n/);
  st.totalLines = lines.length;
  lines.forEach(function(raw, idx){
    var line = idx+1;
    var trimmed = raw.trim();
    if(!trimmed) return;
    if(trimmed.charAt(0)==="#" || trimmed.indexOf("//")===0 || trimmed.charAt(0)===";") return;
    st.contentLines++;
    if(SECRET_RE.test(trimmed)){
      var km = trimmed.match(/^([A-Za-z_][A-Za-z0-9_-]*)/);
      st.secrets.push({line:line, key: km ? km[1] : "secret setting"});
      return;
    }
    if(trimmed.charAt(0)==="-" || trimmed.indexOf("memcached ")===0 || trimmed==="memcached"){
      parseFlagTokens(st, trimmed.split(/\s+/), line);
    } else {
      parseKeyLine(st, trimmed, line);
    }
  });
  return st;
}

function classifyListen(v){
  if(v==="0.0.0.0"||v==="::"||v==="*") return "wildcard";
  if(v==="127.0.0.1"||v==="::1"||v.toLowerCase()==="localhost"||v.indexOf("127.")===0) return "loopback";
  return "specific";
}

function audit(text){
  var st = parse(text);
  var F = [];
  function add(sev, line, title, detail, fix){ F.push({sev:sev, line:line, title:title, detail:detail, fix:fix}); }
  var saslEnabled = st.saslOn.length>0;
  var saslDisabled = !saslEnabled && st.saslOff.length>0;
  var hasV4 = st.listens.some(function(l){return l.value==="0.0.0.0";});
  var hasV6 = st.listens.some(function(l){return l.value==="::";});
  var exposed = st.listens.some(function(l){return classifyListen(l.value)==="wildcard";});
  var loopbackOnly = st.listens.length>0 && st.listens.every(function(l){return classifyListen(l.value)==="loopback";});

  /* Listen */
  if(st.listens.length===0){
    add("WARNING", null, "No listen address (-l) found — NOT VERIFIED",
      "The text never says which address Memcached binds to, so this audit cannot verify the exposure. Depending on the build and flags, the default may accept connections beyond this machine.",
      "Add an explicit listen line, e.g. -l 127.0.0.1 for same-machine use, and re-audit.");
  } else {
    st.listens.forEach(function(l){
      var cls = classifyListen(l.value);
      if(cls==="wildcard"){
        if(saslEnabled){
          add("WARNING", l.line, "Listens on every address ("+l.value+") — SASL is on, but the port is still reachable by anyone",
            "The cache accepts connections on all network interfaces. SASL means a login is required, which helps, but every attacker who can route to this host can still try the door.",
            "Bind to localhost (-l 127.0.0.1) if only this machine uses the cache, or put the port behind a firewall/VPN and keep SASL on.");
        } else {
          var both = hasV4 && hasV6;
          add("BLOCKER", l.line, both ? "ESCALATED: open to every network on IPv4 and IPv6, with no login required" : "Open to every network with no login required",
            (both ? "Both wildcard addresses are present (0.0.0.0 on line "+st.listens.filter(function(x){return x.value==="0.0.0.0";})[0].line+" and :: on line "+st.listens.filter(function(x){return x.value==="::";})[0].line+"), so the cache is exposed on every interface. " : "This listen address ("+l.value+") accepts connections from any network interface. ") + "SASL authentication is not enabled in this config, so anyone who can reach the port can read, write, and delete cached data without logging in.",
            "Bind to localhost (-l 127.0.0.1 and -l ::1) if only this machine uses the cache. If other machines truly need it, bind one specific private address, enable SASL (-S), and firewall the port.");
        }
      } else if(cls==="loopback"){
        add("INFO", l.line, "Localhost-only listening ("+l.value+") — the safe setting",
          "Only programs on this same machine can reach the cache. Remote machines cannot connect to this listen address.",
          "No change needed for this line.");
      } else {
        if(saslEnabled){
          add("INFO", l.line, "Listens on a specific address ("+l.value+") with SASL on",
            "The cache is bound to one named address rather than every interface, and authentication is enabled in the text.",
            "No change needed for this line; keep the port firewalled to the machines that need it.");
        } else {
          add("WARNING", l.line, "Listens on "+l.value+" with no SASL authentication",
            "Any machine that can reach this address can use the cache without logging in.",
            "Enable SASL (-S), or bind to localhost (-l 127.0.0.1) if only this machine uses the cache.");
        }
      }
    });
  }

  /* UDP */
  if(st.udp.length===0){
    add("INFO", null, "No UDP port setting (-U) found — NOT VERIFIED",
      "The text does not state the UDP posture. Current Memcached builds default UDP to off, but this audit grades the text, and the text does not prove it.",
      "Add -U 0 to state plainly that UDP is off.");
  } else {
    st.udp.forEach(function(u){
      if(u.value===0){
        add("INFO", u.line, "UDP is off (-U 0) — the safe setting",
          "With UDP disabled, this server cannot be used as a UDP amplification reflector.",
          "No change needed for this line.");
      } else if(!saslEnabled && exposed){
        add("BLOCKER", u.line, "UDP is on (port "+u.value+"), exposed, with no authentication — amplification risk",
          "This is the classic Memcached amplification setup, in plain words: an attacker sends a tiny request with a forged return address, and the server fires a far bigger reply at the victim. Your server becomes the hose in someone else's flood attack, and your address takes the blame.",
          "Set -U 0 to turn UDP off (most deployments never need it). If UDP is truly required, enable SASL (-S) and bind to localhost or a private address.");
      } else if(!saslEnabled){
        add("WARNING", u.line, "UDP is on (port "+u.value+") with no authentication",
          "UDP Memcached answers are much larger than the requests that trigger them, which is exactly what amplification attacks abuse. The listen address limits who can reach it here, but the safe default is off.",
          "Set -U 0 unless a measured need for UDP exists; if it does, enable SASL (-S).");
      } else {
        add("WARNING", u.line, "UDP is on (port "+u.value+") — SASL is on, but UDP is still best left off",
          "Authentication reduces the risk, but UDP responses remain far larger than requests, which is what amplification attacks abuse.",
          "Set -U 0 unless a measured need for UDP exists.");
      }
    });
  }

  /* SASL */
  if(saslEnabled){
    add("INFO", st.saslOn[0], "SASL authentication is switched on in the text",
      "The config enables SASL, so clients must log in. This auditor does not verify SASL credentials or test a live login — enabled here means the words are present, nothing more.",
      "No change needed for authentication posture; keep credentials strong and stored outside this config's audience.");
  } else if(saslDisabled){
    add("WARNING", st.saslOff[0], "SASL is explicitly switched off",
      "The config turns authentication off, so any client that can reach the port can use the cache without logging in. On a localhost-only cache that may be a deliberate choice; anywhere else it is exposure.",
      "Remove the disable setting and add -S (or --enable-sasl), then provision client credentials.");
  } else {
    add("WARNING", null, "No SASL setting found — authentication NOT VERIFIED",
      "The text never mentions SASL, so this audit cannot verify that any login is required. Absence is not proof either way, and this auditor never treats an unseen setting as a safe one.",
      "Add -S (or --enable-sasl) to enable SASL explicitly, then re-audit.");
  }

  /* User */
  if(st.users.length===0){
    add("INFO", null, "No run-as user (-u) found — NOT VERIFIED",
      "The text does not say which account the daemon runs as, so this audit cannot verify it is not root.",
      "Add a line such as -u memcache to run as a dedicated, unprivileged account.");
  } else {
    st.users.forEach(function(u){
      if(u.value.toLowerCase()==="root"){
        add("BLOCKER", u.line, "Daemon runs as root (-u root)",
          "Memcached has no reason to run with full machine privileges. If the daemon is ever compromised, the attacker lands as root and owns the whole machine, not just the cache.",
          "Change this line to a dedicated account, e.g. -u memcache, and restart the daemon.");
      } else {
        add("INFO", u.line, "Runs as a non-root account ("+u.value+")",
          "The daemon is configured to drop to a dedicated, unprivileged account.",
          "No change needed for this line.");
      }
    });
  }

  /* Memory */
  if(st.mem.length===0){
    add("WARNING", null, "No memory limit (-m) found",
      "Without an explicit -m, the daemon falls back to its built-in default (64 MB) — which may be far from what this machine and workload need, and the text does not prove the choice was deliberate.",
      "Add an explicit limit sized to the machine, e.g. -m 256 for 256 MB, and re-audit.");
  } else {
    st.mem.forEach(function(mEntry){
      var mb = mEntry.value, gb = fmtGB(mb);
      if(mb>=4096){
        add("WARNING", mEntry.line, "Very large memory limit: "+mb+" MB",
          "The arithmetic: "+mb+" MB ÷ 1024 = "+gb+" GB handed to the cache. On a machine with less free RAM than that — or one sharing the box with other services — the cache can push the system into swap or get the daemon killed under memory pressure.",
          "Size -m to measured need and to the machine's free RAM, e.g. -m 256 (256 MB = 0.25 GB) on a small box, and leave headroom for the OS.");
      } else {
        add("INFO", mEntry.line, "Memory limit set: "+mb+" MB ("+mb+" ÷ 1024 = "+gb+" GB)",
          "An explicit cache memory cap is present and is not in the very-large range.",
          "No change needed for this line, provided the machine has comfortably more RAM than this cap.");
      }
    });
  }

  /* Connections */
  if(st.conns.length===0){
    add("INFO", null, "No max-connections setting (-c) found",
      "The daemon will use its built-in default connection cap. That is common, but the text does not state the choice.",
      "Optionally add -c 1024 to state the cap explicitly.");
  } else {
    st.conns.forEach(function(c){
      if(c.value>=10000){
        add("WARNING", c.line, "Very high max connections: "+c.value.toLocaleString("en-US"),
          "Each idle connection still costs the daemon bookkeeping and buffer memory. A cap of "+c.value.toLocaleString("en-US")+" is far above the usual default of 1,024 and is rarely a measured choice.",
          "Set -c to a measured value (1,024 is the common default) unless load testing proves you need more.");
      } else {
        add("INFO", c.line, "Max connections set: "+c.value.toLocaleString("en-US"),
          "An explicit connection cap is present and is within the ordinary range.",
          "No change needed for this line.");
      }
    });
  }

  /* TCP port / threads / extended — informational records */
  st.tcp.forEach(function(p){
    add("INFO", p.line, p.value===0 ? "TCP port disabled (-p 0)" : "TCP port set: "+p.value,
      p.value===0 ? "TCP listening is turned off in the text." : "The cache listens for TCP clients on port "+p.value+". The exposure findings above grade which address that port is bound to.",
      "No change needed for this line on its own.");
  });
  st.threads.forEach(function(t){
    add("INFO", t.line, "Thread count set: "+t.value,
      "An explicit worker-thread count is present.",
      "No change needed for this line.");
  });
  st.ext.forEach(function(e){
    add("INFO", e.line, "Extended options present (-o) — reviewed as text only",
      "An -o extended-options setting is present on this line. Its value is not reproduced here; extended options are tuning inputs, and none of them change the exposure, UDP, or authentication findings above.",
      "No change needed for this line on its own.");
  });
  st.infoFlags.forEach(function(f){
    add("INFO", f.line, "Tuning setting noted", f.label, "No change needed for this line.");
  });

  /* Secrets — key name and line only, value never rendered */
  st.secrets.forEach(function(s){
    add("INFO", s.line, "Secret setting present (key: "+s.key+") — value hidden on purpose",
      "A secret-bearing setting appears on this line. Its value is never shown in these findings or in the report — it is referred to by key name and line number only.",
      "Keep the secret out of shared copies of this config; if this text was pasted anywhere public, rotate that secret.");
  });

  /* Not parsed */
  st.notParsed.slice().sort(function(a,b){return a-b;}).forEach(function(line){
    add("NOT PARSED", line, "Line could not be parsed — reported, not guessed",
      "This line does not match a known Memcached option in flag style or key style, so the auditor left it ungraded rather than guessing what it meant. Anything this line was supposed to set is NOT VERIFIED by this audit.",
      "Check the line against the Memcached options for your version — fix the spelling or format, or remove the line — then re-audit.");
  });

  var counts = { BLOCKER:0, WARNING:0, INFO:0, "NOT PARSED":0 };
  F.forEach(function(f){ counts[f.sev]++; });
  var verdict, vclass, note;
  if(counts.BLOCKER>0){ verdict="DO NOT DEPLOY"; vclass="v-do-not"; note=counts.BLOCKER+" blocker"+(counts.BLOCKER===1?"":"s")+" must be fixed before this config goes anywhere near a real server."; }
  else if(counts.WARNING>0 || counts["NOT PARSED"]>0){ verdict="DEPLOY WITH FIXES"; vclass="v-fixes"; note="No blockers, but "+(counts.WARNING+counts["NOT PARSED"])+" item"+((counts.WARNING+counts["NOT PARSED"])===1?"":"s")+" need attention — including anything marked NOT VERIFIED, which this audit never treats as safe."; }
  else { verdict="SAFE TO DEPLOY"; vclass="v-safe"; note="No blockers and no warnings in the pasted text. Authentication was seen enabled in the text (credentials themselves are not verified), and this remains a heuristic text audit — not a live-server check."; }

  var order = { "BLOCKER":0, "WARNING":1, "INFO":2, "NOT PARSED":3 };
  F.sort(function(a,b){
    if(order[a.sev]!==order[b.sev]) return order[a.sev]-order[b.sev];
    var la = a.line===null?9999:a.line, lb = b.line===null?9999:b.line;
    return la-lb;
  });

  return { findings:F, counts:counts, verdict:verdict, vclass:vclass, note:note, totalLines:st.totalLines, contentLines:st.contentLines };
}

function lineLabel(line){ return line===null ? "Whole config" : "Line "+line; }

function buildReport(r, sourceEmpty){
  if(sourceEmpty) return "J-Dawgs Memcached Config Safety Auditor™ — Audit Report\n\nNo config text was provided. Paste a Memcached config and run the audit.";
  var out = [];
  out.push("J-Dawgs Memcached Config Safety Auditor™ — Audit Report");
  out.push("Verdict: "+r.verdict);
  out.push("Counts: BLOCKER "+r.counts.BLOCKER+" · WARNING "+r.counts.WARNING+" · INFO "+r.counts.INFO+" · NOT PARSED "+r.counts["NOT PARSED"]);
  out.push("Config lines read: "+r.totalLines+" ("+r.contentLines+" setting/comment-bearing)");
  out.push("");
  out.push("Findings:");
  r.findings.forEach(function(f, i){
    out.push("");
    out.push((i+1)+". ["+f.sev+"] "+lineLabel(f.line)+" — "+f.title);
    out.push("   "+f.detail);
    out.push("   Fix: "+f.fix);
  });
  out.push("");
  out.push("Notes: Heuristic text audit only. No server was contacted, nothing was uploaded or saved, and SASL credentials were not verified. Secret values from the config are never included in this report — they are referred to by key name and line number only.");
  return out.join("\n");
}
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-memcached-config-safety-auditor',
  name: 'J-Dawgs Memcached Config Safety Auditor',
  description: 'Grades a pasted Memcached config offline — wildcard listen paired with missing SASL, UDP amplification exposure, root user, and memory arithmetic — into one deploy verdict; secrets named by key and line only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
