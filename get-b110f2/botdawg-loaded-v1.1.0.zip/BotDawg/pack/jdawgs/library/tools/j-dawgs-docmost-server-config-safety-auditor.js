'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Docmost Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

  "use strict";

  var RISKY = [
    "# Docmost production config - copied from a getting-started tutorial",
    "APP_URL=http://wiki.example.com",
    "APP_SECRET=secret123",
    "PORT=3000",
    "HOST=0.0.0.0",
    "DATABASE_URL=postgres://docmost:pass123@db.example.com:5432/docmost",
    "REDIS_URL=redis://127.0.0.1:6379",
    "MAIL_DRIVER=smtp",
    "SMTP_HOST=mail.example.com",
    "SMTP_PORT=25",
    "SMTP_USERNAME=wiki@example.com",
    "SMTP_PASSWORD=mailpass",
    "DISABLE_TELEMETRY=false",
    "APP_ENV=development",
    "DEBUG=true",
    "ALLOW_REGISTRATION=true"
  ].join("\n");

  var HARDENED = [
    "# Docmost production config - hardened",
    "APP_URL=https://wiki.example.com",
    "APP_SECRET=9f2c7a41d8e04b6fa3c59127de08b4c6a71f93d2e84b05c6971ad3f5e2098b6cd41a",
    "PORT=3000",
    "HOST=127.0.0.1",
    "DATABASE_URL=postgres://docmost:Xv9!mQ2%23zL8pR4tW7nK3@db.internal:5432/docmost?sslmode=require",
    "REDIS_URL=rediss://:Rd7!sN4%23wQ9zM2xP8vL5@redis.internal:6380",
    "MAIL_DRIVER=smtp",
    "SMTP_HOST=mail.example.com",
    "SMTP_PORT=587",
    "SMTP_SECURE=true",
    "SMTP_USERNAME=wiki@example.com",
    "SMTP_PASSWORD=Sm6!tP3%23kW8qN5zX2vJ9",
    "DISABLE_TELEMETRY=true",
    "APP_ENV=production",
    "DEBUG=false",
    "ALLOW_REGISTRATION=false"
  ].join("\n");

  var EXAMPLE_SECRETS = ["secret","secret123","changeme","change-me","change_me","password","password123","pass123","your-secret","your_secret","your-secret-key","example","docmost","letmein","supersecret","mysecret","123456","12345678","qwerty","admin","test","dev","development","please-change-me","random-string","appsecret","app-secret","s3cret","default","demo"];

  var input = document.getElementById("configInput");
  var resultsEl = document.getElementById("results");
  var reportEl = document.getElementById("reportText");
  var inputStatus = document.getElementById("inputStatus");
  var copyStatus = document.getElementById("copyStatus");
  var pitchStatus = document.getElementById("pitchStatus");
  var lastAudit = null;

  function isTruthy(v){ return /^(true|1|yes|on)$/i.test(v); }
  function isFalsy(v){ return /^(false|0|no|off)$/i.test(v); }

  function parseConfig(text){
    var lines = text.split(/\r?\n/);
    var entries = [];
    var issues = [];
    var seen = {};
    var map = {};
    for (var i = 0; i < lines.length; i++){
      var lineNo = i + 1;
      var raw = lines[i];
      var s = raw.trim();
      if (!s || s.charAt(0) === "#") continue;
      if (s.indexOf("export ") === 0) s = s.slice(7).trim();
      var eq = s.indexOf("=");
      if (eq === -1){
        issues.push({line: lineNo, message: "Line is not in KEY=VALUE form, so it was skipped. Nothing on this line reaches the server."});
        continue;
      }
      var key = s.slice(0, eq).trim();
      var value = s.slice(eq + 1).trim();
      if (!/^[A-Za-z_][A-Za-z0-9_.]*$/.test(key)){
        issues.push({line: lineNo, message: "The key name on this line looks malformed, so the line was skipped."});
        continue;
      }
      var first = value.charAt(0);
      if ((first === '"' || first === "'") && value.length >= 1){
        if (value.length < 2 || value.charAt(value.length - 1) !== first){
          issues.push({line: lineNo, message: "Value for " + key + " opens a quote that never closes on this line. The server may read a different value than you expect."});
          value = value.slice(1);
        } else {
          value = value.slice(1, -1);
        }
      } else {
        var hashIdx = value.indexOf(" #");
        if (hashIdx !== -1) value = value.slice(0, hashIdx).trim();
      }
      if (Object.prototype.hasOwnProperty.call(seen, key)){
        issues.push({line: lineNo, message: key + " is set again here; it overrides line " + seen[key] + ". Duplicate keys hide which value the server actually uses."});
      }
      seen[key] = lineNo;
      var entry = {key: key, value: value, line: lineNo};
      entries.push(entry);
      map[key] = entry;
      if (value === ""){
        issues.push({line: lineNo, message: key + " is present but empty. An empty value is not the same as a strong value - the server falls back to defaults or fails later."});
      }
    }
    return {entries: entries, issues: issues, map: map, totalLines: lines.length};
  }

  function parseUrlPassword(value){
    try {
      var u = new URL(value);
      var pw = "";
      try { pw = decodeURIComponent(u.password || ""); } catch(e){ pw = u.password || ""; }
      return {ok: true, protocol: u.protocol, username: u.username || "", password: pw, hostname: u.hostname || "", search: u.search || ""};
    } catch(e){
      var m = /^[a-z][a-z0-9+.-]*:\/\/([^:\/?#]*)(?::([^@\/?#]*))?@/i.exec(value);
      if (m) return {ok: true, protocol: "", username: m[1] || "", password: m[2] || "", hostname: "", search: ""};
      return {ok: false, protocol: "", username: "", password: "", hostname: "", search: ""};
    }
  }

  function isExampleSecret(v){
    var lv = v.toLowerCase();
    if (EXAMPLE_SECRETS.indexOf(lv) !== -1) return true;
    if (lv.indexOf("changeme") !== -1 || lv.indexOf("change-me") !== -1 || lv.indexOf("your-") !== -1 || lv.indexOf("example") !== -1 || lv.indexOf("placeholder") !== -1) return true;
    return false;
  }

  function audit(text){
    var parsed = parseConfig(text);
    var entries = parsed.entries, map = parsed.map, issues = parsed.issues.slice();
    var findings = [];
    var secrets = [];

    function add(sev, line, key, title, detail, fix){
      findings.push({severity: sev, line: line, key: key, finding: title, detail: detail, fix: fix});
    }
    function get(k){ return map[k] || null; }

    // Secret inventory: every key that looks like a secret, by name/line/length only.
    var secretNameRe = /(SECRET|PASSWORD|PASSWD|PWD|TOKEN|API_KEY|APIKEY|PRIVATE_KEY|ACCESS_KEY)/i;
    entries.forEach(function(e){
      if (secretNameRe.test(e.key) && e.value !== ""){
        secrets.push({key: e.key, line: e.line, length: e.value.length});
      }
    });
    // Passwords embedded in URLs are secrets too.
    ["DATABASE_URL","REDIS_URL"].forEach(function(k){
      var e = get(k);
      if (e){
        var p = parseUrlPassword(e.value);
        if (p.ok && p.password){
          secrets.push({key: k + " (embedded password)", line: e.line, length: p.password.length});
        }
      }
    });

    if (entries.length === 0){
      add("critical", null, "(file)", "No parseable settings found",
        "The pasted text contains no KEY=VALUE settings the auditor could read, so there is nothing safe to deploy.",
        "Paste the full contents of the Docmost .env file, one KEY=VALUE setting per line.");
    }

    // ---- APP_SECRET ----
    var appSecret = get("APP_SECRET");
    if (!appSecret){
      add("critical", null, "APP_SECRET", "APP_SECRET is missing",
        "Docmost signs sessions and tokens with APP_SECRET. Without one set in the config, the server cannot run safely - and a default or generated-at-random fallback would invalidate or expose sessions.",
        "Set APP_SECRET to a random value of at least 32 characters, generated fresh for this server, and keep it out of source control.");
    } else if (appSecret.value !== ""){
      var sv = appSecret.value;
      if (isExampleSecret(sv)){
        add("critical", appSecret.line, "APP_SECRET", "APP_SECRET is a known example / placeholder value (" + sv.length + " characters)",
          "This value matches the kind of sample secret printed in tutorials and example files. Anyone who has read the same tutorial knows it, so session signing is effectively public. Reported by length only - the value is never printed here.",
          "Replace it with a fresh random secret of at least 32 characters that appears in no example, tutorial, or repository.");
      } else if (sv.length < 16){
        add("critical", appSecret.line, "APP_SECRET", "APP_SECRET is far too short (" + sv.length + " characters)",
          "A secret this short can be guessed or brute-forced, which puts signed sessions and tokens at risk. Reported by length only - the value is never printed here.",
          "Generate a random APP_SECRET of at least 32 characters (64 is a good target).");
      } else if (sv.length < 32){
        add("high", appSecret.line, "APP_SECRET", "APP_SECRET is short (" + sv.length + " characters)",
          "It clears the bare minimum but sits below the 32-character floor expected for a session-signing secret. Reported by length only.",
          "Regenerate APP_SECRET at 32 characters or more.");
      } else if (/^(.)\1+$/.test(sv)){
        add("high", appSecret.line, "APP_SECRET", "APP_SECRET is a single repeated character",
          "Length alone is not strength: a repeated-character value has almost no randomness. Reported by length only.",
          "Generate APP_SECRET from a real random source, not a typed pattern.");
      }
    }

    // ---- APP_URL ----
    var appUrl = get("APP_URL");
    var appEnv = get("APP_ENV") || get("NODE_ENV");
    var isProd = !appEnv || !/^(development|dev|local|test)$/i.test(appEnv.value);
    if (!appUrl){
      add("high", null, "APP_URL", "APP_URL is missing",
        "Docmost builds links, redirects, and cookie settings from APP_URL. Leaving it unset means wrong or insecure defaults at runtime.",
        "Set APP_URL to the exact public https:// address users will open.");
    } else if (appUrl.value !== ""){
      var uv = appUrl.value;
      if (/^http:\/\//i.test(uv)){
        add("high", appUrl.line, "APP_URL", "APP_URL uses plain http://",
          "Logins, session cookies, and every page of the wiki cross the network unencrypted on http://. Anyone on the path can read or steal a session.",
          "Put the server behind an https:// address (reverse proxy or TLS termination) and set APP_URL to the https:// URL.");
      } else if (!/^https:\/\//i.test(uv)){
        add("warning", appUrl.line, "APP_URL", "APP_URL does not start with https://",
          "The value is not a recognisable https web address, so generated links and redirects may be wrong or insecure.",
          "Set APP_URL to the full public address, starting with https://.");
      }
      if (isProd && /(localhost|127\.0\.0\.1)/i.test(uv)){
        add("warning", appUrl.line, "APP_URL", "APP_URL points at localhost in a production config",
          "Users outside this machine cannot use localhost links, and email / share links generated from it will be broken.",
          "Set APP_URL to the real public hostname of the wiki.");
      }
    }

    // ---- DATABASE_URL ----
    var db = get("DATABASE_URL");
    if (!db){
      add("critical", null, "DATABASE_URL", "DATABASE_URL is missing",
        "Docmost stores everything in Postgres and will not run without a database connection string.",
        "Set DATABASE_URL to the Postgres connection string for this deployment.");
    } else if (db.value !== ""){
      var dp = parseUrlPassword(db.value);
      if (!dp.ok){
        add("high", db.line, "DATABASE_URL", "DATABASE_URL could not be parsed as a URL",
          "The value does not look like a scheme://user:password@host:port/database connection string, so the server will likely fail to connect - or connect somewhere unexpected.",
          "Use the standard form: postgres://USER:PASSWORD@HOST:5432/DATABASE.");
      } else if (!dp.password){
        add("high", db.line, "DATABASE_URL", "DATABASE_URL carries no password",
          "Either the database accepts passwordless logins (unsafe for anything reachable) or the server will fail to authenticate. The password itself is never printed here.",
          "Give the database user a strong password and include it in DATABASE_URL.");
      } else {
        if (isExampleSecret(dp.password)){
          add("critical", db.line, "DATABASE_URL", "Database password is a known example value (" + dp.password.length + " characters)",
            "A tutorial-grade password on the database means anyone who has seen the same example can try it. Reported by length only.",
            "Set a unique database password of at least 16 characters and update DATABASE_URL to match.");
        } else if (dp.password.length < 8){
          add("critical", db.line, "DATABASE_URL", "Database password is far too short (" + dp.password.length + " characters)",
            "A password this short falls quickly to guessing, and it sits in plaintext inside DATABASE_URL in this file. Reported by length only.",
            "Use a database password of at least 16 characters.");
        } else if (dp.password.length < 12){
          add("high", db.line, "DATABASE_URL", "Database password is short (" + dp.password.length + " characters)",
            "It is above trivial length but below a safe floor for a credential stored in plaintext in a config file. Reported by length only.",
            "Use a database password of at least 16 characters.");
        }
        if (dp.username && dp.password && dp.username === dp.password){
          add("high", db.line, "DATABASE_URL", "Database password matches the database username",
            "When the username is public knowledge (it appears in logs and process lists), a matching password is no barrier at all.",
            "Choose a database password unrelated to the username.");
        }
        var remoteDb = dp.hostname && !/^(localhost|127\.0\.0\.1|db|postgres|database)$/i.test(dp.hostname) && dp.hostname.indexOf(".internal") === -1;
        if (remoteDb && !/[?&]sslmode=(require|verify-ca|verify-full)/i.test(db.value)){
          add("warning", db.line, "DATABASE_URL", "No TLS required for a remote database host",
            "DATABASE_URL points at a host outside this machine but does not require SSL, so database traffic - including query data - may cross the network in plaintext.",
            "Add ?sslmode=require to DATABASE_URL, or confirm the database is only reachable on a private network.");
        }
      }
    }

    // ---- REDIS_URL ----
    var redis = get("REDIS_URL");
    if (!redis){
      add("high", null, "REDIS_URL", "REDIS_URL is missing",
        "Docmost uses Redis for queues and background work. Without it, parts of the server fail at runtime even if the web pages load.",
        "Set REDIS_URL to the Redis connection string for this deployment.");
    } else if (redis.value !== ""){
      var rp = parseUrlPassword(redis.value);
      if (!rp.ok){
        add("warning", redis.line, "REDIS_URL", "REDIS_URL could not be parsed as a URL",
          "The value does not look like a redis:// or rediss:// connection string, so the connection will likely fail at startup.",
          "Use the standard form: rediss://:PASSWORD@HOST:6380 or redis://:PASSWORD@HOST:6379.");
      } else if (!rp.password){
        add("high", redis.line, "REDIS_URL", "REDIS_URL has no password",
          "Redis without a password lets anyone who can reach the port read, write, or wipe the data it holds - and it is commonly scanned for exactly this.",
          "Set a Redis password (requirepass) of at least 16 characters and include it in REDIS_URL.");
      } else if (rp.password.length < 12){
        add("warning", redis.line, "REDIS_URL", "Redis password is short (" + rp.password.length + " characters)",
          "Below a safe floor for a credential stored in plaintext in this file. Reported by length only.",
          "Use a Redis password of at least 16 characters.");
      }
      if (rp.ok && /^redis:/i.test(rp.protocol) && rp.hostname && !/^(localhost|127\.0\.0\.1|redis)$/i.test(rp.hostname) && rp.hostname.indexOf(".internal") === -1){
        add("warning", redis.line, "REDIS_URL", "Plain redis:// to a remote host (no TLS)",
          "The redis:// scheme (as opposed to rediss://) sends the password and all data unencrypted to a host outside this machine.",
          "Use rediss:// with TLS, or confirm Redis is only reachable on a private network.");
      }
    }

    // ---- Bind / port exposure ----
    ["HOST","APP_HOST","BIND","BIND_ADDRESS","SERVER_HOST"].forEach(function(k){
      var e = get(k);
      if (e && /^(0\.0\.0\.0|::|\*)$/.test(e.value.trim())){
        var port = get("PORT");
        add("high", e.line, k, k + " binds every network interface (" + e.value.trim() + ")",
          "The server will listen on all interfaces" + (port ? ", including port " + port.value.trim() + " wherever the machine is reachable" : "") + ". If this host has a public address and no firewall rule in front, the wiki - and its login page - face the internet directly, bypassing any reverse-proxy protections.",
          "Bind to 127.0.0.1 and let a reverse proxy publish the site, or confirm a firewall restricts the port to trusted networks.");
      }
    });

    // ---- Debug / dev flags ----
    ["DEBUG","APP_DEBUG"].forEach(function(k){
      var e = get(k);
      if (e && isTruthy(e.value)){
        add("high", e.line, k, k + " is switched on",
          "Debug mode can expose stack traces, internal paths, and configuration details to anyone who triggers an error - a roadmap for an attacker.",
          "Set " + k + "=false for deployment.");
      }
    });
    ["APP_ENV","NODE_ENV","ENVIRONMENT","ENV"].forEach(function(k){
      var e = get(k);
      if (e && /^(development|dev|local)$/i.test(e.value.trim())){
        add("high", e.line, k, k + " is set to " + e.value.trim(),
          "A development environment flag typically relaxes security defaults, enables verbose errors, and may skip protections that production mode enforces.",
          "Set " + k + "=production for deployment.");
      }
    });

    // ---- Mail / SMTP ----
    var mailDriver = get("MAIL_DRIVER");
    var smtpHost = get("SMTP_HOST");
    var smtpPort = get("SMTP_PORT");
    var smtpUser = get("SMTP_USERNAME") || get("SMTP_USER");
    var smtpPass = get("SMTP_PASSWORD") || get("SMTP_PASS");
    var smtpSecure = get("SMTP_SECURE") || get("SMTP_TLS") || get("SMTP_REQUIRE_TLS");
    if ((mailDriver && /smtp/i.test(mailDriver.value)) || smtpHost){
      if (smtpPort && smtpPort.value.trim() === "25" && !(smtpSecure && isTruthy(smtpSecure.value))){
        add("warning", smtpPort.line, "SMTP_PORT", "SMTP on port 25 with no TLS flag",
          "Port 25 without STARTTLS enforcement sends the SMTP password and every outgoing email - including password-reset links - across the network in plaintext.",
          "Use the submission port 587 (or 465) with TLS enabled, per your mail provider's instructions.");
      }
      if (smtpUser && smtpUser.value !== "" && (!smtpPass || smtpPass.value === "")){
        add("warning", smtpUser.line, "SMTP_USERNAME", "SMTP username set but no SMTP password",
          "Authenticated sending will fail, or the server will attempt unauthenticated relay. Mail such as invites and password resets then silently never arrives.",
          "Set SMTP_PASSWORD to the mailbox / app password for this account.");
      }
    }
    if (smtpPass && smtpPass.value !== "" && smtpPass.value.length < 12 && !isExampleSecret(smtpPass.value)){
      add("warning", smtpPass.line, "SMTP_PASSWORD", "SMTP password is short (" + smtpPass.value.length + " characters)",
        "A short mailbox password in plaintext in this file is an easy credential to lose. Reported by length only.",
        "Use a dedicated app password of at least 16 characters for SMTP.");
    }
    if (smtpPass && smtpPass.value !== "" && isExampleSecret(smtpPass.value)){
      add("high", smtpPass.line, "SMTP_PASSWORD", "SMTP password is a known example value (" + smtpPass.value.length + " characters)",
        "An example-grade mailbox password risks the whole mailbox, not just outgoing mail. Reported by length only.",
        "Replace it with a unique app password of at least 16 characters.");
    }

    // ---- Registration ----
    ["ALLOW_REGISTRATION","ENABLE_REGISTRATION","OPEN_REGISTRATION","REGISTRATION_OPEN","ALLOW_SIGNUP","ENABLE_SIGNUP"].forEach(function(k){
      var e = get(k);
      if (e && isTruthy(e.value)){
        add("warning", e.line, k, k + " leaves self-registration open",
          "Anyone who can reach the login page can create an account. On a team wiki that usually means strangers inside your documentation the day the URL leaks.",
          "Close registration once the team is created, or restrict the server to invited users.");
      }
    });
    ["DISABLE_SIGNUP","DISABLE_REGISTRATION"].forEach(function(k){
      var e = get(k);
      if (e && isFalsy(e.value)){
        add("warning", e.line, k, k + " is off, so self-registration stays open",
          "With the disable flag off, anyone who can reach the site can sign up.",
          "Set " + k + "=true once your team accounts exist.");
      }
    });

    // ---- Telemetry ----
    var tel = get("DISABLE_TELEMETRY");
    if (tel && isFalsy(tel.value)){
      add("low", tel.line, "DISABLE_TELEMETRY", "Telemetry is left on",
        "DISABLE_TELEMETRY is set to a false value, so usage telemetry stays enabled. Not a break-in risk, but a privacy choice most self-hosters make deliberately.",
        "Set DISABLE_TELEMETRY=true if you do not want the server sending usage telemetry.");
    }

    // ---- Generic short secrets (skip ones already covered) ----
    var covered = {APP_SECRET:1, SMTP_PASSWORD:1, SMTP_PASS:1};
    secrets.forEach(function(s){
      if (covered[s.key]) return;
      if (s.key.indexOf("(embedded password)") !== -1) return;
      if (s.length < 12){
        add("warning", s.line, s.key, s.key + " is short (" + s.length + " characters)",
          "Any secret under 12 characters is weak wherever it is used, and it sits in plaintext in this file. Reported by length only.",
          "Rotate " + s.key + " to a random value of at least 16 characters.");
      }
    });

    // ---- Parse issues become low findings ----
    issues.forEach(function(it){
      findings.push({severity: "low", line: it.line, key: "(file)", finding: "File hygiene issue", detail: it.message, fix: "Fix the line so every setting is one clean KEY=VALUE pair."});
    });

    var order = {critical: 0, high: 1, warning: 2, low: 3};
    findings.sort(function(a, b){
      if (order[a.severity] !== order[b.severity]) return order[a.severity] - order[b.severity];
      var la = a.line === null ? 9999 : a.line, lb = b.line === null ? 9999 : b.line;
      return la - lb;
    });

    var counts = {critical: 0, high: 0, warning: 0, low: 0};
    findings.forEach(function(f){ counts[f.severity]++; });
    var score = Math.max(0, 100 - counts.critical * 25 - counts.high * 15 - counts.warning * 8 - counts.low * 3);

    var verdict, verdictClass, verdictWhy;
    if (entries.length === 0 || counts.critical > 0 || counts.high >= 3){
      verdict = "DO NOT DEPLOY"; verdictClass = "donot";
      verdictWhy = entries.length === 0
        ? "There is no readable configuration to deploy."
        : "This config carries " + counts.critical + " critical and " + counts.high + " high-severity problem(s). Starting the server on it would expose the wiki, its data, or its credentials.";
    } else if (counts.high > 0 || counts.warning > 0 || counts.low > 0){
      verdict = "DEPLOY WITH FIXES"; verdictClass = "fixes";
      verdictWhy = "Nothing here is an automatic stop, but " + (counts.high + counts.warning + counts.low) + " item(s) should be fixed first - each one is listed below with its line and the fix.";
    } else {
      verdict = "SAFE TO DEPLOY"; verdictClass = "safe";
      verdictWhy = "Every check passed: strong secrets, https APP_URL, password-protected database and Redis with TLS where it leaves the machine, no all-interface bind, no debug or dev flags, protected mail, closed registration, telemetry off. This verdict covers this config file only - not your firewall, proxy, or backups.";
    }

    return {
      verdict: verdict, verdictClass: verdictClass, verdictWhy: verdictWhy,
      score: score, counts: counts, findings: findings, secrets: secrets,
      settingsRead: entries.length, totalLines: parsed.totalLines, parseIssues: issues.length
    };
  }

  function esc(s){
    return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }

  function render(a){
    var html = "";
    html += '<div class="verdict ' + a.verdictClass + '"><p class="vlabel">' + esc(a.verdict) + '</p><p>' + esc(a.verdictWhy) + '</p></div>';
    html += '<div class="stats">'
      + '<div class="stat"><div class="n">' + a.score + ' / 100</div><div class="l">Config safety score</div></div>'
      + '<div class="stat"><div class="n">' + a.counts.critical + '</div><div class="l">Critical</div></div>'
      + '<div class="stat"><div class="n">' + a.counts.high + '</div><div class="l">High</div></div>'
      + '<div class="stat"><div class="n">' + a.counts.warning + '</div><div class="l">Warnings</div></div>'
      + '<div class="stat"><div class="n">' + a.counts.low + '</div><div class="l">Low</div></div>'
      + '<div class="stat"><div class="n">' + a.settingsRead + '</div><div class="l">Settings read</div></div>'
      + '</div>';

    if (a.findings.length){
      html += '<div class="tablewrap"><table class="findings"><thead><tr><th>Severity</th><th>Line</th><th>Key</th><th>Finding</th><th>Fix</th></tr></thead><tbody>';
      a.findings.forEach(function(f){
        html += '<tr><td><span class="sev ' + f.severity + '">' + f.severity + '</span></td>'
          + '<td>' + (f.line === null ? "—" : f.line) + '</td>'
          + '<td><code>' + esc(f.key) + '</code></td>'
          + '<td><strong>' + esc(f.finding) + '</strong><br><span class="muted">' + esc(f.detail) + '</span></td>'
          + '<td>' + esc(f.fix) + '</td></tr>';
      });
      html += '</tbody></table></div>';
    } else {
      html += '<div class="empty">No findings. Every check passed on the settings that were present.</div>';
    }

    html += '<h3>Secret inventory — name, line, length only</h3>';
    if (a.secrets.length){
      html += '<div class="tablewrap"><table class="inv"><thead><tr><th>Key</th><th>Line</th><th>Value length</th></tr></thead><tbody>';
      a.secrets.forEach(function(s){
        html += '<tr><td><code>' + esc(s.key) + '</code></td><td>' + s.line + '</td><td>' + s.length + ' characters</td></tr>';
      });
      html += '</tbody></table></div>';
      html += '<p class="small muted">Secret values are never displayed, copied into the report, or exported — here or anywhere else in this tool.</p>';
    } else {
      html += '<div class="empty">No secret-bearing keys were found in the pasted config.</div>';
    }
    resultsEl.innerHTML = html;
  }

  function buildReport(a){
    var out = [];
    out.push("J-Dawgs Docmost Server Config Safety Auditor - audit report");
    out.push("Verdict: " + a.verdict);
    out.push("Score: " + a.score + " / 100");
    out.push("Settings read: " + a.settingsRead + " | Lines in file: " + a.totalLines + " | Parse issues: " + a.parseIssues);
    out.push("Counts: critical " + a.counts.critical + ", high " + a.counts.high + ", warning " + a.counts.warning + ", low " + a.counts.low);
    out.push("");
    out.push("Why: " + a.verdictWhy);
    out.push("");
    if (a.findings.length){
      out.push("Findings (severity | line | key | finding | fix):");
      a.findings.forEach(function(f, i){
        out.push((i + 1) + ". [" + f.severity.toUpperCase() + "] Line " + (f.line === null ? "-" : f.line) + " - " + f.key + ": " + f.finding);
        out.push("   Detail: " + f.detail);
        out.push("   Fix: " + f.fix);
      });
    } else {
      out.push("Findings: none. Every check passed.");
    }
    out.push("");
    out.push("Secret inventory (key name, line, and length only - values are never reported):");
    if (a.secrets.length){
      a.secrets.forEach(function(s){ out.push("- " + s.key + " | line " + s.line + " | " + s.length + " characters"); });
    } else {
      out.push("- none found");
    }
    out.push("");
    out.push("Scope: this audit reads only the pasted config text, in the browser. It does not connect to any server, and a SAFE verdict covers this file only.");
    return out.join("\n");
  }

  function buildJson(a){
    return JSON.stringify({
      tool: "J-Dawgs Docmost Server Config Safety Auditor",
      verdict: a.verdict,
      score: a.score,
      counts: a.counts,
      settingsRead: a.settingsRead,
      totalLines: a.totalLines,
      parseIssues: a.parseIssues,
      findings: a.findings.map(function(f){
        return {severity: f.severity, line: f.line, key: f.key, finding: f.finding, detail: f.detail, fix: f.fix};
      }),
      secretInventory: a.secrets.map(function(s){
        return {key: s.key, line: s.line, valueLength: s.length};
      }),
      note: "Secret values are never included in this export - key name, line, and length only."
    }, null, 2);
  }

  function runAudit(){
    var text = input.value;
    if (!text.trim()){
      lastAudit = null;
      resultsEl.innerHTML = '<div class="empty">The box is empty. Paste a Docmost .env config, or load one of the worked examples, then press <strong>Audit this config</strong>.</div>';
      reportEl.textContent = "Run an audit to generate the report.";
      inputStatus.textContent = "Nothing to audit yet.";
      return;
    }
    lastAudit = audit(text);
    render(lastAudit);
    reportEl.textContent = buildReport(lastAudit);
    inputStatus.textContent = "Audit complete: " + lastAudit.verdict + " (" + lastAudit.settingsRead + " settings read, " + lastAudit.findings.length + " finding(s)).";
    copyStatus.textContent = "";
  }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_SECRETS": (typeof EXAMPLE_SECRETS !== 'undefined' ? EXAMPLE_SECRETS : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-docmost-server-config-safety-auditor',
  name: 'J-Dawgs Docmost Server Config Safety Auditor',
  description: 'Host tools only tell you the server started; ours grades a pasted Docmost config offline into one deploy verdict — secrets reported by key name/line/length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_SECRETS": __core["EXAMPLE_SECRETS"] }
};
