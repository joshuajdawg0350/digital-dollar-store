'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Task Ambiguity Pre-Flight Checker".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the analyze function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var CLEAN_EXAMPLE = "Rewrite README.md in the /project/docs folder. Done means: the rewritten README.md contains exactly three sections in this order — Overview (maximum 100 words), Installation (a numbered list of setup commands), and Usage (exactly two code examples) — and you reply with a summary listing the word count of each section. In scope: README.md only. Out of scope: every other file, every folder outside /project/docs, and all source code. Budget: $0; use no paid services and make no purchases. Deadline: Friday, November 6, 2026 at 5:00 PM CST. Format: GitHub-flavored Markdown, saved to /project/docs/README.md, replacing the current version. Permissions: editing README.md needs no approval; deleting any file or contacting any person needs approval first.";

        function esc(s) {
          return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
        }
        function findAll(text, re) {
          var out = [], m, seen = {};
          var r = new RegExp(re.source, re.flags.indexOf("g") === -1 ? re.flags + "g" : re.flags);
          while ((m = r.exec(text)) !== null) {
            var key = m[0].toLowerCase();
            if (!seen[key]) { seen[key] = { text: m[0], count: 1 }; out.push(seen[key]); }
            else { seen[key].count++; }
            if (r.lastIndex === m.index) r.lastIndex++;
          }
          return out;
        }
        function has(text, re) { return re.test(text); }

        function analyze(raw) {
          var text = raw.trim();
          var findings = []; // {cat, catLabel, sev: 0 blocking,1 risky,2 minor, evidence, question, assumption}
          var checks = [];   // {label, status: 'gap'|'clear'|'note', detail}
          function add(cat, catLabel, sev, evidence, question, assumption) {
            findings.push({ cat: cat, catLabel: catLabel, sev: sev, evidence: evidence, question: question, assumption: assumption || null });
          }

          /* ---------- 1. Missing success criteria ---------- */
          var successPats = [
            /done means/i, /success criteria/i, /acceptance criteria/i, /definition of done/i,
            /complete when/i, /finished when/i, /done when/i, /task is (done|complete|finished)/i,
            /must (contain|include|list|show|produce|result in|end with|have)\b/i,
            /should (contain|include|list|show|produce|result in|end with)\b/i,
            /deliverable(s)? (is|are|:)/i, /finished (result|product|output|version)/i,
            /reply with\b/i, /counts? as (done|complete|finished)/i
          ];
          var hasSuccess = successPats.some(function (re) { return re.test(text); });
          if (!hasSuccess) {
            add("success", "Missing success criteria", 0,
              "No phrase in the text defines what “done” looks like.",
              "What does “done” look like for this task — what exact end state, contents, or result must exist when the work is finished?",
              null);
            checks.push({ label: "Missing success criteria", status: "gap", detail: "No definition of done found anywhere in the text." });
          } else {
            checks.push({ label: "Missing success criteria", status: "clear", detail: "The text states what the finished result must be." });
          }

          /* ---------- 2. Missing scope boundary ---------- */
          var scopePats = [
            /in scope/i, /out of scope/i, /\bscope\s*:/i, /limited to\b/i, /only\b[^.]{0,70}\b(file|files|folder|section|page|document|part|area|module)\b/i,
            /do not (touch|change|edit|modify) (anything|any|other|the)/i, /nothing (else|outside|beyond)/i,
            /leave (everything|the rest|all other)/i, /not (in|within) scope/i
          ];
          var hasScope = scopePats.some(function (re) { return re.test(text); });
          if (!hasScope) {
            add("scope", "Missing scope boundary", 1,
              "Nothing states what may be changed and what must be left alone.",
              "What is in scope and out of scope — which files, systems, or areas may be changed, and which must be left untouched?",
              "Only the items named in the task are in scope; nothing else will be changed, moved, or deleted.");
            checks.push({ label: "Missing scope boundary", status: "gap", detail: "No in-scope / out-of-scope statement found." });
          } else {
            checks.push({ label: "Missing scope boundary", status: "clear", detail: "The text draws a scope boundary." });
          }

          /* ---------- 3. Unresolved referents ---------- */
          var hasFilename = /[\w-]+\.[a-z]{2,5}\b/i.test(text);
          var refFindings = [];
          var definitePats = [
            { re: /\bthe (file|report|document|doc|spreadsheet|list|draft|version|record|dataset)\b/i, sev: 0, kind: "item" },
            { re: /\bthat (report|file|document|draft|list|version)\b/i, sev: 0, kind: "item" },
            { re: /\bthe usual\b/i, sev: 0, kind: "usual" },
            { re: /\b(the|that) (photo|image|email|message|link|page|site|account|thing|stuff|data|other one)\b/i, sev: 1, kind: "item" },
            { re: /\b(this|that) one\b/i, sev: 1, kind: "item" },
            { re: /\bthem\b/i, sev: 0, kind: "people" },
            { re: /\bthey\b/i, sev: 1, kind: "people" },
            { re: /\bit\b/i, sev: 1, kind: "pronoun" }
          ];
          definitePats.forEach(function (p) {
            // A concrete filename in the text can anchor "the file" / "the document".
            if (hasFilename && p.kind === "item" && /file|document|doc/.test(p.re.source)) return;
            findAll(text, p.re).forEach(function (hit) {
              var q, a;
              if (p.kind === "people") {
                q = "Who exactly is “" + hit.text + "” — the names, addresses, or accounts of the people meant?";
                a = "“" + hit.text + "” is taken to mean only the people explicitly named elsewhere in the task; nobody else is contacted.";
              } else if (p.kind === "usual") {
                q = "What exactly is “" + hit.text + "” here — describe the specific item, routine, or standard meant, in full?";
                a = null;
              } else if (p.kind === "pronoun") {
                q = "What exactly does “" + hit.text + "” refer to in this task — name the specific item so there is no guess.";
                a = "“" + hit.text + "” is taken to refer to the main item named in the task, and to nothing else.";
              } else {
                q = "Which one exactly is “" + hit.text + "” — what is its name and location?";
                a = "“" + hit.text + "” is taken to mean the single most recently named matching item in the task text.";
              }
              // "the usual" is blocking with no safe assumption when it carries the whole method;
              // keep its assumption null unless severity drops.
              refFindings.push({ phrase: hit.text, count: hit.count, sev: p.sev, question: q, assumption: p.sev === 0 ? null : a });
            });
          });
          if (refFindings.length) {
            refFindings.forEach(function (rf) {
              add("referents", "Unresolved referents", rf.sev,
                "Quoted from the task: “" + rf.phrase + "”" + (rf.count > 1 ? " (×" + rf.count + ")" : "") + " — no antecedent in the text names what it points to.",
                rf.question, rf.assumption);
            });
            checks.push({ label: "Unresolved referents", status: "gap", detail: refFindings.length + " referent(s) quoted in the questions above have no antecedent in the text." });
          } else {
            checks.push({ label: "Unresolved referents", status: "clear", detail: "No dangling “the file / it / them”-style references found." });
          }

          /* ---------- 4. Vague quantities and times ---------- */
          var vaguePats = [
            { re: /\bsoon\b/i, sev: 1, kind: "time", assume: "“soon” is treated as within 24 hours of starting." },
            { re: /\bshortly\b/i, sev: 1, kind: "time", assume: "“shortly” is treated as within 24 hours of starting." },
            { re: /\bas soon as possible\b/i, sev: 1, kind: "time", assume: "“as soon as possible” is treated as the first task in the queue, started immediately." },
            { re: /\basap\b/i, sev: 1, kind: "time", assume: "“asap” is treated as the first task in the queue, started immediately." },
            { re: /\blater\b/i, sev: 1, kind: "time", assume: "“later” is treated as within 48 hours, with no fixed deadline." },
            { re: /\beventually\b/i, sev: 1, kind: "time", assume: "“eventually” is treated as no deadline; it will be scheduled after dated work." },
            { re: /\bsometime\b/i, sev: 1, kind: "time", assume: "“sometime” is treated as no deadline; it will be scheduled after dated work." },
            { re: /\bat some point\b/i, sev: 1, kind: "time", assume: "“at some point” is treated as no deadline; it will be scheduled after dated work." },
            { re: /\brecently\b/i, sev: 1, kind: "time", assume: "“recently” is treated as the last 30 days." },
            { re: /\brecent\b/i, sev: 2, kind: "time", assume: "“recent” is treated as the last 30 days." },
            { re: /\ba few\b/i, sev: 1, kind: "quantity", assume: "“a few” is treated as exactly 3." },
            { re: /\ba couple( of)?\b/i, sev: 1, kind: "quantity", assume: "“a couple” is treated as exactly 2." },
            { re: /\bseveral\b/i, sev: 1, kind: "quantity", assume: "“several” is treated as exactly 3." },
            { re: /\btoo much\b/i, sev: 1, kind: "quantity", assume: "“too much” is treated as a hard stop at $0 of unplanned spend — nothing is bought." },
            { re: /\btoo many\b/i, sev: 1, kind: "quantity", assume: null },
            { re: /\ba lot\b/i, sev: 2, kind: "quantity", assume: null },
            { re: /\bsome\b/i, sev: 2, kind: "quantity", assume: null },
            { re: /\benough\b/i, sev: 2, kind: "quantity", assume: null },
            { re: /\bvarious\b/i, sev: 2, kind: "quantity", assume: null },
            { re: /\betc\.?/i, sev: 2, kind: "quantity", assume: null },
            { re: /\band so on\b/i, sev: 2, kind: "quantity", assume: null },
            { re: /\bproperly\b/i, sev: 2, kind: "quality", assume: "“properly” is treated as matching the existing style and format of the surrounding material." },
            { re: /\bproper\b/i, sev: 2, kind: "quality", assume: "“proper” is treated as matching the existing style and format of the surrounding material." },
            { re: /\bappropriately\b/i, sev: 2, kind: "quality", assume: null },
            { re: /\bappropriate\b/i, sev: 2, kind: "quality", assume: null },
            { re: /\breasonable\b/i, sev: 2, kind: "quality", assume: null },
            { re: /\bas needed\b/i, sev: 2, kind: "quality", assume: null },
            { re: /\bwhen you can\b/i, sev: 1, kind: "time", assume: "“when you can” is treated as no deadline; it queues behind dated work." }
          ];
          var vagueFound = [];
          vaguePats.forEach(function (p) {
            findAll(text, p.re).forEach(function (hit) {
              var q;
              if (p.kind === "time") q = "What exact date and time does “" + hit.text + "” mean — a deadline a clock can check?";
              else if (p.kind === "quantity") q = "How much or how many exactly does “" + hit.text + "” mean — give a number or a hard limit.";
              else q = "What standard does “" + hit.text + "” set — what specific, checkable result would count as meeting it?";
              vagueFound.push({ phrase: hit.text, count: hit.count });
              add("vague", "Vague quantities and times", p.sev,
                "Quoted from the task: “" + hit.text + "”" + (hit.count > 1 ? " (×" + hit.count + ")" : "") + " — the word carries no checkable value.",
                q, p.sev === 0 ? null : p.assume);
            });
          });
          if (vagueFound.length) {
            checks.push({ label: "Vague quantities and times", status: "gap", detail: vagueFound.length + " vague word(s) quoted in the questions above: " + vagueFound.map(function (v) { return "“" + v.phrase + "”"; }).join(", ") + "." });
          } else {
            checks.push({ label: "Vague quantities and times", status: "clear", detail: "Quantities and times in the text are stated in checkable terms." });
          }

          /* ---------- 5. Missing constraints ---------- */
          var constraintDefs = [
            {
              key: "budget", label: "budget",
              pats: [/\$\s?\d/, /€\s?\d/, /£\s?\d/, /\bbudget\b/i, /spend(ing)? (limit|cap|up to|at most|no more than)/i, /no paid services/i, /cost(s)? (no more than|at most|under) /i, /maximum (spend|cost|of \$)/i],
              sev: 1,
              missingText: "No budget or spending limit is stated anywhere in the text.",
              question: "What is the budget for this task — a dollar amount that may be spent, or zero?",
              assume: "Budget is $0 — no paid services, purchases, or subscriptions will be used.",
              clearDetail: "A budget or spending limit is stated."
            },
            {
              key: "deadline", label: "deadline",
              pats: [/\bdeadline\b/i, /\bby \d{1,2}(:\d{2})?\s?(am|pm)\b/i, /\bby (monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b/i, /\b(january|february|march|april|may|june|july|august|september|october|november|december) \d{1,2}\b/i, /\b\d{4}-\d{2}-\d{2}\b/, /\b\d{1,2}\/\d{1,2}\/\d{2,4}\b/, /\bby \d{1,2} (january|february|march|april|may|june|july|august|september|october|november|december)\b/i],
              sev: 1,
              missingText: "No deadline or due date is stated anywhere in the text.",
              question: "What is the deadline — the exact date and time the finished result is due?",
              assume: "There is no hard deadline; the result is delivered as soon as the work is complete.",
              clearDetail: "A deadline or due date is stated."
            },
            {
              key: "format", label: "format",
              pats: [/\bformat\b/i, /\bmarkdown\b/i, /\bpdf\b/i, /\bcsv\b/i, /\bhtml\b/i, /\bplain text\b/i, /\bspreadsheet\b/i, /\bword (doc|document)\b/i, /\.(md|pdf|csv|html|txt|docx|xlsx)\b/i],
              sev: 2,
              missingText: "No output format is stated anywhere in the text.",
              question: "What format should the result be in — file type, structure, and where it should be saved or sent?",
              assume: "The result is delivered in the same format as the material it is based on.",
              clearDetail: "An output format is stated."
            },
            {
              key: "permission", label: "permission limits",
              pats: [/permission/i, /approval/i, /approve/i, /you may\b/i, /allowed to\b/i, /ask (me |first )?before/i, /without asking/i, /do not .{0,30} without/i, /needs? no approval/i],
              sev: 2,
              missingText: "No permission limits are stated anywhere in the text.",
              question: "What may be done without asking first, and what needs approval before it happens — sending, spending, deleting, publishing?",
              assume: "Nothing is sent, spent, deleted, or published without asking first; only reversible edits are made unasked.",
              clearDetail: "Permission limits are stated."
            }
          ];
          var missingConstraints = [];
          constraintDefs.forEach(function (c) {
            if (!c.pats.some(function (re) { return re.test(text); })) missingConstraints.push(c);
          });
          if (missingConstraints.length) {
            missingConstraints.forEach(function (c) {
              add("constraints", "Missing constraints", c.sev,
                c.missingText,
                c.question, c.assume);
            });
            checks.push({ label: "Missing constraints", status: "gap", detail: "Not stated: " + missingConstraints.map(function (c) { return c.label; }).join(", ") + "." });
          } else {
            checks.push({ label: "Missing constraints", status: "clear", detail: "Budget, deadline, format, and permission limits are all stated." });
          }

          /* ---------- 6. Conflicting instructions ---------- */
          var conflictPairs = [
            {
              a: /\b(send|post|share|submit|deliver|publish)\b[^.]{0,45}\b(today|now|immediately|right away|asap|tonight)\b/i,
              b: /\b(never|don'?t|do not|must not|not)\b[^.]{0,45}\b(send|post|share|submit|publish)\b[^.]{0,45}\b(without|before|until)\b/i,
              bAlt: /\b(ask|get approval|wait for approval|check with me)\b[^.]{0,40}\b(before|first)\b[^.]{0,25}\b(sending|posting|sharing|submitting|publishing)\b/i,
              topic: "sending now vs. never sending without approval"
            },
            {
              a: /\b(spend|pay|buy|purchase)\b[^.]{0,40}\b(whatever|anything|freely)\b/i,
              b: /\b(don'?t|do not|never)\b[^.]{0,30}\b(spend|pay|buy|purchase)\b/i,
              bAlt: /\bspend nothing\b|\bbuy nothing\b|\bno purchases\b/i,
              topic: "spending freely vs. spending nothing"
            },
            {
              a: /\b(delete|remove|erase|wipe)\b[^.]{0,35}\b(all|everything|every)\b/i,
              b: /\b(never|don'?t|do not|must not)\b[^.]{0,30}\b(delete|remove|erase|wipe)\b/i,
              bAlt: /\bkeep everything\b|\bdelete nothing\b/i,
              topic: "deleting everything vs. deleting nothing"
            },
            {
              a: /\bas fast as possible\b|\burgent(ly)?\b|\brush\b|\bhurry\b/i,
              b: /\btake your time\b|\bno rush\b|\bno hurry\b|\bwhenever you get to it\b/i,
              topic: "maximum speed vs. no rush"
            },
            {
              a: /\bchange everything\b|\brewrite (it )?all\b|\bstart (completely )?over\b|\bredo everything\b/i,
              b: /\b(don'?t|do not|never)\b[^.]{0,25}\bchange\b|\bleave .{0,25} as (it|is)\b|\bchange nothing\b/i,
              topic: "changing everything vs. changing nothing"
            },
            {
              a: /\b(post|share|publish)\b[^.]{0,35}\bpublicly\b|\bmake (it |this |that )?public\b/i,
              b: /\bkeep (it |this |that )?(private|confidential|secret)\b|\b(don'?t|do not)\b[^.]{0,25}\b(share|post|publish)\b/i,
              topic: "making it public vs. keeping it private"
            }
          ];
          var conflictFound = [];
          conflictPairs.forEach(function (cp) {
            var ma = text.match(cp.a);
            var mb = text.match(cp.b) || (cp.bAlt ? text.match(cp.bAlt) : null);
            if (ma && mb) {
              conflictFound.push({ a: ma[0].trim(), b: mb[0].trim(), topic: cp.topic });
            }
          });
          if (conflictFound.length) {
            conflictFound.forEach(function (cf) {
              add("conflicts", "Conflicting instructions", 0,
                "The pair: “" + cf.a + "” vs “" + cf.b + "” — " + cf.topic + ".",
                "These two instructions conflict — “" + cf.a + "” and “" + cf.b + "”. Which one wins?",
                null);
            });
            checks.push({ label: "Conflicting instructions", status: "gap", detail: conflictFound.length + " conflicting pair(s) named in the questions above." });
          } else {
            checks.push({ label: "Conflicting instructions", status: "clear", detail: "No pair of directives pulls in opposite directions." });
          }

          /* ---------- 7. Assumed context ---------- */
          var contextPats = [
            /\bas discussed\b/i, /\blike last time\b/i, /\bsame as (before|last time|usual)\b/i,
            /\bas (we )?agreed\b/i, /\bas before\b/i, /\bper our (chat|conversation|discussion|talk)\b/i,
            /\blike we did\b/i, /\bfrom earlier\b/i, /\bas mentioned\b/i, /\bas always\b/i,
            /\byou know (the|what|how)\b/i, /\bthe usual (way|process|routine|one)\b/i,
            /\bcontinuing (from|where)\b/i, /\bpick up where\b/i
          ];
          var ctxFound = [];
          contextPats.forEach(function (re) {
            findAll(text, re).forEach(function (hit) { ctxFound.push(hit.text); });
          });
          if (ctxFound.length) {
            ctxFound.forEach(function (phrase) {
              add("context", "Assumed context", 1,
                "Quoted from the task: “" + phrase + "” — it points to a conversation or document that is not included in the text.",
                "“" + phrase + "” relies on context that is not in this task — what exactly was said or decided there that applies here? Paste the details into the task.",
                "“" + phrase + "” is treated as carrying nothing in — only what is written in this task text is acted on.");
            });
            checks.push({ label: "Assumed context", status: "gap", detail: ctxFound.length + " reference(s) to context outside the text, quoted above." });
          } else {
            checks.push({ label: "Assumed context", status: "clear", detail: "The task stands on its own; no outside conversation is assumed." });
          }

          /* ---------- Verdict ---------- */
          var sevNames = ["BLOCKING", "RISKY", "MINOR"];
          findings.sort(function (x, y) { return x.sev - y.sev; });
          var nBlocking = findings.filter(function (f) { return f.sev === 0; }).length;
          var nRisky = findings.filter(function (f) { return f.sev === 1; }).length;
          var nMinor = findings.filter(function (f) { return f.sev === 2; }).length;
          var verdict, verdictClass, verdictWhy;
          if (nBlocking > 0) {
            verdict = "ASK FIRST — DO NOT GUESS"; verdictClass = "ask";
            verdictWhy = nBlocking + " blocking gap(s): a wrong guess here does real damage — wrong file, wrong recipient, or no way to tell when the job is done. Ask the blocking questions before any work starts.";
          } else if (findings.length > 0) {
            verdict = "START WITH ASSUMPTIONS LOGGED"; verdictClass = "assume";
            verdictWhy = "No blocking gaps, but " + findings.length + " gap(s) still force guesses. Start only with the assumptions below stated in your reply, so the requester can correct them.";
          } else {
            verdict = "READY TO START"; verdictClass = "ready";
            verdictWhy = "All seven checks pass on the text as written: done is defined, scope is bounded, referents resolve, quantities and times are checkable, constraints are stated, nothing conflicts, and no outside context is assumed.";
          }
          var assumptions = findings.filter(function (f) { return f.sev > 0 && f.assumption; })
            .map(function (f) { return f.assumption; });

          return { findings: findings, checks: checks, verdict: verdict, verdictClass: verdictClass, verdictWhy: verdictWhy, assumptions: assumptions, sevNames: sevNames, counts: { b: nBlocking, r: nRisky, m: nMinor } };
        }
  return { "analyze": (typeof analyze !== 'undefined' ? analyze : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "CLEAN_EXAMPLE": (typeof CLEAN_EXAMPLE !== 'undefined' ? CLEAN_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["analyze"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-task-ambiguity-pre-flight-checker',
  name: 'J-Dawgs Task Ambiguity Pre-Flight Checker',
  description: 'Flags underspecified tasks — missing done-definition, unresolved referents, vague quantities, missing constraints, conflicting directives — with ranked clarifying questions and a READY / ASSUMPTIONS LOGGED / ASK FIRST verdict',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["analyze"]) return { ok: false, output: null, summary: 'Extracted core has no analyze function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "CLEAN_EXAMPLE": __core["CLEAN_EXAMPLE"] }
};
