'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Kavita Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the analyze function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------------- Examples (original sample configs) ---------------- */
      var EXAMPLE_RISKY = [
        '{',
        '  "TokenKey": "your-super-secret-token-key-here",',
        '  "Port": 5000,',
        '  "IpAddresses": "0.0.0.0,::",',
        '  "BaseUrl": "http://books.example.org/",',
        '  "CacheDir": "/config/cache",',
        '  "Logging": {',
        '    "LogLevel": {',
        '      "Default": "Debug"',
        '    }',
        '  },',
        '  // "SmtpPassword": "hunter2-example-pass",',
        '  "EmailPassword": "p@ssw0rd-value-123"',
        '}'
      ].join("\n");

      var EXAMPLE_HARDENED = [
        '{',
        '  "TokenKey": "Xk7Qp2Wz9Lm4Rt8Vb3Ny6Hs1Jd5Fg0Ka9Zx2Cv7Bn4Mq6Ws8Er3Ty5Ui",',
        '  "Port": 5000,',
        '  "IpAddresses": "127.0.0.1",',
        '  "BaseUrl": "https://books.example.org/",',
        '  "Logging": {',
        '    "LogLevel": {',
        '      "Default": "Warning"',
        '    }',
        '  }',
        '}'
      ].join("\n");

      /* ---------------- Tolerant config tokenizer ----------------
         Handles JSON, JSON-with-comments, and plain key: value / key = value
         lines. Tracks exact 1-based line numbers. Comment contents are kept
         as comment tokens so commented-out settings can be graded as
         COMMENTED / NOT ACTIVE. */
      function tokenize(text, lineOffset){
        var tokens = [];
        var i = 0, n = text.length;
        var line = 1 + (lineOffset || 0);
        while (i < n){
          var c = text.charAt(i);
          if (c === "\n"){ line++; i++; continue; }
          if (c === " " || c === "\t" || c === "\r" || c === ","){ i++; continue; }
          if (c === "/" && text.charAt(i + 1) === "/"){
            var s = "", j = i + 2;
            while (j < n && text.charAt(j) !== "\n"){ s += text.charAt(j); j++; }
            tokens.push({ type: "comment", value: s, line: line });
            i = j; continue;
          }
          if (c === "#"){
            var s2 = "", j2 = i + 1;
            while (j2 < n && text.charAt(j2) !== "\n"){ s2 += text.charAt(j2); j2++; }
            tokens.push({ type: "comment", value: s2, line: line });
            i = j2; continue;
          }
          if (c === "/" && text.charAt(i + 1) === "*"){
            var startLine = line, buf = "", j3 = i + 2;
            while (j3 < n && !(text.charAt(j3) === "*" && text.charAt(j3 + 1) === "/")){
              if (text.charAt(j3) === "\n") line++;
              buf += text.charAt(j3); j3++;
            }
            tokens.push({ type: "comment", value: buf, line: startLine });
            i = Math.min(j3 + 2, n); continue;
          }
          if (c === '"'){
            var v = "", startL = line; i++;
            while (i < n && text.charAt(i) !== '"'){
              if (text.charAt(i) === "\\" && i + 1 < n){ v += text.charAt(i + 1); i += 2; }
              else { if (text.charAt(i) === "\n") line++; v += text.charAt(i); i++; }
            }
            i++;
            tokens.push({ type: "string", value: v, line: startL });
            continue;
          }
          if ("{}[]:=".indexOf(c) >= 0){ tokens.push({ type: c, line: line }); i++; continue; }
          var m = /^[^\s{}[\]:,="#]+/.exec(text.substring(i));
          if (m){ tokens.push({ type: "word", value: m[0], line: line }); i += m[0].length; continue; }
          i++;
        }
        return tokens;
      }

      /* Recursive-descent walk over tokens -> flat list of leaf entries
         { key, path[], value, line, commented }. */
      function parseTokens(tokens, commentedFlag){
        var entries = [];
        var pos = 0;
        function parseValue(parentPath, keyTok){
          var t = tokens[pos];
          if (!t) return;
          if (t.type === "{"){ pos++; parseObject(parentPath.concat([keyTok.value])); return; }
          if (t.type === "["){
            pos++;
            var items = [];
            while (pos < tokens.length){
              var a = tokens[pos];
              if (a.type === "]"){ pos++; break; }
              if (a.type === "{"){ pos++; parseObject(parentPath.concat([keyTok.value])); continue; }
              if (a.type === "string" || a.type === "word"){ items.push(String(a.value)); pos++; continue; }
              pos++;
            }
            entries.push({ key: keyTok.value, path: parentPath.slice(), value: items.join(","), line: keyTok.line, commented: commentedFlag });
            return;
          }
          pos++;
          entries.push({ key: keyTok.value, path: parentPath.slice(), value: String(t.value), line: keyTok.line, commented: commentedFlag });
        }
        function parseObject(path){
          while (pos < tokens.length){
            var t = tokens[pos];
            if (t.type === "}"){ pos++; return; }
            if (t.type === "{"){ pos++; parseObject(path); continue; }
            if (t.type === "string" || t.type === "word"){
              var keyTok = t; pos++;
              var sep = tokens[pos];
              if (sep && (sep.type === ":" || sep.type === "=")){ pos++; parseValue(path, keyTok); }
              continue;
            }
            pos++;
          }
        }
        parseObject([]);
        return entries;
      }

      function extractEntries(text){
        var tokens = tokenize(text, 0);
        var comments = [], clean = [];
        for (var i = 0; i < tokens.length; i++){
          if (tokens[i].type === "comment") comments.push(tokens[i]); else clean.push(tokens[i]);
        }
        var entries = parseTokens(clean, false);
        for (var k = 0; k < comments.length; k++){
          var inner = tokenize(comments[k].value, comments[k].line - 1);
          var innerClean = [];
          for (var q = 0; q < inner.length; q++){ if (inner[q].type !== "comment") innerClean.push(inner[q]); }
          var ce = parseTokens(innerClean, true);
          for (var r = 0; r < ce.length; r++) entries.push(ce[r]);
        }
        return entries;
      }

      /* ---------------- Gradability ---------------- */
      var KNOWN_KEYS = {
        tokenkey: 1, port: 1, ipaddresses: 1, baseurl: 1, cachedir: 1,
        logging: 1, loglevel: 1, minimumlevel: 1, serilog: 1, urls: 1
      };
      function isGradable(text, entries){
        if (!text || !text.replace(/\s+/g, "")) return false;
        try {
          var o = JSON.parse(text);
          if (o && typeof o === "object" && !Array.isArray(o)) return true;
        } catch (e) { /* not strict JSON — key lines may still grade */ }
        if (entries.length >= 2) return true;
        if (entries.length === 1 && KNOWN_KEYS[entries[0].key.toLowerCase()]) return true;
        return false;
      }

      /* ---------------- Checks ---------------- */
      var EXAMPLE_PATTERNS = ["example", "changeme", "change-me", "change_me", "change me",
        "placeholder", "your-", "your ", "default", "super-secret", "secretkey", "secret-key",
        "password", "letmein", "please-change"];
      function isExampleValue(v){
        var s = v.toLowerCase();
        for (var i = 0; i < EXAMPLE_PATTERNS.length; i++){
          if (s.indexOf(EXAMPLE_PATTERNS[i]) >= 0) return true;
        }
        if (v.length > 0 && /^(.)\1*$/.test(v)) return true;
        return false;
      }
      var SECRET_KEY_RE = /(password|passwd|pwd|secret|api[-_]?key|access[-_]?key|private[-_]?key|credential|token)/i;
      var LOOPBACK = { "127.0.0.1": 1, "::1": 1, "localhost": 1 };

      function splitAddrs(v){
        var parts = String(v).split(",");
        var out = [];
        for (var i = 0; i < parts.length; i++){ var t = parts[i].replace(/\s+/g, ""); if (t) out.push(t); }
        return out;
      }
      function isAllInterface(v){
        var toks = splitAddrs(v);
        for (var i = 0; i < toks.length; i++){
          if (toks[i] === "0.0.0.0" || toks[i] === "::" || toks[i] === "*") return toks[i];
        }
        return null;
      }
      function isRestricted(v){
        var toks = splitAddrs(v);
        if (!toks.length) return false;
        for (var i = 0; i < toks.length; i++){ if (!LOOPBACK[toks[i].toLowerCase()]) return false; }
        return true;
      }

      /* Per-entry checks. A secret VALUE is never copied into a finding —
         only the key name, the line, and the value length. */
      function perEntryFindings(e, status){
        var out = [];
        var key = e.key, lk = key.toLowerCase(), v = (e.value == null ? "" : String(e.value));
        function F(sev, title, detail, fix, len){
          out.push({ severity: sev, status: status, key: key, line: e.line,
            valueLength: (len == null ? null : len), title: title, detail: detail, fix: fix });
        }
        if (lk === "tokenkey"){
          if (v.length === 0){
            F("CRITICAL", "TokenKey is empty",
              "The JWT signing key is present but empty, so session tokens cannot be signed or verified safely.",
              "Set TokenKey to a fresh random value of at least 32 characters.", 0);
          } else if (isExampleValue(v)){
            F("CRITICAL", "TokenKey is an example / placeholder value",
              "The signing key matches a known placeholder pattern. Anyone who has seen the public examples can forge session tokens and sign in as any user. The value itself is not shown here — only its length: " + v.length + " characters.",
              "Generate a fresh random key of at least 32 characters, keep it out of any shared or shipped example config, and restart the server.", v.length);
          } else if (v.length < 32){
            F("CRITICAL", "TokenKey is too short (" + v.length + " characters)",
              "Signing keys under 32 characters can be brute-forced, letting an attacker forge session tokens. The value itself is not shown here — only its length.",
              "Replace it with a random key of at least 32 characters (64 is better).", v.length);
          }
        }
        if (lk === "ipaddresses"){
          var bad = isAllInterface(v);
          if (bad){
            F("HIGH", "Server binds to all network interfaces",
              "IpAddresses includes " + bad + ", so Kavita listens on every interface the machine has — anyone who can reach the machine can reach the login page, whether or not you meant to publish it.",
              "Bind to 127.0.0.1 (and ::1 for IPv6 loopback) and reach Kavita through a reverse proxy, or bind only the one LAN address you intend.");
          }
        }
        if (lk === "baseurl"){
          if (/^http:\/\//i.test(v)){
            F("HIGH", "BaseUrl uses plain http://",
              "The base URL starts with http://, so logins and session tokens cross the network unencrypted wherever this address is used.",
              "Serve Kavita over https:// (a reverse proxy with a certificate is the usual way) and update BaseUrl to match.");
          }
        }
        var fullPath = (e.path.concat([key])).join(".").toLowerCase();
        var lv = v.toLowerCase();
        if ((fullPath.indexOf("log") >= 0 || lk === "minimumlevel") &&
            (lv === "debug" || lv === "verbose" || lv === "trace")){
          F("MEDIUM", "Verbose logging is on (" + v + ")",
            "Debug-level logging writes request and library detail to disk on a deployed server — it slows the server down and can record more about your library and users than you would choose to keep.",
            "Set the logging level to Information or Warning for a deployed server; turn Debug on only while troubleshooting.");
        }
        if (lk === "cachedir"){
          F("LOW", "CacheDir is set in this config",
            "A cache directory is configured. Cache folders can hold cover images and session-adjacent data, so where this path points matters.",
            "Confirm the cache folder sits outside any web-served directory and is not readable by other users on the machine.", null);
        }
        if (lk !== "tokenkey" && SECRET_KEY_RE.test(key) && v.length > 0){
          F("HIGH", "Plaintext secret stored in config: " + key,
            "A secret-like value sits in the config in plain text, where anyone who can read the file — a backup, a screenshot, a shared support bundle — gets the secret too. Reported by key name and length only (" + v.length + " characters); the value is never shown.",
            "Move the secret to an environment variable or a secrets file outside the config, and rotate it, since it has been sitting in plain text.", v.length);
        }
        return out;
      }

      /* Cross-entry checks that only make sense on the active config. */
      function crossFindings(active){
        var out = [];
        var i, e;
        var hasToken = false;
        for (i = 0; i < active.length; i++){ if (active[i].key.toLowerCase() === "tokenkey") hasToken = true; }
        if (!hasToken){
          out.push({ severity: "CRITICAL", status: "ACTIVE", key: "TokenKey", line: null, valueLength: null,
            title: "TokenKey is missing",
            detail: "No active TokenKey setting was found in this config. Without a signing key, Kavita either falls back to a generated or example key or cannot protect sessions the way you expect.",
            fix: "Add a TokenKey of at least 32 random characters to the config before deploying." });
        }
        var portEntry = null, ipEntries = [];
        for (i = 0; i < active.length; i++){
          e = active[i];
          if (e.key.toLowerCase() === "port" && !portEntry) portEntry = e;
          if (e.key.toLowerCase() === "ipaddresses") ipEntries.push(e);
        }
        if (portEntry){
          if (!ipEntries.length){
            out.push({ severity: "HIGH", status: "ACTIVE", key: "Port", line: portEntry.line, valueLength: null,
              title: "Port exposed with no bind restriction",
              detail: "Port " + String(portEntry.value) + " is configured, but no IpAddresses restriction sits alongside it — the port answers on every network interface the machine has.",
              fix: "Add an IpAddresses entry that binds 127.0.0.1 (and ::1), or the single LAN address you intend, and put any wider access behind a reverse proxy." });
          } else {
            var anyAll = false, anyRestricted = false;
            for (i = 0; i < ipEntries.length; i++){
              if (isAllInterface(ipEntries[i].value)) anyAll = true;
              if (isRestricted(ipEntries[i].value)) anyRestricted = true;
            }
            if (anyAll && !anyRestricted){
              out.push({ severity: "MEDIUM", status: "ACTIVE", key: "Port", line: portEntry.line, valueLength: null,
                title: "Port is reachable on every interface",
                detail: "Port " + String(portEntry.value) + " is set while IpAddresses binds all interfaces, so this port is reachable from anywhere the machine is reachable.",
                fix: "Restrict IpAddresses to loopback or one LAN address; the bind finding above carries the detail." });
            }
          }
        }
        return out;
      }

      var SEV_RANK = { CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3 };
      function analyze(text){
        var entries = extractEntries(text || "");
        if (!isGradable(text || "", entries)){
          return {
            tool: "J-Dawgs Kavita Server Config Safety Auditor™",
            generatedAt: new Date().toISOString(),
            verdict: "NOT ENOUGH TO GRADE",
            counts: { critical: 0, high: 0, medium: 0, low: 0, commentedNotActive: 0 },
            findings: [],
            note: "Secret values are never included in this report. Findings about secrets name the key, its line, and the value length only."
          };
        }
        var active = [], commented = [], i;
        for (i = 0; i < entries.length; i++){ (entries[i].commented ? commented : active).push(entries[i]); }
        var findings = crossFindings(active);
        for (i = 0; i < active.length; i++) findings = findings.concat(perEntryFindings(active[i], "ACTIVE"));
        for (i = 0; i < commented.length; i++) findings = findings.concat(perEntryFindings(commented[i], "COMMENTED / NOT ACTIVE"));
        findings.sort(function(a, b){
          var la = (a.line == null ? 0 : a.line), lb = (b.line == null ? 0 : b.line);
          if (la !== lb) return la - lb;
          return SEV_RANK[a.severity] - SEV_RANK[b.severity];
        });
        var counts = { critical: 0, high: 0, medium: 0, low: 0, commentedNotActive: 0 };
        for (i = 0; i < findings.length; i++){
          var f = findings[i];
          if (f.status !== "ACTIVE"){ counts.commentedNotActive++; continue; }
          if (f.severity === "CRITICAL") counts.critical++;
          else if (f.severity === "HIGH") counts.high++;
          else if (f.severity === "MEDIUM") counts.medium++;
          else if (f.severity === "LOW") counts.low++;
        }
        var verdict;
        if (counts.critical > 0) verdict = "DO NOT DEPLOY";
        else if (counts.high > 0 || counts.medium > 0) verdict = "DEPLOY WITH FIXES";
        else verdict = "SAFE TO DEPLOY";
        return {
          tool: "J-Dawgs Kavita Server Config Safety Auditor™",
          generatedAt: new Date().toISOString(),
          verdict: verdict,
          counts: counts,
          findings: findings,
          note: "Secret values are never included in this report. Findings about secrets name the key, its line, and the value length only."
        };
      }

      /* ---------------- Report rendering ---------------- */
      function reportToText(r){
        var lines = [];
        lines.push("J-Dawgs Kavita Server Config Safety Auditor™ — Config Audit Report");
        lines.push("Generated: " + r.generatedAt);
        lines.push("Verdict: " + r.verdict);
        lines.push("Active findings: " + r.counts.critical + " critical, " + r.counts.high + " high, " +
          r.counts.medium + " medium, " + r.counts.low + " low · " +
          r.counts.commentedNotActive + " commented / not active");
        lines.push(r.note);
        lines.push("");
        if (!r.findings.length){
          lines.push(r.verdict === "NOT ENOUGH TO GRADE"
            ? "Nothing gradeable was found in the input — paste a Kavita appsettings.json or config key lines and run the audit again."
            : "No findings. Every check passed on the settings present in this config.");
        }
        for (var i = 0; i < r.findings.length; i++){
          var f = r.findings[i];
          lines.push("[" + f.severity + (f.status !== "ACTIVE" ? " · " + f.status : "") + "] " +
            (f.line == null ? "Not present" : "Line " + f.line) + " — " + f.key + ": " + f.title);
          lines.push("  " + f.detail);
          lines.push("  Fix: " + f.fix);
          if (f.valueLength != null) lines.push("  (Secret reported by length only: " + f.valueLength + " characters. Value never shown.)");
          lines.push("");
        }
        return lines.join("\n");
      }

      function esc(s){
        return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
          .replace(/"/g, "&quot;");
      }

      var currentReport = null;
  return { "analyze": (typeof analyze !== 'undefined' ? analyze : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_RISKY": (typeof EXAMPLE_RISKY !== 'undefined' ? EXAMPLE_RISKY : undefined), "EXAMPLE_HARDENED": (typeof EXAMPLE_HARDENED !== 'undefined' ? EXAMPLE_HARDENED : undefined), "EXAMPLE_PATTERNS": (typeof EXAMPLE_PATTERNS !== 'undefined' ? EXAMPLE_PATTERNS : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["analyze"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-kavita-server-config-safety-auditortm',
  name: 'J-Dawgs Kavita Server Config Safety Auditor',
  description: 'Host tools only tell you the server started; ours grades a pasted Kavita appsettings.json/config offline into one deploy verdict — TokenKey length, all-interface binds, http base URL, and debug logging; secrets by key/line/length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["analyze"]) return { ok: false, output: null, summary: 'Extracted core has no analyze function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_RISKY": __core["EXAMPLE_RISKY"], "EXAMPLE_HARDENED": __core["EXAMPLE_HARDENED"], "EXAMPLE_PATTERNS": __core["EXAMPLE_PATTERNS"] }
};
