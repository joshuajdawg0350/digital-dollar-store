'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Invoice & Payment-Details Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

  "use strict";

  /* ---------- helpers ---------- */
  function $(id){ return document.getElementById(id); }
  function esc(s){
    return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")
      .replace(/"/g,"&quot;").replace(/'/g,"&#39;");
  }
  function centsOf(numStr){ return Math.round(parseFloat(String(numStr).replace(/,/g,""))*100); }
  var SYM = "$";
  function fmt(cents){
    var neg = cents < 0; var a = Math.abs(cents);
    var whole = Math.floor(a/100), rem = a % 100;
    var w = String(whole).replace(/\B(?=(\d{3})+(?!\d))/g,",");
    return (neg?"-":"") + SYM + w + "." + (rem<10?"0":"") + rem;
  }
  function fmtDate(d){
    return d.toLocaleDateString("en-GB",{day:"numeric",month:"short",year:"numeric"});
  }
  function isoDate(d){
    function p(n){ return (n<10?"0":"")+n; }
    return d.getFullYear()+"-"+p(d.getMonth()+1)+"-"+p(d.getDate());
  }
  function addDays(d, n){ var x = new Date(d.getFullYear(), d.getMonth(), d.getDate()); x.setDate(x.getDate()+n); return x; }

  /* Mask any account-like number in arbitrary display text: last 4 only. */
  function maskLine(text){
    var s = String(text);
    s = s.replace(/\b[A-Z]{2}\d{2}(?:[ ]?[A-Z0-9]{4}){2,7}(?:[ ]?[A-Z0-9]{1,3})?\b/gi, function(m){
      var norm = m.toUpperCase().replace(/[^A-Z0-9]/g,"");
      return "••••" + norm.slice(-4);
    });
    s = s.replace(/\d(?:[ ]?\d){8,}/g, function(m){
      var digits = m.replace(/\D/g,"");
      return "••••" + digits.slice(-4);
    });
    return s;
  }

  /* ---------- money tokens ---------- */
  function moneyTokens(line){
    var re = /([$€£¥]|USD|EUR|GBP|CAD|AUD|CHF|JPY)?[ ]?(\d{1,3}(?:,\d{3})+(?:\.\d{1,2})?|\d+\.\d{1,2}|\d{1,3}(?:,\d{3})*|\d+)(?:[ ]?(USD|EUR|GBP|CAD|AUD|CHF|JPY))?/g;
    var out = [], m;
    while((m = re.exec(line)) !== null){
      var numStr = m[2];
      var marker = m[1] || m[3] || null;
      var hasDec = /\.\d{1,2}$/.test(numStr);
      var hasComma = numStr.indexOf(",") >= 0;
      if(!marker && !hasDec && !hasComma) continue; /* plain integer: quantity, year, etc. */
      out.push({ cents: centsOf(numStr), marker: marker, start: m.index, end: m.index + m[0].length, raw: m[0] });
    }
    return out;
  }

  /* ---------- dates ---------- */
  var MONTHS = {jan:1,feb:2,mar:3,apr:4,may:5,jun:6,jul:7,aug:8,sep:9,oct:10,nov:11,dec:12};
  function mkDate(y, mo, d){ var dt = new Date(y, mo-1, d); return isNaN(dt.getTime()) ? null : dt; }
  function parseDate(s){
    var m;
    if(m = s.match(/(\d{4})-(\d{1,2})-(\d{1,2})/)) return mkDate(+m[1], +m[2], +m[3]);
    if(m = s.match(/\b(\d{1,2})\/(\d{1,2})\/(\d{4})\b/)) return mkDate(+m[3], +m[1], +m[2]);
    if(m = s.match(/\b(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.?\s+(\d{1,2})(?:st|nd|rd|th)?,?\s+(\d{4})/i))
      return mkDate(+m[3], MONTHS[m[1].toLowerCase().slice(0,3)], +m[2]);
    if(m = s.match(/\b(\d{1,2})(?:st|nd|rd|th)?\s+(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.?,?\s+(\d{4})/i))
      return mkDate(+m[3], MONTHS[m[2].toLowerCase().slice(0,3)], +m[1]);
    return null;
  }
  function dayOnly(d){ return new Date(d.getFullYear(), d.getMonth(), d.getDate()); }

  /* ---------- names & accounts ---------- */
  function cleanName(s){
    return String(s).replace(/\s+/g," ").replace(/[.\s]+$/,"").trim();
  }
  function normName(s){
    return String(s).toLowerCase().replace(/[^a-z0-9 ]/g,"").replace(/\s+/g," ").trim();
  }
  function namesMatch(a, b){
    var na = normName(a), nb = normName(b);
    if(!na || !nb) return false;
    if(na === nb) return true;
    if(na.length >= 4 && nb.indexOf(na) >= 0) return true;
    if(nb.length >= 4 && na.indexOf(nb) >= 0) return true;
    return false;
  }
  function extractAccounts(text){
    var found = [], seen = {}, m;
    function add(rawVal, kind){
      var norm = String(rawVal).toUpperCase().replace(/[^A-Z0-9]/g,"");
      if(norm.length < 6 || seen[norm]) return;
      seen[norm] = 1;
      found.push({ norm: norm, last4: norm.slice(-4), kind: kind });
    }
    var ibanRe = /\b[A-Z]{2}\d{2}(?:[ ]?[A-Z0-9]{4}){2,7}(?:[ ]?[A-Z0-9]{1,3})?\b/gi;
    while((m = ibanRe.exec(text)) !== null) add(m[0], "IBAN");
    var labRe = /(?:account|acct|a\/c|routing|sort code)\s*(?:no\.?|number|#)?\s*[:#\-]?\s*([A-Z0-9][A-Z0-9 \-]{4,}\d)/gi;
    while((m = labRe.exec(text)) !== null) add(m[1], "account");
    return found;
  }
  function payeeFromBlock(text){
    var lines = String(text).split(/\r?\n/);
    for(var i = 0; i < lines.length; i++){
      var m = lines[i].match(/(?:payee|pay to|account name|name|vendor)\s*[:\-]\s*(.+)$/i);
      if(m) return cleanName(m[1]);
    }
    for(var j = 0; j < lines.length; j++){
      var t = lines[j].trim();
      if(t && !/(iban|account|acct|routing|sort code)/i.test(t) && /[A-Za-z]/.test(t)) return cleanName(t);
    }
    return null;
  }

  /* ---------- audit engine ---------- */
  var MULT_RE = /(\d+(?:\.\d+)?)\s*(?:×|x|\*)\s*([$€£¥]?\s*\d[\d,]*(?:\.\d{1,2})?)/i;

  function stripTokens(line, toks){
    var s = line;
    toks.slice().reverse().forEach(function(tk){ s = s.slice(0, tk.start) + " " + s.slice(tk.end); });
    return s.replace(/\s+/g," ").replace(/[\s—–\-:·]+$/,"").trim();
  }

  function audit(invoiceText, trustedText, today){
    var findings = [];
    var checks = [];
    function F(sev, title, detail, quote, lineNo){ findings.push({sev:sev, title:title, detail:detail, quote:quote||null, lineNo:lineNo||null}); }
    function C(status, text){ checks.push({status:status, text:text}); }

    var lines = invoiceText.split(/\r?\n/);
    var items = [];
    var subtotal = null, tax = null, taxRate = null, total = null, discount = null, shipping = null;
    var invDate = null, dueDate = null;
    var payeeInv = null;
    var currencySet = {};
    var anyAmount = false;

    lines.forEach(function(raw, idx){
      var lineNo = idx + 1;
      var t = raw.trim();
      if(!t) return;
      var toks = moneyTokens(t);
      if(toks.length) anyAmount = true;
      toks.forEach(function(tk){ if(tk.marker) currencySet[tk.marker] = true; });

      var d;
      if(/due date|payment due|due by|due on|pay by/i.test(t)){ d = parseDate(t); if(d && !dueDate) dueDate = d; }
      else if(/invoice date|date issued|date of invoice|issued on/i.test(t)){ d = parseDate(t); if(d && !invDate) invDate = d; }
      else if(/^date\s*[:\-]/i.test(t)){ d = parseDate(t); if(d && !invDate) invDate = d; }

      var pm = t.match(/(?:pay to|payee|remit to|remit payment to)\s*[:\-]\s*(.+)$/i)
            || t.match(/(?:from|vendor|billed by|issued by|seller)\s*[:\-]\s*(.+)$/i);
      if(pm && !payeeInv) payeeInv = cleanName(pm[1]);

      if(/^sub-?total\b/i.test(t)){ if(toks.length) subtotal = { cents: toks[toks.length-1].cents, lineNo: lineNo }; return; }
      if(/^(grand\s+)?total\b/i.test(t) || /^amount due\b/i.test(t) || /^balance due\b/i.test(t)){
        if(toks.length) total = { cents: toks[toks.length-1].cents, lineNo: lineNo, raw: t }; return;
      }
      if(/^(sales\s+)?tax\b/i.test(t) || /^vat\b/i.test(t) || /^gst\b/i.test(t) || /^hst\b/i.test(t)){
        if(toks.length) tax = { cents: toks[toks.length-1].cents, lineNo: lineNo };
        var rm = t.match(/(\d+(?:\.\d+)?)\s*%/); if(rm) taxRate = parseFloat(rm[1]);
        return;
      }
      if(/^discount\b/i.test(t)){ if(toks.length) discount = { cents: Math.abs(toks[toks.length-1].cents), lineNo: lineNo }; return; }
      if(/^(shipping|freight|delivery charges?)\b/i.test(t)){ if(toks.length) shipping = { cents: toks[toks.length-1].cents, lineNo: lineNo }; return; }

      if(/(iban|routing|sort code|account\s*(no\.?|number|#)|bank account)/i.test(t)) return;
      if(/^(invoice|inv\.?|date|due|from|to|bill to|ship to|pay to|payee|remit|iban|account|acct|routing|sort code|bank|vendor|seller|buyer|customer|terms|note|ref|reference|phone|tel|email|www\.|http)/i.test(t)) return;
      if(!toks.length) return;

      var mult = t.match(MULT_RE);
      if(mult){
        var qty = parseFloat(mult[1]);
        var unitCents = centsOf(mult[2].replace(/[$€£¥\s]/g,""));
        var multEnd = mult.index + mult[0].length;
        var after = toks.filter(function(tk){ return tk.start >= multEnd; });
        var hasStatedExt = after.length > 0;
        var ext = hasStatedExt ? after[after.length-1].cents : Math.round(qty * unitCents);
        var desc = t.slice(0, mult.index).replace(/[\s—–\-:·]+$/,"").trim();
        items.push({ lineNo: lineNo, desc: desc, qty: qty, unit: unitCents, ext: ext, statedExt: hasStatedExt, raw: t });
      } else {
        items.push({ lineNo: lineNo, desc: stripTokens(t, toks), qty: null, unit: null, ext: toks[toks.length-1].cents, statedExt: true, raw: t });
      }
    });

    /* --- invoice numbers --- */
    var numCounts = {}, numOrder = [];
    var invNumRe = /(?:invoice|inv\.?)\s*(?:#|no\.?|number|num)\s*[:#]?\s*([A-Za-z0-9][A-Za-z0-9\-\/]*)/gi, nm;
    while((nm = invNumRe.exec(invoiceText)) !== null){
      var key = nm[1].toUpperCase();
      if(!numCounts[key]){ numCounts[key] = 0; numOrder.push(key); }
      numCounts[key]++;
    }
    if(numOrder.length === 0){
      F("WARNING", "Missing invoice number", "No invoice number could be found anywhere in the pasted text. An invoice you cannot reference is hard to dispute or match to a payment.");
    } else {
      numOrder.forEach(function(k){
        if(numCounts[k] >= 2){
          F("WARNING", "Duplicate invoice number", "Invoice number " + k + " appears " + numCounts[k] + " times in the pasted text. The same number twice can mean a re-sent or double-entered bill.");
        }
      });
    }

    /* --- line math --- */
    var sumExt = 0;
    items.forEach(function(it){
      sumExt += it.ext;
      if(it.qty !== null && it.statedExt){
        var expected = Math.round(it.qty * it.unit);
        if(expected !== it.ext){
          F("WARNING", "Line math mismatch — line " + it.lineNo,
            "\"" + (it.desc || "Line item") + "\": " + it.qty + " × " + fmt(it.unit) + " = " + fmt(expected) +
            ", but the line states " + fmt(it.ext) + " — a difference of " + fmt(Math.abs(it.ext - expected)) + ". The arithmetic is shown, not corrected.",
            it.raw, it.lineNo);
          C("bad", "Line " + it.lineNo + " (" + (it.desc || "line item") + "): " + it.qty + " × " + fmt(it.unit) + " = " + fmt(expected) + " expected — invoice states " + fmt(it.ext) + ".");
        } else {
          C("ok", "Line " + it.lineNo + " (" + (it.desc || "line item") + "): " + it.qty + " × " + fmt(it.unit) + " = " + fmt(it.ext) + " — matches.");
        }
      } else if(it.qty !== null){
        C("na", "Line " + it.lineNo + " (" + (it.desc || "line item") + "): " + it.qty + " × " + fmt(it.unit) + " = " + fmt(it.ext) + " — no separate extended amount is printed on the line to check against.");
      } else {
        C("na", "Line " + it.lineNo + " (" + (it.desc || "line item") + "): extended amount " + fmt(it.ext) + " — no quantity × unit price on the line to recompute.");
      }
    });

    /* --- duplicate line items --- */
    var groups = {}, gOrder = [];
    items.forEach(function(it){
      var descKey = (it.desc || "").toLowerCase().replace(/[^a-z0-9]+/g," ").trim();
      if(!descKey) return;
      var key = descKey + "|" + it.ext;
      if(!groups[key]){ groups[key] = []; gOrder.push(key); }
      groups[key].push(it);
    });
    gOrder.forEach(function(k){
      var g = groups[k];
      if(g.length >= 2){
        F("WARNING", "Duplicate line item",
          "\"" + g[0].desc + "\" at " + fmt(g[0].ext) + " appears on line " + g[0].lineNo + " and again on line " + g[1].lineNo +
          ". The same description at the same amount twice may be a genuine second charge — or the same charge billed twice.",
          g[1].raw, g[1].lineNo);
      }
    });

    /* --- subtotal --- */
    if(items.length && subtotal){
      if(sumExt !== subtotal.cents){
        F("WARNING", "Subtotal does not match the line items",
          "The extended amounts add to " + fmt(sumExt) + ", but the stated subtotal is " + fmt(subtotal.cents) +
          " — " + fmt(Math.abs(sumExt - subtotal.cents)) + (sumExt > subtotal.cents ? " less than" : " more than") + " the true sum.",
          lines[subtotal.lineNo-1], subtotal.lineNo);
        C("bad", "Subtotal: line items sum to " + fmt(sumExt) + " — stated subtotal is " + fmt(subtotal.cents) + ".");
      } else {
        C("ok", "Subtotal: line items sum to " + fmt(sumExt) + " — matches the stated subtotal.");
      }
    } else if(items.length && !subtotal){
      C("na", "Subtotal: no subtotal line was pasted — the line items sum to " + fmt(sumExt) + ", but there is no stated subtotal to check it against.");
    } else if(!items.length){
      C("na", "Line items: none could be identified in the pasted text, so no line math or subtotal check is possible.");
    }

    /* --- tax --- */
    var taxBase = subtotal ? subtotal.cents : (items.length ? sumExt : null);
    if(tax && taxRate !== null && taxBase !== null){
      var expectedTax = Math.round(taxBase * taxRate / 100);
      if(Math.abs(expectedTax - tax.cents) > 1){
        F("WARNING", "Tax amount does not match the stated rate",
          "Tax at " + taxRate + "% of " + fmt(taxBase) + " is " + fmt(expectedTax) + ", but the invoice states tax of " + fmt(tax.cents) + ".",
          lines[tax.lineNo-1], tax.lineNo);
        C("bad", "Tax: " + taxRate + "% × " + fmt(taxBase) + " = " + fmt(expectedTax) + " expected — invoice states " + fmt(tax.cents) + ".");
      } else {
        C("ok", "Tax: " + taxRate + "% × " + fmt(taxBase) + " = " + fmt(tax.cents) + " — matches the stated tax.");
      }
    } else if(tax && taxRate === null){
      C("na", "Tax: an amount of " + fmt(tax.cents) + " is stated, but no tax rate appears in the pasted text, so the amount cannot be recomputed.");
    } else if(!tax && taxRate !== null){
      C("na", "Tax: a rate of " + taxRate + "% appears, but no tax amount line was pasted to check.");
    }

    /* --- total --- */
    if(!total){
      F("WARNING", "Missing total", "No total, amount due, or balance due could be found in the pasted text. There is no single figure to pay against.");
      C("na", "Total: NOT CHECKABLE — no total line was pasted.");
    } else if(taxBase === null){
      F("INFO", "Total cannot be recomputed",
        "The stated total is " + fmt(total.cents) + ", but there is no subtotal and no set of line items to recompute it from. It is reported NOT CHECKABLE — never assumed right.");
      C("na", "Total: NOT CHECKABLE — stated total is " + fmt(total.cents) + ", but nothing in the pasted text rebuilds it.");
    } else {
      var expectedTotal = taxBase + (tax ? tax.cents : 0) - (discount ? discount.cents : 0) + (shipping ? shipping.cents : 0);
      var seg = [ (subtotal ? "stated subtotal " : "line-item sum ") + fmt(taxBase) ];
      if(tax) seg.push("+ tax " + fmt(tax.cents));
      if(discount) seg.push("− discount " + fmt(discount.cents));
      if(shipping) seg.push("+ shipping " + fmt(shipping.cents));
      var recon = seg.join(" ");
      if(Math.abs(expectedTotal - total.cents) > 1){
        F("BLOCKER", "Total does not add up",
          "Recomputed from the invoice's own lines — " + recon + " — the total should be " + fmt(expectedTotal) +
          ", but the invoice asks for " + fmt(total.cents) + ". Paying as-is means paying the wrong amount.",
          total.raw, total.lineNo);
        C("bad", "Total: " + recon + " = " + fmt(expectedTotal) + " expected — invoice states " + fmt(total.cents) + ".");
      } else {
        C("ok", "Total: " + recon + " = " + fmt(total.cents) + " — matches the stated total.");
      }
    }

    /* --- currency --- */
    var markers = Object.keys(currencySet);
    if(markers.length >= 2){
      F("WARNING", "More than one currency on the invoice",
        "Amounts appear in " + markers.join(" and ") + ". A bill that mixes currencies can be paid in the wrong one, or converted at a rate you did not agree to.");
    } else if(markers.length === 0 && anyAmount){
      F("INFO", "No currency stated", "Amounts appear in the pasted text, but no currency symbol or code appears anywhere on the invoice — the currency of every amount is unstated.");
    } else if(markers.length === 1){
      C("ok", "Currency: every marked amount uses " + markers[0] + " — consistent throughout.");
    }

    /* --- dates --- */
    if(invDate && dueDate){
      if(dayOnly(dueDate) < dayOnly(invDate)){
        F("BLOCKER", "Due date is before the invoice date",
          "The invoice is dated " + fmtDate(invDate) + " but says payment is due " + fmtDate(dueDate) + " — before the bill was even issued. Dates that cannot both be right are a classic sign of a doctored or mis-sent invoice.");
        C("bad", "Dates: due date " + fmtDate(dueDate) + " is earlier than the invoice date " + fmtDate(invDate) + ".");
      } else {
        C("ok", "Dates: invoice date " + fmtDate(invDate) + ", due date " + fmtDate(dueDate) + " — due date is not before the invoice date.");
      }
    } else {
      C("na", "Dates: " + (!invDate && !dueDate ? "no invoice date or due date could be found in the pasted text." :
        !invDate ? "no invoice date could be found, so the due date cannot be checked against it." :
        "no due date could be found in the pasted text."));
    }
    if(dueDate && dayOnly(dueDate) < dayOnly(today)){
      F("WARNING", "Due date has already passed",
        "Payment was due " + fmtDate(dueDate) + ", and today is " + fmtDate(today) + " by the date you entered. A bill already past due deserves a second look before it is paid in a hurry.");
    }

    /* --- missing payee --- */
    if(!payeeInv){
      F("WARNING", "Missing payee", "No payee could be identified on the invoice (no \"Pay to\", \"Payee\", \"From\" or similar line). You cannot confirm who the money is meant for.");
    }

    /* --- payment-details cross-check --- */
    var payStatus, payDetail;
    if(!trustedText || !trustedText.trim()){
      payStatus = "NOT CHECKED";
      payDetail = "No trusted payment details were pasted, so this check did not run. Changed bank details — the most expensive invoice trick there is — would not be caught.";
      F("INFO", "Payment-details cross-check: NOT CHECKED",
        "No trusted payment details were supplied, so the payee and bank details on this invoice were compared against nothing. NOT CHECKED never means passed.");
      C("na", "Payment details: NOT CHECKED — no trusted details supplied.");
    } else {
      var trustedPayee = payeeFromBlock(trustedText);
      var invAcc = extractAccounts(invoiceText);
      var truAcc = extractAccounts(trustedText);
      var changed = invAcc.filter(function(a){ return !truAcc.some(function(t){ return t.norm === a.norm; }); });
      var problems = [];

      if(trustedPayee && payeeInv){
        if(!namesMatch(payeeInv, trustedPayee)){
          F("BLOCKER", "PAYEE NAME CHANGED",
            "The invoice names the payee as \"" + payeeInv + "\", but the trusted details on file say \"" + trustedPayee + "\". A payee name that changes between bills is a stop-and-verify signal, not a detail.");
          problems.push("payee");
        } else {
          C("ok", "Payee: \"" + payeeInv + "\" matches the trusted payee on file.");
        }
      } else if(trustedPayee && !payeeInv){
        C("na", "Payee: the trusted details name \"" + trustedPayee + "\", but no payee could be identified on the invoice to compare.");
      }

      if(truAcc.length && changed.length){
        var invList = changed.map(function(a){ return "••••" + a.last4 + " (" + a.kind + ")"; }).join(", ");
        var truList = truAcc.map(function(a){ return "••••" + a.last4; }).join(", ");
        F("BLOCKER", "PAYMENT DETAILS CHANGED — verify with the vendor through a channel you already trust before paying",
          "The invoice shows account " + invList + ", which does not match the trusted details on file ending " + truList +
          ". Account numbers are masked to their last 4 here and everywhere in this tool. Do not pay into changed details on the strength of the invoice alone.");
        problems.push("account");
      } else if(truAcc.length && invAcc.length && !changed.length){
        C("ok", "Payment details: the account on the invoice ends ••••" + invAcc[0].last4 + " — matches the trusted details on file.");
      } else if(truAcc.length && !invAcc.length){
        F("WARNING", "No payment details on the invoice to compare",
          "The trusted details on file end " + truAcc.map(function(a){ return "••••" + a.last4; }).join(", ") + ", but the invoice itself shows no account, IBAN, or routing number — there is nothing to pay into, and nothing to cross-check.");
        problems.push("none-on-invoice");
      } else if(!truAcc.length){
        F("INFO", "Trusted block has no account details",
          "The trusted block was supplied, but no account, IBAN, or routing number could be found in it, so the bank details on the invoice could not be compared.");
        C("na", "Payment details: trusted block supplied, but it contains no account/IBAN/routing number to compare against.");
      }

      if(problems.indexOf("payee") >= 0 || problems.indexOf("account") >= 0){
        payStatus = "CHANGED";
        payDetail = "The payment details on this invoice do NOT match the trusted details on file. See the blockers above.";
      } else if(truAcc.length && invAcc.length && !changed.length){
        payStatus = "MATCHED";
        payDetail = "Payee and account details on the invoice match the trusted details on file (accounts compared in full, shown masked).";
      } else {
        payStatus = "PARTIAL";
        payDetail = "The trusted block was supplied, but the comparison could not be completed in full. See the findings above.";
      }
    }

    var rank = { BLOCKER: 0, WARNING: 1, INFO: 2 };
    findings.sort(function(a, b){ return rank[a.sev] - rank[b.sev]; });

    var blockers = findings.filter(function(f){ return f.sev === "BLOCKER"; }).length;
    var warnings = findings.filter(function(f){ return f.sev === "WARNING"; }).length;
    var infos = findings.filter(function(f){ return f.sev === "INFO"; }).length;
    var verdict = blockers > 0 ? "DO NOT PAY YET" : (warnings > 0 ? "PAY WITH FIXES" : "SAFE TO PAY");

    return { verdict: verdict, blockers: blockers, warnings: warnings, infos: infos,
             findings: findings, checks: checks, payStatus: payStatus, payDetail: payDetail };
  }

  /* ---------- rendering ---------- */
  var lastReport = "";
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-invoice-payment-details-auditortm',
  name: 'J-Dawgs Invoice & Payment-Details Auditor',
  description: 'Nobody pre-flights the bill itself; this cross-checks a pasted invoice — line math and totals recomputed with the arithmetic shown, duplicate lines named, due-date traps, and payment details compared against trusted details on file (changed details = DO NOT PAY YET, accounts masked to last 4) — into',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
