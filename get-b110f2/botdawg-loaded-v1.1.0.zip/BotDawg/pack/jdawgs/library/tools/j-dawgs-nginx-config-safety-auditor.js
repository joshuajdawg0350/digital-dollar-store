'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Nginx Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------------- Worked examples ---------------- */

      var RISKY = [
        "# J-Dawgs Nginx Config Safety Auditor - risky worked example",
        "worker_processes 1;",
        "",
        "events {",
        "    worker_connections 512;",
        "}",
        "",
        "http {",
        "    sendfile on;",
        "    server_tokens on;",
        "",
        "    ssl_protocols TLSv1 TLSv1.1 TLSv1.2;",
        "    ssl_prefer_server_ciphers off;",
        "    ssl_ciphers ALL:RC4:DES:!aNULL;",
        "",
        "    server {",
        "        listen 80;",
        "        server_name shop.example.com;",
        "        root /home/jdawg/shop;",
        "    }",
        "",
        "    server {",
        "        listen 443 ssl;",
        "        server_name shop.example.com;",
        "",
        "        ssl_certificate /etc/nginx/certs/shop.pem;",
        "        ssl_certificate_key /etc/nginx/certs/shop.key;",
        "",
        "        root /home/jdawg/shop;",
        "        autoindex on;",
        "        client_max_body_size 2g;",
        "",
        "        location /files/ {",
        "            alias /home/jdawg/shop/files/;",
        "            autoindex on;",
        "        }",
        "",
        "        location /api/ {",
        "            proxy_pass http://127.0.0.1:3000;",
        "            proxy_set_header X-Api-Token \"jd-fake-token-51c2-not-a-real-secret\";",
        "        }",
        "    }",
        "}"
      ].join("\n");

      var CLEAN = [
        "# J-Dawgs Nginx Config Safety Auditor - clean worked example",
        "user www-data;",
        "worker_processes auto;",
        "pid /run/nginx.pid;",
        "error_log /var/log/nginx/error.log warn;",
        "",
        "events {",
        "    worker_connections 1024;",
        "}",
        "",
        "http {",
        "    sendfile on;",
        "    tcp_nopush on;",
        "    server_tokens off;",
        "    include /etc/nginx/mime.types;",
        "    default_type application/octet-stream;",
        "    access_log /var/log/nginx/access.log;",
        "",
        "    ssl_protocols TLSv1.2 TLSv1.3;",
        "    ssl_prefer_server_ciphers on;",
        "    ssl_ciphers ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384;",
        "",
        "    upstream app_backend {",
        "        server 127.0.0.1:8443;",
        "    }",
        "",
        "    server {",
        "        listen 80;",
        "        server_name example.com;",
        "        return 301 https://example.com$request_uri;",
        "    }",
        "",
        "    server {",
        "        listen 443 ssl;",
        "        server_name example.com;",
        "",
        "        ssl_certificate /etc/letsencrypt/live/example.com/fullchain.pem;",
        "        ssl_certificate_key /etc/letsencrypt/live/example.com/privkey.pem;",
        "        ssl_session_timeout 1d;",
        "        ssl_session_cache shared:SSL:10m;",
        "        ssl_session_tickets off;",
        "",
        "        root /var/www/example;",
        "        index index.html;",
        "        client_max_body_size 10m;",
        "",
        "        add_header Strict-Transport-Security \"max-age=63072000\" always;",
        "        add_header X-Content-Type-Options \"nosniff\" always;",
        "        add_header X-Frame-Options \"SAMEORIGIN\" always;",
        "",
        "        location / {",
        "            try_files $uri $uri/ =404;",
        "        }",
        "",
        "        location /api/ {",
        "            proxy_pass https://app_backend;",
        "            proxy_set_header Host $host;",
        "            proxy_set_header X-Real-IP $remote_addr;",
        "            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;",
        "            proxy_set_header X-Forwarded-Proto $scheme;",
        "        }",
        "    }",
        "}"
      ].join("\n");

      /* ---------------- Auditor ---------------- */

      var KNOWN = {};
      ("user worker_processes worker_rlimit_nofile worker_connections worker_cpu_affinity pid error_log access_log " +
       "events http https server location upstream map geo split_clients types include daemon env load_module " +
       "multi_accept accept_mutex sendfile tcp_nopush tcp_nodelay keepalive_timeout keepalive_requests server_tokens " +
       "default default_type charset gzip gzip_types gzip_min_length gzip_proxied gzip_vary gzip_disable gzip_comp_level " +
       "proxy_cache_path proxy_set_header proxy_pass proxy_http_version proxy_read_timeout proxy_connect_timeout " +
       "proxy_send_timeout proxy_buffering proxy_redirect proxy_intercept_errors proxy_ssl_protocols proxy_ssl_ciphers " +
       "proxy_cookie_flags proxy_cache proxy_cache_valid proxy_cache_bypass proxy_no_cache proxy_ignore_headers " +
       "proxy_request_buffering proxy_next_upstream proxy_ssl_server_name proxy_ssl_certificate proxy_ssl_certificate_key " +
       "root alias index try_files return rewrite set add_header expires deny allow auth_basic auth_basic_user_file " +
       "ssl_certificate ssl_certificate_key ssl_protocols ssl_ciphers ssl_prefer_server_ciphers ssl_session_cache " +
       "ssl_session_timeout ssl_session_tickets ssl_stapling ssl_stapling_verify ssl_trusted_certificate ssl_dhparam " +
       "ssl_ecdh_curve ssl_password_file ssl_verify_client ssl_client_certificate listen server_name " +
       "client_max_body_size client_body_buffer_size client_header_buffer_size resolver resolver_timeout error_page " +
       "log_format open_file_cache fastcgi_pass fastcgi_param fastcgi_index fastcgi_read_timeout uwsgi_pass " +
       "scgi_pass grpc_pass break if limit_except autoindex autoindex_exact_size autoindex_localtime limit_req_zone " +
       "limit_req limit_conn_zone limit_conn real_ip_header set_real_ip_from recursive_error_pages server_name_in_redirect " +
       "port_in_redirect absolute_redirect underscores_in_headers merge_slashes http2 http3 quic_retry " +
       "proxy_socket_keepalive fastcgi_cache_path uwsgi_cache_path scgi_cache_path js_import js_set perl " +
       "mp4 flv aio thread_pool pcre_jit ssl_reject_handshake auth_request auth_request_set more_set_headers " +
       "sub_filter sub_filter_types xslt_stylesheet secure_link_status health_check match zone keyval " +
       "least_conn ip_hash hash random sticky status mscache").split(" ").forEach(function (w) { KNOWN[w] = true; });

      var SKIP_PARSE_BLOCKS = { map: true, geo: true, types: true, split_clients: true };

      function tokenize(linesArr) {
        var events = [], buf = "", bufLine = 1, started = false, inQ = false, qCh = "";
        for (var li = 0; li < linesArr.length; li++) {
          var line = li + 1, s = linesArr[li];
          inQ = false;
          for (var i = 0; i < s.length; i++) {
            var c = s[i];
            if (inQ) { buf += c; if (c === qCh) inQ = false; continue; }
            if (c === '"' || c === "'") {
              if (!started) { bufLine = line; started = true; }
              inQ = true; qCh = c; buf += c; continue;
            }
            if (c === "#") break;
            if (c === "{") {
              events.push({ kind: "stmt", text: buf.trim(), term: "{", line: started ? bufLine : line });
              buf = ""; started = false;
              events.push({ kind: "open", line: line });
              continue;
            }
            if (c === "}") {
              if (buf.trim()) events.push({ kind: "stmt", text: buf.trim(), term: "eol", line: started ? bufLine : line });
              buf = ""; started = false;
              events.push({ kind: "close", line: line });
              continue;
            }
            if (c === ";") {
              events.push({ kind: "stmt", text: buf.trim(), term: ";", line: started ? bufLine : line });
              buf = ""; started = false;
              continue;
            }
            if (!started && /\S/.test(c)) { bufLine = line; started = true; }
            buf += c;
          }
        }
        if (buf.trim()) events.push({ kind: "stmt", text: buf.trim(), term: "eol", line: bufLine });
        return events;
      }

      function stripCommentRaw(line) {
        var inQ = false, qCh = "", out = "";
        for (var i = 0; i < line.length; i++) {
          var c = line[i];
          if (inQ) { out += c; if (c === qCh) inQ = false; continue; }
          if (c === '"' || c === "'") { inQ = true; qCh = c; out += c; continue; }
          if (c === "#") break;
          out += c;
        }
        return out;
      }

      function audit(text) {
        var findings = [];
        function add(sev, line, title, detail, fix) {
          findings.push({ sev: sev, line: line, title: title, detail: detail, fix: fix });
        }

        var linesArr = text.split("\n");
        var events = tokenize(linesArr);

        /* --- secret scan: raw lines, key name + line only, value never kept --- */
        var secretRe = /([A-Za-z0-9_$.\-]*(?:password|passwd|secret|token|api[_-]?key|apikey)[A-Za-z0-9_$.\-]*)\s*(?:=\s*|\s+)["']?([^\s;"']{4,})/i;
        linesArr.forEach(function (raw, idx) {
          var code = stripCommentRaw(raw);
          var m = secretRe.exec(code);
          if (!m) return;
          var val = m[2];
          if (val.charAt(0) === "$" || val.charAt(0) === "/" || val.charAt(0) === "{" || val.charAt(0) === "}") return;
          if (/^(on|off|true|false|none|file|shared|builtin)$/i.test(val)) return;
          add("WARNING", idx + 1, "Possible secret in plain text",
            "A value is assigned to the key \u201C" + m[1] + "\u201D directly in this config. The value itself is never shown in this audit — but anyone who can read this file can read it too.",
            "Remove the value for \u201C" + m[1] + "\u201D (line " + (idx + 1) + ") from the config; load it from a protected file or environment outside the config, and rotate it if it was ever real.");
        });

        /* --- structural pass --- */
        var stack = [];          // {type, line, server, loc}
        var servers = [];        // server data objects
        var locations = [];      // location data objects
        var globalCert = false;
        var anySslListen = false;
        var firstSslListenLine = 0;
        var sslProtocols = [], preferCiphers = [], sslCiphers = [], serverTokens = [];
        var fileHeaders = {}, cspFrameAncestors = false;
        var unbalancedDone = false;

        function topServer() {
          for (var i = stack.length - 1; i >= 0; i--) if (stack[i].server) return stack[i].server;
          return null;
        }
        function topLoc() {
          for (var i = stack.length - 1; i >= 0; i--) if (stack[i].loc) return stack[i].loc;
          return null;
        }
        function inSkipBlock() {
          for (var i = 0; i < stack.length; i++) if (SKIP_PARSE_BLOCKS[stack[i].type]) return true;
          return false;
        }

        function processStmt(stmt) {
          var text2 = stmt.text;
          if (!text2) return;
          var parts = text2.split(/\s+/);
          var name = parts[0].toLowerCase();
          var args = parts.slice(1);
          var value = args.join(" ");
          var line = stmt.line;

          if (stmt.term === "{" ) {
            if (/^if\s*\(\s*\$request_method/.test(text2)) {
              add("WARNING", line, "if ($request_method …) inside a block",
                "\u201Cif\u201D in nginx is evaluated at rewrite phase and is famously error-prone (\u201Cif is evil\u201D); matching on $request_method inside a location can skip other rewrite rules and produce surprising results.",
                "Replace the if ($request_method …) check on line " + line + " with a map, try_files, or limit_except block designed for method filtering.");
            }
            return; // block opener handled by caller
          }

          if (stmt.term === ";" && !KNOWN[name] && !inSkipBlock() && name !== "}") {
            add("INFO", line, "NOT PARSED — unrecognized directive \u201C" + name + "\u201D",
              "This heuristic audit does not recognize the directive on line " + line + ", so it was not checked and its meaning was not guessed. It may be a module directive, a typo, or a directive from a newer nginx version.",
              "Verify the directive on line " + line + " against your nginx build (nginx -V and the module docs) and confirm it is spelled as intended.");
          }

          switch (name) {
            case "listen": {
              var srv = topServer();
              if (srv) {
                var addrTok = args[0] || "";
                var port = addrTok.indexOf(":") >= 0 ? addrTok.slice(addrTok.lastIndexOf(":") + 1) : addrTok;
                var isSsl = args.indexOf("ssl") >= 0;
                srv.listens.push({ port: port, ssl: isSsl, line: line });
                if (isSsl) {
                  anySslListen = true;
                  if (!firstSslListenLine) firstSslListenLine = line;
                }
              }
              break;
            }
            case "ssl_certificate": {
              var s2 = topServer();
              if (s2) s2.hasCert = true; else globalCert = true;
              break;
            }
            case "ssl_protocols": sslProtocols.push({ line: line, value: value }); break;
            case "ssl_prefer_server_ciphers": preferCiphers.push({ line: line, value: value.toLowerCase() }); break;
            case "ssl_ciphers": sslCiphers.push({ line: line, value: value }); break;
            case "server_tokens": serverTokens.push({ line: line, value: value.toLowerCase() }); break;
            case "return":
            case "rewrite": {
              var s3 = topServer();
              if (s3 && /https:\/\//.test(value)) s3.hasRedirect = true;
              if (name === "rewrite" && /\$host/.test(value) && /permanent|redirect/.test(value)) {
                add("WARNING", line, "Permanent rewrite built on unvalidated $host",
                  "The rewrite on line " + line + " builds a permanent redirect from $host, which comes from the client request and is not validated. A crafted Host header can poison the redirect target.",
                  "Validate the host first (a dedicated server block with an exact server_name and a default catch-all that returns 444), or hard-code the canonical hostname in the rewrite on line " + line + ".");
              }
              break;
            }
            case "root": {
              var r = value.replace(/["';]/g, "");
              if (r === "/" || r === "/root" || r.indexOf("/home/") === 0 || r.indexOf("/Users/") === 0 || r === "~" || r.indexOf("~/") === 0) {
                add("WARNING", line, "root points at " + (r === "/" ? "the filesystem root" : "a home or system directory"),
                  "root is set to \u201C" + r + "\u201D on line " + line + ". Serving from the filesystem root or a home directory exposes far more than the site — dotfiles, keys, and backups included.",
                  "Point root on line " + line + " at a dedicated web directory (for example /var/www/<site>) that contains only files meant to be public.");
              }
              break;
            }
            case "alias":
              add("INFO", line, "alias traversal risk — review",
                "alias on line " + line + " maps URLs to the filesystem by string substitution; a missing trailing slash or a ../ in the request path is a classic directory-traversal hole with alias.",
                "Check the alias on line " + line + ": the location and the alias path should both end (or both not end) in a slash, and prefer root + try_files where possible.");
              break;
            case "autoindex":
              if (/^on\b/i.test(value)) {
                add("WARNING", line, "autoindex is on",
                  "autoindex on line " + line + " publishes a browsable listing of every file in the directory — including anything dropped there by accident.",
                  "Set autoindex off on line " + line + " (or remove the directive; off is the default) unless a public listing is deliberate.");
              }
              break;
            case "resolver":
              if (/(^|\s)127\.0\.0\.53(\s|:|$)/.test(value)) {
                add("INFO", line, "resolver points at 127.0.0.53",
                  "Line " + line + " uses 127.0.0.53, the systemd-resolved stub listener. It works on many Ubuntu hosts but behaves differently from a real upstream resolver and caches per its own rules — worth a deliberate decision, not a copy-paste.",
                  "Confirm 127.0.0.53 is intended on line " + line + "; on non-systemd hosts use your actual resolver, and add a valid= TTL if upstream names must re-resolve.");
              }
              break;
            case "client_max_body_size": {
              var v = value.replace(/["';]/g, "").toLowerCase();
              var mult = 1;
              if (/k$/.test(v)) mult = 1024;
              else if (/m$/.test(v)) mult = 1024 * 1024;
              else if (/g$/.test(v)) mult = 1024 * 1024 * 1024;
              var num = parseFloat(v);
              if (!isNaN(num)) {
                var bytes = num * mult;
                if (num === 0 || bytes > 256 * 1024 * 1024) {
                  add("WARNING", line, "client_max_body_size is " + (num === 0 ? "unlimited" : "very large"),
                    "Line " + line + " sets client_max_body_size to \u201C" + value + "\u201D" + (num === 0 ? " — 0 disables the limit entirely" : "") + ". Oversized uploads are a cheap disk- and bandwidth-exhaustion lever for anyone who can reach the server.",
                    "Set client_max_body_size on line " + line + " to the largest upload the application genuinely accepts (for example 10m or 25m).");
                }
              }
              break;
            }
            case "add_header": {
              var hn = (args[0] || "").toLowerCase();
              if (hn) {
                fileHeaders[hn] = true;
                if (hn === "content-security-policy" && /frame-ancestors/.test(value)) cspFrameAncestors = true;
              }
              break;
            }
            case "proxy_set_header": {
              var ph = (args[0] || "").toLowerCase();
              var loc = topLoc(), srv2 = topServer();
              if (loc) loc.headers[ph] = true;
              else if (srv2) srv2.proxyHeaders[ph] = true;
              break;
            }
            case "proxy_pass": {
              var loc2 = topLoc(), srv3 = topServer();
              var target = { url: args[0] || "", line: line, server: srv3 };
              if (loc2) { loc2.proxyPasses.push(target); }
              else if (srv3) {
                if (!srv3.implicitLoc) {
                  srv3.implicitLoc = { line: srv3.line, path: "(server level)", headers: {}, proxyPasses: [], server: srv3 };
                  locations.push(srv3.implicitLoc);
                }
                srv3.implicitLoc.proxyPasses.push(target);
              }
              break;
            }
          }
        }

        events.forEach(function (ev) {
          if (ev.kind === "open") return; // block opens are pushed with their stmt
          if (ev.kind === "close") {
            if (!stack.length) {
              if (!unbalancedDone) {
                unbalancedDone = true;
                add("BLOCKER", ev.line, "Unbalanced braces — unmatched closing brace",
                  "A closing brace on line " + ev.line + " has no matching opening brace. nginx will refuse to load this config at all.",
                  "Find the extra closing brace at or before line " + ev.line + " (or the missing opening brace above it) and balance the block.");
              }
            } else stack.pop();
            return;
          }
          // stmt
          if (ev.term === "{") {
            var t = (ev.text.split(/\s+/)[0] || "").toLowerCase();
            var entry = { type: t, line: ev.line, server: null, loc: null };
            processStmt(ev); // runs the if-check
            if (t === "server" && !topLoc()) {
              var sd = { line: ev.line, listens: [], hasCert: false, hasRedirect: false, proxyHeaders: {}, implicitLoc: null };
              entry.server = sd; servers.push(sd);
            } else if (t === "location") {
              var ld = { line: ev.line, path: ev.text.replace(/^location\s+/i, ""), headers: {}, proxyPasses: [], server: topServer() };
              entry.loc = ld; locations.push(ld);
            }
            stack.push(entry);
          } else {
            processStmt(ev);
          }
        });

        if (stack.length && !unbalancedDone) {
          var first = stack[0];
          add("BLOCKER", first.line, "Unbalanced braces — block never closed",
            "The \u201C" + (first.type || "block") + "\u201D block opened on line " + first.line + " is never closed. nginx will refuse to load this config at all.",
            "Add the missing closing brace for the block opened on line " + first.line + ".");
        }

        /* --- TLS posture --- */
        sslProtocols.forEach(function (sp) {
          var toks = sp.value.replace(/["';]/g, "").split(/\s+/);
          var bad = toks.filter(function (t) { return t === "TLSv1" || t === "TLSv1.0" || t === "TLSv1.1"; });
          if (bad.length) {
            add("BLOCKER", sp.line, "Legacy TLS enabled: " + bad.join(", "),
              "ssl_protocols on line " + sp.line + " enables " + bad.join(" and ") + ". TLS 1.0 and 1.1 are deprecated, blocked by every modern browser, and fail current compliance baselines.",
              "Change ssl_protocols on line " + sp.line + " to: ssl_protocols TLSv1.2 TLSv1.3;");
          }
        });
        if (anySslListen && !sslProtocols.length) {
          add("WARNING", firstSslListenLine, "ssl_protocols is not set anywhere",
            "This config serves HTTPS but never sets ssl_protocols, so the protocol versions are whatever the build default happens to be — which may include legacy TLS.",
            "Add an explicit ssl_protocols TLSv1.2 TLSv1.3; in the http block (or each SSL server block).");
        }
        preferCiphers.forEach(function (pc) {
          if (pc.value === "off") {
            add("WARNING", pc.line, "ssl_prefer_server_ciphers is off",
              "With ssl_prefer_server_ciphers off (line " + pc.line + "), the client picks the cipher — and a client can pick the weakest one you both support.",
              "Set ssl_prefer_server_ciphers on; on line " + pc.line + " so the server enforces its cipher order.");
          }
        });
        if (anySslListen && !preferCiphers.length) {
          add("INFO", firstSslListenLine, "ssl_prefer_server_ciphers not set",
            "No ssl_prefer_server_ciphers directive was found. For TLSv1.3 it does not apply, but for TLSv1.2 the server-side cipher order is worth stating explicitly.",
            "Add ssl_prefer_server_ciphers on; alongside your ssl_protocols line.");
        }
        var WEAK = { RC4: 1, DES: 1, "3DES": 1, MD5: 1, NULL: 1, EXPORT: 1, LOW: 1, ANULL: 1, ENULL: 1 };
        sslCiphers.forEach(function (sc) {
          var toks = sc.value.replace(/["']/g, "").split(/[:\s]+/);
          var weak = [];
          toks.forEach(function (tok) {
            if (!tok || tok.charAt(0) === "!" || tok.charAt(0) === "-") return;
            tok.split("-").forEach(function (piece) {
              if (WEAK[piece.toUpperCase()] && weak.indexOf(piece.toUpperCase()) < 0) weak.push(piece.toUpperCase());
            });
          });
          if (weak.length) {
            add("WARNING", sc.line, "Weak ciphers present: " + weak.join(", "),
              "The ssl_ciphers string on line " + sc.line + " includes " + weak.join(", ") + ", which are broken or obsolete and drag down the TLS grade of the whole server.",
              "Replace the cipher list on line " + sc.line + " with a current ECDHE + AES-GCM / ChaCha20 list and remove " + weak.join(", ") + " entirely.");
          }
        });

        /* --- server blocks --- */
        servers.forEach(function (srv) {
          var seenPorts = {};
          srv.listens.forEach(function (L) {
            if (L.ssl && !srv.hasCert && !globalCert) {
              add("BLOCKER", L.line, "SSL listener with no ssl_certificate in this server block",
                "Line " + L.line + " listens with ssl, but the server block starting on line " + srv.line + " contains no ssl_certificate. nginx cannot complete a TLS handshake for this server.",
                "Add ssl_certificate and ssl_certificate_key inside the server block that starts on line " + srv.line + ".");
            }
            var key = L.port;
            if (key && seenPorts[key]) {
              add("WARNING", L.line, "Duplicate listen on port " + key + " in the same server block",
                "Port " + key + " is listened on twice inside the server block starting on line " + srv.line + " (second occurrence on line " + L.line + "). One of them is redundant or a copy-paste error.",
                "Remove the duplicate listen " + key + " on line " + L.line + ", or move it to the server block it was meant for.");
            }
            seenPorts[key] = true;
          });
          var hasHttp = srv.listens.some(function (L) { return !L.ssl; });
          if (hasHttp && !srv.hasRedirect) {
            add("WARNING", srv.line, "HTTP served with no redirect to HTTPS",
              "The server block starting on line " + srv.line + " answers plain HTTP and nothing in it redirects to HTTPS, so visitors (and their credentials and cookies) travel unencrypted.",
              "In the server block on line " + srv.line + ", return a redirect instead of content: return 301 https://<your-host>$request_uri;");
            }
        });
        if (!servers.length && !unbalancedDone) {
          add("INFO", 1, "No server block found",
            "No server { } block was found in the pasted text. If this is a fragment (for example a single site file meant to sit inside an http block), the per-server checks had nothing to attach to.",
            "Paste the fuller config, or confirm this fragment is included from a complete nginx.conf.");
        }

        /* --- proxy posture --- */
        locations.forEach(function (loc) {
          loc.proxyPasses.forEach(function (pp) {
            var url = pp.url.replace(/["';]/g, "");
            var isHttp = /^http:\/\//i.test(url);
            if (isHttp && pp.server && pp.server.listens.some(function (L) { return L.ssl; })) {
              add("WARNING", pp.line, "HTTPS in front, plain HTTP upstream behind it",
                "proxy_pass on line " + pp.line + " sends traffic to an http:// upstream while this server listens with SSL. The visitor's leg is encrypted; the leg to your application is not.",
                "Terminate the upstream over TLS (proxy_pass https://…) on line " + pp.line + ", or confine the plain-HTTP hop to a trusted local socket and document that choice.");
            }
            var host = url.replace(/^[a-z]+:\/\//i, "").split(/[/:]/)[0];
            var internal = host === "localhost" || /^127\./.test(host) || /^10\./.test(host) ||
              /^192\.168\./.test(host) || /^172\.(1[6-9]|2[0-9]|3[01])\./.test(host) ||
              /\.(internal|local|lan|corp)$/i.test(host);
            if (internal) {
              add("INFO", pp.line, "Upstream looks internal — confirm the exposure is intended",
                "proxy_pass on line " + pp.line + " targets \u201C" + host + "\u201D, which looks like a private/internal address. That is normal for a reverse proxy — and exactly the pattern that turns into SSRF-style exposure if the path is reachable in ways you did not intend.",
                "Confirm the location on line " + loc.line + " is meant to reach " + host + ", and that no user-controlled input can steer this proxy_pass to other internal services.");
            }
          });
          if (loc.proxyPasses.length) {
            var eff = {};
            Object.keys(loc.headers).forEach(function (k) { eff[k] = true; });
            if (loc.server) Object.keys(loc.server.proxyHeaders).forEach(function (k) { eff[k] = true; });
            if (!eff["host"]) {
              add("INFO", loc.line, "Proxy location does not set the Host header",
                "The proxying location starting on line " + loc.line + " never sets proxy_set_header Host, so the upstream sees nginx's default Host — virtual-hosted upstreams may route or log the request wrongly.",
                "Add proxy_set_header Host $host; inside the location on line " + loc.line + ".");
            }
            if (!eff["x-forwarded-for"]) {
              add("INFO", loc.line, "Proxy location does not set X-Forwarded-For",
                "The proxying location starting on line " + loc.line + " never sets X-Forwarded-For, so the upstream application cannot see the real client address — rate limits and audit logs will blame the proxy.",
                "Add proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for; inside the location on line " + loc.line + ".");
            }
          }
        });

        /* --- security headers, grouped once --- */
        var missing = [];
        if (!fileHeaders["x-content-type-options"]) missing.push("X-Content-Type-Options");
        if (!fileHeaders["x-frame-options"] && !cspFrameAncestors) missing.push("X-Frame-Options (or a Content-Security-Policy with frame-ancestors)");
        if (anySslListen && !fileHeaders["strict-transport-security"]) missing.push("Strict-Transport-Security");
        if (missing.length) {
          add("WARNING", servers.length ? servers[0].line : 1, "Security headers missing: " + missing.length + " not set",
            "No add_header anywhere in this config sets: " + missing.join("; ") + ". Browsers are left to guess at MIME sniffing, framing, and HTTPS persistence.",
            "Add the missing headers with add_header in the server (or http) block: " + missing.join("; ") + " — for example add_header X-Content-Type-Options \"nosniff\" always;");
        }

        /* --- server_tokens, missing case --- */
        serverTokens.forEach(function (st) {
          if (st.value === "on") {
            add("WARNING", st.line, "server_tokens is on",
              "server_tokens on (line " + st.line + ") prints the exact nginx version in error pages and the Server header — free reconnaissance for anyone scanning for version-specific exploits.",
              "Set server_tokens off; on line " + st.line + ".");
          }
        });
        if (!serverTokens.length) {
          add("INFO", 1, "server_tokens not set",
            "No server_tokens directive was found, so nginx's default applies and the version string is shown. It is a small leak, but it is free to close.",
            "Add server_tokens off; in the http block.");
        }

        var rank = { BLOCKER: 0, WARNING: 1, INFO: 2 };
        findings.sort(function (a, b) {
          if (rank[a.sev] !== rank[b.sev]) return rank[a.sev] - rank[b.sev];
          return a.line - b.line;
        });

        var counts = { BLOCKER: 0, WARNING: 0, INFO: 0 };
        findings.forEach(function (f) { counts[f.sev]++; });
        var verdict = counts.BLOCKER > 0 ? "DO NOT DEPLOY" : (counts.WARNING > 0 ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY");
        return { findings: findings, counts: counts, verdict: verdict, lines: linesArr.length };
      }

      function buildReport(res) {
        var out = [];
        out.push("J-DAWGS NGINX CONFIG SAFETY AUDITOR\u2122 — AUDIT REPORT");
        out.push("Verdict: " + res.verdict);
        out.push("Findings: " + res.counts.BLOCKER + " BLOCKER · " + res.counts.WARNING + " WARNING · " + res.counts.INFO + " INFO across " + res.lines + " pasted lines");
        out.push("");
        if (res.findings.length) {
          out.push("FINDINGS");
          res.findings.forEach(function (f) {
            out.push("[" + f.sev + "] Line " + f.line + " — " + f.title);
            out.push("    " + f.detail);
          });
          out.push("");
          out.push("FIX LIST");
          var seen = {}, n = 0;
          res.findings.forEach(function (f) {
            if (seen[f.fix]) return;
            seen[f.fix] = true; n++;
            out.push(n + ". " + f.fix);
          });
        } else {
          out.push("FINDINGS");
          out.push("None. No rule in this audit's heuristic rule set fired on the pasted config.");
        }
        out.push("");
        out.push("Notes: Heuristic text audit of the pasted config only. No live server was contacted and nginx was not run. Possible secrets are reported by key name and line only — secret values never appear in this report.");
        return out.join("\n");
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-nginx-config-safety-auditor',
  name: 'J-Dawgs Nginx Config Safety Auditor',
  description: 'Audits a pasted nginx config offline — TLS posture, exposure, proxy/header posture, and secrets flagged by key name only — and returns one deploy verdict: SAFE TO DEPLOY / DEPLOY WITH FIXES / DO NOT DEPLOY.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
