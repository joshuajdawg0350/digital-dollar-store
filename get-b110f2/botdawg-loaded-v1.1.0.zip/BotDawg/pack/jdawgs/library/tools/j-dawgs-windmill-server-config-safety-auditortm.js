'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Windmill Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var RISKY_LINES = [
        "# RISKY example - Windmill-style env config (training data only - never deploy this)",
        "DATABASE_URL=postgres://app:DbPass-Plain-7741@db:5432/windmill",
        "JWT_SECRET=secret123",
        "BASE_URL=http://jobs.example.com",
        "WORKER_PRIVILEGED=true",
        "EXECUTOR_UNSAFE_MODE=true",
        "DISABLE_SIGNUP=false",
        "SMTP_HOST=mail.example.com",
        "SMTP_PASSWORD=SmtpPlain-5519",
        "S3_ACCESS_KEY=AKIA-PLAIN-EXAMPLE-01",
        "S3_SECRET_KEY=S3PlainSecret-9034",
        "SUPERADMIN_PASSWORD=admin123",
        "METRICS_ENABLED=true",
        "METRICS_REQUIRE_AUTH=false",
        "TLS_ENABLED=false"
      ];
      var RISKY_TEXT = RISKY_LINES.join("\n");

      var HARDENED_LINES = [
        "# HARDENED example - references only, no plaintext secrets",
        "DATABASE_URL=postgres://app@db:5432/windmill?sslmode=require",
        "JWT_SECRET=${JWT_SECRET_FROM_VAULT}",
        "BASE_URL=https://jobs.example.com",
        "WORKER_PRIVILEGED=false",
        "EXECUTOR_UNSAFE_MODE=false",
        "DISABLE_SIGNUP=true",
        "SMTP_HOST=mail.example.com",
        "SMTP_PASSWORD=${SMTP_PASSWORD_FROM_VAULT}",
        "S3_ACCESS_KEY=${S3_ACCESS_KEY_FROM_VAULT}",
        "S3_SECRET_KEY=${S3_SECRET_KEY_FROM_VAULT}",
        "SUPERADMIN_PASSWORD=${SUPERADMIN_PASSWORD_FROM_VAULT}",
        "METRICS_ENABLED=true",
        "METRICS_REQUIRE_AUTH=true",
        "TLS_ENABLED=true",
        "TLS_CERT_FILE=/run/secrets/tls.crt"
      ];
      var HARDENED_TEXT = HARDENED_LINES.join("\n");

      var PLANTED_SECRETS = ["DbPass-Plain-7741", "secret123", "SmtpPlain-5519",
        "AKIA-PLAIN-EXAMPLE-01", "S3PlainSecret-9034", "admin123"];

      function isTruthy(v) {
        return /^(true|1|yes|on|enabled)$/i.test(String(v).trim());
      }
      function isFalsy(v) {
        return /^(false|0|no|off|disabled)$/i.test(String(v).trim());
      }
      function isRef(v) {
        var s = String(v).trim();
        return /^\$\{[^}]*\}$/.test(s) || /^\$[A-Za-z_][A-Za-z0-9_]*$/.test(s) ||
          /^(vault|secret|file|env|ref):/i.test(s);
      }
      function stripQuotes(v) {
        var s = String(v).trim();
        if (s.length >= 2 && ((s.charAt(0) === '"' && s.charAt(s.length - 1) === '"') ||
            (s.charAt(0) === "'" && s.charAt(s.length - 1) === "'"))) {
          return s.slice(1, -1);
        }
        return s;
      }
      function looksExample(v) {
        var s = String(v).toLowerCase();
        return s.indexOf("example") !== -1 || s.indexOf("changeme") !== -1 ||
          s.indexOf("change-me") !== -1 || s.indexOf("change_me") !== -1 ||
          s === "secret" || s === "password" || s === "letmein" || s === "default";
      }
      function isDefaultCred(v) {
        var s = String(v).toLowerCase();
        var defaults = ["admin", "admin123", "administrator", "password", "password123",
          "changeme", "windmill", "root", "123456", "12345678", "superadmin", "default"];
        for (var i = 0; i < defaults.length; i++) { if (s === defaults[i]) return true; }
        return false;
      }

      function parseConfig(text) {
        var rawLines = String(text || "").split(/\r?\n/);
        var entries = [];
        for (var i = 0; i < rawLines.length; i++) {
          var t = rawLines[i].trim();
          if (!t || t.charAt(0) === "#" || t.indexOf("//") === 0) continue;
          var m = t.match(/^([A-Za-z0-9_.\-]+)\s*[:=]\s*(.*)$/);
          if (!m) continue;
          entries.push({ line: i + 1, key: m[1].toUpperCase(), value: stripQuotes(m[2]) });
        }
        return entries;
      }

      function audit(text) {
        var entries = parseConfig(text);
        var findings = [];
        function add(line, severity, rule, key, valueLength, message) {
          for (var i = 0; i < findings.length; i++) {
            if (findings[i].line === line && findings[i].rule === rule) return;
          }
          var f = { line: line, severity: severity, rule: rule, key: key, message: message };
          if (typeof valueLength === "number") f.valueLength = valueLength;
          findings.push(f);
        }

        if (entries.length < 2) {
          return { verdict: "NOT ENOUGH TO GRADE", entries: entries, findings: findings,
            counts: { BLOCKER: 0, HIGH: 0, WARNING: 0, INFO: 0 } };
        }

        var hasSignupKey = false, hasTlsKey = false, hasMetricsAuthKey = false;
        var metricsEnabledLine = null;

        entries.forEach(function (e) {
          var key = e.key, val = e.value, line = e.line, len = val.length;
          var secretHandled = false;

          if (/(^|_)DISABLE_SIGNUP/.test(key) || /SIGNUP/.test(key)) hasSignupKey = true;
          if (/TLS|SSL|(^|_)HTTPS(_|$)/.test(key)) hasTlsKey = true;
          if (/METRICS.*AUTH|AUTH.*METRICS/.test(key)) hasMetricsAuthKey = true;
          if (/METRICS_ENABLED|METRICS_ENABLE/.test(key) && isTruthy(val)) metricsEnabledLine = line;

          // 1. DATABASE_URL plaintext password
          if (key.indexOf("DATABASE_URL") !== -1 || key === "DATABASE" || key.indexOf("POSTGRES_URL") !== -1) {
            var pm = val.match(/:\/\/[^:\/@\s]+:([^@\s]+)@/);
            if (pm && !isRef(val) && !isRef(pm[1])) {
              add(line, "BLOCKER", "DB_PLAINTEXT_PASSWORD", key, len,
                "Connection string embeds a plaintext password (password length " + pm[1].length + "). Move the password into a secret store and reference it instead.");
              secretHandled = true;
            } else if (isRef(val)) {
              add(line, "INFO", "DB_REFERENCE", key, len,
                "Database connection is supplied by reference, not a literal value.");
              secretHandled = true;
            } else {
              add(line, "INFO", "DB_NO_PLAINTEXT_PASSWORD", key, len,
                "No plaintext password detected inside the database connection string.");
            }
          }

          // 7. S3 / storage credentials (before generic secret rules)
          if (!secretHandled && /(S3|AWS|MINIO|STORAGE|BUCKET|OBJECT_STORE)/.test(key) &&
              /(ACCESS_KEY|SECRET|PASSWORD|TOKEN|CREDENTIAL)/.test(key)) {
            if (val && !isRef(val)) {
              add(line, "HIGH", "STORAGE_PLAINTEXT", key, len,
                "Storage credential is stored as a plaintext literal. Supply it by secret reference instead.");
            } else if (isRef(val)) {
              add(line, "INFO", "STORAGE_REFERENCE", key, len,
                "Storage credential is supplied by secret reference.");
            }
            secretHandled = true;
          }
          if (!secretHandled && /(ACCESS_KEY_ID|SECRET_ACCESS_KEY)/.test(key)) {
            if (val && !isRef(val)) {
              add(line, "HIGH", "STORAGE_PLAINTEXT", key, len,
                "Storage credential is stored as a plaintext literal. Supply it by secret reference instead.");
            } else if (isRef(val)) {
              add(line, "INFO", "STORAGE_REFERENCE", key, len,
                "Storage credential is supplied by secret reference.");
            }
            secretHandled = true;
          }

          // 6. SMTP credentials
          if (!secretHandled && /SMTP/.test(key) && /(PASSWORD|PASS|TOKEN|SECRET)/.test(key)) {
            if (val && !isRef(val)) {
              add(line, "HIGH", "SMTP_PLAINTEXT", key, len,
                "SMTP credential is stored as a plaintext literal. Supply it by secret reference instead.");
            } else if (isRef(val)) {
              add(line, "INFO", "SMTP_REFERENCE", key, len,
                "SMTP credential is supplied by secret reference.");
            }
            secretHandled = true;
          }

          // 8. Superadmin / admin default credentials
          if (!secretHandled && /(SUPERADMIN|ADMIN|ROOT_USER)/.test(key) && /(PASSWORD|PASS|PWD)/.test(key)) {
            if (isRef(val)) {
              add(line, "INFO", "ADMIN_REFERENCE", key, len,
                "Admin credential is supplied by secret reference.");
            } else if (val && (isDefaultCred(val) || len < 16)) {
              add(line, "BLOCKER", "DEFAULT_ADMIN_CREDENTIALS", key, len,
                "Admin credential is a known default or too short to be safe (length " + len + "). Set a long, unique value through a secret store before deploying.");
            } else if (val) {
              add(line, "HIGH", "ADMIN_PLAINTEXT", key, len,
                "Admin credential is stored as a plaintext literal. Supply it by secret reference instead.");
            }
            secretHandled = true;
          }

          // 2. JWT / signing / encryption secret keys
          if (!secretHandled && /(JWT_SECRET|JWT_KEY|SECRET_KEY|ENCRYPTION_KEY|SESSION_SECRET|TOKEN_SECRET|SIGNING_KEY|AUTH_SECRET|JWT)/.test(key) &&
              /(SECRET|KEY)/.test(key)) {
            if (isRef(val)) {
              add(line, "INFO", "SECRET_REFERENCE", key, len,
                "Secret key is supplied by secret reference.");
            } else if (val && (len < 32 || looksExample(val))) {
              add(line, "BLOCKER", "WEAK_SECRET", key, len,
                "Secret key is short or an example value (length " + len + "; safe minimum is 32 characters of random material). Generate a long random secret and store it in a secret store.");
            } else if (val) {
              add(line, "HIGH", "SECRET_PLAINTEXT", key, len,
                "Secret key is stored as a plaintext literal. Supply it by secret reference instead.");
            }
            secretHandled = true;
          }

          // Generic plaintext passwords / secrets not covered above
          if (!secretHandled && /(PASSWORD|PASSWD|PWD)/.test(key)) {
            if (val && !isRef(val)) {
              add(line, "HIGH", "PLAINTEXT_PASSWORD", key, len,
                "Password is stored as a plaintext literal. Supply it by secret reference instead.");
              secretHandled = true;
            } else if (isRef(val)) {
              add(line, "INFO", "PASSWORD_REFERENCE", key, len,
                "Password is supplied by secret reference.");
              secretHandled = true;
            }
          }
          if (!secretHandled && /(SECRET|PRIVATE_KEY|API_KEY|ACCESS_TOKEN)/.test(key)) {
            if (val && !isRef(val) && len < 32) {
              add(line, "HIGH", "WEAK_SECRET", key, len,
                "Secret value is short (length " + len + "). Use long random material supplied by secret reference.");
              secretHandled = true;
            } else if (val && !isRef(val)) {
              add(line, "WARNING", "SECRET_PLAINTEXT", key, len,
                "Secret is stored as a plaintext literal. Prefer a secret reference.");
              secretHandled = true;
            } else if (isRef(val)) {
              add(line, "INFO", "SECRET_REFERENCE", key, len,
                "Secret is supplied by secret reference.");
              secretHandled = true;
            }
          }

          // 3. http instead of https
          if (/^http:\/\//i.test(val)) {
            if (/localhost|127\.0\.0\.1/.test(val)) {
              add(line, "WARNING", "INSECURE_HTTP_LOCAL", key, len,
                "URL uses http for a local address. Fine for local development only - never in a deployed config.");
            } else {
              add(line, "HIGH", "INSECURE_HTTP", key, len,
                "External URL uses http instead of https (scheme: http). Traffic, logins, and tokens on this address are unencrypted.");
            }
          }

          // 4. Privileged / unsafe worker & executor modes
          if (/(PRIVILEGED|UNSAFE|INSECURE_MODE|ALLOW_ROOT|RUN_AS_ROOT|PRIVILEGE)/.test(key) && isTruthy(val)) {
            add(line, "BLOCKER", "PRIVILEGED_MODE", key, len,
              "Privileged or unsafe execution mode is switched ON. Workers/executors with elevated privileges turn any script bug or compromise into a host compromise. Turn it off.");
          }
          if (/--privileged/.test(val)) {
            add(line, "BLOCKER", "PRIVILEGED_MODE", key, len,
              "Value requests privileged container mode. Turn it off before deploying.");
          }

          // 5. Signup posture (explicit bad values; missing handled after loop)
          if (key === "DISABLE_SIGNUP" || key === "DISABLE_SIGNUPS") {
            if (isFalsy(val)) {
              add(line, "HIGH", "OPEN_SIGNUP", key, len,
                "Signup is NOT disabled on a self-hosted server. Anyone who can reach the login page can create an account. Disable signup after creating your own admin account.");
            } else if (isTruthy(val)) {
              add(line, "INFO", "SIGNUP_DISABLED", key, len, "Signup is disabled. Good posture for a self-hosted server.");
            }
          }
          if (/(ALLOW_SIGNUP|OPEN_SIGNUP|SIGNUP_ENABLED|ENABLE_SIGNUP)/.test(key) && isTruthy(val)) {
            add(line, "HIGH", "OPEN_SIGNUP", key, len,
              "Open signup is switched ON. Anyone who can reach the server can create an account. Turn it off.");
          }

          // 9. Metrics auth explicitly off
          if (/METRICS.*AUTH|AUTH.*METRICS|PROMETHEUS.*AUTH/.test(key) && isFalsy(val)) {
            add(line, "HIGH", "METRICS_NO_AUTH", key, len,
              "Metrics/monitoring endpoint authentication is switched OFF. Metrics leak job names, timings, and internals - require auth or keep the endpoint off the public network.");
          }
          if (/METRICS.*AUTH|AUTH.*METRICS/.test(key) && isTruthy(val)) {
            add(line, "INFO", "METRICS_AUTH_ON", key, len, "Metrics endpoint requires authentication.");
          }

          // 10. TLS explicitly off
          if (/(TLS_ENABLED|SSL_ENABLED|HTTPS_ENABLED|ENABLE_TLS|REQUIRE_TLS)/.test(key) && isFalsy(val)) {
            add(line, "HIGH", "TLS_DISABLED", key, len,
              "TLS is explicitly DISABLED. Logins and data will cross the network unencrypted. Enable TLS (directly or at a reverse proxy) before deploying.");
          }
          if (/(TLS_ENABLED|SSL_ENABLED|HTTPS_ENABLED)/.test(key) && isTruthy(val)) {
            add(line, "INFO", "TLS_ON", key, len, "TLS is enabled.");
          }
        });

        // 5b. No signup posture anywhere
        if (!hasSignupKey) {
          add(0, "WARNING", "MISSING_SIGNUP_POSTURE", "(whole config)", null,
            "No signup setting appears anywhere in this config. A self-hosted server should state its signup posture explicitly - ideally signup disabled.");
        }
        // 9b. Metrics enabled with no auth setting anywhere
        if (metricsEnabledLine !== null && !hasMetricsAuthKey) {
          add(metricsEnabledLine, "WARNING", "METRICS_NO_AUTH_NOTE", "METRICS_ENABLED", null,
            "Metrics are enabled but no metrics-auth setting appears anywhere in this config. Confirm the endpoint requires auth or is not publicly reachable.");
        }
        // 10b. No TLS posture anywhere
        if (!hasTlsKey) {
          add(0, "WARNING", "NO_TLS_POSTURE", "(whole config)", null,
            "No TLS/HTTPS setting appears anywhere in this config. State the TLS posture explicitly - enabled directly or terminated at a reverse proxy.");
        }

        var order = { BLOCKER: 0, HIGH: 1, WARNING: 2, INFO: 3 };
        findings.sort(function (a, b) {
          if (order[a.severity] !== order[b.severity]) return order[a.severity] - order[b.severity];
          return a.line - b.line;
        });
        // Present findings in line order within the report for readability:
        var byLine = findings.slice().sort(function (a, b) {
          if (a.line !== b.line) return a.line - b.line;
          return order[a.severity] - order[b.severity];
        });

        var counts = { BLOCKER: 0, HIGH: 0, WARNING: 0, INFO: 0 };
        findings.forEach(function (f) { counts[f.severity]++; });

        var verdict;
        if (counts.BLOCKER > 0) verdict = "DO NOT DEPLOY";
        else if (counts.HIGH > 0 || counts.WARNING > 0) verdict = "DEPLOY WITH FIXES";
        else verdict = "SAFE TO DEPLOY";

        return { verdict: verdict, entries: entries, findings: byLine, counts: counts };
      }

      function lineLabel(f) {
        return f.line > 0 ? "Line " + f.line : "Whole config";
      }

      function buildReport(result, sourceLabel) {
        var out = [];
        out.push("J-Dawgs Windmill Server Config Safety Auditor - Report");
        out.push("Source: " + sourceLabel);
        out.push("Verdict: " + result.verdict);
        out.push("Settings parsed: " + result.entries.length);
        out.push("Findings: " + result.counts.BLOCKER + " BLOCKER, " + result.counts.HIGH +
          " HIGH, " + result.counts.WARNING + " WARNING, " + result.counts.INFO + " INFO");
        out.push("Secrets are reported by key name, line, and value length only. No secret values are included.");
        out.push("");
        if (result.findings.length === 0) {
          out.push("No findings.");
        } else {
          result.findings.forEach(function (f) {
            var s = lineLabel(f) + " [" + f.severity + "] " + f.rule + " - Key: " + f.key;
            if (typeof f.valueLength === "number") s += " (value length: " + f.valueLength + ")";
            s += " - " + f.message;
            out.push(s);
          });
        }
        return out.join("\n");
      }

      function buildJson(result, sourceLabel) {
        return JSON.stringify({
          tool: "J-Dawgs Windmill Server Config Safety Auditor",
          source: sourceLabel,
          verdict: result.verdict,
          settingsParsed: result.entries.length,
          counts: result.counts,
          findings: result.findings.map(function (f) {
            var o = { line: f.line, severity: f.severity, rule: f.rule, key: f.key, message: f.message };
            if (typeof f.valueLength === "number") o.valueLength = f.valueLength;
            return o;
          }),
          note: "Findings carry key name, line, and value length only. No secret values are included."
        }, null, 2);
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-windmill-server-config-safety-auditortm',
  name: 'J-Dawgs Windmill Server Config Safety Auditor',
  description: 'Windmill\'s own checks only answer whether the server starts on the host; ours grades a pasted Windmill server config fully offline — worker and web-server exposure, base URL scheme, database and SMTP credentials, SSO posture, with secrets shown by key name/line/length only — into one deploy verdict:',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
