'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Zitadel Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

var RISKY = [
'ExternalDomain: http://auth.example.com',
'ExternalSecure: false',
'Port: 8080',
'TLS:',
'  Enabled: false',
'Masterkey: exampleMaster123',
'Database:',
'  Postgres:',
'    Host: db.internal',
'    Port: 5432',
'    Database: zitadel',
'    User:',
'      Username: zitadel',
'      Password: DbPass-Plaintext-99!',
'SMTPHost:',
'  Host: smtp.example.com:587',
'  User: mailer@example.com',
'  Password: SmtpPass-Plain-55!',
'  TLS: false',
'DefaultInstance:',
'  Secrets:',
'    EncryptionKey: shortkey123',
'# ExternalDomain: https://old.example.com',
'deployment notes go here with no key and no value'
].join('\n');

var HARDENED = [
'ExternalDomain: https://auth.example.com',
'ExternalSecure: true',
'ExternalPort: 443',
'Port: 8080',
'TLS:',
'  Enabled: true',
'  CertPath: /etc/zitadel/tls.crt',
'  KeyPath: /etc/zitadel/tls.key',
'Masterkey: ${ZITADEL_MASTERKEY}',
'Database:',
'  Postgres:',
'    Host: db.internal',
'    Port: 5432',
'    Database: zitadel',
'    User:',
'      Username: zitadel',
'      Password: ${ZITADEL_DB_PASSWORD}',
'SMTPHost:',
'  Host: smtp.example.com:587',
'  User: mailer@example.com',
'  Password: ${ZITADEL_SMTP_PASSWORD}',
'  TLS: true',
'Log:',
'  Level: info',
'DefaultInstance:',
'  DomainPolicy:',
'    UserLogin: true'
].join('\n');

var KNOWN = {};
('externaldomain externalsecure externalport port tls enabled certpath keypath cert key masterkey ' +
 'database postgres cockroach host username user password admin adminpassword ssl mode ' +
 'maxopenconns maxidleconns smtphost smtp log level format defaultinstance secrets encryptionkey encryptionkeys ' +
 'domainpolicy userlogin oidc saml actions projections auth api systemapi zitadel config version name ' +
 'address issuer audience from sender replyto timeout retries org project grant clientsecret clientid secret ' +
 'token apikey privatekey publickey jwt webhook header value type driver dsn source migration steps ' +
 'firstinstance orgid userid machine smtpconfig sms twilio oidcconfig loginpolicy passwordpolicy').split(' ').forEach(function(k){ KNOWN[k]=true; });

function stripQuotes(v){
  v = v.replace(/^\s+|\s+$/g,'');
  if (v.length>=2 && ((v.charAt(0)==='"' && v.charAt(v.length-1)==='"') || (v.charAt(0)==="'" && v.charAt(v.length-1)==="'"))) {
    return v.slice(1,-1);
  }
  return v;
}
function isRef(v){
  var s = stripQuotes(v);
  return /^\$\{[^}]+\}$/.test(s) || /^\$[A-Za-z_][A-Za-z0-9_]*$/.test(s) ||
    /^env:/i.test(s) || /^file:/i.test(s) || /^vault:/i.test(s) || /^secret:/i.test(s) ||
    /\/run\/secrets\//.test(s) || /^<env/i.test(s);
}
function isExample(v){
  return /example|default|change[-_ ]?me|placeholder|replace[-_ ]?me|todo|your[-_ ]|xxx/i.test(v);
}
function isTrue(v){ return /^(true|yes|on|1)$/i.test(stripQuotes(v)); }
function isFalse(v){ return /^(false|no|off|0)$/i.test(stripQuotes(v)); }
function lastSeg(full){ var p = full.split('.'); return p[p.length-1]; }

function parse(text){
  var lines = text.split(/\r?\n/);
  var entries = [];
  var stack = []; // {indent, key}
  for (var i=0;i<lines.length;i++){
    var raw = lines[i];
    var lineNo = i+1;
    var trimmed = raw.replace(/^\s+|\s+$/g,'');
    if (trimmed === '') continue;
    var indent = raw.length - raw.replace(/^\s+/,'').length;
    if (trimmed.charAt(0) === '#'){
      var body = trimmed.slice(1).replace(/^\s+/,'');
      var cm = body.match(/^([A-Za-z0-9_.\-]+)\s*:\s*(.*)$/);
      entries.push({line:lineNo, commented:true, parsed: !!cm, key: cm ? cm[1] : '', value:'', fullKey: cm ? cm[1] : ''});
      continue;
    }
    var m = trimmed.match(/^([A-Za-z0-9_.\-]+)\s*:\s*(.*)$/) || trimmed.match(/^([A-Za-z0-9_.\-]+)\s*=\s*(.*)$/);
    if (!m){
      entries.push({line:lineNo, commented:false, parsed:false, key:'', value:'', fullKey:''});
      continue;
    }
    var keyRaw = m[1];
    var value = (m[2]||'').replace(/\s+#.*$/,'').replace(/^\s+|\s+$/g,'');
    var fullKey;
    if (keyRaw.indexOf('.') >= 0){
      fullKey = keyRaw;
    } else {
      while (stack.length && stack[stack.length-1].indent >= indent) stack.pop();
      var parts = stack.map(function(s){ return s.key; });
      parts.push(keyRaw);
      fullKey = parts.join('.');
      if (value === '') stack.push({indent:indent, key:keyRaw});
    }
    entries.push({line:lineNo, commented:false, parsed:true, key:keyRaw, value:value, fullKey:fullKey, known: !!KNOWN[lastSeg(fullKey).toLowerCase()]});
  }
  return entries;
}

function audit(text){
  var findings = [];
  function add(severity, line, key, explanation, fix){
    findings.push({severity:severity, line:(line==null?null:line), key:key||'', explanation:explanation, fix:fix});
  }
  if (!text || text.replace(/\s+/g,'') === ''){
    return {verdict:'NOT ENOUGH TO GRADE', why:'Nothing was pasted. Paste a Zitadel configuration (or load one of the examples) and run the audit again.', findings:findings, counts:countAll(findings), recognized:0};
  }
  var entries = parse(text);
  var active = entries.filter(function(e){ return !e.commented && e.parsed; });
  var recognized = active.filter(function(e){ return e.known; }).length;

  // Commented and not-parsed lines are always reported, never graded as active.
  entries.forEach(function(e){
    if (e.commented){
      add('COMMENTED', e.line, e.key || '(comment)', 'This line is commented out, so Zitadel will ignore it. It is reported as COMMENTED / NOT ACTIVE and was not graded as an active setting.', 'Uncomment it only if you intend it to take effect, then run this audit again.');
    } else if (!e.parsed){
      add('NOT PARSED', e.line, '(unrecognized line)', 'This line could not be recognized as a KEY: value setting, so it was not graded. It has not been silently dropped.', 'Rewrite it as YAML (Key: value) or KEY: value, or remove it if it is just a note.');
    } else if (!e.known){
      add('NOT PARSED', e.line, e.fullKey, 'The key on this line is not a recognized Zitadel setting name, so its value was not graded. It has not been silently dropped.', 'Check the key name against your Zitadel version\u2019s configuration reference, fix any typo, and run this audit again.');
    }
  });

  if (recognized < 2){
    return {verdict:'NOT ENOUGH TO GRADE', why:'No recognizable Zitadel configuration was found in the pasted text. Paste a zitadel.yaml-style config or KEY: value lines (ExternalDomain, TLS, Masterkey, Database, SMTPHost) and run the audit again.', findings:findings, counts:countAll(findings), recognized:recognized};
  }

  // Duplicate active keys (same full dotted path).
  var seen = {};
  active.forEach(function(e){
    var k = e.fullKey.toLowerCase();
    if (seen[k]){
      add('WARNING', e.line, e.fullKey, 'This key already appears on line ' + seen[k] + '. With duplicate keys, which value wins depends on the parser, so the effective setting is ambiguous.', 'Remove the duplicate and keep one value for this key.');
    } else { seen[k] = e.line; }
  });

  function findEntry(pred){ for (var i=0;i<active.length;i++){ if (pred(active[i])) return active[i]; } return null; }
  function byLast(name){ return findEntry(function(e){ return lastSeg(e.fullKey).toLowerCase() === name; }); }
  function byFull(name){ var n = name.toLowerCase(); return findEntry(function(e){ return e.fullKey.toLowerCase() === n; }); }

  var ext = byLast('externaldomain');
  var extSecure = byLast('externalsecure');
  var tlsEnabled = findEntry(function(e){ return e.fullKey.toLowerCase().replace(/\./g,'').indexOf('tlsenabled') >= 0 || (lastSeg(e.fullKey).toLowerCase()==='enabled' && e.fullKey.toLowerCase().indexOf('tls')>=0); });
  var tlsPresent = !!findEntry(function(e){ return e.fullKey.toLowerCase().indexOf('tls')===0 || lastSeg(e.fullKey).toLowerCase()==='tls'; });
  var tlsDisabled = tlsEnabled ? isFalse(tlsEnabled.value) : !tlsPresent;
  var tlsOn = tlsEnabled ? isTrue(tlsEnabled.value) : false;

  var extValue = ext ? stripQuotes(ext.value) : '';
  var extIsHttp = /^http:\/\//i.test(extValue);
  var extIsHttps = /^https:\/\//i.test(extValue);
  var hostMatch = extValue.match(/^[a-z]+:\/\/([^\/:?#]+)/i);
  var host = hostMatch ? hostMatch[1].toLowerCase() : '';
  var isLocal = (host==='localhost' || host==='127.0.0.1' || host==='::1');
  var secureFalse = extSecure ? isFalse(extSecure.value) : false;
  var insecureExternal = (secureFalse || (extIsHttp && !isLocal));

  if (!ext){
    add('HIGH', null, 'ExternalDomain', 'No active ExternalDomain setting was found. Zitadel builds issuer URLs, redirects, and links from this value, so a missing one means the deployment\u2019s public address is undefined.', 'Set ExternalDomain to the public https address of this instance, for example an https:// domain name.');
  } else {
    if (extIsHttp && !isLocal){
      var sev1 = tlsDisabled ? 'BLOCKER' : 'HIGH';
      add(sev1, ext.line, ext.fullKey, 'The external domain uses plain http:// on a non-localhost host' + (tlsDisabled ? ', and TLS is disabled, so browser traffic, login flows, and tokens would cross the network unencrypted.' : ', so browser traffic, login flows, and tokens would cross the network unencrypted.'), 'Serve the instance over https:// (a TLS-terminating proxy or TLS in Zitadel itself) and set the external domain to the https:// address.');
    }
    if (secureFalse){
      var sev2 = tlsDisabled ? 'BLOCKER' : 'HIGH';
      add(sev2, extSecure.line, extSecure.fullKey, 'ExternalSecure is false, which tells Zitadel the external address is not secure, so it will generate http URLs and allow insecure flows' + (tlsDisabled ? '. Combined with TLS being disabled, this is a blocker.' : '.'), 'Set ExternalSecure to true once the instance is reachable over https, and enable TLS.');
    }
  }

  // TLS section.
  if (tlsEnabled && isFalse(tlsEnabled.value)){
    add('HIGH', tlsEnabled.line, tlsEnabled.fullKey, 'TLS is disabled (TLS.Enabled is false), so Zitadel itself terminates no encrypted connections. Unless a proxy in front of it terminates TLS for the external domain, all traffic is plaintext.', 'Set TLS.Enabled to true with a certificate and key, or terminate TLS at a proxy and make sure the external domain is https.');
  } else if (!tlsEnabled && !tlsPresent){
    if (extSecure && isTrue(extSecure.value)){
      add('HIGH', extSecure.line, 'TLS.Enabled', 'ExternalSecure is true but no TLS section or TLS.Enabled setting was found in the pasted config, so this audit cannot confirm TLS is enabled anywhere in this file.', 'Add a TLS section with Enabled: true (and certificate/key paths), or document the TLS-terminating proxy in the config you paste here.');
    } else {
      add('WARNING', null, 'TLS.Enabled', 'No TLS section was found in the pasted config, so TLS enablement could not be confirmed from this file.', 'Add a TLS section with Enabled: true, or paste the section of config that shows where TLS is terminated.');
    }
  }

  // Masterkey — value never rendered; length only.
  var mk = byLast('masterkey');
  if (!mk){
    add('BLOCKER', null, 'Masterkey', 'No active Masterkey setting was found. Zitadel encrypts instance secrets with this key; a missing masterkey means the instance cannot be graded as safe to deploy.', 'Set Masterkey to a randomly generated value of exactly 32 bytes, supplied through an environment reference or secret file rather than typed into a shared file.');
  } else if (isRef(mk.value)){
    add('OK', mk.line, mk.fullKey, 'The masterkey is supplied as a reference (environment / file / secret reference) rather than a literal value in this file, so no literal secret is exposed here. Its length cannot be graded from a reference.', 'Make sure the referenced value is a randomly generated 32-byte key in the environment or secret store at deploy time.');
  } else {
    var mkVal = stripQuotes(mk.value);
    if (isExample(mkVal) || mkVal.length < 32){
      var reasons = [];
      if (mkVal.length < 32) reasons.push('it is only ' + mkVal.length + ' characters long (Zitadel expects exactly 32 bytes)');
      if (isExample(mkVal)) reasons.push('it matches an example / default / change-me pattern');
      add('BLOCKER', mk.line, mk.fullKey, 'The masterkey is not deploy-grade: ' + reasons.join(' and ') + '. The value itself is not shown in this report — only its length.', 'Replace it with a randomly generated 32-byte key and supply it through an environment reference or secret file.');
    } else if (mkVal.length > 32){
      add('WARNING', mk.line, mk.fullKey, 'The masterkey is ' + mkVal.length + ' characters long; Zitadel expects exactly 32 bytes. The value itself is not shown in this report — only its length.', 'Use a randomly generated key of exactly 32 bytes.');
    } else {
      add('OK', mk.line, mk.fullKey, 'The masterkey is present at 32 characters and does not match an example or default pattern. The value itself is not shown in this report.', 'No change needed. Prefer supplying it through an environment reference or secret file.');
    }
  }

  // Passwords and secrets — value never rendered; length only.
  var handledSecrets = {};
  if (mk) handledSecrets[mk.line + ':masterkey'] = true;
  active.forEach(function(e){
    var last = lastSeg(e.fullKey).toLowerCase();
    var full = e.fullKey.toLowerCase();
    var isSmtp = full.indexOf('smtp') >= 0;
    var isDb = full.indexOf('database') >= 0 || full.indexOf('postgres') >= 0 || full.indexOf('cockroach') >= 0;
    var isPasswordKey = (last === 'password' || last === 'adminpassword');
    var isSecretKey = (last === 'encryptionkey' || last === 'encryptionkeys' || last === 'clientsecret' || last === 'secret' || last === 'apikey' || last === 'privatekey');
    var inDefault = full.indexOf('defaultinstance') >= 0 || full.indexOf('secrets') >= 0;
    if (!isPasswordKey && !isSecretKey) return;
    if (last === 'encryptionkey' || last === 'encryptionkeys' || isSecretKey){ /* handled below as secret keys */ }
    if (e.value === '') {
      if (isPasswordKey) add('WARNING', e.line, e.fullKey, 'This password setting is present but empty.', 'Supply the password through an environment reference or secret file.');
      return;
    }
    if (isRef(e.value)){
      add('OK', e.line, e.fullKey, 'This credential is supplied as a reference (environment / file / secret reference) rather than a literal value in this file, so no literal secret is exposed here.', 'No change needed. Make sure the reference resolves at deploy time.');
      return;
    }
    var len = stripQuotes(e.value).length;
    var ex = isExample(stripQuotes(e.value));
    if (isPasswordKey && isSmtp){
      add('HIGH', e.line, e.fullKey, 'The SMTP password is stored as plaintext in this config (value length: ' + len + ' characters; the value is not shown). Anyone who can read this file can send mail as this instance.', 'Move the SMTP password into an environment reference or secret file and rotate the exposed password.');
    } else if (isPasswordKey && isDb){
      add('HIGH', e.line, e.fullKey, 'A database password is stored as plaintext in this config (value length: ' + len + ' characters; the value is not shown). Anyone who can read this file can reach the database with these credentials.', 'Move the database password into an environment reference or secret file and rotate the exposed password.');
    } else if (isPasswordKey){
      add('HIGH', e.line, e.fullKey, 'A password is stored as plaintext in this config (value length: ' + len + ' characters; the value is not shown).', 'Move this password into an environment reference or secret file and rotate the exposed password.');
    } else if (isSecretKey){
      if (ex){
        add('HIGH', e.line, e.fullKey, 'This secret / encryption key matches an example or default pattern (value length: ' + len + ' characters; the value is not shown)' + (inDefault ? ' in the default-instance / secrets settings.' : '.'), 'Replace it with a randomly generated value supplied through an environment reference or secret file, and rotate the exposed value.');
      } else if (len < 16){
        add('WARNING', e.line, e.fullKey, 'This secret / encryption key is short — ' + len + ' characters (the value is not shown)' + (inDefault ? ' in the default-instance / secrets settings.' : '.') + ' Short keys are guessable and weaken encryption of stored secrets.', 'Use a randomly generated key of at least 32 characters, supplied through an environment reference or secret file.');
      } else if (len < 32 && (last === 'encryptionkey' || last === 'encryptionkeys')){
        add('WARNING', e.line, e.fullKey, 'This encryption key is ' + len + ' characters long (the value is not shown); 32 characters is the expected strength for encryption keys.', 'Use a randomly generated 32-character encryption key supplied through an environment reference or secret file.');
      } else {
        add('OK', e.line, e.fullKey, 'This secret / encryption key is present at ' + len + ' characters and does not match an example pattern. The value is not shown in this report.', 'No change needed. Prefer an environment reference or secret file.');
      }
    }
  });

  // SMTP TLS.
  var smtpTls = findEntry(function(e){ return e.fullKey.toLowerCase().indexOf('smtp')>=0 && lastSeg(e.fullKey).toLowerCase()==='tls'; });
  var smtpHost = findEntry(function(e){ return e.fullKey.toLowerCase().indexOf('smtp')>=0 && lastSeg(e.fullKey).toLowerCase()==='host'; });
  if (smtpTls && isFalse(smtpTls.value)){
    add('WARNING', smtpTls.line, smtpTls.fullKey, 'SMTP TLS is off, so mail — including password-reset and verification messages — can cross the network unencrypted, credentials included.', 'Turn SMTP TLS on and use the provider\u2019s TLS submission port.');
  }
  if (smtpHost && !smtpTls){
    add('INFO', smtpHost.line, smtpHost.fullKey, 'An SMTP host is configured but no SMTP TLS setting appears in the pasted config, so mail encryption could not be confirmed from this file.', 'Add the SMTP TLS setting explicitly (TLS: true) so the posture is visible in the config.');
  }

  // Log level misuse.
  var logLevel = findEntry(function(e){ return e.fullKey.toLowerCase().indexOf('log')>=0 && lastSeg(e.fullKey).toLowerCase()==='level'; });
  if (logLevel){
    var lv = stripQuotes(logLevel.value).toLowerCase();
    if (lv === 'debug' || lv === 'trace' || lv === 'panic'){
      add('WARNING', logLevel.line, logLevel.fullKey, 'The log level is set to "' + lv + '". Debug-level logging in production can write sensitive request and token details into log files.', 'Run production at info or warn level and raise verbosity only briefly while troubleshooting.');
    }
  }

  // Top-level Port listener.
  var portEntry = findEntry(function(e){ return e.fullKey.toLowerCase() === 'port'; });
  if (portEntry && stripQuotes(portEntry.value) === '8080'){
    if (extIsHttps && tlsOn){
      add('INFO', portEntry.line, portEntry.fullKey, 'Port 8080 is a plaintext HTTP listener, but the external domain is https and TLS is enabled in this config, so this reads as the internal listener behind a TLS-terminated external domain.', 'Keep port 8080 reachable only inside your network or from the TLS-terminating proxy — do not expose it directly to the internet.');
    } else {
      add('WARNING', portEntry.line, portEntry.fullKey, 'Port 8080 is a plaintext HTTP listener, and this config does not show a TLS-terminated https external domain in front of it, so traffic to this listener would be unencrypted.', 'Put a TLS-terminating proxy or Zitadel TLS in front of this listener, or restrict it to a private network.');
    }
  }

  var counts = countAll(findings);
  var verdict, why;
  if (counts.BLOCKER > 0){
    verdict = 'DO NOT DEPLOY';
    why = 'This config has ' + counts.BLOCKER + ' blocker finding' + (counts.BLOCKER===1?'':'s') + '. Fix every blocker — and the high findings — before this configuration goes anywhere near production.';
  } else if (counts.HIGH > 0 || counts.WARNING > 0){
    verdict = 'DEPLOY WITH FIXES';
    why = 'No blockers, but ' + counts.HIGH + ' high and ' + counts.WARNING + ' warning finding' + (counts.WARNING===1?'':'s') + ' need attention before this config is production-grade.';
  } else {
    verdict = 'SAFE TO DEPLOY';
    why = 'No blocker, high, or warning findings in the active settings of this pasted config. Commented and unrecognized lines, if any, are listed below and were not graded.';
  }
  // Order findings: graded findings by line, then missing-key findings, keeping commented/not-parsed in line order within the list.
  findings.sort(function(a,b){
    var la = (a.line==null?9999:a.line), lb = (b.line==null?9999:b.line);
    return la - lb;
  });
  return {verdict:verdict, why:why, findings:findings, counts:counts, recognized:recognized};
}

function countAll(findings){
  var c = {BLOCKER:0, HIGH:0, WARNING:0, INFO:0, OK:0, COMMENTED:0, 'NOT PARSED':0, total:findings.length};
  findings.forEach(function(f){ if (c.hasOwnProperty(f.severity)) c[f.severity]++; });
  return c;
}

function esc(s){
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

var lastResult = null;

function buildTextReport(r){
  var out = [];
  out.push('J-Dawgs Zitadel Server Config Safety Auditor\u2122 — audit report');
  out.push('Verdict: ' + r.verdict);
  out.push(r.why);
  out.push('Counts: BLOCKER ' + r.counts.BLOCKER + ' | HIGH ' + r.counts.HIGH + ' | WARNING ' + r.counts.WARNING + ' | INFO ' + r.counts.INFO + ' | OK ' + r.counts.OK + ' | COMMENTED ' + r.counts.COMMENTED + ' | NOT PARSED ' + r.counts['NOT PARSED']);
  out.push('Secret values are never included in this report; secrets are reported by key name, line, and length only.');
  out.push('');
  out.push('Findings:');
  if (!r.findings.length) out.push('(none)');
  r.findings.forEach(function(f, idx){
    out.push((idx+1) + '. [' + f.severity + '] Line ' + (f.line==null?'—':f.line) + ' — ' + (f.key||''));
    out.push('   ' + f.explanation);
    out.push('   Fix: ' + f.fix);
  });
  out.push('');
  out.push('Scope note: this audit grades only the pasted text. It does not start Zitadel, connect to a database, or verify a live instance, and it is not security certification.');
  return out.join('\n');
}
function buildJsonReport(r){
  return JSON.stringify({
    tool: 'J-Dawgs Zitadel Server Config Safety Auditor\u2122',
    verdict: r.verdict,
    verdictReason: r.why,
    counts: {BLOCKER:r.counts.BLOCKER, HIGH:r.counts.HIGH, WARNING:r.counts.WARNING, INFO:r.counts.INFO, OK:r.counts.OK, COMMENTED:r.counts.COMMENTED, NOT_PARSED:r.counts['NOT PARSED'], total:r.counts.total},
    secretValuesIncluded: false,
    findings: r.findings.map(function(f){
      return {severity:f.severity, line:f.line, key:f.key, explanation:f.explanation, fix:f.fix};
    })
  }, null, 2);
}
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-zitadel-server-config-safety-auditortm',
  name: 'J-Dawgs Zitadel Server Config Safety Auditor',
  description: '',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
