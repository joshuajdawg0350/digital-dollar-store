'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Geode Cluster Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var RISKY = [
        "# Copied from a dev laptop - \"temporary\" production locator",
        "#security-manager=com.example.security.DevSecurityManager",
        "name=locator1",
        "locators=192.168.10.15[10334]",
        "bind-address=0.0.0.0",
        "server-bind-address=0.0.0.0",
        "jmx-manager=true",
        "jmx-manager-port=1099",
        "http-service-port=7070",
        "http-service-bind-address=0.0.0.0",
        "start-dev-rest-api=true",
        "enable-cluster-configuration=true",
        "cluster-ssl-enabled=false",
        "ssl-enabled-components=none",
        "ssl-require-authentication=false",
        "security-client-authenticator=",
        "security-password=admin",
        "ssl-keystore-password=changeit"
      ].join("\n");

      var HARDENED = [
        "# Production locator - hardened",
        "name=prod-locator-1",
        "locators=locator1.internal.example.net[10334]",
        "bind-address=10.20.30.41",
        "server-bind-address=10.20.30.42",
        "security-manager=com.example.geode.security.ProdSecurityManager",
        "security-client-authenticator=com.example.geode.security.ProdClientAuthenticator",
        "security-peer-auth-init=com.example.geode.security.ProdPeerAuthInit",
        "jmx-manager=true",
        "jmx-manager-port=1099",
        "jmx-manager-ssl-enabled=true",
        "http-service-port=0",
        "start-dev-rest-api=false",
        "enable-cluster-configuration=true",
        "ssl-enabled-components=cluster,locator,server,jmx,web",
        "ssl-require-authentication=true",
        "ssl-keystore=keystore/prod-locator.jks",
        "ssl-keystore-password=${PROD_KEYSTORE_PASSWORD}",
        "ssl-truststore=keystore/prod-truststore.jks",
        "ssl-truststore-password=${PROD_TRUSTSTORE_PASSWORD}"
      ].join("\n");

      var WEAK = {"password":1,"changeit":1,"changeme":1,"admin":1,"geode":1,"gemfire":1,"secret":1,"test":1,"default":1,"example":1,"letmein":1,"123456":1,"passw0rd":1,"root":1,"admin123":1};
      var SIGNAL_TERMS = ["geode","gemfire","locator","security-manager","security-client","security-peer","ssl-","cluster-ssl","jmx-manager","http-service","cache-server","<cache","gfsh","start locator","start server","mcast-port","membership","start-dev-rest-api","enable-cluster-configuration","ssl-enabled-components","conserve-sockets","locators="];

      function $(id){ return document.getElementById(id); }

      function canon(key){
        var k = key.toLowerCase().replace(/^gemfire\./,"").replace(/^geode\./,"");
        return k;
      }
      function stripQuotes(v){
        v = v.replace(/^\s+|\s+$/g,"");
        if(v.length>=2 && ((v.charAt(0)==='"' && v.charAt(v.length-1)==='"') || (v.charAt(0)==="'" && v.charAt(v.length-1)==="'"))){ v = v.substring(1, v.length-1); }
        return v;
      }

      // Split raw text into lines; remove XML comment spans and mark
      // properties-style comment lines. Returns active line texts only.
      function activeLines(text){
        var raw = text.split(/\r?\n/);
        var out = [];
        var inComment = false;
        for(var i=0;i<raw.length;i++){
          var line = raw[i];
          var active = "";
          var j = 0;
          while(j < line.length){
            if(inComment){
              var end = line.indexOf("-->", j);
              if(end === -1){ j = line.length; }
              else { inComment = false; j = end + 3; }
            } else {
              var start = line.indexOf("<!--", j);
              if(start === -1){ active += line.substring(j); j = line.length; }
              else { active += line.substring(j, start); inComment = true; j = start + 4; }
            }
          }
          var trimmed = active.replace(/^\s+/,"");
          if(trimmed.charAt(0) === "#" || trimmed.charAt(0) === "!" || trimmed.indexOf("//") === 0){
            continue; // commented-out line: never graded
          }
          if(trimmed === ""){ continue; }
          out.push({ n: i + 1, text: active });
        }
        return { total: raw.length, active: out };
      }

      function parseEntries(lines){
        var entries = [];
        for(var i=0;i<lines.length;i++){
          var n = lines[i].n;
          var t = lines[i].text.replace(/^\s+|\s+$/g,"");
          var m, re;
          if(t.charAt(0) === "<"){
            re = /([A-Za-z][A-Za-z0-9\-.]*)="([^"]*)"/g;
            while((m = re.exec(t)) !== null){
              entries.push({ key: canon(m[1]), rawKey: m[1], value: m[2], line: n });
            }
          } else {
            var pm = t.match(/^([^=:\s][^=:]*?)\s*[=:]\s*(.*)$/);
            if(pm){
              entries.push({ key: canon(pm[1].replace(/\s+$/,"")), rawKey: pm[1].replace(/\s+$/,""), value: stripQuotes(pm[2]), line: n });
            }
            re = /--([A-Za-z][A-Za-z0-9\-]*)=([^\s]+)/g;
            while((m = re.exec(t)) !== null){
              entries.push({ key: canon(m[1]), rawKey: m[1], value: stripQuotes(m[2]), line: n });
            }
            re = /-D([A-Za-z][A-Za-z0-9.\-]*)=([^\s]+)/g;
            while((m = re.exec(t)) !== null){
              entries.push({ key: canon(m[1]), rawKey: m[1], value: stripQuotes(m[2]), line: n });
            }
          }
        }
        return entries;
      }

      function getEntries(entries, name){
        var r = [];
        for(var i=0;i<entries.length;i++){ if(entries[i].key === name){ r.push(entries[i]); } }
        return r;
      }
      function isDisabledValue(v){
        var s = v.replace(/\s+/g,"").toLowerCase();
        return s === "" || s === "none" || s === "null" || s === "false" || s === "disabled" || s === "noop";
      }
      function isWildcard(v){
        var s = v.replace(/\s+/g,"").toLowerCase();
        return s === "0.0.0.0" || s === "::" || s === "*" || s === "[::]" || s === "0:0:0:0:0:0:0:0";
      }
      function isSecretKey(k){
        return /(password|passwd|secret|token|credential|api[-_]?key)/i.test(k);
      }
      function isPlaceholder(v){
        return v.indexOf("${") === 0 || v.indexOf("ENC(") === 0 || v.toLowerCase().indexOf("env:") === 0 || v.toLowerCase().indexOf("file:") === 0;
      }

      function audit(text){
        var split = activeLines(text || "");
        var lines = split.active;
        var lowerAll = (text || "").toLowerCase();
        var distinct = 0;
        for(var s=0;s<SIGNAL_TERMS.length;s++){ if(lowerAll.indexOf(SIGNAL_TERMS[s]) !== -1){ distinct++; } }
        var entries = parseEntries(lines);

        if(!text || text.replace(/\s+/g,"") === "" || distinct < 2 || entries.length === 0){
          return { verdict: "NOT ENOUGH TO GRADE", findings: [], lines: split.total, activeCount: entries.length,
            verdictNote: "Too little Geode signal in this paste to grade honestly. Paste gemfire.properties / gfsecurity settings, a cache.xml excerpt, or locator/server startup settings." };
        }

        var F = [];
        function add(rule, severity, line, key, title, message, fix){
          F.push({ rule: rule, severity: severity, line: line, key: key, title: title, message: message, fix: fix });
        }

        // --- Security manager ---
        var smEntries = getEntries(entries, "security-manager");
        var managerOK = false;
        if(smEntries.length === 0){
          add("security-manager-missing","CRITICAL",null,"security-manager",
            "Security manager is not set",
            "No active line sets security-manager. Commented-out lines do not count, so this cluster would start with no central authorization checks.",
            "Set security-manager to your SecurityManager implementation class on every locator and server.");
        } else {
          for(var a=0;a<smEntries.length;a++){
            if(isDisabledValue(smEntries[a].value)){
              add("security-manager-disabled","CRITICAL",smEntries[a].line,"security-manager",
                "Security manager is disabled",
                "The active security-manager setting on this line is empty or disabled, so no security manager will enforce access control.",
                "Point security-manager at a real SecurityManager implementation class.");
            } else { managerOK = true; }
          }
        }

        // --- Client authentication ---
        var caEntries = getEntries(entries, "security-client-authenticator");
        var clientAuthDisabled = false;
        if(caEntries.length === 0){
          if(!managerOK){
            add("client-auth-not-configured","CRITICAL",null,"security-client-authenticator",
              "Client authentication is not configured",
              "There is no active security-manager and no active security-client-authenticator, so clients can connect without proving who they are.",
              "Configure a security manager (which handles client authentication) or set security-client-authenticator to a real authenticator class.");
          }
        } else {
          for(var b=0;b<caEntries.length;b++){
            if(isDisabledValue(caEntries[b].value)){
              clientAuthDisabled = true;
              add("client-auth-disabled","CRITICAL",caEntries[b].line,"security-client-authenticator",
                "Client authentication is disabled",
                "The active security-client-authenticator setting on this line is empty or disabled, so client connections are not authenticated.",
                "Set security-client-authenticator to a real authenticator class, or rely on a configured security manager.");
            }
          }
        }
        var authOK = managerOK && !clientAuthDisabled;

        // --- Wildcard / all-interface binds ---
        var anyWildcard = false;
        for(var c=0;c<entries.length;c++){
          var e = entries[c];
          if(e.key.indexOf("bind-address") !== -1 && isWildcard(e.value)){
            anyWildcard = true;
            add("wildcard-bind","HIGH",e.line,e.rawKey,
              "Endpoint binds every interface (" + e.rawKey + ")",
              "This bind setting uses a wildcard / all-interface address, so the endpoint listens on every network interface, not just the intended one.",
              "Bind to a specific internal address for locator, server, REST, and JMX endpoints instead of a wildcard address.");
          }
        }

        // --- SSL/TLS explicit disables & require-authentication ---
        var sslExplicitlyDisabled = false;
        var compEntries = getEntries(entries, "ssl-enabled-components");
        var components = null;
        for(var d=0;d<compEntries.length;d++){
          var cv = compEntries[d].value.toLowerCase().replace(/\s+/g,"");
          if(cv === "" || cv === "none"){
            sslExplicitlyDisabled = true;
            add("ssl-disabled","CRITICAL",compEntries[d].line,"ssl-enabled-components",
              "SSL/TLS is disabled",
              "ssl-enabled-components is empty or set to none, so no component encrypts its traffic.",
              "Enable SSL for the cluster, locator, server, JMX, and web components and provide keystore/truststore settings.");
          } else {
            components = cv.split(",");
          }
        }
        var sslFalseKeys = {"cluster-ssl-enabled":"CRITICAL","ssl-enabled":"CRITICAL","server-ssl-enabled":"HIGH","jmx-manager-ssl-enabled":"HIGH","http-service-ssl-enabled":"HIGH"};
        for(var keyName in sslFalseKeys){
          if(!sslFalseKeys.hasOwnProperty(keyName)){ continue; }
          var list = getEntries(entries, keyName);
          for(var f=0;f<list.length;f++){
            if(list[f].value.toLowerCase() === "false"){
              sslExplicitlyDisabled = true;
              add("ssl-disabled","HIGH" === sslFalseKeys[keyName] && keyName !== "cluster-ssl-enabled" && keyName !== "ssl-enabled" ? "HIGH" : sslFalseKeys[keyName], list[f].line, keyName,
                "SSL/TLS is disabled (" + keyName + ")",
                "This active setting turns SSL/TLS off, leaving that traffic in plain text.",
                "Turn SSL on for this component and configure its keystore and truststore.");
            }
          }
        }
        var reqAuthKeys = ["ssl-require-authentication","cluster-ssl-require-authentication","ssl-web-require-authentication","server-ssl-require-authentication"];
        for(var g=0;g<reqAuthKeys.length;g++){
          var rl = getEntries(entries, reqAuthKeys[g]);
          for(var h=0;h<rl.length;h++){
            if(rl[h].value.toLowerCase() === "false"){
              add("ssl-require-auth-off","HIGH",rl[h].line,reqAuthKeys[g],
                "SSL require-authentication is off (" + reqAuthKeys[g] + ")",
                "With require-authentication off, peers and clients are not required to present a trusted certificate, so TLS alone does not prove who is connecting — a real exposure while endpoints are reachable.",
                "Set require-authentication to true so both sides of a TLS connection are authenticated.");
            }
          }
        }

        // --- Secrets: plaintext, short, example/default (value NEVER reported) ---
        for(var k=0;k<entries.length;k++){
          var se = entries[k];
          if(!isSecretKey(se.key)){ continue; }
          var v = se.value;
          if(v === "" || isPlaceholder(v)){ continue; }
          add("plaintext-secret","HIGH",se.line,se.rawKey,
            "Plaintext secret in configuration (" + se.rawKey + ")",
            "Key '" + se.rawKey + "' on line " + se.line + " holds a plaintext secret (length: " + v.length + " characters). The value is never shown in this audit.",
            "Move the secret out of the file: use an environment-variable placeholder, an encrypted value, or a secrets store, and rotate the exposed secret.");
          var lv = v.toLowerCase();
          if(WEAK[lv] || lv.indexOf("example") !== -1 || lv.indexOf("default") !== -1){
            add("default-secret","HIGH",se.line,se.rawKey,
              "Example / default secret (" + se.rawKey + ")",
              "Key '" + se.rawKey + "' on line " + se.line + " matches a known example or default secret pattern (length: " + v.length + " characters). The value is never shown in this audit.",
              "Replace it with a unique, randomly generated secret and rotate it anywhere the example value was ever used.");
          } else if(v.length < 12){
            add("short-secret","HIGH",se.line,se.rawKey,
              "Short secret (" + se.rawKey + ")",
              "Key '" + se.rawKey + "' on line " + se.line + " holds a short secret (length: " + v.length + " characters). The value is never shown in this audit.",
              "Use a unique secret of at least 16 characters, generated randomly.");
          }
        }

        // --- HTTP service (Pulse / developer REST) without authentication ---
        var httpLine = null;
        var portEntries = getEntries(entries, "http-service-port");
        for(var p=0;p<portEntries.length;p++){
          if(portEntries[p].value !== "" && portEntries[p].value !== "0"){ httpLine = portEntries[p].line; }
        }
        var restEntries = getEntries(entries, "start-dev-rest-api");
        for(var q=0;q<restEntries.length;q++){
          if(restEntries[q].value.toLowerCase() === "true" && httpLine === null){ httpLine = restEntries[q].line; }
        }
        if(httpLine !== null && !authOK){
          add("http-service-no-auth","CRITICAL",httpLine,"http-service-port",
            "HTTP service enabled without authentication",
            "The HTTP service (Pulse / developer REST API) is switched on while client authentication is not configured, so the web endpoints are reachable without proven identity.",
            "Disable the HTTP service in production, or configure a security manager / client authentication and SSL before enabling it.");
        }

        // --- SSL present for cluster / locator communication? ---
        var sslConfigured = false;
        if(components){
          for(var r=0;r<components.length;r++){
            if(components[r] === "cluster" || components[r] === "locator" || components[r] === "server" || components[r] === "all"){ sslConfigured = true; }
          }
        }
        var cse = getEntries(entries, "cluster-ssl-enabled");
        for(var s2=0;s2<cse.length;s2++){ if(cse[s2].value.toLowerCase() === "true"){ sslConfigured = true; } }
        var se2 = getEntries(entries, "ssl-enabled");
        for(var s3=0;s3<se2.length;s3++){ if(se2[s3].value.toLowerCase() === "true"){ sslConfigured = true; } }
        if(!sslConfigured && !sslExplicitlyDisabled){
          add("ssl-missing-cluster","CRITICAL",null,"ssl-enabled-components",
            "No SSL/TLS configured for cluster / locator communication",
            "No active setting enables SSL for the cluster or locator components, so member and locator traffic — including credentials — crosses the network unencrypted.",
            "Set ssl-enabled-components to include cluster and locator (and server, jmx, web as needed) with keystore and truststore settings.");
        }

        // --- Cluster configuration service exposed ---
        var ccEntries = getEntries(entries, "enable-cluster-configuration");
        for(var t2=0;t2<ccEntries.length;t2++){
          if(ccEntries[t2].value.toLowerCase() === "true" && (!managerOK || anyWildcard || !sslConfigured)){
            add("cluster-config-exposed","HIGH",ccEntries[t2].line,"enable-cluster-configuration",
              "Cluster configuration service is exposed",
              "The cluster configuration service is enabled on a locator that is missing a security manager, a specific bind address, or cluster SSL — so cluster-wide configuration can be reached and changed too easily.",
              "Run the configuration service only on secured locators: security manager set, specific bind address, and cluster SSL on.");
          }
        }

        var crit = 0, high = 0;
        for(var u=0;u<F.length;u++){ if(F[u].severity === "CRITICAL"){ crit++; } else if(F[u].severity === "HIGH"){ high++; } }
        var verdict, note;
        if(crit > 0){ verdict = "DO NOT DEPLOY"; note = "Critical findings must be fixed before this configuration goes anywhere near production."; }
        else if(F.length > 0){ verdict = "DEPLOY WITH FIXES"; note = "No critical findings, but the high findings below should be fixed before deployment."; }
        else { verdict = "SAFE TO DEPLOY"; note = "No findings: the pasted settings pass every check in this audit. This grades the pasted text only — it is not a test of a running cluster."; }
        return { verdict: verdict, verdictNote: note, findings: F, lines: split.total, activeCount: entries.length, critical: crit, high: high };
      }

      var lastResult = null;

      function escapeHtml(s){
        return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
      }

      function render(result){
        lastResult = result;
        var box = $("verdictBox");
        box.className = "verdict show " + (result.verdict === "SAFE TO DEPLOY" ? "safe" : result.verdict === "DEPLOY WITH FIXES" ? "fixes" : result.verdict === "DO NOT DEPLOY" ? "donot" : "neutral");
        box.innerHTML = escapeHtml(result.verdict) + "<small>" + escapeHtml(result.verdictNote) + "</small>";
        $("statsRow").style.display = "flex";
        $("statCritical").textContent = result.critical || 0;
        $("statHigh").textContent = result.high || 0;
        $("statLines").textContent = result.lines;
        $("statActive").textContent = result.activeCount;
        var list = $("findingsList");
        if(result.findings.length === 0){
          list.innerHTML = result.verdict === "NOT ENOUGH TO GRADE"
            ? "<p class='note'>Nothing was graded. Paste a fuller Geode configuration — properties settings, a cache.xml excerpt, or startup flags — and run the audit again.</p>"
            : "<p>No findings. Every active setting in the paste passed the checks above.</p>";
        } else {
          var html = "";
          for(var i=0;i<result.findings.length;i++){
            var fd = result.findings[i];
            html += "<div class='finding'><div class='top'>"
              + "<span class='chip " + (fd.severity === "CRITICAL" ? "critical" : "high") + "'>" + escapeHtml(fd.severity) + "</span>"
              + "<span class='linetag'>" + (fd.line === null ? "Missing setting" : "Line " + fd.line) + "</span>"
              + "<span class='keytag'>" + escapeHtml(fd.key) + "</span></div>"
              + "<p><span class='title'>" + escapeHtml(fd.title) + "</span> — " + escapeHtml(fd.message) + "</p>"
              + "<p class='fix'><strong>Fix:</strong> " + escapeHtml(fd.fix) + "</p></div>";
          }
          list.innerHTML = html;
        }
        $("reportText").textContent = buildTextReport(result);
        $("reportJson").textContent = JSON.stringify(buildJson(result), null, 2);
      }

      function buildTextReport(result){
        var out = [];
        out.push("J-Dawgs Geode Cluster Config Safety Auditor - Report");
        out.push("Generated: " + new Date().toLocaleString());
        out.push("Verdict: " + result.verdict);
        out.push("Lines scanned: " + result.lines + " | Active settings read: " + result.activeCount);
        out.push("Findings: " + (result.critical || 0) + " critical, " + (result.high || 0) + " high");
        out.push("");
        if(result.findings.length === 0){
          out.push(result.verdict === "NOT ENOUGH TO GRADE" ? "No findings - the paste did not contain enough Geode signal to grade." : "No findings.");
        } else {
          for(var i=0;i<result.findings.length;i++){
            var fd = result.findings[i];
            out.push("[" + fd.severity + "] " + (fd.line === null ? "Missing setting" : "Line " + fd.line) + " | " + fd.key + " | " + fd.title);
            out.push("  " + fd.message);
            out.push("  Fix: " + fd.fix);
          }
        }
        out.push("");
        out.push("Note: Secret values are never printed. Secrets are reported by key name, line, and length only.");
        out.push("Scope: This report grades pasted configuration text only. No cluster was started and no locator or server was contacted.");
        return out.join("\n");
      }

      function buildJson(result){
        return {
          tool: "J-Dawgs Geode Cluster Config Safety Auditor",
          generatedAt: new Date().toISOString(),
          verdict: result.verdict,
          summary: { critical: result.critical || 0, high: result.high || 0, linesScanned: result.lines, activeSettings: result.activeCount },
          findings: result.findings.map(function(fd){
            return { rule: fd.rule, severity: fd.severity, line: fd.line, key: fd.key, title: fd.title, message: fd.message, fix: fd.fix };
          }),
          note: "Secret values are never included. Secrets are reported by key name, line, and length only."
        };
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-geode-cluster-config-safety-auditortm',
  name: 'J-Dawgs Geode Cluster Config Safety Auditor',
  description: 'Grades a pasted Apache Geode cluster configuration fully offline into one deploy verdict, with plaintext secrets shown by key name, line, and length only, never by value. Geode only exercises a config by starting the cluster; this grades it before anything starts.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
