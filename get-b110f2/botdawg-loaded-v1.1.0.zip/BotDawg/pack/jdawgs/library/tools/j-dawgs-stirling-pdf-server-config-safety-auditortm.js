'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Stirling PDF Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

var RISKY = [
'# Stirling PDF - RISKY example (do not deploy as-is)',
'server:',
'  port: 8080',
'  address: 0.0.0.0',
'security:',
'  enableLogin: false',
'  initialUsername: admin',
'  initialPassword: admin',
'oauth:',
'  enabled: true',
'  issuer: http://auth.example.local/realms/main',
'  clientId: stirling-pdf',
'  autoCreateUser: true',
'system:',
'  enableUrlToPDF: true',
'  enableExternalWebContent: true',
'metrics:',
'  enabled: true',
'management:',
'  endpoints:',
'    web:',
'      exposure:',
'        include: "*"',
'  endpoint:',
'    health:',
'      show-details: always',
'spring:',
'  datasource:',
'    url: jdbc:postgresql://db:5432/stirling',
'    username: stirling',
'    password: plainTextDbPass123',
'  mail:',
'    host: smtp.example.local',
'    password: mailSecret99',
'env:',
'  SECURITY_ENABLELOGIN: "false"',
'  DOCKER_ENABLE_SECURITY: "false"',
'  DISABLE_ADDITIONAL_FEATURES: "false"'
].join('\n');

var HARDENED = [
'# Stirling PDF - HARDENED example',
'server:',
'  port: 8080',
'  address: 127.0.0.1',
'security:',
'  enableLogin: true',
'  initialUsername: ${STIRLING_ADMIN_USER}',
'  initialPassword: ${STIRLING_ADMIN_PASSWORD}',
'oauth:',
'  enabled: true',
'  issuer: https://auth.example.com/realms/main',
'  clientId: stirling-pdf',
'system:',
'  enableUrlToPDF: false',
'metrics:',
'  enabled: false',
'management:',
'  endpoints:',
'    web:',
'      exposure:',
'        include: health,info',
'  endpoint:',
'    health:',
'      show-details: never',
'spring:',
'  datasource:',
'    password: ${DB_PASSWORD}',
'  mail:',
'    password: ${MAIL_PASSWORD}',
'env:',
'  SECURITY_ENABLELOGIN: "true"',
'  DOCKER_ENABLE_SECURITY: "true"',
'  DISABLE_ADDITIONAL_FEATURES: "true"'
].join('\n');

function valOf(line){
  var i = line.indexOf(':'); var j = line.indexOf('=');
  var idx = -1;
  if(i>-1 && j>-1) idx = Math.min(i,j); else idx = Math.max(i,j);
  if(idx<0) return '';
  return line.slice(idx+1).trim().replace(/^["']|["']$/g,'').trim();
}
function keyOf(line){
  var t=line.trim(); var i=t.indexOf(':'); var j=t.indexOf('=');
  var idx=-1; if(i>-1&&j>-1) idx=Math.min(i,j); else idx=Math.max(i,j);
  return idx<0 ? t : t.slice(0,idx).trim();
}
function isEnvRef(v){ return v.indexOf('${')===0 || v.indexOf('$')===0; }
function isTrue(v){ v=(''+v).toLowerCase(); return v==='true'||v==='yes'||v==='1'||v==='on'; }
function isFalse(v){ v=(''+v).toLowerCase(); return v==='false'||v==='no'||v==='0'||v==='off'; }

function audit(text){
  var lines = text.split(/\r?\n/);
  var findings=[];
  function add(sev,check,line,found,fix){ findings.push({severity:sev,check:check,line:line,found:found,fix:fix}); }
  var lower = text.toLowerCase();
  var signals = 0;
  ['stirling','enablelogin','security_enablelogin','enableurltopdf','docker_enable_security','initialusername','initialpassword','disable_additional_features'].forEach(function(k){ if(lower.indexOf(k)>-1) signals++; });
  // generic yaml/env with server+security also counts a little
  if(lower.indexOf('server:')>-1) signals+=0; 
  var looksStirling = signals>=2 || lower.indexOf('stirling')>-1;
  if(!text.trim() || !looksStirling){
    return {verdict:'NOT ENOUGH TO GRADE',findings:[{severity:'INFO',check:'Recognition',line:'—',found:'This paste does not contain enough Stirling PDF markers (for example SECURITY_ENABLELOGIN, enableUrlToPDF, or Stirling security keys) to grade honestly.',fix:'Paste a Stirling PDF settings.yml or its environment / Docker config.'}],counts:{critical:0,high:0,medium:0,low:0},lines:lines.length};
  }
  var seenLogin=false, seenDocker=false, seenDisable=false;
  lines.forEach(function(raw,idx){
    var n=idx+1, low=raw.toLowerCase(), key=keyOf(raw), val=valOf(raw), vlow=val.toLowerCase();
    // Login posture
    if(low.indexOf('enablelogin')>-1 || low.indexOf('security_enablelogin')>-1){
      seenLogin=true;
      if(isFalse(vlow)) add('CRITICAL','Login posture',n,'Key "'+key+'" is set to false — login is disabled.', 'Set login to true and require authentication before any network exposure.');
      else if(isTrue(vlow)) add('PASS','Login posture',n,'Key "'+key+'" is enabled.','Keep login on; pair it with strong credentials and HTTPS in front.');
    }
    // Initial username / password — value never rendered
    if(low.indexOf('initialusername')>-1 || low.indexOf('initial_username')>-1){
      if(isEnvRef(val)) add('PASS','Starter credentials',n,'Key "'+key+'" uses an environment reference (length '+val.length+').','Good — keep real credentials out of the file.');
      else if(['admin','stirling','user','username','example'].indexOf(vlow)>-1) add('CRITICAL','Starter credentials',n,'Key "'+key+'" (line '+n+', value length '+val.length+') matches a well-known example value. Value not shown.','Change it to a unique value supplied from a secret store, then rotate it.');
      else if(val.length>0 && val.length<4) add('HIGH','Starter credentials',n,'Key "'+key+'" (line '+n+', value length '+val.length+') is very short. Value not shown.','Use a unique, longer value from a secret store.');
      else if(val) add('MEDIUM','Starter credentials',n,'Key "'+key+'" (line '+n+', value length '+val.length+') is set in plaintext in the file. Value not shown.','Move it to an environment variable / secret reference such as ${STIRLING_ADMIN_USER}.');
    }
    if(low.indexOf('initialpassword')>-1 || low.indexOf('initial_password')>-1){
      if(isEnvRef(val)) add('PASS','Starter credentials',n,'Key "'+key+'" uses an environment reference (length '+val.length+').','Good — keep real passwords out of the file.');
      else if(['admin','password','stirling','changeme','change-me','letmein','123456'].indexOf(vlow)>-1) add('CRITICAL','Starter credentials',n,'Key "'+key+'" (line '+n+', value length '+val.length+') matches a well-known example / default value. Value not shown.','Replace it immediately with a unique secret from a secret store and rotate it.');
      else if(val.length>0 && val.length<12) add('HIGH','Starter credentials',n,'Key "'+key+'" (line '+n+', value length '+val.length+') is short (under 12 characters). Value not shown.','Use at least a long, unique generated password from a secret store.');
      else if(val) add('MEDIUM','Starter credentials',n,'Key "'+key+'" (line '+n+', value length '+val.length+') is set in plaintext. Value not shown.','Move it to an environment / secret reference.');
    }
    // OAuth http
    if((low.indexOf('oauth')>-1||low.indexOf('oidc')>-1||low.indexOf('issuer')>-1||low.indexOf('redirect')>-1||low.indexOf('callback')>-1) && val.indexOf('http://')===0 && val.indexOf('http://localhost')!==0 && val.indexOf('http://127.0.0.1')!==0){
      add('HIGH','OAuth / SSO',n,'Key "'+key+'" uses a plain http:// address — tokens and codes can be intercepted.','Use https:// for issuer, redirect and callback addresses outside localhost.');
    }
    if(low.indexOf('autocreateuser')>-1 && isTrue(vlow)) add('MEDIUM','OAuth / SSO',n,'Key "'+key+'" auto-creates users on first SSO login.','Confirm only intended identities can sign in; otherwise disable auto-creation.');
    // Docker enable security
    if(low.indexOf('docker_enable_security')>-1){
      seenDocker=true;
      if(isFalse(vlow)) add('HIGH','Endpoint restrictions',n,'DOCKER_ENABLE_SECURITY is false — built-in endpoint restrictions are off.','Set DOCKER_ENABLE_SECURITY to true unless a documented, reviewed exception applies.');
      else if(isTrue(vlow)) add('PASS','Endpoint restrictions',n,'DOCKER_ENABLE_SECURITY is true.','Keep it on.');
    }
    // URL to PDF / URL fetch
    if(low.indexOf('enableurltopdf')>-1){
      if(isTrue(vlow)) add('HIGH','URL-fetch endpoints',n,'system.enableUrlToPDF is true — the server will fetch URLs a user supplies (SSRF / internal-network risk).','Set enableUrlToPDF to false, or restrict it behind login, allowlists and network egress rules.');
      else if(isFalse(vlow)) add('PASS','URL-fetch endpoints',n,'system.enableUrlToPDF is false.','Keep it off unless a reviewed use case needs it.');
    }
    if((low.indexOf('enableexternalwebcontent')>-1||low.indexOf('allowurlfetch')>-1||low.indexOf('enableurlfetch')>-1) && isTrue(vlow)){
      add('MEDIUM','URL-fetch endpoints',n,'Key "'+key+'" is true — external web content / URL fetching is exposed.','Turn it off or restrict it with allowlists and egress controls.');
    }
    // Metrics
    if(low.trim().indexOf('metrics:')===0 || low.indexOf('metrics.enabled')>-1 || (key.toLowerCase()==='enabled' && idx>0 && lines[idx-1] && lines[idx-1].toLowerCase().indexOf('metrics')>-1)){
      // handled below via context check
    }
    if(low.indexOf('show-details')>-1 && vlow==='always') add('HIGH','Metrics / actuator',n,'Actuator health show-details is "always" — internals are disclosed to callers.','Set show-details to never (or when-authorized) and limit exposed endpoints.');
    if(low.indexOf('exposure')>-1 || (low.indexOf('include:')>-1 && (val.indexOf('*')>-1))) {
      if(val.indexOf('*')>-1) add('HIGH','Metrics / actuator',n,'Actuator exposure include is "*" — all actuator endpoints are web-exposed.','Expose only health,info (or less) and protect them.');
    }
    // Bind / port
    if((low.indexOf('address:')>-1||low.indexOf('server_address')>-1||low.indexOf('server.address')>-1) && val==='0.0.0.0'){
      add('MEDIUM','Bind / port exposure',n,'Bind address is 0.0.0.0 — the service listens on all interfaces.','Bind to 127.0.0.1 behind a reverse proxy, or firewall the port and require login + HTTPS.');
    }
    if(low.indexOf('0.0.0.0:')>-1) add('MEDIUM','Bind / port exposure',n,'A port is published on 0.0.0.0 in this line.','Publish on 127.0.0.1 where possible (for example 127.0.0.1:8080:8080) or firewall it.');
    // DISABLE_ADDITIONAL_FEATURES
    if(low.indexOf('disable_additional_features')>-1){
      seenDisable=true;
      if(isFalse(vlow)) add('MEDIUM','Extra features posture',n,'DISABLE_ADDITIONAL_FEATURES is false — optional extra features stay enabled, widening the surface.','Set it to true if you do not need the extra features.');
      else if(isTrue(vlow)) add('PASS','Extra features posture',n,'DISABLE_ADDITIONAL_FEATURES is true.','Good — smaller surface.');
    }
    // Plaintext datasource / mail passwords — key name only
    var isPw = key.toLowerCase().indexOf('password')>-1;
    var isInitial = low.indexOf('initialpassword')>-1;
    if(isPw && !isInitial && val && !isEnvRef(val)){
      // only flag in datasource/mail/spring context or explicit datasource/mail keys
      var ctx = lower.slice(0, lower.indexOf(raw.toLowerCase())); // not reliable; use key + nearby lines
      var near = lines.slice(Math.max(0,idx-4), idx+1).join(' ').toLowerCase();
      if(key.toLowerCase().indexOf('datasource')>-1 || key.toLowerCase().indexOf('mail')>-1 || key.toLowerCase().indexOf('smtp')>-1 || near.indexOf('datasource')>-1 || near.indexOf('mail')>-1 || near.indexOf('smtp')>-1){
        add('HIGH','Plaintext passwords',n,'Password key "'+key+'" (line '+n+', value length '+val.length+') is stored in plaintext. Value not shown.','Replace it with an environment / secret reference such as ${DB_PASSWORD} and rotate the exposed secret.');
      }
    }
  });
  // Metrics enabled context: metrics: block followed by enabled: true
  for(var i=0;i<lines.length;i++){
    if(lines[i].trim().toLowerCase()==='metrics:'){
      for(var j=i+1;j<Math.min(i+4,lines.length);j++){
        var vv=valOf(lines[j]);
        if(keyOf(lines[j]).toLowerCase()==='enabled'){
          if(isTrue(vv)) add('MEDIUM','Metrics / actuator',j+1,'Metrics are enabled (metrics.enabled = true).','Disable metrics or restrict the metrics/actuator endpoints to a private network.');
          else if(isFalse(vv)) add('PASS','Metrics / actuator',j+1,'Metrics are disabled.','Keep them off or restricted.');
        }
      }
    }
  }
  if(!seenLogin) add('MEDIUM','Login posture','—','No explicit enableLogin / SECURITY_ENABLELOGIN setting was found.','Set login explicitly to true — do not rely on a default you have not verified for your version.');
  if(!seenDocker) add('LOW','Endpoint restrictions','—','No DOCKER_ENABLE_SECURITY setting was found in this paste.','If you run the Docker image, set DOCKER_ENABLE_SECURITY explicitly and verify endpoint restrictions.');
  if(!seenDisable) add('LOW','Extra features posture','—','DISABLE_ADDITIONAL_FEATURES was not present in this paste.','Consider setting DISABLE_ADDITIONAL_FEATURES to true to shrink the feature surface.');
  var counts={critical:0,high:0,medium:0,low:0};
  findings.forEach(function(f){ var s=f.severity.toLowerCase(); if(counts.hasOwnProperty(s)) counts[s]++; });
  var verdict;
  if(counts.critical>0 || counts.high>=2) verdict='DO NOT DEPLOY';
  else if(counts.high===1 || counts.medium>0) verdict='DEPLOY WITH FIXES';
  else verdict='SAFE TO DEPLOY';
  return {verdict:verdict,findings:findings,counts:counts,lines:lines.length};
}

var lastResult=null, lastText='';
function esc(s){ return (''+s).replace(/&/g,'&amp;').replace(/</g,'&lt;'); }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-stirling-pdf-server-config-safety-auditortm',
  name: 'J-Dawgs Stirling PDF Server Config Safety Auditor',
  description: 'Grades a pasted Stirling PDF settings.yml / env config offline into one deploy verdict: bind exposure, plaintext secrets, and unsafe defaults caught before anything runs; secrets reported by key name, line, and length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
