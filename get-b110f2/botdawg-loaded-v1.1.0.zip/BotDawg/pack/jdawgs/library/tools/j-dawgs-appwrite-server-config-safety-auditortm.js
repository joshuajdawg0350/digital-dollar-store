'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Appwrite Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

/* ---------- Worked examples (line numbers are significant) ---------- */
var RISKY_LINES = [
  "# Risky worked example - training data only, never deploy this",
  "_APP_ENV=development",
  "_APP_OPENSSL_KEY_V1=shortkey123",
  "_APP_DOMAIN=http://203.0.113.10",
  "_APP_DOMAIN_TARGET=http://203.0.113.10",
  "_APP_OPTIONS_ABUSE=disabled",
  "_APP_CONSOLE_WHITELIST_EMAILS=",
  "_APP_CONSOLE_WHITELIST_IPS=",
  "_APP_SYSTEM_EMAIL_ADDRESS=",
  "_APP_DB_PASS=dbpass1",
  "_APP_REDIS_PASS=redis1",
  "_APP_SMTP_PASS=smtp12",
  "_APP_STORAGE_S3_SECRET=s3secret",
  "_APP_FUNCTIONS_RUNTIMES=",
  "_APP_EXECUTOR_RUNTIME_NETWORK=",
  "_APP_GRAPHQL_MAX_DEPTH=100",
  "_APP_GRAPHQL_INTROSPECTION=enabled",
  "_APP_DEBUG=true"
];
var RISKY = RISKY_LINES.join("\n");

var HARDENED_LINES = [
  "# Hardened worked example",
  "_APP_ENV=production",
  "_APP_OPENSSL_KEY_V1=a7f3k9x2m8p1q5w6e0r4t7y2u9i3o6p1a5s8d2f4g7h0j3k6",
  "_APP_DOMAIN=https://app.example.com",
  "_APP_DOMAIN_TARGET=app.example.com",
  "_APP_OPTIONS_ABUSE=enabled",
  "_APP_CONSOLE_WHITELIST_EMAILS=ops@example.com",
  "_APP_CONSOLE_WHITELIST_IPS=198.51.100.23",
  "_APP_SYSTEM_EMAIL_ADDRESS=noreply@example.com",
  "_APP_SYSTEM_EMAIL_NAME=Example App",
  "_APP_DB_HOST=db",
  "_APP_DB_PASS=Kx9mP2vL8qR4wT7yN3bH6jF1dS5aG0z",
  "_APP_REDIS_PASS=Rd8sK3nM9pQ2wX5vL7yT4bH6jF1dS0a",
  "_APP_SMTP_PASS=Sm6tP9kL2xQ8wR4vN7yB3hJ5dF1aG0z",
  "_APP_STORAGE_S3_SECRET=Zx9cV8bN7mK6jH5gF4dS3aQ2wE1rT0yU9iO8p",
  "_APP_FUNCTIONS_RUNTIMES=node-18.0,python-3.11",
  "_APP_EXECUTOR_RUNTIME_NETWORK=appwrite_runtimes",
  "_APP_USAGE_STATS=disabled",
  "_APP_GRAPHQL_MAX_DEPTH=8",
  "_APP_GRAPHQL_INTROSPECTION=disabled",
  "_APP_DEBUG=false",
  "_APP_OPTIONS_FORCE_HTTPS=enabled"
];
var HARDENED = HARDENED_LINES.join("\n");

var PROSE = "The quarterly picnic is on Friday. Bring a chair, bring a dish to share, and please remember to water the office plants while the team is out. Notes from last week are in the shared folder.";

/* ---------- Parsing ---------- */
var SECRET_KEYS = {
  "_APP_OPENSSL_KEY_V1": true,
  "_APP_DB_PASS": true,
  "_APP_REDIS_PASS": true,
  "_APP_SMTP_PASS": true,
  "_APP_STORAGE_S3_SECRET": true,
  "_APP_STORAGE_S3_KEY": true
};
var EXAMPLE_WORDS = ["example","changeme","change-me","your-","password","secret123","letmein","default","testkey","demo"];

function parseConfig(text){
  var lines = String(text || "").split(/\r?\n/);
  var entries = {};   /* key -> {value, line} */
  var order = [];
  var kvCount = 0, appCount = 0;
  for (var i = 0; i < lines.length; i++){
    var raw = lines[i];
    var s = raw.replace(/^\s+/, "").replace(/^-\s+/, "").replace(/^export\s+/, "");
    if (!s || s.charAt(0) === "#") continue;
    var eq = s.indexOf("=");
    if (eq < 1) continue;
    var key = s.slice(0, eq).trim();
    if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(key)) continue;
    var val = s.slice(eq + 1).trim();
    if ((val.charAt(0) === '"' && val.charAt(val.length-1) === '"') ||
        (val.charAt(0) === "'" && val.charAt(val.length-1) === "'")){
      val = val.slice(1, -1);
    }
    kvCount++;
    if (key.indexOf("_APP_") === 0) appCount++;
    if (!entries[key]) order.push(key);
    entries[key] = { value: val, line: i + 1 };
  }
  return { entries: entries, order: order, kvCount: kvCount, appCount: appCount, lineCount: lines.length };
}

function isIP(v){
  return /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}(:\d+)?(\/.*)?$/.test(v) || /^https?:\/\/\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/.test(v);
}
function looksExample(v){
  var low = v.toLowerCase();
  for (var i = 0; i < EXAMPLE_WORDS.length; i++){ if (low.indexOf(EXAMPLE_WORDS[i]) !== -1) return true; }
  return false;
}

/* ---------- Audit ---------- */
var SEV_RANK = { blocker: 0, high: 1, medium: 2, low: 3 };

function audit(text){
  var parsed = parseConfig(text);
  var e = parsed.entries;
  var findings = [];
  function add(sev, key, line, title, detail, fix){
    findings.push({ severity: sev, key: key, line: (typeof line === "number" ? line : null), title: title, detail: detail, fix: fix });
  }
  function get(k){ return e[k] || null; }

  /* Recognizability gate */
  if (parsed.appCount < 3){
    return {
      tool: "J-Dawgs Appwrite Server Config Safety Auditor",
      verdict: "NOT ENOUGH TO GRADE",
      recognizable: false,
      appKeyCount: parsed.appCount,
      keyValueLineCount: parsed.kvCount,
      counts: { blocker: 0, high: 0, medium: 0, low: 0, total: 0 },
      findings: [],
      summary: "This paste is not recognizably an Appwrite server configuration (fewer than 3 _APP_ keys found), so no deploy verdict can be given."
    };
  }

  /* 1. Environment */
  var env = get("_APP_ENV");
  if (!env){
    add("high","_APP_ENV",null,"Environment mode is not set","_APP_ENV is missing, so the server may fall back to a non-production default.","Set _APP_ENV=production before deploying.");
  } else if (env.value.toLowerCase() !== "production"){
    add("blocker","_APP_ENV",env.line,"Environment is not production","_APP_ENV is set to a non-production value (line " + env.line + "). Development behaviour, verbose errors, and relaxed checks can ship silently.","Set _APP_ENV=production and restart with the production configuration.");
  }

  /* 2. OpenSSL key (secret: length only) */
  var ssl = get("_APP_OPENSSL_KEY_V1");
  if (!ssl || ssl.value === ""){
    add("blocker","_APP_OPENSSL_KEY_V1", ssl ? ssl.line : null,"Encryption key is missing","_APP_OPENSSL_KEY_V1 is unset or empty. There is no encryption key protecting stored data.","Generate a long random key (32+ characters) and set _APP_OPENSSL_KEY_V1 before first boot.");
  } else if (looksExample(ssl.value)){
    add("blocker","_APP_OPENSSL_KEY_V1",ssl.line,"Encryption key looks like an example value","_APP_OPENSSL_KEY_V1 on line " + ssl.line + " (value length " + ssl.value.length + ") matches a known example/placeholder pattern. The value itself is never shown here.","Replace it with a unique, randomly generated key of 32+ characters.");
  } else if (ssl.value.length < 32){
    add("blocker","_APP_OPENSSL_KEY_V1",ssl.line,"Encryption key is too short","_APP_OPENSSL_KEY_V1 on line " + ssl.line + " has value length " + ssl.value.length + " — under the 32-character minimum for a production encryption key. The value itself is never shown here.","Generate a random key of at least 32 characters.");
  }

  /* 3. Domains */
  ["_APP_DOMAIN","_APP_DOMAIN_TARGET"].forEach(function(k){
    var d = get(k);
    if (!d || d.value === ""){
      add("medium",k, d ? d.line : null, k + " is not set", k + " is missing or empty, so the server has no proper public domain identity.","Set " + k + " to your real domain name (for example app.example.com).");
    } else if (d.value.toLowerCase().indexOf("http://") === 0){
      add("high",k,d.line,k + " uses plain http://", k + " on line " + d.line + " points at an http:// address, so console and API traffic is not protected by TLS for that identity.","Use an https domain behind a TLS-terminating proxy and set " + k + " to the domain name.");
    } else if (isIP(d.value)){
      add("high",k,d.line,k + " is a bare IP address", k + " on line " + d.line + " is a bare IP address. Certificates and cookie scoping do not work properly on bare IPs.","Point a real domain name at the server and use that domain for " + k + ".");
    }
  });

  /* 4. Abuse / rate limiting */
  var abuse = get("_APP_OPTIONS_ABUSE");
  if (!abuse || abuse.value.toLowerCase() !== "enabled"){
    add("high","_APP_OPTIONS_ABUSE", abuse ? abuse.line : null,"Abuse protection (rate limiting) is not enabled","_APP_OPTIONS_ABUSE is " + (abuse ? "not set to enabled" : "missing") + ", so built-in rate limiting is off and public endpoints can be hammered.","Set _APP_OPTIONS_ABUSE=enabled.");
  }

  /* 5. Console whitelists */
  var wEmails = get("_APP_CONSOLE_WHITELIST_EMAILS");
  var wIps = get("_APP_CONSOLE_WHITELIST_IPS");
  var emailsEmpty = !wEmails || wEmails.value === "";
  var ipsEmpty = !wIps || wIps.value === "";
  if (emailsEmpty && ipsEmpty){
    add("high","_APP_CONSOLE_WHITELIST_EMAILS", wEmails ? wEmails.line : null,"Console has no whitelist protection","Both _APP_CONSOLE_WHITELIST_EMAILS and _APP_CONSOLE_WHITELIST_IPS are empty or unset while the console is reachable. Anyone who finds the console can attempt to register or sign in.","Set _APP_CONSOLE_WHITELIST_EMAILS to your operators' email addresses and/or _APP_CONSOLE_WHITELIST_IPS to your trusted IPs.");
  } else if (emailsEmpty || ipsEmpty){
    add("low","_APP_CONSOLE_WHITELIST_EMAILS", wEmails ? wEmails.line : null,"Only one console whitelist is set","One of the console email/IP whitelists is set and the other is empty. That is a deliberate posture for some teams, but confirm it is intentional.","Confirm the single-whitelist posture is intentional, or fill in both whitelists.");
  }

  /* 6. System email */
  var sysEmail = get("_APP_SYSTEM_EMAIL_ADDRESS");
  if (!sysEmail || sysEmail.value === ""){
    add("medium","_APP_SYSTEM_EMAIL_ADDRESS", sysEmail ? sysEmail.line : null,"System email address is unset","_APP_SYSTEM_EMAIL_ADDRESS is missing or empty, so system mail (resets, alerts, notifications) has no sender identity.","Set _APP_SYSTEM_EMAIL_ADDRESS to a monitored mailbox on your domain.");
  }

  /* 7. Service secrets (length only, never values) */
  [
    ["_APP_DB_PASS","database password"],
    ["_APP_REDIS_PASS","Redis password"],
    ["_APP_SMTP_PASS","SMTP password"],
    ["_APP_STORAGE_S3_SECRET","S3 storage secret"]
  ].forEach(function(pair){
    var k = pair[0], label = pair[1];
    var s = get(k);
    if (!s || s.value === ""){
      /* Only flag S3 secret when S3 storage is in use */
      if (k === "_APP_STORAGE_S3_SECRET"){
        var driver = get("_APP_STORAGE_DEVICE");
        if (!driver || driver.value.toLowerCase().indexOf("s3") === -1) return;
      }
      add("medium",k, s ? s.line : null, label + " is not set", k + " is missing or empty. If this service is in use, it is running without a credential.","Set a long, unique value for " + k + " (16+ characters) via your secret manager or environment.");
      return;
    }
    if (looksExample(s.value)){
      add("blocker",k,s.line,label + " looks like an example value", k + " on line " + s.line + " (value length " + s.value.length + ") matches a known example/placeholder pattern. The value itself is never shown here.","Replace " + k + " with a unique random secret of 16+ characters.");
    } else if (s.value.length < 8){
      add("blocker",k,s.line,label + " is dangerously short", k + " on line " + s.line + " has value length " + s.value.length + " — far too short to resist guessing. The value itself is never shown here.","Replace " + k + " with a unique random secret of 16+ characters.");
    } else if (s.value.length < 16){
      add("high",k,s.line,label + " is short", k + " on line " + s.line + " has value length " + s.value.length + " — under the 16-character floor for a production secret. The value itself is never shown here.","Replace " + k + " with a unique random secret of 16+ characters.");
    }
  });

  /* 8. Function runtimes */
  var rt = get("_APP_FUNCTIONS_RUNTIMES");
  if (!rt || rt.value === "" || rt.value.trim() === "*"){
    add("high","_APP_FUNCTIONS_RUNTIMES", rt ? rt.line : null,"Function runtimes are unrestricted","_APP_FUNCTIONS_RUNTIMES is empty or unset, so functions are not limited to an approved list of runtime images.","Set _APP_FUNCTIONS_RUNTIMES to only the runtimes you actually use, for example node-18.0,python-3.11.");
  }

  /* 9. Executor network */
  var net = get("_APP_EXECUTOR_RUNTIME_NETWORK");
  if (!net || net.value === "" || net.value.trim() === "*" || net.value.toLowerCase() === "host"){
    add("high","_APP_EXECUTOR_RUNTIME_NETWORK", net ? net.line : null,"Executor runtime network is unrestricted","_APP_EXECUTOR_RUNTIME_NETWORK is empty, unset, or wide open, so function executors are not confined to a dedicated runtime network.","Set _APP_EXECUTOR_RUNTIME_NETWORK to a dedicated Docker network name for runtimes (for example appwrite_runtimes).");
  }

  /* 10. Usage stats posture */
  var usage = get("_APP_USAGE_STATS");
  if (!usage){
    add("low","_APP_USAGE_STATS",null,"Usage stats posture was never considered","_APP_USAGE_STATS does not appear in the config, so the telemetry/usage-stats choice was never made deliberately.","Decide on purpose: set _APP_USAGE_STATS=enabled or _APP_USAGE_STATS=disabled and record the choice.");
  }

  /* 11. GraphQL */
  var depth = get("_APP_GRAPHQL_MAX_DEPTH");
  if (depth){
    var n = parseInt(depth.value, 10);
    if (!isNaN(n) && n > 10){
      add("medium","_APP_GRAPHQL_MAX_DEPTH",depth.line,"GraphQL max depth is very high","_APP_GRAPHQL_MAX_DEPTH is set to " + n + " on line " + depth.line + ". Deep nested queries are expensive and easy to abuse.","Lower _APP_GRAPHQL_MAX_DEPTH to 10 or less unless a real client needs more.");
    }
  }
  Object.keys(e).forEach(function(k){
    if (k.indexOf("_APP_GRAPHQL") === 0 && k.toLowerCase().indexOf("introspection") !== -1){
      var v = e[k].value.toLowerCase();
      if (v === "enabled" || v === "true" || v === "1" || v === "on"){
        add("medium",k,e[k].line,"GraphQL introspection is enabled",k + " is enabled on line " + e[k].line + ", exposing your full schema to anyone who can reach the endpoint.","Disable GraphQL introspection in production, or restrict the endpoint to trusted clients.");
      }
    }
  });

  /* 12. Debug / maintenance flags */
  Object.keys(e).forEach(function(k){
    if (k.toLowerCase().indexOf("debug") !== -1){
      var v = e[k].value.toLowerCase();
      if (v === "true" || v === "1" || v === "enabled" || v === "on" || v === "yes"){
        add("high",k,e[k].line,"Debug flag is left on",k + " is switched on at line " + e[k].line + ". Debug output leaks internals and does not belong in production.","Set " + k + "=false (or remove the key) for production.");
      }
    }
  });

  findings.sort(function(a,b){
    if (SEV_RANK[a.severity] !== SEV_RANK[b.severity]) return SEV_RANK[a.severity] - SEV_RANK[b.severity];
    var la = a.line === null ? 9999 : a.line, lb = b.line === null ? 9999 : b.line;
    return la - lb;
  });

  var counts = { blocker: 0, high: 0, medium: 0, low: 0, total: findings.length };
  findings.forEach(function(f){ counts[f.severity]++; });

  var verdict, summary;
  if (counts.blocker > 0){
    verdict = "DO NOT DEPLOY";
    summary = counts.blocker + " blocker finding(s) must be fixed before this config goes anywhere near production.";
  } else if (counts.high > 0 || counts.medium > 0){
    verdict = "DEPLOY WITH FIXES";
    summary = "No blockers, but " + (counts.high + counts.medium) + " high/medium finding(s) should be fixed before or immediately after deploy.";
  } else {
    verdict = "SAFE TO DEPLOY";
    summary = "No blocker, high, or medium findings in the pasted config. This grades the pasted text only — it cannot verify the running deployment.";
  }

  return {
    tool: "J-Dawgs Appwrite Server Config Safety Auditor",
    verdict: verdict,
    recognizable: true,
    appKeyCount: parsed.appCount,
    keyValueLineCount: parsed.kvCount,
    counts: counts,
    findings: findings,
    summary: summary,
    secretHandling: "Secrets are reported by key name, line number, and value length only. Secret values never appear in this report."
  };
}

function reportToText(r){
  var out = [];
  out.push("J-Dawgs Appwrite Server Config Safety Auditor - Report");
  out.push("Verdict: " + r.verdict);
  out.push("Summary: " + r.summary);
  out.push("Recognizable Appwrite config: " + (r.recognizable ? "yes" : "no") + " (" + r.appKeyCount + " _APP_ keys, " + r.keyValueLineCount + " KEY=value lines)");
  out.push("Findings: " + r.counts.total + " total - " + r.counts.blocker + " blocker, " + r.counts.high + " high, " + r.counts.medium + " medium, " + r.counts.low + " low");
  out.push(r.secretHandling);
  out.push("");
  if (!r.findings.length){ out.push("No findings."); }
  r.findings.forEach(function(f, i){
    out.push((i+1) + ". [" + f.severity.toUpperCase() + "] " + f.key + (f.line ? " (line " + f.line + ")" : " (not present)") + " - " + f.title);
    out.push("   " + f.detail);
    out.push("   Fix: " + f.fix);
  });
  out.push("");
  out.push("Scope: this grades pasted text offline. It never connects to a server and cannot verify a running deployment.");
  return out.join("\n");
}

/* ---------- Rendering ---------- */
var currentReport = null;
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_WORDS": (typeof EXAMPLE_WORDS !== 'undefined' ? EXAMPLE_WORDS : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-appwrite-server-config-safety-auditortm',
  name: 'J-Dawgs Appwrite Server Config Safety Auditor',
  description: 'Grades a pasted Appwrite server config offline into one deploy verdict — Appwrite\'s own startup only answers will-it-start; ours grades it before the server ever runs, with secrets reported by key name, line, and length only, never the secret value.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_WORDS": __core["EXAMPLE_WORDS"] }
};
