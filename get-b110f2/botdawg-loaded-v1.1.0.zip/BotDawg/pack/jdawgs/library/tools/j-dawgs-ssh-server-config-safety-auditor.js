'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs SSH Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

/* ---------- Examples ---------- */
var RISKY_EXAMPLE = [
  "# Example sshd_config - training host, do not ship as-is",
  "Port 22",
  "Port 2222",
  "PermitRootLogin yes",
  "PasswordAuthentication yes",
  "PubkeyAuthentication yes",
  "X11Forwarding yes",
  "Ciphers aes256-ctr,aes128-ctr,arcfour128,3des-cbc",
  "Subsystem sftp /usr/lib/openssh/sftp-server"
].join("\n");

var CLEAN_EXAMPLE = [
  "# Example sshd_config - hardened host",
  "Port 22",
  "PermitRootLogin no",
  "PasswordAuthentication no",
  "PubkeyAuthentication yes",
  "AllowUsers deploy ops",
  "MaxAuthTries 3"
].join("\n");

/* ---------- Silent defaults table ----------
   def: commonly compiled default on most builds (platform-dependent).
   risky: true when that default leaves a risky posture -> forces EXPOSE WITH FIXES. */
var DEFAULTS = [
  { name:"PermitRootLogin", def:"prohibit-password", note:"Root can still log in with a key; password root login is refused.", risky:true,
    fix:"Set PermitRootLogin explicitly (no, or prohibit-password if key-based root access is truly required)." },
  { name:"PasswordAuthentication", def:"yes", note:"Password login is ON unless you turn it off - anyone who guesses a password gets in.", risky:true,
    fix:"Set PasswordAuthentication no and rely on keys, or scope it tightly with AllowUsers if passwords must stay." },
  { name:"PubkeyAuthentication", def:"yes", note:"Key-based login is available by default.", risky:false,
    fix:"Leave PubkeyAuthentication yes (the default) and make sure users actually have keys deployed." },
  { name:"PermitEmptyPasswords", def:"no", note:"Accounts with empty passwords cannot log in by default.", risky:false,
    fix:"Keep PermitEmptyPasswords no (the default)." },
  { name:"KbdInteractiveAuthentication", def:"yes (build-dependent)", note:"Keyboard-interactive / challenge-response login is usually on; on PAM systems this can still prompt for a password even when PasswordAuthentication is no. ChallengeResponseAuthentication is the older name for the same switch.", risky:false,
    fix:"If you intend key-only login, set KbdInteractiveAuthentication no as well as PasswordAuthentication no." },
  { name:"MaxAuthTries", def:"6", note:"Six password/key guesses per connection before the server cuts it off - above the 4 this audit treats as a sane ceiling.", risky:true,
    fix:"Set MaxAuthTries to 4 or lower (3 is a good default)." },
  { name:"LoginGraceTime", def:"120 seconds (2m)", note:"Unauthenticated connections get two full minutes to finish logging in, which ties up connection slots.", risky:false,
    fix:"Set LoginGraceTime to 60 or lower (30 is common on exposed hosts)." },
  { name:"X11Forwarding", def:"no", note:"X11 forwarding is off by default.", risky:false,
    fix:"Keep X11Forwarding no (the default) unless someone genuinely needs remote X11 apps." },
  { name:"AllowTcpForwarding", def:"yes", note:"Any user who can log in can also tunnel traffic and forward ports through this server by default.", risky:false,
    fix:"Set AllowTcpForwarding no, or local if only outbound-style local forwards are needed." },
  { name:"GatewayPorts", def:"no", note:"Forwarded ports bind to localhost only by default, so they are not reachable from other machines.", risky:false,
    fix:"Keep GatewayPorts no (the default) unless a forwarded port must be shared deliberately." }
];

/* Weak crypto snapshot, embedded 2026-11-04. */
var SNAPSHOT_DATE = "2026-11-04";
function weakIn(directive, token){
  var t = token.toLowerCase();
  if (t.indexOf("arcfour") !== -1) return "arcfour (broken stream cipher)";
  if (t.indexOf("blowfish") !== -1) return "blowfish (64-bit block cipher, birthday-bound)";
  if (t.indexOf("3des") !== -1) return "3des (slow, 64-bit block cipher, deprecated)";
  if (t.indexOf("md5") !== -1) return "md5 (collision-broken hash)";
  if (directive === "macs" && t.indexOf("sha1") !== -1) return "sha1 in a MAC (deprecated hash)";
  if (directive === "kexalgorithms" && (/(^|-)group1(-|_|$)/.test(t) || t.indexOf("group1-sha1") !== -1 || t.indexOf("group-exchange-sha1") !== -1 || /group14-sha1/.test(t))) return "group1 / sha1 key exchange (1024-bit MODP or sha1-based, too weak)";
  return null;
}

/* ---------- Parsing ---------- */
function parseConfig(text){
  var lines = text.split(/\r?\n/);
  var entries = [];        // {directive(lower), rawName, value, line, inMatch, matchHead}
  var includes = [];
  var inMatch = false, matchHead = "";
  var internetNote = false;
  for (var i = 0; i < lines.length; i++){
    var lineNo = i + 1;
    var raw = lines[i];
    var trimmed = raw.replace(/^\s+/, "");
    if (/^#/.test(trimmed)){
      if (/internet|public[- ]facing|exposed to the (internet|wan)/i.test(trimmed)) internetNote = true;
      continue;
    }
    if (!trimmed) continue;
    // strip inline comment (a # preceded by whitespace)
    var body = trimmed.replace(/\s+#.*$/, "");
    var m = body.match(/^([A-Za-z][A-Za-z0-9]*)\s*(?:=\s*|\s+)(.*)$/) || body.match(/^([A-Za-z][A-Za-z0-9]*)$/);
    if (!m) continue;
    var name = m[1], value = (m[2] || "").trim();
    var lower = name.toLowerCase();
    if (lower === "match"){
      if (/^all(\s|$)/i.test(value)) { inMatch = false; matchHead = ""; }
      else { inMatch = true; matchHead = "Match " + value; }
      entries.push({ directive: lower, rawName: name, value: value, line: lineNo, inMatch: false, isMatchHead: true, matchHead: matchHead });
      continue;
    }
    if (lower === "include") includes.push({ line: lineNo, value: value });
    entries.push({ directive: lower, rawName: name, value: value, line: lineNo, inMatch: inMatch, matchHead: matchHead, isMatchHead: false });
  }
  return { entries: entries, includes: includes, internetNote: internetNote, lineCount: lines.length };
}

function firstWins(entries){
  // global scope: map directive -> first entry; duplicates list
  var first = {}, dups = [];
  entries.forEach(function(e){
    if (e.inMatch || e.isMatchHead) return;
    if (!first[e.directive]) first[e.directive] = e;
    else dups.push({ directive: e.directive, firstEntry: first[e.directive], dupEntry: e });
  });
  return { first: first, dups: dups };
}

function parseGrace(v){
  // sshd time: bare seconds, or units like 2m, 1m30s, 1h
  if (/^\d+$/.test(v)) return parseInt(v, 10);
  var total = 0, re = /(\d+)\s*([smhdw])/gi, mm, any = false;
  while ((mm = re.exec(v)) !== null){
    any = true; var n = parseInt(mm[1], 10);
    var u = mm[2].toLowerCase();
    total += n * (u === "s" ? 1 : u === "m" ? 60 : u === "h" ? 3600 : u === "d" ? 86400 : 604800);
  }
  return any ? total : null;
}

function yesno(v){ var s = (v || "").toLowerCase(); return s === "yes" || s === "no" ? s : s; }

/* ---------- Audit ---------- */
function audit(text){
  var parsed = parseConfig(text);
  var fw = firstWins(parsed.entries);
  var first = fw.first;
  var findings = [];       // global
  var matchFindings = [];  // inside Match blocks
  var fixes = [];
  function add(list, sev, title, lineLabel, detail, fix){
    list.push({ sev: sev, title: title, lines: lineLabel, detail: detail, fix: fix || "" });
    if (fix && list === findings && fixes.indexOf(fix) === -1) fixes.push(fix);
  }
  function L(e){ return "Line " + e.line; }
  function get(name){ return first[name] || null; }

  /* Duplicates: first value wins — except the accumulating directives (Port, ListenAddress, HostKey) */
  var CUMULATIVE = { port: true, listenaddress: true, hostkey: true };
  fw.dups.forEach(function(d){
    if (CUMULATIVE[d.directive]){
      add(findings, "warning",
        d.firstEntry.rawName + " written more than once — this directive accumulates, so BOTH values are live",
        "Lines " + d.firstEntry.line + " and " + d.dupEntry.line,
        "The first-value-wins rule has named exceptions: " + d.firstEntry.rawName + " accumulates instead of overwriting. Line " +
        d.firstEntry.line + " (" + d.firstEntry.rawName + " " + d.firstEntry.value + ") and line " + d.dupEntry.line +
        " (" + d.dupEntry.rawName + " " + d.dupEntry.value + ") BOTH take effect — for Port that means the server listens on both ports, and every extra listening port is extra exposure.",
        "Remove the " + d.dupEntry.rawName + " line " + d.dupEntry.line + " if that value (port " + d.dupEntry.value + ") should not be live.");
      return;
    }
    add(findings, "warning",
      "Duplicate directive: " + d.firstEntry.rawName + " — first value wins",
      "Lines " + d.firstEntry.line + " and " + d.dupEntry.line,
      "sshd uses the FIRST value it reads, unlike most config files. Line " + d.firstEntry.line +
      " (" + d.firstEntry.rawName + " " + d.firstEntry.value + ") is the one that actually takes effect; line " +
      d.dupEntry.line + " (" + d.dupEntry.rawName + " " + d.dupEntry.value + ") is silently ignored.",
      "Delete the ignored duplicate on line " + d.dupEntry.line + " so the file says what the server does.");
  });

  /* Include directives: not followed */
  parsed.includes.forEach(function(inc){
    var inM = parsed.entries.some(function(e){ return e.line === inc.line && e.inMatch; });
    add(inM ? matchFindings : findings, "info",
      "Include not followed: " + inc.value,
      "Line " + inc.line,
      "This audit reads only the pasted text. Settings in the included file(s) are NOT FOLLOWED and are not audited — they can change the effective configuration.",
      "Paste the included file's contents in as well if you want them audited.");
  });

  /* --- Authentication posture --- */
  var root = get("permitrootlogin");
  var rootVal = root ? root.value.toLowerCase() : null;
  var pw = get("passwordauthentication");
  var pwVal = pw ? pw.value.toLowerCase() : null;
  var pwEffective = pw ? pwVal : "yes"; // silent default
  var pub = get("pubkeyauthentication");
  var pubVal = pub ? pub.value.toLowerCase() : null;

  if (root){
    if (rootVal === "yes"){
      add(findings, "blocker", "PermitRootLogin yes — root can log in directly", L(root),
        "Anyone who reaches this server can attack the root account itself, with no need to compromise a normal user first.",
        "Set PermitRootLogin no. Log in as a normal user and use sudo.");
    } else if (rootVal === "prohibit-password" || rootVal === "without-password"){
      add(findings, "warning", "PermitRootLogin " + root.value + " — root login allowed with a key only", L(root),
        "Password root login is refused, but root can still log in directly with a key. That is safer than yes, but a stolen root key is instant full control with no sudo step in between.",
        "Prefer PermitRootLogin no; use prohibit-password only if a key-only root workflow genuinely requires it.");
    } else if (rootVal === "forced-commands-only"){
      add(findings, "info", "PermitRootLogin forced-commands-only — root key restricted to a forced command", L(root),
        "Root keys can only run the command forced in authorized_keys (typical for backup accounts). Graded low, but the forced command becomes the whole security boundary.",
        "Keep forced-commands-only only for single-purpose keys, and audit what the forced command can do.");
    } else if (rootVal === "no"){
      add(findings, "ok", "PermitRootLogin no — direct root login is off", L(root), "Root must be reached through a normal account and sudo.", "");
    }
  }

  if (pw){
    if (pwVal === "yes"){
      var esc = (rootVal === "yes") || parsed.internetNote;
      if (esc){
        var why = rootVal === "yes" ? "combined with PermitRootLogin yes, an attacker can brute-force the root password itself"
                                    : "and this config is noted as internet-facing, so the password prompt is reachable by the whole internet";
        add(findings, "blocker", "PasswordAuthentication yes — ESCALATED: " + why, L(pw),
          "Password login is on, " + why + ". This combination is the single most common way exposed SSH servers get taken over.",
          "Set PasswordAuthentication no and use keys; if passwords must stay temporarily, at minimum set PermitRootLogin no and restrict AllowUsers.");
      } else {
        add(findings, "warning", "PasswordAuthentication yes — password login is on", L(pw),
          "Anyone who guesses or phishes a password gets a shell. Passwords are the weakest credential SSH offers.",
          "Set PasswordAuthentication no and deploy keys; if passwords must stay, scope with AllowUsers and lower MaxAuthTries.");
      }
    } else if (pwVal === "no"){
      add(findings, "ok", "PasswordAuthentication no — password login is off", L(pw), "Only key-based (or other configured) authentication can succeed.", "");
    }
  }

  var empty = get("permitemptypasswords");
  if (empty && empty.value.toLowerCase() === "yes"){
    add(findings, "blocker", "PermitEmptyPasswords yes — empty-password accounts can log in", L(empty),
      "Any account with no password set can be logged into with no credential at all (this only bites while password-style authentication is enabled, but that is exactly when it is catastrophic).",
      "Set PermitEmptyPasswords no and give every account a real password or key.");
  }

  // KbdInteractive / ChallengeResponse alongside passwords
  var kbd = get("kbdinteractiveauthentication") || get("challengeresponseauthentication");
  if (kbd && kbd.value.toLowerCase() === "yes"){
    if (pwEffective === "yes"){
      add(findings, "warning", kbd.rawName + " yes alongside password authentication", L(kbd),
        "Keyboard-interactive (challenge-response) authentication is enabled at the same time as password authentication. On PAM systems it usually prompts for the same password through a second door — turning off one prompt does not close the other.",
        "If you want key-only login, set both PasswordAuthentication no and " + kbd.rawName + " no.");
    } else {
      add(findings, "info", kbd.rawName + " yes while PasswordAuthentication is no", L(kbd),
        "PasswordAuthentication is off, but keyboard-interactive is still on — on PAM systems this can still prompt for a password. Named here so the 'passwords off' claim is honest.",
        "Set " + kbd.rawName + " no as well if no password-style prompt should ever appear.");
    }
  }

  if (pub){
    if (pubVal === "no"){
      if (pwEffective !== "yes"){
        add(findings, "blocker", "PubkeyAuthentication no and passwords also off — no strong authentication left", L(pub),
          "Contradiction: key authentication is disabled and password authentication is also off (set to no or defaulted off in your intent), so there is no strong way left to log in. Either nobody can get in, or login falls back to whatever weaker method remains.",
          "Set PubkeyAuthentication yes and deploy keys; that is the strong method this server should rely on.");
      } else {
        add(findings, "warning", "PubkeyAuthentication no — key login disabled, passwords are the only door", L(pub),
          "The strongest SSH authentication method is switched off while password login remains on.",
          "Set PubkeyAuthentication yes, deploy keys, then turn PasswordAuthentication off.");
      }
    } else if (pubVal === "yes"){
      add(findings, "ok", "PubkeyAuthentication yes — key login is available", L(pub), "Users can authenticate with key pairs.", "");
    }
  }

  /* --- Absent posture-critical directives: the default decides, so the absence is graded --- */
  if (!root){
    add(findings, "warning", "PermitRootLogin not written — the compiled default decides (prohibit-password on most builds)", "No line — directive absent",
      "Root's login posture becomes whatever this build of sshd ships with: prohibit-password on most builds, but platform-dependent and never certain. A config that says nothing about root has not actually made a decision about root.",
      "Write PermitRootLogin explicitly — no, unless a key-only root workflow genuinely requires prohibit-password.");
  }
  if (!pw){
    add(findings, "warning", "PasswordAuthentication not written — defaults to yes on most builds", "No line — directive absent",
      "Silence here means password login is ON: the commonly compiled default is yes, so anyone who guesses a password gets in and nothing in this file says otherwise.",
      "Write PasswordAuthentication no explicitly and rely on keys; if passwords must stay, scope them with AllowUsers.");
  }

  /* --- Access scoping --- */
  var allowU = get("allowusers"), allowG = get("allowgroups");
  if (pwEffective === "yes" && !allowU && !allowG){
    add(findings, "warning", "No AllowUsers / AllowGroups while password login is enabled", pw ? L(pw) : "No line — directive absent",
      "Every account on the machine is a valid target for password guessing. Scoping the server to named users shrinks the attack surface to just those accounts.",
      "Add AllowUsers naming only the people who need SSH access (or AllowGroups with a dedicated ssh group).");
  }
  [allowU, allowG].forEach(function(a){
    if (a && /[\*\?]/.test(a.value)){
      add(findings, "warning", a.rawName + " contains a wildcard pattern: " + a.value, L(a),
        "Wildcards (* and ?) in allow lists widen access beyond the named accounts you probably intended — a future account matching the pattern gets SSH access automatically.",
        "List exact usernames/groups in " + a.rawName + " instead of patterns.");
    }
  });

  var mat = get("maxauthtries");
  if (!mat){
    add(findings, "warning", "MaxAuthTries not written — the default of 6 is above the sane ceiling of 4", "No line — directive absent",
      "With nothing written, each connection gets 6 authentication attempts (the commonly compiled default) before the server hangs up, multiplying how fast passwords can be guessed across many connections.",
      "Set MaxAuthTries to 4 or lower (3 is a good default).");
  }
  if (mat){
    var n = parseInt(mat.value, 10);
    if (!isNaN(n) && n > 4){
      add(findings, "warning", "MaxAuthTries " + n + " — more than 4 guesses per connection", L(mat),
        "Each connection gets " + n + " authentication attempts before the server hangs up, multiplying how fast passwords can be guessed across many connections.",
        "Set MaxAuthTries to 4 or lower (3 is a good default).");
    } else if (!isNaN(n)){
      add(findings, "ok", "MaxAuthTries " + n + " — within the sane ceiling of 4", L(mat), "Few guesses per connection before disconnect.", "");
    }
  }

  var lgt = get("logingracetime");
  if (!lgt){
    add(findings, "info", "LoginGraceTime not written — the default of 120 seconds applies", "No line — directive absent",
      "Unauthenticated connections get the full two minutes (the commonly compiled default) to finish logging in. That sits at the ceiling this audit allows, but on an exposed host it is worth choosing deliberately rather than inheriting.",
      "Consider LoginGraceTime 60 or lower (30 is common on exposed hosts).");
  }
  if (lgt){
    var secs = parseGrace(lgt.value);
    if (secs !== null && secs > 120){
      add(findings, "warning", "LoginGraceTime " + lgt.value + " (" + secs + "s) — over 120 seconds", L(lgt),
        "Unauthenticated connections may linger for " + secs + " seconds, so slow or half-open login attempts can pile up and exhaust connection slots.",
        "Set LoginGraceTime to 60 or lower (30 is common on exposed hosts). 0 means unlimited — never use it on an exposed server.");
    } else if (secs === 0){
      add(findings, "warning", "LoginGraceTime 0 — unlimited login time", L(lgt),
        "Zero disables the grace timer entirely: unauthenticated connections never time out.",
        "Set LoginGraceTime to a finite value, 30–60 seconds.");
    } else if (secs !== null){
      add(findings, "ok", "LoginGraceTime " + lgt.value + " (" + secs + "s) — at or under 120 seconds", L(lgt), "Unauthenticated connections are cut off promptly.", "");
    }
  }

  var x11 = get("x11forwarding");
  if (x11 && x11.value.toLowerCase() === "yes"){
    add(findings, "warning", "X11Forwarding yes — remote X11 apps can reach back to the user's display", L(x11),
      "X11 forwarding lets a session on this server interact with the connecting user's local display and input. A compromised server can abuse that trust, and almost no server workload actually needs it.",
      "Set X11Forwarding no unless a named user genuinely runs remote X11 applications.");
  }

  var tcp = get("allowtcpforwarding");
  if (tcp){
    var tv = tcp.value.toLowerCase();
    if (tv === "yes" || tv === "all"){
      add(findings, "warning", "AllowTcpForwarding " + tcp.value + " — full port forwarding / tunnelling", L(tcp),
        "Any user who can log in can use this server as a tunnel — both local forwards (reaching internal machines from outside) and remote forwards. That is much wider exposure than a shell alone.",
        "Set AllowTcpForwarding no, or local if only local forwards are needed.");
    } else if (tv === "local"){
      add(findings, "info", "AllowTcpForwarding local — local forwards only (narrower)", L(tcp),
        "Users can forward ports from their own machine through this server (local forwarding), but cannot open listening ports on the server for others (remote forwarding). Narrower than yes, wider than no.",
        "Keep local only if users need to reach internal services through this host; otherwise set no.");
    } else if (tv === "remote"){
      add(findings, "info", "AllowTcpForwarding remote — remote forwards only", L(tcp),
        "Users can make the server listen on a port and forward it back to them, but cannot tunnel out to internal machines. Combined with GatewayPorts this can publish an internal service.",
        "Keep remote only for a deliberate, named need; otherwise set no.");
    } else if (tv === "no"){
      add(findings, "ok", "AllowTcpForwarding no — no tunnelling through this server", L(tcp), "SSH is a shell service here, not a network pivot.", "");
    }
  }

  var gw = get("gatewayports");
  if (gw){
    var gv = gw.value.toLowerCase();
    if (gv === "yes"){
      add(findings, "warning", "GatewayPorts yes — forwarded ports are reachable from other machines", L(gw),
        "With GatewayPorts no, a remote forward listens only on localhost — reachable only from the server itself. With yes, it binds all interfaces: anyone on the network (or internet) can connect to the forwarded port, publishing whatever sits behind it.",
        "Set GatewayPorts no unless a forwarded port must deliberately be shared.");
    } else if (gv === "clientspecified"){
      add(findings, "warning", "GatewayPorts clientspecified — each client chooses its bind address", L(gw),
        "The connecting client decides whether its forwarded port stays on localhost or opens to all interfaces. That hands the exposure decision to whoever connects, which is effectively yes for any user who wants it.",
        "Set GatewayPorts no so the server, not the client, decides.");
    } else if (gv === "no"){
      add(findings, "ok", "GatewayPorts no — forwarded ports stay on localhost", L(gw), "Remote forwards are not reachable from other machines.", "");
    }
  }

  /* --- Cryptography posture --- */
  var cryptoNames = ["ciphers", "macs", "kexalgorithms"];
  var anyCrypto = false;
  cryptoNames.forEach(function(cn){
    var e = get(cn); if (!e) return; anyCrypto = true;
    e.value.split(",").forEach(function(tok){
      var t = tok.trim(); if (!t) return;
      if (/^[-+]/.test(t)){
        if (t.charAt(0) === "-") return; // removal of an algorithm = good
        t = t.slice(1);
      }
      var w = weakIn(cn, t);
      if (w){
        add(findings, "warning", "Weak cryptography in " + e.rawName + ": " + t, L(e),
          "This entry names " + w + ". Weak algorithms let a network attacker downgrade or attack the session encryption. (Snapshot date " + SNAPSHOT_DATE + "; this audit cannot check a live server's negotiated set.)",
          "Remove " + t + " from " + e.rawName + " and keep a modern list (for example chacha20-poly1305 / aes-gcm ciphers, hmac-sha2 MACs, curve25519 / group14+ key exchange).");
      }
    });
  });
  if (!anyCrypto){
    add(findings, "info", "No Ciphers / MACs / KexAlgorithms lines — server default set, NOT GRADED offline",
      "No line — directives absent",
      "With none of the three directives written, sshd uses its compiled-in default algorithm set. That set may be perfectly modern or may include older algorithms depending on the build, and a pasted file cannot tell us which — so it is reported honestly as not graded. (Snapshot date " + SNAPSHOT_DATE + "; this audit cannot check a live server's negotiated set.)",
      "Optionally pin explicit modern Ciphers, MACs and KexAlgorithms lists so the posture is reviewable in the file itself.");
  }

  /* --- Match blocks: graded separately --- */
  var matchEntries = parsed.entries.filter(function(e){ return e.inMatch; });
  var currentHead = "";
  matchEntries.forEach(function(e){
    if (e.matchHead !== currentHead){
      currentHead = e.matchHead;
      add(matchFindings, "info", "Inside: " + currentHead, "Applies only when the Match condition is true",
        "Findings under this heading are graded on their own and never merged into the global verdict counts. The condition itself is not evaluated against real users or hosts.", "");
    }
    var v = e.value.toLowerCase();
    if (e.directive === "permitrootlogin" && v === "yes")
      add(matchFindings, "blocker", "PermitRootLogin yes (in Match block)", L(e), "For connections matching this block, root login is fully allowed.", "Set PermitRootLogin no inside this Match block too.");
    else if (e.directive === "passwordauthentication" && v === "yes")
      add(matchFindings, "warning", "PasswordAuthentication yes (in Match block)", L(e), "For connections matching this block, password login is on even if the global section turns it off — Match blocks override the global value for matching connections.", "Set PasswordAuthentication no inside this Match block, or narrow the Match condition.");
    else if (e.directive === "permitemptypasswords" && v === "yes")
      add(matchFindings, "blocker", "PermitEmptyPasswords yes (in Match block)", L(e), "For matching connections, empty-password accounts can log in.", "Set PermitEmptyPasswords no inside this Match block.");
    else if (e.directive === "x11forwarding" && v === "yes")
      add(matchFindings, "warning", "X11Forwarding yes (in Match block)", L(e), "For matching connections, X11 forwarding is enabled.", "Set X11Forwarding no inside this Match block unless needed.");
    else if (e.directive === "allowtcpforwarding" && (v === "yes" || v === "all"))
      add(matchFindings, "warning", "AllowTcpForwarding " + e.value + " (in Match block)", L(e), "For matching connections, full tunnelling through this server is allowed.", "Restrict AllowTcpForwarding inside this Match block.");
    else
      add(matchFindings, "info", e.rawName + " " + e.value + " (in Match block)", L(e), "Scoped setting: applies only to connections matching the block above. Not counted in the global verdict.", "");
  });

  /* --- Silent defaults --- */
  var present = {};
  Object.keys(first).forEach(function(k){ present[k] = true; });
  present["challengeresponseauthentication"] = present["kbdinteractiveauthentication"] || present["challengeresponseauthentication"];
  var silent = DEFAULTS.filter(function(d){ return !present[d.name.toLowerCase()]; })
    .map(function(d){ return { name: d.name, def: d.def, note: d.note, risky: d.risky, fix: d.fix }; });

  /* --- Verdict --- */
  var counts = { blocker: 0, warning: 0, info: 0, ok: 0 };
  findings.forEach(function(f){ counts[f.sev]++; });
  var mCounts = { blocker: 0, warning: 0, info: 0, ok: 0 };
  matchFindings.forEach(function(f){ mCounts[f.sev]++; });
  var riskySilent = silent.filter(function(s){ return s.risky; });
  var verdict, vclass;
  if (counts.blocker > 0){ verdict = "DO NOT EXPOSE"; vclass = "do-not"; }
  else if (counts.warning > 0){ verdict = "EXPOSE WITH FIXES"; vclass = "with-fixes"; }
  else { verdict = "SAFE TO EXPOSE"; vclass = "safe"; }

  silent.forEach(function(s){ if (s.risky && s.fix && fixes.indexOf(s.fix) === -1) fixes.push(s.fix); });

  return { findings: findings, matchFindings: matchFindings, silent: silent, riskySilent: riskySilent,
           counts: counts, mCounts: mCounts, verdict: verdict, vclass: vclass, fixes: fixes };
}

/* ---------- Rendering ---------- */
function esc(s){ return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"); }
function sevLabel(s){ return s === "ok" ? "OK" : s.toUpperCase(); }

function findingHTML(f){
  return '<div class="finding ' + f.sev + '"><span class="sev ' + f.sev + '">' + sevLabel(f.sev) + '</span>' +
    '<span class="ftitle">' + esc(f.title) + '</span> <span class="lines">· ' + esc(f.lines) + '</span>' +
    '<p>' + esc(f.detail) + '</p>' + (f.fix ? '<p class="fix">' + esc(f.fix) + '</p>' : '') + '</div>';
}

function buildReport(r, lineCount){
  var out = [];
  out.push("J-Dawgs SSH Server Config Safety Auditor - audit report");
  out.push("Verdict: " + r.verdict);
  out.push("Global counts: " + r.counts.blocker + " BLOCKER, " + r.counts.warning + " WARNING, " + r.counts.info + " INFO, " + r.counts.ok + " OK (Match-block findings counted separately)");
  out.push("Lines audited: " + lineCount);
  out.push("");
  out.push("== FINDINGS (global) ==");
  if (!r.findings.length) out.push("(none)");
  r.findings.forEach(function(f){ out.push("[" + sevLabel(f.sev) + "] " + f.title + " (" + f.lines + ")"); out.push("  " + f.detail); if (f.fix) out.push("  Fix: " + f.fix); });
  out.push("");
  out.push("== SILENT DEFAULTS (directives absent - the server uses these anyway; commonly compiled defaults, platform-dependent) ==");
  if (!r.silent.length) out.push("(none - every tracked directive is written explicitly)");
  r.silent.forEach(function(s){ out.push("- " + s.name + " absent = " + s.def + ". " + s.note + (s.risky ? " [RISKY DEFAULT]" : "")); });
  out.push("");
  out.push("== MATCH BLOCK FINDINGS (graded separately, not in the verdict counts) ==");
  if (!r.matchFindings.length) out.push("(no Match blocks)");
  r.matchFindings.forEach(function(f){ out.push("[" + sevLabel(f.sev) + "] " + f.title + " (" + f.lines + ")"); out.push("  " + f.detail); if (f.fix) out.push("  Fix: " + f.fix); });
  out.push("");
  out.push("== FIX LIST ==");
  if (!r.fixes.length) out.push("(nothing to fix)");
  r.fixes.forEach(function(fx, i){ out.push((i + 1) + ". " + fx); });
  out.push("");
  out.push("Limits: heuristic text audit of a pasted file. Never connects to a server, never runs sshd -T, Include directives are NOT FOLLOWED, Match conditions are not evaluated against real users/hosts. Weak-crypto snapshot date " + SNAPSHOT_DATE + "; a live server's negotiated set cannot be checked offline.");
  out.push("(c) 2026 Joshua Dawson - J-Dawgs SSH Server Config Safety Auditor");
  return out.join("\n");
}
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "CLEAN_EXAMPLE": (typeof CLEAN_EXAMPLE !== 'undefined' ? CLEAN_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-ssh-server-config-safety-auditor',
  name: 'J-Dawgs SSH Server Config Safety Auditor',
  description: 'sshd -T and online checkers need the live server and stop at per-directive validity; ours audits a pasted sshd_config anywhere, makes the silent defaults explicit, applies the first-value-wins rule, and returns one exposure verdict (SAFE TO EXPOSE / EXPOSE WITH FIXES / DO NOT EXPOSE).',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "CLEAN_EXAMPLE": __core["CLEAN_EXAMPLE"] }
};
