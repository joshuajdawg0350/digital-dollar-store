'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Fail2ban Jail Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

    'use strict';
    /* ============================================================
       AUDIT CORE — pure text-in / findings-out. No DOM access here.
       ============================================================ */
    var KNOWN_KEYS = {};
    ('enabled port filter action logpath backend maxretry findtime bantime ' +
     'ignoreip ignorecommand banaction banaction_allports destemail sender sendername mta ' +
     'protocol chain usedns mode journalmatch datepattern failregex ignoreregex prefregex ' +
     'agent socket pidfile dbfile dbpurgeage loglevel logtarget syslogsocket allowipv6 ' +
     'bantime.increment bantime.factor bantime.multipliers bantime.maxtime bantime.rndtime ' +
     'bantime.overalljails ignorecache _daemon blocktype returntype lockingopt'
    ).split(' ').forEach(function (k) { KNOWN_KEYS[k] = true; });

    var SECRET_KEY_RE = /(pass(word|wd)?|pwd|token|secret|api[-_]?key|access[-_]?key|private[-_]?key|credential|auth)/i;
    var STRIP_COMMENT_KEYS = {};
    ('bantime findtime maxretry port backend enabled banaction filter ignoreip destemail sender usedns protocol mode chain mta').split(' ')
      .forEach(function (k) { STRIP_COMMENT_KEYS[k] = true; });
    var BAN_ACTION_TOKENS = ['iptables', 'firewallcmd', 'nftables', 'shorewall', 'hostsdeny', 'ipfw', 'ufw', 'cloudflare', 'route', 'dummy', 'pf'];

    function isDefaultName(name) { return name.toUpperCase() === 'DEFAULT'; }
    function isDefinitionName(name) { return name.toUpperCase() === 'DEFINITION'; }
    function truthy(v) { return /^(true|yes|on|1)$/i.test(String(v).trim()); }

    function cleanValue(key, value) {
      var v = String(value);
      if (STRIP_COMMENT_KEYS[key.toLowerCase()]) {
        v = v.replace(/\s+[#;].*$/, '');
      }
      return v.trim();
    }

    /* Parse fail2ban-style seconds: "600", "10m", "1h30m", "1d", "-1". Returns seconds or null. */
    function parseDuration(raw) {
      if (raw === null || raw === undefined) return null;
      var v = String(raw).trim().toLowerCase();
      if (v === '') return null;
      if (v === '-1') return -1;
      if (/^\d+$/.test(v)) return parseInt(v, 10);
      var units = { s: 1, sec: 1, secs: 1, second: 1, seconds: 1,
                    m: 60, min: 60, mins: 60, minute: 60, minutes: 60,
                    h: 3600, hr: 3600, hour: 3600, hours: 3600,
                    d: 86400, day: 86400, days: 86400,
                    w: 604800, week: 604800, weeks: 604800,
                    mo: 2592000, month: 2592000, months: 2592000,
                    y: 31536000, year: 31536000, years: 31536000 };
      var re = /(\d+)\s*(seconds|second|secs|sec|s|minutes|minute|mins|min|m|hours|hour|hr|h|days|day|d|weeks|week|w|months|month|mo|years|year|y)/g;
      var total = 0, matched = '', m;
      while ((m = re.exec(v)) !== null) { total += parseInt(m[1], 10) * units[m[2]]; matched += m[0]; }
      if (matched.replace(/\s+/g, '') !== v.replace(/\s+/g, '')) return null;
      return total;
    }

    function parseConfig(text) {
      var lines = String(text).split(/\r\n|\r|\n/);
      var sections = [];
      var outsideKeys = [];
      var current = null;
      var lastEntry = null;
      lines.forEach(function (raw, idx) {
        var lineNo = idx + 1;
        var t = raw.trim();
        if (t === '') { lastEntry = null; return; }
        if (t.charAt(0) === '#' || t.charAt(0) === ';') { lastEntry = null; return; }
        var sm = t.match(/^\[([^\]]+)\]\s*(?:[#;].*)?$/);
        if (sm) {
          current = { name: sm[1].trim(), line: lineNo, entries: [] };
          sections.push(current);
          lastEntry = null;
          return;
        }
        var km = t.match(/^([A-Za-z0-9_.\-]+)\s*=\s*(.*)$/) || t.match(/^([A-Za-z0-9_.\-]+)\s*:\s+(.*)$/);
        if (km) {
          var entry = { key: km[1], value: km[2].trim(), line: lineNo };
          if (current) { current.entries.push(entry); } else { outsideKeys.push(entry); }
          lastEntry = entry;
          return;
        }
        if (lastEntry) { lastEntry.value = (lastEntry.value + ' ' + t).trim(); }
      });
      return { sections: sections, outsideKeys: outsideKeys };
    }

    /* Resolve effective settings for one jail: [DEFAULT] first, then each
       instance of the jail in file order — later entries win per key. */
    function resolveFor(parsed, jailName) {
      var map = {};
      function apply(sec) {
        sec.entries.forEach(function (e) {
          map[e.key.toLowerCase()] = { key: e.key, value: e.value, line: e.line };
        });
      }
      parsed.sections.forEach(function (s) { if (isDefaultName(s.name)) apply(s); });
      if (jailName !== null) {
        parsed.sections.forEach(function (s) { if (s.name === jailName) apply(s); });
      }
      return map;
    }
    function getE(map, key) { return map[key.toLowerCase()] || null; }
    function getV(map, key) {
      var e = getE(map, key);
      return e ? cleanValue(key, e.value) : null;
    }

    function auditConfig(text) {
      var findings = [];
      function add(sev, line, jail, msg) {
        findings.push({ sev: sev, line: line || 0, jail: jail || '', msg: msg });
      }

      var parsed = parseConfig(text);

      if (parsed.outsideKeys.length) {
        add('NOTE', parsed.outsideKeys[0].line, '',
          parsed.outsideKeys.length + ' key line(s) appear before any [section] header (first at line ' +
          parsed.outsideKeys[0].line + '). Fail2ban assigns keys to the section above them, so these belong to no jail and set nothing.');
      }

      if (!parsed.sections.length) {
        add('BLOCKER', 0, '', 'No [section] headers were found. The pasted text does not look like a Fail2ban jail file, so there is nothing here that could be enabled safely.');
        return finish(findings, 0);
      }

      /* Duplicate sections */
      var seenNames = {};
      parsed.sections.forEach(function (s) {
        if (!seenNames[s.name]) seenNames[s.name] = [];
        seenNames[s.name].push(s.line);
      });
      Object.keys(seenNames).forEach(function (name) {
        var ls = seenNames[name];
        if (ls.length > 1) {
          add('WARNING', ls[0], name,
            'Section [' + name + '] is defined ' + ls.length + ' times (lines ' + ls.join(' and ') +
            '). Where the copies repeat a key, the last definition wins — the copy you are not looking at may be the one that takes effect.');
        }
      });

      /* Secret-shaped keys + unknown keys: scanned in every section, enabled or not. */
      var unknownSeen = {};
      parsed.sections.forEach(function (s) {
        s.entries.forEach(function (e) {
          var lk = e.key.toLowerCase();
          if (SECRET_KEY_RE.test(e.key)) {
            add('WARNING', e.line, s.name,
              'Secret-shaped key "' + e.key + '" in [' + s.name + '] (line ' + e.line +
              '): a credential appears to be stored in this jail file. Jail files get copied into tickets, chats, and repos — move the secret to a root-only file or environment variable. (Its value is never shown in this report.)');
          } else if (!KNOWN_KEYS[lk]) {
            var uk = s.name + '|' + lk;
            if (!unknownSeen[uk]) {
              unknownSeen[uk] = true;
              add('NOT AUDITED', e.line, s.name,
                'Key "' + e.key + '" in [' + s.name + '] (line ' + e.line +
                ') is not a key this auditor recognizes. It is reported NOT AUDITED: its effect was not checked and is not guessed at. It may be an action-specific parameter, a local convention, or a typo.');
            }
          }
        });
      });

      /* Jail names in file order */
      var jailNames = [];
      parsed.sections.forEach(function (s) {
        if (!isDefaultName(s.name) && !isDefinitionName(s.name) && jailNames.indexOf(s.name) === -1) {
          jailNames.push(s.name);
        }
      });
      if (!jailNames.length) {
        add('BLOCKER', 0, '', 'The file defines no jail sections — a [DEFAULT] block (or a [Definition] block) alone enables nothing. There is no jail here to call safe.');
        return finish(findings, 0);
      }

      var enabledJails = 0;
      var mailActionUsed = false;
      var destEntry = null;
      var senderPresent = false;

      jailNames.forEach(function (name) {
        var firstLine = 0;
        parsed.sections.forEach(function (s) { if (s.name === name && !firstLine) firstLine = s.line; });
        var map = resolveFor(parsed, name);
        var enabledE = getE(map, 'enabled');
        var enabled = enabledE ? truthy(getV(map, 'enabled')) : false;

        var de = getE(map, 'destemail');
        if (de && getV(map, 'destemail') && !destEntry) destEntry = de;
        if (getV(map, 'sender')) senderPresent = true;

        if (!enabled) {
          add('NOTE', firstLine, name,
            'Jail [' + name + '] is not enabled (no enabled = true in the jail or in [DEFAULT]), so it was not audited as a live jail. Its keys were still scanned for secrets, duplicates, and unrecognized keys.');
          return;
        }
        enabledJails++;

        var actionV = getV(map, 'action');
        if (actionV && /(action_mw|sendmail|mail)/i.test(actionV)) mailActionUsed = true;

        /* --- filter --- */
        var filterE = getE(map, 'filter');
        if (!filterE) {
          add('BLOCKER', firstLine, name,
            'Jail [' + name + '] is enabled but names no filter (section starts line ' + firstLine +
            '). With no filter, Fail2ban has no log pattern to watch — the jail protects nothing.');
        } else if (!getV(map, 'filter')) {
          add('BLOCKER', filterE.line, name,
            'Jail [' + name + '] has a filter key at line ' + filterE.line + ' but its value is empty. An empty filter matches nothing — the jail protects nothing.');
        }

        /* --- action / banaction --- */
        var banactionV = getV(map, 'banaction');
        var actionLine = firstLine;
        var actionE = getE(map, 'action');
        if (actionE) actionLine = actionE.line;
        if (!actionV) {
          if (banactionV) {
            add('NOTE', firstLine, name,
              'Jail [' + name + '] names no action of its own; the standard ban action for banaction "' + banactionV +
              '" applies. That is workable, but naming the action explicitly leaves less to chance.');
          } else {
            add('BLOCKER', firstLine, name,
              'Jail [' + name + '] is enabled but names no action and no banaction (section starts line ' + firstLine +
              '). Nothing in this file would actually ban an attacker.');
          }
        } else if (!banactionV) {
          var embeds = BAN_ACTION_TOKENS.some(function (tok) { return actionV.toLowerCase().indexOf(tok) !== -1; });
          if (!embeds) {
            add('WARNING', actionLine, name,
              'Jail [' + name + '] sets no banaction. The action in use ("' + actionV + '", line ' + actionLine +
              ') defers the actual ban mechanism to whatever the shipped defaults resolve to. Name banaction explicitly so the ban method is the one you chose.');
          }
        }
        if (actionV && banactionV === null && !actionE) { /* unreachable guard */ }

        /* --- bantime / findtime / maxretry math --- */
        var btE = getE(map, 'bantime'), ftE = getE(map, 'findtime'), mrE = getE(map, 'maxretry');
        var bt = btE ? parseDuration(getV(map, 'bantime')) : null;
        var ft = ftE ? parseDuration(getV(map, 'findtime')) : null;
        var mr = mrE ? parseInt(getV(map, 'maxretry'), 10) : null;
        if (mrE && (isNaN(mr) || String(getV(map, 'maxretry')).trim() === '')) {
          add('NOTE', mrE.line, name, 'Jail [' + name + ']: maxretry value at line ' + mrE.line + ' could not be read as a number, so the ban-pressure math for it is NOT AUDITED.');
          mr = null;
        }
        if (btE && bt === null) {
          add('NOTE', btE.line, name, 'Jail [' + name + ']: bantime value at line ' + btE.line + ' could not be read as a duration, so its timing is NOT AUDITED.');
        }
        if (ftE && ft === null) {
          add('NOTE', ftE.line, name, 'Jail [' + name + ']: findtime value at line ' + ftE.line + ' could not be read as a duration, so its timing is NOT AUDITED.');
        }
        if (bt === -1) {
          add('WARNING', btE.line, name,
            'Jail [' + name + ']: bantime = -1 (line ' + btE.line + ') means PERMANENT bans. A false positive — or your own mistyped password from a new address — locks that address out forever unless someone unbans it by hand. Use a long finite bantime unless permanent is truly intended.');
        }
        if (bt === 0) {
          add('WARNING', btE.line, name,
            'Jail [' + name + ']: bantime = 0 (line ' + btE.line + ') means bans expire immediately. The jail would catch an attacker and let them straight back in.');
        }
        if (bt !== null && bt > 0 && ft !== null && ft > 0 && bt < ft) {
          add('WARNING', btE.line, name,
            'Jail [' + name + ']: bantime (' + bt + 's, line ' + btE.line + ') is SHORTER than findtime (' + ft + 's, line ' + ftE.line +
            '). An attacker is unbanned before the failure window that caught them has even closed, so the same burst of attempts can re-trigger endlessly without the pressure ever building.');
        }
        if (ft !== null && ft <= 0 && ftE) {
          add('WARNING', ftE.line, name, 'Jail [' + name + ']: findtime is ' + ft + ' (line ' + ftE.line + '). A non-positive findtime makes the failure window meaningless — check the value.');
        }
        if (mr !== null && mr <= 0 && mrE) {
          add('WARNING', mrE.line, name, 'Jail [' + name + ']: maxretry is ' + mr + ' (line ' + mrE.line + '). Zero or negative retries mean the ban trigger itself is broken — check the value.');
        }
        if (mr !== null && mr > 0 && ft !== null && ft > 0) {
          add('NOTE', mrE ? mrE.line : firstLine, name,
            'Ban pressure — [' + name + ']: ' + mr + ' failures inside a ' + ft + '-second findtime window trigger a ban' +
            (bt === -1 ? ' that never expires (bantime = -1).' :
             bt !== null ? ' lasting ' + bt + ' seconds.' :
             ' whose length this file does not state (the shipped default fills it in).'));
        } else if (!btE || !ftE || !mrE) {
          add('NOTE', firstLine, name,
            'Jail [' + name + '] does not state all of bantime / findtime / maxretry in this file, so its full ban pressure cannot be computed here. Fail2ban\'s shipped defaults fill the gaps (stock: maxretry 5, findtime 600s, bantime 600s) — what runs depends on the host\'s jail.conf underneath this file.');
        }

        /* --- ignoreip --- */
        var igE = getE(map, 'ignoreip');
        if (!igE) {
          add('NOTE', firstLine, name,
            'Jail [' + name + '] sets no ignoreip whitelist. If you ever mistype your own password enough times from your usual address, this jail will ban you too — most operators whitelist at least their own fixed addresses.');
        } else {
          var igV = getV(map, 'ignoreip');
          if (!igV) {
            add('WARNING', igE.line, name,
              'Jail [' + name + ']: ignoreip is present at line ' + igE.line + ' but EMPTY. No address is whitelisted, so nobody — including you — is protected from a self-lockout, and an empty value often means a paste error ate the list.');
          } else {
            igV.split(/[\s,]+/).filter(Boolean).forEach(function (tok) {
              if (tok === '0.0.0.0/0' || tok === '::/0') {
                add('BLOCKER', igE.line, name,
                  'Jail [' + name + ']: ignoreip includes ' + tok + ' (line ' + igE.line +
                  ') — that whitelists every address there is. This jail can never ban anyone, no matter what the rest of the file says.');
                return;
              }
              var cm = tok.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})\/(\d{1,2})$/);
              if (cm) {
                var prefix = parseInt(cm[5], 10);
                var isLoopback8 = (cm[1] === '127' && prefix === 8);
                if (prefix <= 8 && !isLoopback8) {
                  var count = Math.pow(2, 32 - prefix);
                  add('WARNING', igE.line, name,
                    'Jail [' + name + ']: ignoreip includes ' + tok + ' (line ' + igE.line + ') — a /' + prefix +
                    ' whitelists about ' + count.toLocaleString('en-US') + ' addresses. Anyone attacking from inside that range can never be banned by this jail. Whitelist the smallest range that covers the addresses you actually control.');
                }
              }
            });
          }
        }

        /* --- sshd port: NOT SETTLED --- */
        var filterV = getV(map, 'filter') || '';
        if (name.toLowerCase() === 'sshd' || /sshd/.test(filterV)) {
          var portE = getE(map, 'port');
          var portV = getV(map, 'port');
          if (portV && portV !== 'ssh' && portV !== '22') {
            add('NOT SETTLED', portE.line, name,
              'Jail [' + name + '] guards sshd but sets port = ' + portV + ' (line ' + portE.line +
              '). NOT SETTLED: this audit reads a file, not the live machine, so it cannot know which port sshd actually listens on. If sshd is not on ' + portV +
              ' the ban will block the wrong port and the real one stays open. Verify against sshd_config on the host before enabling.');
          } else {
            add('NOT SETTLED', portE ? portE.line : firstLine, name,
              'Jail [' + name + '] guards sshd' + (portV ? ' with port = ' + portV : ' with no port override') +
              '. NOT SETTLED: this audit cannot see the live sshd listening port. If sshd was moved to a custom port, the ban has to name THAT port or it blocks a door nobody uses. Verify against sshd_config on the host before enabling.');
          }
        }

        /* --- backend --- */
        var beE = getE(map, 'backend');
        var beV = getV(map, 'backend');
        if (beV === 'polling') {
          add('NOTE', beE.line, name,
            'Jail [' + name + ']: backend = polling (line ' + beE.line + '). Polling is the works-anywhere fallback — it re-reads log files on an interval, so detection lags and CPU use is higher. Where the systemd journal exists, backend = systemd (or auto) is the sharper tool.');
        } else if (beV === 'systemd' && getV(map, 'logpath')) {
          add('NOTE', beE.line, name,
            'Jail [' + name + ']: backend = systemd (line ' + beE.line + ') reads the journal, so the logpath set for this jail is ignored. Harmless, but remove one of them so the file says what it means.');
        } else if (!beE) {
          add('NOTE', firstLine, name,
            'Jail [' + name + '] sets no backend, so Fail2ban\'s "auto" decides at runtime — on a systemd host that means the journal, elsewhere log polling. The choice affects which log source is actually watched; setting it explicitly removes the doubt.');
        }
      });

      /* --- destemail / sender (global) --- */
      if (destEntry) {
        if (mailActionUsed && !senderPresent) {
          add('WARNING', destEntry.line, '',
            'Alert mail is configured — destemail is set (line ' + destEntry.line + ') and a mail alert action is in use — but no sender is set anywhere in the file. Many mail servers reject or silently drop alerts with no valid sender, so the bans would happen but the alerts may never arrive. Add a sender line.');
        } else if (!mailActionUsed) {
          add('NOTE', destEntry.line, '',
            'destemail is set (line ' + destEntry.line + ') but no mail alert action is named anywhere in the file. Setting an address alone sends nothing — no alerts will be mailed until an action that sends mail (such as action_mwl) is in use.');
        }
      }

      return finish(findings, enabledJails);
    }

    function finish(findings, enabledJails) {
      /* Dedupe identical findings */
      var seen = {}, out = [];
      findings.forEach(function (f) {
        var k = f.sev + '|' + f.jail + '|' + f.msg;
        if (!seen[k]) { seen[k] = true; out.push(f); }
      });
      var rank = { 'BLOCKER': 0, 'WARNING': 1, 'NOT SETTLED': 2, 'NOT AUDITED': 3, 'NOTE': 4 };
      out.sort(function (a, b) {
        if (rank[a.sev] !== rank[b.sev]) return rank[a.sev] - rank[b.sev];
        return (a.line || 99999) - (b.line || 99999);
      });
      var counts = { 'BLOCKER': 0, 'WARNING': 0, 'NOT SETTLED': 0, 'NOT AUDITED': 0, 'NOTE': 0 };
      out.forEach(function (f) { counts[f.sev]++; });
      var verdict = counts['BLOCKER'] > 0 ? 'DO NOT ENABLE'
                  : counts['WARNING'] > 0 ? 'ENABLE WITH FIXES'
                  : 'SAFE TO ENABLE';
      return { verdict: verdict, counts: counts, findings: out, enabledJails: enabledJails };
    }

    function buildReport(result) {
      var c = result.counts;
      var lines = [];
      lines.push('J-DAWGS FAIL2BAN JAIL SAFETY AUDITOR — AUDIT REPORT');
      lines.push('Verdict: ' + result.verdict);
      lines.push('Enabled jails audited: ' + result.enabledJails +
                 ' · Blockers: ' + c['BLOCKER'] +
                 ' · Warnings: ' + c['WARNING'] +
                 ' · Not settled: ' + c['NOT SETTLED'] +
                 ' · Not audited: ' + c['NOT AUDITED'] +
                 ' · Notes: ' + c['NOTE']);
      lines.push('');
      if (!result.findings.length) {
        lines.push('Findings: none. Nothing in this file tripped any check.');
      } else {
        lines.push('Findings (worst first):');
        result.findings.forEach(function (f, i) {
          lines.push((i + 1) + '. [' + f.sev + ']' + (f.line ? ' Line ' + f.line : '') +
                     (f.jail ? ' · jail "' + f.jail + '"' : '') + ' — ' + f.msg);
        });
      }
      lines.push('');
      lines.push('About this audit: a heuristic INI text audit run entirely in the browser. It never connects to a server, never runs fail2ban-client, and saves nothing. Secret-shaped values are flagged by key name only and never appear in this report. Items marked NOT SETTLED cannot be decided from a file alone; items marked NOT AUDITED were not interpreted.');
      return lines.join('\n');
    }
    /* ============================================================
       END AUDIT CORE
       ============================================================ */

    var RISKY_EXAMPLE = [
      '# RISKY EXAMPLE — planted mistakes for testing this auditor. Do not deploy.',
      '[DEFAULT]',
      'bantime = 300',
      'findtime = 600',
      'maxretry = 3',
      'destemail = admin@example.com',
      'action = %(action_mwl)s',
      '',
      '[sshd]',
      'enabled = true',
      'port = 2222',
      'logpath = /var/log/auth.log',
      'backend = polling',
      'ignoreip = 10.0.0.0/8 127.0.0.1',
      'api_token = planted-secret-value-do-not-show',
      '',
      '[sshd]',
      'enabled = true',
      'filter = sshd',
      'bantime = -1',
      '',
      '[web-auth]',
      'enabled = true',
      'logpath = /var/log/nginx/error.log',
      'ignoreip =',
      'frobnicate = yes',
      '',
      '[open-relay]',
      'enabled = true',
      'filter = postfix',
      'action = iptables-multiport[name=postfix, port=smtp]',
      'ignoreip = 0.0.0.0/0'
    ].join('\n');

    var CLEAN_EXAMPLE = [
      '# Clean example — a tight, ordinary sshd setup.',
      '[DEFAULT]',
      'bantime = 3600',
      'findtime = 600',
      'maxretry = 5',
      'ignoreip = 127.0.0.1/8 ::1',
      'banaction = iptables-multiport',
      'backend = systemd',
      '',
      '[sshd]',
      'enabled = true',
      'filter = sshd',
      'action = %(action_)s',
      'port = ssh',
      'journalmatch = _SYSTEMD_UNIT=sshd.service + _COMM=sshd'
    ].join('\n');

    var WORKED_INPUT = '[sshd]\nenabled = true\nbantime = -1\nignoreip = 0.0.0.0/0';
    var WORKED_TEXT = 'IN — a jail an agent might paste:\n' + WORKED_INPUT +
      '\n\nOUT — the verdict it gets:\nDO NOT ENABLE — [sshd] is switched on but names no filter and no action (line 1), so it would watch nothing and ban nobody. ignoreip = 0.0.0.0/0 (line 4) whitelists the entire internet, and bantime = -1 (line 3) makes every ban permanent.';

    var EMPTY_MSG = 'Nothing to audit yet — the input box is empty. Paste a jail.local / jail.conf, or load the risky or clean example, then press Audit.';
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "CLEAN_EXAMPLE": (typeof CLEAN_EXAMPLE !== 'undefined' ? CLEAN_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-fail2ban-jail-safety-auditortm',
  name: 'J-Dawgs Fail2ban Jail Safety Auditor',
  description: 'fail2ban-client needs a live daemon and stops at syntax; ours audits a pasted jail.local offline — bantime/findtime/maxretry math, broad ignoreip, duplicate jails, secrets by key name only — into one enable verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "CLEAN_EXAMPLE": __core["CLEAN_EXAMPLE"] }
};
