'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Rsync Daemon Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

    /* AUDIT-CORE-START — pure logic, no DOM. The worked examples live here too,
       as line arrays, so their line numbers are exact by construction. */
    var RISKY_EXAMPLE_LINES = [
      '# Training-hall rsyncd.conf - pasted for audit',
      'port = 8873',
      'motd file = /etc/rsyncd.motd',
      'this line is not a setting',
      '',
      '[dropbox]',
      '    path = /srv/rsync/dropbox',
      '    comment = Team drop box',
      '    read only = no',
      '    uid = root',
      '',
      '[backups]',
      '    path = /srv/rsync/backups',
      '    read only = no',
      '    auth users = backupbot',
      '    hosts allow = 192.168.1.0/24'
    ];
    var HARDENED_EXAMPLE_LINES = [
      '# Hardened rsyncd.conf',
      'port = 873',
      'log file = /var/log/rsyncd.log',
      'max connections = 10',
      'timeout = 600',
      'use chroot = yes',
      '',
      '[pubdocs]',
      '    path = /srv/rsync/pubdocs',
      '    comment = Public documents',
      '    read only = yes',
      '    list = yes',
      '    hosts allow = 192.168.1.0/24, 10.0.0.0/8',
      '    auth users = docreader',
      '    secrets file = /etc/rsyncd.secrets',
      '    uid = rsyncd',
      '    gid = rsyncd',
      '    max connections = 4',
      '    timeout = 300'
    ];
    var RISKY_EXAMPLE = RISKY_EXAMPLE_LINES.join('\n');
    var HARDENED_EXAMPLE = HARDENED_EXAMPLE_LINES.join('\n');

    var KNOWN_KEYS = {};
    ('address|port|pid file|socket options|log file|syslog facility|motd file|lock file|' +
     'uid|gid|use chroot|max connections|timeout|numeric ids|path|comment|read only|write only|' +
     'list|auth users|secrets file|hosts allow|hosts deny|strict modes|transfer logging|' +
     'log format|include|include from|exclude|exclude from|filter|dont compress|ignore errors|' +
     'refuse options|munge symlinks|incoming chmod|outgoing chmod|pre-xfer exec|post-xfer exec|' +
     'early exec|fake super|forward lookup|reverse lookup|max verbosity|charset'
    ).split('|').forEach(function (k) { KNOWN_KEYS[k] = true; });

    var BOOL_KEYS = {};
    ('read only|write only|list|use chroot|strict modes|transfer logging|numeric ids|' +
     'ignore errors|munge symlinks|fake super|forward lookup|reverse lookup'
    ).split('|').forEach(function (k) { BOOL_KEYS[k] = true; });

    var SECURITY_KEYS = ['auth users', 'secrets file', 'hosts allow', 'hosts deny', 'read only', 'uid', 'gid'];
    var SEV_RANK = { BLOCKER: 0, WARNING: 1, 'NOT PARSED': 2, INFO: 3, 'NOT CHECKED': 4 };
    var SENSITIVE_RE = /backup|secret|private|personal|passwd|password|shadow|credential|vault|finance|payroll|internal|\/home\/|keys?/i;

    function normKey(k) { return String(k).trim().toLowerCase().replace(/\s+/g, ' '); }
    function parseBool(v) {
      if (v == null) return null;
      var s = String(v).trim().toLowerCase();
      if (s === 'yes' || s === 'true' || s === '1') return true;
      if (s === 'no' || s === 'false' || s === '0') return false;
      return null;
    }
    function editDistance(a, b) {
      var m = a.length, n = b.length, i, j;
      var prev = [], cur = [];
      for (j = 0; j <= n; j++) prev[j] = j;
      for (i = 1; i <= m; i++) {
        cur[0] = i;
        for (j = 1; j <= n; j++) {
          cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a.charAt(i - 1) === b.charAt(j - 1) ? 0 : 1));
        }
        var t = prev; prev = cur; cur = t;
      }
      return prev[n];
    }
    function nearMissSecurityKey(key) {
      var flat = key.replace(/\s+/g, '');
      for (var i = 0; i < SECURITY_KEYS.length; i++) {
        var sk = SECURITY_KEYS[i];
        if (editDistance(key, sk) <= 2 || editDistance(flat, sk.replace(/\s+/g, '')) <= 1) return sk;
      }
      return null;
    }
    function isRestrictiveHosts(entry) {
      if (!entry || !String(entry.value).trim()) return false;
      var tokens = String(entry.value).split(/[\s,]+/);
      for (var i = 0; i < tokens.length; i++) {
        var t = tokens[i];
        if (t === '*' || t === '0.0.0.0/0' || t === '::/0' || t === '0.0.0.0' || t === '::') return false;
      }
      return true;
    }

    function auditConfig(text) {
      var findings = [];
      function add(sev, moduleName, line, key, message, fix) {
        findings.push({ severity: sev, module: moduleName || null, line: (line == null ? null : line), key: key || null, message: message, fix: fix || null });
      }

      /* Join backslash continuations, keeping the starting line number. */
      var rawLines = String(text).replace(/\r\n?/g, '\n').split('\n');
      var lines = [], buf = null, bufNum = 0, i, raw;
      for (i = 0; i < rawLines.length; i++) {
        raw = rawLines[i];
        if (buf === null) { buf = raw; bufNum = i + 1; } else { buf += ' ' + raw.trim(); }
        var trimmedBuf = buf.replace(/\s+$/, '');
        if (/\\$/.test(trimmedBuf)) { buf = trimmedBuf.slice(0, -1); continue; }
        lines.push({ num: bufNum, text: buf }); buf = null;
      }
      if (buf !== null) lines.push({ num: bufNum, text: buf });

      var globalEntries = {};
      var modules = [];
      var current = null; /* null = global scope */
      function scopeEntries() { return current ? current.entries : globalEntries; }
      function scopeName() { return current ? current.name : null; }

      lines.forEach(function (ln) {
        var t = ln.text.trim();
        if (t === '') return;
        if (t.charAt(0) === '#' || t.charAt(0) === ';') return;
        if (t.charAt(0) === '&') {
          add('NOT CHECKED', scopeName(), ln.num, null,
            'Include directive on line ' + ln.num + ' ("' + t.split(/\s+/)[0] + '") — the included file is not part of the pasted text, so nothing it sets can be graded.', null);
          return;
        }
        var headerMatch = t.match(/^\[([^\]]+)\]\s*(?:[#;].*)?$/);
        if (headerMatch) {
          var modName = headerMatch[1].trim();
          if (modName === '') {
            add('NOT PARSED', scopeName(), ln.num, null, 'Line ' + ln.num + ' looks like a module header but the module name is empty — reported and excluded from grading.', null);
            current = null;
            return;
          }
          current = { name: modName, headerLine: ln.num, entries: {} };
          modules.push(current);
          return;
        }
        if (t.charAt(0) === '[') {
          add('NOT PARSED', scopeName(), ln.num, null,
            'Line ' + ln.num + ' starts with "[" but is not a well-formed module header — reported and excluded from grading.', null);
          return;
        }
        var eq = t.indexOf('=');
        if (eq === -1) {
          add('NOT PARSED', scopeName(), ln.num, null,
            'Line ' + ln.num + ' has no "=" and is not a module header, comment, or setting — it is not a valid rsyncd.conf line, so it is reported here and excluded from grading.', null);
          return;
        }
        var key = normKey(t.slice(0, eq));
        var value = t.slice(eq + 1).trim();
        if (key === '') {
          add('NOT PARSED', scopeName(), ln.num, null, 'Line ' + ln.num + ' has an "=" but no parameter name before it — reported and excluded from grading.', null);
          return;
        }
        scopeEntries()[key] = { value: value, line: ln.num };
      });

      function eff(mod, key) {
        if (mod && mod.entries[key]) return { value: mod.entries[key].value, line: mod.entries[key].line, where: 'module' };
        if (globalEntries[key]) return { value: globalEntries[key].value, line: globalEntries[key].line, where: 'global' };
        return null;
      }

      /* Unknown keys and unparseable boolean values, in both scopes. */
      function scanScope(entries, modName) {
        Object.keys(entries).forEach(function (key) {
          var e = entries[key];
          if (!KNOWN_KEYS[key]) {
            add('NOT CHECKED', modName, e.line, key,
              'Parameter "' + key + '" (line ' + e.line + ') is not a parameter this auditor recognizes — listed as NOT CHECKED and never guessed at.', null);
            var miss = nearMissSecurityKey(key);
            if (miss) {
              add('WARNING', modName, e.line, key,
                '"' + key + '" on line ' + e.line + ' looks like a misspelling of the security parameter "' + miss + '". rsync ignores unknown parameters, so as written this line sets nothing.',
                'Rename the parameter on line ' + e.line + ' to "' + miss + '" (exact spelling) so it actually takes effect.');
            }
          } else if (BOOL_KEYS[key] && parseBool(e.value) === null && String(e.value).trim() !== '') {
            add('NOT CHECKED', modName, e.line, key,
              'The value "' + e.value + '" for "' + key + '" on line ' + e.line + ' is not a recognized yes/no value, so that setting is not graded.', null);
          }
        });
      }
      scanScope(globalEntries, null);
      modules.forEach(function (m) { scanScope(m.entries, m.name); });

      /* Global port. */
      var gport = globalEntries['port'];
      if (gport) {
        var pnum = parseInt(gport.value, 10);
        if (!isNaN(pnum) && String(pnum) === String(gport.value).trim() && pnum !== 873) {
          add('INFO', null, gport.line, 'port',
            'Global port is ' + pnum + ' (line ' + gport.line + '), which is not the rsync default of 873. Not a risk by itself — just make sure firewalls and clients agree on it.', null);
        }
      }

      /* Duplicate module names. */
      var byName = {};
      modules.forEach(function (m) {
        var k = m.name.toLowerCase();
        if (!byName[k]) byName[k] = [];
        byName[k].push(m);
      });
      Object.keys(byName).forEach(function (k) {
        var group = byName[k];
        if (group.length > 1) {
          add('WARNING', group[1].name, group[1].headerLine, null,
            'Module name [' + group[0].name + '] is defined more than once — header lines ' + group.map(function (g) { return g.headerLine; }).join(' and ') + '. rsync does not give you two separate modules under one name: parameters from both blocks can end up applying to a single module, so neither block alone describes what the daemon will do.',
            'Rename one of the [' + group[0].name + '] blocks (header lines ' + group.map(function (g) { return g.headerLine; }).join(' and ') + ') so each module name is defined exactly once.');
        }
      });

      if (modules.length === 0) {
        add('WARNING', null, null, null,
          'No modules are defined in this file. The daemon would start but have nothing to serve — every client request would fail.', 'Add at least one [module] section with a path.');
      }

      /* Per-module grading. */
      var summaries = [];
      modules.forEach(function (m) {
        var ro = eff(m, 'read only');
        var roVal = ro ? parseBool(ro.value) : null;
        var auth = eff(m, 'auth users');
        var hasAuth = !!(auth && String(auth.value).trim() !== '');
        var secrets = eff(m, 'secrets file');
        var hasSecrets = !!(secrets && String(secrets.value).trim() !== '');
        var ha = eff(m, 'hosts allow');
        var haRestrictive = isRestrictiveHosts(ha);
        var uid = eff(m, 'uid');
        var gid = eff(m, 'gid');
        var pathE = eff(m, 'path');
        var worldWritable = false;

        if (uid && String(uid.value).trim().toLowerCase() === 'root') {
          add('BLOCKER', m.name, uid.line, 'uid',
            'Module [' + m.name + '] runs as uid = root (set on line ' + uid.line + (uid.where === 'global' ? ', in the global section, inherited by this module' : '') + '). Everything this module reads or writes is done with full root privileges — a client-side path mistake or an rsync flaw becomes a root-level problem.',
            'Set uid for [' + m.name + '] to a dedicated unprivileged account that owns only the files this module serves.');
        }
        if (gid && String(gid.value).trim().toLowerCase() === 'root') {
          add('BLOCKER', m.name, gid.line, 'gid',
            'Module [' + m.name + '] runs with gid = root (set on line ' + gid.line + (gid.where === 'global' ? ', in the global section, inherited by this module' : '') + '). Files written through this module land with root-group ownership.',
            'Set gid for [' + m.name + '] to the unprivileged group that owns only the files this module serves.');
        }

        if (hasAuth && !hasSecrets) {
          add('BLOCKER', m.name, auth.line, 'auth users',
            'Module [' + m.name + '] sets auth users (line ' + auth.line + ') but declares no secrets file in the module or the global section. The daemon has no password file to check credentials against, so this authentication cannot work — every authenticated connection will fail.',
            'Add a secrets file line to [' + m.name + '] (for example: secrets file = /etc/rsyncd.secrets) and create that file on the host, readable only by the user the daemon runs as.');
        }

        if (ro && roVal === false) {
          if (!hasAuth && !haRestrictive) {
            worldWritable = true;
            add('BLOCKER', m.name, ro.line, 'read only',
              'Module [' + m.name + '] is world-writable: read only = no (line ' + ro.line + '), no auth users, and no restrictive hosts allow. Any host that can reach the daemon port can read, upload, overwrite, and delete files under ' + (pathE ? pathE.value : 'the module path') + ' with no credentials at all.',
              'Close [' + m.name + '] one of two ways: set read only = yes if uploads are not needed, or keep it writable only behind both auth users with a secrets file and a restrictive hosts allow list.');
          } else {
            var gates = [];
            if (hasAuth) gates.push('auth users');
            if (haRestrictive) gates.push('a restrictive hosts allow');
            add('WARNING', m.name, ro.line, 'read only',
              'Module [' + m.name + '] has read only = no (line ' + ro.line + '), so uploads and deletions are enabled. Writes are gated by ' + gates.join(' and ') + ', which keeps it off the blocker list — but a writable module is still the riskiest kind there is, so confirm writes are genuinely intended.',
              'If [' + m.name + '] does not need uploads, set read only = yes. If it does, keep both auth users and hosts allow in place and review who is on them.');
          }
        } else if (!ro) {
          if (!hasAuth && !haRestrictive) {
            worldWritable = true;
            add('BLOCKER', m.name, m.headerLine, 'read only',
              'Module [' + m.name + '] never sets read only, sets no auth users, and has no restrictive hosts allow. This audit will not take the daemon default posture on faith: with nothing restricting it, this module must be treated as world-writable — any host that can reach the port can attempt reads and writes under ' + (pathE ? pathE.value : 'the module path') + '.',
              'Set read only = yes explicitly in [' + m.name + '] (or, if uploads are truly required, read only = no together with auth users, a secrets file, and a restrictive hosts allow).');
          } else {
            add('WARNING', m.name, m.headerLine, 'read only',
              'Module [' + m.name + '] never sets read only, in the module or the global section. Do not deploy on an assumed default — the read-only posture of this module is undeclared, and undeclared posture is how writable modules ship by accident.',
              'Set read only explicitly in [' + m.name + ']: yes, unless this module genuinely takes uploads.');
          }
        }

        if (!worldWritable) {
          if (!ha) {
            add('WARNING', m.name, m.headerLine, 'hosts allow',
              'Module [' + m.name + '] has no hosts allow (module or global). Any host that can reach the daemon port can attempt a connection to this module — the only thing in front of it is whatever firewall you run, and this config adds no restriction of its own.',
              'Add a hosts allow line to [' + m.name + '] naming only the networks that should reach it (for example: hosts allow = 192.168.1.0/24).');
          } else if (!haRestrictive) {
            add('WARNING', m.name, ha.line, 'hosts allow',
              'Module [' + m.name + '] sets hosts allow to "' + ha.value + '" (line ' + ha.line + '), which matches every host — that restricts nothing.',
              'Replace the hosts allow value for [' + m.name + '] with the specific hosts or networks that should reach it.');
          }
        }

        var uc = eff(m, 'use chroot');
        if (uc && parseBool(uc.value) === false) {
          add('WARNING', m.name, uc.line, 'use chroot',
            'Module [' + m.name + '] sets use chroot = no (line ' + uc.line + '). The daemon will not confine this module to its own path, so path escapes — through symlinks, for instance — are not fenced in.',
            'Set use chroot = yes for [' + m.name + '] unless you have a specific, documented reason it cannot chroot.');
        }

        var mc = eff(m, 'max connections');
        if (!mc) {
          add('WARNING', m.name, m.headerLine, 'max connections',
            'Module [' + m.name + '] has no max connections set, in the module or the global section. Nothing caps simultaneous connections, so one client — or one flood — can crowd out everyone else and exhaust the daemon.',
            'Set max connections for [' + m.name + '] (a small number like 4–10 is typical) or set it once in the global section.');
        }

        var to = eff(m, 'timeout');
        if (!to) {
          add('INFO', m.name, m.headerLine, 'timeout',
            'Module [' + m.name + '] has no timeout set, in the module or the global section. rsync applies no idle timeout by default, so stalled clients can hold connections open indefinitely.', null);
        }

        var listE = eff(m, 'list');
        var listVal = listE ? parseBool(listE.value) : null;
        var listed = listE ? (listVal === true) : true;
        var sensitiveHit = SENSITIVE_RE.test(m.name + ' ' + (pathE ? pathE.value : ''));
        if (listed && sensitiveHit) {
          if (listE && listVal === true) {
            add('WARNING', m.name, listE.line, 'list',
              'Module [' + m.name + '] sets list = yes (line ' + listE.line + ') while its name or path suggests sensitive content. The module name is advertised to anyone who connects and asks for a listing. Note that list = no only hides the name from listings — it is not access control, and anyone who knows or guesses the name can still connect.',
              'If the name itself gives away something sensitive, set list = no on [' + m.name + '] — but treat that as tidiness, not security; the real controls are auth users and hosts allow.');
          } else if (!listE) {
            add('INFO', m.name, m.headerLine, 'list',
              'Module [' + m.name + '] never sets list, and rsync lists modules by default — combined with a name or path that suggests sensitive content, that name is advertised to anyone who connects and asks for a listing. (list = no would hide the name from listings, but hiding is not access control.)', null);
          }
        }

        if (!pathE) {
          add('WARNING', m.name, m.headerLine, 'path',
            'Module [' + m.name + '] declares no path. The daemon has nothing to serve for this module, so every request to it fails.',
            'Add a path line to [' + m.name + '] pointing at the directory it should serve.');
        }

        if (hasSecrets) {
          if (hasAuth) {
            add('INFO', m.name, secrets.line, 'secrets file',
              'Module [' + m.name + '] declares secrets file = ' + secrets.value + ' (line ' + secrets.line + '). That path is all the config text can prove: this audit cannot check the file permissions or contents on the host. On the host, that file should be readable only by the user the daemon runs as (mode 600 is the usual setting) — rsync expects it locked down.', null);
          } else {
            add('INFO', m.name, secrets.line, 'secrets file',
              'Module [' + m.name + '] declares secrets file = ' + secrets.value + ' (line ' + secrets.line + ') but sets no auth users, so nothing in this module ever checks that file. Its permissions and contents also cannot be graded from config text.', null);
          }
        }

        var worst = null;
        findings.forEach(function (f) {
          if (f.module === m.name && (worst === null || SEV_RANK[f.severity] < SEV_RANK[worst])) worst = f.severity;
        });
        summaries.push({
          name: m.name,
          headerLine: m.headerLine,
          path: pathE ? pathE.value : '(no path set)',
          readOnly: ro ? (roVal === true ? 'yes' : (roVal === false ? 'no' : 'set, value not recognized')) : 'not set',
          auth: hasAuth ? 'auth users set' + (hasSecrets ? ' + secrets file' : ' (no secrets file)') : 'none',
          hostsAllow: ha ? (haRestrictive ? 'restrictive list' : 'set, but matches everyone') : 'none',
          runsAs: 'uid ' + (uid ? uid.value : 'not set') + ' / gid ' + (gid ? gid.value : 'not set'),
          worst: worst || 'CLEAN'
        });
      });

      findings.sort(function (a, b) {
        var r = SEV_RANK[a.severity] - SEV_RANK[b.severity];
        if (r !== 0) return r;
        var la = a.line == null ? 99999 : a.line, lb = b.line == null ? 99999 : b.line;
        return la - lb;
      });

      var counts = { BLOCKER: 0, WARNING: 0, INFO: 0, 'NOT PARSED': 0, 'NOT CHECKED': 0 };
      findings.forEach(function (f) { counts[f.severity]++; });

      var verdict;
      if (counts.BLOCKER > 0) verdict = 'DO NOT DEPLOY';
      else if (counts.WARNING > 0 || counts['NOT PARSED'] > 0) verdict = 'DEPLOY WITH FIXES';
      else verdict = 'SAFE TO DEPLOY';

      var fixes = [], seenFix = {};
      findings.forEach(function (f) {
        if (f.fix && !seenFix[f.fix]) { seenFix[f.fix] = true; fixes.push(f.fix); }
      });

      return { verdict: verdict, counts: counts, findings: findings, modules: summaries, fixes: fixes, moduleCount: modules.length };
    }

    function buildTextReport(r) {
      var out = [];
      out.push('J-Dawgs Rsync Daemon Config Safety Auditor - audit report');
      out.push('Verdict: ' + r.verdict);
      out.push('Counts: ' + r.counts.BLOCKER + ' BLOCKER, ' + r.counts.WARNING + ' WARNING, ' + r.counts.INFO + ' INFO, ' +
        r.counts['NOT PARSED'] + ' NOT PARSED, ' + r.counts['NOT CHECKED'] + ' NOT CHECKED');
      out.push('');
      out.push('Findings:');
      if (r.findings.length === 0) out.push('  (none)');
      r.findings.forEach(function (f) {
        var loc = f.line != null ? 'line ' + f.line : 'file level';
        var scope = f.module ? 'module [' + f.module + ']' : 'global';
        out.push('[' + f.severity + '] ' + scope + ', ' + loc + ' - ' + f.message);
        if (f.fix) out.push('    Fix: ' + f.fix);
      });
      out.push('');
      out.push('Per-module summary:');
      if (r.modules.length === 0) out.push('  (no modules defined)');
      r.modules.forEach(function (s) {
        out.push('[' + s.name + '] (header line ' + s.headerLine + '): path ' + s.path + ' | read only: ' + s.readOnly +
          ' | auth: ' + s.auth + ' | hosts allow: ' + s.hostsAllow + ' | runs as: ' + s.runsAs + ' | worst finding: ' + s.worst);
      });
      out.push('');
      out.push('Fix list:');
      if (r.fixes.length === 0) out.push('  (nothing to fix)');
      r.fixes.forEach(function (fx, i) { out.push('  ' + (i + 1) + '. ' + fx); });
      out.push('');
      out.push('Scope note: heuristic text audit only. rsync was not run and no daemon was contacted. ' +
        'A secrets file path can be read from the config, but that file permissions and contents cannot be graded from pasted text.');
      return out.join('\n');
    }

    function buildJsonReport(r) {
      return JSON.stringify({
        tool: 'J-Dawgs Rsync Daemon Config Safety Auditor',
        verdict: r.verdict,
        counts: r.counts,
        modules: r.modules,
        findings: r.findings,
        fixes: r.fixes,
        scopeNote: 'Heuristic text audit of pasted rsyncd.conf text. rsync was not run; no daemon was contacted; secrets file permissions and contents cannot be graded from config text.'
      }, null, 2);
    }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE_LINES": (typeof RISKY_EXAMPLE_LINES !== 'undefined' ? RISKY_EXAMPLE_LINES : undefined), "HARDENED_EXAMPLE_LINES": (typeof HARDENED_EXAMPLE_LINES !== 'undefined' ? HARDENED_EXAMPLE_LINES : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-rsync-daemon-config-safety-auditor',
  name: 'J-Dawgs Rsync Daemon Config Safety Auditor',
  description: 'rsync only exercises its daemon config at startup on an installed host and never grades it; ours audits a pasted rsyncd.conf anywhere — world-writable modules, missing auth, and root-identity modules included — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE_LINES": __core["RISKY_EXAMPLE_LINES"], "HARDENED_EXAMPLE_LINES": __core["HARDENED_EXAMPLE_LINES"], "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
