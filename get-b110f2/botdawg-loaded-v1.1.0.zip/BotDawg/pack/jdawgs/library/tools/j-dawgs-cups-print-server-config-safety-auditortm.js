'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs CUPS Print Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var RISKY = [
          "# Worked example - risky cupsd.conf (teaching sample)",
          "LogLevel warn",
          "MaxLogSize 0",
          "Port 631",
          "Browsing On",
          "BrowseLocalProtocols dnssd",
          "BrowseAllow all",
          "DefaultAuthType Basic",
          "WebInterface Yes",
          "<Location />",
          "  Order allow,deny",
          "  Allow all",
          "</Location>",
          "<Location /admin>",
          "  Order allow,deny",
          "  Allow all",
          "</Location>",
          "<Location /admin/conf>",
          "  AuthType Default",
          "  Require user @SYSTEM",
          "  Order allow,deny",
          "</Location>"
        ].join("\n");

        var HARDENED = [
          "# Hardened example - localhost only, authenticated admin",
          "LogLevel warn",
          "MaxLogSize 0",
          "Listen localhost:631",
          "Browsing Off",
          "BrowseLocalProtocols none",
          "DefaultAuthType Basic",
          "DefaultEncryption Required",
          "WebInterface Yes",
          "ServerName print.example.local",
          "ServerAdmin admin@example.local",
          "<Location />",
          "  Order allow,deny",
          "  Allow @LOCAL",
          "</Location>",
          "<Location /admin>",
          "  AuthType Basic",
          "  Require user @SYSTEM",
          "  Encryption Required",
          "  Order allow,deny",
          "  Allow @LOCAL",
          "</Location>",
          "<Location /admin/conf>",
          "  AuthType Default",
          "  Require user @SYSTEM",
          "  Order allow,deny",
          "</Location>"
        ].join("\n");

        var TOOL_PITCH = "J-Dawgs CUPS Print Server Config Safety Auditor: paste a cupsd.conf and get one deploy verdict - SAFE TO DEPLOY, DEPLOY WITH FIXES, or DO NOT DEPLOY - with line-numbered findings on network exposure, Location access rules, and admin posture. Runs entirely in the browser; nothing is saved or uploaded.";

        // Directives recognised anywhere in cupsd.conf (lowercased first token).
        var KNOWN = {};
        [
          "loglevel","maxlogsize","errorpolicy","jobprivateaccess","jobprivatevalues",
          "subscriptionprivatevalues","listen","port","browsing","browselocalprotocols",
          "browseprotocols","browseallow","browsedeny","browseorder","browsepoll",
          "browserelay","browseinterval","browseport","browsewebif","defaultauthtype",
          "defaultencryption","webinterface","servername","serveradmin","serveralias",
          "servercertificate","serverkey","serverroot","documentroot","datadir","statedir",
          "cachedir","tempdir","rundir","listenbacklog","keepalive","keepalivetimeout",
          "timeout","maxclients","maxclientsperhost","maxjobs","maxjobsperuser",
          "maxjobsperprinter","preservejobhistory","preservejobfiles","autopurgejobs",
          "requestroot","accesslog","errorlog","pagelog","accessloglevel","logdebugtohistory",
          "fatalerrors","reporterrors","printcap","printcapformat","include","user","group",
          "ripcache","filterlimit","classification","classifyoverride","passenv","setenv",
          "order","allow","deny","require","authtype","authclass","authinfo","encryption",
          "satisfy","hostnamelookups","implicitclasses","hideimplicitmembers","filedevice",
          "colormanaged","gssservicename","kerberoskeytab","listen","servercatalog",
          "maxsubscriptions","defaultlanguage","defaultpaperize","defaultpapersize",
          "jobkilldelay","jobretryinterval","jobbufs","pagecost","ripmaxcache"
        ].forEach(function(k){ KNOWN[k]=true; });

        var SENSITIVE = /pass|secret|token|credential|keyfile|private/i;

        function firstToken(line){
          var m = line.match(/^\s*([A-Za-z][A-Za-z0-9_-]*)\b/);
          return m ? m[1] : "";
        }
        function directiveValue(line){
          var t = line.trim();
          var sp = t.search(/\s/);
          return sp === -1 ? "" : t.slice(sp+1).trim();
        }
        function allowsAll(value){
          var v = value.trim().toLowerCase().replace(/\s+/g," ");
          return v === "all" || v === "from all";
        }
        function isLocalListen(value){
          var v = value.trim().toLowerCase();
          if (v.charAt(0) === "/") return true;
          if (v.indexOf("localhost") === 0) return true;
          if (v.indexOf("127.0.0.1") === 0) return true;
          if (v.indexOf("[::1]") === 0 || v.indexOf("::1") === 0) return true;
          return false;
        }

        function audit(text){
          var lines = text.split(/\r\n|\r|\n/);
          var findings = [];
          function add(sev, lineLabel, directive, msg){
            findings.push({sev:sev, lineLabel:lineLabel, directive:directive, msg:msg});
          }

          var networkListens = [];   // {line, directive}
          var listenLines = [];      // all Listen line numbers
          var browsingOnLine = 0;
          var browseLocalLine = 0, browseLocalVal = "";
          var hasServerAdmin = false, hasServerName = false;
          var defaultEncLine = 0, defaultEncVal = "";
          var locations = [];
          var stack = [];            // {kind, path, startLine, loc}
          var currentLoc = null;

          function newLocation(path, startLine){
            return { path:path, startLine:startLine, endLine:0, allowAllLine:0,
                     hasAuthType:false, hasRequireUser:false, encryptionVals:[],
                     limits:[] };
          }

          for (var i=0; i<lines.length; i++){
            var lineNo = i+1;
            var raw = lines[i];
            var t = raw.trim();
            if (t === "" || t.charAt(0) === "#") continue;

            var openLoc = t.match(/^<Location\s+([^>\s]+)\s*>$/i);
            var openLimit = t.match(/^<Limit\s+([^>]*)>$/i);
            var openLimitExcept = t.match(/^<LimitExcept\s+([^>]*)>$/i);
            var openPolicy = t.match(/^<Policy\s+[^>]*>$/i);
            var closeTag = t.match(/^<\/(Location|Limit|LimitExcept|Policy)>$/i);

            if (openLoc){
              var loc = newLocation(openLoc[1], lineNo);
              locations.push(loc);
              stack.push({kind:"Location", startLine:lineNo, loc:loc});
              currentLoc = loc;
              continue;
            }
            if (openLimit || openLimitExcept){
              var opsRaw = (openLimit ? openLimit[1] : openLimitExcept[1]).trim();
              var lim = { line:lineNo, ops:opsRaw ? opsRaw.split(/\s+/) : [],
                          hasRequire:false, hasAuthType:false,
                          except: !!openLimitExcept };
              if (currentLoc) currentLoc.limits.push(lim);
              stack.push({kind: openLimit ? "Limit" : "LimitExcept", startLine:lineNo, lim:lim});
              continue;
            }
            if (openPolicy){
              stack.push({kind:"Policy", startLine:lineNo});
              continue;
            }
            if (closeTag){
              var kind = closeTag[1].toLowerCase();
              for (var s=stack.length-1; s>=0; s--){
                if (stack[s].kind.toLowerCase() === kind){
                  if (stack[s].kind === "Location" && stack[s].loc) stack[s].loc.endLine = lineNo;
                  stack.splice(s,1);
                  break;
                }
              }
              var stillLoc = null;
              for (var s2=stack.length-1; s2>=0; s2--){ if (stack[s2].kind==="Location"){ stillLoc = stack[s2].loc; break; } }
              currentLoc = stillLoc;
              continue;
            }
            if (t.charAt(0) === "<"){
              add("NOT PARSED", "Line " + lineNo, "block tag",
                  "This line starts a block shape this auditor does not recognise. It is reported, not guessed at.");
              continue;
            }

            var tok = firstToken(t);
            var key = tok.toLowerCase();
            if (!tok || !KNOWN[key]){
              var label = (tok && !SENSITIVE.test(tok)) ? tok : "unrecognised directive";
              add("NOT PARSED", "Line " + lineNo, label,
                  "This line is not blank, not a comment, and matches no known cupsd.conf directive or block shape. It is reported, not guessed at. If it carries a value, the value is not printed here.");
              continue;
            }

            var val = directiveValue(t);
            var inLoc = currentLoc;
            var topLimit = null;
            for (var s3=stack.length-1; s3>=0; s3--){
              if (stack[s3].kind==="Limit" || stack[s3].kind==="LimitExcept"){ topLimit = stack[s3].lim; break; }
              if (stack[s3].kind==="Location") break;
            }

            switch(key){
              case "port":
                networkListens.push({line:lineNo, directive:"Port"});
                break;
              case "listen":
                listenLines.push(lineNo);
                if (!isLocalListen(val)) networkListens.push({line:lineNo, directive:"Listen"});
                break;
              case "browsing":
                if (val.toLowerCase() === "on") browsingOnLine = lineNo;
                break;
              case "browselocalprotocols":
                browseLocalLine = lineNo; browseLocalVal = val;
                break;
              case "browseallow":
                if (allowsAll(val)){
                  add("WARNING", "Line " + lineNo, "BrowseAllow",
                      "BrowseAllow all accepts printer discovery from every host, broadcasting discovery beyond the local network. Restrict it to the local subnet.");
                }
                break;
              case "serveradmin": hasServerAdmin = true; break;
              case "servername": hasServerName = true; break;
              case "serveralias":
                if (val.trim() === "*"){
                  add("WARNING", "Line " + lineNo, "ServerAlias",
                      "ServerAlias * makes the server answer to any hostname — a remote-administration exposure. Name the real hostnames instead.");
                }
                break;
              case "defaultencryption":
                defaultEncLine = lineNo; defaultEncVal = val;
                if (val.toLowerCase() === "never"){
                  add("WARNING", "Line " + lineNo, "DefaultEncryption",
                      "DefaultEncryption Never sends print jobs and credentials unencrypted by default. Use Required for anything beyond a sealed local network.");
                }
                break;
              case "encryption":
                if (inLoc) inLoc.encryptionVals.push({line:lineNo, val:val});
                if (val.toLowerCase() === "never"){
                  add("WARNING", "Line " + lineNo, "Encryption",
                      "Encryption Never disables transport encryption" + (inLoc ? " for " + inLoc.path : "") + ". Use Encryption Required here.");
                } else if (inLoc && inLoc.path === "/admin" && val.toLowerCase() !== "required"){
                  add("WARNING", "Line " + lineNo, "Encryption",
                      "The /admin block states an encryption posture weaker than Required (" + (SENSITIVE.test(val) ? "value withheld" : val) + "). Admin traffic should require encryption.");
                }
                break;
              case "allow":
                if (inLoc && allowsAll(val) && !inLoc.allowAllLine) inLoc.allowAllLine = lineNo;
                break;
              case "authtype":
                if (inLoc) inLoc.hasAuthType = true;
                if (topLimit) topLimit.hasAuthType = true;
                break;
              case "require":
                if (/^user\b/i.test(val) || /^valid-user\b/i.test(val)){
                  if (inLoc) inLoc.hasRequireUser = true;
                  if (topLimit) topLimit.hasRequire = true;
                } else if (topLimit) { topLimit.hasRequire = true; }
                break;
            }
          }

          // Unclosed blocks
          stack.forEach(function(item){
            if (item.kind === "Location"){
              add("WARNING", "Line " + item.startLine, "<Location " + (item.loc ? item.loc.path : "") + ">",
                  "This <Location> block is never closed. cupsd may refuse the file or apply the rules differently than intended — close the block and re-audit.");
              if (item.loc) item.loc.endLine = lines.length;
            } else {
              add("WARNING", "Line " + item.startLine, "<" + item.kind + ">",
                  "This <" + item.kind + "> block is never closed.");
            }
          });

          // Duplicate Listen directives
          if (listenLines.length > 1){
            add("INFO", "Lines " + listenLines.join(", "), "Listen",
                "Listen appears " + listenLines.length + " times (lines " + listenLines.join(", ") + "). Multiple listeners can be deliberate — one per interface — but confirm every one is intended; each non-localhost listener is graded above.");
          }

          // Network exposure warnings (one per exposing directive)
          networkListens.forEach(function(nl){
            add("WARNING", "Line " + nl.line, nl.directive,
                nl.directive === "Port"
                  ? "Port 631 listens on every interface. This print server is reachable from the network; make sure the Location rules — not hope — are what protect it."
                  : "This Listen directive binds a non-localhost address. This print server is reachable from the network; make sure the Location rules — not hope — are what protect it.");
          });

          // BLOCKER: open print server
          locations.forEach(function(loc){
            if ((loc.path === "/" || loc.path === "/printers" || loc.path === "/printers/") && loc.allowAllLine && networkListens.length){
              var nl = networkListens[0];
              add("BLOCKER", "Line " + loc.allowAllLine + " (block opens line " + loc.startLine + "; exposed by line " + nl.line + ")", "Allow",
                  "<Location " + loc.path + "> allows access from all hosts while line " + nl.line + " (" + nl.directive + ") exposes the server beyond localhost. Anyone who can reach the port can print. Restrict the Allow rule (for example to @LOCAL) or bind the server to localhost.");
            }
            // BLOCKER: open admin
            if (loc.path === "/admin" && loc.allowAllLine && !loc.hasAuthType && !loc.hasRequireUser){
              add("BLOCKER", "Line " + loc.allowAllLine + " (block opens line " + loc.startLine + ")", "Allow",
                  "<Location /admin> allows access from all hosts with no AuthType and no Require user restriction in the block. Anyone who can reach it can administer the server. Add AuthType and a Require user rule, and stop allowing all hosts.");
            }
            // Partial <Limit> coverage
            if (loc.limits.length){
              var covered = {};
              loc.limits.forEach(function(l){ l.ops.forEach(function(op){ covered[op.toLowerCase()] = true; }); });
              var anyRestricted = loc.limits.some(function(l){ return l.hasRequire || l.hasAuthType; });
              if (anyRestricted && !covered["send-document"] && !covered["create-job"]){
                add("WARNING", "Line " + loc.limits[0].line + " (in <Location " + loc.path + ">, block opens line " + loc.startLine + ")", "<Limit>",
                    "This Location limits some operations, but no <Limit> block covers Send-Document or Create-Job — those job-submission operations stay unrestricted while their neighbours are limited. Add them to a <Limit> block with the same restrictions.");
              }
            }
          });

          // Browsing broadcast
          if (browsingOnLine && browseLocalLine && browseLocalVal.trim().toLowerCase() !== "none" && browseLocalVal.trim() !== ""){
            add("WARNING", "Line " + browsingOnLine + " / line " + browseLocalLine, "Browsing + BrowseLocalProtocols",
                "Browsing is On and BrowseLocalProtocols advertises printers (" + (SENSITIVE.test(browseLocalVal) ? "value withheld" : browseLocalVal) + "). Discovery announcements travel beyond this host. Turn Browsing Off or set BrowseLocalProtocols to none on servers that should not advertise.");
          }

          // INFO: missing identity / encryption defaults
          if (!hasServerAdmin) add("INFO", "Whole file", "ServerAdmin",
              "No ServerAdmin directive anywhere. Not a hole by itself, but the admin contact should be stated so failures have an owner.");
          if (!hasServerName) add("INFO", "Whole file", "ServerName",
              "No ServerName directive anywhere. The server will guess its name; stating it avoids certificate and redirect surprises.");
          if (!defaultEncLine) add("INFO", "Whole file", "DefaultEncryption",
              "DefaultEncryption is not set, so the compiled-in default decides whether jobs and admin traffic must be encrypted. State it explicitly — Required for network-reachable servers.");

          var order = { "BLOCKER":0, "WARNING":1, "INFO":2, "NOT PARSED":3 };
          findings.sort(function(a,b){
            if (order[a.sev] !== order[b.sev]) return order[a.sev]-order[b.sev];
            return 0;
          });

          var counts = { "BLOCKER":0, "WARNING":0, "INFO":0, "NOT PARSED":0 };
          findings.forEach(function(f){ counts[f.sev]++; });

          var verdict;
          if (counts["BLOCKER"] > 0) verdict = "DO NOT DEPLOY";
          else if (counts["WARNING"] > 0 || counts["NOT PARSED"] > 0) verdict = "DEPLOY WITH FIXES";
          else verdict = "SAFE TO DEPLOY";

          return { verdict:verdict, findings:findings, counts:counts, lineCount:lines.length };
        }

        function esc(s){
          return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
        }

        function buildReport(result){
          var out = [];
          out.push("J-Dawgs CUPS Print Server Config Safety Auditor - audit report");
          out.push("Verdict: " + result.verdict);
          out.push("Lines audited: " + result.lineCount);
          out.push("Findings: " + result.counts["BLOCKER"] + " BLOCKER, " + result.counts["WARNING"] + " WARNING, " + result.counts["INFO"] + " INFO, " + result.counts["NOT PARSED"] + " NOT PARSED");
          out.push("");
          if (!result.findings.length) out.push("No findings.");
          result.findings.forEach(function(f, idx){
            out.push((idx+1) + ". [" + f.sev + "] " + f.lineLabel + " - " + f.directive);
            out.push("   " + f.msg);
          });
          out.push("");
          out.push("Limits: text audit of a pasted config only. No printer or server was contacted. Firewall rules, printers.conf, client-side authentication, and TLS certificates are outside this audit.");
          return out.join("\n");
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-cups-print-server-config-safety-auditortm',
  name: 'J-Dawgs CUPS Print Server Config Safety Auditor',
  description: 'Grades a pasted cupsd.conf offline — open print/admin Locations, network Listen exposure, encryption posture — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
