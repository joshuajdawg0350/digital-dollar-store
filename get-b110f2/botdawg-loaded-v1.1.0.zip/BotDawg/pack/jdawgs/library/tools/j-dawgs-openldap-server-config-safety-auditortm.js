'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs OpenLDAP Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var HASH_SCHEMES = ["SSHA", "SHA", "SMD5", "MD5", "CRYPT", "ARGON2", "PBKDF2"];

      var RISKY_TEXT = [
        "# RISKY example — a config that must not ship",
        "suffix \"dc=example,dc=org\"",
        "rootdn \"cn=Manager,dc=example,dc=org\"",
        "rootpw fakeCleartextPass123",
        "access to * by * write"
      ].join("\n");

      var CLEAN_TEXT = [
        "# CLEAN example — restrictive, hashed, TLS on",
        "suffix \"dc=example,dc=org\"",
        "rootdn \"cn=Manager,dc=example,dc=org\"",
        "rootpw {SSHA}RkFLRUhBU0hGb3JFeGFtcGxlT25seUZha2VIYXNo",
        "require authc",
        "security ssf=128 simple_bind=128",
        "TLSCACertificateFile /etc/ldap/ssl/ca-cert.pem",
        "TLSCertificateFile /etc/ldap/ssl/server-cert.pem",
        "TLSCertificateKeyFile /etc/ldap/ssl/server-key.pem",
        "access to attrs=userPassword by self write by anonymous auth by * none",
        "access to * by users read by * none"
      ].join("\n");

      function detectStyle(text) {
        if (/^\s*dn\s*:/im.test(text)) return "ldif";
        if (/\bolc[A-Za-z][A-Za-z0-9-]*\s*:/.test(text)) return "ldif";
        return "conf";
      }

      function canonKey(k) {
        var x = String(k).toLowerCase();
        if (x.indexOf("olc") === 0 && x.length > 3) x = x.slice(3);
        return x;
      }

      function splitPhysical(text) {
        var phys = String(text).split(/\r?\n/);
        var pemBlocks = [];
        var kept = [];
        var inPem = null;
        for (var i = 0; i < phys.length; i++) {
          var line = phys[i];
          if (inPem) {
            if (/-----END [A-Z0-9 ]+-----/.test(line)) {
              inPem.end = i + 1;
              pemBlocks.push(inPem);
              inPem = null;
            }
            continue;
          }
          var bm = line.match(/-----BEGIN ([A-Z0-9 ]+)-----/);
          if (bm) { inPem = { type: bm[1].trim(), start: i + 1, end: i + 1 }; continue; }
          kept.push({ num: i + 1, text: line });
        }
        if (inPem) pemBlocks.push(inPem);
        return { kept: kept, pemBlocks: pemBlocks };
      }

      function logicalLines(kept) {
        var out = [];
        kept.forEach(function (pl) {
          var t = pl.text;
          if (/^\s*$/.test(t)) return;
          if (/^[ \t]/.test(t) && out.length && !out[out.length - 1].comment) {
            out[out.length - 1].text += " " + t.trim();
            return;
          }
          var trimmed = t.trim();
          if (trimmed.charAt(0) === "#") { out.push({ num: pl.num, text: trimmed, comment: true }); return; }
          out.push({ num: pl.num, text: trimmed, comment: false });
        });
        return out.filter(function (l) { return !l.comment; });
      }

      function parseEntry(l, style) {
        var t = l.text;
        if (/^\s*dn\s*:/i.test(t)) {
          return { line: l.num, key: "dn", canon: "dn", value: t.replace(/^\s*dn\s*:\s*/i, "") };
        }
        if (style === "ldif") {
          var m = t.match(/^([A-Za-z][A-Za-z0-9;-]*):{1,2}\s*(.*)$/);
          if (m) return { line: l.num, key: m[1], canon: canonKey(m[1]), value: m[2] };
        }
        var sp = t.search(/\s/);
        var key = sp === -1 ? t : t.slice(0, sp);
        var value = sp === -1 ? "" : t.slice(sp).trim();
        return { line: l.num, key: key, canon: canonKey(key), value: value };
      }

      function isWriteLevel(level) {
        if (!level) return false;
        if (level.charAt(0) === "=") return level.indexOf("w") > -1;
        return ["write", "add", "delete", "manage", "selfwrite"].indexOf(level) > -1;
      }
      function isReadLevel(level) {
        if (!level) return false;
        if (level.charAt(0) === "=") return level.indexOf("r") > -1;
        return ["read", "search", "compare"].indexOf(level) > -1;
      }

      function analyzeAcl(e) {
        var v = e.value.replace(/^\{\d+\}\s*/, "");
        var low = v.toLowerCase();
        var res = { entry: e, pattern: v, target: "", clauses: [], parsed: false,
                    starWrite: false, anonWrite: false, starRead: false, anonRead: false };
        var m = low.match(/^\s*to\s+(.+?)\s+by\s+(.*)$/);
        if (!m) return res;
        res.parsed = true;
        res.target = m[1].trim();
        var parts = m[2].split(/\s+by\s+/);
        res.clauses = parts.map(function (c) {
          var toks = c.trim().split(/\s+/);
          return { who: toks[0] || "", level: toks[1] || "" };
        });
        res.clauses.forEach(function (c) {
          if (c.who === "*" && isWriteLevel(c.level)) res.starWrite = true;
          if (c.who === "anonymous" && isWriteLevel(c.level)) res.anonWrite = true;
          if (c.who === "*" && isReadLevel(c.level)) res.starRead = true;
          if (c.who === "anonymous" && isReadLevel(c.level)) res.anonRead = true;
        });
        return res;
      }

      function lineText(lines) {
        if (!lines || !lines.length) return "no line";
        if (lines.length === 1) return "line " + lines[0];
        return "lines " + lines.join(", ");
      }

      function auditConfig(rawText) {
        var findings = [];
        function add(sev, check, key, lines, lt, msg, fix) {
          findings.push({ sev: sev, check: check, key: key, lines: lines, lineText: lt || lineText(lines), msg: msg, fix: fix });
        }
        var text = rawText == null ? "" : String(rawText);
        var style = detectStyle(text);
        var styleLabel = style === "ldif" ? "slapd-config LDIF (cn=config style)" : "slapd.conf (classic style)";
        var parts = splitPhysical(text);
        var entries = logicalLines(parts.kept).map(function (l) { return parseEntry(l, style); });

        // Section tracking: a database directive or an LDIF dn: line opens a section.
        var section = 0, hasBoundary = false;
        entries.forEach(function (e) {
          if (e.canon === "database" || e.canon === "dn") { section++; hasBoundary = true; }
          e.section = section;
        });
        function byCanon(name) { return entries.filter(function (e) { return e.canon === name; }); }

        // Pasted PEM blocks (part of check 5): flagged by block name + line range only.
        parts.pemBlocks.forEach(function (b) {
          var isKey = /PRIVATE KEY/.test(b.type);
          add(isKey ? "BLOCKER" : "WARNING", 5, "PEM block: " + b.type, [b.start, b.end],
            "lines " + b.start + "–" + b.end,
            "A PEM block (" + b.type + ") is pasted inline at lines " + b.start + "–" + b.end + ". Only the block name and line range are reported here — its body is never shown, and slapd reads certificates and keys from files, not from pasted blocks.",
            isKey
              ? "Remove the private key material from config text entirely. Keep the key in a protected file, reference it with TLSCertificateKeyFile, and treat the pasted copy as compromised."
              : "Keep certificate material in files and reference them with TLSCertificateFile / TLSCACertificateFile instead of pasting blocks into a config.");
        });

        if (entries.length === 0) {
          add("BLOCKER", 0, "input", [], "no line",
            "No config to grade — the pasted text is empty or contains only comments.",
            "Paste a slapd.conf or cn=config (LDIF) configuration, then audit again.");
          return finish(findings, styleLabel);
        }

        /* ---- Check 1: root password form ---- */
        var rootpws = byCanon("rootpw");
        var plaintextRootpw = false;
        if (!rootpws.length) {
          add("INFO", 1, "rootpw / olcRootPW", [], "not present",
            "No rootpw / olcRootPW appears in the pasted text. That can be intentional — for example when the root DN authenticates externally or root access is disabled — so it is noted here, not failed.",
            "If a root DN password is used anywhere, store it hashed (from slappasswd), never in cleartext.");
        } else {
          rootpws.forEach(function (e) {
            var v = e.value.trim().replace(/^["']+/, "");
            var m = v.match(/^\{([A-Za-z0-9-]+)\}/);
            if (m && HASH_SCHEMES.indexOf(m[1].toUpperCase()) > -1) {
              add("INFO", 1, e.key, [e.line], null,
                "Hashed rootpw at line " + e.line + " — scheme {" + m[1].toUpperCase() + "}. The hash value itself is never shown.",
                "Keep it hashed, and re-hash with slappasswd if the value is old or has been shared.");
            } else {
              plaintextRootpw = true;
              add("BLOCKER", 1, e.key, [e.line], null,
                "Cleartext rootpw at line " + e.line + " — the value is never shown. A plaintext root password in config text hands full directory control to anyone who can read the file.",
                "Replace it with a hashed value from slappasswd (for example a {SSHA} hash), and restrict read access to the config file.");
            }
          });
        }

        /* ---- ACL analysis (shared by checks 4 and 6) ---- */
        var aclEntries = entries.filter(function (e) { return e.canon === "access"; });
        var acls = aclEntries.map(analyzeAcl);
        var broadWriteAcl = acls.some(function (a) { return a.starWrite || a.anonWrite; });
        var anonWriteAcl = acls.some(function (a) { return a.anonWrite; });

        /* ---- Check 2: unauthenticated binds / requires ---- */
        var requires = entries.filter(function (e) { return e.canon === "require" || e.canon === "requires"; });
        var disallows = entries.filter(function (e) { return e.canon === "disallow" || e.canon === "disallows"; });
        var bindAnonOff = false;
        disallows.forEach(function (e) {
          if (e.value.toLowerCase().indexOf("bind_anon") > -1) {
            bindAnonOff = true;
            add("INFO", 2, e.key, [e.line], null,
              "Anonymous binds are explicitly disabled (" + e.key + " includes bind_anon) at line " + e.line + ".",
              "No change needed on this point.");
          }
        });
        if (requires.length) {
          var reqGood = requires.some(function (e) {
            var v = e.value.toLowerCase();
            return v.indexOf("authc") > -1 || v.indexOf("strong") > -1;
          });
          if (reqGood) {
            add("INFO", 2, requires[0].key, requires.map(function (e) { return e.line; }), null,
              "A require directive demands authenticated binds (authc / strong) — unauthenticated callers are not let through by this text.",
              "No change needed on this point.");
          } else {
            add("WARNING", 2, requires[0].key, requires.map(function (e) { return e.line; }), null,
              "A require directive is present, but nothing in it demands authc or strong authentication, so it does not settle whether unauthenticated binds are accepted.",
              "Add authc (or strong) to require / olcRequires so binds must authenticate.");
          }
        } else if (!bindAnonOff) {
          add("WARNING", 2, "require / olcRequires", [], "not present",
            "Unauthenticated/anonymous binds are not settled by the pasted text — NOT SETTLED from text alone: there is no require / olcRequires directive and no disallow bind_anon protection in what was pasted. Verify the bind posture on the host.",
            "If anonymous binds are not intended, add \"require authc\" (olcRequires: authc) and/or \"disallow bind_anon\" (olcDisallows: bind_anon).");
        }

        /* ---- Check 3: security / SSF posture ---- */
        var secs = byCanon("security");
        if (!secs.length) {
          add("WARNING", 3, "security / olcSecurity", [], "not present",
            "No security / olcSecurity directive in the pasted text — there is no minimum SSF (security strength factor) floor, so weak or unprotected binds may be accepted depending on the host.",
            "Set a floor such as: security ssf=128 simple_bind=128 (LDIF: olcSecurity: ssf=128 simple_bind=128).");
        } else {
          var factors = [];
          secs.forEach(function (e) {
            var low = e.value.toLowerCase();
            var re = /([a-z_]+)\s*=\s*(\d+)/g, mm;
            while ((mm = re.exec(low)) !== null) {
              factors.push({ name: mm[1], val: parseInt(mm[2], 10), line: e.line });
            }
          });
          var secLines = secs.map(function (e) { return e.line; });
          if (!factors.length) {
            add("WARNING", 3, secs[0].key, secLines, null,
              "A security directive is present, but no numeric SSF values could be read from it, so the strength floor cannot be confirmed from the pasted text.",
              "State explicit values, for example: security ssf=128 simple_bind=128.");
          } else {
            var desc = factors.map(function (f) { return f.name + "=" + f.val; }).join(", ");
            var allHigh = factors.every(function (f) { return f.val >= 128; });
            var sbWeak = factors.some(function (f) { return f.name === "simple_bind" && f.val < 64; });
            var ssfZero = factors.some(function (f) { return f.name === "ssf" && f.val === 0; });
            if (allHigh) {
              add("INFO", 3, secs[0].key, secLines, null,
                "Security floor is set at 128 or better (" + desc + ").",
                "No change needed on this point.");
            } else {
              add("WARNING", 3, secs[0].key, secLines, null,
                "Security / SSF values (" + desc + ") fall below a 128-bit floor" +
                  (sbWeak || ssfZero ? ", including a weak minimum (simple_bind below 64 or ssf=0)" : "") +
                  " — binds weaker than the floor you probably intend may be accepted.",
                "Raise the floor to at least 128 for each factor you rely on, for example: security ssf=128 simple_bind=128.");
            }
          }
        }

        /* ---- Check 4: ACL breadth ---- */
        if (!acls.length) {
          add("BLOCKER", 4, "access / olcAccess", [], "not present",
            "No access / olcAccess rules appear in the pasted text. Without explicit rules the built-in default access applies — in classic slapd.conf the default allows read by all — so the directory is effectively world-readable from this text.",
            "Add explicit access rules: protect attrs=userPassword first, then grant the least access each caller needs.");
        } else {
          acls.forEach(function (a) {
            var e = a.entry;
            if (!a.parsed) {
              add("WARNING", 4, e.key, [e.line], null,
                "Access rule at line " + e.line + " could not be split into a \"to … by …\" pattern from the pasted text, so its breadth is NOT SETTLED here.",
                "Review this rule by hand on the host and confirm it grants no broad read or write.");
              return;
            }
            var targetUP = a.target.indexOf("userpassword") > -1;
            var quoted = "\"" + a.pattern + "\"";
            if (a.starWrite) {
              add("BLOCKER", 4, e.key, [e.line], null,
                "World-writable ACL at line " + e.line + ": " + quoted + " — the bare \"*\" principal with write access lets anyone, including unauthenticated callers where binds allow it, modify the entries it covers.",
                "Replace \"by * write\" with named principals (for example \"by users write\" only where truly needed), and end rules with \"by * none\".");
            } else if (a.anonWrite) {
              add("BLOCKER", 4, e.key, [e.line], null,
                "Anonymous-writable ACL at line " + e.line + ": " + quoted + " — unauthenticated callers can write to the entries it covers.",
                "Anonymous access to writable data should be \"auth\" at most (enough to attempt a login), never write.");
            } else if (targetUP && (a.starRead || a.anonRead)) {
              add("BLOCKER", 4, e.key, [e.line], null,
                "Password attribute exposed at line " + e.line + ": " + quoted + " — attrs including userPassword are readable beyond the entry owner, which exposes password hashes to offline guessing.",
                "Use the restrictive pattern: access to attrs=userPassword by self write by anonymous auth by * none.");
            } else if (a.starRead) {
              add("WARNING", 4, e.key, [e.line], null,
                "World-readable ACL at line " + e.line + ": " + quoted + " — the bare \"*\" principal with read access makes the covered entries readable by anyone who can reach the directory.",
                "If public read is not intended, scope it to authenticated users (\"by users read\") and end with \"by * none\".");
            } else if (a.anonRead && a.target === "*") {
              add("WARNING", 4, e.key, [e.line], null,
                "Anonymous-readable ACL at line " + e.line + ": " + quoted + " — unauthenticated callers can read the whole covered tree.",
                "Limit anonymous access to \"auth\" and give read access to named principals instead.");
            } else if (targetUP) {
              add("INFO", 4, e.key, [e.line], null,
                "Restrictive userPassword rule at line " + e.line + ": " + quoted + " — password changes stay with the entry owner and anonymous callers get auth only.",
                "No change needed on this point.");
            } else {
              add("INFO", 4, e.key, [e.line], null,
                "Access rule at line " + e.line + " grants no broad access (no bare \"*\" read or write): " + quoted + ".",
                "No change needed on this point.");
            }
          });
        }

        /* ---- Check 5: TLS certificate directives ---- */
        var certFiles = byCanon("tlscertificatefile");
        var keyFiles = byCanon("tlscertificatekeyfile");
        var caFiles = byCanon("tlscacertificatefile");
        if (certFiles.length && keyFiles.length) {
          add("INFO", 5, certFiles[0].key + " + " + keyFiles[0].key,
            [certFiles[0].line, keyFiles[0].line], null,
            "TLS certificate pair is complete: " + certFiles[0].key + " (line " + certFiles[0].line + ", path as written: " + certFiles[0].value.trim() + ") and " + keyFiles[0].key + " (line " + keyFiles[0].line + ", path as written: " + keyFiles[0].value.trim() + "). Paths are shown; file contents are never read or shown.",
            "Keep the key file readable only by the LDAP service account.");
        } else if (certFiles.length || keyFiles.length) {
          var present = certFiles.length ? certFiles[0] : keyFiles[0];
          var missingName = certFiles.length ? "TLSCertificateKeyFile / olcTLSCertificateKeyFile" : "TLSCertificateFile / olcTLSCertificateFile";
          add("WARNING", 5, present.key, [present.line], null,
            "TLS certificate pair is incomplete: " + present.key + " is present at line " + present.line + ", but " + missingName + " is missing from the pasted text, so TLS cannot be fully configured from this text.",
            "Add the missing " + missingName + " directive so the certificate and its key are configured as a pair.");
        } else {
          var tlsEscalate = plaintextRootpw || anonWriteAcl || broadWriteAcl;
          add(tlsEscalate ? "BLOCKER" : "WARNING", 5, "TLSCertificateFile / olcTLSCertificateFile", [], "not present",
            "No TLS certificate directives in the pasted text — from this text, directory traffic can be plaintext ldap:// only" +
              (tlsEscalate ? ", and this text also contains a cleartext rootpw or a broadly writable ACL, so credentials and changes can cross the wire unprotected." : "."),
            "Configure TLSCertificateFile and TLSCertificateKeyFile (and TLSCACertificateFile for client verification), then require TLS with the security floor.");
        }
        caFiles.forEach(function (e) {
          add("INFO", 5, e.key, [e.line], null,
            "CA certificate file directive present (" + e.key + ", line " + e.line + ", path as written: " + e.value.trim() + ") — the server can verify client certificates and chain trust from this file.",
            "No change needed on this point.");
        });

        /* ---- Check 6: monitor / config database exposure ---- */
        var dbMentions = [];
        entries.forEach(function (e) {
          if (e.canon === "database") {
            var v = e.value.replace(/^\{[^}]*\}/, "").toLowerCase();
            if (/\bmonitor\b/.test(v)) dbMentions.push({ kind: "monitor", e: e });
            else if (/\bconfig\b/.test(v)) dbMentions.push({ kind: "config", e: e });
          } else if (e.canon === "dn") {
            var firstRdn = e.value.toLowerCase().split(",")[0].trim();
            if (firstRdn === "cn=config" || /^olcdatabase=\{?\d+\}?config$/.test(firstRdn) || firstRdn === "olcdatabase=config") {
              dbMentions.push({ kind: "config", e: e });
            } else if (firstRdn === "cn=monitor" || /^olcdatabase=\{?\d+\}?monitor$/.test(firstRdn) || firstRdn === "olcdatabase=monitor") {
              dbMentions.push({ kind: "monitor", e: e });
            }
          }
        });
        if (!dbMentions.length) {
          add("INFO", 6, "database / olcDatabase", [], "not present",
            "No monitor or config database is mentioned in the pasted text — NOT SETTLED: one may live in a file or entry that was not pasted.",
            "On the host, confirm the config (cn=config) and monitor databases carry restrictive access rules of their own.");
        } else {
          dbMentions.forEach(function (mn) {
            var scope = acls.filter(function (a) { return a.entry.section === mn.e.section; });
            if (!scope.length) scope = acls.filter(function (a) { return a.entry.section === 0; });
            var label = mn.kind === "monitor" ? "monitor database" : "config database";
            if (scope.some(function (a) { return a.starWrite || a.anonWrite; })) {
              add("BLOCKER", 6, mn.e.key, [mn.e.line], null,
                "The " + label + " mentioned at line " + mn.e.line + " sits under an ACL that grants write access to everyone or to anonymous callers — whoever reaches it can rewrite server configuration or monitoring data.",
                "Restrict access to the " + label + " to the root DN or a named admin group only, ending with \"by * none\".");
            } else if (!scope.length) {
              add("WARNING", 6, mn.e.key, [mn.e.line], null,
                "The " + label + " mentioned at line " + mn.e.line + " has no access restriction for it in the pasted text — config and monitor databases answer whoever the defaults allow.",
                "Add restrictive access rules for the " + label + " (admin-only, ending with \"by * none\").");
            } else if (scope.some(function (a) { return a.starRead; })) {
              add("WARNING", 6, mn.e.key, [mn.e.line], null,
                "The " + label + " mentioned at line " + mn.e.line + " is covered by an ACL granting read access to the bare \"*\" principal — configuration details should not be world-readable.",
                "Scope read access on the " + label + " to administrators only.");
            } else {
              add("INFO", 6, mn.e.key, [mn.e.line], null,
                "The " + label + " mentioned at line " + mn.e.line + " is covered by access rules in the pasted text that grant no broad read or write. Confirm on the host that those rules are the ones actually applied to this database.",
                "No change needed on this point, beyond the host confirmation.");
            }
          });
        }

        /* ---- Check 7: secret-bearing keys, by key name only ---- */
        entries.forEach(function (e) {
          if (e.canon === "dn" || e.canon === "rootpw") return;
          if (/rootpw|password|secret|token|credential/i.test(e.key)) {
            add("WARNING", 7, e.key, [e.line], null,
              "Secret-bearing key \"" + e.key + "\" at line " + e.line + " — flagged by key name only; its value is never shown anywhere in this report.",
              "Do not paste or share live secret values. Keep secrets in a protected file or secret store and reference them by name.");
          }
        });

        /* ---- Check 8: duplicate singleton directives ---- */
        var singletons = [
          { canon: "rootdn", label: "rootdn / olcRootDN" },
          { canon: "suffix", label: "suffix / olcSuffix" },
          { canon: "tlscertificatefile", label: "TLSCertificateFile / olcTLSCertificateFile" }
        ];
        singletons.forEach(function (s) {
          var groups = {};
          byCanon(s.canon).forEach(function (e) {
            if (!groups[e.section]) groups[e.section] = [];
            groups[e.section].push(e);
          });
          Object.keys(groups).forEach(function (sec) {
            var g = groups[sec];
            if (g.length > 1) {
              var lines = g.map(function (e) { return e.line; });
              add("WARNING", 8, g[0].key, lines, null,
                "Duplicate singleton directive: " + s.label + " appears " + g.length + " times (" + lineText(lines) + ")" +
                  (hasBoundary ? " within the same database section." : " — section attribution NOT SETTLED (no database boundaries appear in the pasted text, so occurrences were counted globally).") +
                  " Which value takes effect is ambiguous from this text.",
                "Keep exactly one " + s.label + " per database and remove the extras.");
            }
          });
        });

        return finish(findings, styleLabel);
      }

      function finish(findings, styleLabel) {
        var b = findings.filter(function (f) { return f.sev === "BLOCKER"; }).length;
        var w = findings.filter(function (f) { return f.sev === "WARNING"; }).length;
        var i = findings.filter(function (f) { return f.sev === "INFO"; }).length;
        var verdict = b > 0 ? "DO NOT DEPLOY" : (w > 0 ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY");

        var out = [];
        out.push("J-Dawgs OpenLDAP Server Config Safety Auditor™ — Report");
        out.push("VERDICT: " + verdict);
        out.push("Blockers: " + b + " · Warnings: " + w + " · Info: " + i);
        out.push("Detected style: " + styleLabel);
        out.push("");
        [["BLOCKER", "BLOCKER FINDINGS"], ["WARNING", "WARNINGS"], ["INFO", "INFO"]].forEach(function (grp) {
          var list = findings.filter(function (f) { return f.sev === grp[0]; });
          out.push(grp[1] + " (" + list.length + ")");
          if (!list.length) out.push("- None");
          list.forEach(function (f) {
            out.push("- [" + f.key + " · " + f.lineText + "] " + f.msg + " Fix: " + f.fix);
          });
          out.push("");
        });
        out.push("What was checked");
        out.push("1. Root password form — rootpw / olcRootPW (values flagged by key name only, never shown)");
        out.push("2. Unauthenticated binds — require / olcRequires, disallow bind_anon / olcDisallows");
        out.push("3. Security / SSF posture — security / olcSecurity");
        out.push("4. ACL breadth — access / olcAccess");
        out.push("5. TLS certificate directives — TLSCertificateFile, TLSCertificateKeyFile, TLSCACertificateFile and olc forms; pasted PEM blocks flagged by name and line range only");
        out.push("6. Monitor / config database exposure — database / olcDatabase, cn=config");
        out.push("7. Secret-bearing keys — flagged by key name and line only, values never shown");
        out.push("8. Duplicate singleton directives — rootdn, suffix, TLSCertificateFile and olc forms");
        out.push("");
        out.push("Graded from pasted text only. This tool never connected to a server and never ran slapd or slaptest. Secret values were flagged by key name only and never shown.");

        return {
          verdict: verdict,
          counts: { blockers: b, warnings: w, infos: i },
          styleLabel: styleLabel,
          findings: findings,
          reportText: out.join("\n")
        };
      }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-openldap-server-config-safety-auditortm',
  name: 'J-Dawgs OpenLDAP Server Config Safety Auditor',
  description: 'slaptest stops at load/convert validity on an installed host; ours grades a pasted slapd.conf or cn=config LDIF offline — rootpw form (value never shown), ACL breadth, SSF floor and TLS posture — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
