'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Stack Trace Triage Bench".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the analyze function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var WORKED_EXAMPLE = [
        "2026-11-03T14:02:11Z INFO  server started on port 8080",
        "2026-11-03T14:02:12Z INFO  health check ok (db pool warm)",
        "2026-11-03T14:03:41Z ERROR [req=a91f] db: connection to postgres at db.internal:5432 refused after 3 retries",
        "2026-11-03T14:03:44Z INFO  retry queue depth 12",
        "2026-11-03T14:04:02Z ERROR [req=b204] db: connection to postgres at db.internal:5432 refused after 3 retries",
        "2026-11-03T14:04:19Z ERROR [req=c77d] db: connection to postgres at db.internal:5432 refused after 3 retries",
        "2026-11-03T14:05:01Z WARN  cache miss rate above threshold",
        "2026-11-03T14:05:33Z ERROR [req=d510] db: connection to postgres at db.internal:5432 refused after 3 retries",
        "2026-11-03T14:06:10Z ERROR [req=e882] request failed: upstream checkout-api returned 503 (timeout after 5000ms)",
        "2026-11-03T14:06:47Z ERROR [req=f019] request failed: upstream checkout-api returned 503 (timeout after 5000ms)",
        "2026-11-03T14:07:22Z ERROR TypeError: Cannot read properties of undefined (reading 'total')",
        "    at computeTotal (src/cart.js:118:17)",
        "    at checkout (src/checkout.js:64:9)",
        "    at handleRequest (src/server.js:210:5)",
        "    at Layer.handle (node_modules/express/lib/router/layer.js:95:5)",
        "    at trimPrefix (node_modules/express/lib/router/index.js:328:13)",
        "2026-11-03T14:08:03Z INFO  shutting down worker 2"
      ].join("\n");

      var CLEAN_EXAMPLE = [
        "2026-11-03T09:14:58Z INFO  worker boot complete",
        "2026-11-03T09:15:00Z ERROR ValueError: invalid literal for int() with base 10: 'abc'"
      ].join("\n");

      var PITCH_TEXT = [
        "AI Tool Store — Tools AIs actually need, built by J-Dawgs: https://muse.ai/s/ai-tool-store-xng6xkxwjkxl2xab/UoF72OkKI7j33Q2ITxmrZyIr4nv40QtYfj2AgESh_k8",
        "J-Dawgs Agent Exchange — Shareware for AIs: https://muse.ai/s/j-dawgs-agent-exchange-ih6xlnihzxdhxc/ZbleqxFHRE0NcswaBkyN13y9lLp5rPAgHTb6t8ii-PY",
        "Ship the Change Safely Stack — SQL Migration Safety Auditor + Diff Intent & Scope Auditor + Stack Trace Triage Bench (vet the migration, vet the diff, triage the fallout)."
      ].join("\n");

      /* ---------- parsing ---------- */

      var RE_LEVEL_ERR = /\b(ERROR|FATAL|CRITICAL|SEVERE)\b/;
      var RE_LEVEL_ANY = /\b(TRACE|DEBUG|INFO|WARN|WARNING|NOTICE|ERROR|FATAL|CRITICAL|SEVERE)\b/;
      var RE_LEVEL_CHAT = /\b(TRACE|DEBUG|INFO|WARN|WARNING|NOTICE)\b/;
      var RE_EXC = /([A-Za-z_$][\w.$]*(?:Error|Exception|Fault|Panic|Throwable))\s*:\s*/;
      var RE_TS_PREFIX = /^\[?\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}(:\d{2}(\.\d+)?)?\s*(Z|[+-]\d{2}:?\d{2})?\]?\s+/;
      var RE_TS_PREFIX2 = /^\[?\d{1,2}:\d{2}(:\d{2})?(\.\d+)?\]?\s+/;
      var RE_SYMPTOM = /(request failed|upstream|downstream|connection refused|timed out|timeout|service unavailable|bad gateway|econnrefused|econnreset|circuit breaker|\b50[234]\b)/i;

      function simpleTypeName(t) {
        var parts = t.split(".");
        return parts[parts.length - 1];
      }

      function stripPrefix(line) {
        var s = line.replace(RE_TS_PREFIX, "").replace(RE_TS_PREFIX2, "");
        return s;
      }

      function extractHeader(rawLine) {
        var s = stripPrefix(rawLine.trim());
        var level = null;
        var lm = s.match(RE_LEVEL_ANY);
        if (lm && s.indexOf(lm[0]) <= 24) level = lm[1];
        var msg = s.replace(/^\[?(TRACE|DEBUG|INFO|WARN|WARNING|ERROR|FATAL|CRITICAL|SEVERE)\]?\s*[:\-]?\s*/, "");
        var type = null;
        var em = msg.match(RE_EXC);
        if (em) {
          type = simpleTypeName(em[1]);
          msg = msg.slice(msg.indexOf(em[0]) + em[0].length);
        }
        return { type: type, level: level, message: msg };
      }

      function normalize(text) {
        var s = String(text);
        s = s.replace(/\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\b/g, "<id>");
        s = s.replace(/\b\d{4}-\d{2}-\d{2}([T ]\d{2}:\d{2}(:\d{2}(\.\d+)?)?(Z|[+-]\d{2}:?\d{2})?)?\b/g, "<ts>");
        s = s.replace(/\b\d{1,2}:\d{2}(:\d{2})?\b/g, "<ts>");
        s = s.replace(/'[^'\n]*'/g, "<val>").replace(/"[^"\n]*"/g, "<val>");
        s = s.replace(/\b0x[0-9a-fA-F]+\b/g, "<hex>");
        s = s.replace(/\b\d{1,3}(\.\d{1,3}){3}(:\d+)?\b/g, "<ip>");
        s = s.replace(/\[([\w .-]+)=([^\]]*)\]/g, "[$1=<id>]");
        s = s.replace(/(?:[A-Za-z]:)?(?:[\w.~-]+\/)+[\w.~-]*/g, "<path>");
        s = s.replace(/\b(?=[0-9a-fA-F]*\d)[0-9a-fA-F]{6,}\b/g, "<hex>");
        s = s.replace(/\b\d[\d,]*(\.\d+)?(?!\d)/g, "<num>");
        s = s.replace(/\s+/g, " ").trim();
        return s;
      }

      function maskSecrets(text) {
        return String(text).replace(/((?:password|passwd|pwd|secret|token|api[-_ ]?key|apikey|authorization|credential)s?\s*[:=]\s*)(\S+)/gi,
          function (m, key, val) {
            if (val.charAt(0) === "<") return m;
            return key + val.slice(0, 4) + "…";
          });
      }

      function displayMessage(text) { return maskSecrets(normalize(text)); }

      function frameName(line) {
        var m = line.match(/^\s*at\s+(.+?)\s*\(/);
        if (m) return m[1].trim();
        m = line.match(/File\s+"[^"]+",\s*line\s+\d+,\s*in\s+(\S+)/);
        if (m) return m[1];
        m = line.match(/^\s*at\s+([\w.$]+)/);
        if (m) return m[1];
        return null;
      }

      function isLibraryFrame(line) {
        return /(node_modules\/|site-packages|\/usr\/lib\/python|java\.base\/|jdk\.internal|sun\.reflect)/.test(line);
      }

      function isContinuation(line, block) {
        if (!block) return false;
        if (/^\s/.test(line)) return true;
        if (/^at\s+\S/.test(line)) return true;
        if (/^File\s+"/.test(line)) return true;
        if (/^\.\.\.\s*\d+\s*more\b/.test(line)) return true;
        return false;
      }

      function isStrongError(line) {
        if (RE_LEVEL_ERR.test(line)) return true;
        if (RE_EXC.test(line)) return true;
        if (/^Exception in thread\b/.test(line)) return true;
        if (/^panic:/.test(line)) return true;
        return false;
      }

      function parseLog(text) {
        var lines = String(text == null ? "" : text).split(/\r?\n/);
        if (lines.length && lines[lines.length - 1] === "") lines.pop();

        var blocks = [];
        var excluded = { blank: 0, chatter: 0, unparsable: 0 };
        var current = null;

        function startBlock(lineNo, rawLine, pythonPending) {
          var b = {
            firstLine: lineNo, lastLine: lineNo,
            errLine: lineNo, errText: rawLine.trim(),
            type: null, level: null, message: "",
            frames: [], frameLines: [], causedBy: [],
            pythonPending: !!pythonPending, headerSet: false
          };
          if (!pythonPending) {
            var h = extractHeader(rawLine);
            b.type = h.type; b.level = h.level; b.message = h.message; b.headerSet = true;
          }
          blocks.push(b);
          current = b;
          return b;
        }

        for (var i = 0; i < lines.length; i++) {
          var lineNo = i + 1;
          var raw = lines[i];
          var line = raw.replace(/\s+$/, "");

          if (line.trim() === "") { excluded.blank++; continue; }

          var cb = line.match(/^\s*Caused by:\s*(.+)$/);
          if (cb && current) {
            current.causedBy.push(cb[1].trim());
            current.lastLine = lineNo;
            continue;
          }

          if (current && current.pythonPending) {
            var fm = line.match(/File\s+"[^"]+",\s*line\s+\d+,\s*in\s+\S+/);
            if (fm || /^\s/.test(line)) {
              var fn = frameName(line);
              if (fn) { current.frames.push(fn); current.frameLines.push(line); }
              current.lastLine = lineNo;
              continue;
            }
            var em2 = line.match(/^([A-Za-z_$][\w.$]*(?:Error|Exception|Fault|Panic|Throwable|Warning|Interrupt))\s*:\s*(.*)$/);
            if (em2) {
              current.type = simpleTypeName(em2[1]);
              current.message = em2[2];
              current.errLine = lineNo;
              current.errText = line.trim();
              current.headerSet = true;
              current.pythonPending = false;
              current.lastLine = lineNo;
              current = null;
              continue;
            }
            /* fall through: traceback never resolved */
            current.type = current.type || "Traceback";
            current.message = current.message || "(traceback with no final exception line in the paste)";
            current.headerSet = true;
            current.pythonPending = false;
            current = null;
          }

          if (/Traceback \(most recent call last\)/.test(line)) {
            startBlock(lineNo, line, true);
            continue;
          }

          if (isContinuation(line, current)) {
            var fn2 = frameName(line);
            if (fn2) { current.frames.push(fn2); current.frameLines.push(line); }
            current.lastLine = lineNo;
            continue;
          }

          if (cb) { /* orphan "Caused by:" with no open block — treat as its own error */
            startBlock(lineNo, line, false);
            continue;
          }

          if (isStrongError(line)) {
            startBlock(lineNo, line, false);
            continue;
          }

          current = null;
          if (RE_LEVEL_CHAT.test(line)) { excluded.chatter++; continue; }
          if (/\b(error|errors|exception|failed|failure|crash|denied|refused|unreachable)\b/i.test(line)) {
            startBlock(lineNo, line, false);
            continue;
          }
          excluded.unparsable++;
        }

        if (current && current.pythonPending) {
          current.type = current.type || "Traceback";
          current.message = current.message || "(traceback with no final exception line in the paste)";
          current.headerSet = true;
          current.pythonPending = false;
        }

        return { blocks: blocks, excluded: excluded, totalLines: lines.length };
      }

      function analyze(text) {
        var parsed = parseLog(text);
        var blocks = parsed.blocks;

        var groupMap = {};
        var order = [];
        blocks.forEach(function (b) {
          var topFrame = null;
          for (var k = 0; k < b.frames.length; k++) {
            if (!isLibraryFrame(b.frameLines[k])) { topFrame = b.frames[k]; break; }
          }
          if (!topFrame && b.frames.length) topFrame = b.frames[0];
          b.topFrame = topFrame;
          var normMsg = displayMessage(b.message || "");
          var typeLabel = b.type || b.level || "Error";
          var key = b.type || b.level || "ERR";
          key += "|" + (topFrame ? "F:" + topFrame : "M:" + normMsg);
          var g = groupMap[key];
          if (!g) {
            g = {
              key: key, type: b.type, level: b.level, typeLabel: typeLabel,
              representative: normMsg,
              display: (b.type ? b.type + ": " : "") + normMsg,
              topFrame: topFrame,
              count: 0, firstLine: b.firstLine, lastLine: b.lastLine,
              occurrences: [], causedByRoot: null, rawSample: b.errText,
              symptom: false
            };
            groupMap[key] = g;
            order.push(g);
          }
          g.count++;
          if (b.firstLine < g.firstLine) g.firstLine = b.firstLine;
          if (b.lastLine > g.lastLine) g.lastLine = b.lastLine;
          g.occurrences.push({ firstLine: b.firstLine, lastLine: b.lastLine });
          if (b.causedBy.length) {
            g.causedByRoot = displayMessage(b.causedBy[b.causedBy.length - 1]);
          }
        });

        var groups = order.slice().sort(function (a, b) {
          if (b.count !== a.count) return b.count - a.count;
          return a.firstLine - b.firstLine;
        });
        groups.forEach(function (g, idx) { g.rank = idx + 1; });

        if (groups.length > 1) {
          var earliest = Math.min.apply(null, groups.map(function (g) { return g.firstLine; }));
          groups.forEach(function (g) {
            if (g.firstLine > earliest && RE_SYMPTOM.test(g.rawSample + " " + g.representative)) {
              g.symptom = true;
            }
          });
        }

        var firstError = null;
        if (blocks.length) {
          var fb = blocks.slice().sort(function (a, b) { return a.firstLine - b.firstLine; })[0];
          firstError = { line: fb.errLine, text: maskSecrets(fb.errText) };
        }

        var totalErrors = blocks.length;
        var headline;
        if (totalErrors === 0) headline = "0 errors → 0 groups";
        else headline = totalErrors + (totalErrors === 1 ? " error" : " errors") + " → " +
          groups.length + (groups.length === 1 ? " group" : " groups") + "; fix group 1 first";

        return {
          headline: headline,
          totalErrors: totalErrors,
          totalLines: parsed.totalLines,
          groups: groups,
          firstError: firstError,
          excluded: parsed.excluded,
          excludedTotal: parsed.excluded.blank + parsed.excluded.chatter + parsed.excluded.unparsable
        };
      }

      /* ---------- rendering ---------- */

      function esc(s) {
        return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
          .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
      }

      function buildReport(r) {
        var out = [];
        out.push("J-Dawgs Stack Trace Triage Bench — triage report");
        out.push(r.headline);
        out.push("");
        if (r.firstError) {
          out.push("First error (line " + r.firstError.line + "):");
          out.push(r.firstError.text);
          out.push("");
        }
        if (r.groups.length) {
          out.push("Groups (ranked by count, then first seen):");
          r.groups.forEach(function (g) {
            var lineRange = g.firstLine === g.lastLine ? ("line " + g.firstLine) : ("lines " + g.firstLine + "–" + g.lastLine);
            var s = g.rank + ". [×" + g.count + "] " + lineRange + " — " + g.display;
            if (g.topFrame) s += "  (top frame: " + g.topFrame + ")";
            out.push(s);
            if (g.symptom) out.push("   LIKELY SYMPTOM — CANDIDATE (appears after an earlier group and matches a downstream symptom pattern; a candidate, not a proven cause)");
            if (g.causedByRoot) out.push("   Caused-by root: " + g.causedByRoot);
          });
          out.push("");
        } else {
          out.push("No errors found in the paste.");
          out.push("");
        }
        out.push("Excluded lines: " + r.excludedTotal + " of " + r.totalLines +
          " (INFO/DEBUG/WARN chatter: " + r.excluded.chatter +
          ", blank: " + r.excluded.blank +
          ", unparsable: " + r.excluded.unparsable + ")");
        out.push("");
        out.push("Note: grouping is heuristic text analysis of the pasted text only. Ordering in a paste is evidence, not proof of causation.");
        return out.join("\n");
      }

      function buildJson(r) {
        return {
          tool: "J-Dawgs Stack Trace Triage Bench",
          source: "pasted text only — no live logs read",
          headline: r.headline,
          totalErrors: r.totalErrors,
          totalGroups: r.groups.length,
          totalLines: r.totalLines,
          firstError: r.firstError,
          groups: r.groups.map(function (g) {
            return {
              rank: g.rank,
              type: g.typeLabel,
              representativeMessage: g.display,
              topFrame: g.topFrame,
              count: g.count,
              firstSeenLine: g.firstLine,
              lastSeenLine: g.lastLine,
              occurrences: g.occurrences,
              causedByRoot: g.causedByRoot,
              labels: g.symptom ? ["LIKELY SYMPTOM — CANDIDATE"] : []
            };
          }),
          excluded: {
            total: r.excludedTotal,
            chatter: r.excluded.chatter,
            blank: r.excluded.blank,
            unparsable: r.excluded.unparsable
          },
          notes: [
            "Grouping is heuristic text analysis of the pasted blob only.",
            "Ordering in a paste is evidence, not proof of causation; LIKELY SYMPTOM — CANDIDATE is never a proven cause."
          ]
        };
      }
  return { "analyze": (typeof analyze !== 'undefined' ? analyze : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "WORKED_EXAMPLE": (typeof WORKED_EXAMPLE !== 'undefined' ? WORKED_EXAMPLE : undefined), "CLEAN_EXAMPLE": (typeof CLEAN_EXAMPLE !== 'undefined' ? CLEAN_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["analyze"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-stack-trace-triage-bench',
  name: 'J-Dawgs Stack Trace Triage Bench',
  description: 'Groups a pasted error-log blob by root signature — ranked groups, a first-error callout, and LIKELY SYMPTOM candidates labeled as evidence, not proof — with a copyable report and JSON export',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["analyze"]) return { ok: false, output: null, summary: 'Extracted core has no analyze function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "WORKED_EXAMPLE": __core["WORKED_EXAMPLE"], "CLEAN_EXAMPLE": __core["CLEAN_EXAMPLE"] }
};
