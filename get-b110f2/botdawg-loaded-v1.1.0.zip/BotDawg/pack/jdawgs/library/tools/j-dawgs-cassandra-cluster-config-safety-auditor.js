'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Cassandra Cluster Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var RISKY = [
          "# cassandra.yaml — small cluster node, rushed setup",
          "cluster_name: 'Risky Cluster'",
          "num_tokens: 256",
          "seed_provider:",
          "  - class_name: org.apache.cassandra.locator.SimpleSeedProvider",
          "    parameters:",
          '      - seeds: "10.0.0.11"',
          "listen_address: 0.0.0.0",
          "rpc_address: 0.0.0.0",
          "broadcast_address: 10.0.0.11",
          "authenticator: AllowAllAuthenticator",
          "authorizer: AllowAllAuthorizer",
          "endpoint_snitch: SimpleSnitch",
          "server_encryption_options:",
          "  internode_encryption: none",
          "  keystore: conf/.keystore",
          "  keystore_password: cassandra",
          "  truststore: conf/.truststore",
          "  truststore_password: cassandra",
          "client_encryption_options:",
          "  enabled: false",
          "  keystore: conf/.keystore",
          "  keystore_password: cassandra"
        ].join("\n");

        var CLEAN = [
          "# cassandra.yaml — production node",
          "cluster_name: 'Production Cluster'",
          "num_tokens: 256",
          "seed_provider:",
          "  - class_name: org.apache.cassandra.locator.SimpleSeedProvider",
          "    parameters:",
          '      - seeds: "10.0.0.11,10.0.0.12"',
          "listen_address: 10.0.0.11",
          "rpc_address: 10.0.0.11",
          "broadcast_address: 10.0.0.11",
          "authenticator: PasswordAuthenticator",
          "authorizer: CassandraAuthorizer",
          "endpoint_snitch: GossipingPropertyFileSnitch",
          "server_encryption_options:",
          "  internode_encryption: all",
          "  keystore: conf/.keystore",
          "  truststore: conf/.truststore",
          "client_encryption_options:",
          "  enabled: true",
          "  keystore: conf/.keystore"
        ].join("\n");

        var PITCH = "Bind It, Auth It, Prove It Stack — InfluxDB Server Config Safety Auditor + Cassandra Cluster Config Safety Auditor + Trial & Subscription Terms Consistency Auditor: grade the time-series store, grade the cluster, cross-check the trial terms before anyone signs up.\n\nAI Tool Store: https://muse.ai/s/ai-tool-store-xng6xkxwjkxl2xab/UoF72OkKI7j33Q2ITxmrZyIr4nv40QtYfj2AgESh_k8\nJ-Dawgs Agent Exchange: https://muse.ai/s/j-dawgs-agent-exchange-ih6xlnihzxdhxc/ZbleqxFHRE0NcswaBkyN13y9lLp5rPAgHTb6t8ii-PY";

        var AUDITED_TOP = {
          listen_address: 1, rpc_address: 1, broadcast_address: 1, broadcast_rpc_address: 1,
          authenticator: 1, authorizer: 1, seed_provider: 1, endpoint_snitch: 1,
          num_tokens: 1, client_encryption_options: 1, server_encryption_options: 1
        };

        function $(id) { return document.getElementById(id); }

        function isSecretKey(key) {
          var k = key.toLowerCase();
          if (k === "num_tokens") return false;
          return k.indexOf("password") !== -1 || k.indexOf("secret") !== -1 || k.indexOf("token") !== -1;
        }

        function stripQuotes(v) {
          v = v.trim();
          if (v.length >= 2) {
            var a = v.charAt(0), b = v.charAt(v.length - 1);
            if ((a === '"' && b === '"') || (a === "'" && b === "'")) return v.slice(1, -1);
          }
          return v;
        }

        // Remove an inline " # comment" that sits outside quotes.
        function stripComment(line) {
          var inS = false, inD = false;
          for (var i = 0; i < line.length; i++) {
            var c = line.charAt(i);
            if (c === "'" && !inD) inS = !inS;
            else if (c === '"' && !inS) inD = !inD;
            else if (c === "#" && !inS && !inD && (i === 0 || /\s/.test(line.charAt(i - 1)))) {
              return line.slice(0, i);
            }
          }
          return line;
        }

        function classifyAddr(v) {
          if (!v) return "empty";
          var s = v.toLowerCase();
          if (s === "localhost" || s === "::1" || s === "[::1]" || s.indexOf("127.") === 0) return "loopback";
          if (s === "0.0.0.0" || s === "::" || s === "[::]") return "wildcard";
          return "external";
        }

        function parse(text) {
          var rawLines = text.split(/\r?\n/);
          var entries = [];      // {key, value(raw display-safe unless secret), line, parent, top}
          var malformed = [];    // {line}
          var stack = [];        // {indent, key}
          for (var n = 0; n < rawLines.length; n++) {
            var lineNo = n + 1;
            var raw = rawLines[n];
            var line = stripComment(raw).replace(/\s+$/, "");
            var trimmed = line.replace(/^\s+/, "");
            if (!trimmed) continue;
            var indent = line.length - trimmed.length;
            var body = trimmed;
            var effIndent = indent;
            if (body.charAt(0) === "-") {
              // YAML list item: "- key: value" or "- value"
              var afterDash = body.replace(/^-\s*/, "");
              effIndent = indent + 2;
              if (!/^[A-Za-z0-9_.\-]+\s*:/.test(afterDash)) {
                continue; // plain list value (e.g. a seed IP) — part of the key above it
              }
              body = afterDash;
            }
            var m = body.match(/^([A-Za-z0-9_.\-]+)\s*:\s*(.*)$/);
            if (!m) { malformed.push({ line: lineNo }); continue; }
            while (stack.length && stack[stack.length - 1].indent >= effIndent) stack.pop();
            var parent = stack.length ? stack[stack.length - 1].key : null;
            entries.push({
              key: m[1],
              keyLower: m[1].toLowerCase(),
              value: stripQuotes(m[2].trim()),
              line: lineNo,
              parent: parent,
              top: parent === null
            });
            stack.push({ indent: effIndent, key: m[1].toLowerCase() });
          }
          return { entries: entries, malformed: malformed, totalLines: rawLines.length };
        }

        // Last occurrence wins (Cassandra semantics), matching how checks read values.
        function lastEntry(entries, keyLower, parentLower) {
          var found = null;
          for (var i = 0; i < entries.length; i++) {
            var e = entries[i];
            if (e.keyLower === keyLower && (parentLower === undefined || e.parent === parentLower)) found = e;
          }
          return found;
        }

        function audit(text) {
          var parsed = parse(text);
          var entries = parsed.entries;
          var findings = [];
          function add(sev, key, lines, msg, fix) {
            findings.push({ sev: sev, key: key, lines: lines, msg: msg, fix: fix || null });
          }

          // --- Malformed lines ---
          parsed.malformed.forEach(function (mf) {
            add("NOT PARSED", "(line " + mf.line + ")", [mf.line],
              "This line is not a key: value line and could not be read by this line audit. If Cassandra cannot read it either, the node will refuse to start — check it by hand.",
              "Fix or remove line " + mf.line + " so it is a valid YAML key: value line, a list item, or a comment.");
          });

          // --- Duplicate keys (scoped to their section; last value wins) ---
          var seen = {};
          entries.forEach(function (e) {
            var scope = (e.parent || "") + "|" + e.keyLower;
            if (!seen[scope]) seen[scope] = [];
            seen[scope].push(e);
          });
          Object.keys(seen).forEach(function (scope) {
            var list = seen[scope];
            if (list.length > 1) {
              var lines = list.map(function (e) { return e.line; });
              var last = list[list.length - 1];
              var secret = isSecretKey(last.key);
              add("WARNING", last.key, lines,
                "Key '" + last.key + "' is set " + list.length + " times (lines " + lines.join(", ") + "). Cassandra keeps the last value (line " + last.line + ")" + (secret ? "" : ": '" + last.value + "'") + " — the earlier setting is silently ignored.",
                "Delete the duplicate '" + last.key + "' lines and keep only the value you mean, at line " + last.line + ".");
            }
          });

          // --- Secret-looking keys: name + line only, never the value ---
          entries.forEach(function (e) {
            if (isSecretKey(e.key)) {
              add("WARNING", e.key, [e.line],
                "Secret-bearing key '" + e.key + "' is set in plain config text at line " + e.line + ". Its value is intentionally not shown anywhere in this audit or report.",
                "Move the '" + e.key + "' secret out of the plain file where you can (secret store / restricted file permissions) and rotate it if this file was ever shared.");
            }
          });

          // --- Bind addresses ---
          var bindKeys = ["listen_address", "rpc_address", "broadcast_address", "broadcast_rpc_address"];
          var binds = {}; // key -> {entry, cls}
          var anyNonLoopback = false, nonLoopbackList = [];
          bindKeys.forEach(function (bk) {
            var e = lastEntry(entries, bk);
            if (e) {
              var cls = classifyAddr(e.value);
              binds[bk] = { entry: e, cls: cls };
              if (cls === "wildcard" || cls === "external") { anyNonLoopback = true; nonLoopbackList.push(bk + " (line " + e.line + ")"); }
              if (cls === "wildcard") {
                add("INFO", bk, [e.line], bk + " is " + e.value + " — it binds every network interface on the host. That is only as safe as the authentication and encryption paired with it (checked below).", null);
              } else if (cls === "loopback") {
                add("OK", bk, [e.line], bk + " is " + e.value + " — loopback only; other hosts cannot reach this address directly.", null);
              }
            }
          });

          // --- Authenticator / authorizer ---
          var authn = lastEntry(entries, "authenticator");
          var authz = lastEntry(entries, "authorizer");
          var allowAllN = authn && /allowallauthenticator/i.test(authn.value);
          var allowAllZ = authz && /allowallauthorizer/i.test(authz.value);

          if (!authn) {
            add("NOT SETTLED", "authenticator", [],
              "No authenticator is set in the pasted text. Cassandra's default differs by version (older releases default to AllowAllAuthenticator, which lets anyone connect), so this audit will not call an absent authenticator safe.",
              "Set authenticator: PasswordAuthenticator (or your identity-backed authenticator) explicitly — never rely on the version default.");
          } else if (allowAllN) {
            if (anyNonLoopback) {
              add("BLOCKER", "authenticator", [authn.line],
                "authenticator is AllowAllAuthenticator — anyone who can reach the node logs in with no password — and the node binds beyond loopback (" + nonLoopbackList.join(", ") + "). That pairing is an open database.",
                "Set authenticator: PasswordAuthenticator and create real roles before this node is reachable by anything untrusted.");
            } else {
              add("WARNING", "authenticator", [authn.line],
                "authenticator is AllowAllAuthenticator — no login is checked at all. Right now every bind address found is loopback, so this is a warning, not a blocker — but the moment any bind address opens beyond loopback, this becomes an open database. Treat it as one bind change away from a blocker.",
                "Set authenticator: PasswordAuthenticator even for local development, so the habit and the config are production-shaped.");
            }
          } else {
            add("OK", "authenticator", [authn.line], "authenticator is " + authn.value + " — logins are checked; not the allow-all setting.", null);
          }

          if (!authz) {
            add("NOT SETTLED", "authorizer", [],
              "No authorizer is set in the pasted text. Cassandra's default differs by version (older releases default to AllowAllAuthorizer, which grants every permission), so an absent authorizer is never called safe here — an authenticated user could still hold every permission.",
              "Set authorizer: CassandraAuthorizer explicitly and grant permissions per role.");
          } else if (allowAllZ) {
            if (anyNonLoopback) {
              add("BLOCKER", "authorizer", [authz.line],
                "authorizer is AllowAllAuthorizer — every connected user holds every permission — and the node binds beyond loopback (" + nonLoopbackList.join(", ") + "). Anyone who connects owns the data.",
                "Set authorizer: CassandraAuthorizer and grant each role only the permissions it needs.");
            } else {
              add("WARNING", "authorizer", [authz.line],
                "authorizer is AllowAllAuthorizer — every user holds every permission. All bind addresses found are loopback, so this is a warning for now; it escalates to a blocker the moment any bind opens beyond loopback.",
                "Set authorizer: CassandraAuthorizer and scope permissions per role.");
            }
          } else {
            add("OK", "authorizer", [authz.line], "authorizer is " + authz.value + " — permissions are enforced per role; not the allow-all setting.", null);
          }

          // --- Client encryption ---
          var clientSection = lastEntry(entries, "client_encryption_options");
          var clientEnabled = lastEntry(entries, "enabled", "client_encryption_options");
          var rpcBind = binds["rpc_address"];
          var rpcExternal = rpcBind && (rpcBind.cls === "wildcard" || rpcBind.cls === "external");
          if (!clientSection) {
            add("NOT SETTLED", "client_encryption_options", [],
              "No client_encryption_options section appears in the pasted text, so whether client-to-node traffic is encrypted is not settled by this file excerpt.",
              "Add a client_encryption_options section with enabled: true and a valid keystore before clients connect over any shared network.");
          } else if (clientEnabled) {
            var ceVal = clientEnabled.value.toLowerCase();
            if (ceVal === "false") {
              if (rpcExternal) {
                add("BLOCKER", "client_encryption_options.enabled", [clientEnabled.line],
                  "client_encryption_options enabled is false — client traffic is plaintext — while rpc_address binds beyond loopback (line " + rpcBind.entry.line + "). Credentials and data cross the network in the clear to anyone who can listen.",
                  "Set client_encryption_options enabled: true with a valid keystore, and require client encryption before exposing rpc_address.");
              } else {
                add("WARNING", "client_encryption_options.enabled", [clientEnabled.line],
                  "client_encryption_options enabled is false — client-to-node traffic is not encrypted. Binds found are loopback-only, so this is a warning; it becomes a blocker if rpc_address opens beyond loopback.",
                  "Set client_encryption_options enabled: true with a valid keystore.");
              }
            } else if (ceVal === "true") {
              add("OK", "client_encryption_options.enabled", [clientEnabled.line], "Client-to-node encryption is enabled.", null);
            } else {
              add("REVIEW", "client_encryption_options.enabled", [clientEnabled.line],
                "client_encryption_options enabled reads '" + clientEnabled.value + "', which this audit cannot settle as true or false — check the value by hand.",
                "Set client_encryption_options enabled explicitly to true or false.");
            }
          } else {
            add("NOT SETTLED", "client_encryption_options.enabled", [clientSection.line],
              "client_encryption_options is present but no enabled line was found under it in the pasted text, so client encryption is not settled.",
              "Add enabled: true under client_encryption_options with a valid keystore.");
          }

          // --- Internode (server) encryption ---
          var serverSection = lastEntry(entries, "server_encryption_options");
          var internode = lastEntry(entries, "internode_encryption", "server_encryption_options");
          if (!serverSection && !internode) {
            add("NOT SETTLED", "server_encryption_options", [],
              "No server_encryption_options / internode_encryption setting appears in the pasted text, so node-to-node encryption is not settled — in many versions the default leaves internode traffic unencrypted.",
              "Set server_encryption_options internode_encryption: all so node-to-node traffic is encrypted everywhere.");
          } else if (internode) {
            var iv = internode.value.toLowerCase();
            if (iv === "none") {
              add("WARNING", "internode_encryption", [internode.line],
                "internode_encryption is none — node-to-node traffic (including replicated data and credentials passed between nodes) is plaintext on the network.",
                "Set internode_encryption: all and roll the keystore/truststore out to every node.");
            } else if (iv === "all") {
              add("OK", "internode_encryption", [internode.line], "internode_encryption is all — node-to-node traffic is encrypted in both directions, everywhere.", null);
            } else if (iv === "dc" || iv === "rack") {
              add("INFO", "internode_encryption", [internode.line],
                "internode_encryption is " + iv + " — encryption is partial by design (across " + (iv === "dc" ? "data centers" : "racks") + " only). Traffic inside the same " + (iv === "dc" ? "data center" : "rack") + " stays plaintext; that is a deliberate trade-off to confirm, not an error.",
                null);
            } else {
              add("REVIEW", "internode_encryption", [internode.line],
                "internode_encryption reads '" + internode.value + "', which is not one of none / all / dc / rack that this audit can grade — check it by hand.",
                "Set internode_encryption to one of: all, dc, rack, none (all is the safe default).");
            }
          } else {
            add("NOT SETTLED", "internode_encryption", [serverSection.line],
              "server_encryption_options is present but no internode_encryption line was found under it, so node-to-node encryption is not settled.",
              "Add internode_encryption: all under server_encryption_options.");
          }

          // --- Seeds ---
          var seedsEntry = lastEntry(entries, "seeds");
          var seedList = [];
          if (!seedsEntry) {
            add("BLOCKER", "seed_provider seeds", [],
              "No seeds line was found under seed_provider in the pasted text. Without seeds a node has nobody to gossip with and cannot join or form a cluster.",
              "Add seed_provider with a seeds list naming at least two stable nodes (for a multi-node cluster).");
          } else if (!seedsEntry.value) {
            add("BLOCKER", "seed_provider seeds", [seedsEntry.line],
              "The seeds list at line " + seedsEntry.line + " is empty. A node with no seeds cannot join a cluster.",
              "Fill the seeds list with the addresses of at least two stable seed nodes.");
          } else {
            seedList = seedsEntry.value.split(",").map(function (s) { return s.trim(); }).filter(function (s) { return s.length > 0; });
            if (seedList.length === 0) {
              add("BLOCKER", "seed_provider seeds", [seedsEntry.line],
                "The seeds list at line " + seedsEntry.line + " contains no addresses. A node with no seeds cannot join a cluster.",
                "Fill the seeds list with the addresses of at least two stable seed nodes.");
            } else if (seedList.length === 1) {
              add("INFO", "seed_provider seeds", [seedsEntry.line],
                "Exactly one seed is listed (" + seedList[0] + "). A single seed is a single point of failure for bootstrapping: if it is down, new and restarted nodes may not be able to join. Two or three seeds is the usual practice.",
                "List two or three stable nodes as seeds on every node.");
            } else {
              add("OK", "seed_provider seeds", [seedsEntry.line], seedList.length + " seeds listed — no single seed point of failure for bootstrapping.", null);
            }
            // Seed vs own-address consistency
            if (seedList.length > 0) {
              var ownAddrs = [];
              ["listen_address", "broadcast_address"].forEach(function (k) {
                if (binds[k] && binds[k].cls !== "wildcard" && binds[k].cls !== "empty") ownAddrs.push(binds[k].entry.value);
              });
              if (ownAddrs.length > 0) {
                var matched = ownAddrs.some(function (a) { return seedList.indexOf(a) !== -1; });
                if (!matched) {
                  add("REVIEW", "seed_provider seeds", [seedsEntry.line],
                    "None of the seeds (" + seedList.join(", ") + ") matches this node's listen_address or broadcast_address (" + ownAddrs.join(", ") + "). That can be correct — seeds are other nodes — but if this node is meant to be a seed itself, its own address is missing from the list; either way it is worth a human look before deploy.",
                    "Confirm the seed list names the intended seed nodes, and that every node carries the same seed list.");
                }
              }
            }
          }

          // --- Endpoint snitch ---
          var snitch = lastEntry(entries, "endpoint_snitch");
          if (snitch) {
            if (/simplesnitch/i.test(snitch.value)) {
              if (seedList.length > 1) {
                add("WARNING", "endpoint_snitch", [snitch.line],
                  "endpoint_snitch is SimpleSnitch in a multi-node setup (" + seedList.length + " seeds). SimpleSnitch does not know racks or data centers, so replicas can land on the same rack and a single rack failure can take out every copy of some data.",
                  "Use GossipingPropertyFileSnitch (or a cloud snitch) and declare each node's rack and data center.");
              } else {
                add("INFO", "endpoint_snitch", [snitch.line],
                  "endpoint_snitch is SimpleSnitch. It ignores racks and data centers — acceptable for a single node, a problem for a real cluster.",
                  null);
              }
            } else {
              add("OK", "endpoint_snitch", [snitch.line], "endpoint_snitch is " + snitch.value + " — rack/datacenter aware.", null);
            }
          } else {
            add("INFO", "endpoint_snitch", [],
              "No endpoint_snitch in the pasted text; the version default applies (SimpleSnitch in most versions), which ignores racks and data centers.",
              null);
          }

          // --- num_tokens (informational; explicitly NOT treated as a secret) ---
          var nt = lastEntry(entries, "num_tokens");
          if (nt) {
            add("INFO", "num_tokens", [nt.line],
              "num_tokens is " + nt.value + ". Noted for the record — it shapes token distribution and is painful to change later on a live cluster, but it is not a safety finding. (num_tokens is a token count, not a secret, and is never treated as one here.)",
              null);
          }

          // --- Keys not audited ---
          var notAudited = [];
          entries.forEach(function (e) {
            if (e.top && !AUDITED_TOP[e.keyLower] && notAudited.indexOf(e.key) === -1) notAudited.push(e.key);
          });
          if (notAudited.length > 0) {
            add("NOT AUDITED", notAudited.join(", "), [],
              "These top-level keys were seen but are not graded by this audit: " + notAudited.join(", ") + ". Performance and storage tuning keys (for example concurrent_reads / concurrent_writes, commitlog and data directory settings, ports) are outside its checks — no verdict here says anything about them, good or bad.",
              null);
          }

          // --- Verdict ---
          var counts = { blocker: 0, warning: 0, unsettled: 0, info: 0, ok: 0 };
          findings.forEach(function (f) {
            if (f.sev === "BLOCKER") counts.blocker++;
            else if (f.sev === "WARNING" || f.sev === "REVIEW" || f.sev === "NOT SETTLED" || f.sev === "NOT PARSED") counts.warning++;
            if (f.sev === "NOT SETTLED" || f.sev === "REVIEW" || f.sev === "NOT PARSED") counts.unsettled++;
            if (f.sev === "INFO" || f.sev === "NOT AUDITED") counts.info++;
            if (f.sev === "OK") counts.ok++;
          });
          var verdict, vClass, vSub;
          if (counts.blocker > 0) {
            verdict = "DO NOT DEPLOY"; vClass = "danger";
            vSub = counts.blocker + " blocker finding" + (counts.blocker === 1 ? "" : "s") + " — settings that would expose this cluster or stop it joining. Fix every blocker before this config goes near a real node.";
          } else if (counts.warning > 0) {
            verdict = "DEPLOY WITH FIXES"; vClass = "fixes";
            vSub = "No blockers, but " + counts.warning + " finding" + (counts.warning === 1 ? "" : "s") + " need" + (counts.warning === 1 ? "s" : "") + " fixing or settling first — warnings, unsettled settings, and lines that did not parse are listed below.";
          } else {
            verdict = "SAFE TO DEPLOY"; vClass = "safe";
            vSub = "No blockers, no warnings, nothing unsettled in the settings this audit grades. The honest limits below still apply — this verdict covers the pasted text, not the live cluster.";
          }

          var rank = { "BLOCKER": 0, "WARNING": 1, "NOT SETTLED": 2, "REVIEW": 3, "NOT PARSED": 4, "INFO": 5, "NOT AUDITED": 6, "OK": 7 };
          findings.sort(function (a, b) {
            var d = rank[a.sev] - rank[b.sev];
            if (d !== 0) return d;
            var la = a.lines.length ? a.lines[0] : 9999, lb = b.lines.length ? b.lines[0] : 9999;
            return la - lb;
          });

          return { verdict: verdict, vClass: vClass, vSub: vSub, counts: counts, findings: findings, keyCount: entries.length };
        }

        function lineLabel(f) {
          if (!f.lines.length) return "no line — setting absent";
          if (f.lines.length === 1) return "line " + f.lines[0];
          return "lines " + f.lines.join(", ");
        }

        function buildReport(r) {
          var out = [];
          out.push("J-Dawgs Cassandra Cluster Config Safety Auditor™ — Audit Report");
          out.push("Verdict: " + r.verdict);
          out.push("Counts: " + r.counts.blocker + " blocker(s), " + r.counts.warning + " warning/unsettled finding(s), " + r.counts.info + " info, " + r.counts.ok + " OK check(s); " + r.keyCount + " key line(s) read.");
          out.push("");
          out.push("Findings:");
          r.findings.forEach(function (f) {
            out.push("[" + f.sev + "] " + f.key + " — " + lineLabel(f));
            out.push("  " + f.msg);
            if (f.fix) out.push("  Fix: " + f.fix);
          });
          var fixes = r.findings.filter(function (f) { return f.fix; });
          if (fixes.length) {
            out.push("");
            out.push("Fix list:");
            fixes.forEach(function (f, i) { out.push((i + 1) + ". (" + f.sev + ") " + f.fix); });
          }
          out.push("");
          out.push("Limits: heuristic line audit of pasted text — not a full YAML parser, never starts a node, cannot verify cluster state. Absent security settings are reported NOT SETTLED, never safe. Secret values are never printed in this report.");
          out.push("Generated in the browser with the J-Dawgs Cassandra Cluster Config Safety Auditor™. Nothing was uploaded or saved.");
          return out.join("\n");
        }

        var lastReport = "";
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-cassandra-cluster-config-safety-auditor',
  name: 'J-Dawgs Cassandra Cluster Config Safety Auditor',
  description: 'Grades a pasted cassandra.yaml offline — AllowAll auth paired with bind exposure, encryption, seed consistency, secrets by key name and line only — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
