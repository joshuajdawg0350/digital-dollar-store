'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs HTTP Response Header Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var SECRET_HEADERS = {
          "set-cookie": true, "authorization": true, "proxy-authorization": true,
          "cookie": true, "x-api-key": true, "x-auth-token": true
        };
        var HSTS_FLOOR = 15552000;

        var EXAMPLE_BAD = [
          "HTTP/1.1 200 OK",
          "Server: Apache/2.4.41 (Ubuntu)",
          "Content-Type: text/html; charset=UTF-8",
          "Content-Security-Policy: default-src 'self'",
          "Referrer-Policy: strict-origin-when-cross-origin",
          "Permissions-Policy: camera=(), microphone=(), geolocation=()",
          "Cache-Control: public, max-age=3600",
          "X-Frame-Options: DENY",
          "X-Frame-Options: SAMEORIGIN",
          "Set-Cookie: session_id=9f2ac41bd7e84c0a; Path=/; HttpOnly"
        ].join("\n");

        var EXAMPLE_CLEAN = [
          "HTTP/1.1 200 OK",
          "Content-Type: text/html; charset=UTF-8",
          "Server: Apache",
          "Strict-Transport-Security: max-age=63072000; includeSubDomains; preload",
          "Content-Security-Policy: default-src 'self'; frame-ancestors 'none'",
          "X-Content-Type-Options: nosniff",
          "Referrer-Policy: strict-origin-when-cross-origin",
          "Permissions-Policy: camera=(), microphone=(), geolocation=()",
          "Cache-Control: no-store"
        ].join("\n");

        var $ = function (id) { return document.getElementById(id); };
        var input = $("input"), ctxSensitive = $("ctxSensitive"), ctxHtml = $("ctxHtml");

        function parseHeaders(text) {
          var headers = [], bad = 0;
          var lines = String(text).replace(/\r\n?/g, "\n").split("\n");
          for (var i = 0; i < lines.length; i++) {
            var raw = lines[i], line = raw.trim();
            if (!line) continue;
            if (/^HTTP\/\d/i.test(line) && line.indexOf(":") === -1) continue; /* status line */
            if ((raw.charAt(0) === " " || raw.charAt(0) === "\t") && headers.length) {
              headers[headers.length - 1].value += " " + line; /* folded continuation */
              continue;
            }
            var idx = line.indexOf(":");
            if (idx <= 0) { bad++; continue; }
            var name = line.slice(0, idx).trim();
            if (!/^[!#$%&'*+\-.^_`|~0-9A-Za-z]+$/.test(name)) { bad++; continue; }
            headers.push({ name: name, key: name.toLowerCase(), value: line.slice(idx + 1).trim() });
          }
          return { headers: headers, bad: bad };
        }

        function all(headers, key) {
          return headers.filter(function (h) { return h.key === key; });
        }
        function shown(h) { return SECRET_HEADERS[h.key] ? "[redacted]" : h.value; }
        function norm(v) { return v.replace(/\s+/g, " ").trim().toLowerCase(); }

        function audit(text, sensitive, isHtml) {
          var parsed = parseHeaders(text);
          var headers = parsed.headers;
          var F = []; /* findings */
          function add(header, sev, why, fix, fixLine, receipt, notFixed) {
            F.push({ header: header, sev: sev, why: why, fix: fix || "—",
                     fixLine: fixLine || null, receipt: receipt || null, notFixed: notFixed || null });
          }

          /* ---- (1) Strict-Transport-Security ---- */
          var hsts = all(headers, "strict-transport-security");
          if (!hsts.length) {
            add("Strict-Transport-Security", sensitive ? "BLOCKER" : "WARNING",
              sensitive
                ? "Missing on a response that handles login, payment, or session cookies — without HSTS a network attacker can downgrade the first connection to plain HTTP and steal the session."
                : "Missing — nothing forces browsers onto HTTPS, so a connection can be downgraded to plain HTTP (SSL-stripping).",
              "Strict-Transport-Security: max-age=31536000; includeSubDomains",
              "Strict-Transport-Security: max-age=31536000; includeSubDomains",
              "Added Strict-Transport-Security with a one-year max-age and includeSubDomains.",
              null);
          } else {
            var v = hsts[0].value;
            var m = v.match(/max-age\s*=\s*"?(\d+)"?/i);
            if (!m) {
              add("Strict-Transport-Security", "WARNING",
                "Present but carries no max-age directive, so browsers ignore it.",
                "Strict-Transport-Security: max-age=31536000; includeSubDomains",
                "Strict-Transport-Security: max-age=31536000; includeSubDomains",
                "Rewrote Strict-Transport-Security with a valid one-year max-age.",
                null);
            } else if (parseInt(m[1], 10) < HSTS_FLOOR) {
              add("Strict-Transport-Security", "WARNING",
                "max-age is " + m[1] + " seconds — under the 180-day floor of " + HSTS_FLOOR + ", so browsers forget the HTTPS requirement quickly.",
                "Strict-Transport-Security: max-age=31536000; includeSubDomains",
                "Strict-Transport-Security: max-age=31536000; includeSubDomains",
                "Raised HSTS max-age from " + m[1] + " to 31536000 (one year).",
                null);
            }
            if (/includesubdomains/i.test(v)) {
              add("Strict-Transport-Security", "INFO",
                "includeSubDomains is set — the HTTPS requirement covers every subdomain too.", "—", null, null, null);
            }
            if (/preload/i.test(v)) {
              add("Strict-Transport-Security", "INFO",
                "preload is declared — the domain is asking browsers to hard-code HTTPS for it before the first visit.", "—", null, null, null);
            }
          }

          /* ---- (2) Content-Security-Policy (presence only) ---- */
          var csp = all(headers, "content-security-policy");
          var cspro = all(headers, "content-security-policy-report-only");
          if (!csp.length && !cspro.length) {
            if (isHtml) {
              add("Content-Security-Policy", "WARNING",
                "Missing on an HTML page — nothing limits where scripts, styles, and frames may load from if markup is ever injected.",
                "Starter to adapt: Content-Security-Policy: default-src 'self'",
                null, null,
                "Content-Security-Policy: the real directives depend on which scripts, styles, fonts, and frames the page legitimately uses — a human who knows the page must choose them. This tool checks presence only; deep policy grading lives in the CSP Policy & Resource Cross-Check Auditor.");
            }
          } else if (!csp.length && cspro.length) {
            add("Content-Security-Policy-Report-Only", isHtml ? "WARNING" : "INFO",
              "Only a report-only policy is present — violations are reported, but nothing is actually blocked.",
              "Once its reports look clean, send the same policy as Content-Security-Policy to enforce it.",
              null, null,
              "Promoting a report-only CSP to an enforced CSP: check the violation reports first — enforcing a policy with live violations breaks the page.");
          } else {
            add("Content-Security-Policy", "INFO",
              "Present — presence checked only. Deep grading of the policy's directives lives in the CSP Policy & Resource Cross-Check Auditor.",
              "—", null, null, null);
            if (cspro.length) {
              add("Content-Security-Policy-Report-Only", "INFO",
                "A report-only variant is also present alongside the enforced policy — useful for testing stricter rules before enforcing them.",
                "—", null, null, null);
            }
          }

          /* ---- (3) X-Content-Type-Options ---- */
          var xcto = all(headers, "x-content-type-options");
          if (!xcto.length) {
            add("X-Content-Type-Options", "WARNING",
              "Missing — browsers may MIME-sniff a response into a different type than declared, so a harmless-looking upload can be executed as script.",
              "X-Content-Type-Options: nosniff",
              "X-Content-Type-Options: nosniff",
              "Added X-Content-Type-Options: nosniff.",
              null);
          } else if (norm(xcto[0].value) !== "nosniff") {
            add("X-Content-Type-Options", "WARNING",
              "Value is \"" + xcto[0].value + "\", not \"nosniff\" — any other value is ignored, so sniffing protection is off.",
              "X-Content-Type-Options: nosniff",
              "X-Content-Type-Options: nosniff",
              "Changed X-Content-Type-Options from \"" + xcto[0].value + "\" to nosniff.",
              null);
          }

          /* ---- (4) Clickjacking ---- */
          var fa = null;
          if (csp.length) {
            var fam = csp[0].value.match(/frame-ancestors\s+([^;]+)/i);
            if (fam) fa = fam[1].trim();
          }
          var xfo = all(headers, "x-frame-options");
          function faClass(faVal) {
            var t = faVal.toLowerCase();
            if (t === "'none'") return "DENY";
            if (t === "'self'") return "SAMEORIGIN";
            return "OPEN";
          }
          if (isHtml && !fa && !xfo.length) {
            add("Clickjacking protection", "WARNING",
              "Neither CSP frame-ancestors nor X-Frame-Options is present on an HTML page — any site can frame this page and overlay decoy buttons (clickjacking).",
              "Content-Security-Policy: frame-ancestors 'none' — or 'self' if your own pages frame it; legacy alternative: X-Frame-Options: DENY",
              null, null,
              "Clickjacking protection: choose frame-ancestors 'none' / X-Frame-Options DENY versus 'self' / SAMEORIGIN — it depends on whether your own pages legitimately embed this one.");
          }
          if (fa && xfo.length) {
            var xfoVal = xfo[0].value.toUpperCase().trim();
            var cls = faClass(fa);
            if ((cls === "DENY" || cls === "SAMEORIGIN") && (xfoVal === "DENY" || xfoVal === "SAMEORIGIN") && cls !== xfoVal) {
              add("Clickjacking protection", "WARNING",
                "Conflicting frame rules: CSP says frame-ancestors " + fa + " but X-Frame-Options says " + xfo[0].value + " — modern and legacy browsers will enforce different rules.",
                "Make both agree on one policy, e.g. frame-ancestors 'none' with X-Frame-Options: DENY.",
                null, null,
                "Conflicting frame rules (CSP frame-ancestors " + fa + " vs X-Frame-Options " + xfo[0].value + "): a human must pick the single intended framing policy and align both headers.");
            }
          }

          /* ---- (5) Referrer-Policy ---- */
          var rp = all(headers, "referrer-policy");
          if (!rp.length) {
            add("Referrer-Policy", isHtml ? "WARNING" : "INFO",
              "Missing — browsers fall back to defaults that can send more of the URL (path and query string included) to other sites than you intend.",
              "Referrer-Policy: strict-origin-when-cross-origin",
              "Referrer-Policy: strict-origin-when-cross-origin",
              "Added Referrer-Policy: strict-origin-when-cross-origin — the full URL stays same-origin; only the origin crosses sites.",
              null);
          } else if (/\bunsafe-url\b/i.test(rp[0].value)) {
            add("Referrer-Policy", "WARNING",
              "Value is \"unsafe-url\" — the full URL, query string included, is sent to every destination, leaking tokens and search terms.",
              "Referrer-Policy: strict-origin-when-cross-origin",
              "Referrer-Policy: strict-origin-when-cross-origin",
              "Changed Referrer-Policy from unsafe-url to strict-origin-when-cross-origin.",
              null);
          }

          /* ---- (6) Permissions-Policy ---- */
          if (!all(headers, "permissions-policy").length && !all(headers, "feature-policy").length) {
            add("Permissions-Policy", "INFO",
              "Missing — powerful browser features (camera, microphone, geolocation, payment) stay available to the page and anything it embeds by default.",
              "Permissions-Policy: camera=(), microphone=(), geolocation=()",
              "Permissions-Policy: camera=(), microphone=(), geolocation=()",
              "Added a restrictive Permissions-Policy default (camera, microphone, geolocation off) — remove any feature your page legitimately uses before shipping.",
              null);
          }

          /* ---- (7) Cache-Control vs. sensitive context ---- */
          var cc = all(headers, "cache-control");
          var ccJoined = cc.map(function (h) { return h.value; }).join(", ");
          if (sensitive) {
            if (!cc.length) {
              add("Cache-Control", "BLOCKER",
                "Sensitive response is cacheable: no Cache-Control at all on a response that sets cookies or handles login/payment — shared caches and browsers fall back to default storing rules.",
                "Cache-Control: no-store",
                "Cache-Control: no-store",
                "Added Cache-Control: no-store so this sensitive response is not stored by any cache.",
                null);
            } else if (!/\bno-store\b/i.test(ccJoined)) {
              var whyCc = "Sensitive response is cacheable: Cache-Control is \"" + ccJoined + "\" with no no-store — a response tied to a login, payment, or session can be stored by shared caches and replayed to the wrong person.";
              if (/\bno-cache\b/i.test(ccJoined)) {
                whyCc += " Note: \"no-cache\" only forces revalidation before reuse — the response is still stored. It is not the same as no-store.";
              }
              add("Cache-Control", "BLOCKER", whyCc,
                "Cache-Control: no-store",
                "Cache-Control: no-store",
                "Replaced Cache-Control with no-store for this sensitive response.",
                null);
            }
          }

          /* ---- (8) Duplicate / conflicting headers ---- */
          var groups = {}, order = [];
          headers.forEach(function (h) {
            if (h.key === "set-cookie") return; /* repeated Set-Cookie is normal */
            if (!groups[h.key]) { groups[h.key] = []; order.push(h.key); }
            groups[h.key].push(h);
          });
          order.forEach(function (key) {
            var g = groups[key];
            if (g.length < 2) return;
            var distinct = [], seen = {};
            g.forEach(function (h) {
              var n = norm(h.value);
              if (!seen[n]) { seen[n] = true; distinct.push(h); }
            });
            if (distinct.length > 1) {
              var named = distinct.map(function (h) { return "\"" + shown(h) + "\""; }).join(" vs ");
              add(g[0].name, "WARNING",
                "Appears " + g.length + " times with different values (" + named + ") — servers, proxies, and browsers disagree on which value wins, so behavior varies by stack.",
                "Send " + g[0].name + " exactly once, with the single intended value.",
                null, null,
                "Conflicting " + g[0].name + " headers (" + named + "): a human must decide which value is intended — the tool flags the conflict but will not pick a winner.");
            } else {
              add(g[0].name, "INFO",
                "Appears " + g.length + " times with the identical value \"" + shown(g[0]) + "\" — an exact duplicate: harmless, but noisy.",
                "Send " + g[0].name + " once.",
                null, null, null);
            }
          });

          /* ---- (9) Leaky headers ---- */
          var server = all(headers, "server");
          if (server.length && /\d+\.\d+/.test(server[0].value)) {
            add("Server", "INFO",
              "Version disclosure: Server announces \"" + server[0].value + "\" — an exact version number tells an attacker precisely which known exploits to try.",
              "Configure the server to send a bare product name or nothing, e.g. Server: Apache",
              null, null,
              "Server version string \"" + server[0].value + "\": hiding it is a server/framework configuration change — no response header the page adds can remove it.");
          }
          var xpb = all(headers, "x-powered-by");
          if (xpb.length) {
            var hasVer = /\d+\.\d+/.test(xpb[0].value);
            add("X-Powered-By", "INFO",
              (hasVer ? "Version disclosure: " : "Technology disclosure: ") +
              "X-Powered-By announces \"" + xpb[0].value + "\" — free reconnaissance that narrows an attacker's exploit list.",
              "Remove X-Powered-By in your framework's configuration.",
              null, null,
              "X-Powered-By \"" + xpb[0].value + "\": removing it is a framework configuration change, not a header fix.");
          }
          var cookies = all(headers, "set-cookie");
          if (cookies.length) {
            var names = cookies.map(function (h) {
              var n = h.value.split("=")[0].trim();
              return n ? n : "(unnamed)";
            });
            add("Set-Cookie", "INFO",
              cookies.length + " Set-Cookie header(s) present — cookie name(s): " + names.join(", ") + ". Values are never shown here. Cookie attributes are counted, not graded, by this tool.",
              "For deep cookie grading (Secure, HttpOnly, SameSite, expiry), run the Set-Cookie Auditor.",
              null, null,
              "Cookie attributes for " + names.join(", ") + " are graded by the Set-Cookie Auditor, not here — this tool only counts Set-Cookie lines and names the cookies.");
          }
          if (all(headers, "authorization").length) {
            add("Authorization", "INFO",
              "An Authorization header appears in this response block — unusual for a response, and its value is never echoed here. If it is real, treat it as exposed and rotate it.",
              "Remove Authorization from responses; rotate the credential if it was ever live.",
              null, null, null);
          }

          /* ---- unparsed lines ---- */
          if (parsed.bad > 0) {
            add("(input)", "INFO",
              parsed.bad + " line(s) did not parse as \"Name: value\" and were ignored.",
              "—", null, null, null);
          }

          var rank = { BLOCKER: 0, WARNING: 1, INFO: 2 };
          F.sort(function (a, b) { return rank[a.sev] - rank[b.sev]; });
          return { findings: F, headerCount: headers.length, bad: parsed.bad };
        }

        function verdictFor(counts) {
          if (counts.BLOCKER > 0) return { word: "DO NOT DEPLOY — HEADER GAPS", cls: "bad",
            sub: "At least one BLOCKER finding. Fix the blockers before this response ships." };
          if (counts.WARNING > 0) return { word: "DEPLOY WITH FIXES", cls: "mid",
            sub: "No blockers, but WARNING findings should be fixed before or immediately after deploy." };
          return { word: "SAFE TO DEPLOY", cls: "good",
            sub: "No blockers and no warnings in the pasted headers, under the context you selected. INFO notes above are worth a read." };
        }

        function buildReport(ctx, verdict, counts, F, blockLines, receipts, notFixedList) {
          var L = [];
          L.push("J-DAWGS HTTP RESPONSE HEADER SAFETY AUDITOR — REPORT");
          L.push("Context: sets cookies / handles login or payment: " + (ctx.sensitive ? "yes" : "no") +
                 " · HTML page: " + (ctx.isHtml ? "yes" : "no"));
          L.push("Verdict: " + verdict.word);
          L.push("Counts: " + counts.BLOCKER + " BLOCKER · " + counts.WARNING + " WARNING · " + counts.INFO + " INFO");
          L.push("");
          L.push("FINDINGS");
          if (!F.length) L.push("(none)");
          F.forEach(function (f, i) {
            L.push((i + 1) + ". [" + f.sev + "] " + f.header + " — " + f.why);
            L.push("   Fix: " + f.fix);
          });
          L.push("");
          L.push("CORRECTED HEADER BLOCK (mechanical changes only)");
          L.push(blockLines.length ? blockLines.join("\n") : "(no mechanical changes — nothing safe to add or rewrite automatically)");
          if (receipts.length) {
            L.push("");
            L.push("RECEIPTS");
            receipts.forEach(function (r) { L.push("- " + r); });
          }
          L.push("");
          L.push("NOT FIXED (needs a human decision)");
          if (notFixedList.length) notFixedList.forEach(function (n) { L.push("- " + n); });
          else L.push("(nothing outstanding)");
          L.push("");
          L.push("Limits: pasted-text audit only — the live site was never fetched. Header needs differ by app; this is orientation, not a guarantee. Deep CSP grading: CSP Policy & Resource Cross-Check Auditor. Deep cookie grading: Set-Cookie Auditor.");
          return L.join("\n");
        }

        function showMessage(msg) {
          $("report").classList.add("hidden");
          var n = $("emptyNote");
          n.classList.remove("hidden");
          n.innerHTML = "";
          n.textContent = msg;
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_BAD": (typeof EXAMPLE_BAD !== 'undefined' ? EXAMPLE_BAD : undefined), "EXAMPLE_CLEAN": (typeof EXAMPLE_CLEAN !== 'undefined' ? EXAMPLE_CLEAN : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-http-response-header-safety-auditor',
  name: 'J-Dawgs HTTP Response Header Safety Auditor',
  description: '',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_BAD": __core["EXAMPLE_BAD"], "EXAMPLE_CLEAN": __core["EXAMPLE_CLEAN"] }
};
