'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs CoreDNS Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var RISKY_EXAMPLE = [
        ".:53 {",
        "    forward . 8.8.8.8 1.1.1.1",
        "    cache",
        "    health",
        "    prometheus :9153",
        "    kubernetes cluster.local { fallthrough }",
        "    file db.example.org example.org",
        "    rewrite name example.org internal",
        "}"
      ].join("\n");

      var HARDENED_EXAMPLE = [
        "127.0.0.1:53 {",
        "    bind 127.0.0.1",
        "    forward . tls://1.1.1.1 tls://8.8.8.8 { health_check 5s }",
        "    cache 10000 { success 3600 60 }",
        "    loop",
        "    errors",
        "    log",
        "    health localhost:8080",
        "    prometheus localhost:9153",
        "    file db.example.org example.org { reload 30s }",
        "    kubernetes cluster.local",
        "}"
      ].join("\n");

      var KNOWN_PLUGINS = ["forward","cache","file","kubernetes","health","prometheus","loop","errors","log","bind","rewrite","tls","secondary","ready","hosts"];
      var HANDLED_PLUGINS = ["forward","cache","health","prometheus","ready","loop","errors","log","tls","file","secondary","kubernetes","rewrite","bind"];

      function stripComment(line) {
        var idx = line.indexOf("#");
        return idx >= 0 ? line.slice(0, idx) : line;
      }
      function countChar(s, ch) {
        var n = 0;
        for (var i = 0; i < s.length; i++) if (s.charAt(i) === ch) n++;
        return n;
      }
      function isIPv4(s) { return /^\d{1,3}(\.\d{1,3}){3}$/.test(s); }

      // Parse the Corefile into server blocks with plugin entries.
      // Each entry keeps its 1-indexed starting line and its full text
      // (including any inline or nested { ... } option block).
      function parseCorefile(text) {
        var rawLines = text.split(/\r?\n/);
        var blocks = [];
        var hasBlockHeader = false;
        var hasPlugin = false;
        var depth = 0;
        var cur = null;
        var entry = null;
        var entryDepth = 0;

        rawLines.forEach(function (raw, idx) {
          var lineNo = idx + 1;
          var clean = stripComment(raw);
          var t = clean.trim();
          var opens = countChar(clean, "{");
          var closes = countChar(clean, "}");

          var firstTok = t.split(/\s+/)[0].toLowerCase().replace(/[^a-z0-9_-].*$/, "");
          if (KNOWN_PLUGINS.indexOf(firstTok) >= 0) hasPlugin = true;

          if (depth === 0) {
            if (opens > 0 && t) {
              var headerTest = /^(?:[a-zA-Z][a-zA-Z0-9+.-]*:\/\/)?[^\s{]+(?:\s+[^\s{]+)*\s*\{/.test(t);
              if (headerTest) {
                hasBlockHeader = true;
                cur = {
                  headerLine: lineNo,
                  address: t.slice(0, t.indexOf("{")).trim(),
                  entries: [],
                  closeLine: null
                };
                blocks.push(cur);
                depth = opens - closes;
                if (depth <= 0) { cur.closeLine = lineNo; cur = null; depth = 0; }
              }
            }
            return;
          }

          // Inside a server block.
          if (entry) {
            entry.text += "\n" + clean;
            entryDepth += opens - closes;
            depth += opens - closes;
            if (entryDepth <= 0) entry = null;
            if (depth <= 0) { cur.closeLine = lineNo; cur = null; depth = 0; }
            return;
          }
          if (depth === 1 && t && t !== "}") {
            var m = t.match(/^([A-Za-z][A-Za-z0-9_-]*)\b([\s\S]*)$/);
            if (m) {
              entry = { name: m[1].toLowerCase(), line: lineNo, text: clean };
              cur.entries.push(entry);
              entryDepth = opens - closes;
              depth += opens - closes;
              if (entryDepth <= 0) entry = null;
              if (depth <= 0) { cur.closeLine = lineNo; cur = null; depth = 0; }
              return;
            }
          }
          depth += opens - closes;
          if (depth <= 0) { if (cur) cur.closeLine = lineNo; cur = null; depth = 0; }
        });

        return { blocks: blocks, lines: rawLines, hasBlockHeader: hasBlockHeader, hasPlugin: hasPlugin };
      }

      function entryArgs(entry) {
        // First line of the entry with brace blocks removed: tokens after the plugin name.
        var firstLine = entry.text.split("\n")[0];
        var noBraces = firstLine.replace(/\{[^}]*\}/g, " ");
        var toks = noBraces.trim().split(/\s+/).filter(Boolean);
        return toks.slice(1); // drop plugin name
      }
      function findEntry(block, name) {
        for (var i = 0; i < block.entries.length; i++) if (block.entries[i].name === name) return block.entries[i];
        return null;
      }
      function tokenHost(tok) {
        var t = tok.replace(/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//, "");
        var m = t.match(/^(.*):(\d+)$/);
        return (m ? m[1] : t).replace(/^\[|\]$/g, "");
      }
      function tokenScheme(tok) {
        var m = tok.match(/^([a-zA-Z][a-zA-Z0-9+.-]*):\/\//);
        return m ? m[1].toLowerCase() : "";
      }
      function tokenPort(tok) {
        var t = tok.replace(/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//, "");
        var m = t.match(/:(\d+)$/);
        return m ? m[1] : "";
      }

      function auditBlock(block, add) {
        var headerLine = block.headerLine;
        var addressToks = block.address.split(/[\s,]+/).filter(Boolean);
        var bindEntry = findEntry(block, "bind");
        var bindRestricts = false;
        var bindWildcard = false;
        if (bindEntry) {
          var bargs = entryArgs(bindEntry).join(" ");
          if (/0\.0\.0\.0|::/.test(bargs)) bindWildcard = true;
          else if (bargs) bindRestricts = true;
        }

        // --- Check 10b: bind directive misuse ---
        if (bindEntry) {
          if (bindWildcard) {
            add("BLOCKER", bindEntry.line, "BIND-WILDCARD",
              "The bind directive pins this block to 0.0.0.0 / :: — every interface on the host.",
              "Bind to a specific address (for example bind 127.0.0.1 or the host's service IP) so the server only answers where you intend.");
          } else if (bindRestricts) {
            add("INFO", bindEntry.line, "BIND-OK",
              "The bind directive restricts this block to a specific address.",
              "No change needed.");
          }
        }

        // --- Check 1: wildcard bind / listen posture ---
        var worstBind = null; // {sev, msg}
        addressToks.forEach(function (tok) {
          var host = tokenHost(tok);
          if (host === "0.0.0.0" || host === "::") {
            worstBind = { sev: "BLOCKER", msg: "Server block address \"" + tok + "\" binds the wildcard address — CoreDNS listens on every interface, including any public one." };
          } else if (host === "." || host === "") {
            if (!worstBind || worstBind.sev !== "BLOCKER") {
              worstBind = bindRestricts
                ? { sev: "INFO", msg: "Root-zone block \"" + tok + "\" is held to a specific address by its bind directive." }
                : { sev: "BLOCKER", msg: "Server block \"" + tok + "\" is the root zone with no host restriction — CoreDNS listens on all interfaces (0.0.0.0 / ::), so anything that can reach this host can query it." };
            }
          } else if (isIPv4(host) || host.indexOf(":") >= 0 || host === "localhost") {
            if (!worstBind) worstBind = { sev: "INFO", msg: "Server block is bound to the specific address " + host + "." };
          } else {
            if (!worstBind) {
              worstBind = bindRestricts
                ? { sev: "INFO", msg: "Zone block \"" + tok + "\" names a zone, and its bind directive restricts which interfaces answer." }
                : { sev: "WARN", msg: "Zone block \"" + tok + "\" names a zone, not an address, and has no bind directive — CoreDNS listens on all interfaces by default." };
            }
          }
        });
        if (worstBind) {
          add(worstBind.sev, headerLine, worstBind.sev === "INFO" ? "BIND-POSTURE-OK" : "BIND-WILDCARD",
            worstBind.msg,
            worstBind.sev === "INFO" ? "No change needed."
              : "Give the block a specific listen address (for example 127.0.0.1:53) or add a bind directive naming the one interface that should answer.");
        }

        // --- Check 7: TLS posture for encrypted schemes / plaintext note ---
        var scheme = addressToks.length ? tokenScheme(addressToks[0]) : "";
        var tlsEntry = findEntry(block, "tls");
        if (scheme === "tls" || scheme === "https" || scheme === "grpc" || scheme === "quic") {
          if (tlsEntry) {
            add("INFO", tlsEntry.line, "TLS-OK",
              "Encrypted server block (" + scheme + "://) has a tls directive supplying its certificate and key.",
              "No change needed — keep the certificate renewed and the key file readable only by the service account.");
          } else {
            add("BLOCKER", headerLine, "TLS-MISSING",
              "This block serves an encrypted transport (" + scheme + "://) but has no tls directive with certificate and key paths inside the block — it cannot terminate TLS as configured, and a hand-rolled fallback would be worse.",
              "Add a tls directive inside the block with the certificate and key paths (for example: tls /path/cert.pem /path/key.pem).");
          }
        } else {
          var port = addressToks.length ? tokenPort(addressToks[0]) : "";
          add("INFO", headerLine, "PLAINTEXT-DNS",
            "This block serves classic plaintext DNS" + (port ? " on port " + port : "") + " (UDP/TCP). That is normal for a resolver on a trusted network, but queries are readable and spoofable in transit.",
            "If clients reach this server over an untrusted network, add an encrypted block (tls://, https://, or quic://) with a tls directive alongside this one.");
          if (tlsEntry) {
            add("INFO", tlsEntry.line, "TLS-PRESENT",
              "A tls directive is present in a plaintext-scheme block; it only takes effect for encrypted server blocks.",
              "Confirm the tls directive sits in the tls:// / https:// / grpc:// / quic:// block it was meant for.");
          }
        }

        // --- Check 2: forward transport ---
        var fwd = findEntry(block, "forward");
        if (fwd) {
          var args = entryArgs(fwd);
          var upstreams = args.slice(1); // first arg is the zone (usually ".")
          var plain = [], encrypted = [];
          upstreams.forEach(function (u) {
            if (/^(tls|https):\/\//i.test(u)) encrypted.push(u);
            else plain.push(u);
          });
          if (plain.length && encrypted.length) {
            add("BLOCKER", fwd.line, "FORWARD-PLAINTEXT",
              "forward mixes encrypted upstreams with plaintext ones (" + plain.length + " bare upstream" + (plain.length > 1 ? "s" : "") + " with no tls:// or https:// scheme). Bare upstreams are reached over plaintext UDP — readable and spoofable on the path.",
              "Give every upstream an encrypted scheme (tls:// for DNS-over-TLS or https:// for DNS-over-HTTPS), or drop the plaintext upstreams.");
          } else if (plain.length) {
            add("BLOCKER", fwd.line, "FORWARD-PLAINTEXT",
              "forward sends queries to " + plain.length + " bare upstream" + (plain.length > 1 ? "s" : "") + " with no tls:// or https:// scheme — plaintext UDP. Anyone on the path can read the queries and forge the answers.",
              "Change the upstreams to tls:// (DNS-over-TLS) or https:// (DNS-over-HTTPS) endpoints, for example forward . tls://1.1.1.1.");
          } else if (encrypted.length) {
            add("INFO", fwd.line, "FORWARD-ENCRYPTED",
              "forward uses encrypted upstreams only (tls:// / https://).",
              "No change needed.");
          }
          if (!/health_check/.test(fwd.text)) {
            add("WARN", fwd.line, "FORWARD-NO-HEALTHCHECK",
              "forward has no health_check option, so a dead upstream keeps receiving queries until connections time out.",
              "Add a health_check option to the forward block (for example { health_check 5s }).");
          }
          if (/force_tcp/.test(fwd.text)) {
            add("WARN", fwd.line, "FORWARD-FORCE-TCP",
              "forward sets force_tcp, forcing every upstream query onto TCP. That is usually a workaround for a broken UDP path and costs latency on every lookup.",
              "Remove force_tcp and fix the UDP path, unless you have a measured reason to force TCP.");
          }
        }

        // --- Check 3: cache presence / bounds ---
        var cache = findEntry(block, "cache");
        if (cache) {
          if (/\d/.test(cache.text)) {
            add("INFO", cache.line, "CACHE-BOUNDED",
              "cache is configured with numeric bounds (size and/or TTL values).",
              "No change needed.");
          } else {
            add("WARN", cache.line, "CACHE-UNBOUNDED",
              "cache is present with no size or TTL arguments — a bare cache grows and holds answers on default behavior you never chose.",
              "Give cache explicit bounds, for example: cache 10000 { success 3600 60 }.");
          }
        } else if (fwd) {
          add("WARN", headerLine, "CACHE-ABSENT",
            "This block forwards queries but has no cache plugin — every lookup goes upstream, adding latency and leaking the full query stream.",
            "Add a bounded cache (for example: cache 10000 { success 3600 60 }).");
        }

        // --- Check 4 + 12: health / prometheus / ready exposure ---
        [["health", "HEALTH", "8080"], ["prometheus", "PROMETHEUS", "9153"], ["ready", "READY", "8181"]].forEach(function (spec) {
          var e = findEntry(block, spec[0]);
          if (!e) return;
          var rest = entryArgs(e).join(" ");
          var label = spec[0] === "prometheus" ? "prometheus metrics endpoint" : spec[0] + " endpoint";
          if (/localhost|127\.0\.0\.1|\[::1\]/.test(rest)) {
            add("INFO", e.line, spec[1] + "-LOCAL",
              "The " + label + " is bound to localhost — reachable from the host itself, not from the network.",
              "No change needed.");
          } else {
            add("WARN", e.line, spec[1] + "-EXPOSED",
              "The " + label + " is not bound to localhost" + (rest ? " (\"" + rest + "\")" : " (bare directive, default port :" + spec[2] + " on all interfaces)") + " — anyone who can reach the port can read it" + (spec[0] === "prometheus" ? ", and query-volume metrics leak what the server is being asked about." : "."),
              "Bind it to localhost (for example " + spec[0] + " localhost:" + spec[2] + ") and reach it through the host or an authenticated proxy.");
          }
        });

        // --- Check 5: loop detection on forwarded setups ---
        var loop = findEntry(block, "loop");
        if (fwd && !loop) {
          add("WARN", fwd.line, "LOOP-MISSING",
            "This block forwards but has no loop plugin — a forwarding loop (this server ending up querying itself) spins undetected until it melts the resolver.",
            "Add the loop plugin to every block that forwards.");
        } else if (loop) {
          add("INFO", loop.line, "LOOP-OK",
            "loop detection is enabled, so a forwarding loop is caught instead of spinning.",
            "No change needed.");
        }

        // --- Check 6: errors / log posture ---
        var errors = findEntry(block, "errors");
        if (errors) {
          add("INFO", errors.line, "ERRORS-OK", "The errors plugin is on, so SERVFAIL responses are logged instead of vanishing.", "No change needed.");
        } else {
          add("WARN", headerLine, "ERRORS-ABSENT",
            "No errors plugin in this block — failed queries (SERVFAIL) leave no trace, so breakage is invisible until users complain.",
            "Add the errors plugin to the block.");
        }
        var log = findEntry(block, "log");
        if (log) {
          add("INFO", log.line, "LOG-OK", "The log plugin is on, so queries — including dropped ones — are recorded.", "No change needed.");
        } else {
          add("WARN", headerLine, "LOG-ABSENT",
            "No log plugin in this block — there is no record of queries, including the ones this server drops or refuses.",
            "Add the log plugin (scoped as narrowly as your privacy rules allow, but never zero logging).");
        }

        // --- Check 8: file / secondary zone posture ---
        var file = findEntry(block, "file");
        if (file) {
          if (/reload/.test(file.text)) {
            add("INFO", file.line, "FILE-RELOAD-OK",
              "file serves a zone with a reload interval, so zone edits are picked up without a restart.",
              "No change needed.");
          } else {
            add("WARN", file.line, "FILE-NO-RELOAD",
              "file serves a zone file with no reload option — zone changes are silently ignored until the server restarts, so the zone you think is live may not be.",
              "Add a reload interval to the file block (for example { reload 30s }).");
          }
        }
        var secondary = findEntry(block, "secondary");
        if (secondary) {
          if (findEntry(block, "transfer") || /transfer/.test(secondary.text)) {
            add("INFO", secondary.line, "SECONDARY-TRANSFER",
              "secondary has transfer handling configured for zone updates.",
              "No change needed — confirm transfers are restricted to the real primaries.");
          } else {
            add("WARN", secondary.line, "SECONDARY-NO-TRANSFER",
              "secondary is configured with no visible transfer handling — zone transfers may be unaccepted, or accepted from anyone who asks.",
              "Configure transfer handling and restrict zone transfers to the legitimate primary servers only.");
          }
        }

        // --- Check 9: kubernetes fallthrough ---
        var kube = findEntry(block, "kubernetes");
        if (kube) {
          if (/fallthrough/.test(kube.text)) {
            add("BLOCKER", kube.line, "KUBERNETES-FALLTHROUGH",
              "kubernetes is configured with fallthrough — names the cluster does not own are passed on to the next plugin, which can leak internal service names to outside resolvers and mask NXDOMAIN answers clients rely on.",
              "Remove fallthrough from the kubernetes block so unknown cluster names get a definitive answer.");
          } else {
            add("INFO", kube.line, "KUBERNETES-OK",
              "kubernetes is configured without fallthrough — cluster names stay inside the cluster's authority.",
              "No change needed.");
          }
        }

        // --- Check 10a: rewrite misuse ---
        var rewrite = findEntry(block, "rewrite");
        if (rewrite) {
          if (/\.\*|regex/.test(rewrite.text)) {
            add("WARN", rewrite.line, "REWRITE-BROAD",
              "rewrite uses a broad regex-style rule — an over-wide pattern can silently rename queries you never meant to touch.",
              "Narrow the rewrite to exact names or the tightest pattern that covers the intended names only.");
          } else {
            add("INFO", rewrite.line, "REWRITE-PRESENT",
              "A rewrite rule is present. Rewrites change which name is actually resolved, so keep the rule set small and reviewed.",
              "Confirm every rewrite rule still matches only the names it was written for.");
          }
        }

        // --- Other known plugins: INFO-level note ---
        block.entries.forEach(function (e) {
          if (HANDLED_PLUGINS.indexOf(e.name) < 0) {
            add("INFO", e.line, "PLUGIN-NOTED",
              "Plugin \"" + e.name + "\" is present. This audit has no posture rule for it, so it is noted, not graded.",
              "Review the " + e.name + " configuration by hand against your serving intent.");
          }
        });
      }

      // --- Check 11: credential-like strings (name + line + length ONLY) ---
      function scanCredentials(rawLines, add) {
        var keyRe = /\b(password|passwd|pwd|secret|token|api[_-]?key|apikey|access[_-]?key|private[_-]?key|client[_-]?secret|bearer|authorization)\b(?:\s*[:=]\s*|\s+)(["']?)([^\s"'{};,\]]+)\2?/i;
        rawLines.forEach(function (raw, idx) {
          var m = raw.match(keyRe);
          if (!m) return;
          var value = m[3] || "";
          if (value.charAt(0) === "$" || value.charAt(0) === "{") return; // env reference, not a literal
          if (value.length < 4) return;
          var key = m[1].toLowerCase();
          add("BLOCKER", idx + 1, "CREDENTIAL-IN-CONFIG",
            "Credential-like value found for \"" + key + "\" (value length " + value.length + " characters; the value is redacted and never shown). A secret sitting in a Corefile is readable by anyone who can read the config — backups, repos, and config management included.",
            "Remove the credential from the Corefile, rotate it (it must be treated as exposed), and supply it through your secret store or environment instead.");
        });
      }

      function audit(text) {
        var parsed = parseCorefile(text);
        var findings = [];
        function add(sev, line, check, message, fix) {
          findings.push({ severity: sev, line: line, check: check, message: message, fix: fix });
        }
        parsed.blocks.forEach(function (b) { auditBlock(b, add); });
        scanCredentials(parsed.lines, add);
        findings.sort(function (a, b) {
          if (a.line !== b.line) return a.line - b.line;
          var rank = { BLOCKER: 0, WARN: 1, INFO: 2 };
          return rank[a.severity] - rank[b.severity];
        });
        var counts = { BLOCKER: 0, WARN: 0, INFO: 0 };
        findings.forEach(function (f) { counts[f.severity]++; });
        var verdict = counts.BLOCKER > 0 ? "DO NOT SERVE" : (counts.WARN > 0 ? "SERVE WITH FIXES" : "SAFE TO SERVE");
        var fixes = [];
        findings.forEach(function (f) {
          if (f.severity !== "INFO" && fixes.indexOf(f.fix) < 0) fixes.push(f.fix);
        });
        return { verdict: verdict, counts: counts, findings: findings, fixes: fixes, blockCount: parsed.blocks.length };
      }

      function buildReport(r) {
        var out = [];
        out.push("J-Dawgs CoreDNS Server Config Safety Auditor\u2122 - Corefile Audit Report");
        out.push("Verdict: " + r.verdict);
        out.push("Counts: " + r.counts.BLOCKER + " blocker(s), " + r.counts.WARN + " warning(s), " + r.counts.INFO + " info");
        out.push("Server blocks found: " + r.blockCount);
        out.push("");
        out.push("Findings (by line):");
        r.findings.forEach(function (f) {
          out.push("[" + f.severity + "] Line " + f.line + " - " + f.check + " - " + f.message);
          out.push("    Fix: " + f.fix);
        });
        out.push("");
        out.push("Fix list:");
        if (r.fixes.length) r.fixes.forEach(function (fx, i) { out.push((i + 1) + ". " + fx); });
        else out.push("(none - nothing to fix)");
        out.push("");
        out.push("Note: credential values are never shown in this report - only the directive name, line, and value length.");
        return out.join("\n");
      }

      function buildJSON(r) {
        return JSON.stringify({
          tool: "J-Dawgs CoreDNS Server Config Safety Auditor\u2122",
          verdict: r.verdict,
          counts: { blockers: r.counts.BLOCKER, warnings: r.counts.WARN, info: r.counts.INFO },
          serverBlocks: r.blockCount,
          findings: r.findings.map(function (f) {
            return { severity: f.severity, line: f.line, check: f.check, message: f.message, fix: f.fix };
          }),
          fixes: r.fixes
        }, null, 2);
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-coredns-server-config-safety-auditortm',
  name: 'J-Dawgs CoreDNS Server Config Safety Auditor',
  description: 'CoreDNS validation needs the binary running on the host and stops at will-it-load; ours grades a pasted Corefile fully offline for serving safety — wildcard binds, plaintext forwarding, unbounded cache, exposed health/metrics endpoints, missing loop detection, TLS posture for DoT/DoH/DoQ blocks, and',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
