'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Lychee Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Built-in examples (line numbers are part of the test) ---------- */
      var RISKY_EXAMPLE = [
        "# Lychee photo server - production config (RISKY example)",
        "APP_NAME=Lychee",
        "APP_ENV=local",
        "APP_KEY=base64:short-example-key",
        "APP_DEBUG=true",
        "APP_URL=http://photos.example.com",
        "",
        "DB_CONNECTION=mysql",
        "DB_HOST=127.0.0.1",
        "DB_PORT=3306",
        "DB_DATABASE=lychee",
        "DB_USERNAME=lychee",
        "DB_PASSWORD=supersecretpassword123"
      ].join("\n");

      var HARDENED_EXAMPLE = [
        "# Lychee photo server - production config (HARDENED example)",
        "APP_NAME=Lychee",
        "APP_ENV=production",
        "APP_KEY=base64:kX9vQ2mZ8pL4wR7tY1uI6oP3aS5dF0gH2jK9lZ4xC7vB=",
        "APP_DEBUG=false",
        "APP_URL=https://photos.example.com",
        "",
        "DB_CONNECTION=mysql",
        "DB_HOST=127.0.0.1",
        "DB_PORT=3306",
        "DB_DATABASE=lychee",
        "DB_USERNAME=lychee_app",
        "# DB_PASSWORD is injected by the host secret store at boot - it is not kept in this file."
      ].join("\n");

      /* ---------- Parsing ---------- */
      function parseEnv(text){
        var entries = [];
        var lines = String(text || "").split(/\r?\n/);
        for (var i = 0; i < lines.length; i++){
          var trimmed = lines[i].trim();
          if (!trimmed) continue;                       /* blank line */
          if (trimmed.charAt(0) === "#") continue;      /* comment line */
          var m = trimmed.match(/^(?:export\s+)?([A-Za-z_][A-Za-z0-9_.\-]*)\s*=\s*(.*)$/);
          if (!m) continue;                             /* not a KEY=VALUE line */
          var value = m[2].trim();
          if (value.length >= 2){
            var first = value.charAt(0), last = value.charAt(value.length - 1);
            if ((first === '"' && last === '"') || (first === "'" && last === "'")){
              value = value.slice(1, -1);               /* strip surrounding quotes */
            }
          }
          entries.push({ key: m[1].toUpperCase(), value: value, line: i + 1 });
        }
        return entries;
      }

      function isTruthy(v){
        var s = String(v).trim().toLowerCase();
        return s === "true" || s === "1" || s === "yes" || s === "on";
      }
      function isFalsy(v){
        var s = String(v).trim().toLowerCase();
        return s === "false" || s === "0" || s === "no" || s === "off";
      }
      var EXAMPLE_RE = /(example|placeholder|change[\s_-]?me|your[\s_-]|xxxxx|todo|dummy|sample|insert[\s_-])/i;
      var WEAK_RE = /^(password|passw0rd|letmein|secret|admin|administrator|123456|12345678|12345|qwerty|default|root|changeme)$/i;

      function isSecretKey(key){
        return key === "APP_KEY" || /(PASSWORD|PASSWD|SECRET|TOKEN|API_KEY|PRIVATE_KEY)/.test(key);
      }
      function collectSecrets(entries){
        var secrets = [];
        entries.forEach(function(e){
          if (isSecretKey(e.key) && e.value){ secrets.push(e.value); }
        });
        return secrets;
      }
      function scrub(text, secrets){
        var out = String(text);
        secrets.forEach(function(s){
          if (s && s.length >= 4){
            out = out.split(s).join("[REDACTED len=" + s.length + "]");
          }
        });
        return out;
      }
      function redacted(value){ return "[REDACTED len=" + value.length + "]"; }

      /* ---------- Audit ---------- */
      var SEV_RANK = { critical: 0, high: 1, medium: 2, info: 3 };

      function auditConfig(text){
        var entries = parseEnv(text);
        var findings = [];
        function add(severity, line, key, finding, fix){
          findings.push({ severity: severity, line: line, key: key, finding: finding, fix: fix });
        }
        function first(key){
          for (var i = 0; i < entries.length; i++){ if (entries[i].key === key) return entries[i]; }
          return null;
        }

        var recognized = entries.some(function(e){
          return e.key === "APP_KEY" || e.key === "APP_ENV" || e.key === "APP_DEBUG" ||
                 e.key === "APP_URL" || e.key.indexOf("DB_") === 0;
        });
        if (!recognized){
          return { verdict: "NOT ENOUGH TO GRADE", findings: [], entries: entries, recognized: false,
                   counts: { critical: 0, high: 0, medium: 0, info: 0 } };
        }

        /* APP_DEBUG */
        var dbg = first("APP_DEBUG");
        if (dbg){
          if (isTruthy(dbg.value)){
            add("critical", dbg.line, "APP_DEBUG",
              "Debug mode is ON. A live server with debug on can show visitors stack traces, file paths, and config values.",
              "Set APP_DEBUG=false before this server faces the internet.");
          } else if (isFalsy(dbg.value)){
            add("info", dbg.line, "APP_DEBUG", "Debug mode is off. Good.", "No change needed.");
          }
        }

        /* APP_ENV */
        var env = first("APP_ENV");
        if (env){
          var envVal = env.value.trim().toLowerCase();
          if (envVal === "local"){
            add("critical", env.line, "APP_ENV",
              "Environment is set to \"local\" in a config meant for deployment. Local mode relaxes protections and pairs dangerously with debug tooling.",
              "Set APP_ENV=production on the live server.");
          } else if (envVal === "development" || envVal === "dev"){
            add("high", env.line, "APP_ENV",
              "Environment is set to a development value in a deploy config.",
              "Set APP_ENV=production on the live server.");
          } else if (envVal === "staging" || envVal === "testing" || envVal === "test"){
            add("medium", env.line, "APP_ENV",
              "Environment is set to \"" + envVal + "\" — fine for a staging box, wrong for the public server.",
              "Use APP_ENV=production for the live deployment.");
          } else if (envVal === "production" || envVal === "prod"){
            add("info", env.line, "APP_ENV", "Environment is set to production. Good.", "No change needed.");
          }
        }

        /* APP_KEY (secret — length only, never the value) */
        var appKey = first("APP_KEY");
        if (!appKey){
          add("critical", null, "APP_KEY",
            "APP_KEY is missing entirely. The app encrypts sessions and cookies with this key; without one the install is not safe to expose.",
            "Generate a real key on the server (php artisan key:generate) and put it in this file.");
        } else {
          var keyProblems = [];
          if (EXAMPLE_RE.test(appKey.value)) keyProblems.push("it contains example/placeholder text");
          if (appKey.value.length < 32) keyProblems.push("it is only " + appKey.value.length + " characters long (32 minimum)");
          if (keyProblems.length){
            add("critical", appKey.line, "APP_KEY",
              "APP_KEY is not a real key: " + keyProblems.join(" and ") + ". Reported as " + redacted(appKey.value) + " — the value itself is never shown.",
              "Generate a fresh key on the server (php artisan key:generate) and replace this value.");
          } else {
            add("info", appKey.line, "APP_KEY",
              "APP_KEY is present at a healthy length (" + redacted(appKey.value) + ").", "No change needed.");
          }
        }

        /* APP_URL */
        var url = first("APP_URL");
        if (!url){
          add("medium", null, "APP_URL",
            "APP_URL is not set. The app can generate wrong links and insecure redirects without it.",
            "Set APP_URL to the site's full https:// address.");
        } else if (/^http:\/\//i.test(url.value.trim())){
          add("high", url.line, "APP_URL",
            "APP_URL uses http:// — logins, uploads, and session cookies cross the network unencrypted.",
            "Put the site behind HTTPS and set APP_URL to the https:// address.");
        } else if (/^https:\/\//i.test(url.value.trim())){
          add("info", url.line, "APP_URL", "APP_URL uses https://. Good.", "No change needed.");
        } else {
          add("medium", url.line, "APP_URL",
            "APP_URL does not start with https://, so the app cannot be sure it is building secure links.",
            "Set APP_URL to the site's full https:// address.");
        }

        /* DB_PASSWORD (secret — length only) */
        entries.forEach(function(e){
          if (e.key !== "DB_PASSWORD") return;
          if (e.value === ""){
            add("high", e.line, "DB_PASSWORD",
              "DB_PASSWORD is set but empty — either the database is wide open or the app will fail to connect.",
              "Set a strong, unique database password, or inject it from a secret store instead of this file.");
          } else if (EXAMPLE_RE.test(e.value) || WEAK_RE.test(e.value)){
            add("high", e.line, "DB_PASSWORD",
              "DB_PASSWORD looks like an example or default value (" + redacted(e.value) + "). Anyone who has seen the docs can guess it.",
              "Replace it with a strong, unique password that appears nowhere else.");
          } else {
            add("medium", e.line, "DB_PASSWORD",
              "A database password is stored in plain text in this file (" + redacted(e.value) + "). Anyone who can read the file owns the database.",
              "Move the password into a secret store or a locked-down env file (owner-read-only), and rotate it if this file was ever shared.");
          }
        });

        /* Admin credential posture + public posture + other secrets */
        entries.forEach(function(e){
          var key = e.key;
          if (key === "APP_KEY" || key === "DB_PASSWORD") return;

          var isAdminSecret = /ADMIN/.test(key) && /(PASSWORD|PASSWD|SECRET|TOKEN)/.test(key);
          if (isAdminSecret){
            if (e.value === ""){
              add("high", e.line, key, "Admin credential key is present but empty.", "Set a strong admin password, or remove the key and set credentials in the admin panel.");
            } else if (EXAMPLE_RE.test(e.value) || WEAK_RE.test(e.value)){
              add("critical", e.line, key,
                "Admin password looks like a default or example value (" + redacted(e.value) + "). The admin account is effectively unlocked.",
                "Set a strong, unique admin password before deploying.");
            } else {
              add("medium", e.line, key,
                "An admin password is stored in plain text in this file (" + redacted(e.value) + ").",
                "Set admin credentials in the app instead of the config file, or move them to a secret store.");
            }
            return;
          }
          if (/ADMIN/.test(key) && /(USER|USERNAME|LOGIN|NAME)/.test(key)){
            var u = e.value.trim().toLowerCase();
            if (u === "admin" || u === "administrator" || u === "root"){
              add("medium", e.line, key,
                "The admin username is the default \"" + u + "\" — the first name every attacker tries.",
                "Use a non-obvious admin username.");
              return;
            }
          }
          if (/PUBLIC/.test(key) && (isTruthy(e.value) || e.value.trim().toLowerCase() === "public")){
            add("medium", e.line, key,
              "This setting turns public access ON by default. New content may be visible to the whole internet the moment it is uploaded.",
              "Turn it off unless every upload is meant to be public; make public sharing a per-album choice instead.");
            return;
          }
          if (/VISIBILITY/.test(key) && e.value.trim().toLowerCase() === "public"){
            add("medium", e.line, key,
              "Default visibility is \"public\" — new albums start out visible to everyone.",
              "Set the default visibility to private and share albums deliberately.");
            return;
          }
          if (/(GUEST|ANON)/.test(key) && /(UPLOAD|ACCESS|ALLOW)/.test(key) && isTruthy(e.value)){
            add("medium", e.line, key,
              "Guest/anonymous access is switched on by this key — strangers may be able to upload or browse.",
              "Turn it off unless anonymous uploads are the deliberate design.");
            return;
          }
          if (isSecretKey(key) && e.value){
            add("info", e.line, key,
              "Secret present in this file, reported by length only: " + redacted(e.value) + ".",
              "Keep this file out of public folders and version control.");
          }
        });

        findings.sort(function(a, b){
          var la = (a.line === null ? 9999 : a.line), lb = (b.line === null ? 9999 : b.line);
          if (la !== lb) return la - lb;
          return SEV_RANK[a.severity] - SEV_RANK[b.severity];
        });

        var counts = { critical: 0, high: 0, medium: 0, info: 0 };
        findings.forEach(function(f){ counts[f.severity]++; });

        var verdict;
        if (counts.critical > 0) verdict = "DO NOT DEPLOY";
        else if (counts.high > 0 || counts.medium > 0) verdict = "DEPLOY WITH FIXES";
        else verdict = "SAFE TO DEPLOY";

        return { verdict: verdict, findings: findings, entries: entries, recognized: true, counts: counts };
      }

      function verdictWhy(result){
        if (!result.recognized){
          return "The paste is empty or contains no recognizable Lychee/Laravel keys (APP_KEY, APP_ENV, APP_DEBUG, APP_URL, DB_*), so there is nothing to grade.";
        }
        var c = result.counts;
        if (result.verdict === "DO NOT DEPLOY") return c.critical + " critical finding(s) must be fixed before this config faces the internet.";
        if (result.verdict === "DEPLOY WITH FIXES") return "Nothing critical, but " + (c.high + c.medium) + " warning(s) should be fixed before or right after deploying.";
        return "No problems found — every check passed or confirmed a protection already in place.";
      }

      /* ---------- Report + JSON (secret-safe) ---------- */
      function buildReport(result){
        var lines = [];
        lines.push("J-Dawgs Lychee Server Config Safety Auditor - Audit Report");
        lines.push("Verdict: " + result.verdict);
        var c = result.counts;
        lines.push("Counts: " + c.critical + " critical, " + c.high + " high, " + c.medium + " medium, " + c.info + " info");
        lines.push("Generated locally in your browser. Secret values are never shown - secrets are reported by key name, line, and length only.");
        lines.push("");
        if (!result.recognized){
          lines.push("No findings: the pasted text had no recognizable Lychee/Laravel config keys to grade.");
        } else if (!result.findings.length){
          lines.push("No findings.");
        } else {
          lines.push("Findings:");
          result.findings.forEach(function(f){
            lines.push("[" + f.severity.toUpperCase() + "] Line " + (f.line === null ? "n/a (key not present)" : f.line) + " - " + f.key);
            lines.push("  " + f.finding);
            lines.push("  Fix: " + f.fix);
          });
        }
        return scrub(lines.join("\n"), collectSecrets(result.entries));
      }

      function buildJSON(result){
        var obj = {
          tool: "J-Dawgs Lychee Server Config Safety Auditor",
          verdict: result.verdict,
          counts: result.counts,
          note: "Secret values are never included in this export. Secrets are reported by key name, line number, and length only.",
          findings: result.findings.map(function(f){
            return { severity: f.severity, line: f.line, key: f.key, finding: f.finding, fix: f.fix };
          })
        };
        return scrub(JSON.stringify(obj, null, 2), collectSecrets(result.entries));
      }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined), "EXAMPLE_RE": (typeof EXAMPLE_RE !== 'undefined' ? EXAMPLE_RE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-lychee-server-config-safety-auditortm',
  name: 'J-Dawgs Lychee Server Config Safety Auditor',
  description: '',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"], "EXAMPLE_RE": __core["EXAMPLE_RE"] }
};
