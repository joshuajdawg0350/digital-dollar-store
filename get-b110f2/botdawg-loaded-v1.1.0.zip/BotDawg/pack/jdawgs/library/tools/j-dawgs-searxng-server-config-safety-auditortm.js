'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs SearXNG Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

/* ---------- Example configs (line numbers are part of the spec) ---------- */
var RISKY = [
'# RISKY EXAMPLE - practice only, do not deploy',   /* 1 */
'general:',                                          /* 2 */
'  instance_name: "Demo Search"',                    /* 3 */
'  debug: true',                                     /* 4 */
'server:',                                           /* 5 */
'  port: 8888',                                      /* 6 */
'  bind_address: "0.0.0.0"',                         /* 7 */
'  base_url: http://search.example.com/',            /* 8 */
'  secret_key: "ultrasecretkey"',                    /* 9 */
'  limiter: false',                                  /* 10 */
'  image_proxy: false',                              /* 11 */
'search:',                                           /* 12 */
'  safe_search: 0',                                  /* 13 */
'  autocomplete: ""',                                /* 14 */
'  default_method: "GET"',                           /* 15 */
'  formats:',                                        /* 16 */
'    - html',                                        /* 17 */
'    - json',                                        /* 18 */
'    - rss',                                         /* 19 */
'redis:',                                            /* 20 */
'  url: redis://:demoplaintext@127.0.0.1:6379/0',    /* 21 */
'outgoing:',                                         /* 22 */
'  request_timeout: 30.0',                           /* 23 */
'  max_request_timeout: 60.0'                        /* 24 */
].join("\n");

var HARDENED = [
'# HARDENED EXAMPLE - still review before real use',
'general:',
'  instance_name: "Demo Search"',
'  debug: false',
'server:',
'  port: 8888',
'  bind_address: "127.0.0.1"',
'  base_url: https://search.example.com/',
'  secret_key: "kX9f2mQ7vR4pL8wN3zT6yH1bC5dA0sE9"',
'  limiter: true',
'  image_proxy: true',
'search:',
'  safe_search: 2',
'  autocomplete: ""',
'  default_method: "POST"',
'  formats:',
'    - html',
'redis:',
'  url: redis://127.0.0.1:6379/0',
'outgoing:',
'  request_timeout: 3.0',
'  max_request_timeout: 10.0'
].join("\n");

/* ---------- Parsing ---------- */
function cleanVal(v){
  v = (v || "").trim();
  v = v.replace(/\s+#.*$/, "");
  if ((v.charAt(0) === '"' && v.charAt(v.length-1) === '"') ||
      (v.charAt(0) === "'" && v.charAt(v.length-1) === "'")) {
    v = v.slice(1, -1);
  }
  return v.trim();
}

function parseConfig(text){
  var lines = text.split(/\r?\n/);
  var entries = [];       /* {key, value, line, section} */
  var formatItems = [];   /* {value, line} */
  var section = "";
  var inFormats = false, formatsIndent = -1;
  var mentionsSearxng = /searxng/i.test(text);
  for (var i = 0; i < lines.length; i++){
    var raw = lines[i], lineNo = i + 1;
    var trimmed = raw.trim();
    if (!trimmed || trimmed.charAt(0) === "#") continue;
    var indent = raw.length - raw.replace(/^\s+/, "").length;

    if (inFormats){
      var itemMatch = trimmed.match(/^-\s*(.+)$/);
      if (itemMatch && indent > formatsIndent){
        formatItems.push({ value: cleanVal(itemMatch[1]).toLowerCase(), line: lineNo });
        continue;
      } else if (indent <= formatsIndent) {
        inFormats = false;
      }
    }

    var envMatch = trimmed.match(/^([A-Za-z][A-Za-z0-9_]*)=(.*)$/);
    if (envMatch && envMatch[1] === envMatch[1].toUpperCase() && envMatch[1].indexOf("_") !== -1){
      entries.push({ key: envMatch[1].toLowerCase(), value: cleanVal(envMatch[2]), line: lineNo, section: "env" });
      continue;
    }

    var kv = trimmed.match(/^([A-Za-z0-9_.\-]+)\s*:\s*(.*)$/);
    if (kv){
      var key = kv[1].toLowerCase(), val = cleanVal(kv[2]);
      if (indent === 0 && val === "") section = key;
      entries.push({ key: key, value: val, line: lineNo, section: section });
      if (key === "formats"){
        if (val){
          var inner = val.replace(/^\[/, "").replace(/\]$/, "");
          inner.split(",").forEach(function(p){
            var pv = cleanVal(p).toLowerCase();
            if (pv) formatItems.push({ value: pv, line: lineNo });
          });
        } else { inFormats = true; formatsIndent = indent; }
      }
      continue;
    }
  }
  return { entries: entries, formatItems: formatItems, mentionsSearxng: mentionsSearxng, lineCount: lines.length };
}

function findEntry(entries, keys, section){
  for (var i = 0; i < entries.length; i++){
    var e = entries[i];
    if (keys.indexOf(e.key) !== -1 && (!section || e.section === section)) return e;
  }
  return null;
}
function findEnvStyle(entries, suffixes){
  for (var i = 0; i < entries.length; i++){
    var k = entries[i].key;
    for (var j = 0; j < suffixes.length; j++){
      if (k === suffixes[j] || k.slice(-(suffixes[j].length + 1)) === "_" + suffixes[j]) return entries[i];
    }
  }
  return null;
}
function get(entries, yamlKeys, envSuffixes, section){
  return findEntry(entries, yamlKeys, section) || findEntry(entries, yamlKeys, null) || findEnvStyle(entries, envSuffixes || []);
}
function truthy(v){ return /^(true|yes|on|1)$/i.test(v || ""); }
function falsy(v){ return /^(false|no|off|0)$/i.test(v || ""); }

/* ---------- The audit ---------- */
var SECRET_DEFAULTS = ["ultrasecretkey","secret","secretkey","changeme","change-me","change_me","your-secret-key","your_secret_key","searxng-secret","default","example","password"];

function audit(text){
  var parsed = parseConfig(text || "");
  var entries = parsed.entries;
  var findings = [], passed = [];
  function F(severity, check, key, line, detail, fix){
    findings.push({ severity: severity, check: check, key: key, line: line, detail: detail, fix: fix });
  }
  function P(text2){ passed.push(text2); }

  /* Is this a SearXNG config at all? */
  var known = ["bind_address","secret_key","image_proxy","limiter","safe_search","default_method","base_url","formats","engines","outgoing","server","search","redis","valkey","debug","instance_name","port"];
  var seen = {};
  entries.forEach(function(e){ if (known.indexOf(e.key) !== -1) seen[e.key] = true; });
  var seenCount = Object.keys(seen).length;
  var gradeable = parsed.mentionsSearxng || seenCount >= 3 || (seenCount >= 2 && findEntry(entries, ["engines"], null));
  if (!gradeable){
    return { verdict: "NOT ENOUGH TO GRADE", gradeable: false, findings: [], passed: [],
      why: "This paste does not look like a SearXNG config — too few recognisable SearXNG settings were found. Paste a settings.yml (or SearXNG environment lines) and run the audit again." };
  }

  /* debug */
  var debugE = get(entries, ["debug"], ["debug"]);
  if (debugE && truthy(debugE.value)){
    F("critical","Debug mode","debug",debugE.line,"Debug is switched on. A deployed instance in debug mode exposes internals, verbose errors, and reload behaviour that should never face the public.","Set debug to false in the general section before deploying.");
  } else if (debugE){
    P("Debug mode is off (line " + debugE.line + ").");
  } else {
    P("No debug setting found — SearXNG defaults it to off; confirm it stays off.");
  }

  /* bind address + port */
  var bindE = get(entries, ["bind_address"], ["bind_address","bind"]);
  var portE = get(entries, ["port"], ["port"]);
  var bindPublic = false;
  if (bindE){
    var bv = bindE.value;
    if (bv === "0.0.0.0" || bv === "::" || bv === "*"){
      bindPublic = true;
      F("high","Bind address exposure","bind_address",bindE.line,
        "The instance binds to " + bv + (portE ? " on port " + portE.value + " (line " + portE.line + ")" : "") + ", which listens on every network interface — anyone who can reach this machine can reach the search page.",
        "Bind to 127.0.0.1 and put a reverse proxy in front of it, or firewall the port so only your proxy can reach it.");
    } else if (bv === "127.0.0.1" || bv === "localhost" || bv === "::1"){
      P("Bind address is loopback-only (" + bv + ", line " + bindE.line + ")" + (portE ? ", port " + portE.value : "") + ".");
    } else {
      P("Bind address is set to a specific interface (" + bv + ", line " + bindE.line + ") — confirm that interface is the one you intend.");
    }
  } else {
    F("low","Bind address not stated","bind_address",null,"No bind_address was found in the paste, so the exposure depends on defaults and on how the service is launched.","State bind_address explicitly — 127.0.0.1 behind a reverse proxy is the safe default.");
  }

  /* base_url scheme */
  var baseE = get(entries, ["base_url"], ["base_url"]);
  if (baseE && baseE.value){
    if (/^http:\/\//i.test(baseE.value)){
      F("high","Base URL over plain HTTP","base_url",baseE.line,"The base_url uses http://, so searches, results, and session cookies travel unencrypted and can be read or altered in transit.","Serve the instance over https:// (a reverse proxy with a certificate is the usual route) and set base_url to the https address.");
    } else if (/^https:\/\//i.test(baseE.value)){
      P("Base URL uses https (line " + baseE.line + ").");
    } else {
      P("Base URL is set without an http/https scheme to grade (line " + baseE.line + ").");
    }
  } else {
    P("No base_url stated — nothing unencrypted to flag; set one if a proxy path or domain is used.");
  }

  /* secret_key — value NEVER rendered, only key name / line / length */
  var secretE = get(entries, ["secret_key"], ["secret_key","secret"]);
  if (!secretE){
    F("high","secret_key missing","secret_key",null,"No secret_key was found. SearXNG signs session and limiter data with this key; a missing or fallback key undermines both.","Set secret_key to a long random value of your own (32 characters or more) and keep it out of version control.");
  } else {
    var sv = secretE.value, sl = sv.length, slow = sv.toLowerCase();
    var isDefault = SECRET_DEFAULTS.indexOf(slow) !== -1 || slow.indexOf("example") !== -1 || slow.indexOf("change") !== -1 || slow.indexOf("your") === 0;
    if (isDefault){
      F("critical","secret_key is an example or unchanged default","secret_key",secretE.line,
        "Key name: secret_key. Line: " + secretE.line + ". Length: " + sl + " characters. The value matches a published example / default key that anyone can look up — the value itself is never printed here. Anyone who knows it can forge what the key protects.",
        "Generate a fresh random secret_key (32+ characters, e.g. from a password generator or openssl rand -hex 32) and restart with it.");
    } else if (sl < 20){
      F("high","secret_key is short","secret_key",secretE.line,
        "Key name: secret_key. Line: " + secretE.line + ". Length: " + sl + " characters — short enough to guess or brute-force. The value itself is never printed here.",
        "Replace it with a random key of at least 32 characters.");
    } else if (sl < 32){
      F("medium","secret_key could be longer","secret_key",secretE.line,
        "Key name: secret_key. Line: " + secretE.line + ". Length: " + sl + " characters. It is not a known default, but it is under the 32-character mark this audit treats as comfortable. The value itself is never printed here.",
        "Rotate to a random key of 32 characters or more when convenient.");
    } else {
      P("secret_key is present at line " + secretE.line + " with a length of " + sl + " characters and is not a known default (value never shown).");
    }
  }

  /* limiter / bot detection */
  var limE = get(entries, ["limiter"], ["limiter"]);
  if (limE && falsy(limE.value)){
    F("high","Limiter / bot detection off","limiter",limE.line,
      "The limiter is switched off" + (bindPublic ? " on an instance bound to every interface" : "") + ". SearXNG's limiter carries its bot detection; without it, scrapers and abusive bots can drain the instance and get it blocked by upstream engines.",
      "Set limiter to true and give it a working Redis/Valkey backend, as the SearXNG installation docs describe.");
  } else if (limE && truthy(limE.value)){
    P("Limiter is on (line " + limE.line + ") — bot detection posture is in place, provided its Redis/Valkey backend is reachable.");
  } else if (!limE){
    F("medium","Limiter not stated","limiter",null,"No limiter setting was found, so the bot-detection posture cannot be confirmed from this paste.","Set limiter explicitly to true with a Redis/Valkey backend on any public instance.");
  }

  /* image_proxy */
  var imgE = get(entries, ["image_proxy"], ["image_proxy"]);
  if (imgE && falsy(imgE.value)){
    F("medium","image_proxy off","image_proxy",imgE.line,"image_proxy is off, so visitors' browsers load result images directly from third-party sites — leaking each visitor's address and the fact they searched to every site in the results.","Set image_proxy to true so result images are fetched through your instance.");
  } else if (imgE && truthy(imgE.value)){
    P("image_proxy is on (line " + imgE.line + ").");
  } else if (!imgE){
    F("low","image_proxy not stated","image_proxy",null,"No image_proxy setting was found; the privacy posture for result images cannot be confirmed.","Set image_proxy to true explicitly.");
  }

  /* safe_search */
  var safeE = get(entries, ["safe_search"], ["safe_search","safesearch"]);
  if (safeE){
    var svv = parseInt(safeE.value, 10);
    if (svv === 0){
      F("medium","safe_search off","safe_search",safeE.line,"safe_search is 0 — no filtering is applied or offered as the default. Fine for a private instance you control; a real exposure if this page is shared with family, a workplace, or the public.","Set safe_search to 1 (moderate) or 2 (strict) if anyone beyond yourself will use the instance.");
    } else if (svv === 1 || svv === 2){
      P("safe_search is " + svv + " (line " + safeE.line + ").");
    } else {
      P("safe_search is set (line " + safeE.line + ").");
    }
  } else {
    F("low","safe_search not stated","safe_search",null,"No safe_search setting was found in the paste.","State safe_search explicitly so the default filtering level is a decision, not an accident.");
  }

  /* default method */
  var methE = get(entries, ["default_method"], ["default_method"]);
  if (methE){
    if (/^GET$/i.test(methE.value)){
      F("medium","Default method is GET","default_method",methE.line,"With GET as the default method, every search query lands in the URL — and therefore in browser history, proxy logs, and server logs.","Set default_method to POST so queries travel in the request body instead.");
    } else if (/^POST$/i.test(methE.value)){
      P("Default method is POST (line " + methE.line + ") — queries stay out of URLs and logs.");
    } else {
      P("Default method is set (line " + methE.line + ").");
    }
  } else {
    F("low","Default method not stated","default_method",null,"No default_method was found; SearXNG falls back to its built-in default, which may put queries in URLs.","Set default_method to POST explicitly.");
  }

  /* formats */
  var jsonItem = null;
  parsed.formatItems.forEach(function(it){ if (it.value === "json") jsonItem = it; });
  var formatsE = findEntry(entries, ["formats"], null);
  if (jsonItem){
    F("medium","JSON format enabled","formats",jsonItem.line,"The json output format is enabled, which turns the search page into an open API endpoint — the format scrapers and bulk harvesters prefer" + (limE && falsy(limE.value) ? ", and the limiter that would slow them down is off" : "") + ".","Remove json from the formats list unless you deliberately run a public API, and keep the limiter on if you do.");
  } else if (formatsE || parsed.formatItems.length){
    P("Formats enabled are page formats only (" + (parsed.formatItems.map(function(x){return x.value;}).join(", ") || "html") + ") — no JSON API output.");
  } else {
    F("low","Formats not stated","formats",null,"No formats list was found; the enabled output formats cannot be confirmed from this paste.","List formats explicitly and leave json out unless a public API is intended.");
  }

  /* redis / valkey URL — password reported by key name only */
  var redisE = null;
  entries.forEach(function(e){
    if ((e.section === "redis" || e.section === "valkey") && e.key === "url") redisE = e;
  });
  if (!redisE) redisE = findEnvStyle(entries, ["redis_url","valkey_url"]);
  if (redisE && redisE.value){
    var m = redisE.value.match(/^(redis|rediss|valkey):\/\/([^\/@]*:[^\/@]*@|\/\/:[^\/@]*@)/i) || redisE.value.match(/^(redis|rediss|valkey):\/\/[^\/@]*@/i);
    var hasPass = /^(redis|rediss|valkey):\/\/([^:@\/]+:[^@\/]+@|:[^@\/]+@)/i.test(redisE.value);
    if (hasPass){
      F("critical","Plain-text password in cache URL","redis.url",redisE.line,
        "Key name: redis.url. Line: " + redisE.line + ". The Redis/Valkey URL carries a password in plain text inside the config — anyone who reads this file (a leak, a repo commit, a backup) has the cache credentials. The password itself is never printed here.",
        "Move the credential out of the pasted config into a protected environment/secret store, rotate the password since it has been written down, and restrict the file's permissions.");
    } else {
      P("Redis/Valkey URL at line " + redisE.line + " carries no plain-text password.");
    }
  } else {
    P("No Redis/Valkey URL in the paste — no plain-text cache password to flag. Note the limiter needs a reachable Redis/Valkey backend when it is on.");
  }

  /* outgoing network */
  var outSection = findEntry(entries, ["outgoing"], null);
  var verifyE = get(entries, ["verify"], ["verify"]);
  if (verifyE && falsy(verifyE.value)){
    F("high","Outgoing TLS verification off","outgoing.verify",verifyE.line,"An outgoing verify setting of false disables TLS certificate checks on requests the instance makes to engines — the results it serves can be intercepted or forged in transit.","Remove the false verify setting so outgoing requests verify certificates.");
  }
  var rtE = findEntry(entries, ["request_timeout"], "outgoing") || findEntry(entries, ["request_timeout"], null);
  var mrtE = findEntry(entries, ["max_request_timeout"], "outgoing") || findEntry(entries, ["max_request_timeout"], null);
  var rt = rtE ? parseFloat(rtE.value) : NaN, mrt = mrtE ? parseFloat(mrtE.value) : NaN;
  if (!isNaN(rt) && rt > 10){
    F("low","Long outgoing request timeout","outgoing.request_timeout",rtE.line,"request_timeout is " + rtE.value + " seconds. Slow engines can hold workers for that long on every query, so a handful of bad engines can stall the whole instance.","Bring request_timeout down toward the SearXNG default range (a few seconds) unless a specific engine needs more.");
  }
  if (!isNaN(mrt) && mrt > 30){
    F("low","Long outgoing max request timeout","outgoing.max_request_timeout",mrtE.line,"max_request_timeout is " + mrtE.value + " seconds, which lets a single query wait over half a minute before giving up.","Lower max_request_timeout so stuck queries fail fast.");
  }
  if (!outSection && !rtE && !mrtE){
    F("low","Outgoing settings not stated","outgoing",null,"No outgoing section was found; request timeouts and connection behaviour fall back to defaults that cannot be confirmed from this paste.","State the outgoing timeouts explicitly so slow engines cannot stall the instance unnoticed.");
  } else if ((isNaN(rt) || rt <= 10) && (isNaN(mrt) || mrt <= 30) && !(verifyE && falsy(verifyE.value))){
    P("Outgoing timeouts are modest" + (rtE ? " (request_timeout " + rtE.value + "s, line " + rtE.line + ")" : "") + ".");
  }

  /* verdict */
  var hasCrit = findings.some(function(f){return f.severity==="critical";});
  var verdict, why;
  if (hasCrit){
    verdict = "DO NOT DEPLOY";
    why = "At least one critical finding is present. Do not expose this instance until the critical items are fixed and the config is re-audited.";
  } else if (findings.length){
    verdict = "DEPLOY WITH FIXES";
    why = "No critical findings, but the items below should be fixed before this instance faces other people.";
  } else {
    verdict = "SAFE TO DEPLOY";
    why = "Every check in this audit passed. This grades the configuration only — keep the server patched and monitored like any public service.";
  }
  return { verdict: verdict, gradeable: true, findings: findings, passed: passed, why: why };
}

/* ---------- Reports ---------- */
function buildTextReport(r){
  var out = [];
  out.push("J-Dawgs SearXNG Server Config Safety Auditor - Report");
  out.push("======================================================");
  out.push("Verdict: " + r.verdict);
  out.push(r.why || "");
  out.push("");
  if (!r.gradeable){
    out.push("No findings: the paste was not recognisable as a SearXNG config.");
    return out.join("\n");
  }
  var counts = {critical:0,high:0,medium:0,low:0};
  r.findings.forEach(function(f){ counts[f.severity]++; });
  out.push("Findings: " + r.findings.length + " (critical " + counts.critical + ", high " + counts.high + ", medium " + counts.medium + ", low " + counts.low + ")");
  out.push("Checks passed: " + r.passed.length);
  out.push("");
  if (r.findings.length){
    out.push("FINDINGS");
    out.push("--------");
    r.findings.forEach(function(f, i){
      out.push((i+1) + ". [" + f.severity.toUpperCase() + "] " + f.check + " - key: " + f.key + (f.line ? ", line " + f.line : ", not found in paste"));
      out.push("   " + f.detail);
      out.push("   Fix: " + f.fix);
    });
    out.push("");
  }
  if (r.passed.length){
    out.push("CHECKS PASSED");
    out.push("-------------");
    r.passed.forEach(function(p){ out.push("- " + p); });
    out.push("");
  }
  out.push("Notes: graded offline in the browser. No server was started or contacted.");
  out.push("Secret values are never printed in this report - keys are named by key, line, and length only.");
  return out.join("\n");
}
function buildJSON(r){
  return JSON.stringify({
    tool: "J-Dawgs SearXNG Server Config Safety Auditor",
    verdict: r.verdict,
    gradeable: r.gradeable,
    summary: r.why || "",
    counts: {
      critical: r.findings.filter(function(f){return f.severity==="critical";}).length,
      high: r.findings.filter(function(f){return f.severity==="high";}).length,
      medium: r.findings.filter(function(f){return f.severity==="medium";}).length,
      low: r.findings.filter(function(f){return f.severity==="low";}).length,
      passed: r.passed.length
    },
    findings: r.findings,
    passed: r.passed,
    notes: "Graded offline in the browser. No server was started or contacted. Secret values are never included; keys are reported by name, line, and length only."
  }, null, 2);
}

/* ---------- UI wiring ---------- */
var lastResult = null, lastText = "", lastJSON = "{}";
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-searxng-server-config-safety-auditortm',
  name: 'J-Dawgs SearXNG Server Config Safety Auditor',
  description: 'Grades a pasted SearXNG settings.yml / env config offline into one deploy verdict: bind exposure, plaintext secrets, and unsafe defaults caught before anything runs; secrets reported by key name, line, and length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
