'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Airflow Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        /* ---------- Worked examples (line numbers are index + 1) ---------- */

        var RISKY_LINES = [
          "[core]",
          "executor = CeleryExecutor",
          "fernet_key =",
          "unit_test_mode = True",
          "sql_alchemy_conn = postgresql://airflow:airflow@db.internal:5432/airflow",
          "",
          "[webserver]",
          "expose_config = True",
          "secret_key = changeme",
          "authenticate = False",
          "",
          "[api]",
          "auth_backends = airflow.api.auth.backend.default",
          "",
          "[celery]",
          "broker_url = redis://:Br0kerSecret99@redis.internal:6379/0",
          "result_backend = db+postgresql://airflow:airflow@db.internal:5432/results",
          "",
          "[scheduler]",
          "catchup_by_default = True",
          "this line is not a setting and cannot be parsed"
        ];

        var HARDENED_LINES = [
          "# Secrets are supplied at deploy time, not stored in this file.",
          "# fernet_key is provided through the AIRFLOW__CORE__FERNET_KEY environment variable.",
          "[core]",
          "executor = CeleryExecutor",
          "fernet_key_cmd = /opt/airflow/secrets/get-fernet-key",
          "unit_test_mode = False",
          "sql_alchemy_conn_cmd = /opt/airflow/secrets/get-db-url",
          "",
          "[webserver]",
          "expose_config = False",
          "secret_key_cmd = /opt/airflow/secrets/get-webserver-secret",
          "",
          "[api]",
          "auth_backends = airflow.api.auth.backend.session",
          "",
          "[celery]",
          "broker_url = rediss://redis.internal:6380/0",
          "result_backend = db+postgresql://db.internal:5432/results?sslmode=require",
          "",
          "[scheduler]",
          "catchup_by_default = False"
        ];

        /* ---------- Parsing ---------- */

        var KNOWN_KEYS = {
          fernet_key: 1, fernet_key_cmd: 1, fernet_key_secret: 1,
          expose_config: 1, executor: 1, auth_backends: 1, broker_url: 1,
          result_backend: 1, sql_alchemy_conn: 1, sql_alchemy_conn_cmd: 1,
          sql_alchemy_conn_secret: 1, unit_test_mode: 1, dags_folder: 1,
          secret_key: 1, secret_key_cmd: 1, secret_key_secret: 1,
          authenticate: 1, debug: 1
        };

        function stripQuotes(v) {
          var s = String(v).trim();
          if (s.length >= 2) {
            var a = s.charAt(0), b = s.charAt(s.length - 1);
            if ((a === '"' && b === '"') || (a === "'" && b === "'")) return s.slice(1, -1).trim();
          }
          return s;
        }

        function parseBool(v) {
          var s = stripQuotes(v).toLowerCase();
          if (s === "true" || s === "yes" || s === "on" || s === "1") return true;
          if (s === "false" || s === "no" || s === "off" || s === "0") return false;
          return null;
        }

        function parseConfig(text) {
          var lines = String(text).replace(/\r\n?/g, "\n").split("\n");
          var entries = [];        // {section, sectionRaw, key, keyRaw, value, line}
          var sections = {};       // lower name -> {raw, line}
          var sectionOrder = [];
          var notParsed = [];
          var current = null;      // lower section name
          var currentRaw = "";
          for (var i = 0; i < lines.length; i++) {
            var lineNo = i + 1;
            var raw = lines[i];
            var t = raw.trim();
            if (t === "") continue;
            if (t.charAt(0) === "#" || t.charAt(0) === ";") continue;
            var sec = t.match(/^\[([^\]]+)\]\s*(?:[#;].*)?$/);
            if (sec) {
              current = sec[1].trim().toLowerCase();
              currentRaw = sec[1].trim();
              if (!sections[current]) {
                sections[current] = { raw: currentRaw, line: lineNo };
                sectionOrder.push(current);
              }
              continue;
            }
            var kv = raw.match(/^\s*([^=:\s][^=:]*?)\s*(?:=|:)\s*(.*)$/);
            if (kv) {
              entries.push({
                section: current || "",
                sectionRaw: currentRaw,
                key: kv[1].trim().toLowerCase(),
                keyRaw: kv[1].trim(),
                value: kv[2].trim(),
                line: lineNo
              });
              continue;
            }
            notParsed.push(lineNo);
          }
          return { entries: entries, sections: sections, sectionOrder: sectionOrder, notParsed: notParsed, lineCount: lines.length };
        }

        function findEntries(parsed, section, key) {
          var out = [];
          for (var i = 0; i < parsed.entries.length; i++) {
            var e = parsed.entries[i];
            if (e.section === section && e.key === key) out.push(e);
          }
          return out;
        }
        function lastEntry(parsed, section, key) {
          var list = findEntries(parsed, section, key);
          return list.length ? list[list.length - 1] : null;
        }

        /* ---------- URL helpers (password is detected, never returned) ---------- */

        function parseUrl(value) {
          var s = stripQuotes(value);
          var m = s.match(/^([a-zA-Z][a-zA-Z0-9+.\-]*):\/\/([^/?#]*)/);
          if (!m) return null;
          var authority = m[2];
          var at = authority.lastIndexOf("@");
          var userinfo = at >= 0 ? authority.slice(0, at) : null;
          var hasPassword = false;
          if (userinfo !== null) {
            var colon = userinfo.indexOf(":");
            if (colon >= 0 && userinfo.slice(colon + 1).length > 0) hasPassword = true;
          }
          return { scheme: m[1].toLowerCase(), hasPassword: hasPassword, hasUserinfo: userinfo !== null };
        }

        var PLACEHOLDERS = {
          "changeme": 1, "change-me": 1, "change_me": 1, "change me": 1,
          "password": 1, "passw0rd": 1, "secret": 1, "admin": 1,
          "airflow": 1, "default": 1, "letmein": 1, "123456": 1, "12345": 1,
          "your-password": 1, "your_password": 1, "yourpassword": 1,
          "replace-me": 1, "replaceme": 1, "replace_me": 1, "xxx": 1, "todo": 1
        };
        function isPlaceholder(value) {
          var s = stripQuotes(value).toLowerCase();
          if (s === "" || s.indexOf("://") >= 0) return false;
          if (PLACEHOLDERS[s]) return true;
          if (s.indexOf("changeme") >= 0) return true;
          if (/^your[-_]/.test(s)) return true;
          return false;
        }
        var SECRETY_KEY = /(password|passwd|secret|token|fernet|api[-_]?key|access[-_]?key|private[-_]?key)/;

        /* ---------- Audit ---------- */

        var SEV_RANK = { CRITICAL: 0, HIGH: 1, MEDIUM: 2, INFO: 3 };

        function auditConfig(text) {
          var parsed = parseConfig(text == null ? "" : text);
          var findings = [];
          function add(severity, section, key, line, message, fix) {
            findings.push({
              severity: severity,
              section: section || "",
              key: key || "",
              line: (typeof line === "number" && line > 0) ? line : null,
              message: message,
              fix: fix || ""
            });
          }

          var hasKnown = false;
          for (var i = 0; i < parsed.entries.length; i++) {
            if (KNOWN_KEYS[parsed.entries[i].key]) { hasKnown = true; break; }
          }
          var gradable = parsed.entries.length > 0 && (parsed.sectionOrder.length > 0 || hasKnown);

          if (!gradable) {
            add("INFO", "", "", null,
              parsed.entries.length === 0
                ? "No INI settings could be read from the pasted text, so there is nothing to grade. Paste the contents of an airflow.cfg file (sections in [brackets], one key = value per line)."
                : "The pasted text parsed as INI but contains no recognizable airflow.cfg sections or settings, so it cannot be graded as an Airflow config.",
              "");
            return finish(parsed, findings, "NOT ENOUGH TO GRADE",
              parsed.entries.length === 0
                ? "The input was empty or contained no readable key = value settings."
                : "The input does not look like an airflow.cfg.");
          }

          /* --- Fernet key posture ([core]) --- */
          var fernet = lastEntry(parsed, "core", "fernet_key");
          var fernetCmd = lastEntry(parsed, "core", "fernet_key_cmd");
          var fernetSecret = lastEntry(parsed, "core", "fernet_key_secret");
          if (fernet) {
            var fv = stripQuotes(fernet.value);
            if (fv === "") {
              add("CRITICAL", "core", "fernet_key", fernet.line,
                "[core] fernet_key is present but empty. With no Fernet key, Airflow stores connection and variable passwords effectively unencrypted in the metadata database.",
                "Generate a real Fernet key and set it, or supply it through fernet_key_cmd / fernet_key_secret or the AIRFLOW__CORE__FERNET_KEY environment variable.");
            } else if (isPlaceholder(fv)) {
              add("CRITICAL", "core", "fernet_key", fernet.line,
                "[core] fernet_key is set to a placeholder value, which is not a working encryption key (flagged by key name only; the value is not shown).",
                "Replace it with a generated Fernet key, or supply the key through a _cmd/_secret reference or the environment.");
            } else {
              add("INFO", "core", "fernet_key", fernet.line,
                "[core] fernet_key is present (" + fv.length + " characters; the value itself is never shown). " + (fv.length === 44 ? "44 characters is the standard length for a Fernet key." : "Note: a standard Fernet key is 44 characters; this value is " + fv.length + ", so confirm it is a valid key."),
                "");
            }
          } else if (fernetCmd || fernetSecret) {
            var ref = fernetCmd || fernetSecret;
            add("INFO", "core", ref.key, ref.line,
              "[core] fernet_key is not written in the file; it is supplied through " + ref.key + " (line " + ref.line + "), so there is no plaintext key in the config to flag. This audit cannot verify the referenced source actually returns a valid key.",
              "");
          } else if (String(text).indexOf("AIRFLOW__CORE__FERNET_KEY") >= 0) {
            add("INFO", "core", "fernet_key", parsed.sections.core ? parsed.sections.core.line : null,
              "[core] fernet_key is not written in the file, and the pasted text notes it is provided through the AIRFLOW__CORE__FERNET_KEY environment variable, so it is treated as externally supplied rather than missing. This audit cannot verify the environment of a running instance.",
              "");
          } else {
            add("CRITICAL", "core", "fernet_key", parsed.sections.core ? parsed.sections.core.line : null,
              "[core] fernet_key is missing from the pasted config, and no fernet_key_cmd / fernet_key_secret reference or AIRFLOW__CORE__FERNET_KEY environment note appears. Without a Fernet key, connection passwords are stored effectively unencrypted.",
              "Set fernet_key in [core], or supply it via fernet_key_cmd / fernet_key_secret or the AIRFLOW__CORE__FERNET_KEY environment variable.");
          }

          /* --- Config exposure ([webserver] expose_config) --- */
          var expose = lastEntry(parsed, "webserver", "expose_config");
          if (expose && parseBool(expose.value) === true) {
            add("CRITICAL", "webserver", "expose_config", expose.line,
              "[webserver] expose_config = True. The web UI will display the full Airflow configuration — including any secrets stored in it — to anyone who can open the config view.",
              "Set expose_config = False in [webserver].");
          }

          /* --- Credentials embedded in URLs (any key) --- */
          var credsFlagged = {};
          for (var u = 0; u < parsed.entries.length; u++) {
            var ue = parsed.entries[u];
            var url = parseUrl(ue.value);
            if (url && url.hasPassword) {
              credsFlagged[ue.line] = true;
              add("CRITICAL", ue.section, ue.key, ue.line,
                "[" + (ue.sectionRaw || "no section") + "] " + ue.keyRaw + " holds a " + url.scheme + ":// URL with a password embedded in it (flagged by key name and line only; the password is never shown). Anyone who can read this file holds that credential, and the config file tends to travel — backups, repos, tickets.",
                "Remove the password from the URL and supply the credential through a secret reference (_cmd/_secret), an environment variable, or a secrets backend.");
            }
          }

          /* --- Plaintext broker / result backend transport --- */
          var PLAIN_SCHEMES = { redis: 1, amqp: 1, http: 1, ws: 1, pyamqp: 1 };
          ["broker_url", "result_backend"].forEach(function (k) {
            ["celery", "core", ""].forEach(function (sec) {
              var e = lastEntry(parsed, sec, k);
              if (e) {
                var bu = parseUrl(e.value);
                if (bu && PLAIN_SCHEMES[bu.scheme] && !credsFlagged[e.line]) {
                  add("MEDIUM", e.section, e.key, e.line,
                    "[" + (e.sectionRaw || "no section") + "] " + e.keyRaw + " uses the plaintext " + bu.scheme + ":// scheme with no TLS, so traffic to it — tasks, results, and anything they carry — crosses the network unencrypted.",
                    "Switch to the TLS scheme (rediss:// or amqps://) or tunnel the connection.");
                }
              }
            });
          });

          /* --- API auth posture ([api] auth_backends) --- */
          var backends = lastEntry(parsed, "api", "auth_backends");
          if (!backends) {
            add("HIGH", "api", "auth_backends", parsed.sections.api ? parsed.sections.api.line : null,
              "[api] auth_backends is not set in the pasted config. The API authentication posture is left at its defaults with no backend restriction recorded in the file.",
              "Set auth_backends in [api] to the backend(s) you actually intend — for example the session backend — and nothing more permissive.");
          } else {
            var bv = stripQuotes(backends.value).toLowerCase();
            if (bv === "") {
              add("HIGH", "api", "auth_backends", backends.line,
                "[api] auth_backends is present but empty, so no API authentication backend is in force from this file.",
                "Set auth_backends in [api] to the backend(s) you actually intend.");
            } else if (bv.indexOf("airflow.api.auth.backend.default") >= 0) {
              add("HIGH", "api", "auth_backends", backends.line,
                "[api] auth_backends still includes airflow.api.auth.backend.default, the permissive default backend that lets API requests through without authentication.",
                "Remove the default backend and list only the backend(s) that authenticate — for example airflow.api.auth.backend.session.");
            } else if (bv.indexOf("airflow.api.auth.backend.deny_all") >= 0) {
              add("INFO", "api", "auth_backends", backends.line,
                "[api] auth_backends includes the deny-all backend, which refuses API authentication outright — restrictive, not permissive.",
                "");
            }
          }

          /* --- Webserver authenticate off --- */
          var authenticate = lastEntry(parsed, "webserver", "authenticate");
          if (authenticate && parseBool(authenticate.value) === false) {
            add("HIGH", "webserver", "authenticate", authenticate.line,
              "[webserver] authenticate = False. The web UI's own authentication is switched off in this file, so the interface relies entirely on whatever sits in front of it.",
              "Set authenticate = True in [webserver], or document and enforce the external authentication layer that replaces it.");
          }

          /* --- Celery executor worker posture --- */
          var executor = lastEntry(parsed, "core", "executor");
          if (executor && stripQuotes(executor.value).toLowerCase().indexOf("celery") >= 0) {
            var broker = lastEntry(parsed, "celery", "broker_url");
            if (!broker) {
              add("MEDIUM", "core", "executor", executor.line,
                "[core] executor selects a Celery executor but no broker_url appears in [celery], so this file records no broker — and no worker authentication posture — at all.",
                "Record the broker_url in [celery] and make sure access to the broker itself is restricted and encrypted.");
            } else {
              var burl = parseUrl(broker.value);
              var tls = burl && (burl.scheme === "rediss" || burl.scheme === "amqps" || burl.scheme === "pyamqps");
              if (!tls) {
                add("MEDIUM", "core", "executor", executor.line,
                  "[core] executor selects a Celery executor whose broker connection is not TLS, and the config shows no worker authentication posture: workers will execute whatever the broker hands them, so anyone who can reach the broker can submit tasks.",
                  "Use a TLS broker URL (rediss:// / amqps://), restrict broker access, and rotate any credential the broker has seen.");
              }
            }
          }

          /* --- Webserver secret_key presence --- */
          if (parsed.sections.webserver &&
              !lastEntry(parsed, "webserver", "secret_key") &&
              !lastEntry(parsed, "webserver", "secret_key_cmd") &&
              !lastEntry(parsed, "webserver", "secret_key_secret")) {
            add("MEDIUM", "webserver", "secret_key", parsed.sections.webserver.line,
              "[webserver] sets no secret_key and no secret_key_cmd / secret_key_secret reference, so the webserver falls back to a default or per-start generated signing key for sessions.",
              "Set a stable secret_key in [webserver], or supply it through secret_key_cmd / secret_key_secret.");
          }

          /* --- Debug / test settings --- */
          for (var d = 0; d < parsed.entries.length; d++) {
            var de = parsed.entries[d];
            if (de.key === "debug" && parseBool(de.value) === true) {
              add("MEDIUM", de.section, "debug", de.line,
                "[" + (de.sectionRaw || "no section") + "] debug = True is left on in a config headed for deployment.",
                "Set debug = False outside development.");
            }
            if (de.key === "unit_test_mode" && de.section === "core" && parseBool(de.value) === true) {
              add("MEDIUM", "core", "unit_test_mode", de.line,
                "[core] unit_test_mode = True is left on. Test mode changes Airflow's behavior (including around the metadata database) and has no place in a deployed config.",
                "Set unit_test_mode = False in [core].");
            }
          }

          /* --- Placeholder / default values (key name only) --- */
          for (var p = 0; p < parsed.entries.length; p++) {
            var pe = parsed.entries[p];
            if (pe.key === "fernet_key") continue;          // handled above
            if (credsFlagged[pe.line]) continue;            // URL creds already CRITICAL
            if (isPlaceholder(pe.value)) {
              var sev = SECRETY_KEY.test(pe.key) ? "HIGH" : "MEDIUM";
              add(sev, pe.section, pe.key, pe.line,
                "[" + (pe.sectionRaw || "no section") + "] " + pe.keyRaw + " is set to a placeholder or well-known default value (flagged by key name only; the value is not shown). Defaults like this are the first thing an attacker tries.",
                "Replace it with a real, unique value — ideally supplied through a _cmd/_secret reference or the environment rather than written in the file.");
            }
          }

          /* --- Unparsed lines --- */
          if (parsed.notParsed.length) {
            add("INFO", "", "", parsed.notParsed[0],
              "Line" + (parsed.notParsed.length > 1 ? "s" : "") + " " + parsed.notParsed.join(", ") +
              " could not be parsed as a section header, comment, or key = value pair, and " +
              (parsed.notParsed.length > 1 ? "were" : "was") + " excluded from this audit — not guessed at.",
              "");
          }

          findings.sort(function (a, b) {
            var r = SEV_RANK[a.severity] - SEV_RANK[b.severity];
            if (r !== 0) return r;
            var la = a.line === null ? 999999 : a.line;
            var lb = b.line === null ? 999999 : b.line;
            return la - lb;
          });

          var counts = countSev(findings);
          var verdict, why;
          if (counts.CRITICAL > 0) {
            verdict = "DO NOT DEPLOY";
            why = counts.CRITICAL + " CRITICAL finding" + (counts.CRITICAL > 1 ? "s" : "") + " — at least one issue here hands out secrets or leaves stored passwords unprotected. Fix those before this config goes anywhere near a host.";
          } else if (counts.HIGH > 0 || counts.MEDIUM > 0) {
            verdict = "DEPLOY WITH FIXES";
            why = "No CRITICAL findings, but " + (counts.HIGH + counts.MEDIUM) + " HIGH/MEDIUM finding" + ((counts.HIGH + counts.MEDIUM) > 1 ? "s" : "") + " should be fixed before this config is deployed.";
          } else {
            verdict = "SAFE TO DEPLOY";
            why = "No CRITICAL, HIGH, or MEDIUM findings in the pasted text — none of the dangerous patterns this audit checks for were found.";
          }
          return finish(parsed, findings, verdict, why);
        }

        function countSev(findings) {
          var c = { CRITICAL: 0, HIGH: 0, MEDIUM: 0, INFO: 0 };
          findings.forEach(function (f) { c[f.severity]++; });
          return c;
        }

        function finish(parsed, findings, verdict, why) {
          return {
            verdict: verdict,
            why: why,
            counts: countSev(findings),
            findings: findings,
            parsedSettings: parsed.entries.length,
            sectionCount: parsed.sectionOrder.length,
            notParsedLines: parsed.notParsed.slice()
          };
        }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-airflow-config-safety-auditortm',
  name: 'J-Dawgs Airflow Config Safety Auditor',
  description: 'Grades a pasted airflow.cfg offline — expose_config, Fernet posture, auth, plaintext broker/backend credentials by key name + line only — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
