'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Bazarr Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ============================================================
         Worked examples. The API keys and passwords below are fake,
         planted values used only as sample input and by the
         self-test's leak check.
         ============================================================ */
      var RISKY_EXAMPLE = [
        "# Risky example - do not run a server like this",
        "auth:",
        "  type: none",
        "general:",
        "  ip: 0.0.0.0",
        "  port: 6767",
        "  base_url: ''",
        "  debug: true",
        "  use_proxy: false",
        "sonarr:",
        "  url: http://localhost:8989",
        "  apikey: 'a1b2c3d4e5f60718293a4b5c6d7e8f90'",
        "radarr:",
        "  url: http://localhost:7878",
        "  apikey: 'f9e8d7c6b5a4938271605f4e3d2c1b0a'",
        "providers:",
        "  opensubtitles:",
        "    username: movie_fan_88",
        "    password: 'subtitle-hunter-42'"
      ].join("\n");

      var HARDENED_EXAMPLE = [
        "# Hardened example - sign-in on, local bind, debug off",
        "auth:",
        "  type: form",
        "  username: admin",
        "  password: 'correct-horse-battery-staple-42'",
        "general:",
        "  ip: 127.0.0.1",
        "  port: 6767",
        "  base_url: ''",
        "  debug: false",
        "  use_proxy: false",
        "sonarr:",
        "  url: http://localhost:8989",
        "  apikey: '0123456789abcdeffedcba9876543210'",
        "radarr:",
        "  url: http://localhost:7878",
        "  apikey: '55aa55aa55aa55aa55aa55aa55aa55aa'"
      ].join("\n");

      /* Planted secrets, named by key only. The self-test asserts each
         value occurs 0 times in the rendered audit output. */
      var PLANTED_SECRETS = [
        { label: "sonarr.apikey (risky example)",       value: "a1b2c3d4e5f60718293a4b5c6d7e8f90" },
        { label: "radarr.apikey (risky example)",       value: "f9e8d7c6b5a4938271605f4e3d2c1b0a" },
        { label: "providers.opensubtitles.password (risky example)", value: "subtitle-hunter-42" },
        { label: "auth.password (hardened example)",    value: "correct-horse-battery-staple-42" },
        { label: "sonarr.apikey (hardened example)",    value: "0123456789abcdeffedcba9876543210" },
        { label: "radarr.apikey (hardened example)",    value: "55aa55aa55aa55aa55aa55aa55aa55aa" }
      ];

      /* ============================================================
         Tolerant line-based parser for YAML-style "key: value" text.
         Tracks indentation so nested keys get dotted paths
         (e.g. providers.opensubtitles.password). Also accepts
         "key = value" lines. Never throws on odd input.
         ============================================================ */
      function cleanValue(raw) {
        var v = raw.trim();
        if (v.length >= 2) {
          var q = v.charAt(0);
          if (q === "'" || q === '"') {
            var end = v.indexOf(q, 1);
            if (end > 0) return v.slice(1, end);
          }
        }
        var hash = v.indexOf(" #");
        if (hash >= 0) v = v.slice(0, hash);
        return v.trim();
      }

      function parseConfig(text) {
        var entries = [];   // { path:[...], key:"a.b.c", value:"...", line:n }
        var stack = [];     // { indent:n, name:"..." }
        var lines = String(text == null ? "" : text).split(/\r?\n/);
        for (var i = 0; i < lines.length; i++) {
          var rawLine = lines[i];
          var trimmed = rawLine.replace(/^\s+/, "");
          if (!trimmed || trimmed.charAt(0) === "#") continue;
          var indent = rawLine.length - trimmed.length;
          var key = null, rawVal = null;

          var eqIdx = trimmed.indexOf("=");
          var colonIdx = trimmed.indexOf(":");
          if (eqIdx > 0 && (colonIdx < 0 || eqIdx < colonIdx)) {
            key = trimmed.slice(0, eqIdx).trim();
            rawVal = trimmed.slice(eqIdx + 1);
          } else if (colonIdx > 0) {
            key = trimmed.slice(0, colonIdx).trim();
            rawVal = trimmed.slice(colonIdx + 1);
          } else {
            continue;
          }
          key = key.replace(/^[-*]\s*/, "").replace(/['"]/g, "").toLowerCase();
          if (!key) continue;

          while (stack.length && stack[stack.length - 1].indent >= indent) stack.pop();

          var value = cleanValue(rawVal == null ? "" : rawVal);
          if (value === "" && (rawVal == null || rawVal.trim() === "")) {
            // Section header (or empty value) - becomes path context.
            stack.push({ indent: indent, name: key });
            entries.push({ path: stack.map(function (s) { return s.name; }), value: "", line: i + 1, section: true });
          } else {
            var segs = [];
            stack.forEach(function (s) { segs.push(s.name); });
            key.split(".").forEach(function (p) { if (p) segs.push(p); });
            entries.push({ path: segs, value: value, line: i + 1, section: false });
          }
        }
        return entries;
      }

      function dotted(entry) { return entry.path.join("."); }

      function findEntry(entries, candidatePaths) {
        for (var c = 0; c < candidatePaths.length; c++) {
          for (var i = 0; i < entries.length; i++) {
            if (!entries[i].section && dotted(entries[i]) === candidatePaths[c]) return entries[i];
          }
        }
        return null;
      }

      function isTruthy(v) {
        var s = String(v).toLowerCase();
        return s === "true" || s === "yes" || s === "on" || s === "1";
      }

      var SECRET_SEGMENTS = ["apikey", "api_key", "api-key", "password", "passwd", "pass", "token", "secret", "secret_key"];
      function isSecretPath(path) {
        var last = path[path.length - 1] || "";
        return SECRET_SEGMENTS.indexOf(last) >= 0 || last.indexOf("apikey") >= 0 || last.indexOf("password") >= 0;
      }

      /* ============================================================
         The audit. PRIVACY RULE: findings are built from key names,
         line numbers, and value LENGTHS only. A secret's value is
         read just long enough to measure it, and is never copied
         into a finding, so it can never reach the rendered page.
         ============================================================ */
      var SEV_ORDER = { critical: 0, high: 1, medium: 2, low: 3 };

      function auditConfig(text) {
        var entries = parseConfig(text);
        var findings = [];
        function add(severity, entry, keyLabel, title, detail, fix) {
          findings.push({
            severity: severity,
            line: entry ? entry.line : null,
            key: keyLabel,
            title: title,
            detail: detail,
            fix: fix
          });
        }

        /* --- Gather the settings the checks depend on --- */
        var hostEntry = findEntry(entries, ["general.ip", "general.host", "general.bind", "ip", "host", "bind"]);
        var hostVal = hostEntry ? hostEntry.value.trim().toLowerCase() : "";
        var hostScope = "local"; // local | network | all
        if (!hostEntry || hostVal === "" || hostVal === "0.0.0.0" || hostVal === "::" || hostVal === "*") hostScope = "all";
        else if (hostVal === "127.0.0.1" || hostVal === "localhost" || hostVal === "::1") hostScope = "local";
        else hostScope = "network";
        var scopeText = hostScope === "all" ? "every network address (0.0.0.0 / unset)"
                      : hostScope === "network" ? "a specific network address (" + hostVal + ")"
                      : "this machine only (" + hostVal + ")";

        var authTypeEntry = findEntry(entries, ["auth.type", "auth.authtype", "auth.auth_type", "auth_type"]);
        var authPassEntry = findEntry(entries, ["auth.password", "auth.pass", "password"]);
        var authType = authTypeEntry ? authTypeEntry.value.trim().toLowerCase() : "";
        var hasPassword = !!(authPassEntry && authPassEntry.value !== "");
        var authState; // "none" | "nopassword" | "missing" | "ok"
        if (authType === "none" || authType === "no" || authType === "disabled" || authType === "off") authState = "none";
        else if (authType === "form" || authType === "basic") authState = hasPassword ? "ok" : "nopassword";
        else if (authType === "" && hasPassword) authState = "ok";
        else if (authType === "" ) authState = "missing";
        else authState = hasPassword ? "ok" : "nopassword";
        var weakAuth = authState !== "ok";

        /* --- Check 1: authentication off / no password --- */
        if (authState === "none") {
          add(
            hostScope === "local" ? "high" : "critical",
            authTypeEntry, "auth.type",
            "Authentication is turned off",
            "The Bazarr web UI asks for no sign-in at all, and it is reachable on " + scopeText + ". Anyone who can reach the page can change settings, read stored keys, and control your libraries.",
            "In Bazarr, open Settings \u2192 General \u2192 Authentication, choose Form or Basic authentication, and set a username and a strong password."
          );
        } else if (authState === "nopassword") {
          add(
            hostScope === "all" ? "critical" : "high",
            authTypeEntry || authPassEntry, "auth.password",
            "Authentication is selected but no password is set",
            "The auth type asks for a sign-in, but the password setting is empty, so the sign-in protects nothing while the UI is reachable on " + scopeText + ".",
            "Set a real password for the Bazarr UI (Settings \u2192 General \u2192 Authentication) — a long passphrase you do not reuse anywhere else."
          );
        } else if (authState === "missing") {
          add(
            hostScope === "all" ? "high" : "medium",
            null, "auth",
            "No authentication settings found",
            "This config has no auth section, so Bazarr falls back to its default — no sign-in — while the UI is reachable on " + scopeText + ". If your real config sets authentication somewhere this paste did not include, you can ignore this one.",
            "Add authentication in Settings \u2192 General \u2192 Authentication (Form or Basic) and set a username and strong password, then re-check the exported config."
          );
        }

        /* --- Check 2: short UI password (length only, never the value) --- */
        if (hasPassword && authPassEntry.value.length < 8) {
          add(
            "medium", authPassEntry, "auth.password",
            "The UI password is short",
            "The configured password is only " + authPassEntry.value.length + " characters long. Short passwords fall quickly to guessing, especially on a UI reachable from the network.",
            "Use a passphrase of at least 12 characters — several words you can remember beat one short word you cannot."
          );
        }

        /* --- Check 3: listening on all interfaces --- */
        if (hostScope === "all" && weakAuth) {
          add(
            "critical", hostEntry, hostEntry ? dotted(hostEntry) : "general.ip",
            "Exposed on all interfaces with weak or no authentication",
            "The bind/host setting leaves Bazarr listening on every network interface, and the checks above show sign-in is off or empty. Together, that is an open door: anyone on the network (or the internet, if the port is forwarded) gets full control.",
            "Fix both halves: turn on Form/Basic authentication with a strong password, and bind Bazarr to 127.0.0.1 (or one LAN address) unless you deliberately serve it through a secured reverse proxy."
          );
        } else if (hostScope === "all") {
          add(
            "medium", hostEntry, hostEntry ? dotted(hostEntry) : "general.ip",
            "Listening on all network interfaces",
            "Authentication is on, which helps — but Bazarr still answers on every interface, including any public-facing one. A password prompt is the only thing between the internet and your media library if this port is ever forwarded.",
            "Bind to 127.0.0.1 or a single LAN address, keep the port out of your router's forwarding rules, and put remote access behind a VPN or an authenticated reverse proxy."
          );
        } else if (hostScope === "network" && weakAuth) {
          add(
            "high", hostEntry, dotted(hostEntry),
            "Reachable on the LAN without working authentication",
            "Bazarr is bound to a network address and sign-in is off or empty, so every device on the local network — including guests and compromised gadgets — can open the UI.",
            "Turn on authentication, or bind to 127.0.0.1 if only this machine needs the UI."
          );
        }

        /* --- Check 4: plaintext Sonarr / Radarr API keys --- */
        entries.forEach(function (e) {
          if (e.section || !e.value) return;
          var last = e.path[e.path.length - 1];
          var parent = e.path[e.path.length - 2] || "";
          if ((last === "apikey" || last === "api_key") && (parent === "sonarr" || parent === "radarr")) {
            var appName = parent === "sonarr" ? "Sonarr" : "Radarr";
            add(
              "medium", e, dotted(e),
              appName + " API key stored in plain text",
              "This file holds a live " + appName + " API key (" + e.value.length + " characters — the value itself is never shown here). Whoever reads this file can drive " + appName + " with it: add or delete media, change settings, the works.",
              "Treat config.yaml like a password file: lock down its file permissions, never paste it into chats, tickets, or forums, and if it was ever shared, rotate the key in " + appName + " under Settings \u2192 General \u2192 Security."
            );
          }
        });

        /* --- Check 5: subtitle provider passwords in plain text --- */
        entries.forEach(function (e) {
          if (e.section || !e.value) return;
          var last = e.path[e.path.length - 1];
          if ((last === "password" || last === "passwd" || last === "pass") && e.path[0] === "providers") {
            add(
              "medium", e, dotted(e),
              "Subtitle provider password stored in plain text",
              "A provider account password (" + e.value.length + " characters — never displayed here) sits unencrypted in this file. Provider accounts often share passwords with email or other accounts, so a leaked config can travel further than Bazarr.",
              "Use a unique password for subtitle providers, store your master copy in a password manager, and rotate this one if the config file has ever left your machine."
            );
          } else if (isSecretPath(e.path) && e.path[0] !== "auth" &&
                     !((last === "apikey" || last === "api_key") && (e.path[e.path.length - 2] === "sonarr" || e.path[e.path.length - 2] === "radarr")) &&
                     last !== "apikey" && last !== "api_key") {
            add(
              "medium", e, dotted(e),
              "Secret stored in plain text",
              "This setting holds a secret value (" + e.value.length + " characters — never displayed here) in an unencrypted config file.",
              "Keep the file's permissions tight, keep it out of shared folders and backups you do not control, and rotate the secret if the file was ever shared."
            );
          }
        });

        /* --- Check 6: any other API keys (e.g. other integrations) --- */
        entries.forEach(function (e) {
          if (e.section || !e.value) return;
          var last = e.path[e.path.length - 1];
          var parent = e.path[e.path.length - 2] || "";
          if ((last === "apikey" || last === "api_key") && parent !== "sonarr" && parent !== "radarr") {
            add(
              "medium", e, dotted(e),
              "API key stored in plain text",
              "This file holds an API key (" + e.value.length + " characters — the value itself is never shown here) with no encryption. Anyone who can read the file can use the key.",
              "Restrict the config file's permissions, never share it raw, and rotate the key at its source if the file has been exposed."
            );
          }
        });

        /* --- Check 7: debug logging --- */
        entries.forEach(function (e) {
          if (e.section) return;
          var last = e.path[e.path.length - 1];
          var v = e.value.trim().toLowerCase();
          if ((last === "debug" && isTruthy(v)) || ((last === "log_level" || last === "loglevel") && v === "debug")) {
            add(
              "medium", e, dotted(e),
              "Debug logging is enabled",
              "Debug logs record the fine detail of every request — including URLs and headers that can carry API keys — and they grow fast. Logs get shared for troubleshooting far more casually than configs do.",
              "Turn debug off for everyday running (Settings \u2192 General \u2192 Logging) and only switch it on while you are actively diagnosing a problem; delete old debug logs when you are done."
            );
          }
        });

        /* --- Check 8: URL base / proxy contradictions --- */
        var baseUrlEntry = findEntry(entries, ["general.base_url", "general.baseurl", "base_url"]);
        if (baseUrlEntry && baseUrlEntry.value.trim() !== "") {
          var bu = baseUrlEntry.value.trim();
          if (bu.charAt(0) !== "/") {
            add(
              "medium", baseUrlEntry, dotted(baseUrlEntry),
              "URL base does not start with a slash",
              "A URL base is meant to be a path prefix like /bazarr. Without the leading slash, a reverse proxy in front of Bazarr will route requests to the wrong place and the UI can break or land somewhere unexpected.",
              "Set the URL base to a clean path starting with / (for example /bazarr), or clear it entirely if you are not using a reverse proxy."
            );
          }
        }
        var useProxyEntry = findEntry(entries, ["general.use_proxy", "general.useproxy", "use_proxy"]);
        if (useProxyEntry && isTruthy(useProxyEntry.value)) {
          var proxyUrlEntry = findEntry(entries, ["proxy.url", "general.proxy_url", "proxy.host", "general.proxy"]);
          if (!proxyUrlEntry || proxyUrlEntry.value.trim() === "") {
            add(
              "medium", useProxyEntry, dotted(useProxyEntry),
              "Proxy is switched on but no proxy address is configured",
              "The config says to use a proxy, yet no proxy host or URL comes with it. Bazarr can fail to reach providers, or quietly fall back to direct connections you thought were proxied.",
              "Either fill in the proxy address and port you actually use, or turn the proxy setting off so the config matches reality."
            );
          } else if (proxyUrlEntry.value.indexOf("@") >= 0 && proxyUrlEntry.value.indexOf("://") >= 0) {
            add(
              "high", proxyUrlEntry, dotted(proxyUrlEntry),
              "Proxy address appears to embed a username and password",
              "The proxy URL (" + proxyUrlEntry.value.length + " characters — never displayed here) looks like it carries credentials inside it. URLs like that leak into logs, screenshots, and browser history.",
              "Move the proxy credentials into the proxy username/password fields if Bazarr offers them, restrict the config file's permissions, and rotate the proxy password if this file was shared."
            );
          }
        }
        entries.forEach(function (e) {
          if (e.section || !e.value) return;
          var last = e.path[e.path.length - 1];
          var parent = e.path[e.path.length - 2] || "";
          if (last === "url" && (parent === "sonarr" || parent === "radarr")) {
            var u = e.value.trim().toLowerCase();
            if (u.indexOf("http://") !== 0 && u.indexOf("https://") !== 0) {
              add(
                "low", e, dotted(e),
                "Service URL does not start with http:// or https://",
                "This connection address does not look like a complete URL, so Bazarr will likely fail to reach the service — and a mistyped address can send API keys somewhere you did not intend.",
                "Write the full address including the scheme, host, and port, exactly as the service's own UI shows it."
              );
            }
          }
        });

        findings.sort(function (a, b) {
          var s = SEV_ORDER[a.severity] - SEV_ORDER[b.severity];
          if (s !== 0) return s;
          return (a.line || 0) - (b.line || 0);
        });

        var counts = { critical: 0, high: 0, medium: 0, low: 0 };
        findings.forEach(function (f) { counts[f.severity]++; });

        var verdict = counts.critical > 0 ? "DO NOT DEPLOY"
                    : findings.length > 0 ? "DEPLOY WITH FIXES"
                    : "SAFE TO DEPLOY";

        return { verdict: verdict, findings: findings, counts: counts, parsedLines: entries.filter(function (e) { return !e.section; }).length };
      }

      /* ============================================================
         Rendering. Only finding fields are rendered — key name,
         line, lengths, and our own copy. Secret values are not
         present in the data being rendered at all.
         ============================================================ */
      function esc(s) {
        return String(s == null ? "" : s)
          .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
          .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
      }

      function renderResultsHTML(result) {
        var cls = result.verdict === "DO NOT DEPLOY" ? "danger"
                : result.verdict === "DEPLOY WITH FIXES" ? "fixes" : "safe";
        var countsText = result.counts.critical + " critical \u00B7 " + result.counts.high + " high \u00B7 " +
                         result.counts.medium + " medium \u00B7 " + result.counts.low + " low \u00B7 " +
                         result.parsedLines + " settings read";
        var html = '<div class="verdict ' + cls + '"><span class="v-label">' + esc(result.verdict) + '</span>' +
                   '<span class="v-counts">' + esc(countsText) + '</span></div>';
        if (result.findings.length === 0) {
          html += '<div class="all-clear"><strong>No findings.</strong> Nothing in this config tripped a check: authentication, bind address, stored secrets, debug logging, and URL/proxy settings all look clean. That is a statement about this config text only — keep Bazarr itself patched and behind your firewall as usual.</div>';
        }
        result.findings.forEach(function (f) {
          html += '<div class="finding">' +
            '<div class="finding-head">' +
              '<span class="chip ' + esc(f.severity) + '">' + esc(f.severity) + '</span>' +
              '<span class="key">' + esc(f.key) + '</span>' +
              (f.line ? '<span class="line-no">line ' + f.line + '</span>' : '<span class="line-no">not found in config</span>') +
            '</div>' +
            '<span class="title">' + esc(f.title) + '</span>' +
            '<p>' + esc(f.detail) + '</p>' +
            '<p class="fix"><strong>Fix:</strong> ' + esc(f.fix) + '</p>' +
          '</div>';
        });
        return html;
      }

      function runAuditInto(text, container) {
        var result = auditConfig(text);
        container.innerHTML = renderResultsHTML(result);
        return result;
      }

      /* ============================================================
         Self-test: runs the real audit + render pipeline on both
         worked examples and asserts the verdicts and the privacy
         rule (planted secrets occur 0 times in rendered output).
         ============================================================ */
      function countOccurrences(haystack, needle) {
        if (!needle) return 0;
        var n = 0, idx = 0;
        while (true) {
          idx = haystack.indexOf(needle, idx);
          if (idx < 0) break;
          n++; idx += needle.length;
        }
        return n;
      }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-bazarr-server-config-safety-auditortm',
  name: 'J-Dawgs Bazarr Server Config Safety Auditor',
  description: 'Host tools only tell you the server started; ours grades a pasted Bazarr config offline into one deploy verdict — secrets masked by key name/line/length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
