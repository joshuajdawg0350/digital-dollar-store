'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Run Cost Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the analyze function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var STORE_URL = "https://muse.ai/s/ai-tool-store-xng6xkxwjkxl2xab/UoF72OkKI7j33Q2ITxmrZyIr4nv40QtYfj2AgESh_k8";
      var EXCHANGE_URL = "https://muse.ai/s/j-dawgs-agent-exchange-ih6xlnihzxdhxc/ZbleqxFHRE0NcswaBkyN13y9lLp5rPAgHTb6t8ii-PY";

      var RUNAWAY_SAMPLE = [
        "plan | agent-standard | 8000 | 1200 | 0 | 1",
        "gather-context | agent-standard | 24000 | 900 | 0 | 1",
        "search-docs | agent-standard | 46000 | 800 | 0 | 1",
        "draft-solution | agent-standard | 66000 | 1600 | 0 | 1",
        "run-tests | agent-standard | 80000 | 600 | 0 | 6",
        "fix-failures | agent-standard | 98000 | 1200 | 0 | 1",
        "retest-suite | agent-standard | 114000 | 700 | 0 | 1",
        "expand-context | agent-standard | 128000 | 800 | 0 | 1",
        "expand-context | agent-standard | 138000 | 750 | 0 | 1",
        "expand-context | agent-standard | 145000 | 900 | 0 | 1",
        "expand-context | agent-standard | 149000 | 850 | 0 | 1",
        "expand-context | agent-standard | 152000 | 700 | 0 | 1",
        "expand-context | agent-standard | 154000 | 650 | 0 | 1",
        "write-final | agent-standard | 156000 | 2500 | 0 | 1"
      ].join("\n");

      var HEALTHY_SAMPLE = [
        "plan | agent-standard | 6000 | 900 | 0 | 1",
        "read-codebase | agent-standard | 12000 | 700 | 5000 | 1",
        "edit-module | agent-standard | 14000 | 1100 | 11000 | 1",
        "run-tests | agent-standard | 15000 | 500 | 12500 | 1",
        "fix-one-failure | agent-standard | 15500 | 800 | 13000 | 1",
        "retest | agent-standard | 15800 | 450 | 13400 | 1",
        "write-docs | agent-standard | 16000 | 1200 | 13800 | 1",
        "summarize | agent-standard | 16500 | 1500 | 14000 | 1"
      ].join("\n");

      function $(id) { return document.getElementById(id); }

      function fmtInt(n) {
        return Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
      }
      function fmtMoney(n) {
        if (!isFinite(n)) return "$0.00";
        var abs = Math.abs(n);
        var s;
        if (abs > 0 && abs < 0.01) s = n.toFixed(4);
        else if (abs < 1) s = n.toFixed(3);
        else s = n.toFixed(2);
        return "$" + s;
      }
      function fmtPct(part, whole) {
        if (!whole) return "0%";
        return (Math.round((part / whole) * 1000) / 10) + "%";
      }
      function num(v) {
        if (v === null || v === undefined) return NaN;
        var s = String(v).replace(/[$,\s]/g, "");
        if (s === "") return NaN;
        var n = Number(s);
        return isFinite(n) ? n : NaN;
      }

      /* ---------- Parsing ---------- */
      function parseLine(raw) {
        var t = raw.trim();
        if (t.charAt(0) === "{") {
          var obj;
          try { obj = JSON.parse(t); }
          catch (e) { return { error: "not valid JSON" }; }
          var step = {
            name: obj.step !== undefined ? String(obj.step) : (obj.name !== undefined ? String(obj.name) : ""),
            model: obj.model !== undefined ? String(obj.model) : "",
            input: num(obj.input),
            output: num(obj.output),
            cached: obj.cached === undefined ? 0 : num(obj.cached),
            attempts: obj.attempts === undefined ? 1 : num(obj.attempts)
          };
          return validateStep(step);
        }
        var parts = t.split("|");
        if (parts.length < 4) return { error: "needs at least: name | model | input | output" };
        var s2 = {
          name: parts[0].trim(),
          model: (parts[1] || "").trim(),
          input: num(parts[2]),
          output: num(parts[3]),
          cached: parts.length > 4 && parts[4].trim() !== "" ? num(parts[4]) : 0,
          attempts: parts.length > 5 && parts[5].trim() !== "" ? num(parts[5]) : 1
        };
        return validateStep(s2);
      }
      function validateStep(s) {
        if (!s.name) return { error: "missing step name" };
        if (isNaN(s.input)) return { error: "input tokens is not a number" };
        if (isNaN(s.output)) return { error: "output tokens is not a number" };
        if (isNaN(s.cached)) return { error: "cached tokens is not a number" };
        if (isNaN(s.attempts)) return { error: "attempts is not a number" };
        if (s.input < 0 || s.output < 0 || s.cached < 0) return { error: "token counts can't be negative" };
        if (s.attempts < 1) return { error: "attempts must be at least 1" };
        s.attempts = Math.floor(s.attempts);
        if (s.cached > s.input) s.cached = s.input; /* cached is a subset of input */
        return { step: s };
      }
      function parseLog(text) {
        var steps = [], errors = [];
        var lines = text.split(/\r?\n/);
        for (var i = 0; i < lines.length; i++) {
          if (!lines[i].trim()) continue;
          var r = parseLine(lines[i]);
          if (r.error) errors.push({ line: i + 1, reason: r.error, raw: lines[i].trim() });
          else steps.push(r.step);
        }
        return { steps: steps, errors: errors };
      }

      /* ---------- Phases ----------
         Each step lands in exactly one phase, so phase costs sum to the run
         total. Rule order: a step that ran more than once is "retries"; the
         closing step (or one named like a closing step) is "final"; a step
         named for loading/preparing context is "setup"; the rest is "tool". */
      var PHASE_DEFS = [
        { key: "setup", name: "Setup / context load", color: "var(--ph-setup)" },
        { key: "tool", name: "Tool work", color: "var(--ph-tool)" },
        { key: "retries", name: "Retries", color: "var(--ph-retries)" },
        { key: "final", name: "Final answer", color: "var(--ph-final)" }
      ];
      var SETUP_RE = /(plan|setup|set-up|init|context|gather|load|read|fetch|collect|retrieve|ingest|expand|prepare|scan|index)/i;
      var FINAL_RE = /(final|answer|summar)/i;
      function phaseOf(step, idx, count) {
        if (step.attempts > 1) return "retries";
        if (idx === count - 1 || FINAL_RE.test(step.name)) return "final";
        if (SETUP_RE.test(step.name)) return "setup";
        return "tool";
      }
      function buildPhases(per, steps) {
        var byKey = {};
        PHASE_DEFS.forEach(function (d) {
          byKey[d.key] = { key: d.key, name: d.name, color: d.color, count: 0, cost: 0, names: [] };
        });
        for (var i = 0; i < per.length; i++) {
          var ph = byKey[phaseOf(steps[i], i, steps.length)];
          ph.count += 1;
          ph.cost += per[i].cost;
          ph.names.push(steps[i].name);
        }
        return PHASE_DEFS.map(function (d) { return byKey[d.key]; }).filter(function (p) { return p.count > 0; });
      }

      /* One plain sentence: the single costliest step, its share of the run
         (and of the budget, when one was entered), and the one change most
         likely to cut it — picked from that step's own numbers. */
      function costliestSentence(a, budget) {
        var top = a.topStep, s = top.step;
        var fix;
        if (s.attempts > 1) {
          fix = "cap its attempts at 2 and fix the failure it kept hitting instead of paying for the whole step again";
        } else if (s.cached === 0 && s.input >= 8000) {
          fix = "turn on prompt caching — or stop re-sending the whole history — so its " + fmtInt(s.input) + " input tokens stop billing at the full input rate";
        } else if (s.input >= 20000) {
          fix = "trim the context it carries: send a running summary or just the diff instead of the whole history";
        } else if (s.output > s.input) {
          fix = "cap its output length — it writes more tokens than it reads";
        } else {
          fix = "route it to a cheaper model — as the biggest single line item, a rate cut pays back the most there";
        }
        return "The costliest step was “" + s.name + "” at " + fmtMoney(top.cost) + " — " + fmtPct(top.cost, a.total) +
          " of the run's total cost" + (budget > 0 ? " and " + fmtPct(top.cost, budget) + " of your " + fmtMoney(budget) + " budget" : "") +
          "; the one change most likely to cut it: " + fix + ".";
      }

      /* ---------- Analysis ---------- */
      function analyze(steps, rates, budget, maxSteps) {
        var i, s;
        var per = [];
        var totIn = 0, totOut = 0, totCached = 0, total = 0;
        for (i = 0; i < steps.length; i++) {
          s = steps[i];
          var uncached = Math.max(0, s.input - s.cached);
          var once = (uncached / 1e6) * rates.input + (s.output / 1e6) * rates.output + (s.cached / 1e6) * rates.cached;
          var cost = once * s.attempts;
          per.push({ step: s, once: once, cost: cost });
          totIn += s.input; totOut += s.output; totCached += s.cached; total += cost;
        }

        /* (a) Re-sent context estimate.
           Method: on each step after the first, input up to the previous step's
           (input + output) could only be material that already existed — carried
           over, not new. Re-sent tokens per step = min(this input, prev input +
           prev output), charged at the rates that actually applied (cached part
           at the cached rate), times attempts. Labeled estimate everywhere. */
        var resentTokens = 0, resentCost = 0, resentSteps = [];
        for (i = 1; i < steps.length; i++) {
          var prev = steps[i - 1], cur = steps[i];
          var carried = prev.input + prev.output;
          var rs = Math.min(cur.input, carried);
          if (rs > 0) {
            var rsCached = Math.min(rs, cur.cached);
            var rsUncached = rs - rsCached;
            var c = ((rsUncached / 1e6) * rates.input + (rsCached / 1e6) * rates.cached) * cur.attempts;
            resentTokens += rs * cur.attempts;
            resentCost += c;
            resentSteps.push({ name: cur.name, tokens: rs });
          }
        }

        /* (b) Retry burn */
        var retryCost = 0, retrySteps = [];
        for (i = 0; i < per.length; i++) {
          if (per[i].step.attempts > 1) {
            var extra = per[i].once * (per[i].step.attempts - 1);
            retryCost += extra;
            retrySteps.push({ name: per[i].step.name, attempts: per[i].step.attempts, extra: extra });
          }
        }

        /* (c) Expensive-step concentration */
        var sorted = per.slice().sort(function (a, b) { return b.cost - a.cost; });
        var top3 = sorted.slice(0, 3);
        var top3Cost = 0;
        for (i = 0; i < top3.length; i++) top3Cost += top3[i].cost;

        /* (d) Possible cache misses: cached = 0 after step 1, input large
           (>= 8,000) and within 10% of the previous step's input. */
        var missSteps = [], missSaving = 0;
        for (i = 1; i < steps.length; i++) {
          var c2 = steps[i], p2 = steps[i - 1];
          if (c2.cached === 0 && c2.input >= 8000 && p2.input > 0 &&
              Math.abs(c2.input - p2.input) / p2.input <= 0.10) {
            missSteps.push({ name: c2.name, input: c2.input });
            missSaving += ((c2.input / 1e6) * (rates.input - rates.cached)) * c2.attempts;
          }
        }
        if (missSaving < 0) missSaving = 0;

        var drivers = [
          { key: "resent", name: "Re-sent context", amount: resentCost, kind: "waste",
            fix: "Stop re-sending the whole history every step: carry a running summary, send only the diff, or turn on prompt caching so repeated context bills at the cached rate." },
          { key: "retry", name: "Retry burn", amount: retryCost, kind: "waste",
            fix: "Cap attempts per step (2 is a sane default), fail fast on repeated errors, and fix the failing step instead of letting the loop pay for it again." },
          { key: "cachemiss", name: "Possible cache misses", amount: missSaving, kind: "potential",
            fix: "Check your caching setup: repeated near-identical large inputs are arriving with zero cached tokens, so the repeated prefix is billing at the full input rate." },
          { key: "concentration", name: "Expensive-step concentration", amount: top3Cost, kind: "share",
            fix: "Route the top steps to a cheaper model or trim their context first — they are where a rate or context cut pays back the most." }
        ];
        drivers.sort(function (a, b) { return b.amount - a.amount; });

        /* Verdict */
        var overBudget = budget > 0 && total > budget;
        var overSteps = maxSteps > 0 && steps.length > maxSteps;
        var topWaste = null;
        for (i = 0; i < drivers.length; i++) {
          if (drivers[i].kind === "waste" || drivers[i].kind === "potential") { topWaste = drivers[i]; break; }
        }
        var verdict, vclass;
        if (overBudget && topWaste && (topWaste.key === "retry" || topWaste.key === "resent") && topWaste.amount > 0) {
          verdict = "RUNAWAY PATTERN"; vclass = "bad";
        } else if (overBudget || overSteps) {
          verdict = "OVER BUDGET"; vclass = "warn";
        } else {
          verdict = "WITHIN BUDGET"; vclass = "ok";
        }

        /* Cap plan derivations */
        var costs = per.map(function (p) { return p.cost; });
        var sortedCosts = costs.slice().sort(function (a, b) { return a - b; });
        var median = sortedCosts.length % 2 === 1
          ? sortedCosts[(sortedCosts.length - 1) / 2]
          : (sortedCosts[sortedCosts.length / 2 - 1] + sortedCosts[sortedCosts.length / 2]) / 2;
        var cum = 0, step80 = steps.length;
        for (i = 0; i < per.length; i++) {
          cum += per[i].cost;
          if (total > 0 && cum >= 0.8 * total) { step80 = i + 1; break; }
        }
        var derivedStepCap = Math.min(step80, steps.length);
        var recStepCap = derivedStepCap;
        var stepCapNote = "Derived from your log: 80% of this run's total estimated cost had been spent by step " + derivedStepCap + " of " + steps.length + ", so a cap there stops the expensive tail.";
        if (maxSteps > 0 && maxSteps < recStepCap) {
          recStepCap = maxSteps;
          stepCapNote = "Your entered max steps (" + maxSteps + ") is tighter than the log-derived point (80% of cost spent by step " + derivedStepCap + " of " + steps.length + "), so your number wins.";
        }
        var dailyCheck = 2 * median;

        return {
          per: per, total: total, totIn: totIn, totOut: totOut, totCached: totCached,
          phases: buildPhases(per, steps), topStep: sorted.length ? sorted[0] : null,
          resentTokens: resentTokens, resentCost: resentCost, resentSteps: resentSteps,
          retryCost: retryCost, retrySteps: retrySteps,
          top3: top3, top3Cost: top3Cost,
          missSteps: missSteps, missSaving: missSaving,
          drivers: drivers, verdict: verdict, vclass: vclass,
          overBudget: overBudget, overSteps: overSteps, topWaste: topWaste,
          median: median, dailyCheck: dailyCheck, recStepCap: recStepCap, stepCapNote: stepCapNote
        };
      }

      /* ---------- Budget Breach Forecast ----------
         Pure arithmetic on the audited run's own per-step costs — the costs
         analyze() already computed, attempts multiplier included. Nothing here
         predicts anything: it restates this log's numbers at other volumes.
         Every value passes through fz() so the panel never shows a negative
         or a NaN. */
      function fz(x) { return (isFinite(x) && x > 0) ? x : 0; }
      function buildForecast(a) {
        var T = fz(a.total);
        var n = a.per.length;
        var f = { T: T, n: n, repeat10: T * 10, repeat100: T * 100, growth: null, top: null };
        if (n >= 2) {
          var firstCount = Math.floor(n / 2);
          var firstSum = 0, secondSum = 0, i;
          for (i = 0; i < firstCount; i++) firstSum += a.per[i].cost;
          for (i = firstCount; i < n; i++) secondSum += a.per[i].cost;
          var F = firstSum / firstCount;
          var S = secondSum / (n - firstCount);
          if (isFinite(F) && F > 0) {
            var g = S / F;
            var addAvg = S * g;
            f.growth = {
              F: F, S: fz(S), g: fz(g), addAvg: fz(addAvg),
              proj: fz(T + n * addAvg),
              firstCount: firstCount, secondCount: n - firstCount
            };
          }
        }
        if (a.topStep) {
          var D = fz(a.topStep.cost);
          var Tp = fz(T - D / 2);
          f.top = { name: a.topStep.step.name, D: D, saving: D / 2, Tp: Tp, Tp10: Tp * 10, Tp100: Tp * 100 };
        }
        return f;
      }

      function renderForecast(a) {
        var f = buildForecast(a);
        var label = "Arithmetic on the pasted log's own rates — NOT a prediction.";
        var html = "";
        html += "<h3>(a) If the same run repeats, unchanged</h3>";
        html += "<p>" + label + " Inputs: total run cost T = <span class='num'>" + fmtMoney(f.T) + "</span>, step count n = <span class='num'>" + f.n + "</span>.</p>";
        html += "<ul class='plain'>";
        html += "<li>Projected cost of the next 10 identical runs = T × 10 = <span class='num'>" + fmtMoney(f.repeat10) + "</span>.</li>";
        html += "<li>Projected cost of the next 100 identical runs = T × 100 = <span class='num'>" + fmtMoney(f.repeat100) + "</span>.</li>";
        html += "</ul>";
        html += "<h3>(b) If a run ran twice as long</h3>";
        if (!f.growth) {
          html += "<p>Not enough steps in this log to compute a growth projection.</p>";
        } else {
          var gr = f.growth;
          html += "<p>" + label + " Steps split in log order: first half = the first " + gr.firstCount + " step" + (gr.firstCount > 1 ? "s" : "") +
            ", second half = the remaining " + gr.secondCount + " step" + (gr.secondCount > 1 ? "s" : "") + ". " +
            "First-half average per-step cost F = <span class='num'>" + fmtMoney(gr.F) + "</span>; second-half average per-step cost S = <span class='num'>" + fmtMoney(gr.S) + "</span>; " +
            "growth factor g = S / F = <span class='num'>" + gr.g.toFixed(2) + "×</span> (the second-half average is " + Math.round(gr.g * 100) + "% of the first-half average).</p>";
          html += "<p>Formula, in plain text: projected average cost for the additional steps = S × g. " +
            "Projected cost of a run twice as long (" + (2 * f.n) + " steps) = T + n × (S × g) = " + fmtMoney(f.T) + " + " + f.n + " × (" + fmtMoney(gr.S) + " × " + gr.g.toFixed(2) + ") = <span class='num'>" + fmtMoney(gr.proj) + "</span>.</p>";
        }
        html += "<h3>(c) Cheapest single change: halve the costliest step</h3>";
        if (f.top) {
          html += "<p>" + label + " Top-driver step: “" + esc(f.top.name) + "” at D = <span class='num'>" + fmtMoney(f.top.D) + "</span>. " +
            "Recomputed arithmetic, not a guarantee: if that one step's cost were halved, the saving per run would be D / 2 = <span class='num'>" + fmtMoney(f.top.saving) + "</span> " +
            "and the recomputed total would be T' = T − D / 2 = <span class='num'>" + fmtMoney(f.top.Tp) + "</span>. " +
            "Recomputed repeat projections at that halved total: T' × 10 = <span class='num'>" + fmtMoney(f.top.Tp10) + "</span>; T' × 100 = <span class='num'>" + fmtMoney(f.top.Tp100) + "</span>.</p>";
        }
        $("forecastBody").innerHTML = html;
      }

      /* ---------- Rendering ---------- */
      function esc(s) {
        return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
      }

      function driverDetail(d, a) {
        if (d.key === "resent") {
          var names = a.resentSteps.slice(0, 4).map(function (x) { return x.name; }).join(", ");
          return "Estimate — method: on each step after the first, input up to the previous step's input + output could only be material that already existed, so it is counted as re-sent and charged at the rates that applied (cached part at the cached rate), times attempts. " +
            fmtInt(a.resentTokens) + " re-sent tokens across " + a.resentSteps.length + " steps" + (names ? " (" + names + (a.resentSteps.length > 4 ? ", …" : "") + ")" : "") +
            ". Input kept growing while outputs stayed small — the classic signature of a history being re-sent whole.";
        }
        if (d.key === "retry") {
          if (!a.retrySteps.length) return "No step in this log ran more than once, so retries cost nothing here.";
          return a.retrySteps.map(function (x) {
            return "“" + x.name + "” ran " + x.attempts + " times — the " + (x.attempts - 1) + " extra attempt" + (x.attempts - 1 > 1 ? "s" : "") + " cost " + fmtMoney(x.extra) + ".";
          }).join(" ");
        }
        if (d.key === "cachemiss") {
          if (!a.missSteps.length) return "No step matched the pattern (zero cached tokens on a large input that nearly repeats the previous step's input).";
          return "Flag, not a certainty: " + a.missSteps.length + " step" + (a.missSteps.length > 1 ? "s" : "") + " after the first (" +
            a.missSteps.slice(0, 4).map(function (x) { return x.name; }).join(", ") + ") had cached = 0 with a large input within 10% of the previous step's input — possible cache miss, check your caching setup. " +
            "The amount shown is the potential extra paid versus billing those inputs at your cached rate; it overlaps the re-sent context estimate, so don't add the two together.";
        }
        /* concentration */
        return "The top 3 steps by cost — " + a.top3.map(function (p) {
          return "“" + p.step.name + "” " + fmtMoney(p.cost);
        }).join(", ") + " — together are " + fmtPct(a.top3Cost, a.total) + " of the whole run. This is a share of the total, not extra waste on top of the other drivers.";
      }

      var lastReport = "";
      var stepsExpanded = false;

      function runAudit() {
        var status = $("inputStatus");
        var errBox = $("parseErrors");
        var text = $("logInput").value;
        status.className = "status";
        if (!text.trim()) {
          status.textContent = "Paste a run log first — or load one of the samples above — then run the audit.";
          status.className = "status err";
          $("results").style.display = "none";
          errBox.style.display = "none";
          return;
        }
        var parsed = parseLog(text);
        if (parsed.errors.length) {
          var html = "<strong>" + parsed.errors.length + " line" + (parsed.errors.length > 1 ? "s" : "") + " couldn't be read and were left out:</strong><ul>";
          parsed.errors.forEach(function (e) {
            html += "<li>Line " + e.line + ": " + esc(e.reason) + " — <code>" + esc(e.raw.length > 90 ? e.raw.slice(0, 90) + "…" : e.raw) + "</code></li>";
          });
          html += "</ul>";
          errBox.innerHTML = html;
          errBox.style.display = "block";
        } else {
          errBox.style.display = "none";
        }
        if (!parsed.steps.length) {
          status.textContent = "No readable steps in that log — check the format examples above and try again.";
          status.className = "status err";
          $("results").style.display = "none";
          return;
        }
        var rates = {
          input: num($("rateInput").value) || 0,
          output: num($("rateOutput").value) || 0,
          cached: num($("rateCached").value) || 0
        };
        var budget = num($("budget").value);
        if (isNaN(budget) || budget < 0) budget = 0;
        var maxSteps = num($("maxSteps").value);
        if (isNaN(maxSteps) || maxSteps < 0) maxSteps = 0;

        var a = analyze(parsed.steps, rates, budget, maxSteps);
        render(a, rates, budget, maxSteps, parsed.steps.length);
        status.textContent = "Audited " + parsed.steps.length + " steps" + (parsed.errors.length ? " (" + parsed.errors.length + " unreadable lines excluded, listed above)" : "") + ".";
      }

      function render(a, rates, budget, maxSteps, stepCount) {
        $("results").style.display = "block";

        /* Verdict */
        var vb = $("verdictBox");
        vb.className = "verdict " + a.vclass;
        $("verdictName").textContent = a.verdict;
        var detail = "";
        if (a.verdict === "RUNAWAY PATTERN") {
          detail = "Total estimated cost " + fmtMoney(a.total) + " against a " + fmtMoney(budget) + " budget — and the biggest driver is " +
            a.topWaste.name.toLowerCase() + " (" + fmtMoney(a.topWaste.amount) + "). That is the pattern that turns a long run into a surprise bill: the run kept paying for the same material instead of finishing.";
        } else if (a.verdict === "OVER BUDGET") {
          var bits = [];
          if (a.overBudget) bits.push("cost " + fmtMoney(a.total) + " vs. budget " + fmtMoney(budget));
          if (a.overSteps) bits.push(stepCount + " steps vs. a max of " + maxSteps);
          detail = "Over the line: " + bits.join("; ") + ". The cap plan below shows the limits that would have caught it.";
        } else {
          detail = "Total estimated cost " + fmtMoney(a.total) + (budget > 0 ? " against a " + fmtMoney(budget) + " budget" : "") +
            ", " + stepCount + " steps" + (maxSteps > 0 ? " against a max of " + maxSteps : "") + ". Nothing in this log matches a runaway pattern — the cap plan below still locks in the headroom.";
        }
        $("verdictDetail").textContent = detail;

        /* Biggest fix first */
        var top = a.drivers[0];
        $("bigFix").innerHTML = "<strong>Fix this first:</strong> " + esc(top.fix) +
          " <span style='color:var(--muted)'>(" + esc(top.name) + " — " + fmtMoney(top.amount) +
          (top.kind === "share" ? ", " + fmtPct(top.amount, a.total) + " of the run" : ", " + fmtPct(top.amount, a.total) + " of the run") + ".)</span>";

        /* Costliest-step narrative — one plain sentence */
        $("costliestNarrative").innerHTML = "<strong>Costliest step:</strong> " + esc(costliestSentence(a, budget));

        /* Phase timeline */
        $("phaseBar").innerHTML = a.phases.map(function (p) {
          var pct = a.total > 0 ? (p.cost / a.total) * 100 : (p.count / stepCount) * 100;
          return "<div style='width:" + pct.toFixed(2) + "%;background:" + p.color + "' title='" + esc(p.name) + ": " + fmtPct(p.cost, a.total) + " of cost'></div>";
        }).join("");
        $("phaseList").innerHTML = a.phases.map(function (p) {
          return "<div class='phaserow'><div class='phead'><span class='pname'><span class='swatch' style='background:" + p.color + "'></span>" + esc(p.name) + "</span>" +
            "<span class='pamt'>" + fmtMoney(p.cost) + " · " + fmtPct(p.cost, a.total) + " of cost</span></div>" +
            "<p>" + p.count + " step" + (p.count > 1 ? "s" : "") + " · " + fmtPct(p.count, stepCount) + " of steps — " +
            esc(p.names.join(", ")) + "</p></div>";
        }).join("");

        /* Stats */
        var stats = [
          ["Steps parsed", fmtInt(stepCount)],
          ["Input tokens", fmtInt(a.totIn)],
          ["Output tokens", fmtInt(a.totOut)],
          ["Cached input tokens", fmtInt(a.totCached)],
          ["Total est. cost", fmtMoney(a.total)],
          ["Median step cost", fmtMoney(a.median)]
        ];
        if (budget > 0) stats.push(["Budget", fmtMoney(budget)]);
        $("statGrid").innerHTML = stats.map(function (s) {
          return "<div class='stat'><div class='k'>" + esc(s[0]) + "</div><div class='v'>" + esc(s[1]) + "</div></div>";
        }).join("");

        /* Step table — runs over 25 steps start collapsed to the first 25
           rows, with an expand control; the total row always shows. */
        var collapsible = stepCount > 25;
        stepsExpanded = false;
        var rows = "";
        a.per.forEach(function (p, i) {
          var s = p.step;
          var extra = collapsible && i >= 25;
          rows += "<tr" + (extra ? " class='step-extra' style='display:none;'" : "") + ">" +
            "<td data-label='Step'>" + (i + 1) + ". " + esc(s.name) + "</td>" +
            "<td data-label='Model'>" + esc(s.model || "—") + "</td>" +
            "<td class='num' data-label='Input'>" + fmtInt(s.input) + "</td>" +
            "<td class='num' data-label='Output'>" + fmtInt(s.output) + "</td>" +
            "<td class='num' data-label='Cached'>" + fmtInt(s.cached) + "</td>" +
            "<td class='num' data-label='Tries'>" + s.attempts + "</td>" +
            "<td class='cost' data-label='Cost'>" + fmtMoney(p.cost) + "</td></tr>";
        });
        $("stepBody").innerHTML = rows;
        $("stepToggleRow").style.display = collapsible ? "flex" : "none";
        if (collapsible) $("btnToggleSteps").textContent = "Show all " + stepCount + " steps";
        $("stepFoot").innerHTML = "<tr><td>Total</td><td></td>" +
          "<td class='num' data-label='Input'>" + fmtInt(a.totIn) + "</td>" +
          "<td class='num' data-label='Output'>" + fmtInt(a.totOut) + "</td>" +
          "<td class='num' data-label='Cached'>" + fmtInt(a.totCached) + "</td>" +
          "<td></td><td class='cost' data-label='Cost'>" + fmtMoney(a.total) + "</td></tr>";

        /* Drivers */
        $("driverList").innerHTML = a.drivers.map(function (d) {
          var pct = a.total > 0 ? Math.min(100, (d.amount / a.total) * 100) : 0;
          var tag = d.kind === "waste" ? "<span class='tag'>estimate</span>"
            : d.kind === "potential" ? "<span class='tag'>flag · potential</span>"
            : "<span class='tag'>share of total</span>";
          var amtLabel = (d.kind === "potential" ? "up to " : "") + fmtMoney(d.amount) + " · " + fmtPct(d.amount, a.total) + " of run";
          return "<div class='driver'><div class='dhead'><span class='dname'>" + esc(d.name) + tag + "</span>" +
            "<span class='damt'>" + amtLabel + "</span></div>" +
            "<div class='bar'><div style='width:" + pct.toFixed(1) + "%'></div></div>" +
            "<p class='detail'>" + esc(driverDetail(d, a)) + "</p>" +
            "<p><strong>Fix:</strong> " + esc(d.fix) + "</p></div>";
        }).join("");

        /* Cap plan */
        var hardCap = budget > 0 ? budget : a.total;
        var hardCapNote = budget > 0
          ? "Your entered per-run budget. A hard stop at this number would have ended this run " + fmtMoney(a.total - budget) + (a.total > budget ? " earlier." : " — the run stayed under it.")
          : "No budget was entered, so this uses the run's own total (" + fmtMoney(a.total) + ") as the placeholder — set a real budget below what a run is worth to you.";
        if (budget > 0 && a.total <= budget) hardCapNote = "Your entered per-run budget — this run stayed under it, with " + fmtMoney(budget - a.total) + " to spare.";
        var trimList = a.top3.map(function (p) { return "“" + p.step.name + "” (" + fmtMoney(p.cost) + ")"; }).join(", ");
        var retryNote = a.retrySteps.length
          ? " Also cap attempts at 2 on: " + a.retrySteps.map(function (x) { return "“" + x.name + "” (" + x.attempts + " tries)"; }).join(", ") + "."
          : "";
        var missNote = a.missSteps.length
          ? " And check caching on: " + a.missSteps.slice(0, 4).map(function (x) { return "“" + x.name + "”"; }).join(", ") + " — flagged as possible cache misses."
          : "";
        var planItems = [
          { label: "Per-run hard cap: <span class='num'>" + fmtMoney(hardCap) + "</span> — stop the run the moment cumulative estimated spend crosses it.",
            note: hardCapNote },
          { label: "Max steps: <span class='num'>" + a.recStepCap + "</span> — end the run after this many steps no matter what.",
            note: a.stepCapNote },
          { label: "Daily-check threshold: <span class='num'>" + fmtMoney(a.dailyCheck) + " per step</span> — any single step costing more than this gets a human (or supervisor-agent) look the same day.",
            note: "Derived from your log: 2 × the median step cost (median = " + fmtMoney(a.median) + " across " + stepCount + " steps)." },
          { label: "Route or trim first: " + esc(trimList) + " — these are the most expensive steps, so a cheaper model, a smaller context, or a cached prefix pays back fastest there." + esc(retryNote) + esc(missNote),
            note: "Derived from your log: the top 3 steps by estimated cost, plus any step that retried or was flagged for a possible cache miss." }
        ];
        $("planList").innerHTML = planItems.map(function (p) {
          return "<li>" + p.label + "<span class='derived'>" + esc(p.note) + "</span></li>";
        }).join("");

        renderForecast(a);

        lastReport = buildReport(a, rates, budget, maxSteps, stepCount, hardCapNote);
        $("reportText").value = lastReport;
        $("copyStatus").textContent = "";
        $("results").scrollIntoView({ behavior: "smooth", block: "start" });
      }

      function buildReport(a, rates, budget, maxSteps, stepCount, hardCapNote) {
        var L = [];
        L.push("J-DAWGS RUN COST AUDITOR — AUDIT REPORT");
        L.push("Costs are estimates from the rates you enter. This is not a bill and does not read any provider account.");
        L.push("");
        L.push("RATES USED (per 1M tokens): input " + fmtMoney(rates.input) + " · output " + fmtMoney(rates.output) + " · cached input " + fmtMoney(rates.cached));
        L.push("BUDGET: " + (budget > 0 ? fmtMoney(budget) : "not entered") + " · MAX STEPS: " + (maxSteps > 0 ? maxSteps : "not entered"));
        L.push("");
        L.push("VERDICT: " + a.verdict);
        L.push($("verdictDetail").textContent);
        L.push("BIGGEST FIX FIRST: " + a.drivers[0].fix);
        L.push("");
        L.push("TOTALS: " + stepCount + " steps · input " + fmtInt(a.totIn) + " tokens · output " + fmtInt(a.totOut) + " tokens · cached " + fmtInt(a.totCached) + " tokens · total estimated cost " + fmtMoney(a.total));
        L.push("");
        L.push("COSTLIEST STEP: " + costliestSentence(a, budget));
        L.push("");
        L.push("PHASE TIMELINE (every step in exactly one phase; phase costs sum to the run total):");
        a.phases.forEach(function (p) {
          L.push("  " + p.name + " — " + p.count + " step" + (p.count > 1 ? "s" : "") + " (" + fmtPct(p.count, stepCount) + " of steps), " + fmtMoney(p.cost) + " (" + fmtPct(p.cost, a.total) + " of cost): " + p.names.join(", "));
        });
        L.push("");
        L.push("COST PER STEP:");
        a.per.forEach(function (p, i) {
          var s = p.step;
          L.push("  " + (i + 1) + ". " + s.name + " (" + (s.model || "no model") + ") — in " + fmtInt(s.input) + ", out " + fmtInt(s.output) + ", cached " + fmtInt(s.cached) + ", attempts " + s.attempts + " → " + fmtMoney(p.cost));
        });
        L.push("  TOTAL → " + fmtMoney(a.total));
        L.push("");
        L.push("WASTE DRIVERS (ranked):");
        a.drivers.forEach(function (d, i) {
          L.push("  " + (i + 1) + ". " + d.name + " — " + fmtMoney(d.amount) + " (" + fmtPct(d.amount, a.total) + " of run)" +
            (d.kind === "waste" ? " [estimate]" : d.kind === "potential" ? " [flag — potential, overlaps re-sent context]" : " [share of total]"));
          L.push("     " + driverDetail(d, a));
          L.push("     Fix: " + d.fix);
        });
        L.push("");
        L.push("CAP PLAN:");
        L.push("  - Per-run hard cap: " + fmtMoney(budget > 0 ? budget : a.total) + ". " + hardCapNote);
        L.push("  - Max steps: " + a.recStepCap + ". " + a.stepCapNote);
        L.push("  - Daily-check threshold: " + fmtMoney(a.dailyCheck) + " per step (2 × the median step cost of " + fmtMoney(a.median) + " from this log). Investigate any step above it the same day.");
        L.push("  - Route or trim first: " + a.top3.map(function (p) { return p.step.name + " (" + fmtMoney(p.cost) + ")"; }).join(", ") + ".");
        if (a.retrySteps.length) L.push("  - Cap attempts at 2 on: " + a.retrySteps.map(function (x) { return x.name + " (" + x.attempts + " tries)"; }).join(", ") + ".");
        if (a.missSteps.length) L.push("  - Check caching on: " + a.missSteps.map(function (x) { return x.name; }).join(", ") + " — possible cache miss, check your caching setup.");
        L.push("");
        L.push("HONEST LIMITS: estimates only, from user-entered rates; token counts come from the pasted log (this tool does not tokenize text); re-sent-context and cache-miss findings are heuristics; this tool cannot enforce a cap itself — it produces the plan.");
        L.push("");
        L.push("Built by J-Dawgs™, © 2026 Joshua Dawson.");
        return L.join("\n");
      }
  return { "analyze": (typeof analyze !== 'undefined' ? analyze : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RUNAWAY_SAMPLE": (typeof RUNAWAY_SAMPLE !== 'undefined' ? RUNAWAY_SAMPLE : undefined), "HEALTHY_SAMPLE": (typeof HEALTHY_SAMPLE !== 'undefined' ? HEALTHY_SAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["analyze"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-run-cost-auditor',
  name: 'J-Dawgs Run Cost Auditor',
  description: 'Attributes a finished run\'s cost step by step from your rates, ranks re-sent-context / retry / cache waste, and derives a hard-cap plan — now with a phase timeline showing where the money went across the run, and a costliest-step narrative naming the single step that ate the budget — now also with a',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["analyze"]) return { ok: false, output: null, summary: 'Extracted core has no analyze function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RUNAWAY_SAMPLE": __core["RUNAWAY_SAMPLE"], "HEALTHY_SAMPLE": __core["HEALTHY_SAMPLE"] }
};
