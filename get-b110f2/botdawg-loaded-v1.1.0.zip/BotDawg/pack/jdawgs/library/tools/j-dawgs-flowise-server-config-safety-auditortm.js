'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Flowise Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

/* ---------- Worked examples (all values FAKE) ---------- */
var RISKY = [
"# Risky example - FAKE values only. Do not deploy like this.",
"FLOWISE_USERNAME=admin",
"FLOWISE_PASSWORD=1234",
"PASSPHRASE=secret",
"CORS_ORIGINS=*",
"HOST=0.0.0.0",
"PORT=3000",
"DEBUG=true",
"DATABASE_TYPE=postgres",
"DATABASE_USER=flowise",
"DATABASE_PASSWORD=dbpass",
"DATABASE_HOST=db.internal",
"JWT_SECRET=abc123",
"JWT_EXPIRY_IN_MINUTES=10080",
"SECRETKEY_PATH=/tmp/flowise-secret.key",
"APIKEY_PATH=/tmp/api-keys.json",
"STORAGE_TYPE=s3",
"S3_STORAGE_ACCESS_KEY_ID=fake-access-key",
"S3_STORAGE_SECRET_ACCESS_KEY=short",
"BLOB_STORAGE_PATH=/tmp/blobs",
"SMTP_HOST=smtp.example.com",
"SMTP_USER=alerts@example.com",
"SMTP_PASSWORD=mail123",
"DISABLE_FLOWISE_TELEMETRY=false"
].join("\n");

var HARDENED = [
"# Hardened example - FAKE values only, shaped the way a safer deploy looks.",
"FLOWISE_USERNAME=jd-ops-lead",
"FLOWISE_PASSWORD=Kx9vR2mQ7pL4wZ8nT3sH",
"PASSPHRASE=N7fK2wQ9xR4mZ8pL3vT6yH1sD5gJ0bVc",
"CORS_ORIGINS=https://flows.example.com,https://ops.example.com",
"HOST=127.0.0.1",
"PORT=3000",
"DEBUG=false",
"DATABASE_TYPE=postgres",
"DATABASE_USER=flowise_app",
"DATABASE_PASSWORD=D8hK3mN6pQ9rT2vX5zB7",
"DATABASE_HOST=db.internal",
"DATABASE_SSL=true",
"JWT_SECRET=Q7wE9rT2yU5iO8pA1sD4fG6hJ0kL3zX6cV9bN2mM5qW8eR",
"JWT_EXPIRY_IN_MINUTES=60",
"SECRETKEY_PATH=/app/.flowise/secret.key",
"APIKEY_PATH=/app/.flowise/api-keys.json",
"STORAGE_TYPE=s3",
"S3_STORAGE_ACCESS_KEY_ID=fake-hardened-access-key-id",
"S3_STORAGE_SECRET_ACCESS_KEY=W3eR5tY7uI9oP1aS3dF5gH7jK9lZ",
"BLOB_STORAGE_PATH=/app/.flowise/blobs",
"SMTP_HOST=smtp.example.com",
"SMTP_USER=alerts@example.com",
"SMTP_PASSWORD=M4nB6vC8xZ0aS2dF5gH7",
"DISABLE_FLOWISE_TELEMETRY=true"
].join("\n");

/* ---------- Rule data ---------- */
var KNOWN_KEYS = {
  FLOWISE_USERNAME:1, FLOWISE_PASSWORD:1, PASSPHRASE:1, APIKEY_PATH:1,
  DATABASE_TYPE:1, DATABASE_HOST:1, DATABASE_PORT:1, DATABASE_USER:1,
  DATABASE_PASSWORD:1, DATABASE_NAME:1, DATABASE_SSL:1, SECRETKEY_PATH:1,
  JWT_SECRET:1, JWT_EXPIRY_IN_MINUTES:1, JWT_ISSUER:1, JWT_AUDIENCE:1,
  CORS_ORIGINS:1, HOST:1, PORT:1, DEBUG:1, DISABLE_FLOWISE_TELEMETRY:1,
  STORAGE_TYPE:1, BLOB_STORAGE_PATH:1, SMTP_HOST:1, SMTP_PORT:1,
  SMTP_USER:1, SMTP_PASSWORD:1, SMTP_SECURE:1,
  S3_STORAGE_ACCESS_KEY_ID:1, S3_STORAGE_SECRET_ACCESS_KEY:1,
  S3_STORAGE_REGION:1, S3_STORAGE_BUCKET_NAME:1,
  AZURE_STORAGE_CONNECTION_STRING:1, GOOGLE_CLOUD_STORAGE_CREDENTIAL:1,
  FLOWISE_FILE_SIZE_LIMIT:1, NUMBER_OF_PROXIES:1, APP_URL:1, TIMEZONE:1,
  LANGCHAIN_TRACING_V2:1, LANGCHAIN_API_KEY:1, OPENAI_API_KEY:1,
  MODEL_LIST_CONFIG_JSON:1, GLOBAL_AGENT_HTTP_PROXY:1
};
var DEFAULT_SECRETS = {
  "1234":1,"12345":1,"123456":1,"12345678":1,"password":1,"password123":1,
  "admin":1,"admin123":1,"secret":1,"changeme":1,"change-me":1,"default":1,
  "flowise":1,"flowise123":1,"letmein":1,"qwerty":1,"test":1,"test123":1,
  "dbpass":1,"postgres":1,"root":1,"example":1,"yourpassword":1,"mail123":1
};
function isDefaultSecret(v){
  var s = String(v).toLowerCase();
  if (DEFAULT_SECRETS[s]) return true;
  if (s.indexOf("changeme") === 0 || s.indexOf("change-me") === 0) return true;
  if (s.indexOf("your-") === 0 || s.indexOf("your_") === 0) return true;
  if (s === "example-password" || s === "examplepassword") return true;
  return false;
}
function isSecretKey(key){
  if (/_PATH$/.test(key)) return false;
  if (/_ID$/.test(key)) return false;
  return /(PASSWORD|PASSPHRASE|SECRET|TOKEN|API_?KEY|ACCESS_KEY|CONNECTION_STRING|CREDENTIAL)/.test(key);
}
function truthy(v){ var s=String(v).trim().toLowerCase(); return s==="true"||s==="1"||s==="yes"||s==="on"; }
function falsy(v){ var s=String(v).trim().toLowerCase(); return s==="false"||s==="0"||s==="no"||s==="off"; }

/* ---------- Parsing ---------- */
function parseConfig(text){
  var entries = [];
  var lines = String(text == null ? "" : text).split(/\r\n|\r|\n/);
  for (var i = 0; i < lines.length; i++){
    var raw = lines[i];
    var t = raw.trim();
    if (!t || t.charAt(0) === "#") continue;
    var m = t.match(/^(?:export\s+)?([A-Za-z_][A-Za-z0-9_.]*)\s*=\s*(.*)$/);
    if (!m){
      var m2 = t.match(/^([A-Za-z_][A-Za-z0-9_.]*)\s*:\s*(.+)$/);
      if (m2) m = m2; else continue;
    }
    var key = m[1].toUpperCase();
    var val = String(m[2] == null ? "" : m[2]).trim();
    if (val.length >= 2 && ((val.charAt(0)==='"' && val.charAt(val.length-1)==='"') || (val.charAt(0)==="'" && val.charAt(val.length-1)==="'"))){
      val = val.slice(1, -1);
    }
    entries.push({ key:key, value:val, line:i+1 });
  }
  var map = {};
  entries.forEach(function(e){ map[e.key] = e; });
  return { entries:entries, map:map, totalLines:lines.length };
}

/* ---------- Audit ---------- */
function audit(text){
  var parsed = parseConfig(text);
  var entries = parsed.entries, map = parsed.map;
  var findings = [];
  function add(sev, key, entry, title, detail, fix){
    findings.push({
      severity: sev,
      key: key || "",
      line: entry ? entry.line : null,
      secretLength: (entry && key && isSecretKey(key)) ? entry.value.length : null,
      title: title, detail: detail, fix: fix
    });
  }
  function secretCheck(key, entry, goodLen, label){
    if (!entry) return;
    var v = entry.value, len = v.length, reasons = [];
    var sev = null;
    if (len === 0){ add("critical", key, entry, label + " is empty", label + " is set but empty, which is the same as having no secret at all.", "Set a long, unique, randomly generated value and store it in a secrets manager or a locked-down environment file."); return; }
    if (isDefaultSecret(v)){ reasons.push("it matches a well-known default / example value"); sev = "critical"; }
    if (len < 8){ reasons.push("it is only " + len + " characters long"); sev = "critical"; }
    else if (len < goodLen){ reasons.push("it is " + len + " characters long, below the " + goodLen + "-character bar for this setting"); if (!sev) sev = "warning"; }
    if (sev){
      add(sev, key, entry, "Weak " + label,
        label + " (" + key + ") is reported by length only: " + len + " characters. Problem: " + reasons.join("; ") + ". Anyone who can guess or brute-force this value gets in.",
        "Replace it with a unique random value of at least " + goodLen + " characters from a password manager or generator. Never reuse a password from another service, and rotate it if it was ever shared or committed to a repo.");
    }
  }

  /* Not-a-Flowise-config gate */
  var signals = entries.filter(function(e){
    return KNOWN_KEYS[e.key] || e.key.indexOf("FLOWISE") === 0 || e.key.indexOf("DATABASE_") === 0 || e.key.indexOf("S3_STORAGE") === 0;
  });
  if (entries.length === 0 || signals.length === 0){
    findings.push({ severity:"info", key:"", line:null, secretLength:null,
      title:"Nothing recognizable to grade",
      detail:"This paste contains " + (entries.length === 0 ? "no KEY=VALUE settings at all" : "no settings this auditor recognizes as Flowise configuration") + ". It may be the wrong file, a different app's config, or free-form text.",
      fix:"Paste the environment variables / .env contents from your Flowise deployment (look for FLOWISE_USERNAME, DATABASE_TYPE, CORS_ORIGINS and similar keys), then audit again." });
    return finish("NOT ENOUGH TO GRADE", parsed, findings,
      "The paste does not look like a Flowise configuration, so there is nothing honest to grade.");
  }

  var userE = map["FLOWISE_USERNAME"], passE = map["FLOWISE_PASSWORD"];
  var authWeak = !passE || !passE.value || passE.value.length < 12 || isDefaultSecret(passE.value);

  /* App login */
  if (!userE || !userE.value){
    add("critical","FLOWISE_USERNAME",null,"Missing Flowise login — no FLOWISE_USERNAME",
      "No FLOWISE_USERNAME is set. Paired with a missing password, Flowise can run with its login screen effectively unprotected, leaving chatflows and API keys open to anyone who can reach the port.",
      "Set FLOWISE_USERNAME and FLOWISE_PASSWORD before exposing the server, and restart Flowise so the login takes effect.");
  } else if (["admin","administrator","flowise","user","root"].indexOf(userE.value.toLowerCase()) !== -1){
    add("warning","FLOWISE_USERNAME",userE,"Default-style Flowise username",
      "FLOWISE_USERNAME is a widely known default-style name (reported without printing account details beyond the key). Attackers try the obvious usernames first, so half the login is already guessed.",
      "Pick a non-obvious username that is not used anywhere else, and pair it with a long unique password.");
  }
  if (!passE || !passE.value){
    add("critical","FLOWISE_PASSWORD",null,"Missing Flowise login — no FLOWISE_PASSWORD",
      "No FLOWISE_PASSWORD is set. Without it, the Flowise UI and its stored API keys, chatflows, and credentials are exposed to anyone who can reach the server.",
      "Set FLOWISE_PASSWORD to a unique random value of at least 16 characters before the server is reachable by anyone else.");
  } else {
    secretCheck("FLOWISE_PASSWORD", passE, 16, "Flowise login password");
    if (userE && userE.value && passE.value.toLowerCase() === userE.value.toLowerCase()){
      add("critical","FLOWISE_PASSWORD",passE,"Flowise password matches the username",
        "FLOWISE_PASSWORD (length " + passE.value.length + ") is the same value as the username. That is the first combination credential-stuffing tools try.",
        "Use a password that shares nothing with the username, generated randomly and stored in a password manager.");
    }
  }

  /* Passphrase + key files */
  var phraseE = map["PASSPHRASE"], secretPathE = map["SECRETKEY_PATH"], apiPathE = map["APIKEY_PATH"];
  if (phraseE && phraseE.value){ secretCheck("PASSPHRASE", phraseE, 24, "Encryption passphrase"); }
  if (!phraseE && !secretPathE){
    add("warning","PASSPHRASE",null,"No encryption passphrase or key file configured",
      "Neither PASSPHRASE nor SECRETKEY_PATH is set. Flowise encrypts stored credentials with this material; running without deliberate key management risks losing access to stored secrets on redeploy — or relying on defaults you do not control.",
      "Set a long random PASSPHRASE (24+ characters) or point SECRETKEY_PATH at a persistent key file, and back it up somewhere safe and private.");
  }
  [["SECRETKEY_PATH",secretPathE,"secret key file"],["APIKEY_PATH",apiPathE,"API key file"]].forEach(function(pair){
    var e = pair[1];
    if (e && e.value && (e.value.indexOf("/tmp") === 0 || e.value.indexOf("example") !== -1)){
      add("warning",pair[0],e,pair[0] + " points at a throwaway or example location",
        pair[0] + " points into a temporary/example location. Temporary storage is wiped on restart or redeploy, which can lock you out of every credential the " + pair[2] + " protects.",
        "Point " + pair[0] + " at a persistent, access-restricted path on durable storage, and make sure the file permissions exclude other users.");
    }
  });

  /* CORS */
  var corsE = map["CORS_ORIGINS"];
  if (!corsE || !corsE.value){
    add("info","CORS_ORIGINS",null,"CORS_ORIGINS not set",
      "No CORS_ORIGINS was pasted, so this audit cannot confirm which websites may call your Flowise API from a browser. Flowise's own default applies.",
      "Set CORS_ORIGINS explicitly to the exact origins that need access, so the posture is deliberate rather than defaulted.");
  } else if (corsE.value.trim() === "*" || /(^|,)\s*\*\s*(,|$)/.test(corsE.value)){
    add("critical","CORS_ORIGINS",corsE,"Wildcard CORS_ORIGINS",
      "CORS_ORIGINS allows every origin (*). Any website a visitor opens can make their browser talk to your Flowise API, which turns any other web bug into a path into your flows.",
      "Replace * with the exact comma-separated origins that need access, for example your app's https origin only. Never ship * on a server that holds API keys.");
  } else if (/http:\/\/(?!localhost|127\.0\.0\.1)/.test(corsE.value)){
    add("warning","CORS_ORIGINS",corsE,"CORS origin uses plain http",
      "At least one CORS_ORIGINS entry uses unencrypted http for a non-local host. Traffic to that origin can be read or altered in transit.",
      "Use https origins for anything beyond localhost development.");
  }

  /* Host / port bind */
  var hostE = map["HOST"];
  if (hostE && (hostE.value === "0.0.0.0" || hostE.value === "::" || hostE.value === "[::]")){
    if (authWeak){
      add("critical","HOST",hostE,"All-interface bind with weak or missing login",
        "HOST binds Flowise to every network interface while the app login is missing or weak. The server is reachable from the whole network — and anything beyond it — with little standing in the way.",
        "Bind HOST to 127.0.0.1 and reach Flowise through a reverse proxy with TLS, or keep the wide bind only behind a firewall — and set a strong FLOWISE_USERNAME / FLOWISE_PASSWORD either way.");
    } else {
      add("warning","HOST",hostE,"All-interface bind",
        "HOST binds Flowise to every network interface. The login is set, but the server is still directly reachable from the whole network, so its login page takes the full force of scanning and brute-force attempts.",
        "Prefer HOST=127.0.0.1 behind a reverse proxy with TLS and rate limiting, or restrict the port with a firewall to the addresses that need it.");
    }
  }
  if (!map["PORT"]){
    add("info","PORT",null,"PORT not set",
      "No PORT was pasted; Flowise's default port applies. Not a risk by itself — just confirm your firewall and proxy rules target the port actually in use.",
      "Set PORT explicitly in the deployment config so the exposed port is a decision, not a surprise.");
  }

  /* Debug */
  var dbgE = map["DEBUG"];
  if (dbgE && truthy(dbgE.value)){
    add("warning","DEBUG",dbgE,"DEBUG is turned on",
      "DEBUG=true makes Flowise log verbosely. Debug logs routinely capture prompts, payloads, and fragments of credentials, and they tend to be kept longer and shared more widely than anyone intends.",
      "Set DEBUG=false in production. Turn it on only while troubleshooting, and scrub and delete the logs afterward.");
  }

  /* Database */
  var dbTypeE = map["DATABASE_TYPE"], dbPassE = map["DATABASE_PASSWORD"];
  var dbType = dbTypeE ? dbTypeE.value.toLowerCase() : "";
  if (dbType && dbType !== "sqlite" && (!dbPassE || !dbPassE.value)){
    add("critical","DATABASE_PASSWORD",null,"Database has no password set",
      "DATABASE_TYPE uses an external database (" + dbType + ") but no DATABASE_PASSWORD is set. A passwordless database behind an AI app is an open shelf of chatflows and credentials.",
      "Set a long unique DATABASE_PASSWORD, create a dedicated DATABASE_USER for Flowise with least-privilege access, and restrict database network access to the Flowise host.");
  }
  if (dbPassE && dbPassE.value){ secretCheck("DATABASE_PASSWORD", dbPassE, 16, "Database password"); }
  if (dbTypeE && !dbPassE && !dbType){
    add("info","DATABASE_TYPE",dbTypeE,"Database type present without credentials in paste","DATABASE_TYPE is set but no database credentials were pasted, so they could not be graded.","Paste the full database block (type, user, password) for a complete grade.");
  }

  /* JWT */
  var jwtE = map["JWT_SECRET"], jwtExpE = map["JWT_EXPIRY_IN_MINUTES"];
  if (jwtE && jwtE.value){ secretCheck("JWT_SECRET", jwtE, 32, "JWT signing secret"); }
  if ((map["JWT_ISSUER"] || jwtExpE) && !jwtE){
    add("warning","JWT_SECRET",null,"JWT settings present but no JWT_SECRET in paste",
      "JWT-related settings are present but no JWT_SECRET was pasted, so the token-signing strength could not be verified.",
      "Confirm JWT_SECRET is set to a unique random value of at least 32 characters wherever tokens are issued.");
  }
  if (jwtExpE && jwtExpE.value){
    var mins = parseInt(jwtExpE.value, 10);
    if (!isNaN(mins) && mins > 1440){
      add("warning","JWT_EXPIRY_IN_MINUTES",jwtExpE,"Very long JWT lifetime",
        "JWT_EXPIRY_IN_MINUTES is " + mins + " minutes — tokens stay valid for days. A leaked token is a standing invitation for that whole window.",
        "Shorten JWT_EXPIRY_IN_MINUTES to the smallest window your users can live with (for example 60–1440), and rely on re-login rather than long-lived tokens.");
    }
  }

  /* Storage */
  var stE = map["STORAGE_TYPE"];
  var stType = stE ? stE.value.toLowerCase() : "";
  var s3SecretE = map["S3_STORAGE_SECRET_ACCESS_KEY"];
  if (s3SecretE && s3SecretE.value){ secretCheck("S3_STORAGE_SECRET_ACCESS_KEY", s3SecretE, 20, "S3 storage secret access key"); }
  if (stType === "s3" && !s3SecretE){
    add("warning","S3_STORAGE_SECRET_ACCESS_KEY",null,"S3 storage selected without its secret key in paste",
      "STORAGE_TYPE is s3 but no S3_STORAGE_SECRET_ACCESS_KEY was pasted, so the storage credential could not be graded. If it is short, shared, or committed anywhere, uploaded files are exposed.",
      "Use a dedicated, least-privilege S3 key pair for Flowise, keep the secret long and private, and rotate it on a schedule.");
  }
  var azE = map["AZURE_STORAGE_CONNECTION_STRING"];
  if (azE && azE.value){ secretCheck("AZURE_STORAGE_CONNECTION_STRING", azE, 40, "Azure storage connection string"); }
  var blobE = map["BLOB_STORAGE_PATH"];
  if (blobE && blobE.value && blobE.value.indexOf("/tmp") === 0){
    add("warning","BLOB_STORAGE_PATH",blobE,"Blob storage in a temporary directory",
      "BLOB_STORAGE_PATH points into /tmp. Uploaded files stored there can vanish on restart and may be readable by other processes on a shared host.",
      "Point BLOB_STORAGE_PATH at a persistent directory owned by the Flowise user with restrictive permissions — or use object storage with proper credentials.");
  }

  /* SMTP */
  var smtpPassE = map["SMTP_PASSWORD"];
  if (smtpPassE && smtpPassE.value){ secretCheck("SMTP_PASSWORD", smtpPassE, 16, "SMTP password"); }

  /* Generic sweep for any other secret-looking key not already graded */
  var graded = { FLOWISE_PASSWORD:1, PASSPHRASE:1, DATABASE_PASSWORD:1, JWT_SECRET:1, S3_STORAGE_SECRET_ACCESS_KEY:1, AZURE_STORAGE_CONNECTION_STRING:1, SMTP_PASSWORD:1 };
  entries.forEach(function(e){
    if (graded[e.key] || !isSecretKey(e.key) || !e.value) return;
    graded[e.key] = 1;
    secretCheck(e.key, e, 20, "Secret in " + e.key);
  });

  /* Telemetry — always noted, info only */
  var telE = map["DISABLE_FLOWISE_TELEMETRY"];
  if (telE && truthy(telE.value)){
    add("info","DISABLE_FLOWISE_TELEMETRY",telE,"Telemetry disabled",
      "DISABLE_FLOWISE_TELEMETRY=true: usage telemetry is off. That is the privacy-conservative posture and has no effect on the safety verdict.",
      "No action needed. Leave it true if you prefer the server to send no usage telemetry.");
  } else {
    add("info","DISABLE_FLOWISE_TELEMETRY",telE || null,"Telemetry not disabled",
      "DISABLE_FLOWISE_TELEMETRY is " + (telE ? "set to a non-true value" : "not set") + ", so Flowise telemetry may be sent. This is a privacy posture note only — it does not change the safety verdict.",
      "If you prefer no usage telemetry, set DISABLE_FLOWISE_TELEMETRY=true and restart Flowise.");
  }

  /* Sort: critical, warning, info; then by line */
  var rank = { critical:0, warning:1, info:2 };
  findings.sort(function(a,b){
    if (rank[a.severity] !== rank[b.severity]) return rank[a.severity]-rank[b.severity];
    return (a.line||9999)-(b.line||9999);
  });

  var crit = findings.filter(function(f){return f.severity==="critical";}).length;
  var warn = findings.filter(function(f){return f.severity==="warning";}).length;
  var verdict, why;
  if (crit > 0){ verdict = "DO NOT DEPLOY"; why = crit + " critical finding" + (crit===1?"":"s") + " must be fixed before this configuration goes anywhere reachable."; }
  else if (warn > 0){ verdict = "DEPLOY WITH FIXES"; why = "No critical findings, but " + warn + " warning" + (warn===1?"":"s") + " should be fixed before or immediately after deploy."; }
  else { verdict = "SAFE TO DEPLOY"; why = "Nothing in this paste tripped a critical or warning rule. Info notes below are posture reminders, not blockers."; }
  return finish(verdict, parsed, findings, why);
}
function finish(verdict, parsed, findings, why){
  var counts = { critical:0, warning:0, info:0 };
  findings.forEach(function(f){ counts[f.severity]++; });
  return { verdict:verdict, why:why, counts:counts, findings:findings,
    keysParsed: parsed.entries.length, linesScanned: parsed.totalLines };
}

/* ---------- Rendering (built with DOM methods; secret values never enter) ---------- */
var lastResult = null;
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-flowise-server-config-safety-auditortm',
  name: 'J-Dawgs Flowise Server Config Safety Auditor',
  description: 'Host tools only tell you the server started; ours grades a pasted Flowise config offline into one deploy verdict — missing login auth, short passphrase, wildcard CORS, DEBUG on; secrets by key name/line/length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
