'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs QuestDB Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

  "use strict";

  var RISKY = [
    "# Risky QuestDB server.conf — worked example",
    "http.enabled=true",
    "http.bind.address=0.0.0.0:9000",
    "http.tls.enabled=false",
    "http.security.readonly=false",
    "pg.enabled=true",
    "pg.bind.address=0.0.0.0:8812",
    "pg.user=admin",
    "pg.password=quest-admin-1234",
    "line.tcp.enabled=true",
    "line.tcp.bind.address=0.0.0.0:9009",
    "line.udp.enabled=true",
    "line.udp.bind.address=0.0.0.0:9009",
    "telemetry.enabled=true",
    "shared.worker.count=-1",
    "this line is not a property at all",
    "# pg.password=old-commented-value (commented out — must not be graded)"
  ].join("\n");

  var HARDENED = [
    "# Hardened QuestDB server.conf — expected SAFE TO DEPLOY",
    "http.enabled=true",
    "http.bind.address=127.0.0.1:9000",
    "http.tls.enabled=true",
    "http.security.readonly=true",
    "pg.enabled=true",
    "pg.bind.address=127.0.0.1:8812",
    "pg.user=admin",
    "pg.password=${env:QUESTDB_PG_PASSWORD}",
    "line.tcp.enabled=true",
    "line.tcp.bind.address=127.0.0.1:9009",
    "line.tcp.auth.token=${env:QUESTDB_ILP_TOKEN}",
    "line.udp.enabled=false",
    "telemetry.enabled=false",
    "shared.worker.count=4"
  ].join("\n");

  var input = document.getElementById("configInput");
  var verdictBox = document.getElementById("verdictBox");
  var verdictText = document.getElementById("verdictText");
  var verdictDetail = document.getElementById("verdictDetail");
  var countsBox = document.getElementById("counts");
  var findingsBox = document.getElementById("findings");
  var reportOut = document.getElementById("reportOut");
  var jsonOut = document.getElementById("jsonOut");
  var copyStatus = document.getElementById("copyStatus");
  var pitchStatus = document.getElementById("pitchStatus");

  var lastResult = null;

  var KNOWN_PREFIXES = ["http.", "pg.", "line.", "telemetry.", "telemetry", "shared.", "cairo.", "wal.", "tcp.", "udp.", "ilp.", "metrics.", "config."];
  var KNOWN_EXACT = ["telemetry.enabled","shared.worker.count","http.bind.address","pg.password","pg.user"];

  function isKnownKey(key){
    if (KNOWN_EXACT.indexOf(key) !== -1) return true;
    for (var i=0;i<KNOWN_PREFIXES.length;i++){ if (key.indexOf(KNOWN_PREFIXES[i])===0) return true; }
    if (key.indexOf("bind")!==-1 && (key.indexOf("http")!==-1||key.indexOf("pg")!==-1||key.indexOf("line")!==-1)) return true;
    return false;
  }
  function isSecretKey(key){
    return /(password|passwd|pwd|secret|token|api[-_.]?key|access[-_.]?key|private[-_.]?key|auth[-_.]?key)/i.test(key);
  }
  function isSafeReference(value){
    var v = value.trim();
    return /^\$\{[^}]*\}$/.test(v) || /^\$\{env:[^}]*\}$/i.test(v) ||
      /^(vault|env|file|kms|secret|aws-secrets|gcp-secret):/i.test(v) ||
      v.indexOf("${")===0 || /^\{\{.*\}\}$/.test(v);
  }
  function isWildcard(value){
    var host = value.trim();
    var m = host.match(/^(\[[^\]]*\]|[^:]*)(?::\d+)?$/);
    var h = m ? m[1] : host;
    return h==="0.0.0.0" || h==="::" || h==="[::]" || h==="*" || h==="";
  }
  function isTruthy(v){ var s=String(v).trim().toLowerCase(); return s==="true"||s==="1"||s==="yes"||s==="enabled"||s==="on"; }
  function isFalsy(v){ var s=String(v).trim().toLowerCase(); return s==="false"||s==="0"||s==="no"||s==="disabled"||s==="off"||s==="none"; }
  function serviceOf(key){
    if (key.indexOf("http.")===0) return "HTTP";
    if (key.indexOf("pg.")===0) return "PGWire";
    if (key.indexOf("line.")===0 || key.indexOf("ilp.")===0) return "ILP";
    return "server";
  }
  function serviceEnabled(map, key){
    // If the matching *.enabled flag is explicitly false, the listener is off.
    var svc = serviceOf(key);
    var flags = [];
    if (svc==="HTTP") flags=["http.enabled"];
    if (svc==="PGWire") flags=["pg.enabled"];
    if (svc==="ILP") flags=["line.tcp.enabled","line.udp.enabled","line.http.enabled","ilp.enabled"];
    for (var i=0;i<flags.length;i++){
      // Only downgrade when the specific sub-listener flag is off and the key matches it.
      var f = flags[i];
      if (map[f] && isFalsy(map[f].value)){
        if (f==="line.tcp.enabled" && key.indexOf("line.tcp")!==0) continue;
        if (f==="line.udp.enabled" && key.indexOf("line.udp")!==0) continue;
        if (f==="line.http.enabled" && key.indexOf("line.http")!==0) continue;
        return false;
      }
    }
    return true;
  }

  function audit(text){
    var lines = String(text||"").split(/\r?\n/);
    var findings = [];
    var entries = []; // {key, value, line}
    var map = {};
    var commented = 0, blank = 0, parsed = 0, notParsed = 0;

    function add(severity, code, key, line, message, valueLength){
      var f = { severity: severity, code: code, key: key || null, line: line || null, message: message };
      if (typeof valueLength === "number") f.valueLengthChars = valueLength;
      findings.push(f);
    }

    for (var i=0;i<lines.length;i++){
      var lineNo = i+1;
      var raw = lines[i];
      var t = raw.trim();
      if (t===""){ blank++; continue; }
      if (t.charAt(0)==="#"){ commented++; continue; }
      var eq = t.indexOf("=");
      if (eq<=0){
        notParsed++;
        add("WARNING","NOT_PARSED",null,lineNo,"Line " + lineNo + " is NOT PARSED: it is not a key=value property line. Its content is not shown and it was not graded as a setting.");
        continue;
      }
      var key = t.slice(0,eq).trim().toLowerCase();
      var value = t.slice(eq+1).trim();
      if (!key){ notParsed++; add("WARNING","NOT_PARSED",null,lineNo,"Line " + lineNo + " is NOT PARSED: no key before the equals sign."); continue; }
      parsed++;
      var entry = { key:key, value:value, line:lineNo };
      entries.push(entry);
      map[key]=entry;
    }

    var known = 0;
    entries.forEach(function(e){ if (isKnownKey(e.key)) known++; });

    var recognizable = parsed>=3 && known>=2;
    if (!recognizable){
      return {
        verdict:"NOT ENOUGH TO GRADE",
        reason:"The paste is not recognizably a QuestDB server.conf: " + parsed + " key=value line(s) found, " + known + " with recognizably QuestDB keys. Paste the properties file (key=value lines such as http.bind.address, pg.bind.address, telemetry.enabled) and audit again.",
        counts:countSev(findings),
        stats:{lines:lines.length, parsed:parsed, commented:commented, blank:blank, notParsed:notParsed, knownKeys:known},
        findings:findings
      };
    }

    // Per-line checks
    entries.forEach(function(e){
      var key=e.key, value=e.value, lineNo=e.line;

      // Wildcard binds
      if ((key.indexOf("bind")!==-1 || key.indexOf(".host")!==-1) && isWildcard(value)){
        var svc = serviceOf(key);
        if (!serviceEnabled(map,key)){
          add("INFO","WILDCARD_BIND_DISABLED",key,lineNo,key + " is set to a wildcard address, but that listener is disabled, so it is not currently exposed.");
        } else if (svc==="PGWire" || svc==="ILP"){
          add("BLOCKER","WILDCARD_BIND",key,lineNo,key + " binds the " + svc + " listener to a wildcard address (every network interface) on line " + lineNo + ". Anyone who can reach this host can reach that listener. Bind to 127.0.0.1 or a specific private interface, or put it behind a firewall.");
        } else if (svc==="HTTP"){
          add("HIGH","WILDCARD_BIND",key,lineNo,key + " binds the HTTP listener to a wildcard address (every network interface) on line " + lineNo + ". That is only safe with TLS on and a deliberate auth / read-only posture.");
        } else {
          add("WARNING","WILDCARD_BIND",key,lineNo,key + " uses a wildcard bind address on line " + lineNo + ". Confirm that listener is meant to be reachable on every interface.");
        }
      }

      // TLS explicitly disabled (any tls/ssl key set false)
      if (/(tls|ssl)/.test(key) && (isFalsy(value) || value.toLowerCase()==="none")){
        var s2 = serviceOf(key);
        add("BLOCKER","TLS_DISABLED",key,lineNo,key + " turns TLS off on line " + lineNo + ". Traffic to the " + s2 + " listener — including credentials — crosses the network in plain text. Enable TLS or terminate it at a trusted proxy on the same host.");
      }

      // Telemetry
      if (key==="telemetry.enabled" && isTruthy(value)){
        add("WARNING","TELEMETRY_ON",key,lineNo,"telemetry.enabled is true on line " + lineNo + ": the server phones home usage telemetry. Set telemetry.enabled=false if that disclosure is not deliberate.");
      }

      // Read-only posture explicitly off
      if (key==="http.security.readonly" && isFalsy(value)){
        add("HIGH","READONLY_OFF",key,lineNo,"http.security.readonly is false on line " + lineNo + ": the HTTP interface is not locked to read-only, so unauthenticated callers who can reach it may be able to write and run queries. Set it to true unless writes over HTTP are required and authenticated.");
      }

      // Plaintext secrets — report key, line, length ONLY
      if (isSecretKey(key) && value!==""){
        if (isSafeReference(value)){
          add("INFO","SECRET_REFERENCE",key,lineNo,key + " on line " + lineNo + " uses an environment / vault-style reference instead of a written-out value. Good pattern — the value itself was not inspected.");
        } else {
          add("BLOCKER","PLAINTEXT_SECRET",key,lineNo,key + " on line " + lineNo + " holds a plaintext secret (value length: " + value.length + " characters; the value is never shown in this audit). Anyone who reads this file has the secret. Move it to an environment or vault reference.", value.length);
        }
      }

      // Worker counts — INFO only
      if (/(^|\.)shared\.worker\.count$/.test(key) || /worker\.count$/.test(key)){
        var n = parseInt(value,10);
        if (isNaN(n) || n<=0 || n>=128){
          add("INFO","WORKER_COUNT_UNBOUNDED",key,lineNo,key + " on line " + lineNo + " looks unbounded or unset (" + (isNaN(n) ? "non-numeric value" : "value " + n) + "). Noted for capacity planning only — INFO, it does not change the verdict by itself.");
        }
      }
    });

    // Missing-setting checks (whole-file posture)
    var httpPresent = entries.some(function(e){return e.key.indexOf("http.")===0;});
    var pgPresent = entries.some(function(e){return e.key.indexOf("pg.")===0;});
    var ilpPresent = entries.some(function(e){return e.key.indexOf("line.")===0 || e.key.indexOf("ilp.")===0;});

    if (httpPresent && serviceEnabled(map,"http.bind.address")){
      var tlsEntry = null;
      entries.forEach(function(e){ if (e.key.indexOf("http.")===0 && /(tls|ssl)/.test(e.key)) tlsEntry=e; });
      if (!tlsEntry){
        add("HIGH","TLS_MISSING",null,null,"No TLS setting for the HTTP listener appears anywhere in the active config. If TLS is not terminated elsewhere on this host, HTTP traffic — including any credentials — is plain text. Add an explicit TLS setting so the posture is visible in the file.");
      }
      if (!map["http.security.readonly"]){
        add("WARNING","READONLY_UNSET",null,null,"http.security.readonly is not set in the active config. The read-only posture of the HTTP interface is left to defaults instead of being stated. Set http.security.readonly explicitly (true unless authenticated writes over HTTP are required).");
      }
    }
    if (pgPresent && serviceEnabled(map,"pg.bind.address")){
      if (!map["pg.password"]){
        add("HIGH","PG_AUTH_MISSING","pg.password",null,"The PGWire listener is configured but no active pg.password setting was found. Confirm PGWire authentication is actually enforced before this listener is reachable by anyone else.");
      }
    }
    if (ilpPresent){
      var hasIlpAuth = entries.some(function(e){ return (e.key.indexOf("line.")===0 || e.key.indexOf("ilp.")===0) && /(token|auth|password|secret)/.test(e.key); });
      var ilpActive = entries.some(function(e){ return (e.key.indexOf("line.tcp")===0||e.key.indexOf("line.udp")===0) && serviceEnabled(map,e.key); });
      if (!hasIlpAuth && ilpActive){
        add("HIGH","ILP_AUTH_MISSING",null,null,"An ILP (line.tcp / line.udp) listener is active but no token or auth setting for it appears in the active config. Unauthenticated ingestion means anyone who can reach the port can write data. Configure ILP token authentication or bind the listener to localhost.");
      }
    }

    var counts = countSev(findings);
    var verdict, reason;
    if (counts.BLOCKER>0){ verdict="DO NOT DEPLOY"; reason=counts.BLOCKER + " blocker(s) found. Fix every blocker before this config goes anywhere near a deployed server."; }
    else if (counts.HIGH>0 || counts.WARNING>0){ verdict="DEPLOY WITH FIXES"; reason="No blockers, but " + (counts.HIGH+counts.WARNING) + " high / warning finding(s) need fixing or a deliberate, documented exception."; }
    else { verdict="SAFE TO DEPLOY"; reason="No blockers, highs, or warnings in the pasted config. INFO notes, if any, are observations only."; }

    return { verdict:verdict, reason:reason, counts:counts,
      stats:{lines:lines.length, parsed:parsed, commented:commented, blank:blank, notParsed:notParsed, knownKeys:known},
      findings:findings };
  }

  function countSev(findings){
    var c={BLOCKER:0,HIGH:0,WARNING:0,INFO:0};
    findings.forEach(function(f){ if (c.hasOwnProperty(f.severity)) c[f.severity]++; });
    return c;
  }

  function esc(s){ return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"); }

  function render(result){
    lastResult = result;
    verdictText.textContent = result.verdict;
    verdictDetail.textContent = result.reason;
    verdictBox.className = "verdict " + (result.verdict==="SAFE TO DEPLOY" ? "v-safe" :
      result.verdict==="DEPLOY WITH FIXES" ? "v-fixes" :
      result.verdict==="DO NOT DEPLOY" ? "v-no" : "v-unknown");
    countsBox.innerHTML =
      '<span class="count">BLOCKER: '+result.counts.BLOCKER+'</span>' +
      '<span class="count">HIGH: '+result.counts.HIGH+'</span>' +
      '<span class="count">WARNING: '+result.counts.WARNING+'</span>' +
      '<span class="count">INFO: '+result.counts.INFO+'</span>' +
      '<span class="count">Lines: '+result.stats.lines+' · Parsed: '+result.stats.parsed+' · Commented (not graded): '+result.stats.commented+' · Not parsed: '+result.stats.notParsed+'</span>';

    if (!result.findings.length){
      findingsBox.innerHTML = '<p class="small">No findings. Nothing in the pasted config tripped a check.</p>';
    } else {
      var order={BLOCKER:0,HIGH:1,WARNING:2,INFO:3};
      var sorted = result.findings.slice().sort(function(a,b){
        if (order[a.severity]!==order[b.severity]) return order[a.severity]-order[b.severity];
        return (a.line||0)-(b.line||0);
      });
      findingsBox.innerHTML = sorted.map(function(f){
        var meta = [];
        if (f.key) meta.push("Key: " + f.key);
        if (f.line) meta.push("Line: " + f.line);
        if (typeof f.valueLengthChars==="number") meta.push("Value length: " + f.valueLengthChars + " characters");
        meta.push("Code: " + f.code);
        return '<div class="finding"><span class="sev sev-'+f.severity+'">'+f.severity+'</span>' +
          '<span class="meta">'+esc(meta.join(" · "))+'</span><p style="margin:.35rem 0 0">'+esc(f.message)+'</p></div>';
      }).join("");
    }

    // Text report
    var r = [];
    r.push("J-Dawgs QuestDB Server Config Safety Auditor — text report");
    r.push("Verdict: " + result.verdict);
    r.push("Reason: " + result.reason);
    r.push("Counts: BLOCKER " + result.counts.BLOCKER + " · HIGH " + result.counts.HIGH + " · WARNING " + result.counts.WARNING + " · INFO " + result.counts.INFO);
    r.push("Input stats: " + result.stats.lines + " line(s), " + result.stats.parsed + " parsed, " + result.stats.commented + " commented (not graded), " + result.stats.notParsed + " not parsed.");
    r.push("");
    r.push("Findings:");
    if (!result.findings.length){ r.push("  (none)"); }
    result.findings.forEach(function(f){
      var head = "  [" + f.severity + "] " + f.code;
      if (f.key) head += " · key " + f.key;
      if (f.line) head += " · line " + f.line;
      if (typeof f.valueLengthChars==="number") head += " · value length " + f.valueLengthChars + " chars";
      r.push(head);
      r.push("      " + f.message);
    });
    r.push("");
    r.push("Limits: heuristic text audit of the pasted config only. It does not connect to a server, does not start QuestDB, and does not verify that any secret or referenced value is correct. Secret values are never included in this report — only key name, line number, and value length.");
    reportOut.textContent = r.join("\n");

    var jsonObj = {
      tool: "J-Dawgs QuestDB Server Config Safety Auditor",
      verdict: result.verdict,
      reason: result.reason,
      counts: result.counts,
      stats: result.stats,
      findings: result.findings,
      limits: "Heuristic text audit of pasted config only. Does not connect to a server. Does not verify secrets are correct. Secret values are never exported — key name, line number, and value length only."
    };
    jsonOut.textContent = JSON.stringify(jsonObj, null, 2);
  }

  function runAudit(){ render(audit(input.value)); }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-questdb-server-config-safety-auditor',
  name: 'J-Dawgs QuestDB Server Config Safety Auditor',
  description: 'Grades a pasted QuestDB server.conf fully offline into one deploy verdict — listener and HTTP exposure, authentication posture, and plaintext secrets reported by key name, line, and length only, never by value. QuestDB only exercises a config by starting the server; this grades it before anything st',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
