'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Focalboard Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";
var RISKY = [
'{',
'  "serverRoot": "http://boards.example.com",',
'  "port": 8000,',
'  "dbtype": "postgres",',
'  "dbconfig": "postgres://focalboard:SuperSecretPass123@db.example.com:5432/focalboard?sslmode=disable",',
'  "session_expire_time": 15552000,',
'  "session_refresh_time": 2592000,',
'  "authMode": "none",',
'  "enablePublicSharedBoards": true,',
'  "telemetry": true,',
'  "webpath": "./pack",',
'  "filespath": "./files",',
'  "localModeSocketLocation": "/var/tmp/focalboard_local.socket"',
'}'
].join("\n");
var HARDENED = [
'{',
'  "serverRoot": "https://boards.example.com",',
'  "port": 8000,',
'  "dbtype": "postgres",',
'  "dbconfig": "postgres://focalboard@db.example.com:5432/focalboard?sslmode=require",',
'  "session_expire_time": 86400,',
'  "session_refresh_time": 1800,',
'  "authMode": "native",',
'  "enablePublicSharedBoards": false,',
'  "telemetry": false,',
'  "webpath": "./pack",',
'  "filespath": "/var/lib/focalboard/files",',
'  "localModeSocketLocation": ""',
'}'
].join("\n");
var PROSE = [
'Focalboard setup notes for the team',
'We should move the boards server next week.',
'Remember to ask about backups before the move.'
].join("\n");

var KEYMAP = {
  serverroot:"serverRoot", port:"port", dbtype:"dbtype", dbconfig:"dbconfig",
  sessionexpiretime:"session_expire_time", sessionrefreshtime:"session_refresh_time",
  authmode:"authMode", enablepublicsharedboards:"enablePublicSharedBoards",
  telemetry:"telemetry", telemetryenabled:"telemetry", webpath:"webpath",
  filespath:"filespath", localmodesocketlocation:"localModeSocketLocation",
  serverport:"port"
};
function normKey(k){ return String(k).replace(/[^a-z0-9]/gi,"").toLowerCase(); }
function canon(k){ return KEYMAP[normKey(k)] || null; }
function parseScalar(v){
  v = String(v).trim().replace(/,$/,"").trim();
  if(/^".*"$/.test(v) || /^'.*'$/.test(v)) return v.slice(1,-1);
  if(v==="true") return true; if(v==="false") return false;
  if(/^-?\d+$/.test(v)) return parseInt(v,10);
  if(/^-?\d*\.\d+$/.test(v)) return parseFloat(v);
  return v;
}
function findLine(lines, rawKey){
  for(var i=0;i<lines.length;i++){ if(lines[i].indexOf(rawKey)!==-1) return i+1; }
  return 1;
}
function parseInput(text){
  var lines = String(text||"").split(/\r?\n/);
  var entries = [], unparsable = [];
  var trimmed = String(text||"").trim();
  if(!trimmed) return {entries:entries, unparsable:unparsable, lines:lines, format:"empty"};
  // Try whole-document JSON first
  if(trimmed.charAt(0)==="{"){
    try{
      var obj = JSON.parse(trimmed);
      if(obj && typeof obj==="object" && !Array.isArray(obj)){
        Object.keys(obj).forEach(function(k){
          var c = canon(k);
          if(c) entries.push({key:c, rawKey:k, value:obj[k], line:findLine(lines,k)});
        });
        if(entries.length) return {entries:entries, unparsable:unparsable, lines:lines, format:"json"};
      }
    }catch(e){ /* fall through to line parsing */ }
  }
  lines.forEach(function(raw, idx){
    var t = raw.trim(), lineNo = idx+1;
    if(!t || t.charAt(0)==="#" || t.indexOf("//")===0) return;
    if(t==="{" || t==="}" || t==="}," ) return;
    var m = t.match(/^"?([A-Za-z_][A-Za-z0-9_\-]*)"?\s*[:=]\s*(.+)$/);
    if(m){
      var c = canon(m[1]);
      if(c){ entries.push({key:c, rawKey:m[1], value:parseScalar(m[2]), line:lineNo}); return; }
      // Looks like a key/value line but not a known Focalboard key
      unparsable.push(lineNo); return;
    }
    unparsable.push(lineNo);
  });
  return {entries:entries, unparsable:unparsable, lines:lines, format:"lines"};
}
function isPlaceholder(s){
  return /^\$\{.*\}$/.test(s) || /^\$[A-Za-z_]+$/.test(s) || /^\*+$/.test(s) || /^x+$/i.test(s) || /^<.*>$/.test(s) || /^changeme$/i.test(s);
}
function detectPassword(value){
  if(typeof value!=="string") return null;
  var m = value.match(/:\/\/[^:\/@\s]+:([^@\s]+)@/);
  if(m && !isPlaceholder(m[1])) return {length:m[1].length, via:"connection-string URL"};
  m = value.match(/(?:password|pwd|passwd)\s*=\s*'([^']+)'/i);
  if(m && !isPlaceholder(m[1])) return {length:m[1].length, via:"password= setting"};
  m = value.match(/(?:password|pwd|passwd)\s*=\s*([^;\s&]+)/i);
  if(m && !isPlaceholder(m[1])) return {length:m[1].length, via:"password= setting"};
  m = value.match(/^[^:\s\/]+:([^@\s]+)@tcp\(/i);
  if(m && !isPlaceholder(m[1])) return {length:m[1].length, via:"DSN userinfo"};
  return null;
}
function get(entries, key){
  for(var i=0;i<entries.length;i++) if(entries[i].key===key) return entries[i];
  return null;
}
function num(v){ var n = (typeof v==="number")? v : parseInt(String(v),10); return isNaN(n)? null : n; }

function audit(text){
  var parsed = parseInput(text);
  var findings = [];
  function add(sev, key, line, title, detail, fix, extra){
    var f = {severity:sev, key:key, line:line, title:title, detail:detail, fix:fix};
    if(extra) for(var k in extra) f[k]=extra[k];
    findings.push(f);
  }
  if(!String(text||"").trim()){
    return {verdict:"NOT ENOUGH TO GRADE", findings:findings, unparsable:[], entries:[], reason:"The input is empty. Paste a Focalboard config.json or env-style lines to get a verdict."};
  }
  if(parsed.entries.length===0){
    return {verdict:"NOT ENOUGH TO GRADE", findings:findings, unparsable:parsed.unparsable, entries:[], reason:"No recognised Focalboard configuration keys were found, so there is nothing to grade. Unparsable lines are listed by number below."};
  }
  var e;
  // authMode
  e = get(parsed.entries,"authMode");
  if(!e) add("major","authMode",null,"authMode is not set","Without an explicit authMode, the deployment's sign-in behaviour cannot be confirmed from this text.","Set \"authMode\": \"native\" explicitly so sign-in is required.");
  else if(String(e.value).toLowerCase()==="none") add("blocker","authMode",e.line,"Authentication is turned off (authMode is \"none\")","With authMode set to none, Focalboard does not require sign-in. Anyone who can reach the server can use it.","Set \"authMode\": \"native\" and restart with real user accounts before exposing the server.");
  else if(String(e.value).toLowerCase()!=="native") add("major","authMode",e.line,"authMode has an unrecognised value","Only \"native\" (sign-in required) and \"none\" (no sign-in) are expected values; this value cannot be confirmed as safe.","Set \"authMode\": \"native\".");
  // public shared boards
  e = get(parsed.entries,"enablePublicSharedBoards");
  if(!e) add("minor","enablePublicSharedBoards",null,"enablePublicSharedBoards is not stated","If public sharing is enabled elsewhere, boards can be read by anyone holding a public link. Its state cannot be confirmed here.","Set \"enablePublicSharedBoards\": false unless public link sharing is a deliberate, reviewed choice.");
  else if(e.value===true || String(e.value).toLowerCase()==="true") add("blocker","enablePublicSharedBoards",e.line,"Public shared boards are enabled","Anyone with a board's public link can view it without signing in. Board contents can leave the team silently.","Set \"enablePublicSharedBoards\": false, or restrict the server to a private network if public sharing is truly required.");
  // dbconfig + dbtype
  var dbc = get(parsed.entries,"dbconfig"), dbt = get(parsed.entries,"dbtype");
  if(dbc){
    var pw = detectPassword(String(dbc.value));
    if(pw) add("blocker","dbconfig",dbc.line,"Plaintext database password inside dbconfig","A password is embedded in plain text in the connection string. Anyone who reads this config file owns the database. The value is not shown here — key \"dbconfig\", line "+dbc.line+", password length "+pw.length+" characters ("+pw.via+").","Move the credential out of the committed config: use a secret store or an environment-injected connection string, rotate the exposed password now, and restrict file permissions on the config.",{secretKey:"dbconfig", secretLine:dbc.line, secretLength:pw.length});
    if(/sslmode=disable/i.test(String(dbc.value))) add("major","dbconfig",dbc.line,"Database connection does not require TLS (sslmode=disable)","Credentials and board data can cross the network to the database unencrypted.","Use sslmode=require (or verify-full) for Postgres, or the MySQL TLS equivalent, unless the database is on the same trusted host.");
  }
  if(dbt){
    var t = String(dbt.value).toLowerCase();
    if(t==="sqlite" || t==="sqlite3") add("major","dbtype",dbt.line,"SQLite is selected as the database","SQLite is fine for a single-user trial, but it is a fragile choice for a shared, multi-user production server.","Use Postgres (dbtype \"postgres\") with a managed connection string for a shared deployment.");
    if((t==="postgres" || t==="mysql") && !dbc) add("major","dbconfig",dbt.line,"Database type is set but no dbconfig connection string was found","The server cannot be checked for credential or TLS problems without its connection string.","Include the dbconfig value in the audited text (passwords are reported by length only, never shown).");
  }
  // sessions
  var exp = get(parsed.entries,"session_expire_time"), ref = get(parsed.entries,"session_refresh_time");
  var expN = exp? num(exp.value): null, refN = ref? num(ref.value): null;
  if(exp && expN!==null){
    if(expN===0) add("blocker","session_expire_time",exp.line,"Sessions never expire (session_expire_time is 0)","A stolen or leftover session token stays valid indefinitely.","Set session_expire_time to a bounded value such as 86400 (1 day) to 604800 (7 days).");
    else if(expN>7776000) add("blocker","session_expire_time",exp.line,"Session lifetime is very long ("+expN+" seconds, about "+Math.round(expN/86400)+" days)","Sessions stay valid for months. A leaked token is a long-lived key to the server.","Reduce session_expire_time to 2592000 seconds (30 days) or less — 86400 (1 day) is a stronger default.");
    else if(expN>2592000) add("major","session_expire_time",exp.line,"Session lifetime is long ("+expN+" seconds, about "+Math.round(expN/86400)+" days)","Long-lived sessions widen the window if a token leaks.","Reduce session_expire_time to 2592000 seconds (30 days) or less.");
  }
  if(ref && refN!==null){
    if(refN>2592000) add("major","session_refresh_time",ref.line,"Session refresh window is very long ("+refN+" seconds, about "+Math.round(refN/86400)+" days)","A session can be refreshed long after it was issued, stretching its real lifetime.","Keep session_refresh_time well under session_expire_time — for example 1800 seconds (30 minutes).");
    if(expN!==null && refN>=expN && expN>0) add("major","session_refresh_time",ref.line,"Refresh window is not shorter than the session lifetime","When refresh meets or exceeds expire, sessions can effectively roll on far beyond the intended lifetime.","Set session_refresh_time below session_expire_time.");
  }
  // serverRoot
  e = get(parsed.entries,"serverRoot");
  if(e && typeof e.value==="string"){
    if(/^http:\/\//i.test(e.value) && !/^http:\/\/(localhost|127\.0\.0\.1|\[::1\])/i.test(e.value)) add("major","serverRoot",e.line,"serverRoot uses plain HTTP for a non-local host","Sign-ins, session tokens, and board contents travel unencrypted.","Serve Focalboard over HTTPS (directly or behind a TLS reverse proxy) and set serverRoot to the https:// address.");
    if(e.value==="") add("minor","serverRoot",e.line,"serverRoot is empty","Links the server generates for sharing and notifications may be wrong.","Set serverRoot to the full public address of the server, including https://.");
  }
  // telemetry
  e = get(parsed.entries,"telemetry");
  if(e && (e.value===true || String(e.value).toLowerCase()==="true")) add("minor","telemetry",e.line,"Telemetry is on","Telemetry sends usage data out of the server. On a private boards server that is an unnecessary disclosure.","Set \"telemetry\": false for a private deployment.");
  // filespath
  e = get(parsed.entries,"filespath");
  if(e && typeof e.value==="string"){
    if(/^\/tmp(\/|$)/.test(e.value) || /^\/var\/tmp(\/|$)/.test(e.value)) add("major","filespath",e.line,"Files are stored in a temporary folder","Uploaded files under /tmp or /var/tmp can be cleared by the OS and are often world-readable.","Point filespath at a private, backed-up directory such as /var/lib/focalboard/files.");
    else if(e.value==="") add("major","filespath",e.line,"filespath is empty","The server has no confirmed storage location for uploaded files.","Set filespath to a private, backed-up directory.");
  }
  // local mode socket
  e = get(parsed.entries,"localModeSocketLocation");
  if(e && typeof e.value==="string" && e.value!==""){
    if(/^\/tmp(\/|$)/.test(e.value) || /^\/var\/tmp(\/|$)/.test(e.value)) add("minor","localModeSocketLocation",e.line,"Local-mode socket sits in a world-writable folder","A socket in /tmp or /var/tmp can be exposed to other local users, and local mode bypasses normal network controls.","Move the socket under a directory only the Focalboard user can read, or leave local mode disabled.");
  }
  // port
  e = get(parsed.entries,"port");
  if(e){
    var p = num(e.value);
    if(p===null) add("major","port",e.line,"Port value is not a number","The listen port cannot be confirmed from this value.","Set port to a numeric value such as 8000.");
    else if(p<1024 && p>0) add("minor","port",e.line,"Port "+p+" is a privileged port","Ports below 1024 usually need elevated privileges, which gives the server more power than it needs.","Run Focalboard on an unprivileged port such as 8000 behind a reverse proxy.");
  }
  var verdict = "SAFE TO DEPLOY";
  if(findings.some(function(f){return f.severity==="blocker";})) verdict = "DO NOT DEPLOY";
  else if(findings.length) verdict = "DEPLOY WITH FIXES";
  return {verdict:verdict, findings:findings, unparsable:parsed.unparsable, entries:parsed.entries, reason:""};
}

function esc(s){ return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;"); }
function publicEntries(entries){
  return entries.map(function(en){
    var out = {key:en.key, line:en.line};
    if(en.key==="dbconfig"){
      var pw = detectPassword(String(en.value));
      out.value = "[connection string — value not shown]";
      out.valueLength = String(en.value).length;
      if(pw) out.passwordLength = pw.length;
    } else out.value = en.value;
    return out;
  });
}
function buildReports(result){
  var lines = [];
  lines.push("J-Dawgs Focalboard Server Config Safety Auditor™ — Text Report");
  lines.push("Verdict: "+result.verdict);
  lines.push("Offline text audit only. This report does not start Focalboard, connect to any server, or verify a live deployment.");
  if(result.reason) lines.push("Note: "+result.reason);
  lines.push("Recognised keys: "+(result.entries.length? publicEntries(result.entries).map(function(en){return en.key+" (line "+en.line+")";}).join(", ") : "none"));
  lines.push("Unparsable lines: "+(result.unparsable.length? result.unparsable.join(", ") : "none"));
  lines.push("");
  if(result.findings.length){
    lines.push("Findings ("+result.findings.length+"):");
    result.findings.forEach(function(f,i){
      lines.push((i+1)+". ["+f.severity.toUpperCase()+"] "+f.title);
      lines.push("   Key: "+f.key+(f.line? " · Line: "+f.line : " · Line: not present"));
      if(typeof f.secretLength==="number") lines.push("   Secret: key \""+f.secretKey+"\", line "+f.secretLine+", length "+f.secretLength+" characters — value not shown.");
      lines.push("   Why it matters: "+f.detail);
      lines.push("   Fix: "+f.fix);
    });
  } else if(result.verdict==="SAFE TO DEPLOY") lines.push("Findings: none. No blockers or fixes were found in the recognised settings.");
  else lines.push("Findings: none recorded for this verdict.");
  var json = {
    tool:"J-Dawgs Focalboard Server Config Safety Auditor™",
    verdict:result.verdict,
    reason:result.reason||undefined,
    parsedKeys:publicEntries(result.entries),
    unparsableLines:result.unparsable,
    findings:result.findings,
    scope:"Offline text audit only; does not start Focalboard, connect to any server, or verify a live deployment. Secret values are never included — secrets are reported by key, line, and length only."
  };
  return {text:lines.join("\n"), json:JSON.stringify(json,null,2), jsonObj:json};
}

var lastReports = null;
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-focalboard-server-config-safety-auditortm',
  name: 'J-Dawgs Focalboard Server Config Safety Auditor',
  description: 'Host tools only tell you the server started; ours grades a pasted Focalboard server config offline into one deploy verdict — secrets by key name/line/length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
