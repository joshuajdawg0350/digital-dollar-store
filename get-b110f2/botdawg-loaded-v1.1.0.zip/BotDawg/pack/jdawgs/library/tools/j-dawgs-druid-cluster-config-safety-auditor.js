'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Druid Cluster Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var RISKY_EXAMPLE = [
        "# RISKY example - do not deploy a cluster like this",
        "druid.enablePlaintextPort=true",
        "druid.enableTlsPort=false",
        "druid.auth.authenticatorChain=[]",
        "druid.auth.authenticator.allowUnauthenticated=true",
        "druid.metadata.storage.type=postgresql",
        "druid.metadata.storage.connector.connectURI=jdbc:postgresql://db.internal:5432/druid",
        "druid.metadata.storage.connector.user=druid",
        "druid.metadata.storage.connector.password=RISKY-SECRET-PW-98765",
        "druid.storage.type=s3",
        "druid.storage.s3.accessKey=RISKYACCESSKEY123456",
        "druid.storage.s3.secretAccessKey=RISKY-S3-SECRET-ABCDE-12345",
        "druid.server.http.host=0.0.0.0",
        "druid.coordinator.host=0.0.0.0",
        "druid.server.http.enableRequestLimit=false",
        "druid.server.http.queueSize=-1",
        'druid.extensions.loadList=["druid-s3-extensions","druid-basic-security"]'
      ].join("\n");

      var HARDENED_EXAMPLE = [
        "# HARDENED example",
        "druid.enablePlaintextPort=false",
        "druid.enableTlsPort=true",
        "druid.server.https.keyStorePath=/etc/druid/tls/keystore.jks",
        'druid.auth.authenticatorChain=["basic"]',
        "druid.auth.authenticator.allowUnauthenticated=false",
        "druid.metadata.storage.type=postgresql",
        "druid.metadata.storage.connector.connectURI=jdbc:postgresql://db.internal:5432/druid",
        "druid.metadata.storage.connector.password=${env:DRUID_METADATA_PASSWORD}",
        "druid.storage.type=s3",
        "druid.storage.s3.accessKey=${env:AWS_ACCESS_KEY_ID}",
        "druid.storage.s3.secretAccessKey=${env:AWS_SECRET_ACCESS_KEY}",
        "druid.server.http.host=127.0.0.1",
        "druid.coordinator.host=127.0.0.1",
        "druid.server.http.enableRequestLimit=true",
        "druid.server.http.queueSize=100",
        'druid.extensions.loadList=["druid-s3-extensions","druid-basic-security"]'
      ].join("\n");

      var SECRET_WORDS = ["password", "secret", "accesskey", "access-key", "secretaccesskey", "token", "credential"];

      function stripQuotes(v) {
        var s = String(v).trim();
        if (s.length >= 2) {
          var first = s.charAt(0), last = s.charAt(s.length - 1);
          if ((first === '"' && last === '"') || (first === "'" && last === "'")) {
            return s.slice(1, -1);
          }
        }
        return s;
      }

      function isVarRef(value) {
        return value.indexOf("${") !== -1 || /^env:/i.test(value);
      }

      // Parse one trimmed, non-blank, non-comment line.
      // Returns {key, value} or null when the line is not a setting line.
      function parseSettingLine(t) {
        var work = t;
        // A JSON object written on a single line: {"key": value}
        if (work.charAt(0) === "{" && work.charAt(work.length - 1) === "}" && work.indexOf('"') !== -1) {
          work = work.slice(1, -1).trim();
        }
        // JSON-ish: "key": "value" / "key": value (optional trailing comma)
        var mj = work.match(/^"([^"]+)"\s*:\s*(.*?)\s*,?$/);
        if (mj) {
          return { key: mj[1].trim(), value: stripQuotes(mj[2]) };
        }
        // Properties: key=value or key: value
        var mp = work.match(/^([A-Za-z0-9_.\-\/]+)\s*(?:=\s*|:\s+)(.*)$/);
        if (mp) {
          return { key: mp[1].trim(), value: mp[2].trim() };
        }
        return null;
      }

      function auditConfig(text) {
        var lines = text === "" ? [] : String(text).split("\n");
        var entries = [];        // {key, value, line} for every parsed setting line
        var druidEntries = [];   // subset whose key starts with druid.
        var notParsed = [];      // line numbers
        var structural = 0;

        for (var i = 0; i < lines.length; i++) {
          var lineNo = i + 1;
          var t = lines[i].trim();
          if (t === "") continue;
          if (t.charAt(0) === "#" || t.indexOf("//") === 0) continue;
          if (t === "{" || t === "}" || t === "[" || t === "]" || t === "}," || t === "],") { structural++; continue; }
          var parsed = parseSettingLine(t);
          if (!parsed || parsed.key === "") { notParsed.push(lineNo); continue; }
          var entry = { key: parsed.key, value: stripQuotes(parsed.value), line: lineNo };
          entries.push(entry);
          if (entry.key.indexOf("druid.") === 0) druidEntries.push(entry);
        }

        // Last occurrence wins for single-value lookups.
        var byKey = {};
        druidEntries.forEach(function (e) { byKey[e.key.toLowerCase()] = e; });
        function get(key) { return byKey[key.toLowerCase()] || null; }

        var findings = [];
        function add(severity, line, key, message, valueLength) {
          var f = { severity: severity, line: line, key: key, message: message };
          if (typeof valueLength === "number") f.valueLength = valueLength;
          findings.push(f);
        }

        // Global TLS posture, needed by the plaintext check.
        var tlsPortEntry = get("druid.enableTlsPort");
        var tlsEnabled = false;
        if (tlsPortEntry && tlsPortEntry.value.toLowerCase() === "true") tlsEnabled = true;
        druidEntries.forEach(function (e) {
          var lk = e.key.toLowerCase();
          if (lk.indexOf("druid.server.https.") === 0 || lk.indexOf("druid.server.tls.") === 0) tlsEnabled = true;
        });

        // ---- Check 1: plaintext port / TLS posture ----
        var plainEntry = get("druid.enablePlaintextPort");
        if (plainEntry) {
          var plainVal = plainEntry.value.toLowerCase();
          if (plainVal === "true") {
            if (!tlsEnabled) {
              var msg = "The plaintext (unencrypted) HTTP port is enabled and TLS is not enabled anywhere in this paste, so cluster traffic — including credentials and query data — travels unencrypted. Turn the plaintext port off and enable the TLS port with a proper keystore.";
              if (tlsPortEntry && tlsPortEntry.value.toLowerCase() === "false") {
                msg += " The TLS port is also explicitly disabled at line " + tlsPortEntry.line + ", which removes the encrypted option entirely.";
              }
              add("BLOCKER", plainEntry.line, plainEntry.key, msg);
            } else {
              add("HIGH", plainEntry.line, plainEntry.key, "The plaintext (unencrypted) HTTP port is enabled alongside TLS. Anything that reaches the plaintext port bypasses encryption, so disable the plaintext port unless a specific internal client truly needs it.");
            }
          } else if (plainVal === "false" && tlsPortEntry && tlsPortEntry.value.toLowerCase() === "true") {
            add("INFO", plainEntry.line, plainEntry.key, "Good posture: the plaintext port is disabled and the TLS port is enabled, so cluster traffic is encrypted.");
          }
        } else if (tlsPortEntry && tlsPortEntry.value.toLowerCase() === "true") {
          add("INFO", tlsPortEntry.line, tlsPortEntry.key, "The TLS port is enabled, so an encrypted listener is available for cluster traffic.");
        }

        // ---- Check 2: authentication ----
        var chainEntry = get("druid.auth.authenticatorChain");
        var chainNonEmpty = false;
        var allowUnauthFalse = null;
        druidEntries.forEach(function (e) {
          if (e.key.toLowerCase().indexOf("allowunauthenticated") !== -1 && e.value.toLowerCase() === "false") {
            allowUnauthFalse = e;
          }
        });
        if (chainEntry) {
          var chainInner = chainEntry.value.replace(/[\[\]\s]/g, "").replace(/"/g, "");
          if (chainEntry.value === "" || chainInner === "") {
            add("BLOCKER", chainEntry.line, chainEntry.key, "The authenticator chain is empty, so no authenticator runs and requests are not challenged. Configure at least one authenticator (for example a basic-auth authenticator) in the chain.");
          } else {
            chainNonEmpty = true;
          }
        }
        if (chainNonEmpty) {
          if (allowUnauthFalse) {
            add("INFO", chainEntry.line, chainEntry.key, "An authenticator chain is configured and unauthenticated access is not allowed, so requests must prove who they are.");
          } else {
            add("INFO", chainEntry.line, chainEntry.key, "An authenticator chain is configured, so incoming requests pass through at least one authenticator.");
          }
        }

        // ---- Per-line checks: credentials, allowUnauthenticated, bind posture ----
        druidEntries.forEach(function (e) {
          var lk = e.key.toLowerCase();
          var val = e.value;

          // Check 2b: unauthenticated access explicitly allowed
          if (lk.indexOf("allowunauthenticated") !== -1 && val.toLowerCase() === "true") {
            add("BLOCKER", e.line, e.key, "Unauthenticated access is explicitly allowed, so anyone who can reach the service can use it without proving an identity. Set this to false and require authentication.");
          }

          // Check 3: credentials — key name, line, and length only; value never shown
          var isSecretKey = false;
          for (var s = 0; s < SECRET_WORDS.length; s++) {
            if (lk.indexOf(SECRET_WORDS[s]) !== -1) { isSecretKey = true; break; }
          }
          if (isSecretKey && val !== "") {
            if (isVarRef(val)) {
              add("INFO", e.line, e.key, "Credential supplied by variable reference, so the secret itself is not written into this file. Keep the real value in the environment or a secret store.", val.length);
            } else {
              add("BLOCKER", e.line, e.key, "A credential is written directly into the configuration as a literal value (value length " + val.length + "). Anyone who can read this file — a repo, a backup, a screenshot — has the secret. Move it to an environment variable or secret store and reference it here instead.", val.length);
            }
          }

          // Check 4: bind posture
          if (/\.host$/.test(lk)) {
            if (val === "0.0.0.0" || val === "::") {
              add("HIGH", e.line, e.key, "This service binds to " + val + ", which listens on every network interface, including any public one. Bind to a specific internal or loopback address, or put the service behind a firewall that only trusted hosts can pass.");
            } else if (val !== "") {
              add("INFO", e.line, e.key, "This service binds to the specific address " + val + " rather than every interface, which limits who can reach it.");
            }
          }
        });

        // ---- Check 5: request limit / queue posture ----
        var rlEntry = get("druid.server.http.enableRequestLimit");
        var qEntry = get("druid.server.http.queueSize");
        var qVal = null;
        if (qEntry) {
          var parsedQ = parseInt(qEntry.value, 10);
          if (!isNaN(parsedQ)) qVal = parsedQ;
        }
        if (rlEntry && rlEntry.value.toLowerCase() === "false") {
          add("HIGH", rlEntry.line, rlEntry.key, "Request limiting is switched off, so a burst of requests can pile up unbounded work on this service. Turn request limiting on and pair it with a finite queue size.");
        }
        if (qEntry && qVal !== null && (qVal === -1 || qVal === 0 || qVal > 10000)) {
          add("WARNING", qEntry.line, qEntry.key, "The request queue size is " + qEntry.value + ", which is unbounded, disabled, or far larger than a service can drain in a failure. A stuck downstream turns that queue into memory pressure and long stalls. Pick a finite size the service can actually work through (for example 100).");
        }
        if (rlEntry && rlEntry.value.toLowerCase() === "true") {
          if (qEntry && qVal !== null && qVal >= 1 && qVal <= 10000) {
            add("INFO", rlEntry.line, rlEntry.key, "Request limiting is on and the request queue is finite (" + qEntry.value + "), so overload sheds load instead of piling it up.");
          } else if (!qEntry) {
            add("INFO", rlEntry.line, rlEntry.key, "Request limiting is on, so this service can shed load under pressure instead of accepting every request.");
          }
        }

        findings.sort(function (a, b) {
          if (a.line !== b.line) return a.line - b.line;
          var rank = { BLOCKER: 0, HIGH: 1, WARNING: 2, INFO: 3 };
          return rank[a.severity] - rank[b.severity];
        });

        var counts = { BLOCKER: 0, HIGH: 0, WARNING: 0, INFO: 0 };
        findings.forEach(function (f) { counts[f.severity]++; });

        var verdict;
        if (druidEntries.length < 3) {
          verdict = "NOT ENOUGH TO GRADE";
        } else if (counts.BLOCKER > 0) {
          verdict = "DO NOT DEPLOY";
        } else if (counts.HIGH > 0 || counts.WARNING > 0) {
          verdict = "DEPLOY WITH FIXES";
        } else {
          verdict = "SAFE TO DEPLOY";
        }

        return {
          verdict: verdict,
          counts: counts,
          findings: findings,
          linesTotal: lines.length,
          linesParsed: entries.length + structural,
          druidKeys: druidEntries.length,
          notParsedLines: notParsed
        };
      }

      function buildReport(r) {
        var out = [];
        out.push("J-Dawgs Druid Cluster Config Safety Auditor - audit report");
        out.push("Verdict: " + r.verdict);
        out.push("Counts: BLOCKER " + r.counts.BLOCKER + " | HIGH " + r.counts.HIGH + " | WARNING " + r.counts.WARNING + " | INFO " + r.counts.INFO);
        out.push("Lines: " + r.linesTotal + " total | " + r.linesParsed + " parsed | " + r.druidKeys + " Druid keys recognized | " + r.notParsedLines.length + " not parsed");
        out.push("");
        if (r.verdict === "NOT ENOUGH TO GRADE") {
          out.push("Not enough recognizable Druid configuration to grade: fewer than 3 druid.* keys were found. Paste common.runtime.properties and/or per-service runtime.properties text and grade again.");
          out.push("");
        }
        if (r.findings.length === 0) {
          out.push("Findings: none.");
        } else {
          out.push("Findings:");
          r.findings.forEach(function (f) {
            var line = "[" + f.severity + "] Line " + f.line;
            if (f.key) line += " - " + f.key;
            line += ": " + f.message;
            if (typeof f.valueLength === "number" && f.message.indexOf("value length") === -1) {
              line += " (value length " + f.valueLength + ")";
            }
            out.push(line);
          });
        }
        out.push("");
        if (r.notParsedLines.length > 0) {
          out.push("Not parsed lines (not recognized as settings): " + r.notParsedLines.join(", "));
        } else {
          out.push("Not parsed lines: none.");
        }
        out.push("");
        out.push("Note: credential values are never printed in this report - findings name the key, the line, and the value length only.");
        return out.join("\n");
      }

      function buildJson(r) {
        return {
          tool: "J-Dawgs Druid Cluster Config Safety Auditor",
          verdict: r.verdict,
          counts: {
            blocker: r.counts.BLOCKER,
            high: r.counts.HIGH,
            warning: r.counts.WARNING,
            info: r.counts.INFO
          },
          linesTotal: r.linesTotal,
          linesParsed: r.linesParsed,
          druidKeysRecognized: r.druidKeys,
          notParsedLines: r.notParsedLines,
          findings: r.findings.map(function (f) {
            var o = { severity: f.severity, line: f.line, key: f.key, message: f.message };
            if (typeof f.valueLength === "number") o.valueLength = f.valueLength;
            return o;
          })
        };
      }

      var lastResult = null;
      var lastJsonText = "{}";
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-druid-cluster-config-safety-auditor',
  name: 'J-Dawgs Druid Cluster Config Safety Auditor',
  description: 'Grades a pasted Apache Druid cluster configuration (common + per-service runtime.properties) fully offline into one deploy verdict — plaintext ports, authentication-off posture, and plaintext credentials graded, with secrets reported by key name, line, and length only, never by value. Druid only exe',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
