'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Python Project Config Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------------- Built-in examples ---------------- */

      var FLAWED_EXAMPLE = [
        "[project]",
        "name = \"demo-tool\"",
        "dynamic = [\"version\"]",
        "dependencies = [",
        "    \"requests==2.32.3\",",
        "    \"click>=8.0\",",
        "    \"rich\",",
        "    \"helperlib @ git+https://github.com/example/helperlib.git\",",
        "    \"requests>=2.28\",",
        "]",
        "",
        "[tool.demo]",
        "api-token = \"jdawgs-fake-token-0000\""
      ].join("\n");

      var CLEAN_EXAMPLE = [
        "[build-system]",
        "requires = [\"setuptools>=68\", \"wheel==0.45.1\"]",
        "build-backend = \"setuptools.build_meta\"",
        "",
        "[project]",
        "name = \"clean-tool\"",
        "version = \"1.0.0\"",
        "description = \"A clean example package.\"",
        "requires-python = \">=3.9\"",
        "license = {text = \"MIT\"}",
        "classifiers = [",
        "    \"Programming Language :: Python :: 3\",",
        "]",
        "dependencies = [",
        "    \"requests==2.32.3\",",
        "    \"click>=8.0,<9.0\",",
        "]",
        "",
        "[project.scripts]",
        "clean-tool = \"clean_tool.cli:main\""
      ].join("\n");

      /* ---------------- Small helpers ---------------- */

      function stripComment(line) {
        var out = "", inD = false, inS = false;
        for (var i = 0; i < line.length; i++) {
          var c = line.charAt(i);
          if (inD) { out += c; if (c === "\\") { if (i + 1 < line.length) { out += line.charAt(i + 1); i++; } } else if (c === "\"") inD = false; }
          else if (inS) { out += c; if (c === "'") inS = false; }
          else if (c === "\"") { inD = true; out += c; }
          else if (c === "'") { inS = true; out += c; }
          else if (c === "#") break;
          else out += c;
        }
        return out;
      }

      function extractStrings(segment) {
        var res = [], re = /"([^"]*)"|'([^']*)'/g, m;
        while ((m = re.exec(segment)) !== null) {
          res.push(m[1] !== undefined ? m[1] : m[2]);
        }
        return res;
      }

      function unquote(v) {
        v = v.replace(/^\s+|\s+$/g, "");
        if (v.length >= 2) {
          var a = v.charAt(0), b = v.charAt(v.length - 1);
          if ((a === "\"" && b === "\"") || (a === "'" && b === "'")) return v.slice(1, -1);
        }
        return null; /* not a quoted string */
      }

      var SECRET_KEY_RE = /(token|password|passwd|secret|api[-_]?key|access[-_]?key|private[-_]?key|auth[-_]?key|credential)/i;
      var PLACEHOLDER_RE = /^(x{2,}|\*{2,}|\.{2,}|changeme|change[-_ ]?me|todo|tbd|placeholder|example|sample|dummy|fake|test|none|null|redacted|your[-_a-z0-9 ]*|<[^>]*>|\$\{[^}]*\}|env\([^)]*\))$/i;

      function looksSecret(key, rawValue) {
        var seg = key.split(".");
        var last = seg[seg.length - 1].replace(/^["']|["']$/g, "");
        if (!SECRET_KEY_RE.test(last)) return false;
        var inner = unquote(rawValue);
        if (inner === null) return false;
        if (inner.length < 4) return false;
        if (PLACEHOLDER_RE.test(inner.replace(/^\s+|\s+$/g, ""))) return false;
        return true;
      }

      function depName(spec) {
        var m = /^[A-Za-z0-9._-]+/.exec(spec.replace(/^\s+/, ""));
        if (!m) return spec;
        return m[0].replace(/[._-]+$/, "");
      }

      function normName(name) {
        return name.toLowerCase().replace(/[-_.]+/g, "-");
      }

      function hasSpecifier(spec) {
        return /(==|>=|<=|~=|!=|>|<)/.test(spec);
      }

      /* ---------------- The audit ---------------- */

      var SEV_RANK = { "BLOCKER": 0, "WARNING": 1, "NOT PARSED": 2, "INFO": 3 };

      function audit(text) {
        var findings = [];
        function add(sev, line, msg) { findings.push({ sev: sev, line: line, msg: msg }); }

        var lines = String(text).split(/\r?\n/);
        var table = "";           /* current table path, lowercased */
        var tableHeaderLine = 0;
        var inArray = null;       /* { table, key } while an array is open */

        var project = { seen: false, headerLine: 1, name: false, version: false,
                        dynVersion: false, dynLine: 0, reqPy: null, reqPyLine: 0,
                        license: false, classifiers: false };
        var build = { seen: false, headerLine: 1, backend: false };
        var depFirstLine = {};    /* normalized dep name -> first line */

        function isTracked(t) {
          return t === "project" || t === "build-system" || t.indexOf("project.") === 0;
        }

        function classifyDep(spec, lineNo) {
          var name = depName(spec);
          var key = normName(name);
          if (/\s@\s/.test(spec) || /git\+/i.test(spec)) {
            add("BLOCKER", lineNo, "REVIEW — direct URL / VCS dependency \"" + spec + "\" is a supply-chain risk: it bypasses the package index, so what gets installed can change or vanish without a version bump. Pin a released version from the index instead.");
          } else if (spec.indexOf("==") !== -1) {
            add("INFO", lineNo, "Dependency \"" + spec + "\" is PINNED EXACT (==) — fully reproducible.");
          } else if (spec.indexOf("~=") !== -1 || (/(>=|>)/.test(spec) && spec.indexOf("<") !== -1)) {
            add("INFO", lineNo, "Dependency \"" + spec + "\" is BOUNDED — a floor with an upper cap, so upgrades stay inside a tested range.");
          } else if (/(>=|>)/.test(spec)) {
            add("WARNING", lineNo, "Dependency \"" + spec + "\" is OPEN — a floor with no upper bound, so a future release can break this project without any change here. Add an upper cap.");
          } else if (!hasSpecifier(spec)) {
            add("WARNING", lineNo, "Dependency \"" + spec + "\" is UNPINNED — a bare name with no version specifier, so installs are not reproducible. Pin it or bound it.");
          } else {
            add("INFO", lineNo, "Dependency \"" + spec + "\" carries a version specifier (not one of the standard pin shapes) — confirm it resolves to a bounded range.");
          }
          if (depFirstLine[key] !== undefined) {
            add("WARNING", lineNo, "Duplicate dependency \"" + name + "\" — first declared on line " + depFirstLine[key] + ", declared again on line " + lineNo + ". Keep one entry; the resolver may not pick the one you meant.");
          } else {
            depFirstLine[key] = lineNo;
          }
        }

        function classifyBuildRequire(spec, lineNo) {
          if (!hasSpecifier(spec)) {
            add("WARNING", lineNo, "Build requirement \"" + spec + "\" is unpinned — no version specifier, so the build itself is not reproducible. Pin or bound every [build-system] requirement.");
          }
        }

        function handleArrayEntries(tbl, key, entries, lineNo) {
          var i;
          if (tbl === "project" && key === "dependencies") {
            for (i = 0; i < entries.length; i++) classifyDep(entries[i], lineNo);
          } else if (tbl === "project.optional-dependencies") {
            for (i = 0; i < entries.length; i++) classifyDep(entries[i], lineNo);
          } else if (tbl === "build-system" && key === "requires") {
            for (i = 0; i < entries.length; i++) classifyBuildRequire(entries[i], lineNo);
          } else if (tbl === "project" && key === "dynamic") {
            for (i = 0; i < entries.length; i++) {
              if (entries[i] === "version") { project.dynVersion = true; project.dynLine = lineNo; }
            }
          }
        }

        for (var idx = 0; idx < lines.length; idx++) {
          var lineNo = idx + 1;
          var raw = lines[idx];
          var clean = stripComment(raw);
          var trimmed = clean.replace(/^\s+|\s+$/g, "");

          /* Inside a multi-line array: collect string entries until ']' */
          if (inArray) {
            var closes = trimmed.indexOf("]") !== -1;
            var seg = closes ? trimmed.slice(0, trimmed.indexOf("]")) : trimmed;
            var entries = extractStrings(seg);
            if (entries.length) handleArrayEntries(inArray.table, inArray.key, entries, lineNo);
            var rest = seg.replace(/"[^"]*"|'[^']*'/g, "").replace(/[\s,]/g, "");
            if (rest !== "" && isTracked(inArray.table)) {
              add("NOT PARSED", lineNo, "This line sits inside the \"" + inArray.key + "\" array but is not a quoted entry the heuristic can read. It was not guessed at — check it by hand.");
            }
            if (closes) inArray = null;
            continue;
          }

          if (trimmed === "") continue;

          /* Table header */
          var hm = /^\[\[?\s*([^\]]+?)\s*\]\]?$/.exec(trimmed);
          if (hm) {
            table = hm[1].replace(/\s+/g, "").toLowerCase();
            tableHeaderLine = lineNo;
            if (table === "project") { project.seen = true; project.headerLine = lineNo; }
            if (table === "build-system") { build.seen = true; build.headerLine = lineNo; }
            continue;
          }
          if (trimmed.charAt(0) === "[") {
            if (isTracked(table)) add("NOT PARSED", lineNo, "This looks like a table header but the heuristic cannot read it. It was not guessed at — check it by hand.");
            continue;
          }

          /* Key = value */
          var km = /^("([^"]+)"|'([^']+)'|[A-Za-z0-9_-]+(?:\.[A-Za-z0-9_-]+)*)\s*=\s*(.*)$/.exec(trimmed);
          if (!km) {
            if (isTracked(table)) {
              add("NOT PARSED", lineNo, "The heuristic cannot classify this line inside the [" + table + "] table. It was not guessed at — check it by hand.");
            }
            continue;
          }
          var key = (km[2] !== undefined ? km[2] : (km[3] !== undefined ? km[3] : km[1]));
          var keyLower = key.toLowerCase();
          var value = km[4].replace(/\s+$/g, "");

          /* Secret check runs on every key in every table. The value is
             never copied into any finding or report — key name only. */
          if (looksSecret(key, value)) {
            add("BLOCKER", lineNo, "Secret-looking key \"" + key + "\" holds a non-placeholder value. The value is masked here and never shown. Remove it from pyproject.toml before publishing — load secrets from the environment or a secrets manager instead.");
          }

          if (value === "") {
            if (isTracked(table)) add("NOT PARSED", lineNo, "Key \"" + key + "\" has no value the heuristic can read. It was not guessed at — check it by hand.");
            continue;
          }

          /* Arrays */
          if (value.charAt(0) === "[") {
            var closedHere = value.indexOf("]") !== -1;
            var inner = closedHere ? value.slice(0, value.indexOf("]")) : value;
            var ents = extractStrings(inner);
            if (table === "project" && keyLower === "classifiers") project.classifiers = true;
            if (ents.length) handleArrayEntries(table, keyLower, ents, lineNo);
            if (!closedHere) inArray = { table: table, key: keyLower };
            continue;
          }

          /* Scalars inside the tables we track */
          if (table === "project") {
            if (keyLower === "name") project.name = true;
            else if (keyLower === "version") project.version = true;
            else if (keyLower === "requires-python") {
              var rp = unquote(value);
              project.reqPy = rp !== null ? rp : value;
              project.reqPyLine = lineNo;
            }
            else if (keyLower === "license") project.license = true;
          } else if (table === "build-system") {
            if (keyLower === "build-backend") build.backend = true;
          } else if (table === "project.scripts") {
            var target = unquote(value);
            var shown = target !== null ? target : value;
            if (shown.indexOf(":") === -1) {
              add("WARNING", lineNo, "Entry point \"" + key + " = " + shown + "\" looks malformed — a script target needs a colon, as in \"package.module:main\". As written it will not resolve to a callable.");
            }
          } else if (table === "project.optional-dependencies") {
            var single = unquote(value);
            if (single !== null) classifyDep(single, lineNo);
            else if (isTracked(table)) add("NOT PARSED", lineNo, "Optional dependency group \"" + key + "\" is not an array of quoted strings the heuristic can read. It was not guessed at — check it by hand.");
          }
        }

        if (inArray) {
          add("NOT PARSED", lines.length, "The \"" + inArray.key + "\" array opened in [" + inArray.table + "] is never closed with a \"]\" in the pasted text.");
        }

        /* ---- Whole-file checks ---- */
        if (!project.seen) {
          add("BLOCKER", 1, "No [project] table found anywhere in the file. Without it there is no package metadata to publish — this is not a publishable pyproject.toml.");
        } else {
          if (!project.name) {
            add("BLOCKER", project.headerLine, "The [project] table declares no \"name\". A package cannot be published without one.");
          }
          if (!project.version) {
            if (project.dynVersion) {
              add("INFO", project.dynLine, "No static \"version\" in [project], but version is declared dynamic (dynamic = [\"version\"]) — the build backend or VCS will supply it at build time. Make sure that source is configured.");
            } else {
              add("BLOCKER", project.headerLine, "The [project] table declares no \"version\", and version is not declared dynamic either. Publishing needs one or the other.");
            }
          }
          if (project.reqPy === null) {
            add("WARNING", project.headerLine, "No \"requires-python\" in [project]. Without it, installers will offer this package to interpreters it may not run on. Declare the oldest Python you support.");
          } else {
            var rpVal = project.reqPy;
            var hasUpper = rpVal.indexOf("<") !== -1 || rpVal.indexOf("~=") !== -1;
            if (!hasUpper) {
              add("INFO", project.reqPyLine, "requires-python \"" + rpVal + "\" has no upper bound — that is normal; most projects cap only the floor.");
            }
            var floor = /(>=|>|~=)\s*(\d+)\.(\d+)/.exec(rpVal);
            if (floor) {
              var maj = parseInt(floor[2], 10), min = parseInt(floor[3], 10);
              if (maj < 3 || (maj === 3 && min < 9)) {
                add("INFO", project.reqPyLine, "requires-python floor is " + maj + "." + min + ", below 3.9 — those interpreters are past end-of-life, so supporting them is a dated-support commitment. Drop the floor unless you truly need it.");
              }
            }
          }
          if (!project.license) {
            add("INFO", project.headerLine, "No \"license\" field in [project]. Not a blocker, but a license is what tells other people what they may do with the package — add one before publishing.");
          }
          if (project.classifiers) {
            add("INFO", project.headerLine, "A \"classifiers\" list is present. Classifiers are informational only — they help people browse for the package and never affect the verdict.");
          }
        }

        if (!build.seen) {
          add("WARNING", 1, "No [build-system] table found. Builds fall back to a legacy setuptools path with implicit, unpinned requirements — add an explicit [build-system] with pinned requires and a build-backend.");
        } else if (!build.backend) {
          add("WARNING", build.headerLine, "The [build-system] table declares requires but no \"build-backend\". Without a named backend the build can silently fall back to legacy behavior — name the backend explicitly.");
        }

        findings.sort(function (a, b) {
          if (a.line !== b.line) return a.line - b.line;
          return SEV_RANK[a.sev] - SEV_RANK[b.sev];
        });

        var counts = { "BLOCKER": 0, "WARNING": 0, "NOT PARSED": 0, "INFO": 0 };
        for (var i = 0; i < findings.length; i++) counts[findings[i].sev]++;

        var verdict, vclass;
        if (counts["BLOCKER"] > 0) { verdict = "DO NOT PUBLISH YET"; vclass = "bad"; }
        else if (counts["WARNING"] > 0 || counts["NOT PARSED"] > 0) { verdict = "PUBLISH WITH FIXES"; vclass = "warn"; }
        else { verdict = "READY TO PUBLISH"; vclass = "ok"; }

        return { findings: findings, counts: counts, verdict: verdict, vclass: vclass };
      }

      /* ---------------- Plain-text report ---------------- */

      function buildReport(result) {
        var out = [];
        out.push("J-Dawgs Python Project Config Auditor — audit report");
        out.push("Verdict: " + result.verdict);
        out.push("Findings: " + result.counts["BLOCKER"] + " BLOCKER · " +
                 result.counts["WARNING"] + " WARNING · " +
                 result.counts["NOT PARSED"] + " NOT PARSED · " +
                 result.counts["INFO"] + " INFO");
        out.push("");
        if (result.findings.length === 0) {
          out.push("No findings. Nothing was flagged at any level.");
        } else {
          for (var i = 0; i < result.findings.length; i++) {
            var f = result.findings[i];
            out.push("Line " + f.line + " [" + f.sev + "] " + f.msg);
          }
        }
        out.push("");
        out.push("Heuristic text audit — not a full TOML parser. Nothing was built, installed, or fetched; secret values are masked by key name only and never appear in this report.");
        return out.join("\n");
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "FLAWED_EXAMPLE": (typeof FLAWED_EXAMPLE !== 'undefined' ? FLAWED_EXAMPLE : undefined), "CLEAN_EXAMPLE": (typeof CLEAN_EXAMPLE !== 'undefined' ? CLEAN_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-python-project-config-auditortm',
  name: 'J-Dawgs Python Project Config Auditor',
  description: 'Packaging validators need an installed project and stop at metadata validity; this audits a pasted pyproject.toml anywhere — dependency pinning classified per entry, VCS/direct-URL deps and secret-named keys (values never shown) flagged, duplicates named — into one publish verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "FLAWED_EXAMPLE": __core["FLAWED_EXAMPLE"], "CLEAN_EXAMPLE": __core["CLEAN_EXAMPLE"] }
};
