'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs RabbitMQ Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Worked examples ---------- */
      /* Risky example — line numbers the findings must hit:
         4 default_user, 5 default_pass, 6 loopback_users.guest,
         7 management.tcp.ip, 2 listeners.tcp.default, 3 commented TLS listener. */
      var EXAMPLE_RISKY = [
        "# rabbitmq.conf — copied from a getting-started tutorial",
        "listeners.tcp.default = 0.0.0.0:5672",
        "# listeners.ssl.default = 5671",
        "default_user = guest",
        "default_pass = guest",
        "loopback_users.guest = false",
        "management.tcp.ip = 0.0.0.0",
        "management.tcp.port = 15672",
        "heartbeat = 0",
        "ssl_options.verify = verify_none",
        "vm_memory_high_watermark.relative = 0.4",
        "vm_memory_high_watermark.relative = 0.6",
        "my_custom.tuning.knob = on"
      ].join("\n");

      var EXAMPLE_HARDENED = [
        "# rabbitmq.conf — hardened production broker",
        "listeners.tcp.default = 127.0.0.1:5672",
        "listeners.ssl.default = 5671",
        "ssl_options.cacertfile = /etc/rabbitmq/tls/ca.pem",
        "ssl_options.certfile = /etc/rabbitmq/tls/server.pem",
        "ssl_options.keyfile = /etc/rabbitmq/tls/server.key",
        "ssl_options.verify = verify_peer",
        "ssl_options.fail_if_no_peer_cert = true",
        "loopback_users = guest",
        "management.tcp.ip = 127.0.0.1",
        "management.ssl.port = 15671",
        "management.ssl.cacertfile = /etc/rabbitmq/tls/ca.pem",
        "management.ssl.certfile = /etc/rabbitmq/tls/server.pem",
        "management.ssl.keyfile = /etc/rabbitmq/tls/server.key",
        "heartbeat = 60",
        "handshake_timeout = 10000",
        "auth_backends.1 = rabbit_auth_backend_internal"
      ].join("\n");

      /* ---------- Known-key registry (public rabbitmq.conf key space) ---------- */
      var KNOWN_EXACT = {};
      [
        "default_user", "default_pass", "default_vhost", "loopback_users",
        "heartbeat", "handshake_timeout", "channel_max", "frame_max",
        "max_message_size", "consumer_timeout", "channel_shutdown_timeout",
        "collect_statistics", "collect_statistics_interval",
        "cluster_partition_handling", "cluster_keepalive_interval",
        "proxy_protocol", "reverse_dns_lookups", "hipe_compile",
        "total_memory_available_override_value", "raft.wal_max_size_bytes",
        "password_hashing_module", "credit_flow_default_credit"
      ].forEach(function (k) { KNOWN_EXACT[k] = true; });

      var KNOWN_PREFIX = [
        "listeners.", "ssl_options.", "ssl_listen_options.", "management.",
        "auth_backends.", "auth_mechanisms.", "auth_ldap.", "auth_http.",
        "auth_oauth2.", "loopback_users.", "default_permissions.",
        "default_policies.", "vm_memory_high_watermark.", "disk_free_limit.",
        "tcp_listen_options.", "cluster_", "log.", "webmachine.",
        "kernel.", "os_mon.", "mnesia.", "ra.", "quorum_queue.",
        "stream.", "mqtt.", "stomp.", "shovel.", "federation.",
        "prometheus.", "oauth2.", "amqp1_0.", "deprecated_features.permit.",
        "exchange_types.", "tracing.", "background_gc_enabled.",
        "autocluster.", "formation.", "mirroring_sync_batch_size."
      ];

      function isKnownKey(key) {
        if (KNOWN_EXACT[key]) return true;
        for (var i = 0; i < KNOWN_PREFIX.length; i++) {
          if (key.indexOf(KNOWN_PREFIX[i]) === 0) return true;
        }
        return false;
      }

      function isLoopbackAddr(v) {
        v = (v || "").trim().toLowerCase();
        return v === "localhost" || v === "::1" || v.indexOf("127.") === 0;
      }
      function isAllInterfaces(v) {
        v = (v || "").trim().toLowerCase();
        return v === "0.0.0.0" || v === "::" || v === "*";
      }

      function looksLikeErlang(text) {
        var t = text.replace(/^\s+/, "");
        if (t.charAt(0) === "[" || t.charAt(0) === "{") return true;
        if (t.indexOf("[{") !== -1) return true;
        if (/\{\s*(rabbit|rabbitmq|kernel|ssl_options)\s*,/.test(t)) return true;
        var lines = t.split(/\r?\n/), eq = 0, brace = 0, total = 0;
        for (var i = 0; i < lines.length; i++) {
          var s = lines[i].trim();
          if (!s || s.charAt(0) === "%" || s.charAt(0) === "#") continue;
          total++;
          if (s.indexOf("=") !== -1) eq++;
          if (s.indexOf("{") !== -1 || s.indexOf("}") !== -1) brace++;
        }
        return total > 0 && eq === 0 && brace > 0;
      }

      /* ---------- The audit (pure: text in, result out) ---------- */
      function auditConfig(text) {
        var result = {
          notParsed: false, empty: false,
          findings: [], notAudited: [],
          counts: { blocker: 0, warning: 0, info: 0, notAudited: 0 },
          verdict: null, linesAudited: 0
        };
        if (!text || !text.trim()) { result.empty = true; return result; }
        if (looksLikeErlang(text)) { result.notParsed = true; return result; }

        var lines = text.split(/\r?\n/);
        result.linesAudited = lines.length;
        var entries = [];      /* {key, value, line} */
        var commented = [];    /* {key, line} */
        var KEY_RE = /^[A-Za-z0-9_][A-Za-z0-9_.\-]*$/;

        lines.forEach(function (raw, idx) {
          var lineNo = idx + 1;
          var t = raw.trim();
          if (!t) return;
          if (t.charAt(0) === "#") {
            var m = t.slice(1).match(/^\s*([A-Za-z0-9_][A-Za-z0-9_.\-]*)\s*=\s*(.*)$/);
            if (m) commented.push({ key: m[1], line: lineNo });
            return;
          }
          var eq = t.indexOf("=");
          if (eq > 0) {
            var key = t.slice(0, eq).trim();
            if (KEY_RE.test(key)) {
              entries.push({ key: key, value: t.slice(eq + 1).trim(), line: lineNo });
            }
          }
        });

        var byKey = {};        /* key -> [entries in order] */
        entries.forEach(function (e) {
          (byKey[e.key] = byKey[e.key] || []).push(e);
        });
        function eff(key) { var a = byKey[key]; return a ? a[a.length - 1] : null; }
        function hasPrefix(p) {
          return entries.some(function (e) { return e.key.indexOf(p) === 0; });
        }
        function commentedLine(key) {
          for (var i = 0; i < commented.length; i++) {
            if (commented[i].key === key) return commented[i].line;
          }
          return null;
        }
        function add(sev, linesArr, keyName, title, detail, fix) {
          result.findings.push({
            sev: sev, lines: linesArr, key: keyName,
            title: title, detail: detail, fix: fix
          });
        }

        var hasTlsListener = hasPrefix("listeners.ssl.");
        var hasMgmtSsl = hasPrefix("management.ssl.");

        /* 1 — default credentials (BLOCKER). Password value NEVER rendered. */
        var du = eff("default_user");
        if (du) {
          add("BLOCKER", [du.line], "default_user",
            "Default user still configured (default_user, line " + du.line + ")",
            "default_user is set in the file, which means the broker's well-known default-style credentials ship with this config. Anyone who knows RabbitMQ's defaults can try them first — and automated scanners do, within minutes of a broker appearing on a network.",
            "Remove the default_user and default_pass lines entirely and create named users with strong, unique passwords (or provision users via definitions / your config management) before this broker is reachable.");
        }
        var dp = eff("default_pass");
        if (dp) {
          add("BLOCKER", [dp.line], "default_pass",
            "Default password still configured (default_pass, line " + dp.line + ")",
            "default_pass is set on line " + dp.line + ". Its value is deliberately not shown anywhere in this report — findings name the key and the line only — but a password sitting in a shipped config file must be treated as public.",
            "Remove the default_pass line (and default_user with it), rotate the credential anywhere it was ever used, and keep real passwords out of config files that get copied, committed, or shared.");
        }

        /* 2 — loopback_users / remote guest (BLOCKER) */
        var lg = eff("loopback_users.guest");
        if (lg && lg.value.toLowerCase() === "false") {
          add("BLOCKER", [lg.line], "loopback_users.guest",
            "Guest is allowed to log in remotely (loopback_users.guest = false, line " + lg.line + ")",
            "By default RabbitMQ restricts the guest user to connections from localhost. Setting loopback_users.guest = false removes that restriction, so the best-known username in messaging can be tried from anywhere the broker is reachable.",
            "Delete the loopback_users.guest = false line (the default restricts guest to loopback), and give remote access to named users with their own credentials instead.");
        }
        var lu = eff("loopback_users");
        if (lu && lu.value.toLowerCase() === "none") {
          add("BLOCKER", [lu.line], "loopback_users",
            "Loopback restriction removed for every user (loopback_users = none, line " + lu.line + ")",
            "loopback_users = none switches the localhost-only restriction off entirely — including for guest, whose default credentials are the first thing scanners try.",
            "Set loopback_users = guest (or remove the line to restore the default) so built-in accounts stay reachable only from the host itself.");
        }

        /* 3 — management listener without TLS (BLOCKER / WARNING) */
        var mIp = eff("management.tcp.ip");
        var mPort = eff("management.tcp.port");
        if ((mIp || mPort) && !hasMgmtSsl) {
          if (mIp && isAllInterfaces(mIp.value)) {
            add("BLOCKER", [mIp.line], "management.tcp.ip",
              "Management interface exposed on all interfaces without TLS (management.tcp.ip, line " + mIp.line + ")",
              "management.tcp.ip binds the management plugin to every network interface, and no management.ssl listener is configured — so the management UI and HTTP API, which can create users, delete queues, and read messages, are served over plain HTTP to anyone who can reach the host. Credentials and session cookies cross the network unencrypted.",
              "Bind management.tcp.ip to 127.0.0.1 and reach it through a tunnel or a TLS-terminating proxy, or configure management.ssl.port with a certificate so the management interface only speaks HTTPS.");
          } else if (mIp && !isLoopbackAddr(mIp.value)) {
            add("WARNING", [mIp.line], "management.tcp.ip",
              "Management interface on a non-loopback address without TLS (management.tcp.ip, line " + mIp.line + ")",
              "management.tcp.ip points the management plugin at a specific non-loopback address (" + mIp.value + ") and no management.ssl listener is configured. That is narrower than an all-interfaces bind, but the management UI and API still run over plain HTTP on that address — full broker control with credentials sent unencrypted.",
              "Prefer 127.0.0.1 plus a tunnel, or set management.ssl.port with a certificate; if this address is on a trusted private network, say so in a comment and re-check it at every network change.");
          } else if (!mIp && mPort) {
            add("WARNING", [mPort.line], "management.tcp.port",
              "Management listener on by default address, no TLS (silent default at line " + mPort.line + ")",
              "management.tcp.port is set but management.tcp.ip is not, so the management listener falls back to its default bind: all interfaces. With no management.ssl listener configured, the management UI and API are reachable over plain HTTP wherever the network lets traffic in.",
              "Set management.tcp.ip = 127.0.0.1 explicitly, or configure management.ssl.* and use management.ssl.port so the interface only serves HTTPS.");
          }
        }

        /* 4 — AMQP TCP listener on all interfaces without TLS (WARNING) */
        entries.forEach(function (e) {
          if (e.key.indexOf("listeners.tcp.") !== 0) return;
          var v = e.value;
          var barePort = /^\d+$/.test(v);
          var addrPart = v.replace(/:\d+\s*$/, "");
          var allIf = isAllInterfaces(addrPart) || barePort;
          if (allIf && !hasTlsListener) {
            add("WARNING", [e.line], e.key,
              "AMQP listener reachable on all interfaces with no TLS listener (" + e.key + ", line " + e.line + ")",
              barePort
                ? "A bare port number binds the AMQP listener to every interface, and no listeners.ssl.* setting exists in this file — so connections, credentials, and message traffic are all in plain text on every interface."
                : e.key + " binds the AMQP listener to " + addrPart + " (every interface), and no listeners.ssl.* setting exists in this file — so connections, credentials, and message traffic are all in plain text on every interface.",
              "Bind the plain listener to 127.0.0.1 if clients are local, or add a TLS listener (listeners.ssl.default with ssl_options certificates) and have clients connect to that; keep the plain listener off the public network.");
          }
        });

        /* 5 — TLS peer verification weakened (WARNING) */
        var sv = eff("ssl_options.verify");
        if (sv && sv.value.toLowerCase() === "verify_none") {
          add("WARNING", [sv.line], "ssl_options.verify",
            "TLS peer verification is off (ssl_options.verify = verify_none, line " + sv.line + ")",
            "verify_none means the broker accepts TLS connections without verifying the client's certificate. The traffic is encrypted, but the broker cannot tell a legitimate client from anyone else who can open a connection — the authentication half of TLS is switched off.",
            "Set ssl_options.verify = verify_peer with ssl_options.cacertfile pointing at your CA, so clients must present a certificate the broker trusts.");
        }
        var fnp = eff("ssl_options.fail_if_no_peer_cert");
        if (fnp && fnp.value.toLowerCase() === "false") {
          add("WARNING", [fnp.line], "ssl_options.fail_if_no_peer_cert",
            "Clients without certificates are let in anyway (ssl_options.fail_if_no_peer_cert = false, line " + fnp.line + ")",
            "With fail_if_no_peer_cert = false, a client that presents no certificate at all is still allowed to connect — so even where verify_peer is set, certificate-less clients slip past it.",
            "Set ssl_options.fail_if_no_peer_cert = true so a missing or unverifiable client certificate ends the connection.");
        }

        /* 6 — auth backends: anonymous / LDAP without TLS (WARNING) */
        entries.forEach(function (e) {
          if (e.key.indexOf("auth_backends.") === 0 || e.key === "auth_backends") {
            var v = e.value.toLowerCase();
            if (v.indexOf("anonymous") !== -1) {
              add("WARNING", [e.line], e.key,
                "Auth backend allows anonymous access (" + e.key + ", line " + e.line + ")",
                "This auth backend entry (" + e.value + ") permits connections without credentials. On any reachable listener, that is an open door, not a convenience.",
                "Remove the anonymous backend and require named users with real credentials for every connection.");
            } else if (v.indexOf("ldap") !== -1) {
              var ldapSsl = eff("auth_ldap.use_ssl");
              if (!ldapSsl || ldapSsl.value.toLowerCase() !== "true") {
                add("WARNING", [e.line], e.key,
                  "LDAP auth backend with no TLS (" + e.key + ", line " + e.line + ")",
                  "This config authenticates against LDAP (" + e.value + ") but auth_ldap.use_ssl is not set to true, so bind credentials travel to the directory over an unencrypted connection.",
                  "Set auth_ldap.use_ssl = true (and confirm the LDAP port is the TLS one, typically 636) so directory lookups and binds are encrypted.");
              }
            }
          }
          if (e.key.indexOf("auth_mechanisms.") === 0) {
            if (e.value.toUpperCase() === "ANONYMOUS") {
              add("WARNING", [e.line], e.key,
                "Anonymous SASL mechanism enabled (" + e.key + ", line " + e.line + ")",
                "Listing ANONYMOUS in auth_mechanisms lets clients connect with no username and no password on any listener that accepts the mechanism.",
                "Remove ANONYMOUS from auth_mechanisms so every connection presents credentials.");
            }
          }
        });

        /* 7 — heartbeat / handshake extremes (INFO) */
        var hb = eff("heartbeat");
        if (hb) {
          var hbv = parseInt(hb.value, 10);
          if (!isNaN(hbv) && hbv === 0) {
            add("INFO", [hb.line], "heartbeat",
              "Heartbeat disabled (heartbeat = 0, line " + hb.line + ")",
              "A heartbeat of 0 turns connection heartbeats off. Dead connections and dead clients then linger until TCP itself gives up, which can hold queues, memory, and file descriptors far longer than expected.",
              "Set heartbeat to a sane value (the RabbitMQ default is 60 seconds) unless you have a measured reason and your own dead-connection cleanup.");
          } else if (!isNaN(hbv) && hbv >= 300) {
            add("INFO", [hb.line], "heartbeat",
              "Heartbeat is very long (heartbeat = " + hb.value + ", line " + hb.line + ")",
              "Heartbeats this far apart delay detection of dead peers to many minutes — failures surface late and half-open connections pile up in the meantime.",
              "Bring heartbeat back toward the 60-second default unless a measured network constraint forces otherwise.");
          }
        }
        var hs = eff("handshake_timeout");
        if (hs) {
          var hsv = parseInt(hs.value, 10);
          if (!isNaN(hsv) && (hsv <= 2000 || hsv >= 60000)) {
            add("INFO", [hs.line], "handshake_timeout",
              "Handshake timeout is at an extreme (handshake_timeout = " + hs.value + ", line " + hs.line + ")",
              hsv <= 2000
                ? "At " + hs.value + " ms, slow or distant clients may fail the connection handshake under load and retry in storms."
                : "At " + hs.value + " ms, half-finished handshakes hold connections open far longer than they should, which wastes file descriptors under connection churn or scanning.",
              "The RabbitMQ default is 10000 ms; stay near it unless you have measurements that justify the change.");
          }
        }

        /* 8 — duplicate keys: last in file wins, name BOTH lines (WARNING) */
        Object.keys(byKey).forEach(function (key) {
          var occ = byKey[key];
          if (occ.length > 1) {
            var lineList = occ.map(function (o) { return o.line; });
            add("WARNING", lineList, key,
              "Duplicate key: " + key + " is set on lines " + lineList.join(" and ") + " — the last one wins",
              "This key appears " + occ.length + " times. rabbitmq.conf resolves duplicates by taking the last value in the file (line " + lineList[lineList.length - 1] + "), so the earlier setting on line " + lineList[0] + " is dead text that will mislead the next person who edits this file.",
              "Delete the earlier occurrence(s) of " + key + " and keep the single value you actually intend.");
          }
        });

        /* 9 — silent defaults: commented-out / missing security settings */
        if (!hasTlsListener) {
          var cl = commentedLine("listeners.ssl.default");
          add("WARNING", cl ? [cl] : [], "listeners.ssl.default",
            cl
              ? "No TLS listener configured — the only one is commented out (line " + cl + ")"
              : "No TLS listener configured at all (silent default)",
            cl
              ? "Line " + cl + " sets listeners.ssl.default but it is commented out, and commented-out keys count as unset — so this broker runs with no TLS listener at all. That is the silent default: every AMQP connection is plain text unless something outside this file terminates TLS."
              : "Nothing in this file configures a listeners.ssl.* listener, so the broker's silent default applies: no TLS listener at all, and every AMQP connection is plain text unless something outside this file terminates TLS.",
            "Uncomment and complete the listeners.ssl.default setting (with ssl_options.cacertfile, certfile, and keyfile), or document the external TLS terminator that covers this broker.");
        }
        if (!eff("loopback_users") && !eff("loopback_users.guest")) {
          var clu = commentedLine("loopback_users");
          add("INFO", clu ? [clu] : [], "loopback_users",
            "loopback_users not set — safe silent default applies" + (clu ? " (only a commented-out line at line " + clu + ")" : ""),
            "Because loopback_users is unset, RabbitMQ's default applies: the guest user can only connect from localhost. That default is safe — this note exists so you know it is the default protecting you, not a setting in this file.",
            "No change needed. If you want the protection to survive edits, set loopback_users = guest explicitly.");
        }

        /* 10 — unknown keys: NOT AUDITED, by name, never guessed */
        var unknownSeen = {};
        entries.forEach(function (e) {
          if (!isKnownKey(e.key)) {
            if (!unknownSeen[e.key]) unknownSeen[e.key] = [];
            unknownSeen[e.key].push(e.line);
          }
        });
        Object.keys(unknownSeen).forEach(function (key) {
          result.notAudited.push({ key: key, lines: unknownSeen[key] });
        });

        /* Severity order, then line order */
        var rank = { BLOCKER: 0, WARNING: 1, INFO: 2 };
        result.findings.sort(function (a, b) {
          if (rank[a.sev] !== rank[b.sev]) return rank[a.sev] - rank[b.sev];
          var la = a.lines.length ? a.lines[0] : 0, lb = b.lines.length ? b.lines[0] : 0;
          return la - lb;
        });
        result.findings.forEach(function (f) {
          if (f.sev === "BLOCKER") result.counts.blocker++;
          else if (f.sev === "WARNING") result.counts.warning++;
          else if (f.sev === "INFO") result.counts.info++;
        });
        result.counts.notAudited = result.notAudited.length;
        result.verdict = result.counts.blocker > 0 ? "DO NOT DEPLOY"
          : result.counts.warning > 0 ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY";
        return result;
      }

      function verdictWhy(r) {
        if (r.verdict === "DO NOT DEPLOY") {
          return r.counts.blocker + " blocker finding(s) must be fixed before this config goes anywhere near a network. A blocker here means a known-bad credential, a remotely reachable built-in account, or an unencrypted full-control interface.";
        }
        if (r.verdict === "DEPLOY WITH FIXES") {
          return "No blockers, but " + r.counts.warning + " warning(s) should be fixed before deployment — each one below names the line and the fix.";
        }
        return "No blockers and no warnings in the audited settings. Info notes and not-audited keys (if any) are listed below — the verdict covers the keys this tool knows how to grade.";
      }

      function buildReport(r, sourceLabel) {
        var out = [];
        out.push("J-Dawgs RabbitMQ Server Config Safety Auditor — audit report");
        out.push("Source: " + sourceLabel);
        out.push("Verdict: " + r.verdict);
        out.push("Counts: " + r.counts.blocker + " blocker(s), " + r.counts.warning +
          " warning(s), " + r.counts.info + " info, " + r.counts.notAudited + " not audited");
        out.push("");
        if (r.findings.length === 0) {
          out.push("No findings in the audited settings.");
        } else {
          r.findings.forEach(function (f, i) {
            var where = f.lines.length ? "Line " + f.lines.join(", ") : "File-wide (setting absent)";
            out.push((i + 1) + ". [" + f.sev + "] " + where + " — " + f.title);
            out.push("   " + f.detail);
            out.push("   Fix: " + f.fix);
            out.push("");
          });
        }
        if (r.notAudited.length) {
          out.push("NOT AUDITED (unknown keys, named — never guessed):");
          r.notAudited.forEach(function (u) {
            out.push("- " + u.key + " (line " + u.lines.join(", ") + ")");
          });
          out.push("");
        }
        out.push("Notes: heuristic offline text audit. advanced.config Erlang terms are not parsed. " +
          "Password values are never included in this report — findings name the key and line only.");
        return out.join("\n");
      }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_RISKY": (typeof EXAMPLE_RISKY !== 'undefined' ? EXAMPLE_RISKY : undefined), "EXAMPLE_HARDENED": (typeof EXAMPLE_HARDENED !== 'undefined' ? EXAMPLE_HARDENED : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-rabbitmq-server-config-safety-auditor',
  name: 'J-Dawgs RabbitMQ Server Config Safety Auditor',
  description: 'rabbitmqctl needs a running node and answers one question at a time; ours audits a pasted rabbitmq.conf offline — default credentials flagged by key name only, loopback_users posture, management listener exposure, duplicate keys with both lines named — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_RISKY": __core["EXAMPLE_RISKY"], "EXAMPLE_HARDENED": __core["EXAMPLE_HARDENED"] }
};
