'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Listmonk Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Worked examples (line numbers are graded exactly) ---------- */
      var RISKY_LINES = [
        "# Risky worked example \u2014 common first-deploy mistakes. Fake values only.",
        "[app]",
        "address = \"0.0.0.0:9000\"",
        "admin_username = \"listmonk\"",
        "admin_password = \"listmonk\"",
        "# tls_enabled = true",
        "",
        "[db]",
        "host = \"db.internal.example.com\"",
        "port = 5432",
        "user = \"listmonk\"",
        "password = \"R1sky-Db-Pass-7741!\"",
        "database = \"listmonk\"",
        "ssl_mode = \"disable\"",
        "ssl_mode = \"disable\"",
        "",
        "[smtp]",
        "host = \"mail.example.com\"",
        "port = 25",
        "username = \"mailer\"",
        "password = \"Smtp-Pass-9920!\"",
        "tls_type = \"none\"",
        "this line is not a setting at all"
      ];
      var RISKY = RISKY_LINES.join("\n");

      var HARDENED_LINES = [
        "# Hardened worked example \u2014 same shape, deploy-ready posture. Fake values only.",
        "[app]",
        "address = \"127.0.0.1:9000\"",
        "admin_username = \"jd-ops-admin\"",
        "admin_password = \"V7$kQ9!mZ2#xL4pR8wT\"",
        "tls_enabled = true",
        "tls_cert_path = \"/etc/listmonk/tls/fullchain.pem\"",
        "tls_key_path = \"/etc/listmonk/tls/privkey.pem\"",
        "",
        "[db]",
        "host = \"127.0.0.1\"",
        "port = 5432",
        "user = \"listmonk_app\"",
        "password = \"${LISTMONK_DB_PASSWORD}\"",
        "database = \"listmonk\"",
        "ssl_mode = \"require\"",
        "",
        "[upload]",
        "provider = \"filesystem\"",
        "upload_path = \"/var/lib/listmonk/uploads\"",
        "max_file_size = 10485760",
        "",
        "[smtp]",
        "host = \"mail.example.com\"",
        "port = 587",
        "username = \"mailer\"",
        "password = \"${LISTMONK_SMTP_PASSWORD}\"",
        "tls_type = \"starttls\"",
        "tls_skip_verify = false"
      ];
      var HARDENED = HARDENED_LINES.join("\n");

      /* ---------- Grading constants ---------- */
      var DEFAULT_PASSWORDS = ["listmonk","admin","password","password123","password1","changeme","change_me","change-me","letmein","secret","supersecret","listmonk123","yourpassword","example","default"];
      var DEFAULT_USERNAMES = ["listmonk","admin"];
      var SECRET_KEY_RE = /(password|passwd|secret|token|api[_-]?key|private[_-]?key)/i;
      var TLS_KEYS = ["tls_enabled","tls","https","https_enabled","ssl_enabled","tls_cert","tls_cert_path","tls_key","tls_key_path","cert_file","key_file","behind_reverse_proxy","reverse_proxy_tls"];
      var KNOWN_SECTIONS = ["app","db","smtp","upload","message","privacy","bounce","settings"];
      var KNOWN_KEYS = ["address","admin_username","admin_password","host","port","user","password","database","ssl_mode","tls_enabled","tls_type","tls_skip_verify","username","provider","upload_path","max_file_size"];

      /* ---------- Parser ---------- */
      function stripInlineComment(s){
        var inS=false, inD=false, i, c;
        for(i=0;i<s.length;i++){
          c=s.charAt(i);
          if(c==="'" && !inD){ inS=!inS; }
          else if(c==='"' && !inS){ if(s.charAt(i-1)!=="\\"){ inD=!inD; } }
          else if(c==="#" && !inS && !inD){ return s.slice(0,i); }
        }
        return s;
      }
      function unquote(v){
        v=v.replace(/^\s+|\s+$/g,"");
        if(v.length>=2){
          var a=v.charAt(0), b=v.charAt(v.length-1);
          if((a==='"'&&b==='"')||(a==="'"&&b==="'")){ return v.slice(1,-1); }
        }
        return v;
      }
      function parseConfig(text){
        var rawLines = String(text==null?"":text).split(/\r?\n/);
        var entries=[], commented=[], notParsed=[], section="";
        rawLines.forEach(function(raw, idx){
          var lineNo=idx+1, t=raw.replace(/^\s+|\s+$/g,""), body, mSec, mKv, code, sec, kv;
          if(t===""){ return; }
          if(t.charAt(0)==="#"){
            body=t.slice(1).replace(/^\s+|\s+$/g,"");
            mSec=body.match(/^\[([^\]]+)\]$/);
            mKv=body.match(/^([A-Za-z0-9_.\-]+)\s*=\s*(.*)$/);
            if(mSec){ commented.push({line:lineNo, kind:"section", name:mSec[1].replace(/^\s+|\s+$/g,""), section:section}); }
            else if(mKv){ commented.push({line:lineNo, kind:"key", key:mKv[1], section:section}); }
            return;
          }
          code=stripInlineComment(raw).replace(/^\s+|\s+$/g,"");
          if(code===""){ return; }
          sec=code.match(/^\[([^\]]+)\]$/);
          if(sec){ section=sec[1].replace(/^\s+|\s+$/g,""); return; }
          kv=code.match(/^([A-Za-z0-9_.\-]+)\s*=\s*(.+)$/);
          if(kv){ entries.push({section:section, key:kv[1], value:unquote(kv[2]), line:lineNo}); return; }
          notParsed.push({line:lineNo});
        });
        var groups={}, order=[];
        entries.forEach(function(e){
          var id=e.section+"\u0000"+e.key;
          if(!groups[id]){ groups[id]={section:e.section, key:e.key, lines:[]}; order.push(id); }
          groups[id].lines.push(e.line);
        });
        var duplicates=order.map(function(id){ return groups[id]; }).filter(function(g){ return g.lines.length>1; });
        return {entries:entries, commented:commented, notParsed:notParsed, duplicates:duplicates, lineCount:rawLines.length};
      }
      function getEntry(parsed, section, key){
        var found=null;
        parsed.entries.forEach(function(e){ if(e.section===section && e.key===key){ found=e; } });
        return found;
      }
      function findKey(parsed, key){
        var found=null;
        parsed.entries.forEach(function(e){ if(e.key===key){ found=e; } });
        return found;
      }
      function isPlaceholder(v){
        return /^\$\{[A-Za-z0-9_]+\}$/.test(v) || /^\$[A-Za-z0-9_]+$/.test(v) || /^env:/i.test(v) || /^<[^>]*>$/.test(v);
      }
      function truthy(v){
        var s=String(v).toLowerCase();
        return s==="true"||s==="1"||s==="yes"||s==="on";
      }
      function hostOf(address){
        var a=String(address).replace(/^https?:\/\//i,"");
        var idx=a.lastIndexOf(":");
        if(idx>0){ return a.slice(0,idx).replace(/^\[|\]$/g,""); }
        return a;
      }
      function isLocalHost(h){
        h=String(h||"").toLowerCase();
        return h==="localhost"||h==="127.0.0.1"||h==="::1"||h==="";
      }

      /* ---------- Auditor ---------- */
      function audit(text){
        var parsed=parseConfig(text);
        var findings=[], notes=[], passed=[];
        function add(sev, rule, section, key, line, message){
          findings.push({severity:sev, rule:rule, section:section||"", key:key||"", line:line||null, message:message});
        }
        var recognized=parsed.entries.filter(function(e){
          return KNOWN_SECTIONS.indexOf(e.section)>=0 || KNOWN_KEYS.indexOf(e.key)>=0;
        }).length;

        if(parsed.entries.length===0 || recognized===0){
          parsed.notParsed.forEach(function(n){ notes.push({kind:"notparsed", line:n.line, text:"Line "+n.line+" \u00B7 NOT PARSED"}); });
          parsed.commented.forEach(function(c){
            notes.push({kind:"commented", line:c.line, text:"Line "+c.line+" \u00B7 "+(c.kind==="section" ? "["+c.name+"]" : (c.section? "["+c.section+"] ":"")+c.key)+" \u00B7 COMMENTED / NOT ACTIVE"});
          });
          return finish("NOT ENOUGH TO GRADE", parsed, findings, notes, passed,
            parsed.entries.length===0
              ? "No readable settings were found in the pasted text. Paste a Listmonk config.toml (sections like [app] and [db] with key = value lines) to get a deploy verdict."
              : "The pasted text contains lines, but none of them are recognizable Listmonk settings. Paste a config.toml with sections like [app] and [db] to get a deploy verdict.");
        }

        /* TLS posture anywhere in the file? */
        var tlsPosture=false, tlsEntry=null;
        parsed.entries.forEach(function(e){
          if(TLS_KEYS.indexOf(e.key)>=0 && truthy(e.value)){ tlsPosture=true; tlsEntry=e; }
          if(e.key==="address" && /^https:\/\//i.test(e.value)){ tlsPosture=true; }
        });

        /* --- [app] bind address --- */
        var addr=getEntry(parsed,"app","address") || findKey(parsed,"address");
        if(!addr){
          add("WARNING","app-address-missing","app","address",null,
            "No app address setting was found, so the bind posture cannot be confirmed. State the listen address explicitly in [app].");
        } else {
          var host=hostOf(addr.value);
          var allInterfaces = host==="0.0.0.0" || host==="::" || host==="*" || host==="";
          if(allInterfaces && !tlsPosture){
            add("CRITICAL","bind-all-interfaces-no-tls","app","address",addr.line,
              "Line "+addr.line+": [app] address binds the app to all network interfaces (host \""+host+"\") and no TLS posture is stated anywhere in the config. Anyone who can reach the port can reach the admin login over plain HTTP. Bind to 127.0.0.1 behind a TLS-terminating reverse proxy, or state a TLS posture in the config.");
          } else if(allInterfaces && tlsPosture){
            add("WARNING","bind-all-interfaces-with-tls","app","address",addr.line,
              "Line "+addr.line+": [app] address binds the app to all network interfaces. A TLS posture is stated, but confirm a firewall or reverse proxy really limits who can reach this port.");
          } else {
            passed.push("Line "+addr.line+": [app] address binds to \""+host+"\" \u2014 not exposed on all interfaces.");
          }
        }
        if(tlsPosture && tlsEntry){
          passed.push("Line "+tlsEntry.line+": TLS posture is stated ("+tlsEntry.key+" is on).");
        }

        /* --- Admin credentials --- */
        var aUser=getEntry(parsed,"app","admin_username") || findKey(parsed,"admin_username");
        var aPass=getEntry(parsed,"app","admin_password") || findKey(parsed,"admin_password");
        if(!aPass || aPass.value===""){
          add("CRITICAL","admin-password-missing","app","admin_password", aPass? aPass.line : null,
            "admin_password is missing or empty. The admin account has no password protection stated in the config. Set a long, unique admin_password before deploying.");
        } else {
          if(aPass.value.length<12){
            add("CRITICAL","admin-password-short","app","admin_password",aPass.line,
              "Line "+aPass.line+": admin_password is only "+aPass.value.length+" characters long. Short admin passwords fall to guessing fast \u2014 use at least 12 characters, ideally 16 or more. (Length reported; the value is never shown.)");
          } else {
            passed.push("Line "+aPass.line+": admin_password is set and is "+aPass.value.length+" characters long. (Length only; the value is never shown.)");
          }
          if(DEFAULT_PASSWORDS.indexOf(aPass.value.toLowerCase())>=0){
            add("CRITICAL","admin-password-default","app","admin_password",aPass.line,
              "Line "+aPass.line+": admin_password matches a documented default / example value from the Listmonk sample configuration. Those values are public \u2014 anyone can try them. Replace it with a unique password. (The value is never shown.)");
          }
          if(aUser && aUser.value!=="" && aPass.value===aUser.value){
            add("CRITICAL","admin-credentials-equal","app","admin_password",aPass.line,
              "Line "+aPass.line+": admin_password is identical to admin_username. Identical credentials are the first thing an attacker tries. Make the password different from the username and long.");
          }
        }
        if(aUser && DEFAULT_USERNAMES.indexOf(aUser.value.toLowerCase())>=0){
          add("WARNING","admin-username-default","app","admin_username",aUser.line,
            "Line "+aUser.line+": admin_username is a documented default / example username from the Listmonk sample configuration. Default usernames are public knowledge \u2014 pick a non-obvious admin username.");
        } else if(aUser){
          passed.push("Line "+aUser.line+": admin_username is set and is not a documented default.");
        }
        if(aPass && !aUser){
          add("WARNING","admin-username-missing","app","admin_username",null,
            "admin_password is set but no admin_username was found in the pasted config. Confirm the admin account is fully defined.");
        }

        /* --- [db] --- */
        var hasDb = parsed.entries.some(function(e){ return e.section==="db"; });
        if(!hasDb){
          add("WARNING","db-section-missing","db","",null,
            "No [db] section was found in the pasted config, so the database posture could not be graded. Paste the full config to grade it.");
        }
        var dbPass=getEntry(parsed,"db","password");
        var dbHost=getEntry(parsed,"db","host");
        var dbSsl=getEntry(parsed,"db","ssl_mode");
        if(dbPass && dbPass.value!==""){
          if(isPlaceholder(dbPass.value)){
            passed.push("Line "+dbPass.line+": [db] password is an environment / secret reference, not a literal value in the file.");
          } else {
            add("HIGH","db-password-plaintext","db","password",dbPass.line,
              "Line "+dbPass.line+": the database password is stored as plaintext in the config file (key \"password\", "+dbPass.value.length+" characters; the value is never shown). Anyone who reads the file owns the database. Move it to an environment variable or secret reference (for example ${LISTMONK_DB_PASSWORD}) and lock the config file's permissions down.");
          }
        } else if(hasDb){
          add("WARNING","db-password-missing","db","password",null,
            "No [db] password is set in the pasted config. If the database expects one, the server will fail to connect; if it does not, confirm the database is not reachable by anyone else.");
        }
        if(dbSsl){
          var sslVal=dbSsl.value.toLowerCase();
          if(sslVal==="disable"){
            var remote = dbHost && !isLocalHost(hostOf(dbHost.value));
            if(remote){
              add("CRITICAL","db-ssl-disabled-remote","db","ssl_mode",dbSsl.line,
                "Line "+dbSsl.line+": [db] ssl_mode is \"disable\" and the database host is not local, so database traffic \u2014 queries and credentials \u2014 crosses the network unencrypted. Set ssl_mode to \"require\" or stronger.");
            } else {
              add("HIGH","db-ssl-disabled","db","ssl_mode",dbSsl.line,
                "Line "+dbSsl.line+": [db] ssl_mode is \"disable\", so the database connection is unencrypted. On a single local machine this is lower risk, but \"require\" is the safe default if the database is ever moved off-box.");
            }
          } else if(sslVal==="require"||sslVal==="verify-ca"||sslVal==="verify-full"||sslVal==="prefer"){
            passed.push("Line "+dbSsl.line+": [db] ssl_mode is \""+dbSsl.value+"\" \u2014 database TLS is not disabled.");
          } else {
            notes.push({kind:"info", line:dbSsl.line, text:"Line "+dbSsl.line+" \u00B7 [db] ssl_mode has an unrecognized value \u2014 confirm it enables TLS."});
          }
        } else if(hasDb){
          add("WARNING","db-ssl-mode-missing","db","ssl_mode",null,
            "[db] ssl_mode is not stated. The driver default may not require TLS \u2014 state ssl_mode explicitly (\"require\" or stronger) so the posture is a decision, not an accident.");
        }

        /* --- [smtp] / message transport --- */
        var smtpTls=getEntry(parsed,"smtp","tls_type");
        var smtpSkip=getEntry(parsed,"smtp","tls_skip_verify");
        var smtpPass=getEntry(parsed,"smtp","password");
        if(smtpTls){
          var t=smtpTls.value.toLowerCase();
          if(t==="none"||t==="false"||t==="off"){
            add("HIGH","smtp-tls-none","smtp","tls_type",smtpTls.line,
              "Line "+smtpTls.line+": [smtp] tls_type is \""+smtpTls.value+"\", so outgoing mail and the mail account credentials travel unencrypted. Use \"starttls\" or \"tls\".");
          } else {
            passed.push("Line "+smtpTls.line+": [smtp] tls_type is \""+smtpTls.value+"\" \u2014 mail transport TLS is on.");
          }
        }
        if(smtpSkip && truthy(smtpSkip.value)){
          add("HIGH","smtp-tls-skip-verify","smtp","tls_skip_verify",smtpSkip.line,
            "Line "+smtpSkip.line+": [smtp] tls_skip_verify is on, which accepts any certificate and defeats the point of mail TLS. Turn it off.");
        }
        if(smtpPass && smtpPass.value!=="" && !isPlaceholder(smtpPass.value)){
          add("WARNING","smtp-password-plaintext","smtp","password",smtpPass.line,
            "Line "+smtpPass.line+": the SMTP password is stored as plaintext in the config file (key \"password\", "+smtpPass.value.length+" characters; the value is never shown). Prefer an environment / secret reference and restrict the file's permissions.");
        } else if(smtpPass && smtpPass.value!==""){
          passed.push("Line "+smtpPass.line+": [smtp] password is an environment / secret reference, not a literal value in the file.");
        }

        /* --- Duplicates --- */
        parsed.duplicates.forEach(function(d){
          add("WARNING","duplicate-key", d.section, d.key, d.lines[d.lines.length-1],
            "Duplicate key: "+(d.section? "["+d.section+"] ":"")+d.key+" is set on lines "+d.lines.join(" and ")+". A strict TOML parser rejects duplicate keys outright, and humans misread which value wins. Keep one.");
        });

        /* --- Parse notes --- */
        parsed.commented.forEach(function(c){
          var label = c.kind==="section" ? "["+c.name+"]" : (c.section? "["+c.section+"] ":"")+c.key;
          notes.push({kind:"commented", line:c.line, text:"Line "+c.line+" \u00B7 "+label+" \u00B7 COMMENTED / NOT ACTIVE \u2014 not graded as set"});
        });
        parsed.notParsed.forEach(function(n){
          notes.push({kind:"notparsed", line:n.line, text:"Line "+n.line+" \u00B7 NOT PARSED \u2014 this line is not a readable setting"});
        });
        if(parsed.notParsed.length>0){
          add("WARNING","lines-not-parsed","", "", parsed.notParsed[0].line,
            parsed.notParsed.length+" line(s) could not be parsed as settings (line"+(parsed.notParsed.length>1?"s ":" ")+parsed.notParsed.map(function(n){return n.line;}).join(", ")+"). A real config loader may refuse to start on them. Fix or remove those lines.");
        }

        var verdict;
        if(findings.some(function(f){ return f.severity==="CRITICAL"; })){ verdict="DO NOT DEPLOY"; }
        else if(findings.length>0){ verdict="DEPLOY WITH FIXES"; }
        else { verdict="SAFE TO DEPLOY"; }
        var detail = verdict==="DO NOT DEPLOY"
          ? "At least one critical problem below would expose the server, the admin account, or the database. Fix every critical finding before this config goes live."
          : verdict==="DEPLOY WITH FIXES"
            ? "Nothing here is an open door, but the findings below are real weaknesses. Fix them, re-paste, and aim for a clean pass before deploying."
            : "No graded problems were found in what the pasted config states. This grades the config text only \u2014 it does not test your firewall, your reverse proxy, or whether the passwords actually work.";
        return finish(verdict, parsed, findings, notes, passed, detail);
      }

      function finish(verdict, parsed, findings, notes, passed, detail){
        var counts={
          lines: parsed.lineCount,
          settingsParsed: parsed.entries.length,
          commented: parsed.commented.length,
          notParsed: parsed.notParsed.length,
          duplicates: parsed.duplicates.length,
          critical: findings.filter(function(f){return f.severity==="CRITICAL";}).length,
          high: findings.filter(function(f){return f.severity==="HIGH";}).length,
          warnings: findings.filter(function(f){return f.severity==="WARNING";}).length
        };
        return {verdict:verdict, detail:detail, findings:findings, notes:notes, passed:passed, counts:counts, parsed:parsed};
      }

      /* ---------- Report + JSON builders (findings only \u2014 never secret values) ---------- */
      function buildReport(r){
        var out=[];
        out.push("J-DAWGS LISTMONK SERVER CONFIG SAFETY AUDITOR \u2014 REPORT");
        out.push("Verdict: "+r.verdict);
        out.push("Lines pasted: "+r.counts.lines+" \u00B7 Settings parsed: "+r.counts.settingsParsed+
                 " \u00B7 Commented-out lines: "+r.counts.commented+" \u00B7 Not parsed: "+r.counts.notParsed+
                 " \u00B7 Duplicate keys: "+r.counts.duplicates);
        out.push("");
        out.push("FINDINGS ("+r.findings.length+")");
        if(r.findings.length===0){ out.push("None."); }
        r.findings.forEach(function(f){
          out.push("["+f.severity+"] "+(f.line? "Line "+f.line+" \u00B7 ":"")+(f.section? "["+f.section+"] ":"")+(f.key||"")+" \u2014 "+f.message);
        });
        out.push("");
        out.push("PARSE NOTES ("+r.notes.length+")");
        if(r.notes.length===0){ out.push("None."); }
        r.notes.forEach(function(n){ out.push(n.text); });
        out.push("");
        out.push("CHECKS THAT PASSED ("+r.passed.length+")");
        if(r.passed.length===0){ out.push("None."); }
        r.passed.forEach(function(p){ out.push(p); });
        out.push("");
        out.push("Secrets are reported by key name, line number, and length only. No secret value appears in this report.");
        out.push("This report grades the pasted config text only. It does not start a server, connect to a database, or send mail.");
        return out.join("\n");
      }
      function buildJSON(r){
        var data={
          tool:"J-Dawgs Listmonk Server Config Safety Auditor\u2122",
          verdict:r.verdict,
          counts:r.counts,
          findings:r.findings.map(function(f){
            return {severity:f.severity, rule:f.rule, section:f.section, key:f.key, line:f.line, message:f.message};
          }),
          commented:r.parsed.commented.map(function(c){
            return {line:c.line, section:c.section, key:c.kind==="key"? c.key : null, sectionHeader:c.kind==="section"? c.name : null, status:"COMMENTED / NOT ACTIVE"};
          }),
          notParsed:r.parsed.notParsed.map(function(n){ return {line:n.line, status:"NOT PARSED"}; }),
          duplicates:r.parsed.duplicates.map(function(d){ return {section:d.section, key:d.key, lines:d.lines}; }),
          parseNotes:r.notes.map(function(n){ return n.text; }),
          checksPassed:r.passed,
          secretHandling:"Secrets are reported by key name, line number, and length only. No secret value is included in this export."
        };
        return JSON.stringify(data, null, 2);
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-listmonk-server-config-safety-auditortm',
  name: 'J-Dawgs Listmonk Server Config Safety Auditor',
  description: 'Grades a pasted Listmonk config.toml fully offline into one deploy verdict — SAFE TO DEPLOY / DEPLOY WITH FIXES / DO NOT DEPLOY / NOT ENOUGH TO GRADE — an all-interface bind address, a default or short admin password, database ssl_mode=disable, and a plaintext database password, with secrets shown b',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
