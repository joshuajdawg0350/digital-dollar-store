'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Exim Mail Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var RISKY_EXAMPLE = [
        "# Risky Exim configuration - training example, do not deploy",
        "primary_hostname = mail.example.org",
        "",
        "hostlist relay_from_hosts = 127.0.0.1 : 0.0.0.0/0",
        "",
        "acl_smtp_rcpt = acl_check_rcpt",
        "",
        "tls_advertise_hosts = *",
        "",
        "begin acl",
        "",
        "acl_check_rcpt:",
        "  accept",
        "  deny",
        ""
      ].join("\n");

      var HARDENED_EXAMPLE = [
        "# Hardened Exim configuration - training example",
        "primary_hostname = mail.example.org",
        "",
        "hostlist relay_from_hosts = 127.0.0.1 : 192.168.10.0/24",
        "",
        "never_users = root : mailnull",
        "",
        "tls_advertise_hosts = *",
        "tls_certificate = /etc/exim/certs/mail.example.org.crt",
        "tls_privatekey = /etc/exim/certs/mail.example.org.key",
        "",
        "acl_smtp_rcpt = acl_check_rcpt",
        "",
        "helo_try_verify_hosts = *",
        "",
        "begin acl",
        "",
        "acl_check_rcpt:",
        "  accept  hosts = +relay_from_hosts",
        "  require verify = recipient",
        "  deny",
        ""
      ].join("\n");

      var KNOWN_MAIN = {};
      ("primary_hostname qualify_domain qualify_recipient never_users exim_user exim_group " +
       "trusted_users admin_users tls_advertise_hosts tls_certificate tls_privatekey tls_dhparam " +
       "tls_require_ciphers tls_verify_certificates tls_try_verify_hosts tls_verify_hosts " +
       "tls_on_connect_ports openssl_options daemon_smtp_ports local_interfaces acl_smtp_rcpt " +
       "acl_smtp_data acl_smtp_mail acl_smtp_helo acl_smtp_connect acl_smtp_auth acl_smtp_predata " +
       "acl_smtp_mime acl_smtp_dkim acl_smtp_etrn acl_smtp_expn acl_smtp_vrfy acl_smtp_starttls " +
       "acl_not_smtp acl_not_smtp_mime acl_not_smtp_start auth_advertise_hosts helo_verify_hosts " +
       "helo_try_verify_hosts helo_allow_chars helo_lookup_domains helo_accept_junk_hosts host_lookup " +
       "rfc1413_hosts rfc1413_query_timeout log_selector log_file_path syslog_duplication " +
       "syslog_facility syslog_process pid_file_path spool_directory message_size_limit " +
       "smtp_accept_max smtp_accept_max_per_host smtp_accept_max_per_connection smtp_accept_queue " +
       "smtp_accept_queue_per_connection smtp_connect_backlog smtp_listen_backlog smtp_banner " +
       "deliver_queue_load_max queue_run_in_parallel queue_run_max recipients_max recipients_max_reject " +
       "received_headers_max received_header_text print_topbitchars allow_domain_literals allow_mx_to_ip " +
       "allow_unqualified_recipient allow_unqualified_sender allow_utf8 sender_unqualified_hosts " +
       "recipient_unqualified_hosts percent_hack_domains dns_ipv4_lookup dns_use_udp " +
       "dns_check_names_pattern av_scanner spamd_address smtp_ratelimit_hosts keep_environment " +
       "add_environment ignore_bounce_errors_after timeout_frozen_after auto_thaw freeze_tell " +
       "split_spool_directory check_spool_space check_spool_inodes check_log_space " +
       "check_rfc2047_length local_scan_timeout move_frozen_messages preserve_message_logs " +
       "message_logs write_rejectlog delay_warning_timeout delivery_date_remove envelope_to_remove " +
       "errors_copy errors_reply_to gecos_name gecos_pattern headers_charset message_id_domain " +
       "system_filter system_filter_user system_filter_group remote_max_parallel " +
       "connection_max_messages callout_random_local_part relay_from_hosts"
      ).split(" ").forEach(function (n) { KNOWN_MAIN[n] = true; });

      var ACL_VERBS = { accept: 1, deny: 1, defer: 1, discard: 1, drop: 1, require: 1, warn: 1, redirect: 1 };

      function isSecretName(name) {
        var n = name.toLowerCase();
        return n.indexOf("password") !== -1 || n.indexOf("passwd") !== -1 ||
               n.indexOf("secret") !== -1 || /_key$/.test(n) || n === "privatekey";
      }
      function tokensOf(value) {
        return value.split(/[:,\s]+/).filter(function (t) { return t.length > 0; });
      }
      function coversAll(value) {
        var toks = tokensOf(value);
        for (var i = 0; i < toks.length; i++) {
          if (toks[i] === "*" || toks[i] === "0.0.0.0/0" || toks[i] === "::/0") return toks[i];
        }
        return null;
      }

      function auditConfig(text) {
        var findings = [];
        function add(sev, line, msg, relay) {
          findings.push({ sev: sev, line: line, msg: msg, relay: !!relay });
        }

        var rawLines = text.replace(/\r\n?/g, "\n").split("\n");
        var section = "main";
        var mainSettings = {};   // name -> [{line, value}]
        var listDefs = [];       // {kind, name, value, line}
        var macros = [];         // {name, line}
        var includes = [];       // {line, kind}
        var acls = {};           // label -> {line, verbs: [{verb, line, mods: [{text, line}]}]}
        var aclOrder = [];
        var authBlocks = [];     // {name, line, settings: {name -> {line, value}}}
        var currentAcl = null, currentVerb = null, currentAuth = null;

        rawLines.forEach(function (raw, idx) {
          var lineNo = idx + 1;
          var line = raw.replace(/\s+$/, "");
          var trimmed = line.replace(/^\s+/, "");
          if (trimmed === "" || trimmed.charAt(0) === "#") { return; }

          var beginM = trimmed.match(/^begin\s+([a-z]+)\b/i);
          if (beginM) {
            section = beginM[1].toLowerCase();
            currentAcl = null; currentVerb = null; currentAuth = null;
            return;
          }
          if (/^end\b/i.test(trimmed)) { section = "main"; currentAcl = null; currentVerb = null; currentAuth = null; return; }

          if (section === "main") {
            var incM = trimmed.match(/^\.(include_if_exists|include)\b\s*(.*)$/i);
            if (incM) { includes.push({ line: lineNo, kind: incM[1].toLowerCase() }); return; }
            var listM = trimmed.match(/^(hostlist|domainlist|addresslist)\s+([A-Za-z0-9_]+)\s*=\s*(.*)$/);
            if (listM) { listDefs.push({ kind: listM[1].toLowerCase(), name: listM[2], value: listM[3], line: lineNo }); return; }
            var setM = trimmed.match(/^([A-Za-z][A-Za-z0-9_]*)\s*=\s*(.*)$/);
            if (setM) {
              var name = setM[1], value = setM[2];
              if (/^[A-Z][A-Z0-9_]*$/.test(name)) { macros.push({ name: name, line: lineNo }); return; }
              if (!mainSettings[name]) mainSettings[name] = [];
              mainSettings[name].push({ line: lineNo, value: value });
              return;
            }
            return;
          }

          if (section === "acl") {
            var labelM = trimmed.match(/^([A-Za-z][A-Za-z0-9_]*)\s*:\s*$/);
            if (labelM && !/^\s/.test(raw)) {
              currentAcl = labelM[1];
              if (!acls[currentAcl]) { acls[currentAcl] = { line: lineNo, verbs: [] }; aclOrder.push(currentAcl); }
              currentVerb = null;
              return;
            }
            if (!currentAcl) return;
            var verbM = trimmed.match(/^([a-z]+)\b\s*(.*)$/i);
            if (verbM && ACL_VERBS[verbM[1].toLowerCase()]) {
              currentVerb = { verb: verbM[1].toLowerCase(), line: lineNo, mods: [] };
              if (verbM[2]) currentVerb.mods.push({ text: verbM[2], line: lineNo });
              acls[currentAcl].verbs.push(currentVerb);
              return;
            }
            if (currentVerb) currentVerb.mods.push({ text: trimmed, line: lineNo });
            return;
          }

          if (section === "authenticators") {
            var aLabelM = trimmed.match(/^([A-Za-z][A-Za-z0-9_]*)\s*:\s*$/);
            if (aLabelM && !/^\s/.test(raw)) {
              currentAuth = { name: aLabelM[1], line: lineNo, settings: {} };
              authBlocks.push(currentAuth);
              return;
            }
            if (!currentAuth) return;
            var aSetM = trimmed.match(/^([A-Za-z][A-Za-z0-9_]*)\s*=\s*(.*)$/);
            if (aSetM) currentAuth.settings[aSetM[1].toLowerCase()] = { line: lineNo, value: aSetM[2] };
            return;
          }
        });

        function setting(name) {
          var arr = mainSettings[name];
          return arr && arr.length ? arr[arr.length - 1] : null; // last in file wins
        }

        /* ---------- Relay posture ---------- */
        var openRelay = false;
        var relayDefs = listDefs.filter(function (d) { return d.name === "relay_from_hosts"; });
        var plainRelay = setting("relay_from_hosts");
        relayDefs.forEach(function (d) {
          var bad = coversAll(d.value);
          if (bad) {
            add("BLOCKER", d.line, "hostlist relay_from_hosts covers " + bad + " — any host on the internet may relay through this server. This is an open relay.", true);
            openRelay = true;
          } else {
            add("GOOD", d.line, "hostlist relay_from_hosts is set and limited — it does not cover the whole internet.");
          }
        });
        if (plainRelay) {
          var badP = coversAll(plainRelay.value);
          if (badP) {
            add("BLOCKER", plainRelay.line, "relay_from_hosts covers " + badP + " — any host on the internet may relay through this server. This is an open relay.", true);
            openRelay = true;
          }
        }

        var rcptNames = ["acl_smtp_rcpt"];
        var rcptSetting = setting("acl_smtp_rcpt");
        if (rcptSetting && /^[A-Za-z][A-Za-z0-9_]*$/.test(rcptSetting.value.replace(/\s+/g, ""))) {
          rcptNames.push(rcptSetting.value.replace(/\s+/g, ""));
        }
        var rcptAcl = null, rcptAclName = null;
        for (var ri = 0; ri < rcptNames.length; ri++) {
          if (acls[rcptNames[ri]]) { rcptAcl = acls[rcptNames[ri]]; rcptAclName = rcptNames[ri]; break; }
        }

        if (!rcptAcl) {
          add("WARNING", rcptSetting ? rcptSetting.line : null,
            "Relay posture NOT SETTLED: no acl_smtp_rcpt ACL definition was found in this paste" +
            (rcptSetting ? " (the main setting at this line points to an ACL that is not in the paste)" : "") +
            ". The receiving ACL may live in an .include file, so this audit cannot grade relay posture from this paste alone — it does not invent a pass.");
        } else {
          var sawDeny = false, sawVerifyRecipient = false, sawVerifySender = false;
          rcptAcl.verbs.forEach(function (v) {
            var modText = v.mods.map(function (m) { return m.text; }).join(" ");
            if (/verify\s*=\s*recipient\b/.test(modText)) {
              sawVerifyRecipient = true;
              add("GOOD", v.line, "acl '" + rcptAclName + "' requires verify = recipient — recipients are verified before mail is accepted.");
            }
            if (/verify\s*=\s*sender\b/.test(modText)) {
              sawVerifySender = true;
              add("GOOD", v.line, "acl '" + rcptAclName + "' uses verify = sender — sender addresses are verified.");
            }
            if (v.verb === "deny") sawDeny = true;
            if (v.verb === "accept") {
              var restricted = /(hosts|condition|domains|senders|recipients|local_parts|authenticated|verify|control|endpass)\b/.test(modText);
              if (v.mods.length === 0 || !restricted) {
                add("BLOCKER", v.line, "acl '" + rcptAclName + "' has a bare unconditional 'accept' with no hosts/condition restriction" + (sawDeny ? "" : " before any deny") + " — any connecting host is accepted for relay. This is an open relay.", true);
                openRelay = true;
              }
            }
          });
          if (sawDeny) {
            add("GOOD", rcptAcl.verbs.filter(function (v) { return v.verb === "deny"; })[0].line,
              "acl '" + rcptAclName + "' contains a deny — hosts that match no accept are refused.");
          }
          if (!sawVerifyRecipient && !sawVerifySender) {
            add("INFO", rcptAcl.line, "No verify = recipient or verify = sender seen in acl '" + rcptAclName + "' — recipient/sender verification posture is not visible in this paste.");
          }
        }

        /* ---------- Privilege ---------- */
        var neverUsers = setting("never_users");
        if (!neverUsers) {
          add("WARNING", null, "never_users is not set anywhere in this paste — Exim's built-in default applies, but the paste does not prove root is barred from running Exim delivery. Set never_users to include root.");
        } else {
          var nuToks = tokensOf(neverUsers.value.replace(/<[^>]*>/g, " "));
          if (nuToks.indexOf("root") !== -1 || nuToks.indexOf("0") !== -1) {
            add("GOOD", neverUsers.line, "never_users includes root — Exim will refuse to run deliveries as root.");
          } else {
            add("WARNING", neverUsers.line, "never_users is set but does not include root — add root so Exim can never run a delivery as root.");
          }
        }

        /* ---------- TLS ---------- */
        var tlsAdv = setting("tls_advertise_hosts");
        var tlsCert = setting("tls_certificate");
        var tlsKey = setting("tls_privatekey");
        if (!tlsAdv || tlsAdv.value.replace(/\s+/g, "") === "") {
          add("WARNING", tlsAdv ? tlsAdv.line : null, "tls_advertise_hosts is " + (tlsAdv ? "empty" : "not set") + " — STARTTLS is not offered to any host, so mail and credentials can cross the network unencrypted.");
        } else {
          var advAll = coversAll(tlsAdv.value);
          if (advAll && !tlsCert) {
            add("BLOCKER", tlsAdv.line, "tls_advertise_hosts covers " + advAll + " (STARTTLS advertised to everyone) but no tls_certificate is configured anywhere in this paste — TLS is advertised but unconfigured and will fail or fall back to plaintext.");
          } else if (!advAll) {
            add("GOOD", tlsAdv.line, "tls_advertise_hosts is set for a limited host set — STARTTLS is offered where configured.");
          }
        }
        if (tlsCert) {
          add("GOOD", tlsCert.line, "tls_certificate is configured (setting named by line only — its value is never shown in this audit).");
        }
        if (tlsKey) {
          add("GOOD", tlsKey.line, "tls_privatekey is configured (setting named by line only — its value is never shown in this audit).");
        }

        /* ---------- Authenticators ---------- */
        authBlocks.forEach(function (b) {
          var drv = b.settings["driver"];
          if (drv && /^(plaintext|login)$/i.test(drv.value.replace(/\s+/g, "")) && !b.settings["server_advertise_condition"]) {
            add("WARNING", b.line, "Authenticator '" + b.name + "' uses a plaintext-style driver with no server_advertise_condition — posture: it may be offered over unencrypted connections, sending credentials in the clear. NOT SETTLED: this paste cannot prove how the running server advertises it; gate it on an encrypted-session condition.");
          }
          Object.keys(b.settings).forEach(function (sn) {
            if (isSecretName(sn)) {
              add("INFO", b.settings[sn].line, "Secret-bearing setting '" + sn + "' in authenticator '" + b.name + "' is present — flagged by name and line only; its value is never shown.");
            }
          });
        });

        /* ---------- Verification inventory ---------- */
        ["helo_verify_hosts", "helo_try_verify_hosts"].forEach(function (hn) {
          var hs = setting(hn);
          if (hs) add("INFO", hs.line, hn + " is set (inventoried) — HELO verification posture is declared in the config.");
        });

        /* ---------- Structure ---------- */
        Object.keys(mainSettings).forEach(function (name) {
          var arr = mainSettings[name];
          if (arr.length > 1) {
            var lines = arr.map(function (e) { return e.line; });
            add("WARNING", arr[arr.length - 1].line, "Duplicate main setting '" + name + "' appears on lines " + lines.join(" and ") + " — Exim resolves duplicates last-in-file, so line " + arr[arr.length - 1].line + " wins. Remove the earlier one to avoid confusion.");
          }
          if (!KNOWN_MAIN[name]) {
            arr.forEach(function (e) {
              add("INFO", e.line, "Setting '" + name + "' is NOT AUDITED — it is not in this auditor's known Exim option list, so its effect was not graded.");
            });
          }
          if (isSecretName(name) && name !== "tls_privatekey") {
            arr.forEach(function (e) {
              add("INFO", e.line, "Secret-bearing setting '" + name + "' is present — flagged by name and line only; its value is never shown.");
            });
          }
        });
        includes.forEach(function (inc) {
          add("INFO", inc.line, "." + inc.kind + " on this line pulls in another file — NOT CHECKED. Settings and ACLs in that file are invisible to this audit.");
        });
        macros.forEach(function (m) {
          add("INFO", m.line, "Macro '" + m.name + "' defined (inventoried by name only).");
        });

        /* ---------- Logging / privacy ---------- */
        var logSel = setting("log_selector");
        if (logSel) {
          var hits = [];
          ["+sender", "+arguments", "+received_sender", "+delivery_size"].forEach(function (tok) {
            if (logSel.value.indexOf(tok) !== -1) hits.push(tok);
          });
          if (hits.length) {
            add("INFO", logSel.line, "log_selector enables " + hits.join(", ") + " — sender addresses and/or message arguments can land in the logs. Keep log access and retention in mind.");
          }
        }

        var sevRank = { BLOCKER: 0, WARNING: 1, INFO: 2, GOOD: 3 };
        findings.sort(function (a, b) {
          if (sevRank[a.sev] !== sevRank[b.sev]) return sevRank[a.sev] - sevRank[b.sev];
          return (a.line || 0) - (b.line || 0);
        });

        var counts = { BLOCKER: 0, WARNING: 0, INFO: 0, GOOD: 0 };
        findings.forEach(function (f) { counts[f.sev]++; });

        var verdict, verdictClass;
        if (counts.BLOCKER > 0) {
          verdict = "DO NOT DEPLOY" + (openRelay ? " — OPEN RELAY RISK" : "");
          verdictClass = "danger";
        } else if (counts.WARNING > 0) {
          verdict = "DEPLOY WITH FIXES";
          verdictClass = "fixes";
        } else {
          verdict = "SAFE TO DEPLOY";
          verdictClass = "safe";
        }
        return { findings: findings, counts: counts, verdict: verdict, verdictClass: verdictClass, openRelay: openRelay, lineCount: rawLines.length };
      }

      function buildReport(result) {
        var out = [];
        out.push("J-Dawgs Exim Mail Server Config Safety Auditor(TM) - audit report");
        out.push("Verdict: " + result.verdict);
        out.push("Counts: BLOCKER " + result.counts.BLOCKER + " / WARNING " + result.counts.WARNING + " / INFO " + result.counts.INFO + " / GOOD " + result.counts.GOOD);
        out.push("Lines audited: " + result.lineCount);
        out.push("---");
        if (!result.findings.length) out.push("No findings.");
        result.findings.forEach(function (f) {
          out.push("[" + f.sev + "] " + (f.line ? "Line " + f.line : "No line (setting absent)") + " - " + f.msg);
        });
        out.push("---");
        out.push("Generated locally in your browser. Nothing was uploaded, saved, or sent anywhere, and exim was never run.");
        out.push("Secret values are never included in this report - findings name settings by name and line only.");
        return out.join("\n");
      }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-exim-mail-server-config-safety-auditortm',
  name: 'J-Dawgs Exim Mail Server Config Safety Auditor',
  description: 'Grades a pasted Exim configuration offline: open-relay ACL posture, relay_from_hosts scope, never_users privilege, TLS advertising posture, into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
