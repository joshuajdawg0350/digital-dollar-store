'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Beets Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Built-in worked examples ---------- */

      var RISKY_CONFIG = [
        "# Risky example config - do not deploy as-is",
        "library: /beets-library.db",
        "directory: /",
        "plugins: web discogs lastgenre fetchart",
        "",
        "import:",
        "    copy: no",
        "    move: yes",
        "    delete: yes",
        "    threaded: yes",
        "",
        "web:",
        "    host: 0.0.0.0",
        "    port: 8337",
        "    cors: yes",
        "",
        "discogs:",
        "    user_token: DscFakeTokenXq7Lp2Zm9Kv4Rt8Hs3Bn6Wd1Jy5Ce0",
        "",
        "lastfm:",
        "    api_key: fake1fmkey9z8y7x6w5v4u3t2s1r0q",
        "",
        "fetchart:",
        "    sources: filesystem coverart lastfm"
      ].join("\n");

      var HARDENED_CONFIG = [
        "# Hardened example config",
        "library: ~/music/library.db",
        "directory: ~/music/library",
        "plugins: web discogs lastgenre fetchart",
        "",
        "import:",
        "    copy: yes",
        "    move: no",
        "    delete: no",
        "    threaded: no",
        "",
        "web:",
        "    host: 127.0.0.1",
        "    port: 8337",
        "    username: beetadmin",
        "    password: ${BEETS_WEB_PASSWORD}",
        "    cors: no",
        "",
        "discogs:",
        "    user_token: ${DISCOGS_USER_TOKEN}",
        "",
        "fetchart:",
        "    sources: filesystem coverart"
      ].join("\n");

      /* Planted secrets in the risky example, used ONLY by the self-test
         counter. These strings live in this script and in the input box;
         the audit output must never contain them. */
      var PLANTED_SECRETS = [
        { label: "discogs.user_token value", value: "DscFakeTokenXq7Lp2Zm9Kv4Rt8Hs3Bn6Wd1Jy5Ce0" },
        { label: "lastfm.api_key value", value: "fake1fmkey9z8y7x6w5v4u3t2s1r0q" }
      ];

      /* ---------- Tiny YAML reader (keys, values, indentation) ---------- */

      function cleanScalar(v){
        v = String(v).trim();
        if (v.length >= 2) {
          var first = v.charAt(0), last = v.charAt(v.length - 1);
          if ((first === '"' && last === '"') || (first === "'" && last === "'")) {
            return v.slice(1, -1);
          }
        }
        var hashIdx = v.indexOf(" #");
        if (hashIdx >= 0) v = v.slice(0, hashIdx);
        if (v.charAt(0) === "[") v = v.replace(/^\[|\]$/g, "");
        return v.trim();
      }

      function parseConfig(text){
        var entries = [];
        var stack = [];
        var lines = String(text).split(/\r?\n/);
        function currentPath(){ return stack.map(function(s){ return s.key; }); }
        for (var i = 0; i < lines.length; i++) {
          var raw = lines[i];
          var lineNo = i + 1;
          if (/^\s*$/.test(raw) || /^\s*#/.test(raw)) continue;
          var indent = raw.match(/^[ \t]*/)[0].replace(/\t/g, "    ").length;
          while (stack.length && stack[stack.length - 1].indent >= indent) stack.pop();
          var trimmed = raw.trim();
          var listMatch = trimmed.match(/^-\s+(.*)$/);
          if (listMatch) {
            entries.push({ path: currentPath(), key: null, listItem: cleanScalar(listMatch[1]), line: lineNo });
            continue;
          }
          var m = trimmed.match(/^([^:]+):\s*(.*)$/);
          if (!m) {
            entries.push({ path: currentPath(), key: null, unparsed: true, line: lineNo });
            continue;
          }
          var key = m[1].trim();
          var path = currentPath().concat([key]);
          if (m[2] === "") {
            entries.push({ path: path, key: key, value: null, section: true, line: lineNo });
            stack.push({ indent: indent, key: key });
          } else {
            entries.push({ path: path, key: key, value: cleanScalar(m[2]), section: false, line: lineNo });
          }
        }
        return entries;
      }

      function pathStr(e){ return e.path.join("."); }

      function findEntry(entries, dotted){
        for (var i = entries.length - 1; i >= 0; i--) {
          if (!entries[i].section && entries[i].key !== null && pathStr(entries[i]) === dotted) return entries[i];
        }
        return null;
      }
      function findAny(entries, dotted){
        for (var i = entries.length - 1; i >= 0; i--) {
          if (entries[i].key !== null && pathStr(entries[i]) === dotted) return entries[i];
        }
        return null;
      }

      function isTruthy(v){
        return /^(yes|true|on|1)$/i.test(String(v == null ? "" : v).trim());
      }
      function isExplicitlyFalsy(v){
        return /^(no|false|off|0)$/i.test(String(v == null ? "" : v).trim());
      }
      function isEnvRef(v){
        v = String(v == null ? "" : v);
        return v.indexOf("${") !== -1 || /^\$[A-Za-z_{]/.test(v) || /^env:/i.test(v);
      }
      function isNonLocalHost(h){
        h = String(h == null ? "" : h).trim().toLowerCase();
        return h === "0.0.0.0" || h === "::" || h === "[::]" || h === "*" || h === "";
      }
      function isLocalHost(h){
        h = String(h == null ? "" : h).trim().toLowerCase();
        return h === "localhost" || h === "::1" || h === "[::1]" || h.indexOf("127.") === 0;
      }
      function isRootOrHomePath(p){
        p = String(p == null ? "" : p).trim();
        if (p === "/" || p === "~" || p === "~/" || p === "/root") return true;
        if (/^[A-Za-z]:\\?$/.test(p)) return true;
        if (/^\/home\/[^\/]+\/?$/.test(p)) return true;
        if (/^\/Users\/[^\/]+\/?$/.test(p)) return true;
        if (/^\/home\/?$/.test(p)) return true;
        return false;
      }
      function parentIsRoot(p){
        p = String(p == null ? "" : p).trim();
        return /^\/[^\/]+$/.test(p);
      }

      /* ---------- The audit ---------- */

      function audit(text){
        var findings = [];
        function add(severity, line, key, message, fix){
          findings.push({ severity: severity, line: line, key: key, message: message, fix: fix });
        }

        var entries = parseConfig(text);
        var valueEntries = entries.filter(function(e){ return !e.section && e.key !== null; });

        if (valueEntries.length === 0) {
          add("warning", null, "(config)",
            "No settings could be read from the pasted text. It may be empty, or not in config.yaml shape.",
            "Paste the full contents of your Beets config.yaml, keeping the original indentation.");
        }

        /* Plugins list */
        var plugins = [];
        var pluginsEntry = findEntry(entries, "plugins");
        if (pluginsEntry && pluginsEntry.value) {
          plugins = pluginsEntry.value.toLowerCase().split(/[\s,]+/).filter(Boolean);
        }
        entries.forEach(function(e){
          if (e.listItem != null && pathStr(e) === "plugins") plugins.push(e.listItem.toLowerCase());
        });
        var webEnabled = plugins.indexOf("web") !== -1;
        var webSection = findAny(entries, "web");

        /* Web bind + auth */
        var hostEntry = findEntry(entries, "web.host");
        var hostVal = hostEntry ? hostEntry.value : "127.0.0.1";
        var hostKnown = !!hostEntry;
        var nonLocal = hostKnown ? (isNonLocalHost(hostVal) && !isLocalHost(hostVal)) : false;

        var userEntry = findEntry(entries, "web.username");
        var passEntry = findEntry(entries, "web.password");
        var userSet = !!(userEntry && userEntry.value !== "");
        var passSet = !!(passEntry && passEntry.value !== "");
        var authSet = userSet && passSet;

        var openBindFired = false;
        if (webEnabled && nonLocal && !authSet) {
          openBindFired = true;
          add("critical", hostEntry.line, "web.host",
            "The web plugin is enabled and bound to " + hostVal + ", which listens on every network interface, and no working username/password login is set. Anyone who can reach this machine on the network can browse, play, and modify your library through the web interface.",
            "Bind the web plugin to 127.0.0.1 unless you truly need remote access, and set both web.username and web.password. If you do need remote access, put Beets behind a VPN or an authenticated reverse proxy instead.");
        }

        if (webEnabled && (userSet !== passSet)) {
          add("warning", (userSet ? userEntry : passEntry).line, userSet ? "web.username" : "web.password",
            "Only one half of the web login is set. Beets web authentication needs both a username and a password; with just one, the login does not protect the interface the way you expect.",
            "Set both web.username and web.password, or remove both and bind the web plugin to 127.0.0.1 only.");
        }

        /* (g) web plugin without any auth (when the open-bind critical did not already fire) */
        if (webEnabled && !authSet && !openBindFired) {
          add("warning", pluginsEntry ? pluginsEntry.line : (webSection ? webSection.line : null), "plugins",
            "The plugins list enables the web plugin, but no username/password authentication is set in the web section. The interface is only as safe as its bind address — if the host is ever changed away from localhost, it is wide open.",
            "Set web.username and web.password, or remove web from the plugins list when you are not using the web interface.");
        }

        if (!webEnabled && webSection) {
          add("info", webSection.line, "web",
            "A web section is present, but web is not in the plugins list, so these settings currently do nothing.",
            "Add web to the plugins list to use the web interface, or remove the web section to keep the config tidy.");
        }

        /* (b) CORS */
        var corsEntry = findEntry(entries, "web.cors");
        if (corsEntry && webEnabled) {
          var corsBroad = isTruthy(corsEntry.value) || String(corsEntry.value).trim() === "*";
          if (corsBroad && nonLocal) {
            add("critical", corsEntry.line, "web.cors",
              "CORS is fully enabled on the web plugin while it is bound to a non-localhost address. Any website a user visits can make requests to your Beets server from their browser and read the responses.",
              "Set web.cors to no, or restrict it to the specific origin you use. Never combine broad CORS with a network-facing bind.");
          } else if (corsBroad) {
            add("warning", corsEntry.line, "web.cors",
              "CORS is fully enabled on the web plugin. The bind looks local right now, but broad CORS becomes dangerous the moment the bind changes.",
              "Set web.cors to no unless a specific cross-origin client needs it, and if so, name that origin instead of opening it to everyone.");
          }
        }

        /* (c) plaintext secrets — value NEVER rendered, length only */
        var secretNamePattern = /(token|secret|api_key|apikey|password)/i;
        valueEntries.forEach(function(e){
          if (!e.key || !secretNamePattern.test(e.key)) return;
          if (e.value === "" || e.value == null) return;
          var dotted = pathStr(e);
          var len = String(e.value).length;
          if (isEnvRef(e.value)) {
            add("info", e.line, dotted,
              "This secret is referenced from the environment rather than stored as a plain value (reported by length only: " + len + " characters). That is the right pattern — just make sure the variable is set wherever Beets runs.",
              "No change needed if the environment variable is set in the service or shell that launches Beets.");
          } else {
            add("critical", e.line, dotted,
              "A secret is stored in plaintext in the config (reported by length only: " + len + " characters; the value is never shown here). Anyone who can read this file — a backup, a screenshot, a shared dotfiles repo — gets the key.",
              "Move this value out of config.yaml into an environment variable or a secrets file with tight permissions, reference it from there, and rotate the key since it has been sitting in plaintext.");
          }
        });

        /* (d) destructive import settings */
        var deleteEntry = findEntry(entries, "import.delete");
        if (deleteEntry && isTruthy(deleteEntry.value)) {
          add("critical", deleteEntry.line, "import.delete",
            "import delete is on: after a successful import, Beets deletes the original source files. If the import lands in the wrong place or tags are wrong, your only other copy is gone.",
            "Set import.delete to no. Delete source files yourself, later, once you have verified the import and have a backup.");
        }
        var moveEntry = findEntry(entries, "import.move");
        var copyEntry = findEntry(entries, "import.copy");
        if (moveEntry && isTruthy(moveEntry.value)) {
          add("warning", moveEntry.line, "import.move",
            "import move is on: imported files are moved out of their original location into the library, leaving nothing behind at the source. Combined with copy: no, the original folder layout is gone after import.",
            "Leave move off (and copy on) until you are sure about your library layout, or make a backup of the source folder before a move import.");
        } else if (copyEntry && isExplicitlyFalsy(copyEntry.value) && !(deleteEntry && isTruthy(deleteEntry.value))) {
          add("warning", copyEntry.line, "import.copy",
            "import copy is off and move is off: Beets will tag and rename files in place where they sit. There is no separate untouched source copy if something goes wrong.",
            "Turn copy back on for imports from folders you care about, so the originals stay untouched until you clean up by hand.");
        }

        /* (f) threaded + autotag */
        var threadedEntry = findEntry(entries, "import.threaded");
        if (threadedEntry && isTruthy(threadedEntry.value)) {
          var autotagEntry = findEntry(entries, "import.autotag");
          var matchSection = findAny(entries, "match");
          var autotagOff = autotagEntry && isExplicitlyFalsy(autotagEntry.value);
          if (!autotagOff) {
            add("warning", threadedEntry.line, "import.threaded",
              "Threaded imports are on while autotagging is active" + (matchSection ? " (a match section is present, so match-strength choices apply)" : "") + ". Parallel autotagging makes large imports fast, but it also makes wrong matches land faster and logs harder to follow.",
              "Review item: for a first big import, run a small batch with threaded off and check the matches. Turn threading back on once you trust the results.");
          }
        }

        /* (e) + (h) paths */
        var dirEntry = findEntry(entries, "directory");
        var libEntry = findEntry(entries, "library");

        if (!dirEntry) {
          add("warning", null, "directory",
            "No directory setting was found. Beets will fall back to its default music directory, which may not be where you think your library lives.",
            "Add a directory setting that points at the folder that holds (or will hold) your music library.");
        } else if (dirEntry.value !== "" && isRootOrHomePath(dirEntry.value)) {
          if (webEnabled) {
            add("critical", dirEntry.line, "directory",
              "The music directory is set to the filesystem root or a home root — an extremely broad path — and the web plugin is enabled, so the web interface is rooted at that whole tree.",
              "Point directory at a dedicated music folder (for example ~/music/library) and nothing broader.");
          } else {
            add("warning", dirEntry.line, "directory",
              "The music directory is set to the filesystem root or a home root. Imports, moves, and path-based operations will treat that whole tree as the library.",
              "Point directory at a dedicated music folder (for example ~/music/library) and nothing broader.");
          }
        }

        if (!libEntry) {
          add("warning", null, "library",
            "No library setting was found. Beets will use its default database location, which makes backups and moves easy to get wrong.",
            "Add a library setting that points at your database file, in a folder you back up.");
        } else if (libEntry.value !== "" && parentIsRoot(libEntry.value)) {
          add("warning", libEntry.line, "library",
            "The library database file sits directly at the filesystem root. Root-level files are easy to miss in backups and often have awkward permissions.",
            "Move the database into your Beets folder (for example ~/music/library.db) and update the library setting to match.");
        }

        if (!pluginsEntry && plugins.length === 0) {
          add("info", null, "plugins",
            "No plugins list was found, so plugin-specific checks (web, discogs, fetchart) were skipped.",
            "If you use plugins, list them under a plugins setting so the config says what is actually running.");
        }

        /* Sort: critical, warning, info; then by line */
        var rank = { critical: 0, warning: 1, info: 2 };
        findings.sort(function(a, b){
          if (rank[a.severity] !== rank[b.severity]) return rank[a.severity] - rank[b.severity];
          var la = a.line == null ? 99999 : a.line, lb = b.line == null ? 99999 : b.line;
          return la - lb;
        });

        var counts = { critical: 0, warning: 0, info: 0 };
        findings.forEach(function(f){ counts[f.severity]++; });

        var verdict = counts.critical > 0 ? "DO NOT RUN" : (counts.warning > 0 ? "RUN WITH FIXES" : "SAFE TO RUN");
        return { findings: findings, counts: counts, verdict: verdict };
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-beets-server-config-safety-auditortm',
  name: 'J-Dawgs Beets Server Config Safety Auditor',
  description: 'Grades a pasted Beets config.yaml offline into one deploy verdict: web plugin bound to all interfaces with no auth, plaintext plugin API keys, and import delete settings caught before anything runs; secrets reported by key name, line, and length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
