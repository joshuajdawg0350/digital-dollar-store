'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Pulsar Broker Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------------- Worked examples ---------------- */
      var RISKY_LINES = [
        "# Risky training example - a broker config with planted problems",
        "clusterName=payments-cluster",
        "zookeeperServers=zk1.internal:2181,zk2.internal:2181",
        "metadataStoreUrl=zk:zk1.internal:2181",
        "brokerServicePort=6650",
        "webServicePort=8080",
        "bindAddress=0.0.0.0",
        "advertisedListeners=pulsar://broker1.example.net:6650",
        "authenticationEnabled=false",
        "authorizationEnabled=false",
        "superUserRoles=",
        "anonymousUserRole=anonymous",
        "tokenSecretKey=abc123short",
        "tlsEnabled=false",
        "webServiceTlsEnabled=false",
        "allowAutoTopicCreation=true",
        "allowAutoTopicCreationType=partitioned",
        "defaultNumPartitions=64",
        "managedLedgerDefaultEnsembleSize=2",
        "managedLedgerDefaultWriteQuorum=2",
        "managedLedgerDefaultAckQuorum=1",
        "metadataStorePassword=plainTextPassw0rd!",
        "this line is not a setting at all",
        "# journalSyncData=false",
        "clusterName=payments-cluster-duplicate"
      ];

      var HARDENED_LINES = [
        "# Hardened training example - a broker config with the safeguards on",
        "clusterName=payments-cluster",
        "zookeeperServers=zk1.internal:2181,zk2.internal:2181",
        "metadataStoreUrl=zk:zk1.internal:2181",
        "brokerServicePort=6650",
        "brokerServicePortTls=6651",
        "webServicePort=8080",
        "webServicePortTls=8443",
        "bindAddress=10.0.4.21",
        "advertisedListeners=pulsar+ssl://broker1.example.net:6651",
        "authenticationEnabled=true",
        "authenticationProviders=org.apache.pulsar.broker.authentication.AuthenticationProviderToken",
        "authorizationEnabled=true",
        "superUserRoles=admin,ops-lead",
        "anonymousUserRole=",
        "tokenSecretKey=file:///etc/pulsar/keys/token-secret.key",
        "tlsEnabled=true",
        "webServiceTlsEnabled=true",
        "tlsCertificateFilePath=/etc/pulsar/certs/broker.cert.pem",
        "tlsKeyFilePath=/etc/pulsar/certs/broker.key-pk8.pem",
        "tlsTrustCertsFilePath=/etc/pulsar/certs/ca.cert.pem",
        "tlsAllowInsecureConnection=false",
        "tlsRequireTrustedClientCertOnConnect=true",
        "allowAutoTopicCreation=false",
        "managedLedgerDefaultEnsembleSize=3",
        "managedLedgerDefaultWriteQuorum=3",
        "managedLedgerDefaultAckQuorum=2",
        "journalSyncData=true",
        "metadataStorePassword=file:///etc/pulsar/secrets/metadata-store-password"
      ];

      /* ---------------- Recognizable Pulsar keys ---------------- */
      var KNOWN_KEYS = {};
      [
        "clusterName","zookeeperServers","configurationStoreServers","metadataStoreUrl",
        "brokerServicePort","brokerServicePortTls","webServicePort","webServicePortTls",
        "advertisedAddress","advertisedListeners","bindAddress","listeners",
        "authenticationEnabled","authenticationProviders","authorizationEnabled","authorizationProvider",
        "superUserRoles","anonymousUserRole","proxyRoles","originalPrincipal",
        "tokenPublicKey","tokenSecretKey","tokenPrivateKey","tokenAuthClaim","tokenAudience",
        "authenticationRefreshCheckSeconds","brokerClientAuthenticationPlugin","brokerClientAuthenticationParameters",
        "brokerClientTlsEnabled","tlsEnabled","webServiceTlsEnabled","tlsCertificateFilePath","tlsKeyFilePath",
        "tlsTrustCertsFilePath","tlsAllowInsecureConnection","tlsRequireTrustedClientCertOnConnect",
        "tlsProtocols","tlsCiphers","allowAutoTopicCreation","allowAutoTopicCreationType",
        "allowAutoSubscriptionCreation","brokerDeleteInactiveTopicsEnabled","defaultNumPartitions",
        "maxNumPartitionsPerPartitionedTopic","managedLedgerDefaultEnsembleSize","managedLedgerDefaultWriteQuorum",
        "managedLedgerDefaultAckQuorum","managedLedgerMaxEntriesPerLedger","managedLedgerMinLedgerRolloverTimeMinutes",
        "managedLedgerMaxLedgerRolloverTimeMinutes","managedLedgerCursorMaxEntriesPerLedger","managedLedgerDigestType",
        "managedLedgerPassword","journalDirectory","journalSyncData","journalWriteData","ledgerDirectories",
        "autoRecoveryDaemonEnabled","lostBookieRecoveryEnabled","bookkeeperClientAuthenticationPlugin",
        "bookkeeperClientAuthenticationParameters","zkSessionTimeoutMillis","loadBalancerEnabled",
        "functionsWorkerEnabled","brokerId","webServicePortTlsEnabled","numListenerThreads",
        "maxConcurrentLookupRequest","maxConcurrentInboundConnections","replicationClusters",
        "brokerDeduplicationEnabled","subscriptionRedeliveryTrackerEnabled","delayedDeliveryEnabled",
        "systemTopicEnabled","topicLevelPoliciesEnabled","schemaRegistryStorageClassName"
      ].forEach(function (k) { KNOWN_KEYS[k] = true; });

      function isRecognized(key) {
        if (KNOWN_KEYS[key]) return true;
        if (/password/i.test(key)) return true;
        if (/(secret|privatekey|private_key)/i.test(key) && !/public/i.test(key)) return true;
        return false;
      }

      /* ---------------- Parsing ---------------- */
      var KEYVAL_RE = /^([A-Za-z0-9_.\-]+)\s*=\s*(.*)$/;

      function parseConfig(text) {
        var rawLines = text.split(/\r?\n/);
        var entries = [], commented = [], notParsed = [];
        rawLines.forEach(function (raw, i) {
          var lineNo = i + 1;
          var t = raw.replace(/^\s+|\s+$/g, "");
          if (!t) return;
          if (t.charAt(0) === "#") {
            var body = t.replace(/^#+\s*/, "");
            var cm = body.match(KEYVAL_RE);
            if (cm) commented.push({ line: lineNo, key: cm[1] });
            return;
          }
          var m = t.match(KEYVAL_RE);
          if (!m) { notParsed.push({ line: lineNo }); return; }
          entries.push({ line: lineNo, key: m[1], value: m[2].replace(/\s+$/g, "") });
        });
        return { entries: entries, commented: commented, notParsed: notParsed, totalLines: rawLines.length };
      }

      /* ---------------- Audit ---------------- */
      function audit(text) {
        var parsed = parseConfig(text);
        var entries = parsed.entries;
        var findings = [];

        function add(severity, line, key, status, message) {
          findings.push({ severity: severity, line: line, key: key, status: status, message: message });
        }
        function lastEntry(key) {
          var found = null;
          entries.forEach(function (e) { if (e.key === key) found = e; });
          return found;
        }
        function isFalse(e) { return e && e.value.toLowerCase() === "false"; }
        function isTrue(e) { return e && e.value.toLowerCase() === "true"; }
        function isRef(value) {
          return /^file:\/\//i.test(value) || /^env:/i.test(value) || /^\$\{/.test(value) || /^data:env/i.test(value);
        }

        var recognizedCount = 0;
        var seenKeys = {};
        entries.forEach(function (e) {
          if (isRecognized(e.key)) recognizedCount++;
          if (!seenKeys[e.key]) seenKeys[e.key] = [];
          seenKeys[e.key].push(e);
        });

        /* Exposure: broker reachable on all interfaces */
        var bindEntry = lastEntry("bindAddress");
        var advEntry = lastEntry("advertisedListeners");
        var exposed = false;
        if (bindEntry && (bindEntry.value === "0.0.0.0" || bindEntry.value === "::")) exposed = true;
        if (advEntry && advEntry.value.indexOf("0.0.0.0") !== -1) exposed = true;

        if (bindEntry && (bindEntry.value === "0.0.0.0" || bindEntry.value === "::")) {
          add("WARNING", bindEntry.line, "bindAddress", "ACTIVE",
            "The broker binds to all network interfaces (0.0.0.0). Anything that weakens authentication or TLS below is reachable from every network this host touches, not just localhost.");
        }
        if (advEntry && advEntry.value.indexOf("0.0.0.0") !== -1) {
          add("WARNING", advEntry.line, "advertisedListeners", "ACTIVE",
            "advertisedListeners includes 0.0.0.0, advertising the broker on every interface to clients and peers.");
        }

        /* Authentication / authorization */
        var auth = lastEntry("authenticationEnabled");
        var authz = lastEntry("authorizationEnabled");
        if (isFalse(auth)) {
          if (isFalse(authz) || exposed) {
            add("BLOCKER", auth.line, "authenticationEnabled", "ACTIVE",
              "Authentication is switched off" + (isFalse(authz) ? " and authorization is also off" : " on an all-interfaces bind") +
              " - any client that can reach this broker can produce, consume, and administer without proving who it is. Do not deploy.");
          } else {
            add("HIGH", auth.line, "authenticationEnabled", "ACTIVE",
              "Authentication is switched off. Clients connect without proving identity; turn authentication on and name at least one provider before this broker serves real traffic.");
          }
        }
        if (isTrue(auth)) {
          var providers = lastEntry("authenticationProviders");
          if (providers && providers.value === "") {
            add("WARNING", providers.line, "authenticationProviders", "ACTIVE",
              "authenticationEnabled is true but authenticationProviders is empty - no provider is named to actually check credentials.");
          }
        }
        if (isFalse(authz)) {
          add("HIGH", authz.line, "authorizationEnabled", "ACTIVE",
            "Authorization is switched off. Any authenticated (or, with authentication off, any) identity can act on any tenant, namespace, and topic - there is no permission boundary inside the broker.");
        }

        /* Superuser roles */
        var superRoles = lastEntry("superUserRoles");
        var anon = lastEntry("anonymousUserRole");
        if (superRoles && superRoles.value === "") {
          add("HIGH", superRoles.line, "superUserRoles", "ACTIVE",
            "superUserRoles is set but empty. No role holds superuser rights, so tenant and namespace administration has no legitimate owner - and operators tend to 'fix' that later by widening access in a hurry.");
        }
        if (isTrue(auth) && !superRoles) {
          add("WARNING", auth.line, "superUserRoles", "NOT SET",
            "Authentication is on but superUserRoles does not appear in the paste - confirm a superuser role is defined in the full config, or no one can administer tenants and namespaces.");
        }
        if (superRoles && superRoles.value !== "") {
          var roles = superRoles.value.split(",").map(function (s) { return s.replace(/^\s+|\s+$/g, ""); });
          var anonIsSuper = roles.indexOf("anonymous") !== -1 || (anon && anon.value !== "" && roles.indexOf(anon.value) !== -1);
          if (anonIsSuper) {
            add("BLOCKER", superRoles.line, "superUserRoles", "ACTIVE",
              "The anonymous role is listed in superUserRoles. Unauthenticated clients would hold full administrative rights over the whole cluster. Do not deploy.");
          }
        }
        if (anon && anon.value !== "" && isFalse(authz)) {
          add("HIGH", anon.line, "anonymousUserRole", "ACTIVE",
            "An anonymous role is named while authorization is off, so unauthenticated clients effectively act without restriction - the anonymous role can do anything a superuser can reach. Turn authorization on or drop the anonymous role.");
        }

        /* Inline secrets and passwords - value is NEVER printed, length only */
        entries.forEach(function (e) {
          var isSecretKey = /(secret|privatekey|private_key|signingkey)/i.test(e.key) && !/public/i.test(e.key);
          var isPasswordKey = /password/i.test(e.key);
          if (!isSecretKey && !isPasswordKey) return;
          if (e.value === "") return;
          if (isRef(e.value)) {
            add("INFO", e.line, e.key, "ACTIVE",
              "\"" + e.key + "\" is supplied by reference (" + (/^file:/i.test(e.value) ? "file://" : "environment") +
              ") instead of an inline value - the safer pattern. The referenced value was not read and is never shown here.");
            return;
          }
          var looksExample = /example|change[-_ ]?me|placeholder|your[-_]|xxx|dummy/i.test(e.value);
          if (isSecretKey) {
            add("HIGH", e.line, e.key, "ACTIVE",
              "Inline plaintext secret in \"" + e.key + "\" (value length " + e.value.length + " characters" +
              (e.value.length < 32 ? " - short for a signing secret" : "") + (looksExample ? " - looks like a placeholder/example value" : "") +
              "). Anyone who can read this config file holds the token-signing secret. Move it to a file:// or environment reference. The value itself is never shown in this audit.");
          } else {
            add("HIGH", e.line, e.key, "ACTIVE",
              "Inline plaintext password in \"" + e.key + "\" (value length " + e.value.length + " characters" +
              (looksExample ? " - looks like a placeholder/example value" : "") +
              "). Anyone who can read this config file holds this credential. Move it to a file:// or environment reference. The value itself is never shown in this audit.");
          }
        });

        /* TLS */
        var tls = lastEntry("tlsEnabled");
        if (isFalse(tls)) {
          if (exposed) {
            add("BLOCKER", tls.line, "tlsEnabled", "ACTIVE",
              "Broker TLS is switched off while the broker binds to all interfaces - credentials and message traffic cross the network in cleartext where anything on the path can read them. Do not deploy.");
          } else {
            add("HIGH", tls.line, "tlsEnabled", "ACTIVE",
              "Broker TLS is switched off. Credentials and message traffic cross the network in cleartext; enable TLS on the broker service before real traffic.");
          }
        }
        var webTls = lastEntry("webServiceTlsEnabled");
        if (isFalse(webTls)) {
          add(exposed ? "HIGH" : "WARNING", webTls.line, "webServiceTlsEnabled", "ACTIVE",
            "Web service (admin REST API) TLS is switched off" + (exposed ? " on an all-interfaces bind" : "") +
            " - admin credentials and management calls cross the network in cleartext. Enable TLS on the web service.");
        }
        var insecure = lastEntry("tlsAllowInsecureConnection");
        if (isTrue(insecure)) {
          add("WARNING", insecure.line, "tlsAllowInsecureConnection", "ACTIVE",
            "tlsAllowInsecureConnection is true - the broker client side accepts certificates it cannot verify, which quietly removes the protection TLS is supposed to give.");
        }

        /* Auto topic creation */
        var autoTopic = lastEntry("allowAutoTopicCreation");
        if (isTrue(autoTopic)) {
          var typeEntry = lastEntry("allowAutoTopicCreationType");
          var partsEntry = lastEntry("defaultNumPartitions");
          var extra = "";
          if (typeEntry && typeEntry.value.toLowerCase() === "partitioned") {
            extra = " New topics are created as partitioned topics" + (partsEntry ? ", defaulting to " + partsEntry.value + " partitions each" : "") + ", so one stray producer can allocate broker and bookie resources at scale.";
          }
          add("WARNING", autoTopic.line, "allowAutoTopicCreation", "ACTIVE",
            "Auto topic creation is on with no restriction in the paste - any client that can produce or subscribe can create topics just by naming them." + extra + " Turn it off, or restrict who may create topics.");
        }

        /* BookKeeper / managed-ledger durability */
        var journalSync = lastEntry("journalSyncData");
        if (isFalse(journalSync)) {
          add("WARNING", journalSync.line, "journalSyncData", "ACTIVE",
            "journalSyncData is false - bookies acknowledge writes before the journal is synced to disk, so a power loss or crash can lose entries the broker already confirmed. This trades durability for speed.");
        }
        function intVal(e) { var n = parseInt(e && e.value, 10); return isNaN(n) ? null : n; }
        var ensemble = lastEntry("managedLedgerDefaultEnsembleSize");
        var writeQ = lastEntry("managedLedgerDefaultWriteQuorum");
        var ackQ = lastEntry("managedLedgerDefaultAckQuorum");
        var wq = intVal(writeQ), aq = intVal(ackQ), es = intVal(ensemble);
        if (ackQ && aq !== null && wq !== null && aq === 1 && wq > 1) {
          add("WARNING", ackQ.line, "managedLedgerDefaultAckQuorum", "ACTIVE",
            "Ack quorum is 1 while the write quorum is " + wq + " - a write is treated as durable after a single bookie confirms it, so one bookie failure can lose acknowledged data. Raise the ack quorum.");
        }
        if (ackQ && aq !== null && wq !== null && aq > wq) {
          add("WARNING", ackQ.line, "managedLedgerDefaultAckQuorum", "ACTIVE",
            "Ack quorum (" + aq + ") is larger than the write quorum (" + wq + "), which a ledger cannot satisfy - writes will fail or stall. Fix the quorum numbers.");
        }
        if (writeQ && wq === 1) {
          add("WARNING", writeQ.line, "managedLedgerDefaultWriteQuorum", "ACTIVE",
            "Write quorum is 1 - each entry is written to a single bookie. One disk or host failure loses the only copy. Raise the write quorum for anything you cannot afford to lose.");
        } else if (ensemble && es === 1 && !writeQ) {
          add("WARNING", ensemble.line, "managedLedgerDefaultEnsembleSize", "ACTIVE",
            "Ensemble size is 1 - ledgers live on a single bookie with no second copy to recover from.");
        }

        /* Duplicate keys - last value wins */
        Object.keys(seenKeys).forEach(function (key) {
          var list = seenKeys[key];
          if (list.length > 1) {
            var lines = list.map(function (e) { return e.line; }).join(" and ");
            add("WARNING", list[list.length - 1].line, key, "ACTIVE",
              "Key \"" + key + "\" is set " + list.length + " times (lines " + lines + "). With properties files the last value wins, so line " +
              list[list.length - 1].line + " is the one a broker would actually use - the earlier line is dead text that invites mistakes.");
          }
        });

        /* Commented-out settings - reported, never graded as set */
        parsed.commented.forEach(function (c) {
          add("INFO", c.line, c.key, "COMMENTED / NOT ACTIVE",
            "\"" + c.key + "\" appears only as a commented-out line. It is not active and was not graded as set. If it is ever uncommented, re-run this audit before deploying.");
        });

        /* Unparseable lines */
        parsed.notParsed.forEach(function (n) {
          add("INFO", n.line, null, "NOT PARSED",
            "This line could not be parsed as a key=value setting and was skipped. Check it for a typo - a broker may ignore it too, silently.");
        });

        findings.sort(function (a, b) { return a.line - b.line; });

        var counts = { BLOCKER: 0, HIGH: 0, WARNING: 0, INFO: 0 };
        findings.forEach(function (f) { counts[f.severity]++; });

        var verdict;
        if (recognizedCount === 0) verdict = "NOT ENOUGH TO GRADE";
        else if (counts.BLOCKER > 0) verdict = "DO NOT DEPLOY";
        else if (counts.HIGH > 0 || counts.WARNING > 0) verdict = "DEPLOY WITH FIXES";
        else verdict = "SAFE TO DEPLOY";

        return {
          verdict: verdict,
          counts: counts,
          findings: findings,
          recognizedCount: recognizedCount,
          activeSettings: entries.length,
          totalLines: parsed.totalLines
        };
      }

      /* ---------------- Rendering ---------------- */
      function esc(s) {
        return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
      }

      var SEV_LABEL = { BLOCKER: "BLOCKER", HIGH: "HIGH", WARNING: "WARNING", INFO: "INFO" };
      var SEV_CLASS = { BLOCKER: "blocker", HIGH: "high", WARNING: "warning", INFO: "info" };

      function buildReport(r) {
        var out = [];
        out.push("J-Dawgs Pulsar Broker Config Safety Auditor - text report");
        out.push("Verdict: " + r.verdict);
        out.push("Lines pasted: " + r.totalLines + " | Active settings parsed: " + r.activeSettings +
                 " | Recognized Pulsar keys (active): " + r.recognizedCount);
        out.push("Findings: " + r.counts.BLOCKER + " BLOCKER, " + r.counts.HIGH + " HIGH, " +
                 r.counts.WARNING + " WARNING, " + r.counts.INFO + " INFO");
        out.push("");
        if (r.verdict === "NOT ENOUGH TO GRADE") {
          out.push("No recognizable Pulsar broker keys were found in the paste, so no verdict can be graded.");
          out.push("Paste a broker.conf / standalone.conf style configuration (key=value lines) and run the audit again.");
        } else if (r.findings.length === 0) {
          out.push("No findings. Nothing in the pasted settings tripped a check.");
        } else {
          r.findings.forEach(function (f) {
            out.push("[" + f.severity + "] Line " + f.line + " | " + (f.key ? f.key : "(no key)") +
                     " | " + f.status + " - " + f.message);
          });
        }
        out.push("");
        out.push("Notes: heuristic text audit of the paste only - not a Pulsar binary, starts no broker, connects to nothing.");
        out.push("Secrets and passwords are reported by key name, line, and value length only; values never appear in this report.");
        out.push("Commented-out settings are COMMENTED / NOT ACTIVE and were not graded as set. Unparseable lines are NOT PARSED.");
        return out.join("\n");
      }

      function buildJson(r) {
        var obj = {
          tool: "J-Dawgs Pulsar Broker Config Safety Auditor",
          verdict: r.verdict,
          summary: {
            linesPasted: r.totalLines,
            activeSettingsParsed: r.activeSettings,
            recognizedPulsarKeysActive: r.recognizedCount,
            counts: { BLOCKER: r.counts.BLOCKER, HIGH: r.counts.HIGH, WARNING: r.counts.WARNING, INFO: r.counts.INFO }
          },
          findings: r.findings.map(function (f) {
            return { severity: f.severity, line: f.line, key: f.key, status: f.status, message: f.message };
          }),
          notes: "Heuristic text audit of the pasted config only. Secret and password values are never included - key name, line, and value length only."
        };
        return JSON.stringify(obj, null, 2);
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-pulsar-broker-config-safety-auditor',
  name: 'J-Dawgs Pulsar Broker Config Safety Auditor',
  description: 'Grades a pasted Apache Pulsar broker.conf fully offline into one deploy verdict — authentication and authorization posture, TLS and listener exposure, and plaintext credentials shown by key name, line, and length only — and commented-out settings are never graded as active. Pulsar only exercises a c',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
