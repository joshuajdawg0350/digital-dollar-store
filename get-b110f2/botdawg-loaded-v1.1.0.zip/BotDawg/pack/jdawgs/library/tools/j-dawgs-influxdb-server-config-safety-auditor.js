'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs InfluxDB Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

  "use strict";

  var RISKY_EXAMPLE = [
    "# Risky InfluxDB config — a worked example. Do not deploy this.",
    "reporting-disabled = false",
    "",
    "[meta]",
    '  dir = "/var/lib/influxdb/meta"',
    "",
    "[data]",
    '  dir = "/var/lib/influxdb/data"',
    '  wal-dir = "/var/lib/influxdb/wal"',
    "  max-series-per-database = 0",
    "",
    "[http]",
    "  enabled = true",
    '  bind-address = "0.0.0.0:8086"',
    "  auth-enabled = false",
    "  pprof-enabled = true",
    "  https-enabled = false",
    '  shared-secret = "EXAMPLE-SECRET-VALUE-9f27-do-not-print"',
    "",
    "[admin]",
    "  enabled = true",
    '  bind-address = "0.0.0.0:8083"',
    "  https-enabled = false"
  ].join("\n");

  var CLEAN_EXAMPLE = [
    "# Clean InfluxDB config — loopback bind, auth on, TLS complete.",
    "reporting-disabled = false",
    "",
    "[meta]",
    '  dir = "/var/lib/influxdb/meta"',
    "  logging-enabled = true",
    "",
    "[data]",
    '  dir = "/var/lib/influxdb/data"',
    '  wal-dir = "/var/lib/influxdb/wal"',
    "  cache-max-memory-size = 1073741824",
    "  max-series-per-database = 1000000",
    "",
    "[http]",
    "  enabled = true",
    '  bind-address = "127.0.0.1:8086"',
    "  auth-enabled = true",
    "  log-enabled = true",
    "  pprof-enabled = false",
    "  https-enabled = true",
    '  https-certificate = "/etc/ssl/influxdb.crt"',
    '  https-private-key = "/etc/ssl/influxdb.key"',
    "",
    "[admin]",
    "  enabled = false",
    '  bind-address = "127.0.0.1:8083"'
  ].join("\n");

  var KNOWN_SECTIONS = {
    "": true, "meta": true, "data": true, "http": true, "admin": true,
    "tls": true, "logging": true, "coordinator": true, "retention": true,
    "continuous_queries": true, "monitor": true, "subscriber": true
  };
  var KNOWN_KEYS = {
    "": ["reporting-disabled"],
    "meta": ["dir","retention-autocreate","logging-enabled","lease-duration"],
    "data": ["dir","wal-dir","index-version","trace-logging-enabled","query-log-enabled","cache-max-memory-size","cache-snapshot-memory-size","cache-snapshot-write-cold-duration","compact-full-write-cold-duration","compact-throughput","max-series-per-database","max-values-per-tag","series-id-set-cache-size","wal-fsync-delay","validate-keys"],
    "http": ["enabled","bind-address","auth-enabled","log-enabled","suppress-write-log","write-tracing","pprof-enabled","debug-enabled","https-enabled","https-certificate","https-private-key","tls-cert-file","tls-key-file","max-row-limit","max-connection-limit","shared-secret","realm","max-body-size","max-concurrent-write-limit","max-enqueue-timeout","flux-enabled","flux-log-enabled","unix-socket-enabled","bind-socket"],
    "admin": ["enabled","bind-address","https-enabled","https-certificate","https-private-key","tls-cert-file","tls-key-file"],
    "tls": ["ciphers","min-version","max-version"],
    "logging": ["format","level","suppress-logo"],
    "coordinator": ["write-timeout","max-concurrent-queries","query-timeout","log-queries-after","max-select-point","max-select-series","max-select-buckets"],
    "retention": ["enabled","check-interval"],
    "continuous_queries": ["enabled","log-enabled","run-interval"],
    "monitor": ["store-enabled","store-database","store-interval"],
    "subscriber": ["enabled","http-timeout","insecure-skip-verify","concurrency"]
  };

  function isSecretKey(key){
    var k = key.toLowerCase();
    return k.indexOf("token") !== -1 || k.indexOf("password") !== -1 || k.indexOf("secret") !== -1;
  }
  function stripQuotes(v){
    v = v.replace(/\s+#.*$/, "").trim();
    if ((v.charAt(0) === '"' && v.charAt(v.length-1) === '"') ||
        (v.charAt(0) === "'" && v.charAt(v.length-1) === "'")){
      return v.slice(1,-1);
    }
    return v;
  }
  function toBool(v){
    var s = stripQuotes(v).toLowerCase();
    if (s === "true") return true;
    if (s === "false") return false;
    return null;
  }
  function hostOf(bind){
    var v = stripQuotes(bind).trim();
    if (v.charAt(0) === ":") return "";               /* ":8086" = all interfaces */
    if (v.charAt(0) === "["){ var end = v.indexOf("]"); return end > 0 ? v.slice(1,end) : v; }
    var idx = v.lastIndexOf(":");
    return idx > 0 ? v.slice(0, idx) : v;
  }
  function isLoopback(bind){
    var h = hostOf(bind).toLowerCase();
    return h === "127.0.0.1" || h === "localhost" || h === "::1" || h.indexOf("127.") === 0;
  }
  function isExternalBind(bind){
    if (bind === null || bind === undefined) return false;
    return !isLoopback(bind);
  }

  /* Environment-style line: INFLUXDB_HTTP_AUTH_ENABLED -> section http, key auth-enabled */
  function envToSectionKey(rawKey){
    var k = rawKey;
    if (k.indexOf("INFLUXDB_") === 0) k = k.slice("INFLUXDB_".length);
    var parts = k.toLowerCase().split("_");
    if (parts.length < 2) return null;
    var sec = parts[0];
    if (!KNOWN_SECTIONS[sec]) return null;
    return { section: sec, key: parts.slice(1).join("-") };
  }

  function audit(text){
    var findings = [];
    function add(sev, line, loc, msg, fix){
      findings.push({sev:sev, line:line, loc:loc, msg:msg, fix:fix || ""});
    }

    var lines = text.split(/\r?\n/);
    var section = "";
    var sectionLine = {};       /* section name -> header line */
    var entries = [];           /* {section,key,value,line} — value kept in memory only, never rendered for secret keys */
    var seen = {};              /* section|key -> [lines] */
    var unknownSections = {};   /* name -> line */
    var i, raw, line, trimmed;

    for (i = 0; i < lines.length; i++){
      line = i + 1;
      raw = lines[i];
      trimmed = raw.trim();
      if (trimmed === "" || trimmed.charAt(0) === "#") continue;

      var secMatch = trimmed.match(/^\[\s*([A-Za-z0-9_.-]+)\s*\]$/);
      if (secMatch){
        section = secMatch[1].toLowerCase();
        if (!(section in sectionLine)) sectionLine[section] = line;
        if (!KNOWN_SECTIONS[section] && !(section in unknownSections)){
          unknownSections[section] = line;
        }
        continue;
      }
      if (trimmed.charAt(0) === "["){
        add("INFO", line, "line " + line, "NOT PARSED: this line looks like a section header but does not parse, so nothing under it was guessed at.", "Fix the section header to the form [name] and re-run.");
        continue;
      }
      var kv = trimmed.match(/^([A-Za-z0-9_.-]+)\s*=\s*(.+)$/);
      if (!kv){
        add("INFO", line, "line " + line, "NOT PARSED: this line is not a key = value line, a section header, or a comment, so it was not guessed at.", "Rewrite the line as key = value, comment it out, or remove it.");
        continue;
      }
      var key = kv[1], value = kv[2], sec = section;
      if (/^[A-Z][A-Z0-9_]*$/.test(key) && key.indexOf("_") !== -1){
        var mapped = envToSectionKey(key);
        if (mapped){ sec = mapped.section; key = mapped.key; }
      }
      key = key.toLowerCase();
      entries.push({section:sec, key:key, value:value, line:line});
      var dupId = sec + "|" + key;
      if (!seen[dupId]) seen[dupId] = [];
      seen[dupId].push(line);
    }

    /* Unknown sections */
    Object.keys(unknownSections).forEach(function(name){
      add("INFO", unknownSections[name], "line " + unknownSections[name],
        "NOT AUDITED: section [" + name + "] is not a section this auditor knows, so its settings were not graded.",
        "Check this section against the InfluxDB documentation by hand.");
    });

    /* Unknown keys */
    entries.forEach(function(e){
      var known = KNOWN_KEYS[e.section];
      if (KNOWN_SECTIONS[e.section] && known && known.indexOf(e.key) === -1 && !isSecretKey(e.key)){
        add("INFO", e.line, "line " + e.line + " · [" + (e.section || "top level") + "] " + e.key,
          "NOT AUDITED: key \"" + e.key + "\" in section [" + (e.section || "top level") + "] is not a key this auditor knows, so it was not graded.",
          "Verify this key against the InfluxDB documentation by hand.");
      }
    });

    /* Secret-looking keys — name and line ONLY, value never used */
    entries.forEach(function(e){
      if (isSecretKey(e.key)){
        add("WARNING", e.line, "line " + e.line + " · [" + (e.section || "top level") + "] " + e.key,
          "Secret-looking key \"" + e.key + "\" is set in plain text on line " + e.line + ". The value is deliberately not shown anywhere in this audit. A config file readable by others hands them the secret.",
          "Move the secret out of the shared config, restrict the file's permissions, and rotate the secret if this file was ever shared.");
      }
    });

    /* Duplicates — last value wins */
    Object.keys(seen).forEach(function(dupId){
      var ls = seen[dupId];
      if (ls.length > 1){
        var parts = dupId.split("|");
        add("WARNING", ls[ls.length-1], "lines " + ls.join(" and ") + " · [" + (parts[0] || "top level") + "] " + parts[1],
          "Duplicate key \"" + parts[1] + "\" appears on lines " + ls.join(" and ") + ". The last value wins, so line " + ls[ls.length-1] + " is the one in effect.",
          "Delete the stale copy of \"" + parts[1] + "\" so only the intended value remains.");
      }
    });

    function lastEntry(sec, key){
      var found = null;
      entries.forEach(function(e){ if (e.section === sec && e.key === key) found = e; });
      return found;
    }
    function anyEntry(sec, keys){
      var found = null;
      entries.forEach(function(e){ if (e.section === sec && keys.indexOf(e.key) !== -1) found = e; });
      return found;
    }

    /* ---------- [http] checks ---------- */
    var httpBind = lastEntry("http","bind-address");
    var httpAuth = lastEntry("http","auth-enabled");
    var httpHttps = lastEntry("http","https-enabled");
    var httpExternal = httpBind ? isExternalBind(httpBind.value) : false;
    var authVal = httpAuth ? toBool(httpAuth.value) : null;

    if (httpBind && httpExternal && authVal !== true){
      add("BLOCKER", httpBind.line, "line " + httpBind.line + " · [http] bind-address",
        "[http] is bound to a non-loopback address (line " + httpBind.line + ") while auth-enabled is " + (httpAuth ? "false (line " + httpAuth.line + ")" : "absent, which means off") + ". Anyone who can reach the port can read and write the database with no credentials.",
        "Set auth-enabled = true in [http], or bind to 127.0.0.1 if the server must stay local-only.");
    } else if (authVal === false){
      add("WARNING", httpAuth.line, "line " + httpAuth.line + " · [http] auth-enabled",
        "auth-enabled = false in [http]. The bind is not external, so this is not an open door today — but the moment the bind changes, it becomes one.",
        "Set auth-enabled = true in [http] unless this instance is deliberately credential-free on a trusted loopback.");
    } else if (authVal === true){
      add("GOOD", httpAuth.line, "line " + httpAuth.line + " · [http] auth-enabled",
        "auth-enabled = true in [http]: the HTTP API requires credentials.",
        "");
    }
    if (httpBind && !httpExternal){
      add("GOOD", httpBind.line, "line " + httpBind.line + " · [http] bind-address",
        "[http] is bound to a loopback address, so the API is not reachable from other machines.",
        "");
    } else if (httpBind && httpExternal && authVal === true){
      add("INFO", httpBind.line, "line " + httpBind.line + " · [http] bind-address",
        "[http] is bound to a non-loopback address with auth enabled. That can be a legitimate deployment — make sure a firewall and TLS match the exposure.",
        "");
    }
    if (!httpBind){
      add("INFO", sectionLine["http"] || 0, sectionLine["http"] ? "line " + sectionLine["http"] + " · [http]" : "[http]",
        "No bind-address was found in [http]. InfluxDB's default bind reaches beyond loopback on many builds, so the pairing with auth above was graded on what the config states, not the default.",
        "Set bind-address explicitly in [http] so the exposure is a decision, not a default.");
    }

    /* HTTPS posture on external bind */
    if (httpExternal){
      var httpsVal = httpHttps ? toBool(httpHttps.value) : null;
      if (httpsVal !== true){
        add("WARNING", httpHttps ? httpHttps.line : httpBind.line, "line " + (httpHttps ? httpHttps.line : httpBind.line) + " · [http] https-enabled",
          "https-enabled is " + (httpHttps ? "false" : "absent") + " while [http] is bound externally. Credentials and data cross the network unencrypted.",
          "Set https-enabled = true with a complete certificate and key, or put the server behind a TLS-terminating proxy.");
      } else {
        add("GOOD", httpHttps.line, "line " + httpHttps.line + " · [http] https-enabled",
          "https-enabled = true on an externally bound [http]: traffic is encrypted.",
          "");
      }
    }

    /* TLS completeness across http/admin */
    var certE = anyEntry("http",["https-certificate","tls-cert-file"]) || anyEntry("admin",["https-certificate","tls-cert-file"]);
    var keyE  = anyEntry("http",["https-private-key","tls-key-file"]) || anyEntry("admin",["https-private-key","tls-key-file"]);
    if (certE && !keyE){
      add("WARNING", certE.line, "line " + certE.line + " · TLS certificate",
        "A TLS certificate is configured (line " + certE.line + ") but no matching private key was found. Incomplete TLS: the server cannot serve HTTPS with half a pair.",
        "Add the matching private key (https-private-key) next to the certificate.");
    } else if (!certE && keyE){
      add("WARNING", keyE.line, "line " + keyE.line + " · TLS private key",
        "A TLS private key is configured (line " + keyE.line + ") but no matching certificate was found. Incomplete TLS: the server cannot serve HTTPS with half a pair.",
        "Add the matching certificate (https-certificate) next to the private key.");
    } else if (certE && keyE){
      add("GOOD", certE.line, "line " + certE.line + " · TLS",
        "TLS certificate and private key are both configured: the TLS pair is complete.",
        "");
    }

    /* pprof / debug endpoints */
    [["http","pprof-enabled"],["http","debug-enabled"]].forEach(function(pair){
      var e = lastEntry(pair[0], pair[1]);
      if (e && toBool(e.value) === true){
        if (httpExternal){
          add("WARNING", e.line, "line " + e.line + " · [" + pair[0] + "] " + pair[1],
            pair[1] + " = true while the server is bound externally. Debug and profiling endpoints leak internals and can be used to stall the process.",
            "Set " + pair[1] + " = false, or restrict it to a loopback-only listener.");
        } else {
          add("INFO", e.line, "line " + e.line + " · [" + pair[0] + "] " + pair[1],
            pair[1] + " = true on a loopback bind. Fine for local debugging; do not carry it into an externally bound deployment.",
            "");
        }
      }
    });

    /* ---------- [admin] checks ---------- */
    if ("admin" in sectionLine){
      var admEnabled = lastEntry("admin","enabled");
      var admBind = lastEntry("admin","bind-address");
      var admHttps = lastEntry("admin","https-enabled");
      var admOn = admEnabled ? toBool(admEnabled.value) !== false : !!admBind;
      var admExternal = admBind ? isExternalBind(admBind.value) : false;
      var admTls = (admHttps && toBool(admHttps.value) === true) || (!!certE && !!keyE);
      if (admOn && admExternal && !admTls){
        add("BLOCKER", admBind ? admBind.line : sectionLine["admin"], "line " + (admBind ? admBind.line : sectionLine["admin"]) + " · [admin] bind-address",
          "The admin interface is enabled and bound to an external interface (line " + (admBind ? admBind.line : sectionLine["admin"]) + ") with no TLS in place. The admin UI can manage users and databases — exposed, it is a second front door, unencrypted.",
          "Bind [admin] to 127.0.0.1, disable it if unused, or enable HTTPS with a complete certificate and key.");
      } else if (admOn && admBind && !admExternal){
        add("GOOD", admBind.line, "line " + admBind.line + " · [admin] bind-address",
          "The admin interface is bound to loopback only.",
          "");
      } else if (!admOn){
        add("INFO", sectionLine["admin"], "line " + sectionLine["admin"] + " · [admin]",
          "The admin interface is disabled in this config.",
          "");
      }
    }

    /* ---------- [data] checks ---------- */
    if ("data" in sectionLine){
      ["dir","wal-dir"].forEach(function(k){
        var e = lastEntry("data", k);
        if (e){
          add("INFO", e.line, "line " + e.line + " · [data] " + k,
            "[data] " + k + " is set on line " + e.line + ". Noted, not graded: confirm the path is on storage you trust, is backed up, and is not world-readable — database files on disk are the whole database to anyone who can read them.",
            "");
        }
      });
      var cacheE = anyEntry("data",["cache-max-memory-size","cache-snapshot-memory-size"]);
      if (cacheE){
        add("INFO", cacheE.line, "line " + cacheE.line + " · [data] cache",
          "Cache sizing is configured in [data] (line " + cacheE.line + "). Noted: cache limits are a capacity setting, graded here as information only.",
          "");
      }
      var ms = lastEntry("data","max-series-per-database");
      if (!ms){
        add("INFO", sectionLine["data"], "line " + sectionLine["data"] + " · [data] max-series-per-database",
          "max-series-per-database is absent from [data], so series cardinality is unbounded. That is a resource risk, not a security hole: a runaway tag combination can exhaust memory and take the server down.",
          "Set max-series-per-database to a positive limit sized for your workload.");
      } else if (stripQuotes(ms.value).trim() === "0"){
        add("INFO", ms.line, "line " + ms.line + " · [data] max-series-per-database",
          "max-series-per-database = 0 on line " + ms.line + ", which means no limit. That is a resource risk, not a security hole: unbounded cardinality can exhaust memory and take the server down.",
          "Set max-series-per-database to a positive limit sized for your workload.");
      } else {
        add("GOOD", ms.line, "line " + ms.line + " · [data] max-series-per-database",
          "max-series-per-database is set to a positive limit: series cardinality is bounded.",
          "");
      }
    }

    /* Order: severity, then line */
    var rank = {BLOCKER:0, WARNING:1, INFO:2, GOOD:3};
    findings.sort(function(a,b){
      if (rank[a.sev] !== rank[b.sev]) return rank[a.sev] - rank[b.sev];
      return (a.line || 0) - (b.line || 0);
    });

    var counts = {BLOCKER:0, WARNING:0, INFO:0, GOOD:0};
    findings.forEach(function(f){ counts[f.sev]++; });

    var verdict, cls, sub;
    if (counts.BLOCKER > 0){
      verdict = "DO NOT DEPLOY"; cls = "stop";
      sub = counts.BLOCKER + (counts.BLOCKER === 1 ? " blocker" : " blockers") + " found. Fix every blocker before this config goes anywhere near a network.";
    } else if (counts.WARNING > 0){
      verdict = "DEPLOY WITH FIXES"; cls = "fixes";
      sub = "No blockers, but " + counts.WARNING + (counts.WARNING === 1 ? " warning needs" : " warnings need") + " attention before this is a config you can defend.";
    } else {
      verdict = "SAFE TO DEPLOY"; cls = "safe";
      sub = "No blockers and no warnings from these checks. INFO and GOOD notes are listed below for the record.";
    }

    var fixes = [], fixSeen = {};
    findings.forEach(function(f){
      if ((f.sev === "BLOCKER" || f.sev === "WARNING" || (f.sev === "INFO" && f.fix)) && f.fix && !fixSeen[f.fix]){
        fixSeen[f.fix] = true; fixes.push(f.fix);
      }
    });

    /* Copyable report — built only from finding fields; secret values are never in any field. */
    var report = [];
    report.push("J-Dawgs InfluxDB Server Config Safety Auditor — audit report");
    report.push("Verdict: " + verdict);
    report.push("Counts: BLOCKER " + counts.BLOCKER + " · WARNING " + counts.WARNING + " · INFO " + counts.INFO + " · GOOD " + counts.GOOD);
    report.push("Method: heuristic text audit of pasted config text. Not a TOML parser; no server was contacted; secret values are never printed — secret-looking keys are flagged by name and line only.");
    report.push("");
    report.push("FINDINGS");
    if (!findings.length) report.push("(none)");
    findings.forEach(function(f){
      report.push("[" + f.sev + "] " + f.loc + " — " + f.msg);
      if (f.fix) report.push("    Fix: " + f.fix);
    });
    report.push("");
    report.push("FIX LIST");
    if (!fixes.length) report.push("(nothing to fix)");
    fixes.forEach(function(fx, idx){ report.push((idx+1) + ". " + fx); });

    return {findings:findings, counts:counts, verdict:verdict, cls:cls, sub:sub, fixes:fixes, report:report.join("\n")};
  }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "CLEAN_EXAMPLE": (typeof CLEAN_EXAMPLE !== 'undefined' ? CLEAN_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-influxdb-server-config-safety-auditor',
  name: 'J-Dawgs InfluxDB Server Config Safety Auditor',
  description: 'Grades a pasted InfluxDB server config offline — bind exposure paired with auth/TLS posture, admin exposure, secrets by key name and line only — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "CLEAN_EXAMPLE": __core["CLEAN_EXAMPLE"] }
};
