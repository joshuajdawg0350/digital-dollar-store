'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs BookKeeper Bookie Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Examples (line numbers are part of the worked example) ---------- */
      var RISKY_EXAMPLE = [
        "# Risky example - a bookie config with planted problems. Do not ship this.",
        "bookiePort=3181",
        "advertisedAddress=0.0.0.0",
        "journalDirectories=/data/bookkeeper/journal",
        "ledgerDirectories=/data/bookkeeper/journal",
        "zkServers=localhost:2181",
        "httpServerEnabled=true",
        "statsProviderClass=org.apache.bookkeeper.stats.prometheus.PrometheusMetricsProvider",
        "tlsKeyStorePassword=bookie-secret-123",
        "diskUsageThreshold=0.999",
        "bookie config goes here please"
      ].join("\n");

      var HARDENED_EXAMPLE = [
        "# Hardened example - the same bookie, locked down.",
        "bookiePort=3181",
        "advertisedAddress=bookie1.internal",
        "journalDirectories=/mnt/journal-bk/journal",
        "ledgerDirectories=/mnt/ledger-bk/ledgers",
        "indexDirectories=/mnt/ledger-bk/index",
        "zkServers=zk1.internal:2181,zk2.internal:2181,zk3.internal:2181",
        "tlsProviderFactoryClass=org.apache.bookkeeper.tls.TLSContextFactory",
        "tlsCertificatePath=/etc/bookkeeper/certs/bookie.cert.pem",
        "tlsKeyStoreType=PEM",
        "tlsKeyStorePasswordPath=/etc/bookkeeper/certs/keystore-password.txt",
        "bookieAuthProviderFactoryClass=org.apache.bookkeeper.sasl.SASLBookieAuthProviderFactory",
        "httpServerEnabled=false",
        "diskUsageThreshold=0.95",
        "diskUsageLwmThreshold=0.90",
        "isForceGCAllowWhenNoSpace=false"
      ].join("\n");

      /* ---------- Recognized BookKeeper / bookie keys (lowercase) ---------- */
      var KNOWN_KEYS = {};
      ("bookieport advertisedaddress listeninginterface journaldirectories journaldirectory " +
       "ledgerdirectories ledgerdirectory indexdirectories indexdirectory zkservers zktimeout " +
       "zksessiontimeoutms zkledgersrootpath metadataserviceuri httpserverenabled httpserverport " +
       "statsproviderclass tlsproviderfactoryclass tlscertificatepath tlskeystoretype tlskeystore " +
       "tlskeystorepasswordpath tlskeystorepassword tlstruststoretype tlstruststore " +
       "tlstruststorepasswordpath tlsclientauthentication tlsallowinsecureconnection " +
       "bookieauthproviderfactoryclass clientauthproviderfactoryclass diskusagethreshold " +
       "diskusagelwmthreshold diskcheckinterval isforcegcallowwhennospace forcereadonlybookie " +
       "readonlymodeenabled gcwaittime ledgermanagerfactoryclass ledgermanagertype allowloopback " +
       "autorecoverydaemonenabled lostbookierecoverydelay usehostnameasbookieid journalmaxsizemb " +
       "journalsyncdata entrylogfilepreallocationenabled minorcompactionthreshold " +
       "majorcompactionthreshold ledgerstorageclass dbledgerstorageclass sortedledgerstorageenabled " +
       "numjournalcallbackthreads servernumiothreads flushinterval allowephemeralports " +
       "bookiedeathwatchinterval replicationworkernumthreads journalbufferedwritesthreshold " +
       "compactionrate usetransactionalcompaction zkenablesecurity bookieid prometheusstatsproviderclass"
      ).split(" ").forEach(function (k) { KNOWN_KEYS[k] = true; });

      function normalizeKey(rawKey) {
        var k = rawKey.trim();
        if (/^bk_/i.test(k)) k = k.slice(3);
        return k;
      }
      function isRecognized(key) {
        var lk = key.toLowerCase();
        if (KNOWN_KEYS[lk]) return true;
        return /^(bookie|zk|tls|journal|ledger|index|stats|httpserver|disk|metadata|prometheus|gc|compaction)/.test(lk);
      }
      function isSecretKey(key) {
        var lk = key.toLowerCase();
        if (/(path|file|type|store|provider|class|factory)$/.test(lk) && !/password$/.test(lk)) return false;
        if (/passwordpath$|passwordfile$/.test(lk)) return false;
        return /(password|passwd|pwd|secret|credential|accesstoken|authtoken|privatekey)/.test(lk);
      }
      function unquote(v) {
        v = v.trim();
        if (v.length >= 2 && ((v.charAt(0) === '"' && v.charAt(v.length - 1) === '"') || (v.charAt(0) === "'" && v.charAt(v.length - 1) === "'"))) {
          return v.slice(1, -1);
        }
        return v;
      }

      /* ---------- Parser ---------- */
      function parseConfig(text) {
        var lines = text.split(/\r\n|\r|\n/);
        var entries = [], notParsed = [], commented = 0;
        for (var i = 0; i < lines.length; i++) {
          var lineNo = i + 1;
          var raw = lines[i];
          var t = raw.trim();
          if (t === "") continue;
          if (t.charAt(0) === "#") { commented++; continue; }
          var work = t;
          if (work.indexOf("- ") === 0) work = work.slice(2).trim();
          if (/^export\s+/i.test(work)) work = work.replace(/^export\s+/i, "");
          work = unquote(work);
          var m = work.match(/^([A-Za-z][A-Za-z0-9_.\-]*)\s*=\s*(.*)$/) || work.match(/^([A-Za-z][A-Za-z0-9_.\-]*)\s*:\s+(.+)$/);
          if (!m) { notParsed.push({ line: lineNo, length: t.length }); continue; }
          var key = normalizeKey(m[1]);
          entries.push({ key: key, value: unquote(m[2] || ""), line: lineNo, recognized: isRecognized(key) });
        }
        return { entries: entries, notParsed: notParsed, commented: commented, totalLines: lines.length };
      }

      /* ---------- Audit ---------- */
      function audit(text) {
        var parsed = parseConfig(text);
        var findings = [];
        function add(severity, code, line, key, message) {
          findings.push({ severity: severity, code: code, line: line, key: key || null, message: message });
        }
        var byKey = {};
        parsed.entries.forEach(function (e) { byKey[e.key.toLowerCase()] = e; });
        function get(k) { return byKey[k.toLowerCase()] || null; }
        var recognizedCount = parsed.entries.filter(function (e) { return e.recognized; }).length;

        parsed.notParsed.forEach(function (np) {
          add("INFO", "NOT_PARSED", np.line, null,
            "Line " + np.line + " could not be read as a key=value setting (" + np.length + " characters). It was not graded. If it was meant to be a setting, rewrite it as key=value.");
        });

        var stats = {
          linesPasted: parsed.totalLines,
          settingsRead: parsed.entries.length,
          recognizedSettings: recognizedCount,
          commentedLinesIgnored: parsed.commented,
          linesNotParsed: parsed.notParsed.length
        };

        if (recognizedCount === 0) {
          return { verdict: "NOT ENOUGH TO GRADE", findings: findings, stats: stats };
        }

        /* Plaintext secrets — key, line, length ONLY. The value is never copied anywhere. */
        parsed.entries.forEach(function (e) {
          if (isSecretKey(e.key) && e.value !== "") {
            add("CRITICAL", "PLAINTEXT_SECRET", e.line, e.key,
              "Plaintext secret stored under key \"" + e.key + "\" (value length " + e.value.length + "). Anyone who can read this file has the secret. Move it into a password file or secret store and point the matching ...PasswordPath setting at it. The value itself is never shown by this tool.");
          }
        });

        var tlsEntry = get("tlsProviderFactoryClass");
        var tlsOn = !!(tlsEntry && tlsEntry.value !== "" && !/^(null|none|false)$/i.test(tlsEntry.value));
        var authEntry = get("bookieAuthProviderFactoryClass");
        var authOn = !!(authEntry && authEntry.value !== "" && !/^(null|none|false)$/i.test(authEntry.value));
        var portEntry = get("bookiePort");
        var advEntry = get("advertisedAddress");
        var allIfaces = !!(advEntry && /^(0\.0\.0\.0|::|\[::\]|\*)$/.test(advEntry.value.trim()));

        if (allIfaces) {
          add((!tlsOn || !authOn) ? "CRITICAL" : "WARNING", "ALL_INTERFACES", advEntry.line, advEntry.key,
            "advertisedAddress is \"" + advEntry.value + "\" — the bookie announces itself on every network interface. Set it to the one address clients and peers should use" + ((!tlsOn || !authOn) ? ", and note the exposure findings below: with no TLS and no authentication this is an open door." : "."));
        }
        if (portEntry && !tlsOn) {
          add("CRITICAL", "NO_TLS", portEntry.line, "tlsProviderFactoryClass",
            "No TLS provider is configured (tlsProviderFactoryClass is missing from the paste), so bookie traffic on port " + (portEntry.value || "3181") + " travels in plaintext — ledger data and digests can be read or tampered with in transit. Configure tlsProviderFactoryClass with a certificate before deploying.");
        }
        if (portEntry && !authOn) {
          add(allIfaces ? "CRITICAL" : "WARNING", "NO_AUTH", portEntry.line, "bookieAuthProviderFactoryClass",
            "No bookie authentication provider is configured (bookieAuthProviderFactoryClass is missing from the paste)" + (allIfaces ? ", while the bookie is bound to all interfaces — any client that can reach the port can read and write ledgers." : " — any client that can reach the bookie port can read and write ledgers.") + " Configure an auth provider (for example SASL) before deploying.");
        }

        var httpEntry = get("httpServerEnabled");
        var httpOn = !!(httpEntry && /^(true|yes|1)$/i.test(httpEntry.value.trim()));
        var statsEntry = get("statsProviderClass");
        if (httpOn && !tlsOn) {
          add("CRITICAL", "HTTP_SERVER_NO_TLS", httpEntry.line, httpEntry.key,
            "The bookie HTTP server is enabled (httpServerEnabled=true) with no TLS configured. The stats and metrics endpoints answer in plaintext to anyone who can reach the HTTP port. Turn the HTTP server off, bind it to a management network, or put TLS in front of it.");
        }
        if (httpOn && statsEntry) {
          add("WARNING", "STATS_NO_AUTH", statsEntry.line, statsEntry.key,
            "A stats provider (" + statsEntry.value + ") is publishing through the bookie HTTP server, and BookKeeper's built-in HTTP endpoints carry no authentication of their own. Keep the HTTP port off the public network or behind an authenticated proxy.");
        }

        function firstPath(e) { return e ? e.value.split(",")[0].trim() : null; }
        function mountOf(p) {
          var parts = p.split("/").filter(function (s) { return s !== ""; });
          if (parts.length >= 2) return "/" + parts[0] + "/" + parts[1];
          return "/" + (parts[0] || "");
        }
        var jEntry = get("journalDirectories") || get("journalDirectory");
        var lEntry = get("ledgerDirectories") || get("ledgerDirectory");
        var jPath = firstPath(jEntry), lPath = firstPath(lEntry);
        if (jPath && lPath) {
          if (jPath === lPath) {
            add("WARNING", "JOURNAL_LEDGER_SAME_DIR", lEntry.line, lEntry.key,
              "Journal and ledger directories are the same path (" + jPath + "). The journal is the write-ahead log that rebuilds ledgers after a crash — sharing one directory and disk means a full or failed disk takes both at once. Put the journal on its own disk.");
          } else if (mountOf(jPath) === mountOf(lPath)) {
            add("WARNING", "JOURNAL_LEDGER_SAME_DISK", lEntry.line, lEntry.key,
              "Journal (" + jPath + ") and ledger (" + lPath + ") directories sit on the same disk mount (" + mountOf(jPath) + "). Separate them onto different disks so a single disk failure or a full disk cannot take the journal and the ledgers together.");
          }
        }
        [jEntry, lEntry].forEach(function (e) {
          var p = firstPath(e);
          if (p && /^\/tmp(\/|$)/.test(p)) {
            add("WARNING", "TMP_DATA_PATH", e.line, e.key, "Data directory " + p + " is under /tmp — that is the stock example layout, and /tmp is wiped on reboot on many systems. Point it at durable storage.");
          }
        });

        var dtEntry = get("diskUsageThreshold");
        if (!dtEntry) {
          add("INFO", "DISK_THRESHOLD_UNSET", null, "diskUsageThreshold",
            "diskUsageThreshold is not set in the paste, so BookKeeper's built-in default applies and the bookie keeps writing until the disk is nearly full before reacting. Set it explicitly (0.95 is a common working value) so the posture is a decision, not a default.");
        } else {
          var dtVal = parseFloat(dtEntry.value);
          if (!isNaN(dtVal) && dtVal >= 0.99) {
            add("WARNING", "DISK_THRESHOLD_HIGH", dtEntry.line, dtEntry.key,
              "diskUsageThreshold is " + dtEntry.value + " — the bookie will fill the disk to " + Math.round(dtVal * 100) + "% before it stops taking writes or forces garbage collection. That leaves almost no headroom when a disk fills fast. 0.95 or lower is the usual working range.");
          }
          var lwmEntry = get("diskUsageLwmThreshold");
          if (lwmEntry && !isNaN(dtVal)) {
            var lwmVal = parseFloat(lwmEntry.value);
            if (!isNaN(lwmVal) && lwmVal > dtVal) {
              add("WARNING", "DISK_LWM_ABOVE_THRESHOLD", lwmEntry.line, lwmEntry.key,
                "diskUsageLwmThreshold (" + lwmEntry.value + ") is higher than diskUsageThreshold (" + dtEntry.value + "). The low-water mark must sit at or below the threshold, or the bookie can flap in and out of read-only mode.");
            }
          }
        }
        var gcEntry = get("isForceGCAllowWhenNoSpace");
        if (gcEntry && /^true$/i.test(gcEntry.value.trim())) {
          add("WARNING", "FORCE_GC_WHEN_FULL", gcEntry.line, gcEntry.key,
            "isForceGCAllowWhenNoSpace=true: when the disk fills, the bookie garbage-collects instead of going read-only. GC under disk pressure can delete ledgers that are not yet fully replicated. Prefer read-only posture on a full disk unless you have tested this end to end.");
        }

        var zkEntry = get("zkServers");
        if (zkEntry && /(localhost|127\.0\.0\.1)/.test(zkEntry.value)) {
          add("WARNING", "EXAMPLE_ZK_ADDRESS", zkEntry.line, zkEntry.key,
            "zkServers points at \"" + zkEntry.value + "\" — a localhost address is the stock example value. In production this must name the real ZooKeeper ensemble, or the bookie registers with a throwaway ensemble and the cluster cannot see it.");
        }
        if (advEntry && advEntry.value.trim() === "") {
          add("WARNING", "EMPTY_ADVERTISED_ADDRESS", advEntry.line, advEntry.key,
            "advertisedAddress is present but empty. An empty advertised address makes the bookie fall back to its hostname, which clients in other networks often cannot resolve. Set it explicitly.");
        }

        var sevRank = { CRITICAL: 0, WARNING: 1, INFO: 2 };
        findings.sort(function (a, b) {
          if (sevRank[a.severity] !== sevRank[b.severity]) return sevRank[a.severity] - sevRank[b.severity];
          return (a.line || 0) - (b.line || 0);
        });

        var hasCrit = findings.some(function (f) { return f.severity === "CRITICAL"; });
        var hasWarn = findings.some(function (f) { return f.severity === "WARNING"; });
        var verdict = hasCrit ? "DO NOT DEPLOY" : (hasWarn ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY");
        return { verdict: verdict, findings: findings, stats: stats };
      }

      /* ---------- Reports ---------- */
      function countsOf(result) {
        var c = { CRITICAL: 0, WARNING: 0, INFO: 0 };
        result.findings.forEach(function (f) { c[f.severity]++; });
        return c;
      }
      function buildTextReport(result) {
        var c = countsOf(result);
        var out = [];
        out.push("J-Dawgs BookKeeper Bookie Config Safety Auditor(TM) - Audit Report");
        out.push("Verdict: " + result.verdict);
        out.push("Lines pasted: " + result.stats.linesPasted +
                 " | Settings read: " + result.stats.settingsRead +
                 " | Recognized BookKeeper settings: " + result.stats.recognizedSettings +
                 " | Commented lines ignored: " + result.stats.commentedLinesIgnored +
                 " | Lines not parsed: " + result.stats.linesNotParsed);
        out.push("Findings: " + c.CRITICAL + " critical, " + c.WARNING + " warning, " + c.INFO + " info");
        out.push("");
        if (result.findings.length === 0) {
          out.push("No findings. Nothing in the pasted configuration tripped a check.");
        } else {
          result.findings.forEach(function (f) {
            out.push("[" + f.severity + "] " + (f.line ? "Line " + f.line : "No line (setting absent)") +
                     (f.key ? " | " + f.key : "") + " | " + f.code);
            out.push("    " + f.message);
          });
        }
        out.push("");
        out.push("Note: secret values are never printed by this tool. A plaintext-secret finding names the key, its line, and the value length only.");
        return out.join("\n");
      }
      function buildJson(result) {
        var c = countsOf(result);
        return JSON.stringify({
          tool: "J-Dawgs BookKeeper Bookie Config Safety Auditor",
          verdict: result.verdict,
          counts: { critical: c.CRITICAL, warning: c.WARNING, info: c.INFO },
          stats: result.stats,
          findings: result.findings.map(function (f) {
            return { severity: f.severity, code: f.code, line: f.line, key: f.key, message: f.message };
          })
        }, null, 2);
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-bookkeeper-bookie-config-safety-auditortm',
  name: 'J-Dawgs BookKeeper Bookie Config Safety Auditor',
  description: 'Grades a pasted Apache BookKeeper bookie configuration fully offline into one deploy verdict, with plaintext secrets shown by key name, line, and length only, never by value. BookKeeper only exercises a config by starting the bookie; this grades it before anything starts.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
