'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Radon Mitigation Proposal, Work Record & Final Invoice Consistency Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";
function $(id){return document.getElementById(id);}
function round2(n){return Math.round((n+Number.EPSILON)*100)/100;}
function fmt(n){var v=round2(n);var neg=v<0;v=Math.abs(v);var s=v.toFixed(2);var parts=s.split(".");parts[0]=parts[0].replace(/\B(?=(\d{3})+(?!\d))/g,",");return (neg?"-$":"$")+parts.join(".");}
function num(n){return round2(n).toFixed(2);}
function esc(s){return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");}
function normName(s){return String(s).toLowerCase().replace(/[^a-z0-9]+/g," ").replace(/\s+/g," ").trim();}
function isRetest(name){return /retest|re-test|post mitigation test/.test(normName(name));}
function moneyIn(str){var m=String(str).replace(/,/g,"").match(/\$\s*(\d+(?:\.\d+)?)/);return m?parseFloat(m[1]):null;}
function lastMoney(str){var ms=String(str).replace(/,/g,"").match(/\$\s*(\d+(?:\.\d+)?)/g);if(!ms)return null;var last=ms[ms.length-1].match(/(\d+(?:\.\d+)?)/);return last?parseFloat(last[1]):null;}
function fieldNum(str,re){var m=String(str).match(re);return m?parseFloat(String(m[1]).replace(/,/g,"")):null;}

function parseDoc(text, role){
  var doc={role:role, items:{}, itemOrder:[], fees:[], labor:null, depositPaid:null, depositCredit:null,
    retestDone:false, retestNotDone:false, retestIncluded:false, retestCharges:[], statedTotal:null,
    chargeLines:0, unparsed:0};
  if(!text) return doc;
  var lines=String(text).split(/\r?\n/);
  for(var i=0;i<lines.length;i++){
    var raw=lines[i]; var line=raw.trim();
    if(!line) continue;
    if(/^#/.test(line)||/^\/\//.test(line)) continue;
    var m;
    if(/^deposit\b/i.test(line)){
      var amt=moneyIn(line);
      if(amt!==null){
        if(/credit/i.test(line)){ if(doc.depositCredit===null||amt>doc.depositCredit) doc.depositCredit=amt; }
        else if(/paid/i.test(line)){ if(doc.depositPaid===null||amt>doc.depositPaid) doc.depositPaid=amt; }
        else { if(role==="invoice"){ if(doc.depositCredit===null||amt>doc.depositCredit) doc.depositCredit=amt; }
               else { if(doc.depositPaid===null||amt>doc.depositPaid) doc.depositPaid=amt; } }
        doc.chargeLines++;
      }
      continue;
    }
    if(/^item\s*[:\-]/i.test(line)){
      var rest=line.replace(/^item\s*[:\-]\s*/i,"");
      var parts=rest.split("|");
      var name=parts[0].trim().replace(/[:\-]\s*$/,"");
      var qty=fieldNum(rest,/qty\s*[:x]?\s*(\d+(?:\.\d+)?)/i);
      var each=fieldNum(rest,/each\s*[:\$]?\s*\$?\s*([\d,]+(?:\.\d+)?)/i);
      var tot=fieldNum(rest,/total\s*[:\$]?\s*\$?\s*([\d,]+(?:\.\d+)?)/i);
      if(each===null && tot===null){ var lm=lastMoney(rest); if(lm!==null){ if(qty&&qty>1){tot=lm;} else {each=lm;} } }
      if(qty===null) qty=1;
      if(tot===null && each!==null) tot=round2(qty*each);
      if(each===null && tot!==null && qty) each=round2(tot/qty);
      if(tot===null){ doc.unparsed++; continue; }
      doc.chargeLines++;
      if(isRetest(name)){ doc.retestCharges.push({name:name,qty:qty,each:each,total:tot}); continue; }
      var key=normName(name);
      if(!doc.items[key]){ doc.items[key]={name:name,qty:0,each:each,total:0}; doc.itemOrder.push(key); }
      doc.items[key].qty+=qty; doc.items[key].total=round2(doc.items[key].total+tot);
      if(each!==null) doc.items[key].each=each;
      continue;
    }
    if(/^labor\b/i.test(line)){
      var hrs=fieldNum(line,/hours?\s*[:x]?\s*(\d+(?:\.\d+)?)/i);
      var rate=fieldNum(line,/rate\s*[:\$]?\s*\$?\s*([\d,]+(?:\.\d+)?)/i);
      var ltot=fieldNum(line,/total\s*[:\$]?\s*\$?\s*([\d,]+(?:\.\d+)?)/i);
      if(ltot===null){ var lm2=lastMoney(line); if(lm2!==null && (rate===null || lm2!==rate)) ltot=lm2; }
      if(hrs!==null && rate!==null && ltot===null) ltot=round2(hrs*rate);
      if(hrs!==null || ltot!==null){ doc.labor={hours:hrs,rate:rate,total:ltot}; doc.chargeLines++; }
      else doc.unparsed++;
      continue;
    }
    if(/^fee\s*[:\-]/i.test(line)){
      var frest=line.replace(/^fee\s*[:\-]\s*/i,"");
      var fparts=frest.split("|");
      var fname=fparts[0].trim().replace(/[:\-]\s*$/,"");
      var famt=lastMoney(frest);
      if(famt===null){ doc.unparsed++; continue; }
      doc.chargeLines++;
      if(isRetest(fname)){ doc.retestCharges.push({name:fname,qty:1,each:famt,total:famt}); continue; }
      doc.fees.push({name:fname,key:normName(fname),amount:famt});
      continue;
    }
    if(/^retest\b/i.test(line)){
      var ramt=moneyIn(line);
      if(/not\s+done|not\s+recorded|pending|not\s+performed/i.test(line)){ doc.retestNotDone=true; }
      else if(/\bdone\b|completed|performed/i.test(line)){ doc.retestDone=true; }
      if(/included/i.test(line)){ doc.retestIncluded=true; }
      if(ramt!==null && ramt>0){ doc.retestCharges.push({name:"Post-mitigation retest",qty:1,each:ramt,total:ramt}); doc.chargeLines++; }
      continue;
    }
    if(/^(grand\s+)?total\s*[:\-]/i.test(line)){
      var tval=moneyIn(line); if(tval!==null) doc.statedTotal=tval;
      continue;
    }
    var gamt=lastMoney(line);
    if(gamt!==null){
      var gname=line.split("|")[0].replace(/\$\s*[\d,]+(?:\.\d+)?/g,"").replace(/[:\-\|]\s*$/,"").trim();
      if(!gname) gname="Unnamed charge";
      doc.chargeLines++;
      if(isRetest(gname)){ doc.retestCharges.push({name:gname,qty:1,each:gamt,total:gamt}); continue; }
      doc.fees.push({name:gname,key:normName(gname),amount:gamt});
      continue;
    }
    doc.unparsed++;
  }
  return doc;
}

function chargesSum(doc){
  var s=0,k;
  for(k in doc.items) if(Object.prototype.hasOwnProperty.call(doc.items,k)) s+=doc.items[k].total;
  for(var i=0;i<doc.fees.length;i++) s+=doc.fees[i].amount;
  for(var j=0;j<doc.retestCharges.length;j++) s+=doc.retestCharges[j].total;
  if(doc.labor && doc.labor.total!==null && doc.labor.total!==undefined) s+=doc.labor.total;
  return round2(s);
}
function basisKeys(prop,work){
  var set={},k,i;
  [prop,work].forEach(function(d){
    for(k in d.items) if(Object.prototype.hasOwnProperty.call(d.items,k)) set[k]=true;
    for(i=0;i<d.fees.length;i++) set[d.fees[i].key]=true;
    for(i=0;i<d.retestCharges.length;i++) set[normName(d.retestCharges[i].name)]=true;
  });
  return set;
}

function audit(pText,wText,iText){
  var present={proposal:!!(pText&&pText.trim()),work:!!(wText&&wText.trim()),invoice:!!(iText&&iText.trim())};
  var count=(present.proposal?1:0)+(present.work?1:0)+(present.invoice?1:0);
  var names={proposal:"Proposal",work:"Work Record",invoice:"Final Invoice"};
  var missing=[]; ["proposal","work","invoice"].forEach(function(k){ if(!present[k]) missing.push(names[k]); });
  var prop=parseDoc(pText||"","proposal"), work=parseDoc(wText||"","work"), inv=parseDoc(iText||"","invoice");
  var findings=[]; // {sev:'crit'|'warn'|'good', type, title, detail, amount}
  function add(sev,type,title,detail,amount){ findings.push({sev:sev,type:type,title:title,detail:detail,amount:round2(amount||0)}); }

  if(count<2 || !present.invoice){
    var why;
    if(count===0) why="All three boxes are empty. Paste at least the proposal and the final invoice to compare anything.";
    else if(!present.invoice) why="There is no Final Invoice to check. Missing document: Final Invoice"+(missing.length>1?" (also missing: "+missing.filter(function(x){return x!=="Final Invoice";}).join(", ")+")":"")+". Paste the invoice and run the audit again.";
    else why="Only one document was pasted. A cross-check needs at least two — paste the final invoice plus the proposal or the work record.";
    return {verdict:"NOT ENOUGH TO COMPARE",cls:"info",disputed:0,findings:[],missing:missing,present:present,
      why:why,docs:{proposal:prop,work:work,invoice:inv},parseable:false};
  }
  var parseable = inv.chargeLines>0 || prop.chargeLines>0 || work.chargeLines>0;
  if(!parseable){
    return {verdict:"NOT ENOUGH TO COMPARE",cls:"info",disputed:0,findings:[],missing:missing,present:present,
      why:"The pasted text has no lines this tool can read. Use the line format above — ITEM, LABOR, FEE, DEPOSIT and TOTAL lines — and run the audit again.",
      docs:{proposal:prop,work:work,invoice:inv},parseable:false};
  }

  var basis=basisKeys(prop,work);
  var propBasis=basisKeys(prop,parseDoc("","work"));
  var workBasis=basisKeys(parseDoc("","proposal"),work);
  var k,i;

  /* 1 — Quantities billed above installed (invoice vs work record) */
  var notInstalledKeys={};
  if(present.work){
    for(k in inv.items){ if(!Object.prototype.hasOwnProperty.call(inv.items,k)) continue;
      var ii=inv.items[k], wi=work.items[k];
      if(wi){
        if(ii.qty>wi.qty+0.0001){
          var unit=(ii.each!==null&&ii.each!==undefined)?ii.each:(wi.each||0);
          var over=round2((ii.qty-wi.qty)*unit);
          add("crit","qty-above-installed","Billed above installed: "+ii.name,
            "Invoice bills "+ii.qty+" × "+fmt(unit)+" = "+fmt(round2(ii.qty*unit))+". Work record shows "+wi.qty+" installed. Excess: ("+ii.qty+" − "+wi.qty+") × "+fmt(unit)+" = "+fmt(over)+".",over);
        }
      } else if(propBasis[k]){
        notInstalledKeys[k]=true;
        add("crit","not-recorded-installed","Billed but not recorded as installed: "+ii.name,
          "The proposal lists it and the invoice bills "+ii.qty+" × "+fmt(ii.each||0)+" = "+fmt(ii.total)+", but the work record never lists it as installed. Full line held back: "+fmt(ii.total)+".",ii.total);
      }
    }
  }

  /* 2 — Price above proposal */
  if(present.proposal){
    for(k in inv.items){ if(!Object.prototype.hasOwnProperty.call(inv.items,k)) continue;
      var pi=prop.items[k], iv=inv.items[k];
      if(pi && pi.each!==null && iv.each!==null && iv.each>pi.each+0.005){
        var base=work.items[k]?work.items[k].qty:iv.qty;
        var pOver=round2((iv.each-pi.each)*base);
        if(pOver>0) add("warn","price-above-proposal","Unit price above proposal: "+iv.name,
          "Proposal: "+fmt(pi.each)+" each. Invoice: "+fmt(iv.each)+" each. Difference "+fmt(round2(iv.each-pi.each))+" × "+base+" installed = "+fmt(pOver)+".",pOver);
      }
    }
  }

  /* 3 — Labor billed above hours × rate */
  if(inv.labor && inv.labor.total!==null && inv.labor.total!==undefined){
    var il=inv.labor;
    if(present.work && work.labor && work.labor.hours!==null && il.rate!==null){
      var justified=round2(work.labor.hours*il.rate);
      var lOver=round2(il.total-justified);
      if(lOver>0.01){
        var det="Invoice labor billed: "+fmt(il.total)+". Work record shows "+work.labor.hours+" hrs × "+fmt(il.rate)+" = "+fmt(justified)+" justified.";
        if(il.hours!==null){
          var ownLine=round2(il.hours*il.rate);
          det+=" The invoice's own line states "+il.hours+" hrs × "+fmt(il.rate)+" = "+fmt(ownLine)+", so "+fmt(round2(il.total-ownLine))+" of the overage is arithmetic on the invoice itself";
          if(il.hours>work.labor.hours) det+=" and ("+il.hours+" − "+work.labor.hours+") billed-but-unworked hours × "+fmt(il.rate)+" = "+fmt(round2((il.hours-work.labor.hours)*il.rate))+" is hours above the work record";
          det+=".";
        }
        det+=" Total labor overage: "+fmt(il.total)+" − "+fmt(justified)+" = "+fmt(lOver)+".";
        add("crit","labor-overage","Labor billed above hours × rate",det,lOver);
      }
    } else if(il.hours!==null && il.rate!==null){
      var own=round2(il.hours*il.rate);
      var aOver=round2(il.total-own);
      if(aOver>0.01) add("crit","labor-overage","Labor billed above hours × rate",
        "Invoice states "+il.hours+" hrs × "+fmt(il.rate)+" = "+fmt(own)+", but bills "+fmt(il.total)+". Overage: "+fmt(il.total)+" − "+fmt(own)+" = "+fmt(aOver)+".",aOver);
    }
  }

  /* 4 — Uncredited deposit */
  var paid=null;
  [prop,work].forEach(function(d){ if(d.depositPaid!==null){ paid=(paid===null)?d.depositPaid:Math.max(paid,d.depositPaid); } });
  if(paid!==null && paid>0){
    var credited=(inv.depositCredit===null)?0:inv.depositCredit;
    var dOver=round2(paid-credited);
    if(dOver>0.01) add("crit","uncredited-deposit","Deposit paid but not credited",
      "Deposit paid per the "+(work.depositPaid!==null?"work record":"proposal")+": "+fmt(paid)+". Deposit credit on the final invoice: "+fmt(credited)+". Uncredited: "+fmt(paid)+" − "+fmt(credited)+" = "+fmt(dOver)+".",dOver);
  }

  /* Invoice-only keys (computed before duplicates so nothing is counted twice) */
  var invoiceOnlyFeeKeys={};
  var feeGroups={};
  inv.fees.forEach(function(f){ (feeGroups[f.key]=feeGroups[f.key]||[]).push(f); });
  for(var fk in feeGroups){ if(!Object.prototype.hasOwnProperty.call(feeGroups,fk)) continue;
    if(!basis[fk]) invoiceOnlyFeeKeys[fk]=true;
  }

  /* 5 — Duplicate fees on the invoice */
  for(var dk in feeGroups){ if(!Object.prototype.hasOwnProperty.call(feeGroups,dk)) continue;
    var grp=feeGroups[dk];
    if(grp.length>1 && !invoiceOnlyFeeKeys[dk]){
      var dupAmt=0; for(i=1;i<grp.length;i++) dupAmt+=grp[i].amount;
      dupAmt=round2(dupAmt);
      var listings=grp.map(function(f){return fmt(f.amount);}).join(" + ");
      add("warn","duplicate-fee","Duplicate fee on invoice: "+grp[0].name,
        "“"+grp[0].name+"” appears "+grp.length+" times on the invoice ("+listings+"). One charge is legitimate; the extra "+(grp.length-1)+" = "+fmt(dupAmt)+".",dupAmt);
    }
  }

  /* 6 — Invoice-only charges */
  if(present.proposal || present.work){
    for(k in inv.items){ if(!Object.prototype.hasOwnProperty.call(inv.items,k)) continue;
      if(!basis[k] && !notInstalledKeys[k]){
        var io=inv.items[k];
        add("warn","invoice-only","Invoice-only charge: "+io.name,
          "Billed on the invoice at "+io.qty+" × "+fmt(io.each||0)+" = "+fmt(io.total)+", but it appears in neither the proposal nor the work record. No basis found: "+fmt(io.total)+" held back until it is explained.",io.total);
      }
    }
    for(var ok2 in invoiceOnlyFeeKeys){ if(!Object.prototype.hasOwnProperty.call(invoiceOnlyFeeKeys,ok2)) continue;
      var g2=feeGroups[ok2]; var tot2=0; g2.forEach(function(f){tot2+=f.amount;}); tot2=round2(tot2);
      add("warn","invoice-only","Invoice-only charge: "+g2[0].name,
        "Billed on the invoice at "+fmt(tot2)+(g2.length>1?" ("+g2.length+" lines)":"")+", but it appears in neither the proposal nor the work record. No basis found: "+fmt(tot2)+" held back until it is explained.",tot2);
    }
  }

  /* 7 — Retest billed but not recorded */
  var retestBilled=0; inv.retestCharges.forEach(function(r){retestBilled+=r.total;}); retestBilled=round2(retestBilled);
  var retestFlagged=false;
  if(retestBilled>0){
    if(present.work && !work.retestDone){
      add("crit","retest-not-recorded","Post-mitigation retest billed but not recorded",
        "The invoice bills "+fmt(retestBilled)+" for a post-mitigation retest. The work record "+(work.retestNotDone?"states RETEST: NOT DONE":"never records a completed retest")+". Billed with no record of the test happening: "+fmt(retestBilled)+".",retestBilled);
      retestFlagged=true;
    } else if(present.work && work.retestDone && prop.retestIncluded){
      add("warn","retest-double-billed","Retest billed even though the proposal included it",
        "The proposal states RETEST: INCLUDED, yet the invoice bills "+fmt(retestBilled)+" for it. Included work billed again: "+fmt(retestBilled)+".",retestBilled);
      retestFlagged=true;
    } else if(!present.work){
      add("warn","retest-unverified","Retest billed — completion cannot be verified",
        "The invoice bills "+fmt(retestBilled)+" for a post-mitigation retest, but there is no work record on file to confirm the test was done. $0.00 counted as disputed until the work record is produced.",0);
    }
  }

  /* 8 — Stated total vs sum of its own lines (informational, $0 disputed) */
  var invSum=chargesSum(inv);
  if(inv.statedTotal!==null && Math.abs(round2(inv.statedTotal-invSum))>0.01){
    add("warn","total-mismatch","Invoice total does not match its own lines",
      "The invoice states TOTAL: "+fmt(inv.statedTotal)+", but its own lines add to "+fmt(invSum)+". Difference: "+fmt(Math.abs(round2(inv.statedTotal-invSum)))+". Counted as $0.00 disputed here — the line-by-line findings above already cover the money — but the invoice should be re-issued with a total that matches its lines.",0);
  }

  var disputed=0, hasCrit=false, hasWarn=false;
  findings.forEach(function(f){ disputed+=f.amount; if(f.sev==="crit")hasCrit=true; if(f.sev==="warn")hasWarn=true; });
  disputed=round2(disputed);

  var verdict, cls, why;
  if(missing.length===1 && count===2){
    verdict="PAY WITH FIXES"; cls="warn";
    add("warn","missing-document","Missing document: "+missing[0],
      "Only two of the three documents were pasted. Without the "+missing[0]+", "+(missing[0]==="Work Record"?"installed quantities, hours worked, and retest completion cannot be verified against what was billed":"one side of the comparison is missing")+". Produce the "+missing[0]+" and re-run the audit before treating this bill as fully checked.",0);
    why="Two documents agree as far as they go, but the "+missing[0]+" is missing, so the cross-check cannot be completed.";
    disputed=round2(findings.reduce(function(s,f){return s+f.amount;},0));
    if(disputed>=250 || findings.some(function(f){return f.type==="uncredited-deposit";})){
      verdict="DO NOT PAY YET"; cls="bad";
      why="Even with the "+missing[0]+" missing, the two documents on file already show "+fmt(disputed)+" in provable overcharges. Hold that amount — and get the "+missing[0]+" — before paying.";
    }
  } else if(disputed>0 && (hasCrit || disputed>=100)){
    verdict="DO NOT PAY YET"; cls="bad";
    why="The three documents disagree by "+fmt(disputed)+". Hold back the disputed total below and have the invoice corrected before paying it in full.";
  } else if(disputed>0 || hasWarn){
    verdict="PAY WITH FIXES"; cls="warn";
    why=disputed>0?("Small disagreements totalling "+fmt(disputed)+" need correcting, but nothing here blocks payment of the undisputed balance once the fixes are agreed in writing.")
                  :"No money is disputed, but the warnings below should be cleared up in writing before this bill is treated as final.";
  } else {
    verdict="SAFE TO PAY"; cls="ok";
    why="All three documents agree: every billed quantity matches what the work record says was installed, labor matches hours × rate, the deposit is credited, and there are no duplicate, unexplained, or unrecorded charges.";
    add("good","all-clear","No discrepancies found",
      "Quantities, labor, deposit, fees, and retest all reconcile across the proposal, the work record, and the final invoice. Disputed total: $0.00.",0);
  }
  return {verdict:verdict,cls:cls,disputed:disputed,findings:findings,missing:missing,present:present,why:why,
    docs:{proposal:prop,work:work,invoice:inv},parseable:true};
}

/* ---------- rendering ---------- */
var lastResult=null, lastInputs=null;
function docStatLine(doc,present){
  if(!present) return "Nothing pasted yet.";
  var n=0,k; for(k in doc.items) if(Object.prototype.hasOwnProperty.call(doc.items,k)) n++;
  var bits=[];
  bits.push(n+" item"+(n===1?"":"s"));
  bits.push(doc.fees.length+" fee"+(doc.fees.length===1?"":"s"));
  if(doc.labor) bits.push("labor recorded");
  if(doc.retestCharges.length) bits.push("retest charge");
  if(doc.statedTotal!==null) bits.push("stated total "+fmt(doc.statedTotal));
  if(doc.unparsed) bits.push(doc.unparsed+" line"+(doc.unparsed===1?"":"s")+" not in the format (ignored)");
  return bits.join(" · ");
}
function render(res, inputs){
  lastResult=res; lastInputs=inputs;
  $("results").classList.remove("hidden");
  var vb=$("verdictBox"); vb.className="verdict "+res.cls;
  $("verdictWord").textContent=res.verdict;
  if(res.parseable){
    $("sumLine").innerHTML="Total disputed — hold back until fixed: <span class=\"amt\">"+esc(fmt(res.disputed))+"</span>";
  } else {
    $("sumLine").innerHTML="Total disputed: <span class=\"amt\">$0.00</span> — nothing could be compared yet.";
  }
  $("verdictWhy").textContent=res.why;
  var cov="<h3>Documents compared</h3><p>";
  cov+=["proposal","work","invoice"].map(function(k){
    var label={proposal:"Proposal",work:"Work Record",invoice:"Final Invoice"}[k];
    return res.present[k]?("<strong>"+label+":</strong> pasted"):("<strong>"+label+":</strong> MISSING");
  }).join(" · ")+"</p>";
  $("coverage").innerHTML=cov;
  var fh="";
  if(res.findings.length===0){ fh="<p>No findings — see the verdict above.</p>"; }
  res.findings.forEach(function(f){
    var cls=f.sev==="crit"?"crit":(f.sev==="good"?"good":"warnf");
    var tag=f.sev==="crit"?"Hold back":(f.sev==="good"?"Clear":"Fix");
    fh+="<div class=\"finding "+cls+"\"><div class=\"ftitle\">"+esc(f.title)+" — <span class=\"famt\">"+esc(fmt(f.amount))+"</span> <span class=\"small\">("+tag+")</span></div><div class=\"fdetail\">"+esc(f.detail)+"</div></div>";
  });
  $("findings").innerHTML=fh;
  var rows=[["Proposal",res.docs.proposal],["Work Record",res.docs.work],["Final Invoice",res.docs.invoice]];
  var th="<table><tr><th>Document</th><th>Sum of its lines</th><th>Stated TOTAL</th><th>Notes</th></tr>";
  rows.forEach(function(r){
    var d=r[1];
    var notes=[];
    if(d.depositPaid!==null) notes.push("Deposit paid "+fmt(d.depositPaid));
    if(d.depositCredit!==null) notes.push("Deposit credit "+fmt(d.depositCredit));
    if(d.retestDone) notes.push("Retest: DONE");
    if(d.retestNotDone) notes.push("Retest: NOT DONE");
    if(d.retestIncluded) notes.push("Retest: INCLUDED");
    if(r[0]==="Final Invoice" && d.statedTotal!==null){
      var due=round2(d.statedTotal-(d.depositCredit||0));
      notes.push("Balance due per invoice (TOTAL − deposit credit): "+fmt(due));
    }
    th+="<tr><td><strong>"+r[0]+"</strong></td><td class=\"num\">"+fmt(chargesSum(d))+"</td><td class=\"num\">"+(d.statedTotal!==null?fmt(d.statedTotal):"—")+"</td><td>"+esc(notes.join(" · ")||"—")+"</td></tr>";
  });
  th+="</table>";
  $("totalsTable").innerHTML=th;
  $("statProposal").textContent=docStatLine(res.docs.proposal,res.present.proposal);
  $("statWork").textContent=docStatLine(res.docs.work,res.present.work);
  $("statInvoice").textContent=docStatLine(res.docs.invoice,res.present.invoice);
}
function runAudit(){
  var inputs={proposal:$("docProposal").value,work:$("docWork").value,invoice:$("docInvoice").value};
  render(audit(inputs.proposal,inputs.work,inputs.invoice),inputs);
  $("results").scrollIntoView({behavior:"smooth",block:"start"});
}
function reportText(res){
  var L=[];
  L.push("J-Dawgs Radon Mitigation Proposal, Work Record & Final Invoice Consistency Auditor — Audit Report");
  L.push("Verdict: "+res.verdict);
  L.push("Total disputed (hold back until fixed): "+fmt(res.disputed));
  L.push("Why: "+res.why);
  L.push("Documents: "+["proposal","work","invoice"].map(function(k){var label={proposal:"Proposal",work:"Work Record",invoice:"Final Invoice"}[k];return label+" "+(res.present[k]?"pasted":"MISSING");}).join(" · "));
  L.push("");
  L.push("Findings:");
  if(res.findings.length===0) L.push("- None.");
  res.findings.forEach(function(f,i){
    L.push((i+1)+". "+f.title+" — "+fmt(f.amount));
    L.push("   "+f.detail);
  });
  L.push("");
  L.push("Document totals (sum of lines / stated TOTAL):");
  [["Proposal",res.docs.proposal],["Work Record",res.docs.work],["Final Invoice",res.docs.invoice]].forEach(function(r){
    L.push("- "+r[0]+": "+fmt(chargesSum(r[1]))+" / "+(r[1].statedTotal!==null?fmt(r[1].statedTotal):"not stated"));
  });
  L.push("");
  L.push("Scope: text cross-check of pasted documents only. Not a radon measurement or safety certification.");
  return L.join("\n");
}
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-radon-mitigation-proposal-work-record-final-invoice-consistency-auditortm',
  name: 'J-Dawgs Radon Mitigation Proposal, Work Record & Final Invoice Consistency Auditor',
  description: 'Cross-checks a radon mitigation proposal vs work record vs final invoice into one pay verdict with arithmetic shown.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
