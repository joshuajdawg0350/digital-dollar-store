'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Water Heater Installation Estimate, Work Record & Final Invoice Consistency Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the analyze function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Samples (invented numbers, clearly samples) ---------- */

      var SAMPLE_BAD = {
        est:
"APPROVED ESTIMATE — SAMPLE DOCUMENT (invented numbers)\n" +
"QuickFlow Plumbing — Estimate #E-2077\n" +
"\n" +
"Heater: Bradford White 40 gallon gas tank water heater, Model RG240T6N\n" +
"Unit price: $980.00\n" +
"Labor: 3 hours at $110.00 per hour — $330.00\n" +
"Permit fee: $85.00\n" +
"Expansion tank (to be installed): $110.00\n" +
"Drain pan (to be installed): $40.00\n" +
"Deposit paid by customer: $400.00\n" +
"Estimate total: $1,545.00",
        rec:
"INSTALLER WORK RECORD — SAMPLE DOCUMENT (invented numbers)\n" +
"Job #2077 — install completed\n" +
"\n" +
"Unit installed: Bradford White 40 gallon gas tank water heater, Model RG240T6N\n" +
"Labor: 3.0 hours on site\n" +
"Expansion tank installed: yes\n" +
"Drain pan installed: NO — existing pan reused\n" +
"Permit pulled: yes\n" +
"Deposit received from customer: $400.00",
        inv:
"FINAL INVOICE — SAMPLE DOCUMENT (invented numbers)\n" +
"QuickFlow Plumbing — Invoice #INV-2077\n" +
"\n" +
"Bradford White 50 gallon gas tank water heater, Model RG250T6N — $1,240.00\n" +
"Labor — $495.00\n" +
"Permit fee — $85.00\n" +
"Permit processing fee — $85.00\n" +
"Expansion tank — $110.00\n" +
"Drain pan — $40.00\n" +
"Disposal fee — $65.00\n" +
"Total: $2,120.00"
      };

      var SAMPLE_GOOD = {
        est:
"APPROVED ESTIMATE — SAMPLE DOCUMENT (invented numbers)\n" +
"Plumb-Right Heating & Air — Estimate #E-1042\n" +
"\n" +
"Heater: Rheem Performance 50 gallon gas tank water heater, Model RG250T6N\n" +
"Unit price: $1,150.00\n" +
"Labor: 4 hours at $95.00 per hour — $380.00\n" +
"Permit fee: $75.00\n" +
"Expansion tank (to be installed): $120.00\n" +
"Drain pan (to be installed): $45.00\n" +
"Venting materials (to be installed): $85.00\n" +
"Deposit paid by customer: $300.00\n" +
"Estimate total: $1,855.00",
        rec:
"INSTALLER WORK RECORD — SAMPLE DOCUMENT (invented numbers)\n" +
"Job #1042 — install completed\n" +
"\n" +
"Unit installed: Rheem Performance 50 gallon gas tank water heater, Model RG250T6N\n" +
"Labor: 4.0 hours on site\n" +
"Expansion tank installed: yes\n" +
"Drain pan installed: yes\n" +
"New venting installed: yes\n" +
"Permit pulled: yes, city permit #P-2214\n" +
"Deposit received from customer: $300.00",
        inv:
"FINAL INVOICE — SAMPLE DOCUMENT (invented numbers)\n" +
"Plumb-Right Heating & Air — Invoice #INV-1042\n" +
"\n" +
"Rheem Performance 50 gallon gas tank water heater, Model RG250T6N — $1,150.00\n" +
"Labor (4 hours at $95.00/hr) — $380.00\n" +
"Permit fee — $75.00\n" +
"Expansion tank — $120.00\n" +
"Drain pan — $45.00\n" +
"Venting materials — $85.00\n" +
"Subtotal: $1,855.00\n" +
"Less deposit paid: -$300.00\n" +
"Total due: $1,555.00"
      };

      /* ---------- Helpers ---------- */

      function $(id){ return document.getElementById(id); }
      function fmt(n){
        var sign = n < 0 ? "-" : "";
        return sign + "$" + Math.abs(n).toLocaleString("en-US",{minimumFractionDigits:2, maximumFractionDigits:2});
      }
      function fmtSigned(n){ return (n > 0 ? "+" : "") + fmt(n); }
      function round2(n){ return Math.round(n * 100) / 100; }

      function lineAmounts(line){
        var out = [], re = /-?\$\s?\d[\d,]*(?:\.\d{2})?/g, m;
        while ((m = re.exec(line)) !== null){
          var v = parseFloat(m[0].replace(/[$,\s]/g, ""));
          if (!isNaN(v)) out.push(v);
        }
        return out;
      }
      function lastAmount(line){
        var a = lineAmounts(line);
        return a.length ? a[a.length - 1] : null;
      }
      function linesWith(text, re){
        return text.split(/\r?\n/).filter(function(l){ return re.test(l); });
      }

      var BRANDS = ["Bradford White","A.O. Smith","AO Smith","Rheem","Ruud","State Water Heaters",
        "Kenmore","Whirlpool","Richmond","Navien","Rinnai","Noritz","Bosch","Takagi",
        "EcoSmart","Stiebel Eltron","Lochinvar","American Water Heaters"];

      var ADDONS = [
        { label:"Expansion tank", re:/expansion tank/i },
        { label:"Drain pan",      re:/(drain\s*pan|safety pan|\bpan\b)/i },
        { label:"Venting",        re:/vent/i }
      ];

      /* ---------- Per-document parsing ---------- */

      function parseDoc(text){
        if (!text || !text.trim()) return null;
        var d = { text:text, lower:text.toLowerCase(), lines:text.split(/\r?\n/) };

        var gm = text.match(/(\d{2,3})\s*-?\s*(?:gallon|gal)\b/i);
        d.gallons = gm ? parseInt(gm[1], 10) : null;
        d.tankless = /tankless/i.test(text);
        d.type = d.tankless ? "tankless" : (d.gallons !== null ? "tank" : null);

        d.fuel = null;
        var fuelLines = d.lines.filter(function(l){ return /(water heater|heater|gallon|tankless)/i.test(l); });
        var fuelRe = /\b(natural\s+gas|gas|electric|propane)\b/i, fm = null, i;
        for (i = 0; i < fuelLines.length && !fm; i++) fm = fuelLines[i].match(fuelRe);
        if (!fm) fm = text.match(fuelRe);
        if (fm) d.fuel = fm[1].toLowerCase().replace("natural ", "");

        d.brand = null;
        for (i = 0; i < BRANDS.length; i++){
          if (d.lower.indexOf(BRANDS[i].toLowerCase()) !== -1){ d.brand = BRANDS[i]; break; }
        }
        var mm = text.match(/model\s*(?:no\.?|number|#)?\s*:?\s*([A-Za-z0-9][A-Za-z0-9\-]{2,})/i);
        d.model = mm ? mm[1].toUpperCase() : null;

        d.unitPrice = null;
        var up = linesWith(text, /unit price/i);
        for (i = 0; i < up.length && d.unitPrice === null; i++){ var a = lastAmount(up[i]); if (a !== null) d.unitPrice = a; }
        if (d.unitPrice === null){
          var hl = d.lines.filter(function(l){ return /(water heater|heater)/i.test(l) && !/labor|permit/i.test(l); });
          for (i = 0; i < hl.length && d.unitPrice === null; i++){ var b = lastAmount(hl[i]); if (b !== null) d.unitPrice = b; }
        }

        d.laborCharged = null;
        var ll = linesWith(text, /labor/i).filter(function(l){ return !/total/i.test(l); });
        if (ll.length){
          var sum = 0, any = false;
          ll.forEach(function(l){ var v = lastAmount(l); if (v !== null){ sum += v; any = true; } });
          if (any) d.laborCharged = round2(sum);
        }

        d.permitLines = linesWith(text, /permit/i).filter(function(l){ return lineAmounts(l).length > 0; });
        d.permitTotal = null;
        if (d.permitLines.length){
          d.permitTotal = round2(d.permitLines.reduce(function(s, l){ return s + (lastAmount(l) || 0); }, 0));
        }
        d.hasPermitMention = /permit/i.test(text);

        d.total = null;
        var due = d.lines.filter(function(l){ return /(total due|amount due|balance due|grand total)/i.test(l) && lineAmounts(l).length; });
        if (due.length) d.total = lastAmount(due[due.length - 1]);
        if (d.total === null){
          var tl = d.lines.filter(function(l){ return /total/i.test(l) && !/subtotal/i.test(l) && lineAmounts(l).length; });
          if (tl.length) d.total = lastAmount(tl[tl.length - 1]);
        }
        return d;
      }

      function findRate(docs){
        var pats = [
          /\$\s?([\d,]+(?:\.\d{2})?)\s*(?:per\s+hour|\/\s*hr\b|an\s+hour)/i,
          /(?:hourly\s+rate|rate\s+of|rate)\D{0,24}\$\s?([\d,]+(?:\.\d{2})?)/i
        ];
        for (var k = 0; k < docs.length; k++){
          if (!docs[k]) continue;
          for (var p = 0; p < pats.length; p++){
            var m = docs[k].text.match(pats[p]);
            if (m) return parseFloat(m[1].replace(/,/g, ""));
          }
        }
        return null;
      }
      function findHours(doc){
        if (!doc) return null;
        var m = doc.text.match(/(\d+(?:\.\d+)?)\s*(?:hours|hrs)\b/i);
        return m ? parseFloat(m[1]) : null;
      }
      function depositPaidIn(doc){
        if (!doc) return null;
        var best = null;
        linesWith(doc.text, /deposit/i).forEach(function(l){
          lineAmounts(l).forEach(function(v){ if (v > 0 && (best === null || v > best)) best = v; });
        });
        return best;
      }
      function invoiceDepositCredit(inv){
        if (!inv) return 0;
        var credit = 0;
        inv.lines.forEach(function(l){
          var amts = lineAmounts(l);
          if (!amts.length) return;
          if (/deposit|credit|discount/i.test(l)){
            amts.forEach(function(v){ credit += Math.abs(v); });
          } else {
            amts.forEach(function(v){ if (v < 0) credit += Math.abs(v); });
          }
        });
        return round2(credit);
      }

      /* ---------- The audit ---------- */

      var DOCNAMES = ["approved estimate", "installer's work record", "final invoice"];

      function analyze(){
        var est = parseDoc($("doc-est").value);
        var rec = parseDoc($("doc-rec").value);
        var inv = parseDoc($("doc-inv").value);
        var docs = [est, rec, inv];
        var present = docs.map(function(d){ return !!d; });
        var presentCount = present.filter(Boolean).length;
        var missing = DOCNAMES.filter(function(_, i){ return !present[i]; });

        updateDetected("det-est", est);
        updateDetected("det-rec", rec);
        updateDetected("det-inv", inv);

        var findings = [];
        function add(check, status, title, detail){ findings.push({ check:check, status:status, title:title, detail:detail || "" }); }

        var figures = {};

        /* Documents present */
        if (presentCount < 2){
          add("documents", "info", "Not enough documents to compare",
            presentCount === 0
              ? "Nothing is pasted yet. Paste at least two of the three documents — estimate, work record, invoice — to run a cross-check."
              : "Only one document is pasted (" + DOCNAMES[present.indexOf(true)] + "). A cross-check needs at least two; missing: " + missing.join(", ") + ".");
        } else if (presentCount === 2){
          add("documents", "info", "Two of three documents pasted",
            "Missing: the " + missing[0] + ". Checks that need it are marked “not checked,” and the verdict is capped at PAY WITH FIXES — a two-document check can never grade SAFE TO PAY.");
        } else {
          add("documents", "pass", "All three documents pasted", "Estimate, work record, and invoice are all in — every check below could run.");
        }

        if (presentCount >= 2){

          /* --- Heater identity --- */
          var attrs = [
            { key:"gallons", label:"Tank size", show:function(v){ return v + " gallon"; } },
            { key:"fuel",    label:"Fuel type", show:function(v){ return v; } },
            { key:"type",    label:"Heater type", show:function(v){ return v === "tankless" ? "tankless" : "tank (storage)"; } },
            { key:"brand",   label:"Brand", show:function(v){ return v; } },
            { key:"model",   label:"Model", show:function(v){ return v; } }
          ];
          var identityProblems = [], identityNotes = [];
          attrs.forEach(function(at){
            var stated = [];
            docs.forEach(function(d, i){ if (d && d[at.key] !== null && d[at.key] !== undefined) stated.push({ doc:DOCNAMES[i], val:d[at.key], idx:i }); });
            if (stated.length < 2) return;
            var distinct = {};
            stated.forEach(function(s){ distinct[String(s.val).toLowerCase()] = true; });
            if (Object.keys(distinct).length > 1){
              var parts = stated.map(function(s){ return s.doc + " says " + at.show(s.val); }).join("; ");
              var invStated = stated.filter(function(s){ return s.idx === 2; });
              var recStated = stated.filter(function(s){ return s.idx === 1; });
              var billedVsRecorded = invStated.length && recStated.length &&
                String(invStated[0].val).toLowerCase() !== String(recStated[0].val).toLowerCase();
              identityProblems.push({
                blocker: !!billedVsRecorded || invStated.length > 0,
                text: at.label + " does not agree — " + parts + "." +
                  (billedVsRecorded ? " The invoice bills a different unit than the work record says was installed: that is a billed upgrade or downgrade, and it blocks payment." : "")
              });
            } else {
              identityNotes.push(at.label.toLowerCase() + " " + at.show(stated[0].val));
            }
          });
          if (identityProblems.length){
            identityProblems.forEach(function(p){
              add("identity", p.blocker ? "blocker" : "issue", "Heater identity mismatch", p.text);
            });
          } else if (identityNotes.length){
            add("identity", "pass", "Heater identity agrees", "Every document that states it agrees on: " + identityNotes.join(" · ") + ".");
          } else {
            add("identity", "info", "Heater identity not checked", "No two documents state the same heater detail (size, fuel, type, brand, or model), so identity could not be cross-checked.");
          }

          /* --- Unit price --- */
          figures.unitPriceEstimate = est ? est.unitPrice : null;
          figures.unitPriceInvoice = inv ? inv.unitPrice : null;
          if (est && inv && est.unitPrice !== null && inv.unitPrice !== null){
            var ud = round2(inv.unitPrice - est.unitPrice);
            figures.unitPriceDiff = ud;
            if (Math.abs(ud) <= 0.01){
              add("unit-price", "pass", "Unit price matches the estimate",
                "Invoice unit price " + fmt(inv.unitPrice) + " = estimate unit price " + fmt(est.unitPrice) + ". Difference: " + fmt(0) + ".");
            } else {
              add("unit-price", "issue", "Unit price differs from the estimate",
                "Invoice unit price " + fmt(inv.unitPrice) + " − estimate unit price " + fmt(est.unitPrice) + " = " + fmtSigned(ud) + ". The customer approved " + fmt(est.unitPrice) + " for the heater; the extra " + fmt(Math.abs(ud)) + " was never in the approved estimate.");
            }
          } else {
            add("unit-price", "info", "Unit price not checked",
              "A heater unit price could not be read from " + (!est || est.unitPrice === null ? "the estimate" : "the invoice") + ", so the billed unit price could not be compared.");
          }

          /* --- Labor --- */
          var rate = findRate([inv, est, rec]);
          var hours = findHours(rec);
          if (hours === null) hours = findHours(est);
          var laborCharged = inv ? inv.laborCharged : null;
          figures.hourlyRate = rate; figures.recordedHours = hours; figures.laborCharged = laborCharged;
          var laborExpected = (rate !== null && hours !== null) ? round2(rate * hours) : null;
          figures.laborExpected = laborExpected;
          if (laborCharged !== null && laborExpected !== null){
            var ld = round2(laborCharged - laborExpected);
            figures.laborDiff = ld;
            var arith = "Recorded time " + hours + " hrs × stated rate " + fmt(rate) + "/hr = " + fmt(laborExpected) + " expected; invoice charges " + fmt(laborCharged) + ".";
            if (Math.abs(ld) <= 1){
              add("labor", "pass", "Labor math checks out", arith + " Difference " + fmt(Math.abs(ld)) + " — within a $1.00 rounding allowance.");
            } else if (ld > 0){
              add("labor", "issue", "Labor charged above the recorded time", arith + " Overcharge: " + fmt(laborCharged) + " − " + fmt(laborExpected) + " = " + fmt(ld) + ".");
            } else {
              add("labor", "pass", "Labor charged below the recorded time", arith + " The invoice charges " + fmt(Math.abs(ld)) + " less than the recorded time supports — in the customer's favor.");
            }
          } else if (laborCharged !== null && est && est.laborCharged !== null){
            var ld2 = round2(laborCharged - est.laborCharged);
            if (Math.abs(ld2) <= 0.01){
              add("labor", "pass", "Labor matches the estimate (hours/rate not stated)",
                "Invoice labor " + fmt(laborCharged) + " = estimate labor " + fmt(est.laborCharged) + ". Recorded hours or an hourly rate were not stated, so the hours × rate check could not run.");
            } else {
              add("labor", "issue", "Labor differs from the estimate (hours/rate not stated)",
                "Invoice labor " + fmt(laborCharged) + " − estimate labor " + fmt(est.laborCharged) + " = " + fmtSigned(ld2) + ". Recorded hours or an hourly rate were not stated, so the difference cannot be tied to time on site.");
            }
          } else {
            add("labor", "info", "Labor not checked",
              "Labor could not be verified: " +
              (laborCharged === null ? "no labor charge was read from the invoice" : "the recorded hours or the stated hourly rate is missing") + ".");
          }

          /* --- Permit --- */
          var permitExtra = 0, permitDiffForDelta = 0;
          if (inv && inv.permitTotal !== null){
            var estPermit = est ? est.permitTotal : null;
            if (inv.permitLines.length >= 2){
              var allowed = estPermit !== null ? estPermit : (lastAmount(inv.permitLines[0]) || 0);
              permitExtra = round2(inv.permitTotal - allowed);
              permitDiffForDelta = estPermit !== null ? round2(inv.permitTotal - estPermit) : permitExtra;
              add("permit", "issue", "Permit fee charged " + inv.permitLines.length + " times",
                "Invoice permit lines: " + inv.permitLines.map(function(l){ return fmt(lastAmount(l) || 0); }).join(" + ") + " = " + fmt(inv.permitTotal) +
                ". One permit fee of " + fmt(allowed) + " is what the paperwork supports — extra charged: " + fmt(inv.permitTotal) + " − " + fmt(allowed) + " = " + fmt(permitExtra) + ".");
            } else if (!((est && est.hasPermitMention) || (rec && rec.hasPermitMention))){
              permitDiffForDelta = inv.permitTotal;
              add("permit", "issue", "Permit fee on the invoice, nowhere else",
                "The invoice charges a permit fee of " + fmt(inv.permitTotal) + ", but neither the estimate nor the work record mentions a permit at all. A fee with no paper trail in either other document needs an explanation before it is paid.");
            } else if (estPermit !== null && Math.abs(round2(inv.permitTotal - estPermit)) > 0.01){
              permitDiffForDelta = round2(inv.permitTotal - estPermit);
              add("permit", "issue", "Permit fee differs from the estimate",
                "Invoice permit fee " + fmt(inv.permitTotal) + " − estimate permit fee " + fmt(estPermit) + " = " + fmtSigned(permitDiffForDelta) + ".");
            } else {
              add("permit", "pass", "Permit fee checks out",
                "One permit charge of " + fmt(inv.permitTotal) + " on the invoice" + (estPermit !== null ? ", matching the estimate's " + fmt(estPermit) : ", and a permit is mentioned in the other paperwork") + ".");
            }
          } else if (inv){
            add("permit", "pass", "No permit fee billed", "The invoice carries no permit charge, so there is no permit fee to double-charge or explain.");
          } else {
            add("permit", "info", "Permit not checked", "No invoice is pasted, so permit charges could not be checked.");
          }
          figures.permitExtra = permitExtra;

          /* --- Add-on items billed vs installed --- */
          var addonFindings = 0;
          ADDONS.forEach(function(item){
            if (!inv) return;
            var billedLines = inv.lines.filter(function(l){ return item.re.test(l) && lineAmounts(l).length && !/total/i.test(l); });
            if (!billedLines.length) return;
            var billed = round2(billedLines.reduce(function(s, l){ return s + (lastAmount(l) || 0); }, 0));
            if (!rec){
              add("addons", "info", item.label + " billed, installation not checked",
                "The invoice bills " + fmt(billed) + " for " + item.label.toLowerCase() + ", but no work record is pasted to confirm it was installed.");
              addonFindings++;
              return;
            }
            var recLines = rec.lines.filter(function(l){ return item.re.test(l); });
            var neg = recLines.some(function(l){ return /(\bno\b|not installed|not replaced|reused|existing|skipped|declined)/i.test(l); });
            if (!recLines.length){
              add("addons", "issue", item.label + " billed but not recorded as installed",
                "The invoice bills " + fmt(billed) + " for " + item.label.toLowerCase() + ", and the work record never mentions it. Billed work with no record of installation: " + fmt(billed) + " at risk.");
              addonFindings++;
            } else if (neg){
              add("addons", "issue", item.label + " billed but the record says it was not installed",
                "The invoice bills " + fmt(billed) + " for " + item.label.toLowerCase() + ", while the work record states it was not installed / the existing one was reused. Charge to remove: " + fmt(billed) + ".");
              addonFindings++;
            } else {
              add("addons", "pass", item.label + " billed and recorded as installed",
                "Invoice bills " + fmt(billed) + "; the work record confirms " + item.label.toLowerCase() + " was installed.");
              addonFindings++;
            }
          });
          if (!addonFindings){
            add("addons", "info", "No add-on items billed",
              "No expansion tank, drain pan, or venting line was read from the invoice, so there is nothing billed to match against the work record.");
          }

          /* --- Deposit credit (BLOCKER) --- */
          var depEst = depositPaidIn(est), depRec = depositPaidIn(rec);
          var depositPaid = Math.max(depEst || 0, depRec || 0);
          var credit = invoiceDepositCredit(inv);
          figures.depositPaid = depositPaid || null; figures.depositCredit = inv ? credit : null;
          if (depositPaid > 0 && inv){
            if (credit >= depositPaid - 0.01){
              add("deposit", "pass", "Deposit credited on the invoice",
                "Deposit documented as paid: " + fmt(depositPaid) + ". Credit on the invoice: " + fmt(credit) + ". " + fmt(depositPaid) + " − " + fmt(credit) + " = " + fmt(round2(depositPaid - credit)) + " uncredited — the deposit is fully accounted for.");
            } else {
              add("deposit", "blocker", "Deposit paid but not credited on the invoice",
                "The " + (depEst ? "estimate" : "work record") + (depEst && depRec ? " and work record show" : " shows") +
                " a deposit paid of " + fmt(depositPaid) + ", but the invoice credits only " + fmt(credit) + ". Missing credit: " +
                fmt(depositPaid) + " − " + fmt(credit) + " = " + fmt(round2(depositPaid - credit)) +
                ". Paying this invoice as written charges the deposit twice.");
            }
          } else if (depositPaid > 0){
            add("deposit", "info", "Deposit noted, invoice not pasted",
              "A deposit of " + fmt(depositPaid) + " is documented as paid, but with no invoice pasted there is nothing to check the credit against.");
          } else {
            add("deposit", "pass", "No deposit in play", "Neither the estimate nor the work record shows a deposit paid, so there is no deposit credit to look for on the invoice.");
          }

          /* --- Invoice-only fees --- */
          var invoiceOnly = [];
          if (inv){
            var otherText = ((est ? est.lower : "") + "\n" + (rec ? rec.lower : ""));
            var stop = { fee:1, fees:1, charge:1, charges:1, cost:1, flat:1, rate:1, item:1, items:1, service:1, services:1, total:1, misc:1, each:1 };
            inv.lines.forEach(function(l){
              var amt = lastAmount(l);
              if (amt === null || amt <= 0) return;
              if (/total|subtotal|balance|amount due|tax|deposit|credit|discount|labor|permit/i.test(l)) return;
              if (/(water heater|heater|unit price)/i.test(l)) return;
              if (ADDONS.some(function(it){ return it.re.test(l); })) return;
              var label = l.replace(/-?\$\s?\d[\d,]*(?:\.\d{2})?/g, " ").toLowerCase();
              var words = (label.match(/[a-z]{4,}/g) || []).filter(function(w){ return !stop[w]; });
              var seen = words.some(function(w){ return otherText.indexOf(w) !== -1; });
              if (words.length && !seen){
                invoiceOnly.push({ label:l.replace(/\s+/g, " ").trim(), amount:amt });
              }
            });
          }
          figures.invoiceOnlyFees = invoiceOnly;
          var feesSum = round2(invoiceOnly.reduce(function(s, f){ return s + f.amount; }, 0));
          if (inv && invoiceOnly.length){
            add("invoice-only-fees", "issue", invoiceOnly.length + " invoice-only fee" + (invoiceOnly.length > 1 ? "s" : "") + " — in neither other document",
              invoiceOnly.map(function(f){ return "“" + f.label + "”"; }).join("; ") +
              ". Total invoice-only charges: " + invoiceOnly.map(function(f){ return fmt(f.amount); }).join(" + ") + " = " + fmt(feesSum) +
              ". None of these words appear in the estimate or the work record — each one needs an explanation before it is paid.");
          } else if (inv){
            add("invoice-only-fees", "pass", "No invoice-only fees",
              "Every billed line on the invoice traces back to wording in the estimate or the work record. Invoice-only charges: " + fmt(0) + ".");
          } else {
            add("invoice-only-fees", "info", "Invoice-only fees not checked", "No invoice is pasted.");
          }

          /* --- Invoice math: re-add the lines --- */
          var computedTotal = null;
          if (inv && inv.total !== null){
            var itemsSum = 0;
            inv.lines.forEach(function(l){
              var a = lastAmount(l);
              if (a === null) return;
              if (/subtotal|total|balance|amount due/i.test(l)) return;
              if (/deposit|credit|discount/i.test(l)) return;
              if (a < 0) return;
              itemsSum += a;
            });
            itemsSum = round2(itemsSum);
            computedTotal = round2(itemsSum - credit);
            figures.invoiceItemsSum = itemsSum; figures.invoiceComputedTotal = computedTotal; figures.invoiceStatedTotal = inv.total;
            var gap = round2(inv.total - computedTotal);
            figures.invoiceTotalGap = gap;
            var sumStr = "Line items re-added: " + fmt(itemsSum) + (credit > 0 ? " − deposit credit " + fmt(credit) : "") + " = " + fmt(computedTotal) + " computed, against a stated invoice total of " + fmt(inv.total) + ".";
            if (Math.abs(gap) <= 0.01){
              add("invoice-math", "pass", "Invoice math adds up", sumStr + " Gap: " + fmt(0) + ".");
            } else {
              add("invoice-math", "issue", "Invoice total does not match its own line items",
                sumStr + " Gap: " + fmt(inv.total) + " − " + fmt(computedTotal) + " = " + fmt(gap) + " unexplained by the invoice's own lines.");
            }
          } else if (inv){
            add("invoice-math", "info", "Invoice math not checked", "No stated invoice total was read, so the line items could not be re-added against it.");
          } else {
            add("invoice-math", "info", "Invoice math not checked", "No invoice is pasted.");
          }

          /* --- Total delta: invoice vs estimate --- */
          figures.estimateTotal = est ? est.total : null;
          figures.invoiceTotal = inv ? inv.total : null;
          if (est && inv && est.total !== null && inv.total !== null){
            var delta = round2(inv.total - est.total);
            var unitDiff = figures.unitPriceDiff || 0;
            var laborDiff = (figures.laborDiff !== undefined && figures.laborDiff !== null) ? figures.laborDiff
              : (laborCharged !== null && est.laborCharged !== null ? round2(laborCharged - est.laborCharged) : 0);
            var explained = round2(unitDiff + laborDiff + permitDiffForDelta + feesSum - credit);
            var unexplained = round2(delta - explained);
            figures.totalDelta = delta; figures.deltaExplained = explained; figures.deltaUnexplained = unexplained;
            var dstr = "Invoice total " + fmt(inv.total) + " − estimate total " + fmt(est.total) + " = " + fmtSigned(delta) + " difference. Explained by: unit price " + fmtSigned(unitDiff) +
              ", labor " + fmtSigned(laborDiff) + ", permit " + fmtSigned(permitDiffForDelta) + ", invoice-only fees " + fmtSigned(feesSum) +
              (credit > 0 ? ", deposit credit −" + fmt(credit).slice(0) : "") + " — total explained " + fmtSigned(explained) + ".";
            if (Math.abs(unexplained) <= 1){
              add("total-delta", "pass", "Total difference fully explained", dstr + " Unexplained remainder: " + fmt(Math.abs(unexplained)) + " — within a $1.00 rounding allowance.");
            } else {
              add("total-delta", "issue", "Total difference not fully explained",
                dstr + " Unexplained remainder: " + fmtSigned(delta) + " − " + fmtSigned(explained) + " = " + fmtSigned(unexplained) + " that no check above accounts for.");
            }
          } else {
            add("total-delta", "info", "Total difference not checked",
              "A stated total could not be read from " + (!est || est.total === null ? "the estimate" : "the invoice") + ", so the invoice-vs-estimate difference could not be reconciled.");
          }
        }

        /* --- Verdict --- */
        var blockers = findings.filter(function(f){ return f.status === "blocker"; });
        var issues = findings.filter(function(f){ return f.status === "issue"; });
        var verdict, vclass, vnote;
        if (presentCount < 2){
          verdict = "NOT ENOUGH TO COMPARE"; vclass = "info";
          vnote = "Paste at least two of the three documents — the approved estimate, the installer's work record, and the final invoice — to get a pay verdict.";
        } else if (blockers.length){
          verdict = "DO NOT PAY YET"; vclass = "bad";
          vnote = blockers.length + " blocker" + (blockers.length > 1 ? "s" : "") + " found: " + blockers.map(function(b){ return b.title.toLowerCase(); }).join("; ") +
            ". A blocker means the paperwork contradicts itself on what was installed or what was already paid — settle it before any money moves.";
        } else if (issues.length){
          verdict = "PAY WITH FIXES"; vclass = "warn";
          vnote = issues.length + " fix" + (issues.length > 1 ? "es" : "") + " to settle first: " + issues.map(function(b){ return b.title.toLowerCase(); }).join("; ") +
            ". Nothing here blocks payment outright, but each item should be corrected or explained on the invoice before it is paid in full.";
        } else if (presentCount === 2){
          verdict = "PAY WITH FIXES"; vclass = "warn";
          vnote = "Everything the two pasted documents can check agrees — but the " + missing[0] + " is missing, so the verdict is capped at PAY WITH FIXES. Paste it for a full three-way check.";
        } else {
          verdict = "SAFE TO PAY"; vclass = "ok";
          vnote = "Every cross-check passed: same heater on all three documents, unit price and labor math agree, one permit fee, every billed add-on recorded as installed, the deposit is credited, no invoice-only fees, and both totals reconcile to the cent.";
        }

        return { verdict:verdict, vclass:vclass, vnote:vnote, findings:findings,
                 present:present, missing:missing, presentCount:presentCount, figures:figures };
      }

      /* ---------- Rendering ---------- */

      function describeDoc(d){
        if (!d) return "Nothing pasted yet.";
        var bits = [];
        if (d.gallons !== null) bits.push(d.gallons + " gallon");
        if (d.tankless) bits.push("tankless"); else if (d.gallons !== null) bits.push("tank");
        if (d.fuel) bits.push(d.fuel);
        if (d.brand) bits.push(d.brand);
        if (d.model) bits.push("Model " + d.model);
        if (d.unitPrice !== null) bits.push("unit " + fmt(d.unitPrice));
        if (d.total !== null) bits.push("total " + fmt(d.total));
        return bits.length ? "Read from this paste: <b>" + bits.join(" · ") + "</b>" : "Pasted — no heater details or prices recognized in it yet.";
      }
      function updateDetected(id, d){ $(id).innerHTML = describeDoc(d); }

      var CHIP = { pass:"Pass", issue:"Fix", blocker:"Blocker", info:"Not checked" };
  return { "analyze": (typeof analyze !== 'undefined' ? analyze : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "SAMPLE_BAD": (typeof SAMPLE_BAD !== 'undefined' ? SAMPLE_BAD : undefined), "SAMPLE_GOOD": (typeof SAMPLE_GOOD !== 'undefined' ? SAMPLE_GOOD : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["analyze"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-water-heater-installation-estimate-work-record-final-invoice-consistency-auditortm',
  name: 'J-Dawgs Water Heater Installation Estimate, Work Record & Final Invoice Consistency Auditor',
  description: 'Cross-checks a water heater installation estimate against the work record and final invoice into one pay verdict — unit identity, labor vs hours × rate, a permit double-charge, an uncredited deposit, and invoice-only fees, with arithmetic shown across all pastes. Every other system grades one docume',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["analyze"]) return { ok: false, output: null, summary: 'Extracted core has no analyze function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "SAMPLE_BAD": __core["SAMPLE_BAD"], "SAMPLE_GOOD": __core["SAMPLE_GOOD"] }
};
