'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Few-Shot Example Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Worked examples ---------- */

      var FLAWED_INSTRUCTION =
        "Classify each incoming support ticket into exactly one of these labels: billing, technical, or account. Reply with the label only.";

      var FLAWED_EXAMPLES =
        "Input: There is a $12 charge on my card from your company and I do not know what it is for.\n" +
        "\n" +
        "Input: The app freezes every time I try to upload a photo.\n" +
        "Output: technical\n" +
        "\n" +
        "Input: I was charged twice for my subscription this month.\n" +
        "Output: billing\n" +
        "\n" +
        "Input: My invoice lists a setup fee I never agreed to pay.\n" +
        "Output: billing\n" +
        "\n" +
        "Input: The refund for my cancelled order still has not arrived, and support closed my ticket.\n" +
        "Output: billing\n" +
        "\n" +
        "Input: I cancelled my plan last month but I was billed again this week.\n" +
        "Output: billing";

      var CLEAN_INSTRUCTION =
        "Classify each incoming support ticket into exactly one of these labels: billing, technical, or account. Reply with the label only.";

      var CLEAN_EXAMPLES =
        "Input: I was charged twice for my subscription this month.\n" +
        "Output: billing\n" +
        "\n" +
        "Input: The app crashes every time I open the settings page.\n" +
        "Output: technical\n" +
        "\n" +
        "Input: I need to change the email address on my profile.\n" +
        "Output: account\n" +
        "\n" +
        "Input: My invoice shows a fee I do not recognise.\n" +
        "Output: billing\n" +
        "\n" +
        "Input: The export button spins forever and never downloads my file.\n" +
        "Output: technical\n" +
        "\n" +
        "Input: How do I update the name shown on my account?\n" +
        "Output: account";

      /* ---------- Parsing ---------- */

      var FIELD_RE = /^\s*(input|output|label)\s*:\s*(.*)$/i;

      function parseBlocks(text){
        var raw = String(text || "").replace(/\r\n?/g, "\n");
        var chunks = raw.split(/\n[ \t]*\n/).map(function(s){ return s.trim(); }).filter(function(s){ return s.length > 0; });
        return chunks.map(function(chunk, idx){
          var lines = chunk.split("\n");
          var block = {
            n: idx + 1,
            fields: [],          // in order of appearance: {kind:'input'|'output', rawLabel, value}
            input: null, output: null,
            inputLabel: null, outputLabel: null,
            strayLines: 0
          };
          var current = null;
          lines.forEach(function(line){
            var m = line.match(FIELD_RE);
            if (m) {
              var kind = m[1].toLowerCase() === "input" ? "input" : "output";
              current = { kind: kind, rawLabel: m[1], value: m[2] };
              block.fields.push(current);
            } else if (current) {
              current.value += "\n" + line;
            } else {
              block.strayLines++;
            }
          });
          block.fields.forEach(function(f){
            f.value = f.value.replace(/\s+$/,"");
            if (f.kind === "input" && block.input === null) { block.input = f.value; block.inputLabel = f.rawLabel; }
            if (f.kind === "output" && block.output === null) { block.output = f.value; block.outputLabel = f.rawLabel; }
          });
          return block;
        });
      }

      function normText(s){
        return String(s || "").toLowerCase().replace(/\s+/g, " ").trim();
      }
      function normLabel(s){
        return normText(s).replace(/[.\s]+$/,"");
      }
      function median(nums){
        if (!nums.length) return 0;
        var a = nums.slice().sort(function(x,y){ return x - y; });
        var mid = Math.floor(a.length / 2);
        return a.length % 2 ? a[mid] : (a[mid - 1] + a[mid]) / 2;
      }
      function pct(n, d){ return d ? (Math.round(n / d * 1000) / 10) : 0; }

      /* Labels named in the instruction: quoted words, "labels: a, b, or c" lists,
         and "one of / either / choose" enumerations. Heuristic by design. */
      function instructionLabels(instruction){
        var text = String(instruction || "");
        var found = {}, out = [];
        function add(tok){
          tok = String(tok || "");
          if (tok.indexOf(":") !== -1) tok = tok.slice(tok.lastIndexOf(":") + 1);
          tok = tok.replace(/^["'“”‘’\(\[]+|["'“”‘’\)\].:;]+$/g, "").trim().toLowerCase();
          tok = tok.replace(/^(or|and|the)\s+/, "").replace(/^(or|and)\s+/, "");
          if (!tok || tok.length > 40) return;
          if (/^(the|a|an|one|exactly|only|either|label|labels|category|categories|class|classes|following|reply|respond|answer|output|input|with|and|or|of|for|to|is|are|be|as|in|on|it|that|this)$/.test(tok)) return;
          if (!found[tok]) { found[tok] = true; out.push(tok); }
        }
        var q, reQ = /["“]([^"”]{1,40})["”]/g;
        while ((q = reQ.exec(text)) !== null) add(q[1]);

        var m = text.match(/(?:labels?|categories|classes)\s*(?:are|include|includes|is|:|=)\s*([^\n.;]+)/i);
        if (m) {
          m[1].split(/\s*,\s*|\s+or\s+|\s+and\s+/).forEach(add);
        }
        var m2 = text.match(/(?:one of|either|choose(?:s|ing)?\s+(?:from|between)|classif\w*\s+as|assign)\s*:?\s*([^\n.;]+)/i);
        if (m2 && /,|\bor\b|\band\b/.test(m2[1])) {
          m2[1].split(/\s*,\s*|\s+or\s+|\s+and\s+/).forEach(add);
        }
        return out;
      }

      /* ---------- The audit ---------- */

      function audit(instruction, examplesText){
        var blocks = parseBlocks(examplesText);
        var findings = [];
        function add(sev, cat, text){ findings.push({ sev: sev, cat: cat, text: text }); }

        var labeled = blocks.filter(function(b){ return b.output !== null && normLabel(b.output) !== ""; });
        var total = blocks.length, nLab = labeled.length;

        /* --- Format consistency --- */
        blocks.forEach(function(b){
          if (b.input === null) add("blocker", "Format", "Block " + b.n + " is missing its Input line — the model gets an answer with no question to learn from.");
          if (b.output === null) add("blocker", "Format", "Block " + b.n + " is missing its Output line — an example with no output teaches nothing and breaks the pattern the model is copying.");
          if (b.strayLines > 0) add("warning", "Format", "Block " + b.n + " has " + b.strayLines + " line(s) before any Input:/Output: field — text outside the fields blurs where one field ends and the next begins.");
        });

        if (blocks.length){
          /* Field order: compare every complete block against the set's dominant
             order, so one broken or unusual block doesn't become the baseline. */
          var orderCounts = {}, dominant = null;
          blocks.forEach(function(b){
            if (b.input === null || b.output === null) return;
            var ord = b.fields.map(function(f){ return f.kind; }).join(">");
            orderCounts[ord] = (orderCounts[ord] || 0) + 1;
            if (!dominant || orderCounts[ord] > orderCounts[dominant]) dominant = ord;
          });
          if (dominant) {
            blocks.forEach(function(b){
              if (b.input === null || b.output === null) return; /* missing fields already reported as blockers */
              var ord = b.fields.map(function(f){ return f.kind; }).join(">");
              if (ord !== dominant) {
                add("warning", "Format", "Block " + b.n + " puts its fields in a different order than the rest of the set (" +
                  ord.replace(/>/g, " then ") + " vs the dominant " + dominant.replace(/>/g, " then ") +
                  "). Models copy the dominant pattern; mixed order makes the pattern ambiguous.");
              }
            });
          }

          function casingCheck(getLabel, name){
            var seen = {}, variants = [];
            blocks.forEach(function(b){
              var l = getLabel(b);
              if (l !== null && l !== undefined && !seen[l]) { seen[l] = true; variants.push(l); }
            });
            var lower = {}, clash = false;
            variants.forEach(function(v){ var k = v.toLowerCase(); if (lower[k] && lower[k] !== v) clash = true; lower[k] = v; });
            if (clash) add("warning", "Format", "The " + name + " field name appears with differing casing across blocks (" + variants.join(", ") + "). Pick one casing and use it everywhere.");
          }
          casingCheck(function(b){ return b.inputLabel; }, "Input:");
          casingCheck(function(b){ return b.outputLabel; }, "Output:/Label:");

          var kindSeen = {};
          blocks.forEach(function(b){ if (b.outputLabel) kindSeen[b.outputLabel.toLowerCase()] = true; });
          if (kindSeen["output"] && kindSeen["label"]) {
            add("warning", "Format", "Blocks mix Output: and Label: for the answer field. Both are accepted here, but the model sees two different formats — standardise on one.");
          }

          /* Output length outliers */
          if (nLab >= 3) {
            var lens = labeled.map(function(b){ return b.output.length; });
            var med = median(lens);
            if (med > 0) {
              labeled.forEach(function(b){
                if (b.output.length > 3 * med) {
                  add("warning", "Format", "Block " + b.n + "'s output is " + b.output.length + " characters — more than 3× the median output length (" + med + "). One long output among short ones teaches the model an inconsistent answer shape.");
                }
              });
            }
          }
        }

        /* --- Label distribution --- */
        var dist = {}, order = [];
        labeled.forEach(function(b){
          var l = normLabel(b.output);
          if (!(l in dist)) { dist[l] = 0; order.push(l); }
          dist[l]++;
        });
        var rawCase = {};
        labeled.forEach(function(b){
          var raw = String(b.output).trim(), k = normLabel(b.output);
          if (!rawCase[k]) rawCase[k] = {};
          rawCase[k][raw] = true;
        });
        order.forEach(function(l){
          var variants = Object.keys(rawCase[l]);
          if (variants.length > 1) {
            add("warning", "Format", "The label \"" + l + "\" is written with differing casing across examples (" + variants.join(", ") + "). If labels are matched exactly downstream, these read as different labels.");
          }
        });

        /* --- Coverage --- */
        var named = instructionLabels(instruction);
        var hasInstruction = String(instruction || "").trim().length > 0;
        if (!hasInstruction) {
          add("info", "Coverage", "No instruction was provided, so coverage checks were skipped. Paste the instruction to check that every label it names is demonstrated, and vice versa.");
        } else if (named.length) {
          named.forEach(function(l){
            if (!(l in dist)) add("blocker", "Coverage", "The instruction names the label \"" + l + "\" but no example demonstrates it. The model is asked to produce a label it has never seen produced — expect it to guess or avoid it.");
          });
          order.forEach(function(l){
            if (named.indexOf(l) === -1) add("warning", "Coverage", "Examples demonstrate the label \"" + l + "\", but the instruction never names it. Either name it in the instruction or drop those examples.");
          });
        } else {
          add("info", "Coverage", "No label list could be read out of the instruction (the check looks for quoted labels or a \"labels: a, b, or c\" style list), so named-vs-demonstrated coverage could not be checked.");
        }

        /* --- Balance --- */
        order.forEach(function(l){
          var p = pct(dist[l], nLab);
          if (nLab > 1 && dist[l] / nLab > 0.5) {
            add("warning", "Balance", "\"" + l + "\" is " + dist[l] + " of " + nLab + " labeled examples (" + p + "%). A majority label over 50% is a majority-bias risk: published few-shot research shows models over-predict the label they saw most.");
          }
        });

        /* --- Ordering --- */
        if (nLab) {
          var seq = labeled.map(function(b){ return { n: b.n, label: normLabel(b.output) }; });
          /* Runs are counted over consecutive blocks; a block with no readable
             label breaks a run rather than silently extending it. */
          var runSeq = blocks.map(function(b){
            return { n: b.n, label: (b.output !== null && normLabel(b.output) !== "") ? normLabel(b.output) : null };
          });
          var i, runStart = 0;
          for (i = 1; i <= runSeq.length; i++) {
            if (i === runSeq.length || runSeq[i].label === null || runSeq[i].label !== runSeq[runStart].label) {
              var runLen = i - runStart;
              if (runSeq[runStart].label !== null && runLen >= 3) {
                add("warning", "Ordering", "Blocks " + runSeq[runStart].n + "–" + runSeq[i - 1].n + " are " + runLen + " \"" + runSeq[runStart].label + "\" examples in a row. A same-label run at any point — worst at the end — skews the model toward repeating that label.");
              }
              runStart = i;
            }
          }
          var last = seq[seq.length - 1];
          add("info", "Ordering", "The last example (Block " + last.n + ") is labeled \"" + last.label + "\". Whatever label sits last carries recency-bias risk: models lean toward the answer they saw most recently. End on the label you can most afford to over-predict, or rotate the order between requests.");
        }

        /* --- Duplicates --- */
        var byInput = {};
        blocks.forEach(function(b){
          if (b.input === null) return;
          var k = normText(b.input);
          if (!byInput[k]) byInput[k] = [];
          byInput[k].push(b.n);
        });
        Object.keys(byInput).forEach(function(k){
          if (byInput[k].length > 1) {
            add("warning", "Duplicates", "Blocks " + byInput[k].join(", ") + " have the exact same input (\"" + (k.length > 60 ? k.slice(0, 60) + "…" : k) + "\"). Exact duplicates waste example slots and double-weight that input's label.");
          }
        });
        var byPrefix = {};
        blocks.forEach(function(b){
          if (b.input === null) return;
          var k = normText(b.input);
          if (k.length < 40) return;
          var p = k.slice(0, 40);
          if (!byPrefix[p]) byPrefix[p] = [];
          byPrefix[p].push({ n: b.n, full: k });
        });
        Object.keys(byPrefix).forEach(function(p){
          var group = byPrefix[p], fulls = {};
          group.forEach(function(g){ fulls[g.full] = true; });
          if (group.length > 1 && Object.keys(fulls).length > 1) {
            add("warning", "Duplicates", "Blocks " + group.map(function(g){ return g.n; }).join(", ") + " are near-duplicates: their inputs share the same first 40 normalised characters (\"" + p + "…\"). Near-identical inputs with the same label add cost, not signal.");
          }
        });

        /* --- Token estimate --- */
        var exChars = String(examplesText || "").length;
        var inChars = String(instruction || "").length;
        var estTokens = Math.round(exChars / 4);
        var estTotal = Math.round((exChars + inChars) / 4);

        /* --- Verdict --- */
        var blockers = findings.filter(function(f){ return f.sev === "blocker"; }).length;
        var warnings = findings.filter(function(f){ return f.sev === "warning"; }).length;
        var verdict, why;
        if (total === 0) {
          verdict = "DO NOT SHIP YET"; blockers = Math.max(blockers, 1);
          why = "No example blocks were found. Paste at least two or three examples in the documented format, then audit again.";
        } else if (blockers > 0) {
          verdict = "DO NOT SHIP YET";
          why = blockers + " blocking problem" + (blockers === 1 ? "" : "s") + " found — examples are missing pieces, or a label the instruction promises is never demonstrated. Fix the blockers first; the model cannot learn what is not there.";
        } else if (warnings > 0) {
          verdict = "FIX BEFORE SHIPPING";
          why = "The set is structurally complete, but " + warnings + " fixable risk" + (warnings === 1 ? "" : "s") + " remain" + (warnings === 1 ? "s" : "") + " — balance, ordering, format, or duplicate problems that measurably skew few-shot behaviour. Work the fix list, then re-audit.";
        } else {
          verdict = "SHIP THE EXAMPLES";
          why = "No blocking problems and no structural risks found: the format is consistent, every named label is demonstrated, no label dominates, and there are no duplicate or ordering hazards beyond the standing recency note.";
        }
        if (total > 0 && nLab === 0 && verdict !== "DO NOT SHIP YET") { verdict = "DO NOT SHIP YET"; }

        return {
          blocks: blocks, labeled: labeled, dist: dist, order: order,
          findings: findings, verdict: verdict, why: why,
          blockers: blockers, warnings: warnings,
          exChars: exChars, estTokens: estTokens, estTotal: estTotal, inChars: inChars
        };
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "FLAWED_EXAMPLES": (typeof FLAWED_EXAMPLES !== 'undefined' ? FLAWED_EXAMPLES : undefined), "CLEAN_EXAMPLES": (typeof CLEAN_EXAMPLES !== 'undefined' ? CLEAN_EXAMPLES : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-few-shot-example-auditor',
  name: 'J-Dawgs Few-Shot Example Auditor',
  description: 'Audits a prompt\'s instruction plus few-shot examples for format consistency, label balance and coverage, ordering and recency bias, and duplicates, and returns one ship verdict',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "FLAWED_EXAMPLES": __core["FLAWED_EXAMPLES"], "CLEAN_EXAMPLES": __core["CLEAN_EXAMPLES"] }
};
