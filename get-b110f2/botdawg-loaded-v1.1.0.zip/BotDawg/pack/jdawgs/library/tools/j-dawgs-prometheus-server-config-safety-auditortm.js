'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Prometheus Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var RISKY_CONFIG = [
        "# Risky example - do not deploy a config like this",
        "global:",
        "  scrape_interval: 15s",
        "  evaluation_interval: 15s",
        "",
        "rule_files:",
        '  - "rules/*.yml"',
        "",
        "remote_write:",
        "  - url: http://metrics-archive.example.com:9009/api/v1/write",
        "    basic_auth:",
        "      username: prom",
        '      password: "hunter2-do-not-leak"',
        "    tls_config:",
        "      insecure_skip_verify: true",
        "",
        "scrape_configs:",
        '  - job_name: "node-exporter"',
        "    scheme: http",
        "    static_configs:",
        '      - targets: ["203.0.113.44:9100"]'
      ].join("\n");

      var RISKY_FLAGS = [
        "--web.listen-address=0.0.0.0:9090",
        "--web.enable-admin-api",
        "--web.enable-lifecycle",
        "--web.enable-remote-write-receiver"
      ].join("\n");

      var HARDENED_CONFIG = [
        "# Hardened example",
        "global:",
        "  scrape_interval: 30s",
        "  evaluation_interval: 30s",
        "",
        "rule_files:",
        '  - "rules/node.yml"',
        "",
        "remote_write:",
        "  - url: https://metrics-archive.example.com/api/v1/write",
        "    tls_config:",
        "      insecure_skip_verify: false",
        "",
        "scrape_configs:",
        '  - job_name: "node-exporter"',
        "    scheme: https",
        "    tls_config:",
        "      insecure_skip_verify: false",
        "    static_configs:",
        '      - targets: ["127.0.0.1:9100"]'
      ].join("\n");

      var HARDENED_FLAGS = "--web.listen-address=127.0.0.1:9090";

      function $(id) { return document.getElementById(id); }

      function isLocalhostHost(host) {
        if (!host) return false;
        var h = host.toLowerCase().replace(/^\[|\]$/g, "");
        return h === "127.0.0.1" || h === "localhost" || h === "::1" || h === "0:0:0:0:0:0:0:1";
      }
      function isAllInterfacesHost(host) {
        if (host === null || host === undefined) return false;
        var h = host.replace(/^\[|\]$/g, "");
        return h === "" || h === "0.0.0.0" || h === "::" || h === "0:0:0:0:0:0:0:0";
      }
      function splitHostPort(addr) {
        var a = String(addr || "").trim().replace(/^["']|["']$/g, "");
        if (!a) return { host: "", port: "" };
        if (a.charAt(0) === "[") {
          var close = a.indexOf("]");
          if (close >= 0) return { host: a.slice(0, close + 1), port: a.slice(close + 2) };
        }
        var idx = a.lastIndexOf(":");
        if (idx >= 0 && a.indexOf(":") === idx) return { host: a.slice(0, idx), port: a.slice(idx + 1) };
        if (idx >= 0) return { host: a, port: "" }; // bare IPv6, no port
        return { host: a, port: "" };
      }
      function urlHost(url) {
        var m = /^https?:\/\/([^\/?#]+)/i.exec(url || "");
        if (!m) return "";
        var authority = m[1];
        var at = authority.lastIndexOf("@");
        if (at >= 0) authority = authority.slice(at + 1);
        return splitHostPort(authority).host;
      }
      function urlHasUserinfoPassword(url) {
        return /^https?:\/\/[^\/\s:@]+:[^\/\s@]+@/i.test(url || "");
      }
      function parseDurationSeconds(v) {
        var m = /^(\d+(?:\.\d+)?)(ms|s|m|h|d|w|y)$/.exec(String(v || "").trim().replace(/^["']|["']$/g, ""));
        if (!m) return null;
        var mult = { ms: 0.001, s: 1, m: 60, h: 3600, d: 86400, w: 604800, y: 31536000 };
        return parseFloat(m[1]) * mult[m[2]];
      }

      function audit(configText, flagsText) {
        var findings = [];
        function add(sev, where, msg) { findings.push({ sev: sev, where: where, msg: msg }); }

        var configLines = String(configText || "").split(/\r?\n/);
        var flagLines = String(flagsText || "").split(/\r?\n/);
        var combined = String(configText || "") + "\n" + String(flagsText || "");

        /* ---------- flags ---------- */
        var adminApi = null, lifecycle = null, remoteReceiver = null;
        var listen = null; // {host, raw, where}
        flagLines.forEach(function (line, i) {
          var where = "Flags line " + (i + 1);
          var lm = /--web\.listen-address(?:=|\s+)("[^"]*"|'[^']*'|\S+)/.exec(line);
          if (lm) listen = { raw: lm[1].replace(/^["']|["']$/g, ""), where: where };
          if (/--web\.enable-admin-api(\s|=|$)/.test(line) || /--web\.enable-admin-api$/.test(line.trim())) adminApi = where;
          if (/--web\.enable-lifecycle(\s|=|$)/.test(line) || /--web\.enable-lifecycle$/.test(line.trim())) lifecycle = where;
          if (/--web\.enable-remote-write-receiver/.test(line)) remoteReceiver = where;
        });

        /* ---------- config scan ---------- */
        var section = "";           // current top-level key
        var scrapeScheme = null;    // current scheme inside scrape_configs
        var topKeys = {};           // key -> first line number
        var authInConfig = /basic_auth_users\s*:/.test(configText) ||
          /(^|\n)\s*web\s*:\s*\n[^]*?basic_auth/.test(configText);

        configLines.forEach(function (raw, i) {
          var n = i + 1;
          var where = "Line " + n;
          var line = raw;

          if (/^\t|\s\t/.test(line) && line.trim() !== "") {
            add("NOT PARSED", where, "Tab indentation detected. YAML forbids tabs for indentation and this heuristic audit does not guess at tab-indented structure.");
          }
          if (/<<\s*:/.test(line)) {
            add("NOT PARSED", where, "YAML merge key (<<:) found. This text audit does not resolve merge keys, so keys pulled in by the merge were not graded.");
          } else if (/:\s*&[A-Za-z0-9_-]+/.test(line) || /:\s*\*[A-Za-z0-9_-]+/.test(line)) {
            add("NOT PARSED", where, "YAML anchor or alias found. This text audit does not resolve anchors/aliases, so the anchored value was not graded.");
          }

          var trimmed = line.trim();
          if (trimmed === "" || trimmed.charAt(0) === "#") return;

          var top = /^([A-Za-z_][\w.-]*)\s*:/.exec(line);
          if (top && !/^\s/.test(line)) {
            var key = top[1];
            if (Object.prototype.hasOwnProperty.call(topKeys, key)) {
              add("WARNING", where, "Duplicate top-level key \"" + key + "\": first defined at line " + topKeys[key] + ", repeated at line " + n + ". YAML loaders differ on which value wins; keep exactly one.");
            } else {
              topKeys[key] = n;
            }
            section = key;
            scrapeScheme = null;
          } else if (!/^\s/.test(line) && trimmed.charAt(0) !== "-" && trimmed !== "---") {
            add("NOT PARSED", where, "Top-level line does not look like a YAML key. This heuristic audit could not place it, so it was not graded.");
          }

          // listen address written inside the config text
          var clm = /--web\.listen-address(?:=|\s+)("[^"]*"|'[^']*'|\S+)/.exec(line) ||
                    /listen[-_]address\s*:\s*("[^"]*"|'[^']*'|\S+)/.exec(line);
          if (clm && !listen) listen = { raw: clm[1].replace(/^["']|["']$/g, ""), where: where };

          // web.yml-style basic auth users pasted inline
          if (/basic_auth_users\s*:/.test(line)) authInConfig = true;

          // credential-bearing keys: flag by key name + line ONLY, never the value
          var cred = /(password|passwd|bearer_token|bearer_token_file|client_secret|access_token|api_key)\s*:/i.exec(line);
          if (cred) {
            add("WARNING", where, "Credential present under key \"" + cred[1] + "\" at line " + n + ". The value is never shown by this tool. Confirm it is injected from a secret store, not committed with the config.");
          }

          // insecure_skip_verify
          if (/insecure_skip_verify\s*:\s*true/i.test(line)) {
            add("WARNING", where, "tls_config sets insecure_skip_verify: true at line " + n + ". TLS certificate verification is off, so the connection can be intercepted without detection.");
          }

          // global intervals
          if (section === "global") {
            var iv = /(scrape_interval|evaluation_interval)\s*:\s*(\S+)/.exec(line);
            if (iv) {
              var secs = parseDurationSeconds(iv[2]);
              if (secs !== null && (secs < 5 || secs > 3600)) {
                add("INFO", where, "global " + iv[1] + " is " + iv[2].replace(/^["']|["']$/g, "") + " — outside the usual 5s to 1h band. Very short intervals load the server and targets; very long ones delay detection.");
              }
            }
          }

          // remote_write / remote_read URLs
          if (section === "remote_write" || section === "remote_read") {
            var um = /url\s*:\s*(https?:\/\/[^\s"']+)/i.exec(line);
            if (um) {
              var u = um[1];
              if (/^http:\/\//i.test(u)) {
                add("WARNING", where, section + " url at line " + n + " uses plain http:// (host: " + (urlHost(u) || "unknown") + "). Metrics and credentials cross the network unencrypted; use https://.");
              }
              if (urlHasUserinfoPassword(u)) {
                add("WARNING", where, "Credential embedded in the " + section + " url at line " + n + " (key \"url\"). The value is never shown by this tool. Move credentials into basic_auth with secret management instead of the URL.");
              }
            }
          }

          // rule_files inventory
          if (section === "rule_files") {
            var rf = /-\s*["']?([^"'\s]+)["']?/.exec(trimmed);
            if (rf) add("INFO", where, "rule_files references \"" + rf[1] + "\" (line " + n + "). Inventory only — this tool cannot read that file, so its contents were not verified.");
            else if (/rule_files\s*:/.test(line) && trimmed !== "rule_files:") {
              add("INFO", where, "rule_files entry at line " + n + ". Inventory only — referenced files cannot be read or verified by this tool.");
            }
          }

          // alertmanager inventory
          if (section === "alerting" && /targets\s*:/.test(line)) {
            add("INFO", where, "Alertmanager targets referenced at line " + n + ". Inventory only — this tool cannot read the Alertmanager config, so its auth and routing were not verified.");
          }
          if (section === "alerting" && /api_url\s*:\s*(https?:\/\/[^\s"']+)/i.test(line)) {
            var au = /api_url\s*:\s*(https?:\/\/[^\s"']+)/i.exec(line)[1];
            if (/^http:\/\//i.test(au) && !isLocalhostHost(urlHost(au))) {
              add("WARNING", where, "Alertmanager api_url at line " + n + " uses plain http:// to a non-localhost host. Use https://.");
            } else {
              add("INFO", where, "Alertmanager api_url referenced at line " + n + ". Inventory only — the Alertmanager side was not verified.");
            }
          }

          // scrape configs
          if (section === "scrape_configs") {
            var sc = /scheme\s*:\s*(\w+)/.exec(line);
            if (sc) scrapeScheme = sc[1].toLowerCase();
            if (/targets\s*:/.test(line)) {
              var targets = [];
              var tq = /["']([^"']+)["']/g, tm;
              while ((tm = tq.exec(line)) !== null) targets.push(tm[1]);
              if (targets.length === 0) {
                var tb = /targets\s*:\s*\[([^\]]*)\]/.exec(line);
                if (tb) targets = tb[1].split(",").map(function (s) { return s.trim(); }).filter(Boolean);
              }
              targets.forEach(function (t) {
                var host = t.indexOf("://") >= 0 ? urlHost(t) : splitHostPort(t).host;
                var plainHttp = /^http:\/\//i.test(t) || scrapeScheme === "http";
                if (plainHttp && host && !isLocalhostHost(host)) {
                  add("WARNING", where, "Scrape target \"" + host + "\" at line " + n + " is reached over plain http. Scrape traffic to a non-localhost host is unencrypted; prefer https with TLS verification on.");
                } else if (plainHttp && host && isLocalhostHost(host)) {
                  add("INFO", where, "Scrape target \"" + host + "\" at line " + n + " uses plain http on localhost. Acceptable on a single host; encrypt before it crosses a network.");
                }
              });
            }
          }
        });

        /* ---------- cross-cutting verdict inputs ---------- */
        var authMention = authInConfig || /basic_auth_users|--web\.config\.file/.test(combined);

        if (adminApi) {
          add("BLOCKER", adminApi, "--web.enable-admin-api is enabled. The admin API can delete series and shut Prometheus down over HTTP. Leave it off in production; enable it only briefly, behind auth and network controls, for maintenance.");
        }
        if (lifecycle) {
          add("WARNING", lifecycle, "--web.enable-lifecycle is enabled. It exposes /-/reload and /-/quit endpoints. Anyone who can reach them can reload the config or stop the server.");
        }
        if (remoteReceiver) {
          add("WARNING", remoteReceiver, "--web.enable-remote-write-receiver is enabled. The server accepts remote-write pushes; without auth in front of it, any reachable client can write metrics into your TSDB.");
        }

        if (listen) {
          var hp = splitHostPort(listen.raw);
          var host = hp.host;
          if (isAllInterfacesHost(host) || (host && !isLocalhostHost(host))) {
            if (!authMention) {
              if (adminApi || lifecycle) {
                add("BLOCKER", listen.where, "Web/API listens on \"" + (listen.raw || "all interfaces") + "\" (external interface) with no basic-auth users in the pasted text, AND admin/lifecycle endpoints are enabled. That is unauthenticated remote control: bind to localhost behind a reverse proxy, or configure web basic-auth in web.yml, before deploying.");
              } else {
                add("WARNING", listen.where, "Web/API listens on \"" + (listen.raw || "all interfaces") + "\" (external interface) with no basic-auth users in the pasted text. The UI and API are open to anyone who can reach the port. Bind to localhost behind a reverse proxy, or configure web basic-auth in web.yml.");
              }
            } else {
              add("INFO", listen.where, "Web/API listens on \"" + listen.raw + "\" (external interface) and basic-auth is configured in the pasted text. Keep the auth file protected and prefer a reverse proxy with TLS in front.");
            }
          } else if (isLocalhostHost(host)) {
            if (!authMention) {
              add("INFO", listen.where, "Web/API binds to localhost only (\"" + listen.raw + "\") and no basic-auth is configured. Not escalated: the port is not reachable from other hosts, so local access controls carry the posture. Add web basic-auth if other local users or tunnels can reach it.");
            } else {
              add("INFO", listen.where, "Web/API binds to localhost only (\"" + listen.raw + "\") with basic-auth configured. Tight posture for a single-host deployment.");
            }
          }
        } else {
          add("INFO", "Flags", "No --web.listen-address found in the pasted text. Prometheus uses its built-in default listen address; confirm the bind on the host, since posture is graded from the actual bind.");
        }

        var order = { "BLOCKER": 0, "WARNING": 1, "NOT PARSED": 2, "INFO": 3 };
        findings.sort(function (a, b) {
          if (order[a.sev] !== order[b.sev]) return order[a.sev] - order[b.sev];
          return a.where.localeCompare(b.where, undefined, { numeric: true });
        });

        var blockers = findings.filter(function (f) { return f.sev === "BLOCKER"; }).length;
        var warnings = findings.filter(function (f) { return f.sev === "WARNING"; }).length;
        var infos = findings.filter(function (f) { return f.sev === "INFO"; }).length;
        var notParsed = findings.filter(function (f) { return f.sev === "NOT PARSED"; }).length;

        var verdict, verdictClass, verdictNote;
        if (blockers > 0) {
          verdict = "DO NOT DEPLOY"; verdictClass = "do-not";
          verdictNote = blockers + " blocker" + (blockers === 1 ? "" : "s") + " must be fixed before this config goes live.";
        } else if (warnings > 0) {
          verdict = "DEPLOY WITH FIXES"; verdictClass = "with-fixes";
          verdictNote = "No blockers, but " + warnings + " warning" + (warnings === 1 ? "" : "s") + " should be fixed before or alongside deploy.";
        } else {
          verdict = "SAFE TO DEPLOY"; verdictClass = "safe";
          verdictNote = "No graded risks found in the pasted text. That is not proof the deployment is secure — see Honest limits.";
        }

        return {
          verdict: verdict, verdictClass: verdictClass, verdictNote: verdictNote,
          findings: findings,
          counts: { blockers: blockers, warnings: warnings, infos: infos, notParsed: notParsed }
        };
      }

      function buildReport(result) {
        var lines = [];
        lines.push("J-Dawgs Prometheus Server Config Safety Auditor - audit report");
        lines.push("Verdict: " + result.verdict);
        lines.push("Counts: " + result.counts.blockers + " BLOCKER, " + result.counts.warnings + " WARNING, " +
                   result.counts.notParsed + " NOT PARSED, " + result.counts.infos + " INFO");
        lines.push("");
        if (result.findings.length === 0) {
          lines.push("No findings.");
        } else {
          result.findings.forEach(function (f) {
            lines.push("[" + f.sev + "] " + f.where + " - " + f.msg);
          });
        }
        lines.push("");
        lines.push("Limits: heuristic text audit of pasted text only. Never connected to a server, never ran promtool, never read referenced files. Secret values are never printed; credentials are flagged by key name and line only.");
        return lines.join("\n");
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-prometheus-server-config-safety-auditortm',
  name: 'J-Dawgs Prometheus Server Config Safety Auditor',
  description: 'promtool and server startup only check your config on an installed host, and only for whether it loads; ours grades a pasted prometheus.yml anywhere — web/API exposure, admin endpoints, and scrape TLS posture included — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
