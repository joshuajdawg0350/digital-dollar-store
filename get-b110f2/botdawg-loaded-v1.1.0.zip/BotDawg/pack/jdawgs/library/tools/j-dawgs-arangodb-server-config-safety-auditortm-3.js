'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs ArangoDB Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var RISKY = [
          "# arangod.conf — production settings, pasted for review",
          "[server]",
          "endpoint = tcp://0.0.0.0:8529",
          "endpoint = ssl://0.0.0.0:8530",
          "authentication = false",
          "jwt-secret = letmein123",
          "root-password = hunter2",
          "[database]",
          "directory = /var/lib/arangodb3",
          "[encryption]",
          "keyfile =",
          "[ssl]",
          "[agency]",
          "activate = true",
          "authentication = false",
          "# endpoint = tcp://127.0.0.1:8529",
          "remember to ask Dave about the firewall"
        ].join("\n");

        var HARDENED = [
          "# arangod.conf — hardened single server",
          "[server]",
          "endpoint = ssl://127.0.0.1:8530",
          "authentication = true",
          "jwt-secret = /etc/arangodb3/jwt-secret.txt",
          "[database]",
          "directory = /var/lib/arangodb3",
          "[encryption]",
          "keyfile = /etc/arangodb3/encryption.key",
          "[ssl]",
          "keyfile = /etc/arangodb3/server.pem",
          "[agency]",
          "activate = false"
        ].join("\n");

        var inputEl = document.getElementById("input");
        var verdictBox = document.getElementById("verdict-box");
        var verdictText = document.getElementById("verdict-text");
        var verdictSub = document.getElementById("verdict-sub");
        var countsEl = document.getElementById("counts");
        var findingsEl = document.getElementById("findings");
        var reportEl = document.getElementById("report");
        var jsonEl = document.getElementById("json");

        document.getElementById("example-in").textContent = RISKY;
        inputEl.value = RISKY;

        function stripQuotes(v){
          v = v.trim();
          if (v.length >= 2 && ((v.charAt(0) === '"' && v.charAt(v.length-1) === '"') || (v.charAt(0) === "'" && v.charAt(v.length-1) === "'"))) {
            return v.slice(1, -1);
          }
          return v;
        }
        function qualify(key, section){
          key = key.toLowerCase();
          if (key.indexOf(".") >= 0) return key;
          if (section) return section + "." + key;
          return key;
        }
        function parseEq(str){
          var m = str.match(/^([A-Za-z0-9_.\-]+)\s*=\s*(.*)$/);
          if (!m) return null;
          return { rawKey: m[1], value: stripQuotes(m[2]) };
        }
        function parseCli(str){
          var tokens = str.split(/\s+/);
          var out = [];
          var i = 0;
          if (tokens[0] === "arangod" || /arangod$/.test(tokens[0])) i = 1;
          if (i >= tokens.length) return null;
          for (; i < tokens.length; i++){
            var tok = tokens[i];
            if (tok.indexOf("--") !== 0) return null;
            var body = tok.slice(2), key, value;
            var eq = body.indexOf("=");
            if (eq >= 0){ key = body.slice(0, eq); value = body.slice(eq + 1); }
            else {
              key = body;
              if (i + 1 < tokens.length && tokens[i+1].indexOf("--") !== 0){ value = tokens[i+1]; i++; }
              else value = "true";
            }
            if (!/^[A-Za-z0-9_.\-]+$/.test(key)) return null;
            out.push({ rawKey: key, value: stripQuotes(value) });
          }
          return out.length ? out : null;
        }
        function trySettings(str){
          var eq = parseEq(str);
          if (eq) return [eq];
          if (str.indexOf("--") >= 0) return parseCli(str);
          return null;
        }
        function looksLikePath(v){
          return v.charAt(0) === "/" || v.indexOf("/") >= 0 || /^[A-Za-z]:\\/.test(v);
        }
        function looksLikeRef(v){
          return v.indexOf("${") === 0 || /^env:/i.test(v) || /^file:/i.test(v);
        }
        function truthy(v){ v = v.toLowerCase(); return v === "true" || v === "yes" || v === "on" || v === "1"; }
        function falsy(v){ v = v.toLowerCase(); return v === "false" || v === "no" || v === "off" || v === "0" || v === "none" || v === ""; }

        var SEV_RANK = { CRITICAL:0, HIGH:1, MEDIUM:2, LOW:3, INFO:4, PASS:5 };

        function audit(text){
          var lines = text.split(/\r?\n/);
          var findings = [];
          var settings = [];       // active settings {line, key, rawKey, value}
          var section = "";
          var activeCount = 0;

          function add(line, sev, check, title, detail){
            findings.push({ line: line, severity: sev, check: check, title: title, detail: detail });
          }

          var i, raw, t;
          for (i = 0; i < lines.length; i++){
            var lineNo = i + 1;
            raw = lines[i]; t = raw.trim();
            if (!t) continue;
            if (t.charAt(0) === "#" || t.charAt(0) === ";"){
              var inner = t.replace(/^[#;]\s*/, "");
              var cs = trySettings(inner);
              if (cs && cs.length){
                add(lineNo, "INFO", "commented-not-active", "COMMENTED / NOT ACTIVE",
                  "Setting '" + cs[0].rawKey + "' is commented out on this line. Commented-out settings are not active and were not graded.");
              }
              continue;
            }
            var sec = t.match(/^\[([^\]]+)\]$/);
            if (sec){ section = sec[1].trim().toLowerCase(); continue; }
            var parsed = trySettings(t);
            if (parsed && parsed.length){
              for (var k = 0; k < parsed.length; k++){
                settings.push({ line: lineNo, key: qualify(parsed[k].rawKey, section), rawKey: parsed[k].rawKey, value: parsed[k].value });
                activeCount++;
              }
              continue;
            }
            add(lineNo, "LOW", "not-parsed", "NOT PARSED",
              "This line could not be read as an arangod option (an INI key = value line, a [section] header, or a --option). It was not graded.");
          }

          // Cross-setting state
          var endpoints = [];        // {line, value, cls: all|loopback|other, ssl:bool}
          var authDisabled = false, authOn = false, authLine = 0;
          var jwtPresent = false;
          var sslKeyfileLine = 0;
          var agencyActiveLine = 0;

          settings.forEach(function(s){
            var key = s.key, val = s.value, vlow = val.toLowerCase();

            if (key === "server.endpoint" || key === "endpoint"){
              val.split(",").forEach(function(ep){
                ep = ep.trim(); if (!ep) return;
                var cls = "other";
                if (ep.indexOf("0.0.0.0") >= 0 || ep.indexOf("[::]") >= 0) cls = "all";
                else if (ep.indexOf("127.0.0.1") >= 0 || ep.indexOf("localhost") >= 0 || ep.indexOf("unix://") === 0 || ep.indexOf("[::1]") >= 0) cls = "loopback";
                var isSsl = ep.indexOf("ssl://") === 0 || ep.indexOf("https://") === 0;
                endpoints.push({ line: s.line, value: ep, cls: cls, ssl: isSsl });
                if (cls === "all"){
                  add(s.line, "CRITICAL", "endpoint-all-interfaces", "Endpoint bound to all interfaces (0.0.0.0)",
                    "server.endpoint is \"" + ep + "\". ArangoDB answers on every network interface of the host, not just localhost — anyone who can reach the host can reach the database port.");
                } else if (cls === "loopback"){
                  add(s.line, "PASS", "endpoint-loopback", "Endpoint bound to loopback only",
                    "server.endpoint is \"" + ep + "\"; only connections from this host can reach it.");
                } else {
                  add(s.line, "MEDIUM", "endpoint-non-loopback", "Endpoint bound to a non-loopback address",
                    "server.endpoint is \"" + ep + "\". Confirm a firewall or VPN limits who can reach it, and that authentication is on.");
                }
              });
              return;
            }

            if (key === "server.authentication"){
              if (falsy(vlow) && vlow !== ""){ authDisabled = true; authLine = s.line;
                add(s.line, "CRITICAL", "authentication-disabled", "Authentication is disabled",
                  "server.authentication is false. Anyone who can reach the endpoint can read and write the database and open the web interface with no login.");
              } else if (truthy(vlow)){ authOn = true;
                add(s.line, "PASS", "authentication-on", "Authentication is on",
                  "server.authentication is true; clients must log in.");
              }
              return;
            }

            if (key.indexOf("jwt-secret") >= 0 || key.indexOf("jwt_secret") >= 0){
              jwtPresent = true;
              if (key.indexOf("keyfile") >= 0 || looksLikePath(val) || looksLikeRef(val)){
                add(s.line, "PASS", "jwt-secret-file", "JWT secret comes from a file or reference",
                  "Key '" + key + "' points at a file or reference rather than holding the secret inline in the config.");
              } else if (val === ""){
                add(s.line, "HIGH", "jwt-secret-empty", "JWT secret is empty",
                  "Key '" + key + "' is present but empty. Cluster and token signing fall back to a default secret anyone can look up.");
              } else {
                add(s.line, "HIGH", "jwt-secret-plaintext", "JWT secret is plaintext in the config",
                  "Key '" + key + "', line " + s.line + ", value length " + val.length + " characters — the value itself is never shown. " +
                  (val.length < 32 ? "At under 32 characters it is also too short for an HMAC signing secret. " : "") +
                  "Move the secret into a file the config points at, or a secret store.");
              }
              return;
            }

            if (key === "ssl.keyfile"){ sslKeyfileLine = s.line; return; }

            if (key.indexOf("encryption") >= 0){
              if (key.indexOf("keyfile") >= 0 || key === "encryption.key"){
                if (falsy(vlow)){
                  add(s.line, "HIGH", "encryption-off", "Encryption at rest is off",
                    "Key '" + key + "' is presented but " + (val === "" ? "empty" : "switched off") + " — the RocksDB data files are stored unencrypted.");
                } else {
                  add(s.line, "PASS", "encryption-on", "Encryption at rest is configured",
                    "Key '" + key + "' points at a keyfile, so stored data files are encrypted at rest.");
                }
              }
              return;
            }

            if (key === "agency.authentication" || key === "cluster.authentication"){
              if (falsy(vlow) && vlow !== ""){
                add(s.line, "HIGH", "agency-auth-off", "Agency/cluster authentication is off",
                  "Key '" + key + "' is false. Agency and cluster components would exchange traffic without authentication.");
              } else if (truthy(vlow)){
                add(s.line, "PASS", "agency-auth-on", "Agency/cluster authentication is on",
                  "Key '" + key + "' is true.");
              }
              return;
            }

            if (key === "agency.activate" && truthy(vlow)){ agencyActiveLine = s.line; return; }

            if (/(password|passwd|secret|token|api[-_]?key|private[-_]?key)/i.test(key)){
              if (val !== "" && !looksLikePath(val) && !looksLikeRef(val)){
                add(s.line, "HIGH", "plaintext-secret", "Plaintext secret in config",
                  "Key '" + key + "', line " + s.line + ", value length " + val.length + " characters — the value itself is never shown. Anyone who can read this config file holds the credential; move it to a file or secret-store reference.");
              }
              return;
            }
          });

          // SSL cross-check
          var sslEndpoints = endpoints.filter(function(e){ return e.ssl; });
          if (sslEndpoints.length && !sslKeyfileLine){
            add(sslEndpoints[0].line, "HIGH", "ssl-keyfile-missing", "SSL endpoint without an SSL keyfile",
              "An ssl:// endpoint is configured (line " + sslEndpoints[0].line + ") but no active ssl.keyfile setting appears in the config, so the SSL endpoint has no certificate/key pair to serve.");
          }
          if (sslEndpoints.length && sslKeyfileLine){
            add(sslKeyfileLine, "PASS", "ssl-keyfile-present", "SSL keyfile present for the SSL endpoint",
              "ssl.keyfile is set, matching the ssl:// endpoint in this config.");
          }

          // Agency without JWT
          if (agencyActiveLine && !jwtPresent){
            add(agencyActiveLine, "MEDIUM", "agency-no-jwt", "Agency is active but no JWT secret is presented",
              "agency.activate is true, but no JWT secret setting appears in the active config. Cluster components authenticate to each other with a shared JWT secret; set one on every node.");
          }

          // Web interface / _api posture
          if (endpoints.length){
            var firstPublic = null, anyPublic = false, allLoopback = true;
            endpoints.forEach(function(e){
              if (e.cls !== "loopback"){ anyPublic = true; allLoopback = false; if (!firstPublic) firstPublic = e; }
            });
            if (anyPublic && authDisabled){
              add(firstPublic.line, "CRITICAL", "web-interface-exposed", "Web interface and _api are exposed with authentication off",
                "The admin web interface and the _api HTTP API are served on the same endpoint as the database. With a non-loopback endpoint and authentication disabled, both are open to anyone who can reach the host.");
            } else if (anyPublic){
              add(firstPublic.line, "MEDIUM", "web-interface-public", "Web interface and _api are reachable beyond localhost",
                "The admin web interface and the _api HTTP API are served on the database endpoint. Authentication is not shown as disabled, but a non-loopback endpoint still exposes them — restrict by firewall or VPN.");
            } else if (allLoopback){
              add(endpoints[0].line, "PASS", "web-interface-local", "Web interface and _api are local-only",
                "The web interface and _api ride on the loopback endpoint only, so they are not reachable from the network.");
            }
          }

          findings.sort(function(a, b){
            if (a.line !== b.line) return a.line - b.line;
            return SEV_RANK[a.severity] - SEV_RANK[b.severity];
          });

          var counts = { CRITICAL:0, HIGH:0, MEDIUM:0, LOW:0, INFO:0, PASS:0 };
          findings.forEach(function(f){ counts[f.severity]++; });
          var graded = counts.CRITICAL + counts.HIGH + counts.MEDIUM + counts.PASS;

          var verdict, vclass, vsub;
          if (graded === 0){
            verdict = "NOT ENOUGH TO GRADE"; vclass = "none";
            vsub = activeCount === 0
              ? "No active arangod settings could be read from this text. Paste an arangod.conf or arangod command-line options to get a verdict."
              : "Settings were read, but none of the graded security settings (endpoint, authentication, JWT, encryption, SSL, agency, secrets) are presented. There is not enough here to grade.";
          } else if (counts.CRITICAL > 0){
            verdict = "DO NOT DEPLOY"; vclass = "crit";
            vsub = counts.CRITICAL + " critical finding" + (counts.CRITICAL === 1 ? "" : "s") + " — fix these before this config goes anywhere near a network.";
          } else if (counts.HIGH > 0 || counts.MEDIUM > 0){
            verdict = "DEPLOY WITH FIXES"; vclass = "warn";
            vsub = "No critical findings, but " + (counts.HIGH + counts.MEDIUM) + " finding" + ((counts.HIGH + counts.MEDIUM) === 1 ? "" : "s") + " to fix before this is a clean deploy.";
          } else {
            verdict = "SAFE TO DEPLOY"; vclass = "ok";
            vsub = "Every graded setting presented in this config passed. Settings not presented in the pasted text are not covered by this verdict.";
          }

          return {
            verdict: verdict, vclass: vclass, vsub: vsub,
            lines: lines.length, active: activeCount,
            counts: counts, findings: findings
          };
        }

        function esc(s){
          return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
        }

        function render(result){
          verdictBox.className = "verdict " + result.vclass;
          verdictText.textContent = result.verdict;
          verdictSub.textContent = result.vsub;

          var chips = [
            result.lines + " lines audited",
            result.active + " active settings",
            result.counts.CRITICAL + " critical",
            result.counts.HIGH + " high",
            result.counts.MEDIUM + " medium",
            result.counts.LOW + " not parsed",
            result.counts.INFO + " commented",
            result.counts.PASS + " passed"
          ];
          countsEl.innerHTML = chips.map(function(c){ return '<span class="chip">' + esc(c) + "</span>"; }).join("");

          if (!result.findings.length){
            findingsEl.innerHTML = '<li><div class="fbody"><span class="ftitle">No findings.</span> <span class="fdetail">Nothing in this text could be graded.</span></div></li>';
          } else {
            findingsEl.innerHTML = result.findings.map(function(f){
              return '<li><span class="ln">Line ' + f.line + '</span><span class="sev ' + f.severity + '">' + f.severity + '</span>' +
                '<div class="fbody"><span class="ftitle">' + esc(f.title) + '</span><br><span class="fdetail">' + esc(f.detail) + "</span></div></li>";
            }).join("");
          }

          var reportLines = [];
          reportLines.push("J-Dawgs ArangoDB Server Config Safety Auditor\u2122 — audit report");
          reportLines.push("Verdict: " + result.verdict);
          reportLines.push("Lines audited: " + result.lines + " | Active settings parsed: " + result.active +
            " | Findings: " + result.findings.length + " (Critical " + result.counts.CRITICAL + ", High " + result.counts.HIGH +
            ", Medium " + result.counts.MEDIUM + ", Low " + result.counts.LOW + ", Info " + result.counts.INFO + ", Pass " + result.counts.PASS + ")");
          reportLines.push("");
          reportLines.push("Findings (by line):");
          if (!result.findings.length) reportLines.push("  (none)");
          result.findings.forEach(function(f){
            reportLines.push("[" + f.severity + "] Line " + f.line + " — " + f.title + ": " + f.detail);
          });
          reportLines.push("");
          reportLines.push("Notes: Secret values are never shown anywhere in this report — findings name the key, the line, and the value length only. Lines starting with # are COMMENTED / NOT ACTIVE and are not graded. Lines that cannot be read as arangod options are marked NOT PARSED.");
          reportLines.push("Scope: offline text audit only. This tool does not start ArangoDB, does not connect to any server, and does not verify that the config loads.");
          reportEl.value = reportLines.join("\n");

          var payload = {
            tool: "J-Dawgs ArangoDB Server Config Safety Auditor\u2122",
            verdict: result.verdict,
            summary: {
              linesAudited: result.lines,
              activeSettings: result.active,
              critical: result.counts.CRITICAL,
              high: result.counts.HIGH,
              medium: result.counts.MEDIUM,
              low: result.counts.LOW,
              info: result.counts.INFO,
              pass: result.counts.PASS
            },
            findings: result.findings.map(function(f){
              return { line: f.line, severity: f.severity, check: f.check, title: f.title, detail: f.detail };
            }),
            notes: [
              "Secret values are never included; findings carry key name, line, and value length only.",
              "Commented-out lines (#) are COMMENTED / NOT ACTIVE and are not graded.",
              "Offline text audit only: does not start ArangoDB, connect to any server, or verify the config loads."
            ]
          };
          jsonEl.value = JSON.stringify(payload, null, 2);
        }

        function run(){ render(audit(inputEl.value)); }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-arangodb-server-config-safety-auditortm-3',
  name: 'J-Dawgs ArangoDB Server Config Safety Auditor',
  description: '',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
