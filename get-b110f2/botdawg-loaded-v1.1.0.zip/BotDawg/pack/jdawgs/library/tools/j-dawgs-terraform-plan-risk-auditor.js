'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Terraform Plan Risk Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

  "use strict";

  var STATEFUL_RE = /(db|database|rds|bucket|volume|instance|cluster)/i;

  /* Quote characters in these patterns tolerate a preceding backslash, because
     plan JSON commonly embeds policy documents as escaped JSON strings
     (\"Action\":\"*\") — the widening is the same either way. */
  var IAM_SIGNALS = [
    { re: /\\?"Action\\?"\s*:\s*\\?"\*\\?"/g,            label: 'IAM wildcard action — "Action": "*"' },
    { re: /\\?"Action\\?"\s*:\s*\[\s*\\?"\*\\?"\s*\]/g,  label: 'IAM wildcard action — "Action": ["*"]' },
    { re: /\bAction\s*=\s*"\*"/g,                        label: 'IAM wildcard action — Action = "*"' },
    { re: /\\?"Resource\\?"\s*:\s*\\?"\*\\?"/g,          label: 'IAM wildcard resource — "Resource": "*"' },
    { re: /\\?"Resource\\?"\s*:\s*\[\s*\\?"\*\\?"\s*\]/g,label: 'IAM wildcard resource — "Resource": ["*"]' },
    { re: /\bResource\s*=\s*"\*"/g,                      label: 'IAM wildcard resource — Resource = "*"' },
    { re: /AdministratorAccess/g,                       label: 'Managed policy AdministratorAccess referenced' },
    { re: /0\.0\.0\.0\/0/g,                             label: 'Open CIDR 0.0.0.0/0 (world-open ingress/route)' },
    { re: /\\?"aws:PrincipalOrgID\\?"\s*:\s*\\?"\*\\?"/g,label: 'Policy condition widened to any organization' }
  ];

  var EXPOSURE_SIGNALS = [
    { re: /"?publicly_accessible"?\s*[:=]\s*true/g, label: 'publicly_accessible = true' },
    { re: /"?acl"?\s*[:=]\s*"public[-a-z]*"/g,      label: 'Public ACL (acl = "public…")' },
    { re: /\bacl\s*=\s*public[-a-z]*/g,             label: 'Public ACL (acl = public…)' }
  ];

  var SAMPLE_RISKY = {
    "format_version": "1.2",
    "terraform_version": "1.6.0",
    "resource_changes": [
      {
        "address": "aws_db_instance.main",
        "type": "aws_db_instance",
        "name": "main",
        "change": {
          "actions": ["delete", "create"],
          "before": { "engine": "postgres", "instance_class": "db.t3.medium", "publicly_accessible": false },
          "after":  { "engine": "postgres", "instance_class": "db.t3.large",  "publicly_accessible": false }
        }
      },
      {
        "address": "aws_iam_policy.deployer",
        "type": "aws_iam_policy",
        "name": "deployer",
        "change": {
          "actions": ["update"],
          "before": { "policy": "{\"Version\":\"2012-10-17\",\"Statement\":[{\"Effect\":\"Allow\",\"Action\":[\"s3:GetObject\"],\"Resource\":\"arn:aws:s3:::app-artifacts/*\"}]}" },
          "after":  { "policy": "{\"Version\":\"2012-10-17\",\"Statement\":[{\"Effect\":\"Allow\",\"Action\":\"*\",\"Resource\":\"*\"}]}" }
        }
      },
      {
        "address": "aws_instance.web",
        "type": "aws_instance",
        "name": "web",
        "change": {
          "actions": ["update"],
          "before": { "tags": { "Team": "platform" } },
          "after":  { "tags": { "Team": "platform", "CostCenter": "cc-1042" } }
        }
      }
    ]
  };

  var SAMPLE_CLEAN = [
    "Terraform used the selected providers to generate the following execution",
    "plan. Resource actions are indicated with the following symbols:",
    "  + create",
    "  ~ update in-place",
    "",
    "Terraform will perform the following actions:",
    "",
    "  # aws_s3_bucket.logs will be created",
    "  + resource \"aws_s3_bucket\" \"logs\" {",
    "      + bucket = \"app-logs-2026\"",
    "      + tags = {",
    "          + \"Team\" = \"platform\"",
    "        }",
    "    }",
    "",
    "  # aws_instance.web will be updated in-place",
    "  ~ resource \"aws_instance\" \"web\" {",
    "        id = \"i-0123456789abcdef0\"",
    "      ~ tags = {",
    "          ~ \"CostCenter\" = \"cc-1042\" -> \"cc-2048\"",
    "        }",
    "    }",
    "",
    "Plan: 1 to add, 1 to change, 0 to destroy."
  ].join("\n");

  function esc(s){
    return String(s).replace(/[&<>"']/g, function(c){
      return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c];
    });
  }

  function isStateful(type, name, address){
    return STATEFUL_RE.test(String(type||"")) || STATEFUL_RE.test(String(name||"")) || STATEFUL_RE.test(String(address||""));
  }

  function classifyActions(actions){
    if (!actions || !actions.length) return null;
    var a = actions.slice().sort().join(",");
    if (a === "no-op") return "NO-OP";
    if (a === "create") return "CREATE";
    if (a === "delete") return "DESTROY";
    if (a === "update") return "UPDATE";
    if (a === "create,delete") return "REPLACE";
    if (a === "read") return "NO-OP";
    return null;
  }

  function parseJSONPlan(text){
    var data;
    try { data = JSON.parse(text); }
    catch(e){ return { ok:false, error:"JSON.parse failed: " + e.message }; }
    if (!data || typeof data !== "object" || !Array.isArray(data.resource_changes)){
      return { ok:false, error:"Valid JSON, but it has no top-level \"resource_changes\" array — this is not a terraform show -json plan document." };
    }
    var changes = [], unparsed = [];
    data.resource_changes.forEach(function(rc, i){
      var addr = rc && rc.address ? String(rc.address) : "(entry " + (i+1) + " — no address field)";
      var actions = rc && rc.change ? rc.change.actions : null;
      var cls = classifyActions(actions);
      if (cls === null){
        unparsed.push({ where:"resource_changes[" + i + "] (" + addr + ")",
          what:"Unrecognized change.actions " + JSON.stringify(actions || null) + " — not classified, not guessed." });
        return;
      }
      changes.push({ address: addr, type: rc.type || "", name: rc.name || "", cls: cls,
                     stateful: isStateful(rc.type, rc.name, addr) });
    });
    var otherSections = Object.keys(data).filter(function(k){ return k !== "resource_changes"; });
    return { ok:true, format:"JSON plan (terraform show -json) — resource_changes[]", changes:changes,
             unparsed:unparsed, otherSections:otherSections };
  }

  var TEXT_VERBS = [
    { re: /will be created/i,        cls:"CREATE"  },
    { re: /will be destroyed/i,      cls:"DESTROY" },
    { re: /will be updated in-place/i, cls:"UPDATE" },
    { re: /must be replaced/i,       cls:"REPLACE" },
    { re: /will be replaced/i,       cls:"REPLACE" }
  ];

  function parseTextPlan(text){
    var lines = text.split(/\r?\n/);
    var changes = [], unparsed = [];
    var summary = null;
    lines.forEach(function(raw, idx){
      var line = raw.trim();
      var sm = line.match(/^Plan:\s*(\d+) to add,\s*(\d+) to change,\s*(\d+) to destroy/);
      if (sm){ summary = { add:+sm[1], change:+sm[2], destroy:+sm[3] }; return; }
      if (line.charAt(0) !== "#") return;
      var body = line.replace(/^#\s*/, "");
      var addrMatch = body.match(/^(\S+)\s+(.*)$/);
      if (!addrMatch) {
        unparsed.push({ where:"line " + (idx+1), what:"Header line with no readable address: " + line });
        return;
      }
      var addr = addrMatch[1], rest = addrMatch[2];
      if (!/will|must/i.test(rest)) return; /* e.g. "# (because …)" notes — not a change header */
      var hit = null;
      for (var i=0;i<TEXT_VERBS.length;i++){ if (TEXT_VERBS[i].re.test(rest)){ hit = TEXT_VERBS[i].cls; break; } }
      if (!hit){
        unparsed.push({ where:"line " + (idx+1),
          what:"Change header with an unrecognized verb phrase — not classified, not guessed: " + line });
        return;
      }
      var typeGuess = addr.replace(/\[\d+\]\s*$/, "").replace(/"[^"]*"/g,"").split(".");
      var type = typeGuess.length >= 2 ? typeGuess[typeGuess.length-2] : "";
      var name = typeGuess.length >= 1 ? typeGuess[typeGuess.length-1] : "";
      changes.push({ address: addr, type: type, name: name, cls: hit, stateful: isStateful(type, name, addr) });
    });
    return { changes:changes, unparsed:unparsed, summary:summary, lineCount:lines.length };
  }

  function scanSignals(text){
    var lines = text.split(/\r?\n/);
    var blockers = [], warnings = [];
    function run(set, out, level){
      set.forEach(function(sig){
        lines.forEach(function(raw, idx){
          sig.re.lastIndex = 0;
          var m;
          var seenOnLine = false;
          while ((m = sig.re.exec(raw)) !== null){
            if (seenOnLine) break;
            seenOnLine = true;
            var start = Math.max(0, m.index - 50);
            var end = Math.min(raw.length, m.index + m[0].length + 50);
            var snippet = (start > 0 ? "…" : "") + raw.slice(start, end).trim() + (end < raw.length ? "…" : "");
            out.push({ level:level, label:sig.label, quote:snippet, line:idx+1 });
          }
        });
      });
    }
    run(IAM_SIGNALS, blockers, "BLOCKER");
    run(EXPOSURE_SIGNALS, warnings, "WARNING");
    return { blockers:blockers, warnings:warnings };
  }

  function audit(raw){
    var text = (raw || "").trim();
    var result = { parseOk:false, format:"", changes:[], unparsed:[], blockers:[], warnings:[],
                   summaryMismatch:null, otherSections:[] };

    if (!text){
      result.format = "No input";
      result.unparsed.push({ where:"input", what:"The paste box is empty — nothing was audited." });
      return finish(result);
    }

    var signals = scanSignals(raw);
    result.blockers = signals.blockers;
    result.warnings = signals.warnings;

    if (text.charAt(0) === "{" || text.charAt(0) === "["){
      var jp = parseJSONPlan(text);
      if (jp.ok){
        result.parseOk = true;
        result.format = jp.format;
        result.changes = jp.changes;
        result.unparsed = jp.unparsed;
        result.otherSections = jp.otherSections;
      } else {
        result.format = "JSON attempted — failed";
        result.unparsed.push({ where:"whole input", what: jp.error });
      }
      return finish(result);
    }

    var tp = parseTextPlan(raw);
    if (tp.changes.length || tp.unparsed.length){
      result.parseOk = tp.changes.length > 0;
      result.format = "Human-readable plan text (terraform plan) — # address headers";
      result.changes = tp.changes;
      result.unparsed = tp.unparsed;
      if (tp.summary){
        var add = 0, chg = 0, dst = 0;
        tp.changes.forEach(function(c){
          if (c.cls === "CREATE") add++;
          if (c.cls === "REPLACE"){ add++; dst++; }
          if (c.cls === "UPDATE") chg++;
          if (c.cls === "DESTROY") dst++;
        });
        if (add !== tp.summary.add || chg !== tp.summary.change || dst !== tp.summary.destroy){
          result.summaryMismatch = "Parsed headers give " + add + " to add, " + chg + " to change, " + dst +
            " to destroy, but the plan's own summary line says " + tp.summary.add + " / " + tp.summary.change +
            " / " + tp.summary.destroy + ". Some change headers may be missing from the paste — the audit covers only what was pasted.";
        }
      }
      if (!tp.changes.length && !tp.unparsed.length){
        result.format = "Not recognized";
        result.unparsed.push({ where:"whole input", what:"No \"# <address> will be …\" change headers found and the input is not plan JSON. Nothing was classified." });
      }
    } else {
      result.format = "Not recognized";
      result.unparsed.push({ where:"whole input", what:"No \"# <address> will be …\" change headers found and the input is not plan JSON. Nothing was classified." });
    }
    return finish(result);
  }

  function finish(result){
    /* Destructive-change findings */
    result.changes.forEach(function(c){
      if (c.cls === "DESTROY" || c.cls === "REPLACE"){
        if (c.stateful){
          result.blockers.push({ level:"BLOCKER",
            label:(c.cls === "DESTROY" ? "Destroy" : "Replace (delete + create)") + " of a stateful-matching resource",
            quote:c.address, line:null, destructive:true });
        } else {
          result.warnings.push({ level:"WARNING",
            label:(c.cls === "DESTROY" ? "Destroy" : "Replace (delete + create)") + " of a resource",
            quote:c.address, line:null, destructive:true });
        }
      }
    });

    var counts = { "CREATE":0, "UPDATE":0, "REPLACE":0, "DESTROY":0, "NO-OP":0 };
    result.changes.forEach(function(c){ counts[c.cls]++; });
    result.counts = counts;

    var destructive = result.changes.filter(function(c){ return c.cls === "DESTROY" || c.cls === "REPLACE"; });
    result.destructive = destructive;

    var iamBlockers = result.blockers.filter(function(b){ return !b.destructive; });
    if (!result.parseOk || iamBlockers.length){
      result.verdict = "DO NOT APPLY YET"; result.verdictClass = "stop";
      result.verdictWhy = !result.parseOk
        ? "The input could not be fully parsed (see “Not parsed”). An auditor that can't read the plan does not bless the plan."
        : "IAM/policy-widening BLOCKERs are present (see Findings). Wildcard access must be narrowed or explicitly owned by a human before this plan goes anywhere near apply.";
    } else if (result.blockers.length || destructive.length || result.warnings.length || result.summaryMismatch){
      result.verdict = "APPLY WITH CONFIRMATION"; result.verdictClass = "confirm";
      result.verdictWhy = "No policy-widening BLOCKERs, but destructive changes, stateful BLOCKERs, or warnings need the confirmation checklist worked through first.";
    } else {
      result.verdict = "SAFE TO APPLY"; result.verdictClass = "safe";
      result.verdictWhy = "The plan parsed fully: no BLOCKERs, no WARNINGs, nothing destroyed or replaced.";
    }
    return result;
  }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "SAMPLE_RISKY": (typeof SAMPLE_RISKY !== 'undefined' ? SAMPLE_RISKY : undefined), "SAMPLE_CLEAN": (typeof SAMPLE_CLEAN !== 'undefined' ? SAMPLE_CLEAN : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-terraform-plan-risk-auditor',
  name: 'J-Dawgs Terraform Plan Risk Auditor',
  description: 'Audits a pasted Terraform plan (JSON or text) before apply: classifies CREATE / UPDATE / REPLACE / DESTROY, flags stateful destroys and replacements and IAM widening as BLOCKERs, and returns one verdict — SAFE TO APPLY / APPLY WITH CONFIRMATION / DO NOT APPLY YET.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "SAMPLE_RISKY": __core["SAMPLE_RISKY"], "SAMPLE_CLEAN": __core["SAMPLE_CLEAN"] }
};
