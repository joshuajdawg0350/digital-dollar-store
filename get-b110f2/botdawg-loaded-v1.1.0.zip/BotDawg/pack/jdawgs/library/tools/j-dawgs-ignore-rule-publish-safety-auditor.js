'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Ignore-Rule & Publish-Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the evaluate function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var EXAMPLE_RULES = "# Sample ignore rules\n*.log\n.env\n!important.log\nbuild/\n/dist/**";
        var EXAMPLE_PATHS = "src/app.js\n.env\nlogs/important.log\nbuild/out.js\ndist/a/b.js\ncerts/id_rsa.key";

        var SENSITIVE_TOKENS = [".env", ".key", ".pem", ".crt", "secret", "credential", "token", "id_rsa", ".aws", ".ssh", "password"];

        var rulesInput = document.getElementById("rules-input");
        var pathsInput = document.getElementById("paths-input");
        var resultsEl = document.getElementById("results");
        var verdictEl = document.getElementById("verdict");
        var reportEl = document.getElementById("report-output");

        function escapeRegExpChar(c) {
          return c.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
        }

        // Convert one path segment (no "/") of a glob into regex source.
        function segmentToRegex(seg) {
          var out = "";
          var i = 0;
          while (i < seg.length) {
            var c = seg.charAt(i);
            if (c === "*") {
              out += "[^/]*";
              i++;
            } else if (c === "?") {
              out += "[^/]";
              i++;
            } else if (c === "[") {
              var j = i + 1;
              var neg = false;
              if (seg.charAt(j) === "!") { neg = true; j++; }
              var cls = "";
              if (seg.charAt(j) === "]") { cls += "\\]"; j++; }
              while (j < seg.length && seg.charAt(j) !== "]") {
                var cc = seg.charAt(j);
                cls += (cc === "\\") ? "\\\\" : cc;
                j++;
              }
              if (j >= seg.length) {
                out += "\\["; // no closing bracket: literal "["
                i++;
              } else {
                out += "[" + (neg ? "^" : "") + cls + "]";
                i = j + 1;
              }
            } else if (c === "\\" && i + 1 < seg.length) {
              out += escapeRegExpChar(seg.charAt(i + 1));
              i += 2;
            } else {
              out += escapeRegExpChar(c);
              i++;
            }
          }
          return out;
        }

        // Convert a whole pattern (slashes kept) into regex source, handling **.
        function globToRegex(pat) {
          var segs = pat.split("/");
          var out = "";
          for (var i = 0; i < segs.length; i++) {
            var seg = segs[i];
            var isLast = i === segs.length - 1;
            if (seg === "**") {
              if (isLast) {
                // trailing "/**": everything below (separator already emitted)
                out += ".*";
              } else {
                // "**/": zero or more whole directories
                out += "(?:[^/]+/)*";
                continue; // the slash after ** is folded into the group
              }
            } else {
              out += segmentToRegex(seg);
            }
            if (!isLast) out += "/";
          }
          return out;
        }

        function parseRules(text) {
          var lines = text.split(/\r?\n/);
          var rules = [];
          for (var idx = 0; idx < lines.length; idx++) {
            var raw = lines[idx];
            var line = raw.replace(/\s+$/, "");
            if (line === "") continue;
            if (line.charAt(0) === "#") continue;
            var negated = false;
            var pat = line;
            if (pat.charAt(0) === "!") { negated = true; pat = pat.slice(1); }
            else if (pat.charAt(0) === "\\" && (pat.charAt(1) === "!" || pat.charAt(1) === "#")) { pat = pat.slice(1); }
            if (pat === "") continue;
            var dirOnly = false;
            if (pat.charAt(pat.length - 1) === "/") { dirOnly = true; pat = pat.slice(0, -1); }
            if (pat === "") continue;
            var anchored = false;
            if (pat.charAt(0) === "/") { anchored = true; pat = pat.slice(1); }
            if (pat.indexOf("/") !== -1) anchored = true;
            if (pat === "") continue;
            var regex;
            try {
              regex = new RegExp("^" + globToRegex(pat) + "$");
            } catch (e) {
              continue;
            }
            rules.push({
              lineNo: idx + 1,
              text: line,
              pattern: pat,
              negated: negated,
              dirOnly: dirOnly,
              anchored: anchored,
              regex: regex
            });
          }
          return rules;
        }

        // Does this rule match the given target path (or target's basename if floating)?
        function ruleMatchesTarget(rule, target) {
          var testStr = rule.anchored ? target : target.split("/").pop();
          return rule.regex.test(testStr);
        }

        // Find which part of `path` (itself or an ancestor directory) the rule matches.
        // Returns the matched target string, or null.
        function ruleMatchTarget(rule, path, pathIsDir) {
          var segs = path.split("/");
          for (var k = segs.length; k >= 1; k--) {
            var target = segs.slice(0, k).join("/");
            var targetIsDir = (k < segs.length) || pathIsDir;
            if (rule.dirOnly && !targetIsDir) continue;
            if (ruleMatchesTarget(rule, target)) return target;
          }
          return null;
        }

        function sensitiveTokenFor(path) {
          var lower = path.toLowerCase();
          for (var i = 0; i < SENSITIVE_TOKENS.length; i++) {
            if (lower.indexOf(SENSITIVE_TOKENS[i]) !== -1) return SENSITIVE_TOKENS[i];
          }
          return null;
        }

        function normalizePath(raw) {
          var p = raw.trim();
          if (p === "") return null;
          p = p.replace(/\\/g, "/");
          var isDir = false;
          if (p.charAt(p.length - 1) === "/") { isDir = true; p = p.replace(/\/+$/, ""); }
          p = p.replace(/^\.\//, "").replace(/^\//, "");
          if (p === "") return null;
          return { path: p, isDir: isDir };
        }

        function evaluate(rules, paths) {
          var out = [];
          for (var i = 0; i < paths.length; i++) {
            var entry = paths[i];
            var decision = null;
            var matchedTarget = null;
            for (var r = 0; r < rules.length; r++) {
              var t = ruleMatchTarget(rules[r], entry.path, entry.isDir);
              if (t !== null) { decision = rules[r]; matchedTarget = t; }
            }
            var ignored = decision !== null && !decision.negated;
            var wouldShip = !ignored;
            var token = sensitiveTokenFor(entry.path);
            out.push({
              path: entry.path,
              isDir: entry.isDir,
              decision: decision,
              matchedTarget: matchedTarget,
              ignored: ignored,
              wouldShip: wouldShip,
              sensitiveToken: token,
              blocker: wouldShip && token !== null
            });
          }
          return out;
        }

        function describeDecision(res) {
          if (!res.decision) return "no rule matched";
          var d = res.decision;
          var s = "rule " + d.lineNo + ": \"" + d.text + "\"";
          if (d.negated) s += " (negation — re-includes the path)";
          if (res.matchedTarget && res.matchedTarget !== res.path) {
            s += " — matched via directory \"" + res.matchedTarget + "/\"";
          }
          return s;
        }
  return { "evaluate": (typeof evaluate !== 'undefined' ? evaluate : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_RULES": (typeof EXAMPLE_RULES !== 'undefined' ? EXAMPLE_RULES : undefined), "EXAMPLE_PATHS": (typeof EXAMPLE_PATHS !== 'undefined' ? EXAMPLE_PATHS : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["evaluate"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-ignore-rule-publish-safety-auditor',
  name: 'J-Dawgs Ignore-Rule & Publish-Safety Auditor',
  description: 'Single-path ignore checkers stop at one file and one yes/no; ours tests a whole file list at once, names the exact rule that decided each path, and flags sensitive files that would still ship',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["evaluate"]) return { ok: false, output: null, summary: 'Extracted core has no evaluate function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_RULES": __core["EXAMPLE_RULES"], "EXAMPLE_PATHS": __core["EXAMPLE_PATHS"] }
};
