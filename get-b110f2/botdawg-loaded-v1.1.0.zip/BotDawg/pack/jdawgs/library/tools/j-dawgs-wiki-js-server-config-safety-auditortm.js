'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Wiki.js Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

/* ---------- Worked examples (line numbers are part of the spec) ---------- */
var RISKY_LINES = [
  "# Wiki.js config.yml - RISKY worked example (do not deploy as-is)", // 1
  "port: 3000",                                                        // 2
  "bindIP: 0.0.0.0",                                                   // 3
  "ssl:",                                                              // 4
  "  enabled: false",                                                  // 5
  "  provider: custom",                                                // 6
  "  rejectUnauthorized: false",                                       // 7
  "db:",                                                               // 8
  "  type: postgres",                                                  // 9
  "  host: db.internal",                                               // 10
  "  user: wikijs",                                                    // 11
  "  pass: wikijs123",                                                 // 12
  "  db: wiki",                                                        // 13
  "dataPath: ./data",                                                  // 14
  "uploads:",                                                          // 15
  "  maxFileSize: 52428800",                                           // 16
  "  maxOtherFileSize: 52428800",                                      // 17
  "auth:",                                                             // 18
  "  local:",                                                          // 19
  "    enabled: true",                                                 // 20
  "  registration:",                                                   // 21
  "    enabled: true",                                                 // 22
  "    requireApproval: false",                                        // 23
  "sessionSecret: abc123",                                             // 24
  "telemetry:",                                                        // 25
  "  enabled: true",                                                   // 26
  "debug: true",                                                       // 27
  "public: true"                                                       // 28
];
var RISKY = RISKY_LINES.join("\n");

var HARDENED_LINES = [
  "# Wiki.js config.yml - HARDENED worked example",
  "port: 3000",
  "bindIP: 127.0.0.1",
  "ssl:",
  "  enabled: true",
  "  provider: letsencrypt",
  "  rejectUnauthorized: true",
  "db:",
  "  type: postgres",
  "  host: db.internal",
  "  user: wikijs",
  "  pass: ${DB_PASS}",
  "  db: wiki",
  "dataPath: ./data",
  "uploads:",
  "  maxFileSize: 5242880",
  "  maxOtherFileSize: 2097152",
  "auth:",
  "  local:",
  "    enabled: true",
  "  google:",
  "    enabled: true",
  "  registration:",
  "    enabled: false",
  "    requireApproval: true",
  "sessionSecret: ${SESSION_SECRET}",
  "telemetry:",
  "  enabled: false",
  "debug: false",
  "public: false"
];
var HARDENED = HARDENED_LINES.join("\n");

/* ---------- Parsing ---------- */
function cleanValue(v) {
  v = (v || "").trim();
  var hashIdx = v.indexOf(" #");
  if (hashIdx > 0 && v.charAt(0) !== '"' && v.charAt(0) !== "'") v = v.slice(0, hashIdx).trim();
  if (v.length >= 2 && ((v.charAt(0) === '"' && v.charAt(v.length - 1) === '"') || (v.charAt(0) === "'" && v.charAt(v.length - 1) === "'"))) {
    v = v.slice(1, -1);
  }
  return v;
}
function truthy(v) { var s = String(v).toLowerCase(); return s === "true" || s === "yes" || s === "on" || s === "1"; }
function falsy(v) { var s = String(v).toLowerCase(); return s === "false" || s === "no" || s === "off" || s === "0"; }
function isPlaceholder(v) {
  if (!v) return true;
  return v.indexOf("${") === 0 || v.indexOf("$") === 0 || v.indexOf("process.env") === 0 ||
         v === "***" || v === "REDACTED" || v === "..." || v.indexOf("{{") === 0;
}
function normKey(k) { return String(k).toLowerCase().replace(/[^a-z0-9]/g, ""); }

function parseConfig(text) {
  var entries = [];
  var lines = String(text || "").split(/\r?\n/);
  var stack = []; // {indent, key}
  for (var i = 0; i < lines.length; i++) {
    var raw = lines[i];
    var lineNo = i + 1;
    var trimmed = raw.trim();
    if (!trimmed || trimmed.charAt(0) === "#") continue;
    // env-style: KEY=value (uppercase-ish key at column 0)
    var envM = raw.match(/^([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/);
    if (envM && raw.charAt(0) !== " " && raw.charAt(0) !== "\t") {
      entries.push({ line: lineNo, path: [envM[1]], key: envM[1], value: cleanValue(envM[2]) });
      continue;
    }
    var m = raw.match(/^(\s*)([A-Za-z0-9_.\-"']+)\s*:\s*(.*)$/);
    if (!m) continue;
    var indent = m[1].replace(/\t/g, "  ").length;
    var keyParts = m[2].replace(/["']/g, "").split(".").filter(function (s) { return s.length; });
    var value = cleanValue(m[3]);
    while (stack.length && stack[stack.length - 1].indent >= indent) stack.pop();
    var path = stack.map(function (s) { return s.key; }).concat(keyParts);
    entries.push({ line: lineNo, path: path, key: keyParts[keyParts.length - 1], value: value });
    if (value === "") {
      stack.push({ indent: indent, key: keyParts[keyParts.length - 1] });
    }
  }
  return entries;
}

function pathStr(e) { return e.path.join("."); }
function pathHas(e, name) {
  var n = normKey(name);
  return e.path.some(function (p) { return normKey(p) === n; });
}
function findEntries(entries, pred) { return entries.filter(pred); }

/* ---------- Audit ---------- */
var EXAMPLE_SECRETS = ["password","pass","passwd","admin","changeme","change-me","change_me","example","wikijs","wikijs123","secret","abc123","123456","12345678","letmein","default","test","qwerty","postgres","root"];
var SECRET_KEY_RE = /(pass|secret|token|apikey|privatekey|credential)/;
var KNOWN_KEYS = ["port","bindip","ssl","db","auth","datapath","uploads","telemetry","debug","sessionsecret","registration","public","offline","host","data"];

function audit(text) {
  var entries = parseConfig(text);
  var findings = [];
  var passed = [];
  function add(sev, line, check, key, detail, fix, extra) {
    var f = { severity: sev, line: (line == null ? null : line), check: check, key: key, detail: detail, fix: fix };
    if (extra) { for (var k in extra) f[k] = extra[k]; }
    findings.push(f);
  }

  // Gradeability: need several config-shaped lines and at least one known Wiki.js key.
  var knownHits = entries.filter(function (e) {
    return e.path.some(function (p) { return KNOWN_KEYS.indexOf(normKey(p)) !== -1; }) ||
           SECRET_KEY_RE.test(normKey(e.key));
  }).length;
  if (entries.length < 4 || knownHits < 1) {
    return {
      verdict: "NOT ENOUGH TO GRADE",
      gradeable: false,
      findings: [],
      passed: [],
      counts: { CRITICAL: 0, HIGH: 0, MEDIUM: 0, LOW: 0 },
      entryCount: entries.length,
      note: "The pasted text does not look like a Wiki.js config (too few key/value lines, or none of the keys this auditor recognises). Paste a config.yml or env-style config and run the audit again."
    };
  }

  /* bindIP */
  var bindEntries = findEntries(entries, function (e) { return normKey(e.key) === "bindip" || normKey(e.key) === "bind_ip".toLowerCase(); });
  if (!bindEntries.length) {
    add("MEDIUM", null, "Network binding", "bindIP", "bindIP is not stated in the config. If the runtime default binds broadly, the wiki may listen on every interface.", "Set bindIP explicitly — 127.0.0.1 when a reverse proxy fronts the server.");
  }
  bindEntries.forEach(function (e) {
    var v = e.value;
    if (v === "0.0.0.0" || v === "::" || v === "*" || v === "[::]" || v === "") {
      add("CRITICAL", e.line, "Network binding", "bindIP", "bindIP is set to \"" + (v || "(empty)") + "\" — Wiki.js will listen on all network interfaces, exposing the app (and its admin surface) to the whole network.", "Bind to 127.0.0.1 behind a reverse proxy, or to one specific private interface.");
    } else if (v === "127.0.0.1" || v === "localhost" || v === "::1") {
      passed.push("Line " + e.line + ": bindIP is loopback-only (" + v + ").");
    } else {
      passed.push("Line " + e.line + ": bindIP is set to a specific interface (" + v + ").");
    }
  });

  /* SSL posture */
  var sslEntries = findEntries(entries, function (e) { return pathHas(e, "ssl") || normKey(e.key).indexOf("ssl") === 0; });
  var sslEnabledEntries = findEntries(entries, function (e) {
    return (pathHas(e, "ssl") && normKey(e.key) === "enabled") || normKey(e.key) === "sslenabled";
  });
  if (!sslEntries.length) {
    add("HIGH", null, "SSL / HTTPS", "ssl", "No ssl section or SSL keys were found. As pasted, there is no evidence HTTPS is enabled — logins and session cookies may travel over plain HTTP.", "Enable SSL (Let's Encrypt or a real certificate) in the config, or terminate TLS at a reverse proxy and say so in your deploy notes.");
  } else if (!sslEnabledEntries.length) {
    add("MEDIUM", null, "SSL / HTTPS", "ssl.enabled", "An ssl section exists but ssl.enabled is never stated, so the HTTPS posture is ambiguous.", "State ssl.enabled explicitly.");
  }
  sslEnabledEntries.forEach(function (e) {
    if (falsy(e.value)) {
      add("CRITICAL", e.line, "SSL / HTTPS", "ssl.enabled", "ssl.enabled is false — Wiki.js will serve over plain HTTP. Credentials, session cookies, and page content are exposed in transit.", "Set ssl.enabled to true with a valid certificate, or front the server with a TLS-terminating reverse proxy.");
    } else if (truthy(e.value)) {
      passed.push("Line " + e.line + ": ssl.enabled is true.");
    }
  });
  findEntries(entries, function (e) { return normKey(e.key) === "rejectunauthorized"; }).forEach(function (e) {
    if (falsy(e.value)) {
      add("HIGH", e.line, "SSL / HTTPS", pathStr(e), "rejectUnauthorized is false — certificate verification is switched off, so a man-in-the-middle with any certificate will be trusted.", "Set rejectUnauthorized to true and fix the underlying certificate problem instead.");
    } else if (truthy(e.value)) {
      passed.push("Line " + e.line + ": rejectUnauthorized is true (certificate verification on).");
    }
  });
  findEntries(entries, function (e) { return pathHas(e, "ssl") && normKey(e.key) === "provider"; }).forEach(function (e) {
    var v = e.value.toLowerCase();
    if (v === "custom" || v === "self-signed" || v === "selfsigned") {
      add("MEDIUM", e.line, "SSL / HTTPS", "ssl.provider", "ssl.provider is \"" + e.value + "\" — a custom/self-signed posture. Browsers will warn (or verification is being bypassed somewhere) unless clients have been given the CA out of band.", "Prefer a publicly trusted certificate (e.g. Let's Encrypt) for anything reachable beyond your own machines.");
    } else if (v) {
      passed.push("Line " + e.line + ": ssl.provider is \"" + e.value + "\".");
    }
  });

  /* Registration & public access */
  var regEnabled = findEntries(entries, function (e) {
    return (pathHas(e, "registration") && normKey(e.key) === "enabled") || normKey(e.key) === "registrationenabled";
  });
  var regOpen = false;
  regEnabled.forEach(function (e) {
    if (truthy(e.value)) {
      regOpen = true;
      add("HIGH", e.line, "Registration & public access", pathStr(e), "Public registration is enabled — anyone who can reach the wiki can create an account.", "Disable public registration, or require admin approval for every new account.");
    } else if (falsy(e.value)) {
      passed.push("Line " + e.line + ": public registration is disabled.");
    }
  });
  if (regOpen) {
    findEntries(entries, function (e) { return pathHas(e, "registration") && normKey(e.key) === "requireapproval"; }).forEach(function (e) {
      if (falsy(e.value)) {
        add("MEDIUM", e.line, "Registration & public access", pathStr(e), "Registration is open and requireApproval is false — new accounts are active immediately, with no human in the loop.", "Set requireApproval to true so an admin approves each registration.");
      }
    });
  }
  findEntries(entries, function (e) { return normKey(e.key) === "public"; }).forEach(function (e) {
    if (truthy(e.value)) {
      add("HIGH", e.line, "Registration & public access", pathStr(e), "public access is set to true — content may be readable without an account.", "Set public to false unless this wiki is deliberately world-readable.");
    } else if (falsy(e.value)) {
      passed.push("Line " + e.line + ": public access is off.");
    }
  });

  /* Secrets: DB passwords, session secrets, tokens — value NEVER reported */
  var secretEntries = findEntries(entries, function (e) { return SECRET_KEY_RE.test(normKey(e.key)); });
  secretEntries.forEach(function (e) {
    var keyLabel = pathStr(e);
    var v = e.value;
    if (!v) {
      add("MEDIUM", e.line, "Secrets", keyLabel, "Secret key \"" + keyLabel + "\" is present but empty (value length 0).", "Set a long random value, supplied via environment or a secrets manager.", { valueLength: 0 });
      return;
    }
    if (isPlaceholder(v)) {
      passed.push("Line " + e.line + ": \"" + keyLabel + "\" is supplied by reference (environment/placeholder), not stored in the config.");
      return;
    }
    var len = v.length;
    var isDbPass = pathHas(e, "db") || normKey(e.key).indexOf("db") === 0;
    var isSession = normKey(e.key).indexOf("session") !== -1 || normKey(e.key) === "secret" || normKey(e.key).indexOf("jwt") !== -1;
    var minLen = isSession ? 32 : 16;
    if (EXAMPLE_SECRETS.indexOf(v.toLowerCase()) !== -1) {
      add("CRITICAL", e.line, "Secrets", keyLabel, "Secret key \"" + keyLabel + "\" holds a well-known example/default value (reported by length only: " + len + " characters). Anyone who has seen a sample config knows this value.", "Replace it with a long random value and supply it via environment or a secrets manager — never commit it to the config file.", { valueLength: len });
    } else if (len < minLen) {
      add("HIGH", e.line, "Secrets", keyLabel, "Secret key \"" + keyLabel + "\" is short — value length is " + len + " characters (minimum expected " + minLen + "). Short secrets are brute-forceable. The value itself is never shown in this audit.", "Use a generated random value of at least " + minLen + " characters, supplied via environment or a secrets manager.", { valueLength: len });
    } else {
      add(isDbPass || isSession ? "MEDIUM" : "LOW", e.line, "Secrets", keyLabel, "Secret key \"" + keyLabel + "\" is stored as plaintext in the config (value length " + len + "; value never shown). Anyone who reads this file has the secret.", "Move it to an environment variable or secrets manager and reference it from the config.", { valueLength: len });
    }
  });

  /* Debug & telemetry */
  var sawDebug = false;
  findEntries(entries, function (e) { return normKey(e.key) === "debug"; }).forEach(function (e) {
    sawDebug = true;
    if (truthy(e.value)) {
      add("HIGH", e.line, "Debug & telemetry", pathStr(e), "Debug mode is on. Debug output can leak stack traces, paths, and config detail to anyone who can trigger an error.", "Set debug to false in production.");
    } else if (falsy(e.value)) {
      passed.push("Line " + e.line + ": debug is off.");
    }
  });
  findEntries(entries, function (e) { return normKey(e.key) === "loglevel"; }).forEach(function (e) {
    if (e.value.toLowerCase() === "debug" || e.value.toLowerCase() === "verbose") {
      add("MEDIUM", e.line, "Debug & telemetry", pathStr(e), "Log level is \"" + e.value + "\" — verbose logs can capture sensitive request and config detail.", "Use info or warn in production.");
    }
  });
  findEntries(entries, function (e) { return pathHas(e, "telemetry") && normKey(e.key) === "enabled"; }).forEach(function (e) {
    if (truthy(e.value)) {
      add("LOW", e.line, "Debug & telemetry", pathStr(e), "Telemetry is enabled — the server will send usage data outbound. Not a break-in risk by itself, but it should be a deliberate choice.", "Disable telemetry unless you have decided you want it.");
    } else if (falsy(e.value)) {
      passed.push("Line " + e.line + ": telemetry is off.");
    }
  });

  /* Auth strategy */
  var providerKeys = ["local","ldap","saml","oauth","oauth2","google","github","azure","microsoft","facebook","discord","keycloak","auth0","okta","generic"];
  var authEntries = findEntries(entries, function (e) {
    return pathHas(e, "auth") || providerKeys.indexOf(normKey(e.key)) !== -1 || normKey(e.key).indexOf("auth") !== -1;
  });
  if (!authEntries.length) {
    add("MEDIUM", null, "Authentication", "auth", "No authentication strategy is declared in the pasted config. How users sign in — and who can — is left to defaults.", "Declare at least one auth strategy explicitly and disable the ones you do not use.");
  } else {
    var enabledProviders = {};
    entries.forEach(function (e) {
      providerKeys.forEach(function (pk) {
        if (pathHas(e, pk) && normKey(e.key) === "enabled" && truthy(e.value)) enabledProviders[pk] = e.line;
      });
    });
    var names = Object.keys(enabledProviders);
    if (names.length === 1 && names[0] === "local") {
      add("LOW", enabledProviders.local, "Authentication", "auth.local", "Local accounts are the only enabled sign-in strategy. That is workable, but password strength and account lifecycle rest entirely on this server.", "Consider an external identity provider or enforced strong passwords for anything beyond a personal wiki.");
    } else if (names.length) {
      passed.push("Authentication strategies enabled: " + names.join(", ") + ".");
    }
    findEntries(entries, function (e) { return normKey(e.key) === "require2fa" || normKey(e.key) === "enforce2fa" || normKey(e.key) === "requiremfa"; }).forEach(function (e) {
      if (falsy(e.value)) {
        add("MEDIUM", e.line, "Authentication", pathStr(e), "Two-factor enforcement is explicitly off for a server that may hold private knowledge.", "Turn on 2FA enforcement for admin accounts at minimum.");
      }
    });
  }

  /* Uploads */
  findEntries(entries, function (e) { return normKey(e.key) === "maxfilesize" || normKey(e.key) === "maxotherfilesize"; }).forEach(function (e) {
    var n = parseInt(e.value, 10);
    if (!isNaN(n) && n > 20971520) {
      add("MEDIUM", e.line, "Uploads & files", pathStr(e), "Upload size limit \"" + pathStr(e) + "\" is " + n + " bytes (over 20 MB). Oversized uploads are an easy disk-fill and denial-of-service lever on a self-hosted box.", "Bring upload limits down to what your users actually need.");
    } else if (!isNaN(n)) {
      passed.push("Line " + e.line + ": " + pathStr(e) + " is " + n + " bytes (within a sane range).");
    }
  });

  /* DB section sanity (no values beyond key names) */
  if (!findEntries(entries, function (e) { return pathHas(e, "db"); }).length) {
    add("LOW", null, "Database", "db", "No db section was found in the pasted config — database posture could not be graded.", "Include the db section (with secrets referenced, not written out) when you audit.");
  }

  var sevOrder = { CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3 };
  findings.sort(function (a, b) {
    var d = sevOrder[a.severity] - sevOrder[b.severity];
    if (d) return d;
    return (a.line || 9999) - (b.line || 9999);
  });
  var counts = { CRITICAL: 0, HIGH: 0, MEDIUM: 0, LOW: 0 };
  findings.forEach(function (f) { counts[f.severity]++; });

  var verdict;
  if (counts.CRITICAL > 0) verdict = "DO NOT DEPLOY";
  else if (counts.HIGH > 0 || counts.MEDIUM > 0) verdict = "DEPLOY WITH FIXES";
  else verdict = "SAFE TO DEPLOY";

  return { verdict: verdict, gradeable: true, findings: findings, passed: passed, counts: counts, entryCount: entries.length, note: "" };
}

/* ---------- Reports (built from findings only — input is never echoed) ---------- */
function buildReport(r) {
  var L = [];
  L.push("J-Dawgs Wiki.js Server Config Safety Auditor - Audit Report");
  L.push("==============================================================");
  L.push("Verdict: " + r.verdict);
  if (!r.gradeable) {
    L.push("");
    L.push(r.note);
    L.push("");
    L.push("Method: heuristic text audit, run locally in the browser. This tool does not start Wiki.js and does not verify certificate signatures or trust.");
    return L.join("\n");
  }
  L.push("Findings: " + r.findings.length + " (CRITICAL " + r.counts.CRITICAL + ", HIGH " + r.counts.HIGH + ", MEDIUM " + r.counts.MEDIUM + ", LOW " + r.counts.LOW + ")");
  L.push("Config lines recognised: " + r.entryCount);
  L.push("");
  L.push("FINDINGS");
  L.push("--------");
  if (!r.findings.length) L.push("None.");
  r.findings.forEach(function (f, i) {
    L.push((i + 1) + ". [" + f.severity + "] " + f.check + " - key \"" + f.key + "\"" + (f.line ? " - line " + f.line : " - not present in config"));
    L.push("   " + f.detail);
    L.push("   Fix: " + f.fix);
  });
  L.push("");
  L.push("CHECKS THAT PASSED");
  L.push("------------------");
  if (!r.passed.length) L.push("None recorded.");
  r.passed.forEach(function (p) { L.push("- " + p); });
  L.push("");
  L.push("SECRET HANDLING");
  L.push("---------------");
  L.push("Password, secret, token, and API-key values were never copied into this report. Secret findings name only the key, its line, and the value length.");
  L.push("");
  L.push("LIMITS");
  L.push("------");
  L.push("Heuristic text audit of the pasted config only. This tool does not start Wiki.js, does not connect to any server or database, and does not verify certificate signatures, chain of trust, DNS, or reverse-proxy settings. Runtime environment overrides are not visible here.");
  return L.join("\n");
}
function buildJson(r) {
  var obj = {
    tool: "J-Dawgs Wiki.js Server Config Safety Auditor",
    verdict: r.verdict,
    gradeable: r.gradeable,
    counts: r.counts,
    configLinesRecognised: r.entryCount,
    findings: r.findings.map(function (f) {
      var o = { severity: f.severity, line: f.line, check: f.check, key: f.key, detail: f.detail, fix: f.fix };
      if (typeof f.valueLength === "number") o.valueLength = f.valueLength;
      return o;
    }),
    passedChecks: r.passed,
    secretHandling: "Secret values are never included. Secret findings carry key name, line, and valueLength only.",
    limits: "Heuristic text audit only. Does not start Wiki.js. Does not verify certificate signatures or trust. Runtime environment overrides are not visible."
  };
  if (!r.gradeable) obj.note = r.note;
  return JSON.stringify(obj, null, 2);
}
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_SECRETS": (typeof EXAMPLE_SECRETS !== 'undefined' ? EXAMPLE_SECRETS : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-wiki-js-server-config-safety-auditortm',
  name: 'J-Dawgs Wiki.js Server Config Safety Auditor',
  description: 'Host tools only tell you the server started; ours grades a pasted Wiki.js config.yml offline into one deploy verdict — secrets reported by key name/line/length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_SECRETS": __core["EXAMPLE_SECRETS"] }
};
