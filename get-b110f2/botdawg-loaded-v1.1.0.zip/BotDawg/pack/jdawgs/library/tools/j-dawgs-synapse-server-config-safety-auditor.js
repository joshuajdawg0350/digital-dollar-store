'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Synapse Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ============================================================
         Worked examples. Planted line numbers are real: the auditor
         reports the line each key actually sits on.
         ============================================================ */
      var RISKY_EXAMPLE = [
        "# Risky example homeserver.yaml - planted problems, do not deploy as-is",
        'server_name: "chat.example.org"',
        'public_baseurl: "http://matrix.example.org/"',
        "pid_file: /run/synapse.pid",
        "listeners:",
        "  - port: 8008",
        "    tls: false",
        "    type: http",
        "    x_forwarded: true",
        "    bind_addresses: ['0.0.0.0']",
        "    resources:",
        "      - names: [client, federation]",
        "        compress: false",
        "  - port: 9000",
        "    type: metrics",
        "    bind_addresses: ['0.0.0.0']",
        "database:",
        "  name: psycopg2",
        "  args:",
        "    user: synapse",
        '    password: "hunter2"',
        "    database: synapse",
        "    host: localhost",
        'signing_key_path: "/data/chat.example.org.signing.key"',
        'macaroon_secret_key: "changeme"',
        'form_secret: "short"',
        'registration_shared_secret: "example-secret"',
        "enable_registration: true",
        "enable_registration_without_verification: true",
        "allow_public_rooms_without_auth: true",
        "allow_public_rooms_over_federation: true",
        "url_preview_enabled: true",
        "max_upload_size: 500M",
        "report_stats: true"
      ].join("\n");

      var HARDENED_EXAMPLE = [
        "# Hardened example homeserver.yaml - the same server, locked down",
        'server_name: "chat.example.org"',
        'public_baseurl: "https://chat.example.org/"',
        "pid_file: /run/synapse.pid",
        "listeners:",
        "  - port: 8008",
        "    tls: false",
        "    type: http",
        "    x_forwarded: true",
        "    bind_addresses: ['127.0.0.1']",
        "    resources:",
        "      - names: [client, federation]",
        "        compress: false",
        "  - port: 9000",
        "    type: metrics",
        "    bind_addresses: ['127.0.0.1']",
        "database:",
        "  name: psycopg2",
        "  args:",
        "    user: synapse",
        '    password: "${SYNAPSE_DB_PASSWORD}"',
        "    database: synapse",
        "    host: localhost",
        'signing_key_path: "/data/chat.example.org.signing.key"',
        'macaroon_secret_key: "kX9mP2vR7qL4zN8wT3hJ6sD1fG5bVcX0aZpQeWrTyUiO4nM7kL2"',
        'form_secret: "aB3dF5gH7jK9mN2pQ4rS6tU8vW0xZ1cVbNeRtYuIoP3sD6fG9h"',
        'registration_shared_secret: "pO9iU7yT5rE3wQ1aS4dF6gH8jK0lZ2xCvBnMkJhGfDsA5qW7eR"',
        "enable_registration: false",
        "registrations_require_3pid:",
        "  - email",
        "allow_public_rooms_without_auth: false",
        "allow_public_rooms_over_federation: false",
        "url_preview_enabled: false",
        'media_store_path: "/data/media_store"',
        "max_upload_size: 50M",
        "password_config:",
        "  enabled: true",
        "report_stats: false"
      ].join("\n");

      /* ============================================================
         Line model + tiny YAML-ish helpers (heuristic, text-only).
         ============================================================ */
      function buildLines(text) {
        var raw = String(text == null ? "" : text).split(/\r\n|\r|\n/);
        return raw.map(function (t, i) {
          var lead = t.match(/^[ \t]*/)[0];
          return {
            n: i + 1,
            text: t,
            indent: lead.replace(/\t/g, "  ").length,
            hasTab: lead.indexOf("\t") >= 0,
            blank: t.trim() === "",
            comment: /^\s*#/.test(t)
          };
        });
      }

      function keyRegex(name) {
        return new RegExp("^\\s*" + name + "\\s*:\\s*(.*)$");
      }

      function findKeys(lines, name) {
        var re = keyRegex(name), out = [];
        lines.forEach(function (L) {
          if (L.blank || L.comment) return;
          var m = L.text.match(re);
          if (m) out.push({ line: L.n, indent: L.indent, raw: m[1] });
        });
        return out;
      }

      function parseScalar(raw) {
        var s = String(raw == null ? "" : raw).trim();
        if (s.charAt(0) === '"' || s.charAt(0) === "'") {
          var q = s.charAt(0), end = s.indexOf(q, 1);
          return end === -1 ? s.slice(1) : s.slice(1, end);
        }
        var h = s.indexOf(" #");
        if (h >= 0) s = s.slice(0, h);
        return s.trim();
      }

      function isTrue(raw) { return parseScalar(raw).toLowerCase() === "true"; }
      function isFalse(raw) { return parseScalar(raw).toLowerCase() === "false"; }

      function sectionEnd(lines, startIdx, indent) {
        for (var i = startIdx + 1; i < lines.length; i++) {
          var L = lines[i];
          if (L.blank || L.comment) continue;
          if (L.indent <= indent) return i;
        }
        return lines.length;
      }

      function findKeyInRange(lines, from, to, name) {
        var re = keyRegex(name);
        for (var i = from; i < to && i < lines.length; i++) {
          var L = lines[i];
          if (L.blank || L.comment) continue;
          var m = L.text.match(re);
          if (m) return { line: L.n, indent: L.indent, raw: m[1], idx: i };
        }
        return null;
      }

      function isPlaceholderValue(v) {
        var s = String(v).toLowerCase();
        if (!s) return false;
        var needles = ["example", "changeme", "change_me", "change-me", "change me",
          "placeholder", "replace_me", "replace me", "your_secret", "your-secret",
          "your secret", "insert", "somesecret", "super secret", "xxxx", "todo",
          "fixme", "default_secret", "secret_key_here", "sample"];
        for (var i = 0; i < needles.length; i++) {
          if (s.indexOf(needles[i]) >= 0) return true;
        }
        if (/^(secret|password|passwd|letmein|hunter2|123456|12345678|qwerty)$/.test(s)) return true;
        if (/^(.)\1{7,}$/.test(s)) return true; /* aaaaaaaa-style repeats */
        return false;
      }

      /* Parse the listeners: section into blocks. */
      function parseListeners(lines) {
        var start = -1, sIndent = 0;
        for (var i = 0; i < lines.length; i++) {
          var L = lines[i];
          if (L.blank || L.comment) continue;
          if (keyRegex("listeners").test(L.text)) { start = i; sIndent = L.indent; break; }
        }
        if (start < 0) return null;
        var end = sectionEnd(lines, start, sIndent);
        var blocks = [], cur = null, itemIndent = -1;
        for (var j = start + 1; j < end; j++) {
          var Lj = lines[j];
          if (Lj.blank || Lj.comment) continue;
          var m = Lj.text.match(/^(\s*)-\s+(.*)$/);
          if (m) {
            var ind = m[1].replace(/\t/g, "  ").length;
            if (itemIndent < 0) itemIndent = ind;
            if (ind <= itemIndent) {
              cur = { lines: [] };
              blocks.push(cur);
            }
          }
          if (cur) cur.lines.push(Lj);
        }
        return blocks.map(function (b) {
          var text = b.lines.map(function (x) { return x.text; }).join("\n");
          var info = {
            port: null, portLine: null, type: null, typeLine: null,
            tls: null, tlsLine: null, bindLine: null,
            bindAll: false, bindLoop: false, hasBindKey: false,
            names: "", firstLine: b.lines.length ? b.lines[0].n : null
          };
          b.lines.forEach(function (x) {
            var pm = x.text.match(/^\s*-?\s*port\s*:\s*(\d+)/);
            if (pm && info.port === null) { info.port = pm[1]; info.portLine = x.n; }
            var tm = x.text.match(/^\s*-?\s*type\s*:\s*([A-Za-z_]+)/);
            if (tm && info.type === null) { info.type = tm[1].toLowerCase(); info.typeLine = x.n; }
            var lm = x.text.match(/^\s*tls\s*:\s*(true|false)/i);
            if (lm && info.tls === null) { info.tls = lm[1].toLowerCase() === "true"; info.tlsLine = x.n; }
            if (/bind_address/.test(x.text)) { info.hasBindKey = true; if (info.bindLine === null) info.bindLine = x.n; }
            var nm = x.text.match(/names\s*:\s*\[([^\]]*)\]/);
            if (nm) info.names += " " + nm[1].toLowerCase();
          });
          if (text.indexOf("0.0.0.0") >= 0) info.bindAll = true;
          if (text.replace(/::1/g, "").indexOf("::") >= 0) info.bindAll = true;
          if (text.indexOf("127.0.0.1") >= 0 || text.indexOf("::1") >= 0) info.bindLoop = true;
          if (!info.names) {
            if (/\bfederation\b/.test(text)) info.names += " federation";
            if (/\bclient\b/.test(text)) info.names += " client";
          }
          return info;
        });
      }

      /* Which lines cannot be read as YAML structure at all? */
      function findNotParsed(lines) {
        var bad = [], content = 0;
        lines.forEach(function (L) {
          if (L.blank || L.comment) return;
          content++;
          if (L.hasTab) { bad.push(L.n); return; }
          if (/^\s*(?:-\s+)?[A-Za-z0-9_"'][^:]*:\s*.*$/.test(L.text)) return; /* key: ... */
          if (/^\s*-\s+\S/.test(L.text)) return;                               /* - list item */
          if (/^\s*-\s*$/.test(L.text)) return;
          bad.push(L.n);
        });
        return { bad: bad, content: content };
      }

      var SYNAPSE_MARKERS = ["server_name", "listeners", "enable_registration",
        "public_baseurl", "database", "signing_key_path", "macaroon_secret_key",
        "form_secret", "registration_shared_secret", "media_store_path",
        "report_stats", "url_preview_enabled", "password_config",
        "allow_public_rooms_without_auth", "allow_public_rooms_over_federation"];

      /* ============================================================
         The audit itself.
         ============================================================ */
      function audit(configText, notesText) {
        var lines = buildLines(configText);
        var findings = [];
        function add(sev, line, key, title, meaning, fix) {
          findings.push({ severity: sev, line: line, key: key, title: title, meaning: meaning, fix: fix });
        }

        var trimmed = String(configText || "").trim();
        var np = findNotParsed(lines);
        var notEnough = null;

        if (!trimmed) {
          notEnough = "Nothing was pasted — there is no config to grade.";
        } else if (trimmed.charAt(0) === "{") {
          notEnough = "The paste starts with “{” — it looks like JSON, not a Synapse homeserver.yaml. Paste the YAML file itself.";
        } else {
          var commaLines = lines.filter(function (L) { return !L.blank && !L.comment && /,\s*$/.test(L.text); }).length;
          if (np.content >= 4 && commaLines / np.content > 0.3) {
            notEnough = "Most content lines end in commas — this looks like JSON or another format, not YAML.";
          } else if (np.content >= 4 && np.bad.length / np.content > 0.35) {
            notEnough = "Too much of the paste can't be read as YAML structure (" + np.bad.length + " of " + np.content + " content lines), so grading it would mean guessing.";
          } else {
            var markers = 0;
            SYNAPSE_MARKERS.forEach(function (k) { if (findKeys(lines, k).length) markers++; });
            var keyLines = lines.filter(function (L) { return !L.blank && !L.comment && /^\s*(?:-\s+)?[A-Za-z0-9_"'][^:]*:/.test(L.text); }).length;
            if (markers === 0) {
              notEnough = "No Synapse keys were found (no server_name, listeners, database, enable_registration, …) — this doesn't look like a homeserver.yaml.";
            } else if (keyLines < 3) {
              notEnough = "Only " + keyLines + " recognizable config line(s) — not enough of a homeserver.yaml to grade.";
            }
          }
        }

        if (notEnough) {
          return { verdict: "NOT ENOUGH TO GRADE", reasons: [notEnough], findings: [], notParsed: np.bad, counts: null };
        }

        var notes = String(notesText || "");
        var proxyMentioned = /reverse proxy|tls terminat|terminat\w* tls|nginx|caddy|traefik|haproxy|load balancer/i.test(notes);

        /* ---- server_name / public_baseurl ---- */
        var sn = findKeys(lines, "server_name");
        var snVal = sn.length ? parseScalar(sn[0].raw) : "";
        if (!sn.length) {
          add("HIGH", null, "server_name",
            "server_name is missing",
            "Synapse cannot run without a server_name — it becomes the suffix of every user ID and room ID on the server, and it can't be changed later without breaking federation.",
            "Set server_name to your public domain, e.g. server_name: \"example.org\", before first start.");
        }
        var pb = findKeys(lines, "public_baseurl");
        var baseIsHttp = false;
        if (pb.length) {
          var pbVal = parseScalar(pb[0].raw);
          if (/^http:\/\//i.test(pbVal)) {
            baseIsHttp = true;
            add("HIGH", pb[0].line, "public_baseurl",
              "public_baseurl uses plain http://",
              "Clients and other servers will be sent to an unencrypted address. Logins, messages, and media cross the network in the clear unless something else terminates TLS in front.",
              "Serve the homeserver over HTTPS and set public_baseurl to the https:// address, e.g. \"https://" + (snVal || "your-domain") + "/\".");
          }
          var host = pbVal.replace(/^https?:\/\//i, "").split("/")[0].split(":")[0];
          if (snVal && host && host.toLowerCase() !== snVal.toLowerCase()) {
            add("WARNING", pb[0].line, "public_baseurl",
              "public_baseurl host doesn't match server_name",
              "The public baseurl host (" + host + ") differs from server_name (" + snVal + "). A different host is legitimate behind a reverse proxy or well-known delegation, but if it's a typo, clients get sent to the wrong place and federation breaks in confusing ways.",
              "Confirm the mismatch is deliberate (proxy/delegation). Otherwise set public_baseurl to \"https://" + snVal + "/\".");
          }
        } else {
          add("WARNING", null, "public_baseurl",
            "public_baseurl is not set",
            "Without it, Synapse derives client URLs from server_name and incoming request headers, which is easy to get subtly wrong behind proxies.",
            "Set public_baseurl explicitly to the https:// address clients use to reach this server.");
        }

        /* ---- registration ---- */
        var reg = findKeys(lines, "enable_registration");
        var wov = findKeys(lines, "enable_registration_without_verification");
        var has3pid = findKeys(lines, "registrations_require_3pid").length > 0 ||
                      findKeys(lines, "account_threepid_delegates").length > 0;
        var rc = findKeys(lines, "recaptcha_public_key");
        var hasCaptcha = rc.length > 0 && parseScalar(rc[0].raw).length >= 10 && !isPlaceholderValue(parseScalar(rc[0].raw));
        if (reg.length && isTrue(reg[0].raw)) {
          if (wov.length && isTrue(wov[0].raw)) {
            add("BLOCKER", wov[0].line, "enable_registration_without_verification",
              "Public registration is open with NO verification at all",
              "enable_registration is on and enable_registration_without_verification is true: anyone on the internet can create accounts instantly, with no captcha and no email check. Open servers like this get flooded with spam and abuse accounts, and can be shut down by their host.",
              "Set enable_registration: false, or remove enable_registration_without_verification and require verification — configure reCAPTCHA keys or registrations_require_3pid: [email] — before this server faces the internet.");
          } else if (!hasCaptcha && !has3pid) {
            add("BLOCKER", reg[0].line, "enable_registration",
              "Public registration is open with no captcha or email verification configured",
              "Registration is enabled but the config shows no reCAPTCHA keys and no email/3PID requirement, so account creation is effectively unguarded — the classic setup for spam floods and abuse signups.",
              "Either set enable_registration: false, or add a verification gate: reCAPTCHA (recaptcha_public_key / recaptcha_private_key) or registrations_require_3pid: [email].");
          } else {
            add("WARNING", reg[0].line, "enable_registration",
              "Public registration is open (with a verification gate)",
              "Anyone can sign up, but a captcha or email check is configured, which blunts automated abuse. Still a posture decision: open servers attract spam and moderation load.",
              "If this server is meant to be private, set enable_registration: false and hand out accounts manually. Otherwise keep the verification gate and watch signup rates.");
          }
        } else if (reg.length) {
          add("INFO", reg[0].line, "enable_registration",
            "Registration is closed",
            "enable_registration is false: only accounts you create (or create via a shared secret / SSO) can exist. This is the safe default for a private server.",
            "No change needed. To invite people later, create accounts with the admin API or register_user rather than opening public registration.");
        } else {
          add("INFO", null, "enable_registration",
            "enable_registration is not set — Synapse's default is closed",
            "Modern Synapse defaults to closed registration when the key is absent, so no public signup is expected. The auditor notes it because older configs sometimes relied on different defaults.",
            "No change needed. If you ever open registration, add a captcha or email verification gate at the same time.");
        }

        /* ---- listeners ---- */
        var listenerBlocks = parseListeners(lines);
        if (listenerBlocks === null) {
          add("WARNING", null, "listeners",
            "No listeners section found",
            "Without a listeners section the auditor can't verify bind addresses or TLS — and Synapse needs at least one HTTP listener to serve clients at all.",
            "Define listeners explicitly, bind internal listeners to 127.0.0.1, and make sure TLS is terminated at the listener or a reverse proxy.");
        } else if (listenerBlocks.length === 0) {
          add("WARNING", null, "listeners",
            "The listeners section couldn't be broken into listener entries",
            "The paste's listener entries didn't parse into blocks, so binds and TLS posture were not graded.",
            "Check the listeners formatting (each entry starts with “- port: …”) and re-run the audit.");
        } else {
          listenerBlocks.forEach(function (b) {
            var label = b.port ? ("port " + b.port) : "a listener";
            var anchor = b.bindLine || b.tlsLine || b.portLine || b.firstLine;
            if (b.type === "metrics") {
              if (b.bindAll) {
                add("HIGH", anchor, "listeners (metrics)",
                  "Metrics listener on " + label + " is bound to all interfaces",
                  "Synapse's metrics endpoint has no authentication. Bound to 0.0.0.0/::, anyone who can reach the port can read detailed server internals — user counts, room sizes, request patterns.",
                  "Bind the metrics listener to 127.0.0.1 (bind_addresses: ['127.0.0.1']) and scrape it locally, or firewall the port to your Prometheus host only.");
              } else if (b.bindLoop) {
                add("INFO", anchor, "listeners (metrics)",
                  "Metrics listener on " + label + " is bound to loopback only",
                  "The unauthenticated metrics endpoint is reachable only from this host, which is the safe posture.",
                  "No change needed. Keep it that way if you expose metrics later — scrape locally or over a private network.");
              } else {
                add("WARNING", anchor, "listeners (metrics)",
                  "Metrics listener on " + label + " has no clear bind restriction in the paste",
                  "The metrics endpoint is unauthenticated. The pasted config doesn't show a loopback bind for it, so the auditor can't confirm it isn't network-reachable.",
                  "Set bind_addresses: ['127.0.0.1'] on the metrics listener, or firewall its port to your monitoring host.");
              }
              return;
            }
            var isClientFed = b.names.indexOf("client") >= 0 || b.names.indexOf("federation") >= 0;
            if (b.bindAll) {
              add(isClientFed ? "HIGH" : "WARNING", anchor, "listeners",
                "Listener on " + label + " is bound to all interfaces (0.0.0.0 / ::)",
                "This listener answers on every network interface. For client/federation ports that may be intended — but combined with tls: false or no reverse proxy, Synapse itself is directly exposed to the internet with no encryption at its own socket.",
                "If a reverse proxy fronts this server, bind the listener to 127.0.0.1. If Synapse faces the network directly, restrict bind_addresses to the intended interface and terminate TLS.");
            }
            var noTls = (b.tls === false || b.tls === null);
            if (noTls && b.type !== "metrics") {
              if (b.bindLoop) {
                add("INFO", b.tlsLine || anchor, "listeners",
                  "Listener on " + label + " has TLS off but is loopback-only",
                  "That's the standard reverse-proxy pattern: the proxy terminates TLS publicly and Synapse speaks plain HTTP on localhost only. Safe as long as nothing else can reach this port.",
                  "No change needed — just make sure the proxy really terminates TLS and this port stays unreachable from other hosts.");
              } else if (baseIsHttp) {
                add("HIGH", b.tlsLine || anchor, "listeners",
                  "Listener on " + label + " has no TLS, and the public baseurl is http://",
                  "TLS appears to be terminated nowhere: the listener doesn't do it, and the published baseurl is plain HTTP. Client logins and federation traffic would cross the network unencrypted.",
                  "Terminate TLS — either set tls: true on the listener with real certificates, or put a reverse proxy with HTTPS in front and bind this listener to 127.0.0.1 — and change public_baseurl to https://.");
              } else if (proxyMentioned) {
                add("WARNING", b.tlsLine || anchor, "listeners",
                  "Listener on " + label + " has TLS off; your notes say a reverse proxy terminates TLS",
                  "That's a valid pattern, but this listener is not bound to loopback, so anything that can reach the port bypasses the proxy and its TLS (and any rate limits or access rules) entirely.",
                  "Bind this listener to 127.0.0.1, or firewall the port so only the proxy host can reach it.");
              } else {
                add("WARNING", b.tlsLine || anchor, "listeners",
                  "Listener on " + label + " has no TLS enabled",
                  "The listener itself doesn't terminate TLS. If a reverse proxy in front of it does, this is fine — but the config alone doesn't show that, and the listener isn't loopback-only.",
                  "Either enable tls: true here with certificates, or confirm a reverse proxy terminates TLS and bind this listener to 127.0.0.1.");
              }
            }
          });
        }

        /* ---- database ---- */
        var dbStart = -1, dbIndent = 0;
        for (var di = 0; di < lines.length; di++) {
          if (!lines[di].blank && !lines[di].comment && keyRegex("database").test(lines[di].text)) { dbStart = di; dbIndent = lines[di].indent; break; }
        }
        if (dbStart < 0) {
          add("WARNING", null, "database",
            "No database section — Synapse falls back to SQLite",
            "Without a database config, Synapse uses a local SQLite file. That's fine for a test box and a bottleneck for a real server: it serializes writes and doesn't scale past a handful of users.",
            "For anything beyond testing, configure PostgreSQL (name: psycopg2) with its own database and user.");
        } else {
          var dbEnd = sectionEnd(lines, dbStart, dbIndent);
          var dbName = findKeyInRange(lines, dbStart, dbEnd, "name");
          var dbPw = findKeyInRange(lines, dbStart, dbEnd, "password");
          if (dbName && parseScalar(dbName.raw).toLowerCase().indexOf("sqlite") >= 0) {
            add("INFO", dbName.line, "database",
              "Database is SQLite — no database password applies",
              "SQLite has no password to leak, but it also doesn't scale: fine for testing or a tiny private server, a bottleneck in production.",
              "No password action needed. Move to PostgreSQL before the server gets busy.");
          }
          if (dbPw) {
            var pwVal = parseScalar(dbPw.raw);
            if (/\$\{[^}]*\}/.test(pwVal) || /^env:/i.test(pwVal) || /\bENV\b/.test(pwVal)) {
              add("INFO", dbPw.line, "database.password",
                "Database password is an environment/external reference (" + pwVal.length + " characters), not a literal value",
                "The config points elsewhere for the password instead of embedding it, so the secret doesn't live in this file. Reported by length only, like every secret in this tool.",
                "No change needed — keep the real password in the environment or your secret store, out of the YAML.");
            } else {
              add("HIGH", dbPw.line, "database.password",
                "Database password is stored in plaintext in the config (" + pwVal.length + " characters)",
                "Anyone who reads this file — a backup, a repo commit, a support paste — gets full access to the homeserver's database, which holds every message and account. The value itself is never shown by this tool; only its length is reported.",
                "Move the password out of the file: supply it via an environment reference such as \"${SYNAPSE_DB_PASSWORD}\" (expanded by your launcher) or a secret manager, restrict this file's permissions, and rotate the password since it has existed in plaintext.");
            }
          } else if (dbName && parseScalar(dbName.raw).toLowerCase().indexOf("psycopg") >= 0) {
            add("INFO", lines[dbStart].n, "database",
              "PostgreSQL configured; no password key inside the pasted database section",
              "No plaintext password was found in the database block — it may come from a .pgpass file, the environment, or peer auth. The auditor can only grade what's pasted.",
              "No change needed if the password really lives outside this file.");
          }
        }

        /* ---- signing key ---- */
        var sk = findKeys(lines, "signing_key_path");
        if (sk.length) {
          add("INFO", sk[0].line, "signing_key_path",
            "signing_key_path is set — contents NOT CHECKED",
            "The path is noted, but this tool never opens the key file. If that key is lost, the server's identity is lost with it; if it leaks, anyone can impersonate the server to the federation.",
            "Back the signing key up somewhere safe and offline, keep its file permissions tight, and never paste its contents anywhere — including into this tool.");
        } else {
          add("WARNING", null, "signing_key_path",
            "No signing_key_path in the paste",
            "Synapse will use its default location, which may be inside the working directory where it's easy to lose in a rebuild — and losing the signing key means losing the server's identity.",
            "Set signing_key_path to a durable location you back up, e.g. \"/data/" + (snVal || "your-domain") + ".signing.key\".");
        }

        /* ---- secrets (value NEVER rendered — key, line, length only) ---- */
        function checkSecret(keyName, absentSev, absentTitle, absentMeaning, absentFix, placeholderSev) {
          var hits = findKeys(lines, keyName);
          if (!hits.length) {
            if (absentSev) add(absentSev, null, keyName, absentTitle, absentMeaning, absentFix);
            return;
          }
          var val = parseScalar(hits[0].raw);
          var len = val.length;
          if (len === 0) {
            add("HIGH", hits[0].line, keyName,
              keyName + " is set but empty",
              "An empty secret is no secret at all — anything derived from it is predictable.",
              "Set " + keyName + " to a random value of at least 32 characters (e.g. from a password generator) and restart Synapse.");
          } else if (isPlaceholderValue(val)) {
            add(placeholderSev, hits[0].line, keyName,
              keyName + " is an obvious example/placeholder value (" + len + " characters)",
              "The value matches a well-known example or placeholder pattern — the kind printed in sample configs and tutorials. Anyone who has read the same example knows this server's secret. The value is not shown here; only its length is reported.",
              "Replace " + keyName + " with a freshly generated random value of at least 32 characters, unique to this server, and restart Synapse.");
          } else if (len < 32) {
            add("HIGH", hits[0].line, keyName,
              keyName + " is too short (" + len + " characters)",
              "Secrets under 32 characters are guessable territory for an attacker who can test candidates offline or online. The value is not shown here; only its length is reported.",
              "Replace " + keyName + " with a random value of at least 32 characters (50+ is better) and restart Synapse.");
          } else {
            add("INFO", hits[0].line, keyName,
              keyName + " is present (" + len + " characters)",
              "Length looks healthy and the value doesn't match known example/placeholder patterns. The value itself is never displayed by this tool.",
              "No change needed. Keep it out of repos, tickets, and chat logs.");
          }
        }
        checkSecret("macaroon_secret_key", "WARNING",
          "macaroon_secret_key is not set",
          "Without a fixed macaroon secret, Synapse generates one at startup — so every restart invalidates all logged-in sessions and access tokens.",
          "Set macaroon_secret_key to a fixed random value of at least 32 characters.",
          "BLOCKER");
        checkSecret("form_secret", "WARNING",
          "form_secret is not set",
          "Without an explicit form secret, form/session protection falls back to generated or shared material that can change across restarts, breaking in-flight forms and sessions.",
          "Set form_secret to a fixed random value of at least 32 characters, different from the macaroon secret.",
          "BLOCKER");
        checkSecret("registration_shared_secret", "INFO",
          "registration_shared_secret is not set — shared-secret registration is off",
          "That's the normal posture: the admin registration endpoint can't be used with a shared secret because there isn't one.",
          "No change needed. If you set one later, make it random and at least 32 characters.",
          "HIGH");

        /* ---- federation posture ---- */
        var fwa = findKeys(lines, "allow_public_rooms_without_auth");
        if (fwa.length && isTrue(fwa[0].raw)) {
          add("HIGH", fwa[0].line, "allow_public_rooms_without_auth",
            "The public room directory is readable without any authentication",
            "allow_public_rooms_without_auth: true lets anyone — no account, no login — enumerate your server's public rooms. That's a privacy leak and a scraping invitation.",
            "Set allow_public_rooms_without_auth: false so the room directory requires a logged-in user.");
        } else if (fwa.length) {
          add("INFO", fwa[0].line, "allow_public_rooms_without_auth",
            "Public room directory requires authentication",
            "allow_public_rooms_without_auth is false — the directory isn't world-readable.",
            "No change needed.");
        }
        var fof = findKeys(lines, "allow_public_rooms_over_federation");
        if (fof.length && isTrue(fof[0].raw)) {
          add("WARNING", fof[0].line, "allow_public_rooms_over_federation",
            "The public room list is shared over federation",
            "Other homeservers can pull your public room directory, so your room list (names, topics, member counts) propagates across the federation whether you watch it or not.",
            "If your rooms aren't meant to be advertised network-wide, set allow_public_rooms_over_federation: false.");
        } else if (fof.length) {
          add("INFO", fof[0].line, "allow_public_rooms_over_federation",
            "Public room list is not shared over federation",
            "allow_public_rooms_over_federation is false — other servers can't enumerate your public rooms.",
            "No change needed.");
        }

        /* ---- media ---- */
        var msp = findKeys(lines, "media_store_path");
        if (!msp.length) {
          add("WARNING", null, "media_store_path",
            "media_store_path is not set",
            "Uploaded media then lands in Synapse's default location under the working directory — easy to lose in a container rebuild, and it fills the same disk as the database and logs.",
            "Set media_store_path to a durable, backed-up volume with room to grow, e.g. \"/data/media_store\".");
        }
        var mus = findKeys(lines, "max_upload_size");
        if (mus.length) {
          var rawSize = parseScalar(mus[0].raw);
          var mSize = rawSize.match(/^(\d+(?:\.\d+)?)\s*([KMG]?)B?$/i);
          if (mSize) {
            var mb = parseFloat(mSize[1]);
            var unit = (mSize[2] || "").toUpperCase();
            if (unit === "G") mb *= 1024;
            else if (unit === "K") mb /= 1024;
            else if (unit === "") mb = mb / (1024 * 1024);
            if (mb > 100) {
              add("WARNING", mus[0].line, "max_upload_size",
                "max_upload_size is very large (" + rawSize + ")",
                "A per-upload cap in the hundreds of megabytes lets any user park huge files on your disk — a cheap way to fill a volume and take the server down.",
                "Bring max_upload_size down to what your users actually need (Synapse's default is 50M) unless this server is deliberately a file host with disk to match.");
            } else if (mb < 1) {
              add("WARNING", mus[0].line, "max_upload_size",
                "max_upload_size is unusually small (" + rawSize + ")",
                "Under a megabyte, ordinary photos will fail to upload and users will report the server as broken.",
                "Raise max_upload_size to something realistic — 10M–50M covers normal photo and document sharing.");
            }
          }
        } else {
          add("INFO", null, "max_upload_size",
            "max_upload_size is not set — Synapse's default (50M) applies",
            "The default cap is sane for most servers.",
            "No change needed unless your users legitimately send larger files.");
        }

        /* ---- URL previews ---- */
        var upe = findKeys(lines, "url_preview_enabled");
        if (upe.length && isTrue(upe[0].raw)) {
          var bl = findKeys(lines, "url_preview_ip_range_blacklist");
          if (!bl.length) {
            add("HIGH", upe[0].line, "url_preview_enabled",
              "URL previews are on with no IP-range blacklist in the paste",
              "With url_preview_enabled and no url_preview_ip_range_blacklist, the server will fetch any URL a user posts — including addresses inside your own network. That's a server-side request forgery (SSRF) hole aimed at internal services.",
              "Add url_preview_ip_range_blacklist covering loopback and private ranges (127.0.0.0/8, 10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16, ::1/128, fc00::/7) — Synapse's documented example list is a good start — or set url_preview_enabled: false.");
          } else {
            add("WARNING", upe[0].line, "url_preview_enabled",
              "URL previews are on, with a blacklist present (contents not range-checked)",
              "A blacklist exists, which is the right shape — but this text audit doesn't evaluate every range in it, so a gap (a missed private range) can't be ruled out from the paste.",
              "Confirm the blacklist still covers loopback, all private ranges, and link-local addresses, and re-check it after copying config examples from the internet.");
          }
        } else if (upe.length) {
          add("INFO", upe[0].line, "url_preview_enabled",
            "URL previews are disabled",
            "url_preview_enabled is false, so the server won't fetch arbitrary URLs from messages — no SSRF surface from previews.",
            "No change needed.");
        }

        /* ---- password auth posture ---- */
        var pcStart = -1, pcIndent = 0;
        for (var pi = 0; pi < lines.length; pi++) {
          if (!lines[pi].blank && !lines[pi].comment && keyRegex("password_config").test(lines[pi].text)) { pcStart = pi; pcIndent = lines[pi].indent; break; }
        }
        if (pcStart >= 0) {
          var pcEnd = sectionEnd(lines, pcStart, pcIndent);
          var pcEnabled = findKeyInRange(lines, pcStart, pcEnd, "enabled");
          if (pcEnabled && isFalse(pcEnabled.raw)) {
            add("WARNING", pcEnabled.line, "password_config.enabled",
              "Password login is disabled",
              "password_config.enabled: false means nobody can log in with a password. That's correct if SSO/OIDC is configured and working — and a lockout for everyone if it isn't.",
              "Confirm your SSO/OIDC (or another login path) actually works before deploying with password login off; otherwise set enabled: true.");
          } else if (pcEnabled) {
            add("INFO", pcEnabled.line, "password_config.enabled",
              "Password login is enabled",
              "Standard posture: users log in with passwords. Its safety then rests on the secrets and registration settings graded elsewhere in this report.",
              "No change needed.");
          }
        }

        /* ---- report_stats (INFO by design) ---- */
        var rs = findKeys(lines, "report_stats");
        if (rs.length) {
          if (isTrue(rs[0].raw)) {
            add("INFO", rs[0].line, "report_stats",
              "report_stats is on — anonymous usage stats are sent to matrix.org",
              "That's the project's own telemetry: aggregate counts, no message content. Harmless for most operators, but it is an outbound disclosure worth knowing about.",
              "Leave it on to help the project, or set report_stats: false if you'd rather the server report nothing.");
          } else {
            add("INFO", rs[0].line, "report_stats",
              "report_stats is off — the server reports no usage stats",
              "Nothing is sent to matrix.org about this server's usage.",
              "No change needed.");
          }
        }

        /* ---- verdict ---- */
        var counts = { BLOCKER: 0, HIGH: 0, WARNING: 0, INFO: 0 };
        findings.forEach(function (f) { counts[f.severity]++; });
        var verdict = counts.BLOCKER > 0 ? "DO NOT DEPLOY"
          : (counts.HIGH > 0 || counts.WARNING > 0) ? "DEPLOY WITH FIXES"
          : "SAFE TO DEPLOY";
        var rank = { BLOCKER: 0, HIGH: 1, WARNING: 2, INFO: 3 };
        findings.sort(function (a, b) {
          if (rank[a.severity] !== rank[b.severity]) return rank[a.severity] - rank[b.severity];
          var la = a.line === null ? 1e9 : a.line, lb = b.line === null ? 1e9 : b.line;
          return la - lb;
        });
        return { verdict: verdict, reasons: [], findings: findings, notParsed: np.bad, counts: counts };
      }

      /* ============================================================
         Rendering + report/JSON text.
         ============================================================ */
      var lastResult = null;

      function esc(s) {
        return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
      }

      function countsText(c) {
        if (!c) return "";
        return c.BLOCKER + " BLOCKER · " + c.HIGH + " HIGH · " + c.WARNING + " WARNING · " + c.INFO + " INFO";
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-synapse-server-config-safety-auditor',
  name: 'J-Dawgs Synapse Server Config Safety Auditor',
  description: 'Grades a pasted Matrix Synapse homeserver.yaml fully offline — open registration, federation exposure, and TLS posture all graded, with secrets shown by name, line, and length only — into one deploy verdict: SAFE TO DEPLOY / DEPLOY WITH FIXES / DO NOT DEPLOY.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
