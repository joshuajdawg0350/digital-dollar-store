'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Vault Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        /*AUDIT-CORE-START*/
        var RISKY = [
          '# Risky vault.hcl — pasted example with planted faults (not a real config)',
          'ui            = true',
          'dev           = true',
          'disable_mlock = true',
          '',
          'listener "tcp" {',
          '  address     = "0.0.0.0:8200"',
          '  tls_disable = true',
          '}',
          '',
          'storage "mysql" {',
          '  username = "vault"',
          '  password = "VAULT-CANARY-7f3a9-NOT-REAL"',
          '  database = "vault"',
          '  database = "vault_legacy"',
          '}',
          '',
          'telemetry {',
          '  prometheus_retention_time = "24h"',
          '  this stanza never closes properly {{{'
        ].join("\n");

        var HARDENED = [
          '# Hardened vault.hcl — pasted example',
          'ui            = false',
          'disable_mlock = false',
          '',
          'listener "tcp" {',
          '  address       = "10.0.4.21:8200"',
          '  tls_cert_file = "/etc/vault/tls/vault.crt"',
          '  tls_key_file  = "/etc/vault/tls/vault.key"',
          '  tls_disable   = false',
          '}',
          '',
          'storage "raft" {',
          '  path    = "/opt/vault/data"',
          '  node_id = "vault-node-1"',
          '  retry_join {',
          '    leader_api_addr = "https://10.0.4.22:8200"',
          '  }',
          '  retry_join {',
          '    leader_api_addr = "https://10.0.4.23:8200"',
          '  }',
          '}',
          '',
          'seal "awskms" {',
          '  region     = "us-east-1"',
          '  kms_key_id = "1234abcd-56ef-78ab-90cd-1234567890ab"',
          '}',
          '',
          'api_addr     = "https://10.0.4.21:8200"',
          'cluster_addr = "https://10.0.4.21:8201"'
        ].join("\n");

        var SECRET_RE = /(password|passwd|passphrase|secret|api[-_]?key|access[-_]?key|private[-_]?key|credential|auth[-_]?token|token)/i;
        var SECRET_EXCLUDE_RE = /(_id|_ids|_file|_files|_path|_dir|_arn|_name)$/i;
        var SEAL_TYPES = ["awskms", "azurekeyvault", "gcpckms", "hsm", "transit", "shamir"];

        function stripComment(line) {
          var inStr = false, esc = false;
          for (var i = 0; i < line.length; i++) {
            var c = line[i];
            if (esc) { esc = false; continue; }
            if (c === "\\") { esc = true; continue; }
            if (c === '"') { inStr = !inStr; continue; }
            if (!inStr) {
              if (c === "#") return line.slice(0, i);
              if (c === "/" && line[i + 1] === "/") return line.slice(0, i);
            }
          }
          return line;
        }
        function commentText(line) {
          var code = stripComment(line);
          return code.length < line.length ? line.slice(code.length) : "";
        }

        function normValue(raw) {
          var v = raw.replace(/,\s*$/, "").trim();
          return { raw: v, unq: v.replace(/^"+|"+$/g, "") };
        }
        function isTruthy(raw) {
          var u = normValue(raw).unq.toLowerCase();
          return u === "true" || u === "1";
        }

        function hostOf(addr) {
          var a = String(addr).trim();
          if (a.charAt(0) === "[") {
            var end = a.indexOf("]");
            return end > 0 ? a.slice(1, end) : a;
          }
          var first = a.indexOf(":"), last = a.lastIndexOf(":");
          if (last > 0 && first === last) return a.slice(0, last);
          if (last === 0) return "";
          return a;
        }
        function hostClass(host) {
          if (!host) return "wildcard";
          var h = String(host).toLowerCase();
          if (h === "0.0.0.0" || h === "::") return "wildcard";
          if (h === "localhost" || h === "::1" || h.indexOf("127.") === 0) return "localhost";
          if (/^10\./.test(h) || /^192\.168\./.test(h) || /^172\.(1[6-9]|2[0-9]|3[0-1])\./.test(h)) return "private";
          return "public";
        }

        function audit(text) {
          var lines = String(text == null ? "" : text).split(/\r\n|\r|\n/);
          var findings = [];
          var stack = []; // {name, label, line, id, rec}
          var nextId = 1;
          var stanzaSeen = {};
          var keysSeen = {};
          var listeners = [];
          var storage = null; // {type, line, retryJoin}
          var seal = null;    // {type, line}
          var devHits = [];   // {line, what}
          var mlockLine = 0;
          var uiHit = null;   // {line}
          var apiAddr = false, clusterAddr = false;
          var sawContent = false;
          var notParsedLines = 0;

          function add(sev, line, title, fix, line2) {
            findings.push({ sev: sev, line: line || null, line2: line2 || null, title: title, fix: fix });
          }
          function scopeId() {
            if (!stack.length) return "root";
            return stack.map(function (b) { return b.id; }).join("/");
          }
          function enclosingRec(kind) {
            for (var i = stack.length - 1; i >= 0; i--) {
              if (stack[i].rec && stack[i].rec.kind === kind) return stack[i].rec;
            }
            return null;
          }
          function inStorageRaft() {
            for (var i = 0; i < stack.length; i++) {
              if (stack[i].rec && stack[i].rec.kind === "storage") return stack[i].rec.type === "raft";
            }
            return false;
          }

          var openerRe = /^\s*"?([A-Za-z_][\w-]*)"?\s*(?::\s*)?(?:"([^"]*)"\s*)?\{\s*$/;
          var looseOpenerRe = /^\s*"?([A-Za-z_][\w-]*)"?\s*(?::\s*)?(?:"([^"]*)")?\s*\{/;
          var kvRe = /^\s*"?([A-Za-z_][\w-]*)"?\s*(?:=|:)\s*(.+?)\s*$/;

          for (var n = 0; n < lines.length; n++) {
            var lineNo = n + 1;
            var rawLine = lines[n];
            if (!rawLine.trim()) continue;
            sawContent = true;

            // Dev-mode signals that live outside key/value parsing: the -dev flag and dev-mode comments.
            if (/(^|\s)-dev(?=\s|$)/.test(rawLine)) {
              devHits.push({ line: lineNo, what: "the -dev flag appears on this line" });
            } else {
              var cmt = commentText(rawLine);
              if (cmt && /(dev\s*mode|development\s*mode|in\s+dev\b)/i.test(cmt) &&
                  !/\b(not|never|no|non|disable|disabled|off|production)\b/i.test(cmt)) {
                devHits.push({ line: lineNo, what: "a comment on this line describes running in dev mode" });
              }
            }

            var clean = stripComment(rawLine).trim();
            if (!clean) continue;

            if (clean === "{") { stack.push({ name: "(block)", label: "", line: lineNo, id: nextId++, rec: null }); continue; }
            if (/^\}[,;]?\s*$/.test(clean)) {
              if (stack.length) { stack.pop(); }
              else if (notParsedLines < 10) { notParsedLines++; add("WARNING", lineNo, "NOT PARSED: line " + lineNo + " closes a block that was never opened.", "Check the braces around this line — an unmatched closing brace means the block structure is not what it looks like."); }
              continue;
            }

            var om = clean.match(openerRe);
            if (om) {
              var bname = om[1].toLowerCase(), blabel = om[2] || "";
              if (stack.length === 0) {
                var skey = bname + "|" + blabel;
                if (stanzaSeen[skey]) {
                  add("WARNING", lineNo,
                    'Duplicate stanza: "' + bname + (blabel ? " \"" + blabel + "\"" : "") + '" appears on line ' + stanzaSeen[skey] + " and again on line " + lineNo + ".",
                    "Keep one " + bname + " stanza and merge the settings into it — with two, one silently wins and the running config is not the one you wrote.",
                    stanzaSeen[skey]);
                } else {
                  stanzaSeen[skey] = lineNo;
                }
              }
              var rec = null;
              if (bname === "listener") {
                rec = { kind: "listener", line: lineNo, address: null, addressLine: 0, hostClass: null, tlsDisable: false, tlsDisableLine: 0, certLine: 0, keyLine: 0 };
                listeners.push(rec);
              } else if (bname === "storage") {
                rec = { kind: "storage", type: blabel.toLowerCase(), line: lineNo, retryJoin: 0 };
                if (!storage) storage = rec;
              } else if (bname === "seal") {
                rec = { kind: "seal", type: blabel.toLowerCase(), line: lineNo };
                if (!seal) seal = rec;
              } else if (bname === "retry_join" && inStorageRaft() && storage) {
                storage.retryJoin++;
              }
              stack.push({ name: bname, label: blabel, line: lineNo, id: nextId++, rec: rec });
              continue;
            }

            if (clean.indexOf("{") !== -1 && clean.indexOf("}") !== -1) {
              // One-line block: register storage/seal presence, grade nothing inside it.
              var lm = clean.match(looseOpenerRe);
              if (lm) {
                var lname = lm[1].toLowerCase(), llabel = (lm[2] || "").toLowerCase();
                if (lname === "storage" && !storage) storage = { type: llabel, line: lineNo, retryJoin: 0 };
                if (lname === "seal" && !seal) seal = { type: llabel, line: lineNo };
                if (lname === "listener" && !listeners.length) {
                  listeners.push({ kind: "listener", line: lineNo, address: null, addressLine: 0, hostClass: null, tlsDisable: false, tlsDisableLine: 0, certLine: 0, keyLine: 0 });
                }
              }
              continue;
            }

            var km = clean.match(kvRe);
            if (!km) {
              if (clean.indexOf("}") === 0 && stack.length) { stack.pop(); continue; }
              if (notParsedLines < 10) {
                notParsedLines++;
                add("WARNING", lineNo,
                  "NOT PARSED: line " + lineNo + " could not be parsed as a key, a block, or a closing brace.",
                  "Check this line by hand — the auditor grades only what it can parse, so anything hiding on this line is ungraded.");
              }
              continue;
            }

            var key = km[1], keyLc = key.toLowerCase(), val = km[2];
            var scope = scopeId();
            var dupKey = scope + "|" + keyLc;
            if (keysSeen[dupKey]) {
              add("WARNING", lineNo,
                'Duplicate key: "' + key + '" is set on line ' + keysSeen[dupKey] + " and again on line " + lineNo + " in the same stanza.",
                "Delete one of the two assignments — only one value takes effect, and it may not be the one you expect.",
                keysSeen[dupKey]);
            } else {
              keysSeen[dupKey] = lineNo;
            }

            if ((keyLc === "dev" || keyLc === "dev_mode") && isTruthy(val)) {
              devHits.push({ line: lineNo, what: key + " = true is set on this line" });
            }
            if (keyLc === "disable_mlock" && isTruthy(val) && !mlockLine) mlockLine = lineNo;
            if (keyLc === "ui" && isTruthy(val) && !uiHit) uiHit = { line: lineNo };
            if (keyLc === "api_addr") apiAddr = true;
            if (keyLc === "cluster_addr") clusterAddr = true;

            var lrec = enclosingRec("listener");
            if (lrec) {
              if (keyLc === "address") {
                lrec.address = normValue(val).unq;
                lrec.addressLine = lineNo;
                lrec.hostClass = hostClass(hostOf(lrec.address));
              } else if (keyLc === "tls_disable" && isTruthy(val)) {
                lrec.tlsDisable = true;
                lrec.tlsDisableLine = lineNo;
              } else if (keyLc === "tls_cert_file") {
                lrec.certLine = lineNo;
              } else if (keyLc === "tls_key_file") {
                lrec.keyLine = lineNo;
              }
            }

            if (!SECRET_EXCLUDE_RE.test(keyLc) && SECRET_RE.test(keyLc)) {
              add("WARNING", lineNo,
                'Secret-bearing key "' + key + '" sits in the config file (flagged by key name and line only — the value is never shown in any output).',
                "Remove the secret from the config, supply it through the environment or the backend's own credential chain, and rotate it — anything that has sat in a config file should be treated as exposed.");
            }
          }

          // Blocks still open at end of input were never closed.
          var anonOpen = 0;
          for (var s = 0; s < stack.length; s++) {
            if (stack[s].name === "(block)") { anonOpen++; continue; }
            add("WARNING", stack[s].line,
              'NOT PARSED: the "' + stack[s].name + (stack[s].label ? " \"" + stack[s].label + "\"" : "") + '" block opened on line ' + stack[s].line + " is never closed.",
              "Close this block with a matching brace — until the braces balance, nothing inside it can be trusted to mean what it looks like.");
          }
          if (anonOpen > 0) {
            add("WARNING", null,
              "NOT PARSED: " + anonOpen + " unnamed block" + (anonOpen === 1 ? " is" : "s are") + " never closed.",
              "Balance the braces in the pasted config and audit it again.");
          }

          if (!sawContent) {
            findings.length = 0;
            add("BLOCKER", null,
              "NOT PARSED: the pasted input is empty — there is no config to grade.",
              "Paste a Vault server config (HCL or JSON) and audit it again.");
          }

          // Dev mode.
          devHits.forEach(function (d) {
            add("BLOCKER", d.line,
              "Dev mode signal: " + d.what + " — a dev-mode Vault keeps everything in memory, starts unsealed, and uses a known root token.",
              "Remove every dev-mode signal (dev keys, -dev flags, dev-mode comments) and run Vault as a real server with durable storage and a seal.");
          });

          // Listener posture.
          var anyExternal = false, anyPlaintext = false;
          listeners.forEach(function (L) {
            if (L.hostClass === "wildcard" || L.hostClass === "public") anyExternal = true;
            if (L.tlsDisable) anyPlaintext = true;
          });
          listeners.forEach(function (L) {
            var where = L.address ? L.address : "(no address set)";
            if (L.hostClass === "wildcard") {
              add("WARNING", L.addressLine,
                "Listener binds " + (hostOf(L.address) === "::" || hostOf(L.address) === "" ? "[::]" : "0.0.0.0") + " — the Vault port is exposed on every network interface.",
                "Bind the listener to the specific private address Vault should serve on (for example a 10.x or 192.168.x address), or put a firewall in front of the port.");
            } else if (L.hostClass === "public") {
              add("INFO", L.addressLine,
                "Listener binds a public address (" + hostOf(L.address) + ") — the Vault port is reachable from the public internet by design or by accident.",
                "No fix if that reach is intended and firewalled; otherwise bind a private address and reach Vault through your internal network.");
            }
            if (L.tlsDisable) {
              if (L.hostClass === "localhost") {
                add("WARNING", L.tlsDisableLine,
                  "TLS is disabled on a localhost-only listener (tls_disable = true) — plaintext, but reachable only from this host.",
                  "Even locally, prefer TLS: remove tls_disable and configure tls_cert_file and tls_key_file so nothing on the host can sniff Vault traffic.");
              } else {
                add("BLOCKER", L.tlsDisableLine,
                  "TLS is disabled on the listener (tls_disable = true) bound to " + where + " — Vault traffic runs over plaintext HTTP" +
                    (L.hostClass === "wildcard" ? ", and the wildcard bind exposes that plaintext traffic on every interface." : "."),
                  "Remove tls_disable (or set it to false) and configure tls_cert_file and tls_key_file on the listener so Vault serves HTTPS.");
              }
            } else {
              if (L.certLine && !L.keyLine) {
                add(L.hostClass === "wildcard" || L.hostClass === "public" ? "BLOCKER" : "WARNING", L.certLine,
                  "TLS listener has tls_cert_file (line " + L.certLine + ") but no tls_key_file — the certificate has no key to serve with.",
                  "Add tls_key_file pointing at the private key that matches the certificate, on the same listener.");
              } else if (!L.certLine && L.keyLine) {
                add(L.hostClass === "wildcard" || L.hostClass === "public" ? "BLOCKER" : "WARNING", L.keyLine,
                  "TLS listener has tls_key_file (line " + L.keyLine + ") but no tls_cert_file — the key has no certificate to serve with.",
                  "Add tls_cert_file pointing at the certificate that matches the key, on the same listener.");
              } else if (!L.certLine && !L.keyLine) {
                add("WARNING", L.line,
                  "Listener (line " + L.line + ") sets neither tls_cert_file nor tls_key_file and does not disable TLS — as written it cannot serve HTTPS.",
                  "Configure both tls_cert_file and tls_key_file on the listener (or, only for a throwaway local test, tls_disable = true on a localhost bind).");
              }
            }
          });

          // mlock.
          if (mlockLine) {
            if (anyExternal) {
              add("BLOCKER", mlockLine,
                "disable_mlock = true, escalated to BLOCKER: a listener binds an external or non-localhost address, so Vault is both reachable from outside and free to swap its memory — secrets included — to disk.",
                "Set disable_mlock = false (and grant the binary the IPC_LOCK capability, or run it where mlock is permitted) so secrets in memory never reach a swap file.");
            } else {
              add("WARNING", mlockLine,
                "disable_mlock = true — Vault's memory can be swapped to disk.",
                "Set disable_mlock = false (and grant the binary the IPC_LOCK capability, or run it where mlock is permitted) so secrets in memory never reach a swap file.");
            }
          }

          // UI exposure.
          if (uiHit) {
            if (anyExternal || anyPlaintext) {
              add("WARNING", uiHit.line,
                "ui = true while a listener is exposed (external bind) or plaintext (TLS disabled) — the web UI login surface is reachable on that listener.",
                "Set ui = false, or first fix the listener: bind a private address and serve TLS, so the UI is only reachable where you intend.");
            } else {
              add("INFO", uiHit.line,
                "ui = true — the web UI is enabled, and every listener is private and on TLS, so the login surface stays where it belongs.",
                "No fix required. Keep the UI behind your normal access controls and it stays a convenience, not an exposure.");
            }
          }

          // Storage posture.
          if (!sawContent) {
            // Empty input: the NOT PARSED finding above is the whole result.
          } else if (!storage) {
            add("BLOCKER", null,
              "No storage backend stanza — the config declares no storage \"…\" block.",
              "Add a storage stanza, for example storage \"raft\" with a data path (or another supported backend), so Vault has durable storage for its encrypted data.");
          } else if (storage.type === "file") {
            add("WARNING", storage.line,
              'Storage backend: "file" (line ' + storage.line + ") — file storage keeps everything on this one host's disk with no clustering and no HA.",
              "Move production Vault to raft integrated storage or a replicated backend (consul, a managed database) so a single disk or host loss is not a total loss.");
          } else if (storage.type === "raft") {
            var nodes = storage.retryJoin + 1;
            var quorum = Math.floor(nodes / 2) + 1;
            var tolerates = nodes - quorum;
            add("INFO", storage.line,
              'Storage backend: "raft" integrated storage (line ' + storage.line + ")" +
                (storage.retryJoin > 0
                  ? " — " + storage.retryJoin + " retry_join stanza" + (storage.retryJoin === 1 ? "" : "s") + " stated, so this node plus " + storage.retryJoin + " peer" + (storage.retryJoin === 1 ? "" : "s") + " makes a " + nodes + "-node cluster: quorum is " + quorum + ", and it tolerates " + tolerates + " node failure" + (tolerates === 1 ? "" : "s") + "."
                  : " — no retry_join stanzas stated, so as written this reads as a single-node cluster with no HA."),
              "No fix required for the stanza itself. Keep raft clusters at an odd node count (3 or 5) so quorum arithmetic stays clean.");
          } else if (storage.type) {
            add("INFO", storage.line,
              'Storage backend: "' + storage.type + '" (line ' + storage.line + ") — its durability and HA depend on that backend's own replication, which this audit does not verify.",
              "No fix required for the stanza itself. Make sure the backend behind Vault is itself backed up and replicated.");
          } else {
            add("WARNING", storage.line,
              'Storage stanza on line ' + storage.line + " has no backend name the auditor can read.",
              'Name the backend explicitly, for example storage "raft", so the storage posture is reviewable.');
          }

          // Seal posture: named when present, NOT VERIFIED when absent — never assumed.
          if (sawContent && seal && seal.type) {
            add("INFO", seal.line,
              'Seal: "' + seal.type + '" stanza present (line ' + seal.line + ") — seal type named. Whether the KMS key, IAM permissions, or HSM behind it actually work is NOT VERIFIED by this audit.",
              "No fix required for the stanza itself. Test an unseal against the real KMS/HSM before you depend on it.");
          } else if (sawContent) {
            add("WARNING", null,
              'Seal: NOT VERIFIED — no seal stanza (' + SEAL_TYPES.join(", ") + ") was found in the pasted config, so no seal is assumed to exist; Vault falls back to Shamir unsealing with no auto-unseal.",
              'Add a seal stanza for a cloud KMS or HSM (for example seal "awskms") so Vault can auto-unseal after restarts instead of waiting on a human with Shamir key shares.');
          }

          var order = { BLOCKER: 0, WARNING: 1, INFO: 2 };
          findings.sort(function (a, b) {
            if (order[a.sev] !== order[b.sev]) return order[a.sev] - order[b.sev];
            var la = a.line === null ? 1e9 : a.line, lb = b.line === null ? 1e9 : b.line;
            return la - lb;
          });

          var counts = { BLOCKER: 0, WARNING: 0, INFO: 0 };
          findings.forEach(function (f) { counts[f.sev]++; });
          var verdict = counts.BLOCKER > 0 ? "DO NOT DEPLOY" : (counts.WARNING > 0 ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY");
          return {
            verdict: verdict,
            counts: counts,
            findings: findings,
            parsed: {
              storage: storage ? (storage.type || null) : null,
              storageLine: storage ? storage.line : null,
              raftRetryJoin: storage && storage.type === "raft" ? storage.retryJoin : null,
              seal: seal && seal.type ? seal.type : "NOT VERIFIED",
              listeners: listeners.map(function (L) {
                return {
                  line: L.line,
                  address: L.address,
                  bindClass: L.hostClass,
                  tlsDisabled: !!L.tlsDisable,
                  tlsCertFileLine: L.certLine || null,
                  tlsKeyFileLine: L.keyLine || null
                };
              }),
              apiAddrPresent: apiAddr,
              clusterAddrPresent: clusterAddr
            }
          };
        }

        function lineLabel(f) {
          if (f.line && f.line2) return "Lines " + f.line2 + " & " + f.line;
          if (f.line) return "Line " + f.line;
          return "Whole config";
        }

        function buildReport(r) {
          var out = [];
          out.push("J-DAWGS VAULT SERVER CONFIG SAFETY AUDITOR — REPORT");
          out.push("Verdict: " + r.verdict);
          out.push("Counts: " + r.counts.BLOCKER + " BLOCKER · " + r.counts.WARNING + " WARNING · " + r.counts.INFO + " INFO");
          out.push("Storage backend: " + (r.parsed.storage ? '"' + r.parsed.storage + '"' : "none found"));
          out.push("Seal: " + (r.parsed.seal === "NOT VERIFIED" ? "NOT VERIFIED (no seal stanza found)" : '"' + r.parsed.seal + '" (stanza present; internals NOT VERIFIED)'));
          out.push("");
          if (!r.findings.length) {
            out.push("No findings. None of the graded dangers were found in this config.");
          } else {
            out.push("Findings and fixes:");
            r.findings.forEach(function (f, i) {
              out.push((i + 1) + ". [" + f.sev + "] " + lineLabel(f) + " — " + f.title);
              out.push("   Fix: " + f.fix);
            });
          }
          out.push("");
          out.push("Notes: static grade of pasted text only — Vault was not run and no Vault server was contacted. Secret values are never shown in this report; secret keys are flagged by name and line only.");
          return out.join("\n");
        }

        function buildJSON(r) {
          var obj = {
            tool: "J-Dawgs Vault Server Config Safety Auditor",
            verdict: r.verdict,
            counts: { BLOCKER: r.counts.BLOCKER, WARNING: r.counts.WARNING, INFO: r.counts.INFO },
            parsed: r.parsed,
            findings: r.findings.map(function (f) {
              var lines = [];
              if (f.line2) lines.push(f.line2);
              if (f.line) lines.push(f.line);
              return {
                severity: f.sev,
                line: f.line,
                lines: lines.length ? lines : null,
                title: f.title,
                fix: f.fix
              };
            }),
            notes: "Static grade of pasted text only. Secret values are never included; secret findings carry key names and lines only. Seal internals are NOT VERIFIED."
          };
          return JSON.stringify(obj, null, 2);
        }
        /*AUDIT-CORE-END*/

        function esc(s) {
          return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-vault-server-config-safety-auditor',
  name: 'J-Dawgs Vault Server Config Safety Auditor',
  description: 'Grades a pasted HashiCorp Vault server config offline: tls_disable, wildcard listener + UI exposure, mlock, seal/storage posture, secrets by key name only — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
