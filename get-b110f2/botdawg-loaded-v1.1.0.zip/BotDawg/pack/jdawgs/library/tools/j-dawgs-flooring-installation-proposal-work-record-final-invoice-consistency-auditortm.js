'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Flooring Installation Proposal, Work Record & Final Invoice Consistency Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      'use strict';

      /* ================= Example documents ================= */

      var PROBLEM = {
        proposal: [
          'PROPOSAL — J-Dawgs Flooring',
          'Material: White Oak flooring — 550 sq ft @ $6.00/sq ft = $3,300.00',
          'Underlayment: 550 sq ft @ $0.50/sq ft = $275.00',
          'Moisture barrier: $150.00',
          'Trim and transitions: $240.00',
          'Labor: 40 hours @ $75.00/hr = $3,000.00',
          'Site preparation: $200.00',
          'Rooms: Living Room, Kitchen, Hallway',
          'Deposit paid: $1,000.00',
          'Proposal total: $7,165.00'
        ].join('\n'),
        work: [
          'WORK RECORD — J-Dawgs Flooring Crew',
          'Material installed: Red Oak — 480 sq ft @ $5.00/sq ft',
          'Underlayment installed: 480 sq ft',
          'Labor: 32 hours on site',
          'Rooms completed: Living Room, Kitchen, Hallway',
          'Notes: Old floor removed. Subfloor solid.'
        ].join('\n'),
        invoice: [
          'FINAL INVOICE — J-Dawgs Flooring',
          'White Oak flooring: 600 sq ft @ $6.00/sq ft = $3,600.00',
          'Underlayment: 550 sq ft @ $0.50/sq ft = $300.00',
          'Moisture barrier: $150.00',
          'Trim and transitions: $240.00',
          'Labor: 48 hours @ $75.00/hr = $3,600.00',
          'Guest Bedroom install: $450.00',
          'Site preparation fee: $200.00',
          'Preparation and cleanup fee: $200.00',
          'Disposal fee: $125.00',
          'Less deposit credit: -$500.00',
          'Invoice total: $8,465.00'
        ].join('\n')
      };

      var CLEAN = {
        proposal: [
          'PROPOSAL — J-Dawgs Flooring',
          'Material: White Oak flooring — 440 sq ft @ $6.00/sq ft = $2,640.00',
          'Underlayment: 440 sq ft @ $0.50/sq ft = $220.00',
          'Moisture barrier: $150.00',
          'Trim and transitions: $240.00',
          'Labor: 36 hours @ $75.00/hr = $2,700.00',
          'Site preparation: $200.00',
          'Rooms: Living Room, Kitchen',
          'Deposit paid: $1,000.00',
          'Proposal total: $6,150.00'
        ].join('\n'),
        work: [
          'WORK RECORD — J-Dawgs Flooring Crew',
          'Material installed: White Oak — 400 sq ft @ $6.00/sq ft',
          'Underlayment installed: 400 sq ft',
          'Moisture barrier installed',
          'Trim and transitions installed',
          'Labor: 36 hours on site',
          'Rooms completed: Living Room, Kitchen'
        ].join('\n'),
        invoice: [
          'FINAL INVOICE — J-Dawgs Flooring',
          'White Oak flooring: 440 sq ft @ $6.00/sq ft = $2,640.00',
          'Underlayment: 440 sq ft @ $0.50/sq ft = $220.00',
          'Moisture barrier: $150.00',
          'Trim and transitions: $240.00',
          'Labor: 36 hours @ $75.00/hr = $2,700.00',
          'Site preparation: $200.00',
          'Less deposit credit: -$1,000.00',
          'Invoice total: $5,150.00'
        ].join('\n')
      };

      /* ================= Parsing helpers ================= */

      function round2(n) { return Math.round(n * 100) / 100; }
      function money(n) {
        var sign = n < 0 ? '-$' : '$';
        return sign + Math.abs(round2(n)).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
      }
      function fmtNum(n) {
        return (Math.round(n * 100) / 100).toLocaleString('en-US');
      }
      function titleCase(s) {
        return s.replace(/\b\w/g, function (c) { return c.toUpperCase(); });
      }

      function lastMoney(raw) {
        var re = /(-)?\$\s*([\d,]+(?:\.\d{1,2})?)/g, m, last = null;
        while ((m = re.exec(raw)) !== null) {
          last = { neg: !!m[1], val: parseFloat(m[2].replace(/,/g, '')) };
        }
        if (!last) return null;
        var v = last.neg ? -last.val : last.val;
        if (/\(\s*\$/.test(raw)) v = -Math.abs(v);
        return v;
      }

      function parseLine(raw, idx) {
        var lower = raw.toLowerCase();
        var line = {
          idx: idx, raw: raw, lower: lower,
          amount: lastMoney(raw),
          qty: null, unit: null, rate: null, sqft: null, hours: null,
          isTotal: /\btotal\b/.test(lower),
          isDeposit: lower.indexOf('deposit') >= 0
        };
        var qm = raw.match(/([\d,]+(?:\.\d+)?)\s*(sq\.?\s*ft|sf|hours?|hrs?)\b[^=\n]*?@\s*\$?\s*([\d,]+(?:\.\d+)?)/i);
        if (qm) {
          line.qty = parseFloat(qm[1].replace(/,/g, ''));
          line.unit = /h/i.test(qm[2]) ? 'hr' : 'sqft';
          line.rate = parseFloat(qm[3].replace(/,/g, ''));
        }
        var sm = raw.match(/([\d,]+(?:\.\d+)?)\s*(?:sq\.?\s*ft|sf)\b/i);
        if (sm) line.sqft = parseFloat(sm[1].replace(/,/g, ''));
        var hm = raw.match(/([\d,]+(?:\.\d+)?)\s*(?:hours?|hrs?)\b/i);
        if (hm) line.hours = parseFloat(hm[1].replace(/,/g, ''));
        if (line.qty !== null && line.unit === 'sqft') line.sqft = line.qty;
        if (line.qty !== null && line.unit === 'hr') line.hours = line.qty;
        if (line.rate === null) {
          var rm = raw.match(/@\s*\$?\s*([\d,]+(?:\.\d+)?)/);
          if (rm) line.rate = parseFloat(rm[1].replace(/,/g, ''));
        }
        return line;
      }

      function parseDoc(text) {
        var rawLines = String(text || '').split(/\r?\n/).map(function (s) { return s.trim(); }).filter(function (s) { return s.length > 0; });
        return {
          text: String(text || ''),
          lower: String(text || '').toLowerCase(),
          lines: rawLines.map(function (raw, i) { return parseLine(raw, i); })
        };
      }

      var SPECIES = ['white oak', 'red oak', 'hickory', 'walnut', 'maple', 'cherry', 'bamboo', 'ash', 'pine', 'luxury vinyl', 'lvp', 'laminate', 'engineered hardwood', 'hardwood', 'tile', 'cork'];
      function speciesIn(lowerText) {
        return SPECIES.filter(function (s) {
          return new RegExp('\\b' + s.replace(/ /g, '\\s+') + '\\b').test(lowerText);
        });
      }
      function materialInfo(doc) {
        for (var i = 0; i < doc.lines.length; i++) {
          var sp = speciesIn(doc.lines[i].lower);
          if (sp.length) {
            var l = doc.lines[i];
            return { line: l, species: sp[0], sqft: l.sqft, rate: l.rate, amount: l.amount };
          }
        }
        return null;
      }
      function laborLine(doc, needHours) {
        for (var i = 0; i < doc.lines.length; i++) {
          var l = doc.lines[i];
          if (l.lower.indexOf('labor') >= 0 && (needHours ? l.hours !== null : l.amount !== null)) return l;
        }
        return null;
      }
      function statedTotal(doc) {
        var t = null;
        doc.lines.forEach(function (l) { if (l.isTotal && l.amount !== null) t = l.amount; });
        return t;
      }

      var COMPONENTS = [
        { key: 'underlayment', label: 'Underlayment' },
        { key: 'moisture barrier', label: 'Moisture barrier' },
        { key: 'trim', label: 'Trim' },
        { key: 'transition', label: 'Transitions' }
      ];
      function componentsIn(lower) {
        return COMPONENTS.filter(function (c) { return lower.indexOf(c.key) >= 0; });
      }

      var ROOM_NAMES = ['living room', 'dining room', 'family room', 'guest bedroom', 'primary bedroom', 'master bedroom', 'bedroom', 'kitchen', 'bathroom', 'hallway', 'basement', 'office', 'laundry room', 'sunroom', 'entryway', 'mudroom', 'pantry', 'nursery', 'den', 'closet', 'garage'];
      function roomsInText(lower) {
        var found = [];
        var sorted = ROOM_NAMES.slice().sort(function (a, b) { return b.length - a.length; });
        sorted.forEach(function (r) {
          if (new RegExp('\\b' + r + '\\b').test(lower)) {
            var covered = found.some(function (f) { return f.indexOf(r) >= 0 || r.indexOf(f) >= 0; });
            if (!covered) found.push(r);
          }
        });
        return found;
      }
      function workRoomSet(doc) {
        var set = roomsInText(doc.lower);
        doc.lines.forEach(function (l) {
          if (/^\s*rooms?\b/.test(l.lower) && l.lower.indexOf(':') >= 0) {
            l.lower.split(':')[1].split(/[,;]|\band\b/).forEach(function (part) {
              var name = part.trim();
              if (name.length >= 3 && name.indexOf('$') < 0 && set.indexOf(name) < 0) set.push(name);
            });
          }
        });
        return set;
      }

      var STOPWORDS = { fee: 1, fees: 1, charge: 1, charges: 1, cost: 1, costs: 1, service: 1, services: 1, labor: 1, labour: 1, material: 1, materials: 1, install: 1, installed: 1, installation: 1, flooring: 1, floor: 1, total: 1, hours: 1, hour: 1, each: 1, with: 1, and: 1, the: 1, for: 1, per: 1, sqft: 1 };
      function sigTokens(raw) {
        return raw.toLowerCase().replace(/[^a-z\s]/g, ' ').split(/\s+/).filter(function (w) {
          return w.length >= 4 && !STOPWORDS[w];
        });
      }

      /* ================= The auditor ================= */

      function audit(pText, wText, iText, wastePct) {
        var findings = [];
        var parseIssues = [];
        var P = parseDoc(pText), W = parseDoc(wText), I = parseDoc(iText);
        var claimed = {};
        function add(category, severity, title, detail, arithmetic, amount) {
          findings.push({
            id: findings.length + 1, category: category, severity: severity,
            title: title, detail: detail, arithmetic: arithmetic, amount: round2(amount)
          });
        }
        function chargeLines(doc) {
          return doc.lines.filter(function (l) { return !l.isTotal && !l.isDeposit && l.amount !== null; });
        }
        var invCharges = chargeLines(I);

        if (!P.text.trim()) parseIssues.push('Proposal paste is empty — nothing to check the invoice against.');
        if (!W.text.trim()) parseIssues.push('Work record paste is empty — nothing to check the invoice against.');
        if (!I.text.trim()) parseIssues.push('Invoice paste is empty — there is no bill to audit.');
        else if (!I.lines.some(function (l) { return l.amount !== null; })) parseIssues.push('Invoice: no dollar amounts could be read from the pasted text.');
        if (P.text.trim() && !P.lines.some(function (l) { return l.amount !== null; })) parseIssues.push('Proposal: no dollar amounts could be read from the pasted text.');
        if (W.text.trim() && materialInfo(W) === null && laborLine(W, true) === null) parseIssues.push('Work record: no installed material or labor hours could be read from the pasted text.');

        var insufficient = parseIssues.length > 0;
        if (insufficient) {
          add('insufficient-data', 'severe', 'Not enough readable data to clear this bill',
            'One or more pastes could not be read well enough to run the cross-checks. An auditor that cannot read the documents cannot call the bill safe.',
            parseIssues.join(' '), 0);
        }

        var invMat = materialInfo(I), workMat = materialInfo(W), propMat = materialInfo(P);

        /* 1 — Square feet billed vs. installed (+ waste allowance) */
        if (invMat && workMat && invMat.sqft !== null && workMat.sqft !== null) {
          var allowed = workMat.sqft * (1 + wastePct / 100);
          if (invMat.sqft > allowed + 0.005) {
            var rate1 = invMat.rate !== null ? invMat.rate : (propMat && propMat.rate !== null ? propMat.rate : 0);
            var excess = invMat.sqft - allowed;
            add('square-feet', 'severe', 'Square feet billed above square feet installed',
              'The invoice bills ' + fmtNum(invMat.sqft) + ' sq ft of flooring, but the work record shows ' + fmtNum(workMat.sqft) + ' sq ft installed. Even after the ' + wastePct + '% waste allowance, ' + fmtNum(excess) + ' sq ft were billed for floor that was never laid.',
              'Billed ' + fmtNum(invMat.sqft) + ' sq ft − allowed ' + fmtNum(allowed) + ' sq ft (' + fmtNum(workMat.sqft) + ' installed × 1.' + String(wastePct).padStart(2, '0') + ') = ' + fmtNum(excess) + ' sq ft × ' + money(rate1) + '/sq ft = ' + money(excess * rate1),
              excess * rate1);
            claimed[invMat.line.idx] = true;
          }
        }

        /* 2 — Material grade / species mismatch */
        var billedSpecies = speciesIn(I.lower).concat(speciesIn(P.lower)).filter(function (s, i, a) { return a.indexOf(s) === i; });
        var workSpecies = speciesIn(W.lower);
        if (workSpecies.length && billedSpecies.length && !workSpecies.some(function (s) { return billedSpecies.indexOf(s) >= 0; })) {
          var amt2 = 0, arith2 = 'The species differ, but no per-sq-ft rates were found in the pastes to price the difference — ask for the rate difference in writing.';
          if (invMat && workMat && invMat.rate !== null && workMat.rate !== null && invMat.rate > workMat.rate && workMat.sqft !== null) {
            amt2 = (invMat.rate - workMat.rate) * workMat.sqft;
            arith2 = 'Billed rate ' + money(invMat.rate) + '/sq ft (' + titleCase(billedSpecies[0]) + ') − installed-material rate ' + money(workMat.rate) + '/sq ft (' + titleCase(workSpecies[0]) + ') = ' + money(invMat.rate - workMat.rate) + '/sq ft × ' + fmtNum(workMat.sqft) + ' sq ft installed = ' + money(amt2);
          }
          add('material-grade', 'severe',
            'Material billed as ' + titleCase(billedSpecies[0]) + ', installed material recorded as ' + titleCase(workSpecies[0]),
            'The proposal and invoice bill a higher-grade material (' + titleCase(billedSpecies[0]) + ') than the material the work record says actually went down (' + titleCase(workSpecies[0]) + '). You are being charged the premium-grade price for the standard-grade floor.',
            arith2, amt2);
          if (invMat) claimed[invMat.line.idx] = true;
        }

        /* 3 — Components billed but never recorded as installed */
        invCharges.forEach(function (l) {
          if (l.amount <= 0) return;
          var comps = componentsIn(l.lower);
          if (!comps.length) return;
          var missing = comps.filter(function (c) { return W.lower.indexOf(c.key) < 0; });
          var present = comps.filter(function (c) { return W.lower.indexOf(c.key) >= 0; });
          if (missing.length && !present.length) {
            var labels = missing.map(function (c) { return c.label; }).join(' / ');
            add('not-installed', 'severe', labels + ' billed but never recorded as installed',
              'The invoice charges for ' + labels.toLowerCase() + ', but the work record from the installer never mentions it being installed.',
              'Invoice line "' + l.raw + '" = ' + money(l.amount) + '; work record mentions ' + labels.toLowerCase() + ': never',
              l.amount);
            claimed[l.idx] = true;
          }
        });

        /* 4 — Labor billed above recorded hours × proposal rate */
        var invLabor = laborLine(I, false);
        var propLabor = laborLine(P, false);
        var workLabor = laborLine(W, true);
        if (invLabor && workLabor && (propLabor || invLabor.rate !== null)) {
          var rate4 = propLabor && propLabor.rate !== null ? propLabor.rate : invLabor.rate;
          var allowedLabor = workLabor.hours * rate4;
          if (invLabor.amount > allowedLabor + 0.005) {
            add('labor', 'severe', 'Labor billed above recorded hours at the proposal rate',
              'The invoice bills ' + (invLabor.hours !== null ? fmtNum(invLabor.hours) + ' hours of labor' : 'labor') + ', but the work record shows ' + fmtNum(workLabor.hours) + ' hours on site, and the proposal rate is ' + money(rate4) + '/hr.',
              'Billed ' + money(invLabor.amount) + ' − (' + fmtNum(workLabor.hours) + ' hrs × ' + money(rate4) + '/hr = ' + money(allowedLabor) + ') = ' + money(invLabor.amount - allowedLabor),
              invLabor.amount - allowedLabor);
            claimed[invLabor.idx] = true;
          }
        }

        /* 5 — Rooms billed that the work record never lists */
        var workRooms = workRoomSet(W);
        invCharges.forEach(function (l) {
          if (claimed[l.idx] || l.amount <= 0) return;
          var lineRooms = roomsInText(l.lower);
          var bad = lineRooms.filter(function (r) { return workRooms.indexOf(r) < 0; });
          if (bad.length) {
            add('room-not-worked', 'severe', 'Room billed that the work record never lists: ' + titleCase(bad[0]),
              'The invoice charges for work in the ' + bad[0] + ', but the work record lists only: ' + (workRooms.length ? workRooms.map(titleCase).join(', ') : '(no rooms)') + '.',
              'Invoice line "' + l.raw + '" = ' + money(l.amount) + '; "' + titleCase(bad[0]) + '" appears in the work record: never',
              l.amount);
            claimed[l.idx] = true;
          }
        });

        /* 6 — Deposit paid but not credited */
        var paid = null;
        P.lines.forEach(function (l) { if (l.isDeposit && l.amount !== null && paid === null) paid = Math.abs(l.amount); });
        var credited = 0;
        I.lines.forEach(function (l) { if (l.isDeposit && l.amount !== null) credited += Math.abs(l.amount); });
        if (paid !== null && paid > credited + 0.005) {
          add('deposit', 'severe', 'Deposit paid but not fully credited on the invoice',
            'The proposal records a deposit of ' + money(paid) + ' already paid. The final invoice credits only ' + money(credited) + ' of it — the rest is being charged to you a second time.',
            money(paid) + ' deposit paid − ' + money(credited) + ' credited on invoice = ' + money(paid - credited) + ' still owed back to you',
            paid - credited);
        }

        /* 7 — Same fee twice under two names */
        var posCharges = invCharges.filter(function (l) { return l.amount > 0; });
        for (var a = 0; a < posCharges.length; a++) {
          for (var b = a + 1; b < posCharges.length; b++) {
            var la = posCharges[a], lb = posCharges[b];
            if (claimed[lb.idx]) continue;
            if (Math.abs(la.amount - lb.amount) > 0.005) continue;
            var ta = sigTokens(la.raw), tb = sigTokens(lb.raw);
            var shared = ta.filter(function (t) { return tb.indexOf(t) >= 0; });
            if (shared.length) {
              add('duplicate-fee', 'severe', 'Same fee billed twice under two names',
                '"' + la.raw + '" and "' + lb.raw + '" are the same charge wearing two labels — both are for ' + money(la.amount) + ' and both hinge on "' + shared[0] + '". The proposal authorizes this fee once.',
                'Fee charged twice at ' + money(la.amount) + ' each; one of them is a duplicate = ' + money(lb.amount),
                lb.amount);
              claimed[lb.idx] = true;
              break;
            }
          }
        }

        /* 8 — Invoice line arithmetic errors */
        I.lines.forEach(function (l) {
          if (l.isTotal || l.isDeposit) return;
          if (l.qty !== null && l.rate !== null && l.amount !== null) {
            var expected = round2(l.qty * l.rate);
            if (Math.abs(expected - l.amount) > 0.01) {
              var diff = round2(l.amount - expected);
              add('arithmetic', 'minor', 'Invoice line arithmetic error',
                'The line "' + l.raw + '" does not multiply out. Quantity × rate is ' + money(expected) + ', but the line charges ' + money(l.amount) + '.',
                fmtNum(l.qty) + ' × ' + money(l.rate) + ' = ' + money(expected) + ', charged ' + money(l.amount) + ' → ' + (diff > 0 ? 'overcharge ' + money(diff) : 'undercharge ' + money(-diff)),
                diff);
              claimed[l.idx] = true;
            }
          }
        });

        /* 9 — Invoice-only charges */
        invCharges.forEach(function (l) {
          if (claimed[l.idx] || l.amount <= 0) return;
          var toks = sigTokens(l.raw);
          if (!toks.length) return;
          var found = toks.some(function (t) { return P.lower.indexOf(t) >= 0 || W.lower.indexOf(t) >= 0; });
          if (!found) {
            add('invoice-only', 'severe', 'Invoice-only charge: appears in neither the proposal nor the work record',
              '"' + l.raw + '" shows up for the first time on the final invoice. It was never proposed and never recorded as work done.',
              'Key words checked (' + toks.join(', ') + '): in proposal: never; in work record: never. Full line amount = ' + money(l.amount),
              l.amount);
            claimed[l.idx] = true;
          }
        });

        /* 10 — Invoice total mismatch */
        var lineSum = 0;
        I.lines.forEach(function (l) { if (!l.isTotal && l.amount !== null) lineSum += l.amount; });
        lineSum = round2(lineSum);
        var stated = statedTotal(I);
        if (stated !== null && Math.abs(stated - lineSum) > 0.01) {
          var diffT = round2(stated - lineSum);
          add('total-mismatch', 'minor', 'Invoice total does not match its own lines',
            'Adding up every line on the invoice (including the deposit credit) gives ' + money(lineSum) + ', but the invoice states a total of ' + money(stated) + '.',
            money(stated) + ' stated − ' + money(lineSum) + ' actual line sum = ' + (diffT > 0 ? money(diffT) + ' overcharge' : money(-diffT) + ' undercharge'),
            diffT);
        }

        var overcharge = round2(findings.reduce(function (s, f) { return s + (f.amount > 0 ? f.amount : 0); }, 0));
        var hasSevere = findings.some(function (f) { return f.severity === 'severe'; });
        var verdict;
        if (insufficient) verdict = 'DO NOT PAY YET';
        else if (findings.length === 0) verdict = 'SAFE TO PAY';
        else if (hasSevere || overcharge >= 500) verdict = 'DO NOT PAY YET';
        else verdict = 'PAY WITH CORRECTIONS';

        return {
          tool: 'J-Dawgs Flooring Installation Proposal, Work Record & Final Invoice Consistency Auditor™',
          generatedAt: new Date().toISOString(),
          settings: { wasteAllowancePct: wastePct },
          verdict: verdict,
          totals: {
            invoiceStatedTotal: stated,
            invoiceLineSum: I.lines.some(function (l) { return l.amount !== null; }) ? lineSum : null,
            documentedOvercharge: overcharge
          },
          parseIssues: parseIssues,
          findings: findings
        };
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-flooring-installation-proposal-work-record-final-invoice-consistency-auditortm',
  name: 'J-Dawgs Flooring Installation Proposal, Work Record & Final Invoice Consistency Auditor',
  description: 'Cross-checks a flooring installation proposal against its work record and final invoice into one pay verdict, with arithmetic shown across all pastes — documented overcharge in its worked example: $3,902.00.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
