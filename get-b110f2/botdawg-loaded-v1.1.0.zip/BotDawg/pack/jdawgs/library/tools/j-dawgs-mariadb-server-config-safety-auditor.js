'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs MariaDB Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var RISKY = [
          "[mysqld]",
          "bind-address = 0.0.0.0",
          "port = 3306",
          "local_infile = 1",
          "secure_file_priv =",
          "require_secure_transport = OFF",
          "general_log = ON",
          "general_log_file = /var/log/mysql/general.log",
          "password = correct-horse-7734-do-not-print",
          "max_connections = 500",
          "max_allowed_packet = 64M",
          "datadir = /var/lib/mysql"
        ].join("\n");

        var HARDENED = [
          "[mysqld]",
          "bind-address = 127.0.0.1",
          "port = 3306",
          "local_infile = 0",
          "secure_file_priv = /var/lib/mysql-files",
          "require_secure_transport = ON",
          "ssl-ca = /etc/mysql/ssl/ca.pem",
          "ssl-cert = /etc/mysql/ssl/server-cert.pem",
          "ssl-key = /etc/mysql/ssl/server-key.pem",
          "general_log = OFF",
          "slow_query_log = ON",
          "slow_query_log_file = /var/log/mysql/slow.log",
          "log_error = /var/log/mysql/error.log",
          "max_connections = 200",
          "max_allowed_packet = 64M",
          "skip-name-resolve",
          "datadir = /var/lib/mysql"
        ].join("\n");

        // Keys this auditor has a rule for, or recognises as standard MariaDB
        // options whose presence alone is not a finding. Anything else is
        // counted NOT AUDITED — never named as safe.
        var KNOWN = {};
        [
          "bind_address", "skip_networking", "port", "socket", "pid_file",
          "datadir", "basedir", "tmpdir", "user", "ssl", "ssl_ca", "ssl_cert",
          "ssl_key", "ssl_cipher", "ssl_capath", "require_secure_transport",
          "local_infile", "secure_file_priv", "skip_grant_tables",
          "skip_name_resolve", "general_log", "general_log_file",
          "slow_query_log", "slow_query_log_file", "long_query_time",
          "log_error", "log_warnings", "max_connections", "max_allowed_packet",
          "max_connect_errors", "character_set_server", "collation_server",
          "default_character_set", "default_storage_engine", "sql_mode",
          "symbolic_links", "skip_symbolic_links", "log_bin", "skip_log_bin",
          "binlog_format", "server_id", "expire_logs_days",
          "binlog_expire_logs_seconds", "lower_case_table_names",
          "open_files_limit", "back_log", "thread_cache_size",
          "table_open_cache", "table_definition_cache", "wait_timeout",
          "interactive_timeout", "read_buffer_size", "read_rnd_buffer_size",
          "sort_buffer_size", "join_buffer_size", "tmp_table_size",
          "max_heap_table_size", "key_buffer_size", "query_cache_size",
          "query_cache_type", "query_cache_limit", "concurrent_insert",
          "innodb_buffer_pool_size", "innodb_buffer_pool_instances",
          "innodb_file_per_table", "innodb_flush_log_at_trx_commit",
          "innodb_log_file_size", "innodb_log_buffer_size",
          "innodb_io_capacity", "innodb_thread_concurrency",
          "innodb_data_file_path", "innodb_undo_directory",
          "performance_schema", "event_scheduler", "plugin_dir",
          "plugin_load_add", "init_connect", "default_authentication_plugin",
          "authentication_policy", "old_passwords", "secure_auth",
          "skip_external_locking", "skip_show_database", "thread_handling",
          "optimizer_switch", "net_buffer_length", "net_read_timeout",
          "net_write_timeout", "sync_binlog", "auto_increment_increment",
          "auto_increment_offset", "ft_min_word_len", "host", "protocol",
          "database", "compress", "ssl_verify_server_cert", "version_comment",
          "gtid_strict_mode", "enforce_gtid_consistency", "relay_log",
          "master_info_repository", "transaction_isolation", "tx_isolation",
          "explicit_defaults_for_timestamp", "disabled_storage_engines",
          "have_ssl", "tls_version", "admin_address", "admin_port",
          "create_admin_listener_thread", "persisted_variables_load"
        ].forEach(function (k) { KNOWN[k] = true; });

        var SECRET_RE = /(password|passwd|pwd|secret|api_?key|access_?token|auth_?token)/i;

        function normKey(raw) {
          var k = raw.replace(/^--/, "").replace(/^loose[-_]/i, "");
          return k.toLowerCase().replace(/-/g, "_");
        }
        function stripQuotes(v) {
          if (v == null) return v;
          var t = String(v).trim();
          if (t.length >= 2) {
            var a = t.charAt(0), b = t.charAt(t.length - 1);
            if ((a === '"' && b === '"') || (a === "'" && b === "'")) return t.slice(1, -1);
          }
          return t;
        }
        function cleanValue(v) {
          if (v == null) return null;
          var t = stripQuotes(v);
          // Trailing inline comments (whitespace then # or ;) are not part of the value.
          var m = /^([^#;]*?)\s+(?:#|;).*$/ .exec(t);
          if (m && !/^\//.test(t)) t = m[1];
          return t.trim();
        }
        function boolOf(entry) {
          if (!entry) return null;
          if (entry.value == null) return true; // bare flag, e.g. "skip-networking"
          var v = String(entry.value).trim().toLowerCase();
          if (v === "1" || v === "on" || v === "true" || v === "yes") return true;
          if (v === "0" || v === "off" || v === "false" || v === "no" || v === "") return false;
          return null;
        }
        function parseSizeBytes(v) {
          if (v == null) return null;
          var m = /^\s*(\d+(?:\.\d+)?)\s*([kmgt]b?|b)?\s*$/i.exec(String(v));
          if (!m) return null;
          var n = parseFloat(m[1]);
          var u = (m[2] || "").toLowerCase();
          var mult = 1;
          if (u.charAt(0) === "k") mult = 1024;
          else if (u.charAt(0) === "m") mult = 1024 * 1024;
          else if (u.charAt(0) === "g") mult = 1024 * 1024 * 1024;
          else if (u.charAt(0) === "t") mult = 1024 * 1024 * 1024 * 1024;
          return Math.round(n * mult);
        }
        function fmtBytes(n) {
          var units = ["B", "KiB", "MiB", "GiB", "TiB"];
          var x = n, i = 0;
          while (x >= 1024 && i < units.length - 1) { x = x / 1024; i++; }
          var s = (i === 0 ? String(x) : (Math.round(x * 100) / 100).toString());
          return n.toLocaleString("en-US") + " bytes (" + s + " " + units[i] + ")";
        }
        function isServerSection(sec) {
          if (sec == null) return true;
          var s = sec.toLowerCase();
          return s === "mysqld" || s === "server" || s === "mariadb" ||
                 s.indexOf("mysqld") === 0 || s.indexOf("mariadb") === 0;
        }
        function isClientSection(sec) {
          if (sec == null) return false;
          var s = sec.toLowerCase();
          return s === "client" || s === "mysql" || s === "mysqldump" ||
                 s === "mariadb-client" || s.indexOf("client") === 0;
        }

        function parse(text) {
          var lines = text.split(/\r\n|\r|\n/);
          var entries = [];      // {key, value|null, line, section}
          var notParsed = [];    // line numbers
          var section = null;
          for (var i = 0; i < lines.length; i++) {
            var lineNo = i + 1;
            var raw = lines[i];
            var t = raw.trim();
            if (t === "") continue;
            if (t.charAt(0) === "#" || t.charAt(0) === ";") continue;
            var secM = /^\[([^\]]+)\]\s*$/.exec(t);
            if (secM) { section = secM[1].trim(); continue; }
            if (t.charAt(0) === "[") { notParsed.push(lineNo); continue; }
            var kv = /^([A-Za-z0-9_.\-]+)\s*(?:=\s*(.*))?$/.exec(t);
            if (kv) {
              entries.push({
                key: normKey(kv[1]),
                rawKey: kv[1],
                value: kv[2] === undefined ? null : cleanValue(kv[2]),
                line: lineNo,
                section: section
              });
              continue;
            }
            notParsed.push(lineNo);
          }
          return { entries: entries, notParsed: notParsed, totalLines: lines.length };
        }

        function audit(text, expectedBind) {
          var parsed = parse(text);
          var entries = parsed.entries;
          var findings = [];
          function add(sev, line, key, title, detail, fix) {
            findings.push({ severity: sev, line: line, key: key, title: title, detail: detail, fix: fix || null });
          }

          // Server-scope effective values (last occurrence wins).
          function eff(key) {
            var found = null;
            entries.forEach(function (e) { if (e.key === key && isServerSection(e.section)) found = e; });
            return found;
          }
          function occurrences(key) {
            return entries.filter(function (e) { return e.key === key; });
          }

          // --- NOT PARSED lines (content never echoed) ---
          parsed.notParsed.forEach(function (ln) {
            add("NOTE", ln, null, "NOT PARSED — line could not be read as a setting",
              "This line is neither a section header, a comment, nor a key = value setting, so the auditor could not read it. Its content is not reproduced here. Check it by hand — an unparsable line in a real my.cnf can stop the server or be silently ignored depending on where it sits.",
              null);
          });

          // --- Secret-like and credential keys: key name + line ONLY ---
          var credentialRefs = [];
          entries.forEach(function (e) {
            var isSecret = SECRET_RE.test(e.key);
            var isCredUser = (e.key === "user" || e.key === "username" || e.key === "default_user") && isClientSection(e.section);
            if (isSecret) {
              credentialRefs.push(e.key + " (line " + e.line + ")");
              add("WARNING", e.line, e.key, "Credential stored in the config file — key name only shown",
                "A secret-like key (" + e.key + ") appears at line " + e.line + ". Its value is never displayed by this auditor — not in these findings, not in the report, not in the JSON. Anyone who can read this file holds that credential.",
                "Move the credential out of the shared config (a root-only option file with 0600 permissions, or a secrets store), and rotate it if this file has been shared.");
            } else if (isCredUser) {
              credentialRefs.push(e.key + " (line " + e.line + ")");
              add("NOTE", e.line, e.key, "Credential-related key in a client section — key name only shown",
                "A user/credential key (" + e.key + ") appears at line " + e.line + " in a client section. Its value is not displayed. Client sections are often copied between machines — treat this file as sensitive.",
                null);
            }
          });

          // --- Duplicate keys (per section): report both lines, last wins ---
          var groups = {};
          entries.forEach(function (e) {
            var g = (e.section || "") + "|" + e.key;
            if (!groups[g]) groups[g] = [];
            groups[g].push(e);
          });
          Object.keys(groups).forEach(function (g) {
            var list = groups[g];
            if (list.length > 1) {
              var linesList = list.map(function (e) { return e.line; }).join(", ");
              var last = list[list.length - 1];
              add("WARNING", list[0].line, list[0].key, "Duplicate key — last value wins",
                "The key " + list[0].key + " is set " + list.length + " times in the same section (lines " + linesList + "). MariaDB applies the last value, so the setting on line " + last.line + " is the one that takes effect; the earlier line(s) are dead text and a common source of \"I fixed it but nothing changed.\" Values are not reproduced here.",
                "Delete the duplicate line(s) for " + list[0].key + " and keep only the intended setting (currently the one on line " + last.line + ").");
            }
          });

          // --- Unknown keys: NOT AUDITED, never safe ---
          var unknownSeen = {};
          entries.forEach(function (e) {
            if (KNOWN[e.key]) return;
            if (SECRET_RE.test(e.key)) return; // already reported above
            if ((e.key === "user" || e.key === "username" || e.key === "default_user") && isClientSection(e.section)) return;
            if (!unknownSeen[e.key]) unknownSeen[e.key] = [];
            unknownSeen[e.key].push(e.line);
          });
          Object.keys(unknownSeen).forEach(function (k) {
            var ls = unknownSeen[k];
            add("NOT AUDITED", ls[0], k, "Key not covered by this auditor",
              "The key " + k + " appears on line" + (ls.length > 1 ? "s " + ls.join(", ") : " " + ls[0]) + " and is not in this auditor's rule set. It is counted as NOT AUDITED — this tool has not judged it safe or unsafe. (An unrecognised key can also be a typo that a real server would reject at startup.)",
              null);
          });

          // --- Networking posture ---
          var skipNet = eff("skip_networking");
          var skipNetOn = boolOf(skipNet) === true;
          var networkingOn = !skipNetOn;
          if (skipNet) {
            if (skipNetOn) {
              add("NOTE", skipNet.line, "skip_networking", "skip-networking is ON — local socket only",
                "With skip-networking on, the server does not listen on TCP at all, so the bind and TLS findings below are informational only — remote clients simply cannot connect.",
                null);
            } else {
              add("NOTE", skipNet.line, "skip_networking", "skip-networking is explicitly OFF — networking is on",
                "The config explicitly leaves networking enabled, so the bind-address and TLS posture below decide who can reach this server.",
                null);
            }
          } else {
            add("NOTE", null, "skip_networking", "skip-networking is not set — networking is on (the default)",
              "Nothing in the pasted config disables networking, so this server is treated as networked: bind-address and TLS decide its exposure.",
              null);
          }

          // --- TLS posture (computed early: bind escalation depends on it) ---
          var rst = eff("require_secure_transport");
          var rstOn = boolOf(rst) === true;
          var sslE = eff("ssl");
          var sslOff = boolOf(sslE) === false && sslE && sslE.value != null;
          var bindE = eff("bind_address");
          var bindState = "missing", bindTokens = [];
          if (bindE) {
            var bv = (bindE.value == null ? "" : String(bindE.value)).trim().toLowerCase();
            bindTokens = bv.split(",").map(function (s) { return s.trim(); });
            if (bv === "" || bindTokens.some(function (x) { return x === "0.0.0.0" || x === "::" || x === "*"; })) bindState = "wildcard";
            else if (bindTokens.every(function (x) { return x === "127.0.0.1" || x === "localhost" || x === "::1"; })) bindState = "loopback";
            else bindState = "specific";
          }
          var exposedBind = networkingOn && (bindState === "wildcard" || bindState === "missing");
          var tlsEsc = exposedBind ? "BLOCKER" : "WARNING";

          if (rst) {
            if (rstOn) {
              add("NOTE", rst.line, "require_secure_transport", "require_secure_transport is ON — TLS is required",
                "Clients must connect over TLS; unencrypted connections are refused. That is the strong posture. The certificate files themselves are not verified by this audit.",
                null);
            } else {
              add(tlsEsc, rst.line, "require_secure_transport", "require_secure_transport is OFF — unencrypted connections allowed",
                "The config explicitly allows plain, unencrypted client connections." + (exposedBind ? " Because the server is reachable on every interface (wildcard or missing bind), this is escalated to a BLOCKER: credentials and data can cross the network in clear text." : " On a loopback-only bind the exposure is smaller, but any local process can still read the traffic."),
                "Set require_secure_transport = ON and configure ssl-ca, ssl-cert and ssl-key so clients must use TLS.");
            }
          } else if (sslOff) {
            add(tlsEsc, sslE.line, "ssl", "ssl is explicitly OFF — TLS is disabled",
              "The config turns TLS off entirely, so every connection is clear text." + (exposedBind ? " Combined with a wildcard or missing bind, that is a BLOCKER." : ""),
              "Remove the ssl = OFF setting, configure ssl-ca, ssl-cert and ssl-key, and set require_secure_transport = ON.");
          } else if (sslE && boolOf(sslE) === true) {
            add("WARNING", sslE.line, "ssl", "TLS is available but not required",
              "The ssl option is on, so clients may use TLS — but nothing forces them to. A client (or a downgrade attack) can still connect in clear text because require_secure_transport is not set.",
              "Set require_secure_transport = ON so TLS is mandatory, not optional.");
          } else {
            add(tlsEsc, null, "require_secure_transport", "No TLS requirement found in the config",
              "Neither require_secure_transport nor an ssl setting appears in the pasted config, so this audit treats connections as unencrypted by default." + (exposedBind ? " Because the server is reachable on every interface (wildcard or missing bind), this is escalated to a BLOCKER." : ""),
              "Configure ssl-ca, ssl-cert and ssl-key and set require_secure_transport = ON.");
          }

          // TLS certificate pairing
          var certKeys = [["ssl_ca", "ssl-ca"], ["ssl_cert", "ssl-cert"], ["ssl_key", "ssl-key"]];
          var presentCerts = [], missingCerts = [], firstCertLine = null;
          certKeys.forEach(function (pair) {
            var e = eff(pair[0]);
            if (e && e.value != null && String(e.value).trim() !== "") {
              presentCerts.push(pair[1]);
              if (firstCertLine == null) firstCertLine = e.line;
            } else missingCerts.push(pair[1]);
          });
          if (presentCerts.length === 3) {
            add("NOTE", firstCertLine, "ssl_ca", "TLS certificate material is fully configured (paths only)",
              "ssl-ca, ssl-cert and ssl-key are all present, so the pairing is complete. This audit reads paths only — it does not open the files, check expiry, or verify the certificates chain to a trusted CA.",
              null);
          } else if (presentCerts.length > 0) {
            add("WARNING", firstCertLine, presentCerts[0].replace(/-/g, "_"), "Partial TLS configuration",
              "Only part of the TLS trio is configured — present: " + presentCerts.join(", ") + "; missing: " + missingCerts.join(", ") + ". A partial TLS config can make the server fail to start with TLS, or leave it running without the encryption you think you turned on.",
              "Configure all three: ssl-ca, ssl-cert and ssl-key (or remove the partial settings and accept the no-TLS finding above).");
          } else {
            add("NOTE", null, "ssl_ca", "No TLS certificate paths configured",
              "No ssl-ca, ssl-cert or ssl-key settings appear in the pasted config, so there is no certificate material for TLS to use.",
              null);
          }

          // --- bind-address ---
          if (!networkingOn) {
            if (bindE) {
              add("NOTE", bindE.line, "bind_address", "bind-address is set but networking is off",
                "skip-networking is on, so this bind-address has no effect — the server only listens on its local socket.",
                null);
            }
          } else if (bindState === "missing") {
            if (rstOn) {
              add("WARNING", null, "bind_address", "No bind-address set — server listens on all interfaces",
                "With no bind-address, MariaDB listens on every network interface by default. require_secure_transport is ON, which keeps the traffic encrypted, but the server is still reachable from anywhere that can route to it.",
                "Set bind-address = 127.0.0.1 if only local applications should connect, or bind a specific private address.");
            } else {
              add("BLOCKER", null, "bind_address", "No bind-address set — server listens on all interfaces, without required TLS",
                "With no bind-address, MariaDB listens on every network interface by default — and this config does not require TLS either. Anyone who can reach the host can attempt to authenticate against it.",
                "Set bind-address = 127.0.0.1 (local only) or a specific private address, and require TLS (require_secure_transport = ON).");
            }
          } else if (bindState === "wildcard") {
            if (rstOn) {
              add("WARNING", bindE.line, "bind_address", "Wildcard bind-address (" + bindE.value + ") — reachable on every interface",
                "The server binds " + bindE.value + ", so it answers on every network interface. require_secure_transport is ON, which encrypts the traffic, but the login surface is still exposed to the whole network — firewall rules and strong accounts carry the whole load.",
                "Bind 127.0.0.1 or a specific private address unless remote clients genuinely need every interface, and firewall port 3306 to known clients.");
            } else {
              add("BLOCKER", bindE.line, "bind_address", "Wildcard bind-address (" + bindE.value + ") with no required TLS",
                "The server binds " + bindE.value + " — every network interface — and require_secure_transport is not ON, so clients can connect in clear text. That pairing is the classic exposed-database setup: reachable by the whole network, readable on the wire.",
                "Set bind-address = 127.0.0.1 or a specific private address, and set require_secure_transport = ON with ssl-ca / ssl-cert / ssl-key configured.");
            }
          } else if (bindState === "loopback") {
            add("NOTE", bindE.line, "bind_address", "bind-address is loopback (" + bindE.value + ") — safer",
              "Binding " + bindE.value + " means the server is only reachable from this host. Remote attackers cannot reach the login prompt at all; local applications are unaffected.",
              null);
          } else {
            add("NOTE", bindE.line, "bind_address", "bind-address is a specific address (" + bindE.value + ")",
              "The server binds only " + bindE.value + ", not every interface. That limits exposure to that network — make sure the address is on a private, firewalled interface if remote clients are not expected.",
              null);
          }

          // Expected-bind check
          if (expectedBind != null && String(expectedBind).trim() !== "") {
            var exp = String(expectedBind).trim().toLowerCase();
            if (bindState === "missing") {
              add("WARNING", null, "bind_address", "Bind does not match your expectation",
                "You expected the server to bind " + expectedBind + ", but the pasted config sets no bind-address at all, so it listens on every interface by default.",
                "Add bind-address = " + expectedBind + " to the [mysqld] section.");
            } else {
              var actual = (bindE.value == null ? "" : String(bindE.value)).trim().toLowerCase();
              if (actual === exp || bindTokens.indexOf(exp) >= 0) {
                add("NOTE", bindE.line, "bind_address", "bind-address matches your expected bind",
                  "The configured bind (" + bindE.value + ") matches the expectation you supplied (" + expectedBind + ").",
                  null);
              } else {
                add("WARNING", bindE.line, "bind_address", "Bind does not match your expectation",
                  "You expected the server to bind " + expectedBind + ", but the config binds " + bindE.value + " (line " + bindE.line + "). Config-vs-intent mismatches are how a server ends up exposed while everyone believes it is local-only.",
                  "Change bind-address to " + expectedBind + ", or correct the expectation if the wider bind is deliberate — and firewall it.");
              }
            }
          }

          // --- port ---
          var portE = eff("port");
          if (portE) {
            var p = parseInt(portE.value, 10);
            if (!isNaN(p) && p === 3306) {
              add("NOTE", portE.line, "port", "port is the default 3306", "The server uses the standard MariaDB/MySQL port, 3306.", null);
            } else if (!isNaN(p)) {
              add("NOTE", portE.line, "port", "Non-default port " + p + " — noted, not a safety control by itself",
                "The server listens on port " + p + " instead of 3306. A non-default port reduces background scanning noise slightly, but it is obscurity, not protection — it is not graded as safe by itself.",
                null);
            } else {
              add("NOTE", portE.line, "port", "port value could not be parsed as a number",
                "The port setting on this line is not a plain number, so this audit could not verify which port the server will use.", null);
            }
          } else {
            add("NOTE", null, "port", "No port set — default 3306 assumed",
              "The pasted config sets no port, so the server will use the default 3306 unless it is set elsewhere (a file this audit cannot see).", null);
          }

          // --- local-infile ---
          var li = eff("local_infile");
          if (li) {
            var lib = boolOf(li);
            if (lib === true) {
              add("BLOCKER", li.line, "local_infile", "local_infile is ON — arbitrary file read risk",
                "local_infile = 1 lets a client ask the server to read files from the connecting machine (LOAD DATA LOCAL INFILE) — and a rogue or compromised server can turn that around to read files from clients that connect to it. It is one of the most abused settings in stolen-credential attacks.",
                "Set local_infile = 0 in [mysqld] unless a specific, trusted import job genuinely needs it — and turn it back off afterwards.");
            } else if (lib === false) {
              add("NOTE", li.line, "local_infile", "local_infile is OFF — good",
                "LOAD DATA LOCAL is disabled, so the file-read path it opens is closed.", null);
            } else {
              add("WARNING", li.line, "local_infile", "local_infile value not recognised",
                "The local_infile setting on this line is not a plain 0/1 or ON/OFF, so this audit cannot tell whether the file-read feature is on. MariaDB treats an ambiguous value as a startup problem or a default you did not choose.",
                "Set local_infile = 0 explicitly.");
            }
          } else {
            add("WARNING", null, "local_infile", "local_infile is not set — the build default decides",
              "Nothing in the pasted config sets local_infile. MariaDB builds have commonly shipped this ON by default, which opens the LOAD DATA LOCAL file-read path — do not leave a security-relevant setting to a default you have not read.",
              "Set local_infile = 0 explicitly in [mysqld].");
          }

          // --- secure_file_priv ---
          var sfp = eff("secure_file_priv");
          if (sfp) {
            var sv = sfp.value == null ? "" : String(sfp.value).trim();
            if (sv.toUpperCase() === "NULL") {
              add("NOTE", sfp.line, "secure_file_priv", "secure_file_priv is NULL — file import/export disabled. Safer.",
                "With secure_file_priv = NULL, LOAD DATA INFILE and SELECT ... INTO OUTFILE are disabled entirely. That is the safest setting if no SQL-level file transfer is needed.", null);
            } else if (sv === "") {
              add("WARNING", sfp.line, "secure_file_priv", "secure_file_priv is empty — file access is unrestricted",
                "An empty secure_file_priv means LOAD DATA INFILE and SELECT ... INTO OUTFILE are not confined to any directory: any account with the FILE privilege can read or write anywhere the server process can reach.",
                "Set secure_file_priv to one dedicated directory (e.g. /var/lib/mysql-files), or to NULL to disable SQL file transfer entirely.");
            } else {
              add("NOTE", sfp.line, "secure_file_priv", "secure_file_priv is restricted to a directory (" + sv + ")",
                "File import/export through SQL is confined to " + sv + ". Make sure that directory is not web-served and is owned by the server account only.", null);
            }
          } else {
            add("NOTE", null, "secure_file_priv", "secure_file_priv is not set — compiled default applies",
              "Nothing in the pasted config sets secure_file_priv, so the build's compiled default decides where SQL file transfer may read and write. Set it explicitly so the answer is in the file, not in the build.",
              null);
          }

          // --- skip-grant-tables ---
          var sgt = eff("skip_grant_tables");
          if (sgt) {
            if (boolOf(sgt) === false) {
              add("NOTE", sgt.line, "skip_grant_tables", "skip-grant-tables is present but set OFF",
                "The option appears in the config but is disabled, so normal authentication applies. It is safer to delete the line entirely so nobody enables it by accident during a late-night repair.", null);
            } else {
              add("BLOCKER", sgt.line, "skip_grant_tables", "skip-grant-tables is present — authentication is bypassed entirely",
                "skip-grant-tables makes the server accept any username with any password and full privileges. It exists for emergency password recovery only. Left in a deployed config, there is effectively no login at all.",
                "Remove skip-grant-tables from the config and restart. If it was added for a password reset, the reset is done — take it back out now.");
            }
          }

          // --- skip-name-resolve ---
          var snr = eff("skip_name_resolve");
          if (snr) {
            add("NOTE", snr.line, "skip_name_resolve", "skip-name-resolve is set — hostnames are not resolved",
              "With name resolution skipped, grants must use IP addresses and a spoofed reverse-DNS name cannot match a hostname grant. The trade-off: existing hostname-based grants silently stop matching, which surprises people during incidents. Posture noted, not graded either way.", null);
          } else {
            add("NOTE", null, "skip_name_resolve", "skip-name-resolve is not set — name resolution is on (default)",
              "The server resolves client hostnames for grant matching. Hostname-based grants then depend on DNS answers — posture noted, not graded either way.", null);
          }

          // --- Logs ---
          var gl = eff("general_log");
          var glf = eff("general_log_file");
          if (gl && boolOf(gl) === true) {
            add("WARNING", gl.line, "general_log", "general_log is ON — every statement is written to a log",
              "The general query log records every statement from every session, including literals — passwords set in SQL, personal data, tokens. It also grows fast enough to fill disks." + (glf && glf.value ? " It is being written to " + glf.value + " (line " + glf.line + ")." : ""),
              "Set general_log = OFF for normal running. Turn it on briefly for a specific debugging session, then off again, and treat any log it produced as sensitive.");
          } else if (gl) {
            add("NOTE", gl.line, "general_log", "general_log is OFF",
              "The general query log is disabled, so session statements (and any secrets inside them) are not being written to a log file.", null);
          } else {
            add("NOTE", null, "general_log", "general_log is not set — off by default",
              "Nothing in the pasted config enables the general query log, so statement-level logging stays off unless another file turns it on.", null);
          }

          var sql2 = eff("slow_query_log");
          var sqlf = eff("slow_query_log_file");
          if (sql2 && boolOf(sql2) === true) {
            add("NOTE", sql2.line, "slow_query_log", "slow_query_log is ON — posture noted",
              "Slow queries are being logged" + (sqlf && sqlf.value ? " to " + sqlf.value + " (line " + sqlf.line + ")" : "") + ". Slow-query logs also contain statement literals, so treat the file as sensitive, but the log itself is a normal operations tool.", null);
          } else if (sql2) {
            add("NOTE", sql2.line, "slow_query_log", "slow_query_log is OFF — posture noted",
              "No slow-query logging: fine for privacy and disk, but you lose the easiest evidence when a query starts hurting. Posture noted, not graded.", null);
          } else {
            add("NOTE", null, "slow_query_log", "slow_query_log is not set — posture noted",
              "The pasted config does not set slow_query_log, so the build default applies. Either posture is defensible; what matters is that it is a chosen one.", null);
          }

          var le = eff("log_error");
          if (le && le.value) {
            add("NOTE", le.line, "log_error", "Error log path noted: " + le.value,
              "Errors and startup messages go to " + le.value + ". This audit notes the path only — it cannot read the log. Make sure the file is not world-readable: startup errors can leak paths and version details.", null);
          } else {
            add("NOTE", null, "log_error", "No log-error path in the pasted config",
              "No log_error setting appears, so errors go to the build/host default location. Fine — but know where that is before you need it during an incident.", null);
          }

          // --- Size arithmetic ---
          var mc = eff("max_connections");
          var mcVal = null;
          if (mc) {
            var n = parseInt(mc.value, 10);
            if (!isNaN(n)) {
              mcVal = n;
              add("NOTE", mc.line, "max_connections", "max_connections = " + n.toLocaleString("en-US"),
                "The server will allow up to " + n.toLocaleString("en-US") + " simultaneous connections. Each one carries session memory, so this number belongs in the host's memory budget, not just the config.", null);
            } else {
              add("NOTE", mc.line, "max_connections", "max_connections value could not be parsed",
                "The max_connections value on this line is not a plain integer, so no arithmetic was done with it.", null);
            }
          } else {
            add("NOTE", null, "max_connections", "max_connections is not set — build default applies",
              "The pasted config does not set max_connections (MariaDB's default is 151). Posture noted.", null);
          }

          var map2 = eff("max_allowed_packet");
          if (map2) {
            var bytes = parseSizeBytes(map2.value);
            if (bytes != null) {
              var detail = "max_allowed_packet = " + map2.value + " = " + fmtBytes(bytes) + ". That is the largest single packet or generated string the server will accept.";
              if (mcVal != null) {
                detail += " Arithmetic, shown for scale: if all " + mcVal.toLocaleString("en-US") + " allowed connections each held one maximum-size packet at once, that alone would be " + mcVal.toLocaleString("en-US") + " × " + bytes.toLocaleString("en-US") + " = " + fmtBytes(mcVal * bytes) + " of data in flight — a worst-case ceiling, not a prediction.";
              }
              if (bytes >= 1073741824) {
                add("WARNING", map2.line, "max_allowed_packet", "max_allowed_packet is very large: " + fmtBytes(bytes),
                  detail + " Packets this large are rarely needed outside bulk-loading and make memory spikes and oversized-statement accidents easier.",
                  "Reduce max_allowed_packet to the largest statement your application genuinely sends (64M covers most applications).");
              } else {
                add("NOTE", map2.line, "max_allowed_packet", "max_allowed_packet = " + fmtBytes(bytes), detail, null);
              }
            } else {
              add("NOTE", map2.line, "max_allowed_packet", "max_allowed_packet value could not be parsed",
                "The value \"" + String(map2.value) + "\" is not a plain size this audit can convert (use a number with an optional K, M or G suffix), so no byte arithmetic was done.", null);
            }
          } else {
            add("NOTE", null, "max_allowed_packet", "max_allowed_packet is not set — build default applies",
              "The pasted config does not set max_allowed_packet, so the build default (commonly 64M in recent MariaDB) applies. Posture noted.", null);
          }

          // --- Authentication posture: never provable from a config ---
          if (credentialRefs.length > 0) {
            add("NOTE", null, null, "Authentication posture — NOT VERIFIED (credential keys present)",
              "Credential-related keys appear in this file, by name and line only: " + credentialRefs.join("; ") + ". Beyond their presence, a config file cannot show which users exist on the live server, whether anonymous users remain, or whether any account has an empty password. Authentication posture is therefore labelled NOT VERIFIED — check it on the server itself (for example, SELECT user, host FROM mysql.user) before deploying.",
              null);
          } else {
            add("NOTE", null, null, "Authentication posture — NOT VERIFIED",
              "No credential keys appear in the pasted config — but that proves nothing either way. A config file cannot show which users exist on the live server, whether anonymous users remain, or whether any account has an empty password. Authentication posture is labelled NOT VERIFIED, never safe, until it is checked on the server itself (for example, SELECT user, host FROM mysql.user).",
              null);
          }

          // --- Verdict & counts ---
          var order = { "BLOCKER": 0, "WARNING": 1, "NOTE": 2, "NOT AUDITED": 3 };
          findings.sort(function (a, b) {
            var d = order[a.severity] - order[b.severity];
            if (d !== 0) return d;
            var la = a.line == null ? 99999 : a.line;
            var lb = b.line == null ? 99999 : b.line;
            return la - lb;
          });
          var counts = { "BLOCKER": 0, "WARNING": 0, "NOTE": 0, "NOT AUDITED": 0 };
          findings.forEach(function (f) { counts[f.severity]++; });
          var verdict = counts.BLOCKER > 0 ? "DO NOT DEPLOY" : (counts.WARNING > 0 ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY");
          var fixes = findings.filter(function (f) { return f.fix && (f.severity === "BLOCKER" || f.severity === "WARNING"); })
            .map(function (f) { return (f.line != null ? "Line " + f.line + " — " : "") + f.fix; });

          return { verdict: verdict, counts: counts, findings: findings, fixes: fixes, parsed: parsed };
        }

        function buildReport(result, expectedBind) {
          var L = [];
          L.push("J-Dawgs MariaDB Server Config Safety Auditor — audit report");
          L.push("==============================================================");
          L.push("Verdict: " + result.verdict);
          L.push("Counts: BLOCKER " + result.counts.BLOCKER + " · WARNING " + result.counts.WARNING +
                 " · NOTE " + result.counts.NOTE + " · NOT AUDITED " + result.counts["NOT AUDITED"]);
          L.push("Expected bind supplied: " + (expectedBind && String(expectedBind).trim() !== "" ? String(expectedBind).trim() : "(none)"));
          L.push("");
          L.push("Findings");
          L.push("--------------------------------------------------------------");
          result.findings.forEach(function (f) {
            L.push("[" + f.severity + "] " + (f.line != null ? "Line " + f.line : "File level") +
                   (f.key ? " · " + f.key : "") + " — " + f.title);
            L.push("  " + f.detail);
            if (f.fix) L.push("  Fix: " + f.fix);
          });
          L.push("");
          L.push("Fix list");
          L.push("--------------------------------------------------------------");
          if (result.fixes.length === 0) {
            L.push("No fixes required by this audit. (NOT VERIFIED and NOT AUDITED items above still stand — a clean verdict covers only what the pasted text shows.)");
          } else {
            result.fixes.forEach(function (fx, i) { L.push((i + 1) + ". " + fx); });
          }
          L.push("");
          L.push("Limits: heuristic text audit of the pasted config only. No server was contacted,");
          L.push("no live users or grants were read, and no certificate was verified. Secret-like");
          L.push("keys are reported by name and line only; their values appear nowhere in this report.");
          L.push("Produced locally in your browser. Nothing was uploaded or saved.");
          return L.join("\n");
        }

        function buildJson(result, expectedBind) {
          var obj = {
            tool: "J-Dawgs MariaDB Server Config Safety Auditor",
            verdict: result.verdict,
            counts: {
              BLOCKER: result.counts.BLOCKER,
              WARNING: result.counts.WARNING,
              NOTE: result.counts.NOTE,
              NOT_AUDITED: result.counts["NOT AUDITED"]
            },
            expectedBind: expectedBind && String(expectedBind).trim() !== "" ? String(expectedBind).trim() : null,
            findings: result.findings.map(function (f) {
              return {
                severity: f.severity,
                line: f.line,
                key: f.key,
                title: f.title,
                detail: f.detail,
                fix: f.fix
              };
            }),
            fixes: result.fixes,
            limits: "Heuristic text audit of pasted config only. No server connection, no live users/grants read, no certificates verified. Secret-like key values are never included."
          };
          return JSON.stringify(obj, null, 2);
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-mariadb-server-config-safety-auditor',
  name: 'J-Dawgs MariaDB Server Config Safety Auditor',
  description: 'Grades a pasted MariaDB my.cnf offline — wildcard bind, local-infile, TLS, secure_file_priv, secrets by key name/line only — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
