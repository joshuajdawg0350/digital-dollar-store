'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Makefile Safety & Silent-No-Op Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Example inputs ---------- */

      var WORKED_MAKEFILE = [
        "# Worked example - a Makefile with planted problems",
        "BUILD_DIR =",
        "API_TOKEN = sk-live-FAKE-0000-never-real",
        "",
        ".PHONY: clean build",
        "",
        "all: build",
        "",
        "build: app.o",
        "\t$(CC) -o app app.o",
        "",
        "app.o: app.c",
        "\t$(CC) -c app.c",
        "",
        "install:",
        "\tcurl -fsSL https://example.com/install.sh | sh",
        "",
        "test:",
        "\t./run-tests.sh",
        "",
        "clean:",
        "\trm -rf $(BUILD_DIR)",
        "",
        "lint:",
        "    ./lint.sh"
      ].join("\n");

      var WORKED_EXISTING = "test";

      var CLEAN_MAKEFILE = [
        "# Clean example - nothing for the auditor to find",
        "CC = gcc",
        "CFLAGS = -O2 -Wall",
        "",
        ".PHONY: all build clean test",
        "",
        "all: build",
        "",
        "build: app.o",
        "\t$(CC) $(CFLAGS) -o app app.o",
        "",
        "app.o: app.c",
        "\t$(CC) $(CFLAGS) -c app.c",
        "",
        "test: build",
        "\t./run-tests.sh",
        "",
        "clean:",
        "\trm -f app app.o"
      ].join("\n");

      var CLEAN_EXISTING = "app.c";

      /* ---------- Auditor ---------- */

      var SECRET_NAME = /(SECRET|TOKEN|PASSWORD|PASSWD|API_?KEY|PRIVATE_?KEY|ACCESS_?KEY|CREDENTIAL|AUTH_?KEY)/i;
      var PLACEHOLDER = /^(x{3,}|\.+|<.*>|changeme|change-me|your[-_ ]|placeholder|example|todo|none|null|redacted)/i;

      function audit(mkText, existingText) {
        var rawLines = String(mkText).replace(/\r\n?/g, "\n").split("\n");
        var findings = [];
        function add(sev, pass, line, title, detail, fix) {
          findings.push({ sev: sev, pass: pass, line: line, title: title, detail: detail, fix: fix });
        }

        /* Pre-pass: variable table (needed to judge rm -rf $(VAR)). */
        var vars = {}; /* name -> { value, line } */
        var assignRe = /^([A-Za-z_][A-Za-z0-9_]*)\s*([:+?]?=)\s*(.*?)\s*$/;
        rawLines.forEach(function (raw, i) {
          if (raw.charAt(0) === "\t" || raw.charAt(0) === " ") return;
          var m = raw.match(assignRe);
          if (m) vars[m[1]] = { value: m[3].replace(/\s+#.*$/, ""), line: i + 1, op: m[2] };
        });

        var existing = {};
        String(existingText).split(/[\n,]+/).forEach(function (s) {
          var v = s.trim().replace(/^\.\//, "").replace(/\/$/, "");
          if (v) existing[v] = true;
        });

        var phony = {};      /* name -> decl line */
        var targetDefs = {}; /* name -> [ {line, prereqs, hasRecipe} ] */
        var targetOrder = [];
        var defaultTarget = null;
        var currentTargets = null; /* defs currently collecting recipe lines */

        function checkRecipe(line, ln) {
          var t = line.replace(/^\s+/, "");
          var compact = t.replace(/\s+/g, "");

          /* Fork bomb */
          if (compact.indexOf(":(){:|:&};:") !== -1 || /:\(\)\{/.test(compact)) {
            add("blocker", 1, ln, "Fork bomb pattern",
              "This recipe line matches the classic shell fork-bomb pattern. Running it can freeze the machine.",
              "Delete this line. There is no legitimate build step that needs it.");
          }
          /* Remote code piped to a shell */
          if (/\b(curl|wget)\b[^|#]*\|\s*(sudo\s+)?(sh|bash|zsh|dash|ash|python3?|perl|ruby)\b/.test(t) ||
              /\b(sh|bash|zsh)\s+-c\s+["']?\$\(\s*(curl|wget)\b/.test(t) ||
              /\b(sh|bash|zsh)\b[^#]*<\(\s*(curl|wget)\b/.test(t)) {
            add("blocker", 1, ln, "Remote code executed without verification",
              "This recipe downloads a script and pipes it straight into a shell. Whatever the server returns is what runs, with your permissions, and nothing checks it first.",
              "Download the script to a file, inspect it (and verify a checksum or signature), then run the saved copy.");
          }
          /* rm recursive */
          var rm = t.match(/\brm\s+((?:-\S+\s+)*)(.*)$/);
          if (rm && /r/.test(rm[1] || "")) {
            var operands = (rm[2] || "").trim();
            var vm = operands.match(/\$\((\w+)\)|\$\{(\w+)\}/);
            if (operands === "/" || operands.indexOf("/*") === 0 || operands === "~" || operands === "~/" ||
                operands.indexOf("$HOME") === 0 || operands.indexOf("/") === 0 && operands.split(/\s+/)[0] === "/") {
              add("blocker", 1, ln, "rm -rf aimed at a root or home path",
                "This recursive delete targets a root or home path. One run can erase the system or the user's files.",
                "Point the delete at a specific build subdirectory and guard it (test -n and a prefix check) before running.");
            } else if (vm) {
              var vname = vm[1] || vm[2];
              var v = vars[vname];
              if (!v) {
                add("blocker", 1, ln, "rm -rf on an undefined variable ($(" + vname + "))",
                  "$(" + vname + ") is never assigned in this Makefile. If it is empty in the environment, the delete can collapse onto a bare or root path.",
                  "Define " + vname + " in the Makefile, or fail the recipe when it is empty: test -n \"$(\" + vname + \")\".");
              } else if (v.value.trim() === "") {
                add("blocker", 1, ln, "rm -rf on a possibly-empty variable ($(" + vname + "))",
                  "$(" + vname + ") is assigned an empty value at line " + v.line + ". If the recipe appends anything to it (a slash, a subpath), an empty expansion can turn the delete loose on the wrong directory.",
                  "Give " + vname + " a real value, or guard the recipe: refuse to run when $(" + vname + ") is empty.");
              } else {
                add("warn", 1, ln, "rm -rf with a variable target ($(" + vname + "))",
                  "The delete target comes from a variable assigned at line " + v.line + ". Safe only as long as that value is always the intended build directory.",
                  "Echo the expanded target in a dry run (make -n) before a real run, and consider a guard that the value starts with the project directory.");
              }
            } else if (operands.indexOf("*") !== -1) {
              add("blocker", 1, ln, "rm -rf with a wildcard target",
                "A recursive delete through a wildcard removes whatever the glob happens to match at run time, which may be more than the build output.",
                "List the exact paths to delete, or confine the wildcard to a dedicated build directory.");
            }
          }
          /* dd to a device */
          if (/\bdd\b/.test(t) && /\bof=\/dev\//.test(t)) {
            add("blocker", 1, ln, "dd writing to a device path",
              "dd with of=/dev/… writes raw bytes straight to a device. A typo in the device name overwrites the wrong disk.",
              "Remove this from the Makefile, or run it manually after triple-checking the exact device path.");
          }
          /* mkfs */
          if (/\bmkfs(\.[A-Za-z0-9]+)?\b/.test(t)) {
            add("blocker", 1, ln, "mkfs in a recipe",
              "mkfs formats a filesystem — it destroys everything on the target device. It does not belong in a build step.",
              "Remove the mkfs step from the Makefile and format devices manually, deliberately.");
          }
          /* shred */
          if (/\bshred\b/.test(t)) {
            add("warn", 1, ln, "shred in a recipe",
              "shred overwrites a file so it cannot be recovered. In a build recipe it can run on the wrong file with no undo.",
              "Confirm the target is exactly the file meant to be destroyed, or move shredding out of the build.");
          }
          /* writes into /etc or /usr */
          if (/(^|\s)(>>?)\s*\/(etc|usr)\//.test(t) || /\b(tee|cp|mv|install|rsync)\b[^|#]*\/(etc|usr)\//.test(t)) {
            add("warn", 1, ln, "Recipe writes into a system directory (/etc or /usr)",
              "This recipe writes into a system directory. That usually needs root, affects the whole machine, and is easy to trigger by accident with the wrong target.",
              "Install into a project-local or staging prefix instead, and make any system install a separate, clearly named manual step.");
          }
          /* git clone as a build step */
          if (/\bgit\s+clone\b/.test(t)) {
            var pinned = /(--branch|-b)[ =]+["']?v?\d+\.\d+/.test(t);
            if (!pinned) {
              add("warn", 1, ln, "git clone of a moving branch used as a build step",
                "The clone is not pinned to a tag or commit, so the build silently pulls whatever the branch holds that day — unreviewed code, straight into the build.",
                "Pin the clone to a release tag or full commit hash (--branch vX.Y.Z or a checkout of a fixed commit).");
            }
          }
          /* sudo */
          if (/(^|[\s;|&])sudo\s/.test(t)) {
            add("warn", 1, ln, "sudo in a recipe",
              "A recipe running sudo can prompt mid-build, run with more privilege than the build needs, and surprise whoever invoked an innocent-looking target.",
              "Drop sudo from the recipe; if a step truly needs root, name the target clearly (e.g. install-system) so nobody hits it by accident.");
          }
        }

        var targetRe = /^([^\s:=#][^:=]*?)\s*:(?![=])\s*(.*)$/;
        var prevWasAssignContinuation = false;

        rawLines.forEach(function (raw, idx) {
          var ln = idx + 1;
          var trimmed = raw.trim();

          /* Recipe line (tab) */
          if (raw.charAt(0) === "\t") {
            if (currentTargets) currentTargets.forEach(function (d) { d.hasRecipe = true; });
            checkRecipe(raw, ln);
            prevWasAssignContinuation = false;
            return;
          }
          /* Space-indented line */
          if (/^ +[^ ]/.test(raw)) {
            if (currentTargets && !prevWasAssignContinuation) {
              currentTargets.forEach(function (d) { d.hasRecipe = true; });
              add("blocker", 2, ln, "Recipe line indented with spaces (missing separator)",
                "This line sits under a target but is indented with spaces, not a tab. GNU make rejects it with \"missing separator\" and the build stops.",
                "Re-indent line " + ln + " with a single tab character.");
              checkRecipe(raw, ln);
            }
            return;
          }
          /* Blank or comment: context carries on */
          if (trimmed === "" || trimmed.charAt(0) === "#") return;

          /* Column-0 line: recipe context ends unless it is a target */
          var am = raw.match(assignRe);
          if (am && raw.indexOf(":") === -1 || am && am[2] !== "=" && raw.indexOf("=") < raw.indexOf(":") || am && /^[A-Za-z_][A-Za-z0-9_]*\s*=/.test(raw) || am && /^[A-Za-z_][A-Za-z0-9_]*\s*[:+?]=/.test(raw)) {
            currentTargets = null;
            prevWasAssignContinuation = /\\\s*$/.test(raw);
            var name = am[1], op = am[2], value = am[3].replace(/\s+#.*$/, "");
            /* Hardcoded secret — name and line ONLY, value never reported */
            if (SECRET_NAME.test(name) && value.trim() !== "" && value.indexOf("$(") !== 0 && value.indexOf("${") !== 0 && !PLACEHOLDER.test(value.trim().replace(/^["']|["']$/g, ""))) {
              add("blocker", 1, ln, "Hardcoded secret in variable " + name + ", line " + ln,
                "Variable " + name + " is assigned a literal secret value in the Makefile. Anyone who can read the file — or the repo history — has the secret. (The value is deliberately not shown anywhere in this audit.)",
                "Move " + name + " out of the Makefile: read it from the environment or a secrets file that is never committed, and rotate the exposed value.");
            }
            /* Recursive self-reference */
            if ((op === "=" || op === "+=") && (value.indexOf("$(" + name + ")") !== -1 || value.indexOf("${" + name + "}") !== -1)) {
              add("warn", 2, ln, "Recursive variable self-reference (" + name + " = $(" + name + "))",
                "With recursive (=) assignment, " + name + " refers to itself. Make aborts with \"Recursive variable '" + name + "' references itself (eventually)\" the moment anything expands it.",
                "Build the value from a different base variable, or set it with := before appending.");
            }
            /* $(shell ...) at parse time */
            if (value.indexOf("$(shell") !== -1 || value.indexOf("$(shell ") !== -1) {
              add("warn", 1, ln, "$(shell …) runs at parse time",
                "This assignment is expanded while make reads the file, so the shell command runs on ANY target invocation — even make clean or make -n style dry runs of unrelated targets.",
                "Move the command into the recipe that actually needs its output, or guard it so it only runs for the targets that use it.");
            }
            return;
          }

          if (/^-?s?include\s+/.test(raw)) {
            currentTargets = null;
            add("note", 2, ln, "include at line " + ln + " — NOT AUDITED",
              "This line pulls in another makefile. This audit reads only the pasted text, so the included file's targets, variables, and recipes were not checked.",
              "Paste the included file's contents in as well and re-run the audit to cover it.");
            return;
          }

          var phonyM = raw.match(/^\.PHONY\s*:\s*(.*)$/);
          if (phonyM) {
            currentTargets = null;
            phonyM[1].replace(/#.*$/, "").split(/\s+/).forEach(function (n) {
              if (n) phony[n] = ln;
            });
            return;
          }
          if (raw.charAt(0) === ".") { currentTargets = null; return; } /* other special targets */

          var tm = raw.match(targetRe);
          if (tm) {
            var namesPart = tm[1].trim();
            var rest = tm[2] || "";
            var semi = rest.indexOf(";");
            var prereqPart = (semi === -1 ? rest : rest.slice(0, semi)).replace(/#.*$/, "").trim();
            var inlineRecipe = semi !== -1 && rest.slice(semi + 1).trim() !== "";
            var defs = [];
            namesPart.split(/\s+/).forEach(function (n) {
              if (!n) return;
              var def = { name: n, line: ln, prereqs: prereqPart, hasRecipe: inlineRecipe };
              if (!targetDefs[n]) { targetDefs[n] = []; targetOrder.push(n); }
              targetDefs[n].push(def);
              defs.push(def);
              if (defaultTarget === null && n.charAt(0) !== "." && n.indexOf("%") === -1) {
                defaultTarget = { name: n, line: ln };
              }
            });
            currentTargets = defs;
            if (inlineRecipe) checkRecipe(rest.slice(semi + 1), ln);
            /* $(shell) in a target/prereq line also expands at parse time */
            if (raw.indexOf("$(shell") !== -1) {
              add("warn", 1, ln, "$(shell …) runs at parse time",
                "This target line is expanded while make reads the file, so the shell command runs on ANY target invocation, before anything is built.",
                "Move the command into a recipe so it only runs when its target is actually requested.");
            }
            prevWasAssignContinuation = false;
            return;
          }

          /* Unmatched column-0 line (define/endef, conditionals, etc.) */
          currentTargets = null;
          if (raw.indexOf("$(shell") !== -1) {
            add("warn", 1, ln, "$(shell …) runs at parse time",
              "This line is expanded while make reads the file, so the shell command runs on ANY target invocation.",
              "Move the command into a recipe so it only runs when needed.");
          }
        });

        /* ---- Pass 2 post-checks ---- */

        targetOrder.forEach(function (n) {
          var defs = targetDefs[n];
          /* Silent no-op: target names an existing file/dir but is not .PHONY */
          if (existing[n] && !phony[n] && n.indexOf("%") === -1 && n.charAt(0) !== ".") {
            add("blocker", 2, defs[0].line, "Target '" + n + "' will silently do nothing (not .PHONY, but '" + n + "' exists)",
              "'" + n + "' is listed as an existing file/directory in this project, and the target '" + n + "' (line " + defs[0].line + ") is not declared .PHONY. Because the file exists and has no older prerequisites to beat, make will report '" + n + " is up to date' and silently skip the recipe — the build looks green and nothing ran.",
              "Add " + n + " to a .PHONY declaration (e.g. .PHONY: " + n + "), or rename the target so it no longer collides with a real file or directory.");
          }
          /* Duplicate definitions */
          if (defs.length > 1) {
            var linesList = defs.map(function (d) { return d.line; }).join(" and ");
            var withRecipes = defs.filter(function (d) { return d.hasRecipe; }).length;
            add("warn", 2, defs[1].line, "Duplicate target '" + n + "' (defined at lines " + linesList + ")",
              withRecipes > 1
                ? "Target '" + n + "' gets a recipe more than once. Make keeps only the LAST recipe and warns \"overriding recipe\" — the earlier recipe is silently dead."
                : "Target '" + n + "' is defined more than once. Make merges the prerequisites from all definitions, which may not be what either definition intended.",
              "Merge the definitions of '" + n + "' into one, at a single line.");
          }
          /* No recipe, no prerequisites */
          defs.forEach(function (d) {
            if (!d.hasRecipe && d.prereqs === "" && n.indexOf("%") === -1 && n.charAt(0) !== ".") {
              add("note", 2, d.line, "Target '" + n + "' has no recipe and no prerequisites",
                "Running make " + n + " succeeds instantly and does nothing at all — an easy silent no-op to mistake for a passed step.",
                "Give '" + n + "' a recipe, prerequisites, or delete the target if it is a leftover.");
            }
          });
        });

        /* .PHONY names with no matching target (typo trap) */
        Object.keys(phony).forEach(function (n) {
          if (!targetDefs[n]) {
            add("warn", 2, phony[n], ".PHONY declares '" + n + "', but no target named '" + n + "' exists",
              "A .PHONY entry with no matching target usually means a typo: the real target was meant to be phony but isn't, so it can be silently skipped when a file with its name exists.",
              "Fix the spelling in the .PHONY line, or add it to the real target's .PHONY declaration.");
          }
        });

        var sevRank = { blocker: 0, warn: 1, note: 2 };
        findings.sort(function (a, b) {
          if (a.line !== b.line) return a.line - b.line;
          return sevRank[a.sev] - sevRank[b.sev];
        });

        var blockers = findings.filter(function (f) { return f.sev === "blocker"; }).length;
        var warns = findings.filter(function (f) { return f.sev === "warn"; }).length;
        var notes = findings.filter(function (f) { return f.sev === "note"; }).length;
        var verdict = blockers > 0 ? "DO NOT RUN" : (warns > 0 ? "RUN WITH FIXES" : "SAFE TO RUN");

        return {
          findings: findings, blockers: blockers, warns: warns, notes: notes,
          verdict: verdict, defaultTarget: defaultTarget
        };
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-makefile-safety-silent-no-op-auditor',
  name: 'J-Dawgs Makefile Safety & Silent-No-Op Auditor',
  description: 'Audits a pasted Makefile anywhere: destructive recipes, empty-variable rm risks, curl|sh, secrets by name only, and non-.PHONY targets that silently do nothing — one run verdict. Makefile linters need an install and grade style; ours grades whether targets are safe to run and whether any will silent',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
