'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Umami Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

  "use strict";
  var KNOWN = {
    DATABASE_URL:1, DATABASE_TYPE:1, DATABASE_HOST:1, DATABASE_PORT:1, DATABASE_USER:1,
    DATABASE_PASSWORD:1, DATABASE_NAME:1, HOSTNAME:1, PORT:1, DISABLE_LOGIN:1,
    DISABLE_TELEMETRY:1, IGNORE_IP:1, IGNORE_USER_AGENT:1, CORS_ORIGIN:1, SESSION_TIMEOUT:1,
    REDIS_URL:1, APP_SECRET:1, JWT_SECRET:1, HOST_URL:1, BASE_PATH:1, CLIENT_IP_HEADER:1,
    DISABLE_UI:1, WEBSITE_BASE_URL:1, TRACK_UMAMI:1
  };
  var COMMON_PASSWORDS = ["password","password123","password1","postgres","postgresql","mysql",
    "umami","admin","administrator","changeme","change-me","example","test","test123","secret",
    "letmein","default","123456","12345678","12345","qwerty","root","dbpassword","database"];
  var SECRET_KEY_RE = /(PASSWORD|SECRET|TOKEN|API_KEY|APIKEY|PRIVATE_KEY)/;

  function isPlaceholder(v){
    if(!v) return true;
    if(/^\$\{[^}]*\}$/.test(v)) return true;
    if(/^\$[A-Za-z_][A-Za-z0-9_]*$/.test(v)) return true;
    if(/^\*+$/.test(v)) return true;
    if(/^<[^>]*>$/.test(v)) return true;
    if(/^\{\{[^}]*\}\}$/.test(v)) return true;
    return false;
  }
  function isTrue(v){ return /^(true|1|yes|on)$/i.test(String(v).trim()); }
  function isFalse(v){ return /^(false|0|no|off)$/i.test(String(v).trim()); }

  function parseConfig(text){
    var lines = String(text == null ? "" : text).split(/\r?\n/);
    var entries = [], commented = [], notParsed = [], blank = 0;
    for(var i=0;i<lines.length;i++){
      var lineNo = i+1, t = lines[i].trim();
      if(t === ""){ blank++; continue; }
      if(t.charAt(0) === "#" || t.indexOf("//") === 0){
        var inner = t.replace(/^#+\s?/,"").replace(/^\/\/\s?/,"");
        var cm = inner.match(/^([A-Za-z_][A-Za-z0-9_]*)\s*[:=]/);
        commented.push({line:lineNo, key: cm ? cm[1].toUpperCase() : null});
        continue;
      }
      var work = t;
      if(work.indexOf("- ") === 0) work = work.slice(2).trim();
      if(/^export\s+/i.test(work)) work = work.replace(/^export\s+/i,"");
      var m = work.match(/^([A-Za-z_][A-Za-z0-9_]*)\s*[:=]\s*(.*)$/);
      if(!m){ notParsed.push({line:lineNo}); continue; }
      var key = m[1].toUpperCase();
      var value = m[2].trim();
      if(value.indexOf("://") === -1){
        var hashIdx = value.indexOf(" #");
        if(hashIdx > 0) value = value.slice(0, hashIdx).trim();
      }
      if(value.length >= 2 &&
        ((value.charAt(0)==='"' && value.charAt(value.length-1)==='"') ||
         (value.charAt(0)==="'" && value.charAt(value.length-1)==="'"))){
        value = value.slice(1,-1);
      }
      entries.push({key:key, value:value, line:lineNo});
    }
    return {entries:entries, commented:commented, notParsed:notParsed, blank:blank, totalLines:lines.length};
  }

  function parseDbUrl(raw){
    var out = {looksLikeUrl:false, scheme:null, host:null, hasPassword:false, passwordLength:0, passwordIsPlaceholder:false, passwordIsCommon:false};
    var m = String(raw).match(/^([a-zA-Z][a-zA-Z0-9+.-]*):\/\/([^/?#]*)/);
    if(!m) return out;
    out.looksLikeUrl = true; out.scheme = m[1].toLowerCase();
    var authority = m[2], at = authority.lastIndexOf("@");
    var hostPart = at >= 0 ? authority.slice(at+1) : authority;
    out.host = hostPart || null;
    if(at >= 0){
      var userinfo = authority.slice(0, at), colon = userinfo.indexOf(":");
      if(colon >= 0){
        var pw = userinfo.slice(colon+1);
        try{ pw = decodeURIComponent(pw); }catch(e){}
        if(pw.length > 0){
          out.hasPassword = true; out.passwordLength = pw.length;
          out.passwordIsPlaceholder = isPlaceholder(pw);
          out.passwordIsCommon = COMMON_PASSWORDS.indexOf(pw.toLowerCase()) !== -1;
        }
      }
    }
    return out;
  }

  function isPublicHost(h){
    if(!h) return false;
    var v = String(h).trim().toLowerCase();
    if(v === "localhost" || v === "127.0.0.1" || v === "::1" || v === "0.0.0.0") return false;
    if(/^10\./.test(v) || /^192\.168\./.test(v) || /^172\.(1[6-9]|2\d|3[0-1])\./.test(v)) return false;
    if(/^\d+\.\d+\.\d+\.\d+$/.test(v)) return true;
    if(v.indexOf(".") !== -1) return true;
    return false;
  }

  function audit(text){
    var parsed = parseConfig(text);
    var findings = [];
    function add(sev, key, line, msg){ findings.push({severity:sev, key:key, line:line, message:msg}); }

    var byKey = {}, order = [];
    parsed.entries.forEach(function(e){
      if(!byKey[e.key]){ byKey[e.key] = []; order.push(e.key); }
      byKey[e.key].push(e);
    });
    var eff = {};
    order.forEach(function(k){ eff[k] = byKey[k][byKey[k].length-1]; });

    var recognized = order.filter(function(k){ return !!KNOWN[k]; }).length;

    order.forEach(function(k){
      if(byKey[k].length > 1){
        var lineList = byKey[k].map(function(e){ return e.line; }).join(", ");
        add("MEDIUM", k, byKey[k][byKey[k].length-1].line,
          "Duplicate key " + k + " appears on lines " + lineList + ". Last value wins — the entry on line " +
          byKey[k][byKey[k].length-1].line + " is the one graded; the earlier value(s) are ignored.");
      }
    });

    parsed.commented.forEach(function(c){
      if(c.key){
        add("INFO", c.key, c.line, "Line " + c.line + ": " + c.key + " is COMMENTED / NOT ACTIVE — it is not set and was not graded.");
      }
    });
    parsed.notParsed.forEach(function(n){
      add("INFO", null, n.line, "Line " + n.line + ": NOT PARSED — this line does not match KEY=value or KEY: value format and was excluded from grading.");
    });

    var unknown = order.filter(function(k){ return !KNOWN[k]; });
    if(unknown.length){
      add("INFO", null, null, "Unrecognized key(s) left ungraded: " + unknown.join(", ") + ". Only known Umami keys are graded.");
    }

    /* DATABASE_URL */
    var dbEntry = eff["DATABASE_URL"] || null, dbInfo = null;
    if(!dbEntry){
      add("MEDIUM", "DATABASE_URL", null, "DATABASE_URL is not set in the active config. Umami cannot reach a database without it, and credential posture cannot be graded.");
    } else {
      dbInfo = parseDbUrl(dbEntry.value);
      if(!dbInfo.looksLikeUrl){
        add("MEDIUM", "DATABASE_URL", dbEntry.line, "DATABASE_URL on line " + dbEntry.line + " does not look like a scheme:// URL, so its credential posture cannot be verified from the text. The value is never shown.");
      } else if(dbInfo.hasPassword && !dbInfo.passwordIsPlaceholder){
        add("HIGH", "DATABASE_URL", dbEntry.line,
          "DATABASE_URL on line " + dbEntry.line + " embeds a plaintext password (password length " + dbInfo.passwordLength + "). The password value is never shown in this audit. Anyone who can read this config text holds the database credential — keep the file secret-managed and out of source control.");
        if(dbInfo.passwordIsCommon || dbInfo.passwordLength < 12){
          add("BLOCKER", "DATABASE_URL", dbEntry.line,
            "The DATABASE_URL password on line " + dbEntry.line + " is " + (dbInfo.passwordIsCommon ? "a well-known example/common password" : "short") +
            " (password length " + dbInfo.passwordLength + "). It would be guessed immediately. Replace it with a long, unique password before deploying.");
        }
      } else if(dbInfo.hasPassword && dbInfo.passwordIsPlaceholder){
        add("OK", "DATABASE_URL", dbEntry.line, "DATABASE_URL on line " + dbEntry.line + " uses a variable/placeholder reference for its password rather than a plaintext value. Good posture.");
      } else {
        add("OK", "DATABASE_URL", dbEntry.line, "DATABASE_URL on line " + dbEntry.line + " embeds no password in the URL text (scheme " + (dbInfo.scheme || "unknown") + "). Credential posture for the pasted text is clean.");
      }
      var dt = eff["DATABASE_TYPE"];
      if(dt && dbInfo.looksLikeUrl && dbInfo.scheme){
        var want = (dbInfo.scheme.indexOf("postgres") === 0) ? "postgresql" : (dbInfo.scheme === "mysql" ? "mysql" : null);
        if(want && dt.value.trim().toLowerCase() !== want){
          add("MEDIUM", "DATABASE_TYPE", dt.line, "DATABASE_TYPE on line " + dt.line + " is set to \"" + dt.value + "\" but the DATABASE_URL scheme points to " + want + ". The mismatch will stop Umami from using the database as configured.");
        }
      }
    }

    /* Secret-shaped standalone keys */
    order.forEach(function(k){
      if(k === "DATABASE_URL") return;
      if(SECRET_KEY_RE.test(k)){
        var e = eff[k];
        if(e.value && !isPlaceholder(e.value)){
          add("HIGH", k, e.line, k + " on line " + e.line + " holds a plaintext secret value (length " + e.value.length + "). The value is never shown in this audit. Keep it secret-managed and out of source control.");
        } else if(e.value){
          add("OK", k, e.line, k + " on line " + e.line + " uses a placeholder/variable reference rather than a plaintext secret.");
        }
      }
    });

    /* DISABLE_LOGIN */
    var dl = eff["DISABLE_LOGIN"];
    if(dl){
      if(isTrue(dl.value)){
        add("BLOCKER", "DISABLE_LOGIN", dl.line, "DISABLE_LOGIN=true on line " + dl.line + " turns the Umami login off entirely. Anyone who can reach the server gets full use of it with no account. Set DISABLE_LOGIN=false (or remove the key) before deploying.");
      } else if(isFalse(dl.value)){
        add("OK", "DISABLE_LOGIN", dl.line, "DISABLE_LOGIN is off on line " + dl.line + " — the login stays enabled.");
      } else {
        add("MEDIUM", "DISABLE_LOGIN", dl.line, "DISABLE_LOGIN on line " + dl.line + " has an unrecognized value (\"" + dl.value + "\"). Use true or false so the login posture is unambiguous.");
      }
    } else {
      add("INFO", "DISABLE_LOGIN", null, "DISABLE_LOGIN is not set. Umami's default keeps the login enabled — confirm that default is what the running version does.");
    }

    /* HOSTNAME */
    var hn = eff["HOSTNAME"], hostnamePublic = false, allInterfaces = false;
    if(hn){
      var hv = hn.value.trim().toLowerCase();
      if(hv === "0.0.0.0" || hv === "::" || hv === "[::]" || hv === "*"){
        allInterfaces = true;
        add("HIGH", "HOSTNAME", hn.line, "HOSTNAME on line " + hn.line + " is " + hn.value + " — the server binds every network interface, including public ones if the host has them. Bind a specific interface or put the server behind a reverse proxy with access controls.");
      } else if(hv === "127.0.0.1" || hv === "localhost" || hv === "::1"){
        add("OK", "HOSTNAME", hn.line, "HOSTNAME on line " + hn.line + " binds locally (" + hn.value + "). Reachable only through a local process or reverse proxy.");
      } else if(isPublicHost(hv)){
        hostnamePublic = true;
        add("MEDIUM", "HOSTNAME", hn.line, "HOSTNAME on line " + hn.line + " is a public address (" + hn.value + "). The server is meant to be reachable from the network — make sure TLS and the login are in place.");
      } else {
        add("INFO", "HOSTNAME", hn.line, "HOSTNAME on line " + hn.line + " is set to " + hn.value + ". Confirm that bind matches how the server should be reached.");
      }
    } else {
      add("INFO", "HOSTNAME", null, "HOSTNAME is not set. Umami will use its default bind — verify the running server is not exposed on an interface you did not intend.");
    }

    /* TLS / http posture */
    var values = order.map(function(k){ return eff[k].value; });
    var hasHttps = values.some(function(v){ return String(v).indexOf("https://") !== -1; });
    var httpLines = [];
    parsed.entries.forEach(function(e){
      if(String(e.value).indexOf("http://") !== -1 && !SECRET_KEY_RE.test(e.key) && e.key !== "DATABASE_URL") httpLines.push(e);
    });
    httpLines.forEach(function(e){
      add("MEDIUM", e.key, e.line, e.key + " on line " + e.line + " uses a plain http:// address. Traffic to it is unencrypted — use https:// wherever the endpoint supports it.");
    });
    if(!httpLines.length && (hostnamePublic || allInterfaces) && !hasHttps){
      add("MEDIUM", "HOSTNAME", hn ? hn.line : null,
        "Public or all-interface exposure with no https:// indicator anywhere in the config — http-only posture flagged. Confirm a reverse proxy or the server itself terminates TLS before this is reachable.");
    }

    /* DISABLE_TELEMETRY */
    var tel = eff["DISABLE_TELEMETRY"];
    if(tel){
      if(isTrue(tel.value)){
        add("OK", "DISABLE_TELEMETRY", tel.line, "DISABLE_TELEMETRY=true on line " + tel.line + " — telemetry is disabled.");
      } else if(isFalse(tel.value)){
        add("MEDIUM", "DISABLE_TELEMETRY", tel.line, "DISABLE_TELEMETRY=false on line " + tel.line + " — telemetry is left enabled, so the instance reports usage data back. Set it to true if that is not intended.");
      } else {
        add("INFO", "DISABLE_TELEMETRY", tel.line, "DISABLE_TELEMETRY on line " + tel.line + " has an unrecognized value (\"" + tel.value + "\"); telemetry posture is unclear.");
      }
    } else {
      add("INFO", "DISABLE_TELEMETRY", null, "DISABLE_TELEMETRY is not set. Telemetry posture follows the Umami default for the running version — set DISABLE_TELEMETRY=true to opt out explicitly.");
    }

    /* CORS_ORIGIN */
    var cors = eff["CORS_ORIGIN"];
    if(cors){
      var cv = cors.value.trim();
      if(cv === "*" || /(^|[,\s])\*([,\s]|$)/.test(cv)){
        add("HIGH", "CORS_ORIGIN", cors.line, "CORS_ORIGIN=* on line " + cors.line + " accepts cross-origin requests from any website. Name the specific origin(s) that should be allowed instead.");
      } else if(cv === ""){
        add("INFO", "CORS_ORIGIN", cors.line, "CORS_ORIGIN is present but empty on line " + cors.line + ". Confirm the intended cross-origin posture.");
      } else {
        add("OK", "CORS_ORIGIN", cors.line, "CORS_ORIGIN on line " + cors.line + " names specific origin(s) rather than a wildcard.");
      }
    } else {
      add("INFO", "CORS_ORIGIN", null, "CORS_ORIGIN is not set. Cross-origin posture follows the Umami default — set it explicitly if other sites embed or call this instance.");
    }

    /* SESSION_TIMEOUT */
    var st = eff["SESSION_TIMEOUT"];
    if(st){
      var n = parseInt(st.value, 10);
      if(isNaN(n) || String(st.value).trim() === "" || !/^-?\d+$/.test(String(st.value).trim())){
        add("MEDIUM", "SESSION_TIMEOUT", st.line, "SESSION_TIMEOUT on line " + st.line + " is not a plain number (\"" + st.value + "\"). Set it in seconds so session lifetime is unambiguous.");
      } else if(n === 0){
        add("MEDIUM", "SESSION_TIMEOUT", st.line, "SESSION_TIMEOUT=0 on line " + st.line + " — sessions may never expire (or the setting is a placeholder). Give sessions a finite lifetime.");
      } else if(n > 604800){
        add("MEDIUM", "SESSION_TIMEOUT", st.line, "SESSION_TIMEOUT on line " + st.line + " is " + n + " seconds — longer than seven days. Long-lived sessions widen the window if a session is stolen; shorten it unless there is a specific reason.");
      } else if(n < 0){
        add("MEDIUM", "SESSION_TIMEOUT", st.line, "SESSION_TIMEOUT on line " + st.line + " is negative. Set a positive session lifetime in seconds.");
      } else {
        add("OK", "SESSION_TIMEOUT", st.line, "SESSION_TIMEOUT on line " + st.line + " is " + n + " seconds — a finite, reasonable session lifetime.");
      }
    } else {
      add("INFO", "SESSION_TIMEOUT", null, "SESSION_TIMEOUT is not set. Session lifetime follows the Umami default — set it explicitly if sessions should expire sooner.");
    }

    /* PORT */
    var port = eff["PORT"];
    if(port){
      var pn = parseInt(port.value, 10);
      if(isNaN(pn) || pn < 1 || pn > 65535 || !/^\d+$/.test(String(port.value).trim())){
        add("MEDIUM", "PORT", port.line, "PORT on line " + port.line + " is not a valid port number (\"" + port.value + "\"). Use a number from 1 to 65535.");
      } else {
        add("OK", "PORT", port.line, "PORT on line " + port.line + " is " + pn + " — a valid port.");
      }
    } else {
      add("INFO", "PORT", null, "PORT is not set. Umami will use its default port (3000) — confirm that matches the deployment.");
    }

    /* IGNORE_IP / IGNORE_USER_AGENT posture */
    ["IGNORE_IP","IGNORE_USER_AGENT"].forEach(function(k){
      var e = eff[k];
      if(e){
        if(e.value.trim() === ""){
          add("INFO", k, e.line, k + " is present but empty on line " + e.line + " — no exclusions configured under this key.");
        } else if(SECRET_KEY_RE.test(k)){
          add("INFO", k, e.line, k + " is set on line " + e.line + " (value not shown).");
        } else {
          add("INFO", k, e.line, k + " is set on line " + e.line + " — analytics exclusions are configured under this key.");
        }
      } else {
        add("INFO", k, null, k + " is not set. No exclusions are configured under this key; all matching traffic is counted.");
      }
    });

    var blockers = findings.filter(function(f){ return f.severity === "BLOCKER"; }).length;
    var highs = findings.filter(function(f){ return f.severity === "HIGH"; }).length;
    var mediums = findings.filter(function(f){ return f.severity === "MEDIUM"; }).length;

    var verdict;
    if(recognized < 2 || parsed.entries.length === 0){
      verdict = "NOT ENOUGH TO GRADE";
    } else if(blockers > 0){
      verdict = "DO NOT DEPLOY";
    } else if(highs > 0 || mediums > 0){
      verdict = "DEPLOY WITH FIXES";
    } else {
      verdict = "SAFE TO DEPLOY";
    }

    var effective = order.map(function(k){
      var e = eff[k], item = {key:k, line:e.line};
      if(k === "DATABASE_URL"){
        var info = parseDbUrl(e.value);
        item.value = "[redacted — database URL; password reported by length only]";
        item.scheme = info.scheme; item.host = info.host;
        item.passwordPresent = info.hasPassword; item.passwordLength = info.passwordLength;
      } else if(SECRET_KEY_RE.test(k)){
        item.value = "[redacted — secret; length only]";
        item.valueLength = e.value.length;
      } else {
        item.value = e.value;
      }
      item.occurrences = byKey[k].map(function(x){ return x.line; });
      return item;
    });

    return {
      verdict: verdict,
      findings: findings,
      counts: {
        totalLines: parsed.totalLines,
        activeKeys: parsed.entries.length,
        recognizedUmamiKeys: recognized,
        commentedLines: parsed.commented.length,
        notParsedLines: parsed.notParsed.length,
        duplicateKeys: order.filter(function(k){ return byKey[k].length > 1; }).length,
        blockers: blockers, high: highs, medium: mediums,
        info: findings.filter(function(f){ return f.severity === "INFO"; }).length,
        ok: findings.filter(function(f){ return f.severity === "OK"; }).length
      },
      effectiveConfig: effective,
      commented: parsed.commented,
      notParsed: parsed.notParsed
    };
  }

  function buildReport(r){
    var out = [];
    out.push("J-Dawgs Umami Server Config Safety Auditor\u2122 — Text Report");
    out.push("Verdict: " + r.verdict);
    out.push("Counts: " + r.counts.activeKeys + " active key(s), " + r.counts.recognizedUmamiKeys +
      " recognized Umami key(s), " + r.counts.blockers + " blocker(s), " + r.counts.high +
      " high, " + r.counts.medium + " medium, " + r.counts.commentedLines + " commented line(s), " +
      r.counts.notParsedLines + " line(s) not parsed.");
    out.push("Secrets: secret values are never included in this report. Passwords are reported by key name, line number, and length only.");
    out.push("");
    out.push("Findings:");
    if(!r.findings.length) out.push("  (none)");
    r.findings.forEach(function(f){
      var where = f.line ? ("Line " + f.line) : "Config-wide";
      out.push("  [" + f.severity + "] " + where + (f.key ? (" · " + f.key) : "") + " — " + f.message);
    });
    out.push("");
    out.push("Scope: text audit only. This tool did not connect to any server and did not verify the database.");
    return out.join("\n");
  }
  function buildJson(r){
    return JSON.stringify({
      tool: "J-Dawgs Umami Server Config Safety Auditor\u2122",
      verdict: r.verdict,
      counts: r.counts,
      effectiveConfig: r.effectiveConfig,
      findings: r.findings,
      commentedLines: r.commented,
      notParsedLines: r.notParsed,
      secretsPolicy: "Secret values are never included. Passwords are reported by key name, line number, and length only."
    }, null, 2);
  }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-umami-server-config-safety-auditortm',
  name: 'J-Dawgs Umami Server Config Safety Auditor',
  description: 'Grades a pasted Umami analytics server config fully offline into one deploy verdict — SAFE TO DEPLOY / DEPLOY WITH FIXES / DO NOT DEPLOY / NOT ENOUGH TO GRADE — the DATABASE_URL password, DISABLE_LOGIN, bind addresses, CORS origins, and telemetry, with secrets shown by key name, line, and length onl',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
