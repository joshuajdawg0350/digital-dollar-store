'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs QR Payload Safety & Contents Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the analyze function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- constants ---------- */
      // Built-in URL-shortener host list (current as of November 2026).
      // A shortener's real destination cannot be known offline.
      var SHORTENERS = ["bit.ly", "t.co", "tinyurl.com", "rb.gy", "shorturl.at"];
      var SHORTENER_NOTE = "Host is on the built-in shortener list (November 2026): destination hidden — a shortener's real target cannot be known offline.";

      var EXAMPLE = [
        "https://muse.ai/s/ai-tool-store-xng6xkxwjkxl2xab/UoF72OkKI7j33Q2ITxmrZyIr4nv40QtYfj2AgESh_k8",
        "",
        "WIFI:T:WPA;S:ShopGuest;P:CorrectHorse42!;H:false;;",
        "",
        "otpauth://totp/JDawgs:joshua@example.com?secret=JBSWY3DPEHPK3PXPJBSWY3DPEHPK3PXP&issuer=JDawgs&digits=6&period=30",
        "",
        "http://bit.ly/3xAbC9d"
      ].join("\n");

      var CLEAN_EXAMPLE = [
        "https://joshuajdawg0350.github.io/jdawgs-hub/",
        "",
        "tel:+1-417-555-0134",
        "",
        "BEGIN:VCARD",
        "VERSION:3.0",
        "FN:J-Dawgs Trading Post",
        "ORG:J-Dawgs Trading Post",
        "TEL;TYPE=WORK:+1-417-555-0134",
        "EMAIL:shop@example.com",
        "END:VCARD"
      ].join("\n");

      /* ---------- helpers ---------- */
      function el(tag, cls, text) {
        var n = document.createElement(tag);
        if (cls) n.className = cls;
        if (text !== undefined) n.textContent = text;
        return n;
      }
      // Mask for a Wi-Fi password: first character + length only. Full value never rendered.
      function maskFirstLen(v) {
        if (!v) return "(empty)";
        return v.charAt(0) + "•••••• (" + v.length + " characters — full value never shown)";
      }
      // Mask for a TOTP secret: length only.
      function maskLenOnly(v) {
        return "(" + v.length + " characters — value never shown)";
      }
      function truncateAddr(v) {
        if (v.length <= 12) return v;
        return v.slice(0, 6) + "…" + v.slice(-4);
      }
      function finding(sev, text) { return { sev: sev, text: text }; }

      // Find secret-looking material in free text: long base64-ish tokens and
      // "password"-style labels. Returns {findings, safe} with values masked.
      function scanFreeText(text, secrets) {
        var findings = [];
        var safe = text;
        var labelRe = /(password|passwd|pwd|passcode|secret|api[\s_-]?key|access[\s_-]?token)(\s*[:=]\s*)(\S+)/gi;
        var m;
        var replaced = text;
        while ((m = labelRe.exec(text)) !== null) {
          if (m[3].length >= 3) secrets.push(m[3]);
          findings.push(finding("warning",
            "Secret-looking label \"" + m[1] + "\" with a value attached — value masked (" + m[3].length + " characters). Treat as a live secret."));
          replaced = replaced.split(m[0]).join(m[1] + m[2] + "***");
        }
        safe = replaced;
        var tokenRe = /[A-Za-z0-9+/=_-]{20,}/g;
        while ((m = tokenRe.exec(safe)) !== null) {
          var tok = m[0];
          if (/[0-9]/.test(tok) && /[A-Za-z]/.test(tok)) {
            secrets.push(tok);
            findings.push(finding("warning",
              "Long token that looks like a secret or key (masked: " + tok.slice(0, 4) + "••••, " + tok.length + " characters). If it's a credential, don't share this payload."));
            safe = safe.split(tok).join(tok.slice(0, 4) + "••••(" + tok.length + " chars)");
          }
        }
        return { findings: findings, safe: safe };
      }

      /* ---------- URL checks (shared by URL, sms body, vCard NOTE/URL) ---------- */
      function checkURL(raw, secrets) {
        var findings = [];
        var fields = [];
        var safe = raw;
        var url = null;
        var candidate = /^www\./i.test(raw) ? "https://" + raw : raw;
        try { url = new URL(candidate); } catch (e) { url = null; }

        if (/^(data|javascript):/i.test(raw)) {
          findings.push(finding("blocker",
            "Dangerous scheme (" + raw.split(":")[0].toLowerCase() + ":) — this payload carries executable or embedded content, not a link. Never share or scan it outside a sandbox."));
          return { findings: findings, fields: [["Scheme", raw.split(":")[0].toLowerCase() + ":"]], safe: raw.split(":")[0].toLowerCase() + ":*** (content withheld)", parsed: null };
        }
        if (!url) {
          findings.push(finding("warning", "Looks like a URL but could not be parsed — destination unknowable from this text."));
          return { findings: findings, fields: fields, safe: safe, parsed: null };
        }

        fields.push(["Scheme", url.protocol.replace(":", "")]);
        fields.push(["Host", url.hostname || "(none)"]);
        if (url.pathname && url.pathname !== "/") fields.push(["Path", url.pathname]);
        if (url.search) fields.push(["Query", url.search]);

        if (url.protocol === "http:") {
          findings.push(finding("warning", "Plain http, not https — traffic to this link is unencrypted and can be read or altered in transit."));
        }
        if (url.username || url.password) {
          if (url.password) secrets.push(decodeURIComponent(url.password));
          findings.push(finding("blocker",
            "Credentials embedded in the URL (user \"" + (url.username || "(none)") + "\"" + (url.password ? ", password present — never shown here" : "") + "). Anyone holding this link holds the login."));
          try {
            var su = new URL(candidate);
            if (su.password) su.password = "***";
            safe = su.toString();
          } catch (e) { safe = raw.replace(/:[^:@/]+@/, ":***@"); }
        }
        var host = (url.hostname || "").toLowerCase();
        if (SHORTENERS.indexOf(host) !== -1) {
          findings.push(finding("warning", SHORTENER_NOTE));
        }
        if (host.indexOf("xn--") !== -1) {
          findings.push(finding("warning", "Punycode host (xn--) — internationalized names can imitate a familiar brand. Possible lookalike; verify the real destination another way."));
        }
        var bareHost = host.replace(/^\[|\]$/g, "");
        if (/^\d{1,3}(\.\d{1,3}){3}$/.test(bareHost) || bareHost.indexOf(":") !== -1) {
          findings.push(finding("warning", "Host is a raw IP address, not a name — there is no domain reputation to lean on, and IP-hosted links are a common throwaway-scam pattern."));
        }
        return { findings: findings, fields: fields, safe: safe, parsed: url };
      }

      function looksLikePaymentURL(url) {
        if (!url) return false;
        var s = (url.pathname + url.search).toLowerCase();
        return /(^|[\/\-_?=&])(pay|payment|payments|checkout|donate|donation|purchase|billing)([\/\-_?=&]|$)/.test(s);
      }

      /* ---------- per-type analyzers ---------- */
      function analyze(raw, secrets) {
        var p = raw.trim();
        var lower = p.toLowerCase();

        /* otpauth:// — authenticator seed */
        if (lower.indexOf("otpauth://") === 0) {
          var f = [], finds = [];
          var rest = p.slice("otpauth://".length);
          var kind = rest.split("/")[0] || "totp";
          var q = {};
          var qi = p.indexOf("?");
          if (qi !== -1) {
            p.slice(qi + 1).split("&").forEach(function (pair) {
              var kv = pair.split("=");
              q[decodeURIComponent(kv[0] || "")] = decodeURIComponent(kv.slice(1).join("=") || "");
            });
          }
          var label = "";
          var afterKind = rest.slice(kind.length + 1);
          label = decodeURIComponent(afterKind.split("?")[0] || "");
          f.push(["Kind", kind.toUpperCase() + " authenticator seed"]);
          if (label) f.push(["Label", label]);
          if (q.issuer) f.push(["Issuer", q.issuer]);
          if (q.secret) {
            secrets.push(q.secret);
            f.push(["Secret", maskLenOnly(q.secret)]);
          }
          if (q.digits) f.push(["Digits", q.digits]);
          if (q.period) f.push(["Period", q.period + "s"]);
          if (q.algorithm) f.push(["Algorithm", q.algorithm]);
          finds.push(finding("blocker",
            "Authenticator seed (TOTP secret) — this is a live credential: anyone who scans this code gets the same rotating codes as the owner. The secret is never shown here; the safe version replaces it with ***. Do not share this payload, ever."));
          var safe = p.replace(/([?&]secret=)[^&]*/i, "$1***");
          return { type: "Authenticator seed (otpauth://)", fields: f, findings: finds, safe: safe };
        }

        /* WIFI: */
        if (/^WIFI:/i.test(p)) {
          var f2 = [], finds2 = [];
          var body = p.slice(5);
          var parts = [];
          var cur = "", i, c;
          for (i = 0; i < body.length; i++) {
            c = body.charAt(i);
            if (c === "\\" && i + 1 < body.length) { cur += body.charAt(i + 1); i++; }
            else if (c === ";") { parts.push(cur); cur = ""; }
            else cur += c;
          }
          if (cur) parts.push(cur);
          var kv = {};
          parts.forEach(function (part) {
            var ci = part.indexOf(":");
            if (ci > 0) kv[part.slice(0, ci).toUpperCase()] = part.slice(ci + 1);
          });
          var secType = kv.T;
          if (kv.S !== undefined) f2.push(["Network name (SSID)", kv.S]);
          f2.push(["Security type", secType ? secType : "(not specified)"]);
          if (kv.P !== undefined && kv.P !== "") {
            secrets.push(kv.P);
            f2.push(["Password", maskFirstLen(kv.P)]);
          }
          if (kv.H !== undefined) f2.push(["Hidden network", kv.H]);
          if (kv.P) {
            finds2.push(finding("blocker",
              "Wi-Fi password inside — a live network credential. It is masked everywhere in this audit (first character + length only); sharing the original payload hands out the network key."));
          }
          if (!secType || secType.toLowerCase() === "nopass") {
            finds2.push(finding("warning", "Open network (no password / T:nopass or missing security type) — anyone in range can join, and traffic can be sniffed."));
          } else if (secType.toUpperCase() === "WEP") {
            finds2.push(finding("warning", "WEP encryption — long broken and crackable in minutes. Treat this network as effectively open."));
          }
          if (kv.H && kv.H.toLowerCase() === "true") {
            finds2.push(finding("info", "Hidden SSID — the network does not broadcast its name; devices must already know it to join."));
          }
          var safeWifi = p;
          if (kv.P) safeWifi = p.replace(/(P:)((?:\\.|[^;\\])*)/i, "$1***");
          return { type: "Wi-Fi network (WIFI:)", fields: f2, findings: finds2, safe: safeWifi };
        }

        /* vCard */
        if (/^BEGIN:VCARD/i.test(p)) {
          var f3 = [], finds3 = [];
          var lines = p.split(/\r?\n/);
          lines.forEach(function (line) {
            var ci = line.indexOf(":");
            if (ci === -1) return;
            var keyPart = line.slice(0, ci);
            var name = keyPart.split(";")[0].toUpperCase();
            var value = line.slice(ci + 1);
            if (name === "BEGIN" || name === "END") return;
            var shown = value;
            var scan = scanFreeText(value, secrets);
            if (scan.findings.length) shown = scan.safe;
            f3.push([name, shown]);
            if (name === "URL" || name === "NOTE") {
              var urls = value.match(/https?:\/\/[^\s<>"']+/g) || [];
              urls.forEach(function (u) {
                var r = checkURL(u, secrets);
                r.findings.forEach(function (fd) {
                  finds3.push(finding(fd.sev, "In " + name + " field — " + fd.text));
                });
              });
              scan.findings.forEach(function (fd) {
                finds3.push(finding(fd.sev, "In " + name + " field — " + fd.text));
              });
            }
          });
          if (!finds3.length) finds3.push(finding("ok", "Contact card with no risky fields found — fields listed by name above."));
          var safeCard = scanFreeText(p, []).safe;
          return { type: "Contact card (vCard)", fields: f3, findings: finds3, safe: safeCard };
        }

        /* dangerous schemes */
        if (/^(data|javascript):/i.test(p)) {
          var rd = checkURL(p, secrets);
          return { type: "Dangerous scheme payload", fields: rd.fields, findings: rd.findings, safe: rd.safe };
        }

        /* crypto payment URIs */
        var payMatch = p.match(/^(bitcoin|ethereum):/i);
        if (payMatch) {
          var scheme = payMatch[1].toLowerCase();
          var f4 = [], finds4 = [];
          var after = p.slice(scheme.length + 1);
          var addr = after.split("?")[0];
          var params = {};
          var qi2 = after.indexOf("?");
          if (qi2 !== -1) {
            after.slice(qi2 + 1).split("&").forEach(function (pair) {
              var kv2 = pair.split("=");
              params[decodeURIComponent(kv2[0] || "")] = decodeURIComponent(kv2.slice(1).join("=") || "");
            });
          }
          f4.push(["Scheme", scheme + ":"]);
          f4.push(["Address (truncated)", truncateAddr(addr)]);
          if (params.amount !== undefined) f4.push(["Amount (exactly as decoded)", params.amount]);
          if (params.label) f4.push(["Label", params.label]);
          if (params.message) f4.push(["Message", params.message]);
          finds4.push(finding("warning",
            "Payment code — QR payment codes are a known swap-scam surface (a sticker or swapped code redirects the money). The address is shown truncated (first 6 + last 4) on purpose: verify the full address out-of-band with the payee before sending anything."));
          var safePay = scheme + ":" + truncateAddr(addr) + (qi2 !== -1 ? after.slice(qi2) : "");
          return { type: "Payment (" + scheme + ":)", fields: f4, findings: finds4, safe: safePay };
        }

        /* tel: */
        if (/^tel:/i.test(p)) {
          var num = p.slice(4);
          return {
            type: "Phone number (tel:)",
            fields: [["Number", num]],
            findings: [finding("info", "Phone number shown as decoded. Whether a number is premium-rate or toll-free cannot be verified offline, so this tool makes no claim either way.")],
            safe: p
          };
        }

        /* sms: / SMSTO: */
        if (/^(sms|smsto):/i.test(p)) {
          var f5 = [], finds5 = [];
          var num2 = "", bodyText = "";
          if (/^SMSTO:/i.test(p)) {
            var restSms = p.slice(6);
            var ci2 = restSms.indexOf(":");
            if (ci2 === -1) num2 = restSms; else { num2 = restSms.slice(0, ci2); bodyText = restSms.slice(ci2 + 1); }
          } else {
            var rest2 = p.slice(4);
            var qi3 = rest2.indexOf("?");
            if (qi3 === -1) num2 = rest2;
            else {
              num2 = rest2.slice(0, qi3).replace(/&$/, "");
              var qs = rest2.slice(qi3 + 1);
              qs.split("&").forEach(function (pair) {
                var kv3 = pair.split("=");
                if (decodeURIComponent(kv3[0] || "").toLowerCase() === "body") bodyText = decodeURIComponent(kv3.slice(1).join("=") || "");
              });
            }
          }
          f5.push(["Number", num2]);
          if (bodyText) f5.push(["Prefilled message", bodyText]);
          finds5.push(finding("info", "Phone number shown as decoded. Whether a number is premium-rate cannot be verified offline, so this tool makes no claim either way."));
          if (bodyText) {
            var bodyUrls = bodyText.match(/https?:\/\/[^\s<>"']+/g) || [];
            bodyUrls.forEach(function (u) {
              var r2 = checkURL(u, secrets);
              r2.findings.forEach(function (fd) {
                finds5.push(finding(fd.sev, "Link inside the prefilled message — " + fd.text));
              });
            });
            if (bodyUrls.length) finds5.push(finding("info", "The prefilled message contains a link, checked above with the standard URL checks."));
          }
          return { type: "Text message (sms:)", fields: f5, findings: finds5, safe: p };
        }

        /* mailto: */
        if (/^mailto:/i.test(p)) {
          var f6 = [["Address", ""]];
          var addrM = p.slice(7).split("?")[0];
          f6[0][1] = decodeURIComponent(addrM);
          var qi4 = p.indexOf("?");
          if (qi4 !== -1) {
            p.slice(qi4 + 1).split("&").forEach(function (pair) {
              var kv4 = pair.split("=");
              var k4 = decodeURIComponent(kv4[0] || "");
              var v4 = decodeURIComponent(kv4.slice(1).join("=") || "");
              if (k4) f6.push([k4.charAt(0).toUpperCase() + k4.slice(1), v4]);
            });
          }
          return {
            type: "Email (mailto:)",
            fields: f6,
            findings: [finding("info", "Email payload decoded above. This tool cannot verify the address belongs to who it claims to be — structure and contents only.")],
            safe: p
          };
        }

        /* geo: */
        if (/^geo:/i.test(p)) {
          var geoBody = p.slice(4);
          var coords = geoBody.split(/[;?]/)[0].split(",");
          var f7 = [];
          if (coords[0]) f7.push(["Latitude", coords[0]]);
          if (coords[1]) f7.push(["Longitude", coords[1]]);
          if (coords[2]) f7.push(["Altitude", coords[2]]);
          var uM = geoBody.match(/[;?]u=([^;?&]+)/i);
          if (uM) f7.push(["Uncertainty (m)", uM[1]]);
          var qM = geoBody.match(/[?&]q=([^&]+)/i);
          if (qM) f7.push(["Label", decodeURIComponent(qM[1])]);
          return {
            type: "Location (geo:)",
            fields: f7,
            findings: [finding("info", "Coordinates decoded above. Sharing a geo payload shares that exact location — make sure it's a place meant to be public.")],
            safe: p
          };
        }

        /* URL (incl. payment-style URLs) */
        if (/^https?:\/\//i.test(p) || /^www\./i.test(p)) {
          var ru = checkURL(p, secrets);
          if (ru.parsed && looksLikePaymentURL(ru.parsed)) {
            var f8 = ru.fields.slice();
            var amtKeys = ["amount", "amt", "price", "total"];
            if (ru.parsed) {
              ru.parsed.searchParams.forEach(function (v, k) {
                if (amtKeys.indexOf(k.toLowerCase()) !== -1) f8.push(["Amount parameter \"" + k + "\" (exactly as decoded)", v]);
              });
            }
            ru.findings.push(finding("warning",
              "Payment/checkout link — QR payment codes are a known swap-scam surface. Shown truncated on purpose: verify the full destination out-of-band before paying."));
            var safePayUrl = truncateAddr(p);
            return { type: "Payment link (URL)", fields: f8, findings: ru.findings, safe: safePayUrl };
          }
          if (!ru.findings.length) ru.findings.push(finding("ok", "Clean https URL — no embedded credentials, no shortener, no lookalike tricks visible in the text."));
          return { type: "Web link (URL)", fields: ru.fields, findings: ru.findings, safe: ru.safe };
        }

        /* plain text fallback */
        var scanP = scanFreeText(p, secrets);
        var f9 = [["Text", scanP.safe.length > 120 ? scanP.safe.slice(0, 120) + "…" : scanP.safe]];
        var finds9 = scanP.findings.slice();
        var textUrls = p.match(/https?:\/\/[^\s<>"']+/g) || [];
        textUrls.forEach(function (u) {
          var r3 = checkURL(u, secrets);
          r3.findings.forEach(function (fd) {
            finds9.push(finding(fd.sev, "Link inside the text — " + fd.text));
          });
        });
        if (!finds9.length) finds9.push(finding("ok", "Plain text — no secret-looking patterns and no risky links found."));
        return { type: "Plain text", fields: f9, findings: finds9, safe: scanP.safe };
      }

      function gradeOf(findings) {
        var g = "ok";
        findings.forEach(function (f) {
          if (f.sev === "blocker") g = "block";
          else if (f.sev === "warning" && g === "ok") g = "warn";
        });
        return g;
      }
      var GRADE_LABEL = { ok: "SAFE TO SHARE", warn: "SHARE WITH CARE", block: "DO NOT SHARE" };
  return { "analyze": (typeof analyze !== 'undefined' ? analyze : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE": (typeof EXAMPLE !== 'undefined' ? EXAMPLE : undefined), "CLEAN_EXAMPLE": (typeof CLEAN_EXAMPLE !== 'undefined' ? CLEAN_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["analyze"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-qr-payload-safety-auditor',
  name: 'J-Dawgs QR Payload Safety & Contents Auditor',
  description: 'QR generators make codes and stop; ours audits the payload text before anyone scans or shares it — WIFI passwords and otpauth TOTP seeds masked or blocked, shortener/http/embedded-credential risks named — and returns one share verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["analyze"]) return { ok: false, output: null, summary: 'Extracted core has no analyze function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE": __core["EXAMPLE"], "CLEAN_EXAMPLE": __core["CLEAN_EXAMPLE"] }
};
