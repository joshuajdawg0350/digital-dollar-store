'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Logstash Pipeline Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

'use strict';

/* ---------- Worked examples (line numbers are load-bearing) ---------- */

var RISKY_LINES = [
  '# Risky pipeline — pasted from a staging host. Do not ship.',
  'input {',
  '  http {',
  '    host => "0.0.0.0"',
  '    port => 8080',
  '  }',
  '  beats {',
  '    host => "0.0.0.0"',
  '    port => 5044',
  '    ssl => false',
  '  }',
  '}',
  'filter {',
  '  mutate {',
  '    add_field => { "env" => "prod" }',
  '  }',
  '}',
  'output {',
  '  elasticsearch {',
  '    hosts => ["http://es-plaintext.internal:9200"]',
  '    user => "elastic"',
  '    password => "hunter2-r1sky!"',
  '  }',
  '  http {',
  '    http_method => "post"',
  '    url => "http://hooks.legacy.internal:9000/events"',
  '  }',
  '}'
];

var HARDENED_LINES = [
  '# Hardened pipeline — keystore credentials, TLS on, certificates verified.',
  'input {',
  '  http {',
  '    host => "127.0.0.1"',
  '    port => 8080',
  '    user => "ingest"',
  '    password => "${HTTP_INPUT_PWD}"',
  '    ssl => true',
  '    ssl_certificate => "/etc/logstash/certs/http-input.crt"',
  '    ssl_key => "/etc/logstash/certs/http-input.key"',
  '  }',
  '}',
  'filter {',
  '  mutate {',
  '    remove_field => ["[event][original]"]',
  '  }',
  '}',
  'output {',
  '  elasticsearch {',
  '    hosts => ["https://es-node-1.internal:9200", "https://es-node-2.internal:9200"]',
  '    user => "logstash_writer"',
  '    password => "${ES_PWD}"',
  '    cacert => "/etc/logstash/certs/ca.crt"',
  '    ssl_certificate_verification => true',
  '    index => "app-logs-%{+YYYY.MM.dd}"',
  '  }',
  '}'
];

/* ---------- Parser ---------- */

var SECTIONS = { input: 1, filter: 1, output: 1 };

function stripComment(line) {
  var out = '', inS = false, inD = false;
  for (var i = 0; i < line.length; i++) {
    var c = line[i];
    if (inD) {
      out += c;
      if (c === '\\' && i + 1 < line.length) { out += line[i + 1]; i++; }
      else if (c === '"') { inD = false; }
      continue;
    }
    if (inS) { out += c; if (c === "'") { inS = false; } continue; }
    if (c === '"') { inD = true; out += c; continue; }
    if (c === "'") { inS = true; out += c; continue; }
    if (c === '#') { break; }
    out += c;
  }
  return out;
}

function parseConfig(text) {
  var rawLines = text.split(/\r?\n/);
  var plugins = [], settings = [], notParsed = [];
  var stack = [{ kind: 'root', name: '(root)', line: 0 }];

  function currentPlugin() {
    for (var i = stack.length - 1; i >= 0; i--) {
      if (stack[i].kind === 'plugin') { return stack[i].node; }
    }
    return null;
  }
  function currentSection() {
    for (var i = stack.length - 1; i >= 0; i--) {
      if (stack[i].kind === 'section') { return stack[i].name; }
    }
    return null;
  }

  for (var idx = 0; idx < rawLines.length; idx++) {
    var lineNo = idx + 1;
    var t = stripComment(rawLines[idx]).trim();
    if (!t) { continue; }

    if (t === '}') {
      if (stack.length > 1) { stack.pop(); }
      else { notParsed.push({ line: lineNo, reason: 'Closing brace with no open block — line excluded.' }); }
      continue;
    }
    var elseM = t.match(/^}\s*(else|if)\b[^{]*\{$/);
    if (elseM) {
      if (stack.length > 1) { stack.pop(); }
      stack.push({ kind: 'conditional', name: elseM[1], line: lineNo });
      continue;
    }
    var setM = t.match(/^"?([A-Za-z0-9_.\-]+)"?\s*=>\s*(.+)$/);
    if (setM) {
      if (setM[2].trim() === '{') {
        stack.push({ kind: 'hash', name: setM[1], line: lineNo });
        continue;
      }
      var plugin = currentPlugin();
      var s = { key: setM[1], value: setM[2].trim(), line: lineNo, plugin: plugin, section: currentSection() };
      settings.push(s);
      if (plugin) { plugin.settings.push(s); }
      continue;
    }
    if (/\{$/.test(t)) {
      var nameM = t.match(/^([A-Za-z0-9_]+)/);
      var nm = nameM ? nameM[1].toLowerCase() : 'block';
      if (SECTIONS[nm] && stack.length === 1) {
        stack.push({ kind: 'section', name: nm, line: lineNo });
        continue;
      }
      if (nm === 'if' || nm === 'else') {
        stack.push({ kind: 'conditional', name: nm, line: lineNo });
        continue;
      }
      var node = { name: nm, line: lineNo, section: currentSection(), settings: [] };
      plugins.push(node);
      stack.push({ kind: 'plugin', name: nm, line: lineNo, node: node });
      continue;
    }
    notParsed.push({ line: lineNo, reason: 'Line does not match Logstash config syntax (a setting, a block, or a brace) — excluded, not guessed.' });
  }

  for (var j = 1; j < stack.length; j++) {
    notParsed.push({ line: stack[j].line, reason: 'Block "' + stack[j].name + '" opened here is never closed — unbalanced braces.' });
  }
  notParsed.sort(function (a, b) { return a.line - b.line; });

  return { plugins: plugins, settings: settings, notParsed: notParsed, lineCount: rawLines.length };
}

/* ---------- Value helpers ---------- */

function unquote(v) {
  v = String(v).trim();
  if (v.length >= 2 && v[0] === '"' && v[v.length - 1] === '"') { return v.slice(1, -1); }
  if (v.length >= 2 && v[0] === "'" && v[v.length - 1] === "'") { return v.slice(1, -1); }
  return v;
}
function isFalseVal(v) { return /^(false|no|off)$/i.test(unquote(v).trim()); }
function isLocalHost(h) {
  h = unquote(h).trim().toLowerCase();
  return h === 'localhost' || h === '::1' || h === '[::1]' || h.indexOf('127.') === 0;
}

/* ---------- Audit ---------- */

var NETWORK_INPUTS = { http: 1, tcp: 1, udp: 1, beats: 1, syslog: 1, gelf: 1, kafka: 1, redis: 1, websocket: 1, snmp: 1 };
var TLS_INPUTS = { http: 1, tcp: 1, beats: 1, syslog: 1, gelf: 1 };
var SECRET_KEY_RE = /(password|passwd|api[-_]?key|client[-_]?secret|access[-_]?token|auth[-_]?token|secret[-_]?key)/i;
var SEV_RANK = { CRITICAL: 0, HIGH: 1, MEDIUM: 2, INFO: 3 };

function auditConfig(text) {
  var findings = [];
  function add(sev, line, title, detail) {
    findings.push({ severity: sev, line: line, title: title, detail: detail });
  }

  if (!text || !text.trim()) {
    return {
      verdict: 'NOT ENOUGH TO GRADE', empty: true,
      counts: { CRITICAL: 0, HIGH: 0, MEDIUM: 0, INFO: 0 },
      findings: [], notParsed: [], pluginCount: 0, lineCount: 0
    };
  }

  var parsed = parseConfig(text);
  var plugins = parsed.plugins, settings = parsed.settings, notParsed = parsed.notParsed;

  /* Raw-line scans: settings that live outside pipeline plugin blocks
     (logstash.yml-style lines, when pasted alongside the pipeline). */
  var rawLines = text.split(/\r?\n/);
  for (var i = 0; i < rawLines.length; i++) {
    var rt = rawLines[i].trim();
    if (!rt || rt.charAt(0) === '#') { continue; }
    var ln = i + 1, m;
    if ((m = rt.match(/api\.http\.host\s*[:=]\s*>?\s*"?([^\s",}]+)/i))) {
      if (!isLocalHost(m[1])) {
        add('HIGH', ln, 'Logstash API / monitoring HTTP bound beyond localhost',
          'api.http.host is set to ' + m[1] + ' — the Logstash API (pipeline stats, health, and reload endpoints) answers on that interface. Bind it to 127.0.0.1 or put it behind authentication and a firewall.');
      } else {
        add('INFO', ln, 'Logstash API host setting present', 'api.http.host is set to a localhost address — the API stays on this host.');
      }
    } else if ((m = rt.match(/(?:^|[^\w.])http\.host\s*[:=]\s*>?\s*"?([^\s",}]+)/))) {
      if (!isLocalHost(m[1])) {
        add('HIGH', ln, 'Monitoring HTTP interface bound beyond localhost',
          'http.host is set to ' + m[1] + ' — the monitoring HTTP interface answers on that interface. Bind it to 127.0.0.1 or restrict it at the firewall.');
      } else {
        add('INFO', ln, 'Monitoring HTTP host setting present', 'http.host is set to a localhost address — the monitoring interface stays on this host.');
      }
    } else if (/api\.http\.port\s*[:=]/i.test(rt)) {
      add('INFO', ln, 'Logstash API HTTP port configured',
        'An api.http.port setting is present. Confirm the API host binding keeps it off the network — the API can expose pipeline details.');
    }
    if (/xpack\.monitoring/i.test(rt)) {
      add('INFO', ln, 'X-Pack monitoring setting present',
        'An xpack.monitoring setting is pasted here. Monitoring ships cluster and pipeline data to its target — confirm the destination and its credentials are the intended ones.');
    }
    if ((m = rt.match(/log\.level\s*[:=]\s*>?\s*"?(debug|trace)\b/i))) {
      add('MEDIUM', ln, 'Debug-level logging can capture event payloads',
        'log.level is set to ' + m[1].toLowerCase() + '. At that level Logstash writes event contents to its logs — including any secrets carried inside the events themselves. Keep production at info or warn.');
    }
  }

  /* Plugin-level checks. */
  plugins.forEach(function (p) {
    function get(key) {
      for (var k = 0; k < p.settings.length; k++) {
        if (p.settings[k].key.toLowerCase() === key) { return p.settings[k]; }
      }
      return null;
    }

    if (p.section === 'input' && NETWORK_INPUTS[p.name]) {
      var hostS = get('host');
      var beyond = hostS ? !isLocalHost(hostS.value) : true;
      var bindDesc = hostS
        ? 'binds to ' + unquote(hostS.value) + ' (line ' + hostS.line + ')'
        : 'has no host setting, so the plugin binds all interfaces by default';
      var sslS = get('ssl') || get('ssl_enabled');

      if (sslS && isFalseVal(sslS.value)) {
        if (beyond) {
          add('CRITICAL', sslS.line, 'TLS disabled on ' + p.name + ' input exposed beyond localhost',
            'ssl => false on the ' + p.name + ' input while it ' + bindDesc + '. Events cross the network in plaintext, and anyone who can reach the port can read them or inject their own.');
        } else {
          add('HIGH', sslS.line, 'TLS disabled on ' + p.name + ' input',
            'ssl => false — events arrive in plaintext. The localhost bind limits exposure, but any local process, tunnel, or port forward can still read them.');
        }
      } else if (!sslS && TLS_INPUTS[p.name]) {
        add('MEDIUM', p.line, 'No TLS configured on ' + p.name + ' input',
          'This network input carries no ssl setting. Unless TLS is terminated in front of it, events cross the network in plaintext.');
      }

      if (p.name === 'http') {
        var hasUser = !!get('user'), hasPass = !!get('password');
        if (!hasUser || !hasPass) {
          if (beyond) {
            add('CRITICAL', p.line, 'Unauthenticated http input accepts events from any host',
              'The http input has ' + (hasUser || hasPass ? 'only one of user/password set, so no working authentication' : 'no user/password authentication') + ' and ' + bindDesc + '. Anyone who can reach the port can push forged events straight into this pipeline.');
          } else {
            add('MEDIUM', p.line, 'http input has no authentication',
              'It is bound to localhost only, which limits exposure — but any local process can still push events. Add user/password authentication or keep the bind local and firewalled.');
          }
        }
      }
    }

    if (p.section === 'output') {
      p.settings.forEach(function (s) {
        if (/http:\/\//.test(s.value)) {
          add('HIGH', s.line, 'Plaintext http:// target in ' + p.name + ' output',
            'Setting "' + s.key + '" points at an http:// URL. Events — and any credentials sent with them — cross the network unencrypted. Switch to https:// with certificate verification on.');
        }
      });
    }
  });

  /* Setting-level checks across every plugin. */
  settings.forEach(function (s) {
    var k = s.key.toLowerCase();

    if (k === 'ssl_certificate_verification' && isFalseVal(s.value)) {
      add('HIGH', s.line, 'TLS certificate verification disabled',
        'ssl_certificate_verification => false means the peer\'s certificate is never checked — TLS is on, but a man-in-the-middle can still intercept. Verify against a CA bundle (cacert) instead.');
    }
    if (k === 'ssl_verify_mode' && /^"?(none|no|off)"?$/i.test(s.value.trim())) {
      add('HIGH', s.line, 'TLS certificate verification disabled',
        'ssl_verify_mode is set to "' + unquote(s.value) + '" — the peer\'s certificate is never checked, so a man-in-the-middle can intercept the TLS stream. Use peer or force_peer with a CA certificate.');
    }

    if (SECRET_KEY_RE.test(s.key)) {
      var v = s.value.trim();
      if (v.indexOf('${') !== -1) {
        add('INFO', s.line, 'Credential "' + s.key + '" comes from a keystore / environment reference',
          'The value is a ${...} reference, not an inline secret — the correct pattern. The referenced secret itself is not in the pasted text, so this audit cannot grade its strength or storage.');
      } else {
        var lit = unquote(v);
        var isQuoted = (v.charAt(0) === '"' && v.charAt(v.length - 1) === '"') || (v.charAt(0) === "'" && v.charAt(v.length - 1) === "'");
        var isBare = /^[A-Za-z0-9_\-\.!@#%^*+=:;]+$/.test(v);
        if (lit.length > 0 && (isQuoted || isBare)) {
          add('HIGH', s.line, 'Plaintext credential in "' + s.key + '" setting',
            'An inline credential is written directly in the config (value length: ' + lit.length + ' characters — the value itself is never shown anywhere in this audit). Anyone with read access to this file holds the secret. Move it to the Logstash keystore and reference it as ${...}.');
        }
      }
    }

    if (k === 'codec' && s.section === 'output' && /rubydebug/i.test(s.value)) {
      add('INFO', s.line, 'rubydebug codec prints full events',
        'The rubydebug codec writes complete event contents wherever this output points. Fine at a console during development; a payload leak if it feeds a file or a network destination.');
    }
  });

  findings.sort(function (a, b) {
    if (SEV_RANK[a.severity] !== SEV_RANK[b.severity]) { return SEV_RANK[a.severity] - SEV_RANK[b.severity]; }
    return a.line - b.line;
  });

  var counts = { CRITICAL: 0, HIGH: 0, MEDIUM: 0, INFO: 0 };
  findings.forEach(function (f) { counts[f.severity]++; });

  var verdict;
  if (plugins.length === 0 && settings.length === 0) { verdict = 'NOT ENOUGH TO GRADE'; }
  else if (counts.CRITICAL > 0) { verdict = 'DO NOT DEPLOY'; }
  else if (counts.HIGH > 0 || counts.MEDIUM > 0 || notParsed.length > 0) { verdict = 'DEPLOY WITH FIXES'; }
  else { verdict = 'SAFE TO DEPLOY'; }

  return {
    verdict: verdict, empty: false, counts: counts, findings: findings,
    notParsed: notParsed, pluginCount: plugins.length, lineCount: parsed.lineCount
  };
}

/* ---------- Report + JSON builders (secret values are never included) ---------- */

function buildReport(r, sourceLineCount) {
  var out = [];
  out.push('J-DAWGS LOGSTASH PIPELINE CONFIG SAFETY AUDITOR — AUDIT REPORT');
  out.push('================================================================');
  if (r.empty) {
    out.push('Verdict: NOT ENOUGH TO GRADE');
    out.push('');
    out.push('Nothing was pasted, so there is nothing to grade.');
    return out.join('\n');
  }
  out.push('Verdict: ' + r.verdict);
  out.push('Findings: ' + r.counts.CRITICAL + ' CRITICAL · ' + r.counts.HIGH + ' HIGH · ' + r.counts.MEDIUM + ' MEDIUM · ' + r.counts.INFO + ' INFO');
  out.push('Pipeline text: ' + sourceLineCount + ' lines · ' + r.pluginCount + ' plugin blocks parsed · ' + r.notParsed.length + ' not-parsed lines');
  out.push('');
  out.push('FINDINGS');
  if (r.findings.length === 0) {
    out.push('  (none)');
  }
  r.findings.forEach(function (f) {
    out.push('[' + f.severity + '] Line ' + f.line + ' — ' + f.title);
    out.push('    ' + f.detail);
  });
  out.push('');
  out.push('NOT PARSED (excluded from grading, never guessed)');
  if (r.notParsed.length === 0) {
    out.push('  (none)');
  }
  r.notParsed.forEach(function (n) {
    out.push('  Line ' + n.line + ': ' + n.reason);
  });
  out.push('');
  out.push('Scope: heuristic text audit of the pasted pipeline text only. It never connects');
  out.push('to Logstash or Elasticsearch, sends no events, and cannot verify what a running');
  out.push('pipeline actually does. Secret values are never printed — findings name the');
  out.push('setting and line only.');
  return out.join('\n');
}

function buildJson(r, sourceLineCount) {
  var obj = {
    tool: 'J-Dawgs Logstash Pipeline Config Safety Auditor™',
    verdict: r.verdict,
    counts: r.counts,
    linesAudited: r.empty ? 0 : sourceLineCount,
    pluginsParsed: r.pluginCount,
    findings: r.findings.map(function (f) {
      return { severity: f.severity, line: f.line, title: f.title, detail: f.detail };
    }),
    notParsed: r.notParsed.map(function (n) { return { line: n.line, reason: n.reason }; }),
    scope: 'Heuristic text audit of pasted pipeline text only. Never connects to Logstash or Elasticsearch, sends no events, and cannot verify what a running pipeline actually does. Secret values are never included — findings name the setting and line only.'
  };
  return JSON.stringify(obj, null, 2);
}
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-logstash-pipeline-config-safety-auditortm',
  name: 'J-Dawgs Logstash Pipeline Config Safety Auditor',
  description: 'Grades a pasted Logstash pipeline offline — unauthenticated inputs, output TLS, plaintext credentials by setting name + line only — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
