'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Drywall Proposal, Work Record & Final Invoice Consistency Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";
var $ = function(id){ return document.getElementById(id); };
var TOL = 1.00;      // money tolerance in dollars
var MAJOR = 25.00;   // money gap above this is a major failure

var BAD = {
proposal:
"DRYWALL PROPOSAL - 456 Pine St\n" +
"Sheets: 50 sheets of 4x8 drywall\n" +
"Wall and ceiling area: 1600 sq ft\n" +
"Finish level: Level 4\n" +
"Labor rate: $65/hr\n" +
"Deposit: $800.00 required upfront\n" +
"Materials quoted: joint compound and tape included in labor",
work:
"WORK RECORD - 456 Pine St\n" +
"Sheets hung: 46 sheets\n" +
"Sheet size: 4x8\n" +
"Finish level completed: Level 3\n" +
"Labor hours worked: 38 hours",
invoice:
"FINAL INVOICE - 456 Pine St\n" +
"Sheets billed: 50 sheets\n" +
"Finish level billed: Level 4\n" +
"Labor: $2600.00\n" +
"Materials: 20 x $22.00 = $500.00\n" +
"Rush fee: $250.00\n" +
"Disposal fee: $175.00\n" +
"Total: $3650.00"
};
var GOOD = {
proposal:
"DRYWALL PROPOSAL - 123 Oak St\n" +
"Sheets: 40 sheets of 4x8 drywall (32 sq ft per sheet)\n" +
"Wall and ceiling area: 1280 sq ft\n" +
"Finish level: Level 4\n" +
"Labor: 32 hours at $60/hr = $1920.00\n" +
"Materials: 40 x $18.00 = $720.00\n" +
"Deposit: $500.00 paid upfront\n" +
"Total quoted: $2640.00",
work:
"WORK RECORD - 123 Oak St\n" +
"Sheets hung: 40 sheets\n" +
"Sheet size: 4x8\n" +
"Area covered: 1280 sq ft\n" +
"Finish level completed: Level 4\n" +
"Labor hours worked: 32 hours\n" +
"Hourly rate: $60/hr",
invoice:
"FINAL INVOICE - 123 Oak St\n" +
"Sheets billed: 40 sheets\n" +
"Finish level billed: Level 4\n" +
"Labor: 32 hours x $60.00 = $1920.00\n" +
"Materials: 40 x $18.00 = $720.00\n" +
"Deposit credit: -$500.00\n" +
"Total: $2140.00"
};

/* ---------- parsing helpers ---------- */
function lines(t){ return (t||"").split(/\r?\n/); }
function moneyVals(str){
  var out=[], m, re=/\$\s*-?\s*(\d[\d,]*(?:\.\d{1,2})?)/g;
  while((m=re.exec(str))!==null){ out.push(parseFloat(m[1].replace(/,/g,""))); }
  return out;
}
function lastMoney(str){ var v=moneyVals(str); return v.length? v[v.length-1] : null; }
function firstMoney(str){ var v=moneyVals(str); return v.length? v[0] : null; }
function fmt(n){ return "$" + Math.abs(n).toLocaleString("en-US",{minimumFractionDigits:2,maximumFractionDigits:2}); }
function num(n){ return (Math.round(n*100)/100).toLocaleString("en-US",{maximumFractionDigits:2}); }

function usable(t){ return !!t && t.trim().length>=30 && /\d/.test(t); }

function extractSheets(text){
  if(!text) return null;
  var ls=lines(text), i, m;
  for(i=0;i<ls.length;i++){
    if(!/sheet/i.test(ls[i])) continue;
    m = ls[i].match(/sheets?\s*(?:billed|hung|recorded|quoted|installed|completed)?\s*[:\-]?\s*(\d+(?:\.\d+)?)/i)
     || ls[i].match(/(\d+(?:\.\d+)?)\s*sheets?/i);
    if(m) return parseFloat(m[1]);
  }
  m = text.match(/(\d+(?:\.\d+)?)\s*sheets?/i);
  return m? parseFloat(m[1]) : null;
}
function extractFinish(text){
  if(!text) return null;
  var m = text.match(/level\s*([0-5])\b/i);
  return m? parseInt(m[1],10) : null;
}
function extractHours(text){
  if(!text) return null;
  var ls=lines(text), i, m;
  for(i=0;i<ls.length;i++){
    m = ls[i].match(/(\d+(?:\.\d+)?)\s*hours?\b/i) || ls[i].match(/hours?\s*(?:worked|completed)?\s*[:\-]?\s*(\d+(?:\.\d+)?)/i);
    if(m) return parseFloat(m[1]);
  }
  return null;
}
function extractRate(texts){
  var i, m, t;
  for(i=0;i<texts.length;i++){
    t=texts[i]; if(!t) continue;
    m = t.match(/\$\s*(\d+(?:\.\d{1,2})?)\s*(?:\/\s*hr|per\s+hour)/i);
    if(m) return parseFloat(m[1]);
  }
  for(i=0;i<texts.length;i++){
    t=texts[i]; if(!t) continue;
    m = t.match(/(?:hourly\s+)?rate\s*[:\-]?\s*\$?\s*(\d+(?:\.\d{1,2})?)/i);
    if(m) return parseFloat(m[1]);
  }
  return null;
}
function extractLaborCharged(invoice){
  if(!invoice) return null;
  var ls=lines(invoice), i;
  for(i=0;i<ls.length;i++){ if(/labor/i.test(ls[i])){ var v=lastMoney(ls[i]); if(v!==null) return v; } }
  return null;
}
function extractHoursOnInvoice(invoice){
  if(!invoice) return null;
  var ls=lines(invoice), i, m;
  for(i=0;i<ls.length;i++){ if(/labor/i.test(ls[i])){ m=ls[i].match(/(\d+(?:\.\d+)?)\s*hours?/i); if(m) return parseFloat(m[1]); } }
  return null;
}
function extractDeposit(text){
  if(!text) return null;
  var ls=lines(text), i;
  for(i=0;i<ls.length;i++){ if(/deposit/i.test(ls[i])){ var v=firstMoney(ls[i]); if(v!==null) return v; } }
  return null;
}
function extractSheetArea(texts){
  var i, m;
  for(i=0;i<texts.length;i++){ if(!texts[i]) continue;
    m = texts[i].match(/\b(4)\s*[x\u00D7]\s*(8|10|12)\b/);
    if(m) return parseInt(m[1],10)*parseInt(m[2],10);
  }
  return null;
}
function extractStatedArea(text){
  if(!text) return null;
  var m = text.match(/area[^$\d\n]*(\d[\d,]*(?:\.\d+)?)\s*(?:sq\.?\s*ft|square\s+feet)?/i);
  if(m) return parseFloat(m[1].replace(/,/g,""));
  var ls=lines(text), i;
  for(i=0;i<ls.length;i++){
    if(/per\s+sheet/i.test(ls[i])) continue;
    m = ls[i].match(/(\d[\d,]*(?:\.\d+)?)\s*(?:sq\.?\s*ft|square\s+feet)/i);
    if(m) return parseFloat(m[1].replace(/,/g,""));
  }
  return null;
}
function extractInvoiceTotal(invoice){
  if(!invoice) return null;
  var ls=lines(invoice), i, found=null;
  for(i=0;i<ls.length;i++){ if(/total/i.test(ls[i])){ var v=lastMoney(ls[i]); if(v!==null) found=v; } }
  return found;
}
function invoiceItemLines(invoice){
  /* lines carrying money, excluding total lines. Amount = last $ on the line (the line total). */
  var out=[], ls=lines(invoice||""), i;
  for(i=0;i<ls.length;i++){
    if(!/\$/.test(ls[i])) continue;
    if(/total/i.test(ls[i])) continue;
    var v=lastMoney(ls[i]); if(v===null) continue;
    var neg = /credit/i.test(ls[i]) || /-\s*\$/.test(ls[i]);
    out.push({label:ls[i].trim(), amount: neg? -v : v, raw:v});
  }
  return out;
}
function qtyUnitLines(text, docName){
  /* "20 x $22.00 = $500.00" style lines in any document */
  var out=[], ls=lines(text||""), i, m;
  for(i=0;i<ls.length;i++){
    m = ls[i].match(/(\d+(?:\.\d+)?)\s*[x\u00D7]\s*\$?\s*(\d+(?:\.\d{1,2})?)/);
    if(!m) continue;
    var vals=moneyVals(ls[i]); if(vals.length<2) continue;
    var total=vals[vals.length-1];
    out.push({doc:docName, label:ls[i].trim(), qty:parseFloat(m[1]), unit:parseFloat(m[2]), stated:total, computed:parseFloat(m[1])*parseFloat(m[2])});
  }
  return out;
}

/* ---------- the audit ---------- */
function audit(){
  var P=$("proposal").value, W=$("work").value, I=$("invoice").value;
  var docs={proposal:usable(P), work:usable(W), invoice:usable(I)};
  var count=(docs.proposal?1:0)+(docs.work?1:0)+(docs.invoice?1:0);
  var missing=[]; if(!docs.proposal)missing.push("Proposal / quote"); if(!docs.work)missing.push("Work record"); if(!docs.invoice)missing.push("Final invoice");

  var sheetsP=extractSheets(P), sheetsW=extractSheets(W), sheetsI=extractSheets(I);
  var finishP=extractFinish(P), finishW=extractFinish(W), finishI=extractFinish(I);
  var hoursW=extractHours(W), hoursI=extractHoursOnInvoice(I);
  var rate=extractRate([P,W,I]);
  var laborCharged=extractLaborCharged(I);
  var depP=extractDeposit(P), depI=extractDeposit(I);
  var perSheet=extractSheetArea([P,W,I]);
  var areaStated=extractStatedArea(P)!==null? extractStatedArea(P) : (extractStatedArea(W)!==null? extractStatedArea(W) : extractStatedArea(I));
  var invTotal=extractInvoiceTotal(I);
  var items=invoiceItemLines(I);

  var checks=[];
  function add(id,title,status,severity,arith){ checks.push({id:id,title:title,status:status,severity:severity||null,arithmetic:arith}); }

  /* 1 — Sheets billed vs sheets hung */
  (function(){
    var billed = sheetsI!==null? sheetsI : sheetsP;
    var billedSrc = sheetsI!==null? "invoice" : "proposal";
    if(billed===null || sheetsW===null){ add("sheets","Sheets billed vs. sheets recorded as hung","NOT ENOUGH DATA",null,
      "Sheets billed: "+(billed===null?"not stated in the pastes":num(billed)+" (from the "+billedSrc+")")+"\nSheets recorded as hung: "+(sheetsW===null?"not stated in the work record":num(sheetsW))+"\nThis check needs both figures — one is missing, so it is not passed or failed."); return; }
    var diff=billed-sheetsW;
    if(diff===0){ add("sheets","Sheets billed vs. sheets recorded as hung","PASS",null,
      "Sheets billed ("+billedSrc+"): "+num(billed)+"\nSheets recorded as hung (work record): "+num(sheetsW)+"\n"+num(billed)+" - "+num(sheetsW)+" = 0 sheets difference. They agree."); }
    else{ add("sheets","Sheets billed vs. sheets recorded as hung","FAIL", Math.abs(diff)>=2?"major":"minor",
      "Sheets billed ("+billedSrc+"): "+num(billed)+"\nSheets recorded as hung (work record): "+num(sheetsW)+"\n"+num(billed)+" - "+num(sheetsW)+" = "+num(diff)+" sheets "+(diff>0?"billed but never recorded as hung":"hung but not billed")+"."); }
  })();

  /* 2 — Area cross-check */
  (function(){
    var billed = sheetsI!==null? sheetsI : sheetsP;
    if(perSheet===null || (billed===null && sheetsW===null)){ add("area","Sheet count \u00D7 sheet size \u2192 area cross-check","NOT ENOUGH DATA",null,
      "Sheet size (e.g. 4x8): "+(perSheet===null?"not stated in the pastes":num(perSheet)+" sq ft per sheet")+"\nWithout a stated sheet size and sheet counts, area cannot be recomputed."); return; }
    var txt="Sheet size gives "+num(perSheet)+" sq ft per sheet.\n";
    var fail=null;
    if(billed!==null) txt+="Area billed: "+num(billed)+" sheets \u00D7 "+num(perSheet)+" sq ft = "+num(billed*perSheet)+" sq ft.\n";
    if(sheetsW!==null) txt+="Area hung: "+num(sheetsW)+" sheets \u00D7 "+num(perSheet)+" sq ft = "+num(sheetsW*perSheet)+" sq ft.\n";
    if(areaStated!==null) txt+="Area stated in the documents: "+num(areaStated)+" sq ft.\n";
    if(billed!==null && sheetsW!==null && billed!==sheetsW){ fail={sev:Math.abs(billed-sheetsW)>=2?"major":"minor", msg:"Billed area and hung area disagree by "+num(Math.abs(billed-sheetsW)*perSheet)+" sq ft."}; }
    else if(sheetsW!==null && areaStated!==null && Math.abs(sheetsW*perSheet-areaStated)>0.5){ fail={sev:"major", msg:"Hung area ("+num(sheetsW*perSheet)+" sq ft) does not match the stated area ("+num(areaStated)+" sq ft) — difference "+num(Math.abs(sheetsW*perSheet-areaStated))+" sq ft."}; }
    else if(billed!==null && areaStated!==null && sheetsW===null && Math.abs(billed*perSheet-areaStated)>0.5){ fail={sev:"minor", msg:"Billed area does not match the stated area."}; }
    if(fail){ txt+=fail.msg; add("area","Sheet count \u00D7 sheet size \u2192 area cross-check","FAIL",fail.sev,txt); }
    else if(sheetsW!==null && (areaStated!==null || billed!==null)){ add("area","Sheet count \u00D7 sheet size \u2192 area cross-check","PASS",null,txt+"The areas agree."); }
    else { add("area","Sheet count \u00D7 sheet size \u2192 area cross-check","NOT ENOUGH DATA",null,txt+"No stated area and no second sheet count to cross-check against."); }
  })();

  /* 3 — Finish level */
  (function(){
    var billedF = finishI!==null? finishI : finishP;
    var src = finishI!==null? "invoice" : "proposal";
    if(billedF===null || finishW===null){ add("finish","Finish level billed vs. finish level recorded","NOT ENOUGH DATA",null,
      "Finish level billed: "+(billedF===null?"not stated":("Level "+billedF+" (from the "+src+")"))+"\nFinish level recorded as completed: "+(finishW===null?"not stated in the work record":("Level "+finishW))+"\nThis check needs both levels."); return; }
    if(billedF===finishW){ add("finish","Finish level billed vs. finish level recorded","PASS",null,
      "Finish level billed ("+src+"): Level "+billedF+"\nFinish level recorded as completed (work record): Level "+finishW+"\nLevel "+billedF+" = Level "+finishW+". They agree."); }
    else{ add("finish","Finish level billed vs. finish level recorded","FAIL","major",
      "Finish level billed ("+src+"): Level "+billedF+"\nFinish level recorded as completed (work record): Level "+finishW+"\nLevel "+billedF+" billed, Level "+finishW+" recorded — the invoice charges for a finish the work record does not show."); }
  })();

  /* 4 — Labor hours x rate vs labor charged */
  (function(){
    var hours = hoursW!==null? hoursW : hoursI;
    var hsrc = hoursW!==null? "work record" : "invoice";
    if(hours===null || rate===null || laborCharged===null){ add("labor","Recorded labor hours \u00D7 hourly rate vs. labor charged","NOT ENOUGH DATA",null,
      "Labor hours: "+(hours===null?"not stated":num(hours)+" (from the "+hsrc+")")+"\nHourly rate: "+(rate===null?"not stated in any paste":fmt(rate)+"/hr")+"\nLabor charged on invoice: "+(laborCharged===null?"no labor line with an amount on the invoice":fmt(laborCharged))+"\nThis check needs all three figures."); return; }
    var expected=hours*rate, diff=laborCharged-expected;
    if(Math.abs(diff)<=TOL){ add("labor","Recorded labor hours \u00D7 hourly rate vs. labor charged","PASS",null,
      num(hours)+" hours ("+hsrc+") \u00D7 "+fmt(rate)+"/hr = "+fmt(expected)+"\nLabor charged on invoice: "+fmt(laborCharged)+"\nDifference: "+fmt(diff)+". They agree."); }
    else{ add("labor","Recorded labor hours \u00D7 hourly rate vs. labor charged","FAIL", Math.abs(diff)>MAJOR?"major":"minor",
      num(hours)+" hours ("+hsrc+") \u00D7 "+fmt(rate)+"/hr = "+fmt(expected)+"\nLabor charged on invoice: "+fmt(laborCharged)+"\nDifference: "+fmt(laborCharged)+" - "+fmt(expected)+" = "+fmt(diff)+" "+(diff>0?"overcharged":"undercharged")+"."); }
  })();

  /* 5 — Quantity x unit price line totals */
  (function(){
    var ql = qtyUnitLines(I,"invoice").concat(qtyUnitLines(P,"proposal"));
    if(!ql.length){ add("materials","Line totals vs. quantity \u00D7 unit price","NOT ENOUGH DATA",null,
      "No line in the pastes is written as quantity \u00D7 unit price = total, so no line total can be recomputed."); return; }
    var bad=[], txt="";
    ql.forEach(function(l){ txt+=l.doc+": "+num(l.qty)+" \u00D7 "+fmt(l.unit)+" = "+fmt(l.computed)+" recomputed; line states "+fmt(l.stated)+(Math.abs(l.computed-l.stated)<=0.51?" — agrees.\n":" — DISAGREES by "+fmt(l.stated-l.computed)+".\n");
      if(Math.abs(l.computed-l.stated)>0.51) bad.push(l); });
    if(!bad.length) add("materials","Line totals vs. quantity \u00D7 unit price","PASS",null,txt.trim());
    else { var worst=0; bad.forEach(function(l){ worst=Math.max(worst,Math.abs(l.stated-l.computed)); });
      add("materials","Line totals vs. quantity \u00D7 unit price","FAIL", worst>MAJOR?"major":"minor", txt.trim()); }
  })();

  /* 6 — Deposit */
  (function(){
    if(depP===null){ add("deposit","Deposit in proposal vs. deposit credited on invoice","NOT ENOUGH DATA",null,
      "No deposit amount is stated in the proposal paste, so there is nothing to look for on the invoice."); return; }
    if(!docs.invoice){ add("deposit","Deposit in proposal vs. deposit credited on invoice","NOT ENOUGH DATA",null,
      "Deposit stated in proposal: "+fmt(depP)+"\nNo usable invoice was pasted, so the credit cannot be checked."); return; }
    if(depI===null){ add("deposit","Deposit in proposal vs. deposit credited on invoice","FAIL","major",
      "Deposit stated in proposal: "+fmt(depP)+"\nDeposit credited on invoice: no deposit line found.\nThe "+fmt(depP)+" deposit is missing from the invoice — the customer would pay it twice."); return; }
    var diff=depP-depI;
    if(Math.abs(diff)<=TOL){ add("deposit","Deposit in proposal vs. deposit credited on invoice","PASS",null,
      "Deposit stated in proposal: "+fmt(depP)+"\nDeposit credited on invoice: "+fmt(depI)+"\n"+fmt(depP)+" - "+fmt(depI)+" = $0.00. The full deposit is credited."); }
    else{ add("deposit","Deposit in proposal vs. deposit credited on invoice","FAIL", Math.abs(diff)>MAJOR?"major":"minor",
      "Deposit stated in proposal: "+fmt(depP)+"\nDeposit credited on invoice: "+fmt(depI)+"\n"+fmt(depP)+" - "+fmt(depI)+" = "+fmt(diff)+" of the deposit is not credited."); }
  })();

  /* 7 — Invoice-only charges */
  (function(){
    if(!docs.invoice){ add("invonly","Charges that appear only on the invoice","NOT ENOUGH DATA",null,"No usable invoice was pasted."); return; }
    var others=((P||"")+" "+(W||"")).toLowerCase();
    var stop={the:1,and:1,for:1,per:1,with:1,total:1,fee:0};
    var flagged=[];
    items.forEach(function(it){
      if(/deposit/i.test(it.label)) return;
      var words=it.label.toLowerCase().replace(/[^a-z\s]/g," ").split(/\s+/).filter(function(w){ return w.length>=3; });
      var found=false;
      words.forEach(function(w){ if(others.indexOf(w)>=0) found=true; });
      if(words.length && !found) flagged.push(it);
    });
    if(!items.length){ add("invonly","Charges that appear only on the invoice","NOT ENOUGH DATA",null,"The invoice paste has no priced line items to compare against the proposal and work record."); return; }
    if(!flagged.length){ add("invonly","Charges that appear only on the invoice","PASS",null,
      items.length+" priced invoice line(s) checked. Every one traces back to wording in the proposal or the work record. No invoice-only charges found."); }
    else{ var txt="These charges appear on the invoice and nowhere in the proposal or work record:\n";
      flagged.forEach(function(it){ txt+="\u2022 "+it.label+" — "+fmt(it.amount)+"\n"; });
      txt+="Total invoice-only charges: "+fmt(flagged.reduce(function(s,it){return s+it.amount;},0))+".";
      add("invonly","Charges that appear only on the invoice","FAIL","major",txt.trim()); }
  })();

  /* 8 — Invoice lines sum vs stated total */
  (function(){
    if(!docs.invoice || invTotal===null || !items.length){ add("invtotal","Invoice line items vs. the invoice's stated total","NOT ENOUGH DATA",null,
      "Invoice stated total: "+(invTotal===null?"not stated":fmt(invTotal))+"\nPriced line items found: "+items.length+"\nThis check needs both the line items and a stated total."); return; }
    var sum=items.reduce(function(s,it){return s+it.amount;},0);
    var parts=items.map(function(it){ return (it.amount<0?"- ":"")+fmt(it.amount); }).join(" + ").replace(/\+ - /g,"- ");
    var diff=invTotal-sum;
    if(Math.abs(diff)<=TOL){ add("invtotal","Invoice line items vs. the invoice's stated total","PASS",null,
      "Line items: "+parts+" = "+fmt(sum)+"\nStated total on invoice: "+fmt(invTotal)+"\nDifference: $0.00. The invoice adds up."); }
    else{ add("invtotal","Invoice line items vs. the invoice's stated total","FAIL", Math.abs(diff)>MAJOR?"major":"minor",
      "Line items: "+parts+" = "+fmt(sum)+"\nStated total on invoice: "+fmt(invTotal)+"\n"+fmt(invTotal)+" - "+fmt(sum)+" = "+fmt(diff)+" — the stated total does not match its own line items."); }
  })();

  /* ---------- verdict ---------- */
  var majors=checks.filter(function(c){return c.status==="FAIL"&&c.severity==="major";});
  var minors=checks.filter(function(c){return c.status==="FAIL"&&c.severity!=="major";});
  var passes=checks.filter(function(c){return c.status==="PASS";}).length;
  var nds=checks.filter(function(c){return c.status==="NOT ENOUGH DATA";}).length;
  var verdict, sub;
  if(count<2){
    verdict="NOT ENOUGH TO COMPARE";
    sub="Fewer than two usable documents were pasted ("+count+" of 3). Cross-checking needs at least two documents that state figures."+(missing.length?" Missing or unusable: "+missing.join(", ")+".":"");
  } else if(majors.length){
    verdict="DO NOT PAY YET";
    sub=majors.length+" major disagreement(s) across the documents — named in the checks below with amounts. Hold payment until they are fixed.";
  } else if(minors.length){
    verdict="PAY WITH FIXES";
    sub=minors.length+" small disagreement(s) to fix first — named in the checks below with amounts.";
  } else if(count===2){
    verdict="PAY WITH FIXES";
    sub="Only two documents were pasted, so the verdict is capped at PAY WITH FIXES. Missing document: "+missing.join(", ")+". Nothing found disagrees — but the third document was never checked.";
  } else if(passes>=3 && nds<=2){
    verdict="SAFE TO PAY";
    sub="All three documents agree on every figure that could be recomputed. No mismatches, no uncredited deposit, no invoice-only charges.";
  } else {
    verdict="PAY WITH FIXES";
    sub="Nothing disagrees, but "+nds+" check(s) had NOT ENOUGH DATA — too little was stated in the pastes to call it fully safe.";
  }
  if(count===2 && majors.length){ sub+=" Also note: only two documents were pasted — missing document: "+missing.join(", ")+"."; }

  /* ---------- render ---------- */
  $("verdictText").textContent=verdict;
  $("verdictSub").textContent=sub;
  $("docCount").textContent=count+" / 3";
  var problems=majors.length+minors.length;
  $("failCount").textContent=problems+" problem"+(problems===1?"":"s")+" · "+passes+" checks passed";
  $("missingDoc").textContent= missing.length? ("Missing: "+missing.join(", ")) : "All three documents present";

  var pillCls={PASS:"ok",FAIL:"bad","NOT ENOUGH DATA":"nd"};
  $("checks").innerHTML=checks.map(function(c){
    var cls = c.status==="FAIL" ? (c.severity==="major"?"bad":"warn") : pillCls[c.status];
    var label = c.status==="FAIL" ? (c.severity==="major"?"FAIL — MAJOR":"FAIL") : c.status;
    return '<div class="check"><div class="check-head"><h3>'+c.title+'</h3><span class="pill '+cls+'">'+label+'</span></div><div class="arith">'+c.arithmetic.replace(/&/g,"&amp;").replace(/</g,"&lt;")+'</div></div>';
  }).join("");

  var figRows=[
    ["Sheets — proposal", sheetsP===null?"not stated":num(sheetsP)],["Sheets — work record (hung)", sheetsW===null?"not stated":num(sheetsW)],["Sheets — invoice (billed)", sheetsI===null?"not stated":num(sheetsI)],
    ["Sheet size", perSheet===null?"not stated":num(perSheet)+" sq ft per sheet"],["Stated wall/ceiling area", areaStated===null?"not stated":num(areaStated)+" sq ft"],
    ["Finish level — proposal", finishP===null?"not stated":"Level "+finishP],["Finish level — work record", finishW===null?"not stated":"Level "+finishW],["Finish level — invoice", finishI===null?"not stated":"Level "+finishI],
    ["Labor hours — work record", hoursW===null?"not stated":num(hoursW)],["Hourly rate", rate===null?"not stated":fmt(rate)+"/hr"],["Labor charged — invoice", laborCharged===null?"not stated":fmt(laborCharged)],
    ["Deposit — proposal", depP===null?"not stated":fmt(depP)],["Deposit credited — invoice", depI===null?"not stated":fmt(depI)],["Invoice stated total", invTotal===null?"not stated":fmt(invTotal)]
  ];
  $("figures").innerHTML='<table><tr><th>Figure</th><th>Value found in the pastes</th></tr>'+figRows.map(function(r){return "<tr><td>"+r[0]+"</td><td>"+r[1]+"</td></tr>";}).join("")+"</table>";

  var report={
    tool:"J-Dawgs Drywall Proposal, Work Record & Final Invoice Consistency Auditor\u2122",
    verdict:verdict, verdictDetail:sub,
    documents:{proposal:docs.proposal, workRecord:docs.work, invoice:docs.invoice, usableCount:count, missing:missing},
    figures:{sheetsProposal:sheetsP, sheetsHung:sheetsW, sheetsBilled:sheetsI, sqFtPerSheet:perSheet, statedAreaSqFt:areaStated,
      finishProposal:finishP, finishRecorded:finishW, finishBilled:finishI, laborHours:hoursW, hourlyRate:rate,
      laborCharged:laborCharged, depositProposal:depP, depositCreditedInvoice:depI, invoiceStatedTotal:invTotal},
    checks:checks.map(function(c){return {check:c.title, status:c.status, severity:c.severity, arithmetic:c.arithmetic};})
  };
  var txt="DRYWALL CONSISTENCY AUDIT\nVerdict: "+verdict+"\n"+sub+"\nDocuments usable: "+count+" of 3"+(missing.length?" — missing: "+missing.join(", "):"")+"\n\n";
  checks.forEach(function(c){ txt+="["+c.status+(c.status==="FAIL"&&c.severity?" / "+c.severity.toUpperCase():"")+"] "+c.title+"\n"+c.arithmetic+"\n\n"; });
  txt+="Note: this audit compares only what the pasted documents state. It does not judge workmanship quality and does not verify measurements on site.";
  $("reportText").value=txt;
  $("reportJson").value=JSON.stringify(report,null,2);
  return report;
}
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-drywall-proposal-work-record-final-invoice-consistency-auditortm',
  name: 'J-Dawgs Drywall Proposal, Work Record & Final Invoice Consistency Auditor',
  description: 'Cross-checks a drywall proposal against the work record and final invoice into one pay verdict — sheets billed vs hung, finish level, labor, deposit credit, and invoice-only fees, all shown across all pastes. Every other system grades one document alone.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
