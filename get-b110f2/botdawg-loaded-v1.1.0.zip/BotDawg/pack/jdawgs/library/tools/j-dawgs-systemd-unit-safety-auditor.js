'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Systemd Unit Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var RISKY_EXAMPLE = [
          "[Unit]",
          "Description=Legacy backup uploader (worked example)",
          "After=network.target",
          "",
          "[Service]",
          "Type=simple",
          'ExecStart=/bin/bash -c "/opt/backup/upload.sh --push"',
          "Restart=always",
          "RestartSec=0",
          "Environment=API_KEY=FAKE-EXAMPLE-KEY-0000-do-not-use",
          "",
          "[Install]",
          "WantedBy=multi-user.target"
        ].join("\n");

        var CLEAN_EXAMPLE = [
          "[Unit]",
          "Description=Nightly report generator (worked example)",
          "After=network.target",
          "",
          "[Service]",
          "Type=simple",
          "User=reportsvc",
          "Group=reportsvc",
          "ExecStart=/usr/local/bin/report-gen --run",
          "NoNewPrivileges=true",
          "ProtectSystem=strict",
          "ProtectHome=true",
          "PrivateTmp=true",
          "ProtectKernelTunables=true",
          "ProtectControlGroups=true",
          "CapabilityBoundingSet=CAP_NET_BIND_SERVICE",
          "Restart=on-failure",
          "RestartSec=5",
          "StartLimitBurst=5",
          "",
          "[Install]",
          "WantedBy=multi-user.target"
        ].join("\n");

        var SECRET_PATTERNS = ["PASSWORD", "PASSWD", "TOKEN", "SECRET", "API_KEY", "APIKEY",
          "PRIVATE_KEY", "ACCESS_KEY", "SECRET_KEY", "CREDENTIAL"];
        var SANDBOX_DIRECTIVES = ["ProtectSystem", "ProtectHome", "PrivateTmp",
          "ProtectKernelTunables", "ProtectControlGroups"];

        function isTruthy(v) {
          var s = String(v).trim().toLowerCase();
          return s === "yes" || s === "true" || s === "on" || s === "1";
        }
        function isFalsy(v) {
          var s = String(v).trim().toLowerCase();
          return s === "no" || s === "false" || s === "off" || s === "0" || s === "";
        }

        // Join backslash-continued lines, remembering the line each logical line starts on.
        function toLogicalLines(text) {
          var raw = text.split(/\r?\n/);
          var out = [];
          var cur = null;
          for (var i = 0; i < raw.length; i++) {
            if (cur === null) cur = { text: raw[i], line: i + 1 };
            else cur.text += raw[i];
            var trimmedEnd = cur.text.replace(/\s+$/, "");
            if (trimmedEnd.charAt(trimmedEnd.length - 1) === "\\" && i < raw.length - 1) {
              cur.text = trimmedEnd.slice(0, -1);
              continue;
            }
            out.push(cur);
            cur = null;
          }
          if (cur !== null) out.push(cur);
          return out;
        }

        function parseUnit(text) {
          var logical = toLogicalLines(text);
          var directives = []; // {key, value, line, section, checked}
          var sections = {};   // name -> {line}
          var problems = [];   // {line, kind, text}
          var section = "";
          logical.forEach(function (entry) {
            var t = entry.text.trim();
            if (t === "" || t.charAt(0) === "#" || t.charAt(0) === ";") return;
            if (t.charAt(0) === "[") {
              var m = t.match(/^\[\s*([A-Za-z][A-Za-z0-9]*)\s*\]$/);
              if (m) {
                section = m[1];
                if (!sections[section]) sections[section] = { line: entry.line };
              } else {
                problems.push({ line: entry.line, kind: "header", text: t.slice(0, 60) });
                section = "";
              }
              return;
            }
            var eq = t.indexOf("=");
            if (eq > 0) {
              directives.push({
                key: t.slice(0, eq).trim(),
                value: t.slice(eq + 1).trim(),
                line: entry.line,
                section: section,
                checked: false
              });
            } else {
              problems.push({ line: entry.line, kind: "stray", text: t.slice(0, 60) });
            }
          });
          return { directives: directives, sections: sections, problems: problems, lineCount: logical.length };
        }

        function audit(text) {
          var parsed = parseUnit(text);
          var directives = parsed.directives;
          var sections = parsed.sections;
          var findings = [];

          function add(severity, line, directive, finding, fix) {
            findings.push({ severity: severity, line: line, directive: directive, finding: finding, fix: fix });
          }
          function all(key, sectionName) {
            return directives.filter(function (d) {
              return d.key === key && (sectionName === undefined || d.section === sectionName);
            });
          }
          function last(key, sectionName) {
            var list = all(key, sectionName);
            return list.length ? list[list.length - 1] : null;
          }
          function mark(d) { if (d) d.checked = true; }
          function markAll(list) { list.forEach(mark); }

          var serviceLine = sections["Service"] ? sections["Service"].line : 1;
          var unitLine = sections["Unit"] ? sections["Unit"].line : 1;

          // Malformed lines first — parsing cannot be trusted past them.
          parsed.problems.forEach(function (p) {
            if (p.kind === "header") {
              add("BLOCKER", p.line, "(section header)",
                "Malformed section header: \"" + p.text + "\" — it does not parse as a [Section] header, so directives under it may belong to the wrong section.",
                "Fix the header to the form [Unit], [Service], or [Install] on its own line, then re-audit.");
            } else {
              add("WARNING", p.line, "(unparsed line)",
                "This line is not a recognizable Key=Value directive or section header, so the audit could not evaluate whatever it sets.",
                "Rewrite it as a proper directive line, or remove it, then re-audit.");
            }
          });

          if (!sections["Service"]) {
            add("BLOCKER", 1, "[Service]",
              "No [Service] section found — this does not parse as a runnable service unit.",
              "Add a [Service] section with at least Type= and ExecStart=.");
          }

          // ---- Runs as root ----
          var userD = last("User", "Service");
          var dynD = last("DynamicUser", "Service");
          mark(userD); mark(dynD);
          var dynOn = dynD ? isTruthy(dynD.value) : false;
          var rootUser = userD ? (userD.value === "root" || userD.value === "0") : false;
          var runningRoot = false;
          if (userD) {
            if (rootUser) {
              runningRoot = true;
              add("BLOCKER", userD.line, "User=",
                "Service runs as root (User=" + userD.value + "). A compromise of this service is a compromise of the whole machine.",
                "Create a dedicated unprivileged account for this service and set User= to it.");
            }
          } else if (dynOn) {
            add("INFO", dynD.line, "DynamicUser=",
              "No User= is set, but DynamicUser=yes is on: systemd runs the service as an ephemeral unprivileged user, so the runs-as-root risk is mitigated.",
              "No change needed for the user risk. Note the account is recreated per run — do not rely on a persistent home directory.");
          } else {
            runningRoot = true;
            add("BLOCKER", serviceLine, "User=",
              "No User= directive in [Service] — systemd runs this service as root by default. A compromise of the service is a compromise of the whole machine.",
              "Create a dedicated unprivileged account for this service and add User=<that account> in [Service] (or set DynamicUser=yes).");
          }

          // ---- Privilege ----
          var nnpD = last("NoNewPrivileges", "Service");
          mark(nnpD);
          if (!nnpD) {
            add("WARNING", serviceLine, "NoNewPrivileges=",
              "NoNewPrivileges is missing — the service's processes can still gain privileges through setuid/setgid binaries and file capabilities.",
              "Add NoNewPrivileges=true in [Service].");
          } else if (!isTruthy(nnpD.value)) {
            add("WARNING", nnpD.line, "NoNewPrivileges=",
              "NoNewPrivileges is set to \"" + nnpD.value + "\" (off) — the service's processes can gain privileges through setuid/setgid binaries and file capabilities.",
              "Set NoNewPrivileges=true.");
          }

          var cbsD = last("CapabilityBoundingSet", "Service");
          mark(cbsD);
          if (cbsD) {
            var caps = cbsD.value.toUpperCase().split(/\s+/).filter(Boolean);
            if (caps.indexOf("CAP_SYS_ADMIN") !== -1) {
              add("WARNING", cbsD.line, "CapabilityBoundingSet=",
                "CapabilityBoundingSet includes CAP_SYS_ADMIN, which is close to root-equivalent — it largely undoes the point of a bounding set.",
                "Drop CAP_SYS_ADMIN and keep only the specific capabilities the service truly needs.");
            }
            if (cbsD.value.trim() === "") {
              add("WARNING", cbsD.line, "CapabilityBoundingSet=",
                "CapabilityBoundingSet is set to an empty value, which resets it to the full default capability set instead of restricting anything.",
                "List only the capabilities the service needs, e.g. CapabilityBoundingSet=CAP_NET_BIND_SERVICE.");
            }
          } else if (runningRoot) {
            add("WARNING", serviceLine, "CapabilityBoundingSet=",
              "CapabilityBoundingSet is not set and the service runs as root, so the process keeps the full default capability set.",
              "Set CapabilityBoundingSet= to only the capabilities the service needs (or to an empty restriction via a non-root user plus an explicit short list).");
          }

          var ambList = all("AmbientCapabilities", "Service");
          markAll(ambList);
          ambList.forEach(function (d) {
            if (d.value.trim() !== "") {
              add("WARNING", d.line, "AmbientCapabilities=",
                "AmbientCapabilities raises capabilities into the ambient set, so they survive exec and apply to every child process — including any shell the service spawns.",
                "Remove AmbientCapabilities= unless the service genuinely needs capabilities in unprivileged child processes; prefer CapabilityBoundingSet= plus a dedicated user.");
            }
          });

          // ---- Filesystem sandboxing ----
          var setCount = 0;
          var sandboxState = SANDBOX_DIRECTIVES.map(function (name) {
            var d = last(name, "Service");
            mark(d);
            var on = false;
            if (d) {
              if (name === "PrivateTmp" || name === "ProtectKernelTunables" || name === "ProtectControlGroups") {
                on = isTruthy(d.value);
              } else {
                on = !isFalsy(d.value); // ProtectSystem / ProtectHome: true, strict, full, read-only, tmpfs…
              }
            }
            if (on) setCount++;
            return { name: name, d: d, on: on };
          });
          var severalSet = setCount >= 3;
          sandboxState.forEach(function (s) {
            if (s.on) return;
            var sev = severalSet ? "INFO" : "WARNING";
            if (s.d) {
              add(sev, s.d.line, s.name + "=",
                s.name + " is set to \"" + s.d.value + "\", which leaves this part of the filesystem/kernel surface unprotected.",
                "Turn " + s.name + " on (see systemd.exec documentation for the right value for this service).");
            } else {
              add(sev, serviceLine, s.name + "=",
                s.name + " is missing — one layer of filesystem/kernel sandboxing is absent." +
                  (severalSet ? " Several other sandbox directives are already set, so this is a gap, not a hole." : ""),
                "Add " + s.name + "= with a protective value in [Service].");
            }
          });

          var rwpList = all("ReadWritePaths", "Service");
          markAll(rwpList);
          rwpList.forEach(function (d) {
            var tokens = d.value.split(/\s+/).filter(Boolean);
            tokens.forEach(function (tok) {
              var p = tok.replace(/^[-+!]+/, "");
              if (p === "/" || p === "/etc" || p.indexOf("/etc/") === 0) {
                add("WARNING", d.line, "ReadWritePaths=",
                  "ReadWritePaths exposes " + p + " as writable, which punches a hole through ProtectSystem-style sandboxing — a compromised service could rewrite system configuration.",
                  "Narrow ReadWritePaths= to the specific state directory the service owns (e.g. a path under /var/lib), never / or /etc.");
              }
            });
          });

          // ---- Restart posture ----
          var typeD = last("Type", "Service");
          var restartD = last("Restart", "Service");
          var restartSecD = last("RestartSec", "Service");
          var burstD = last("StartLimitBurst");
          mark(typeD); mark(restartD); mark(restartSecD); mark(burstD);
          var restartVal = restartD ? restartD.value.trim().toLowerCase() : "";
          if (typeD && typeD.value.trim().toLowerCase() === "oneshot" && restartVal === "always") {
            add("BLOCKER", restartD.line, "Restart=",
              "Type=oneshot combined with Restart=always is an invalid combination — a oneshot unit runs once and exits, so \"always restart\" contradicts it and systemd rejects the pattern in practice.",
              "Use Type=simple (or oneshot with Restart=no / on-failure via a separate timer) instead.");
          }
          if (restartD && (restartVal === "always" || restartVal === "on-failure")) {
            var secMissing = !restartSecD || restartSecD.value.trim() === "" || parseFloat(restartSecD.value) === 0;
            var burstHigh = !burstD || burstD.value.trim() === "" || parseInt(burstD.value, 10) >= 10;
            if (secMissing && burstHigh) {
              add("WARNING", restartD.line, "Restart=",
                "Restart=" + restartD.value + " with " + (restartSecD ? "RestartSec=" + restartSecD.value : "no RestartSec") +
                  " and " + (burstD ? "a high StartLimitBurst" : "no StartLimitBurst limit") +
                  " — if the service starts crashing, it will crash-loop with no pause, burning CPU and flooding the journal.",
                "Set RestartSec=5 (or higher) in [Service] and StartLimitBurst= (for example 5) in [Unit] so a broken service backs off instead of spinning.");
            }
          }

          // ---- Execution safety ----
          var execList = all("ExecStart", "Service");
          if (execList.length === 0) execList = all("ExecStart");
          if (execList.length === 0) {
            add("WARNING", serviceLine, "ExecStart=",
              "No ExecStart= directive found — there is no command here whose execution safety can be audited, and the unit would not run as a normal service.",
              "Add ExecStart= with an absolute path to the service binary.");
          }
          markAll(execList);
          var shellRe = /(?:^|[\s"'])(\/[\w./-]*)?\b(?:ba|da|z)?sh\s+-[a-zA-Z]*c\b/;
          execList.forEach(function (d) {
            var v = d.value;
            var firstTok = v.split(/\s+/).filter(Boolean)[0] || "";
            var path = firstTok.replace(/^[@\-:+!]+/, "");
            if (path && path.charAt(0) !== "/") {
              add("BLOCKER", d.line, "ExecStart=",
                "ExecStart path \"" + path + "\" is not an absolute path — systemd requires the command to be given as an absolute path.",
                "Use the full path to the binary, e.g. ExecStart=/usr/bin/<name>.");
            }
            if (shellRe.test(v) || ((path.slice(-3) === "/sh" || path.slice(-5) === "/bash") && /(^|\s)-c(\s|$)/.test(v))) {
              add("WARNING", d.line, "ExecStart=",
                "ExecStart runs the command through a shell (-c). Shell parsing adds quoting and injection risk, hides the real argument list from auditing, and the shell becomes an extra process that inherits the service's privileges.",
                "Call the binary directly in ExecStart= with plain arguments; if shell features are truly needed, move them into a reviewed script file and exec that.");
            }
          });

          // ---- Environment secrets: key name + line only, never the value ----
          var envList = all("Environment");
          markAll(envList);
          envList.forEach(function (d) {
            var keyRe = /([A-Za-z_][A-Za-z0-9_]*)\s*=/g;
            var m;
            var seen = {};
            while ((m = keyRe.exec(d.value)) !== null) {
              var key = m[1];
              var upper = key.toUpperCase();
              if (seen[upper]) continue;
              var hit = SECRET_PATTERNS.some(function (p) { return upper.indexOf(p) !== -1; });
              if (hit) {
                seen[upper] = true;
                add("WARNING", d.line, "Environment=",
                  "Environment= sets " + key + ", a secret-looking variable name, directly in the unit file. Unit files are world-readable and land in version control, so anything set here should be treated as published. (The value is deliberately not shown.)",
                  "Move " + key + " out of the unit: use an EnvironmentFile= with 0600 permissions, or systemd credentials (LoadCredential= / systemd-creds), and rotate the exposed secret.");
              }
            }
          });

          // ---- Completeness (INFO) ----
          var descD = last("Description", "Unit");
          mark(descD);
          if (!descD) {
            add("INFO", unitLine, "Description=",
              "No Description= in [Unit] — the unit is anonymous in systemctl listings, which slows down incident response.",
              "Add a one-line Description= naming what the service does.");
          }
          var wantedD = last("WantedBy", "Install");
          mark(wantedD);
          if (!sections["Install"]) {
            add("INFO", parsed.lineCount, "WantedBy=",
              "No [Install] section, so no WantedBy= — the unit cannot be enabled with systemctl enable and will not start at boot on its own.",
              "Add an [Install] section with WantedBy=multi-user.target if the service should start at boot.");
          } else if (!wantedD) {
            add("INFO", sections["Install"].line, "WantedBy=",
              "The [Install] section has no WantedBy= — the unit cannot be enabled with systemctl enable and will not start at boot on its own.",
              "Add WantedBy=multi-user.target under [Install] if the service should start at boot.");
          }

          // ---- Accounting: every directive lands in exactly one bucket ----
          // Findings name the directives they are about; a restart finding also
          // implicates RestartSec / StartLimitBurst, which feed that check.
          var implicated = {};
          findings.forEach(function (f) {
            implicated[f.directive.replace(/=$/, "")] = true;
          });
          if (implicated["Restart"]) {
            implicated["RestartSec"] = true;
            implicated["StartLimitBurst"] = true;
          }
          var passed = [];
          var passedByKey = {};
          var notChecked = [];
          var ncByKey = {};
          directives.forEach(function (d) {
            if (d.checked && !implicated[d.key]) {
              if (!passedByKey[d.key]) { passedByKey[d.key] = []; passed.push(d.key); }
              passedByKey[d.key].push(d.line);
            } else if (!d.checked) {
              if (!ncByKey[d.key]) { ncByKey[d.key] = []; notChecked.push(d.key); }
              ncByKey[d.key].push(d.line);
            }
          });

          var sevRank = { BLOCKER: 0, WARNING: 1, INFO: 2 };
          findings.sort(function (a, b) {
            if (sevRank[a.severity] !== sevRank[b.severity]) return sevRank[a.severity] - sevRank[b.severity];
            return a.line - b.line;
          });

          var counts = { BLOCKER: 0, WARNING: 0, INFO: 0 };
          findings.forEach(function (f) { counts[f.severity]++; });

          var verdict = counts.BLOCKER > 0 ? "DO NOT RUN YET"
            : counts.WARNING > 0 ? "RUN WITH FIXES" : "SAFE TO RUN";

          return {
            verdict: verdict,
            counts: counts,
            findings: findings,
            passed: passed.map(function (k) { return { key: k, lines: passedByKey[k] }; }),
            notChecked: notChecked.map(function (k) { return { key: k, lines: ncByKey[k] }; })
          };
        }

        function buildReport(r) {
          var lines = [];
          lines.push("J-Dawgs Systemd Unit Safety Auditor™ — audit report");
          lines.push("Verdict: " + r.verdict);
          lines.push("Counts: BLOCKER " + r.counts.BLOCKER + " · WARNING " + r.counts.WARNING + " · INFO " + r.counts.INFO);
          lines.push("");
          if (r.findings.length === 0) {
            lines.push("Findings: none — every check this tool runs passed.");
          } else {
            lines.push("Findings:");
            r.findings.forEach(function (f) {
              lines.push("[" + f.severity + "] Line " + f.line + " — " + f.directive + " — " + f.finding);
              lines.push("    Fix: " + f.fix);
            });
          }
          lines.push("");
          if (r.passed.length > 0) {
            lines.push("Checked and passed (evaluated, no finding):");
            r.passed.forEach(function (n) {
              lines.push("- " + n.key + " (line" + (n.lines.length > 1 ? "s " : " ") + n.lines.join(", ") + ")");
            });
            lines.push("");
          }
          if (r.notChecked.length === 0) {
            lines.push("Not checked: every directive in the unit was covered by a check.");
          } else {
            lines.push("Not checked (named, not passed):");
            r.notChecked.forEach(function (n) {
              lines.push("- " + n.key + " (line" + (n.lines.length > 1 ? "s " : " ") + n.lines.join(", ") + ")");
            });
          }
          lines.push("");
          lines.push("Note: heuristic line-by-line text audit of the pasted unit only. It does not run systemd, does not verify the binary exists, and does not check the host. Environment= secret values are never shown — key names and line numbers only.");
          lines.push("™ + © 2026 Joshua Dawson");
          return lines.join("\n");
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "CLEAN_EXAMPLE": (typeof CLEAN_EXAMPLE !== 'undefined' ? CLEAN_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-systemd-unit-safety-auditor',
  name: 'J-Dawgs Systemd Unit Safety Auditor',
  description: 'Audits a pasted systemd unit file — root/sandboxing/restart-loop posture — into one run verdict. systemd-analyze grades a unit on a live host; ours audits a pasted unit anywhere and returns one verdict plus a line-numbered fix list.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "CLEAN_EXAMPLE": __core["CLEAN_EXAMPLE"] }
};
