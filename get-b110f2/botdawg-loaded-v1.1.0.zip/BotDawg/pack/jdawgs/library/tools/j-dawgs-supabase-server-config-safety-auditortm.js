'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Supabase Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------------------------------------------------------------
         Worked examples. Line numbers are part of the spec: the risky
         example's planted findings must land on the exact lines below,
         and the self-test asserts them.
         --------------------------------------------------------------- */
      var RISKY_EXAMPLE = [
        "# Self-hosted Supabase - production .env (RISKY worked example - do not deploy)", // line 1
        "POSTGRES_HOST=db",                                                              // line 2
        "POSTGRES_DB=postgres",                                                          // line 3
        "POSTGRES_PORT=5432",                                                            // line 4
        "POSTGRES_PASSWORD=postgres",                                                    // line 5
        "JWT_SECRET=shortsecret",                                                        // line 6
        "JWT_EXP=99999999",                                                              // line 7
        "ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJyb2xlIjoiYW5vbiIsImlzcyI6InN1cGFiYXNlLWRlbW8iLCJpYXQiOjE2NDE3NjkyMDAsImV4cCI6MTc5OTUzNTYwMH0.dc_X5iR_VP_qT0zsiyj_I_OZ2T9FtRU2BBNWN8Bu4GE", // line 8
        "SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJyb2xlIjoic2VydmljZV9yb2xlIiwiaXNzIjoic3VwYWJhc2UtZGVtbyIsImlhdCI6MTY0MTc2OTIwMCwiZXhwIjoxNzk5NTM1NjAwfQ.DaYlNEoUrrEn2Ig7tqibS-PHK5vgusBcbo7X36XVt4Q", // line 9
        "DASHBOARD_USERNAME=supabase",                                                   // line 10
        "DASHBOARD_PASSWORD=admin",                                                      // line 11
        "SITE_URL=http://localhost:3000",                                                // line 12
        "API_EXTERNAL_URL=http://192.168.1.50:8000",                                     // line 13
        "SUPABASE_PUBLIC_URL=http://203.0.113.10:8000",                                  // line 14
        "ADDITIONAL_REDIRECT_URLS=https://example.com/**",                               // line 15
        "ENABLE_SIGNUP=true",                                                            // line 16
        "ENABLE_EMAIL_AUTOCONFIRM=true",                                                 // line 17
        "SMTP_HOST=smtp.example.com",                                                    // line 18
        "SMTP_PORT=587",                                                                 // line 19
        "SMTP_USER=alerts@example.com",                                                  // line 20
        "SMTP_PASS=PlaintextPassw0rd!234",                                               // line 21
        "STUDIO_DEFAULT_ORGANIZATION=Default Organization",                              // line 22
        "STUDIO_DEFAULT_PROJECT=default",                                                // line 23
        "LOGFLARE_API_KEY=lf_plain_9f8e7d6c5b4a3210fedc",                                // line 24
        "POOLER_TENANT_ID=default-pooler",                                               // line 25
        "    ports:",                                                                    // line 26
        '      - "5432:5432"',                                                           // line 27
        '      - "6543:6543"',                                                           // line 28
        '      - "8000:8000"'                                                            // line 29
      ].join("\n");

      var HARDENED_EXAMPLE = [
        "# Self-hosted Supabase - production .env (hardened example)",
        "POSTGRES_HOST=db",
        "POSTGRES_DB=postgres",
        "POSTGRES_PORT=5432",
        "POSTGRES_PASSWORD=Xk9$mQ2vLp8!zR4wN7bT3yH6sD1fG5jK0aQe",
        "JWT_SECRET=vR8nK2pQ7xW4mZ9bT6yH3sJ5dF1gA0cVeUoMkN",
        "JWT_EXP=3600",
        "ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJyb2xlIjoiYW5vbiIsImlzcyI6InN1cGFiYXNlIiwicmVmIjoiaGFyZGVuZWRleGFtcGxlIiwiaWF0IjoxNzE5NzkyMDAwLCJleHAiOjIwMzUxMzI4MDB9.AwQFBgcICQoLDA0ODxAREhMUFRYXGBkaGxwdHh8gISI",
        "SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJyb2xlIjoic2VydmljZV9yb2xlIiwiaXNzIjoic3VwYWJhc2UiLCJyZWYiOiJoYXJkZW5lZGV4YW1wbGUiLCJpYXQiOjE3MTk3OTIwMDAsImV4cCI6MjAzNTEzMjgwMH0.AwQFBgcICQoLDA0ODxAREhMUFRYXGBkaGxwdHh8gISI",
        "DASHBOARD_USERNAME=ops-admin",
        "DASHBOARD_PASSWORD=Tr7!wQ9zX2mK8pL4vN6b",
        "SITE_URL=https://app.example.com",
        "API_EXTERNAL_URL=https://api.example.com",
        "SUPABASE_PUBLIC_URL=https://api.example.com",
        "ADDITIONAL_REDIRECT_URLS=https://app.example.com/auth/callback",
        "ENABLE_SIGNUP=false",
        "DISABLE_SIGNUP=true",
        "ENABLE_EMAIL_AUTOCONFIRM=false",
        "SMTP_HOST=smtp.example.com",
        "SMTP_PORT=587",
        "SMTP_USER=alerts@example.com",
        "STUDIO_DEFAULT_ORGANIZATION=Example Org",
        "STUDIO_DEFAULT_PROJECT=production",
        "POOLER_TENANT_ID=prod-pooler",
        "    ports:",
        '      - "127.0.0.1:5432:5432"',
        '      - "127.0.0.1:6543:6543"'
      ].join("\n");

      var PROSE_EXAMPLE = [
        "Deployment notes for Friday.",
        "",
        "We are moving the community database to a new host this weekend.",
        "Remember to water the plants, back up the photo archive, and",
        "tell the team the maintenance window starts at nine in the evening.",
        "Nothing in this note is a configuration file."
      ].join("\n");

      /* Secrets planted in the risky example. The self-test scans the
         report text and JSON for these and requires 0 occurrences. */
      var PLANTED_SECRETS = [
        "shortsecret",
        "99999999",
        "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJyb2xlIjoiYW5vbiIsImlzcyI6InN1cGFiYXNlLWRlbW8iLCJpYXQiOjE2NDE3NjkyMDAsImV4cCI6MTc5OTUzNTYwMH0.dc_X5iR_VP_qT0zsiyj_I_OZ2T9FtRU2BBNWN8Bu4GE",
        "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJyb2xlIjoic2VydmljZV9yb2xlIiwiaXNzIjoic3VwYWJhc2UtZGVtbyIsImlhdCI6MTY0MTc2OTIwMCwiZXhwIjoxNzk5NTM1NjAwfQ.DaYlNEoUrrEn2Ig7tqibS-PHK5vgusBcbo7X36XVt4Q",
        "PlaintextPassw0rd!234",
        "lf_plain_9f8e7d6c5b4a3210fedc"
      ];

      var KNOWN_KEYS = {
        POSTGRES_PASSWORD: 1, POSTGRES_HOST: 1, POSTGRES_DB: 1, POSTGRES_USER: 1, POSTGRES_PORT: 1,
        JWT_SECRET: 1, JWT_EXP: 1, ANON_KEY: 1, SERVICE_ROLE_KEY: 1,
        SITE_URL: 1, API_EXTERNAL_URL: 1, SUPABASE_PUBLIC_URL: 1, ADDITIONAL_REDIRECT_URLS: 1,
        ENABLE_SIGNUP: 1, DISABLE_SIGNUP: 1, ENABLE_EMAIL_AUTOCONFIRM: 1, ENABLE_PHONE_SIGNUP: 1,
        ENABLE_PHONE_AUTOCONFIRM: 1, ENABLE_ANONYMOUS_USERS: 1,
        SMTP_HOST: 1, SMTP_PORT: 1, SMTP_USER: 1, SMTP_PASS: 1, SMTP_ADMIN_EMAIL: 1, SMTP_SENDER_NAME: 1,
        DASHBOARD_USERNAME: 1, DASHBOARD_PASSWORD: 1,
        STUDIO_DEFAULT_ORGANIZATION: 1, STUDIO_DEFAULT_PROJECT: 1, STUDIO_PORT: 1,
        KONG_HTTP_PORT: 1, KONG_HTTPS_PORT: 1,
        POOLER_TENANT_ID: 1, POOLER_PROXY_PORT_TRANSACTION: 1, POOLER_PROXY_PORT_SESSION: 1,
        POOLER_MAX_CLIENT_CONN: 1, POOLER_DEFAULT_POOL_SIZE: 1,
        LOGFLARE_API_KEY: 1, LOGFLARE_PRIVATE_ACCESS_TOKEN: 1, LOGFLARE_PUBLIC_ACCESS_TOKEN: 1,
        DOCKER_SOCKET_LOCATION: 1, FUNCTIONS_VERIFY_JWT: 1, IMGPROXY_ENABLE_WEBP_DETECTION: 1,
        SUPABASE_META_URL: 1, GOTRUE_EXTERNAL_PHONE_ENABLED: 1, MFA_ENABLED: 1
      };

      /* The documented demo / example values shipped in Supabase's own
         self-hosting examples. Anyone can read them in the public docs,
         so a config still carrying them is effectively public. */
      var DEMO_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJyb2xlIjoiYW5vbiIsImlzcyI6InN1cGFiYXNlLWRlbW8iLCJpYXQiOjE2NDE3NjkyMDAsImV4cCI6MTc5OTUzNTYwMH0.dc_X5iR_VP_qT0zsiyj_I_OZ2T9FtRU2BBNWN8Bu4GE";
      var DEMO_SERVICE_ROLE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJyb2xlIjoic2VydmljZV9yb2xlIiwiaXNzIjoic3VwYWJhc2UtZGVtbyIsImlhdCI6MTY0MTc2OTIwMCwiZXhwIjoxNzk5NTM1NjAwfQ.DaYlNEoUrrEn2Ig7tqibS-PHK5vgusBcbo7X36XVt4Q";
      var EXAMPLE_POSTGRES_PASSWORDS = ["postgres", "password", "changeme", "your-super-secret-and-long-postgres-password", "your_password", "example", "letmein", "admin"];
      var EXAMPLE_JWT_SECRETS = ["your-super-secret-jwt-token-with-at-least-32-characters-long", "your-jwt-secret", "changeme", "secret"];

      var SEV_ORDER = { blocker: 0, high: 1, medium: 2, low: 3 };

      function isPlaceholder(v) {
        var s = v.toLowerCase();
        return s === "" || s.indexOf("your-") === 0 || s.indexOf("your_") === 0 ||
          s.indexOf("<") === 0 || s.indexOf("${") === 0 || s === "changeme" ||
          s === "todo" || s === "xxx" || s === "...";
      }

      function decodeJwtPayload(token) {
        var parts = token.split(".");
        if (parts.length !== 3) return null;
        try {
          var b64 = parts[1].replace(/-/g, "+").replace(/_/g, "/");
          while (b64.length % 4) b64 += "=";
          return JSON.parse(atob(b64));
        } catch (e) { return null; }
      }

      function isDemoKey(token) {
        if (token === DEMO_ANON_KEY || token === DEMO_SERVICE_ROLE_KEY) return true;
        var payload = decodeJwtPayload(token);
        return !!(payload && payload.iss === "supabase-demo");
      }

      function hostOf(url) {
        var m = /^[a-z][a-z0-9+.-]*:\/\/([^\/:?#]+)/i.exec(url);
        return m ? m[1].toLowerCase() : "";
      }

      /* ------------------------- the auditor ------------------------- */
      function auditConfig(text) {
        var lines = String(text == null ? "" : text).split(/\r?\n/);
        var entries = {};      // KEY -> { value, line }
        var entryOrder = [];
        var portLines = [];    // { line, raw, hostPort, bindIp }
        var recognized = 0;
        var composeSignals = 0;

        lines.forEach(function (raw, idx) {
          var lineNo = idx + 1;
          var trimmed = raw.trim();
          var kv = /^(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/.exec(trimmed);
          if (kv) {
            var key = kv[1].toUpperCase();
            var val = kv[2].trim();
            if ((val.charAt(0) === '"' && val.charAt(val.length - 1) === '"') ||
                (val.charAt(0) === "'" && val.charAt(val.length - 1) === "'")) {
              val = val.slice(1, -1);
            }
            if (!entries[key]) entryOrder.push(key);
            entries[key] = { value: val, line: lineNo };
            if (KNOWN_KEYS[key]) recognized++;
            return;
          }
          if (/^(services|volumes|networks)\s*:/.test(trimmed) || /^image\s*:/.test(trimmed) || /supabase\//.test(trimmed)) composeSignals++;
          var pm = /^-\s*"?([^"\s]+)"?\s*$/.exec(trimmed);
          if (pm && pm[1].indexOf(":") !== -1 && /^\d/.test(pm[1].replace(/^[\d.]+:/, ""))) {
            var spec = pm[1];
            var parts = spec.split(":");
            var bindIp = null, hostPort = null;
            if (parts.length >= 3) { bindIp = parts[0]; hostPort = parts[parts.length - 2]; }
            else if (parts.length === 2) { hostPort = parts[0]; }
            if (hostPort && /^\d+$/.test(hostPort)) portLines.push({ line: lineNo, hostPort: hostPort, bindIp: bindIp });
          }
        });

        var findings = [];
        function add(severity, key, line, valueLength, title, detail, fix) {
          var f = { severity: severity, key: key, line: line, title: title, detail: detail, fix: fix };
          if (typeof valueLength === "number") f.valueLength = valueLength;
          findings.push(f);
        }
        function entry(key) { return entries[key] || null; }

        var gradeable = recognized >= 3 || (recognized >= 2 && composeSignals > 0);

        if (!gradeable) {
          return {
            tool: "J-Dawgs Supabase Server Config Safety Auditor™",
            verdict: "NOT ENOUGH TO GRADE",
            gradeable: false,
            recognizedKeys: recognized,
            linesScanned: lines.length,
            counts: { blocker: 0, high: 0, medium: 0, low: 0 },
            findings: [],
            note: "The paste does not look like a self-hosted Supabase configuration: fewer than three recognized Supabase .env keys were found. Paste the docker .env file (KEY=value lines) for the self-hosted stack, optionally with docker-compose lines mixed in."
          };
        }

        /* POSTGRES_PASSWORD */
        (function () {
          var e = entry("POSTGRES_PASSWORD");
          if (!e) {
            add("blocker", "POSTGRES_PASSWORD", null, null,
              "POSTGRES_PASSWORD is missing",
              "No POSTGRES_PASSWORD line was found. The database superuser password is the root of the whole stack; a config without one cannot be graded as safe.",
              "Set a unique, randomly generated POSTGRES_PASSWORD of at least 16 characters.");
            return;
          }
          var v = e.value;
          if (EXAMPLE_POSTGRES_PASSWORDS.indexOf(v.toLowerCase()) !== -1) {
            add("blocker", "POSTGRES_PASSWORD", e.line, v.length,
              "POSTGRES_PASSWORD is a documented example value",
              "The database password is one of the example values printed in the public self-hosting docs. Anyone who has read the docs knows it.",
              "Replace it with a unique, randomly generated password of at least 16 characters and rotate it anywhere it was reused.");
          } else if (v.length < 16) {
            add("blocker", "POSTGRES_PASSWORD", e.line, v.length,
              "POSTGRES_PASSWORD is too short (" + v.length + " characters)",
              "A database superuser password this short can be brute-forced quickly once the database port is reachable.",
              "Use a randomly generated password of at least 16 characters (32 is better).");
          }
        })();

        /* JWT_SECRET */
        (function () {
          var e = entry("JWT_SECRET");
          if (!e) {
            add("blocker", "JWT_SECRET", null, null,
              "JWT_SECRET is missing",
              "No JWT_SECRET line was found. This secret signs every auth token the stack issues; without one set deliberately, token security cannot be graded.",
              "Set a unique, randomly generated JWT_SECRET of at least 32 characters.");
            return;
          }
          var v = e.value;
          if (EXAMPLE_JWT_SECRETS.indexOf(v.toLowerCase()) !== -1) {
            add("blocker", "JWT_SECRET", e.line, v.length,
              "JWT_SECRET is a documented example value",
              "This is the sample secret printed in the public self-hosting examples. Anyone can use it to forge valid tokens for this stack.",
              "Generate a fresh random secret of at least 32 characters and re-issue ANON_KEY and SERVICE_ROLE_KEY from it.");
          } else if (v.length < 32) {
            add("blocker", "JWT_SECRET", e.line, v.length,
              "JWT_SECRET is under 32 characters (" + v.length + ")",
              "Supabase requires a JWT secret of at least 32 characters. Shorter secrets weaken every signed token and can make the auth service fail or fall back insecurely at startup.",
              "Generate a random secret of at least 32 characters, then re-issue ANON_KEY and SERVICE_ROLE_KEY.");
          }
        })();

        /* ANON_KEY / SERVICE_ROLE_KEY */
        [["ANON_KEY", DEMO_ANON_KEY, "anonymous (public) key"],
         ["SERVICE_ROLE_KEY", DEMO_SERVICE_ROLE_KEY, "service role key"]].forEach(function (spec) {
          var key = spec[0], e = entry(key);
          if (!e) {
            add("high", key, null, null,
              key + " is missing",
              "No " + key + " line was found. The stack expects both keys to be issued from your own JWT_SECRET.",
              "Generate " + key + " from your JWT_SECRET using the key generator in the Supabase self-hosting docs.");
            return;
          }
          var v = e.value;
          if (isDemoKey(v)) {
            add("blocker", key, e.line, v.length,
              key + " is the published Supabase demo key",
              "This " + spec[2] + " is the demo key printed in the public documentation — its issuer is literally “supabase-demo” and it is signed with the demo secret. For SERVICE_ROLE_KEY that means full, row-level-security-bypassing database access for anyone on the internet who has read the docs.",
              "Re-issue this key from your own JWT_SECRET and never ship the demo keys outside a throwaway local demo.");
          } else if (v.length < 40) {
            add("high", key, e.line, v.length,
              key + " is obviously short (" + v.length + " characters)",
              "Real Supabase API keys are long JWTs. A value this short is a placeholder or a hand-typed stand-in, not an issued key.",
              "Generate the real key from your JWT_SECRET and paste the full JWT.");
          } else {
            var payload = decodeJwtPayload(v);
            if (payload && payload.iss && payload.iss !== "supabase" && payload.iss !== "supabase-demo") {
              add("low", key, e.line, v.length,
                key + " has an unexpected issuer",
                "The key's JWT issuer claim is not the usual self-hosted value. That can be legitimate for a custom setup, but it is worth confirming the key was issued for this stack.",
                "Confirm the key was generated for this deployment; if not, re-issue it from your JWT_SECRET.");
            }
          }
        });

        /* URLs */
        [["SITE_URL", "the site URL users are redirected to"],
         ["API_EXTERNAL_URL", "the API URL tokens are issued against"],
         ["SUPABASE_PUBLIC_URL", "the public API URL"]].forEach(function (spec) {
          var key = spec[0], e = entry(key);
          if (!e) return;
          var v = e.value, host = hostOf(v);
          var isLocal = host === "localhost" || host === "127.0.0.1" || host === "0.0.0.0" || host === "::1";
          var isPrivate = /^(192\.168\.|10\.|172\.(1[6-9]|2\d|3[0-1])\.)/.test(host);
          if (/^http:\/\//i.test(v)) {
            if (isLocal) {
              add("high", key, e.line, null,
                key + " points at localhost over plain http",
                "In a production paste, " + spec[1] + " is a loopback address. Auth redirects, password-reset links, and issued tokens will point at a machine your users are not on, and plain http sends tokens unencrypted.",
                "Set " + key + " to the real public https URL of this deployment.");
            } else if (isPrivate) {
              add("high", key, e.line, null,
                key + " uses a private LAN address over plain http",
                "This URL only resolves inside your local network and travels unencrypted, so external users get broken auth links and tokens cross the wire in the clear.",
                "Set " + key + " to the real public https URL of this deployment.");
            } else {
              add("high", key, e.line, null,
                key + " is plain http",
                "Tokens, reset links, and session cookies tied to this URL travel unencrypted and can be intercepted or rewritten in transit.",
                "Serve the deployment over https and update " + key + " to the https URL.");
            }
          } else if (/^https:\/\//i.test(v) && isLocal) {
            add("high", key, e.line, null,
              key + " points at localhost",
              "In a production paste this loopback URL breaks auth redirects and emailed links for every real user.",
              "Set " + key + " to the real public URL of this deployment.");
          }
        });

        /* ADDITIONAL_REDIRECT_URLS */
        (function () {
          var e = entry("ADDITIONAL_REDIRECT_URLS");
          if (!e) return;
          if (e.value.indexOf("*") !== -1) {
            add("high", "ADDITIONAL_REDIRECT_URLS", e.line, null,
              "ADDITIONAL_REDIRECT_URLS contains a wildcard",
              "A wildcard redirect URL lets an attacker steer post-login and password-reset redirects to look-alike sites they control, harvesting sessions and reset tokens.",
              "List exact redirect URLs only — full scheme, host, and path, with no * wildcards.");
          }
          if (/http:\/\//i.test(e.value)) {
            add("medium", "ADDITIONAL_REDIRECT_URLS", e.line, null,
              "ADDITIONAL_REDIRECT_URLS includes a plain-http URL",
              "At least one allowed redirect target is plain http, so auth redirects can be intercepted in transit.",
              "Use https URLs for every redirect target.");
          }
        })();

        /* Signup posture */
        (function () {
          var en = entry("ENABLE_SIGNUP"), dis = entry("DISABLE_SIGNUP");
          var enOpen = en && en.value.toLowerCase() === "true";
          var disOpen = dis && dis.value.toLowerCase() === "false";
          var line = enOpen ? en.line : (disOpen ? dis.line : null);
          if (enOpen || disOpen) {
            add("medium", enOpen ? "ENABLE_SIGNUP" : "DISABLE_SIGNUP", line, null,
              "Public signup is switched on",
              "Registration is open, so anyone who can reach the stack can create an account. That is fine for a public product and a hole for a private or internal one — the danger is deploying it open by default without deciding.",
              "If this stack is not meant for public registration, set ENABLE_SIGNUP=false / DISABLE_SIGNUP=true. If it is public, pair it with email confirmation and rate limits.");
          }
        })();

        /* Email autoconfirm */
        (function () {
          var e = entry("ENABLE_EMAIL_AUTOCONFIRM");
          if (e && e.value.toLowerCase() === "true") {
            add("high", "ENABLE_EMAIL_AUTOCONFIRM", e.line, null,
              "ENABLE_EMAIL_AUTOCONFIRM=true",
              "New accounts are confirmed without proving they own the email address. Anyone can register as someone else's email, and password-reset flows become an account-takeover path.",
              "Set ENABLE_EMAIL_AUTOCONFIRM=false so signup requires clicking the confirmation link, unless this is a throwaway local stack.");
          }
        })();

        /* SMTP credentials in plaintext */
        (function () {
          var e = entry("SMTP_PASS");
          if (e && !isPlaceholder(e.value)) {
            add("medium", "SMTP_PASS", e.line, e.value.length,
              "SMTP password sits in the config in plaintext",
              "The mail account password is stored as readable text in this file (reported by length only). Anyone who gets the file — a leaked repo, a backup, a screenshot — gets working mail credentials and can send as your domain.",
              "Inject SMTP_PASS from a secrets manager or the host's secret store at deploy time instead of committing it to the .env, and rotate this password since it has been pasted around.");
          }
        })();

        /* Dashboard password */
        (function () {
          var e = entry("DASHBOARD_PASSWORD");
          if (!e) return;
          var v = e.value;
          if (v.length < 12 || EXAMPLE_POSTGRES_PASSWORDS.indexOf(v.toLowerCase()) !== -1 || v.toLowerCase() === "supabase") {
            add("high", "DASHBOARD_PASSWORD", e.line, v.length,
              "DASHBOARD_PASSWORD is short or guessable (" + v.length + " characters)",
              "This password guards the Studio dashboard — effectively an admin console over the whole database. A short or dictionary password on an internet-reachable dashboard will be found by scanners.",
              "Use a unique, randomly generated dashboard password of at least 16 characters, and keep Studio behind a VPN or IP allowlist where you can.");
          }
        })();

        /* Studio defaults note */
        (function () {
          var org = entry("STUDIO_DEFAULT_ORGANIZATION"), proj = entry("STUDIO_DEFAULT_PROJECT");
          if ((org && /default/i.test(org.value)) || (proj && /^default$/i.test(proj.value))) {
            var e = org && /default/i.test(org.value) ? org : proj;
            add("low", e === org ? "STUDIO_DEFAULT_ORGANIZATION" : "STUDIO_DEFAULT_PROJECT", e.line, null,
              "Studio still carries its default organization / project names",
              "Cosmetic on its own, but untouched defaults are a reliable sign the rest of the example file was deployed as-is — which is exactly how the demo keys above survive into production.",
              "Rename the organization and project to your real ones as a final sweep that the example file was fully reviewed.");
          }
        })();

        /* Logflare keys in plaintext */
        [["LOGFLARE_API_KEY"], ["LOGFLARE_PRIVATE_ACCESS_TOKEN"]].forEach(function (spec) {
          var key = spec[0], e = entry(key);
          if (e && !isPlaceholder(e.value)) {
            add("medium", key, e.line, e.value.length,
              key + " sits in the config in plaintext",
              "The Logflare credential is stored as readable text in this file (reported by length only). Whoever holds it can read or push to your log pipeline, where connection strings and errors tend to accumulate.",
              "Inject the Logflare key from a secrets manager at deploy time and rotate it if this file has been shared.");
          }
        });

        /* JWT_EXP */
        (function () {
          var e = entry("JWT_EXP");
          if (!e) return;
          var n = parseInt(e.value, 10);
          if (!isNaN(n) && n > 86400) {
            add("medium", "JWT_EXP", e.line, null,
              "JWT_EXP is excessively long",
              "Access tokens stay valid for far longer than a day. A leaked token is then a long-lived skeleton key that revocation lists struggle to contain; the usual self-hosted setting is 3600 (one hour).",
              "Set JWT_EXP to 3600 unless you have a documented reason for longer-lived tokens.");
          }
        })();

        /* Published ports */
        portLines.forEach(function (p) {
          var isDb = p.hostPort === "5432", isPooler = p.hostPort === "6543";
          var loopback = p.bindIp === "127.0.0.1" || p.bindIp === "::1";
          if ((isDb || isPooler) && !loopback) {
            add("high", "docker-compose ports", p.line, null,
              (isDb ? "Database" : "Pooler") + " port " + p.hostPort + " is published on all interfaces",
              "This compose line binds the port on 0.0.0.0, so the " + (isDb ? "PostgreSQL server" : "connection pooler") + " is reachable from the whole network — and, on a public host, the whole internet. Database ports are scanned for constantly, and a weak POSTGRES_PASSWORD turns this into a direct breach.",
              'Bind it to loopback instead — "127.0.0.1:' + p.hostPort + ":" + p.hostPort + '" — or drop the published port entirely and let the stack talk internally.');
          } else if (!isDb && !isPooler && p.bindIp === "0.0.0.0") {
            add("low", "docker-compose ports", p.line, null,
              "Port " + p.hostPort + " is explicitly bound to 0.0.0.0",
              "This service port is published on all interfaces. That is normal for the public API gateway, but worth confirming every published port is one you mean to expose.",
              "Confirm this port belongs to a public-facing service; otherwise bind it to 127.0.0.1.");
          }
        });
        (function () {
          var pp = entry("POSTGRES_PORT"), tp = entry("POOLER_PROXY_PORT_TRANSACTION");
          if (pp && portLines.length === 0) {
            add("low", "POSTGRES_PORT", pp.line, null,
              "POSTGRES_PORT is set with no compose port lines to check",
              "The .env names a database port, but no docker-compose port mappings were pasted, so this audit cannot tell whether the database is published on all interfaces.",
              "Paste the compose ports section too, or confirm on the host that the database port is bound to localhost or a private network only.");
          }
          if (tp && portLines.length === 0) {
            add("low", "POOLER_PROXY_PORT_TRANSACTION", tp.line, null,
              "POOLER_PROXY_PORT_TRANSACTION is set with no compose port lines to check",
              "The .env names a pooler port, but no docker-compose port mappings were pasted, so this audit cannot tell whether the pooler is published on all interfaces.",
              "Paste the compose ports section too, or confirm the pooler port is bound deliberately.");
          }
        })();

        findings.sort(function (a, b) {
          if (SEV_ORDER[a.severity] !== SEV_ORDER[b.severity]) return SEV_ORDER[a.severity] - SEV_ORDER[b.severity];
          var la = a.line == null ? 9999 : a.line, lb = b.line == null ? 9999 : b.line;
          return la - lb;
        });

        var counts = { blocker: 0, high: 0, medium: 0, low: 0 };
        findings.forEach(function (f) { counts[f.severity]++; });

        var verdict;
        if (counts.blocker > 0) verdict = "DO NOT DEPLOY";
        else if (counts.high + counts.medium + counts.low > 0) verdict = "DEPLOY WITH FIXES";
        else verdict = "SAFE TO DEPLOY";

        return {
          tool: "J-Dawgs Supabase Server Config Safety Auditor™",
          verdict: verdict,
          gradeable: true,
          recognizedKeys: recognized,
          linesScanned: lines.length,
          counts: counts,
          findings: findings,
          note: verdict === "SAFE TO DEPLOY"
            ? "No blocker, high, medium, or low findings in the pasted text. This grades the paste only — it does not verify a running deployment."
            : "Secrets are reported by key name, line number, and value length only; no secret values appear in this report."
        };
      }

      /* --------------------- report rendering --------------------- */
      function verdictClass(v) {
        if (v === "DO NOT DEPLOY") return "v-blocker";
        if (v === "DEPLOY WITH FIXES") return "v-fixes";
        if (v === "SAFE TO DEPLOY") return "v-safe";
        return "v-unknown";
      }
      function verdictSub(r) {
        if (r.verdict === "DO NOT DEPLOY") return "Blocker findings are present. Fix every blocker before this config goes anywhere near a server.";
        if (r.verdict === "DEPLOY WITH FIXES") return "Nothing here is an automatic breach, but the findings below should be fixed before deployment.";
        if (r.verdict === "SAFE TO DEPLOY") return "The pasted config passed every check in this auditor. It grades the paste only — it cannot verify a running deployment.";
        return r.note;
      }

      function reportToText(r) {
        var out = [];
        out.push("J-Dawgs Supabase Server Config Safety Auditor™ — audit report");
        out.push("Verdict: " + r.verdict);
        out.push("Lines scanned: " + r.linesScanned + " · Recognized Supabase keys: " + r.recognizedKeys);
        out.push("Findings: " + r.counts.blocker + " blocker, " + r.counts.high + " high, " + r.counts.medium + " medium, " + r.counts.low + " low");
        out.push("Secrets are reported by key name, line number, and value length only.");
        out.push("");
        if (!r.findings.length) {
          out.push(r.gradeable ? "No findings." : r.note);
        }
        r.findings.forEach(function (f, i) {
          out.push((i + 1) + ". [" + f.severity.toUpperCase() + "] " + f.key +
            (f.line != null ? " — line " + f.line : " — not present") +
            (typeof f.valueLength === "number" ? " — value length " + f.valueLength : ""));
          out.push("   " + f.title);
          out.push("   " + f.detail);
          out.push("   Fix: " + f.fix);
          out.push("");
        });
        out.push("This report grades pasted text offline. It does not connect to a server or database and cannot verify a running deployment.");
        return out.join("\n");
      }

      function reportToJson(r) {
        return JSON.stringify(r, null, 2);
      }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined), "PROSE_EXAMPLE": (typeof PROSE_EXAMPLE !== 'undefined' ? PROSE_EXAMPLE : undefined), "EXAMPLE_POSTGRES_PASSWORDS": (typeof EXAMPLE_POSTGRES_PASSWORDS !== 'undefined' ? EXAMPLE_POSTGRES_PASSWORDS : undefined), "EXAMPLE_JWT_SECRETS": (typeof EXAMPLE_JWT_SECRETS !== 'undefined' ? EXAMPLE_JWT_SECRETS : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-supabase-server-config-safety-auditortm',
  name: 'J-Dawgs Supabase Server Config Safety Auditor',
  description: 'Grades a pasted self-hosted Supabase .env offline into one deploy verdict, with demo-key and short-secret traps named — secrets reported by key name, line, and length only, never the secret value.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"], "PROSE_EXAMPLE": __core["PROSE_EXAMPLE"], "EXAMPLE_POSTGRES_PASSWORDS": __core["EXAMPLE_POSTGRES_PASSWORDS"], "EXAMPLE_JWT_SECRETS": __core["EXAMPLE_JWT_SECRETS"] }
};
