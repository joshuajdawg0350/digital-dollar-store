'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Flink Cluster Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------------- Examples ---------------- */

      var RISKY_EXAMPLE = [
        "# Flink cluster config — risky example",
        "jobmanager.address: jm.internal",
        "rest.bind-address: 0.0.0.0",
        "rest.port: 8081",
        "web.submit.enable: true",
        "security.ssl.enabled: false",
        "security.ssl.key-password: hunter2",
        "taskmanager.numberOfTaskSlots: 4",
        "parallelism.default: 4",
        "state.backend: filesystem",
        "state.checkpoints.dir: file:///tmp/flink-checkpoints"
      ].join("\n");

      var HARDENED_EXAMPLE = [
        "# Flink cluster config — hardened example",
        "jobmanager.address: jm.internal",
        "rest.bind-address: 10.0.3.15",
        "rest.port: 8081",
        "web.submit.enable: false",
        "security.ssl.enabled: true",
        "security.ssl.keystore: /etc/flink/ssl/keystore.jks",
        "security.ssl.keystore-password: ${env:FLINK_SSL_PW}",
        "security.ssl.key-password: ${env:FLINK_SSL_PW}",
        "taskmanager.numberOfTaskSlots: 4",
        "parallelism.default: 4",
        "high-availability.type: zookeeper",
        "high-availability.zookeeper.quorum: zk1.internal:2181,zk2.internal:2181,zk3.internal:2181",
        "high-availability.storageDir: hdfs:///flink/ha",
        "state.backend: rocksdb",
        "state.checkpoints.dir: hdfs://namenode.internal:8020/flink/checkpoints",
        "execution.checkpointing.interval: 60000"
      ].join("\n");

      /* ---------------- Parsing ---------------- */

      var KNOWN_ROOTS = [
        "jobmanager","taskmanager","rest","web","security","state","execution",
        "high-availability","env","historyserver","metrics","parallelism","blob",
        "fs","s3","checkpointing","classloader","cluster","pipeline","yarn",
        "kubernetes","akka","heartbeat","queryable-state","restart-strategy",
        "slotmanager","resourcemanager","dispatcher","io","flink"
      ];

      function isRecognizedKey(key){
        for (var i=0;i<KNOWN_ROOTS.length;i++){
          var r = KNOWN_ROOTS[i];
          if (key === r || key.indexOf(r + ".") === 0 || key.indexOf(r + "-") === 0) return true;
        }
        return false;
      }

      // Parse paste into entries {line, key (dotted, lowercase), value} plus malformed lines.
      // Handles flat flink-conf.yaml style and simple indented config.yaml nesting.
      function parseConfig(text){
        var lines = String(text).split(/\r?\n/);
        var entries = [], malformed = [];
        var stack = []; // {indent, key}
        for (var i=0;i<lines.length;i++){
          var raw = lines[i];
          var lineNo = i+1;
          var trimmed = raw.replace(/^\s+|\s+$/g,"");
          if (!trimmed) continue;
          if (trimmed.charAt(0) === "#") continue;
          var indent = raw.length - raw.replace(/^\s+/,"").length;
          while (stack.length && stack[stack.length-1].indent >= indent) stack.pop();
          if (trimmed.charAt(0) === "-" && stack.length) continue; // YAML list item under a parent
          var work = trimmed;
          var hashIdx = work.indexOf(" #");
          if (hashIdx > 0) work = work.slice(0, hashIdx).replace(/\s+$/,"");
          var ci = work.indexOf(":");
          if (ci <= 0){ malformed.push({line: lineNo}); continue; }
          var leafKey = work.slice(0, ci).replace(/^\s+|\s+$/g,"").toLowerCase();
          var value = work.slice(ci+1).replace(/^\s+|\s+$/g,"");
          if (!leafKey){ malformed.push({line: lineNo}); continue; }
          var parts = [];
          for (var s=0;s<stack.length;s++) parts.push(stack[s].key);
          parts.push(leafKey);
          var fullKey = parts.join(".");
          if (value === "" && /:$/.test(work)){
            stack.push({indent: indent, key: leafKey});
            continue;
          }
          entries.push({line: lineNo, key: fullKey, value: value});
        }
        return {entries: entries, malformed: malformed, totalLines: lines.length};
      }

      /* ---------------- Audit engine ---------------- */

      var WILDCARD = {"0.0.0.0":1, "::":1, "[::]":1, "*":1};
      var LOCAL = {"localhost":1, "127.0.0.1":1, "::1":1, "[::1]":1};
      var PLACEHOLDERS = {
        "changeme":1,"change-me":1,"change_me":1,"example":1,"test":1,"password":1,
        "secret":1,"xxx":1,"xxxx":1,"todo":1,"replace-me":1,"replaceme":1,
        "your-password":1,"yourpassword":1,"default":1,"none":1,"null":1,"***":1,"...":1,
        "placeholder":1,"dummy":1,"sample":1
      };
      var REST_LISTENER_KEYS = {"rest.bind-address":1, "rest.address":1, "jobmanager.web.address":1};
      var SUBMIT_KEYS = {"web.submit.enable":1, "jobmanager.web.submit.enable":1, "rest.submit.enable":1};
      var FLAMEGRAPH_KEYS = {"rest.flamegraph.enabled":1, "web.flamegraph.enabled":1};
      var SECRET_NAME = /(password|passwd|secret|token|(^|[.\-_])key([.\-_\d]|$)|(^|[.\-_])keys([.\-_\d]|$))/;

      function isTrue(v){ return String(v).toLowerCase() === "true"; }
      function isFalse(v){ return String(v).toLowerCase() === "false"; }
      function stripQuotes(v){
        if (v.length >= 2){
          var a = v.charAt(0), b = v.charAt(v.length-1);
          if ((a === '"' && b === '"') || (a === "'" && b === "'")) return v.slice(1,-1);
        }
        return v;
      }
      function isEnvRef(v){ return v.indexOf("${") !== -1; }
      function isLocalPath(v){
        var s = String(v).toLowerCase();
        return s.indexOf("file:") === 0 || s.charAt(0) === "/";
      }

      function audit(text){
        var parsed = parseConfig(text);
        var entries = parsed.entries;
        var findings = [];
        function add(severity, line, key, message, fix, kind){
          findings.push({severity: severity, line: line, key: key, message: message, fix: fix, kind: kind || "CHECK"});
        }

        var recognized = 0, i, e;
        for (i=0;i<entries.length;i++) if (isRecognizedKey(entries[i].key)) recognized++;

        // Malformed lines are always reported, never guessed at.
        for (i=0;i<parsed.malformed.length;i++){
          add("WARNING", parsed.malformed[i].line, "(unparsed line)",
            "NOT PARSED: this line has no “key: value” separator, so the auditor cannot tell what setting it was meant to be. It was not guessed at, and Flink itself may reject or ignore it.",
            "Rewrite the line as key: value (for example rest.port: 8081), or delete it if it is stray text.",
            "NOT_PARSED");
        }

        if (recognized === 0){
          add("INFO", 1, "(whole paste)",
            entries.length === 0 && parsed.malformed.length === 0
              ? "Nothing recognizable was pasted — the input is empty or blank, so there is no configuration to grade."
              : "No recognizable Flink configuration keys were found in this paste. It may be prose, JSON, or a different tool's configuration format, so there is nothing this auditor can grade.",
            "Paste the contents of a flink-conf.yaml or config.yaml file — lines like rest.bind-address, security.ssl.enabled, state.checkpoints.dir — and run the audit again.",
            "NOT_ENOUGH");
          return finish("NOT ENOUGH TO GRADE",
            "The paste contains no recognizable Flink configuration keys, so no deploy verdict can be given.",
            findings, parsed, recognized);
        }

        function getAll(key){
          var out = [];
          for (var j=0;j<entries.length;j++) if (entries[j].key === key) out.push(entries[j]);
          return out;
        }
        function getFirst(key){ var a = getAll(key); return a.length ? a[0] : null; }
        function anyKey(pred){
          for (var j=0;j<entries.length;j++) if (pred(entries[j].key)) return entries[j];
          return null;
        }

        // --- Cross-cutting posture facts ---
        var restListeners = entries.filter(function(x){ return REST_LISTENER_KEYS[x.key]; });
        var wildcardListener = null, specificListener = null;
        restListeners.forEach(function(x){
          var v = stripQuotes(x.value).toLowerCase();
          if (WILDCARD[v]) wildcardListener = wildcardListener || x;
          else if (!LOCAL[v]) specificListener = specificListener || x;
        });
        var networkBound = !!(wildcardListener || specificListener);

        var submitEntry = null;
        entries.forEach(function(x){ if (SUBMIT_KEYS[x.key] && isTrue(x.value)) submitEntry = submitEntry || x; });

        var sslEntry = getFirst("security.ssl.enabled");
        var sslOn = sslEntry ? isTrue(sslEntry.value) : false;
        var contextFactory = getFirst("security.context.factory");
        var kerberos = anyKey(function(k){ return k.indexOf("security.kerberos") === 0; });
        var postureStated = sslOn || !!contextFactory || !!kerberos;

        // --- REST listener exposure ---
        restListeners.forEach(function(x){
          var v = stripQuotes(x.value).toLowerCase();
          if (WILDCARD[v]){
            if (submitEntry || !postureStated){
              add("BLOCKER", x.line, x.key,
                "The Flink REST API and web UI are bound to all network interfaces (0.0.0.0 / ::), and the configuration gives an attacker a way in: " + (submitEntry ? "job submission through the web UI is enabled, and submitting a job is remote code execution" : "no authentication or TLS posture is stated") + ". Anyone who can reach this host's REST port can take over the cluster.",
                "Bind the REST API to localhost or one specific internal management address, disable web job submission, and put the UI behind an authenticated reverse proxy or firewall rules that only allow your operators' network.",
                "CHECK");
            } else {
              add("HIGH", x.line, x.key,
                "The Flink REST API and web UI are bound to all network interfaces (0.0.0.0 / ::). The REST API can inspect jobs, cancel work, and read cluster details, so exposing it on every interface widens the attack surface to the whole network.",
                "Set rest.bind-address to localhost or a specific internal IP on a management network, or restrict the REST port with firewall rules.",
                "CHECK");
            }
          } else if (!LOCAL[v]){
            add("INFO", x.line, x.key,
              "The REST API and web UI are bound to one specific address rather than all interfaces. That is the safer pattern — just confirm the address sits on a private or management network, not a public one.",
              "No change needed if the address is private. If it is publicly reachable, move it to a management network or behind an authenticated proxy.",
              "CHECK");
          }
        });

        // --- Web job submission / flamegraph ---
        entries.forEach(function(x){
          if (SUBMIT_KEYS[x.key] && isTrue(x.value)){
            add("HIGH", x.line, x.key,
              "Job submission through the web UI / REST API is enabled. Submitting a job means uploading and running arbitrary code, so anyone who can reach the web UI effectively has remote code execution on the cluster.",
              "Set web.submit.enable to false and submit jobs with the CLI or a controlled deployment pipeline instead. If submission must stay on, restrict the REST port to a trusted network and require authentication in front of it.",
              "CHECK");
          }
          if (FLAMEGRAPH_KEYS[x.key] && isTrue(x.value)){
            add("HIGH", x.line, x.key,
              "The REST flamegraph endpoint is enabled. Flamegraphs expose live JVM stack traces and method samples from running jobs to anyone who can reach the REST API — useful debugging data, and useful reconnaissance for an attacker.",
              "Set rest.flamegraph.enabled to false in production, or enable it only temporarily while debugging on a restricted network.",
              "CHECK");
          }
        });

        // --- SSL / TLS posture ---
        if (sslEntry && isFalse(sslEntry.value)){
          if (networkBound){
            add("HIGH", sslEntry.line, sslEntry.key,
              "SSL/TLS is explicitly switched off while the REST/web listeners are bound beyond this host. Credentials, job details, and anything else sent to the web UI or REST API cross the network in plaintext.",
              "Set security.ssl.enabled to true and configure the keystore settings, or confine every listener to localhost and reach the UI through an SSH tunnel or authenticated proxy.",
              "CHECK");
          } else {
            add("WARNING", sslEntry.line, sslEntry.key,
              "SSL/TLS is explicitly switched off. The listeners appear to be local-only in this paste, so the exposure is limited — but the moment any listener is bound to a network address, all REST/web traffic is plaintext.",
              "Enable security.ssl.enabled with a proper keystore before binding any listener to a network address.",
              "CHECK");
          }
        } else if (!sslEntry && networkBound){
          var anchor = wildcardListener || specificListener;
          add("WARNING", anchor.line, "security.ssl.enabled",
            "No security.ssl.enabled setting is stated, while a REST/web listener is bound beyond this host. Unless TLS is terminated elsewhere, REST and web UI traffic to this cluster is plaintext.",
            "Set security.ssl.enabled to true with keystore settings, or document that TLS is terminated at an authenticated proxy in front of the cluster.",
            "CHECK");
        }

        // --- Authentication posture ---
        if (!postureStated){
          var authAnchor = restListeners.length ? restListeners[0] : entries[0];
          add("INFO", authAnchor.line, "security.*",
            "AUTH NOT STATED — cannot confirm: this paste names no security context factory, no Kerberos settings, and does not turn SSL on, so the auditor cannot confirm any authentication protects the REST API and web UI. Flink's built-in REST/web layer has no user login of its own; authentication is normally added with a proxy, firewall, or Kerberos/SSO in front of it.",
            "State the posture explicitly: enable SSL, note the Kerberos or security context settings if you use them, or document the authenticated proxy / network controls that front the cluster.",
            "CHECK");
        }

        // --- Secrets (key name + value length only; value is never rendered) ---
        entries.forEach(function(x){
          if (!SECRET_NAME.test(x.key)) return;
          var v = stripQuotes(x.value);
          if (!v) return;
          if (isEnvRef(v)) return; // ${env:...} / ${...} references are the safe pattern
          var lower = v.toLowerCase();
          var placeholder = v.length < 16 || PLACEHOLDERS[lower] || /^x{2,}$/i.test(v) || /^\*+$/.test(v) || lower.indexOf("example") === 0 || lower.indexOf("changeme") === 0;
          if (placeholder){
            add("BLOCKER", x.line, x.key,
              "This key holds a secret typed directly into the config, and the value is only " + v.length + " characters long — a placeholder, example, or very short value. A guessable credential in a deployed config is effectively no credential. (The value itself is never shown in this report — only its length.)",
              "Replace it with a real, long, unique secret delivered through an environment reference such as ${env:MY_SECRET} or a secrets manager, and rotate the old value if it was ever real.",
              "CHECK");
          } else {
            add("HIGH", x.line, x.key,
              "This key holds a secret typed directly into the config in plaintext (value length: " + v.length + " characters — the value itself is never shown in this report). Anyone who can read this file, a backup of it, or a repo it lands in gets the credential.",
              "Move the secret out of the file: reference it as ${env:MY_SECRET} or inject it from a secrets manager at deploy time, and rotate it if the config was ever shared or committed.",
              "CHECK");
          }
        });

        // --- Checkpoint / savepoint / HA storage on local paths ---
        var slotEntry = getFirst("taskmanager.numberoftaskslots");
        var slots = slotEntry ? parseInt(slotEntry.value, 10) : NaN;
        var parEntry = getFirst("parallelism.default");
        var par = parEntry ? parseInt(parEntry.value, 10) : NaN;
        var tmKeys = {};
        entries.forEach(function(x){ if (x.key.indexOf("taskmanager.") === 0) tmKeys[x.key] = 1; });
        var tmKeyCount = Object.keys(tmKeys).length;
        var multipleTM = (slots > 1) || (par > 1) || tmKeyCount >= 2;
        var clustered = multipleTM || networkBound ||
          !!anyKey(function(k){ return k.indexOf("kubernetes.") === 0 || k.indexOf("yarn.") === 0 || k.indexOf("cluster.") === 0; });

        ["state.checkpoints.dir","state.savepoints.dir"].forEach(function(key){
          getAll(key).forEach(function(x){
            if (isLocalPath(x.value)){
              if (clustered || x.value.toLowerCase().indexOf("/tmp") !== -1){
                add("WARNING", x.line, x.key,
                  "Checkpoints/savepoints point at a local filesystem path on one host. In a cluster, that storage dies with the host: if the machine or its disk is lost, the checkpoints are gone and jobs cannot recover from them.",
                  "Point " + key + " at shared, durable storage every node can reach — for example an hdfs:// or s3:// URI — instead of a local file:// path.",
                  "CHECK");
              } else {
                add("INFO", x.line, x.key,
                  "Checkpoints/savepoints point at a local filesystem path. That is fine for a single-host development setup, but the checkpoints are lost if that host dies.",
                  "Before running this as a real cluster, move checkpoint storage to shared storage such as hdfs:// or s3://.",
                  "CHECK");
              }
            }
          });
        });
        getAll("high-availability.storagedir").concat(getAll("high-availability.zookeeper.storagedir")).forEach(function(x){
          if (isLocalPath(x.value)){
            add("WARNING", x.line, x.key,
              "High-availability metadata is stored on a local filesystem path. If that host is lost, the HA state the standby JobManagers need for failover is lost with it.",
              "Store HA metadata on shared storage (hdfs:// or s3://) that every JobManager host can reach.",
              "CHECK");
          }
        });

        // --- Checkpointing interval ---
        if (!getFirst("execution.checkpointing.interval")){
          var cpAnchor = getFirst("state.checkpoints.dir") || getFirst("state.backend") || entries[0];
          add("INFO", cpAnchor.line, "execution.checkpointing.interval",
            "No execution.checkpointing.interval is set in this config. Checkpointing may still be enabled in job code, but nothing in the cluster configuration guarantees it — jobs that rely on checkpoints for recovery may be running without them.",
            "Set execution.checkpointing.interval (for example 60000 for one minute) if the jobs on this cluster are expected to checkpoint.",
            "CHECK");
        }

        // --- High availability ---
        var haEntry = getFirst("high-availability.type");
        if (!haEntry && multipleTM){
          var tmAnchor = slotEntry || entries.filter(function(x){ return x.key.indexOf("taskmanager.") === 0; })[0] || entries[0];
          add("WARNING", tmAnchor.line, "high-availability.type",
            "No high-availability mode is configured, but this config describes a multi-TaskManager cluster (task slots / parallelism above 1). Without HA, the JobManager is a single point of failure: if it dies, every job on the cluster dies with it and needs a manual restart.",
            "Set high-availability.type (for example zookeeper or kubernetes) with matching quorum and storage settings, or accept and document the single-JobManager risk.",
            "CHECK");
        } else if (haEntry && haEntry.value.toLowerCase() === "none"){
          if (multipleTM){
            add("WARNING", haEntry.line, haEntry.key,
              "High availability is explicitly set to none in a config that describes a multi-TaskManager cluster. The JobManager is a single point of failure: if it dies, all jobs stop until someone restarts it by hand.",
              "Set high-availability.type to zookeeper or kubernetes with matching storage, or document why a single JobManager is acceptable here.",
              "CHECK");
          } else {
            add("INFO", haEntry.line, haEntry.key,
              "High availability is set to none. That is a reasonable choice for a single-host setup, but the JobManager remains a single point of failure.",
              "No change needed for a single host. For a real cluster, configure high-availability.type with ZooKeeper or Kubernetes HA.",
              "CHECK");
          }
        }

        // --- HistoryServer exposure ---
        getAll("historyserver.web.address").forEach(function(x){
          if (WILDCARD[stripQuotes(x.value).toLowerCase()]){
            add("WARNING", x.line, x.key,
              "The HistoryServer web UI is bound to all network interfaces. It serves completed-job details — job graphs, metrics, and exception traces — to anyone who can reach the port.",
              "Bind historyserver.web.address to localhost or a specific internal address, or restrict its port with firewall rules.",
              "CHECK");
          }
        });

        // --- Debug logging / java opts ---
        entries.forEach(function(x){
          var isJavaOpts = x.key.indexOf("env.java.opts") === 0;
          var isLogKey = x.key.indexOf("log") !== -1;
          if ((isJavaOpts && /debug/i.test(x.value)) || (isLogKey && stripQuotes(x.value).toUpperCase() === "DEBUG")){
            add("INFO", x.line, x.key,
              "Debug-level logging or debug options appear to be switched on. That fits a troubleshooting session, not steady production: debug logs are noisy, slower, and can record job data and configuration details you would not want in log files.",
              "Drop the level back to INFO for normal running, and turn DEBUG on only while actively diagnosing a problem.",
              "CHECK");
          }
        });

        // --- Verdict ---
        var counts = countSeverities(findings);
        var verdict, why;
        if (counts.blocker > 0){
          verdict = "DO NOT DEPLOY";
          why = counts.blocker + " blocker finding(s) must be fixed before this configuration goes anywhere near a real cluster.";
        } else if (counts.high > 0 || counts.warning > 0){
          verdict = "DEPLOY WITH FIXES";
          why = "No blockers, but " + (counts.high + counts.warning) + " high/warning finding(s) should be fixed first — each one below names the line and the fix.";
        } else {
          verdict = "SAFE TO DEPLOY";
          why = "No blocker, high, or warning findings in the pasted configuration. Info notes, if any, are listed below. This grades the pasted text only — it does not verify a live cluster.";
        }
        return finish(verdict, why, findings, parsed, recognized);
      }

      function countSeverities(findings){
        var c = {blocker:0, high:0, warning:0, info:0, notParsed:0};
        findings.forEach(function(f){
          if (f.kind === "NOT_PARSED") c.notParsed++;
          else if (f.severity === "BLOCKER") c.blocker++;
          else if (f.severity === "HIGH") c.high++;
          else if (f.severity === "WARNING") c.warning++;
          else if (f.severity === "INFO") c.info++;
        });
        return c;
      }

      var SEV_RANK = {BLOCKER:0, HIGH:1, WARNING:2, INFO:3};
      function finish(verdict, why, findings, parsed, recognized){
        findings.sort(function(a,b){
          var ka = a.kind === "NOT_PARSED" ? 2 : SEV_RANK[a.severity];
          var kb = b.kind === "NOT_PARSED" ? 2 : SEV_RANK[b.severity];
          if (ka !== kb) return ka - kb;
          return a.line - b.line;
        });
        return {
          verdict: verdict, why: why, findings: findings,
          counts: countSeverities(findings),
          totalLines: parsed.totalLines, recognized: recognized,
          notParsed: parsed.malformed.length
        };
      }

      /* ---------------- Rendering ---------------- */

      function esc(s){
        return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
      }
      function sevClass(f){
        if (f.kind === "NOT_PARSED") return "notparsed";
        return f.severity.toLowerCase();
      }
      function sevLabel(f){
        if (f.kind === "NOT_PARSED") return "Not parsed";
        return f.severity;
      }
      function findingHTML(f){
        return '<div class="finding">' +
          '<div class="fhead"><span class="sev ' + sevClass(f) + '">' + esc(sevLabel(f)) + '</span>' +
          '<span class="fkey">' + esc(f.key) + '</span>' +
          '<span class="fline">Line ' + f.line + '</span></div>' +
          '<p>' + esc(f.message) + '</p>' +
          '<p class="fix"><b>Fix:</b> ' + esc(f.fix) + '</p></div>';
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-flink-cluster-config-safety-auditortm',
  name: 'J-Dawgs Flink Cluster Config Safety Auditor',
  description: 'Flink startup answers will-it-start only; ours grades a pasted flink-conf.yaml / config.yaml offline — REST bind and web-submit exposure, SSL and auth posture, checkpoint/HA storage, secrets by key name, line, and length only — into one deploy verdict (SAFE TO DEPLOY / DEPLOY WITH FIXES / DO NOT DEP',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
