'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Thanos Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

/* ---------------- Worked examples (line numbers are load-bearing) ---------------- */
var RISKY_LINES = [
  "# RISKY EXAMPLE - Thanos components (audit me)",          // 1
  "component: query",                                        // 2
  "--http-address=0.0.0.0:10902",                            // 3
  "--http-address=0.0.0.0:10902",                            // 4  (duplicate of line 3)
  "--grpc-address=0.0.0.0:10901",                            // 5
  "--web.external-url=http://thanos.example.com:10902",      // 6
  "--grpc-client-tls-insecure-skip-verify=true",             // 7
  "component: compactor",                                    // 8
  "--retention-resolution-raw=0d",                           // 9
  "--retention-resolution-5d=0",                             // 10
  "--downsampling.disable=true",                             // 11
  "component: receiver",                                     // 12
  "--remote-write.address=0.0.0.0:19291",                    // 13
  "component: ruler",                                        // 14
  "--web.enable-admin-api",                                  // 15
  "--enable-feature=debug-pprof",                            // 16
  "type: S3",                                                // 17
  "config:",                                                 // 18
  "  bucket: thanos-data",                                   // 19
  "  endpoint: http://minio.internal:9000",                  // 20
  "  access_key: minioadmin",                                // 21
  "  secret_key: Tr0pic!Thunder-99xQ",                       // 22
  "  insecure: true",                                        // 23
  "this line cannot be parsed ???"                           // 24
];

var HARDENED_LINES = [
  "# HARDENED EXAMPLE - Thanos components",                  // 1
  "component: query",                                        // 2
  "--http-address=127.0.0.1:10902",                          // 3
  "--grpc-address=127.0.0.1:10901",                          // 4
  "--web.external-url=https://thanos.example.com",           // 5
  "--query.enable-dedup=true",                               // 6
  "--query.replica-label=replica",                           // 7
  "--grpc-server-tls-cert=/etc/thanos/tls/server.crt",       // 8
  "--grpc-server-tls-key=/etc/thanos/tls/server.key",        // 9
  "--grpc-server-tls-client-ca=/etc/thanos/tls/ca.crt",      // 10
  "--grpc-client-tls-secure=true",                           // 11
  "component: compactor",                                    // 12
  "--retention-resolution-raw=30d",                          // 13
  "--retention-resolution-5d=180d",                          // 14
  "--downsampling.disable=false",                            // 15
  "component: receiver",                                     // 16
  "--remote-write.address=127.0.0.1:19291",                  // 17
  "--web.basic-auth-enabled=true",                           // 18
  "component: store-gateway",                                // 19
  "--http-address=127.0.0.1:10912",                          // 20
  "type: S3",                                                // 21
  "config:",                                                 // 22
  "  bucket: thanos-data",                                   // 23
  "  endpoint: s3.amazonaws.com",                            // 24
  "  access_key: ${env:THANOS_S3_ACCESS_KEY}",               // 25
  "  secret_key: ${env:THANOS_S3_SECRET_KEY}",               // 26
  "  insecure: false"                                        // 27
];

/* ---------------- Auditor ---------------- */
var SECRET_KEYS = {
  access_key:1, secret_key:1, service_account:1, storage_account_key:1,
  password:1, passwd:1, secret:1, api_key:1, private_key:1, client_secret:1
};
var WELL_KNOWN = {
  "minioadmin":1, "password":1, "password123":1, "changeme":1, "change-me":1,
  "secret":1, "admin":1, "letmein":1, "thanos":1, "test1234":1, "12345678":1,
  "123456789":1, "1234567890":1, "example":1, "demo":1, "default":1
};
var COMPONENT_WORDS = ["query-frontend","query","sidecar","store-gateway","store","compactor","ruler","receiver","rule"];
var SEV_RANK = {BLOCKER:0, HIGH:1, WARNING:2, INFO:3};

function isSecretKey(name){
  var n = name.toLowerCase().replace(/-/g,"_");
  if (SECRET_KEYS[n]) return true;
  if (/(password|secret_key|access_key|api_key|storage_account_key|service_account)/.test(n)) return true;
  return false;
}
function truthy(v){
  if (v === null || v === undefined) return true; /* bare flag present */
  var s = String(v).toLowerCase();
  return s === "true" || s === "1" || s === "yes" || s === "on";
}
function isRefValue(v){
  var s = String(v).trim();
  return /^\$\{(env|file):/i.test(s) || /^\$\{env:/i.test(s) ||
         /^file:/i.test(s) || /^env:/i.test(s) ||
         /^\//.test(s) || /\.(json|pem|key|crt)$/i.test(s);
}
function bindsAll(v){
  var s = String(v||"");
  return s.indexOf("0.0.0.0") !== -1 || s.indexOf("[::]") !== -1 || s.indexOf("::") === 0 || /^:\d+$/.test(s);
}

function audit(text){
  var lines = String(text||"").split(/\r?\n/);
  var findings = [];
  var seenFinding = {};
  function add(sev, line, check, msg){
    var k = sev+"|"+line+"|"+check;
    if (seenFinding[k]) return;
    seenFinding[k] = 1;
    findings.push({severity:sev, line:line, check:check, message:msg});
  }

  var signals = 0;               /* recognizable-Thanos evidence */
  var section = "top";
  var seenKeys = {};             /* section|key -> first line */
  var hasGrpcAddress = null;     /* line number */
  var hasServerTLS = false;
  var hasAnyTLS = false;
  var hasAuth = false;
  var components = {};
  var hasDedup = false, hasReplica = false, hasQuery = false;
  var receiverLines = [], rulerLines = [];

  function noteDuplicate(key, lineNo){
    var id = section + "|" + key.toLowerCase();
    if (seenKeys[id] !== undefined){
      add("WARNING", lineNo, "Duplicate key",
        "Duplicate key '" + key + "' on lines " + seenKeys[id] + " and " + lineNo +
        ". Both were kept in the paste; in Thanos the last value wins, so the line " + seenKeys[id] +
        " setting is silently overridden.");
    } else {
      seenKeys[id] = lineNo;
    }
  }

  function checkSecret(name, rawValue, lineNo){
    var v = String(rawValue||"").replace(/^["']|["']$/g,"").trim();
    if (!v){
      add("INFO", lineNo, "Credential reference",
        "Credential key '" + name + "' on line " + lineNo + " has no inline value in the paste; nothing plaintext to grade.");
      return;
    }
    if (isRefValue(v)){
      add("INFO", lineNo, "Credential reference",
        "Credential key '" + name + "' on line " + lineNo + " uses an environment or file reference rather than an inline value. Treated as safe; the referenced value itself was not pasted and cannot be graded here.");
      return;
    }
    var extra = "";
    if (v.length < 12 || WELL_KNOWN[v.toLowerCase()]){
      extra = " It is also short or matches a well-known published example value, so it must be treated as compromised.";
    }
    add("BLOCKER", lineNo, "Plaintext credential",
      "Plaintext credential in key '" + name + "' on line " + lineNo + " (value length: " + v.length +
      " characters; the value itself is never shown in this audit)." + extra +
      " Move it to an environment variable, a mounted secret file, or a secret manager and reference it instead.");
  }

  function checkFlag(name, value, lineNo){
    var n = name.toLowerCase();
    /* TLS posture bookkeeping */
    if (n.indexOf("grpc-server-tls-cert") !== -1) { hasServerTLS = true; hasAnyTLS = true; }
    if (n.indexOf("tls-secure") !== -1 && truthy(value)) { hasAnyTLS = true; }
    if (n === "grpc-address" && hasGrpcAddress === null) hasGrpcAddress = lineNo;
    if (/basic-auth|bearer|auth-token|tls-client-ca/.test(n)) hasAuth = true;
    if (n.indexOf("dedup") !== -1) hasDedup = true;
    if (n.indexOf("replica-label") !== -1) hasReplica = true;
    if (n.indexOf("query") === 0) hasQuery = true;

    /* secrets carried in flags */
    if (isSecretKey(n) && value !== null && value !== ""){
      checkSecret(name, value, lineNo);
      return;
    }
    /* all-interface listeners */
    if (/(http-address|grpc-address|listen-address|remote-write\.address|address)$/.test(n) && bindsAll(value)){
      if (hasAnyTLS){
        add("WARNING", lineNo, "Listener on all interfaces",
          "Listener flag '--" + name + "' on line " + lineNo + " binds to all interfaces (0.0.0.0 / wildcard). TLS settings are present elsewhere in the paste, but confirm this listener itself is the one protected and that a firewall or private network still fronts it.");
      } else {
        add("HIGH", lineNo, "Listener on all interfaces, no TLS",
          "Listener flag '--" + name + "' on line " + lineNo + " binds to all interfaces (0.0.0.0 / wildcard) and no TLS posture appears anywhere in the paste. Anyone who can reach the port can reach the service. Bind to a private address or loopback, or put TLS and network controls in front of it.");
      }
    }
    /* plain http endpoints */
    if (value && /^http:\/\//i.test(String(value))){
      add("HIGH", lineNo, "Plain HTTP endpoint",
        "Flag '--" + name + "' on line " + lineNo + " points at a plain http:// endpoint. Traffic, queries, and any credentials in transit are unencrypted. Use https:// with valid certificates.");
    }
    /* insecure TLS flags */
    if (n.indexOf("insecure") !== -1 && truthy(value)){
      add("HIGH", lineNo, "TLS verification disabled",
        "Flag '--" + name + "' on line " + lineNo + " disables TLS verification or marks the connection insecure. Certificate checks exist to stop impersonation; remove this flag and fix the certificate chain instead.");
    }
    /* retention */
    if (n.indexOf("retention") !== -1){
      var rv = String(value||"").toLowerCase();
      if (rv === "0" || rv === "0d" || rv === "0h" || rv === "0s" || rv === "disabled" || rv === "infinite" || rv === "forever" || rv === "-1"){
        add("HIGH", lineNo, "Compactor retention disabled",
          "Retention flag '--" + name + "' on line " + lineNo + " is set to zero / disabled / effectively infinite. Blocks are never deleted at this resolution, so object storage grows without bound. Set a finite retention that matches your storage budget.");
      }
    }
    /* downsampling */
    if (n.indexOf("downsampling") !== -1 && n.indexOf("disable") !== -1 && truthy(value)){
      add("WARNING", lineNo, "Downsampling disabled",
        "Flag '--" + name + "' on line " + lineNo + " disables downsampling. Long-range queries will scan raw-resolution data and cost more CPU and storage bandwidth. Re-enable downsampling unless you have measured a reason not to.");
    }
    /* admin / debug / pprof */
    if (n.indexOf("enable-admin-api") !== -1 && truthy(value)){
      add("HIGH", lineNo, "Admin API exposed",
        "Flag '--" + name + "' on line " + lineNo + " enables the admin API, which can delete data and change runtime state. Keep it off, or gate it behind authentication and a private listener.");
    }
    var combined = n + " " + String(value || "");
    if (combined.indexOf("pprof") !== -1 || (n.indexOf("debug") !== -1 && truthy(value))){
      add("WARNING", lineNo, "Debug / pprof surface",
        "Flag '--" + name + "' on line " + lineNo + " enables a debug or profiling (pprof) surface. Profiling endpoints leak runtime internals and can be abused for denial of service. Disable them outside a controlled debugging session.");
    }
    /* remote-write receiver bind handled by listener check; component noted globally */
  }

  function checkYaml(key, value, lineNo){
    var n = key.toLowerCase();
    if (isSecretKey(n)){
      checkSecret(key, value, lineNo);
      return;
    }
    if (n === "insecure" && truthy(value)){
      add("HIGH", lineNo, "TLS verification disabled",
        "Setting 'insecure: true' on line " + lineNo + " disables TLS verification for this connection. Remove it and fix the endpoint's certificate instead.");
    }
    if ((n === "endpoint" || n === "url" || n === "external-url") && value && /^http:\/\//i.test(value)){
      add("HIGH", lineNo, "Plain HTTP endpoint",
        "Setting '" + key + "' on line " + lineNo + " uses a plain http:// endpoint. Traffic to it is unencrypted. Use https:// with valid certificates.");
    }
    if (n === "endpoint" || n === "bucket") signals++;
  }

  for (var i = 0; i < lines.length; i++){
    var lineNo = i + 1;
    var raw = lines[i];
    var line = raw.trim();
    if (!line) continue;
    if (line.charAt(0) === "#") continue;
    if (line === "\\") continue;

    var parsed = false;

    /* component header: "component: query" */
    var compM = line.match(/^component\s*:\s*([a-z-]+)\s*$/i);
    if (compM){
      section = compM[1].toLowerCase();
      components[section] = lineNo;
      signals++;
      parsed = true;
      if (section === "receiver") receiverLines.push(lineNo);
      if (section === "ruler") rulerLines.push(lineNo);
      if (section.indexOf("query") !== -1) hasQuery = true;
    }

    /* "thanos <component> ..." command lines */
    var thM = line.match(/^thanos\s+([a-z-]+)/i);
    if (thM && COMPONENT_WORDS.indexOf(thM[1].toLowerCase()) === -1) thM = null;
    if (thM){
      section = thM[1].toLowerCase();
      components[section] = lineNo;
      signals++;
      parsed = true;
      if (section === "receiver") receiverLines.push(lineNo);
      if (section === "ruler") rulerLines.push(lineNo);
      if (section.indexOf("query") !== -1) hasQuery = true;
    }

    /* flags anywhere on the line */
    var flagRe = /--([A-Za-z0-9._-]+)(?:=([^\s\\]+))?/g, fm, sawFlag = false;
    while ((fm = flagRe.exec(line)) !== null){
      sawFlag = true; parsed = true;
      var fname = fm[1], fval = (fm[2] !== undefined ? fm[2] : null);
      if (/^(http-address|grpc-address|web\.|query\.|retention|remote-write|objstore|downsampling)/i.test(fname)) signals++;
      if (fname.toLowerCase().indexOf("remote-write") !== -1 && receiverLines.indexOf(lineNo) === -1 && section !== "receiver"){
        /* remote-write flag implies a receiver even without a header */
        if (!components.receiver) { components.receiver = lineNo; receiverLines.push(lineNo); }
      }
      noteDuplicate("--" + fname, lineNo);
      checkFlag(fname, fval, lineNo);
    }
    if (sawFlag) continue;

    /* environment-style: KEY=value (optionally export) */
    var envM = line.match(/^(?:export\s+)?([A-Za-z][A-Za-z0-9_]*)=(\S*)$/);
    if (envM){
      parsed = true;
      var ekey = envM[1], eval_ = envM[2];
      if (/^THANOS_/i.test(ekey) || /objstore|s3_endpoint/i.test(ekey)) signals++;
      if (isSecretKey(ekey)) { noteDuplicate(ekey, lineNo); checkSecret(ekey, eval_, lineNo); continue; }
      if (eval_ && /^http:\/\//i.test(eval_)){
        add("HIGH", lineNo, "Plain HTTP endpoint",
          "Setting '" + ekey + "' on line " + lineNo + " uses a plain http:// endpoint. Use https:// with valid certificates.");
      }
      continue;
    }

    /* YAML key: value */
    var yM = line.match(/^([A-Za-z0-9_.-]+)\s*:\s*(.*)$/);
    if (yM){
      parsed = true;
      var ykey = yM[1], yval = yM[2].replace(/^["']|["']$/g,"");
      var yl = ykey.toLowerCase();
      if (yl === "type" && /^(s3|gcs|azure|swift|filesystem|cos|aliyunoss)$/i.test(yval)) { section = "objstore"; signals++; continue; }
      if (yl === "config" && yval === "") continue;
      if (isSecretKey(yl) || yl === "bucket" || yl === "endpoint" || yl === "insecure") signals++;
      noteDuplicate(ykey, lineNo);
      checkYaml(ykey, yval, lineNo);
      continue;
    }

    if (!parsed){
      add("WARNING", lineNo, "NOT PARSED",
        "Line " + lineNo + " could not be parsed as a flag, an environment-style setting, or YAML. It was not guessed at and none of its content was graded. Re-paste it in one of those forms to have it audited.");
    }
  }

  /* -------- cross-line checks -------- */
  if (hasGrpcAddress !== null && !hasServerTLS){
    add("HIGH", hasGrpcAddress, "Missing gRPC server TLS",
      "A gRPC listener is configured (line " + hasGrpcAddress + ") but no --grpc-server-tls-cert / --grpc-server-tls-key settings appear in the paste. Remote Thanos components (query, store gateway, sidecar) exchange data over this channel; without server TLS it runs in plaintext. Configure mutual TLS for component-to-component gRPC.");
  }
  if (components.receiver && !hasAuth){
    var rl = receiverLines[0] || components.receiver;
    add("HIGH", rl, "Receiver without authentication",
      "A Receiver is configured (first seen on line " + rl + ") and no authentication posture appears anywhere in the paste — no basic auth, bearer token, or TLS client-certificate requirement. An unauthenticated remote-write endpoint accepts metrics from anyone who can reach it. Add authentication and restrict the listener.");
  }
  if (components.ruler && !hasAuth){
    var ul = rulerLines[0] || components.ruler;
    add("WARNING", ul, "Ruler without authentication",
      "A Ruler is configured (first seen on line " + ul + ") and no authentication posture appears anywhere in the paste. Rule and alert APIs should sit behind authentication and a private listener.");
  }
  if (hasQuery && !hasDedup){
    add("WARNING", components.query || 1, "Query deduplication not configured",
      "A Query component is present but no deduplication flag (for example --query.enable-dedup) appears in the paste. Without deduplication, replicated series are returned multiple times and queries cost more. Enable deduplication and set matching replica labels on sidecars and rulers.");
  }
  if (hasQuery && !hasReplica){
    add("WARNING", components.query || 1, "Replica labels not configured",
      "A Query component is present but no replica label setting (for example --query.replica-label) appears in the paste. Deduplication needs a replica label to tell replicated series apart from distinct ones.");
  }

  findings.sort(function(a,b){
    if (SEV_RANK[a.severity] !== SEV_RANK[b.severity]) return SEV_RANK[a.severity] - SEV_RANK[b.severity];
    return a.line - b.line;
  });

  var counts = {BLOCKER:0, HIGH:0, WARNING:0, INFO:0};
  findings.forEach(function(f){ counts[f.severity]++; });

  var recognized = signals >= 2;
  var verdict;
  if (!recognized) verdict = "NOT ENOUGH TO GRADE";
  else if (counts.BLOCKER > 0) verdict = "DO NOT DEPLOY";
  else if (counts.HIGH > 0 || counts.WARNING > 0) verdict = "DEPLOY WITH FIXES";
  else verdict = "SAFE TO DEPLOY";

  return {verdict:verdict, findings:findings, counts:counts, recognized:recognized, lineCount:lines.length};
}
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-thanos-server-config-safety-auditor',
  name: 'J-Dawgs Thanos Server Config Safety Auditor',
  description: 'Grades a pasted Thanos server configuration (flags/YAML/objstore) fully offline into one deploy verdict — objstore and storage credentials, retention and compaction posture, and plaintext secrets shown by key name, line, and length only. Thanos only exercises a config by starting on it; this grades ',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
