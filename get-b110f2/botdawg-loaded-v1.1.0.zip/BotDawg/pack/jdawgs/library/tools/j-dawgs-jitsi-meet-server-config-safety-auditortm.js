'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Jitsi Meet Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

  "use strict";

  var RISKY = [
    "domain: 'meet.example.com',",
    "anonymousdomain: 'guest.meet.example.com',",
    "enableGuestAccess: true,",
    "authentication: 'anonymous',",
    "bosh: 'http://meet.example.com/http-bind',",
    "websocket: 'ws://meet.example.com/xmpp-websocket',",
    "enableLobby: false,",
    "disableDeepLinking: false,",
    "app_id: 'my-jitsi-app',",
    "app_secret: 'example-secret',",
    "JVB_SECRET=short1",
    "JICOFO_SECRET=abc123",
    "recordingEnabled: true,",
    "jibriPassword: 'jibri-pass-123',",
    "rtmpStreamKey: 'live-rtmp-9999',",
    "allowPublicRoomCreation: true,"
  ].join("\n");

  var HARDENED = [
    "domain: 'meet.example.com',",
    "authdomain: 'meet.example.com',",
    "authentication: 'internal_hashed',",
    "enableGuestAccess: false,",
    "bosh: 'https://meet.example.com/http-bind',",
    "websocket: 'wss://meet.example.com/xmpp-websocket',",
    "enableLobby: true,",
    "disableDeepLinking: true,",
    "app_id: 'my-jitsi-app',",
    "app_secret: '${JITSI_APP_SECRET}',",
    "JVB_SECRET=${JVB_SECRET}",
    "JICOFO_SECRET=${JICOFO_SECRET}",
    "recordingEnabled: false,",
    "allowPublicRoomCreation: false,"
  ].join("\n");

  var PLANTED_SECRETS = ["example-secret","short1","abc123","jibri-pass-123","live-rtmp-9999"];

  var KNOWN = ["domain","bosh","websocket","guest","auth","app_id","app_secret","secret",
    "pass","token","jibri","record","rtmp","lobby","deeplink","external","muc","focus",
    "videobridge","jvb","jicofo","prosody","room","anonymous","host","enable","disable",
    "stream","xmpp","conference","jwt","ldap","welcome","livestream"];

  var SEV_ORDER = {CRITICAL:0, HIGH:1, MEDIUM:2, LOW:3, INFO:4};

  function isTrueV(v){
    var s = String(v).toLowerCase();
    return s==="true"||s==="1"||s==="yes"||s==="on"||s==="allow"||s==="allowed"||s==="enabled";
  }
  function isFalseV(v){
    var s = String(v).toLowerCase();
    return s==="false"||s==="0"||s==="no"||s==="off"||s==="disabled"||s==="deny"||s==="denied";
  }
  function isEnvRef(raw, clean){
    var s = String(raw||"") + " " + String(clean||"");
    return s.indexOf("${") !== -1 || s.indexOf("process.env") !== -1 ||
           s.indexOf("$ENV") !== -1 || s.indexOf("{{") !== -1 ||
           /^\s*env:/i.test(String(clean||""));
  }
  function isPlaceholder(clean){
    var s = String(clean||"").toLowerCase();
    return s.indexOf("changeme") !== -1 || s.indexOf("change_me") !== -1 ||
           s.indexOf("change-me") !== -1 || s.indexOf("example") !== -1 ||
           s.indexOf("your_") !== -1 || s.indexOf("your-") !== -1 ||
           s.indexOf("placeholder") !== -1 || s.indexOf("todo") !== -1 ||
           s === "xxx" || s === "default" || s === "password" || s === "secret";
  }
  function isLocalHost(host){
    return host === "localhost" || host === "127.0.0.1" || host === "::1" ||
           host === "[::1]" || /\.local$/.test(host);
  }

  // Parse one raw line into {key, valueClean, valueRaw} or null.
  function parseKV(text){
    var m = /^\s*['"]?([A-Za-z0-9_][A-Za-z0-9_.\-]*)['"]?\s*[:=]\s*(.*)$/.exec(text);
    if(!m) return null;
    var key = m[1];
    var rest = String(m[2] || "").trim();
    var clean;
    if(rest.charAt(0) === "'" || rest.charAt(0) === '"'){
      var q = rest.charAt(0);
      var end = rest.indexOf(q, 1);
      clean = (end === -1) ? rest.slice(1) : rest.slice(1, end);
    } else {
      clean = rest.split(/[\s,;]+/)[0] || "";
    }
    return { key: key, valueClean: clean, valueRaw: rest };
  }

  function audit(text){
    var lines = String(text == null ? "" : text).split(/\r?\n/);
    var findings = [];
    var seen = {}; // normalized key -> first line number
    var recognized = 0;

    function add(sev, line, setting, category, why, fix, secretLength){
      var f = { severity: sev, line: line, setting: setting, category: category, why: why, fix: fix };
      if(typeof secretLength === "number") f.secretLength = secretLength;
      findings.push(f);
    }

    for(var i = 0; i < lines.length; i++){
      var lineNo = i + 1;
      var raw = lines[i];
      var trimmed = raw.trim();
      if(trimmed === "") continue;

      // Structural lines (braces / closers) are not settings and are not guessed at.
      if(/^[{}()\[\]]+[;,]?$/.test(trimmed)) continue;

      // Commented-out lines: reported, never graded as active.
      if(trimmed.indexOf("//") === 0 || trimmed.charAt(0) === "#" || trimmed.indexOf("--") === 0){
        var inner = trimmed.replace(/^(\/\/|#|--)\s?/, "");
        var cp = parseKV(inner);
        add("INFO", lineNo, cp ? cp.key : "(comment)", "COMMENTED / NOT ACTIVE",
          "This line is commented out, so this setting is not active and was not graded.",
          "Leave it commented if you do not want it. Uncomment it only if you intend it to take effect — then audit again.");
        continue;
      }

      var p = parseKV(trimmed);
      if(!p){
        add("INFO", lineNo, "(unparsed line)", "NOT PARSED",
          "This line could not be read as a key/value setting, so it was not guessed or graded.",
          "If this line is meant to be a setting, rewrite it as key: value or KEY=value. Otherwise it can be ignored.");
        continue;
      }

      var key = p.key;
      var kl = key.toLowerCase();
      var val = p.valueClean;
      var vl = String(val).toLowerCase();

      var isKnown = false;
      for(var k = 0; k < KNOWN.length; k++){ if(kl.indexOf(KNOWN[k]) !== -1){ isKnown = true; break; } }
      if(isKnown) recognized++;

      // Duplicate active keys.
      if(seen[kl] !== undefined){
        add("MEDIUM", lineNo, key, "DUPLICATE",
          "This setting is set twice: first on line " + seen[kl] + " and again on line " + lineNo + ". In most Jitsi components the later value wins, so the effective value is easy to misread.",
          "Keep exactly one active line for " + key + " (currently lines " + seen[kl] + " and " + lineNo + ") and delete or comment out the other.");
      } else {
        seen[kl] = lineNo;
      }

      var isSecretKey = /(pass|secret|token|key)/.test(kl);

      // ---- Plaintext / placeholder / env-referenced secrets (value never rendered) ----
      if(isSecretKey){
        if(val === ""){
          add("LOW", lineNo, key, "EMPTY SECRET",
            "This secret setting has an empty value (" + key + ", 0 characters). The component may fall back to a default or refuse to start.",
            "Set " + key + " from an environment variable or secret store; do not leave it empty.");
        } else if(isEnvRef(p.valueRaw, val)){
          add("INFO", lineNo, key, "ENV-REFERENCED",
            "This secret is referenced from the environment rather than written into the config (" + key + ", reference is " + val.length + " characters; value not shown). That is the safe pattern.",
            "No change needed. Keep the real value in the environment or secret store only.", val.length);
        } else if(isPlaceholder(val)){
          add(kl.indexOf("app_secret") !== -1 ? "CRITICAL" : "HIGH", lineNo, key, "EXAMPLE / PLACEHOLDER",
            "This secret is an example or placeholder value, not a real secret (" + key + ", " + val.length + " characters; value not shown). Anyone who has seen the sample config knows it.",
            "Replace " + key + " with a long random secret loaded from an environment variable, and rotate it anywhere the placeholder was ever used.", val.length);
        } else if(val.length < 8){
          add("CRITICAL", lineNo, key, "PLAINTEXT SECRET",
            "This secret is written in plaintext in the config and is very short — only " + val.length + " characters (" + key + "; value not shown). Short plaintext secrets are guessable and leak with the file.",
            "Move " + key + " into an environment variable or secret store, reference it as ${...}, and use a random value of at least 32 characters. Rotate it if the file was ever shared.", val.length);
        } else if(val.length < 16){
          add("HIGH", lineNo, key, "PLAINTEXT SECRET",
            "This secret is written in plaintext in the config and is short — " + val.length + " characters (" + key + "; value not shown).",
            "Move " + key + " into an environment variable or secret store, reference it as ${...}, and use a random value of at least 32 characters. Rotate it if the file was ever shared.", val.length);
        } else {
          add("MEDIUM", lineNo, key, "PLAINTEXT SECRET",
            "This secret is written in plaintext directly in the config (" + key + ", " + val.length + " characters; value not shown). Anyone who can read the file has the secret.",
            "Move " + key + " into an environment variable or secret store and reference it as ${...}. Rotate it if the file was ever shared.", val.length);
        }
      }

      // ---- Transport: unencrypted URLs ----
      var urlMatch = /(https?|wss?):\/\/([^\/:?#\s'"]+)/i.exec(p.valueRaw);
      if(urlMatch){
        var scheme = urlMatch[1].toLowerCase();
        var host = urlMatch[2].toLowerCase();
        var isBoshWs = /(bosh|websocket|ws|xmpp|http-bind)/.test(kl);
        if(scheme === "http" || scheme === "ws"){
          if(isLocalHost(host)){
            add("LOW", lineNo, key, "UNENCRYPTED (LOCAL)",
              "This URL uses unencrypted " + scheme + "://, but the host is local (localhost / loopback), so traffic does not cross a network.",
              "Fine for local development. Switch to " + (scheme === "http" ? "https" : "wss") + ":// before this config faces any real network.");
          } else {
            add(isBoshWs ? "CRITICAL" : "HIGH", lineNo, key, "UNENCRYPTED TRANSPORT",
              "This URL uses unencrypted " + scheme + ":// for a public (non-localhost) host. Signaling, credentials, and meeting traffic on this channel can be read or altered in transit.",
              "Serve this endpoint over " + (scheme === "http" ? "https" : "wss") + ":// with a valid certificate and update " + key + " to match.");
          }
        } else if(isBoshWs){
          add("INFO", lineNo, key, "ENCRYPTED TRANSPORT",
            "This endpoint uses encrypted " + scheme + ":// transport. That is the safe pattern.",
            "No change needed.");
        }
      }

      // ---- Anonymous domain ----
      if(kl.indexOf("anonymousdomain") !== -1 || kl.indexOf("anonymous_domain") !== -1){
        if(val !== "" && !isFalseV(val) && vl !== "null" && vl !== "none"){
          add("CRITICAL", lineNo, key, "ANONYMOUS ACCESS",
            "An anonymous domain is set. Visitors who are not signed in are placed on this guest domain and can join meetings without any account or credential.",
            "Remove the anonymous domain, or put the deployment behind an authenticated domain (for example internal_hashed, LDAP, or JWT) so only signed-in users can start and join rooms.");
        }
      }

      // ---- Guest access ----
      if(kl.indexOf("guest") !== -1 && !isSecretKey){
        if(isTrueV(val)){
          add("CRITICAL", lineNo, key, "GUEST ACCESS ON",
            "Guest access is switched on. Anyone with a meeting link can enter as a guest without authenticating.",
            "Set " + key + " to false and require authentication to join, or keep guests waiting in an enabled lobby that a moderator must admit.");
        } else if(isFalseV(val)){
          add("INFO", lineNo, key, "GUEST ACCESS OFF",
            "Guest access is switched off, so unauthenticated visitors cannot walk straight in. That is the safe pattern.",
            "No change needed.");
        }
      }

      // ---- Public room creation ----
      if(kl.indexOf("public") !== -1 && kl.indexOf("room") !== -1){
        if(isTrueV(val)){
          add("HIGH", lineNo, key, "PUBLIC ROOM CREATION",
            "Public room creation is allowed. Anyone who reaches the server can create rooms, which invites spam meetings and resource abuse.",
            "Restrict room creation to authenticated users (set " + key + " to false) so only signed-in accounts can start rooms.");
        } else if(isFalseV(val)){
          add("INFO", lineNo, key, "ROOM CREATION RESTRICTED",
            "Public room creation is off, so rooms are limited to authenticated users. That is the safe pattern.",
            "No change needed.");
        }
      }

      // ---- Lobby ----
      if(kl.indexOf("lobby") !== -1 && !isSecretKey){
        if(isFalseV(val) || vl.indexOf("disabled") !== -1){
          add("HIGH", lineNo, key, "LOBBY DISABLED",
            "The lobby is disabled. Joiners are not held for a moderator to admit, so anyone with the link goes straight into the meeting.",
            "Enable the lobby for " + key + " so a moderator admits each guest before they join.");
        } else if(isTrueV(val) || vl === "enabled"){
          add("INFO", lineNo, key, "LOBBY ENABLED",
            "The lobby is enabled, so guests wait until a moderator admits them. That is the safe pattern.",
            "No change needed.");
        }
      }

      // ---- Authentication posture ----
      var isAuthTypeKey = (kl === "authentication" || /\.authentication$/.test(kl) ||
                           kl.indexOf("auth_type") !== -1 || kl.indexOf("authtype") !== -1 || kl === "auth");
      if(isAuthTypeKey){
        if(vl.indexOf("anonymous") !== -1){
          add("CRITICAL", lineNo, key, "ANONYMOUS AUTH",
            "Authentication is set to anonymous. The server asks for no credential at all, so identity on this deployment is unenforced.",
            "Switch authentication to internal_hashed, LDAP, or JWT so users sign in before hosting or joining.");
        } else if(vl.indexOf("internal_hashed") !== -1 || vl.indexOf("internal") !== -1 ||
                  vl.indexOf("ldap") !== -1 || vl.indexOf("jwt") !== -1 || vl.indexOf("token") !== -1){
          add("INFO", lineNo, key, "AUTHENTICATION SET",
            "Authentication uses a real credential check (not anonymous). That is the safe pattern.",
            "No change needed.");
        }
      }
      if(kl.indexOf("authdomain") !== -1){
        add("INFO", lineNo, key, "AUTHENTICATED DOMAIN",
          "An authenticated domain is configured, so there is a host that requires sign-in. That is the safe pattern.",
          "No change needed.");
      }

      // ---- JWT app_id ----
      if(kl === "app_id" || /[._\-]app_id$/.test(kl)){
        add("INFO", lineNo, key, "JWT APP ID",
          "A JWT app_id is set, which means token-based (JWT) authentication is in use. Its safety depends entirely on the matching app_secret.",
          "Make sure app_secret is long (32+ characters), random, and loaded from the environment — never an example value.");
      }

      // ---- Deep linking ----
      if(kl.indexOf("deeplink") !== -1){
        var deepDisabled = (kl.indexOf("disable") !== -1) ? isTrueV(val) : isFalseV(val);
        var deepEnabled  = (kl.indexOf("disable") !== -1) ? isFalseV(val) : isTrueV(val);
        if(deepEnabled){
          add("MEDIUM", lineNo, key, "DEEP LINKING OPEN",
            "Deep linking is not disabled. Web visitors get pushed toward the mobile apps, and the join flow is harder to keep behind your own sign-in page.",
            "Set disableDeepLinking to true on a server deployment so the web join flow stays under your control.");
        } else if(deepDisabled){
          add("INFO", lineNo, key, "DEEP LINKING DISABLED",
            "Deep linking is disabled, so the web join flow stays on your server. That is the safe pattern.",
            "No change needed.");
        }
      }

      // ---- External API ----
      if(kl.indexOf("externalapi") !== -1 || kl.indexOf("external_api") !== -1){
        if(isTrueV(val)){
          add("LOW", lineNo, key, "EXTERNAL API ON",
            "The external API (iframe API) surface is enabled. Pages on other sites may be able to embed and drive meetings from this server.",
            "Leave it on only if embedding is intended; otherwise disable it, and always pair embedding with JWT authentication.");
        }
      }

      // ---- Recording / streaming enablement ----
      if(!isSecretKey && (kl.indexOf("record") !== -1 || kl.indexOf("livestream") !== -1)){
        if(isTrueV(val)){
          add("MEDIUM", lineNo, key, "RECORDING / STREAMING ON",
            "Recording or live streaming is switched on. Recordings capture everything said in the meeting, and the Jibri / streaming credentials become high-value targets.",
            "Keep recording on only if it is intended. Make sure every Jibri / RTMP credential is env-referenced (never plaintext) and tell participants when recording is active.");
        } else if(isFalseV(val)){
          add("INFO", lineNo, key, "RECORDING OFF",
            "Recording / streaming is switched off in this setting. That is the safe default.",
            "No change needed.");
        }
      }
      if(!isSecretKey && kl.indexOf("jibri") !== -1 && kl.indexOf("enabl") !== -1 && isTrueV(val)){
        add("MEDIUM", lineNo, key, "JIBRI ON",
          "Jibri is enabled. Jibri signs in with its own account to record or stream, so its credentials decide how safe this is.",
          "Use a dedicated Jibri account with env-referenced credentials, and keep the Jibri host off the public internet.");
      }
    }

    findings.sort(function(a, b){
      if(SEV_ORDER[a.severity] !== SEV_ORDER[b.severity]) return SEV_ORDER[a.severity] - SEV_ORDER[b.severity];
      return a.line - b.line;
    });

    var counts = { CRITICAL: 0, HIGH: 0, MEDIUM: 0, LOW: 0, INFO: 0 };
    findings.forEach(function(f){ counts[f.severity]++; });

    var verdict, verdictWhy;
    if(recognized === 0){
      verdict = "NOT ENOUGH TO GRADE";
      verdictWhy = "The paste was empty, prose, or contained no recognizable Jitsi Meet setting, so there is nothing safe to grade. Paste config.js lines, Prosody / Jicofo / JVB properties, or .env lines and audit again.";
    } else if(counts.CRITICAL > 0){
      verdict = "DO NOT DEPLOY";
      verdictWhy = counts.CRITICAL + " critical finding(s): this config would expose the deployment as pasted. Fix every critical item before this server faces users.";
    } else if(counts.HIGH > 0 || counts.MEDIUM > 0){
      verdict = "DEPLOY WITH FIXES";
      verdictWhy = "No critical findings, but " + (counts.HIGH + counts.MEDIUM) + " high/medium finding(s) should be fixed before or immediately after deploying.";
    } else {
      verdict = "SAFE TO DEPLOY";
      verdictWhy = "No critical, high, or medium findings in the pasted config. This grades the pasted text only — it does not verify a live server.";
    }

    return { verdict: verdict, verdictWhy: verdictWhy, counts: counts,
             findings: findings, recognized: recognized, totalLines: lines.length };
  }

  function buildTextReport(r){
    var out = [];
    out.push("J-Dawgs Jitsi Meet Server Config Safety Auditor\u2122 \u2014 Text Report");
    out.push("Verdict: " + r.verdict);
    out.push("Recognized Jitsi Meet settings: " + r.recognized + " \u00b7 Lines audited: " + r.totalLines);
    out.push("Counts: Critical " + r.counts.CRITICAL + " \u00b7 High " + r.counts.HIGH +
             " \u00b7 Medium " + r.counts.MEDIUM + " \u00b7 Low " + r.counts.LOW + " \u00b7 Info " + r.counts.INFO);
    out.push("Secret values are never shown; secrets are reported by key name, line, and character length only.");
    out.push("");
    out.push("Findings:");
    if(r.findings.length === 0) out.push("(none)");
    r.findings.forEach(function(f){
      var len = (typeof f.secretLength === "number") ? " \u00b7 value length: " + f.secretLength + " characters" : "";
      out.push("[" + f.severity + "] Line " + f.line + " \u00b7 " + f.setting + " (" + f.category + ")" + len);
      out.push("  Why: " + f.why);
      out.push("  Fix: " + f.fix);
    });
    out.push("");
    out.push("Limits: text audit of the pasted config only. This does not start a server, connect to anything, or verify a live deployment. Commented settings are not active. Secret strength is judged by length and placeholder patterns only.");
    return out.join("\n");
  }

  function buildJsonReport(r){
    var obj = {
      tool: "J-Dawgs Jitsi Meet Server Config Safety Auditor\u2122",
      verdict: r.verdict,
      recognizedSettings: r.recognized,
      linesAudited: r.totalLines,
      counts: { critical: r.counts.CRITICAL, high: r.counts.HIGH, medium: r.counts.MEDIUM, low: r.counts.LOW, info: r.counts.INFO },
      findings: r.findings.map(function(f){
        var o = { severity: f.severity, line: f.line, setting: f.setting, category: f.category, why: f.why, fix: f.fix };
        if(typeof f.secretLength === "number") o.secretValueLength = f.secretLength;
        return o;
      }),
      limits: "Text audit of the pasted config only; does not start a server, connect to anything, or verify a live deployment. Commented settings are not active. Secret strength judged by length and placeholder patterns only; secret values are never included."
    };
    return JSON.stringify(obj, null, 2);
  }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-jitsi-meet-server-config-safety-auditortm',
  name: 'J-Dawgs Jitsi Meet Server Config Safety Auditor',
  description: '',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
