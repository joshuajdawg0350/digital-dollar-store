'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Meilisearch Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

    "use strict";

    /* ============================================================
       J-Dawgs Meilisearch Server Config Safety Auditor
       Runs entirely in the browser. Nothing is saved or sent.
       Secret values are used only to measure length / placeholder
       status in memory — they are never rendered anywhere.
       ============================================================ */

    var RISKY_EXAMPLE = [
      "MEILI_ENV=production",
      "MEILI_HTTP_ADDR=0.0.0.0:7700",
      "MEILI_MASTER_KEY=masterKey",
      "MEILI_DUMPS_DIR=./dumps"
    ].join("\n");

    var HARDENED_EXAMPLE = [
      "# Hardened Meilisearch - production, loopback bind, TLS on",
      "MEILI_ENV=production",
      "MEILI_HTTP_ADDR=127.0.0.1:7700",
      "MEILI_MASTER_KEY=xK9mQ2vR8tY5wP3nB7sD4hJ6aF1cE0gH",
      "MEILI_SSL_CERT_PATH=/etc/meilisearch/certs/server.crt",
      "MEILI_SSL_KEY_PATH=/etc/meilisearch/certs/server.key",
      "MEILI_NO_ANALYTICS=true",
      "MEILI_DUMPS_DIR=/var/lib/meilisearch/dumps",
      "MEILI_SNAPSHOTS_DIR=/var/lib/meilisearch/snapshots"
    ].join("\n");

    var NGINX_EXAMPLE = [
      "server {",
      "    listen 80;",
      "    server_name example.com;",
      "    location / {",
      "        proxy_pass http://127.0.0.1:7700;",
      "    }",
      "}"
    ].join("\n");

    /* Canonical Meilisearch settings (normalized: MEILI_ stripped,
       dashes -> underscores, upper case). */
    var CANON = {
      HTTP_ADDR: 1, MASTER_KEY: 1, ENV: 1, NO_ANALYTICS: 1,
      DUMPS_DIR: 1, SNAPSHOTS_DIR: 1, SNAPSHOT_DIR: 1,
      SSL_CERT_PATH: 1, SSL_KEY_PATH: 1, SSL_AUTH_PATH: 1,
      SSL_OCSP_PATH: 1, SSL_REQUIRE_CLIENT_CERT: 1, SSL_RESOLVERS: 1,
      DB_PATH: 1, LOG_LEVEL: 1, SCHEDULE_SNAPSHOT: 1,
      HTTP_PAYLOAD_SIZE_LIMIT: 1, MAX_INDEXING_MEMORY: 1,
      MAX_INDEXING_THREADS: 1, INSTANCE_UID: 1, LAUNCHDB_EDITION: 1
    };
    var BOOL_FLAGS = { NO_ANALYTICS: 1, SSL_REQUIRE_CLIENT_CERT: 1, SCHEDULE_SNAPSHOT: 1 };
    var STRUCTURAL = {
      SERVICES:1, ENVIRONMENT:1, IMAGE:1, PORTS:1, VOLUMES:1, COMMAND:1,
      CONTAINER_NAME:1, RESTART:1, NETWORKS:1, DEPENDS_ON:1, BUILD:1,
      DEPLOY:1, HEALTHCHECK:1, EXPOSE:1, WORKING_DIR:1, USER:1, PROFILES:1
    };
    var PLACEHOLDERS = [
      "masterkey","master-key","your-master-key","your_master_key",
      "yourmasterkey","changeme","change-me","change_me","password",
      "passwd","secret","secretkey","secret-key","example","example-key",
      "test","testkey","default","letmein","meilisearch","admin",
      "123456","12345678","qwerty","your-key-here","insert-key-here",
      "replace-me","replace_me","todo","xxx","xxxx","none","null"
    ];
    var SECRET_NAME = /(SECRET|TOKEN|PASSWORD|PASSWD|PASSPHRASE|APIKEY|API_KEY|ACCESS_KEY|PRIVATE_KEY|CREDENTIAL|CLIENT_SECRET|AUTH_TOKEN|BEARER)/;

    function normalizeKey(raw) {
      var k = String(raw).replace(/^\s+|\s+$/g, "").replace(/-/g, "_").toUpperCase();
      if (k.indexOf("MEILI_") === 0) k = k.slice(6);
      return k;
    }
    function canonOf(norm) {
      if (norm === "SNAPSHOT_DIR") return "SNAPSHOTS_DIR";
      return CANON[norm] ? norm : null;
    }
    function cleanValue(v) {
      v = String(v).replace(/\r$/, "").replace(/^\s+|\s+$/g, "");
      if (v.length >= 2) {
        var a = v.charAt(0), b = v.charAt(v.length - 1);
        if ((a === '"' && b === '"') || (a === "'" && b === "'")) v = v.slice(1, -1);
      }
      if (v.charAt(v.length - 1) === ";") v = v.slice(0, -1);
      return v.replace(/^\s+|\s+$/g, "");
    }
    function unquotedClean(v) {
      /* strip an inline " # comment" from an unquoted env value */
      var wasQuoted = /^["']/.test(String(v).replace(/^\s+/, ""));
      var out = cleanValue(v);
      if (!wasQuoted) {
        var i = out.indexOf(" #");
        if (i > 0) out = out.slice(0, i).replace(/\s+$/, "");
      }
      return out;
    }
    function truthy(v) {
      var s = String(v).toLowerCase();
      return s === "true" || s === "1" || s === "yes" || s === "on";
    }
    function isVarRef(v) { return String(v).indexOf("$") !== -1; }

    /* ---------------- Parser ----------------
       Returns:
         entries: canon -> {value, line, display, occ:[{line,value,display}]}
         generic: [{norm, display, value, line}]  (non-Meilisearch keys)
         notParsed: [lineNumber]
         meiliCount: number of recognized Meilisearch settings
         formats: {env, cli, toml, compose, systemd} booleans
    */
    function parseConfig(text) {
      var lines = String(text).split("\n");
      var entries = {}, generic = [], notParsed = [];
      var meiliCount = 0;
      var formats = {};
      var occMap = {}; /* identity -> [{line,value,display}] for duplicates */

      function record(rawKey, value, lineNo, fmt) {
        var norm = normalizeKey(rawKey);
        var canon = canonOf(norm);
        formats[fmt] = true;
        var display = "MEILI_" + (canon || norm);
        var id = canon ? ("C:" + canon) : ("G:" + norm);
        if (!occMap[id]) occMap[id] = [];
        occMap[id].push({ line: lineNo, value: value, display: display });
        if (canon || norm.indexOf("MEILI_") === 0 || String(rawKey).toUpperCase().indexOf("MEILI_") === 0) {
          meiliCount++;
        }
        if (canon) {
          entries[canon] = { value: value, line: lineNo, display: display, occ: occMap[id] };
        } else {
          generic.push({ norm: norm, display: String(rawKey), value: value, line: lineNo });
        }
      }

      function parseCliTokens(lineText, lineNo) {
        var toks = lineText.match(/"[^"]*"|'[^']*'|\S+/g) || [];
        var found = 0;
        for (var i = 0; i < toks.length; i++) {
          var t = toks[i].replace(/\\$/, "");
          if (t.indexOf("--") !== 0) continue;
          var body = t.slice(2), eq = body.indexOf("=");
          var fname = eq >= 0 ? body.slice(0, eq) : body;
          var norm = normalizeKey(fname);
          var canon = canonOf(norm);
          var val = eq >= 0 ? cleanValue(body.slice(eq + 1)) : null;
          if (BOOL_FLAGS[norm] && val === null) {
            var nxt = toks[i + 1];
            if (nxt && nxt.charAt(0) !== "-" && /^(true|false|1|0|yes|no)$/i.test(nxt)) { val = nxt; i++; }
            else val = "true";
          } else if (val === null) {
            var n2 = toks[i + 1];
            if (n2 && n2.charAt(0) !== "-") { val = cleanValue(n2); i++; }
            else val = "";
          }
          if (canon) { record(fname, val, lineNo, "cli"); found++; }
        }
        return found;
      }

      for (var ln = 0; ln < lines.length; ln++) {
        var lineNo = ln + 1;
        var raw = lines[ln].replace(/\r$/, "");
        var t = raw.replace(/^\s+|\s+$/g, "");
        if (t === "") continue;
        if (t.charAt(0) === "#" || t.indexOf("//") === 0) continue;
        if (t === "{" || t === "}" || t === "---" || t === "...") continue;
        if (/^\[[^\]]*\]$/.test(t)) continue; /* TOML table header */
        if (/^(?:\S*\/)?meilisearch\s*\\?$/.test(t)) continue; /* bare command line */

        var work = t, fmt = "env";

        /* systemd Environment= prefix */
        if (/^Environment=/.test(work)) {
          work = work.slice("Environment=".length);
          work = work.replace(/^\s+|\s+$/g, "");
          if (work.length >= 2 && work.charAt(0) === '"' && work.charAt(work.length - 1) === '"') {
            work = work.slice(1, -1);
          }
          fmt = "systemd";
        }
        /* shell export */
        if (/^export\s+/.test(work)) { work = work.replace(/^export\s+/, ""); }
        /* docker-compose list item */
        if (/^-\s+/.test(work)) { work = work.replace(/^-\s+/, ""); fmt = "compose"; }

        /* CLI flags anywhere on the line (covers ExecStart= and command:) */
        if (/--[a-zA-Z]/.test(work)) {
          if (parseCliTokens(work, lineNo) > 0) continue;
        }

        /* KEY=VALUE */
        var m = work.match(/^([A-Za-z_][A-Za-z0-9_.\-]*)\s*=\s*(.*)$/);
        if (m) {
          var normK = normalizeKey(m[1]);
          var f2 = fmt;
          if (f2 === "env" && !CANON[normK] && normK === normK.toLowerCase() && false) f2 = "env";
          if (f2 === "env" && m[1] === m[1].toLowerCase() && CANON[normK]) f2 = "toml";
          record(m[1], unquotedClean(m[2]), lineNo, f2);
          continue;
        }

        /* YAML KEY: VALUE (docker-compose map style) */
        var y = work.match(/^([A-Za-z_][A-Za-z0-9_\-]*)\s*:\s+(\S[\s\S]*)$/);
        if (y) {
          var yn = normalizeKey(y[1]);
          if (canonOf(yn) || String(y[1]).toUpperCase().indexOf("MEILI") === 0) {
            record(y[1], unquotedClean(y[2]), lineNo, "compose");
            continue;
          }
          if (STRUCTURAL[yn]) continue; /* compose structure, not a setting */
          generic.push({ norm: yn, display: y[1], value: unquotedClean(y[2]), line: lineNo });
          continue;
        }
        /* bare structural word: (services:, environment:, ...) */
        var s = work.match(/^([A-Za-z_][A-Za-z0-9_\-]*)\s*:\s*$/);
        if (s && STRUCTURAL[normalizeKey(s[1])]) continue;
        /* any other bare label with no value (compose service names,
           section labels) sets nothing by itself — not a finding */
        if (/^[A-Za-z_][A-Za-z0-9_.\-]*\s*:\s*$/.test(work)) continue;
        /* compose port/volume mapping like 7700:7700 or ./data:/data */
        if (/^[^\s=]+:[^\s=]+$/.test(work)) continue;

        notParsed.push(lineNo);
      }

      return {
        entries: entries, generic: generic, notParsed: notParsed,
        meiliCount: meiliCount, formats: formats, occMap: occMap,
        totalLines: lines.length
      };
    }

    /* ---------------- Bind analysis ---------------- */
    function analyzeBind(value) {
      var v = String(value).replace(/^\s+|\s+$/g, "");
      var host;
      if (v.charAt(0) === "[") {
        var end = v.indexOf("]");
        host = end > 0 ? v.slice(1, end) : v;
      } else {
        var pm = v.match(/^([^:]*):(\d+)$/);
        host = pm ? pm[1] : v;
      }
      host = host.toLowerCase();
      var loopback = host === "localhost" || host === "::1" || host.indexOf("127.") === 0;
      var wildcard = host === "" || host === "0.0.0.0" || host === "::" || host === "*";
      return { host: host || "(all interfaces)", loopback: loopback, wildcard: wildcard, network: !loopback };
    }
    function defaultishDir(value, kind) {
      var v = String(value).replace(/^\s+|\s+$/g, "").replace(/\/+$/, "").toLowerCase();
      var names = kind === "dumps" ? ["dumps"] : ["snapshots", "snapshot"];
      for (var i = 0; i < names.length; i++) {
        if (v === names[i] || v === "./" + names[i] || v === "/" + names[i]) return true;
      }
      return false;
    }

    /* ---------------- Audit ---------------- */
    var LIMITS = [
      "Parses pasted text only — it never connects to a server and cannot see firewall rules, reverse-proxy configuration, file permissions, or host patching.",
      "NOT AUDITED: actual API-key scopes. Meilisearch derives its default and production API keys from the master key; which derived keys were handed out, and what they can reach, is out of scope.",
      "Heuristic grading is not a penetration test.",
      "Secret values never appear in this output — secrets are reported by key name, line, and length only."
    ];

    function audit(text) {
      var p = parseConfig(text);
      var E = p.entries;
      var findings = [], oks = [];
      function F(sev, line, key, title, detail) {
        findings.push({ severity: sev, line: line, key: key, title: title, detail: detail });
      }
      function OK(text2) { oks.push(text2); }

      var trimmed = String(text).replace(/\s+/g, "");
      if (trimmed === "") {
        return { verdict: "NOT ENOUGH TO GRADE", reason: "empty",
          sub: "The paste box is empty — there is nothing to grade. Paste a Meilisearch configuration, or load one of the examples.",
          findings: [], oks: [], counts: null, parsed: p, settings: [] };
      }
      if (p.meiliCount === 0) {
        return { verdict: "NOT ENOUGH TO GRADE", reason: "nomeili",
          sub: "No recognizable Meilisearch settings were found in this paste, so no verdict is given. This tool grades Meilisearch configuration only — env lines (MEILI_*), CLI flags (--http-addr, --master-key, …), systemd Environment= lines, docker-compose environment entries, or TOML config keys.",
          findings: [], oks: [], counts: null, parsed: p, settings: [] };
      }

      var envE = E.ENV, bindE = E.HTTP_ADDR, keyE = E.MASTER_KEY;
      var isProd = !!(envE && String(envE.value).toLowerCase() === "production");
      var bind = bindE ? analyzeBind(bindE.value) : null;
      var networkBind = !!(bind && bind.network);

      var keyPresent = !!keyE;
      var keyRef = keyPresent && isVarRef(keyE.value);
      var keyLen = keyPresent ? String(keyE.value).length : 0;
      var keyPlaceholder = keyPresent && !keyRef && PLACEHOLDERS.indexOf(String(keyE.value).toLowerCase()) !== -1;
      var keyShort = keyPresent && !keyRef && keyLen < 16;
      var keyWeak = !keyPresent || keyPlaceholder || keyShort;

      /* (1) HTTP address binding */
      if (bindE) {
        if (bind.loopback) {
          OK("Loopback-only bind — " + bindE.display + " (line " + bindE.line + ") binds " + bind.host + ", so this setting alone does not expose the server to other machines.");
        } else if (keyWeak) {
          var why = !keyPresent ? "no master key is set"
            : keyPlaceholder ? "the master key is a known placeholder/example value"
            : "the master key is only " + keyLen + " characters long";
          F("BLOCKER", bindE.line, bindE.display,
            "Network-reachable bind without a strong master key",
            bindE.display + " binds " + bind.host + " (line " + bindE.line + "), which accepts connections from other machines — and " + why + ". Anyone who can reach this port effectively has full control of the search server and its data. Bind to 127.0.0.1 or set a long, random master key before this server is reachable.");
        } else {
          F("WARNING", bindE.line, bindE.display,
            "Network-reachable bind",
            bindE.display + " binds " + bind.host + " (line " + bindE.line + "), so the server accepts connections from other machines. A strong master key is set, which is what stands between the network and full control — keep it that way, and make sure your firewall only allows the hosts that need this port.");
        }
      } else {
        F("INFO", null, "MEILI_HTTP_ADDR",
          "No HTTP address in the paste",
          "No bind address was pasted, so Meilisearch's default of 127.0.0.1:7700 (loopback only) is assumed for this grade. If the server is actually started with a different --http-addr, that setting was not graded.");
      }

      /* (2) Master key posture — value never rendered, only name/line/length */
      if (!keyPresent) {
        if (isProd) {
          F("BLOCKER", envE.line, "MEILI_MASTER_KEY",
            "Production mode with no master key",
            "The environment is production (line " + envE.line + ") but no master key appears anywhere in the paste. Production requires a master key — without one the deployment is unprotected. Set MEILI_MASTER_KEY to a long, random value (32+ characters) that exists nowhere else.");
        } else if (!networkBind) {
          F("WARNING", envE ? envE.line : null, "MEILI_MASTER_KEY",
            "No master key set",
            "No master key appears in the paste. On a loopback-only development setup that is workable, but the moment this server binds to a network address it is wide open. Set MEILI_MASTER_KEY before any network exposure.");
        }
        /* networkBind + no key is already the bind BLOCKER above */
      } else if (keyRef) {
        F("INFO", keyE.line, keyE.display,
          "Master key supplied by reference",
          keyE.display + " (line " + keyE.line + ") is set from a variable reference rather than a literal value in the paste, so its length and strength cannot be graded here. Make sure the referenced value is long, random, and unique to this server.");
      } else if (keyPlaceholder) {
        F((isProd || networkBind) ? "BLOCKER" : "HIGH", keyE.line, keyE.display,
          "Master key is a known placeholder / example value",
          keyE.display + " (line " + keyE.line + ", " + keyLen + " characters) matches a placeholder or example value that appears in documentation and tutorials — anyone who has read the same docs knows it. The value itself is never shown in this audit. Replace it with a long, random key (32+ characters) before deploying.");
      } else if (keyShort) {
        F("HIGH", keyE.line, keyE.display,
          "Master key is short — " + keyLen + " characters",
          keyE.display + " (line " + keyE.line + ") is " + keyLen + " characters, under the 16-character floor. Short keys fall to brute force and guessing, and the master key controls everything, including the derived API keys. The value itself is never shown in this audit. Use 32+ random characters.");
      } else {
        OK("Master key present and " + keyLen + " characters long (" + keyE.display + ", line " + keyE.line + "), and not a known placeholder. Its value is never shown in this audit.");
      }

      /* (3) Environment */
      if (isProd) {
        OK("Environment is production (" + envE.display + ", line " + envE.line + ").");
      } else if (envE) {
        if (networkBind) {
          F("WARNING", envE.line, envE.display,
            "Non-production environment on a network-reachable bind",
            envE.display + " (line " + envE.line + ") is not \"production\". Development mode relaxes protections and is meant for local work — on a bind other machines can reach, that combination is an exposure. Set the environment to production for any deployed server.");
        } else {
          F("INFO", envE.line, envE.display,
            "Environment is not production",
            envE.display + " (line " + envE.line + ") is not \"production\" — fine for local development on a loopback bind. Switch to production before the server is exposed to any network.");
        }
      } else {
        if (networkBind) {
          F("WARNING", bindE.line, "MEILI_ENV",
            "MEILI_ENV is not set, on a network-reachable bind",
            "No environment setting appears in the paste, so Meilisearch defaults to development — which relaxes protections — while the bind (line " + bindE.line + ") accepts connections from other machines. Set MEILI_ENV=production for any deployed server.");
        } else {
          F("INFO", null, "MEILI_ENV",
            "MEILI_ENV is not set",
            "No environment setting appears in the paste; Meilisearch defaults to development. Fine for local work — set MEILI_ENV=production before deploying.");
        }
      }

      /* (4) TLS posture */
      var certE = E.SSL_CERT_PATH, skeyE = E.SSL_KEY_PATH;
      var authE = E.SSL_AUTH_PATH, rccE = E.SSL_REQUIRE_CLIENT_CERT;
      var sslFull = !!(certE && skeyE), sslPartial = !!(!sslFull && (certE || skeyE));
      if (sslPartial) {
        var present = certE || skeyE, missingName = certE ? "MEILI_SSL_KEY_PATH" : "MEILI_SSL_CERT_PATH";
        F("HIGH", present.line, present.display,
          "TLS is half-configured",
          present.display + " is set (line " + present.line + ") but " + missingName + " is missing. A certificate without its key (or the reverse) cannot serve TLS — Meilisearch will fail to start or fall back in ways you did not intend. Set both, or neither (with a TLS-terminating proxy in front).");
      } else if (sslFull) {
        OK("TLS is configured — certificate (" + certE.display + ", line " + certE.line + ") and key (" + skeyE.display + ", line " + skeyE.line + ") paths are both set. File contents and permissions are not visible to this tool.");
        if (authE && !(rccE && truthy(rccE.value))) {
          F("WARNING", authE.line, authE.display,
            "SSL auth path set, but client certificates are not required",
            authE.display + " (line " + authE.line + ") names a client-certificate auth path, but " + (rccE ? rccE.display + " (line " + rccE.line + ") does not enable it" : "MEILI_SSL_REQUIRE_CLIENT_CERT is not enabled") + " — so the auth path has no effect and any client can connect over TLS. Enable ssl_require_client_cert, or remove the auth path.");
        } else if (rccE && truthy(rccE.value) && !authE) {
          F("WARNING", rccE.line, rccE.display,
            "Client certificates required, but no SSL auth path",
            rccE.display + " (line " + rccE.line + ") requires client certificates, but no " + "MEILI_SSL_AUTH_PATH is set to say which certificate authority signs acceptable client certificates — clients will have nothing valid to present. Set the auth path, or turn the requirement off.");
        } else if (rccE && truthy(rccE.value) && authE) {
          OK("Mutual TLS — client certificates are required (" + rccE.display + ", line " + rccE.line + ") with an auth path set (" + authE.display + ", line " + authE.line + ").");
        }
      } else if (networkBind) {
        F("HIGH", bindE.line, "MEILI_SSL_CERT_PATH",
          "Network-reachable bind with no TLS configured",
          "The bind (line " + bindE.line + ") accepts connections from other machines, but no SSL certificate/key paths appear in the paste — API keys and data would cross the network as plain HTTP. Either configure MEILI_SSL_CERT_PATH and MEILI_SSL_KEY_PATH, or put a TLS-terminating reverse proxy in front (proxy configuration is not visible to this tool).");
      } else if (bindE && bind.loopback) {
        OK("No TLS configured, and none required by this grade — the bind is loopback-only, so traffic never leaves the machine.");
      }

      /* (5) Analytics — INFO either way, never a blocker */
      var anE = E.NO_ANALYTICS;
      if (anE && truthy(anE.value)) {
        F("INFO", anE.line, anE.display,
          "Analytics / telemetry is off",
          anE.display + " (line " + anE.line + ") disables Meilisearch's anonymous usage telemetry. Informational only — this is never graded as a safety issue.");
      } else if (anE) {
        F("INFO", anE.line, anE.display,
          "Analytics / telemetry is on",
          anE.display + " (line " + anE.line + ") leaves Meilisearch's anonymous usage telemetry enabled. Informational only — this is never graded as a safety issue.");
      } else {
        F("INFO", null, "MEILI_NO_ANALYTICS",
          "Analytics flag not set",
          "No MEILI_NO_ANALYTICS setting appears in the paste, so Meilisearch's anonymous usage telemetry is on by default. Informational only — this is never graded as a safety issue.");
      }

      /* (6) Dumps / snapshots directories */
      [["DUMPS_DIR", "dumps", "./dumps"], ["SNAPSHOTS_DIR", "snapshots", "./snapshots"]].forEach(function (spec) {
        var e = E[spec[0]], label = spec[1], dflt = spec[2];
        if (e) {
          if (defaultishDir(e.value, spec[1])) {
            if (networkBind) {
              F("WARNING", e.line, e.display,
                label.charAt(0).toUpperCase() + label.slice(1) + " directory is the predictable default path",
                e.display + " (line " + e.line + ") points at the default " + dflt + " location while the server binds to a network-reachable address. " + label.charAt(0).toUpperCase() + label.slice(1) + " contain full copies of your index data — a predictable path makes them easier to find and grab. Move them somewhere non-obvious and lock down the file permissions.");
            } else {
              F("INFO", e.line, e.display,
                label.charAt(0).toUpperCase() + label.slice(1) + " directory is the default path",
                e.display + " (line " + e.line + ") uses the predictable default location. Harmless while the bind stays loopback — revisit it before any network exposure, since " + label + " hold full copies of your data.");
            }
          } else {
            OK(label.charAt(0).toUpperCase() + label.slice(1) + " directory is set to a non-default path (" + e.display + ", line " + e.line + ").");
          }
        } else if (networkBind) {
          F("WARNING", null, "MEILI_" + spec[0],
            label.charAt(0).toUpperCase() + label.slice(1) + " directory not set — default path applies",
            "No " + label + " directory appears in the paste, so Meilisearch uses the predictable default " + dflt + " while the server binds to a network-reachable address. " + label.charAt(0).toUpperCase() + label.slice(1) + " contain full copies of your index data. Set an explicit, non-obvious path and lock down its permissions.");
        }
      });

      /* (7) Other secret-looking values — name / line / length only */
      p.generic.forEach(function (g) {
        if (SECRET_NAME.test(g.norm) && String(g.value).length >= 4 && !isVarRef(g.value)) {
          F("WARNING", g.line, g.display,
            "Secret-looking value in " + g.display,
            g.display + " (line " + g.line + ") holds a value " + String(g.value).length + " characters long under a secret-sounding key name. The value is never shown in this audit. If this paste has been shared, committed, or screenshotted, treat that secret as exposed and rotate it — and keep secrets out of files that travel.");
        }
      });

      /* (8) Duplicate keys with conflicting values */
      Object.keys(p.occMap).forEach(function (id) {
        var occ = p.occMap[id];
        if (occ.length < 2) return;
        var distinct = {};
        occ.forEach(function (o) { distinct[o.value] = true; });
        if (Object.keys(distinct).length < 2) return;
        var lineList = occ.map(function (o) { return o.line; });
        F("WARNING", occ[0].line, occ[0].display,
          "Duplicate setting with conflicting values — lines " + lineList.join(" and "),
          occ[0].display + " is set " + occ.length + " times with different values (lines " + lineList.join(", ") + "). Most loaders let the last value win, which may not be the one you intended — and this audit graded the last one. Delete the stale line so the effective value is the one on the page. (Values are not shown for any key that could be a secret.)");
      });

      /* (9) Unparsable lines — content withheld */
      p.notParsed.forEach(function (ln2) {
        F("NOT PARSED", ln2, null,
          "Line not parsed",
          "Line " + ln2 + " did not match any known Meilisearch setting format, so anything it sets was not graded. Its content is withheld from this report. If it configures the server, re-check it by hand.");
      });

      /* Verdict */
      var order = { "BLOCKER": 0, "HIGH": 1, "WARNING": 2, "INFO": 3, "NOT PARSED": 4 };
      findings.sort(function (a, b) {
        var d = order[a.severity] - order[b.severity];
        if (d !== 0) return d;
        var la = a.line === null ? 9999 : a.line, lb = b.line === null ? 9999 : b.line;
        return la - lb;
      });
      var counts = { BLOCKER: 0, HIGH: 0, WARNING: 0, INFO: 0, NOTPARSED: 0, OK: oks.length };
      findings.forEach(function (f) {
        if (f.severity === "NOT PARSED") counts.NOTPARSED++; else counts[f.severity]++;
      });
      var verdict, sub;
      if (counts.BLOCKER > 0) {
        verdict = "DO NOT DEPLOY";
        sub = counts.BLOCKER + (counts.BLOCKER === 1 ? " blocker" : " blockers") + " must be fixed before this configuration is exposed to any network. The blockers are at the top of the findings list, each with its line number.";
      } else if (counts.HIGH > 0 || counts.WARNING > 0) {
        verdict = "DEPLOY WITH FIXES";
        sub = "No blockers — but the findings below should be fixed before this configuration is exposed. Each one names its line.";
      } else {
        verdict = "SAFE TO DEPLOY";
        sub = "No blockers, no high findings, no warnings. The protections this grade could verify are listed under Verified protections. The honest limits still apply — this grade covers the pasted configuration only.";
      }

      /* Safe settings summary for JSON: values included only for
         non-secret settings; secret values are name/line/length only. */
      var settings = [];
      Object.keys(E).forEach(function (k) {
        var e = E[k];
        if (k === "MASTER_KEY") settings.push({ key: e.display, line: e.line, present: true, length: String(e.value).length, value: "[withheld]" });
        else settings.push({ key: e.display, line: e.line, value: e.value });
      });
      p.generic.forEach(function (g) {
        if (SECRET_NAME.test(g.norm)) settings.push({ key: g.display, line: g.line, length: String(g.value).length, value: "[withheld]" });
        else settings.push({ key: g.display, line: g.line, value: g.value });
      });

      return { verdict: verdict, sub: sub, findings: findings, oks: oks, counts: counts, parsed: p, settings: settings };
    }

    /* ---------------- Report + JSON ---------------- */
    function sevLabel(f) { return f.severity === "NOT PARSED" ? "NOT PARSED" : f.severity; }
    function lineLabel(f) { return f.line === null ? "not set" : "line " + f.line; }

    function buildReport(r) {
      var out = [];
      out.push("J-DAWGS MEILISEARCH SERVER CONFIG SAFETY AUDITOR — AUDIT REPORT");
      out.push("Audited: " + new Date().toLocaleString());
      out.push("");
      out.push("VERDICT: " + r.verdict);
      if (r.sub) out.push(r.sub);
      if (r.counts) {
        out.push("");
        out.push("Counts: " + r.counts.BLOCKER + " blocker · " + r.counts.HIGH + " high · " +
          r.counts.WARNING + " warning · " + r.counts.INFO + " info · " +
          r.counts.NOTPARSED + " not parsed · " + r.counts.OK + " verified protections");
      }
      out.push("");
      out.push("FINDINGS");
      if (!r.findings.length) out.push("(none)");
      r.findings.forEach(function (f) {
        out.push("[" + sevLabel(f) + "] " + (f.key ? f.key + " · " : "") + lineLabel(f) + " — " + f.title);
        out.push("    " + f.detail);
      });
      out.push("");
      out.push("VERIFIED PROTECTIONS");
      if (!r.oks.length) out.push("(none could be verified from this paste)");
      r.oks.forEach(function (o) { out.push("✓ " + o); });
      out.push("");
      out.push("WHAT THIS AUDIT CANNOT SEE");
      LIMITS.forEach(function (l) { out.push("- " + l); });
      return out.join("\n");
    }

    function buildJson(r) {
      var obj = {
        tool: "J-Dawgs Meilisearch Server Config Safety Auditor",
        generatedAt: new Date().toISOString(),
        verdict: r.verdict,
        counts: r.counts ? {
          blocker: r.counts.BLOCKER, high: r.counts.HIGH, warning: r.counts.WARNING,
          info: r.counts.INFO, notParsed: r.counts.NOTPARSED, verifiedProtections: r.counts.OK
        } : null,
        findings: r.findings.map(function (f) {
          return { severity: sevLabel(f), line: f.line, key: f.key, title: f.title, detail: f.detail };
        }),
        verifiedProtections: r.oks,
        settings: r.settings,
        limits: LIMITS
      };
      return JSON.stringify(obj, null, 2);
    }

    /* ---------------- Rendering ---------------- */
    var lastResult = null, lastReport = "", lastJson = "";
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined), "NGINX_EXAMPLE": (typeof NGINX_EXAMPLE !== 'undefined' ? NGINX_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-meilisearch-server-config-safety-auditortm',
  name: 'J-Dawgs Meilisearch Server Config Safety Auditor',
  description: 'Meilisearch ships no safety validator, so a wildcard bind with a weak or missing master key starts silently; paste any Meilisearch config (env lines, shell exports, docker-compose, systemd, CLI flags, or TOML — auto-detected) and get one deploy verdict (SAFE TO DEPLOY / DEPLOY WITH FIXES / DO NOT DE',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"], "NGINX_EXAMPLE": __core["NGINX_EXAMPLE"] }
};
