'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs OAuth Authorize-URL Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Example data ---------- */
      var FLAWED_URL = "https://auth.example.com/oauth2/authorize?response_type=token&client_id=legacy-mobile-app&redirect_uri=http://app.example.net/callback&scope=openid%20profile%20admin&client_secret=sk-demo-9f27c1deadbeef";
      var CLEAN_URL = "https://auth.example.com/oauth2/authorize?response_type=code&client_id=orders-web-app&redirect_uri=https%3A%2F%2Fapp.example.com%2Fauth%2Fcallback&scope=openid%20profile%20email&state=af3d9c27b1e84f05a6d2c8e7f0b19345&nonce=3f8a1c9e7b2d4056a1c3e5f7092b8d64&code_challenge=E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM&code_challenge_method=S256";
      var CLEAN_REGISTERED = "https://app.example.com/auth/callback";
      var CLEAN_CALLBACK = "https://app.example.com/auth/callback?code=Qcb0Orv1zh30vL1MPRsbm-diHiMwcLyZvn1arpZv-Jxf&state=af3d9c27b1e84f05a6d2c8e7f0b19345";

      var PITCHES = {
        pitch1: "Before you send any OAuth authorize link, run it through the J-Dawgs OAuth Authorize-URL Safety Auditor\u2122 \u2014 one verdict, every fault named by parameter, fully offline.",
        pitch2: "Verify the Handshake Stack \u2014 SAML Response Safety Auditor + OAuth Authorize-URL Safety Auditor + WebSocket Session Trace Auditor: grade the login, grade the flow, grade the socket \u2014 $2.50 full pass.",
        pitch3: "https://muse.ai/s/ai-tool-store-xng6xkxwjkxl2xab/UoF72OkKI7j33Q2ITxmrZyIr4nv40QtYfj2AgESh_k8",
        pitch4: "https://muse.ai/s/j-dawgs-agent-exchange-ih6xlnihzxdhxc/ZbleqxFHRE0NcswaBkyN13y9lLp5rPAgHTb6t8ii-PY"
      };

      /* ---------- Redaction ----------
         Values of state, nonce, code, code_verifier and anything secret/token-like
         are NEVER rendered in full: first 2 characters + length only. */
      var NEVER_FULL = { state: 1, nonce: 1, code: 1, code_verifier: 1 };
      var SECRET_NAME = /secret|token|password|passwd|api[-_]?key|assertion|private[-_]?key|credential/i;
      function isSensitive(name) { return !!NEVER_FULL[name] || SECRET_NAME.test(name); }
      function redact(name, value) {
        if (value === undefined || value === null) return "";
        if (isSensitive(name)) {
          if (value.length === 0) return "(empty value)";
          return value.slice(0, 2) + "\u2026 (" + value.length + " chars, full value never printed)";
        }
        return value;
      }

      /* ---------- URL parameter extraction (query + fragment), duplicates preserved ---------- */
      function paramsOf(url) {
        var list = [];
        url.searchParams.forEach(function (v, k) { list.push({ name: k, value: v, source: "query" }); });
        if (url.hash && url.hash.length > 1) {
          var frag = new URLSearchParams(url.hash.slice(1));
          frag.forEach(function (v, k) { list.push({ name: k, value: v, source: "fragment" }); });
        }
        return list;
      }
      function valuesOf(list, name) {
        var out = [];
        for (var i = 0; i < list.length; i++) if (list[i].name === name) out.push(list[i].value);
        return out;
      }
      function firstOf(list, name) { var v = valuesOf(list, name); return v.length ? v[0] : undefined; }
      function hostOf(str) {
        try { return new URL(str).hostname || "(no host)"; } catch (e) { return "(unparseable)"; }
      }
      function isLoopback(host) {
        return host === "localhost" || host === "127.0.0.1" || host === "::1" || host === "[::1]" || /\.localhost$/i.test(host);
      }

      /* Broad-scope list, built in, dated November 2026. Exact token match. */
      var BROAD_SCOPES = ["*", "all", "admin", "admin:*", "administrator", "root", "superuser", "super_user", "full", "full_access", "full-access", "god", "manage_all", "read_write_all", "*:*"];

      function audit(authUrlStr, registeredStr, callbackStr, isPublic) {
        var findings = [];
        function add(param, level, reason) { findings.push({ parameter: param, level: level, reason: reason }); }

        var authUrl;
        try { authUrl = new URL(authUrlStr); }
        catch (e) { return { parseError: "authorize" }; }
        if (!/^https?:$/i.test(authUrl.protocol)) return { parseError: "authorize" };

        var P = paramsOf(authUrl);
        var scopeRaw = firstOf(P, "scope");
        var scopeTokens = scopeRaw ? scopeRaw.split(/\s+/).filter(Boolean) : [];
        var hasOpenid = scopeTokens.indexOf("openid") !== -1;

        /* --- response_type --- */
        var rt = firstOf(P, "response_type");
        if (rt === undefined) {
          add("response_type", "BLOCKER", "Missing. The authorize request must state response_type=code so credentials come back through the back channel, not the browser.");
        } else {
          var rtParts = rt.split(/\s+/).filter(Boolean);
          var tokenish = rtParts.filter(function (t) { return t === "token" || t === "id_token"; });
          if (tokenish.length) {
            add("response_type", "BLOCKER", "response_type includes \"" + tokenish.join(" ") + "\" \u2014 implicit/hybrid token delivery. Tokens returned in the front channel land in the URL fragment or query, where they leak into browser history, server and proxy logs, and Referer headers. Use response_type=code with PKCE instead.");
          } else if (rtParts.length === 1 && rtParts[0] === "code") {
            add("response_type", "PASS", "response_type=code \u2014 authorization-code flow. The code is exchanged server-to-server, so no token ever travels through the browser.");
          } else if (rtParts.indexOf("code") !== -1) {
            add("response_type", "WARNING", "response_type is \"" + rt + "\". It includes code but is not the plain authorization-code flow \u2014 confirm this exact combination is what the provider and client were configured for.");
          } else {
            add("response_type", "WARNING", "response_type is \"" + rt + "\", not \"code\". Only the authorization-code flow (with PKCE) matches current best practice.");
          }
        }

        /* --- state --- */
        var state = firstOf(P, "state");
        if (state === undefined) {
          add("state", "BLOCKER", "Missing. Without state, the callback cannot be tied to the request that started the flow \u2014 that is the CSRF / login-confusion hole: an attacker can inject a callback from their own flow into a victim's session.");
        } else if (state.length < 16) {
          add("state", "WARNING", "Present (" + redact("state", state) + ") but only " + state.length + " characters \u2014 under the 16-character floor. Weak-entropy heuristic, length-only: this tool cannot measure real entropy, but short values are guessable and reusable.");
        } else {
          add("state", "PASS", "Present: " + redact("state", state) + " \u2014 meets the 16-character length floor (length-only check; real entropy cannot be measured from the URL).");
        }

        /* --- PKCE --- */
        var challenge = firstOf(P, "code_challenge");
        var method = firstOf(P, "code_challenge_method");
        if (challenge === undefined) {
          if (isPublic) {
            add("code_challenge", "BLOCKER", "Missing, and this is a public client. A public client cannot keep a secret, so PKCE is the only thing binding the token exchange to the device that started the flow. Without code_challenge, anyone who intercepts the code can redeem it.");
          } else {
            add("code_challenge", "WARNING", "Missing. PKCE binds the token exchange to whoever started the flow; without code_challenge an intercepted code can be redeemed by someone else. Strong warning \u2014 and a hard BLOCKER for public clients (tick the public-client box if this client cannot keep a secret).");
          }
          if (method !== undefined) {
            add("code_challenge_method", "WARNING", "code_challenge_method=\"" + method + "\" is present but there is no code_challenge for it to describe \u2014 PKCE is not actually in effect.");
          }
        } else if (method === undefined) {
          add("code_challenge", "WARNING", "code_challenge is present but code_challenge_method is missing. Provider defaults vary \u2014 several default to \"plain\", which exposes the challenge. Send code_challenge_method=S256 explicitly.");
        } else if (method === "plain") {
          add("code_challenge_method", "BLOCKER", "code_challenge_method=plain sends the verifier effectively unhashed \u2014 anyone who sees the authorize URL holds the PKCE secret, so PKCE protects nothing. Use S256.");
        } else if (method === "S256") {
          add("code_challenge", "PASS", "PKCE present with code_challenge_method=S256 \u2014 the challenge is the SHA-256 hash of a secret verifier that never appears in this URL.");
        } else {
          add("code_challenge_method", "WARNING", "code_challenge_method is \"" + method + "\", not the standard \"S256\". Confirm the provider actually supports it.");
        }

        /* --- nonce (OIDC) --- */
        var nonce = firstOf(P, "nonce");
        if (nonce === undefined) {
          if (hasOpenid) {
            add("nonce", "WARNING", "Missing while scope includes openid. nonce is the OIDC replay protection: it binds the returned ID token to this exact request, so a captured ID token cannot be replayed into a new session.");
          } else {
            add("nonce", "INFO", "Absent, and scope does not include openid, so nonce (an OIDC-only value) is not expected here.");
          }
        } else {
          add("nonce", "PASS", "Present: " + redact("nonce", nonce) + " \u2014 the ID token can be bound to this request (replay protection).");
        }

        /* --- redirect_uri --- */
        var redirect = firstOf(P, "redirect_uri");
        if (redirect === undefined) {
          add("redirect_uri", "WARNING", "Missing \u2014 the provider's pre-registered default will be used, if one exists. Relying on a default you cannot see in the URL is fragile; send redirect_uri explicitly.");
        } else {
          var rUrl = null;
          try { rUrl = new URL(redirect); } catch (e) { rUrl = null; }
          if (!rUrl) {
            add("redirect_uri", "BLOCKER", "The redirect_uri value \"" + redirect + "\" is not a parseable absolute URL, so the provider cannot safely match or use it.");
          } else {
            if (redirect.indexOf("#") !== -1) {
              add("redirect_uri", "BLOCKER", "redirect_uri contains a fragment (#\u2026). Fragments are forbidden in redirect_uri \u2014 they change how the callback is parsed and can smuggle parameters past matching.");
            }
            if (rUrl.protocol === "http:" && !isLoopback(rUrl.hostname)) {
              add("redirect_uri", "BLOCKER", "redirect_uri uses plain http:// to a non-loopback host (" + rUrl.hostname + "). The authorization code crosses the network in clear text on the redirect and can be intercepted. Use https:// (loopback http is the only accepted exception, for native apps).");
            } else if (rUrl.protocol === "https:") {
              if (redirect.indexOf("#") === -1) add("redirect_uri", "PASS", "https redirect to host " + rUrl.hostname + " \u2014 encrypted in transit, no fragment.");
            } else if (rUrl.protocol === "http:" && isLoopback(rUrl.hostname)) {
              add("redirect_uri", "PASS", "http redirect to loopback host " + rUrl.hostname + " \u2014 the accepted native-app exception; traffic never leaves the device.");
            } else {
              add("redirect_uri", "INFO", "redirect_uri uses the \"" + rUrl.protocol.replace(":", "") + "\" scheme (host " + rUrl.hostname + "). Custom schemes are normal for native apps; confirm the scheme is registered only to your app.");
            }
          }
          /* exact-match against registered value */
          if (registeredStr) {
            if (redirect === registeredStr) {
              add("redirect_uri (registered match)", "PASS", "redirect_uri exactly matches the registered value, character for character, host " + hostOf(redirect) + ".");
            } else {
              var pos = -1, minLen = Math.min(redirect.length, registeredStr.length);
              for (var i = 0; i < minLen; i++) { if (redirect.charAt(i) !== registeredStr.charAt(i)) { pos = i; break; } }
              if (pos === -1) pos = minLen;
              var aHost = hostOf(redirect), rHost = hostOf(registeredStr);
              add("redirect_uri (registered match)", "BLOCKER", "redirect_uri does NOT exactly match the registered value. First difference at character " + (pos + 1) + " (1-based). Authorize host: " + aHost + " \u00b7 registered host: " + rHost + ". OAuth matching is exact-string \u2014 there is no \"close enough\", and a one-character difference is exactly how codes get sent to the wrong place.");
              var lookalike = (aHost !== rHost) && (aHost.indexOf(rHost + ".") === 0 || rHost.indexOf(aHost + ".") === 0 || aHost.slice(-(rHost.length + 1)) === "." + rHost || rHost.slice(-(aHost.length + 1)) === "." + aHost);
              if (lookalike) {
                add("redirect_uri (lookalike host)", "WARNING", "Heuristic warning: the two hosts differ only by an added suffix label (" + aHost + " vs " + rHost + ") \u2014 the classic lookalike pattern, e.g. example.com.attacker.test riding on a trusted name. Treat as hostile until proven registered.");
              }
            }
          }
        }

        /* --- scope --- */
        if (scopeRaw === undefined || scopeTokens.length === 0) {
          add("scope", "INFO", "No scope parameter \u2014 the provider's default grant applies, whatever that is. Naming scopes explicitly makes the request reviewable.");
        } else {
          var broad = scopeTokens.filter(function (t) { return BROAD_SCOPES.indexOf(t.toLowerCase()) !== -1 || t.indexOf("*") !== -1; });
          if (broad.length) {
            add("scope", "WARNING", "Overly broad scope requested: \"" + broad.join("\", \"") + "\" (flagged by name from this tool's built-in broad-scope list, dated November 2026). Least privilege: request only the scopes this client actually uses, so a leaked token buys an attacker less.");
          } else {
            add("scope", "PASS", "Scopes requested: " + scopeTokens.join(", ") + " \u2014 none match the built-in broad-scope list (dated November 2026).");
          }
        }

        /* --- secrets / tokens in the front channel --- */
        var seenSecret = {};
        for (var s = 0; s < P.length; s++) {
          var nm = P[s].name;
          if (SECRET_NAME.test(nm) && !seenSecret[nm]) {
            seenSecret[nm] = 1;
            add(nm, "BLOCKER", "A secret/token parameter named \"" + nm + "\" is present in the authorize URL (value never printed: " + redact(nm, P[s].value) + "). Secrets never belong in a front-channel URL \u2014 authorize URLs sit in browser history, logs, analytics, and Referer headers. Secrets go in the back-channel token request only.");
          }
        }

        /* --- duplicates with conflicting values --- */
        var byName = {};
        for (var d = 0; d < P.length; d++) {
          if (!byName[P[d].name]) byName[P[d].name] = [];
          byName[P[d].name].push(P[d].value);
        }
        Object.keys(byName).forEach(function (name) {
          var vals = byName[name];
          if (vals.length > 1) {
            var uniq = vals.filter(function (v, idx) { return vals.indexOf(v) === idx; });
            if (uniq.length > 1) {
              add(name + " (duplicate)", "WARNING", "Parameter \"" + name + "\" appears " + vals.length + " times with conflicting values. Different parsers resolve duplicates differently (first-value-wins ambiguity): the provider may honor a different value than the one you reviewed. Send each parameter once.");
            } else {
              add(name + " (duplicate)", "INFO", "Parameter \"" + name + "\" appears " + vals.length + " times with the same value \u2014 harmless here, but duplicate parameters are worth removing for clarity.");
            }
          }
        });

        /* --- callback cross-check --- */
        var callbackChecked = false;
        if (callbackStr) {
          var cbUrl;
          try { cbUrl = new URL(callbackStr); } catch (e) { return { parseError: "callback" }; }
          callbackChecked = true;
          var C = paramsOf(cbUrl);
          var cbState = firstOf(C, "state");
          if (state !== undefined) {
            if (cbState === undefined) {
              add("state (callback)", "BLOCKER", "The authorize URL sent state " + redact("state", state) + " but the callback carries no state at all. An unauthenticated callback cannot be trusted \u2014 accept nothing from it.");
            } else if (cbState !== state) {
              add("state (callback)", "BLOCKER", "State mismatch. Authorize URL state: " + redact("state", state) + " \u00b7 callback state: " + redact("state", cbState) + ". They must be identical; a mismatch means this callback does not belong to the flow you started (possible CSRF / login confusion). Reject it.");
            } else {
              add("state (callback)", "PASS", "Callback state matches the authorize URL state (" + redact("state", state) + ") \u2014 this callback belongs to the flow that was started.");
            }
          } else {
            add("state (callback)", "INFO", "The authorize URL carried no state, so there is nothing to cross-check the callback against \u2014 see the state BLOCKER above.");
          }
          var cbError = firstOf(C, "error");
          if (cbError !== undefined) {
            add("error (callback)", "WARNING", "The provider returned an error in the callback: error=" + cbError + " (reported verbatim). The flow did not complete; read the provider's documentation for this error code before retrying.");
          }
          var codeQuery = undefined, codeFrag = undefined;
          for (var c = 0; c < C.length; c++) {
            if (C[c].name === "code") { if (C[c].source === "query") codeQuery = C[c].value; else codeFrag = C[c].value; }
          }
          if (codeFrag !== undefined && codeQuery === undefined) {
            add("code (callback)", "WARNING", "The authorization code arrived in the callback's fragment instead of its query (" + redact("code", codeFrag) + "). Fragments are not sent to servers, so a server-side callback handler never sees this code \u2014 and fragment delivery is the implicit-flow pattern this audit flags elsewhere.");
          } else if (codeQuery !== undefined) {
            add("code (callback)", "PASS", "Authorization code present in the callback query: " + redact("code", codeQuery) + " \u2014 the normal delivery path for the code flow.");
          } else if (cbError === undefined) {
            add("code (callback)", "INFO", "No code in the callback URL. Expected if the flow used a non-code response type or the user has not finished it.");
          }
        }

        var blockers = findings.filter(function (f) { return f.level === "BLOCKER"; }).length;
        var warnings = findings.filter(function (f) { return f.level === "WARNING"; }).length;
        var infos = findings.filter(function (f) { return f.level === "INFO"; }).length;
        var verdict = blockers > 0 ? "DO NOT SEND" : (warnings > 0 ? "SEND WITH FIXES" : "SAFE TO SEND");
        return {
          verdict: verdict,
          findings: findings,
          counts: { blockers: blockers, warnings: warnings, infos: infos },
          endpoint: authUrl.protocol + "//" + authUrl.host + authUrl.pathname,
          publicClient: !!isPublic,
          callbackChecked: callbackChecked
        };
      }

      /* ---------- Rendering ---------- */
      var lastResult = null;

      function esc(s) {
        return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
      }

      function reportText(r) {
        var lines = [];
        lines.push("J-Dawgs OAuth Authorize-URL Safety Auditor\u2122 \u2014 audit report");
        lines.push("Audited locally in the browser on " + new Date().toLocaleString() + ". Nothing was uploaded; the audited URL was never fetched.");
        lines.push("Authorize endpoint (host + path only): " + r.endpoint);
        lines.push("Public client: " + (r.publicClient ? "yes" : "no") + " \u00b7 Callback cross-checked: " + (r.callbackChecked ? "yes" : "no"));
        lines.push("");
        lines.push("VERDICT: " + r.verdict);
        lines.push("Findings: " + r.counts.blockers + " blocker(s), " + r.counts.warnings + " warning(s), " + r.counts.infos + " info note(s).");
        lines.push("");
        r.findings.forEach(function (f) {
          lines.push("[" + f.level + "] " + f.parameter + " \u2014 " + f.reason);
        });
        lines.push("");
        lines.push("Redaction: values of state, nonce, code, and any secret/token parameter are shown as first 2 characters + length only, everywhere in this report.");
        lines.push("Limits: this audits the URLs as pasted only. It cannot know the provider's server-side enforcement, registered values beyond the one supplied, or real entropy. It never contacts the provider.");
        return lines.join("\n");
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-oauth-authorize-url-safety-auditor',
  name: 'J-Dawgs OAuth Authorize-URL Safety Auditor',
  description: 'Audits a pasted OAuth authorize URL offline before the flow runs — implicit response_type, missing state, plain or missing PKCE, http redirect_uri, secrets in the URL — one verdict: SAFE TO SEND / SEND WITH FIXES / DO NOT SEND.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
