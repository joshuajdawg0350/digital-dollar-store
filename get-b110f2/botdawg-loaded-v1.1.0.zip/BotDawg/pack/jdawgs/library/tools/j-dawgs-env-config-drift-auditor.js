'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Env & Config Drift Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var $ = function (id) { return document.getElementById(id); };
        var inActual = $("in-actual"), inTemplate = $("in-template"), inRefs = $("in-refs");

        /* ---------------- Samples ---------------- */

        var SAMPLE_DRIFT_ACTUAL = [
          "# Production env — app server (pasted from the live box)",
          "DATABASE_URL=postgres://db.internal:5432/app",
          "API_KEY=changeme",
          "export FEED_TOKEN_V2=fd9c-real-token-value",
          "PORT=99999",
          "MAX_RETRIES=three",
          "CACHE_ENABLED=maybe",
          "EMPTY_THING=",
          "DATABASE_URL=postgres://db.internal:5432/app2",
          "WORKER_COUNT=4",
          "LEGACY_MODE=true"
        ].join("\n");

        var SAMPLE_DRIFT_TEMPLATE = [
          "# .env.example",
          "DATABASE_URL=",
          "API_KEY=",
          "FEED_TOKEN=",
          "PORT=",
          "MAX_RETRIES=",
          "CACHE_ENABLED=",
          "EMPTY_THING=",
          "SESSION_SECRET="
        ].join("\n");

        var SAMPLE_DRIFT_REFS = [
          "// app startup",
          "const token = process.env.FEED_TOKEN;",
          "const db = process.env.DATABASE_URL;",
          "const port = process.env.PORT;",
          "await fetch(process.env.WEBHOOK_URL, { method: \"POST\" });",
          "",
          "# deploy.yml",
          "env:",
          "  API_KEY: ${API_KEY}",
          "steps:",
          "  - run: echo \"retries=$MAX_RETRIES cache=$CACHE_ENABLED\""
        ].join("\n");

        var SAMPLE_CLEAN_ACTUAL = [
          "DATABASE_URL=postgres://db.internal:5432/app",
          "API_KEY=sk-live-9f27c1realvalue",
          "PORT=8080",
          "CACHE_ENABLED=true",
          "MAX_RETRIES=3"
        ].join("\n");

        var SAMPLE_CLEAN_TEMPLATE = [
          "# .env.example",
          "DATABASE_URL=",
          "API_KEY=",
          "PORT=",
          "CACHE_ENABLED=",
          "MAX_RETRIES="
        ].join("\n");

        var SAMPLE_CLEAN_REFS = [
          "const db = process.env.DATABASE_URL;",
          "const key = process.env.API_KEY;",
          "const port = process.env.PORT;",
          "const cache = process.env.CACHE_ENABLED;",
          "const retries = process.env.MAX_RETRIES;"
        ].join("\n");

        /* ---------------- Parsing ---------------- */

        function parseEnv(text) {
          var entries = new Map();
          var order = [];
          var lines = String(text).split(/\r?\n/);
          for (var i = 0; i < lines.length; i++) {
            var lineNo = i + 1;
            var line = lines[i].trim();
            if (!line || line.charAt(0) === "#") continue;
            if (line.indexOf("export ") === 0) line = line.slice(7).trim();
            var eq = line.indexOf("=");
            if (eq === -1) continue;
            var key = line.slice(0, eq).trim();
            if (!/^[A-Za-z_][A-Za-z0-9_.]*$/.test(key)) continue;
            var val = line.slice(eq + 1).trim();
            var first = val.charAt(0), last = val.charAt(val.length - 1);
            if (val.length >= 2 && ((first === '"' && last === '"') || (first === "'" && last === "'"))) {
              val = val.slice(1, -1);
            } else {
              var hash = val.indexOf(" #");
              if (hash !== -1) val = val.slice(0, hash).trim();
            }
            if (!entries.has(key)) {
              entries.set(key, { value: val, lines: [] });
              order.push(key);
            }
            var e = entries.get(key);
            e.lines.push(lineNo);
            e.value = val; // last definition wins, like a shell
          }
          return { entries: entries, order: order };
        }

        function extractRefs(text) {
          var refs = new Map(); // name -> Set of pattern labels
          function add(name, how) {
            if (!refs.has(name)) refs.set(name, new Set());
            refs.get(name).add(how);
          }
          var src = String(text);
          var m;
          var rules = [
            [/process\.env\.([A-Za-z_][A-Za-z0-9_]*)/g, "process.env.NAME"],
            [/process\.env\[["']([A-Za-z_][A-Za-z0-9_]*)["']\]/g, "process.env[\"NAME\"]"],
            [/os\.environ\[["']([A-Za-z_][A-Za-z0-9_]*)["']\]/g, "os.environ[\"NAME\"]"],
            [/os\.environ\.get\(["']([A-Za-z_][A-Za-z0-9_]*)["']/g, "os.environ.get(\"NAME\")"],
            [/os\.getenv\(["']([A-Za-z_][A-Za-z0-9_]*)["']/g, "os.getenv(\"NAME\")"],
            [/\$\{([A-Za-z_][A-Za-z0-9_]*)/g, "${NAME}"],
            [/secrets\.([A-Za-z_][A-Za-z0-9_]*)/g, "secrets.NAME"],
            [/(^|[^A-Za-z0-9_.])env\.([A-Za-z_][A-Za-z0-9_]*)/gm, "env.NAME", 2],
            [/\$([A-Z_][A-Z0-9_]*)/g, "$NAME"]
          ];
          for (var r = 0; r < rules.length; r++) {
            var re = rules[r][0], label = rules[r][1], group = rules[r][2] || 1;
            re.lastIndex = 0;
            while ((m = re.exec(src)) !== null) {
              if (m[group]) add(m[group], label);
              if (re.lastIndex === m.index) re.lastIndex++;
            }
          }
          return refs;
        }

        /* ---------------- Checks ---------------- */

        var PLACEHOLDER_RES = [
          [/change[-_]?me/i, "changeme"],
          [/placeholder/i, "placeholder"],
          [/your[-_]/i, "your-…"],
          [/example/i, "example"],
          [/todo/i, "todo"],
          [/xxx/i, "xxx"],
          [/replace[-_]?me/i, "replace-me"]
        ];

        function mask(v) {
          if (v === "") return "(empty)";
          if (v.length <= 3) return "••• (len " + v.length + ")";
          return v.slice(0, 2) + "••• (len " + v.length + ")";
        }

        function shapeIssues(name, value) {
          var issues = [];
          if (value === "") return issues;
          var up = name.toUpperCase();
          var tokens = up.split("_");
          var isPort = tokens.indexOf("PORT") !== -1;
          if (isPort) {
            if (!/^\d+$/.test(value)) {
              issues.push({ cls: "SHAPE ISSUE", sev: "warn", detail: "port field holds a non-numeric value " + mask(value) });
            } else {
              var n = parseInt(value, 10);
              if (n < 1 || n > 65535) {
                issues.push({ cls: "SHAPE ISSUE", sev: "bad", detail: "port value " + mask(value) + " is outside 1–65535" });
              }
            }
          } else if (/_COUNT|_LIMIT|_TIMEOUT|_RETRIES|_SIZE|_SECONDS/.test(up)) {
            if (!/^-?\d+(\.\d+)?$/.test(value)) {
              issues.push({ cls: "SHAPE ISSUE", sev: "warn", detail: "numeric field contains non-numeric text: " + mask(value) });
            }
          }
          if (tokens.indexOf("URL") !== -1 || /URL$/.test(up)) {
            var okUrl = true;
            try { new URL(value); } catch (e) { okUrl = false; }
            if (!okUrl) {
              issues.push({ cls: "SHAPE ISSUE", sev: "warn", detail: "URL field holds a malformed URL: " + mask(value) });
            }
          }
          var boolLike = /_ENABLED|_DISABLED/.test(up) || /^ENABLE_/.test(up) || /^DISABLE_/.test(up) || /_FLAG$/.test(up);
          if (boolLike) {
            if (!/^(true|false|1|0|yes|no|on|off)$/i.test(value)) {
              issues.push({ cls: "SHAPE ISSUE", sev: "warn", detail: "boolean field holds a non-boolean value: " + mask(value) });
            }
          }
          return issues;
        }

        function levenshtein(a, b) {
          var m = a.length, n = b.length, i, j;
          var prev = [], cur = [];
          for (j = 0; j <= n; j++) prev[j] = j;
          for (i = 1; i <= m; i++) {
            cur[0] = i;
            for (j = 1; j <= n; j++) {
              cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a.charAt(i - 1) === b.charAt(j - 1) ? 0 : 1));
            }
            var tmp = prev; prev = cur; cur = tmp;
          }
          return prev[n];
        }

        function nearMisses(refName, setNames) {
          var suffixes = ["_V1", "_V2", "_V3", "_OLD", "_NEW", "_LEGACY", "S"];
          var prefixes = ["OLD_", "NEW_", "APP_"];
          var hits = [];
          for (var i = 0; i < setNames.length; i++) {
            var s = setNames[i];
            if (s === refName) continue;
            var reason = null;
            if (s.indexOf(refName) === 0 && suffixes.indexOf(s.slice(refName.length)) !== -1) {
              reason = "set name is this name plus suffix \"" + s.slice(refName.length) + "\"";
            } else if (refName.indexOf(s) === 0 && suffixes.indexOf(refName.slice(s.length)) !== -1) {
              reason = "referenced name is the set name plus suffix \"" + refName.slice(s.length) + "\"";
            } else if (s.length > refName.length && s.slice(s.length - refName.length) === refName && prefixes.indexOf(s.slice(0, s.length - refName.length)) !== -1) {
              reason = "set name adds the prefix \"" + s.slice(0, s.length - refName.length) + "\"";
            } else if (levenshtein(refName, s) === 1) {
              reason = "names differ by one character";
            }
            if (reason) hits.push({ setName: s, reason: reason });
          }
          return hits;
        }

        /* ---------------- Audit ---------------- */

        var CLASS_ORDER = ["MISSING FROM ACTUAL", "MISSING FROM TEMPLATE", "PLACEHOLDER VALUE", "EMPTY VALUE", "DUPLICATE KEY", "NEAR-MISS NAME", "SHAPE ISSUE"];

        function audit() {
          var actual = parseEnv(inActual.value);
          var template = parseEnv(inTemplate.value);
          var refs = extractRefs(inRefs.value);

          var names = [];
          var seen = new Set();
          function pushName(n) { if (!seen.has(n)) { seen.add(n); names.push(n); } }
          actual.order.forEach(pushName);
          template.order.forEach(pushName);
          refs.forEach(function (_, n) { pushName(n); });
          names.sort();

          var rows = [];
          var counts = {};
          CLASS_ORDER.forEach(function (c) { counts[c] = 0; });
          var okCount = 0;
          var anyPlaceholder = false, anyRefUnset = false, anyFinding = false;

          names.forEach(function (name) {
            var inA = actual.entries.has(name);
            var inT = template.entries.has(name);
            var isRef = refs.has(name);
            var findings = [];

            if ((inT || isRef) && !inA) {
              var why = [];
              if (inT) why.push("listed in the template");
              if (isRef) why.push("referenced via " + Array.from(refs.get(name)).join(", "));
              findings.push({ cls: "MISSING FROM ACTUAL", sev: "bad", detail: why.join(" and ") + ", but not set in the actual environment" });
              if (isRef) anyRefUnset = true;
            }
            if ((inA || isRef) && !inT) {
              var why2 = [];
              if (inA) why2.push("set in the actual environment");
              if (isRef) why2.push("referenced via " + Array.from(refs.get(name)).join(", "));
              findings.push({ cls: "MISSING FROM TEMPLATE", sev: "warn", detail: why2.join(" and ") + ", but not documented in the template" });
            }
            if (inA) {
              var entry = actual.entries.get(name);
              var value = entry.value;
              for (var p = 0; p < PLACEHOLDER_RES.length; p++) {
                if (PLACEHOLDER_RES[p][0].test(value)) {
                  findings.push({ cls: "PLACEHOLDER VALUE", sev: "bad", detail: "value " + mask(value) + " matches the \"" + PLACEHOLDER_RES[p][1] + "\" placeholder pattern" });
                  anyPlaceholder = true;
                  break;
                }
              }
              if (value === "") {
                findings.push({ cls: "EMPTY VALUE", sev: "warn", detail: "set in the actual environment with an empty value" });
              }
              if (entry.lines.length > 1) {
                findings.push({ cls: "DUPLICATE KEY", sev: "warn", detail: "defined " + entry.lines.length + " times in the actual env (lines " + entry.lines.join(" and ") + "); the last value wins" });
              }
              shapeIssues(name, value).forEach(function (si) { findings.push(si); });
            }
            if (inT && template.entries.get(name).lines.length > 1) {
              findings.push({ cls: "DUPLICATE KEY", sev: "warn", detail: "defined " + template.entries.get(name).lines.length + " times in the template (lines " + template.entries.get(name).lines.join(" and ") + ")" });
            }
            if (isRef && !inA) {
              nearMisses(name, actual.order).forEach(function (hit) {
                findings.push({
                  cls: "NEAR-MISS NAME", sev: "bad",
                  detail: "similar to " + hit.setName + ", which IS set (" + hit.reason + ") — suspected rename, not confirmed"
                });
              });
            }

            findings.forEach(function (f) { counts[f.cls]++; anyFinding = true; });
            if (findings.length === 0) okCount++;
            rows.push({ name: name, inA: inA, inT: inT, isRef: isRef, refVia: isRef ? Array.from(refs.get(name)) : [], findings: findings });
          });

          var verdict, verdictClass, verdictWhy;
          if (anyPlaceholder || anyRefUnset) {
            verdict = "DO NOT DEPLOY"; verdictClass = "stop";
            var bits = [];
            if (anyPlaceholder) bits.push("a placeholder value is set in the actual environment");
            if (anyRefUnset) bits.push("code or config references variables that are set nowhere");
            verdictWhy = "Blocked: " + bits.join(", and ") + ".";
          } else if (anyFinding) {
            verdict = "DRIFT FOUND"; verdictClass = "drift";
            verdictWhy = "No blockers, but the three texts disagree — reconcile them before the next deploy.";
          } else {
            verdict = "SAFE TO DEPLOY"; verdictClass = "safe";
            verdictWhy = "No drift among the three pasted texts. That is all this check can say — it does not prove production itself is correct.";
          }

          return {
            rows: rows, counts: counts, okCount: okCount,
            verdict: verdict, verdictClass: verdictClass, verdictWhy: verdictWhy,
            actual: actual, template: template, refs: refs, empty: names.length === 0
          };
        }

        /* ---------------- Corrected template & report ---------------- */

        function correctedExample(result) {
          var templateText = inTemplate.value.replace(/\s+$/, "");
          var missing = [];
          result.rows.forEach(function (row) {
            if (!row.inT) missing.push(row);
          });
          var out = templateText ? templateText : "# .env.example";
          if (missing.length === 0) {
            return { text: out + "\n", added: 0 };
          }
          var lines = [out, "", "# --- Added by the Drift Auditor: keys missing from this template ---", "# Values are intentionally left blank — fill them in per environment."];
          missing.forEach(function (row) {
            var note;
            if (row.inA && row.isRef) note = "set in the actual env and referenced in pasted code/config, but missing from this template";
            else if (row.isRef) note = "referenced in pasted code/config (via " + row.refVia.join(", ") + "), but missing from this template and not set in the actual env";
            else note = "set in the actual env, but missing from this template";
            lines.push("");
            lines.push("# " + row.name + " — " + note);
            lines.push(row.name + "=");
          });
          return { text: lines.join("\n") + "\n", added: missing.length };
        }

        function buildReport(result, corrected) {
          var L = [];
          L.push("J-Dawgs Env & Config Drift Auditor™ — audit report");
          L.push("Verdict: " + result.verdict);
          L.push("");
          L.push("Counts (variables per class; one variable can appear in several classes):");
          CLASS_ORDER.forEach(function (c) { L.push("  " + c + ": " + result.counts[c]); });
          L.push("  OK (no findings): " + result.okCount);
          L.push("  Variables checked: " + result.rows.length);
          L.push("");
          L.push("Per-variable findings (secret values are masked — first two characters + length only):");
          var anyF = false;
          result.rows.forEach(function (row) {
            var where = [];
            if (row.inA) where.push("actual");
            if (row.inT) where.push("template");
            if (row.isRef) where.push("referenced");
            L.push("- " + row.name + " [" + where.join(", ") + "]");
            if (row.findings.length === 0) {
              L.push("    OK");
            } else {
              anyF = true;
              row.findings.forEach(function (f) { L.push("    " + f.cls + ": " + f.detail); });
            }
          });
          if (!anyF) L.push("  (no findings)");
          L.push("");
          L.push("Corrected template: " + corrected.added + " key(s) were missing from the template and have been added as NAME= with an explanatory comment. No values were invented.");
          L.push("");
          L.push("Notes:");
          L.push("- Near-miss names are suspected renames based on similarity only — never confirmed facts.");
          L.push("- This report compares only the three texts pasted into the tool. It does not read a live server, a secrets manager, or a repo, so a clean result means no drift among the pasted texts — not that production is correct.");
          return L.join("\n");
        }

        /* ---------------- Rendering ---------------- */

        function esc(s) {
          return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
        }

        function render(result, corrected, report) {
          var box = $("verdict-box");
          box.className = "verdict " + result.verdictClass;
          $("verdict-label").textContent = result.verdict;
          $("verdict-why").textContent = result.verdictWhy;

          var countsHtml = CLASS_ORDER.map(function (c) {
            var n = result.counts[c];
            var cls = "count-chip" + (n === 0 ? " zero" : (c === "PLACEHOLDER VALUE" || c === "MISSING FROM ACTUAL" || c === "NEAR-MISS NAME" ? " hot-bad" : " hot-warn"));
            return '<span class="' + cls + '">' + esc(c) + ": <b>" + n + "</b></span>";
          }).join("");
          countsHtml += '<span class="count-chip' + (result.okCount === 0 ? " zero" : "") + '">OK: <b>' + result.okCount + "</b></span>";
          countsHtml += '<span class="count-chip">Variables checked: <b>' + result.rows.length + "</b></span>";
          $("counts").innerHTML = countsHtml;

          var rowsHtml = result.rows.map(function (row) {
            var src =
              '<span class="src' + (row.inA ? "" : " off") + '">Actual</span>' +
              '<span class="src' + (row.inT ? "" : " off") + '">Template</span>' +
              '<span class="src' + (row.isRef ? "" : " off") + '">Referenced</span>';
            var finds;
            if (row.findings.length === 0) {
              finds = '<span class="ok-text">OK — consistent across all three texts</span>';
            } else {
              finds = row.findings.map(function (f) {
                return '<span class="finding"><span class="tag ' + (f.sev === "bad" ? "bad" : "warn") + '">' + esc(f.cls) + "</span>" + esc(f.detail) + "</span>";
              }).join("");
            }
            return "<tr><td class=\"var\">" + esc(row.name) + "</td><td>" + src + "</td><td>" + finds + "</td></tr>";
          }).join("");
          $("rows").innerHTML = rowsHtml;

          $("out-example").textContent = corrected.text;
          $("out-report").textContent = report;
          $("results").classList.add("show");
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "SAMPLE_DRIFT_ACTUAL": (typeof SAMPLE_DRIFT_ACTUAL !== 'undefined' ? SAMPLE_DRIFT_ACTUAL : undefined), "SAMPLE_DRIFT_TEMPLATE": (typeof SAMPLE_DRIFT_TEMPLATE !== 'undefined' ? SAMPLE_DRIFT_TEMPLATE : undefined), "SAMPLE_DRIFT_REFS": (typeof SAMPLE_DRIFT_REFS !== 'undefined' ? SAMPLE_DRIFT_REFS : undefined), "SAMPLE_CLEAN_ACTUAL": (typeof SAMPLE_CLEAN_ACTUAL !== 'undefined' ? SAMPLE_CLEAN_ACTUAL : undefined), "SAMPLE_CLEAN_TEMPLATE": (typeof SAMPLE_CLEAN_TEMPLATE !== 'undefined' ? SAMPLE_CLEAN_TEMPLATE : undefined), "SAMPLE_CLEAN_REFS": (typeof SAMPLE_CLEAN_REFS !== 'undefined' ? SAMPLE_CLEAN_REFS : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-env-config-drift-auditor',
  name: 'J-Dawgs Env & Config Drift Auditor',
  description: 'Crosses .env vs .env.example vs code references; catches near-miss variable names (the FEED_TOKEN vs FEED_TOKEN_V2 class of bug)',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "SAMPLE_DRIFT_ACTUAL": __core["SAMPLE_DRIFT_ACTUAL"], "SAMPLE_DRIFT_TEMPLATE": __core["SAMPLE_DRIFT_TEMPLATE"], "SAMPLE_DRIFT_REFS": __core["SAMPLE_DRIFT_REFS"], "SAMPLE_CLEAN_ACTUAL": __core["SAMPLE_CLEAN_ACTUAL"], "SAMPLE_CLEAN_TEMPLATE": __core["SAMPLE_CLEAN_TEMPLATE"], "SAMPLE_CLEAN_REFS": __core["SAMPLE_CLEAN_REFS"] }
};
