'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Immich Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var RISKY_EXAMPLE = [
          "# Immich example config — risky on purpose, for testing the auditor",
          "DB_HOST=localhost",
          "DB_USERNAME=postgres",
          "DB_PASSWORD=changeme",
          "UPLOAD_LOCATION=/",
          "IMMICH_WORKERS_INCLUDE=all",
          "IMMICH_MACHINE_LEARNING_URL=http://ml.example.com:3003",
          "IMMICH_TELEMETRY_INCLUDE=all",
          "JWT_SECRET=abc123",
          "disablePasswordLogin=false",
          "MAP_STYLE_URL=https://tiles.example.com/style.json"
        ].join("\n");

        var HARDENED_EXAMPLE = [
          "# Immich example config — hardened",
          "# This instance sits behind a reverse proxy with SSO / OAuth (OIDC) login in front of it.",
          "DB_HOSTNAME=db.internal.local",
          "DB_DATABASE_NAME=immich",
          "DB_USERNAME=immich_svc_01",
          "DB_PASSWORD=Kx9f2mQ7vR4tZ8pL3nW6sD1hJ5bN0cXa4eG7u",
          "UPLOAD_LOCATION=/data/immich/upload",
          "IMMICH_WORKERS_INCLUDE=api,immich",
          "IMMICH_MACHINE_LEARNING_URL=https://ml.internal.local:3003",
          "IMMICH_TELEMETRY_INCLUDE=",
          "JWT_SECRET=9f8e7d6c5b4a39281706f5e4d3c2b1a09f8e7d6c5b4a39281706f5e4d3c2b1a0",
          "disablePasswordLogin=true",
          "MAP_STYLE_URL="
        ].join("\n");

        var SEV_ORDER = { CRITICAL:0, HIGH:1, MEDIUM:2, LOW:3, INFO:4 };
        var SECRET_TOKENS = ["PASSWORD","SECRET","TOKEN","JWT","APIKEY","AUTH","PRIVATE"];
        var DEFAULT_USERS = ["immich","postgres","admin","root","user","db","default"];

        var els = {
          input: document.getElementById("configInput"),
          inputStatus: document.getElementById("inputStatus"),
          verdictBox: document.getElementById("verdictBox"),
          verdictValue: document.getElementById("verdictValue"),
          verdictRule: document.getElementById("verdictRule"),
          countsRow: document.getElementById("countsRow"),
          findingsWrap: document.getElementById("findingsWrap"),
          reportText: document.getElementById("reportText"),
          copyStatus: document.getElementById("copyStatus"),
          passStatus: document.getElementById("passStatus"),
          btnCopyReport: document.getElementById("btnCopyReport"),
          btnCopyJson: document.getElementById("btnCopyJson"),
          btnDownloadJson: document.getElementById("btnDownloadJson")
        };

        var lastReport = "";
        var lastJson = "";

        function normalizeKey(k){
          return String(k).toUpperCase().replace(/[^A-Z0-9]/g, "");
        }
        function isSecretKey(norm){
          for (var i=0;i<SECRET_TOKENS.length;i++){
            if (norm.indexOf(SECRET_TOKENS[i]) !== -1) return true;
          }
          return false;
        }
        function isJwtKey(norm){
          return norm.indexOf("JWT") !== -1 || norm === "SESSIONSECRET";
        }
        function cleanValue(v){
          v = v.replace(/\s+$/, "");
          if (v.charAt(v.length-1) === ",") v = v.slice(0, v.length-1).replace(/\s+$/, "");
          if (v.length >= 2){
            var first = v.charAt(0), last = v.charAt(v.length-1);
            if ((first === '"' && last === '"') || (first === "'" && last === "'")){
              return v.slice(1, v.length-1);
            }
          }
          if (v.charAt(0) === '"' || v.charAt(0) === "'"){
            var q = v.charAt(0);
            var end = v.indexOf(q, 1);
            if (end > 0) return v.slice(1, end);
          }
          var hashIdx = v.indexOf(" #");
          if (hashIdx !== -1) v = v.slice(0, hashIdx);
          return v.replace(/\s+$/, "");
        }

        function parseConfig(text){
          var entries = [];
          var lines = String(text).split(/\r?\n/);
          for (var i=0;i<lines.length;i++){
            var lineNo = i+1;
            var t = lines[i].replace(/^\s+/, "").replace(/\s+$/, "");
            if (!t) continue;
            if (t.charAt(0) === "#") continue;
            if (t.indexOf("//") === 0) continue;
            var s = t;
            if (s.indexOf("export ") === 0) s = s.slice(7).replace(/^\s+/, "");
            if (s.charAt(0) === "-") s = s.slice(1).replace(/^\s+/, "");
            var key = null, value = null, m = null;
            m = s.match(/^["']([^"']+)["']\s*:\s*(.*)$/);
            if (m){ key = m[1]; value = m[2]; }
            else {
              var eq = s.indexOf("=");
              var colon = s.indexOf(":");
              if (eq > 0 && (colon === -1 || eq < colon)){ key = s.slice(0, eq); value = s.slice(eq+1); }
              else if (colon > 0){ key = s.slice(0, colon); value = s.slice(colon+1); }
              else continue;
            }
            key = key.replace(/^\s+/, "").replace(/\s+$/, "").replace(/^["']/, "").replace(/["']$/, "");
            if (!key) continue;
            value = cleanValue(String(value).replace(/^\s+/, ""));
            if (value === "{" || value === "[" || value === "}" || value === "]") continue;
            entries.push({ key:key, norm:normalizeKey(key), value:value, line:lineNo });
          }
          return entries;
        }

        function findEntry(entries, norms){
          for (var i=0;i<entries.length;i++){
            if (norms.indexOf(entries[i].norm) !== -1) return entries[i];
          }
          return null;
        }
        function truthy(v){
          var s = String(v).toLowerCase();
          return s === "true" || s === "yes" || s === "1" || s === "on";
        }
        function falsy(v){
          var s = String(v).toLowerCase();
          return s === "false" || s === "no" || s === "0" || s === "off";
        }
        function hostOf(url){
          var m = String(url).match(/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\/([^\/:?#]+)/);
          return m ? m[1].toLowerCase() : "";
        }
        function isLocalHost(h){
          return h === "localhost" || h === "127.0.0.1" || h === "::1" || h === "";
        }

        function audit(text){
          var entries = parseConfig(text);
          var findings = [];
          function add(severity, key, line, category, message, fix){
            findings.push({ severity:severity, key:key, line:line, category:category, message:message, fix:fix });
          }
          var rawLower = String(text).toLowerCase();
          var hasProxyNote = /reverse[\s-]*proxy/.test(rawLower) || rawLower.indexOf("sso") !== -1 ||
                             rawLower.indexOf("oauth") !== -1 || rawLower.indexOf("oidc") !== -1 ||
                             rawLower.indexOf("single sign-on") !== -1 || rawLower.indexOf("single sign on") !== -1;

          // Rule 1 + 11: DB_PASSWORD
          var dbPw = findEntry(entries, ["DBPASSWORD"]);
          if (!dbPw){
            add("HIGH","DB_PASSWORD",null,"Database",
              "DB_PASSWORD is missing from the pasted config.",
              "Set a long, unique database password (24+ characters) and keep it in a secrets manager or docker secrets, not in a committed file.");
          } else if (dbPw.value.length === 0){
            add("HIGH","DB_PASSWORD",dbPw.line,"Database",
              "DB_PASSWORD (line " + dbPw.line + ", length 0) is set but empty.",
              "Set a long, unique database password (24+ characters).");
          } else if (dbPw.value.length < 16){
            add("CRITICAL","DB_PASSWORD",dbPw.line,"Database",
              "DB_PASSWORD (line " + dbPw.line + ", length " + dbPw.value.length + ") is far too short for a database password and appears in plaintext.",
              "Use a generated password of at least 24 characters, unique to this server, stored in a secrets manager or docker secrets.");
          } else if (dbPw.value.length < 24){
            add("HIGH","DB_PASSWORD",dbPw.line,"Database",
              "DB_PASSWORD (line " + dbPw.line + ", length " + dbPw.value.length + ") is short for a database password.",
              "Lengthen it to at least 24 characters and make sure it is unique to this server.");
          }

          // Rule 2 + 11: DB_USERNAME
          var dbUser = findEntry(entries, ["DBUSERNAME","DBUSER"]);
          if (!dbUser){
            add("INFO","DB_USERNAME",null,"Database",
              "DB_USERNAME is not present in the pasted config, so the auditor cannot check it.",
              "Confirm which database user Immich connects as, and make sure it is a dedicated, non-default account.");
          } else if (dbUser.value.length < 4){
            add("HIGH","DB_USERNAME",dbUser.line,"Database",
              "DB_USERNAME (line " + dbUser.line + ") is very short (" + dbUser.value.length + " characters), which usually means a default or throwaway account.",
              "Use a dedicated database user with a descriptive name, for example a service account name unique to this install.");
          } else if (DEFAULT_USERS.indexOf(dbUser.value.toLowerCase()) !== -1){
            add("MEDIUM","DB_USERNAME",dbUser.line,"Database",
              "DB_USERNAME (line " + dbUser.line + ") is a well-known default database username — the first one an attacker tries.",
              "Rename the database user to a dedicated service account name that is not a product or role default.");
          }

          // Rule 11: DB host presence (info only)
          var dbHost = findEntry(entries, ["DBHOST","DBHOSTNAME"]);
          if (!dbHost){
            add("INFO","DB_HOSTNAME",null,"Database",
              "No DB_HOST / DB_HOSTNAME entry was found in the pasted config.",
              "If the database host is set elsewhere (for example in the compose service name), this is fine — otherwise set it explicitly.");
          }

          // Rules 3 + 4: secret-like keys (DB_PASSWORD handled above).
          // Login/auth *flags* (disablePasswordLogin, OAuth toggles) are settings, not secrets — skip them.
          for (var i=0;i<entries.length;i++){
            var e = entries[i];
            if (!isSecretKey(e.norm)) continue;
            if (e.norm === "DBPASSWORD") continue;
            if (e.norm.indexOf("LOGIN") !== -1) continue;
            var evLow = e.value.toLowerCase();
            if (evLow === "true" || evLow === "false" || evLow === "yes" || evLow === "no" || evLow === "on" || evLow === "off") continue;
            if (e.value.length === 0){
              add("HIGH", e.key, e.line, "Secrets",
                e.key + " (line " + e.line + ", length 0) is set but empty.",
                "Give it a long, generated value, or remove the key if the feature is not used.");
            } else if (isJwtKey(e.norm)){
              if (e.value.length < 32){
                add("CRITICAL", e.key, e.line, "Secrets",
                  e.key + " (line " + e.line + ", length " + e.value.length + ") is a signing/session secret shorter than 32 characters — sessions and tokens can be forged.",
                  "Generate a random secret of at least 48 characters and store it in a secrets manager or docker secrets.");
              }
            } else if (e.value.length < 16){
              add("CRITICAL", e.key, e.line, "Secrets",
                e.key + " (line " + e.line + ", length " + e.value.length + ") is a secret-like value shorter than 16 characters.",
                "Replace it with a long, generated, unique value (32+ characters) kept out of committed files.");
            } else if (e.value.length < 32){
              add("MEDIUM", e.key, e.line, "Secrets",
                e.key + " (line " + e.line + ", length " + e.value.length + ") is a secret-like value under 32 characters.",
                "Lengthen it to 32+ characters and make sure it is not reused anywhere else.");
            }
          }

          // Rule 12: plaintext secrets note (INFO per secret key present)
          for (var j=0;j<entries.length;j++){
            var s2 = entries[j];
            if (s2.norm.indexOf("LOGIN") !== -1) continue;
            var svLow = s2.value.toLowerCase();
            if (svLow === "true" || svLow === "false" || svLow === "yes" || svLow === "no" || svLow === "on" || svLow === "off") continue;
            if (isSecretKey(s2.norm) && s2.value.length > 0){
              add("INFO", s2.key, s2.line, "Secrets handling",
                s2.key + " (line " + s2.line + ", length " + s2.value.length + ") is stored in plaintext in the pasted config text.",
                "Prefer a secrets manager or docker secrets so secret values do not live in plain env files or shell history.");
            }
          }

          // Rule 5: workers
          var workers = findEntry(entries, ["IMMICHWORKERSINCLUDE","WORKERSINCLUDE"]);
          if (workers){
            var tokens = workers.value.toLowerCase().split(/[\s,]+/);
            if (tokens.indexOf("all") !== -1){
              add("MEDIUM","IMMICH_WORKERS_INCLUDE",workers.line,"Workers",
                "IMMICH_WORKERS_INCLUDE (line " + workers.line + ") includes 'all', so every worker type runs in one process with no isolation or scaling control.",
                "List only the workers this server needs, for example an explicit api / background-jobs list, so each can be scaled and restarted on its own.");
            }
          }

          // Rule 6: password login exposure
          var loginEnabled = false, loginEntry = null;
          var dpl = findEntry(entries, ["DISABLEPASSWORDLOGIN"]);
          if (dpl && falsy(dpl.value)){ loginEnabled = true; loginEntry = dpl; }
          var pub = findEntry(entries, ["PUBLICLOGIN","PUBLICLOGINENABLED"]);
          if (pub && truthy(pub.value)){ loginEnabled = true; loginEntry = pub; }
          if (loginEnabled && loginEntry){
            if (!hasProxyNote){
              add("HIGH", loginEntry.key, loginEntry.line, "Authentication",
                loginEntry.key + " (line " + loginEntry.line + ") leaves password login enabled, and nothing in the pasted config mentions a reverse proxy, SSO, or OAuth in front of Immich.",
                "Put Immich behind a reverse proxy with SSO / OAuth and disable password login, or — if password login must stay on — document the proxy/SSO setup in the config so the exposure is a deliberate, reviewed choice.");
            } else {
              add("INFO", loginEntry.key, loginEntry.line, "Authentication",
                loginEntry.key + " (line " + loginEntry.line + ") leaves password login enabled, but the config does mention a reverse proxy / SSO / OAuth setup.",
                "Confirm the proxy and SSO are actually enforced in front of Immich, not just planned.");
            }
          }

          // Rule 7 + 11: UPLOAD_LOCATION
          var up = findEntry(entries, ["UPLOADLOCATION","UPLOADPATH"]);
          if (!up){
            add("HIGH","UPLOAD_LOCATION",null,"Storage",
              "UPLOAD_LOCATION is missing from the pasted config, so uploads land wherever the default points.",
              "Set UPLOAD_LOCATION to a dedicated directory on a data volume with room to grow, never the OS root filesystem.");
          } else {
            var uv = up.value.replace(/\s+$/, "");
            var uvLow = uv.toLowerCase();
            if (uv === "/" || uvLow === "/root" || uvLow === "/root/" || uvLow.indexOf("/root/") === 0 ||
                /^[a-z]:\\?$/.test(uv) || uv.length < 3){
              add("HIGH","UPLOAD_LOCATION",up.line,"Storage",
                "UPLOAD_LOCATION (line " + up.line + ") points at a root or near-root path. A photo library grows without limit — filling the OS disk takes the whole server down.",
                "Point UPLOAD_LOCATION at a dedicated path on a data disk or volume, for example a /data style mount, and monitor its free space.");
            }
          }

          // Rule 8: machine-learning URL
          for (var k=0;k<entries.length;k++){
            var ml = entries[k];
            var isMl = ml.norm === "IMMICHMACHINELEARNINGURL" || ml.norm === "MLURL" ||
                       ml.norm === "MACHINELEARNINGURL" || (ml.norm.indexOf("MACHINELEARNING") !== -1 && ml.norm.indexOf("URL") !== -1);
            if (!isMl) continue;
            if (ml.value.toLowerCase().indexOf("http://") === 0){
              var host = hostOf(ml.value);
              if (isLocalHost(host)){
                add("MEDIUM", ml.key, ml.line, "Machine learning",
                  ml.key + " (line " + ml.line + ") uses plain http:// to a local machine-learning service. Traffic is unencrypted, even on localhost-adjacent networks.",
                  "Use https:// where the ML service supports it, or keep the service bound to localhost / a private container network only.");
              } else {
                add("HIGH", ml.key, ml.line, "Machine learning",
                  ml.key + " (line " + ml.line + ") uses plain http:// to a non-local host, so photo data sent for machine learning crosses the network unencrypted.",
                  "Switch the machine-learning URL to https://, or restrict the ML service to a private network that no other host can reach.");
              }
            }
          }

          // Rule 9: telemetry
          var tel = findEntry(entries, ["IMMICH TELEMETRYINCLUDE".replace(/\s/g,""), "IMMICH TELEMETRY".replace(/\s/g,""), "TELEMETRYINCLUDE"]);
          var tel2 = null;
          for (var t2=0;t2<entries.length;t2++){
            if (entries[t2].norm.indexOf("TELEMETRY") !== -1) tel2 = entries[t2];
          }
          var telEntry = tel2 || tel;
          if (telEntry && telEntry.value){
            var tv = telEntry.value.toLowerCase();
            if (tv === "all" || tv.indexOf("all") !== -1){
              add("MEDIUM", telEntry.key, telEntry.line, "Privacy",
                telEntry.key + " (line " + telEntry.line + ") turns on the full telemetry set, so usage data leaves this self-hosted server.",
                "Trim telemetry to the minimum you are comfortable sharing, or turn it off — a self-hosted photo server should not report home by default.");
            } else if (truthy(tv) || tv.length > 0){
              add("LOW", telEntry.key, telEntry.line, "Privacy",
                telEntry.key + " (line " + telEntry.line + ") enables some telemetry.",
                "Check exactly what is sent and trim it to the minimum, or disable telemetry entirely.");
            }
          }
          var telEnabled = findEntry(entries, ["TELEMETRYENABLED"]);
          if (telEnabled && truthy(telEnabled.value)){
            add("LOW", telEnabled.key, telEnabled.line, "Privacy",
              telEnabled.key + " (line " + telEnabled.line + ") enables telemetry.",
              "Disable telemetry unless you have a specific reason to send usage data from a self-hosted server.");
          }

          // Rule 10: external map / style URLs
          for (var m2=0;m2<entries.length;m2++){
            var ms = entries[m2];
            var isMap = ms.norm.indexOf("MAPSTYLE") !== -1 || ms.norm === "STYLEURL" ||
                        ms.norm.indexOf("TILEURL") !== -1 || ms.norm.indexOf("MAPTILE") !== -1 ||
                        (ms.norm.indexOf("MAP") !== -1 && ms.norm.indexOf("URL") !== -1);
            if (!isMap || !ms.value) continue;
            var mv = ms.value.toLowerCase();
            if (mv.indexOf("http://") === 0 || mv.indexOf("https://") === 0){
              var mhost = hostOf(ms.value);
              if (!isLocalHost(mhost)){
                if (mv.indexOf("http://") === 0){
                  add("MEDIUM", ms.key, ms.line, "Privacy",
                    ms.key + " (line " + ms.line + ") loads map/style data from an external host over plain http:// — every map view tells that third party when and where the server is used, and the connection is unencrypted.",
                    "Self-host the map style/tiles, or at minimum use an https:// source you trust.");
                } else {
                  add("LOW", ms.key, ms.line, "Privacy",
                    ms.key + " (line " + ms.line + ") loads map/style data from an external host — map usage leaks to that third party and the server depends on it staying up.",
                    "Self-host the map style/tiles, or accept the dependency knowingly and note it in your runbook.");
                }
              }
            }
          }

          findings.sort(function(a,b){
            var d = SEV_ORDER[a.severity] - SEV_ORDER[b.severity];
            if (d !== 0) return d;
            var la = a.line === null ? 9999 : a.line;
            var lb = b.line === null ? 9999 : b.line;
            return la - lb;
          });

          var counts = { CRITICAL:0, HIGH:0, MEDIUM:0, LOW:0, INFO:0 };
          for (var c=0;c<findings.length;c++) counts[findings[c].severity]++;

          var authDbHigh = 0;
          for (var h=0;h<findings.length;h++){
            var f = findings[h];
            if (f.severity === "HIGH" && (f.category === "Database" || f.category === "Authentication" || f.category === "Secrets")) authDbHigh++;
          }

          var verdict, rule;
          if (counts.CRITICAL > 0){
            verdict = "DO NOT DEPLOY";
            rule = "At least one CRITICAL finding is present.";
          } else if (authDbHigh >= 2){
            verdict = "DO NOT DEPLOY";
            rule = "Two or more HIGH findings in the database / authentication / secrets areas.";
          } else if (counts.HIGH > 0 || counts.MEDIUM >= 3){
            verdict = "DEPLOY WITH FIXES";
            rule = counts.HIGH > 0 ? "HIGH findings are present, but none are critical." : "Three or more MEDIUM findings add up to real risk.";
          } else if (counts.MEDIUM > 0 || counts.LOW > 0){
            verdict = "DEPLOY WITH FIXES";
            rule = "Only MEDIUM / LOW findings — worth fixing before this goes live.";
          } else {
            verdict = "SAFE TO DEPLOY";
            rule = "No CRITICAL, HIGH, MEDIUM, or LOW findings. INFO notes, if any, do not change the verdict.";
          }

          return { verdict:verdict, rule:rule, counts:counts, findings:findings, keysParsed:entries.length };
        }

        function buildReport(r){
          var lines = [];
          lines.push("J-Dawgs Immich Server Config Safety Auditor — Report");
          lines.push("Verdict: " + r.verdict);
          lines.push("Why: " + r.rule);
          lines.push("Counts: CRITICAL " + r.counts.CRITICAL + " | HIGH " + r.counts.HIGH + " | MEDIUM " + r.counts.MEDIUM + " | LOW " + r.counts.LOW + " | INFO " + r.counts.INFO);
          lines.push("Keys parsed: " + r.keysParsed);
          lines.push("Secret values are never displayed in results — only key name, line, and length.");
          lines.push("");
          if (r.findings.length === 0){
            lines.push("No findings.");
          } else {
            for (var i=0;i<r.findings.length;i++){
              var f = r.findings[i];
              lines.push("[" + f.severity + "] " + f.key + (f.line !== null ? " (line " + f.line + ")" : " (not present)") + " — " + f.category);
              lines.push("  " + f.message);
              lines.push("  Fix: " + f.fix);
            }
          }
          return lines.join("\n");
        }

        function buildJson(r){
          var obj = {
            tool: "J-Dawgs Immich Server Config Safety Auditor",
            verdict: r.verdict,
            verdictRule: r.rule,
            counts: { critical:r.counts.CRITICAL, high:r.counts.HIGH, medium:r.counts.MEDIUM, low:r.counts.LOW, info:r.counts.INFO },
            keysParsed: r.keysParsed,
            secretHandling: "Secret values are never included — findings reference key name, line, and length only.",
            findings: []
          };
          for (var i=0;i<r.findings.length;i++){
            var f = r.findings[i];
            obj.findings.push({ severity:f.severity, key:f.key, line:f.line, category:f.category, message:f.message, fix:f.fix });
          }
          return JSON.stringify(obj, null, 2);
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-immich-server-config-safety-auditortm-2',
  name: 'J-Dawgs Immich Server Config Safety Auditor',
  description: 'pasting an Immich configuration (.env/config)',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
