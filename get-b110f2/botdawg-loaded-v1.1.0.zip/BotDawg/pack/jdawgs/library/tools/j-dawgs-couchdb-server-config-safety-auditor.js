'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs CouchDB Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        /* ---------- Worked examples ---------- */
        var RISKY_EXAMPLE = [
          "; CouchDB config — risky worked example",
          "[chttpd]",
          "bind_address = 0.0.0.0",
          "port = 5984",
          "",
          "[cors]",
          "enable_cors = true",
          "origins = *",
          "credentials = true"
        ].join("\n");

        var HARDENED_EXAMPLE = [
          "; CouchDB config — hardened worked example",
          "[admins]",
          "root = -hashed-7f3a9c1e5b2d4806a1f0c9e2b4d60718293a4b5c,0a1b2c3d4e5f60718293a4b5c6d7e8f9",
          "",
          "[chttpd]",
          "bind_address = 127.0.0.1",
          "require_valid_user = true",
          "",
          "[cors]",
          "enable_cors = true",
          "origins = https://app.example.com",
          "credentials = true"
        ].join("\n");

        /* ---------- Parsing ---------- */
        function parseConfig(text) {
          var lines = text.split(/\r\n|\r|\n/);
          var entries = [];
          var sections = {};       // name -> { line, entries: [] }
          var sectionOrder = [];
          var unparsed = [];       // line numbers
          var current = null;
          for (var i = 0; i < lines.length; i++) {
            var lineNo = i + 1;
            var t = lines[i].replace(/^\s+|\s+$/g, "");
            if (t === "") continue;
            if (t.charAt(0) === ";" || t.charAt(0) === "#") continue;
            var sec = /^\[([^\]]+)\]\s*$/.exec(t);
            if (sec) {
              current = sec[1].replace(/^\s+|\s+$/g, "");
              if (!sections[current]) {
                sections[current] = { line: lineNo, entries: [] };
                sectionOrder.push(current);
              }
              continue;
            }
            var kv = /^([^=]+)=(.*)$/.exec(t);
            if (kv && current !== null) {
              var key = kv[1].replace(/^\s+|\s+$/g, "");
              var value = kv[2].replace(/^\s+|\s+$/g, "");
              if (key !== "") {
                var entry = { section: current, key: key, value: value, line: lineNo };
                entries.push(entry);
                sections[current].entries.push(entry);
                continue;
              }
            }
            unparsed.push(lineNo);
          }
          return { entries: entries, sections: sections, sectionOrder: sectionOrder, unparsed: unparsed, lineCount: lines.length };
        }

        function isTrue(v) { return typeof v === "string" && v.toLowerCase() === "true"; }

        // Last occurrence wins, matching INI override behaviour.
        function getEntry(parsed, section, key) {
          var found = null;
          for (var i = 0; i < parsed.entries.length; i++) {
            var e = parsed.entries[i];
            if (e.section === section && e.key === key) found = e;
          }
          return found;
        }
        function getEntryAny(parsed, sectionsWanted, key) {
          for (var s = 0; s < sectionsWanted.length; s++) {
            var e = getEntry(parsed, sectionsWanted[s], key);
            if (e) return e;
          }
          return null;
        }

        /* ---------- Audit ---------- */
        function audit(text) {
          var parsed = parseConfig(text);
          var findings = [];
          function add(sev, cat, title, detail, loc, fix) {
            findings.push({ sev: sev, cat: cat, title: title, detail: detail, loc: loc || null, fix: fix || null });
          }
          function locOf(e) { return e ? { section: e.section, key: e.key, line: e.line } : null; }

          /* --- Admin party & admin password storage --- */
          var adminsSection = parsed.sections["admins"] || null;
          var adminEntries = adminsSection ? adminsSection.entries : [];
          var adminParty = !adminsSection || adminEntries.length === 0;
          var plaintextAdmins = [];

          if (!adminsSection) {
            add("blocker", "Admin party",
              "Admin party — no [admins] section at all",
              "This file defines no admin account, so the node runs in \"admin party\" mode: every visitor is an admin, with full read, write, and delete rights over every database, no password asked.",
              null,
              "Add an [admins] section with at least one admin account, then restart CouchDB — it stores the password in hashed form on startup.");
          } else if (adminEntries.length === 0) {
            add("blocker", "Admin party",
              "Admin party — [admins] section present but empty",
              "An [admins] section exists but holds no accounts, so the node still runs in \"admin party\" mode: every visitor is an admin, with full rights over every database, no password asked.",
              { section: "admins", key: null, line: adminsSection.line },
              "Add at least one admin account under [admins], then restart CouchDB — it stores the password in hashed form on startup.");
          } else {
            for (var a = 0; a < adminEntries.length; a++) {
              var ae = adminEntries[a];
              if (ae.value.indexOf("-hashed-") === 0) {
                add("good", "Admin accounts",
                  "Admin password stored in hashed form",
                  "The stored value for this admin account is in -hashed- form (a salted hash), not a readable password. The value itself is never shown in this audit.",
                  locOf(ae), null);
              } else {
                plaintextAdmins.push(ae);
                add("warning", "Admin accounts",
                  "Plaintext admin password",
                  "The stored value for this admin account does not start with -hashed-, so the admin password sits in this file as readable plaintext. The value itself is never shown in this audit.",
                  locOf(ae),
                  "Restart CouchDB: on startup it rewrites plaintext [admins] values into -hashed- form automatically. Until that restart happens, treat this file itself as a credential and keep it off shared drives and out of source control.");
              }
            }
          }

          /* --- Bind exposure --- */
          var bindEntries = [];
          for (var b = 0; b < parsed.entries.length; b++) {
            var be = parsed.entries[b];
            if (be.key === "bind_address" && (be.section === "chttpd" || be.section === "httpd")) bindEntries.push(be);
          }
          var nonLocalBind = false;
          for (var c = 0; c < bindEntries.length; c++) {
            var entry = bindEntries[c];
            var v = entry.value.toLowerCase();
            if (v === "0.0.0.0" || v === "::") {
              nonLocalBind = true;
              if (adminParty) {
                add("blocker", "Bind exposure",
                  "Wide-open bind paired with admin party",
                  "bind_address listens on every network interface, and this config is in admin party — the pairing means anyone who can reach the port is a full admin with no password at all. This is the combination behind the classic CouchDB takeover.",
                  locOf(entry),
                  "Fix both halves: add an [admins] account AND set bind_address = 127.0.0.1 (or a specific trusted address), or put an authenticating reverse proxy in front of the node.");
              } else if (plaintextAdmins.length > 0) {
                add("blocker", "Bind exposure",
                  "Wide-open bind paired with a plaintext admin password",
                  "bind_address listens on every network interface, and at least one [admins] password is stored in plaintext in this same file — the pairing means the credential protecting this fully exposed node can be read straight out of the file by anyone who gets a copy of it.",
                  locOf(entry),
                  "Restart CouchDB so the plaintext admin password is rewritten in -hashed- form, AND set bind_address = 127.0.0.1 (or a specific trusted address) or put an authenticating reverse proxy in front of the node.");
              } else {
                add("warning", "Bind exposure",
                  "Bind listens on every interface",
                  "bind_address = " + entry.value + " exposes CouchDB on all network interfaces, so the node is reachable from the whole network (and, behind a permissive firewall or port forward, the whole internet).",
                  locOf(entry),
                  "Set bind_address = 127.0.0.1 if only local processes should reach CouchDB, or bind a specific trusted address and put an authenticating reverse proxy in front of it.");
              }
            } else if (v === "127.0.0.1" || v === "::1" || v === "localhost") {
              add("good", "Bind exposure",
                "Bind is local-only",
                "bind_address = " + entry.value + " keeps CouchDB reachable only from this machine. Remote clients would need a tunnel or a reverse proxy you control.",
                locOf(entry), null);
            } else {
              nonLocalBind = true;
              add("note", "Bind exposure",
                "Bind set to a specific address",
                "bind_address names one specific interface address rather than every interface. The node is reachable from other machines on that network, so the auth checks below carry the weight.",
                locOf(entry), null);
            }
          }
          if (bindEntries.length === 0) {
            add("note", "Bind exposure",
              "No bind_address setting in this file",
              "No bind_address appears under [chttpd] or [httpd], so the version default decides: CouchDB 3.x defaults to 127.0.0.1 (local-only), while 2.x defaulted to 0.0.0.0 (every interface). On a 2.x node, confirm the effective bind on the host itself.",
              null, null);
          }

          /* --- CORS --- */
          var corsEnable = getEntry(parsed, "cors", "enable_cors");
          var corsOrigins = getEntry(parsed, "cors", "origins");
          var corsCreds = getEntry(parsed, "cors", "credentials");
          var legacyCorsEnable = getEntry(parsed, "httpd", "enable_cors");

          if (legacyCorsEnable && corsEnable && isTrue(legacyCorsEnable.value) !== isTrue(corsEnable.value)) {
            add("warning", "Conflicting settings",
              "Conflicting CORS settings — legacy [httpd] enable_cors disagrees with [cors] enable_cors",
              "The 2.x legacy spelling under [httpd] and the current [cors] setting say opposite things about whether CORS is on. Which one governs depends on the CouchDB version, so the effective cross-origin posture is ambiguous from this file alone.",
              locOf(legacyCorsEnable),
              "Keep CORS settings in [cors] only on 3.x (and remove the legacy [httpd] enable_cors line), so there is exactly one source of truth.");
          }

          var corsOnEntry = corsEnable || legacyCorsEnable;
          if (corsOnEntry && isTrue(corsOnEntry.value)) {
            if (corsOrigins && corsOrigins.value === "*") {
              if (corsCreds && isTrue(corsCreds.value)) {
                add("blocker", "CORS",
                  "Wildcard CORS origins with credentials allowed",
                  "CORS is on with origins = * while credentials = true: any website a visitor happens to open can make credentialed cross-origin requests to this node and read the responses — the browser's same-origin protection is switched off for everyone.",
                  locOf(corsOrigins),
                  "Replace origins = * with the exact origin list that needs access (for example a single app origin), or set credentials = false if no credentialed cross-origin access is truly needed.");
              } else {
                add("warning", "CORS",
                  "Wildcard CORS origins",
                  "CORS is on with origins = *: any website can read this node's responses cross-origin. Credentials are not enabled, which limits the damage, but the data itself is world-readable from any browser.",
                  locOf(corsOrigins),
                  "Replace origins = * with the exact origin list that needs access.");
              }
            } else if (corsOrigins) {
              add("good", "CORS",
                "CORS origins are a specific list",
                "CORS is on, but origins names specific origins rather than *, so only the listed sites get cross-origin access.",
                locOf(corsOrigins), null);
            } else {
              add("note", "CORS",
                "CORS on, no origins line in this file",
                "CORS is enabled but no origins setting appears in this file, so the built-in default origin list applies.",
                locOf(corsOnEntry), null);
            }
          } else if (corsOnEntry) {
            add("note", "CORS",
              "CORS is disabled in this file",
              "enable_cors is set to false, so browsers get no cross-origin access to this node.",
              locOf(corsOnEntry), null);
          }

          /* --- Auth posture --- */
          var rvu = getEntryAny(parsed, ["chttpd", "httpd"], "require_valid_user");
          if (rvu && isTrue(rvu.value)) {
            add("good", "Auth posture",
              "require_valid_user is on",
              "Every request to this node must carry a valid user — anonymous requests are rejected outright.",
              locOf(rvu), null);
          } else if (nonLocalBind) {
            add("warning", "Auth posture",
              "require_valid_user is off or missing on a non-local bind",
              "The node is reachable from other machines, but require_valid_user is not set to true, so anonymous requests can still reach whatever the per-database security objects allow — and in admin party that is everything.",
              locOf(rvu),
              "Set require_valid_user = true under [chttpd] (3.x spelling) so every request must authenticate.");
          } else if (rvu) {
            add("note", "Auth posture",
              "require_valid_user is off, but the bind is local-only",
              "Anonymous requests are possible in principle, but the local-only bind means only processes on this machine can reach the node. Turn it on anyway if anything else on the box is untrusted.",
              locOf(rvu), null);
          }

          var handlers = getEntryAny(parsed, ["chttpd", "httpd"], "authentication_handlers");
          if (handlers) {
            var named = [];
            if (/cookie_authentication_handler/.test(handlers.value)) named.push("cookie auth (cookie_authentication_handler)");
            if (/default_authentication_handler/.test(handlers.value)) named.push("default Basic auth (default_authentication_handler)");
            if (/proxy_authentication_handler/.test(handlers.value)) named.push("proxy auth (proxy_authentication_handler)");
            if (/oauth_authentication_handler/.test(handlers.value)) named.push("OAuth auth (oauth_authentication_handler)");
            var handlerText = named.length > 0
              ? "Handlers configured: " + named.join("; ") + ". Handler entries are module names, not secrets, so they are safe to inventory here."
              : "An authentication_handlers setting is present. Handler entries are module names, not secrets, so the setting is safe to inventory here.";
            add("note", "Auth posture",
              "authentication_handlers inventoried",
              handlerText,
              locOf(handlers), null);

            if (/proxy_authentication_handler/.test(handlers.value)) {
              var proxySecret = null;
              for (var s2 = 0; s2 < parsed.entries.length; s2++) {
                var pe = parsed.entries[s2];
                if (/proxy/i.test(pe.key) && /secret/i.test(pe.key)) { proxySecret = pe; break; }
              }
              if (!proxySecret) {
                add("warning", "Auth posture",
                  "Proxy auth handler with no proxy secret posture stated",
                  "proxy_authentication_handler trusts identity headers (X-Auth-CouchDB-UserName and friends) from a front proxy, but no proxy secret setting appears in this file. Without the shared-secret check, anyone who can reach the node directly can forge those headers and impersonate any user, admins included. No secret value is shown in this audit — none was found to show.",
                  locOf(handlers),
                  "Set the proxy shared secret in the config (a key pairing \"proxy\" with \"secret\") and make sure only the proxy can reach CouchDB directly, so forged headers from anyone else never arrive.");
              } else {
                add("note", "Auth posture",
                  "Proxy secret setting is present",
                  "A proxy secret setting appears in this file (named in the secret-key inventory below), so the proxy auth handler has a stated shared-secret posture. Its value is never shown in this audit.",
                  locOf(proxySecret), null);
              }
            }
          }

          /* --- Duplicate / conflicting 2.x vs 3.x spellings --- */
          if (parsed.sections["httpd"] && parsed.sections["chttpd"]) {
            var httpdLast = {}, chttpdLast = {};
            var i2;
            for (i2 = 0; i2 < parsed.entries.length; i2++) {
              var de = parsed.entries[i2];
              if (de.section === "httpd") httpdLast[de.key] = de;
              if (de.section === "chttpd") chttpdLast[de.key] = de;
            }
            for (var key in chttpdLast) {
              if (Object.prototype.hasOwnProperty.call(chttpdLast, key) && httpdLast[key]) {
                var hE = httpdLast[key], cE = chttpdLast[key];
                if (hE.value === cE.value) {
                  add("note", "Duplicate spelling",
                    "Duplicate spelling — \"" + key + "\" set under both [httpd] and [chttpd]",
                    "The same key appears in the 2.x [httpd] section (line " + hE.line + ") and the 3.x [chttpd] section (line " + cE.line + ") with the same value. Harmless today, but the stale copy invites a future edit to land in the wrong section.",
                    locOf(cE),
                    "Keep the key in [chttpd] only on 3.x and delete the [httpd] copy (or the reverse on a genuine 2.x node).");
                } else {
                  add("warning", "Conflicting settings",
                    "Conflicting spelling — \"" + key + "\" differs between [httpd] and [chttpd]",
                    "The same key appears in the 2.x [httpd] section (line " + hE.line + ") and the 3.x [chttpd] section (line " + cE.line + ") with different values. Which value governs depends on the CouchDB version, so the effective setting is ambiguous from this file alone. (Values are not shown for credential-shaped keys; for this key the two copies simply disagree.)",
                    locOf(cE),
                    "Decide the intended value, keep it in the section your CouchDB version actually reads ([chttpd] on 3.x), and delete the other copy.");
                }
              }
            }
          }

          /* --- Secret-bearing key inventory (names only) --- */
          var secretKeys = [];
          for (var k = 0; k < parsed.entries.length; k++) {
            var ke = parsed.entries[k];
            if (/(password|secret|token)/i.test(ke.key)) secretKeys.push(ke);
          }

          /* --- Verdict --- */
          var counts = { blocker: 0, warning: 0, note: 0, good: 0 };
          for (var f = 0; f < findings.length; f++) counts[findings[f].sev]++;
          var verdict = counts.blocker > 0 ? "DO NOT DEPLOY" : (counts.warning > 0 ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY");

          return { parsed: parsed, findings: findings, secretKeys: secretKeys, counts: counts, verdict: verdict };
        }

        /* ---------- Text helpers (values never rendered for credentials) ---------- */
        function locText(loc) {
          if (!loc) return "whole file — no single line";
          var s = "[" + loc.section + "]";
          if (loc.key) s += " · key \"" + loc.key + "\"";
          s += " · line " + loc.line;
          return s;
        }
        var SEV_LABEL = { blocker: "BLOCKER", warning: "WARNING", note: "NOTE", good: "PASSED" };

        function buildReport(result) {
          var out = [];
          out.push("J-Dawgs CouchDB Server Config Safety Auditor — Audit Report");
          out.push("==============================================================");
          out.push("Verdict: " + result.verdict);
          out.push("Blockers: " + result.counts.blocker + " · Warnings: " + result.counts.warning +
                   " · Notes: " + result.counts.note + " · Passed checks: " + result.counts.good);
          out.push("Lines read: " + result.parsed.lineCount + " · Settings parsed: " + result.parsed.entries.length +
                   " · Unparsed lines: " + result.parsed.unparsed.length);
          out.push("");
          out.push("FINDINGS");
          out.push("--------");
          var order = { blocker: 0, warning: 1, note: 2, good: 3 };
          var sorted = result.findings.slice().sort(function (x, y) { return order[x.sev] - order[y.sev]; });
          if (sorted.length === 0) out.push("(No findings.)");
          for (var i = 0; i < sorted.length; i++) {
            var fd = sorted[i];
            out.push("[" + SEV_LABEL[fd.sev] + "] " + fd.title + "  (" + locText(fd.loc) + ")");
            out.push("  " + fd.detail);
            if (fd.fix) out.push("  Fix: " + fd.fix);
            out.push("");
          }
          out.push("FIX LIST");
          out.push("--------");
          var fixes = [];
          for (var j = 0; j < sorted.length; j++) {
            if ((sorted[j].sev === "blocker" || sorted[j].sev === "warning") && sorted[j].fix) fixes.push(sorted[j]);
          }
          if (fixes.length === 0) out.push("Nothing to fix — no blockers or warnings.");
          for (var n = 0; n < fixes.length; n++) {
            out.push((n + 1) + ". [" + SEV_LABEL[fixes[n].sev] + "] " + fixes[n].title + " (" + locText(fixes[n].loc) + "): " + fixes[n].fix);
          }
          out.push("");
          out.push("SECRET-BEARING KEYS (names only — values are never shown)");
          out.push("----------------------------------------------------------");
          if (result.secretKeys.length === 0) out.push("None found — no key name contains \"password\", \"secret\", or \"token\".");
          for (var m = 0; m < result.secretKeys.length; m++) {
            var sk = result.secretKeys[m];
            out.push("- [" + sk.section + "] · key \"" + sk.key + "\" · line " + sk.line);
          }
          out.push("");
          out.push("UNPARSED LINES");
          out.push("--------------");
          if (result.parsed.unparsed.length === 0) out.push("None — every non-blank, non-comment line parsed as a section header or a key = value pair.");
          else out.push("Lines " + result.parsed.unparsed.join(", ") + " could not be parsed as a section header or a key = value pair. They were excluded from grading, never guessed.");
          out.push("");
          out.push("LIMITS");
          out.push("------");
          out.push("This report grades pasted config text only. It never connected to a CouchDB node. The Fauxton / _utils surface and per-database _security objects do not live in this file and were NOT audited. Admin password values (plain or hashed) appear nowhere in this report by design.");
          return out.join("\n");
        }

        function buildSummary(result) {
          var out = [];
          out.push("CouchDB Server Config Safety Auditor — share-safe summary");
          out.push("Verdict: " + result.verdict);
          out.push("Blockers: " + result.counts.blocker + " · Warnings: " + result.counts.warning +
                   " · Notes: " + result.counts.note + " · Passed checks: " + result.counts.good);
          out.push("Settings parsed: " + result.parsed.entries.length + " · Unparsed lines: " + result.parsed.unparsed.length);
          out.push("No values, addresses, or credentials are included in this summary.");
          return out.join("\n");
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-couchdb-server-config-safety-auditor',
  name: 'J-Dawgs CouchDB Server Config Safety Auditor',
  description: 'Grades a pasted CouchDB config offline — admin-party state, plaintext vs hashed admin passwords, bind exposure, wildcard CORS — into one deploy verdict. CouchDB starts happily in admin party on its own host; ours grades a pasted config anywhere before deploy.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
