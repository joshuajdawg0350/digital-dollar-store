'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs OpenSSH Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var RISKY = [
        "# RISKY worked example - a careless sshd_config, do not deploy as-is",
        "Port 22",
        "Port 2222",
        "ListenAddress 0.0.0.0",
        "Protocol 2,1",
        "PermitRootLogin yes",
        "PasswordAuthentication yes",
        "PermitEmptyPasswords yes",
        "ChallengeResponseAuthentication yes",
        "PubkeyAuthentication no",
        "MaxAuthTries 10",
        "MaxAuthTries 2",
        "LoginGraceTime 0",
        "X11Forwarding yes",
        "AllowTcpForwarding yes",
        "PermitTunnel yes",
        "GatewayPorts yes",
        "ClientAliveInterval 0",
        "AuthorizedKeysFile /tmp/authorized_keys",
        "Include /etc/ssh/sshd_config.d/extra.conf",
        "Match User backup",
        "    PasswordAuthentication yes",
        "    AllowTcpForwarding yes"
      ].join("\n");

      var HARDENED = [
        "# HARDENED example - key-only, allowlisted, forwarding off",
        "Port 22",
        "ListenAddress 192.0.2.25",
        "PermitRootLogin prohibit-password",
        "PasswordAuthentication no",
        "PermitEmptyPasswords no",
        "KbdInteractiveAuthentication no",
        "PubkeyAuthentication yes",
        "AuthenticationMethods publickey",
        "AllowUsers deploy ops",
        "MaxAuthTries 3",
        "LoginGraceTime 45",
        "X11Forwarding no",
        "AllowTcpForwarding no",
        "AllowAgentForwarding no",
        "PermitTunnel no",
        "GatewayPorts no",
        "ClientAliveInterval 120",
        "ClientAliveCountMax 2",
        "AuthorizedKeysFile .ssh/authorized_keys",
        "StrictModes yes",
        "HostbasedAuthentication no",
        "PermitUserEnvironment no",
        "Ciphers chacha20-poly1305@openssh.com,aes256-gcm@openssh.com,aes128-gcm@openssh.com",
        "Match User sftp",
        "    AllowTcpForwarding no",
        "    X11Forwarding no",
        "    PasswordAuthentication no",
        "Match all"
      ].join("\n");

      var KNOWN = {};
      ("port listenaddress hostkey permitrootlogin passwordauthentication permitemptypasswords " +
       "challengeresponseauthentication kbdinteractiveauthentication pubkeyauthentication authorizedkeysfile " +
       "authorizedkeyscommand authorizedkeyscommanduser authorizedprincipalsfile authorizedprincipalscommand " +
       "hostbasedauthentication ignoreuserknownhosts ignorerhosts strictmodes maxauthtries maxsessions maxstartups " +
       "logingracetime x11forwarding x11displayoffset x11uselocalhost allowtcpforwarding allowagentforwarding " +
       "gatewayports permittunnel clientaliveinterval clientalivecountmax protocol ciphers macs kexalgorithms " +
       "hostkeyalgorithms pubkeyacceptedalgorithms pubkeyacceptedkeytypes casignaturealgorithms allowusers " +
       "allowgroups denyusers denygroups include authenticationmethods banner chrootdirectory forcecommand " +
       "subsystem usepam usedns compression permituserenvironment acceptenv setenv addressfamily " +
       "allowstreamlocalforwarding channeltimeout disableforwarding exposeauthinfo fingerprinthash " +
       "gssapiauthentication gssapicleanupcredentials gssapikeyexchange gssapistrictacceptorcheck " +
       "gssapistorecredentialsonrekey hostkeyagent ipqos kerberosauthentication kerberosgetafstoken " +
       "kerberosorlocalpasswd kerberosticketcleanup loglevel syslogfacility permitlisten permitopen permittty " +
       "permitusercdrom pidfile printlastlog printmotd pubkeyauthoptions rekeylimit requiredrsasize " +
       "revokedkeys securitykeyprovider streamlocalbindmask streamlocalbindunlink tcpkeepalive trustedusercakeys " +
       "verifyhostkeydns versionaddendum xauthlocation debianbanner kerberosuniqueccache " +
       "gssapienablek5users hostcertificate moduledir").split(" ").forEach(function(k){ KNOWN[k]=true; });

      function canonical(lower){
        if(lower === "challengeresponseauthentication") return "kbdinteractiveauthentication";
        return lower;
      }
      function firstTok(v){ return (v || "").split(/\s+/)[0] || ""; }
      function dispVal(name, value){
        var lv = (value || "").toLowerCase();
        var safe = { "yes":1, "no":1, "prohibit-password":1, "without-password":1, "forced-commands-only":1, "none":1 };
        if(/(secret|token|passwd)/i.test(name) && !safe[lv]) return "[value not shown]";
        if(/password/i.test(name) && !safe[lv] && name.toLowerCase() !== "passwordauthentication" && name.toLowerCase() !== "permitemptypasswords") return "[value not shown]";
        return value;
      }
      function parseDuration(v){
        v = (v || "").trim().toLowerCase();
        if(!v) return null;
        if(/^\d+$/.test(v)) return parseInt(v,10);
        var re = /(\d+)\s*(w|d|h|m|s)/g, m, total = 0, matched = false;
        var mult = { w:604800, d:86400, h:3600, m:60, s:1 };
        while((m = re.exec(v)) !== null){ total += parseInt(m[1],10) * mult[m[2]]; matched = true; }
        return matched ? total : null;
      }
      function parseIntStrict(v){
        var n = parseInt(v,10);
        return isNaN(n) ? null : n;
      }

      function audit(text){
        var findings = [];
        function add(sev, line, key, msg, nc){
          findings.push({ sev:sev, line:line, key:key, msg:msg, nc:!!nc });
        }
        var lines = (text || "").split(/\r?\n/);
        var seen = {};        // scope|canonical -> {line, name, value}
        var globalEff = {};   // canonical -> {line, name, value}
        var scope = "global";
        var scopeLabel = "global scope";

        function grade(canon, name, value, lineNo){
          var vl = (value || "").toLowerCase();
          var vt = firstTok(vl);
          var ctx = scope === "global" ? "" : " (in " + scopeLabel + ")";
          switch(canon){
            case "permitrootlogin":
              if(vt === "yes") add("BLOCKER", lineNo, name, "PermitRootLogin = yes" + ctx + " — direct root login over SSH is fully enabled. Root is the one account every scanner tries first; a guessed or leaked root credential is total control. Set prohibit-password or no.");
              else if(vt === "prohibit-password" || vt === "without-password") add("INFO", lineNo, name, "PermitRootLogin = prohibit-password" + ctx + " — noted as a restricted setting: root may log in with a public key only, never a password.");
              else if(vt === "forced-commands-only") add("INFO", lineNo, name, "PermitRootLogin = forced-commands-only" + ctx + " — noted as a restricted setting: root key logins can only run the command the key is pinned to.");
              else if(vt === "no") add("INFO", lineNo, name, "PermitRootLogin = no" + ctx + " — direct root SSH login is disabled.");
              else add("WARNING", lineNo, name, "PermitRootLogin has an unrecognized value (" + dispVal(name, value) + ")" + ctx + " — sshd may refuse it; use yes, prohibit-password, forced-commands-only, or no.");
              break;
            case "passwordauthentication":
              if(vt === "yes") add("WARNING", lineNo, name, "PasswordAuthentication = yes" + ctx + " — password logins are enabled and can be guessed online, credential by credential. Prefer key-only (no) with PubkeyAuthentication yes.");
              else if(vt === "no") add("INFO", lineNo, name, "PasswordAuthentication = no" + ctx + " — password logins are refused.");
              else add("WARNING", lineNo, name, "PasswordAuthentication has an unrecognized value (" + dispVal(name, value) + ")" + ctx + ".");
              break;
            case "permitemptypasswords":
              if(vt === "yes") add("BLOCKER", lineNo, name, "PermitEmptyPasswords = yes" + ctx + " — accounts with an empty password can log in over SSH with no credential at all wherever password-style authentication reaches them. Set no.");
              else if(vt === "no") add("INFO", lineNo, name, "PermitEmptyPasswords = no" + ctx + " — empty-password logins are refused.");
              else add("WARNING", lineNo, name, "PermitEmptyPasswords has an unrecognized value" + ctx + ".");
              break;
            case "kbdinteractiveauthentication":
              if(vt === "yes") add("WARNING", lineNo, name, name + " = yes" + ctx + " — keyboard-interactive authentication is enabled. It can fall back to password-style prompts and PAM challenges, quietly reopening the password door even when PasswordAuthentication is off. Set no unless you run MFA through PAM on purpose.");
              else if(vt === "no") add("INFO", lineNo, name, name + " = no" + ctx + " — keyboard-interactive authentication is disabled.");
              else add("WARNING", lineNo, name, name + " has an unrecognized value" + ctx + ".");
              break;
            case "pubkeyauthentication":
              if(vt === "no") add("WARNING", lineNo, name, "PubkeyAuthentication = no" + ctx + " — public-key login is disabled, which pushes clients toward weaker methods such as passwords. Set yes.");
              else if(vt === "yes") add("INFO", lineNo, name, "PubkeyAuthentication = yes" + ctx + " — public-key login is available.");
              else add("WARNING", lineNo, name, "PubkeyAuthentication has an unrecognized value" + ctx + ".");
              break;
            case "authenticationmethods": {
              var methods = vl.split(",").join(" ");
              if(methods.indexOf("password") !== -1 || methods.indexOf("keyboard-interactive") !== -1)
                add("WARNING", lineNo, name, "AuthenticationMethods (" + dispVal(name, value) + ")" + ctx + " permits a password-based method in the chain.");
              else
                add("INFO", lineNo, name, "AuthenticationMethods = " + dispVal(name, value) + "" + ctx + " — no password-based method is named in the chain.");
              break;
            }
            case "port": {
              var p = parseIntStrict(vt);
              if(p === null || p < 1 || p > 65535) add("WARNING", lineNo, name, "Port value (" + dispVal(name, value) + ")" + ctx + " is not a valid TCP port (1-65535).");
              else if(p === 22) add("INFO", lineNo, name, "Port 22" + ctx + " — the standard SSH port.");
              else add("INFO", lineNo, name, "Port " + p + "" + ctx + " — non-standard port, noted only. A moved port is not graded as safer: scanners find open ports, so obscurity is not a control.");
              break;
            }
            case "listenaddress": {
              var host = firstTok(value).split(":")[0].replace(/^\[|\]$/g, "");
              if(host === "0.0.0.0" || host === "::" || host === "*" || host === "")
                add("WARNING", lineNo, name, "ListenAddress " + dispVal(name, value) + "" + ctx + " — sshd listens on every interface, so the SSH door faces every network this host touches. Bind a specific address if the host sits on more than one network.");
              else
                add("INFO", lineNo, name, "ListenAddress " + dispVal(name, value) + "" + ctx + " — bound to a specific address, so exposure is limited to that interface.");
              break;
            }
            case "allowusers":
            case "allowgroups": {
              var n = (value || "").split(/\s+/).filter(Boolean).length;
              add("INFO", lineNo, name, name + "" + ctx + " — an allowlist is in place (" + n + (n === 1 ? " entry" : " entries") + " named); only the named " + (canon === "allowusers" ? "users" : "groups") + " can log in.");
              break;
            }
            case "denyusers":
            case "denygroups":
              add("INFO", lineNo, name, name + "" + ctx + " — a deny list is present and noted.");
              break;
            case "maxauthtries": {
              var mt = parseIntStrict(vt);
              if(mt === null || mt < 1) add("WARNING", lineNo, name, "MaxAuthTries value (" + dispVal(name, value) + ")" + ctx + " is not a positive number.");
              else if(mt > 6) add("WARNING", lineNo, name, "MaxAuthTries = " + mt + "" + ctx + " — more guesses per connection than the default of 6; each connection is a free round of password attempts. 3 or 4 is a common hardened choice.");
              else add("INFO", lineNo, name, "MaxAuthTries = " + mt + "" + ctx + " — authentication attempts per connection are capped.");
              break;
            }
            case "logingracetime": {
              var secs = parseDuration(value);
              if(secs === null) add("WARNING", lineNo, name, "LoginGraceTime value (" + dispVal(name, value) + ")" + ctx + " could not be read as a duration.");
              else if(secs === 0) add("WARNING", lineNo, name, "LoginGraceTime = 0" + ctx + " — the login timer never expires, so unauthenticated connections can be held open indefinitely and pile up. Set 30-60 seconds.");
              else if(secs > 120) add("WARNING", lineNo, name, "LoginGraceTime = " + secs + "s" + ctx + " — longer than the 120-second default; unauthenticated connections linger and consume slots. 30-60 seconds is a common hardened choice.");
              else add("INFO", lineNo, name, "LoginGraceTime = " + secs + "s" + ctx + " — unauthenticated connections are cut off promptly.");
              break;
            }
            case "x11forwarding":
              if(vt === "yes") add("WARNING", lineNo, name, "X11Forwarding = yes" + ctx + " — X11 forwarding is enabled; a session can reach back into the client's display channel. Disable it on servers that do not run graphical applications for users.");
              else if(vt === "no") add("INFO", lineNo, name, "X11Forwarding = no" + ctx + " — X11 forwarding is disabled.");
              else add("WARNING", lineNo, name, "X11Forwarding has an unrecognized value" + ctx + ".");
              break;
            case "allowtcpforwarding":
              if(vt === "yes") add("WARNING", lineNo, name, "AllowTcpForwarding = yes" + ctx + " — any authenticated user can tunnel arbitrary traffic through this host, turning it into a jump box into whatever it can reach. Set no, or local/remote if only one direction is needed.");
              else if(vt === "no") add("INFO", lineNo, name, "AllowTcpForwarding = no" + ctx + " — TCP forwarding is disabled.");
              else if(vt === "local" || vt === "remote") add("INFO", lineNo, name, "AllowTcpForwarding = " + vt + "" + ctx + " — noted as a restricted setting: only " + vt + " forwarding is permitted.");
              else add("WARNING", lineNo, name, "AllowTcpForwarding has an unrecognized value" + ctx + ".");
              break;
            case "allowagentforwarding":
              if(vt === "yes") add("WARNING", lineNo, name, "AllowAgentForwarding = yes" + ctx + " — agent forwarding is on, and anyone who gains root on this host can borrow a forwarded agent while it is connected, reaching back to the client's other servers. Disable it if users do not need it.");
              else if(vt === "no") add("INFO", lineNo, name, "AllowAgentForwarding = no" + ctx + " — agent forwarding is disabled.");
              else add("WARNING", lineNo, name, "AllowAgentForwarding has an unrecognized value" + ctx + ".");
              break;
            case "permittunnel":
              if(vt === "yes") add("WARNING", lineNo, name, "PermitTunnel = yes" + ctx + " — users can create tun/tap virtual network interfaces through this host, effectively joining its networks. Set no unless VPN-style tunnels are the point of the server.");
              else if(vt === "point-to-point" || vt === "ethernet") add("WARNING", lineNo, name, "PermitTunnel = " + vt + "" + ctx + " — tunnel devices are permitted in " + vt + " mode; confirm every user who can log in should be able to build a network tunnel.");
              else if(vt === "no") add("INFO", lineNo, name, "PermitTunnel = no" + ctx + " — tunnel devices are refused.");
              else add("WARNING", lineNo, name, "PermitTunnel has an unrecognized value" + ctx + ".");
              break;
            case "gatewayports":
              if(vt === "yes") add("WARNING", lineNo, name, "GatewayPorts = yes" + ctx + " — ports forwarded by any user are bound on all interfaces, so a private tunnel becomes a public door. Set no.");
              else if(vt === "clientspecified") add("WARNING", lineNo, name, "GatewayPorts = clientspecified" + ctx + " — clients choose the bind address for forwarded ports, which can expose a tunnel publicly. Confirm that is intended for every user.");
              else if(vt === "no") add("INFO", lineNo, name, "GatewayPorts = no" + ctx + " — forwarded ports stay bound to loopback.");
              else add("WARNING", lineNo, name, "GatewayPorts has an unrecognized value" + ctx + ".");
              break;
            case "clientaliveinterval": {
              var ci = parseIntStrict(vt);
              if(ci === null) add("WARNING", lineNo, name, "ClientAliveInterval value (" + dispVal(name, value) + ")" + ctx + " is not a number of seconds.");
              else if(ci === 0) add("WARNING", lineNo, name, "ClientAliveInterval = 0" + ctx + " — the server never probes connected clients, so dead or abandoned sessions (and any forwards they hold) can linger indefinitely. A common pattern is 120 with ClientAliveCountMax 2.");
              else if(ci > 300) add("WARNING", lineNo, name, "ClientAliveInterval = " + ci + "s" + ctx + " — idle sessions are probed only every " + ci + " seconds; combined with ClientAliveCountMax that can leave idle sessions alive for a long time.");
              else add("INFO", lineNo, name, "ClientAliveInterval = " + ci + "s" + ctx + " — idle clients are probed on a schedule.");
              break;
            }
            case "clientalivecountmax": {
              var cm = parseIntStrict(vt);
              if(cm === null) add("WARNING", lineNo, name, "ClientAliveCountMax value (" + dispVal(name, value) + ")" + ctx + " is not a number.");
              else add("INFO", lineNo, name, "ClientAliveCountMax = " + cm + "" + ctx + " — a client is disconnected after " + cm + " unanswered probes; with ClientAliveInterval this caps how long an idle session can survive.");
              break;
            }
            case "protocol": {
              var toks = vl.split(/[,\s]+/).filter(Boolean);
              if(toks.indexOf("1") !== -1) add("BLOCKER", lineNo, name, "Protocol names protocol 1" + ctx + " — SSH protocol 1 is obsolete and insecure, and support was removed from OpenSSH in 2017. Any value naming 1 must be deleted.");
              else add("INFO", lineNo, name, "Protocol = " + dispVal(name, value) + "" + ctx + " — only protocol 2 is named. Noted: the Protocol directive itself is obsolete in modern OpenSSH and can be removed.");
              break;
            }
            case "authorizedkeysfile": {
              var paths = (value || "").split(/\s+/).filter(Boolean);
              var worst = null;
              paths.forEach(function(pp){
                if(/^\/tmp\//.test(pp) || /^\/var\/tmp\//.test(pp) || /^\/dev\/shm/.test(pp)){
                  if(!worst) worst = { sev:"BLOCKER", msg:"AuthorizedKeysFile points into a world-writable location (" + pp + ")" + ctx + " — anyone who can write that file can grant themselves SSH access. Keep key files under each user's .ssh directory or a root-owned path." };
                } else if(pp.charAt(0) === "/"){
                  if(!worst) worst = { sev:"WARNING", msg:"AuthorizedKeysFile uses the absolute path " + pp + "" + ctx + " for every user — this audit cannot verify that file's ownership or permissions from pasted text. Confirm it is root-owned and not group/world-writable." };
                }
              });
              if(worst) add(worst.sev, lineNo, name, worst.msg);
              else add("INFO", lineNo, name, "AuthorizedKeysFile = " + dispVal(name, value) + "" + ctx + " — a per-user relative path, the standard arrangement.");
              break;
            }
            case "include":
              add("INFO", lineNo, name, "NOT CHECKED — Include " + dispVal(name, value) + "" + ctx + ": the included file(s) were not pasted, so nothing in them is graded. Included directives can change the effective configuration; audit those files separately.", true);
              break;
            case "strictmodes":
              if(vt === "no") add("WARNING", lineNo, name, "StrictModes = no" + ctx + " — sshd stops checking ownership and permissions on home directories and key files, so loosely-permissioned key files become usable. Set yes.");
              else if(vt === "yes") add("INFO", lineNo, name, "StrictModes = yes" + ctx + " — ownership and permissions on key files are enforced.");
              break;
            case "hostbasedauthentication":
              if(vt === "yes") add("WARNING", lineNo, name, "HostbasedAuthentication = yes" + ctx + " — logins are trusted based on the client host's identity, a weaker, rarely-needed model. Set no unless you deliberately run host-based trust.");
              else if(vt === "no") add("INFO", lineNo, name, "HostbasedAuthentication = no" + ctx + " — host-based login trust is disabled.");
              break;
            case "permituserenvironment":
              if(vt === "yes" || /^yes\s/.test(vl)) add("WARNING", lineNo, name, "PermitUserEnvironment = yes" + ctx + " — users can set environment variables from their authorized_keys options and ~/.ssh/environment, which can be abused to influence executed programs. Set no unless a workflow depends on it.");
              else if(vt === "no") add("INFO", lineNo, name, "PermitUserEnvironment = no" + ctx + " — users cannot inject environment variables.");
              break;
            case "ciphers":
            case "macs":
            case "kexalgorithms":
            case "hostkeyalgorithms":
            case "pubkeyacceptedalgorithms": {
              var weak = {
                ciphers: ["arcfour","arcfour128","arcfour256","3des-cbc","blowfish-cbc","cast128-cbc"],
                macs: ["hmac-md5","hmac-md5-96","hmac-sha1-96","umac-64@openssh.com","umac-64-etm@openssh.com"],
                kexalgorithms: ["diffie-hellman-group1-sha1","diffie-hellman-group14-sha1","diffie-hellman-group-exchange-sha1"],
                hostkeyalgorithms: ["ssh-rsa","ssh-dss"],
                pubkeyacceptedalgorithms: ["ssh-rsa","ssh-dss"]
              }[canon] || [];
              var list = vl.split(",").map(function(s){ return s.trim(); }).filter(Boolean);
              var found = list.filter(function(t){ return weak.indexOf(t) !== -1; });
              if(found.length) add("WARNING", lineNo, name, name + "" + ctx + " includes known-weak algorithm(s): " + found.join(", ") + ". Remove them and keep a modern list.");
              else if(canon === "ciphers" && list.some(function(t){ return /-cbc$/.test(t); })) add("INFO", lineNo, name, "Ciphers" + ctx + " — noted: the list includes legacy CBC-mode ciphers. Prefer AEAD ciphers (chacha20-poly1305 or AES-GCM).");
              else add("INFO", lineNo, name, name + "" + ctx + " — no known-weak algorithms in the pasted list.");
              break;
            }
            case "forcecommand":
              add("INFO", lineNo, name, "ForceCommand is set" + ctx + " — sessions in this scope run only the forced command. The command value is not graded.");
              break;
            case "chrootdirectory":
              add("INFO", lineNo, name, "ChrootDirectory is set" + ctx + " — sessions in this scope are confined to a chroot. Its ownership and permissions cannot be verified from pasted text.");
              break;
            case "banner":
              add("INFO", lineNo, name, "Banner is set" + ctx + " — a pre-login banner is configured and noted.");
              break;
            default:
              if(!KNOWN[canon]){
                add("INFO", lineNo, name, "Unrecognized directive " + name + "" + ctx + " — not graded. Current sshd refuses to start on an unknown keyword, and this audit cannot verify one. (Only the directive name is reported, never a password-like value.)");
              }
              break;
          }
        }

        for(var i = 0; i < lines.length; i++){
          var lineNo = i + 1;
          var t = lines[i].replace(/^\s+/, "");
          if(!t || t.charAt(0) === "#") continue;
          var m = t.match(/^([A-Za-z0-9]+)[ \t]*(?:=[ \t]*)?([\s\S]*)$/);
          if(!m){
            add("INFO", lineNo, "(line)", "Line could not be parsed as a directive — not graded.");
            continue;
          }
          var name = m[1];
          var value = (m[2] || "").replace(/\s+$/, "");
          var lower = name.toLowerCase();

          if(lower === "match"){
            var criteria = value.replace(/\s+/g, " ").trim();
            if(criteria.toLowerCase() === "all"){
              scope = "global"; scopeLabel = "global scope";
              add("INFO", lineNo, "Match", "Match all — the block above ends here; directives after this line are global again.");
            } else {
              scope = "match:" + criteria.toLowerCase();
              scopeLabel = "Match " + criteria;
              add("INFO", lineNo, "Match", "Match block begins — criteria: " + criteria + ". Directives under it are graded only for connections matching: " + criteria + ".");
            }
            continue;
          }

          var canon = canonical(lower);
          var skey = scope + "|" + canon;
          var CUMULATIVE = { port:1, listenaddress:1, hostkey:1 };
          if(seen[skey] && !CUMULATIVE[canon]){
            var first = seen[skey];
            add("WARNING", lineNo, name, "Duplicate directive " + first.name + " in the same scope (" + scopeLabel + ") — sshd semantics: the FIRST obtained value wins. Line " + first.line + " (" + first.name + " = " + dispVal(first.name, first.value) + ") is effective; line " + lineNo + " (" + name + " = " + dispVal(name, value) + ") is ignored. Delete one line so the intent is unambiguous.");
            continue;
          }
          seen[skey] = { line:lineNo, name:name, value:value };
          if(scope === "global" && !globalEff[canon]) globalEff[canon] = { line:lineNo, name:name, value:value };
          grade(canon, name, value, lineNo);
        }

        // Absence checks — global scope only. Line shown as "Global".
        function absent(canonKey){ return !globalEff[canonKey]; }
        if(absent("permitrootlogin"))
          add("INFO", null, "PermitRootLogin", "PermitRootLogin is not set — the modern OpenSSH default is prohibit-password. Setting it explicitly removes doubt across versions and distros.");
        if(absent("passwordauthentication"))
          add("WARNING", null, "PasswordAuthentication", "PasswordAuthentication is not set — the compiled default is yes, so password logins are on unless your distro changed it. Set it explicitly.");
        if(absent("kbdinteractiveauthentication"))
          add("WARNING", null, "KbdInteractiveAuthentication", "Neither KbdInteractiveAuthentication nor ChallengeResponseAuthentication is set — the default is yes, so keyboard-interactive (password-style) prompts are on. Set it explicitly.");
        if(absent("pubkeyauthentication"))
          add("INFO", null, "PubkeyAuthentication", "PubkeyAuthentication is not set — the default is yes, so public-key login is available.");
        if(absent("allowusers") && absent("allowgroups"))
          add("WARNING", null, "AllowUsers / AllowGroups", "No AllowUsers or AllowGroups in global scope — there is no allowlist, so every local account is a potential SSH login. Add an allowlist naming only the accounts that actually need SSH.");
        if(absent("allowtcpforwarding"))
          add("WARNING", null, "AllowTcpForwarding", "AllowTcpForwarding is not set — the default is yes, so any user who logs in can tunnel traffic. Set it explicitly.");
        if(absent("allowagentforwarding"))
          add("WARNING", null, "AllowAgentForwarding", "AllowAgentForwarding is not set — the default is yes, so forwarded agents can be borrowed by anyone who gains root on this host. Set it explicitly.");
        if(absent("authenticationmethods"))
          add("INFO", null, "AuthenticationMethods", "AuthenticationMethods is not set — any single enabled authentication method is enough to log in; no chain (such as key plus a second factor) is required.");
        if(absent("strictmodes"))
          add("INFO", null, "StrictModes", "StrictModes is not set — the default is yes, so key-file ownership and permissions are enforced.");
        if(absent("hostbasedauthentication"))
          add("INFO", null, "HostbasedAuthentication", "HostbasedAuthentication is not set — the default is no.");
        if(absent("permituserenvironment"))
          add("INFO", null, "PermitUserEnvironment", "PermitUserEnvironment is not set — the default is no.");
        if(absent("permitemptypasswords"))
          add("INFO", null, "PermitEmptyPasswords", "PermitEmptyPasswords is not set — the default is no.");
        if(absent("x11forwarding"))
          add("INFO", null, "X11Forwarding", "X11Forwarding is not set — the default is no.");
        if(absent("permittunnel"))
          add("INFO", null, "PermitTunnel", "PermitTunnel is not set — the default is no.");
        if(absent("gatewayports"))
          add("INFO", null, "GatewayPorts", "GatewayPorts is not set — the default is no.");
        if(absent("maxauthtries"))
          add("INFO", null, "MaxAuthTries", "MaxAuthTries is not set — the default is 6 attempts per connection.");
        if(absent("logingracetime"))
          add("INFO", null, "LoginGraceTime", "LoginGraceTime is not set — the default is 120 seconds.");
        if(absent("clientaliveinterval"))
          add("INFO", null, "ClientAliveInterval", "ClientAliveInterval is not set — the default is 0, so idle sessions are never probed or cut off.");
        if(absent("authorizedkeysfile"))
          add("INFO", null, "AuthorizedKeysFile", "AuthorizedKeysFile is not set — the default is .ssh/authorized_keys under each user's home.");
        if(absent("listenaddress"))
          add("INFO", null, "ListenAddress", "ListenAddress is not set — by default sshd listens on all interfaces.");
        if(absent("port"))
          add("INFO", null, "Port", "Port is not set — the default is 22.");
        if(absent("protocol"))
          add("INFO", null, "Protocol", "Protocol is not set — fine on modern OpenSSH, which supports protocol 2 only.");

        var blockers = findings.filter(function(f){ return f.sev === "BLOCKER"; }).length;
        var warnings = findings.filter(function(f){ return f.sev === "WARNING"; }).length;
        var infos = findings.filter(function(f){ return f.sev === "INFO"; }).length;
        var notChecked = findings.filter(function(f){ return f.nc; }).length;
        var verdict, vclass, why;
        if(blockers > 0){ verdict = "DO NOT DEPLOY"; vclass = "v-no"; why = blockers + (blockers === 1 ? " blocker" : " blockers") + " must be fixed before this config goes anywhere near a server."; }
        else if(warnings > 0){ verdict = "DEPLOY WITH FIXES"; vclass = "v-fixes"; why = "No blockers, but " + warnings + (warnings === 1 ? " warning" : " warnings") + " should be fixed first."; }
        else { verdict = "SAFE TO DEPLOY"; vclass = "v-safe"; why = "No blockers and no warnings in the pasted text. Included files, host keys, and file permissions were not checked — they are outside what a pasted config can prove."; }
        if(notChecked > 0 && blockers === 0) why += " " + notChecked + (notChecked === 1 ? " Include directive was" : " Include directives were") + " reported NOT CHECKED.";

        return { findings:findings, blockers:blockers, warnings:warnings, infos:infos, notChecked:notChecked, verdict:verdict, vclass:vclass, why:why };
      }

      function buildReport(r){
        var out = [];
        out.push("J-Dawgs OpenSSH Server Config Safety Auditor - report");
        out.push("Verdict: " + r.verdict);
        out.push("Counts: " + r.blockers + " BLOCKER / " + r.warnings + " WARNING / " + r.infos + " INFO (" + r.notChecked + " of the INFO findings are NOT CHECKED Include directives)");
        out.push("");
        r.findings.forEach(function(f){
          out.push("[" + f.sev + "] " + (f.line ? "Line " + f.line : "Global") + " - " + f.key + ": " + f.msg);
        });
        out.push("");
        out.push("Limits: text audit only. This tool does not run sshd, does not connect to any server, and cannot verify host keys, file permissions, local accounts, or included files. Include directives are reported NOT CHECKED by name. Defaults quoted are modern OpenSSH defaults.");
        return out.join("\n");
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-openssh-server-config-safety-auditortm',
  name: 'J-Dawgs OpenSSH Server Config Safety Auditor',
  description: 'sshd -t only says will-it-start on an installed host; ours grades a pasted sshd_config offline — root login, password posture, forwarding, Match blocks, first-value-wins duplicates — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
