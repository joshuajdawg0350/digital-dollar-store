'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Piwigo Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------------- Example configs ---------------- */

      var RISKY_EXAMPLE = [
        "<?php",
        "// Sample Piwigo local config — risky example for this auditor.",
        "$conf['db_host'] = 'localhost';",
        "$conf['db_user'] = 'piwigo_admin';",
        "$conf['db_password'] = 'Sup3rSecretPiwigo!2026';",
        "$conf['db_name'] = 'piwigo_gallery';",
        "$conf['site_url'] = 'http://photos.example.com/gallery';",
        "$conf['show_php_errors'] = true;",
        "$conf['debug'] = true;",
        "$conf['allow_user_registration'] = true;",
        "$conf['guest_access'] = true;",
        "$conf['allow_guest_fullsize'] = true;",
        "$conf['upload_file_types'] = 'jpg,png,gif,php,exe';",
        "$conf['admin_password'] = 'letmein';",
        "$conf['gallery_title'] = 'Family Photos';"
      ].join("\n");

      var HARDENED_EXAMPLE = [
        "<?php",
        "// Sample Piwigo local config — hardened example for this auditor.",
        "// Database and admin credentials are loaded from environment variables",
        "// outside this config file — no password values live in this file.",
        "$conf['db_host'] = 'localhost';",
        "$conf['db_user'] = 'piwigo_admin';",
        "$conf['db_name'] = 'piwigo_gallery';",
        "$conf['site_url'] = 'https://photos.example.com/gallery';",
        "$conf['show_php_errors'] = false;",
        "$conf['debug'] = false;",
        "$conf['allow_user_registration'] = false;",
        "$conf['guest_access'] = false;",
        "$conf['allow_guest_fullsize'] = false;",
        "$conf['upload_file_types'] = 'jpg,jpeg,png,gif,webp';",
        "$conf['rate_limit_login'] = true;",
        "$conf['login_attempts_max'] = 5;",
        "$conf['gallery_locked'] = false;",
        "$conf['force_https'] = true;"
      ].join("\n");

      var PLANTED_SECRET = "Sup3rSecretPiwigo!2026";
      var PLACEHOLDER_PASSWORDS = ["password","admin","changeme","change-me","letmein","123456","12345678","piwigo","default","secret","qwerty"];

      /* ---------------- Parser ----------------
         Reads line by line, keeps exact 1-based line numbers.
         SECRET RULE: for any key whose name contains password / passwd /
         secret / token, the value itself is discarded at parse time.
         Only its length, a placeholder flag, and an "loaded externally"
         flag survive — findings are built from those, never the value. */

      function isSecretKey(keyLower){
        return /password|passwd|secret|token/.test(keyLower);
      }

      function parseRawValue(raw){
        var v = raw.replace(/;\s*$/, "").trim();
        var m;
        m = v.match(/^'([^']*)'$/);
        if (m) return { type:"string", str:m[1] };
        m = v.match(/^"([^"]*)"$/);
        if (m) return { type:"string", str:m[1] };
        if (/^array\s*\(/i.test(v) || v.charAt(0) === "["){
          var items = [];
          var re = /'([^']*)'|"([^"]*)"|([A-Za-z0-9_*.\-]+)/g, t;
          var inner = v.replace(/^array\s*\(/i, "").replace(/^\[/, "");
          while ((t = re.exec(inner)) !== null){
            var item = (t[1] !== undefined ? t[1] : (t[2] !== undefined ? t[2] : t[3]));
            if (item && item.toLowerCase() !== "array") items.push(item);
          }
          return { type:"array", items:items };
        }
        if (/^true$/i.test(v)) return { type:"bool", bool:true };
        if (/^false$/i.test(v)) return { type:"bool", bool:false };
        if (/^-?\d+(\.\d+)?$/.test(v)) return { type:"number", num:parseFloat(v) };
        return { type:"expr", str:v };
      }

      function parseConfig(text){
        var lines = String(text).split(/\r\n|\r|\n/);
        var entries = [];
        var confCount = 0;
        var envNote = false;
        var confRe = /\$conf\s*\[\s*'([^']+)'\s*\]\s*=\s*(.+)$/;
        var confReD = /\$conf\s*\[\s*"([^"]+)"\s*\]\s*=\s*(.+)$/;
        var defRe = /define\s*\(\s*'([A-Za-z0-9_]+)'\s*,\s*(.+)\)/;
        var defReD = /define\s*\(\s*"([A-Za-z0-9_]+)"\s*,\s*(.+)\)/;

        for (var i = 0; i < lines.length; i++){
          var lineNo = i + 1;
          var line = lines[i];
          var trimmed = line.replace(/^\s+/, "");
          if (/^(\/\/|#|\*|\/\*)/.test(trimmed)){
            if (/environment|getenv|outside (this|the) config|secret manager|loaded from/i.test(line)) envNote = true;
            continue;
          }
          var key = null, rawVal = null, m;
          if ((m = line.match(confRe)) || (m = line.match(confReD))){
            key = m[1]; rawVal = m[2]; confCount++;
          } else if ((m = line.match(defRe)) || (m = line.match(defReD))){
            key = m[1]; rawVal = m[2];
          }
          if (key === null) continue;

          var keyLower = key.toLowerCase();
          var parsed = parseRawValue(rawVal);
          var entry = { key:key, keyLower:keyLower, line:lineNo, value:parsed };

          if (isSecretKey(keyLower)){
            var rawStr = rawVal.replace(/;\s*$/, "").trim();
            var external = /getenv|\$_ENV|\$_SERVER/.test(rawStr);
            var valStr = (parsed.type === "string") ? parsed.str : null;
            var len = (valStr !== null) ? valStr.length : 0;
            var placeholder = (valStr !== null) && PLACEHOLDER_PASSWORDS.indexOf(valStr.toLowerCase()) >= 0;
            // The secret value itself is dropped here and never stored.
            entry.value = { type:"secret", len:len, placeholder:placeholder, external:external };
          }
          entries.push(entry);
        }
        return { entries:entries, confCount:confCount, envNote:envNote, lineCount:lines.length };
      }

      function truthy(entry){
        if (!entry) return null;
        var v = entry.value;
        if (v.type === "bool") return v.bool;
        if (v.type === "number") return v.num !== 0;
        if (v.type === "string"){
          var s = v.str.toLowerCase();
          if (s === "true" || s === "1" || s === "on" || s === "yes") return true;
          if (s === "false" || s === "0" || s === "off" || s === "no" || s === "") return false;
          return null;
        }
        if (v.type === "expr"){
          if (/E_ALL/i.test(v.str)) return true;
          if (/^0$/.test(v.str)) return false;
          return null;
        }
        return null;
      }

      function findEntries(entries, test){
        var out = [];
        for (var i = 0; i < entries.length; i++) if (test(entries[i])) out.push(entries[i]);
        return out;
      }

      /* ---------------- Audit ---------------- */

      var SEV_RANK = { CRITICAL:0, HIGH:1, MEDIUM:2, LOW:3, OK:4 };

      function auditConfig(text){
        var parsed = parseConfig(text);
        var findings = [];
        function add(severity, line, key, message, fix){
          findings.push({ severity:severity, line:(line === null ? null : line), key:key, message:message, fix:fix });
        }

        if (String(text).trim() === "" || parsed.confCount === 0){
          return {
            gradeable:false,
            verdict:"NOT ENOUGH TO GRADE",
            explanation:"No Piwigo $conf[...] assignments were found in the pasted text, so there is nothing to grade. Paste the contents of a Piwigo config file (for example local/config/config.inc.php) and audit again.",
            counts:{ CRITICAL:0, HIGH:0, MEDIUM:0, LOW:0, OK:0 },
            findings:[]
          };
        }

        var entries = parsed.entries;
        var i, e, t;

        /* 1. Plaintext database password */
        var dbPw = findEntries(entries, function(en){
          return /password|passwd/.test(en.keyLower) && /(^|_)db(_|$)|database/.test(en.keyLower);
        });
        if (dbPw.length){
          for (i = 0; i < dbPw.length; i++){
            e = dbPw[i];
            if (e.value.external){
              add("OK", e.line, e.key, "Database password is loaded from outside the config (environment), not stored in the file.", "No change needed — keep credentials out of the file.");
            } else if (e.value.len > 0){
              add("CRITICAL", e.line, e.key, "Plaintext database password stored in the config file (length " + e.value.len + " characters). Anyone who can read this file — a backup leak, a misconfigured server, a shared screenshot — has full access to the gallery database.", "Move the database password out of the config: load it from an environment variable or a secrets file outside the web root, then rotate the password, because the old one has been sitting in plaintext.");
            } else {
              add("LOW", e.line, e.key, "Database password key is present but empty.", "Set the database password through your hosting control panel or environment, never as an empty value in the file.");
            }
          }
        } else if (parsed.envNote){
          add("OK", null, "database credentials", "No plaintext database password in this config — a note in the file says credentials are loaded from outside it.", "No change needed.");
        }

        /* 2. Debug / show errors */
        var debugKeys = findEntries(entries, function(en){
          return /debug|show_php_errors|show_errors|display_errors|error_reporting/.test(en.keyLower);
        });
        if (debugKeys.length){
          for (i = 0; i < debugKeys.length; i++){
            e = debugKeys[i]; t = truthy(e);
            if (t === true){
              add("CRITICAL", e.line, e.key, "Debug / error display is switched ON. On a live site this prints PHP errors, file paths, and sometimes database details to anyone who visits.", "Set this to false before deploying, and log errors to a private file instead of showing them to visitors.");
            } else if (t === false){
              add("OK", e.line, e.key, "Debug / error display is off.", "No change needed.");
            }
          }
        }

        /* 3. Site URL scheme */
        var urlKeys = findEntries(entries, function(en){
          return /url/.test(en.keyLower) && en.value.type === "string";
        });
        for (i = 0; i < urlKeys.length; i++){
          e = urlKeys[i];
          if (/^http:\/\//i.test(e.value.str)){
            add("HIGH", e.line, e.key, "Site address uses plain http, not https. Logins, admin sessions, and uploads cross the network unencrypted.", "Move the gallery to an https address (free certificates are standard) and update this value to the https URL.");
          } else if (/^https:\/\//i.test(e.value.str)){
            add("OK", e.line, e.key, "Site address uses https.", "No change needed.");
          }
        }

        /* 4. Open registration */
        var regKeys = findEntries(entries, function(en){
          return /register|registration/.test(en.keyLower);
        });
        for (i = 0; i < regKeys.length; i++){
          e = regKeys[i]; t = truthy(e);
          if (t === true){
            add("HIGH", e.line, e.key, "Open registration is enabled — anyone on the internet can create an account on the gallery, which invites spam accounts and upload abuse.", "Turn registration off, or leave it on only with admin approval for new accounts.");
          } else if (t === false){
            add("OK", e.line, e.key, "Open registration is off.", "No change needed.");
          }
        }

        /* 5. Guest access to full-size originals */
        var guestKeys = findEntries(entries, function(en){
          return /guest/.test(en.keyLower);
        });
        for (i = 0; i < guestKeys.length; i++){
          e = guestKeys[i]; t = truthy(e);
          var fullsize = /full|original/.test(e.keyLower);
          if (t === true){
            add("HIGH", e.line, e.key, fullsize
              ? "Guests can reach full-size original photos without an account. Originals are the master files — anyone can download them at full resolution."
              : "Guest access is open — visitors without an account can browse gallery content this key exposes.", "Set this to false so guests see only the sizes you intend to share, and keep originals behind a login.");
          } else if (t === false){
            add("OK", e.line, e.key, "Guest access on this key is off.", "No change needed.");
          }
        }

        /* 6. Gallery posture */
        var lockKeys = findEntries(entries, function(en){
          return /gallery_(locked|closed)|maintenance/.test(en.keyLower);
        });
        for (i = 0; i < lockKeys.length; i++){
          e = lockKeys[i]; t = truthy(e);
          if (t === true){
            add("LOW", e.line, e.key, "The gallery is locked / closed in this config. That is safe, but visitors will see a closed gallery.", "Deploy is fine — just remember to unlock the gallery once you are ready for visitors.");
          }
        }
        var publicKeys = findEntries(entries, function(en){
          return /gallery_public|public_gallery|open_to_public/.test(en.keyLower);
        });
        for (i = 0; i < publicKeys.length; i++){
          e = publicKeys[i]; t = truthy(e);
          if (t === true){
            add("MEDIUM", e.line, e.key, "The gallery is explicitly set open to the public, with no access control noted in the config.", "If any albums are private, add access control (accounts or album permissions) before deploying, or accept that everything is public.");
          }
        }

        /* 7. Admin password posture (secret-safe: length only) */
        var adminPw = findEntries(entries, function(en){
          return /admin/.test(en.keyLower) && /password|passwd/.test(en.keyLower);
        });
        if (adminPw.length){
          for (i = 0; i < adminPw.length; i++){
            e = adminPw[i];
            if (e.value.external){
              add("OK", e.line, e.key, "Admin password is loaded from outside the config (environment), not stored in the file.", "No change needed.");
            } else if (e.value.len === 0){
              add("MEDIUM", e.line, e.key, "Admin password key is present but empty.", "Set a strong admin password of at least 12 characters through the installer or admin panel.");
            } else if (e.value.placeholder){
              add("HIGH", e.line, e.key, "Admin password is a well-known placeholder value (length " + e.value.len + " characters). It is one of the first things an attacker tries.", "Change it to a unique password of at least 12 characters that you use nowhere else.");
            } else if (e.value.len < 12){
              add("HIGH", e.line, e.key, "Admin password is short (length " + e.value.len + " characters). Short admin passwords fall to automated guessing.", "Change it to a unique password of at least 12 characters — a few random words plus digits works well.");
            } else {
              add("OK", e.line, e.key, "Admin password length looks reasonable (length " + e.value.len + " characters). Strength beyond length cannot be judged from a config.", "No change needed — keep it unique to this gallery.");
            }
          }
        } else if (parsed.envNote){
          add("OK", null, "admin credentials", "No plaintext admin password in this config — a note in the file says credentials are loaded from outside it.", "No change needed.");
        } else {
          add("MEDIUM", null, "admin_password (missing)", "No admin password key was found in the config, and nothing in the file says credentials are handled elsewhere. The auditor cannot confirm the admin account is protected.", "Confirm the gallery admin account uses a strong, unique password of at least 12 characters, set through the installer or admin panel — not a default or a reused one.");
        }

        /* 8. Rate limiting / brute-force protection */
        var rlKeys = findEntries(entries, function(en){
          return /rate_limit|login_attempt|brute|captcha|fail2ban|login_lock/.test(en.keyLower);
        });
        var rlOn = null;
        for (i = 0; i < rlKeys.length; i++){
          t = truthy(rlKeys[i]);
          if (t === true){ rlOn = rlKeys[i]; break; }
          if (rlKeys[i].value.type === "number" && rlKeys[i].value.num > 0){ rlOn = rlKeys[i]; break; }
        }
        if (rlOn){
          add("OK", rlOn.line, rlOn.key, "Login rate limiting / brute-force protection is switched on.", "No change needed.");
        } else if (rlKeys.length){
          add("MEDIUM", rlKeys[0].line, rlKeys[0].key, "A rate-limiting key exists but is switched off, so the login page can be guessed against without slowing down.", "Enable login rate limiting (for example a small number of attempts, then a lockout) before deploying.");
        } else {
          add("MEDIUM", null, "rate limiting (missing)", "No rate limiting, login-attempt limit, captcha, or brute-force protection key was found. The admin login can be guessed against all day without slowing down.", "Enable a login-attempt limit or rate limiting (in Piwigo settings, a plugin, or fail2ban on the server) before deploying.");
        }

        /* 9. Upload file types */
        var upKeys = findEntries(entries, function(en){
          return /file_types|allowed.*(ext|type)|upload.*types|extensions/.test(en.keyLower);
        });
        var EXEC = ["php","php3","php4","php5","phtml","exe","sh","cgi","pl","asp","aspx","jsp","com","bat","cmd","jar","swf"];
        for (i = 0; i < upKeys.length; i++){
          e = upKeys[i];
          var items = [];
          if (e.value.type === "array") items = e.value.items.slice();
          else if (e.value.type === "string") items = e.value.str.split(/[,\s|]+/);
          var clean = [];
          for (var j = 0; j < items.length; j++){
            var it = String(items[j]).replace(/^\./, "").toLowerCase().trim();
            if (it) clean.push(it);
          }
          var execFound = [];
          for (j = 0; j < clean.length; j++) if (EXEC.indexOf(clean[j]) >= 0) execFound.push(clean[j]);
          if (execFound.length){
            add("CRITICAL", e.line, e.key, "Upload file types allow executable files (" + execFound.join(", ") + "). If uploads land anywhere the web server can run them, one uploaded file can take over the site.", "Restrict upload types to images only — jpg, jpeg, png, gif, webp — and never allow script or program extensions.");
          } else if (clean.indexOf("*") >= 0 || clean.length === 0){
            add("MEDIUM", e.line, e.key, "Upload file types are unrestricted (wildcard or empty list), so any kind of file can be uploaded.", "Restrict upload types to the image formats the gallery needs — jpg, jpeg, png, gif, webp.");
          } else {
            add("OK", e.line, e.key, "Upload file types are restricted to: " + clean.join(", ") + ".", "No change needed.");
          }
        }

        findings.sort(function(a, b){
          var r = SEV_RANK[a.severity] - SEV_RANK[b.severity];
          if (r !== 0) return r;
          var la = (a.line === null ? 99999 : a.line), lb = (b.line === null ? 99999 : b.line);
          if (la !== lb) return la - lb;
          return a.key < b.key ? -1 : (a.key > b.key ? 1 : 0);
        });

        var counts = { CRITICAL:0, HIGH:0, MEDIUM:0, LOW:0, OK:0 };
        for (i = 0; i < findings.length; i++) counts[findings[i].severity]++;

        var verdict;
        if (counts.CRITICAL > 0) verdict = "DO NOT DEPLOY";
        else if (counts.HIGH >= 2) verdict = "DO NOT DEPLOY";
        else if (counts.HIGH === 1) verdict = "DEPLOY WITH FIXES";
        else if (counts.MEDIUM > 0) verdict = "DEPLOY WITH FIXES";
        else verdict = "SAFE TO DEPLOY";

        return { gradeable:true, verdict:verdict, explanation:null, counts:counts, findings:findings };
      }

      /* ---------------- Reports (secret-safe by construction) ---------------- */

      function buildTextReport(result){
        var lines = [];
        lines.push("J-Dawgs Piwigo Server Config Safety Auditor — Audit Report");
        lines.push("Verdict: " + result.verdict);
        if (!result.gradeable){
          lines.push(result.explanation);
          return lines.join("\n");
        }
        var c = result.counts;
        lines.push("Findings: " + result.findings.length + " total — CRITICAL " + c.CRITICAL + ", HIGH " + c.HIGH + ", MEDIUM " + c.MEDIUM + ", LOW " + c.LOW + ", OK " + c.OK);
        lines.push("----------------------------------------");
        for (var i = 0; i < result.findings.length; i++){
          var f = result.findings[i];
          lines.push("[" + f.severity + "] " + (f.line === null ? "No line" : "Line " + f.line) + " · " + f.key);
          lines.push("  " + f.message);
          lines.push("  Fix: " + f.fix);
        }
        return lines.join("\n");
      }

      function buildJSONExport(result){
        return JSON.stringify({
          tool: "J-Dawgs Piwigo Server Config Safety Auditor",
          verdict: result.verdict,
          gradeable: result.gradeable,
          explanation: result.explanation,
          counts: result.counts,
          findings: result.findings
        }, null, 2);
      }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-piwigo-server-config-safety-auditortm',
  name: 'J-Dawgs Piwigo Server Config Safety Auditor',
  description: '',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
