'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Logrotate Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

  "use strict";

  var RISKY = [
    "/var/log/app/*.log {",
    "    daily",
    "    rotate 0",
    "    compress",
    "    delaycompress",
    "    copytruncate",
    "    prerotate",
    "        /usr/local/bin/pre.sh",
    "    endscript",
    "    postrotate",
    "        /usr/local/bin/post.sh",
    "    endscript",
    "    frobnicate",
    "}",
    "",
    "/var/log/app/*.log {",
    "    weekly",
    "    size 100M",
    "}"
  ].join("\n");

  var CLEAN = [
    "/var/log/myapp/app.log {",
    "    weekly",
    "    rotate 8",
    "    missingok",
    "    compress",
    "    dateext",
    "    dateformat -%Y%m%d",
    "    create 0640 myapp adm",
    "    su myapp adm",
    "    sharedscripts",
    "    postrotate",
    "        /bin/systemctl reload myapp >/dev/null 2>&1 || true",
    "    endscript",
    "}"
  ].join("\n");

  var WORKED = [
    "/var/log/worker.log {",
    "    daily",
    "    rotate 0",
    "    missingok",
    "}"
  ].join("\n");

  var KNOWN = {};
  [
    "daily","weekly","monthly","yearly","hourly","rotate","missingok","nomissingok",
    "compress","nocompress","delaycompress","copytruncate","nocopytruncate",
    "create","nocreate","createolddir","nocreateolddir","dateext","nodateext",
    "dateformat","dateyesterday","su","sharedscripts","nosharedscripts",
    "prerotate","postrotate","firstaction","lastaction","endscript",
    "size","minsize","maxsize","maxage","shred","noshred","shredcycles",
    "notifempty","ifempty","nomail","mail","mailfirst","maillast",
    "olddir","noolddir","start","extension","addextension","include",
    "tabooext","taboopat","errors","renamecopy","norenamecopy","weekly"
  ].forEach(function(d){ KNOWN[d] = true; });

  var SCHEDULE_DAYS = { hourly: null, daily: 1, weekly: 7, monthly: 30, yearly: 365 };
  var SCHEDULE_LABEL = { hourly: "hourly", daily: "daily (1 day)", weekly: "weekly (7 days)", monthly: "monthly (~30 days)", yearly: "yearly (365 days)" };

  var inputEl = document.getElementById("config-input");
  var reportEl = document.getElementById("report-output");
  var verdictEl = document.getElementById("verdict");
  var verdictLabel = document.getElementById("verdict-label");
  var verdictDetail = document.getElementById("verdict-detail");
  var findingsWrap = document.getElementById("findings-wrap");
  var findingsEl = document.getElementById("findings");
  var retentionWrap = document.getElementById("retention-wrap");
  var retentionBody = document.getElementById("retention-body");
  var inputStatus = document.getElementById("input-status");
  var copyStatus = document.getElementById("copy-status");

  function copyText(text, statusEl, okMsg){
    function done(ok){
      if (statusEl) statusEl.textContent = ok ? okMsg : "Copy failed — select the text and copy it by hand.";
    }
    if (navigator.clipboard && navigator.clipboard.writeText){
      navigator.clipboard.writeText(text).then(function(){ done(true); }, function(){ fallback(); });
    } else { fallback(); }
    function fallback(){
      try {
        var ta = document.createElement("textarea");
        ta.value = text;
        ta.style.position = "fixed";
        ta.style.opacity = "0";
        document.body.appendChild(ta);
        ta.select();
        var ok = document.execCommand("copy");
        document.body.removeChild(ta);
        done(!!ok);
      } catch(e){ done(false); }
    }
  }

  function stripComment(line){
    var idx = line.indexOf("#");
    if (idx === -1) return line;
    return line.slice(0, idx);
  }

  function splitPaths(headerText){
    var m = headerText.match(/"[^"]+"|\S+/g) || [];
    return m.map(function(p){ return p.replace(/^"|"$/g, ""); }).filter(function(p){ return p.length > 0; });
  }

  function parseConfig(text){
    var lines = text.replace(/\r\n?/g, "\n").split("\n");
    var stanzas = [];
    var globals = []; // {name, line, args}
    var current = null;
    var inScript = false;
    var pendingHeader = null;

    for (var i = 0; i < lines.length; i++){
      var lineNo = i + 1;
      var raw = lines[i];
      var noComment = stripComment(raw);
      var trimmed = noComment.trim();

      if (!current){
        if (trimmed === "") continue;
        if (trimmed === "{"){
          var paths = pendingHeader ? splitPaths(pendingHeader.text) : [];
          current = newStanza(paths, pendingHeader ? pendingHeader.line : lineNo);
          pendingHeader = null;
          inScript = false;
          continue;
        }
        if (trimmed.indexOf("{") !== -1){
          var braceIdx = trimmed.indexOf("{");
          var head = trimmed.slice(0, braceIdx).trim();
          var rest = trimmed.slice(braceIdx + 1).trim();
          current = newStanza(splitPaths(head), lineNo);
          inScript = false;
          if (rest) processBodyLine(current, rest, lineNo);
          continue;
        }
        // Possible header line whose "{" is on the next line
        if (/^"/.test(trimmed) || /^\//.test(trimmed) || /^\*/.test(trimmed)){
          pendingHeader = { text: trimmed, line: lineNo };
          continue;
        }
        // Global directive line
        var gtok = trimmed.split(/\s+/);
        if (gtok[0]) globals.push({ name: gtok[0].toLowerCase(), line: lineNo, args: gtok.slice(1), raw: trimmed });
        continue;
      }

      // Inside a stanza
      if (inScript){
        if (trimmed.toLowerCase() === "endscript"){
          inScript = false;
          current.directives.push({ name: "endscript", line: lineNo, args: [], raw: trimmed });
        }
        continue;
      }
      if (trimmed === "}" || trimmed.indexOf("}") === 0){
        current.endLine = lineNo;
        stanzas.push(current);
        current = null;
        continue;
      }
      if (trimmed === "") continue;
      processBodyLine(current, trimmed, lineNo);
      var lastDir = current.directives[current.directives.length - 1];
      if (lastDir && (lastDir.name === "prerotate" || lastDir.name === "postrotate" || lastDir.name === "firstaction" || lastDir.name === "lastaction")){
        inScript = true;
        current.scripts.push({ name: lastDir.name, line: lineNo });
      }
    }
    if (current){ current.endLine = lines.length; stanzas.push(current); }
    return { stanzas: stanzas, globals: globals, lineCount: lines.length };

    function newStanza(paths, startLine){
      return {
        paths: paths,
        pathLabel: paths.length ? paths.join(" ") : "(no path parsed)",
        startLine: startLine,
        endLine: startLine,
        directives: [],
        scripts: []
      };
    }
    function processBodyLine(stanza, trimmedLine, lineNo){
      var tok = trimmedLine.split(/\s+/);
      if (!tok[0]) return;
      stanza.directives.push({ name: tok[0].toLowerCase(), line: lineNo, args: tok.slice(1), raw: trimmedLine });
    }
  }

  function dirMap(stanza){
    var map = {};
    stanza.directives.forEach(function(d){
      if (!map[d.name]) map[d.name] = [];
      map[d.name].push(d);
    });
    return map;
  }
  function has(map, name){ return !!map[name]; }
  function first(map, name){ return map[name] ? map[name][0] : null; }

  function globalHas(globals, name){
    for (var i = 0; i < globals.length; i++) if (globals[i].name === name) return globals[i];
    return null;
  }

  function audit(text){
    var parsed = parseConfig(text);
    var findings = [];
    var retentions = [];

    function add(sev, stanzaLabel, line, title, detail){
      findings.push({ sev: sev, stanza: stanzaLabel, line: line, title: title, detail: detail });
    }

    // Unknown global directives
    parsed.globals.forEach(function(g){
      if (!KNOWN[g.name]){
        add("NOT AUDITED", "global (outside any stanza)", g.line,
          "Unknown directive \"" + g.name + "\" — NOT AUDITED",
          "This auditor does not recognize \"" + g.name + "\" and did not grade it. It may be a typo, a directive from a newer logrotate, or a global-only option used in the wrong place. Check it against the logrotate man page by hand.");
      }
    });

    var seenPaths = {}; // path -> {stanzaIndex, line}

    parsed.stanzas.forEach(function(stanza, sIdx){
      var map = dirMap(stanza);
      var label = stanza.pathLabel;
      var startLine = stanza.startLine;
      var hasWildcard = stanza.paths.some(function(p){ return p.indexOf("*") !== -1 || p.indexOf("?") !== -1; });

      // Effective values with global fallback for presence checks
      var rotateDir = first(map, "rotate") || globalHas(parsed.globals, "rotate") && { line: globalHas(parsed.globals, "rotate").line, args: globalHas(parsed.globals, "rotate").args, global: true };
      var scheduleName = null, scheduleLine = null;
      ["hourly","daily","weekly","monthly","yearly"].forEach(function(s){
        if (has(map, s)){ scheduleName = s; scheduleLine = first(map, s).line; }
      });
      if (!scheduleName){
        ["hourly","daily","weekly","monthly","yearly"].forEach(function(s){
          var g = globalHas(parsed.globals, s);
          if (g && !scheduleName){ scheduleName = s; scheduleLine = g.line; }
        });
      }
      var rotateVal = null;
      if (rotateDir && rotateDir.args.length){
        var rv = parseInt(rotateDir.args[0], 10);
        if (!isNaN(rv)) rotateVal = rv;
      }

      // 1. No rotate count
      if (!rotateDir){
        add("WARNING", label, startLine,
          "No rotate count — unbounded growth risk",
          "This stanza never states how many archives to keep. With no rotate count in the stanza (and none in the global lines), retention is unbounded on paper: archives can pile up until the disk fills. Add an explicit rotate N so the retention window is a decision, not an accident.");
      }

      // 8. rotate 0 with a schedule
      if (rotateVal === 0 && scheduleName){
        add("BLOCKER", label, rotateDir.line,
          "rotate 0 with " + scheduleName + " — logs deleted with no retention",
          "rotate 0 (line " + rotateDir.line + ") on a " + scheduleName + " schedule (line " + scheduleLine + ") means every rotation deletes the log outright and keeps no archive at all. The first rotation after deploy erases the history. Set rotate to at least 1 — at least 4 is a safer floor — unless deletion-on-rotation is truly intended.");
      } else if (rotateVal === 0){
        add("WARNING", label, rotateDir.line,
          "rotate 0 — logs deleted with no retention",
          "rotate 0 keeps no archives: rotation deletes the log. No schedule directive was found in this stanza to pair it with, but the effect is the same whenever rotation fires.");
      }

      // 2. Wildcard without missingok
      if (hasWildcard && !has(map, "missingok") && !globalHas(parsed.globals, "missingok")){
        add("WARNING", label, startLine,
          "Wildcard path without missingok — rotation failure risk",
          "The path uses a wildcard but the stanza has no missingok. If the wildcard matches nothing on a given run — or one matched file is missing — logrotate reports an error and the stanza's rotation fails instead of quietly skipping. Add missingok if an empty match is acceptable.");
      }

      // 3. copytruncate checks
      if (has(map, "copytruncate")){
        var ct = first(map, "copytruncate");
        add("WARNING", label, ct.line,
          "copytruncate in use — risky on a large or active log",
          "copytruncate copies the whole log and then truncates the original in place. On a large or actively-written log that copy takes real time, and anything the writer appends between the copy and the truncate is lost. If the writing process can reopen its log file, prefer create + a reload/reopen signal instead.");
        if (!has(map, "create")){
          add("WARNING", label, ct.line,
            "copytruncate with no create — create semantics do not apply here",
            "This pairing is expected, not a typo — but it changes what you can rely on. With copytruncate the original file is never replaced: it is copied, then emptied in place. A create directive (mode and owner for the replacement file) only acts when rotation renames the old file and makes a new one, so under copytruncate create has nothing to act on and ownership/permissions simply stay whatever they already are on the existing file. Do not add create expecting it to fix ownership on a copytruncate stanza, and do not expect a fresh file with fresh permissions after rotation.");
        }
      }

      // 4. compress + delaycompress
      if (has(map, "compress") && has(map, "delaycompress")){
        add("WARNING", label, first(map, "delaycompress").line,
          "compress with delaycompress — contradictory pair",
          "compress (line " + first(map, "compress").line + ") asks for archives to be compressed, but delaycompress (line " + first(map, "delaycompress").line + ") postpones compression of the most recent archive by one full rotation cycle. The pair is legal — delaycompress exists for programs that keep the newest archive open — but as written the newest archive always sits uncompressed, which surprises anyone reading compress at face value. Keep delaycompress only if a program genuinely holds the fresh archive open; otherwise drop it.");
      }

      // 5. su missing
      if (!has(map, "su") && !globalHas(parsed.globals, "su")){
        add("WARNING", label, startLine,
          "su missing — daemon may refuse or run as wrong owner, NOT SETTLED without filesystem facts",
          "This stanza has no su directive. Whether that matters depends on the owner and permissions of the log's parent directory — facts that live on the target filesystem, not in this pasted text, so this auditor does not settle it. On systems where the parent directory is not root-owned or is group/world-writable, logrotate may refuse to rotate this stanza at all; elsewhere it may rotate running as an unintended owner. Check the parent directory on the target machine, then set su <user> <group> explicitly to match it.");
      }

      // 6. Scripts without sharedscripts
      if (stanza.scripts.length && !has(map, "sharedscripts") && !globalHas(parsed.globals, "sharedscripts")){
        if (stanza.paths.length > 1 || hasWildcard){
          var scriptDesc = stanza.scripts.map(function(s){ return s.name + " (line " + s.line + ")"; }).join(", ");
          var countDesc = hasWildcard
            ? "once for every file the wildcard matches — the matched-file count is NOT SETTLED from pasted text"
            : "once for each of the " + stanza.paths.length + " paths in this stanza";
          add("WARNING", label, stanza.scripts[0].line,
            "prerotate/postrotate without sharedscripts — scripts run per file",
            stanza.scripts.length + " script block(s) here (" + scriptDesc + ") will each run " + countDesc + ", not once per stanza. A reload or restart script therefore fires repeatedly — wasteful, and racy if the script is not idempotent. Add sharedscripts if the scripts should run exactly once per stanza.");
        }
      }

      // 7. dateext absent
      if (!has(map, "dateext") && !globalHas(parsed.globals, "dateext")){
        add("INFO", label, startLine,
          "dateext absent — numeric archive suffixes",
          "Without dateext, archives are named with numeric suffixes (.1, .2, .2.gz …) instead of dates, so an archive's age cannot be read from its filename and old archives are harder to identify during an incident. Harmless, but dateext is usually what operators expect.");
      }

      // 9. size/minsize overriding schedule
      var sizeDir = first(map, "size") || first(map, "minsize");
      if (sizeDir && scheduleName && !sizeDir.global){
        add("WARNING", label, sizeDir.line,
          sizeDir.name + " overrides the " + scheduleName + " schedule",
          sizeDir.name + " " + (sizeDir.args.join(" ") || "") + " (line " + sizeDir.line + ") takes precedence over the " + scheduleName + " schedule (line " + scheduleLine + "): rotation is decided by file size, not by the calendar. The schedule word stays in the file but stops being the trigger. Keep both only if size-driven rotation inside a scheduled check is exactly what you intend.");
      }

      // 11. Unknown directives
      stanza.directives.forEach(function(d){
        if (!KNOWN[d.name]){
          add("NOT AUDITED", label, d.line,
            "Unknown directive \"" + d.name + "\" — NOT AUDITED",
            "This auditor does not recognize \"" + d.name + "\" (line " + d.line + ") and did not grade it. It may be a typo of a real directive — a misspelled directive is silently not the protection you think you configured — or a directive from a newer logrotate than this auditor's list. Verify it against the logrotate man page by hand.");
        }
      });

      // 10. Duplicate stanza paths
      stanza.paths.forEach(function(p){
        if (seenPaths[p]){
          add("BLOCKER", label, startLine,
            "Duplicate stanza for " + p + " — first at line " + seenPaths[p].line + ", again at line " + startLine,
            "The path " + p + " is configured by two stanzas: the first starting at line " + seenPaths[p].line + " and this one at line " + startLine + ". logrotate treats a duplicate log entry as an error and skips the duplicated path, so one of these stanzas silently does nothing. Merge them into a single stanza.");
        } else {
          seenPaths[p] = { stanzaIndex: sIdx, line: startLine };
        }
      });

      // Retention math
      var retention;
      if (rotateVal === null){
        retention = {
          stanza: label + " (line " + startLine + ")",
          math: "schedule " + (scheduleName || "not stated") + " × rotate — no rotate count found",
          window: "NOT SETTLED — no rotate count, so no retention window can be computed"
        };
      } else if (!scheduleName){
        var sizeNote = sizeDir ? " Rotation here is size-driven (" + sizeDir.name + " " + (sizeDir.args.join(" ") || "") + "), so the window also depends on how fast the log grows." : "";
        retention = {
          stanza: label + " (line " + startLine + ")",
          math: "no schedule directive × rotate " + rotateVal,
          window: "NOT SETTLED from the stanza alone — no daily/weekly/monthly schedule stated." + sizeNote
        };
      } else if (scheduleName === "hourly"){
        retention = {
          stanza: label + " (line " + startLine + ")",
          math: "hourly (1 hour) × rotate " + rotateVal + " = " + rotateVal + " hours",
          window: rotateVal + " hours (" + (rotateVal / 24) + " days)"
        };
      } else {
        var days = SCHEDULE_DAYS[scheduleName] * rotateVal;
        retention = {
          stanza: label + " (line " + startLine + ")",
          math: SCHEDULE_LABEL[scheduleName] + " × rotate " + rotateVal + " = " + days + " days",
          window: days + " days"
        };
      }
      retentions.push(retention);
    });

    var counts = { BLOCKER: 0, WARNING: 0, INFO: 0, "NOT AUDITED": 0 };
    findings.forEach(function(f){ counts[f.sev]++; });

    var verdict, verdictClass;
    if (counts.BLOCKER > 0){ verdict = "DO NOT DEPLOY"; verdictClass = "donot"; }
    else if (counts.WARNING > 0 || counts["NOT AUDITED"] > 0){ verdict = "DEPLOY WITH FIXES"; verdictClass = "fixes"; }
    else { verdict = "SAFE TO DEPLOY"; verdictClass = "safe"; }

    // Sort findings: BLOCKER, WARNING, NOT AUDITED, INFO; then by line
    var order = { "BLOCKER": 0, "WARNING": 1, "NOT AUDITED": 2, "INFO": 3 };
    findings.sort(function(a, b){ return (order[a.sev] - order[b.sev]) || (a.line - b.line); });

    return { verdict: verdict, verdictClass: verdictClass, findings: findings, counts: counts, retentions: retentions, stanzaCount: parsed.stanzas.length };
  }

  function buildReport(result, sourceText){
    var out = [];
    out.push("J-Dawgs Logrotate Config Safety Auditor — audit report");
    out.push("======================================================");
    out.push("Verdict: " + result.verdict);
    out.push("Stanzas audited: " + result.stanzaCount);
    out.push("Findings: " + result.counts.BLOCKER + " BLOCKER, " + result.counts.WARNING + " WARNING, " + result.counts["NOT AUDITED"] + " NOT AUDITED, " + result.counts.INFO + " INFO");
    out.push("");
    out.push("Retention math (per stanza):");
    result.retentions.forEach(function(r){
      out.push("- " + r.stanza + ": " + r.math + " -> " + r.window);
    });
    out.push("");
    out.push("Findings:");
    if (!result.findings.length){
      out.push("- None. No BLOCKER, WARNING, NOT AUDITED, or INFO findings.");
    } else {
      result.findings.forEach(function(f){
        out.push("- [" + f.sev + "] " + f.stanza + " — line " + f.line + ": " + f.title);
        out.push("  " + f.detail);
      });
    }
    out.push("");
    out.push("Scope note: heuristic text audit only. This tool never ran logrotate, never touched the filesystem, and saved and uploaded nothing. Items marked NOT SETTLED or NOT AUDITED need filesystem facts or a manual man-page check.");
    return out.join("\n");
  }

  function showEmpty(message){
    verdictEl.className = "verdict show empty";
    verdictLabel.textContent = message;
    verdictDetail.textContent = "";
    findingsWrap.style.display = "none";
    retentionWrap.style.display = "none";
    findingsEl.innerHTML = "";
    retentionBody.innerHTML = "";
    reportEl.value = "";
  }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-logrotate-config-safety-auditortm',
  name: 'J-Dawgs Logrotate Config Safety Auditor',
  description: 'logrotate --debug needs an install and a state file; ours audits a pasted logrotate config offline — retention math with arithmetic shown, copytruncate, rotate 0 as a blocker, duplicate stanzas — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
