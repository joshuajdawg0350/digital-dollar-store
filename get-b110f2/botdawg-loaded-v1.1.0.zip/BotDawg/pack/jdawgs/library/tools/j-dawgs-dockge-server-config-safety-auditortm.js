'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Dockge Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Worked examples (line numbers are part of the test contract) ---------- */
      /* Risky example lines:
         1 comment · 5 image:latest · 8 privileged · 10 bare port 5001 ·
         12 DOCKGE_ADMIN_PASSWORD (plaintext, weak) · 13 API_TOKEN (plaintext) ·
         15 docker.sock · 16 stacks mount · 17 host root mount            */
      var RISKY_EXAMPLE = [
        "# RISKY EXAMPLE — for practice only, do not deploy",
        'version: "3.8"',
        "services:",
        "  dockge:",
        "    image: louislam/dockge:latest",
        "    container_name: dockge",
        "    restart: unless-stopped",
        "    privileged: true",
        "    ports:",
        '      - "5001:5001"',
        "    environment:",
        "      - DOCKGE_ADMIN_PASSWORD=admin123",
        "      - API_TOKEN=sk-live-9f8e7d6c5b4a3210fedcba9876",
        "    volumes:",
        "      - /var/run/docker.sock:/var/run/docker.sock",
        "      - /opt/stacks:/opt/stacks",
        "      - /:/host-files"
      ].join("\n");

      var HARDENED_EXAMPLE = [
        "# HARDENED EXAMPLE — localhost bind, TLS proxy, file-based secret",
        'version: "3.8"',
        "services:",
        "  dockge:",
        "    image: louislam/dockge:1",
        "    container_name: dockge",
        "    restart: unless-stopped",
        "    ports:",
        '      - "127.0.0.1:5001:5001"',
        "    environment:",
        "      - DOCKGE_STACKS_DIR=/opt/stacks",
        "      - DOCKGE_ADMIN_PASSWORD_FILE=/run/secrets/dockge_admin_password",
        "    volumes:",
        "      - /var/run/docker.sock:/var/run/docker.sock",
        "      - ./data:/app/data",
        "      - /opt/stacks:/opt/stacks",
        "    labels:",
        '      - "proxy.host=dockge.internal"',
        '      - "proxy.scheme=https"',
        '      - "proxy.tls=true"',
        "secrets:",
        "  dockge_admin_password:",
        "    file: ./secrets/dockge_admin_password.txt"
      ].join("\n");

      var WEAK_PASSWORDS = ["admin","admin123","password","password123","dockge","123456","12345678","123456789","changeme","letmein","root","test","qwerty","default"];
      var SECRET_KEY_RE = /([A-Za-z_][A-Za-z0-9_.-]*(?:PASSWORD|PASSWD|SECRET|TOKEN|API[-_]?KEY|PRIVATE[-_]?KEY|CREDENTIAL|AUTH[-_]?KEY)[A-Za-z0-9_.-]*)\s*[:=]\s*["']?([^\s"'#]+)/i;

      function auditConfig(text) {
        var findings = [];
        var secretValues = []; /* internal only: used to redact outputs, never rendered */
        function add(code, severity, line, title, fix, extra) {
          var f = { code: code, severity: severity, line: line, title: title, fix: fix };
          if (extra) { for (var k in extra) { f[k] = extra[k]; } }
          findings.push(f);
        }
        if (typeof text !== "string") { text = ""; }
        var lines = text.split(/\r?\n/);
        var trimmed = text.trim();

        var hasDockgeSignal = /dockge/i.test(text) || /DOCKGE_/.test(text) || /5001/.test(text);
        var hasComposeSignal = /(^|\n)\s*(services|image|ports|volumes|environment)\s*:/.test(text) || /docker\.sock/.test(text) || /docker-compose/.test(text);
        if (trimmed.length < 40 || (!hasDockgeSignal && !hasComposeSignal)) {
          add("NOT_ENOUGH", "INFO", null, "Not enough config text to grade",
            "Paste the Dockge environment lines, startup flags, or the full docker-compose text — a few fragments are not enough to judge the deployment.", null);
          return finish("NOT ENOUGH TO GRADE", findings, lines.length, secretValues);
        }

        var hasTLS = /(https|tls|ssl|traefik|caddy|letsencrypt)/i.test(text);
        var localhostBind = /127\.0\.0\.1\s*:\s*\d+\s*:\s*\d+/.test(text) || /127\.0\.0\.1\s*:\s*5001/.test(text);
        var exposedBindLine = null;
        var sawPasswordPosture = false;
        var stacksLine = null;

        for (var i = 0; i < lines.length; i++) {
          var n = i + 1;
          var L = lines[i];

          /* --- secrets: key name, line, length ONLY --- */
          var m = L.match(SECRET_KEY_RE);
          if (m) {
            var key = m[1], val = m[2];
            if (/_FILE$/i.test(key)) {
              sawPasswordPosture = true;
              add("SECRET_VIA_FILE", "INFO", n, "Secret supplied through a file reference — key " + key,
                "Good pattern. Keep the file itself out of the repo and readable only by the service.", { key: key });
            } else if (val.charAt(0) === "$" || val.indexOf("${") === 0 || val.charAt(0) === "<" || val.charAt(0) === "/") {
              sawPasswordPosture = true;
              add("SECRET_VIA_REFERENCE", "INFO", n, "Secret supplied by reference, not in plaintext — key " + key,
                "Good pattern. Make sure the referenced variable or file is set outside the committed config.", { key: key });
            } else {
              secretValues.push(val);
              if (/PASSWORD|PASSWD/i.test(key)) { sawPasswordPosture = true; }
              add("PLAINTEXT_SECRET", "CRITICAL", n, "Plaintext secret in config — key " + key + ", value length " + val.length + " characters (value not shown)",
                "Move it out of the config text: use a ${...} variable reference or a " + key + "_FILE secret file, and rotate this value — it has been sitting in plaintext.", { key: key, length: val.length });
              if (/PASSWORD|PASSWD/i.test(key) && (WEAK_PASSWORDS.indexOf(val.toLowerCase()) !== -1 || val.length < 12)) {
                add("WEAK_PASSWORD", "CRITICAL", n, "Weak or default admin password posture — key " + key + ", value length " + val.length + " characters (value not shown)",
                  "Use a long, unique password (12+ characters) that is not a default, a dictionary word, or reused anywhere else. Whoever guesses this password owns every container on the host.", { key: key, length: val.length });
              }
            }
          }

          /* --- interface binding --- */
          if (/0\.0\.0\.0/.test(L)) {
            if (exposedBindLine === null) { exposedBindLine = n; }
            add("BIND_ALL_INTERFACES", "CRITICAL", n, "Service bound to all network interfaces (0.0.0.0)",
              "Bind to localhost instead — \"127.0.0.1:5001:5001\" — and reach the UI through a TLS reverse proxy, VPN, or SSH tunnel.", null);
          } else if (/-\s*["']?\d{1,5}:\d{1,5}["']?/.test(L) && L.indexOf("127.0.0.1") === -1 && L.indexOf("localhost") === -1) {
            if (exposedBindLine === null) { exposedBindLine = n; }
            add("EXPOSED_BIND", "HIGH", n, "Published port is reachable on all interfaces",
              "Prefix the mapping with 127.0.0.1 (for example \"127.0.0.1:5001:5001\") so the management UI is not open to the whole network.", null);
          }

          /* --- privileged / host networking --- */
          if (/privileged\s*:\s*true/i.test(L)) {
            add("PRIVILEGED", "CRITICAL", n, "Container runs privileged",
              "Remove privileged: true. Dockge does not need it, and privileged mode hands the container near-total control of the host.", null);
          }
          if (/network_mode\s*:\s*["']?host/i.test(L)) {
            add("HOST_NETWORK", "HIGH", n, "Container shares the host network namespace",
              "Drop network_mode: host and publish only the ports Dockge needs, bound to localhost.", null);
          }

          /* --- docker socket --- */
          if (L.indexOf("/var/run/docker.sock") !== -1) {
            if (/:ro\b/.test(L) || /:ro["']?\s*$/.test(L)) {
              add("DOCKER_SOCKET_RO", "LOW", n, "Docker socket mounted read-only",
                "Read-only is reduced risk, but the socket can still enumerate the host's containers. Keep the UI localhost-only.", null);
            } else if (localhostBind) {
              add("DOCKER_SOCKET_MITIGATED", "LOW", n, "Docker socket mounted read-write (Dockge needs it) — mitigated by a localhost-only bind",
                "Socket access is effectively root on the host. It is only acceptable here because the UI is bound to localhost; never expose this service directly.", null);
            } else {
              add("DOCKER_SOCKET_EXPOSED", "HIGH", n, "Docker socket mounted read-write while the UI is reachable beyond localhost",
                "The Docker socket is root-equivalent on the host. Bind the UI to 127.0.0.1 and put a TLS proxy or VPN in front of it.", null);
            }
          }

          /* --- host mounts --- */
          if (/-\s*\/\s*:/.test(L)) {
            add("HOST_ROOT_MOUNT", "CRITICAL", n, "Entire host filesystem mounted into the container",
              "Remove this mount. Mount only the specific directories Dockge needs (its data directory and the stacks directory).", null);
          } else if (/-\s*\/(etc|root|home|var)\//.test(L) && L.indexOf("docker.sock") === -1) {
            add("BROAD_HOST_MOUNT", "HIGH", n, "Sensitive host directory mounted into the container",
              "Narrow this mount to the exact directory the service needs, read-only if it never writes there.", null);
          }

          /* --- stacks directory line (severity decided after bind scan) --- */
          if (stacksLine === null && /:\s*\/opt\/stacks/.test(L)) { stacksLine = n; }

          /* --- image pinning --- */
          var im = L.match(/image\s*:\s*["']?([^\s"']+)/i);
          if (im) {
            var ref = im[1];
            var lastSlash = ref.lastIndexOf("/"), lastColon = ref.lastIndexOf(":");
            if (lastColon <= lastSlash || /:latest$/i.test(ref)) {
              add("UNPINNED_IMAGE", "MEDIUM", n, "Image is unpinned or uses the moving \"latest\" tag",
                "Pin an exact version tag so the deployment you audited is the deployment that actually runs.", null);
            }
          }

          /* --- default admin username --- */
          if (/(ADMIN_USER|DOCKGE_USER|USERNAME)\s*[:=]\s*["']?admin\b/i.test(L)) {
            add("DEFAULT_USERNAME", "MEDIUM", n, "Default-style admin username",
              "Pair the strong password with a non-obvious admin username where the setup allows it.", null);
          }
        }

        /* --- plain HTTP on an exposed UI --- */
        if (exposedBindLine !== null && !hasTLS) {
          add("PLAIN_HTTP", "HIGH", exposedBindLine, "Management UI served over plain HTTP on an exposed port",
            "Put Dockge behind a TLS-terminating reverse proxy (HTTPS), or keep it localhost-only and reach it over a VPN or SSH tunnel. Passwords typed into a plain-HTTP page cross the network readable.", null);
        }

        /* --- stacks directory reachable through an exposed UI --- */
        if (stacksLine !== null && exposedBindLine !== null) {
          add("STACKS_EXPOSED", "MEDIUM", stacksLine, "Stacks directory is mounted while the UI is exposed",
            "Anyone who reaches the UI can read and edit every stack's compose files. Bind the UI to localhost and treat the stacks directory as code: back it up and restrict its file permissions.", null);
        }

        /* --- no credential posture visible at all --- */
        if (!sawPasswordPosture) {
          add("NO_PASSWORD_POSTURE", "MEDIUM", null, "No admin credential setting found in the pasted text",
            "The audit cannot confirm how the admin account is protected. If the password is created in the web UI on first run, set a long, unique one immediately — an unclaimed or weak first-run account on an exposed UI is an open door.", null);
        }

        var hasCrit = findings.some(function (f) { return f.severity === "CRITICAL"; });
        var hasFix = findings.some(function (f) { return f.severity === "HIGH" || f.severity === "MEDIUM"; });
        var verdict = hasCrit ? "DO NOT DEPLOY" : (hasFix ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY");
        return finish(verdict, findings, lines.length, secretValues);
      }

      function finish(verdict, findings, lineCount, secretValues) {
        var rank = { CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3, INFO: 4 };
        findings.sort(function (a, b) {
          var la = a.line === null ? 99999 : a.line, lb = b.line === null ? 99999 : b.line;
          if (la !== lb) { return la - lb; }
          return rank[a.severity] - rank[b.severity];
        });
        var counts = { CRITICAL: 0, HIGH: 0, MEDIUM: 0, LOW: 0, INFO: 0 };
        findings.forEach(function (f) { counts[f.severity]++; });
        return { verdict: verdict, findings: findings, counts: counts, lineCount: lineCount, _secrets: secretValues };
      }

      function redact(str, secrets) {
        var out = str;
        (secrets || []).forEach(function (s) {
          if (s && s.length >= 3) { out = out.split(s).join("[redacted]"); }
        });
        return out;
      }

      function buildReport(result) {
        var lines = [];
        lines.push("J-Dawgs Dockge Server Config Safety Auditor™ — Audit Report");
        lines.push("Verdict: " + result.verdict);
        lines.push("Lines audited: " + result.lineCount);
        lines.push("Counts: Critical " + result.counts.CRITICAL + " · High " + result.counts.HIGH + " · Medium " + result.counts.MEDIUM + " · Low " + result.counts.LOW + " · Info " + result.counts.INFO);
        lines.push("");
        lines.push("Findings:");
        if (!result.findings.length) { lines.push("  (none)"); }
        result.findings.forEach(function (f) {
          var where = f.line === null ? "Line — (whole config)" : "Line " + f.line;
          lines.push(where + " [" + f.severity + "] " + f.title);
          lines.push("    Fix: " + f.fix);
        });
        lines.push("");
        lines.push("Note: secrets are reported by key name, line, and value length only — values never appear in this report. Offline text audit only: no server was started and nothing was uploaded.");
        return redact(lines.join("\n"), result._secrets);
      }

      function buildJSON(result) {
        var obj = {
          tool: "J-Dawgs Dockge Server Config Safety Auditor™",
          verdict: result.verdict,
          linesAudited: result.lineCount,
          counts: result.counts,
          findings: result.findings.map(function (f) {
            var o = { code: f.code, severity: f.severity, line: f.line, title: f.title, fix: f.fix };
            if (f.key) { o.key = f.key; }
            if (typeof f.length === "number") { o.valueLength = f.length; }
            return o;
          })
        };
        return redact(JSON.stringify(obj, null, 2), result._secrets);
      }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-dockge-server-config-safety-auditortm',
  name: 'J-Dawgs Dockge Server Config Safety Auditor',
  description: 'Host tools only tell you the server started; ours grades a pasted Dockge compose-manager config offline into one deploy verdict — passwords by key name/line/length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
