'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Metabase Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var RISKY_LINES = [
        "# Metabase config copied from a forum post - never reviewed",
        "MB_DB_TYPE=postgres",
        "MB_DB_CONNECTION_URI=postgres://metabase:Sup3rSecretDbPass@db.internal.example.net:5432/metabase",
        "MB_ENCRYPTION_SECRET_KEY=shortkey",
        "MB_ADMIN_EMAIL=admin@example.com",
        "MB_SITE_URL=http://analytics.example.net",
        "MB_ENABLE_EMBEDDING=true",
        "MB_ANON_TRACKING_ENABLED=true",
        "MB_JETTY_HOST=0.0.0.0",
        "MB_JETTY_PORT=3000",
        "MB_PASSWORD_COMPLEXITY=weak",
        "MB_PASSWORD_LENGTH=6",
        "MB_SESSION_COOKIES=false",
        "MB_EMAIL_SMTP_HOST=smtp.example.net",
        "MB_EMAIL_SMTP_USERNAME=alerts@example.net",
        "MB_EMAIL_SMTP_PASSWORD=PlaintextSmtpPass123",
        "# MB_ENCRYPTION_SECRET_KEY=backupkey-that-is-off",
        "remember to ask Dave about the firewall"
      ];

      var HARDENED_LINES = [
        "# Metabase production config - hardened",
        "MB_DB_TYPE=postgres",
        "MB_DB_HOST=db.internal.example.net",
        "MB_DB_PORT=5432",
        "MB_DB_DBNAME=metabase",
        "MB_DB_USER=metabase_svc",
        "MB_ENCRYPTION_SECRET_KEY=a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4",
        "MB_ADMIN_EMAIL=ops@jdawgsindustries.com",
        "MB_SITE_URL=https://analytics.jdawgsindustries.com",
        "MB_ENABLE_EMBEDDING=false",
        "MB_ANON_TRACKING_ENABLED=false",
        "MB_JETTY_HOST=127.0.0.1",
        "MB_JETTY_PORT=3000",
        "MB_PASSWORD_COMPLEXITY=strong",
        "MB_PASSWORD_LENGTH=14",
        "MB_SESSION_COOKIES=true",
        "MB_EMAIL_SMTP_HOST=smtp.jdawgsindustries.com",
        "MB_EMAIL_SMTP_USERNAME=alerts@jdawgsindustries.com"
      ];

      var EXAMPLE_SECRETS = ["changeme","change-me","change_me","secret","password","passwd",
        "example","your-secret-key","your_secret_key","metabase","default","letmein","1234567890123456"];

      var el = function(id){ return document.getElementById(id); };
      var input = el("configInput");

      function isEnvRef(v){ return v.indexOf("${") !== -1 || v.indexOf("$MB_") === 0; }

      function parseKv(text){
        var m = text.match(/^(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*[:=]\s*(.*?)\s*$/);
        if(!m) return null;
        var rawKey = m[1];
        if(rawKey !== rawKey.toUpperCase()) return null; /* env-style keys are uppercase */
        var value = m[2];
        if(value.length >= 2){
          var first = value.charAt(0), last = value.charAt(value.length-1);
          if((first === '"' && last === '"') || (first === "'" && last === "'")) value = value.slice(1,-1);
        }
        return { key: rawKey, value: value };
      }

      function audit(text){
        var lines = text.replace(/\r\n?/g, "\n").split("\n");
        var findings = [];
        var recognized = 0, activeKeys = {};
        var seenEncryption = false;

        function add(line, severity, key, title, detail){
          findings.push({ line: line, severity: severity, key: key, title: title, detail: detail });
        }

        for(var i = 0; i < lines.length; i++){
          var lineNo = i + 1;
          var raw = lines[i];
          var trimmed = raw.replace(/^\s+|\s+$/g, "");
          if(trimmed === "") continue;

          if(trimmed.charAt(0) === "#"){
            var inner = parseKv(trimmed.slice(1).replace(/^\s+/, ""));
            if(inner){
              add(lineNo, "COMMENTED", inner.key, "Commented out — NOT ACTIVE",
                "This line is commented out, so the setting is not in effect. It is reported for visibility and is never graded as an active setting.");
            } else {
              add(lineNo, "COMMENTED", null, "Comment line — NOT ACTIVE",
                "A comment line. Not a setting; nothing graded.");
            }
            continue;
          }

          var kv = parseKv(trimmed);
          if(!kv){
            add(lineNo, "NOT_PARSED", null, "Line not parsed",
              "This line does not look like KEY=value or KEY: value configuration, so it was skipped. Its contents are not reproduced here.");
            continue;
          }

          recognized++;
          var key = kv.key, value = kv.value;
          activeKeys[key] = true;

          switch(key){
            case "MB_DB_CONNECTION_URI": {
              if(isEnvRef(value)){
                add(lineNo, "INFO", key, "Connection URI comes from a reference",
                  "The value is an environment/secret reference rather than a literal URI, so no embedded credential could be graded.");
                break;
              }
              var m = value.match(/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\/([^@/?#]*)@/);
              if(m && m[1].indexOf(":") !== -1){
                var pw = m[1].slice(m[1].indexOf(":") + 1);
                if(pw.length > 0 && pw !== "***"){
                  add(lineNo, "CRITICAL", key, "Plaintext database password embedded in the connection URI",
                    "The URI carries a literal database password (password length: " + pw.length + " characters; the value is never printed). Anyone who can read this config owns the application database. Move the password into a secret store or separate credential, and rotate the exposed password now.");
                }
              } else {
                add(lineNo, "INFO", key, "No embedded password in the connection URI",
                  "No literal password was found in the URI userinfo. Keep credentials in a secret store rather than in the URI.");
              }
              break;
            }
            case "MB_DB_FILE":
              add(lineNo, "INFO", key, "File-based application database",
                "Metabase is pointed at a local file database. That is the trial-grade default; production deployments should use a dedicated Postgres or MySQL application database.");
              break;
            case "MB_ENCRYPTION_SECRET_KEY": {
              seenEncryption = true;
              var low = value.toLowerCase();
              var isExample = EXAMPLE_SECRETS.indexOf(low) !== -1 || low.indexOf("example") !== -1 ||
                              low.indexOf("changeme") !== -1 || low.indexOf("change-me") !== -1 || low.indexOf("your-") === 0;
              if(value.length === 0){
                add(lineNo, "HIGH", key, "Encryption secret key is set but empty",
                  "An empty key gives no encryption for the database credentials Metabase saves. Set a long random value (16+ characters) and keep it in a secret store.");
              } else if(isExample){
                add(lineNo, "HIGH", key, "Encryption secret key matches an example/placeholder value",
                  "The key matches a known example or placeholder pattern (value length: " + value.length + " characters; the value is never printed). Anyone who has seen the same example can decrypt what Metabase saves. Replace it with a long random value.");
              } else if(value.length < 16){
                add(lineNo, "HIGH", key, "Encryption secret key is too short",
                  "The key is " + value.length + " characters long; Metabase requires at least 16. Use a long random value (32+ characters is a sound target) stored in a secret store.");
              } else {
                add(lineNo, "INFO", key, "Encryption secret key is set",
                  "A key of " + value.length + " characters is configured. Keep it in a secret store — losing it means losing access to the credentials Metabase encrypted with it.");
              }
              break;
            }
            case "MB_ADMIN_EMAIL": {
              var at = value.lastIndexOf("@");
              var domain = at !== -1 ? value.slice(at + 1).toLowerCase() : "";
              if(domain.indexOf("example.") === 0 || value.toLowerCase().indexOf("example.") !== -1){
                add(lineNo, "MEDIUM", key, "Admin email is a default/example address",
                  "The initial admin address uses an example domain, which usually means the first-run admin account was never replaced with a real, monitored mailbox. Set a real admin address and confirm the default account is secured.");
              } else {
                add(lineNo, "INFO", key, "Admin email is a non-example address",
                  "No example/default pattern detected in the admin address.");
              }
              break;
            }
            case "MB_SITE_URL": {
              var sm = value.match(/^(https?):\/\/([^\/:?#]+)/i);
              if(sm){
                var scheme = sm[1].toLowerCase(), host = sm[2].toLowerCase();
                var local = host === "localhost" || host === "127.0.0.1" || host === "[::1]" || host === "::1";
                if(scheme === "http" && !local){
                  add(lineNo, "HIGH", key, "Site URL uses plain http on a non-localhost host",
                    "Sessions and credentials for a publicly addressed Metabase cross the network unencrypted, and Metabase builds links and redirects from this URL. Serve Metabase over https (directly or behind a TLS-terminating proxy) and set MB_SITE_URL to the https address.");
                } else if(scheme === "http" && local){
                  add(lineNo, "INFO", key, "Site URL is http on localhost",
                    "Plain http bound to localhost is a normal local-development posture. Switch to https before exposing it beyond this machine.");
                } else {
                  add(lineNo, "INFO", key, "Site URL uses https",
                    "The configured site URL is encrypted in transit.");
                }
              } else {
                add(lineNo, "LOW", key, "Site URL could not be read as a URL",
                  "MB_SITE_URL should be the full public address of the instance, including the https:// scheme.");
              }
              break;
            }
            case "MB_ENABLE_EMBEDDING": {
              var ev = value.toLowerCase();
              if(ev === "true"){
                add(lineNo, "MEDIUM", key, "Public embedding is enabled",
                  "Embedding lets dashboards and questions be shown on external sites. That widens the exposure of whatever is embedded — enable it only if it is intended, and review which items are publicly embedded.");
              } else if(ev === "false"){
                add(lineNo, "INFO", key, "Embedding is off",
                  "Public embedding is disabled.");
              } else {
                add(lineNo, "LOW", key, "Unrecognized embedding value",
                  "MB_ENABLE_EMBEDDING takes true or false. The value found is not one of those, so the effective posture could not be graded.");
              }
              break;
            }
            case "MB_ANON_TRACKING_ENABLED": {
              var av = value.toLowerCase();
              if(av === "true"){
                add(lineNo, "INFO", key, "Anonymous usage tracking is on",
                  "Metabase will send anonymous usage statistics. That is a privacy posture choice, not a vulnerability — noted so the deployment owns the decision.");
              } else if(av === "false"){
                add(lineNo, "INFO", key, "Anonymous usage tracking is off",
                  "No anonymous usage statistics will be sent.");
              } else {
                add(lineNo, "INFO", key, "Anonymous tracking value noted",
                  "MB_ANON_TRACKING_ENABLED takes true or false; the posture is reported as information only.");
              }
              break;
            }
            case "MB_JETTY_HOST": {
              if(value === "0.0.0.0" || value === "::" || value === "[::]"){
                add(lineNo, "MEDIUM", key, "Web server binds all network interfaces",
                  "MB_JETTY_HOST is set to bind every interface, so Metabase answers on every network the host touches. Bind it to localhost or a private interface and let a reverse proxy face the network, unless broad binding is deliberate and firewalled.");
              } else if(value === "127.0.0.1" || value.toLowerCase() === "localhost" || value === "::1" || value === "[::1]"){
                add(lineNo, "INFO", key, "Web server bound to localhost only",
                  "Metabase answers only on this machine; external access must come through a proxy or tunnel.");
              } else {
                add(lineNo, "INFO", key, "Web server bound to a specific interface",
                  "The bind address is a specific interface rather than all interfaces.");
              }
              break;
            }
            case "MB_JETTY_PORT":
              add(lineNo, "INFO", key, "Jetty port configured: " + value,
                "The embedded web server port is set explicitly. Make sure firewall rules and any reverse proxy agree with it.");
              break;
            case "MB_PASSWORD_COMPLEXITY": {
              var cv = value.toLowerCase();
              if(cv === "weak"){
                add(lineNo, "MEDIUM", key, "Password complexity is set to weak",
                  "Weak complexity lets users pick passwords that fall to guessing quickly. Raise MB_PASSWORD_COMPLEXITY to normal or strong.");
              } else if(cv === "normal"){
                add(lineNo, "INFO", key, "Password complexity is normal",
                  "Normal complexity is the middle setting; strong is the safer posture for an exposed instance.");
              } else if(cv === "strong"){
                add(lineNo, "INFO", key, "Password complexity is strong",
                  "Strong complexity is the safest of Metabase's built-in settings.");
              } else {
                add(lineNo, "LOW", key, "Unrecognized password complexity value",
                  "MB_PASSWORD_COMPLEXITY takes weak, normal, or strong. The value found is none of those, so the posture could not be graded.");
              }
              break;
            }
            case "MB_PASSWORD_LENGTH": {
              var n = parseInt(value, 10);
              if(!isNaN(n) && String(n) === value.replace(/^\+/, "")){
                if(n < 8){
                  add(lineNo, "MEDIUM", key, "Minimum password length is short: " + n,
                    "A minimum length of " + n + " allows passwords that are cheap to brute-force. Set MB_PASSWORD_LENGTH to at least 8 — 12 or more is a sound target — alongside a normal or strong complexity setting.");
                } else {
                  add(lineNo, "INFO", key, "Minimum password length is " + n,
                    "That meets the 8-character floor used by this audit.");
                }
              } else {
                add(lineNo, "LOW", key, "Password length is not a plain number",
                  "MB_PASSWORD_LENGTH should be an integer count of characters.");
              }
              break;
            }
            case "MB_SESSION_COOKIES": {
              var sv = value.toLowerCase();
              if(sv === "false"){
                add(lineNo, "MEDIUM", key, "Secure session cookies are not enforced",
                  "With MB_SESSION_COOKIES off, session cookies are not restricted to secure (https) contexts, so a session can leak over a plain-http request. Serve Metabase over https and turn secure session cookies on.");
              } else if(sv === "true"){
                add(lineNo, "INFO", key, "Secure session cookies are on",
                  "Session cookies are restricted to secure contexts.");
              } else {
                add(lineNo, "LOW", key, "Unrecognized session cookie value",
                  "MB_SESSION_COOKIES takes true or false, so the cookie posture could not be graded.");
              }
              break;
            }
            default: {
              if(key.indexOf("PASSWORD") !== -1 && key !== "MB_PASSWORD_COMPLEXITY" && key !== "MB_PASSWORD_LENGTH"){
                if(isEnvRef(value)){
                  add(lineNo, "INFO", key, "Password supplied by reference",
                    "The password value is an environment/secret reference rather than a literal, so nothing plaintext could be graded.");
                } else if(value.length > 0){
                  add(lineNo, "HIGH", key, "Plaintext password stored as a literal value",
                    "This key holds a literal password (value length: " + value.length + " characters; the value is never printed). Config files get copied into tickets, repos, and backups — move the password into a secret store or injected environment variable and rotate it.");
                }
              }
              break;
            }
          }
        }

        if(recognized > 0 && !seenEncryption){
          add(null, "HIGH", "MB_ENCRYPTION_SECRET_KEY", "Encryption secret key is not set",
            "No active MB_ENCRYPTION_SECRET_KEY line was found. Without it, the database credentials Metabase saves are not encrypted at rest. Set a long random key (16+ characters) before deploying. A commented-out key does not count — it is not active.");
        }

        var counts = { CRITICAL:0, HIGH:0, MEDIUM:0, LOW:0, INFO:0, COMMENTED:0, NOT_PARSED:0 };
        for(var j = 0; j < findings.length; j++){
          var s = findings[j].severity;
          if(s === "NOT_PARSED") counts.NOT_PARSED++; else counts[s]++;
        }

        var verdict, why;
        if(recognized === 0){
          verdict = "NOT ENOUGH TO GRADE";
          why = "No recognizable config lines were found. Paste MB_* KEY=value (or KEY: value) lines and audit again.";
        } else if(counts.CRITICAL > 0){
          verdict = "DO NOT DEPLOY";
          why = counts.CRITICAL + " critical finding(s) — a credential or equivalent exposure is live in this config. Fix those lines before this goes anywhere near production.";
        } else if(counts.HIGH > 0 || counts.MEDIUM > 0){
          verdict = "DEPLOY WITH FIXES";
          why = "No critical findings, but " + (counts.HIGH + counts.MEDIUM) + " high/medium finding(s) should be fixed before or immediately after deploy.";
        } else {
          verdict = "SAFE TO DEPLOY";
          why = "No critical, high, or medium findings in the graded settings. Low and info notes above are posture notes, not blockers.";
        }

        return {
          verdict: verdict, why: why, counts: counts, findings: findings,
          linesScanned: lines.length, recognized: recognized
        };
      }

      function esc(s){
        return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
      }

      function sevLabel(s){ return s === "NOT_PARSED" ? "NOT PARSED" : s; }

      function render(result){
        var box = el("verdictBox"), vt = el("verdictText"), vw = el("verdictWhy");
        vt.textContent = result.verdict;
        vw.textContent = result.why;
        box.className = "verdict " + (result.verdict === "SAFE TO DEPLOY" ? "safe" :
          result.verdict === "DEPLOY WITH FIXES" ? "fixes" :
          result.verdict === "DO NOT DEPLOY" ? "no" : "na");

        var order = ["CRITICAL","HIGH","MEDIUM","LOW","INFO","COMMENTED","NOT_PARSED"];
        var html = "";
        for(var k = 0; k < order.length; k++){
          html += '<span class="count">' + sevLabel(order[k]) + ": <b>" + result.counts[order[k]] + "</b></span>";
        }
        html += '<span class="count">Config lines recognized: <b>' + result.recognized + "</b></span>";
        el("countsBox").innerHTML = html;

        var list = el("findingsList");
        if(result.findings.length === 0){
          list.innerHTML = "";
          el("findingsEmpty").style.display = "block";
          el("findingsEmpty").textContent = "The audit ran and produced no findings — there was nothing to grade in the pasted text.";
        } else {
          el("findingsEmpty").style.display = "none";
          var out = "";
          for(var f = 0; f < result.findings.length; f++){
            var fd = result.findings[f];
            out += '<li class="finding"><div class="fhead">' +
              '<span class="badge ' + fd.severity.replace("_","") + '">' + sevLabel(fd.severity) + "</span>" +
              '<span class="fline">' + (fd.line ? "Line " + fd.line : "Whole config") + "</span>" +
              (fd.key ? '<span class="fkey">' + esc(fd.key) + "</span>" : "") +
              '<span class="ftitle">' + esc(fd.title) + "</span></div>" +
              '<div class="fdetail">' + esc(fd.detail) + "</div></li>";
          }
          list.innerHTML = out;
        }

        /* Plain-text report */
        var r = [];
        r.push("J-Dawgs Metabase Server Config Safety Auditor(TM) - Audit Report");
        r.push("Verdict: " + result.verdict);
        r.push("Lines scanned: " + result.linesScanned + " | Config lines recognized: " + result.recognized);
        r.push("Counts: CRITICAL " + result.counts.CRITICAL + " | HIGH " + result.counts.HIGH +
               " | MEDIUM " + result.counts.MEDIUM + " | LOW " + result.counts.LOW +
               " | INFO " + result.counts.INFO + " | COMMENTED " + result.counts.COMMENTED +
               " | NOT PARSED " + result.counts.NOT_PARSED);
        r.push("");
        r.push("Findings:");
        if(result.findings.length === 0){ r.push("(none)"); }
        for(var g = 0; g < result.findings.length; g++){
          var x = result.findings[g];
          r.push("[" + sevLabel(x.severity) + "] " + (x.line ? "Line " + x.line : "Whole config") +
                 (x.key ? " - " + x.key : "") + ": " + x.title);
          r.push("    " + x.detail);
        }
        r.push("");
        r.push("Secret handling: findings name the key, the line, and the value length only. Secret values never appear in this report or the JSON export.");
        r.push("Scope: this grades pasted config text offline in the browser. It does not connect to any server.");
        el("reportOut").value = r.join("\n");

        /* JSON export */
        var payload = {
          tool: "J-Dawgs Metabase Server Config Safety Auditor",
          verdict: result.verdict,
          verdictReason: result.why,
          linesScanned: result.linesScanned,
          configLinesRecognized: result.recognized,
          counts: {
            CRITICAL: result.counts.CRITICAL, HIGH: result.counts.HIGH, MEDIUM: result.counts.MEDIUM,
            LOW: result.counts.LOW, INFO: result.counts.INFO, COMMENTED: result.counts.COMMENTED,
            NOT_PARSED: result.counts.NOT_PARSED
          },
          findings: result.findings.map(function(fd2){
            return { line: fd2.line, severity: sevLabel(fd2.severity), key: fd2.key, title: fd2.title, detail: fd2.detail };
          }),
          secretHandling: "Findings report key name, line, and value length only. Secret values are never included."
        };
        el("jsonOut").value = JSON.stringify(payload, null, 2);
      }

      function runAudit(){ render(audit(input.value)); updateStats(); }

      function updateStats(){
        var n = input.value === "" ? 0 : input.value.replace(/\r\n?/g,"\n").split("\n").length;
        el("inputStats").textContent = n + (n === 1 ? " line" : " lines") + " in the box";
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_SECRETS": (typeof EXAMPLE_SECRETS !== 'undefined' ? EXAMPLE_SECRETS : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-metabase-server-config-safety-auditortm',
  name: 'J-Dawgs Metabase Server Config Safety Auditor',
  description: '',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_SECRETS": __core["EXAMPLE_SECRETS"] }
};
