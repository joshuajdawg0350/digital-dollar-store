'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Authentik Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var RISKY = [
        "# Authentik server - risky example config",
        "AUTHENTIK_SECRET_KEY=short-example-key-123",
        "AUTHENTIK_POSTGRESQL__HOST=postgres",
        "AUTHENTIK_POSTGRESQL__PASSWORD=pgpass123",
        "AUTHENTIK_REDIS__HOST=redis",
        "AUTHENTIK_EMAIL__HOST=smtp.example.com",
        "AUTHENTIK_EMAIL__USE_TLS=false",
        "AUTHENTIK_EMAIL__PORT=587",
        "AUTHENTIK_LISTEN__TRUSTED_PROXY_CIDRS=0.0.0.0/0",
        "AUTHENTIK_BOOTSTRAP_PASSWORD=bootpass99",
        "# AUTHENTIK_SECRET_KEY=old-commented-secret-999",
        "this line is not a config setting at all"
      ].join("\n");

      var HARDENED = [
        "# Authentik server - hardened example config",
        "AUTHENTIK_SECRET_KEY_FILE=/run/secrets/authentik_secret_key",
        "AUTHENTIK_POSTGRESQL__HOST=postgres",
        "AUTHENTIK_POSTGRESQL__PASSWORD_FILE=/run/secrets/pg_password",
        "AUTHENTIK_REDIS__HOST=redis",
        "AUTHENTIK_REDIS__PASSWORD_FILE=/run/secrets/redis_password",
        "AUTHENTIK_EMAIL__HOST=smtp.example.com",
        "AUTHENTIK_EMAIL__USE_TLS=true",
        "AUTHENTIK_EMAIL__PORT=587",
        "AUTHENTIK_LISTEN__TRUSTED_PROXY_CIDRS=172.16.0.0/12",
        "AUTHENTIK_ERROR_REPORTING__ENABLED=false",
        "AUTHENTIK_DISABLE_STARTUP_ANALYTICS=true",
        "AUTHENTIK_DISABLE_PASSWORD_AUTH=true"
      ].join("\n");

      var EXAMPLE_WORDS = ["example","changeme","change-me","change_me","please","insecure","default","password","letmein","admin123"];
      var YAML_HEADS = {secret_key:1, postgresql:1, redis:1, email:1, listen:1, error_reporting:1, tenants:1, geoip:1, avatars:1, bootstrap:1};

      function $(id){ return document.getElementById(id); }
      function esc(s){ return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;"); }
      function cleanValue(v){
        v = String(v == null ? "" : v).trim();
        if (v.length >= 2 && ((v.charAt(0)==='"' && v.charAt(v.length-1)==='"') || (v.charAt(0)==="'" && v.charAt(v.length-1)==="'"))) v = v.slice(1,-1);
        return v.trim();
      }
      function isRef(key, value){
        if (!value) return false;
        if (/_FILE$/.test(key)) return true;
        if (value.indexOf("${") !== -1) return true;
        if (value.indexOf("$(") !== -1) return true;
        if (/^\/run\/secrets\//.test(value) || /^file:\/\//.test(value)) return true;
        return false;
      }
      function hasExampleWord(value){
        var lv = value.toLowerCase();
        for (var i=0;i<EXAMPLE_WORDS.length;i++){ if (lv.indexOf(EXAMPLE_WORDS[i]) !== -1) return true; }
        return false;
      }
      function isLocalHost(v){
        if (!v) return true;
        var h = v.toLowerCase().split(":")[0].split("/")[0];
        if (h === "localhost" || h === "::1" || h === "127.0.0.1") return true;
        if (h.indexOf(".") === -1) return true; /* compose service name */
        if (/\.local$/.test(h) || /\.internal$/.test(h) || /\.lan$/.test(h)) return true;
        if (/^10\./.test(h) || /^192\.168\./.test(h) || /^172\.(1[6-9]|2\d|3[0-1])\./.test(h)) return true;
        return false;
      }
      function isTrue(v){ var s = String(v||"").toLowerCase(); return s==="true"||s==="yes"||s==="1"||s==="on"; }
      function isFalse(v){ var s = String(v||"").toLowerCase(); return s==="false"||s==="no"||s==="0"||s==="off"; }

      /* Normalize a raw key token to a canonical AUTHENTIK_* name, or null if not recognizable. */
      function normalizeKey(rawKey){
        var k = rawKey.trim();
        if (!k) return null;
        if (/^AUTHENTIK_[A-Z0-9_]+$/i.test(k)) return k.toUpperCase();
        var lk = k.toLowerCase();
        if (YAML_HEADS[lk] || lk === "secret_key" || lk === "disable_password_auth" || lk === "disable_startup_analytics" || lk === "disable_update_check"){
          if (lk.indexOf("authentik") !== 0) return ("AUTHENTIK_" + lk.replace(/-/g,"_")).toUpperCase();
          return lk.toUpperCase();
        }
        var head = lk.split("__")[0].split("_")[0];
        if (YAML_HEADS[head] && lk.indexOf("__") !== -1) return ("AUTHENTIK_" + lk.replace(/-/g,"_")).toUpperCase();
        if (/password|secret|token/i.test(k) && /^[A-Za-z][A-Za-z0-9_.\-]*$/.test(k)) return k.toUpperCase();
        return null;
      }
      function extractKeyFromComment(text){
        var m = text.match(/([A-Za-z][A-Za-z0-9_.\-]*)\s*[:=]/);
        if (!m) return null;
        return normalizeKey(m[1]) || (/AUTHENTIK/i.test(m[1]) ? m[1].toUpperCase() : null);
      }

      function audit(text){
        var lines = String(text || "").split(/\r?\n/);
        var entries = {};      /* canonical key -> {line, value, length} (first active occurrence) */
        var order = [];
        var findings = [];     /* {severity, line, key, message, fix} */
        var passes = [];       /* {line, key, message} */
        var commented = [];
        var notParsed = [];
        var recognized = 0;

        function addEntry(key, line, value){
          if (!entries[key]){ entries[key] = { line: line, value: value, length: value.length }; order.push(key); }
        }

        for (var i=0;i<lines.length;i++){
          var lineNo = i+1;
          var raw = lines[i];
          var t = raw.trim();
          if (!t) continue;
          if (t.charAt(0) === "#"){
            var ck = extractKeyFromComment(t.slice(1));
            if (ck) commented.push({ severity:"COMMENTED", line:lineNo, key:ck,
              message:"This line is commented out, so the setting is COMMENTED / NOT ACTIVE. It was not graded as a live setting, and no value is shown.",
              fix:"Leave it commented if it is not in use, or uncomment it deliberately and re-run this audit." });
            continue;
          }
          var body = t.replace(/^-\s+/, "").replace(/^export\s+/, "");
          /* compose port mapping, e.g. "0.0.0.0:9000:9000" */
          var pm = body.match(/["']?((?:\d{1,3}\.){3}\d{1,3})?:?(\d{2,5}):(\d{2,5})["']?/);
          if (pm && (pm[3] === "9000" || pm[3] === "9443") && !/[A-Za-z]{4,}\s*[:=]/.test(body.split(":")[0] + "")){
            recognized++;
            findings.push({ severity:"INFO", line:lineNo, key:"ports (" + pm[3] + ")",
              message:"Port " + pm[3] + " is published" + (pm[1] ? " on " + pm[1] : "") + ". Publishing Authentik's 9000/9443 ports is normal when Authentik sits behind a reverse proxy that terminates TLS and is the only public entry point.",
              fix:"No change needed behind a reverse proxy. If there is no proxy, restrict the binding to localhost or a private interface." });
            continue;
          }
          var kv = body.match(/^([A-Za-z][A-Za-z0-9_.\-]*)\s*[:=]\s*(.*)$/);
          if (!kv){ notParsed.push({ severity:"NOT PARSED", line:lineNo, key:"—",
            message:"This non-empty line was NOT PARSED: it does not match a recognized Authentik setting, so it was not graded. Its content is not reproduced here.",
            fix:"If this line was meant to be a setting, rewrite it as KEY=value (or a YAML key) and re-run the audit." });
            continue; }
          var key = normalizeKey(kv[1]);
          if (!key){ notParsed.push({ severity:"NOT PARSED", line:lineNo, key:"—",
            message:"This non-empty line was NOT PARSED: \"" + esc(kv[1]) + "\" is not a recognized Authentik key, so the line was not graded.",
            fix:"This tool grades the AUTHENTIK_* / authentik key family only. Remove the line or convert it to an Authentik setting." });
            continue; }
          recognized++;
          addEntry(key, lineNo, cleanValue(kv[2]));
        }

        var handled = {};
        function F(sev, line, key, msg, fix){ findings.push({severity:sev, line:line, key:key, message:msg, fix:fix}); }
        function P(line, key, msg){ passes.push({line:line, key:key, message:msg}); }
        function get(k){ return entries[k] || null; }

        if (recognized === 0){
          return { verdict:"NOT ENOUGH TO GRADE", findings:findings.concat(commented, notParsed), passes:passes,
            counts:countAll(findings, commented, notParsed, passes), recognized:0,
            note:"No recognizable Authentik settings were found in the paste. Paste AUTHENTIK_* environment lines, a .env file, or authentik YAML keys and run the audit again." };
        }

        /* ---- Secret key ---- */
        var sk = get("AUTHENTIK_SECRET_KEY"), skf = get("AUTHENTIK_SECRET_KEY_FILE");
        if (skf){ handled["AUTHENTIK_SECRET_KEY_FILE"]=1; P(skf.line, "AUTHENTIK_SECRET_KEY_FILE", "Secret key is supplied through a file reference (line " + skf.line + "), not plaintext in the config."); }
        if (sk){
          handled["AUTHENTIK_SECRET_KEY"]=1;
          if (isRef(sk.key || "AUTHENTIK_SECRET_KEY", sk.value) || isRef("AUTHENTIK_SECRET_KEY", sk.value)){
            P(sk.line, "AUTHENTIK_SECRET_KEY", "Secret key is supplied as an environment/file reference, not plaintext (line " + sk.line + ").");
          } else if (sk.length === 0){
            F("BLOCKER", sk.line, "AUTHENTIK_SECRET_KEY", "AUTHENTIK_SECRET_KEY is present but empty (length 0). Authentik cannot run securely without a secret key.", "Set AUTHENTIK_SECRET_KEY to a randomly generated value of at least 50 characters, or supply it via AUTHENTIK_SECRET_KEY_FILE.");
          } else if (hasExampleWord(sk.value) || sk.length < 50){
            F("BLOCKER", sk.line, "AUTHENTIK_SECRET_KEY", "AUTHENTIK_SECRET_KEY is too weak: the value on line " + sk.line + " is " + sk.length + " characters long" + (hasExampleWord(sk.value) ? " and matches a documented example / placeholder pattern" : "") + ". Authentik requires a fixed random string of at least 50 characters; the value itself is never shown here.", "Generate a fresh random secret of at least 50 characters (for example with a password generator or openssl rand) and set it, or supply it via AUTHENTIK_SECRET_KEY_FILE.");
          } else {
            P(sk.line, "AUTHENTIK_SECRET_KEY", "Secret key present at line " + sk.line + " with length " + sk.length + " (50+ characters). Length only was checked; randomness cannot be verified from text.");
          }
        } else if (!skf){
          F("BLOCKER", null, "AUTHENTIK_SECRET_KEY", "AUTHENTIK_SECRET_KEY is missing from this recognizable Authentik config. Without it, Authentik falls back to an insecure or non-persistent key and sessions/tokens are not safe.", "Set AUTHENTIK_SECRET_KEY to a randomly generated value of at least 50 characters, or supply it via AUTHENTIK_SECRET_KEY_FILE, before deploying.");
        }

        /* ---- PostgreSQL ---- */
        var pgPass = get("AUTHENTIK_POSTGRESQL__PASSWORD"), pgPassF = get("AUTHENTIK_POSTGRESQL__PASSWORD_FILE");
        if (pgPassF){ handled["AUTHENTIK_POSTGRESQL__PASSWORD_FILE"]=1; P(pgPassF.line, "AUTHENTIK_POSTGRESQL__PASSWORD_FILE", "PostgreSQL password is supplied through a file reference (line " + pgPassF.line + "), not plaintext."); }
        if (pgPass){
          handled["AUTHENTIK_POSTGRESQL__PASSWORD"]=1;
          if (isRef("AUTHENTIK_POSTGRESQL__PASSWORD", pgPass.value)){
            P(pgPass.line, "AUTHENTIK_POSTGRESQL__PASSWORD", "PostgreSQL password is supplied as a reference, not plaintext (line " + pgPass.line + ").");
          } else if (pgPass.length < 16 || hasExampleWord(pgPass.value)){
            F("HIGH", pgPass.line, "AUTHENTIK_POSTGRESQL__PASSWORD", "PostgreSQL password is stored in plaintext and is weak: line " + pgPass.line + ", length " + pgPass.length + (hasExampleWord(pgPass.value) ? ", matching an example / placeholder pattern" : "") + ". The value itself is never shown here.", "Use a long random database password and supply it via AUTHENTIK_POSTGRESQL__PASSWORD_FILE or a secrets manager instead of plaintext.");
          } else {
            F("WARNING", pgPass.line, "AUTHENTIK_POSTGRESQL__PASSWORD", "PostgreSQL password is stored in plaintext in the config (line " + pgPass.line + ", length " + pgPass.length + "). Anyone who can read this file has the database password; the value itself is never shown here.", "Move it to AUTHENTIK_POSTGRESQL__PASSWORD_FILE or a secrets manager and rotate it if this file was ever shared.");
          }
        }
        var pgHost = get("AUTHENTIK_POSTGRESQL__HOST");
        if (pgHost){
          handled["AUTHENTIK_POSTGRESQL__HOST"]=1;
          var hasSSL = !!(get("AUTHENTIK_POSTGRESQL__SSLMODE") || get("AUTHENTIK_POSTGRESQL__SSL_MODE") || get("AUTHENTIK_POSTGRESQL__SSLROOTCERT") || get("AUTHENTIK_POSTGRESQL__USE_PGDUMP"));
          if (!isLocalHost(pgHost.value) && !hasSSL){
            F("WARNING", pgHost.line, "AUTHENTIK_POSTGRESQL__HOST", "The PostgreSQL host on line " + pgHost.line + " (" + esc(pgHost.value) + ") looks like a public / external host, and no PostgreSQL SSL setting or AUTHENTIK_POSTGRESQL__USE_PGDUMP was found in the paste, so the connection posture cannot be confirmed as encrypted.", "Enable SSL for the PostgreSQL connection (sslmode) when the database is reached over an untrusted network, and confirm backups do not depend on an unencrypted pgdump path.");
          } else if (!isLocalHost(pgHost.value)){
            P(pgHost.line, "AUTHENTIK_POSTGRESQL__HOST", "External PostgreSQL host with an SSL / pgdump-related setting present in the paste.");
          }
        }

        /* ---- disable_password_auth posture (INFO only, never a blocker) ---- */
        var dpa = get("AUTHENTIK_DISABLE_PASSWORD_AUTH") || get("AUTHENTIK_DISABLE_PASSWORD_AUTH".replace("AUTHENTIK_","AUTHENTIK_"));
        if (dpa){ handled["AUTHENTIK_DISABLE_PASSWORD_AUTH"]=1;
          P(dpa.line, "AUTHENTIK_DISABLE_PASSWORD_AUTH", "disable_password_auth posture is set explicitly (line " + dpa.line + ", value: " + (isTrue(dpa.value) ? "true" : isFalse(dpa.value) ? "false" : "custom") + ").");
        } else {
          F("INFO", null, "AUTHENTIK_DISABLE_PASSWORD_AUTH", "AUTHENTIK_DISABLE_PASSWORD_AUTH is not set, so password authentication stays enabled (the default). This is informational only — many deployments keep password auth on and enforce MFA in flows instead.", "No change required. If your identity provider setup is fully federated, consider disabling password auth deliberately and note the decision.");
        }

        /* ---- Redis ---- */
        var rHost = get("AUTHENTIK_REDIS__HOST"), rPass = get("AUTHENTIK_REDIS__PASSWORD"), rPassF = get("AUTHENTIK_REDIS__PASSWORD_FILE");
        if (rPassF){ handled["AUTHENTIK_REDIS__PASSWORD_FILE"]=1; P(rPassF.line, "AUTHENTIK_REDIS__PASSWORD_FILE", "Redis password is supplied through a file reference (line " + rPassF.line + "), not plaintext."); }
        if (rPass){
          handled["AUTHENTIK_REDIS__PASSWORD"]=1;
          if (isRef("AUTHENTIK_REDIS__PASSWORD", rPass.value)){
            P(rPass.line, "AUTHENTIK_REDIS__PASSWORD", "Redis password is supplied as a reference, not plaintext (line " + rPass.line + ").");
          } else if (rPass.length < 16 || hasExampleWord(rPass.value)){
            F("HIGH", rPass.line, "AUTHENTIK_REDIS__PASSWORD", "Redis password is stored in plaintext and is weak: line " + rPass.line + ", length " + rPass.length + ". The value itself is never shown here.", "Use a long random Redis password supplied via AUTHENTIK_REDIS__PASSWORD_FILE or a secrets manager.");
          } else {
            F("WARNING", rPass.line, "AUTHENTIK_REDIS__PASSWORD", "Redis password is stored in plaintext in the config (line " + rPass.line + ", length " + rPass.length + "). The value itself is never shown here.", "Move it to AUTHENTIK_REDIS__PASSWORD_FILE or a secrets manager.");
          }
        } else if (rHost && !isLocalHost(rHost.value)){
          F("HIGH", rHost.line, "AUTHENTIK_REDIS__PASSWORD", "A non-local Redis host is set (line " + rHost.line + ": " + esc(rHost.value) + ") but no AUTHENTIK_REDIS__PASSWORD is present, so Authentik would connect to a remote cache without a password.", "Set AUTHENTIK_REDIS__PASSWORD (preferably via a file reference) or keep Redis on a private/local network only.");
        }
        if (rHost) handled["AUTHENTIK_REDIS__HOST"]=1;

        /* ---- Email ---- */
        var ePass = get("AUTHENTIK_EMAIL__PASSWORD"), ePassF = get("AUTHENTIK_EMAIL__PASSWORD_FILE");
        if (ePassF){ handled["AUTHENTIK_EMAIL__PASSWORD_FILE"]=1; P(ePassF.line, "AUTHENTIK_EMAIL__PASSWORD_FILE", "Email password is supplied through a file reference (line " + ePassF.line + "), not plaintext."); }
        if (ePass){
          handled["AUTHENTIK_EMAIL__PASSWORD"]=1;
          if (isRef("AUTHENTIK_EMAIL__PASSWORD", ePass.value)){
            P(ePass.line, "AUTHENTIK_EMAIL__PASSWORD", "Email password is supplied as a reference, not plaintext (line " + ePass.line + ").");
          } else {
            F("WARNING", ePass.line, "AUTHENTIK_EMAIL__PASSWORD", "Email (SMTP) password is stored in plaintext in the config (line " + ePass.line + ", length " + ePass.length + "). The value itself is never shown here.", "Supply it via AUTHENTIK_EMAIL__PASSWORD_FILE or a secrets manager, and rotate it if this file was shared.");
          }
        }
        var eHost = get("AUTHENTIK_EMAIL__HOST"), eTls = get("AUTHENTIK_EMAIL__USE_TLS"), eSsl = get("AUTHENTIK_EMAIL__USE_SSL"), ePort = get("AUTHENTIK_EMAIL__PORT");
        if (eHost) handled["AUTHENTIK_EMAIL__HOST"]=1;
        if (eTls){
          handled["AUTHENTIK_EMAIL__USE_TLS"]=1;
          if (isFalse(eTls.value) && eHost && !isLocalHost(eHost.value)){
            F("WARNING", eTls.line, "AUTHENTIK_EMAIL__USE_TLS", "AUTHENTIK_EMAIL__USE_TLS is false on line " + eTls.line + " while the mail host (" + esc(eHost.value) + ") is external, so SMTP credentials and mail can travel unencrypted.", "Set AUTHENTIK_EMAIL__USE_TLS=true (typically port 587) or AUTHENTIK_EMAIL__USE_SSL=true (port 465) for an external mail host.");
          } else if (isTrue(eTls.value)){
            P(eTls.line, "AUTHENTIK_EMAIL__USE_TLS", "Email TLS is enabled (line " + eTls.line + ").");
          }
        }
        if (eSsl) handled["AUTHENTIK_EMAIL__USE_SSL"]=1;
        if (ePort){
          handled["AUTHENTIK_EMAIL__PORT"]=1;
          if (String(ePort.value).trim() === "25"){
            F("WARNING", ePort.line, "AUTHENTIK_EMAIL__PORT", "The email port on line " + ePort.line + " is 25, the plain SMTP port, which is commonly unencrypted and often blocked by providers.", "Use port 587 with TLS or 465 with SSL for an external mail host.");
          }
        }

        /* ---- Listen / exposure ---- */
        ["AUTHENTIK_LISTEN__HTTP","AUTHENTIK_LISTEN__HTTPS"].forEach(function(k){
          var e = get(k);
          if (e){ handled[k]=1;
            F("INFO", e.line, k, k + " is set (line " + e.line + ": " + esc(e.value) + "). Binding Authentik's HTTP/HTTPS listeners is normal when Authentik sits behind a reverse proxy that is the only public entry point.", "No change needed behind a reverse proxy. If there is no proxy, restrict the binding and put TLS in front of Authentik.");
          }
        });
        var tpc = get("AUTHENTIK_LISTEN__TRUSTED_PROXY_CIDRS");
        if (tpc){
          handled["AUTHENTIK_LISTEN__TRUSTED_PROXY_CIDRS"]=1;
          if (/(^|[\s,\[\]"'])0\.0\.0\.0\/0/.test(tpc.value) || tpc.value.indexOf("::/0") !== -1){
            F("HIGH", tpc.line, "AUTHENTIK_LISTEN__TRUSTED_PROXY_CIDRS", "AUTHENTIK_LISTEN__TRUSTED_PROXY_CIDRS is set to 0.0.0.0/0 on line " + tpc.line + ", which trusts proxy headers (such as X-Forwarded-For) from every address — any client can spoof its IP and forwarded headers.", "Restrict it to the actual reverse proxy's address range only, for example the proxy container network CIDR.");
          } else {
            P(tpc.line, "AUTHENTIK_LISTEN__TRUSTED_PROXY_CIDRS", "Trusted proxy CIDRs are restricted (line " + tpc.line + ": " + esc(tpc.value) + "), not open to 0.0.0.0/0.");
          }
        }
        var err = get("AUTHENTIK_ERROR_REPORTING__ENABLED");
        if (err){
          handled["AUTHENTIK_ERROR_REPORTING__ENABLED"]=1;
          if (isTrue(err.value)){
            F("WARNING", err.line, "AUTHENTIK_ERROR_REPORTING__ENABLED", "Error reporting is enabled on line " + err.line + ", which sends error data to Sentry. That can include deployment details you may not want leaving the server.", "Set AUTHENTIK_ERROR_REPORTING__ENABLED=false unless you deliberately run error reporting.");
          } else {
            P(err.line, "AUTHENTIK_ERROR_REPORTING__ENABLED", "Error reporting is disabled (line " + err.line + "); no error data is sent to Sentry by this setting.");
          }
        }
        var dsa = get("AUTHENTIK_DISABLE_STARTUP_ANALYTICS");
        if (dsa){
          handled["AUTHENTIK_DISABLE_STARTUP_ANALYTICS"]=1;
          F("INFO", dsa.line, "AUTHENTIK_DISABLE_STARTUP_ANALYTICS", "AUTHENTIK_DISABLE_STARTUP_ANALYTICS is set on line " + dsa.line + " (value: " + (isTrue(dsa.value) ? "true — anonymous startup analytics are disabled" : "false — anonymous startup analytics remain on") + "). Noted for awareness; this does not affect the deploy verdict.", "No change required. Set it to true if you want startup analytics off.");
        }

        /* ---- Bootstrap credentials ---- */
        ["AUTHENTIK_BOOTSTRAP_PASSWORD","AUTHENTIK_BOOTSTRAP_TOKEN"].forEach(function(k){
          var e = get(k);
          if (e){ handled[k]=1;
            F("HIGH", e.line, k, k + " is present in the config (line " + e.line + ", length " + e.length + "). Bootstrap credentials create the first admin account/token and must be removed after first setup — left in place, anyone with this file holds a standing way in. The value itself is never shown here.", "Remove " + k + " from the config once the first setup is complete, and rotate it if this file was ever shared.");
          }
          var ef = get(k + "_FILE");
          if (ef){ handled[k+"_FILE"]=1;
            F("HIGH", ef.line, k + "_FILE", k + "_FILE is present (line " + ef.line + "). Even as a file reference, a bootstrap credential must be removed after first setup.", "Remove the bootstrap reference once the first setup is complete.");
          }
        });

        /* ---- Tenants / impersonation / geoip / avatars: INFO when present ---- */
        order.forEach(function(k){
          if (handled[k]) return;
          if (k.indexOf("AUTHENTIK_TENANTS") === 0 || k === "AUTHENTIK_TENANTS__ENABLED" || /TENANT/.test(k)){
            handled[k]=1; var e1 = get(k);
            F("INFO", e1.line, k, k + " is set (line " + e1.line + "). Tenancy settings change how authentik isolates tenants/domains; noted so the deployment choice is deliberate, not graded as a flaw.", "No change required. Confirm the tenancy setup matches how this instance is meant to be hosted.");
          } else if (/IMPERSONAT/.test(k)){
            handled[k]=1; var e2 = get(k);
            F("INFO", e2.line, k, k + " is set (line " + e2.line + "). Impersonation lets privileged users act as another user inside authentik; noted because it widens who can assume an identity, not graded as a flaw by itself.", "No change required. Confirm impersonation is limited to the admins who should have it.");
          } else if (/GEOIP/.test(k)){
            handled[k]=1; var e3 = get(k);
            F("INFO", e3.line, k, k + " is set (line " + e3.line + "). GeoIP settings control IP-location lookups used in policies and events; noted for awareness.", "No change required.");
          } else if (/AVATAR/.test(k)){
            handled[k]=1; var e4 = get(k);
            F("INFO", e4.line, k, k + " is set (line " + e4.line + "). Avatar settings control where user avatars are fetched/stored; noted for awareness.", "No change required.");
          }
        });

        /* ---- Any other password|secret|token key ---- */
        order.forEach(function(k){
          if (handled[k]) return;
          if (/PASSWORD|SECRET|TOKEN/.test(k)){
            handled[k]=1; var e = get(k);
            if (isRef(k, e.value)){
              P(e.line, k, "Supplied as an environment/file reference, not plaintext (line " + e.line + ").");
            } else if (e.length < 16 || hasExampleWord(e.value)){
              F("HIGH", e.line, k, k + " holds a plaintext credential that looks weak: line " + e.line + ", length " + e.length + ". The value itself is never shown here.", "Use a long random value and supply it via a *_FILE reference or a secrets manager.");
            } else {
              F("WARNING", e.line, k, k + " holds a plaintext credential in the config (line " + e.line + ", length " + e.length + "). The value itself is never shown here.", "Move it to a *_FILE reference or a secrets manager.");
            }
          }
        });
        /* remaining recognized keys: mark handled silently (parsed, no finding invented) */
        order.forEach(function(k){ handled[k]=1; });

        var all = findings.concat(commented, notParsed);
        var counts = countAll(findings, commented, notParsed, passes);
        var verdict;
        if (counts.BLOCKER > 0 || counts.HIGH > 0) verdict = "DO NOT DEPLOY";
        else if (counts.WARNING > 0) verdict = "DEPLOY WITH FIXES";
        else verdict = "SAFE TO DEPLOY";
        return { verdict:verdict, findings:all, passes:passes, counts:counts, recognized:recognized, note:null };
      }

      function countAll(findings, commented, notParsed, passes){
        var c = { BLOCKER:0, HIGH:0, WARNING:0, INFO:0, COMMENTED:commented.length, NOT_PARSED:notParsed.length, PASS:passes.length };
        findings.forEach(function(f){ if (c.hasOwnProperty(f.severity)) c[f.severity]++; });
        return c;
      }

      function lineLabel(l){ return (l === null || l === undefined) ? "Line — (missing)" : "Line " + l; }

      function buildReport(r){
        var L = [];
        L.push("J-Dawgs Authentik Server Config Safety Auditor(TM)");
        L.push("Verdict: " + r.verdict);
        if (r.note) L.push("Note: " + r.note);
        L.push("Counts: BLOCKER " + r.counts.BLOCKER + " | HIGH " + r.counts.HIGH + " | WARNING " + r.counts.WARNING + " | INFO " + r.counts.INFO + " | COMMENTED " + r.counts.COMMENTED + " | NOT PARSED " + r.counts.NOT_PARSED + " | PASS " + r.counts.PASS);
        L.push("");
        L.push("FINDINGS");
        if (!r.findings.length) L.push("(none)");
        r.findings.forEach(function(f){
          L.push("[" + f.severity + "] " + lineLabel(f.line) + " - " + f.key);
          L.push("  " + f.message);
          L.push("  Fix: " + f.fix);
        });
        L.push("");
        L.push("PASSED CHECKS");
        if (!r.passes.length) L.push("(none)");
        r.passes.forEach(function(p){ L.push("[PASS] " + lineLabel(p.line) + " - " + p.key + ": " + p.message); });
        L.push("");
        L.push("Limits: heuristic text audit of the pasted config only. Secret values are reported by key name, line, and length only - never by value.");
        return L.join("\n");
      }
      function buildJSON(r){
        return JSON.stringify({
          tool: "J-Dawgs Authentik Server Config Safety Auditor",
          verdict: r.verdict,
          note: r.note,
          counts: { BLOCKER:r.counts.BLOCKER, HIGH:r.counts.HIGH, WARNING:r.counts.WARNING, INFO:r.counts.INFO, COMMENTED:r.counts.COMMENTED, NOT_PARSED:r.counts.NOT_PARSED, PASS:r.counts.PASS },
          findings: r.findings.map(function(f){ return { severity:f.severity, line:(f.line == null ? null : f.line), key:f.key, explanation:f.message, fix:f.fix }; }),
          passes: r.passes.map(function(p){ return { line:(p.line == null ? null : p.line), key:p.key, note:p.message }; })
        }, null, 2);
      }

      function render(r){
        var v = $("verdict");
        v.className = "show " + (r.verdict === "SAFE TO DEPLOY" ? "v-safe" : r.verdict === "DEPLOY WITH FIXES" ? "v-fixes" : r.verdict === "DO NOT DEPLOY" ? "v-no" : "v-unknown");
        var sub = {
          "SAFE TO DEPLOY":"No BLOCKER or HIGH findings. Review any INFO notes, then deploy.",
          "DEPLOY WITH FIXES":"No BLOCKER or HIGH findings, but WARNING items should be fixed before or right after deploying.",
          "DO NOT DEPLOY":"BLOCKER or HIGH findings are present. Fix them before this config goes live.",
          "NOT ENOUGH TO GRADE":"Nothing gradeable was found in the paste."
        }[r.verdict];
        v.innerHTML = "<h2>" + esc(r.verdict) + "</h2><p>" + esc(r.note || sub) + "</p>" +
          '<div class="counts"><span>BLOCKER: ' + r.counts.BLOCKER + '</span><span>HIGH: ' + r.counts.HIGH + '</span><span>WARNING: ' + r.counts.WARNING + '</span><span>INFO: ' + r.counts.INFO + '</span><span>COMMENTED: ' + r.counts.COMMENTED + '</span><span>NOT PARSED: ' + r.counts.NOT_PARSED + '</span><span>PASS: ' + r.counts.PASS + "</span></div>";
        var fh = "";
        if (!r.findings.length) fh = '<div class="empty-note">No findings.</div>';
        r.findings.forEach(function(f){
          var sevClass = f.severity === "NOT PARSED" ? "NOTPARSED" : f.severity;
          var sevLabel = f.severity === "COMMENTED" ? "COMMENTED / NOT ACTIVE" : f.severity;
          fh += '<div class="finding"><div class="meta"><span class="sev sev-' + sevClass + '">' + esc(sevLabel) + '</span><span class="lineno">' + esc(lineLabel(f.line)) + '</span><span class="keyname">' + esc(f.key) + "</span></div><p>" + esc(f.message) + '</p><p class="fix"><strong>Fix:</strong> ' + esc(f.fix) + "</p></div>";
        });
        $("findings").innerHTML = fh;
        var ph = "";
        if (!r.passes.length) ph = '<div class="empty-note">No passed checks to list.</div>';
        r.passes.forEach(function(p){
          ph += '<div class="passitem"><span class="keyname">PASS · ' + esc(p.key) + '</span> <span class="lineno">' + esc(lineLabel(p.line)) + "</span><br>" + esc(p.message) + "</div>";
        });
        $("passes").innerHTML = ph;
        $("report").value = buildReport(r);
        $("json").value = buildJSON(r);
        $("results").hidden = false;
      }

      function run(){ render(audit($("input").value)); }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_WORDS": (typeof EXAMPLE_WORDS !== 'undefined' ? EXAMPLE_WORDS : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-authentik-server-config-safety-auditor',
  name: 'J-Dawgs Authentik Server Config Safety Auditor',
  description: 'Grades a pasted Authentik config fully offline into one deploy verdict — SAFE TO DEPLOY / DEPLOY WITH FIXES / DO NOT DEPLOY / NOT ENOUGH TO GRADE — AUTHENTIK_SECRET_KEY posture, plaintext postgres, redis, and bootstrap credentials, and trusted proxy CIDRs, with secrets shown by key name, line, and l',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_WORDS": __core["EXAMPLE_WORDS"] }
};
