'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Concrete Proposal, Work Record & Final Invoice Consistency Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";
/* ---------- Example document sets ---------- */
var EXAMPLE_BAD = {
proposal:
"PROPOSAL / ESTIMATE - J-Dawgs Concrete\n" +
"Project: Driveway replacement, 123 Oak Street\n" +
"Area: 800 sq ft\n" +
"Thickness: 4 in\n" +
"Mix: 4000 PSI air-entrained with fiber mesh\n" +
"Concrete: 10.5 cu yd @ $185.00 = $1,942.50\n" +
"Labor: 16 h @ $65.00 = $1,040.00\n" +
"Proposal total: $2,982.50\n" +
"Deposit required: $1,000.00",
record:
"WORK RECORD - delivery tickets & placement log summary\n" +
"Area: 800 sq ft\n" +
"Thickness: 4 in\n" +
"Mix: 4000 PSI air-entrained with fiber mesh\n" +
"Concrete delivered: 10.5 cu yd\n" +
"Waste allowance: 5%\n" +
"Hours worked: 16 h\n" +
"Labor rate: $65.00 per hour\n" +
"Deposit paid: $1,000.00",
invoice:
"FINAL INVOICE #1042\n" +
"Mix: 3000 PSI standard\n" +
"Concrete: 14 cu yd @ $185.00 = $2,590.00\n" +
"Labor: $1,400.00\n" +
"Expedited cleanup fee: $350.00\n" +
"Total: $4,590.00"
};
var EXAMPLE_GOOD = {
proposal:
"PROPOSAL / ESTIMATE - J-Dawgs Concrete\n" +
"Project: Driveway replacement, 123 Oak Street\n" +
"Area: 800 sq ft\n" +
"Thickness: 4 in\n" +
"Mix: 4000 PSI air-entrained with fiber mesh\n" +
"Concrete: 10.5 cu yd @ $185.00 = $1,942.50\n" +
"Labor: 16 h @ $65.00 = $1,040.00\n" +
"Subtotal: $2,982.50\n" +
"Deposit due at signing: $1,000.00\n" +
"Total due on completion: $1,982.50",
record:
"WORK RECORD - delivery tickets & placement log summary\n" +
"Area: 800 sq ft\n" +
"Thickness: 4 in\n" +
"Mix: 4000 PSI air-entrained with fiber mesh\n" +
"Concrete delivered: 10.5 cu yd\n" +
"Waste allowance: 10%\n" +
"Hours worked: 16 h\n" +
"Labor rate: $65.00 per hour\n" +
"Deposit paid: $1,000.00",
invoice:
"FINAL INVOICE #1042\n" +
"Mix: 4000 PSI air-entrained with fiber mesh\n" +
"Concrete: 10.5 cu yd @ $185.00 = $1,942.50\n" +
"Labor: 16 h @ $65.00 = $1,040.00\n" +
"Deposit credit: -$1,000.00\n" +
"Total due: $1,982.50"
};
var PITCHES = {
pitch1: "Cross-check a concrete job's proposal, work record, and final invoice in the browser - one pay verdict with the arithmetic shown for every figure. AI Tool Store: https://muse.ai/s/ai-tool-store-xng6xkxwjkxl2xab/UoF72OkKI7j33Q2ITxmrZyIr4nv40QtYfj2AgESh_k8",
pitch2: "Find this tool and the rest of the J-Dawgs shelf on the J-Dawgs Agent Exchange: https://muse.ai/s/j-dawgs-agent-exchange-ih6xlnihzxdhxc/ZbleqxFHRE0NcswaBkyN13y9lLp5rPAgHTb6t8ii-PY",
pitch3: "Store It, Stream It, Pour It Right Stack \u2014 Thanos Server Config Safety Auditor + Pulsar Broker Config Safety Auditor + Concrete Proposal, Work Record & Final Invoice Consistency Auditor: grade the metrics store, grade the streaming broker, cross-check the concrete paperwork ($2.75 full pass in the AI Tool Store)."
};

/* ---------- Helpers ---------- */
function $(id){ return document.getElementById(id); }
function num(s){ return parseFloat(String(s).replace(/,/g,"")); }
function fmt$(n){ var neg = n < 0; var v = Math.abs(n).toLocaleString("en-US",{minimumFractionDigits:2,maximumFractionDigits:2}); return (neg?"-$":"$")+v; }
function fmtN(n,d){ return n.toLocaleString("en-US",{minimumFractionDigits:(d==null?2:d),maximumFractionDigits:(d==null?2:d)}); }
function esc(s){ return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"); }

/* ---------- Parsing ---------- */
function toLines(text){
  return String(text||"").split(/\r?\n/).map(function(t,i){ return {no:i+1, text:t}; }).filter(function(L){ return L.text.trim().length>0; });
}
function parseDoc(text){
  var lines = toLines(text);
  var f = { lines:lines, psi:[], totals:[], items:[], signals:0 };
  lines.forEach(function(L){
    var t = L.text, m, pm;
    if(/\$\s*[\d]/.test(t)) f.signals += 1;
    if(!f.area && (m=t.match(/area\s*:\s*([\d,]+(?:\.\d+)?)/i))){ f.area={v:num(m[1]),line:L}; f.signals+=2; }
    if(!f.thickness && (m=t.match(/thickness\s*:\s*([\d.]+)/i))){ f.thickness={v:num(m[1]),line:L}; f.signals+=2; }
    if(!f.waste && (m=t.match(/waste(?:\s+allowance)?\s*:\s*([\d.]+)\s*%/i))){ f.waste={v:num(m[1]),line:L}; f.signals+=2; }
    if(!f.mixLine && /mix\s*:/i.test(t)){ f.mixLine={text:t.split(/mix\s*:/i)[1].trim(), norm:t.split(/mix\s*:/i)[1].trim().toLowerCase().replace(/\s+/g," "), line:L}; f.signals+=2; }
    var psiRe=/(\d{3,5})\s*psi/gi;
    while((pm=psiRe.exec(t))){ f.psi.push({v:parseInt(pm[1],10), line:L}); f.signals+=1; }
    if(!f.yards && (m=t.match(/(?:concrete|yards)[^\n]*?([\d.]+)\s*(?:cu\.?\s*)?yd/i))){
      f.yards={v:num(m[1]), line:L};
      var rm=t.match(/@\s*\$\s*([\d,]+(?:\.\d+)?)/);
      if(rm) f.yards.rate=num(rm[1]);
      f.signals+=2;
    }
    if(!f.hours && (m=t.match(/hours(?:\s+worked)?\s*:\s*([\d.]+)/i))){ f.hours={v:num(m[1]),line:L}; f.signals+=2; }
    if(!f.rate && (m=t.match(/(?:labor\s+)?rate\s*:\s*\$\s*([\d,]+(?:\.\d+)?)/i))){ f.rate={v:num(m[1]),line:L}; f.signals+=2; }
    if((m=t.match(/([\d.]+)\s*h\s*@\s*\$\s*([\d,]+(?:\.\d+)?)/i))){
      if(!f.hours){ f.hours={v:num(m[1]),line:L}; f.signals+=1; }
      if(!f.rate){ f.rate={v:num(m[2]),line:L}; f.signals+=1; }
    }
    if(!f.depositPaid && (m=t.match(/deposit\s+paid\s*:\s*\$\s*([\d,]+(?:\.\d+)?)/i))){ f.depositPaid={v:num(m[1]),line:L}; f.signals+=2; }
    if(/deposit/i.test(t) && (m=t.match(/\$\s*([\d,]+(?:\.\d+)?)/))){ (f.depositLines=f.depositLines||[]).push({v:num(m[1]),line:L}); }
    if(/total/i.test(t) && !/subtotal/i.test(t) && (m=t.match(/\$\s*([\d,]+(?:\.\d+)?)/))){
      f.totals.push({v:num(m[1]), line:L, due:/due/i.test(t)}); f.signals+=1;
    }
    if(/concrete|labor|invoice|proposal|deposit|hours|total/i.test(t)) f.signals+=1;
    /* line item */
    if(!/total/i.test(t) || /credit/i.test(t)){
      var amt=null, neg=false;
      if((m=t.match(/=\s*(-?)\s*\$\s*([\d,]+(?:\.\d+)?)/))){ amt=num(m[2]); if(m[1]==="-") neg=true; }
      else if((m=t.match(/([\d.]+)\s*(?:cu\.?\s*)?yd\s*@\s*\$\s*([\d,]+(?:\.\d+)?)/i))){ amt=num(m[1])*num(m[2]); }
      else if((m=t.match(/([\d.]+)\s*h\s*@\s*\$\s*([\d,]+(?:\.\d+)?)/i))){ amt=num(m[1])*num(m[2]); }
      else if((m=t.match(/\$\s*([\d,]+(?:\.\d+)?)\s*$/))){ amt=num(m[1]); }
      if(amt!==null){
        if(/-\s*\$\s*[\d]/.test(t)) neg=true;
        var lm=t.match(/^([^:$@=]+)/);
        var label=lm?lm[1].replace(/[-–—]\s*$/,"").trim():"";
        if(label && !/^(final invoice|proposal|work record)/i.test(label)){
          f.items.push({label:label, amount:neg?-Math.abs(amt):amt, line:L});
        }
      }
    }
  });
  if(f.totals.length){
    var dues=f.totals.filter(function(x){return x.due;});
    f.total = dues.length?dues[dues.length-1]:f.totals[f.totals.length-1];
  }
  f.usable = f.signals>=3 && lines.length>=1;
  f.laborCharged = f.items.filter(function(it){return /labor/i.test(it.label);}).reduce(function(s,it){return s+it.amount;},0);
  f.hasLabor = f.items.some(function(it){return /labor/i.test(it.label);});
  return f;
}

/* ---------- Audit ---------- */
var DOCNAMES = { proposal:"Proposal", record:"Work Record", invoice:"Final Invoice" };
var lastResult = null;

function audit(){
  var raw = {
    proposal: $("docProposal").value,
    record: $("docRecord").value,
    invoice: $("docInvoice").value
  };
  var d = { proposal:parseDoc(raw.proposal), record:parseDoc(raw.record), invoice:parseDoc(raw.invoice) };
  var findings = [];
  function add(sev,check,title,detail,arith,locs){
    findings.push({severity:sev, check:check, title:title, detail:detail, arithmetic:arith||"", locations:locs||[]});
  }
  function loc(docKey, field){ return field?[{doc:DOCNAMES[docKey], line:field.line.no, text:field.line.text.trim()}]:[]; }

  var usableKeys = ["proposal","record","invoice"].filter(function(k){ return d[k].usable; });
  var missingKeys = ["proposal","record","invoice"].filter(function(k){ return !d[k].usable; });

  if(usableKeys.length < 2){
    var res = { verdict:"NOT ENOUGH TO COMPARE", findings:[], docs:{}, missing:missingKeys.map(function(k){return DOCNAMES[k];}), note:"Fewer than two recognizable documents were pasted." };
    lastResult = { result:res, parsed:d };
    render(res, d);
    return res;
  }

  missingKeys.forEach(function(k){
    add("MISSING","documents","Missing document: "+DOCNAMES[k],
      "No usable "+DOCNAMES[k]+" text was pasted (the box is empty or the text has no recognizable labeled fields or amounts). With a document missing, the verdict is capped at PAY WITH FIXES.",
      "", []);
  });

  var P=d.proposal, R=d.record, I=d.invoice;

  /* (b) mix / PSI identity */
  if(usableKeys.length>=2){
    var psiByDoc = {};
    ["proposal","record","invoice"].forEach(function(k){
      if(d[k].usable && d[k].psi.length) psiByDoc[k]=d[k].psi[0];
    });
    var psiVals = Object.keys(psiByDoc).map(function(k){return psiByDoc[k].v;});
    var distinctPsi = psiVals.filter(function(v,i){return psiVals.indexOf(v)===i;});
    if(Object.keys(psiByDoc).length>=2 && distinctPsi.length>1){
      var locsB=[]; Object.keys(psiByDoc).forEach(function(k){ locsB=locsB.concat(loc(k, psiByDoc[k])); });
      add("BLOCKER","b-mix","Concrete mix / PSI named differently across documents",
        "The documents do not agree on what was specified and billed: "+Object.keys(psiByDoc).map(function(k){return DOCNAMES[k]+" says "+psiByDoc[k].v+" PSI";}).join("; ")+". Do not pay until the mix on the invoice matches the approved proposal and the work record.",
        "", locsB);
    } else {
      var mixDocs = ["proposal","record","invoice"].filter(function(k){ return d[k].usable && d[k].mixLine; });
      var mixNorms = mixDocs.map(function(k){return d[k].mixLine.norm;});
      var distinctMix = mixNorms.filter(function(v,i){return mixNorms.indexOf(v)===i;});
      if(mixDocs.length>=2 && distinctMix.length>1){
        var locsB2=[]; mixDocs.forEach(function(k){ locsB2.push({doc:DOCNAMES[k], line:d[k].mixLine.line.no, text:d[k].mixLine.line.text.trim()}); });
        add("BLOCKER","b-mix","Concrete mix named differently across documents",
          "Mix lines differ: "+mixDocs.map(function(k){return DOCNAMES[k]+' "'+d[k].mixLine.text+'"';}).join("; ")+". Do not pay until the documents name the same mix.",
          "", locsB2);
      }
    }
  }

  /* (a) cubic yards billed vs geometry */
  var areaF = (R.usable && R.area)?{f:R.area,k:"record"} : (P.usable && P.area)?{f:P.area,k:"proposal"} : (I.usable && I.area)?{f:I.area,k:"invoice"}:null;
  var thickF = (R.usable && R.thickness)?{f:R.thickness,k:"record"} : (P.usable && P.thickness)?{f:P.thickness,k:"proposal"} : (I.usable && I.thickness)?{f:I.thickness,k:"invoice"}:null;
  if(I.usable && I.yards && areaF && thickF){
    var geom = areaF.f.v * thickF.f.v / 12 / 27;
    var wastePct, wasteNote;
    if(R.usable && R.waste){ wastePct=R.waste.v; wasteNote="stated waste allowance "+fmtN(wastePct,0)+"% from the work record"; }
    else { wastePct=10; wasteNote="no waste allowance stated - default geometry + 10% used"; }
    var allowed = geom * (1 + wastePct/100);
    if(I.yards.v > allowed + 0.01){
      var excess = I.yards.v - allowed;
      var arithA = fmtN(areaF.f.v,0)+" sq ft x "+fmtN(thickF.f.v)+" in / 12 / 27 = "+fmtN(geom)+" cu yd (geometry)\n"+
        "Allowed with waste ("+wasteNote+"): "+fmtN(geom)+" x "+fmtN(1+wastePct/100)+" = "+fmtN(allowed)+" cu yd\n"+
        "Billed on invoice: "+fmtN(I.yards.v)+" cu yd\n"+
        "Excess: "+fmtN(I.yards.v)+" - "+fmtN(allowed)+" = "+fmtN(excess)+" cu yd";
      if(I.yards.rate) arithA += "\nExcess value at "+fmt$(I.yards.rate)+"/cu yd: "+fmtN(excess)+" x "+fmt$(I.yards.rate)+" = "+fmt$(excess*I.yards.rate);
      if(R.usable && R.yards) arithA += "\nWork record delivered: "+fmtN(R.yards.v)+" cu yd";
      add("FIX","a-yards","Cubic yards billed above what the geometry allows",
        "The invoice bills "+fmtN(I.yards.v)+" cu yd, but the placed area and thickness imply only "+fmtN(allowed)+" cu yd including waste. Have the excess removed or justified before paying.",
        arithA, loc("invoice", I.yards).concat(loc(areaF.k, areaF.f)));
    }
  }

  /* (c) labor: recorded hours x rate vs charged */
  var hrsF = (R.usable && R.hours)?{f:R.hours,k:"record"} : (P.usable && P.hours)?{f:P.hours,k:"proposal"}:null;
  var rateF = (R.usable && R.rate)?{f:R.rate,k:"record"} : (P.usable && P.rate)?{f:P.rate,k:"proposal"}:null;
  if(I.usable && I.hasLabor && hrsF && rateF){
    var expected = hrsF.f.v * rateF.f.v;
    if(I.laborCharged > expected + 1){
      var over = I.laborCharged - expected;
      var laborItem = I.items.filter(function(it){return /labor/i.test(it.label);})[0];
      add("FIX","c-labor","Labor charged above recorded hours x rate",
        "The invoice charges "+fmt$(I.laborCharged)+" for labor, but the record supports "+fmt$(expected)+". Overage: "+fmt$(over)+".",
        fmtN(hrsF.f.v)+" h x "+fmt$(rateF.f.v)+" = "+fmt$(expected)+" (recorded)\nInvoice labor charged: "+fmt$(I.laborCharged)+"\nOverage: "+fmt$(I.laborCharged)+" - "+fmt$(expected)+" = "+fmt$(over),
        laborItem?[{doc:"Final Invoice", line:laborItem.line.no, text:laborItem.line.text.trim()}]:[]);
    }
  }

  /* (d) deposit paid but not credited */
  if(R.usable && R.depositPaid && R.depositPaid.v>0 && I.usable){
    var credited = 0, creditLine=null;
    (I.depositLines||[]).forEach(function(x){ credited=Math.max(credited, x.v); creditLine=x; });
    var hasCredit = /deposit/i.test(raw.invoice) && credited>0 && /credit|less|paid|applied|-/i.test(raw.invoice);
    if(!hasCredit || credited < R.depositPaid.v - 0.01){
      var short = R.depositPaid.v - (hasCredit?credited:0);
      add("BLOCKER","d-deposit","Deposit paid but not credited on the invoice",
        "The work record shows a deposit paid of "+fmt$(R.depositPaid.v)+", but the invoice credits only "+fmt$(hasCredit?credited:0)+" of it. Uncredited amount: "+fmt$(short)+". Do not pay until the deposit is credited.",
        "Deposit paid (work record): "+fmt$(R.depositPaid.v)+"\nDeposit credited (invoice): "+fmt$(hasCredit?credited:0)+"\nUncredited: "+fmt$(R.depositPaid.v)+" - "+fmt$(hasCredit?credited:0)+" = "+fmt$(short),
        loc("record", R.depositPaid));
    }
  }

  /* (e) invoice-only charges */
  if(I.usable && (P.usable || R.usable)){
    var hay = ((P.usable?raw.proposal:"")+"\n"+(R.usable?raw.record:"")).toLowerCase();
    var generic = {concrete:1,labor:1,deposit:1,credit:1,total:1,invoice:1,with:1,from:1,charge:1};
    I.items.forEach(function(it){
      if(it.amount<=0) return;
      var words = it.label.toLowerCase().replace(/[^a-z ]/g," ").split(/\s+/).filter(function(w){ return w.length>=4 && !generic[w]; });
      if(!words.length) return;
      var found = words.some(function(w){ return hay.indexOf(w)>=0; });
      if(!found){
        add("FIX","e-invoice-only","Invoice-only charge: "+it.label+" "+fmt$(it.amount),
          "\""+it.label+"\" appears on the invoice at "+fmt$(it.amount)+" but in neither the proposal nor the work record. Ask what it is and where it was agreed before paying it.",
          "", [{doc:"Final Invoice", line:it.line.no, text:it.line.text.trim()}]);
      }
    });
  }

  /* (f) invoice lines re-added vs stated total */
  if(I.usable && I.total && I.items.length){
    var sum = I.items.reduce(function(s,it){return s+it.amount;},0);
    var diff = I.total.v - sum;
    if(Math.abs(diff) > 0.011){
      add("FIX","f-total","Invoice line items do not add up to the stated total",
        "Re-adding the invoice's own line items gives "+fmt$(sum)+", but the invoice states a total of "+fmt$(I.total.v)+". Difference: "+fmt$(Math.abs(diff))+" ("+(diff>0?"stated total is higher":"stated total is lower")+" than the lines support).",
        I.items.map(function(it){return "  "+it.label+": "+fmt$(it.amount);}).join("\n")+"\n  Re-added sum: "+fmt$(sum)+"\n  Stated total: "+fmt$(I.total.v)+"\n  Difference: "+fmt$(Math.abs(diff)),
        loc("invoice", I.total));
    }
  }

  /* (g) proposal total vs invoice total */
  if(P.usable && P.total && I.usable && I.total){
    var delta = I.total.v - P.total.v;
    if(Math.abs(delta) > 0.011){
      var pct = P.total.v!==0 ? (delta/Math.abs(P.total.v)*100) : 0;
      add("FIX","g-delta","Invoice total vs proposal total",
        "The final invoice total is "+fmt$(Math.abs(delta))+" ("+fmtN(Math.abs(pct),2)+"% ) "+(delta>0?"above":"below")+" the approved proposal total.",
        "Proposal total: "+fmt$(P.total.v)+"\nInvoice total: "+fmt$(I.total.v)+"\nDelta: "+fmt$(I.total.v)+" - "+fmt$(P.total.v)+" = "+fmt$(delta)+" ("+(delta>=0?"+":"")+fmtN(pct,2)+"% vs proposal)",
        loc("proposal", P.total).concat(loc("invoice", I.total)));
    }
  }

  var blockers = findings.filter(function(x){return x.severity==="BLOCKER";}).length;
  var verdict;
  if(blockers>0) verdict="DO NOT PAY YET";
  else if(findings.length>0) verdict="PAY WITH FIXES";
  else verdict="SAFE TO PAY";

  var res2 = { verdict:verdict, findings:findings, docs:{proposal:P.usable, record:R.usable, invoice:I.usable}, missing:missingKeys.filter(function(k){return usableKeys.indexOf(k)<0;}).map(function(k){return DOCNAMES[k];}) };
  lastResult = { result:res2, parsed:d };
  render(res2, d);
  return res2;
}

/* ---------- Rendering ---------- */
function render(res, d){
  var vt=$("verdictText"), pill=$("verdictPill"), counts=$("verdictCounts");
  vt.textContent = res.verdict;
  pill.textContent = res.verdict;
  pill.className = "pill " + (res.verdict==="SAFE TO PAY"?"safe":res.verdict==="PAY WITH FIXES"?"fixes":res.verdict==="DO NOT PAY YET"?"donot":"");
  var nb = res.findings.filter(function(x){return x.severity==="BLOCKER";}).length;
  counts.textContent = res.findings.length? (res.findings.length+" finding"+(res.findings.length===1?"":"s")+" · "+nb+" blocker"+(nb===1?"":"s")) : (res.verdict==="SAFE TO PAY"?"0 findings":"");
  ["proposal","record","invoice"].forEach(function(k){
    var cap = k.charAt(0).toUpperCase()+k.slice(1);
    var el = $("meta"+cap);
    if(el) el.textContent = d[k].usable ? ("Recognized · "+d[k].lines.length+" lines") : (d[k].lines.length? "Not recognizable - treated as missing" : "Empty");
  });
  $("findingCount").textContent = res.findings.length? "("+res.findings.length+")":"";
  var box=$("findings");
  if(res.verdict==="NOT ENOUGH TO COMPARE"){
    box.innerHTML = '<div class="clean" style="background:var(--jd-mist)"><strong>Not enough to compare.</strong> Paste at least two recognizable documents - proposal, work record, or final invoice - using the labeled fields above. No verdict is given on fewer than two.</div>';
  } else if(!res.findings.length){
    box.innerHTML = '<div class="clean"><strong>Zero findings.</strong> Yards billed fit the geometry plus waste, the mix matches across documents, labor matches recorded hours x rate, the deposit is credited, every invoice charge appears in the proposal or record, the invoice lines re-add to its stated total, and the invoice total matches the proposal total.</div>';
  } else {
    box.innerHTML = res.findings.map(function(fd){
      var locHtml = fd.locations.map(function(L){ return '<div class="loc">'+esc(L.doc)+' · line '+L.line+': <code>'+esc(L.text)+'</code></div>'; }).join("");
      return '<div class="finding"><span class="sev '+fd.severity.toLowerCase()+'">'+fd.severity+'</span><h3>'+esc(fd.title)+'</h3><p style="margin:.15rem 0">'+esc(fd.detail)+'</p>'+(fd.arithmetic?'<div class="arith">'+esc(fd.arithmetic)+'</div>':"")+locHtml+'</div>';
    }).join("");
  }
  $("reportText").textContent = buildReport(res);
}

function buildReport(res){
  var L=[];
  L.push("J-Dawgs Concrete Proposal, Work Record & Final Invoice Consistency Auditor");
  L.push("Pay verdict: "+res.verdict);
  L.push("Documents compared: "+["proposal","record","invoice"].filter(function(k){return res.docs[k];}).map(function(k){return DOCNAMES[k];}).join(", "));
  if(res.missing && res.missing.length) L.push("Missing: "+res.missing.join(", "));
  L.push("Findings: "+res.findings.length);
  res.findings.forEach(function(fd,i){
    L.push("");
    L.push((i+1)+". ["+fd.severity+"] "+fd.title);
    L.push("   "+fd.detail);
    if(fd.arithmetic) fd.arithmetic.split("\n").forEach(function(a){ L.push("   "+a); });
    fd.locations.forEach(function(x){ L.push("   At: "+x.doc+" line "+x.line+': "'+x.text+'"'); });
  });
  if(res.verdict==="NOT ENOUGH TO COMPARE"){ L.push(""); L.push("Fewer than two recognizable documents were pasted; no cross-check was run."); }
  L.push("");
  L.push("Text cross-check only: verifies no work performed and no actual delivered quantity. Not trade, engineering, or legal advice.");
  return L.join("\n");
}

function buildJson(){
  if(!lastResult) return "{}";
  var res=lastResult.result;
  var out={ tool:"J-Dawgs Concrete Proposal, Work Record & Final Invoice Consistency Auditor", verdict:res.verdict,
    documentsPresent:res.docs, missingDocuments:res.missing||[],
    findings:res.findings.map(function(fd){ return {severity:fd.severity, check:fd.check, title:fd.title, detail:fd.detail, arithmetic:fd.arithmetic, locations:fd.locations}; }) };
  return JSON.stringify(out,null,2);
}
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_BAD": (typeof EXAMPLE_BAD !== 'undefined' ? EXAMPLE_BAD : undefined), "EXAMPLE_GOOD": (typeof EXAMPLE_GOOD !== 'undefined' ? EXAMPLE_GOOD : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-concrete-proposal-work-record-final-invoice-consistency-auditor',
  name: 'J-Dawgs Concrete Proposal, Work Record & Final Invoice Consistency Auditor',
  description: 'Cross-checks a concrete proposal against its work record and final invoice — cubic yards billed vs slab geometry, recorded hours × rate vs labor charged, deposit credit, invoice-only charges, arithmetic shown across all pastes — into one pay verdict. Every other system grades one document alone.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_BAD": __core["EXAMPLE_BAD"], "EXAMPLE_GOOD": __core["EXAMPLE_GOOD"] }
};
