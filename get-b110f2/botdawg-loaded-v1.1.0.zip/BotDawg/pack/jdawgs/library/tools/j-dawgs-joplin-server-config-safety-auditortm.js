'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Joplin Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var RISKY_EXAMPLE = [
        "# Risky worked example - a Joplin Server env with planted problems. Do not deploy.",
        "POSTGRES_PASSWORD=short1",
        "DB_CLIENT=pg",
        "POSTGRES_DB=joplin",
        "APP_BASE_URL=http://notes.example.com",
        "APP_PORT=22300",
        "HOST=0.0.0.0",
        "NODE_ENV=development",
        "DEBUG=true",
        "LOG_LEVEL=debug",
        "MAILER_ENABLED=true",
        "MAILER_HOST=mail.example.com",
        "MAILER_PORT=25",
        "MAILER_SECURE=false",
        "MAILER_USER=joplin@example.com",
        "MAILER_PASSWORD=password123",
        "STORAGE_DRIVER=local"
      ].join("\n");

      var HARDENED_EXAMPLE = [
        "# Hardened worked example - same shape, problems fixed.",
        "POSTGRES_PASSWORD=Xk9$mQ2vLp8!zR4wN7bT",
        "DB_CLIENT=pg",
        "POSTGRES_DB=joplin",
        "APP_BASE_URL=https://notes.dawsonhome.net",
        "APP_PORT=22300",
        "HOST=127.0.0.1",
        "NODE_ENV=production",
        "DEBUG=false",
        "LOG_LEVEL=info",
        "MAILER_ENABLED=true",
        "MAILER_HOST=smtp.dawsonhome.net",
        "MAILER_PORT=465",
        "MAILER_SECURE=true",
        "MAILER_USER=alerts@dawsonhome.net",
        "MAILER_PASSWORD=Tr7!vQ9mZ2xKp4sW8n",
        "STORAGE_DRIVER=local"
      ].join("\n");

      var MISSING_PW_EXAMPLE = [
        "APP_BASE_URL=https://notes.dawsonhome.net",
        "DB_CLIENT=pg",
        "APP_PORT=22300",
        "NODE_ENV=production"
      ].join("\n");

      var PROSE_EXAMPLE = "The quick brown fox jumps over the lazy dog. Remember to water the plants and lock the front door before Friday.";

      var KNOWN_KEYS = {
        POSTGRES_PASSWORD:1, POSTGRES_USER:1, POSTGRES_DB:1, POSTGRES_HOST:1, POSTGRES_PORT:1,
        DB_CLIENT:1, APP_BASE_URL:1, APP_PORT:1, APP_NAME:1, HOST:1, BIND:1, APP_HOST:1, PORT:1,
        NODE_ENV:1, DEBUG:1, LOG_LEVEL:1, STORAGE_DRIVER:1, STORAGE_DRIVER_FALLBACK:1,
        MAILER_ENABLED:1, MAILER_HOST:1, MAILER_PORT:1, MAILER_SECURE:1, MAILER_USER:1,
        MAILER_PASSWORD:1, MAILER_FROM:1, SMTP_HOST:1, SMTP_PORT:1, SMTP_SECURE:1,
        SMTP_USER:1, SMTP_PASSWORD:1, SMTP_ENCRYPTION:1, API_BASE_URL:1, COOKIE_SECURE:1
      };

      var SECRET_KEY_RE = /PASSWORD|PASSWD|SECRET|TOKEN|API_KEY|PRIVATE_KEY|ACCESS_KEY/;
      var WEAK_SECRETS = {
        "password":1, "password123":1, "changeme":1, "change-me":1, "joplin":1, "joplin123":1,
        "postgres":1, "admin":1, "admin123":1, "letmein":1, "123456":1, "12345678":1,
        "qwerty":1, "secret":1, "default":1, "test":1, "test123":1, "example":1
      };
      var PLACEHOLDER_RE = /changeme|change-me|placeholder|your[-_ ]|example|todo|sample|xxx+|\*\*\*|<[^>]*>|insert[-_ ]|replace[-_ ]|default[-_ ]?password/i;
      var EXAMPLE_VALUE_RE = /example\.(com|org|net)|changeme|placeholder|your[-_](domain|host|server|email)|todo|sample[-_ ]?(value|config)/i;
      var TRUTHY_RE = /^(true|1|yes|on)$/i;
      var FALSY_RE = /^(false|0|no|off)$/i;

      function isSecretKey(key){ return SECRET_KEY_RE.test(key); }

      function parseConfig(text){
        var entries = [];
        var rawLines = String(text || "").split(/\r?\n/);
        for (var i = 0; i < rawLines.length; i++){
          var raw = rawLines[i];
          var lineNo = i + 1;
          var trimmed = raw.replace(/^\s+/, "");
          if (!trimmed || trimmed.charAt(0) === "#") continue;
          // Docker compose published-port lines, e.g. - "0.0.0.0:22300:22300"
          if (trimmed.indexOf("0.0.0.0:") !== -1 || trimmed.indexOf("[::]:") !== -1){
            entries.push({ line: lineNo, key: "__PORT_BIND__", value: "0.0.0.0", raw: raw });
            continue;
          }
          var m = trimmed.match(/^(?:-\s*)?(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*[:=]\s*(.*)$/);
          if (!m) continue;
          var key = m[1].toUpperCase();
          var value = m[2].replace(/\s+#.*$/, "").trim();
          if ((value.charAt(0) === '"' && value.charAt(value.length - 1) === '"') ||
              (value.charAt(0) === "'" && value.charAt(value.length - 1) === "'")){
            value = value.slice(1, -1);
          }
          entries.push({ line: lineNo, key: key, value: value, raw: raw });
        }
        return entries;
      }

      function auditConfig(text){
        var entries = parseConfig(text);
        var findings = [];
        function add(line, key, severity, code, message, fix, secretLength){
          var f = { line: line, key: key, severity: severity, code: code, message: message, fix: fix };
          if (typeof secretLength === "number") f.secretLength = secretLength;
          findings.push(f);
        }
        function byKey(k){
          for (var i = 0; i < entries.length; i++){ if (entries[i].key === k) return entries[i]; }
          return null;
        }

        var knownCount = 0;
        var i, e;
        for (i = 0; i < entries.length; i++){ if (KNOWN_KEYS[entries[i].key]) knownCount++; }
        if (knownCount < 2){
          return { verdict: "NOT ENOUGH TO GRADE", findings: [], entries: entries, knownCount: knownCount };
        }

        // --- Database password: missing ---
        var dbPw = byKey("POSTGRES_PASSWORD");
        var dbClient = byKey("DB_CLIENT");
        var usesPostgres = dbClient && /pg|postgres/i.test(dbClient.value);
        if (!dbPw && (usesPostgres || byKey("POSTGRES_USER") || byKey("POSTGRES_DB") || byKey("POSTGRES_HOST"))){
          add(dbClient ? dbClient.line : 0, "POSTGRES_PASSWORD", "CRITICAL", "MISSING_DB_PASSWORD",
            "No POSTGRES_PASSWORD is set, but a Postgres database is configured. The database would run with no password or a container default.",
            "Set POSTGRES_PASSWORD to a unique value of at least 16 characters, stored in a secret manager or a locked-down env file.");
        }

        // --- Database password: short / weak / placeholder (value never reported) ---
        if (dbPw){
          var pwLen = dbPw.value.length;
          if (pwLen === 0){
            add(dbPw.line, "POSTGRES_PASSWORD", "CRITICAL", "MISSING_DB_PASSWORD",
              "POSTGRES_PASSWORD is present but empty (length 0).",
              "Set POSTGRES_PASSWORD to a unique value of at least 16 characters.");
          } else if (WEAK_SECRETS[dbPw.value.toLowerCase()] || PLACEHOLDER_RE.test(dbPw.value)){
            add(dbPw.line, "POSTGRES_PASSWORD", "CRITICAL", "DB_PASSWORD_PLACEHOLDER",
              "POSTGRES_PASSWORD (length " + pwLen + ") matches a well-known example, default, or placeholder password pattern.",
              "Replace it with a unique generated password of at least 16 characters.", pwLen);
          } else if (pwLen < 12){
            add(dbPw.line, "POSTGRES_PASSWORD", "CRITICAL", "DB_PASSWORD_SHORT",
              "POSTGRES_PASSWORD is only " + pwLen + " characters long. Short database passwords fall to guessing and credential-stuffing quickly.",
              "Use a unique generated password of at least 16 characters.", pwLen);
          } else if (pwLen < 16){
            add(dbPw.line, "POSTGRES_PASSWORD", "HIGH", "DB_PASSWORD_SHORT",
              "POSTGRES_PASSWORD is " + pwLen + " characters long - below the 16-character floor this audit recommends for a database password.",
              "Rotate to a unique generated password of at least 16 characters.", pwLen);
          }
        }

        // --- APP_BASE_URL ---
        var baseUrl = byKey("APP_BASE_URL");
        if (!baseUrl){
          add(0, "APP_BASE_URL", "MEDIUM", "MISSING_BASE_URL",
            "APP_BASE_URL is not set. Joplin clients and share links will be built from whatever the server guesses, which breaks sync links behind proxies.",
            "Set APP_BASE_URL to the exact public https address of the server.");
        } else if (/^http:\/\//i.test(baseUrl.value)){
          add(baseUrl.line, "APP_BASE_URL", "CRITICAL", "INSECURE_BASE_URL",
            "APP_BASE_URL uses http:// - logins, session cookies, and synced notes cross the network unencrypted.",
            "Put the server behind https (reverse proxy or TLS) and set APP_BASE_URL to the https address.");
        } else if (!/^https:\/\//i.test(baseUrl.value)){
          add(baseUrl.line, "APP_BASE_URL", "MEDIUM", "BASE_URL_NO_SCHEME",
            "APP_BASE_URL has no https:// scheme, so clients cannot be sure traffic is encrypted.",
            "Set APP_BASE_URL to the full https:// address of the server.");
        }
        if (baseUrl && /localhost|127\.0\.0\.1/i.test(baseUrl.value)){
          add(baseUrl.line, "APP_BASE_URL", "MEDIUM", "BASE_URL_LOCALHOST",
            "APP_BASE_URL points at localhost. Remote Joplin clients will try to sync with themselves and fail.",
            "Set APP_BASE_URL to the public https address clients actually reach.");
        }

        // --- Wildcard / all-interface bind and port exposure ---
        var bindKeys = ["HOST", "BIND", "APP_HOST"];
        for (i = 0; i < entries.length; i++){
          e = entries[i];
          if (e.key === "__PORT_BIND__"){
            add(e.line, "ports", "CRITICAL", "WILDCARD_BIND",
              "A published port is bound to 0.0.0.0 (all interfaces), exposing the service on every network the host touches.",
              "Bind published ports to 127.0.0.1 and reach the server through a reverse proxy, or firewall the port deliberately.");
          } else if (bindKeys.indexOf(e.key) !== -1 && (e.value === "0.0.0.0" || e.value === "::" || e.value === "*" || e.value === "[::]")){
            add(e.line, e.key, "CRITICAL", "WILDCARD_BIND",
              e.key + " is set to a wildcard address, so the server listens on all interfaces - including networks you did not intend to serve.",
              "Bind to 127.0.0.1 behind a reverse proxy, or to one specific internal address, unless a public bind is deliberate and firewalled.");
          }
        }

        // --- Debug / dev flags ---
        var nodeEnv = byKey("NODE_ENV");
        if (nodeEnv && /^(development|dev|debug|test)$/i.test(nodeEnv.value)){
          add(nodeEnv.line, "NODE_ENV", "HIGH", "DEV_MODE",
            "NODE_ENV is set to a development value. Development mode can enable verbose errors, dev tooling, and weaker defaults in production.",
            "Set NODE_ENV=production for any deployed instance.");
        }
        var debug = byKey("DEBUG");
        if (debug && TRUTHY_RE.test(debug.value)){
          add(debug.line, "DEBUG", "HIGH", "DEBUG_ENABLED",
            "DEBUG is switched on. Debug output can leak request details, paths, and config values into logs.",
            "Set DEBUG=false (or remove the line) for deployment.");
        }
        var logLevel = byKey("LOG_LEVEL");
        if (logLevel && /^(debug|trace|silly)$/i.test(logLevel.value)){
          add(logLevel.line, "LOG_LEVEL", "MEDIUM", "DEBUG_LOG_LEVEL",
            "LOG_LEVEL is set to a debug-level value. Debug logs grow fast and often record request and sync details you do not want kept.",
            "Set LOG_LEVEL=info or LOG_LEVEL=warn for deployment.");
        }

        // --- Mailer / SMTP ---
        var mailPw = byKey("MAILER_PASSWORD") || byKey("SMTP_PASSWORD");
        var mailSecure = byKey("MAILER_SECURE") || byKey("SMTP_SECURE");
        var mailPort = byKey("MAILER_PORT") || byKey("SMTP_PORT");
        var smtpEncryption = byKey("SMTP_ENCRYPTION");
        var secureOff = (mailSecure && FALSY_RE.test(mailSecure.value)) ||
                        (smtpEncryption && /^(none|plain|false)$/i.test(smtpEncryption.value));
        var plaintextPort = mailPort && (mailPort.value === "25");
        if (mailPw && mailPw.value.length > 0){
          var mpLen = mailPw.value.length;
          if (secureOff || plaintextPort){
            add(mailPw.line, mailPw.key, "CRITICAL", "PLAINTEXT_SMTP_CREDENTIALS",
              mailPw.key + " (length " + mpLen + ") is present while SMTP transport encryption is off or on the plaintext port 25 - the mail credential crosses the network unencrypted.",
              "Use port 465 with MAILER_SECURE=true (or 587 with STARTTLS required) so the credential never travels in plaintext.", mpLen);
          } else if (!mailSecure && !smtpEncryption){
            add(mailPw.line, mailPw.key, "HIGH", "SMTP_TLS_UNCONFIRMED",
              mailPw.key + " (length " + mpLen + ") is present, but no MAILER_SECURE / SMTP encryption setting confirms TLS - the credential may travel unencrypted.",
              "Set MAILER_SECURE=true with port 465, or require STARTTLS on port 587.", mpLen);
          }
          if (WEAK_SECRETS[mailPw.value.toLowerCase()] || PLACEHOLDER_RE.test(mailPw.value)){
            add(mailPw.line, mailPw.key, "HIGH", "MAILER_CREDENTIAL_WEAK",
              mailPw.key + " (length " + mpLen + ") matches a well-known weak, example, or placeholder password pattern.",
              "Replace it with the real, unique SMTP credential from your mail provider.", mpLen);
          }
        }
        if (mailSecure && FALSY_RE.test(mailSecure.value)){
          add(mailSecure.line, mailSecure.key, "HIGH", "SMTP_NOT_SECURE",
            mailSecure.key + " is off, so SMTP traffic - including any mail credential and message content - is sent unencrypted.",
            "Set " + mailSecure.key + "=true and use port 465, or require STARTTLS on port 587.");
        }
        if (plaintextPort){
          add(mailPort.line, mailPort.key, "MEDIUM", "SMTP_PLAINTEXT_PORT",
            mailPort.key + " is 25, the plaintext SMTP port. Mail sent this way is unencrypted unless STARTTLS is enforced.",
            "Move to port 465 (implicit TLS) or 587 with STARTTLS required.");
        }

        // --- Example / placeholder / default values (non-secret detail only) ---
        for (i = 0; i < entries.length; i++){
          e = entries[i];
          if (e.key === "__PORT_BIND__") continue;
          if (isSecretKey(e.key)) continue; // secret placeholders already graded above, value never shown
          if (EXAMPLE_VALUE_RE.test(e.value)){
            add(e.line, e.key, "MEDIUM", "EXAMPLE_VALUE",
              e.key + " still holds an example or placeholder value. Example values mean the setting was never actually configured for this deployment.",
              "Replace the example value in " + e.key + " with the real value for this server.");
          }
        }

        findings.sort(function(a, b){ return (a.line - b.line) || (a.code < b.code ? -1 : 1); });

        var verdict;
        var hasCrit = findings.some(function(f){ return f.severity === "CRITICAL"; });
        var hasFix = findings.some(function(f){ return f.severity === "HIGH" || f.severity === "MEDIUM"; });
        if (hasCrit) verdict = "DO NOT DEPLOY";
        else if (hasFix) verdict = "DEPLOY WITH FIXES";
        else verdict = "SAFE TO DEPLOY";
        return { verdict: verdict, findings: findings, entries: entries, knownCount: knownCount };
      }

      function countsOf(findings){
        var c = { CRITICAL: 0, HIGH: 0, MEDIUM: 0, INFO: 0 };
        findings.forEach(function(f){ c[f.severity] = (c[f.severity] || 0) + 1; });
        return c;
      }

      function buildReport(result){
        var lines = [];
        lines.push("J-Dawgs Joplin Server Config Safety Auditor - Audit Report");
        lines.push("Verdict: " + result.verdict);
        if (result.verdict === "NOT ENOUGH TO GRADE"){
          lines.push("The pasted text did not contain enough recognizable Joplin Server settings to grade.");
        } else {
          var c = countsOf(result.findings);
          lines.push("Findings: " + result.findings.length + " (" + c.CRITICAL + " critical, " + c.HIGH + " high, " + c.MEDIUM + " medium)");
          if (result.findings.length === 0){
            lines.push("No findings. Every checked setting passed.");
          }
          result.findings.forEach(function(f){
            var where = f.line > 0 ? "Line " + f.line : "Line - (setting missing)";
            var lenNote = (typeof f.secretLength === "number") ? " [secret: key + length only, length " + f.secretLength + "]" : "";
            lines.push(where + " [" + f.severity + "] " + f.key + " (" + f.code + "): " + f.message + lenNote);
            lines.push("  Fix: " + f.fix);
          });
        }
        lines.push("Secrets are reported by key name, line, and length only. No secret values appear in this report.");
        lines.push("Offline paste audit only - this report does not start a server, connect to a database, or verify a live deployment.");
        return lines.join("\n");
      }

      function buildJson(result){
        var payload = {
          tool: "J-Dawgs Joplin Server Config Safety Auditor",
          verdict: result.verdict,
          counts: countsOf(result.findings),
          findings: result.findings.map(function(f){
            var o = { line: f.line, key: f.key, severity: f.severity, code: f.code, message: f.message, fix: f.fix };
            if (typeof f.secretLength === "number") o.secretLength = f.secretLength;
            return o;
          }),
          note: "Secrets are reported by key name, line, and length only. No secret values are included."
        };
        return JSON.stringify(payload, null, 2);
      }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined), "MISSING_PW_EXAMPLE": (typeof MISSING_PW_EXAMPLE !== 'undefined' ? MISSING_PW_EXAMPLE : undefined), "PROSE_EXAMPLE": (typeof PROSE_EXAMPLE !== 'undefined' ? PROSE_EXAMPLE : undefined), "EXAMPLE_VALUE_RE": (typeof EXAMPLE_VALUE_RE !== 'undefined' ? EXAMPLE_VALUE_RE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-joplin-server-config-safety-auditortm',
  name: 'J-Dawgs Joplin Server Config Safety Auditor',
  description: 'Host tools only tell you the server started; ours grades a pasted Joplin Server config offline into one deploy verdict — secrets by key name/line/length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"], "MISSING_PW_EXAMPLE": __core["MISSING_PW_EXAMPLE"], "PROSE_EXAMPLE": __core["PROSE_EXAMPLE"], "EXAMPLE_VALUE_RE": __core["EXAMPLE_VALUE_RE"] }
};
