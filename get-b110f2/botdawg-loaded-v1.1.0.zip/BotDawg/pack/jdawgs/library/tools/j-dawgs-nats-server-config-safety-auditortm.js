'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs NATS Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

/* ---------- worked examples ---------- */
var RISKY = [
"# Risky NATS server config - worked example",
"# (every line below is a real habit that gets servers hurt)",
"server_name: edge-prod-1",
"listen: 0.0.0.0:4222",
"monitor_port: 8222",
"http_host: 0.0.0.0",
"",
"no_authorization: true",
"",
"jetstream {",
"  store_dir: \"/data/jetstream\"",
"}",
"",
"authorization {",
"  token: \"plain-text-token-in-the-file\"",
"}",
"",
"max_connections: 1024",
"max_connections: 2048",
"debug: true",
""
].join("\n");

var HARDENED = [
"# Hardened NATS server config - worked example",
"server_name: edge-prod-1",
"listen: 10.0.4.12:4222",
"",
"http_host: 127.0.0.1",
"monitor_port: 8222",
"",
"tls {",
"  cert_file: \"/etc/nats/tls/server-cert.pem\"",
"  key_file: \"/etc/nats/tls/server-key.pem\"",
"  ca_file: \"/etc/nats/tls/ca.pem\"",
"  verify: true",
"}",
"",
"authorization {",
"  users: [",
"    {",
"      user: \"app-writer\"",
"      password: \"$2a$11$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy\"",
"      permissions: {",
"        publish: \"events.ingest.>\"",
"        subscribe: \"events.ack.>\"",
"      }",
"    }",
"  ]",
"}",
"",
"jetstream {",
"  store_dir: \"/data/jetstream\"",
"  max_memory_store: 1GB",
"  max_file_store: 10GB",
"}",
"",
"max_payload: 1MB",
"max_connections: 1024",
""
].join("\n");

/* ---------- helpers ---------- */
function $(id){ return document.getElementById(id); }
function stripQuotes(v){ v=(v||"").trim(); if(v.length>=2 && ((v[0]==='"'&&v[v.length-1]==='"')||(v[0]==="'"&&v[v.length-1]==="'"))) return v.slice(1,-1); return v; }
function isSecretKey(k){ return /^(password|passwd|pass|token|auth_token|secret|api_key|apikey|private_key)$/i.test(k) || /password|passwd|token|secret/i.test(k); }
function stripComment(line){
  var q=null;
  for(var i=0;i<line.length;i++){
    var c=line[i];
    if(q){ if(c===q) q=null; continue; }
    if(c==='"'||c==="'"){ q=c; continue; }
    if(c==="#") return line.slice(0,i);
    if(c==="/" && line[i+1]==="/") return line.slice(0,i);
  }
  return line;
}
function countChar(line,ch){
  var q=null,n=0;
  for(var i=0;i<line.length;i++){ var c=line[i];
    if(q){ if(c===q) q=null; continue; }
    if(c==='"'||c==="'"){ q=c; continue; }
    if(c===ch) n++;
  }
  return n;
}

/* ---------- parser ---------- */
function parseConfig(text){
  var lines=text.split(/\r?\n/);
  var assignments=[]; // {key,value,line,pathNames,pathIds}
  var blocks=[];      // {name,line,pathNames,pathIds}
  var stack=[{name:"(root)",id:0,line:0}];
  var nextId=1, arrayDepth=0, error=null;
  var KEYRE=/^([A-Za-z][A-Za-z0-9_.$-]*)\s*[:=]\s*(.*)$/;
  var BLOCKRE=/^([A-Za-z][A-Za-z0-9_.$-]*)\s*[:=]?\s*$/;
  var BAREKEYRE=/^([A-Za-z][A-Za-z0-9_.$-]*)\s+(\S.*)$/;

  function pathNames(extra){ var p=stack.map(function(s){return s.name;}); if(extra)p.push(extra); return p; }
  function pathIds(extra){ var p=stack.map(function(s){return s.id;}); if(extra!=null)p.push(extra); return p; }
  function recordAssign(key,value,line,extraName,extraId){
    assignments.push({key:key.toLowerCase(),rawKey:key,value:stripQuotes(value.replace(/,\s*$/,"")),
      line:line,path:pathNames(extraName),pathIds:pathIds(extraId)});
  }
  function parseInlineAssignments(inner,line,extraName,extraId){
    // split top-level commas
    var parts=[],depth=0,q=null,cur="";
    for(var i=0;i<inner.length;i++){ var c=inner[i];
      if(q){ cur+=c; if(c===q)q=null; continue; }
      if(c==='"'||c==="'"){ q=c; cur+=c; continue; }
      if(c==="{"||c==="[")depth++; if(c==="}"||c==="]")depth--;
      if(c===","&&depth===0){ parts.push(cur); cur=""; continue; }
      cur+=c;
    }
    if(cur.trim())parts.push(cur);
    parts.forEach(function(p){
      var m=p.trim().match(KEYRE);
      if(m) recordAssign(m[1],m[2],line,extraName,extraId);
    });
  }

  for(var ln=0; ln<lines.length && !error; ln++){
    var lineNo=ln+1;
    var clean=stripComment(lines[ln]).trim();
    if(!clean) continue;
    var opens=countChar(clean,"{"), closes=countChar(clean,"}");
    arrayDepth += countChar(clean,"[") - countChar(clean,"]");
    if(arrayDepth<0) arrayDepth=0;

    var firstBrace=clean.indexOf("{"), firstClose=clean.indexOf("}");
    var cut=(firstBrace===-1)?(firstClose===-1?clean.length:firstClose):(firstClose===-1?firstBrace:Math.min(firstBrace,firstClose));
    var head=clean.slice(0,cut).trim();

    if(opens>0 && opens===closes && firstBrace!==-1){
      // inline block on one line, e.g. tls { cert_file: "..." }
      var bm=head.match(BLOCKRE) || head.replace(/[:=]\s*$/,"").match(BLOCKRE);
      var bname=bm?bm[1]:"block";
      var id=nextId++;
      blocks.push({name:bname.toLowerCase(),line:lineNo,path:pathNames(bname),pathIds:pathIds(id)});
      var inner=clean.slice(firstBrace+1, clean.lastIndexOf("}"));
      parseInlineAssignments(inner,lineNo,bname,id);
      continue;
    }

    if(head){
      var am=head.match(KEYRE);
      if(opens>0 && !am){
        var bm2=head.match(BLOCKRE);
        if(!bm2){ error={line:lineNo,text:"Line "+lineNo+" opens a block but does not name it in a way NATS config syntax allows."}; break; }
        var id2=nextId++;
        blocks.push({name:bm2[1].toLowerCase(),line:lineNo,path:pathNames(bm2[1]),pathIds:pathIds(id2)});
        stack.push({name:bm2[1],id:id2,line:lineNo});
        opens--; // consumed by push above
      } else if(am){
        var rest=clean.slice(head.length).trim(); // anything after head (e.g. a closing brace) handled below
        recordAssign(am[1], am[2], lineNo);
      } else if(clean.charAt(0)==="{"){
        var id3=nextId++;
        blocks.push({name:"(entry)",line:lineNo,path:pathNames("(entry)"),pathIds:pathIds(id3)});
        stack.push({name:"(entry)",id:id3,line:lineNo});
        opens--;
      } else if(arrayDepth>0 || /^["'0-9]/.test(clean) || clean.charAt(0)==="}" || clean.charAt(0)==="]"){
        // array element / value continuation / closing punctuation: acceptable
      } else {
        error={line:lineNo,text:"Line "+lineNo+" is not a key, a block, or a value in NATS config syntax: the audit stopped rather than guess."}; break;
      }
    } else if(clean.charAt(0)==="{"){
      var id4=nextId++;
      blocks.push({name:"(entry)",line:lineNo,path:pathNames("(entry)"),pathIds:pathIds(id4)});
      stack.push({name:"(entry)",id:id4,line:lineNo});
      opens--;
    }
    // any remaining opens (nested inline starts) push anonymous blocks
    while(opens>0){ var id5=nextId++; stack.push({name:"(entry)",id:id5,line:lineNo}); opens--; }
    // closes
    while(closes>0){
      if(stack.length<=1){ error={line:lineNo,text:"Line "+lineNo+" closes a block that was never opened — unbalanced braces."}; break; }
      stack.pop(); closes--;
    }
  }
  if(!error && stack.length>1){
    var un=stack[stack.length-1];
    error={line:un.line,text:"The block opened on line "+un.line+" (\""+un.name+"\") is never closed — unbalanced braces."};
  }
  return {lines:lines.length, assignments:assignments, blocks:blocks, error:error};
}

/* ---------- analysis ---------- */
function hostOf(value){
  var v=(value||"").trim();
  v=v.replace(/^(nats|tls|ws|wss|mqtt):\/\//i,"");
  var m=v.match(/^([^:\/\s]+):(\d+)$/);
  if(m) return {host:m[1],port:m[2]};
  if(/^\d+$/.test(v)) return {host:"",port:v};
  return {host:v,port:null};
}
function isAllInterfaces(h){ return h===""||h==="0.0.0.0"||h==="::"||h==="*"; }
function isLocal(h){ return h==="127.0.0.1"||h==="localhost"||h==="::1"; }

function audit(text){
  var parsed=parseConfig(text);
  if(parsed.error) return {notParsed:parsed.error, parsed:parsed};
  var A=parsed.assignments, B=parsed.blocks;
  var findings=[];
  function add(sev,title,line,body,fix){ findings.push({sev:sev,title:title,line:line,body:body,fix:fix||null}); }
  function inPath(a,names){ return names.some(function(n){ return a.path.indexOf(n)!==-1; }); }
  function topLevel(a){ return a.path.length===1; }

  /* --- listeners & exposure --- */
  var clientListen=A.filter(function(a){ return topLevel(a)&&(a.key==="listen"); });
  var rootPort=A.filter(function(a){ return topLevel(a)&&a.key==="port"; });
  var rootHost=A.filter(function(a){ return topLevel(a)&&a.key==="host"; });
  var exposed=false, exposedLine=null, exposedDesc="";
  function considerListener(host,line,what){
    if(isAllInterfaces(host)){ exposed=true; if(exposedLine===null){exposedLine=line;exposedDesc=what+" is bound to all interfaces";} }
    else if(host && !isLocal(host)){ exposed=true; if(exposedLine===null){exposedLine=line;exposedDesc=what+" is bound to a non-local address";} }
  }
  clientListen.forEach(function(a){ var hp=hostOf(a.value); considerListener(hp.host,a.line,"Client listener (line "+a.line+")"); });
  if(!clientListen.length && rootPort.length){
    var hh=rootHost.length?stripQuotes(rootHost[0].value):"";
    considerListener(hh,rootPort[0].line,"Client listener (line "+rootPort[0].line+")");
  }
  ["cluster","gateway","leafnodes"].forEach(function(sec){
    A.filter(function(a){ return a.key==="listen"&&inPath(a,[sec]); }).forEach(function(a){
      var hp=hostOf(a.value); considerListener(hp.host,a.line,sec+" listener (line "+a.line+")");
    });
  });

  /* --- authorization --- */
  var authBlocks=B.filter(function(b){ return b.name==="authorization"; });
  var accountsBlock=B.some(function(b){ return b.name==="accounts"; });
  var authInner=A.filter(function(a){ return inPath(a,["authorization"]); });
  var authMaterial=authInner.filter(function(a){ return ["user","password","token","users","auth_token"].indexOf(a.key)!==-1; });
  var hasAuth=(authBlocks.length&&authMaterial.length>0)||accountsBlock;
  var noAuth=A.filter(function(a){ return a.key==="no_authorization"&&/^(true|yes|on)$/i.test(a.value); });
  var noAuthUser=A.filter(function(a){ return a.key==="no_auth_user"; });

  noAuth.forEach(function(a){
    if(exposed) add("blocker","Authorization switched off on a reachable server",a.line,
      "<span class=\"mono\">no_authorization</span> is set on line "+a.line+" while "+exposedDesc+". Anyone who can reach the port can publish and subscribe — no account, no token, nothing.",
      "Remove <span class=\"mono\">no_authorization</span> and configure an <span class=\"mono\">authorization</span> block with real users or a token before this server is reachable.");
    else add("warning","Authorization switched off",a.line,
      "<span class=\"mono\">no_authorization</span> is set on line "+a.line+". Every listener in this file looks local right now, but the first bind change turns this into an open server.",
      "Drop <span class=\"mono\">no_authorization</span> and add an <span class=\"mono\">authorization</span> block now, while it is still cheap.");
  });
  if(!hasAuth && !noAuth.length){
    if(exposed) add("blocker","No authorization configured — exposed listener",exposedLine,
      "There is no working <span class=\"mono\">authorization</span> block (no users, token, or accounts) anywhere in this file, and "+exposedDesc+". A loading-but-open NATS server lets any reachable client publish, subscribe, and read whatever flows through it.",
      "Add an <span class=\"mono\">authorization</span> block with per-user credentials or an auth token, and scope each user with publish/subscribe permissions.");
    else add("warning","No authorization configured",1,
      "No <span class=\"mono\">authorization</span> block with users or a token was found. That is survivable only while every listener stays on localhost.",
      "Add an <span class=\"mono\">authorization</span> block before this config is reused anywhere near a network.");
  }
  if(authBlocks.length && !authMaterial.length && !accountsBlock){
    add("warning","Authorization block is empty",authBlocks[0].line,
      "An <span class=\"mono\">authorization</span> block opens on line "+authBlocks[0].line+" but defines no users, token, or password — it authorizes nothing.",
      "Put real users (bcrypt-hashed passwords) or a token inside the block, or remove it so the gap is obvious.");
  }
  if(hasAuth && !noAuth.length){
    add("pass","Authorization is configured",authBlocks.length?authBlocks[0].line:1,
      "An <span class=\"mono\">authorization</span> structure with credential material is present"+(authBlocks.length?(" (block opens line "+authBlocks[0].line+")"):"")+".",null);
  }
  noAuthUser.forEach(function(a){
    if(exposed) add("blocker","Unauthenticated user mapping on an exposed server",a.line,
      "<span class=\"mono\">no_auth_user</span> on line "+a.line+" silently logs in every unauthenticated client as a real user, and this server is reachable beyond localhost.",
      "Remove <span class=\"mono\">no_auth_user</span>, or bind every listener to localhost before relying on it.");
    else add("warning","Unauthenticated user mapping set",a.line,
      "<span class=\"mono\">no_auth_user</span> on line "+a.line+" maps unauthenticated clients to a named user.",
      "Keep it only if that user is deliberately powerless — and re-check it the moment a listener leaves localhost.");
  });

  /* --- monitor / http --- */
  var monPorts=A.filter(function(a){ return ["monitor_port","http_port"].indexOf(a.key)!==-1; });
  var httpsPorts=A.filter(function(a){ return a.key==="https_port"; });
  var httpHosts=A.filter(function(a){ return ["http_host","monitor_host","https_host"].indexOf(a.key)!==-1; });
  monPorts.forEach(function(a){
    var host=httpHosts.length?stripQuotes(httpHosts[0].value):null;
    var hline=httpHosts.length?httpHosts[0].line:a.line;
    if(host!==null && isAllInterfaces(host)){
      add("blocker","Monitor / HTTP port bound to all interfaces",hline,
        "The monitoring endpoint is switched on by <span class=\"mono\">"+a.key+"</span> (line "+a.line+") and bound to <span class=\"mono\">0.0.0.0</span> on line "+hline+". NATS monitoring leaks server internals, connection lists, and route detail to anyone who can reach it — it is a recon gift.",
        "Bind it to localhost (<span class=\"mono\">http_host: 127.0.0.1</span>) and reach it over SSH or a private network, or turn the monitor port off.");
    } else if(host===null){
      add("warning","Monitor port on with no bind address",a.line,
        "<span class=\"mono\">"+a.key+"</span> is set on line "+a.line+" but no <span class=\"mono\">http_host</span> restricts where the monitoring endpoint listens, so it follows the server's default bind — assume every interface.",
        "Add <span class=\"mono\">http_host: 127.0.0.1</span> next to the monitor port, or remove the monitor port entirely.");
    } else if(isLocal(host)){
      add("pass","Monitor endpoint bound to localhost",a.line,
        "The monitoring port (line "+a.line+") is pinned to a local address on line "+hline+", where it belongs.",null);
    } else {
      add("warning","Monitor endpoint on a non-local address",hline,
        "The monitoring endpoint is bound to a specific non-local address (line "+hline+"). Monitoring output includes connection and subscription detail.",
        "Move it to localhost, or put it behind authenticated private access only.");
    }
  });
  httpsPorts.forEach(function(a){
    add("info","HTTPS monitor port enabled",a.line,
      "An encrypted monitoring port is configured on line "+a.line+". Confirm its bind address and certificate separately — the bind checks above grade the plain monitor port.",null);
  });
  if(!monPorts.length && !httpsPorts.length){
    add("pass","No monitor port exposed","—","No <span class=\"mono\">monitor_port</span> / <span class=\"mono\">http_port</span> is configured, so the monitoring surface does not exist in this file.",null);
  }

  /* --- TLS --- */
  var tlsBlocks=B.filter(function(b){ return b.name==="tls"&&b.path.length<=2; });
  var tlsInner=A.filter(function(a){ return inPath(a,["tls"]); });
  var tlsCert=tlsInner.filter(function(a){ return a.key==="cert_file"; });
  var tlsKey=tlsInner.filter(function(a){ return a.key==="key_file"; });
  var tlsVerifyFalse=tlsInner.filter(function(a){ return a.key==="verify"&&/^(false|no|off)$/i.test(a.value); });
  var tlsOff=A.filter(function(a){ return topLevel(a)&&a.key==="tls"&&/^(false|no|off|disabled)$/i.test(a.value); });
  if(tlsOff.length){
    add(exposed?"blocker":"warning","TLS explicitly off",tlsOff[0].line,
      "<span class=\"mono\">tls</span> is set off on line "+tlsOff[0].line+". Credentials and message traffic cross the wire in the clear.",
      "Configure a <span class=\"mono\">tls</span> block with <span class=\"mono\">cert_file</span> and <span class=\"mono\">key_file</span>.");
  } else if(!tlsBlocks.length){
    if(exposed) add("blocker","No TLS configured on a reachable server",exposedLine,
      "There is no <span class=\"mono\">tls</span> block in this file, and "+exposedDesc+". Auth tokens, passwords, and every message cross the network unencrypted.",
      "Add a <span class=\"mono\">tls</span> block with <span class=\"mono\">cert_file</span>, <span class=\"mono\">key_file</span>, and <span class=\"mono\">verify: true</span> so clients authenticate the server (and, with a CA, vice versa).");
    else add("warning","No TLS configured",1,
      "No <span class=\"mono\">tls</span> block was found. Acceptable on a throwaway localhost setup; a hole the moment this file is reused on a reachable bind.",
      "Add TLS before this config leaves the local machine.");
  } else {
    if(!tlsCert.length || !tlsKey.length){
      add("warning","TLS block is incomplete",tlsBlocks[0].line,
        "A <span class=\"mono\">tls</span> block opens on line "+tlsBlocks[0].line+" but "+(!tlsCert.length&&!tlsKey.length?"neither <span class=\"mono\">cert_file</span> nor <span class=\"mono\">key_file</span> is set":(!tlsCert.length?"<span class=\"mono\">cert_file</span> is missing":"<span class=\"mono\">key_file</span> is missing"))+" — the server cannot present a certificate as written.",
        "Set both <span class=\"mono\">cert_file</span> and <span class=\"mono\">key_file</span> inside the <span class=\"mono\">tls</span> block.");
    } else {
      add("pass","TLS configured with certificate and key",tlsBlocks[0].line,
        "The <span class=\"mono\">tls</span> block (line "+tlsBlocks[0].line+") sets both a certificate and a key file.",null);
    }
    tlsVerifyFalse.forEach(function(a){
      add("warning","TLS client verification switched off",a.line,
        "<span class=\"mono\">verify</span> is off on line "+a.line+" inside the TLS settings — clients are not asked to prove who they are at the TLS layer.",
        "Set <span class=\"mono\">verify: true</span> with a <span class=\"mono\">ca_file</span> if client certificates are part of your auth story.");
    });
  }

  /* --- JetStream --- */
  var jsBlocks=B.filter(function(b){ return b.name==="jetstream"; });
  var jsAssign=A.filter(function(a){ return topLevel(a)&&a.key==="jetstream"&&/^(true|yes|on|enabled)$/i.test(a.value); });
  var jsEnabled=jsBlocks.length>0||jsAssign.length>0;
  if(jsEnabled){
    var jsLine=jsBlocks.length?jsBlocks[0].line:jsAssign[0].line;
    var limits=A.filter(function(a){ return inPath(a,["jetstream"])&&["max_memory_store","max_file_store"].indexOf(a.key)!==-1; });
    var topLimits=A.filter(function(a){ return topLevel(a)&&["max_memory_store","max_file_store"].indexOf(a.key)!==-1; });
    if(!limits.length && !topLimits.length){
      add("warning","JetStream on with no store limits noted",jsLine,
        "JetStream is enabled (line "+jsLine+") but neither <span class=\"mono\">max_memory_store</span> nor <span class=\"mono\">max_file_store</span> appears anywhere. An unbounded stream or a chatty producer can eat the disk and take the broker — and everything co-hosted — down with it.",
        "Set explicit <span class=\"mono\">max_memory_store</span> and <span class=\"mono\">max_file_store</span> limits sized to the disk you can actually afford to lose.");
    } else {
      add("pass","JetStream store limits noted",jsLine,
        "JetStream is enabled (line "+jsLine+") with store limit(s) recorded on line "+(limits.concat(topLimits).map(function(x){return x.line;}).join(", "))+".",null);
    }
  } else {
    add("info","JetStream not enabled", "—","No JetStream block or enable flag was found, so store-limit checks do not apply to this file.",null);
  }

  /* --- cluster / gateway / leaf extras --- */
  ["cluster","gateway"].forEach(function(sec){
    var secBlocks=B.filter(function(b){ return b.name===sec; });
    if(!secBlocks.length) return;
    var secAuth=B.some(function(b){ return b.name==="authorization"&&b.path.indexOf(sec)!==-1; }) ||
                A.some(function(a){ return inPath(a,[sec])&&["user","password","token"].indexOf(a.key)!==-1; });
    var secTls=B.some(function(b){ return b.name==="tls"&&b.path.indexOf(sec)!==-1; });
    if(!secAuth) add("warning",sec.charAt(0).toUpperCase()+sec.slice(1)+" without its own authorization",secBlocks[0].line,
      "A <span class=\"mono\">"+sec+"</span> block opens on line "+secBlocks[0].line+" with no authorization material inside it. Route and gateway links are the trusted backbone — an unauthenticated one is worse than an unauthenticated client port.",
      "Add authorization (and TLS) inside the <span class=\"mono\">"+sec+"</span> block.");
    if(!secTls) add("info",sec.charAt(0).toUpperCase()+sec.slice(1)+" TLS not configured",secBlocks[0].line,
      "No <span class=\"mono\">tls</span> block was found inside the <span class=\"mono\">"+sec+"</span> section (line "+secBlocks[0].line+"). If those links cross machines you do not fully control, encrypt them.",null);
  });

  /* --- duplicate keys --- */
  var groups={}, order=[];
  A.forEach(function(a){
    var g=a.pathIds.join("/")+"|"+a.key;
    if(!groups[g]){ groups[g]=[]; order.push(g); }
    groups[g].push(a);
  });
  var dupCount=0;
  order.forEach(function(g){
    var list=groups[g];
    if(list.length>1){
      dupCount++;
      var key=list[0].rawKey, lines=list.map(function(x){return x.line;});
      add("warning","Duplicate key: "+key,list[1].line,
        "The key <span class=\"mono\">"+key+"</span> is set "+list.length+" times in the same block (lines "+lines.join(", ")+"). In NATS config the later value quietly wins, so the line someone edits may not be the line that runs.",
        "Delete the stale <span class=\"mono\">"+key+"</span> line(s) and keep exactly one value.");
    }
  });
  if(!dupCount) add("pass","No duplicate keys","—","No key is set twice inside the same block, so what you read is what runs.",null);

  /* --- secrets: key name + line only, values NEVER rendered --- */
  var secrets=A.filter(function(a){ return isSecretKey(a.key); });
  secrets.forEach(function(a){
    var v=a.value||"";
    var bcrypt=/^\$2[aby]\$/.test(v), envRef=/^\$\{?[A-Za-z_][A-Za-z0-9_]*\}?$/.test(v);
    if(bcrypt){
      add("pass","Secret stored as a bcrypt hash: "+a.rawKey,a.line,
        "The <span class=\"mono\">"+a.rawKey+"</span> key on line "+a.line+" holds a bcrypt hash rather than a readable password. (Value not shown, by design.)",null);
    } else if(envRef){
      add("info","Secret pulled from the environment: "+a.rawKey,a.line,
        "The <span class=\"mono\">"+a.rawKey+"</span> key on line "+a.line+" references an environment variable instead of carrying the secret in the file. (Value not shown, by design.)",null);
    } else if(a.key==="credentials"){
      add("info","Credentials file referenced: "+a.rawKey,a.line,
        "The <span class=\"mono\">"+a.rawKey+"</span> key on line "+a.line+" points at a credentials file. Whoever can read that file owns this identity — check its permissions. (Value not shown, by design.)",null);
    } else {
      add("warning","Secret stored as a plain literal: "+a.rawKey,a.line,
        "The <span class=\"mono\">"+a.rawKey+"</span> key on line "+a.line+" carries a readable literal secret in the config file. Anyone who can read the file — backups, repos, screenshots — has it. (Value not shown, by design.)",
        "For passwords, store a bcrypt hash (generate one with <span class=\"mono\">nats-server --gen</span>-era tooling / bcrypt). For tokens, inject via an environment reference and rotate the one that lived in this file.");
    }
  });

  /* --- misc hygiene --- */
  A.filter(function(a){ return (a.key==="debug"||a.key==="trace")&&/^(true|yes|on)$/i.test(a.value); }).forEach(function(a){
    add("warning","Verbose logging left on: "+a.rawKey,a.line,
      "<span class=\"mono\">"+a.rawKey+"</span> is on (line "+a.line+"). Debug/trace logging on a production broker is noisy, slow, and can write message payloads into log files.",
      "Turn <span class=\"mono\">"+a.rawKey+"</span> off for deployment; switch it on temporarily when you actually need it.");
  });
  A.filter(function(a){ return a.key==="include"; }).forEach(function(a){
    add("info","Include directive not followed",a.line,
      "An <span class=\"mono\">include</span> on line "+a.line+" pulls in another file. Included files were not pasted, so nothing in them was audited — grade them separately.",null);
  });

  var sevRank={blocker:0,warning:1,info:2,pass:3};
  findings.sort(function(x,y){ return sevRank[x.sev]-sevRank[y.sev] || (parseInt(x.line,10)||0)-(parseInt(y.line,10)||0); });
  var blockers=findings.filter(function(f){return f.sev==="blocker";}).length;
  var warnings=findings.filter(function(f){return f.sev==="warning";}).length;
  var passes=findings.filter(function(f){return f.sev==="pass";}).length;
  var verdict= blockers>0 ? "DO NOT DEPLOY" : (warnings>0 ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY");
  return {parsed:parsed, findings:findings, secrets:secrets, blockers:blockers, warnings:warnings, passes:passes, verdict:verdict, exposed:exposed};
}

/* ---------- rendering ---------- */
var lastResult=null, lastText="";
function esc(s){ return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;"); }

function render(text){
  lastText=text;
  var banner=$("verdictBanner"), vt=$("verdictText"), vs=$("verdictSub"),
      chips=$("chips"), fbox=$("findings"), sbox=$("secretsBox"), slist=$("secretsList");
  if(!text.trim()){
    banner.className=""; vt.textContent="—"; chips.innerHTML=""; sbox.className="";
    fbox.innerHTML='<p class="empty-note">Paste a server.conf above — or load an example — and the verdict lands here.</p>';
    lastResult=null; return;
  }
  var r=audit(text); lastResult=r;
  banner.classList.add("show");
  if(r.notParsed){
    banner.className="show noparse"; vt.textContent="NOT PARSED";
    vs.textContent=r.notParsed.text+" Fix the syntax, then re-run — a safety grade on a misread file would be a lie.";
    chips.innerHTML='<span class="chip">Lines scanned <b>'+r.parsed.lines+'</b></span><span class="chip">Problem line <b>'+r.notParsed.line+'</b></span>';
    sbox.className=""; fbox.innerHTML="";
    return;
  }
  banner.className="show "+(r.verdict==="DO NOT DEPLOY"?"bad":(r.verdict==="DEPLOY WITH FIXES"?"mid":"good"));
  vt.textContent=r.verdict;
  vs.textContent= r.verdict==="DO NOT DEPLOY"
    ? "Blocker findings below would leave this server open. Fix every blocker, then re-grade."
    : (r.verdict==="DEPLOY WITH FIXES"
      ? "Nothing fatal, but the warnings below are real exposure or real surprises waiting. Fix them, then re-grade."
      : "No blockers, no warnings in the pasted text. Still run nats-server -t and your own review — this is a heuristic audit, not a guarantee.");
  chips.innerHTML=
    '<span class="chip cb">Blockers <b>'+r.blockers+'</b></span>'+
    '<span class="chip cw">Warnings <b>'+r.warnings+'</b></span>'+
    '<span class="chip co">Checks passed <b>'+r.passes+'</b></span>'+
    '<span class="chip">Lines scanned <b>'+r.parsed.lines+'</b></span>'+
    '<span class="chip">Keys read <b>'+r.parsed.assignments.length+'</b></span>'+
    '<span class="chip">Exposure <b>'+(r.exposed?"beyond localhost":"local only / none found")+'</b></span>';
  if(r.secrets.length){
    sbox.classList.add("show");
    slist.innerHTML=r.secrets.map(function(s){
      return "<li>"+esc(s.rawKey)+" — line "+s.line+" (value never shown)</li>";
    }).join("");
  } else sbox.className="";
  fbox.innerHTML=r.findings.map(function(f){
    return '<div class="finding"><div class="fhead"><span class="sev '+f.sev+'">'+f.sev+'</span>'+
      '<span class="ftitle">'+f.title+'</span>'+
      '<span class="fline">'+(f.line==="—"?"no single line":"line "+f.line)+'</span></div>'+
      '<p>'+f.body+'</p>'+(f.fix?'<p class="fix"><strong>Fix:</strong> '+f.fix+'</p>':"")+"</div>";
  }).join("");
}
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-nats-server-config-safety-auditortm',
  name: 'J-Dawgs NATS Server Config Safety Auditor',
  description: 'Grades a pasted NATS server.conf offline — auth posture, monitor/listener exposure, JetStream and TLS — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
