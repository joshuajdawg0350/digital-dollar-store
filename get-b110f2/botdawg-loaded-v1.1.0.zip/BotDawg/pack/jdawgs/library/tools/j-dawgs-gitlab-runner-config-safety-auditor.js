'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs GitLab Runner Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

/*AUDIT-CORE-START*/
var RISKY_EXAMPLE = [
'concurrent = 2',
'check_interval = 0',
'',
'[[runners]]',
'  name = "docker-runner-01"',
'  url = "http://gitlab.example.com"',
'  token = "glrt-EXAMPLEtoken0001abcd"',
'  executor = "docker"',
'  limit = 4',
'  [runners.docker]',
'    tls_verify = false',
'    image = "alpine:latest"',
'    privileged = true',
'    network_mode = "host"',
'    pull_policy = "always"',
'    volumes = ["/cache", "/var/run/docker.sock:/var/run/docker.sock", "/:/host"]',
'  [runners.cache]',
'    Type = "s3"',
'    [runners.cache.s3]',
'      ServerAddress = "http://minio.example.com:9000"'
].join('\n');

var HARDENED_EXAMPLE = [
'concurrent = 4',
'check_interval = 0',
'',
'# token is injected by the secret manager at deploy time - never committed',
'[[runners]]',
'  name = "docker-runner-hardened"',
'  url = "https://gitlab.example.com"',
'  tls-ca-file = "/etc/gitlab-runner/certs/ca.crt"',
'  executor = "docker"',
'  limit = 2',
'  [runners.docker]',
'    tls_verify = true',
'    image = "alpine:3.20.2"',
'    privileged = false',
'    volumes = ["/cache"]',
'    pull_policy = "if-not-present"',
'  [runners.cache]',
'    Type = "s3"',
'    [runners.cache.s3]',
'      ServerAddress = "s3.amazonaws.com"',
'      Insecure = false'
].join('\n');

var SECRET_KEY_RE = /(token|secret|passwd|password|api[_-]?key|access[_-]?key|private[_-]?key|credential|auth[_-]?key)/i;
var HOST_ROOT_RE = /["'](\/|\/etc|\/root|\/proc|\/sys):/;

function parseScalar(raw){
  var v = String(raw).trim();
  if (v.charAt(0) === '"'){
    var out = '', i = 1;
    while (i < v.length){
      var c = v.charAt(i);
      if (c === '\\' && i + 1 < v.length){ out += v.charAt(i + 1); i += 2; continue; }
      if (c === '"'){ break; }
      out += c; i++;
    }
    return { type: 'string', value: out };
  }
  if (v.charAt(0) === "'"){
    var end = v.indexOf("'", 1);
    return { type: 'string', value: end === -1 ? v.slice(1) : v.slice(1, end) };
  }
  if (v === 'true') return { type: 'bool', value: true };
  if (v === 'false') return { type: 'bool', value: false };
  if (/^-?\d+$/.test(v)) return { type: 'number', value: parseInt(v, 10) };
  if (v.charAt(0) === '[') return { type: 'array', value: v };
  return { type: 'raw', value: v };
}

function looksSecretLine(line){
  if (SECRET_KEY_RE.test(line)) return true;
  if (/[A-Za-z0-9_\-]{24,}/.test(line)) return true;
  return false;
}

function verdictFor(findings){
  var hasBlock = false, hasWarn = false;
  for (var i = 0; i < findings.length; i++){
    if (findings[i].severity === 'BLOCKER') hasBlock = true;
    if (findings[i].severity === 'WARNING') hasWarn = true;
  }
  if (hasBlock) return 'DO NOT DEPLOY';
  if (hasWarn) return 'DEPLOY WITH FIXES';
  return 'SAFE TO DEPLOY';
}

function auditConfig(text){
  var findings = [];
  var runners = [];
  var lines = String(text == null ? '' : text).split(/\r?\n/);
  var section = '(global)';
  var runnerIdx = -1;
  var parsedEntries = 0;
  var hasConcurrent = false;
  var inArray = false;

  function cur(){ return runnerIdx >= 0 ? runners[runnerIdx] : null; }
  function add(sev, code, line, message, fix, extra){
    var f = { severity: sev, code: code, line: line, section: section,
      runner: runnerIdx >= 0 ? runnerIdx + 1 : null, message: message, fix: fix };
    if (extra){ for (var k in extra) f[k] = extra[k]; }
    findings.push(f);
    return f;
  }
  function newRunner(startLine){
    runners.push({ index: runners.length + 1, startLine: startLine, name: null,
      urls: [], tlsCaFile: false, tlsDisabled: [], images: [], pullPolicies: [],
      privLine: null, sockLines: [], netHostLine: null, hasLimit: false });
    runnerIdx = runners.length - 1;
  }

  for (var li = 0; li < lines.length; li++){
    var lineNo = li + 1;
    var rawLine = lines[li];
    var trimmed = rawLine.replace(/^\s+|\s+$/g, '');

    if (inArray){
      if (trimmed.indexOf(']') !== -1) inArray = false;
      scanMounts(rawLine, lineNo);
      continue;
    }
    if (trimmed === '') continue;
    if (trimmed.charAt(0) === '#') continue;

    var secMatch = trimmed.match(/^\[\[?\s*([^\]]+?)\s*\]\]?\s*(#.*)?$/);
    if (secMatch){
      section = trimmed.replace(/\s*(#.*)?$/, '');
      var secName = secMatch[1].replace(/\s+/g, '');
      if (secName === 'runners'){ newRunner(lineNo); }
      parsedEntries++;
      continue;
    }

    var kvMatch = trimmed.match(/^([A-Za-z0-9_.\-]+)\s*=\s*(.+)$/);
    if (!kvMatch){
      var withheld = looksSecretLine(trimmed);
      add('WARNING', 'NOT_PARSED', lineNo,
        withheld
          ? 'Line could not be parsed as a section or key = value, and it looks secret-bearing, so its content is withheld from every output.'
          : 'Line could not be parsed as a section or key = value: "' + trimmed.slice(0, 80) + '"',
        'Fix the syntax, or remove the line. Unparsed lines are not verified by any other check.',
        { notParsed: true, contentWithheld: withheld });
      continue;
    }

    parsedEntries++;
    var fullKey = kvMatch[1];
    var keyParts = fullKey.split('.');
    var key = keyParts[keyParts.length - 1].toLowerCase();
    var rawVal = kvMatch[2].replace(/\s+#.*$/, function(m){ return m; });
    var parsed = parseScalar(kvMatch[2]);
    var r = cur();
    var inCache = /cache/i.test(section);
    var isSecret = SECRET_KEY_RE.test(fullKey);

    scanMounts(rawLine, lineNo);

    if (parsed.type === 'array' && kvMatch[2].indexOf(']') === -1) inArray = true;

    // Secrets: flag by key, section, line, length only. Value never stored.
    if (isSecret){
      var vlen = parsed.type === 'string' ? parsed.value.length : String(kvMatch[2]).trim().length;
      if (vlen > 0){
        add('WARNING', 'PLAINTEXT_SECRET', lineNo,
          'Plaintext secret in the config file: key "' + fullKey + '" in section ' + section + ' (value length: ' + vlen + ' characters; the value is never shown in any output). Anyone who can read this file holds this credential.',
          'Move the secret to a secret manager or a root-only file (mode 0600), and rotate it if this file was ever shared, committed, or backed up.',
          { key: fullKey, valueLength: vlen });
      }
      continue;
    }

    if (key === 'concurrent' && runnerIdx === -1) hasConcurrent = true;
    if (r && key === 'name' && parsed.type === 'string' && !r.name) r.name = parsed.value;
    if (r && key === 'limit') r.hasLimit = true;

    if (r && key === 'url' && parsed.type === 'string'){
      r.urls.push({ line: lineNo, value: parsed.value, section: section });
    }
    if (r && key === 'tls-ca-file') r.tlsCaFile = true;

    // TLS verification disabled family.
    var tlsDisabled = false;
    if ((/disable/.test(key) && /tls|ssl|verify/.test(key) && parsed.value === true)) tlsDisabled = true;
    if ((/tls_?verify|verify_?tls|tls_?verification/.test(key) && parsed.value === false)) tlsDisabled = true;
    if ((key === 'insecure' || /insecure_?skip/.test(key)) && parsed.value === true) tlsDisabled = true;
    if (tlsDisabled){
      if (inCache){
        add('WARNING', 'CACHE_TLS_DISABLED', lineNo,
          'Cache TLS protection is disabled here ("' + fullKey + '"), so cache traffic can be intercepted or tampered with.',
          'Turn cache TLS back on and use an https:// cache endpoint with a valid certificate.');
      } else if (r){
        r.tlsDisabled.push({ line: lineNo, key: fullKey, section: section });
      } else {
        add('BLOCKER', 'TLS_VERIFICATION_DISABLED', lineNo,
          'TLS verification is disabled by "' + fullKey + '", so the runner will trust any certificate it is handed.',
          'Remove this setting and pin the coordinator CA with tls-ca-file instead.');
      }
    }

    if (r && key === 'privileged' && parsed.value === true){
      r.privLine = lineNo;
      add('BLOCKER', 'PRIVILEGED_ENABLED', lineNo,
        'privileged = true gives every job container full root-equivalent access to the host. Any CI job — including jobs from untrusted merge requests — can escape to the host.',
        'Set privileged = false. If a job truly needs elevated rights, isolate it on a dedicated, single-purpose host.');
    }

    if (r && (key === 'network_mode' || key === 'network') && parsed.type === 'string' && parsed.value === 'host'){
      r.netHostLine = lineNo;
    }

    if (r && key === 'image' && parsed.type === 'string'){
      r.images.push({ line: lineNo, value: parsed.value });
    }
    if (r && key === 'pull_policy' && parsed.type === 'string'){
      r.pullPolicies.push({ line: lineNo, value: parsed.value.toLowerCase() });
    }

    // Cache endpoint over plain HTTP.
    if (inCache && parsed.type === 'string' && /^http:\/\//i.test(parsed.value)){
      add('WARNING', 'CACHE_OVER_HTTP', lineNo,
        'Cache endpoint "' + fullKey + '" uses plain http://, so build cache contents cross the network unencrypted and unauthenticated by TLS.',
        'Use an https:// cache endpoint, or keep the cache on a trusted private network segment.');
    }
  }

  function scanMounts(rawLine, lineNo){
    var t = rawLine.replace(/^\s+/, '');
    if (t.charAt(0) === '#') return;
    var r = cur();
    if (rawLine.indexOf('/var/run/docker.sock') !== -1){
      if (r) r.sockLines.push({ line: lineNo, section: section });
      findings.push({ severity: 'BLOCKER', code: 'DOCKER_SOCK_MOUNT', line: lineNo, section: section,
        runner: runnerIdx >= 0 ? runnerIdx + 1 : null,
        message: 'The host Docker socket (/var/run/docker.sock) is mounted into job containers. That socket is root-equivalent on the host: any job can start a privileged container and take the machine.',
        fix: 'Remove the docker.sock volume. Use a rootless builder, kaniko, or a dedicated build host instead.' });
    }
    if (HOST_ROOT_RE.test(rawLine)){
      findings.push({ severity: 'BLOCKER', code: 'HOST_ROOT_MOUNT', line: lineNo, section: section,
        runner: runnerIdx >= 0 ? runnerIdx + 1 : null,
        message: 'A host filesystem root or sensitive host directory is mounted into job containers, giving jobs direct read/write access to the host filesystem.',
        fix: 'Remove the host mount. Give jobs a dedicated scratch volume (for example /cache) instead of host paths.' });
    }
  }

  // Per-runner post-pass: pairings and posture.
  for (var ri = 0; ri < runners.length; ri++){
    var run = runners[ri];
    var savedSection = section, savedIdx = runnerIdx;
    section = '[[runners]] #' + run.index; runnerIdx = ri;

    for (var u = 0; u < run.urls.length; u++){
      var urlEnt = run.urls[u];
      section = urlEnt.section;
      if (/^http:\/\//i.test(urlEnt.value)){
        add('BLOCKER', 'HTTP_COORDINATOR_URL', urlEnt.line,
          'Coordinator URL uses plain http://' + (run.tlsCaFile ? '' : ' and no tls-ca-file is pinned for this runner') + ', so the runner token and job payloads cross the network in the clear and can be redirected by anyone on the path.',
          'Change the coordinator URL to https:// and pin its CA with tls-ca-file.');
      } else if (/^https:\/\//i.test(urlEnt.value) && !run.tlsCaFile){
        add('WARNING', 'NO_TLS_CA_FILE', urlEnt.line,
          'Coordinator URL is https:// but no tls-ca-file is pinned for this runner, so verification depends entirely on the host system CA store.',
          'Pin the coordinator CA with tls-ca-file so a tampered system store cannot silently redirect the runner.');
      }
    }
    for (var t = 0; t < run.tlsDisabled.length; t++){
      section = run.tlsDisabled[t].section || ('[[runners]] #' + run.index);
      add('BLOCKER', 'TLS_VERIFICATION_DISABLED', run.tlsDisabled[t].line,
        'TLS verification is disabled by "' + run.tlsDisabled[t].key + '", so connections made under this setting trust any certificate they are handed — a man-in-the-middle can impersonate the endpoint and the runner cannot tell.',
        'Remove this setting (or set it back to verified) and pin the coordinator CA with tls-ca-file.');
    }

    var unpinned = false;
    for (var im = 0; im < run.images.length; im++){
      var img = run.images[im];
      if (img.value.indexOf('@sha256:') !== -1) continue;
      var lastSlash = img.value.lastIndexOf('/');
      var lastColon = img.value.lastIndexOf(':');
      var tag = lastColon > lastSlash ? img.value.slice(lastColon + 1) : null;
      if (!tag || tag === 'latest'){
        unpinned = true;
        add('WARNING', 'UNPINNED_IMAGE', img.line,
          'Default image "' + img.value + '" is ' + (tag === 'latest' ? 'tagged :latest' : 'untagged') + ', so the exact code a job runs can change between runs without any config change.',
          'Pin the image to a specific version tag or, better, a digest (image@sha256:…).');
      }
    }
    for (var pp = 0; pp < run.pullPolicies.length; pp++){
      var pol = run.pullPolicies[pp];
      if (pol.value === 'always'){
        if (unpinned){
          add('WARNING', 'PULL_ALWAYS_UNPINNED', pol.line,
            'pull_policy = "always" combined with an unpinned image means every job silently pulls whatever the tag points to that day — a mutable, unaudited supply chain.',
            'Pin the image and prefer pull_policy = "if-not-present" so the image changes only when you change the config.');
        } else {
          findings.push({ severity: 'INFO', code: 'PULL_ALWAYS', line: pol.line, section: section,
            runner: run.index,
            message: 'pull_policy = "always" re-pulls the image for every job. The image is pinned, so this is a speed and availability note, not a safety finding.',
            fix: 'Consider "if-not-present" unless you specifically need a fresh pull every job.' });
        }
      }
    }

    if (run.netHostLine !== null){
      if (run.privLine !== null){
        add('BLOCKER', 'PRIVILEGED_HOST_NETWORK', run.netHostLine,
          'Host networking combined with privileged = true: jobs share the host network namespace while holding root-equivalent container rights, so they can bind host ports, sniff host traffic, and reach host-only services.',
          'Drop host networking (use the default bridge), and set privileged = false.');
      } else {
        add('WARNING', 'HOST_NETWORK', run.netHostLine,
          'Host networking shares the host network namespace with every job, exposing host-only services and ports to CI jobs.',
          'Use the default bridge networking unless a job demonstrably needs host networking.');
      }
    }

    if (run.privLine !== null && run.sockLines.length > 0){
      for (var s = 0; s < run.sockLines.length; s++){
        section = run.sockLines[s].section;
        add('BLOCKER', 'PRIVILEGED_DOCKER_SOCK', run.sockLines[s].line,
          'ESCALATED: privileged = true (line ' + run.privLine + ') combined with a mounted Docker socket is a direct, well-known path from any CI job to full host compromise — the two findings multiply, they do not add.',
          'Remove the docker.sock mount AND set privileged = false. Fixing only one still leaves the other standing alone as a BLOCKER.');
      }
      section = '[[runners]] #' + run.index;
    }

    if (!run.hasLimit){
      add('INFO', 'MISSING_LIMIT', run.startLine,
        'This runner sets no limit, so it can accept an unbounded number of concurrent jobs for its token and starve the host or other runners.',
        'Set a per-runner limit that matches the host\'s CPU and memory.');
    }
    section = savedSection; runnerIdx = savedIdx;
  }

  if (!hasConcurrent && runners.length > 0 || (!hasConcurrent && parsedEntries > 0 && runners.length === 0)){
    findings.push({ severity: 'INFO', code: 'MISSING_CONCURRENT', line: null, section: '(global)',
      runner: null,
      message: 'No global concurrent is set, so the total number of jobs across all runners is bounded only by GitLab Runner defaults, not by a decision recorded in this file.',
      fix: 'Set concurrent at the top of the file to the total job count this host should ever run at once.' });
  }

  var sevRank = { BLOCKER: 0, WARNING: 1, INFO: 2 };
  findings.sort(function(a, b){
    var d = sevRank[a.severity] - sevRank[b.severity];
    if (d !== 0) return d;
    return (a.line || 0) - (b.line || 0);
  });

  var counts = { BLOCKER: 0, WARNING: 0, INFO: 0, NOT_PARSED: 0 };
  for (var ci = 0; ci < findings.length; ci++){
    counts[findings[ci].severity]++;
    if (findings[ci].code === 'NOT_PARSED') counts.NOT_PARSED++;
  }

  var runnerGrades = runners.map(function(run){
    var rf = findings.filter(function(f){ return f.runner === run.index; });
    return { index: run.index, name: run.name, startLine: run.startLine,
      verdict: verdictFor(rf),
      counts: { BLOCKER: rf.filter(function(f){return f.severity==='BLOCKER';}).length,
                WARNING: rf.filter(function(f){return f.severity==='WARNING';}).length,
                INFO: rf.filter(function(f){return f.severity==='INFO';}).length } };
  });

  return { enough: parsedEntries > 0, lineCount: lines.length, parsedEntries: parsedEntries,
    verdict: verdictFor(findings), counts: counts, findings: findings, runners: runnerGrades };
}

function buildReport(result){
  var out = [];
  out.push('J-Dawgs GitLab Runner Config Safety Auditor - heuristic text audit');
  out.push('================================================================');
  if (!result.enough){
    out.push('Verdict: NOT ENOUGH TO GRADE');
    out.push('No recognizable config.toml structure (sections or key = value lines) was found in the input.');
    return out.join('\n');
  }
  out.push('Verdict: ' + result.verdict);
  out.push('Counts: ' + result.counts.BLOCKER + ' BLOCKER / ' + result.counts.WARNING + ' WARNING / ' +
           result.counts.INFO + ' INFO / ' + result.counts.NOT_PARSED + ' NOT PARSED');
  out.push('Lines audited: ' + result.lineCount);
  out.push('');
  out.push('Per-runner grades:');
  if (result.runners.length === 0) out.push('  (no [[runners]] sections found)');
  for (var i = 0; i < result.runners.length; i++){
    var rg = result.runners[i];
    out.push('  Runner #' + rg.index + (rg.name ? ' "' + rg.name + '"' : '') + ' (starts line ' + rg.startLine + '): ' +
             rg.verdict + ' - ' + rg.counts.BLOCKER + ' BLOCKER / ' + rg.counts.WARNING + ' WARNING / ' + rg.counts.INFO + ' INFO');
  }
  out.push('');
  out.push('Findings:');
  if (result.findings.length === 0) out.push('  None. No BLOCKER, WARNING, or INFO findings.');
  for (var j = 0; j < result.findings.length; j++){
    var f = result.findings[j];
    var tag = f.code === 'NOT_PARSED' ? 'NOT PARSED' : f.severity;
    out.push('[' + tag + '] ' + (f.line ? 'Line ' + f.line : 'Global') + ' / ' + f.section + ' / ' + f.code);
    out.push('  ' + f.message);
    if (f.valueLength != null) out.push('  Secret reported by key, section, line and length only (' + f.valueLength + ' chars). Value not printed.');
    out.push('  Fix: ' + f.fix);
  }
  out.push('');
  out.push('Notes: heuristic text audit only - not a full TOML parser, does not run GitLab Runner,');
  out.push('does not connect to GitLab, and does not verify any token. Secret values are never printed.');
  return out.join('\n');
}

function buildJSON(result){
  return JSON.stringify({
    tool: 'J-Dawgs GitLab Runner Config Safety Auditor',
    auditType: 'heuristic text audit (not a full TOML parser; does not run GitLab Runner)',
    verdict: result.enough ? result.verdict : 'NOT ENOUGH TO GRADE',
    enoughToGrade: result.enough,
    linesAudited: result.lineCount,
    counts: result.counts,
    runners: result.runners,
    findings: result.findings.map(function(f){
      var o = { severity: f.severity, code: f.code, line: f.line, section: f.section,
        runner: f.runner, message: f.message, fix: f.fix };
      if (f.key) o.key = f.key;
      if (f.valueLength != null) o.valueLength = f.valueLength;
      if (f.notParsed) o.notParsed = true;
      if (f.contentWithheld) o.contentWithheld = true;
      return o;
    }),
    secretHandling: 'Secrets are reported by key name, section, line and length only. Secret values never appear in this JSON.'
  }, null, 2);
}
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-gitlab-runner-config-safety-auditor',
  name: 'J-Dawgs GitLab Runner Config Safety Auditor',
  description: 'Grades a pasted runner config.toml offline into one deploy verdict — privileged mode and docker.sock mounts as BLOCKERs, http coordinator / TLS-off, tokens by key name/section/line/length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
