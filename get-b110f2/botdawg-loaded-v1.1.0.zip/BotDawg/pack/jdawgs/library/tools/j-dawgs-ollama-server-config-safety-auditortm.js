'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Ollama Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        /* ---------- Worked examples (line numbers are index + 1) ---------- */

        var RISKY_LINES = [
          "OLLAMA_HOST=0.0.0.0:11434",
          "OLLAMA_ORIGINS=*",
          "OLLAMA_DEBUG=1",
          "OLLAMA_MODELS=/tmp/ollama-models",
          "OLLAMA_NUM_PARALLEL=4"
        ];

        var HARDENED_LINES = [
          "# Ollama stays on this machine only.",
          "OLLAMA_HOST=127.0.0.1:11434",
          "OLLAMA_ORIGINS=http://localhost:3000,http://127.0.0.1:3000",
          "OLLAMA_DEBUG=0",
          "OLLAMA_MODELS=/var/lib/ollama/models"
        ];

        var COMPOSE_LINES = [
          "services:",
          "  ollama:",
          "    image: ollama/ollama",
          "    environment:",
          "      - OLLAMA_HOST=0.0.0.0:11434",
          "      - OLLAMA_ORIGINS=*",
          "    ports:",
          "      - \"11434:11434\""
        ];

        /* ---------- Known Ollama variables ---------- */

        var PERF_KEYS = {
          OLLAMA_FLASH_ATTENTION: 1, OLLAMA_NUM_PARALLEL: 1, OLLAMA_MAX_QUEUE: 1,
          OLLAMA_MAX_LOADED_MODELS: 1, OLLAMA_KEEP_ALIVE: 1, OLLAMA_LOAD_TIMEOUT: 1,
          OLLAMA_KV_CACHE_TYPE: 1, OLLAMA_SCHED_SPREAD: 1, OLLAMA_CONTEXT_LENGTH: 1,
          OLLAMA_NOPRUNE: 1
        };
        var KNOWN_KEYS = {
          OLLAMA_HOST: 1, OLLAMA_ORIGINS: 1, OLLAMA_DEBUG: 1, OLLAMA_MODELS: 1,
          OLLAMA_TMPDIR: 1
        };
        for (var pk in PERF_KEYS) KNOWN_KEYS[pk] = 1;

        /* ---------- Parsing ---------- */

        function stripQuotes(v) {
          var s = String(v).trim();
          if (s.length >= 2) {
            var a = s.charAt(0), b = s.charAt(s.length - 1);
            if ((a === '"' && b === '"') || (a === "'" && b === "'")) return s.slice(1, -1).trim();
          }
          return s;
        }

        function cleanValue(v) {
          var s = String(v).trim();
          if (s.charAt(0) === '"' || s.charAt(0) === "'") {
            var q = s.charAt(0);
            var end = s.indexOf(q, 1);
            if (end > 0) return s.slice(1, end).trim();
            return s.slice(1).trim();
          }
          var hash = s.indexOf(" #");
          if (hash >= 0) s = s.slice(0, hash);
          return s.trim();
        }

        function parseBool(v) {
          var s = stripQuotes(v).toLowerCase();
          if (s === "true" || s === "yes" || s === "on" || s === "1") return true;
          if (s === "false" || s === "no" || s === "off" || s === "0") return false;
          return null;
        }

        function detectFormat(lines) {
          var hasSystemd = false, hasCompose = false, hasExport = false, i, t;
          for (i = 0; i < lines.length; i++) {
            t = lines[i];
            if (/^\s*Environment\s*=/.test(t) || /^\s*\[(Unit|Service|Install)\]\s*$/.test(t)) hasSystemd = true;
            if (/^\s*environment\s*:\s*(#.*)?$/.test(t) || /^\s*services\s*:\s*(#.*)?$/.test(t)) hasCompose = true;
            if (/^\s*export\s+[A-Za-z_]/.test(t)) hasExport = true;
          }
          if (hasSystemd) return "systemd unit";
          if (hasCompose) return "docker-compose";
          if (hasExport) return "shell exports";
          return "environment-variable lines";
        }

        function parseConfig(text) {
          var lines = String(text).replace(/\r\n?/g, "\n").split("\n");
          var entries = [];      // {key, keyRaw, value, line}
          var notParsed = [];
          var envIndent = null;  // indent of an open compose environment: block
          for (var i = 0; i < lines.length; i++) {
            var lineNo = i + 1;
            var raw = lines[i];
            var t = raw.trim();
            if (t === "") continue;
            if (t.charAt(0) === "#" || t.charAt(0) === ";") continue;
            var indent = raw.match(/^\s*/)[0].length;

            /* docker-compose environment: block tracking */
            var envHead = raw.match(/^(\s*)environment\s*:\s*(#.*)?$/);
            if (envHead) { envIndent = envHead[1].length; continue; }
            if (envIndent !== null) {
              if (indent > envIndent) {
                var inner = t.replace(/^-\s+/, "");
                var kvIn = inner.match(/^([A-Za-z_][A-Za-z0-9_.-]*)\s*(?:=|:)\s*(.*)$/);
                if (kvIn) {
                  entries.push({ key: kvIn[1].toUpperCase(), keyRaw: kvIn[1], value: cleanValue(kvIn[2]), line: lineNo });
                } else {
                  notParsed.push(lineNo);
                }
                continue;
              }
              envIndent = null; // dedented out of the block; fall through
            }

            /* systemd [Section] headers */
            if (/^\[[^\]]+\]\s*$/.test(t)) continue;

            /* systemd Environment= lines (one line may carry several pairs) */
            var envLine = raw.match(/^\s*Environment\s*=\s*(.*)$/);
            if (envLine) {
              var rest = envLine[1].replace(/["]/g, " ");
              var pairRe = /([A-Za-z_][A-Za-z0-9_.-]*)=([^\s]+)/g;
              var pm, any = false;
              while ((pm = pairRe.exec(rest)) !== null) {
                entries.push({ key: pm[1].toUpperCase(), keyRaw: pm[1], value: cleanValue(pm[2]), line: lineNo });
                any = true;
              }
              if (!any) notParsed.push(lineNo);
              continue;
            }

            /* plain KEY=VALUE, optionally behind export */
            var body = t.replace(/^export\s+/, "");
            var kv = body.match(/^([A-Za-z_][A-Za-z0-9_.-]*)\s*=\s*(.*)$/);
            if (kv) {
              entries.push({ key: kv[1].toUpperCase(), keyRaw: kv[1], value: cleanValue(kv[2]), line: lineNo });
              continue;
            }

            /* compose-style "KEY: value" when the key is an Ollama variable */
            var ykv = body.match(/^([A-Za-z_][A-Za-z0-9_.-]*)\s*:\s+(.+)$/);
            if (ykv && ykv[1].toUpperCase().indexOf("OLLAMA_") === 0) {
              entries.push({ key: ykv[1].toUpperCase(), keyRaw: ykv[1], value: cleanValue(ykv[2]), line: lineNo });
              continue;
            }

            /* other YAML structure (service names, image:, ports:, list items) is context, not a setting */
            if (/^[A-Za-z0-9_."'][A-Za-z0-9_."\/-]*\s*:(\s.*)?$/.test(t) || /^-\s+/.test(t)) continue;

            notParsed.push(lineNo);
          }
          return { entries: entries, notParsed: notParsed, format: detectFormat(lines), lineCount: lines.length };
        }

        function lastEntry(parsed, key) {
          var found = null;
          for (var i = 0; i < parsed.entries.length; i++) {
            if (parsed.entries[i].key === key) found = parsed.entries[i];
          }
          return found;
        }

        /* ---------- Host parsing ---------- */

        function parseHostValue(v) {
          var s = stripQuotes(v).trim();
          s = s.replace(/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//, "");
          s = s.split("/")[0];
          var host = s, port = null;
          if (s.charAt(0) === "[") {
            var close = s.indexOf("]");
            if (close >= 0) {
              host = s.slice(1, close);
              var pm = s.slice(close + 1).match(/^:(\d+)$/);
              if (pm) port = pm[1];
            }
          } else {
            var idx = s.lastIndexOf(":");
            if (idx >= 0) {
              var tail = s.slice(idx + 1);
              if (/^\d+$/.test(tail)) { port = tail; host = s.slice(0, idx); }
              else if (tail === "") { host = s.slice(0, idx); }
            }
          }
          return { host: host.trim(), port: port };
        }

        function isLoopbackHost(h) {
          var x = h.toLowerCase();
          return x === "localhost" || x === "::1" || x === "127.0.0.1" || /^127\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(x);
        }
        function isAllInterfaces(h) {
          return h === "" || h === "0.0.0.0" || h === "::";
        }

        /* ---------- Secret-like value detection (value is never returned) ---------- */

        var PLACEHOLDERISH = /^(changeme|change-me|change_me|password|secret|token|example|placeholder|xxx+|todo|none|null)$/i;
        function looksSecretLike(key, value) {
          var v = stripQuotes(value);
          if (!v || v.length < 8) return false;
          if (/\s/.test(v)) return false;
          if (v.indexOf("://") >= 0) return false;
          if (v.charAt(0) === "/") return false;
          if (PLACEHOLDERISH.test(v)) return false;
          if (/^(sk-[A-Za-z0-9]|ghp_[A-Za-z0-9]|gho_[A-Za-z0-9]|github_pat_|AKIA[0-9A-Z]{12}|xox[baprs]-|eyJ[A-Za-z0-9_-]{8,}\.)/.test(v)) return true;
          if (/^[A-Za-z0-9_\-+/=]+$/.test(v) && v.length >= 20 && /[a-z]/.test(v) && /[A-Z]/.test(v) && /[0-9]/.test(v)) return true;
          if (/^[0-9a-fA-F]{32,}$/.test(v)) return true;
          var keySecret = /(token|secret|passwd|password|api[-_]?key|access[-_]?key|private[-_]?key|credential)/i.test(key);
          if (keySecret && v.length >= 12) return true;
          return false;
        }

        /* ---------- Model path posture ---------- */

        function sharedModelsPath(v) {
          var p = stripQuotes(v).trim();
          if (/^\/tmp(\/|$)/.test(p) || /^\/var\/tmp(\/|$)/.test(p) || /^\/dev\/shm(\/|$)/.test(p)) return "a shared temporary directory";
          if (/^\/Users\/Shared(\/|$)/.test(p) || /^\/shared(\/|$)/.test(p)) return "a shared directory";
          if (p === "/") return "the filesystem root";
          if (/^\/(home|Users)\/[^/]+\/?$/.test(p) || p === "/root" || p === "/root/" || p === "~" || p === "~/" || p === "$HOME" || p === "$HOME/") return "a home-directory root";
          return null;
        }

        /* ---------- Audit ---------- */

        var SEV_RANK = { BLOCKER: 0, HIGH: 1, WARNING: 2, INFO: 3 };
        var PROXY_NOTE = /(reverse[\s-]?proxy|proxy_pass|basic[\s_]?auth|oauth|oidc|nginx|caddy|traefik|cloudflare|firewall|ufw|iptables|authentik|authelia)/i;

        function auditConfig(text) {
          var rawText = text == null ? "" : String(text);
          var parsed = parseConfig(rawText);
          var findings = [];
          function add(severity, key, line, message, fix) {
            findings.push({
              severity: severity,
              key: key || "",
              line: (typeof line === "number" && line > 0) ? line : null,
              message: message,
              fix: fix || ""
            });
          }

          var ollamaEntries = [];
          var i, e;
          for (i = 0; i < parsed.entries.length; i++) {
            if (parsed.entries[i].key.indexOf("OLLAMA_") === 0) ollamaEntries.push(parsed.entries[i]);
          }

          if (ollamaEntries.length === 0) {
            var empty = rawText.trim() === "";
            add("INFO", "", null,
              empty
                ? "Nothing was pasted, so there is nothing to grade. Paste an Ollama server configuration — environment-variable lines, a systemd Environment= block, a docker-compose environment block, or a shell export block."
                : "The pasted text contains no recognizable Ollama variables (no OLLAMA_* settings), so it cannot be graded as an Ollama server configuration.",
              "");
            return finish(parsed, findings, "NOT ENOUGH TO GRADE",
              empty ? "The input was empty." : "The input contains no OLLAMA_* settings.",
              ollamaEntries.length);
          }

          var proxyNoted = PROXY_NOTE.test(rawText);

          /* --- OLLAMA_HOST bind exposure --- */
          var hostEntry = lastEntry(parsed, "OLLAMA_HOST");
          var networkBind = false;
          if (hostEntry) {
            var hv = parseHostValue(hostEntry.value);
            if (stripQuotes(hostEntry.value) === "") {
              add("WARNING", "OLLAMA_HOST", hostEntry.line,
                "OLLAMA_HOST is present but empty. An empty value leaves the bind address to whatever the surrounding service definition does with it, so the exposure cannot be confirmed from this paste.",
                "Set OLLAMA_HOST explicitly — 127.0.0.1:11434 to keep Ollama on this machine.");
            } else if (isLoopbackHost(hv.host)) {
              add("INFO", "OLLAMA_HOST", hostEntry.line,
                "OLLAMA_HOST binds to " + hv.host + ", a loopback address: only processes on this same machine can reach the API. That is the safe posture for a server with no built-in authentication.",
                "");
            } else {
              networkBind = true;
              var bindDesc = isAllInterfaces(hv.host)
                ? "every network interface (" + (hv.host === "" ? "no host part — all interfaces" : hv.host) + ")"
                : "the non-loopback address " + hv.host;
              if (proxyNoted) {
                add("HIGH", "OLLAMA_HOST", hostEntry.line,
                  "OLLAMA_HOST binds Ollama to " + bindDesc + ". The pasted text notes a reverse-proxy or auth layer, which is graded HIGH instead of BLOCKER — but Ollama itself has no built-in authentication, so the proxy layer is the only thing authenticating anyone, and this audit cannot verify it is actually in front of the port or correctly configured.",
                  "Confirm the proxy really is the only path to the port (the Ollama port itself firewalled from direct access), or bind OLLAMA_HOST to 127.0.0.1 and let the proxy be the sole entry point.");
              } else {
                add("BLOCKER", "OLLAMA_HOST", hostEntry.line,
                  "OLLAMA_HOST binds Ollama to " + bindDesc + ", and nothing in the paste notes a reverse proxy or any other authentication layer in front of it. Ollama has no built-in authentication, so network exposure is unauthenticated exposure: anyone who can reach this port can run prompts, pull and delete models, and consume the machine's compute.",
                  "Bind OLLAMA_HOST to 127.0.0.1:11434 unless remote access is truly required; if it is, put an authenticating reverse proxy in front and firewall the Ollama port itself.");
              }
            }
            if (hv.port && hv.port !== "11434") {
              add("INFO", "OLLAMA_HOST", hostEntry.line,
                "OLLAMA_HOST uses port " + hv.port + " instead of Ollama's default 11434. A non-default port is not a security control — the findings above grade the bind address, not the port — but clients and firewall rules must agree on it.",
                "");
            }
          } else {
            add("INFO", "OLLAMA_HOST", null,
              "OLLAMA_HOST is not set in the paste. Ollama's own default binds 127.0.0.1:11434 — this machine only — so on the bind axis the default posture is loopback, provided nothing outside this paste (a unit file, a container port publish) overrides it.",
              "");
          }

          /* --- OLLAMA_ORIGINS --- */
          var originsEntry = lastEntry(parsed, "OLLAMA_ORIGINS");
          if (originsEntry) {
            var ov = stripQuotes(originsEntry.value);
            var parts = ov.split(",").map(function (s) { return s.trim(); });
            var wildcard = ov === "*" || parts.indexOf("*") >= 0;
            if (wildcard) {
              if (networkBind) {
                add("BLOCKER", "OLLAMA_ORIGINS", originsEntry.line,
                  "OLLAMA_ORIGINS is set to * on top of a network bind. Any website a user visits can have its scripts call this server cross-origin, so the unauthenticated API is reachable not just by machines on the network but by any web page opened from one.",
                  "Replace * with the explicit origins that legitimately use the API (for example http://localhost:3000), or remove OLLAMA_ORIGINS entirely.");
              } else {
                add("HIGH", "OLLAMA_ORIGINS", originsEntry.line,
                  "OLLAMA_ORIGINS is set to *, which lets any website's scripts call this server cross-origin. The bind is not network-facing in this paste, which keeps this at HIGH rather than BLOCKER — but the wildcard removes the browser-side barrier entirely if the bind ever widens.",
                  "Replace * with the explicit origins that legitimately use the API, or remove OLLAMA_ORIGINS entirely.");
              }
            } else if (ov !== "") {
              add("INFO", "OLLAMA_ORIGINS", originsEntry.line,
                "OLLAMA_ORIGINS names an explicit origin list rather than a wildcard, so only the listed web origins can call the server cross-origin. Confirm every listed origin is one you operate.",
                "");
            }
          } else {
            add("INFO", "OLLAMA_ORIGINS", null,
              "OLLAMA_ORIGINS is not set. Ollama's default allows only local origins, so browser-based cross-origin calls from arbitrary websites are not opened up by this paste.",
              "");
          }

          /* --- OLLAMA_DEBUG --- */
          var debugEntry = lastEntry(parsed, "OLLAMA_DEBUG");
          if (debugEntry && parseBool(debugEntry.value) === true) {
            add("WARNING", "OLLAMA_DEBUG", debugEntry.line,
              "OLLAMA_DEBUG is enabled. Debug mode makes the server log verbosely, and verbose request logs can record prompt and request detail — content users sent to the model — in log files that are usually kept longer and shared more widely than the prompts themselves.",
              "Set OLLAMA_DEBUG=0 (or remove it) outside active troubleshooting.");
          }

          /* --- OLLAMA_MODELS --- */
          var modelsEntry = lastEntry(parsed, "OLLAMA_MODELS");
          if (modelsEntry) {
            var shared = sharedModelsPath(modelsEntry.value);
            if (shared) {
              add("WARNING", "OLLAMA_MODELS", modelsEntry.line,
                "OLLAMA_MODELS points at " + shared + ". Model files stored where other local users can reach them can be read, replaced, or deleted by those users — a swapped model file is code and weights the server will happily load.",
                "Point OLLAMA_MODELS at a dedicated directory owned by the user the Ollama service runs as (for example /var/lib/ollama/models).");
            } else if (stripQuotes(modelsEntry.value) !== "") {
              add("INFO", "OLLAMA_MODELS", modelsEntry.line,
                "OLLAMA_MODELS points at a dedicated path rather than a shared or home-root location, so model files sit under one service account's control.",
                "");
            }
          } else {
            add("INFO", "OLLAMA_MODELS", null,
              "OLLAMA_MODELS is not set, so models live in Ollama's default location under the service user's home directory — the standard, single-owner posture.",
              "");
          }

          /* --- Performance settings: INFO only, never security findings --- */
          for (i = 0; i < parsed.entries.length; i++) {
            e = parsed.entries[i];
            if (PERF_KEYS[e.key]) {
              add("INFO", e.key, e.line,
                e.keyRaw + " is a performance / tuning setting. It is noted here for completeness only — it has no bearing on exposure and is never graded as a security finding by this audit.",
                "");
            }
          }

          /* --- Unrecognized OLLAMA_* names --- */
          for (i = 0; i < parsed.entries.length; i++) {
            e = parsed.entries[i];
            if (e.key.indexOf("OLLAMA_") === 0 && !KNOWN_KEYS[e.key]) {
              add("INFO", e.key, e.line,
                e.keyRaw + " is not an Ollama variable name this audit recognizes. Ollama silently ignores variables it does not know, so if this is a typo (for example of OLLAMA_HOST or OLLAMA_ORIGINS), the setting you intended is not in force.",
                "Check the spelling against the Ollama variable you meant to set.");
            }
          }

          /* --- Credential-looking values on non-Ollama variables --- */
          for (i = 0; i < parsed.entries.length; i++) {
            e = parsed.entries[i];
            if (e.key.indexOf("OLLAMA_") === 0) continue;
            if (looksSecretLike(e.keyRaw, e.value)) {
              add("HIGH", e.key, e.line,
                "The value assigned to " + e.keyRaw + " on line " + e.line + " looks like a token or API key (" + stripQuotes(e.value).length + " characters; the value itself is never shown). It is not an Ollama setting, and a server environment block tends to travel — unit files, compose files, and tickets get copied — taking the credential with it.",
                "Remove the credential from this configuration and supply it through a secrets mechanism instead; rotate it if this text has already been shared.");
            }
          }

          /* --- Unparsed lines --- */
          if (parsed.notParsed.length) {
            add("INFO", "", parsed.notParsed[0],
              "Line" + (parsed.notParsed.length > 1 ? "s" : "") + " " + parsed.notParsed.join(", ") +
              " could not be read as a setting in the detected format (" + parsed.format + ") and " +
              (parsed.notParsed.length > 1 ? "were" : "was") + " excluded from this audit — not guessed at.",
              "");
          }

          findings.sort(function (a, b) {
            var r = SEV_RANK[a.severity] - SEV_RANK[b.severity];
            if (r !== 0) return r;
            var la = a.line === null ? 999999 : a.line;
            var lb = b.line === null ? 999999 : b.line;
            return la - lb;
          });

          var counts = countSev(findings);
          var verdict, why;
          if (counts.BLOCKER > 0) {
            verdict = "DO NOT EXPOSE";
            why = counts.BLOCKER + " BLOCKER finding" + (counts.BLOCKER > 1 ? "s" : "") + " — this configuration would put an unauthenticated Ollama API within reach of the network or of any web page. Fix the BLOCKER items before this server is started anywhere reachable.";
          } else if (counts.HIGH > 0 || counts.WARNING > 0) {
            verdict = "EXPOSE WITH FIXES";
            why = "No BLOCKER findings, but " + (counts.HIGH + counts.WARNING) + " HIGH/WARNING finding" + ((counts.HIGH + counts.WARNING) > 1 ? "s" : "") + " should be fixed before this server is exposed.";
          } else {
            verdict = "SAFE TO EXPOSE";
            why = "No BLOCKER, HIGH, or WARNING findings in the pasted text — none of the exposure patterns this audit checks for were found.";
          }
          return finish(parsed, findings, verdict, why, ollamaEntries.length);
        }

        function countSev(findings) {
          var c = { BLOCKER: 0, HIGH: 0, WARNING: 0, INFO: 0 };
          findings.forEach(function (f) { c[f.severity]++; });
          return c;
        }

        function finish(parsed, findings, verdict, why, ollamaCount) {
          return {
            verdict: verdict,
            why: why,
            counts: countSev(findings),
            findings: findings,
            format: parsed.format,
            parsedSettings: parsed.entries.length,
            ollamaSettings: ollamaCount,
            notParsedLines: parsed.notParsed.slice()
          };
        }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-ollama-server-config-safety-auditortm',
  name: 'J-Dawgs Ollama Server Config Safety Auditor',
  description: 'Grades a pasted Ollama server environment offline into one exposure verdict. Ollama ships no config checker and no built-in authentication; ours grades bind exposure, CORS origins, and debug posture before the port opens.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
