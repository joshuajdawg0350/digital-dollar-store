'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs SiYuan Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Worked examples (exact text, loaded verbatim) ---------- */
      var RISKY_EXAMPLE = [
        "host=0.0.0.0",
        "port=6806",
        "accessAuthCode=123456",
        "readonly=false",
        "publishEnabled=true",
        "protocol=http",
        "apiToken=EXAMPLETOKEN-planted-000111222"
      ].join("\n");

      var HARDENED_EXAMPLE = [
        "host=127.0.0.1",
        "port=6806",
        "accessAuthCode=Local-Strong-Auth-Example-9f27K!",
        "readonly=true",
        "publishEnabled=false",
        "protocol=https"
      ].join("\n");

      var WEAK_AUTH_VALUES = ["123456", "12345678", "changeme", "change-me", "example", "password", "test", "siyuan", "admin", "letmein"];

      /* ---------- Key recognition ---------- */
      var CANON = {
        host: "host", bind: "host", bindaddress: "host", bindhost: "host",
        listenaddress: "host", listenhost: "host", serverhost: "host", ip: "host",
        port: "port", serverport: "port", listenport: "port",
        accessauthcode: "accessAuthCode", authcode: "accessAuthCode", accesscode: "accessAuthCode",
        readonly: "readonly",
        publishenabled: "publishEnabled", publish: "publishEnabled", publishenable: "publishEnabled",
        protocol: "protocol", scheme: "protocol",
        https: "secureTransport", ssl: "secureTransport", tls: "secureTransport",
        httpsenabled: "secureTransport", sslenabled: "secureTransport", tlsenabled: "secureTransport",
        usehttps: "secureTransport", usessl: "secureTransport", usetls: "secureTransport",
        enablehttps: "secureTransport", enablessl: "secureTransport", enabletls: "secureTransport",
        apitoken: "apiToken", cloudtoken: "cloudToken"
      };
      var DISPLAY = {
        host: "host", port: "port", accessAuthCode: "accessAuthCode",
        readonly: "readonly", publishEnabled: "publishEnabled",
        protocol: "protocol", apiToken: "apiToken", cloudToken: "cloudToken"
      };

      function normalizeKey(raw) {
        var k = String(raw).toLowerCase().replace(/[^a-z0-9]/g, "");
        if (k.indexOf("siyuan") === 0) k = k.slice(6);
        return k;
      }

      function classify(norm) {
        if (Object.prototype.hasOwnProperty.call(CANON, norm)) return CANON[norm];
        if (norm.indexOf("token") >= 0 || norm.indexOf("secret") >= 0 || norm.indexOf("password") >= 0) return "secret";
        return null;
      }

      function cleanToken(v) {
        v = String(v).trim();
        if (v.charAt(v.length - 1) === ",") v = v.slice(0, -1).trim();
        if (v.length >= 2) {
          var a = v.charAt(0), b = v.charAt(v.length - 1);
          if ((a === '"' && b === '"') || (a === "'" && b === "'")) v = v.slice(1, -1);
        }
        return v.trim();
      }

      function parseConfig(text) {
        var entries = [];
        var lines = String(text == null ? "" : text).split(/\r?\n/);
        for (var i = 0; i < lines.length; i++) {
          var s = lines[i].trim();
          if (!s) continue;
          if (s.charAt(0) === "#") continue;
          if (s.indexOf("//") === 0) continue;
          if (s === "{" || s === "}" || s === "[" || s === "]") continue;
          if (s.indexOf("- ") === 0) s = s.slice(2).trim();
          var key = null, value = "";
          if (s.indexOf("--") === 0) {
            var rest = s.slice(2).trim();
            var eq = rest.indexOf("=");
            if (eq >= 0) { key = rest.slice(0, eq); value = rest.slice(eq + 1); }
            else {
              var parts = rest.split(/\s+/);
              key = parts[0];
              value = parts.length > 1 ? parts.slice(1).join(" ") : "true";
            }
          } else {
            var ei = s.indexOf("="), ci = s.indexOf(":");
            var cut = -1;
            if (ei >= 0 && ci >= 0) cut = Math.min(ei, ci);
            else if (ei >= 0) cut = ei;
            else if (ci >= 0) cut = ci;
            if (cut < 0) continue;
            key = s.slice(0, cut);
            value = s.slice(cut + 1);
          }
          key = cleanToken(key);
          value = cleanToken(value);
          if (!key) continue;
          var norm = normalizeKey(key);
          var kind = classify(norm);
          entries.push({
            line: i + 1,
            rawKey: key,
            norm: norm,
            kind: kind,
            displayKey: kind && DISPLAY[kind] ? DISPLAY[kind] : key,
            value: value
          });
        }
        return entries;
      }

      function isTruthy(v) {
        var t = String(v).trim().toLowerCase();
        return t === "true" || t === "yes" || t === "on" || t === "1";
      }
      function isFalsy(v) {
        var t = String(v).trim().toLowerCase();
        return t === "false" || t === "no" || t === "off" || t === "0";
      }
      function firstKind(entries, kind) {
        for (var i = 0; i < entries.length; i++) if (entries[i].kind === kind) return entries[i];
        return null;
      }
      function countFindings(findings) {
        var c = { CRITICAL: 0, WARNING: 0, NOTE: 0 };
        findings.forEach(function (f) { c[f.severity]++; });
        return c;
      }

      /* ---------- The audit ---------- */
      function auditConfig(text) {
        var entries = parseConfig(text);
        var recognized = entries.filter(function (e) { return e.kind !== null; });
        var findings = [];
        function add(sev, line, key, msg) {
          findings.push({ severity: sev, line: line, key: key, message: msg });
        }

        if (recognized.length < 3) {
          add("NOTE", null, "config",
            "Only " + recognized.length + " recognizable config key(s) found — at least 3 are needed to grade a config. Fix: paste the server flags, environment lines, or workspace settings (host, port, access auth code, and so on) and audit again.");
          return finish("NOT ENOUGH TO GRADE", findings, recognized.length);
        }

        /* Host / bind address */
        var hostE = firstKind(entries, "host");
        var localhostOnly = false;
        if (hostE) {
          var hv = hostE.value.trim().toLowerCase();
          if (hv === "0.0.0.0" || hv === "::" || hv === "*" || hv === "[::]") {
            add("CRITICAL", hostE.line, hostE.displayKey,
              "Host is bound to all network interfaces (" + hv + "), so anyone who can reach this machine can reach the workspace server. Fix: bind to 127.0.0.1 for local-only use, or place the server behind a firewalled, authenticated reverse proxy.");
          } else if (hv === "127.0.0.1" || hv === "localhost" || hv === "::1" || hv === "[::1]") {
            localhostOnly = true;
            add("NOTE", hostE.line, hostE.displayKey,
              "Host is bound to localhost only (" + hv + "), so the server is not reachable from other machines on the network.");
          }
        }

        /* Access auth code */
        var authE = firstKind(entries, "accessAuthCode");
        if (!authE) {
          add("CRITICAL", null, "accessAuthCode",
            "No access auth code was found anywhere in the pasted config. Without one, anyone who can reach the server can open the workspace. Fix: set a long, random access auth code (16 or more characters) that you do not reuse anywhere else.");
        } else {
          var av = authE.value;
          if (WEAK_AUTH_VALUES.indexOf(av.toLowerCase()) >= 0) {
            add("CRITICAL", authE.line, authE.displayKey,
              "The access auth code matches a known example or weak value that anyone can guess (value not shown). Fix: replace it with a long, random code of 16 or more characters that has never been published or shared.");
          }
          if (av.length < 12) {
            add("CRITICAL", authE.line, authE.displayKey,
              "The access auth code is too short — value length " + av.length + " (value not shown). Short codes fall quickly to guessing. Fix: use at least 16 random characters.");
          } else if (av.length <= 15) {
            add("WARNING", authE.line, authE.displayKey,
              "The access auth code is usable but short — value length " + av.length + " (value not shown). Fix: lengthen it to 16 or more random characters.");
          } else {
            add("NOTE", authE.line, authE.displayKey,
              "Access auth code is present with value length " + av.length + " (value not shown), which meets the 16+ length recommendation. This tool cannot tell whether the code itself is actually secret.");
          }
        }

        /* Plaintext secrets: any token / secret / password value, by key + line + length only */
        entries.forEach(function (e) {
          if ((e.kind === "secret" || e.kind === "apiToken" || e.kind === "cloudToken") && e.value.length > 0) {
            add("CRITICAL", e.line, e.displayKey,
              "A plaintext secret value sits in the config: " + e.displayKey + " at line " + e.line + ", value length " + e.value.length + " — value not shown. Anyone who can read or copy this config gets the credential. Fix: move the value into an environment variable or a secret store, and rotate it if it was ever shared.");
          }
        });

        /* Port */
        var portE = firstKind(entries, "port");
        if (portE) {
          var pv = portE.value.trim();
          if (!/^\d+$/.test(pv) || parseInt(pv, 10) < 1 || parseInt(pv, 10) > 65535) {
            add("WARNING", portE.line, portE.displayKey,
              "The port value \"" + pv + "\" is not a valid port — it must be a whole number from 1 to 65535, or the server may fail to start or listen somewhere unexpected. Fix: set a numeric port, for example 6806.");
          }
        }

        /* Protocol: http with no https/ssl/tls, and not localhost-only */
        var protoE = firstKind(entries, "protocol");
        var secureOn = entries.some(function (e) { return e.kind === "secureTransport" && isTruthy(e.value); });
        if (protoE) {
          var protoVal = protoE.value.trim().toLowerCase();
          if (protoVal === "http" && !secureOn && !localhostOnly) {
            add("WARNING", protoE.line, protoE.displayKey,
              "The config uses plain http with no https/ssl/tls enabled, and the host is not localhost-only, so logins and the auth code cross the network unencrypted. Fix: enable https (directly or through a TLS-terminating reverse proxy), or bind the host to localhost only.");
          } else if (protoVal === "https") {
            add("NOTE", protoE.line, protoE.displayKey,
              "Protocol is https, so traffic is encrypted in transit.");
          }
        }

        /* Read-only off + publish on */
        var roE = firstKind(entries, "readonly");
        var pubE = firstKind(entries, "publishEnabled");
        if (roE && pubE && isFalsy(roE.value) && isTruthy(pubE.value)) {
          add("WARNING", pubE.line, pubE.displayKey,
            "Read-only mode is off while publishing is enabled, so the published workspace can be changed through the server instead of staying a fixed snapshot. Fix: turn read-only mode on for a published workspace, or disable publishing.");
        }

        findings.sort(function (a, b) {
          var la = a.line == null ? 9999 : a.line;
          var lb = b.line == null ? 9999 : b.line;
          return la - lb;
        });

        var counts = countFindings(findings);
        var verdict = counts.CRITICAL > 0 ? "DO NOT DEPLOY"
          : counts.WARNING > 0 ? "DEPLOY WITH FIXES"
          : "SAFE TO DEPLOY";
        return finish(verdict, findings, recognized.length);
      }

      function finish(verdict, findings, recognizedCount) {
        return {
          verdict: verdict,
          findings: findings,
          counts: countFindings(findings),
          recognized: recognizedCount
        };
      }

      /* ---------- Output builders (secrecy-safe by construction) ---------- */
      var TOOL_NAME = "J-Dawgs SiYuan Server Config Safety Auditor™";

      function lineLabel(f) { return f.line == null ? "no line" : "line " + f.line; }

      function buildReport(r) {
        var out = [];
        out.push(TOOL_NAME);
        out.push("Verdict: " + r.verdict);
        out.push("Recognized config keys: " + r.recognized);
        out.push("Findings: " + r.counts.CRITICAL + " critical, " + r.counts.WARNING + " warning, " + r.counts.NOTE + " note");
        out.push("");
        if (r.findings.length === 0) out.push("No findings.");
        r.findings.forEach(function (f) {
          out.push("[" + f.severity + "] " + lineLabel(f) + " — " + f.key + ": " + f.message);
        });
        return out.join("\n");
      }

      function buildJSON(r) {
        return JSON.stringify({
          tool: TOOL_NAME,
          verdict: r.verdict,
          counts: { critical: r.counts.CRITICAL, warning: r.counts.WARNING, note: r.counts.NOTE },
          findings: r.findings.map(function (f) {
            return { severity: f.severity, line: f.line, key: f.key, message: f.message };
          })
        }, null, 2);
      }

      function escapeHtml(s) {
        return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
          .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
      }

      function verdictClass(v) {
        if (v === "SAFE TO DEPLOY") return "v-safe";
        if (v === "DEPLOY WITH FIXES") return "v-fixes";
        if (v === "DO NOT DEPLOY") return "v-no";
        return "v-none";
      }

      function buildFindingsHTML(r) {
        var html = '<div class="verdict ' + verdictClass(r.verdict) + '">' + escapeHtml(r.verdict) +
          "<small>" + r.counts.CRITICAL + " critical · " + r.counts.WARNING + " warning · " + r.counts.NOTE +
          " note · " + r.recognized + " recognized config keys</small></div>";
        if (r.findings.length) {
          html += '<ul class="findings">';
          r.findings.forEach(function (f) {
            html += '<li><span class="sev sev-' + f.severity + '">' + f.severity + '</span>' +
              '<span class="loc">' + (f.line == null ? "No line" : "Line " + f.line) + " · " + escapeHtml(f.key) + "</span>" +
              "<p>" + escapeHtml(f.message) + "</p></li>";
          });
          html += "</ul>";
        }
        return html;
      }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-siyuan-server-config-safety-auditor',
  name: 'J-Dawgs SiYuan Server Config Safety Auditor',
  description: 'Host tools only tell you the server started; ours grades a pasted SiYuan server config offline into one deploy verdict — secrets by key name/line/length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
