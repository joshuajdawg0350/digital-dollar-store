'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs SNMP Agent Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var WORKED_EXAMPLE = [
          "# Worked example - risky snmpd.conf",
          "agentAddress udp:161",
          "rocommunity public default",
          "rwcommunity private",
          "com2sec v1reader default Tr0picThunder",
          "syscontact admin@example.com",
          "syslocation Rack 7, lab",
          "extend diskcheck /usr/local/bin/check_disk.sh"
        ].join("\n");

        var HARDENED_EXAMPLE = [
          "# Hardened example - SNMPv3 only",
          "agentAddress udp:127.0.0.1:161",
          "createUser netops SHA AuthPhrase-one-234 AES PrivPhrase-two-234",
          "rouser netops authPriv",
          "syscontact netops@example.com",
          "syslocation Data center, Row 4"
        ].join("\n");

        var TOOL_PITCH = "J-Dawgs SNMP Agent Config Safety Auditor\u2122 \u2014 paste a snmpd.conf, get one deploy verdict (SAFE TO DEPLOY / DEPLOY WITH FIXES / DO NOT DEPLOY) with line-numbered findings: default communities, read-write exposure, and protocol posture graded offline in the browser. Nothing uploaded, nothing saved. AI Tool Store: https://muse.ai/s/ai-tool-store-xng6xkxwjkxl2xab/UoF72OkKI7j33Q2ITxmrZyIr4nv40QtYfj2AgESh_k8 \u00b7 J-Dawgs Agent Exchange: https://muse.ai/s/j-dawgs-agent-exchange-ih6xlnihzxdhxc/ZbleqxFHRE0NcswaBkyN13y9lLp5rPAgHTb6t8ii-PY";

        var KNOWN = {};
        ("agentaddress agentxperms agentxsocket rocommunity rwcommunity rocommunity6 rwcommunity6 " +
         "com2sec com2sec6 group access view included createduser createuser rouser rwuser user " +
         "syscontact syslocation sysname sysdescr sysservices sysobjectid extend extend-sh exec pass pass_persist " +
         "proxy include master subagent trapsink trap2sink informsink trapsess trapcommunity authtrapenable " +
         "snmpenableauthentrapenable linkupdownnotifications defaultmonitors monitor notificationlog dlmod load " +
         "override proc procfix disk diskpercent memory swap file logmatch setevent notificationevent engineid " +
         "exactengineid oldengineid iquerysecname iqueryseclevel persistentdirectory tempfilepattern leavepidfile " +
         "serversendbuf serverrecvbuf clientsendbuf clientrecvbuf notokenwarnings strictcommentfilter norangecheck " +
         "dumppacket donotfork donotlog pidfile clientaddr defaultport agentsecname dontlogtcpwrappersconnects " +
         "mibs mibdirs mibreplacewithlatest miballowunderline mibcommentterm mibwarninglevel printfailures " +
         "logtimestamp outputtimestamp addlabelstooids sysortable agentxaddress agentxtimeout agentxretries " +
         "v1trapaddress sendv2ctrapsink sendv1trap noauthaccessnotification logoption smquery sming versioninfo " +
         "includealldisks configinstdir workdir maxgetbulkresponses maxgetbulkrepeats").split(/\s+/).forEach(function (d) {
          KNOWN[d] = true;
        });

        function maskSecret(s) {
          if (s == null) return "";
          var v = String(s);
          var head = v.slice(0, 2);
          return head + "\u2022\u2022\u2022 (" + v.length + " chars)";
        }
        function stripQuotes(t) {
          if (t.length >= 2 && ((t.charAt(0) === '"' && t.charAt(t.length - 1) === '"') || (t.charAt(0) === "'" && t.charAt(t.length - 1) === "'"))) {
            return t.slice(1, -1);
          }
          return t;
        }
        function tokensOf(line) {
          return line.trim().split(/\s+/).filter(function (t) { return t.length > 0; });
        }
        function basename(p) {
          var parts = String(p).split("/");
          return parts[parts.length - 1] || String(p);
        }

        var WORLD_SOURCES = { "default": true, "0.0.0.0/0": true, "::/0": true, "0.0.0.0": true, "::": true, "world": true, "any": true };

        function audit(text) {
          var findings = [];
          function add(sev, line, dir, msg) {
            findings.push({ sev: sev, line: line, dir: dir, msg: msg });
          }

          var rawLines = String(text == null ? "" : text).split(/\r?\n/);
          var communityDefs = {}; // exact community string -> [{line, dir}]
          var hasSysContact = false, hasSysLocation = false;
          var hasAgentAddress = false;
          var parsedLines = 0;

          function noteCommunity(comm, line, dir) {
            if (!comm) return;
            if (!communityDefs[comm]) communityDefs[comm] = [];
            communityDefs[comm].push({ line: line, dir: dir });
          }
          function defaultCheck(comm, line, dir) {
            if (comm === "public" || comm === "private") {
              add("BLOCKER", line, dir, "Shipped-default community string " + maskSecret(comm) + " \u2014 anyone who knows SNMP defaults can use it. Replace it with a long, unique community or move to SNMPv3.");
            }
          }
          function v12cWarn(line, dir) {
            add("WARNING", line, dir, "SNMPv1/v2c community access \u2014 community strings travel the wire in plaintext, readable by anyone who can see the traffic.");
          }
          // Extract community for ro/rw style lines: first token after directive, skipping -v style flags is not needed for common shapes.
          function communityFrom(tokens) {
            var idx = 1;
            if (tokens[idx] && tokens[idx] === "-v") idx += 2;
            return tokens[idx] ? stripQuotes(tokens[idx]) : null;
          }
          function sourceFrom(tokens) {
            var idx = 1;
            if (tokens[idx] && tokens[idx] === "-v") idx += 2;
            var src = tokens[idx + 1];
            if (src && src.charAt(0) === "-") return null;
            return src || null;
          }
          function hasView(tokens) {
            for (var i = 0; i < tokens.length; i++) {
              if (tokens[i] === "-V" || tokens[i].indexOf("-V") === 0) return true;
            }
            return false;
          }

          for (var i = 0; i < rawLines.length; i++) {
            var lineNo = i + 1;
            var raw = rawLines[i];
            var trimmed = raw.trim();
            if (trimmed === "" || trimmed.charAt(0) === "#") continue;
            var tokens = tokensOf(raw);
            var dirRaw = tokens[0];
            var dir = dirRaw.toLowerCase();

            if (!KNOWN[dir]) {
              add("NOTPARSED", lineNo, dirRaw, "Line does not match any known snmpd.conf directive shape \u2014 reported as NOT PARSED, not guessed.");
              continue;
            }
            parsedLines++;

            if (dir === "syscontact") hasSysContact = true;
            if (dir === "syslocation") hasSysLocation = true;

            if (dir === "rocommunity" || dir === "rocommunity6") {
              var rc = communityFrom(tokens);
              noteCommunity(rc, lineNo, dir);
              defaultCheck(rc, lineNo, dir);
              v12cWarn(lineNo, dir);
              var src = sourceFrom(tokens);
              if ((!src || WORLD_SOURCES[src]) && !hasView(tokens)) {
                add("BLOCKER", lineNo, dir, "Read-only community " + maskSecret(rc) + " is reachable from " + (src ? "source \u201C" + src + "\u201D (world scope)" : "any source (no source restriction)") + " with no view restriction \u2014 the whole MIB tree is readable from anywhere that can reach the agent.");
              } else if (src && !WORLD_SOURCES[src]) {
                add("GOOD", lineNo, dir, "Read access is restricted to source \u201C" + src + "\u201D.");
              }
            }
            else if (dir === "rwcommunity" || dir === "rwcommunity6") {
              var wc = communityFrom(tokens);
              noteCommunity(wc, lineNo, dir);
              defaultCheck(wc, lineNo, dir);
              v12cWarn(lineNo, dir);
              var wsrc = sourceFrom(tokens);
              if (!wsrc || WORLD_SOURCES[wsrc]) {
                add("BLOCKER", lineNo, dir, "Read-write SNMP access is enabled with community " + maskSecret(wc) + " and " + (wsrc ? "source \u201C" + wsrc + "\u201D (world scope)" : "no source restriction") + " \u2014 escalated: anyone who learns the community can SET values on this device from anywhere. Remove read-write community access; use SNMPv3 authPriv if writes are truly required.");
              } else {
                add("BLOCKER", lineNo, dir, "Read-write SNMP access is enabled with community " + maskSecret(wc) + " (source restricted to \u201C" + wsrc + "\u201D). Read-write community access can reconfigure the device \u2014 remove it unless it is strictly required.");
              }
            }
            else if (dir === "com2sec" || dir === "com2sec6") {
              // com2sec [-Cn context] secname source community  => community is the last token.
              var comm = tokens.length >= 2 ? stripQuotes(tokens[tokens.length - 1]) : null;
              noteCommunity(comm, lineNo, dir);
              defaultCheck(comm, lineNo, dir);
              v12cWarn(lineNo, dir);
            }
            else if (dir === "group") {
              for (var g = 1; g < tokens.length; g++) {
                if (tokens[g] === "v1" || tokens[g] === "v2c") {
                  v12cWarn(lineNo, dir);
                  break;
                }
              }
            }
            else if (dir === "agentaddress") {
              hasAgentAddress = true;
              var specs = [];
              for (var a = 1; a < tokens.length; a++) {
                tokens[a].split(",").forEach(function (s) { if (s) specs.push(s); });
              }
              var anyAll = false, anyLocal = false, anySpecific = false, allDetail = "", specificDetail = "";
              specs.forEach(function (spec) {
                var s = spec;
                var ci = s.indexOf(":");
                var rest = ci >= 0 ? s.slice(ci + 1) : s;
                var host = null;
                if (/^\d+$/.test(rest)) { host = null; }
                else if (rest.indexOf(":") >= 0) { host = rest.slice(0, rest.lastIndexOf(":")).replace(/^\[|\]$/g, ""); }
                else { host = rest; }
                if (host === null || host === "" || host === "0.0.0.0" || host === "::" || host === "*") { anyAll = true; allDetail = spec; }
                else if (host === "127.0.0.1" || host === "localhost" || host === "::1") { anyLocal = true; }
                else { anySpecific = true; specificDetail = host; }
              });
              if (anyAll) {
                add("WARNING", lineNo, dir, "agentAddress \u201C" + allDetail + "\u201D listens on all interfaces \u2014 the agent answers SNMP from any network that can reach it. Bind it to a management address or localhost.");
              } else if (anyLocal && !anySpecific) {
                add("GOOD", lineNo, dir, "agentAddress is bound to localhost only \u2014 the agent is not reachable from the network.");
              } else if (anySpecific) {
                add("GOOD", lineNo, dir, "agentAddress is bound to a specific address (" + specificDetail + ") rather than all interfaces.");
              }
            }
            else if (dir === "createuser") {
              // Skip leading options: -e ENGINEID pair; username is next non-option token.
              var rest = tokens.slice(1);
              var u = 0;
              while (u < rest.length && rest[u].charAt(0) === "-") { u += (rest[u] === "-e" ? 2 : 1); }
              var protoTokens = rest.slice(u + 1);
              var authProto = null, privProto = null;
              for (var p = 0; p < protoTokens.length; p++) {
                var up = protoTokens[p].toUpperCase();
                if (protoTokens[p] === "-a" && protoTokens[p + 1]) { authProto = protoTokens[p + 1].toUpperCase(); }
                if (protoTokens[p] === "-x" && protoTokens[p + 1]) { privProto = protoTokens[p + 1].toUpperCase(); }
                if (!authProto && /^(MD5|SHA|SHA-?\d+)$/.test(up)) authProto = up;
                else if (!privProto && /^(DES|AES|AES-?\d+C?)$/.test(up)) privProto = up;
              }
              if (authProto === "MD5") {
                add("WARNING", lineNo, dir, "createUser uses MD5 authentication \u2014 MD5 is weak for SNMPv3 auth. Use SHA (SHA-256 or better). Passphrase not shown.");
              }
              if (privProto === "DES") {
                add("WARNING", lineNo, dir, "createUser uses DES privacy \u2014 DES is weak encryption. Use AES privacy. Passphrase not shown.");
              }
              if (!authProto) {
                add("WARNING", lineNo, dir, "createUser has no authentication protocol (noauth posture) \u2014 an SNMPv3 user without authentication gets no identity assurance. Add SHA authentication and AES privacy.");
              } else if (!privProto && privProto !== "DES") {
                if (privProto === null) {
                  add("WARNING", lineNo, dir, "createUser authenticates (" + authProto + ") but has no privacy protocol (authNoPriv posture) \u2014 traffic is authenticated but sent unencrypted. Add AES privacy for authPriv.");
                }
              }
              if (authProto && /^SHA/.test(authProto) && privProto && /^AES/.test(privProto)) {
                add("GOOD", lineNo, dir, "createUser uses " + authProto + " authentication with " + privProto + " privacy (authPriv) \u2014 the strong SNMPv3 posture. Passphrases not shown.");
              }
            }
            else if (dir === "rouser" || dir === "rwuser") {
              var lvl = null;
              for (var r = 1; r < tokens.length; r++) {
                var lt = tokens[r].toLowerCase();
                if (lt === "noauth") lvl = "noauth";
                else if (lt === "auth" || lt === "authnopriv") lvl = "auth";
                else if (lt === "priv" || lt === "authpriv") lvl = "priv";
              }
              if (lvl === "noauth") {
                add("WARNING", lineNo, dir, dir + " allows access with no authentication (noauth) \u2014 require authPriv.");
              } else if (lvl === "auth") {
                add("WARNING", lineNo, dir, dir + " requires authentication but not privacy (authNoPriv) \u2014 traffic is unencrypted. Require authPriv.");
              } else if (lvl === "priv") {
                add("GOOD", lineNo, dir, dir + " requires authPriv \u2014 authenticated and encrypted access.");
              }
              if (dir === "rwuser") {
                add("INFO", lineNo, dir, "rwuser grants an SNMPv3 user write access \u2014 keep the list of write users as short as possible.");
              }
            }
            else if (dir === "extend" || dir === "exec") {
              var prog = tokens[2] ? basename(stripQuotes(tokens[2])) : null;
              add("WARNING", lineNo, dir, dir + " runs an external command" + (prog ? " (\u201C" + prog + "\u201D)" : "") + " whenever its OID is polled \u2014 the command runs with the agent's privileges. Confirm it is expected and cannot be influenced by polled input.");
            }
            else if (dir === "pass" || dir === "pass_persist") {
              var pprog = tokens[2] ? basename(stripQuotes(tokens[2])) : null;
              add("WARNING", lineNo, dir, dir + " hands an OID subtree to an external command" + (pprog ? " (\u201C" + pprog + "\u201D)" : "") + " \u2014 it runs with the agent's privileges and can answer (or alter) those OIDs.");
            }
            else if (dir === "proxy") {
              add("WARNING", lineNo, dir, "proxy forwards SNMP requests to another agent \u2014 that agent's exposure and credentials are outside this config. Confirm the forwarding is intended and the path is trusted.");
            }
          }

          if (!hasAgentAddress && parsedLines > 0) {
            add("WARNING", null, "agentAddress", "No agentAddress line found \u2014 the Net-SNMP default is to listen on all interfaces at UDP 161. Add an explicit agentAddress to control where the agent listens.");
          }
          if (!hasSysContact) {
            add("INFO", null, "syscontact", "No syscontact set \u2014 responders cannot tell who owns this agent from the config (operational hygiene).");
          }
          if (!hasSysLocation) {
            add("INFO", null, "syslocation", "No syslocation set \u2014 the agent's location is undocumented in the config (operational hygiene).");
          }

          Object.keys(communityDefs).forEach(function (comm) {
            var defs = communityDefs[comm];
            if (defs.length > 1) {
              var lines = defs.map(function (d) { return d.line; });
              add("WARNING", lines[0], defs[0].dir, "Duplicate community definition: " + maskSecret(comm) + " is defined " + defs.length + " times (lines " + lines.join(", ") + ") \u2014 duplicates drift apart and widen access quietly. Keep one definition per community.");
            }
          });

          var order = { BLOCKER: 0, WARNING: 1, NOTPARSED: 2, INFO: 3, GOOD: 4 };
          findings.sort(function (x, y) {
            if (order[x.sev] !== order[y.sev]) return order[x.sev] - order[y.sev];
            var xl = x.line == null ? 99999 : x.line, yl = y.line == null ? 99999 : y.line;
            return xl - yl;
          });

          var counts = { BLOCKER: 0, WARNING: 0, INFO: 0, GOOD: 0, NOTPARSED: 0 };
          findings.forEach(function (f) { counts[f.sev]++; });

          var verdict;
          if (counts.BLOCKER > 0) verdict = "DO NOT DEPLOY";
          else if (counts.WARNING > 0 || counts.NOTPARSED > 0) verdict = "DEPLOY WITH FIXES";
          else verdict = "SAFE TO DEPLOY";

          return { verdict: verdict, counts: counts, findings: findings, totalLines: rawLines.length, parsedLines: parsedLines };
        }

        function reportText(result) {
          var c = result.counts;
          var out = [];
          out.push("J-Dawgs SNMP Agent Config Safety Auditor\u2122 \u2014 audit report");
          out.push("Verdict: " + result.verdict);
          out.push("Findings: " + c.BLOCKER + " BLOCKER \u00b7 " + c.WARNING + " WARNING \u00b7 " + c.NOTPARSED + " NOT PARSED \u00b7 " + c.INFO + " INFO \u00b7 " + c.GOOD + " GOOD");
          out.push("");
          result.findings.forEach(function (f) {
            var where = f.line == null ? "Config-wide" : "Line " + f.line;
            var sevLabel = f.sev === "NOTPARSED" ? "NOT PARSED" : f.sev;
            out.push("[" + sevLabel + "] " + where + " \u00b7 " + f.dir + " \u2014 " + f.msg);
          });
          out.push("");
          out.push("Limits: text audit of the pasted config only. No device was contacted, no credential was tested, and firewall reachability of UDP 161 cannot be seen from config text.");
          return out.join("\n");
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "WORKED_EXAMPLE": (typeof WORKED_EXAMPLE !== 'undefined' ? WORKED_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-snmp-agent-config-safety-auditortm',
  name: 'J-Dawgs SNMP Agent Config Safety Auditor',
  description: 'Grades a pasted snmpd.conf offline — default public/private communities, read-write exposure, SNMPv1/v2c posture — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "WORKED_EXAMPLE": __core["WORKED_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
