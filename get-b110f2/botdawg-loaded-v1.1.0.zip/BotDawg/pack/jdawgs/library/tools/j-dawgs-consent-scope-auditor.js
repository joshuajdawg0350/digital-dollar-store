'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Consent Scope Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the analyze function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        /* ================= lexicons ================= */
        var STOPWORDS = {};
        ("the a an and or of to for in on at by with from about into over under my your his her their our me you i it its this that these those is are was were be been can could may might shall should will would do does did have has had not no yes if then than as so such per via just only also any all one two").split(" ").forEach(function (w) { STOPWORDS[w] = true; });

        var VERBS = ("use post email send spend buy purchase create delete remove share publish message contact pay book upload download schedule register access read check fix list sell sign call text update edit invite charge refund order file submit transfer withdraw deposit reply forward announce advertise promote renew cancel subscribe join follow like comment review approve print ship open close move copy save draft write set change add run start stop hold pick choose").split(" ");

        var SERVICES = ("gmail venmo stripe facebook instagram youtube moltbook threads tiktok linkedin paypal zelle github dropbox whatsapp messenger shopify etsy ebay amazon calendar drive photos twitter x").split(" ");

        var VAGUE_TARGETS = { accounts: 1, account: 0, stuff: 1, things: 1, thing: 1, info: 1, information: 1, details: 1, everything: 1, anything: 1, whatever: 1 };

        /* ================= text helpers ================= */
        function norm(s) { return s.replace(/[’‘]/g, "'").replace(/[“”]/g, '"'); }
        function rawTokens(s) {
          var m = norm(s).toLowerCase().match(/[a-z]+/g);
          return m || [];
        }
        function stem(w) {
          if (w.length >= 4 && w.charAt(w.length - 1) === "s" && !/(ss|us|is)$/.test(w)) return w.slice(0, -1);
          return w;
        }
        function verbOf(tok) {
          var cands = [tok, stem(tok)];
          if (/ing$/.test(tok) && tok.length > 4) { cands.push(tok.slice(0, -3)); cands.push(tok.slice(0, -3) + "e"); }
          if (/ed$/.test(tok) && tok.length > 3) { cands.push(tok.slice(0, -2)); cands.push(tok.slice(0, -1)); }
          for (var i = 0; i < cands.length; i++) if (VERBS.indexOf(cands[i]) >= 0) return cands[i];
          return null;
        }
        function analyze(text) {
          var toks = rawTokens(text);
          var content = {}, verbs = {}, targets = {}, i, t, v;
          for (i = 0; i < toks.length; i++) {
            t = toks[i];
            v = verbOf(t);
            if (v) verbs[v] = true;
            if (!STOPWORDS[t]) content[stem(t)] = true;
            if (SERVICES.indexOf(t) >= 0) targets[t] = true;
          }
          /* capitalized words in the original (not the first word) are named targets */
          var words = norm(text).split(/\s+/);
          for (i = 1; i < words.length; i++) {
            var w = words[i].replace(/[^A-Za-z]/g, "");
            if (/^[A-Z][a-z]+$/.test(w) || /^[A-Z]{2,}$/.test(w)) targets[w.toLowerCase()] = true;
          }
          /* "my X" targets */
          for (i = 0; i + 1 < toks.length; i++) {
            if (toks[i] === "my" && !STOPWORDS[toks[i + 1]]) targets[toks[i + 1]] = true;
          }
          var amt = norm(text).match(/\$\s*(\d[\d,]*(?:\.\d+)?)/);
          return {
            text: text, toks: toks, content: content, verbs: verbs, targets: targets,
            amount: amt ? parseFloat(amt[1].replace(/,/g, "")) : null
          };
        }
        function overlap(a, b) {
          var n = 0, k;
          for (k in a) if (b[k]) n++;
          return n;
        }
        function setList(set) { var r = []; for (var k in set) r.push(k); return r; }
        function q(s) { return "“" + s + "”"; }

        /* ================= statement extraction ================= */
        function splitStatements(text) {
          var out = [];
          norm(text).split(/\n+/).forEach(function (line) {
            line = line.replace(/^(user|human|joshua|principal|boss|owner|assistant|agent|ai)\s*:\s*/i, "");
            line.split(/(?<=[.!?;])\s+/).forEach(function (p) {
              p = p.trim().replace(/[;]+$/, "");
              if (p.length > 2) out.push(p);
            });
          });
          return out;
        }

        var DENY_RE = /\b(don'?t|do not|never|not allowed|forbidden|hands off)\b/i;
        var DENY_NO_RE = /\bno\s+(emailing|posting|spending|creating|buying|selling|sharing|sending|accounts?|access)\b/i;
        var GRANT_RE = /(you can|you can also|you may|go ahead|feel free|permission|authori[sz]|allowed|okay to|ok to|it'?s fine|that'?s fine|use my|help yourself|be my guest|sure,|yes,)/i;
        var VAGUE_FLAVOR_RE = /\b(ok|okay|fine|sure|sounds good|whatever|go for it|handle it|take care of)\b/i;

        function extractCap(s) {
          var m = norm(s).match(/(up to|under|at most|no more than|max(?:imum)? of)\s*\$\s*(\d[\d,]*(?:\.\d+)?)/i);
          if (m) return { value: parseFloat(m[2].replace(/,/g, "")), quote: m[0] };
          return null;
        }
        function extractCondition(s) {
          var pats = [/(if [^.,;]+)/i, /(as long as [^.,;]+)/i, /(provided(?: that)? [^.,;]+)/i, /(unless [^.,;]+)/i, /(only if [^.,;]+)/i, /(when [^.,;]+)/i];
          for (var i = 0; i < pats.length; i++) { var m = norm(s).match(pats[i]); if (m) return m[1].trim(); }
          return null;
        }
        function extractBound(s) {
          var m = norm(s).match(/(until [^.,;]+)/i);
          if (m) return m[1].trim();
          var pats = [/\bthis week\b/i, /\bthis month\b/i, /\bthis weekend\b/i, /\bthis morning\b/i, /\bthis afternoon\b/i, /\btonight\b/i, /\btoday\b/i, /\bfor now\b/i, /\bby (monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b/i];
          for (var i = 0; i < pats.length; i++) { m = norm(s).match(pats[i]); if (m) return m[0]; }
          return null;
        }
        function extractLimits(s) {
          var out = [], m;
          var pats = [/(only for [^.,;]+)/i, /(only [^.,;]+)/i, /(just this once)/i, /(this one time)/i, /(show me [^.,;]+ first)/i, /(ask me first)/i, /(check with me[^.,;]*)/i];
          for (var i = 0; i < pats.length; i++) {
            m = norm(s).match(pats[i]);
            if (m && out.indexOf(m[1].trim()) < 0) out.push(m[1].trim());
          }
          return out;
        }
        function extractPurpose(s, a) {
          var m = norm(s).match(/\b(to|for|about)\s+([^.,;]+)/i);
          if (!m) return null;
          var clause = m[2].trim();
          if (clause.length < 3) return null;
          /* The statement's own first verb, so a purpose clause that merely restates
             it ("…to use my stuff") doesn't count as scope on its own. */
          var firstVerb = null, i, t;
          for (i = 0; i < a.toks.length; i++) { var v0 = verbOf(a.toks[i]); if (v0) { firstVerb = v0; break; } }
          var ctoks = rawTokens(clause), anchor = {}, all = {}, leadSeen = false;
          for (i = 0; i < ctoks.length; i++) {
            t = ctoks[i];
            if (STOPWORDS[t]) continue;
            all[stem(t)] = true;
            var isLead = !leadSeen; leadSeen = true;
            if (VAGUE_TARGETS[t]) continue;
            if (isLead && verbOf(t) && verbOf(t) === firstVerb) continue;
            anchor[stem(t)] = true;
          }
          return { quote: m[0].trim(), tokens: all, anchorTokens: anchor };
        }
        function hasAnchor(s, a, purpose) {
          if (a.amount !== null) return true;
          var svc, k;
          for (k in a.targets) {
            if (SERVICES.indexOf(k) >= 0) return true;
          }
          /* capitalized named target */
          var words = norm(s).split(/\s+/);
          for (var i = 1; i < words.length; i++) {
            var w = words[i].replace(/[^A-Za-z]/g, "");
            if (/^[A-Z]/.test(w)) return true;
          }
          /* concrete "my X" target (not a vague one) */
          for (var j = 0; j + 1 < a.toks.length; j++) {
            if (a.toks[j] === "my" && !STOPWORDS[a.toks[j + 1]] && !VAGUE_TARGETS[a.toks[j + 1]]) return true;
          }
          if (purpose && setList(purpose.anchorTokens).length >= 2) return true;
          return false;
        }

        function classifyStatement(text) {
          var a = analyze(text);
          var purpose = extractPurpose(text, a);
          var base = {
            text: text, a: a, purpose: purpose,
            cap: extractCap(text), condition: extractCondition(text),
            bound: extractBound(text), limits: extractLimits(text)
          };
          var hasVerbOrTarget = setList(a.verbs).length > 0 || setList(a.targets).length > 0;
          /* An imperative instruction ("Spend up to $20…", "Post the update…") is a grant too. */
          var imperative = a.toks.length > 0 && verbOf(a.toks[0]) !== null && text.indexOf("?") < 0;
          var positivePhrase = /\byou can\b|\byou may\b|\bgo ahead\b|\bfeel free\b|\buse my\b/i.test(text);

          if ((DENY_RE.test(text) || DENY_NO_RE.test(text)) && hasVerbOrTarget && !positivePhrase) {
            base.cls = "denial"; base.label = "EXPLICIT DENIAL"; return base;
          }
          if (GRANT_RE.test(text) || imperative) {
            if (base.condition) { base.cls = "conditional"; base.label = "CONDITIONAL GRANT"; return base; }
            if (base.bound) { base.cls = "stale"; base.label = "EXPIRED / STALE GRANT"; return base; }
            if (hasAnchor(text, a, purpose)) { base.cls = "grant"; base.label = "EXPLICIT GRANT"; return base; }
            base.cls = "ambiguous"; base.label = "AMBIGUOUS"; return base;
          }
          if (VAGUE_FLAVOR_RE.test(text) && hasVerbOrTarget === false || VAGUE_FLAVOR_RE.test(text) && /whatever|handle it|take care of|go for it/i.test(text)) {
            base.cls = "ambiguous"; base.label = "AMBIGUOUS"; return base;
          }
          return null;
        }

        /* ================= action audit ================= */
        function matchScore(aa, sa) {
          var v = overlap(aa.verbs, sa.verbs);
          var c = overlap(aa.content, sa.content);
          return { verbs: v, content: c, score: v * 3 + c, qualifies: v >= 1 || c >= 2 };
        }

        function auditAction(actionText, stmts) {
          var aa = analyze(actionText);
          var i, st, m;

          /* 1 — denials first */
          for (i = 0; i < stmts.length; i++) {
            st = stmts[i];
            if (st.cls !== "denial") continue;
            m = matchScore(aa, st.a);
            if (!m.qualifies) continue;
            if (st.purpose && setList(st.purpose.anchorTokens).length >= 1) {
              var pOver = overlap(aa.content, st.purpose.tokens);
              if (pOver === 0) continue; /* denial was scoped to something else */
            }
            return {
              action: actionText, verdict: "denied", label: "DENIED", stmt: st,
              reason: "Denied by the statement " + q(st.text) + " — the matched words are " +
                (m.verbs ? "the action verb(s) " + setList(aa.verbs).filter(function (v) { return st.a.verbs[v]; }).map(q).join(", ") : "the shared scope words") + "."
            };
          }

          /* 2 — grants (explicit, stale, conditional) */
          var best = null, bestM = null;
          for (i = 0; i < stmts.length; i++) {
            st = stmts[i];
            if (st.cls !== "grant" && st.cls !== "stale" && st.cls !== "conditional") continue;
            m = matchScore(aa, st.a);
            if (!m.qualifies) continue;
            if (!best || m.score > bestM.score) { best = st; bestM = m; }
          }

          if (best) {
            /* dollar cap */
            if (best.cap && aa.amount !== null && aa.amount > best.cap.value) {
              return { action: actionText, verdict: "creep", label: "SCOPE CREEP", stmt: best,
                reason: "Resembles the grant " + q(best.text) + " but the amount $" + aa.amount + " exceeds its quoted limit " + q(best.cap.quote) + "." };
            }
            /* wider target: "all / every" against a specifically-named grant target */
            if (/\b(all|every)\b/i.test(actionText) && !/\b(all|every)\b/i.test(best.text) && setList(best.a.targets).length > 0 && bestM.verbs >= 1) {
              return { action: actionText, verdict: "creep", label: "SCOPE CREEP", stmt: best,
                reason: "The grant " + q(best.text) + " names a specific target (" + setList(best.a.targets).map(q).join(", ") + "), but this action widens it with " + q(norm(actionText).match(/\b(all|every)\b[^.,;]*/i)[0]) + "." };
            }
            /* stated-purpose scope */
            if (best.purpose && setList(best.purpose.anchorTokens).length >= 2 && bestM.verbs >= 1) {
              var po = overlap(aa.content, best.purpose.tokens);
              if (po === 0) {
                return { action: actionText, verdict: "creep", label: "SCOPE CREEP", stmt: best,
                  reason: "Uses the granted tool/target from " + q(best.text) + " but for a different purpose — nothing in the action matches its stated purpose " + q(best.purpose.quote) + "." };
              }
            }
            /* stale grant */
            if (best.cls === "stale") {
              if (/\b(tomorrow|next week|next month|next)\b/i.test(actionText)) {
                return { action: actionText, verdict: "creep", label: "SCOPE CREEP", stmt: best,
                  reason: "The only matching grant was time-bound — " + q(best.text) + " — with the bound " + q(best.bound) + ". This action sits outside that bound." };
              }
              return { action: actionText, verdict: "conditional", label: "CONDITIONAL", stmt: best,
                reason: "The only matching grant is time-bound (" + q(best.bound) + " in " + q(best.text) + ") and may have lapsed — its currency is unverified." };
            }
            /* conditional grant */
            if (best.cls === "conditional") {
              return { action: actionText, verdict: "conditional", label: "CONDITIONAL", stmt: best,
                reason: "Covered only under a condition that has not been verified: " + q(best.condition) + " (from " + q(best.text) + ")." };
            }
            return { action: actionText, verdict: "covered", label: "COVERED", stmt: best,
              reason: "Covered by " + q(best.text) + " — matched on " +
                (bestM.verbs ? "verb(s) " + setList(aa.verbs).filter(function (v) { return best.a.verbs[v]; }).map(q).join(", ") : "the shared scope words") +
                (best.cap ? ", within the cap " + q(best.cap.quote) : "") + "." };
          }

          /* 3 — ambiguous near-match: still NOT COVERED */
          for (i = 0; i < stmts.length; i++) {
            st = stmts[i];
            if (st.cls !== "ambiguous") continue;
            m = matchScore(aa, st.a);
            if (m.qualifies) {
              return { action: actionText, verdict: "notcovered", label: "NOT COVERED", stmt: st,
                reason: "The nearest statement is ambiguous — " + q(st.text) + " — with no clear scope. Ambiguous is never upgraded to a grant, so this action is not covered." };
            }
          }

          /* 4 — silence */
          return { action: actionText, verdict: "notcovered", label: "NOT COVERED", stmt: null,
            reason: "No statement in the history mentions anything like this action. Absence of a mention is never consent." };
        }

        /* ================= examples ================= */
        var EXAMPLE_A = {
          history: [
            "You can use my Gmail to fix the Moltbook claim.",
            "Spend up to $20 on listings, and show me anything bigger first.",
            "Don't create accounts in my name.",
            "You can post for me today.",
            "The weather in Springfield has been rough lately."
          ].join("\n"),
          actions: [
            "Use Gmail to check the Moltbook claim status",
            "Create a new vendor account in my name",
            "Spend $49 on a featured listing",
            "Post the launch recap tomorrow morning",
            "Delete the old backup files from the drive"
          ].join("\n")
        };
        var EXAMPLE_B = {
          history: [
            "You can use my Venmo to pay the printer for the flyers.",
            "You may email the client list about the schedule change.",
            "Go ahead and post the weekly update to the shop page."
          ].join("\n"),
          actions: [
            "Use Venmo to pay the printer for the flyers",
            "Email the client list about the schedule change",
            "Post the weekly update to the shop page"
          ].join("\n")
        };
  return { "analyze": (typeof analyze !== 'undefined' ? analyze : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_A": (typeof EXAMPLE_A !== 'undefined' ? EXAMPLE_A : undefined), "EXAMPLE_B": (typeof EXAMPLE_B !== 'undefined' ? EXAMPLE_B : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["analyze"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-consent-scope-auditor',
  name: 'J-Dawgs Consent Scope Auditor',
  description: 'Extracts granted/denied/conditional consent from a pasted history and checks each planned action — covered, denied, conditional, not covered, or scope creep',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["analyze"]) return { ok: false, output: null, summary: 'Extracted core has no analyze function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_A": __core["EXAMPLE_A"], "EXAMPLE_B": __core["EXAMPLE_B"] }
};
