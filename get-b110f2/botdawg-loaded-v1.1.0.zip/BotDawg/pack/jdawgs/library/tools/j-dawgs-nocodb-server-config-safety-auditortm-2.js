'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs NocoDB Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        /* ---------- Fixtures ---------- */

        /* The selectable risky example uses masked placeholder values: they
           still trigger the checks (by pattern and length), but no real-looking
           secret is ever rendered on this page. The self-test separately grades
           a secret-bearing fixture held only in memory to prove the outputs
           never echo a real secret value. */
        var RISKY = [
          "# NocoDB production config - risky sample (secret values masked)",
          "NC_AUTH_JWT_SECRET=example-jwt-secret-do-not-use",
          "NC_DB=pg://db.internal:5432?u=nocodb&p=••••••••••••••••&d=nocodb",
          "NC_PUBLIC_URL=http://nocodb.example.com",
          "PORT=8080",
          "HOST=0.0.0.0",
          "NC_ALLOW_LOCAL_HOOKS=true",
          "NC_SMTP_HOST=mail.example.com",
          "NC_SMTP_PASSWORD=••••••••••••••••••",
          "NC_REDIS_URL=redis://:•••••••••••••••••••@127.0.0.1:6379",
          "NC_INVITE_ONLY_SIGNUP=false",
          "NC_CORS_ALLOW_ORIGIN=*",
          "NC_DISABLE_TELE=true"
        ].join("\n");

        var SECRET_FIXTURE = [
          "# secret-bearing fixture - held in memory only, never displayed",
          "NC_AUTH_JWT_SECRET=supersecret",
          "NC_DB=pg://db.internal:5432?u=nocodb&p=PlantedDbPass123&d=nocodb",
          "NC_PUBLIC_URL=http://nocodb.example.com",
          "PORT=8080",
          "HOST=0.0.0.0",
          "NC_ALLOW_LOCAL_HOOKS=true",
          "NC_SMTP_HOST=mail.example.com",
          "NC_SMTP_PASSWORD=PlantedSmtpPass456",
          "NC_REDIS_URL=redis://:PlantedRedisPass789@127.0.0.1:6379",
          "NC_INVITE_ONLY_SIGNUP=false",
          "NC_CORS_ALLOW_ORIGIN=*",
          "NC_DISABLE_TELE=true"
        ].join("\n");

        var HARDENED = [
          "# NocoDB production config - hardened sample",
          "NC_AUTH_JWT_SECRET=9f2c7a41bd835e06a1c4f7902db58e63c07a15f92b4d81e6a03c5f7b29d841e6",
          "NC_DB=pg://db.internal:5432?u=nocodb&p=${NC_DB_PASSWORD}&d=nocodb",
          "NC_PUBLIC_URL=https://nocodb.example.com",
          "PORT=8080",
          "HOST=127.0.0.1",
          "NC_ALLOW_LOCAL_HOOKS=false",
          "NC_SMTP_HOST=mail.example.com",
          "NC_SMTP_PORT=465",
          "NC_SMTP_SECURE=true",
          "NC_SMTP_PASSWORD=${NC_SMTP_PASSWORD}",
          "NC_REDIS_URL=redis://:${NC_REDIS_PASSWORD}@127.0.0.1:6379",
          "NC_INVITE_ONLY_SIGNUP=true",
          "NC_CORS_ALLOW_ORIGIN=https://nocodb.example.com"
        ].join("\n");

        var GIBBERISH = "the quick brown fox jumps over\nlorem ipsum dolor sit amet\n12345 !!! ???\nnot a config at all";

        var PLANTED_SECRETS = ["supersecret", "PlantedDbPass123", "PlantedSmtpPass456", "PlantedRedisPass789"];

        /* ---------- Parsing ---------- */

        function parseConfig(text) {
          var entries = [];
          var lines = String(text || "").split(/\r?\n/);
          for (var i = 0; i < lines.length; i++) {
            var s = lines[i].trim();
            if (!s || s.charAt(0) === "#") continue;
            s = s.replace(/^export\s+/, "").replace(/^-\s+/, "");
            var m = s.match(/^([A-Za-z_][A-Za-z0-9_]*)\s*[:=]\s*(.*)$/);
            if (!m) continue;
            var v = m[2].trim();
            if (v.length >= 2 && ((v.charAt(0) === '"' && v.charAt(v.length - 1) === '"') || (v.charAt(0) === "'" && v.charAt(v.length - 1) === "'"))) {
              v = v.slice(1, -1);
            }
            entries.push({ key: m[1].toUpperCase(), value: v, line: i + 1 });
          }
          return entries;
        }

        function getEntry(entries, key) {
          for (var i = 0; i < entries.length; i++) if (entries[i].key === key) return entries[i];
          return null;
        }

        function isSecretRef(v) {
          if (!v) return false;
          if (/^\$\{[^}]+\}$/.test(v)) return true;
          if (/^\$[A-Za-z_][A-Za-z0-9_]*$/.test(v)) return true;
          if (/^(vault|file|secret|env):/i.test(v)) return true;
          return false;
        }

        var EXAMPLE_WORDS = ["secret", "supersecret", "password", "passwd", "changeme", "change-me", "jwtsecret", "jwt-secret", "mysecret", "default", "letmein", "123456"];
        function isExampleValue(v) {
          var lv = String(v).toLowerCase();
          if (EXAMPLE_WORDS.indexOf(lv) !== -1) return true;
          if (lv.indexOf("example") !== -1) return true;
          if (lv.indexOf("your_") === 0 || lv.indexOf("your-") === 0) return true;
          if (lv.indexOf("placeholder") !== -1 || lv.indexOf("todo") !== -1) return true;
          if (/^x{4,}$/.test(lv)) return true;
          return false;
        }

        function extractUrlPassword(v) {
          if (!v) return null;
          var m = v.match(/[?&]p=([^&\s]+)/);
          if (m) return m[1];
          m = v.match(/:\/\/[^:\/@\s]*:([^@\s]+)@/);
          if (m) return m[1];
          m = v.match(/[?&](?:password|passwd|pwd)=([^&\s]+)/i);
          if (m) return m[1];
          return null;
        }

        function truthy(v) { return /^(true|1|yes|on)$/i.test(String(v || "").trim()); }
        function falsy(v) { return /^(false|0|no|off)$/i.test(String(v || "").trim()); }

        /* ---------- Audit ---------- */

        var SEV_ORDER = { CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3, INFO: 4 };

        function audit(text) {
          var entries = parseConfig(text);
          var findings = [];
          var passed = [];
          function add(sev, line, key, issue, fix) {
            findings.push({ severity: sev, line: line, key: key, issue: issue, fix: fix });
          }
          function pass(key) { if (passed.indexOf(key) === -1) passed.push(key); }

          var recognized = 0;
          entries.forEach(function (e) {
            if (e.key.indexOf("NC_") === 0 || e.key === "PORT" || e.key === "HOST") recognized++;
          });

          /* NC_AUTH_JWT_SECRET */
          var jwt = getEntry(entries, "NC_AUTH_JWT_SECRET");
          if (!jwt || !jwt.value) {
            add("CRITICAL", jwt ? jwt.line : null, "NC_AUTH_JWT_SECRET",
              "NC_AUTH_JWT_SECRET is missing or empty. NocoDB signs login sessions with this secret; without a strong one you set yourself, sessions can be forged.",
              "Set NC_AUTH_JWT_SECRET to a random value of at least 32 characters from a password generator or secret manager, and restart the server.");
          } else if (isSecretRef(jwt.value)) {
            pass("NC_AUTH_JWT_SECRET");
          } else if (isExampleValue(jwt.value)) {
            add("CRITICAL", jwt.line, "NC_AUTH_JWT_SECRET",
              "NC_AUTH_JWT_SECRET is a known example/placeholder value (length " + jwt.value.length + "). Anyone who has seen the docs can sign valid session tokens for your instance.",
              "Replace it with a unique random secret of at least 32 characters that appears in no example, tutorial, or repository.");
          } else if (jwt.value.length < 32) {
            add("HIGH", jwt.line, "NC_AUTH_JWT_SECRET",
              "NC_AUTH_JWT_SECRET is only " + jwt.value.length + " characters long. Short secrets can be brute-forced offline against a captured session token.",
              "Regenerate NC_AUTH_JWT_SECRET at 32 characters or more (64 is a good target) and restart; existing sessions will need to sign in again.");
          } else {
            pass("NC_AUTH_JWT_SECRET");
          }

          /* NC_DB / NC_DB_URL */
          var db = getEntry(entries, "NC_DB") || getEntry(entries, "NC_DB_URL");
          if (!db || !db.value) {
            add("MEDIUM", null, "NC_DB",
              "NC_DB is not set. NocoDB falls back to its built-in local SQLite file for all of your data, which is easy to lose when a container or volume is recreated.",
              "Set NC_DB to a managed Postgres or MySQL connection string and back that database up.");
          } else {
            var dbPw = extractUrlPassword(db.value);
            if (dbPw && !isSecretRef(dbPw)) {
              add("HIGH", db.line, db.key,
                "The " + db.key + " connection string carries a plaintext database password (password length " + dbPw.length + "; the value is never shown here). Anyone who can read this config owns the database.",
                "Move the password out of the committed config: inject it at deploy time from a secret manager or CI secret (for example p=${NC_DB_PASSWORD}), restrict the config file's permissions, and rotate the password since it has been stored in plaintext.");
            } else {
              pass(db.key);
            }
          }

          /* NC_PUBLIC_URL */
          var pub = getEntry(entries, "NC_PUBLIC_URL");
          if (!pub || !pub.value) {
            add("MEDIUM", null, "NC_PUBLIC_URL",
              "NC_PUBLIC_URL is not set. Invite links, password resets, and OAuth redirects are built from the address the server guesses, which is often wrong behind a proxy.",
              "Set NC_PUBLIC_URL to the exact public https address users reach this instance at.");
          } else if (/^http:\/\//i.test(pub.value)) {
            if (/(localhost|127\.0\.0\.1)/i.test(pub.value)) {
              add("LOW", pub.line, "NC_PUBLIC_URL",
                "NC_PUBLIC_URL uses http on a local address. Fine for local development only.",
                "Before exposing this instance to anyone else, serve it over https and update NC_PUBLIC_URL to the https address.");
            } else {
              add("HIGH", pub.line, "NC_PUBLIC_URL",
                "NC_PUBLIC_URL uses plain http. Logins, invite links, and session cookies for this instance travel unencrypted and can be intercepted or altered.",
                "Put the instance behind https (reverse proxy or platform TLS), then set NC_PUBLIC_URL to the https address.");
            }
          } else if (/^https:\/\//i.test(pub.value)) {
            pass("NC_PUBLIC_URL");
          } else {
            add("LOW", pub.line, "NC_PUBLIC_URL",
              "NC_PUBLIC_URL does not start with http:// or https://, so generated links may be malformed.",
              "Set NC_PUBLIC_URL to a full URL including the https:// scheme.");
          }

          /* HOST / PORT bind */
          var host = getEntry(entries, "HOST");
          var port = getEntry(entries, "PORT");
          if (host && /^(0\.0\.0\.0|::|\*)$/.test(host.value.trim())) {
            add("MEDIUM", host.line, "HOST",
              "HOST binds the server to all network interfaces (0.0.0.0 / ::). The instance answers on every network the host touches, not just the one your proxy uses.",
              "Set HOST=127.0.0.1 when a reverse proxy on the same machine fronts the instance, or confirm a firewall limits who can reach the port directly.");
          } else if (host && /^(127\.0\.0\.1|localhost)$/i.test(host.value.trim())) {
            pass("HOST");
          } else if (!host && port) {
            add("LOW", port.line, "HOST",
              "PORT is set with no HOST, so the server binds all network interfaces by default.",
              "Set HOST=127.0.0.1 behind a reverse proxy, or confirm a firewall restricts direct access to PORT " + (port.value || "") + ".");
          }

          /* Local hooks / webhooks */
          var hooks = getEntry(entries, "NC_ALLOW_LOCAL_HOOKS");
          if (hooks) {
            if (truthy(hooks.value)) {
              add("HIGH", hooks.line, "NC_ALLOW_LOCAL_HOOKS",
                "NC_ALLOW_LOCAL_HOOKS=true lets webhooks and automations call addresses on the server's own network. Anyone who can create a webhook can probe internal services (server-side request forgery).",
                "Set NC_ALLOW_LOCAL_HOOKS=false unless a trusted workflow genuinely needs local targets, and restrict who can create webhooks.");
            } else {
              pass("NC_ALLOW_LOCAL_HOOKS");
            }
          }
          entries.forEach(function (e) {
            if (e.key.indexOf("HOOK") !== -1 && e.key !== "NC_ALLOW_LOCAL_HOOKS" && /(localhost|127\.0\.0\.1|169\.254\.|10\.\d+\.\d+\.\d+|192\.168\.)/.test(e.value)) {
              add("HIGH", e.line, e.key,
                "This webhook target points at a local/private network address, which can be used to reach internal services from the server.",
                "Point webhooks only at public endpoints you control, and keep NC_ALLOW_LOCAL_HOOKS=false.");
            }
          });

          /* SMTP credentials */
          var smtpPwEntry = null, smtpSecure = getEntry(entries, "NC_SMTP_SECURE");
          entries.forEach(function (e) {
            if (/SMTP|MAILER/.test(e.key) && /(PASS|PWD|SECRET|TOKEN)/.test(e.key)) smtpPwEntry = e;
          });
          if (smtpPwEntry && smtpPwEntry.value && !isSecretRef(smtpPwEntry.value)) {
            add("MEDIUM", smtpPwEntry.line, smtpPwEntry.key,
              "An SMTP credential is stored in plaintext in this config (value length " + smtpPwEntry.value.length + "; the value is never shown here). A leaked config hands out your mail account, which sends password-reset mail for the instance.",
              "Inject the SMTP password from a secret manager or CI secret instead of the committed config, restrict file permissions, and rotate the mail password.");
          } else if (smtpPwEntry) {
            pass(smtpPwEntry.key);
          }
          if (smtpSecure && falsy(smtpSecure.value)) {
            add("MEDIUM", smtpSecure.line, "NC_SMTP_SECURE",
              "NC_SMTP_SECURE=false turns off TLS for outgoing mail, so credentials and reset links cross the network in the clear.",
              "Set NC_SMTP_SECURE=true (with the matching SMTP port, typically 465) or use STARTTLS as your mail provider requires.");
          } else if (smtpSecure) {
            pass("NC_SMTP_SECURE");
          }

          /* Redis */
          var redisUrl = getEntry(entries, "NC_REDIS_URL");
          var redisPw = getEntry(entries, "NC_REDIS_PASSWORD");
          if (redisUrl && redisUrl.value) {
            var rPw = extractUrlPassword(redisUrl.value);
            if (rPw && !isSecretRef(rPw)) {
              add("MEDIUM", redisUrl.line, "NC_REDIS_URL",
                "The NC_REDIS_URL connection string carries a plaintext Redis password (password length " + rPw.length + "; the value is never shown here).",
                "Inject the Redis password from a secret manager or CI secret (for example redis://:${NC_REDIS_PASSWORD}@host:6379) and rotate the password.");
            } else {
              pass("NC_REDIS_URL");
            }
          }
          if (redisPw && redisPw.value && !isSecretRef(redisPw.value)) {
            add("MEDIUM", redisPw.line, "NC_REDIS_PASSWORD",
              "NC_REDIS_PASSWORD is stored in plaintext in this config (value length " + redisPw.value.length + "; the value is never shown here).",
              "Inject NC_REDIS_PASSWORD from a secret manager or CI secret and rotate the Redis password.");
          } else if (redisPw) {
            pass("NC_REDIS_PASSWORD");
          }

          /* Signup posture */
          var invite = getEntry(entries, "NC_INVITE_ONLY_SIGNUP");
          if (invite) {
            if (falsy(invite.value)) {
              add("HIGH", invite.line, "NC_INVITE_ONLY_SIGNUP",
                "NC_INVITE_ONLY_SIGNUP=false leaves registration open: anyone who can reach the instance can create an account and start creating bases.",
                "Set NC_INVITE_ONLY_SIGNUP=true so new accounts require an invitation from an existing admin.");
            } else {
              pass("NC_INVITE_ONLY_SIGNUP");
            }
          } else {
            add("MEDIUM", null, "NC_INVITE_ONLY_SIGNUP",
              "NC_INVITE_ONLY_SIGNUP is not set, so the instance's default signup posture applies — on a reachable instance that can mean anyone may register.",
              "Set NC_INVITE_ONLY_SIGNUP=true explicitly so the posture is a decision, not a default.");
          }

          /* CORS */
          entries.forEach(function (e) {
            if (e.key.indexOf("CORS") !== -1) {
              if (/(^|[,\s])\*([,\s]|$)/.test(e.value)) {
                add("HIGH", e.line, e.key,
                  "CORS is configured with a wildcard origin (*), so any website a signed-in user visits can call this instance's API from their browser.",
                  "Replace * with the exact origin(s) of your own front end, or remove the CORS override if you do not need cross-origin access.");
              } else if (e.value) {
                pass(e.key);
              }
            }
          });

          /* Telemetry posture (surfaced, not scored) */
          var tele = getEntry(entries, "NC_DISABLE_TELE");
          if (tele && truthy(tele.value)) {
            add("INFO", tele.line, "NC_DISABLE_TELE",
              "Telemetry is disabled (NC_DISABLE_TELE=true). That is a legitimate privacy choice — it is surfaced here so the posture is visible rather than silent; it does not lower the verdict.",
              "No fix needed. Leave it set if you prefer no usage telemetry; unset it if you want the project to receive anonymous usage counts.");
          }

          findings.sort(function (a, b) {
            if (SEV_ORDER[a.severity] !== SEV_ORDER[b.severity]) return SEV_ORDER[a.severity] - SEV_ORDER[b.severity];
            return (a.line || 9999) - (b.line || 9999);
          });

          var counts = { CRITICAL: 0, HIGH: 0, MEDIUM: 0, LOW: 0, INFO: 0 };
          findings.forEach(function (f) { counts[f.severity]++; });

          var verdict;
          if (recognized < 2) verdict = "NOT ENOUGH TO GRADE";
          else if (counts.CRITICAL > 0 || counts.HIGH >= 2) verdict = "DO NOT DEPLOY";
          else if (counts.HIGH > 0 || counts.MEDIUM > 0) verdict = "DEPLOY WITH FIXES";
          else verdict = "SAFE TO DEPLOY";

          return { verdict: verdict, findings: findings, passed: passed, counts: counts, recognized: recognized, entryCount: entries.length };
        }

        /* ---------- Report / JSON ---------- */

        function buildReport(result) {
          var out = [];
          out.push("J-Dawgs NocoDB Server Config Safety Auditor\u2122 - Config Audit Report");
          out.push("Verdict: " + result.verdict);
          out.push("Findings: " + result.findings.length + " (CRITICAL " + result.counts.CRITICAL + ", HIGH " + result.counts.HIGH + ", MEDIUM " + result.counts.MEDIUM + ", LOW " + result.counts.LOW + ", INFO " + result.counts.INFO + ")");
          out.push("Checks passed: " + (result.passed.length ? result.passed.join(", ") : "none"));
          out.push("");
          if (result.findings.length === 0) {
            out.push("No findings.");
          } else {
            result.findings.forEach(function (f, i) {
              out.push((i + 1) + ". [" + f.severity + "] " + (f.line ? "Line " + f.line : "Line - (key not present)") + " - " + f.key);
              out.push("   " + f.issue);
              out.push("   Fix: " + f.fix);
            });
          }
          out.push("");
          out.push("Note: Offline, paste-only audit performed in the browser. Secret values are reported by key name, line, and length only and never appear in this report. This audit never connected to any server and does not verify that the server runs.");
          return out.join("\n");
        }

        function buildJSON(result) {
          return JSON.stringify({
            tool: "J-Dawgs NocoDB Server Config Safety Auditor\u2122",
            verdict: result.verdict,
            counts: result.counts,
            recognizedKeys: result.recognized,
            findings: result.findings.map(function (f) {
              return { severity: f.severity, line: f.line, key: f.key, issue: f.issue, fix: f.fix };
            }),
            passedChecks: result.passed,
            note: "Offline paste-only audit. Secret values are never included; passwords are described by key, line, and length only. This audit never connected to any server and does not verify that the server runs."
          }, null, 2);
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_WORDS": (typeof EXAMPLE_WORDS !== 'undefined' ? EXAMPLE_WORDS : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-nocodb-server-config-safety-auditortm-2',
  name: 'J-Dawgs NocoDB Server Config Safety Auditor',
  description: '',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_WORDS": __core["EXAMPLE_WORDS"] }
};
