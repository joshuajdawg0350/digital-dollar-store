'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs WireGuard VPN Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Examples (fake test keys only — never real credentials) ---------- */
      var RISKY = [
        "[Interface]",
        "PrivateKey = SHORTKEY123456",
        "Address = 10.8.0.1/24",
        "ListenPort = 51820",
        "MTU = 9000",
        "PostUp = iptables -A FORWARD -i wg0 -j ACCEPT; iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE",
        "SaveConfig = true",
        "FooBar = 1",
        "rotate the keys before friday",
        "",
        "[Peer]",
        "PublicKey = ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopq=",
        "AllowedIPs = 0.0.0.0/0, ::/0",
        "PersistentKeepalive = 25",
        "",
        "[Peer]",
        "PublicKey = ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopq=",
        "AllowedIPs = 0.0.0.0/0, ::/0",
        "Endpoint = vpn.example.com"
      ].join("\n");

      var HARDENED = [
        "[Interface]",
        "PrivateKey = abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQ=",
        "Address = 10.8.0.2/32",
        "DNS = 10.8.0.1",
        "MTU = 1420",
        "",
        "[Peer]",
        "PublicKey = ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopq=",
        "PresharedKey = ZYXWVUTSRQPONMLKJIHGFEDCBAzyxwvutsrqponmlkj=",
        "AllowedIPs = 10.8.0.0/24",
        "Endpoint = vpn.example.com:51820",
        "PersistentKeepalive = 25"
      ].join("\n");

      /* ---------- Parser ---------- */
      var CANON = {
        privatekey:"PrivateKey", listenport:"ListenPort", address:"Address", dns:"DNS", mtu:"MTU",
        postup:"PostUp", postdown:"PostDown", preup:"PreUp", predown:"PreDown", saveconfig:"SaveConfig",
        table:"Table", fwmark:"FwMark", publickey:"PublicKey", presharedkey:"PresharedKey",
        allowedips:"AllowedIPs", endpoint:"Endpoint", persistentkeepalive:"PersistentKeepalive"
      };
      var SCRIPT_KEYS = {postup:1, postdown:1, preup:1, predown:1};

      function parseConfig(text){
        var lines = String(text).split(/\r?\n/);
        var out = { interfaces:[], peers:[], malformed:[], unknownKeys:[], totalLines:lines.length, keyLines:0 };
        var current = null;
        for (var i=0;i<lines.length;i++){
          var lineNo = i+1;
          var t = lines[i].trim();
          if (!t) continue;
          if (t.charAt(0)==="#" || t.charAt(0)===";") continue;
          var m = t.match(/^\[\s*([^\]]+?)\s*\]$/);
          if (m){
            var name = m[1].toLowerCase();
            if (name==="interface"){ current={type:"interface", entries:{}, headerLine:lineNo}; out.interfaces.push(current); }
            else if (name==="peer"){ current={type:"peer", num:out.peers.length+1, entries:{}, headerLine:lineNo}; out.peers.push(current); }
            else { out.malformed.push({line:lineNo}); current=null; }
            continue;
          }
          var eq = t.indexOf("=");
          if (eq<0){ out.malformed.push({line:lineNo}); continue; }
          var keyRaw = t.slice(0,eq).trim();
          var value = t.slice(eq+1).trim();
          var lower = keyRaw.toLowerCase();
          if (!SCRIPT_KEYS[lower]){
            var cm = value.search(/\s[#;]/);
            if (cm>=0) value = value.slice(0,cm).trim();
          }
          if (!current){ out.malformed.push({line:lineNo}); continue; }
          if (Object.prototype.hasOwnProperty.call(CANON, lower)){
            var ck = CANON[lower];
            if (!current.entries[ck]) current.entries[ck]=[];
            current.entries[ck].push({value:value, line:lineNo});
            out.keyLines++;
          } else {
            out.unknownKeys.push({key:keyRaw, line:lineNo});
          }
        }
        return out;
      }

      function entries(sec, key){ return (sec && sec.entries[key]) ? sec.entries[key] : []; }
      function firstVal(sec, key){ var e=entries(sec,key); return e.length? e[0] : null; }
      function splitList(entryArr){
        var vals=[];
        entryArr.forEach(function(e){
          e.value.split(",").forEach(function(part){
            var v=part.trim(); if (v) vals.push({value:v, line:e.line});
          });
        });
        return vals;
      }

      /* ---------- IP / CIDR math (CIDRs are not secrets and may be shown) ---------- */
      function parseIPv4(s){
        var parts=s.split("."); if (parts.length!==4) return null;
        var n=0n;
        for (var i=0;i<4;i++){
          if (!/^\d{1,3}$/.test(parts[i])) return null;
          var o=parseInt(parts[i],10); if (o>255) return null;
          n=(n<<8n)+BigInt(o);
        }
        return n;
      }
      function parseIPv6(s){
        if (s.indexOf(":")<0) return null;
        var halves=s.split("::");
        if (halves.length>2) return null;
        function side(str){
          if (!str) return [];
          var gs=str.split(":");
          for (var i=0;i<gs.length;i++){ if (!/^[0-9a-fA-F]{1,4}$/.test(gs[i])) return null; }
          return gs.map(function(g){ return parseInt(g,16); });
        }
        var left=side(halves[0]); if (left===null) return null;
        var right = halves.length===2 ? side(halves[1]) : [];
        if (right===null) return null;
        if (halves.length===1 && left.length!==8) return null;
        if (halves.length===2 && left.length+right.length>7) return null;
        var groups=left.slice();
        var missing=8-left.length-right.length;
        for (var j=0;j<missing;j++) groups.push(0);
        groups=groups.concat(right);
        if (groups.length!==8) return null;
        var n=0n;
        groups.forEach(function(g){ n=(n<<16n)+BigInt(g); });
        return n;
      }
      function parseIP(s){
        if (s.indexOf(":")>=0){ var v6=parseIPv6(s); return v6===null? null : {family:6, big:v6, bits:128}; }
        var v4=parseIPv4(s); return v4===null? null : {family:4, big:v4, bits:32};
      }
      function parseCIDR(s){
        var slash=s.lastIndexOf("/");
        var ipStr=s, prefix=null;
        if (slash>=0){ ipStr=s.slice(0,slash); var p=s.slice(slash+1); if (!/^\d+$/.test(p)) return null; prefix=parseInt(p,10); }
        var ip=parseIP(ipStr); if (!ip) return null;
        if (prefix===null) prefix=ip.bits;
        if (prefix<0 || prefix>ip.bits) return null;
        var shift=BigInt(ip.bits-prefix);
        var net=(ip.big>>shift)<<shift;
        var end=net + ((1n<<shift)-1n);
        return {family:ip.family, bits:ip.bits, prefix:prefix, net:net, end:end, raw:s};
      }
      function cidrContains(outer, inner){ return outer.family===inner.family && inner.net>=outer.net && inner.end<=outer.end; }
      function cidrOverlap(a,b){ return a.family===b.family && a.net<=b.end && b.net<=a.end; }
      function ipInCIDR(ipObj, cidr){ return ipObj.family===cidr.family && ipObj.big>=cidr.net && ipObj.big<=cidr.end; }
      function fmtIP(family, big){
        if (family===4){
          var parts=[];
          for (var i=3;i>=0;i--){ parts.push(String(Number((big>>(BigInt(i)*8n))&255n))); }
          return parts.join(".");
        }
        var groups=[];
        for (var k=7;k>=0;k--){ groups.push(Number((big>>(BigInt(k)*16n))&65535n)); }
        var bestStart=-1, bestLen=0, curStart=-1, curLen=0;
        for (var i2=0;i2<8;i2++){
          if (groups[i2]===0){ if (curStart<0){curStart=i2; curLen=1;} else curLen++; if (curLen>bestLen){bestLen=curLen; bestStart=curStart;} }
          else { curStart=-1; curLen=0; }
        }
        var hex=groups.map(function(g){ return g.toString(16); });
        if (bestLen>=2){
          var leftPart=hex.slice(0,bestStart).join(":");
          var rightPart=hex.slice(bestStart+bestLen).join(":");
          return leftPart+"::"+rightPart;
        }
        return hex.join(":");
      }
      function overlapRangeText(a,b){
        var lo = a.net>b.net? a.net : b.net;
        var hi = a.end<b.end? a.end : b.end;
        return fmtIP(a.family, lo)+" – "+fmtIP(a.family, hi);
      }

      /* ---------- Audit engine ---------- */
      var PLACEHOLDER = /example|changeme|change-me|placeholder|your[-_ ]|xxx|todo/i;

      function audit(text){
        var parsed = parseConfig(text);
        var findings = [];
        function add(sev, where, line, title, detail, fix){
          findings.push({severity:sev, where:where, line:(line==null? null:line), title:title, detail:detail, fix:fix});
        }

        var ifaces = parsed.interfaces, peers = parsed.peers;
        var iface = ifaces.length? ifaces[0] : null;

        if (ifaces.length===0) add("BLOCKER","Config",null,"No [Interface] section","The config has no [Interface] section, so there is no local identity, address, or port for WireGuard to bring up.","Add an [Interface] section with at least a PrivateKey and an Address.");
        if (ifaces.length>1) add("BLOCKER","Config",ifaces[1].headerLine,"More than one [Interface] section","A single config file describes one interface. A second [Interface] section makes the file ambiguous and wg-quick will reject or misread it.","Keep exactly one [Interface] section per config file; split extra interfaces into their own files.");
        if (peers.length===0) add("MAJOR","Config",null,"No [Peer] section","There is nobody on the other end of this tunnel. The interface can start, but it connects to nothing.","Add at least one [Peer] section with the other side's PublicKey and AllowedIPs.");

        var serverLike = false;
        var ifaceCIDRs = [];

        if (iface){
          var W="[Interface]";
          /* PrivateKey */
          var pk=firstVal(iface,"PrivateKey");
          if (!pk){
            add("BLOCKER",W,null,"PrivateKey is missing","No interface identity: without a PrivateKey, WireGuard cannot start this interface as configured — there is no keypair for the tunnel to authenticate with.","Generate a keypair with wg genkey / wg pubkey on the machine and put the private key (44 characters) on the PrivateKey line. Never reuse a key from an example.");
          } else if (PLACEHOLDER.test(pk.value)){
            add("BLOCKER",W,pk.line,"PrivateKey looks like a placeholder","The PrivateKey value on this line reads as placeholder-like (it contains wording such as “example”, “changeme”, or “your-…”). The value itself is never shown here. A placeholder is not a key and the tunnel cannot authenticate with it.","Replace it with a real key generated on the machine (wg genkey), 44 characters, base64 ending in “=”.");
          } else if (pk.value.length!==44){
            add("BLOCKER",W,pk.line,"PrivateKey has the wrong length ("+pk.value.length+" characters)","WireGuard keys are 44 characters (base64, ending in “=”). A "+pk.value.length+"-character value is truncated, mistyped, or not a WireGuard key at all — the value itself is never shown here.","Replace it with a complete key generated by wg genkey and paste all 44 characters.");
          } else {
            add("PASS",W,pk.line,"PrivateKey present, 44 characters","A PrivateKey of the correct WireGuard length is set. The value was graded by length only and is never shown.","No change needed for the key itself.");
            add("INFO",W,pk.line,"A plaintext private key sits in this file","Any valid-length PrivateKey in a pasted config is stored as plaintext wherever this file lives. That is normal for WireGuard, and it makes the file itself a secret.","Keep the file at permissions 0600, owned by root, or hold it in a secrets manager. File permissions are NOT VERIFIED — a paste carries no permission bits.");
          }
          /* Address */
          var addrEntries=entries(iface,"Address");
          if (!addrEntries.length){
            add("BLOCKER",W,null,"Address is missing","The interface has no tunnel address, so it has no identity on the VPN network and the tunnel cannot route.","Set Address to this machine's tunnel IP in CIDR form, e.g. Address = 10.8.0.1/24 for a server or 10.8.0.2/32 for a client.");
          } else {
            var addrVals=splitList(addrEntries);
            var seenAddr={}, addrBad=false, addrDup=false;
            addrVals.forEach(function(av){
              var c=parseCIDR(av.value);
              if (!c){ addrBad=true; add("BLOCKER",W,av.line,"Address entry is not a valid CIDR (“"+av.value+"”)","CIDR arithmetic cannot be done on this entry, so overlap and routing checks treat it as broken.","Write the entry as IP/prefix, e.g. 10.8.0.1/24."); return; }
              ifaceCIDRs.push(c);
              var key=av.value.toLowerCase();
              if (seenAddr[key]) addrDup=true; seenAddr[key]=true;
            });
            if (addrDup) add("BLOCKER",W,null,"Duplicate Address entries","The same tunnel address is listed more than once in [Interface], which makes the local routing ambiguous.","List each tunnel address once.");
            if (!addrBad && !addrDup) add("PASS",W,addrEntries[0].line,"Address present and valid","Tunnel address set: "+addrVals.map(function(a){return a.value;}).join(", ")+".","No change needed.");
          }
          /* ListenPort */
          var lp=firstVal(iface,"ListenPort");
          if (lp){
            serverLike=true;
            if (!/^\d+$/.test(lp.value) || parseInt(lp.value,10)<1 || parseInt(lp.value,10)>65535){
              add("BLOCKER",W,lp.line,"ListenPort is not a usable port","The ListenPort value is non-numeric or outside 1–65535, so the interface has no valid UDP port to listen on.","Set ListenPort to a number between 1 and 65535 (51820 is the conventional WireGuard port).");
            } else if (parseInt(lp.value,10)<1024){
              add("MINOR",W,lp.line,"ListenPort "+lp.value+" is a privileged port","Ports below 1024 normally need elevated privileges and are more likely to collide with other services.","Prefer an unprivileged port such as 51820 unless you specifically need this one.");
            } else {
              add("INFO",W,lp.line,"This interface listens on UDP port "+lp.value,"A ListenPort makes this a reachable, server-style interface: anything on the network can knock on UDP "+lp.value+" (WireGuard silently drops unauthenticated packets, but the port itself is exposed).","Keep the port only if this machine should accept incoming tunnels, and make sure your firewall expects it.");
            }
          }
          /* MTU */
          var mtu=firstVal(iface,"MTU");
          if (!mtu){
            add("MINOR",W,null,"MTU is not set","WireGuard will pick a default MTU. On PPPoE, DSL, or mobile links the default can be too big, and oversized packets fragment or stall — the classic “tunnel connects, big pages hang” symptom.","Set MTU explicitly — 1280–1420 covers most links; 1420 is the common WireGuard default choice.");
          } else if (!/^\d+$/.test(mtu.value)){
            add("BLOCKER",W,mtu.line,"MTU is not a number","The MTU value cannot be parsed as a number, so the interface MTU is undefined.","Set MTU to a whole number between 1280 and 1500.");
          } else {
            var mv=parseInt(mtu.value,10);
            if (mv<1280 || mv>1500) add("MAJOR",W,mtu.line,"MTU "+mv+" is outside the sane 1280–1500 range","Below 1280 violates the IPv6 minimum and fragments badly; above 1500 exceeds standard Ethernet and will fragment on almost any real path.","Set MTU between 1280 and 1500 — 1420 is the usual pick for WireGuard over the public internet.");
            else add("PASS",W,mtu.line,"MTU "+mv+" is in the sane range","Set explicitly and inside 1280–1500.","No change needed.");
          }
          /* PostUp / PostDown */
          var postUps=entries(iface,"PostUp"), postDowns=entries(iface,"PostDown");
          var hasFw = postUps.some(function(e){ return /iptables|nft\b/.test(e.value); });
          if (postUps.length && !postDowns.length){
            if (hasFw) add("BLOCKER",W,postUps[0].line,"PostUp adds firewall rules and there is no PostDown","The PostUp commands run iptables/nft on the way up and nothing removes those rules on the way down. Every restart piles up duplicate rules, and forwarding/NAT rules outlive the tunnel they were written for.","Add a PostDown that reverses each PostUp rule (same commands with -D instead of -A, or the matching nft delete).");
            else add("MAJOR",W,postUps[0].line,"PostUp present with no PostDown","Whatever PostUp sets up on the way up is never undone on the way down, so state leaks across restarts.","Add a PostDown that undoes each PostUp step, or remove PostUp if nothing needs undoing.");
          } else if (!postUps.length && postDowns.length){
            add("MINOR",W,postDowns[0].line,"PostDown present with no PostUp","A teardown script with no matching setup script usually means a PostUp was deleted or never copied over.","Check whether a PostUp is missing; if the PostDown is leftover, remove it.");
          } else if (postUps.length && postDowns.length){
            add("PASS",W,postUps[0].line,"PostUp has a matching PostDown","Setup commands exist and teardown commands exist.","Skim the pair once to confirm the PostDown really reverses the PostUp.");
          }
          /* SaveConfig */
          var sc=firstVal(iface,"SaveConfig");
          if (sc && sc.value.toLowerCase()==="true"){
            add("MAJOR",W,sc.line,"SaveConfig = true","With SaveConfig on, runtime peer changes get written back into this file on shutdown. Peers added on the fly become permanent silently, and the file — private key included — gets rewritten by the daemon.","Set SaveConfig = false (or delete the line) unless you deliberately manage peers at runtime and accept the write-back.");
          }
        }

        /* Per-peer checks */
        var peerCIDRLists = [];
        var fullTunnel=false;
        peers.forEach(function(peer, idx){
          var W="[Peer "+peer.num+"]";
          var pub=firstVal(peer,"PublicKey");
          if (!pub){
            add("BLOCKER",W,null,"PublicKey is missing","Without the other side's PublicKey, WireGuard has no way to authenticate this peer and no tunnel to it can form.","Add the peer's PublicKey (44 characters, from wg pubkey on that machine).");
          } else if (PLACEHOLDER.test(pub.value)){
            add("BLOCKER",W,pub.line,"PublicKey looks like a placeholder","The PublicKey value on this line reads as placeholder-like (wording such as “example”, “changeme”, or “your-…”). The value itself is never shown here.","Replace it with the peer's real public key, all 44 characters.");
          } else if (pub.value.length!==44){
            add("BLOCKER",W,pub.line,"PublicKey has the wrong length ("+pub.value.length+" characters)","WireGuard keys are 44 characters (base64, ending in “=”). This value cannot be a working key — the value itself is never shown here.","Re-copy the peer's full public key from the source machine.");
          } else {
            add("PASS",W,pub.line,"PublicKey present, 44 characters","Graded by length only; the value is never shown.","No change needed.");
          }
          var psk=firstVal(peer,"PresharedKey");
          if (!psk){
            add("MAJOR",W,null,"No PresharedKey for this peer","No preshared key means no defense-in-depth for this peer: the tunnel rests entirely on the long-term keys, with no symmetric post-quantum hedge if a private key is ever exposed.","Generate one with wg genpsk, put the same 44-character value in both sides' configs for this peer, and store it like a key.");
          } else if (PLACEHOLDER.test(psk.value)){
            add("BLOCKER",W,psk.line,"PresharedKey looks like a placeholder","The PresharedKey value reads as placeholder-like. The value itself is never shown here; a placeholder preshared key protects nothing.","Replace it with a real wg genpsk value (44 characters) on both sides.");
          } else if (psk.value.length!==44){
            add("BLOCKER",W,psk.line,"PresharedKey has the wrong length ("+psk.value.length+" characters)","A preshared key must be a full 44-character WireGuard key, and it must match on both sides. The value itself is never shown here.","Regenerate with wg genpsk and install the identical value on both ends.");
          } else {
            add("PASS",W,psk.line,"PresharedKey present, 44 characters","Defense-in-depth is in place for this peer. Graded by length only; the value is never shown.","No change needed.");
          }
          /* AllowedIPs */
          var aiEntries=entries(peer,"AllowedIPs");
          var cidrList=[];
          if (!aiEntries.length){
            add("BLOCKER",W,null,"AllowedIPs is missing","AllowedIPs is both the routing table and the access control for this peer. Without it, no traffic is assigned to this peer at all.","Set AllowedIPs to exactly the ranges this peer may send from and receive at — a single host is a /32.");
          } else {
            var aiVals=splitList(aiEntries);
            var bad=false, full4=false, full6=false, sevHere=false;
            aiVals.forEach(function(av){
              var c=parseCIDR(av.value);
              if (!c){ bad=true; sevHere=true; add("BLOCKER",W,av.line,"AllowedIPs entry is not a valid CIDR (“"+av.value+"”)","This entry cannot be parsed as IP/prefix, so WireGuard's cryptokey routing has nothing sane to do with it.","Write each entry as IP/prefix, e.g. 10.8.0.2/32 or 10.8.0.0/24."); return; }
              cidrList.push(c);
              if (c.family===4 && c.prefix===0) full4=true;
              if (c.family===6 && c.prefix===0) full6=true;
            });
            if (full4){ fullTunnel=true; sevHere=true;
              add("MAJOR",W,aiEntries[0].line,"AllowedIPs contains 0.0.0.0/0 — full tunnel (IPv4)","All IPv4 traffic from this machine routes through this peer. That is a real design choice, not a default: it changes your public IP, your DNS path, and your failure modes.","If only a LAN or one service was intended, narrow AllowedIPs to just those ranges (e.g. 10.8.0.0/24). Keep 0.0.0.0/0 only for a deliberate full tunnel.");
            }
            if (full6){ fullTunnel=true; sevHere=true;
              add("MAJOR",W,aiEntries[0].line,"AllowedIPs contains ::/0 — full tunnel (IPv6)", full4? "Together with 0.0.0.0/0, literally all traffic — IPv4 and IPv6 — routes through this peer.":"All IPv6 traffic routes through this peer.","If only a LAN or one service was intended, narrow AllowedIPs to just those ranges. Keep ::/0 only for a deliberate full tunnel.");
            }
            /* identity overlap with the interface's own Address */
            cidrList.forEach(function(c){
              ifaceCIDRs.forEach(function(ic){
                if (c.family===ic.family && c.net===ic.net && c.prefix===ic.prefix){
                  sevHere=true;
                  add("BLOCKER",W,aiEntries[0].line,"AllowedIPs claims this interface's own address ("+ic.raw+")","This peer's AllowedIPs contains the exact tunnel address assigned to this interface ("+ic.raw+"), so traffic for this machine's own address is routed back out to the peer — a loop.","Remove the interface's own address from this peer's AllowedIPs; a peer may contain the address inside a wider range, but must not claim the address itself.");
                }
              });
            });
            /* overlap with earlier peers */
            for (var j=0;j<idx;j++){
              var other=peerCIDRLists[j];
              var hit=null, hitOther=null;
              for (var a=0;a<cidrList.length && !hit;a++){
                for (var b=0;b<other.length;b++){
                  if (cidrOverlap(cidrList[a], other[b])){ hit=cidrList[a]; hitOther=other[b]; break; }
                }
              }
              if (hit){
                sevHere=true;
                add("BLOCKER",W,aiEntries[0].line,"AllowedIPs overlaps Peer "+(j+1),"Peer "+(j+1)+" allows "+hitOther.raw+" and this peer allows "+hit.raw+"; the ranges overlap on "+overlapRangeText(hit,hitOther)+". Cryptokey routing picks one peer for an address, so the overlap makes delivery to that range ambiguous and one peer silently shadows the other.","Give each range to exactly one peer: shrink one side until the two peers' AllowedIPs no longer intersect.");
              }
            }
            if (!bad && !sevHere){
              var allHost = cidrList.length>0 && cidrList.every(function(c){ return c.prefix===c.bits; });
              add("PASS",W,aiEntries[0].line, allHost? "AllowedIPs is narrow (single-host routes only)" : "AllowedIPs is scoped","This peer routes only: "+cidrList.map(function(c){return c.raw;}).join(", ")+". No full tunnel, no overlap with other peers.","No change needed.");
            }
          }
          peerCIDRLists.push(cidrList);
          /* Endpoint */
          var ep=firstVal(peer,"Endpoint");
          if (!ep){
            add("INFO",W,null,"No Endpoint for this peer","With no Endpoint, this peer can only be reached when the other side initiates — roaming only. That is fine for a server-side peer entry, and a problem for a client peer that must dial out.","If this machine must initiate the tunnel, add Endpoint = host:port for the other side. If this is a server's view of a roaming client, leave it.");
          } else {
            var ev=ep.value, portOk=false, portBad=false;
            if (ev.charAt(0)==="["){
              var bm=ev.match(/^\[[^\]]+\]:(\d{1,5})$/);
              if (bm){ var bp=parseInt(bm[1],10); if (bp>=1 && bp<=65535) portOk=true; else portBad=true; }
            } else {
              var colons=(ev.match(/:/g)||[]).length;
              if (colons===1){
                var pp=ev.slice(ev.lastIndexOf(":")+1);
                if (/^\d+$/.test(pp)){ var pv=parseInt(pp,10); if (pv>=1 && pv<=65535) portOk=true; else portBad=true; }
                else portBad=true;
              }
            }
            if (portOk) add("PASS",W,ep.line,"Endpoint present, with a port","This peer can be dialed directly at the configured host and UDP port. Reachability of that host is NOT VERIFIED — this is a text check only.","No change needed.");
            else add("MAJOR",W,ep.line,"Endpoint has no usable :port","The Endpoint is missing its UDP port (or the port is not a number in 1–65535), so this machine does not know where to dial. The endpoint value is not shown beyond its shape.","Write the Endpoint as host:port, e.g. vpn.example.com:51820 (IPv6 hosts go in brackets: [2001:db8::1]:51820).");
          }
          /* PersistentKeepalive */
          var ka=firstVal(peer,"PersistentKeepalive");
          if (!ka){
            if (!serverLike && ep){
              add("MINOR",W,null,"No PersistentKeepalive on a client-style peer","This config has no ListenPort and this peer has an Endpoint, so this machine dials out. If it sits behind NAT, silence lets the NAT mapping expire and the peer goes quiet until it speaks first.","Set PersistentKeepalive = 25 — the usual value — to keep the mapping warm.");
            }
          } else if (!/^\d+$/.test(ka.value) || parseInt(ka.value,10)>65535){
            add("BLOCKER",W,ka.line,"PersistentKeepalive is not a usable number","The keepalive value is non-numeric or outside 0–65535, so it cannot be applied.","Set PersistentKeepalive to a whole number of seconds — 25 is the usual value — or remove the line.");
          } else {
            var kv=parseInt(ka.value,10);
            if (serverLike){
              add("MINOR",W,ka.line,"PersistentKeepalive set on a server-style config","This interface has a ListenPort, so it is the reachable side. Servers normally do not need keepalive — it wastes a small packet every "+kv+" seconds per peer keeping NAT mappings warm that nobody on this side needs.","Remove PersistentKeepalive from server-side peer entries unless you know a specific NAT case that needs it.");
            } else if (kv===0){
              add("INFO",W,ka.line,"PersistentKeepalive = 0 (disabled)","Keepalive is explicitly off for this peer.","Fine on an open network; behind NAT, 25 keeps the mapping alive.");
            } else if (kv>=1 && kv<=60){
              add("PASS",W,ka.line,"PersistentKeepalive = "+kv+" seconds","A sane keepalive for a client-style config: the NAT mapping stays warm without chatter.","No change needed.");
            } else {
              add("MINOR",W,ka.line,"PersistentKeepalive = "+kv+" seconds is unusually long","Past about a minute, most NAT mappings have already expired, so the keepalive stops doing its one job.","Use 25 seconds unless you measured a reason not to.");
            }
          }
        });

        /* DNS posture (needs peer AllowedIPs, so it runs after the peer pass) */
        if (iface){
          var dnsEntries=entries(iface,"DNS");
          if (!dnsEntries.length){
            if (fullTunnel){
              add("MAJOR","[Interface]",null,"Full tunnel with no DNS set — DNS leak risk","A peer routes all traffic (0.0.0.0/0 and/or ::/0) but the config sets no DNS. Name lookups then fall back to the machine's normal resolvers, which can leak queries — and the sites they name — outside the tunnel even though the traffic itself is inside.","Add a DNS line naming a resolver reached through the tunnel (for example the tunnel's own server address), so lookups travel the same path as traffic.");
            }
          } else {
            var dnsVals=splitList(dnsEntries);
            add("PASS","[Interface]",dnsEntries[0].line,"DNS is set","Resolver(s) configured for the tunnel: "+dnsVals.map(function(d){return d.value;}).join(", ")+".","No change needed.");
            var allPeerCIDRs=[];
            peerCIDRLists.forEach(function(l){ l.forEach(function(c){ allPeerCIDRs.push(c); }); });
            if (peers.length){
              dnsVals.forEach(function(dv){
                var ip=parseIP(dv.value);
                if (!ip) return; /* hostname resolver — not computable */
                var inside=allPeerCIDRs.some(function(c){ return ipInCIDR(ip,c); });
                if (!inside){
                  add("MAJOR","[Interface]",dv.line,"DNS server "+dv.value+" is outside every peer's AllowedIPs","Queries to this resolver do not travel through the tunnel — they leave on the plain network, which leaks lookups even when the rest of the config is tight.","Point DNS at a resolver inside a peer's AllowedIPs (e.g. the tunnel server), or widen AllowedIPs deliberately if that resolver must be reached through the tunnel.");
                }
              });
            }
          }
        }

        /* Duplicate peers (values compared internally only — never shown) */
        for (var i2=0;i2<peers.length;i2++){
          for (var j2=i2+1;j2<peers.length;j2++){
            var a2=firstVal(peers[i2],"PublicKey"), b2=firstVal(peers[j2],"PublicKey");
            if (a2 && b2 && a2.value && a2.value===b2.value){
              add("BLOCKER","Peers "+(i2+1)+" and "+(j2+1),null,"Duplicate peers: Peer "+(i2+1)+" and Peer "+(j2+1)+" carry the same PublicKey","Two peer entries with the same public key are the same machine written down twice (the values were compared internally and are never shown). Duplicate entries make routing and future edits ambiguous.","Delete the duplicate [Peer] section and keep one entry per machine.");
            } else {
              var ea=firstVal(peers[i2],"Endpoint"), eb=firstVal(peers[j2],"Endpoint");
              var aa=splitList(entries(peers[i2],"AllowedIPs")).map(function(x){return x.value.toLowerCase();}).sort().join(",");
              var ab=splitList(entries(peers[j2],"AllowedIPs")).map(function(x){return x.value.toLowerCase();}).sort().join(",");
              if (ea && eb && ea.value.toLowerCase()===eb.value.toLowerCase() && aa && aa===ab){
                add("BLOCKER","Peers "+(i2+1)+" and "+(j2+1),null,"Duplicate peers: Peer "+(i2+1)+" and Peer "+(j2+1)+" share the same Endpoint and AllowedIPs","Same reachable address and the same routed ranges, written twice. One of the two entries will shadow the other.","Merge them into a single [Peer] section, or fix whichever entry carries the wrong Endpoint or AllowedIPs.");
              }
            }
          }
        }

        /* Verdict + counts */
        var counts={BLOCKER:0, MAJOR:0, MINOR:0, PASS:0, INFO:0};
        findings.forEach(function(f){ counts[f.severity]++; });
        var verdict;
        if (counts.BLOCKER>0) verdict="DO NOT DEPLOY";
        else if (counts.MAJOR>0) verdict="DEPLOY WITH FIXES";
        else if (counts.MINOR>0 || parsed.malformed.length>0) verdict="DEPLOY WITH FIXES";
        else verdict="SAFE TO DEPLOY";

        return {
          verdict:verdict, findings:findings,
          counts:{ BLOCKER:counts.BLOCKER, MAJOR:counts.MAJOR, MINOR:counts.MINOR, PASS:counts.PASS, INFO:counts.INFO,
                   NOT_PARSED:parsed.malformed.length, NOT_AUDITED:parsed.unknownKeys.length },
          parsed:{ interfaces:parsed.interfaces.length, peers:parsed.peers.length, keyLines:parsed.keyLines, totalLines:parsed.totalLines },
          notParsed:parsed.malformed, notAudited:parsed.unknownKeys
        };
      }

      /* ---------- Rendering ---------- */
      var SEV_ORDER=["BLOCKER","MAJOR","MINOR","INFO","PASS"];
      var lastResult=null;

      function esc(s){ return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"); }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-wireguard-vpn-config-safety-auditortm',
  name: 'J-Dawgs WireGuard VPN Config Safety Auditor',
  description: 'wg-quick startup only answers will-it-start; ours grades a pasted WireGuard config offline — keys by name/line/length only, AllowedIPs broadness, DNS-leak pairing — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
