'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Radarr Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Fixtures ---------- */
      var RISKY = [
        "<Config>",
        "  <Port>7878</Port>",
        "  <SslPort>9898</SslPort>",
        "  <EnableSsl>False</EnableSsl>",
        "  <BindAddress>*</BindAddress>",
        "  <ApiKey>testkey123</ApiKey>",
        "  <AuthenticationMethod>None</AuthenticationMethod>",
        "  <AuthenticationEnabled>False</AuthenticationEnabled>",
        "  <LogLevel>Info</LogLevel>",
        "  <IndexerPassword>hunter2secret</IndexerPassword>",
        "</Config>"
      ].join("\n");

      var HARDENED = [
        "<Config>",
        "  <Port>7878</Port>",
        "  <SslPort>9898</SslPort>",
        "  <EnableSsl>True</EnableSsl>",
        "  <BindAddress>127.0.0.1</BindAddress>",
        "  <ApiKey>9f2c7a41b8e04d6fa3c51e7b90d2f684</ApiKey>",
        "  <AuthenticationMethod>Forms</AuthenticationMethod>",
        "  <AuthenticationEnabled>True</AuthenticationEnabled>",
        "  <LogLevel>Info</LogLevel>",
        "</Config>"
      ].join("\n");

      /* ---------- Parsing ---------- */
      function normKey(raw){
        var k = String(raw).toLowerCase().replace(/[^a-z0-9]/g, "");
        if (k.indexOf("radarr") === 0) k = k.slice(6);
        return k;
      }
      function parseConfig(text){
        var entries = [];
        var lines = String(text).split(/\r?\n/);
        for (var i = 0; i < lines.length; i++){
          var raw = lines[i], lineNo = i + 1, m;
          m = raw.match(/^\s*<([A-Za-z][A-Za-z0-9_.\-]*)>\s*([^<]*?)\s*<\/[A-Za-z][A-Za-z0-9_.\-]*>\s*$/);
          if (m){
            entries.push({ key: normKey(m[1]), rawKey: m[1], value: m[2].trim(), line: lineNo });
            continue;
          }
          m = raw.match(/^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_.\-]*)\s*=\s*(.*?)\s*$/);
          if (m){
            var v = m[2];
            if (v.length >= 2 && ((v.charAt(0) === '"' && v.charAt(v.length-1) === '"') || (v.charAt(0) === "'" && v.charAt(v.length-1) === "'"))) v = v.slice(1, -1);
            entries.push({ key: normKey(m[1]), rawKey: m[1], value: v.trim(), line: lineNo });
          }
        }
        return entries;
      }
      function find(entries, key){
        for (var i = 0; i < entries.length; i++) if (entries[i].key === key) return entries[i];
        return null;
      }
      function isTrue(v){ return /^(true|1|yes|on|enabled)$/i.test(v); }
      function isFalse(v){ return /^(false|0|no|off|disabled|none|)$/i.test(v); }
      function isPlaceholder(v){
        var s = v.toLowerCase();
        return /^(test|example|sample|demo|changeme|change-me|placeholder|default|insert|your|xxx+|000+|1234|abcd)/.test(s)
          || s.indexOf("example") !== -1 || s.indexOf("placeholder") !== -1
          || s.indexOf("changeme") !== -1 || s.indexOf("your-api-key") !== -1
          || s.indexOf("testkey") !== -1 || s.indexOf("apikey") === 0;
      }
      function isPasswordKey(e){
        if (e.key === "apikey") return false;
        return e.key.indexOf("password") !== -1 || e.key.indexOf("passwd") !== -1 || /pwd$/.test(e.key);
      }
      function isRedacted(v){
        return /^[\*\u2022]+$/.test(v) || /^\[.*\]$/.test(v) || /^<.*>$/.test(v);
      }
      var KNOWN_PREFIX = ["apikey","authentication","bindaddress","enablessl","port","sslport","loglevel","certificatevalidation","sslcert","urlbase","branch","instancename","analyticsenabled","updatebranch"];
      function isKnown(e){
        if (isPasswordKey(e)) return true;
        for (var i = 0; i < KNOWN_PREFIX.length; i++) if (e.key.indexOf(KNOWN_PREFIX[i]) === 0) return true;
        return false;
      }

      /* ---------- Grading ---------- */
      function audit(text){
        var findings = [], passed = [];
        function add(sev, check, keyName, line, title, detail){
          findings.push({ severity: sev, check: check, key: keyName, line: line, title: title, detail: detail });
        }
        if (text === null || text === undefined || String(text).trim() === ""){
          return { verdict: "NOT ENOUGH TO GRADE", reason: "The input box is empty — paste a Radarr config.xml or KEY=VALUE environment text first.", findings: findings, passed: passed, recognized: 0 };
        }
        var entries = parseConfig(text);
        var known = entries.filter(isKnown);
        if (entries.length === 0){
          return { verdict: "NOT ENOUGH TO GRADE", reason: "No config.xml elements or KEY=VALUE lines were recognized — this looks like prose, not a Radarr config.", findings: findings, passed: passed, recognized: 0 };
        }
        if (known.length === 0){
          return { verdict: "NOT ENOUGH TO GRADE", reason: entries.length + " line(s) parsed as settings, but none are Radarr settings this auditor grades (no ApiKey, authentication, bind, SSL, port, log, or password settings found).", findings: findings, passed: passed, recognized: 0 };
        }

        /* Authentication */
        var authEnabled = find(entries, "authenticationenabled");
        var authMethod = find(entries, "authenticationmethod");
        var authBad = false;
        if (!authEnabled && !authMethod){
          add("BLOCKER", "authentication", "AuthenticationEnabled / AuthenticationMethod", null,
            "Authentication settings are missing",
            "Neither AuthenticationEnabled nor AuthenticationMethod is present, so there is no evidence of a login gate — a Radarr UI reached without one hands full control to anyone who can reach the port.");
          authBad = true;
        } else {
          if (authEnabled && isFalse(authEnabled.value)){
            add("BLOCKER", "authentication", authEnabled.rawKey, authEnabled.line,
              "Authentication is disabled",
              "AuthenticationEnabled is set to a disabled value — anyone who can reach the port controls the server, no login required.");
            authBad = true;
          }
          if (authMethod && /^(none|disabled|off|false)$/i.test(authMethod.value)){
            add("BLOCKER", "authentication", authMethod.rawKey, authMethod.line,
              "Authentication method is None",
              "AuthenticationMethod is set to \"" + authMethod.value + "\" — the web UI and API require no login.");
            authBad = true;
          }
        }
        if (!authBad){
          var bits = [];
          if (authEnabled) bits.push("AuthenticationEnabled on line " + authEnabled.line);
          if (authMethod) bits.push("AuthenticationMethod \"" + authMethod.value + "\" on line " + authMethod.line);
          passed.push("Authentication is enabled (" + bits.join("; ") + ")");
        }

        /* ApiKey — value never rendered, length only */
        var apiKey = find(entries, "apikey");
        if (!apiKey){
          add("BLOCKER", "apikey", "ApiKey", null,
            "ApiKey is missing",
            "No ApiKey setting was found. Without one the API cannot authenticate clients — and a missing key usually means this config was never fully generated by the server.");
        } else if (isPlaceholder(apiKey.value)){
          add("BLOCKER", "apikey", apiKey.rawKey, apiKey.line,
            "ApiKey is an example / placeholder value",
            "The ApiKey on this line matches a known example or placeholder pattern (length " + apiKey.value.length + " characters). Anyone who has seen the same example knows this key.");
        } else if (apiKey.value.length < 32){
          add("BLOCKER", "apikey", apiKey.rawKey, apiKey.line,
            "ApiKey is too short (" + apiKey.value.length + " characters)",
            "The ApiKey is only " + apiKey.value.length + " characters long; a genuine Radarr API key is 32 characters. Short keys are guessable and are usually copied examples.");
        } else {
          passed.push("ApiKey present at full length (" + apiKey.value.length + " characters, line " + apiKey.line + ") — value not shown");
        }

        /* BindAddress */
        var bind = find(entries, "bindaddress");
        if (bind && (bind.value === "*" || bind.value === "0.0.0.0" || bind.value === "::")){
          add("HIGH", "bindaddress", bind.rawKey, bind.line,
            "Bound to all network interfaces",
            "BindAddress is \"" + bind.value + "\" — the web UI listens on every interface, including the LAN and any exposed network. Prefer 127.0.0.1 behind a reverse proxy, or a single LAN address.");
        } else if (bind){
          passed.push("BindAddress is not a wildcard (" + bind.value + ", line " + bind.line + ")");
        } else {
          passed.push("BindAddress is not set to a wildcard (setting absent)");
        }

        /* EnableSsl */
        var ssl = find(entries, "enablessl");
        if (!ssl){
          add("HIGH", "enablessl", "EnableSsl", null,
            "EnableSsl is absent",
            "EnableSsl does not appear in the config, so the UI and API are served over plain HTTP — logins and the API key travel in cleartext.");
        } else if (isFalse(ssl.value)){
          add("HIGH", "enablessl", ssl.rawKey, ssl.line,
            "SSL is disabled",
            "EnableSsl is false — the web UI and API run over plain HTTP, so credentials and the API key cross the network in cleartext.");
        } else {
          passed.push("SSL is enabled (EnableSsl, line " + ssl.line + ")");
        }

        /* Ports */
        var port = find(entries, "port");
        var sslPort = find(entries, "sslport");
        var portProblem = false;
        function portNum(e){ var n = parseInt(e.value, 10); return (String(n) === e.value.trim() || /^\d+$/.test(e.value.trim())) ? n : NaN; }
        if (port && isNaN(portNum(port))){
          add("WARNING", "ports", port.rawKey, port.line, "Port is not a number", "Port is set to \"" + port.value + "\", which is not a valid TCP port number.");
          portProblem = true;
        }
        if (sslPort && isNaN(portNum(sslPort))){
          add("WARNING", "ports", sslPort.rawKey, sslPort.line, "SslPort is not a number", "SslPort is set to \"" + sslPort.value + "\", which is not a valid TCP port number.");
          portProblem = true;
        }
        if (port && sslPort && !isNaN(portNum(port)) && !isNaN(portNum(sslPort))){
          if (portNum(port) === portNum(sslPort)){
            add("WARNING", "ports", port.rawKey + " / " + sslPort.rawKey, port.line,
              "Port and SslPort conflict (both " + portNum(port) + ")",
              "Port (line " + port.line + ") and SslPort (line " + sslPort.line + ") are the same number — the plain and SSL listeners collide and one of them will fail to start.");
            portProblem = true;
          }
          if (portNum(port) < 1 || portNum(port) > 65535 || portNum(sslPort) < 1 || portNum(sslPort) > 65535){
            add("WARNING", "ports", "Port / SslPort", null, "Port out of range", "A configured port falls outside the valid 1–65535 range.");
            portProblem = true;
          }
        }
        if (!portProblem && port && sslPort) passed.push("Port (" + portNum(port) + ", line " + port.line + ") and SslPort (" + portNum(sslPort) + ", line " + sslPort.line + ") do not conflict");
        else if (!portProblem) passed.push("No port conflict detected");

        /* Plaintext passwords — name, line, length only */
        var pwCount = 0;
        entries.forEach(function(e){
          if (!isPasswordKey(e)) return;
          if (e.value === "") return;
          if (isRedacted(e.value)){ passed.push("Password setting " + e.rawKey + " is redacted in the paste (line " + e.line + ")"); return; }
          pwCount++;
          add("HIGH", "plaintext-password", e.rawKey, e.line,
            "Plaintext password stored (" + e.rawKey + ")",
            "A password for a download client, indexer, or notification service is stored in plaintext under " + e.rawKey + " (length " + e.value.length + " characters — value not shown). Anyone who reads this file owns that account.");
        });
        if (pwCount === 0 && !passed.some(function(p){ return p.indexOf("redacted") !== -1; })){
          passed.push("No plaintext password settings found");
        }

        /* LogLevel */
        var log = find(entries, "loglevel");
        if (log && /^(debug|trace)$/i.test(log.value)){
          add("WARNING", "loglevel", log.rawKey, log.line,
            "LogLevel is \"" + log.value + "\"",
            "Debug/trace logging is verbose enough to capture credentials, tokens, and request URLs in the log files. Run Info in production.");
        } else if (log){
          passed.push("LogLevel is \"" + log.value + "\" (line " + log.line + ")");
        } else {
          passed.push("LogLevel is not set to debug/trace (setting absent)");
        }

        /* CertificateValidation */
        var cert = null;
        entries.forEach(function(e){ if (e.key.indexOf("certificatevalidation") !== -1 && !cert) cert = e; });
        if (cert){
          var cv = cert.value.toLowerCase().replace(/[^a-z]/g, "");
          if (cv === "disabled"){
            add("HIGH", "certificatevalidation", cert.rawKey, cert.line,
              "Certificate validation is disabled",
              "CertificateValidation is disabled — TLS to indexers and download clients can be intercepted or spoofed without any warning.");
          } else if (cv.indexOf("disabledforlocal") === 0){
            add("WARNING", "certificatevalidation", cert.rawKey, cert.line,
              "Certificate validation disabled for local addresses",
              "CertificateValidation is relaxed for local addresses only. Acceptable on a trusted LAN, but know that local TLS is not being verified.");
          } else {
            passed.push("Certificate validation is not disabled (" + cert.rawKey + ", line " + cert.line + ")");
          }
        } else {
          passed.push("CertificateValidation is not disabled (setting absent)");
        }

        /* Verdict */
        var blockers = findings.filter(function(f){ return f.severity === "BLOCKER"; }).length;
        var highs = findings.filter(function(f){ return f.severity === "HIGH"; }).length;
        var warns = findings.filter(function(f){ return f.severity === "WARNING"; }).length;
        var verdict, reason;
        if (blockers > 0){
          verdict = "DO NOT DEPLOY";
          reason = blockers + " blocker(s) must be fixed before this server is exposed anywhere: " + findings.filter(function(f){ return f.severity === "BLOCKER"; }).map(function(f){ return f.title; }).join("; ") + ".";
        } else if (highs > 0 || warns > 0){
          verdict = "DEPLOY WITH FIXES";
          reason = "No blockers, but " + (highs + warns) + " finding(s) (" + highs + " high, " + warns + " warning) should be fixed before this config faces a network.";
        } else {
          verdict = "SAFE TO DEPLOY";
          reason = "Every graded check passed: authentication on, full-length API key, no wildcard bind, SSL on, no port conflict, no plaintext passwords, sane log level.";
        }
        return { verdict: verdict, reason: reason, findings: findings, passed: passed, recognized: known.length };
      }

      /* ---------- Reports (secret values never included) ---------- */
      function lineLabel(f){ return f.line === null ? "not present" : "line " + f.line; }
      function textReport(r){
        var out = [];
        out.push("J-Dawgs Radarr Server Config Safety Auditor — report");
        out.push("Verdict: " + r.verdict);
        out.push("Reason: " + r.reason);
        out.push("Recognized Radarr settings: " + r.recognized);
        out.push("");
        out.push("Findings (" + r.findings.length + "):");
        if (r.findings.length === 0) out.push("  (none)");
        r.findings.forEach(function(f){
          out.push("  [" + f.severity + "] " + f.title + " — " + f.key + ", " + lineLabel(f));
          out.push("      " + f.detail);
        });
        out.push("");
        out.push("Passed checks (" + r.passed.length + "):");
        r.passed.forEach(function(p){ out.push("  PASS  " + p); });
        out.push("");
        out.push("Note: secret values are never printed — findings carry setting name, line, and value length only.");
        return out.join("\n");
      }
      function jsonReport(r){
        return JSON.stringify({
          tool: "J-Dawgs Radarr Server Config Safety Auditor",
          verdict: r.verdict,
          reason: r.reason,
          recognizedSettings: r.recognized,
          counts: {
            blockers: r.findings.filter(function(f){ return f.severity === "BLOCKER"; }).length,
            high: r.findings.filter(function(f){ return f.severity === "HIGH"; }).length,
            warnings: r.findings.filter(function(f){ return f.severity === "WARNING"; }).length,
            passed: r.passed.length
          },
          findings: r.findings.map(function(f){
            return { severity: f.severity, check: f.check, key: f.key, line: f.line, title: f.title, detail: f.detail };
          }),
          passedChecks: r.passed,
          note: "Secret values are never included; findings carry setting name, line, and value length only."
        }, null, 2);
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-radarr-server-config-safety-auditortm',
  name: 'J-Dawgs Radarr Server Config Safety Auditor',
  description: 'Radarr\'s own checks only answer whether the service starts on the host; ours grades a pasted Radarr config.xml or env fully offline — authentication disabled, a short or example ApiKey, wildcard bind, SSL off, plaintext download-client and indexer passwords — into one deploy verdict, with secrets sh',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
