'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Stunnel TLS Proxy Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var KNOWN = {};
      ("accept backlog bind CAfile CApath cert checkEmail checkHost checkIP ciphers ciphersuites client config connect CRLfile CRLpath curve debug delay deny exec execArgs failover foreground ident include key libwrap local logId OCSP OCSPaia OCSPflag options output pid protocol protocolAuthentication protocolHost protocolPassword protocolUsername pskIdentity pskSecrets renegotiation requireCert retry service session sessiond setgid setuid chroot socket sslVersion sslVersionMin sslVersionMax stack stats TIMEOUTbusy TIMEOUTclose TIMEOUTconnect TIMEOUTidle transparent verify verifyChain verifyPeer").split(" ").forEach(function(k){ KNOWN[k]=true; });

      function isOn(v){ return /^(yes|on|true|1)$/i.test(String(v).trim()); }
      function isOff(v){ return /^(no|off|false|0)$/i.test(String(v).trim()); }

      function redactPreview(raw){
        var s = String(raw).trim();
        if (/PRIVATE KEY|BEGIN [A-Z ]*KEY/i.test(s)) return "[line withheld — it looks like key material, which this tool never displays]";
        s = s.replace(/[A-Za-z0-9+\/=]{24,}/g, "[redacted]");
        if (s.length > 70) s = s.slice(0,70) + "…";
        return s;
      }

      function parseConfig(text){
        var lines = String(text).split(/\r?\n/);
        var global = { name:"global", line:0, dirs:[] };
        var services = [];
        var current = global;
        var notParsed = [];
        var parsedCount = 0;
        lines.forEach(function(raw, i){
          var n = i + 1;
          var line = raw.trim();
          if (!line) return;
          if (line.charAt(0) === ";" || line.charAt(0) === "#") return;
          var sec = line.match(/^\[([^\]]+)\]\s*$/);
          if (sec){
            var svc = { name: sec[1].trim(), line: n, dirs: [] };
            services.push(svc); current = svc; parsedCount++; return;
          }
          var d = line.match(/^([A-Za-z][A-Za-z0-9]*)\s*=\s*(\S.*)$/);
          if (d){
            current.dirs.push({ key:d[1], value:d[2].trim(), line:n });
            parsedCount++; return;
          }
          notParsed.push({ line:n, section:current.name, raw:raw });
        });
        return { global:global, services:services, notParsed:notParsed, parsedCount:parsedCount };
      }

      function getAll(section, key){
        var out = [];
        section.dirs.forEach(function(d){ if (d.key.toLowerCase() === key.toLowerCase()) out.push(d); });
        return out;
      }
      function getLast(section, key){
        var all = getAll(section, key);
        return all.length ? all[all.length-1] : null;
      }
      function eff(svc, global, key){
        return getLast(svc, key) || getLast(global, key);
      }
      function effOptions(svc, global){
        return getAll(global, "options").concat(getAll(svc, "options"));
      }

      function parseHostPort(v){
        if (!v) return { host:null, port:null };
        v = String(v).trim();
        if (v.charAt(0) === "/") return { host:"(unix socket)", port:null, unix:true };
        var m = v.match(/^\[([^\]]+)\]:(\d+)$/);
        if (m) return { host:m[1], port:m[2] };
        var idx = v.lastIndexOf(":");
        if (idx > 0 && /^\d+$/.test(v.slice(idx+1))) return { host:v.slice(0,idx), port:v.slice(idx+1) };
        if (/^\d+$/.test(v)) return { host:null, port:v };
        return { host:v, port:null };
      }
      function isLoopback(host){
        if (!host) return false;
        var h = String(host).toLowerCase();
        return h === "localhost" || h === "::1" || h.indexOf("127.") === 0;
      }
      function bindsAll(host){ return !host || host === "0.0.0.0" || host === "::" || host === "*"; }

      function F(list, sev, section, line, text, fix){
        list.push({ sev:sev, section:section, line:line, text:text, fix:fix || null });
      }

      function auditGlobal(global, list){
        var dbg = getLast(global, "debug");
        if (dbg){
          var lvl = parseInt(dbg.value, 10);
          if (!isNaN(lvl) && lvl >= 6){
            F(list, "warn", "global", dbg.line, "debug = " + dbg.value + " is verbose logging — at this level stunnel can write sensitive session detail to its log.", "Drop to debug = 5 or lower for production.");
          }
        }
        var fg = getLast(global, "foreground");
        if (fg && isOn(fg.value)){
          F(list, "note", "global", fg.line, "foreground = yes: stunnel stays in the foreground — right under a service manager or in a container, surprising in an interactive shell.");
        }
        var su = getLast(global, "setuid"), sg = getLast(global, "setgid");
        if (su){
          if (su.value === "root" || su.value === "0"){
            F(list, "warn", "global", su.line, "setuid = " + su.value + " keeps stunnel running as root — the privilege drop buys nothing.", "Point setuid at a dedicated unprivileged account.");
          } else {
            F(list, "good", "global", su.line, "Privilege drop configured: stunnel setuids to \"" + su.value + "\" after startup.");
          }
        }
        if (sg){
          if (sg.value === "root" || sg.value === "0"){
            F(list, "warn", "global", sg.line, "setgid = " + sg.value + " keeps the root group — the privilege drop buys nothing.", "Point setgid at a dedicated unprivileged group.");
          } else {
            F(list, "good", "global", sg.line, "Privilege drop configured: stunnel setgids to \"" + sg.value + "\" after startup.");
          }
        }
        if (!su && !sg){
          F(list, "note", "global", null, "No setuid/setgid: stunnel keeps the privileges of whoever starts it. Started as root, it stays root.", "Start it as an unprivileged user, or add setuid/setgid for a dedicated account.");
        }
        var ch = getLast(global, "chroot");
        if (ch){
          F(list, "good", "global", ch.line, "chroot jail configured (" + ch.value + ") — a compromised stunnel sees only that tree.");
        }
      }

      function auditService(svc, global, list){
        var name = svc.name;
        var clientDir = eff(svc, global, "client");
        var clientMode = !!(clientDir && isOn(clientDir.value));
        F(list, "note", name, clientDir ? clientDir.line : svc.line,
          clientMode ? "Mode: client (client = yes) — this service dials out to a TLS server and offers a plaintext listener locally."
                     : "Mode: server — this service terminates incoming TLS and forwards plaintext to its connect target.");

        /* ---- accept / binding ---- */
        var accDir = getLast(svc, "accept");
        var acc = accDir ? parseHostPort(accDir.value) : null;
        var publicAccept = false;
        if (!accDir){
          F(list, "warn", name, svc.line, "No accept directive — this service defines no listening socket, so nothing can connect to it.", "Add accept = <port>, or accept = 127.0.0.1:<port> to keep it on this host only.");
        } else if (acc.unix){
          F(list, "note", name, accDir.line, "accept is a unix socket (" + accDir.value + ") — reachable only by local processes with filesystem access.");
        } else if (isLoopback(acc.host)){
          F(list, "good", name, accDir.line, "accept binds loopback only (" + accDir.value + ") — reachable from this host, not from the network.");
        } else {
          publicAccept = true;
          if (bindsAll(acc.host)){
            F(list, "note", name, accDir.line, "accept = " + accDir.value + " has no host part, so it binds every interface — reachable from the network.");
          } else {
            F(list, "note", name, accDir.line, "accept binds " + acc.host + ", a non-loopback address — reachable from the network.");
          }
          if (clientMode){
            F(list, "warn", name, accDir.line, "Client mode with a network-reachable accept: any host that can reach this port can push traffic through your outbound TLS tunnel.", "Bind the client-mode listener to loopback: accept = 127.0.0.1:" + (acc.port || "<port>") + ".");
          }
        }

        /* ---- verification ---- */
        var verifyDir = eff(svc, global, "verify");
        var vChain = eff(svc, global, "verifyChain");
        var vPeer = eff(svc, global, "verifyPeer");
        var reqCert = eff(svc, global, "requireCert");
        var caFile = eff(svc, global, "CAfile");
        var verificationOn = !!((vChain && isOn(vChain.value)) || (vPeer && isOn(vPeer.value)) || (reqCert && isOn(reqCert.value)));
        if (verifyDir){
          var vl = parseInt(verifyDir.value, 10);
          if (vl === 0){
            if (!clientMode && publicAccept){
              F(list, "blocker", name, verifyDir.line, "verify = 0 with a network-reachable accept: peer certificates are not checked at all — anyone can connect, and a man-in-the-middle is invisible.", "Set verify = 2 with a CAfile holding the peers you trust, or turn on verifyChain / verifyPeer.");
            } else if (!clientMode){
              F(list, "warn", name, verifyDir.line, "verify = 0: peer certificates are not checked at all. The listener is loopback-only, so exposure is local — but any local process can connect.", "Set verify = 2 with a CAfile, or turn on verifyChain / verifyPeer.");
            } else {
              F(list, "warn", name, verifyDir.line, "Client mode with verify = 0: the TLS server this service dials is never authenticated.", "Set verify = 2 with a CAfile, or verifyChain = yes, so the remote server is checked.");
            }
          } else if (vl === 1){
            if (!clientMode && publicAccept){
              F(list, "blocker", name, verifyDir.line, "verify = 1 with a network-reachable accept: a peer is checked only if it happens to present a certificate — presenting none sails through.", "Set verify = 2 with a CAfile holding the peers you trust, or turn on verifyChain / verifyPeer.");
            } else {
              F(list, "warn", name, verifyDir.line, "verify = 1 checks a peer's certificate only if one is presented — a peer with no certificate is accepted unchecked.", "Set verify = 2 with a CAfile, or turn on verifyChain / verifyPeer.");
            }
          } else if (vl === 2){
            verificationOn = true;
            if (!caFile){
              F(list, "warn", name, verifyDir.line, "verify = 2 needs a CAfile to check peers against, and none is configured — verification has nothing to trust.", "Add CAfile = /path/to/trusted-peers.pem.");
            } else {
              F(list, "good", name, verifyDir.line, "Peer certificates are required and verified against a CAfile (verify = 2).");
            }
          } else if (vl >= 3){
            verificationOn = true;
            F(list, "good", name, verifyDir.line, "Strict peer verification configured (verify = " + vl + ").");
          }
        }
        if (vChain && isOff(vChain.value)){
          if (!clientMode && publicAccept){
            F(list, "blocker", name, vChain.line, "verifyChain = " + vChain.value + " with a network-reachable accept: peer certificate chains are not verified.", "Set verifyChain = yes with a CAfile, or use verify = 2.");
          } else {
            F(list, "warn", name, vChain.line, "verifyChain = " + vChain.value + ": peer certificate chains are not verified.", "Set verifyChain = yes with a CAfile, or use verify = 2.");
          }
        }
        if (vPeer && isOff(vPeer.value)){
          if (!clientMode && publicAccept){
            F(list, "blocker", name, vPeer.line, "verifyPeer = " + vPeer.value + " with a network-reachable accept: the peer certificate itself is not verified.", "Set verifyPeer = yes with a CAfile, or use verify = 2.");
          } else {
            F(list, "warn", name, vPeer.line, "verifyPeer = " + vPeer.value + ": the peer certificate itself is not verified.", "Set verifyPeer = yes with a CAfile, or use verify = 2.");
          }
        }
        if ((vChain && isOn(vChain.value) || vPeer && isOn(vPeer.value)) && !caFile && !(verifyDir && parseInt(verifyDir.value,10) >= 2)){
          var onDir = (vChain && isOn(vChain.value)) ? vChain : vPeer;
          F(list, "warn", name, onDir.line, "Chain/peer verification is switched on but no CAfile is configured to verify against.", "Add CAfile = /path/to/ca.pem.");
        }
        var chainPeerOff = !!((vChain && isOff(vChain.value)) || (vPeer && isOff(vPeer.value)));
        if (!verifyDir && !verificationOn && !chainPeerOff){
          if (!clientMode && publicAccept){
            F(list, "blocker", name, svc.line, "No peer verification is configured (no verify, verifyChain, verifyPeer, or requireCert) and accept is network-reachable — stunnel's default accepts any peer, certificate or not.", "Add verify = 2 with a CAfile, or verifyChain = yes.");
          } else if (!clientMode){
            F(list, "note", name, svc.line, "No peer verification configured. The listener is loopback-only, so exposure is limited to this host.");
          } else {
            F(list, "note", name, svc.line, "Client mode with no explicit server-verification directives — add verifyChain = yes with a CAfile to pin down which server you are really talking to.");
          }
        } else if (clientMode && verificationOn){
          F(list, "good", name, svc.line, "Outbound server verification is configured for this client-mode service.");
        }

        /* ---- cert / key posture ---- */
        var certDir = eff(svc, global, "cert");
        var keyDir = eff(svc, global, "key");
        if (!clientMode){
          if (!certDir){
            F(list, "blocker", name, svc.line, "Server mode with no cert directive: stunnel has no certificate to present to connecting peers, so the TLS listener cannot run as configured.", "Add cert = /path/to/server-cert.pem (and key = /path/to/server-key.pem if the key lives in its own file).");
          } else {
            F(list, "good", name, certDir.line, "Certificate declared: cert = " + certDir.value + ". This tool notes the path only — the file is never opened.");
          }
          if (keyDir){
            F(list, "good", name, keyDir.line, "A private key is declared by the key directive at line " + keyDir.line + " — reported by name and line only; its value and the file's contents are never displayed.");
          } else if (certDir){
            F(list, "note", name, certDir.line, "No separate key directive — stunnel will look for the private key inside the cert file itself.");
          }
        } else {
          if (certDir){
            F(list, "note", name, certDir.line, "cert is set in client mode — only needed when the remote server asks this service to present a client certificate.");
          }
          if (keyDir){
            F(list, "note", name, keyDir.line, "A private key is declared by the key directive at line " + keyDir.line + " — reported by name and line only; its value and the file's contents are never displayed.");
          }
        }

        /* ---- protocol / cipher posture ---- */
        var svMin = eff(svc, global, "sslVersionMin");
        var sv = eff(svc, global, "sslVersion");
        var weakProto = null, protoLine = null;
        function protoWeak(v){
          var toks = String(v).split(/[\s,]+/);
          for (var i=0;i<toks.length;i++){
            var t = toks[i];
            if (/^all$/i.test(t) || /^SSLv[23]$/i.test(t) || /^TLSv1(\.0|\.1)?$/i.test(t)) return t;
          }
          return null;
        }
        if (svMin){
          var w1 = protoWeak(svMin.value);
          if (w1){ weakProto = "sslVersionMin = " + svMin.value; protoLine = svMin.line; }
          else F(list, "good", name, svMin.line, "Protocol floor pinned at " + svMin.value + " — nothing older is negotiated.");
        }
        if (sv){
          var w2 = protoWeak(sv.value);
          if (w2){ weakProto = "sslVersion = " + sv.value; protoLine = sv.line; }
          else if (!svMin) F(list, "good", name, sv.line, "Protocol version restricted by sslVersion = " + sv.value + ".");
        }
        if (weakProto){
          F(list, "warn", name, protoLine, "Weak protocol versions are allowed (" + weakProto + ") — SSLv3 and TLS 1.0/1.1 have known attacks and no place on a deployed tunnel.", "Pin the floor: sslVersionMin = TLSv1.2, and add options = NO_SSLv3, NO_TLSv1, NO_TLSv1_1.");
        }
        if (!sv && !svMin){
          F(list, "warn", name, svc.line, "No protocol floor is pinned (no sslVersion or sslVersionMin) — what gets negotiated is left to build-time defaults.", "Add sslVersionMin = TLSv1.2 so the floor is explicit and survives upgrades.");
        }
        var opts = effOptions(svc, global);
        var disabled = [];
        opts.forEach(function(o){
          String(o.value).split(/[\s,]+/).forEach(function(t){ if (/^NO_(SSLv|TLSv)/i.test(t)) disabled.push(t); });
        });
        if (disabled.length){
          F(list, "good", name, opts[0].line, "options hard-disables legacy protocols: " + disabled.join(", ") + ".");
        }
        var ciph = eff(svc, global, "ciphers");
        if (ciph){
          var weakToks = [];
          String(ciph.value).split(":").forEach(function(tok){
            var t = tok.trim().toUpperCase();
            if (!t) return;
            if (t.indexOf("RC4") >= 0 || t.indexOf("MD5") >= 0 || t.indexOf("NULL") >= 0 || t.indexOf("EXP") === 0 ||
                t.indexOf("3DES") >= 0 || t.indexOf("DES-CBC") >= 0 || t === "DES" || t.indexOf("ADH") >= 0 || t.indexOf("LOW") === 0){
              weakToks.push(tok.trim());
            }
          });
          if (weakToks.length){
            F(list, "warn", name, ciph.line, "The pinned ciphers list includes weak entries: " + weakToks.join(", ") + ".", "Rebuild the ciphers list from AEAD suites only (AES-GCM / ChaCha20-Poly1305 with ECDHE key exchange).");
          } else {
            F(list, "good", name, ciph.line, "Cipher list is pinned and contains no known-weak entries this tool checks for.");
          }
        } else {
          F(list, "note", name, svc.line, "No ciphers list pinned — the host's OpenSSL defaults decide what is negotiable.");
        }

        /* ---- connect / plaintext leg ---- */
        var conDir = getLast(svc, "connect");
        if (!conDir){
          F(list, "warn", name, svc.line,
            clientMode ? "Client mode with no connect directive — there is no TLS endpoint for this service to dial."
                       : "Server mode with no connect directive — accepted TLS connections have nowhere to go.",
            "Add connect = <host>:<port> for the service on the other side of the tunnel.");
        } else {
          var con = parseHostPort(conDir.value);
          if (con.unix){
            F(list, "good", name, conDir.line, "connect target is a unix socket on this host — the plaintext leg never leaves the machine.");
          } else if (isLoopback(con.host)){
            if (!clientMode) F(list, "good", name, conDir.line, "connect target is loopback (" + conDir.value + ") — the plaintext leg stays on this host.");
            else F(list, "note", name, conDir.line, "connect target is loopback (" + conDir.value + ") — unusual for client mode, which normally dials a remote TLS server.");
          } else if (con.host){
            if (!clientMode){
              F(list, "warn", name, conDir.line, "connect target " + con.host + " is not loopback: once stunnel strips the TLS, that leg crosses the network in plaintext.", "Move the backend onto this host, or protect that leg separately (a second tunnel, a private network) — do not let it cross a shared network bare.");
            } else {
              F(list, "note", name, conDir.line, "connect target is the remote TLS endpoint (" + con.host + ") — that leg is the encrypted one in client mode.");
            }
          }
        }
      }

      function audit(text){
        var parsed = parseConfig(text);
        var list = [];
        auditGlobal(parsed.global, list);
        parsed.global.dirs.forEach(function(d){
          if (!KNOWN[d.key]) F(list, "note", "global", d.line, "Directive \"" + d.key + "\" is not in this auditor's rule set — it was read, but not graded.");
        });
        if (!parsed.services.length){
          F(list, "blocker", "global", null, "No [service] sections found — a stunnel config with no services tunnels nothing.", "Add at least one [service] section with accept and connect directives.");
        }
        parsed.services.forEach(function(svc){
          auditService(svc, parsed.global, list);
          svc.dirs.forEach(function(d){
            if (!KNOWN[d.key]) F(list, "note", svc.name, d.line, "Directive \"" + d.key + "\" is not in this auditor's rule set — it was read, but not graded.");
          });
        });
        parsed.notParsed.forEach(function(np){
          F(list, "warn", np.section, np.line, "NOT PARSED — line " + np.line + " is not a section header, comment, or key = value directive, so it was not guessed at: \"" + redactPreview(np.raw) + "\"", "Fix or remove line " + np.line + " — stunnel will refuse a config it cannot parse either.");
        });
        var sevRank = { blocker:0, warn:1, note:2, good:3 };
        list.sort(function(a,b){
          var la = a.line == null ? 1e9 : a.line, lb = b.line == null ? 1e9 : b.line;
          if (la !== lb) return la - lb;
          return sevRank[a.sev] - sevRank[b.sev];
        });
        var counts = { blocker:0, warn:0, note:0, good:0 };
        list.forEach(function(f){ counts[f.sev]++; });
        var verdict = counts.blocker > 0 ? "DO NOT DEPLOY" : (counts.warn > 0 ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY");
        return { findings:list, counts:counts, verdict:verdict, services:parsed.services.length, notParsed:parsed.notParsed.length };
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-stunnel-tls-proxy-config-safety-auditor',
  name: 'J-Dawgs Stunnel TLS Proxy Config Safety Auditor',
  description: 'stunnel -test only answers will-it-load; ours grades a pasted stunnel.conf offline — certificate verification, bind exposure, and cipher posture — into one deploy verdict, key values never rendered.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
