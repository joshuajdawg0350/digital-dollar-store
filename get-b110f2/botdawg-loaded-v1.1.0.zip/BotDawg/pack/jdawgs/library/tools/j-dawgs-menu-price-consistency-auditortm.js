'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Menu & Price Consistency Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var EXAMPLE_1 = [
        "SOURCE: In-store board",
        "Classic Burger — $11.00 — Grilled beef patty with cheddar",
        "Fries — $4.50 — Crispy shoestring fries",
        "Vanilla Shake — $6.00 — Hand-spun vanilla shake",
        "",
        "SOURCE: Website menu",
        "Classic Burger — $12.50 — Grilled beef patty with cheddar",
        "Fries — $4.50 — Crispy shoestring fries",
        "Vanilla Shake — $6.00 — Hand-spun vanilla shake",
        "",
        "SOURCE: Delivery app",
        "Classic Burger — $12.50 — Grilled beef patty with cheddar",
        "Vanilla Shake — $6.00 — Thick vanilla bean shake with whipped cream"
      ].join("\n");

      var EXAMPLE_2 = [
        "SOURCE: In-store board",
        "Classic Burger — $11.00 — Grilled beef patty with cheddar",
        "Fries — $4.50 — Crispy shoestring fries",
        "Vanilla Shake — $6.00 — Hand-spun vanilla shake",
        "",
        "SOURCE: Website menu",
        "Classic Burger — $11.00 — Grilled beef patty with cheddar",
        "Fries — $4.50 — Crispy shoestring fries",
        "Vanilla Shake — $6.00 — Hand-spun vanilla shake",
        "",
        "SOURCE: Delivery app",
        "Classic Burger — $11.00 — Grilled beef patty with cheddar",
        "Fries — $4.50 — Crispy shoestring fries",
        "Vanilla Shake — $6.00 — Hand-spun vanilla shake"
      ].join("\n");

      function fmtMoney(cents) {
        var sign = cents < 0 ? "-$" : "$";
        var abs = Math.abs(cents);
        var dollars = Math.floor(abs / 100);
        var rem = abs % 100;
        return sign + dollars + "." + (rem < 10 ? "0" : "") + rem;
      }

      function normalizeName(name) {
        return name.toLowerCase().replace(/\s+/g, " ").replace(/[\s.,;:!?"'’‘“”]+$/, "").trim();
      }

      function normalizeDesc(desc) {
        return desc.replace(/\s+/g, " ").trim();
      }

      /* Split pasted text into blocks. A new block starts at every
         "SOURCE:" line and after a blank line. A block whose first
         content line is not a SOURCE: line is unlabeled. */
      function splitBlocks(text) {
        var lines = text.split(/\r?\n/);
        var blocks = [];
        var cur = null;
        function flush() {
          if (cur && cur.lines.some(function (l) { return l.trim() !== ""; })) {
            blocks.push(cur);
          }
          cur = null;
        }
        lines.forEach(function (line) {
          var t = line.trim();
          if (/^source\s*:/i.test(t)) {
            flush();
            cur = { labeled: true, label: t.replace(/^source\s*:/i, "").trim(), lines: [] };
          } else if (t === "") {
            if (cur && cur.lines.some(function (l) { return l.trim() !== ""; })) flush();
          } else {
            if (!cur) cur = { labeled: false, label: null, lines: [] };
            cur.lines.push(line);
          }
        });
        flush();
        return blocks;
      }

      /* Parse one item line. Separators: —, –, ..., |
         Returns { name, priceCents|null, desc } or null if no name. */
      function parseItemLine(raw) {
        var parts = raw.split(/—|–|\.\.\.|\|/).map(function (s) { return s.trim(); });
        if (!parts.length || parts[0] === "") return null;
        var priceCents = null;
        var priceIdx = -1;
        var namePart = parts[0];
        for (var i = 0; i < parts.length; i++) {
          var m = parts[i].match(/\$\s*(\d{1,3}(?:,\d{3})*(?:\.\d{1,2})?|\d+(?:\.\d{1,2})?)/);
          if (m) {
            priceCents = Math.round(parseFloat(m[1].replace(/,/g, "")) * 100);
            priceIdx = i;
            if (i === 0) {
              namePart = parts[0].slice(0, parts[0].indexOf(m[0])).trim();
            }
            break;
          }
        }
        var name = namePart.replace(/\s+/g, " ").trim();
        if (name === "") return null;
        var descParts = [];
        for (var j = 1; j < parts.length; j++) {
          if (j === priceIdx) {
            var rest = parts[j].replace(/\$\s*(\d{1,3}(?:,\d{3})*(?:\.\d{1,2})?|\d+(?:\.\d{1,2})?)/, "").trim();
            if (rest) descParts.push(rest);
          } else if (parts[j] !== "") {
            descParts.push(parts[j]);
          }
        }
        return { name: name, priceCents: priceCents, desc: normalizeDesc(descParts.join(" — ")) };
      }

      function parseSource(block) {
        var items = [];
        block.lines.forEach(function (line) {
          if (line.trim() === "") return;
          var it = parseItemLine(line);
          if (it) items.push(it);
        });
        return { name: block.label || "Unnamed source", items: items };
      }

      function audit(text) {
        var blocks = splitBlocks(text);
        var excluded = [];
        var sources = [];
        blocks.forEach(function (b, idx) {
          if (!b.labeled) {
            excluded.push({ block: idx + 1, reason: "No SOURCE: label — reported by block number and excluded; its source was not guessed." });
          } else if (sources.length >= 4) {
            excluded.push({ block: idx + 1, reason: "Beyond the 4-copy limit — excluded." });
          } else {
            sources.push(parseSource(b));
          }
        });

        var result = {
          sources: sources,
          excluded: excluded,
          items: [],
          possibleMatches: [],
          duplicateNotes: [],
          totals: [],
          counts: { blockers: 0, warnings: 0, notes: 0, matched: 0 },
          verdict: "NOT ENOUGH TO COMPARE",
          verdictClass: "warn",
          verdictNote: ""
        };

        /* Per-source totals */
        sources.forEach(function (s) {
          var priced = s.items.filter(function (i) { return i.priceCents !== null; });
          var sum = priced.reduce(function (a, i) { return a + i.priceCents; }, 0);
          var basis = priced.length
            ? priced.map(function (i) { return fmtMoney(i.priceCents); }).join(" + ") + " = " + fmtMoney(sum)
            : "no stated prices";
          result.totals.push({
            source: s.name,
            itemCount: s.items.length,
            pricedCount: priced.length,
            noPriceCount: s.items.length - priced.length,
            totalCents: sum,
            basis: basis
          });
        });

        if (sources.length < 2) {
          result.verdictNote = sources.length === 0
            ? "No labeled copies were found. Paste at least 2 copies, each starting with a SOURCE: line."
            : "Only 1 labeled copy was pasted. Paste at least one more copy to compare against it.";
          result.counts.notes = excluded.length;
          return finishCounts(result);
        }

        /* Union of items by normalized name, first-seen order */
        var order = [];
        var byKey = {};
        sources.forEach(function (s, si) {
          var seenHere = {};
          s.items.forEach(function (it) {
            var key = normalizeName(it.name);
            if (!byKey[key]) {
              byKey[key] = { key: key, name: it.name, per: sources.map(function () { return null; }) };
              order.push(key);
            }
            if (seenHere[key]) {
              result.duplicateNotes.push("“" + it.name + "” is listed more than once in " + s.name + " — the first listing was used.");
            } else {
              seenHere[key] = true;
              byKey[key].per[si] = it;
            }
          });
        });

        order.forEach(function (key) {
          var rec = byKey[key];
          var item = { name: rec.name, key: key, perSource: [], findings: [], grade: "MATCH" };
          var pricedIdx = [], distinctPrices = [], priceCount = {};
          var presentDescs = {};

          rec.per.forEach(function (entry, si) {
            var srcName = sources[si].name;
            if (!entry) {
              item.perSource.push({ source: srcName, state: "MISSING FROM", price: null, desc: null });
            } else if (entry.priceCents === null) {
              item.perSource.push({ source: srcName, state: "NO PRICE STATED", price: null, desc: entry.desc });
            } else {
              item.perSource.push({ source: srcName, state: "PRICED", price: entry.priceCents, desc: entry.desc });
              pricedIdx.push(si);
              if (distinctPrices.indexOf(entry.priceCents) === -1) distinctPrices.push(entry.priceCents);
              priceCount[entry.priceCents] = (priceCount[entry.priceCents] || 0) + 1;
            }
            if (entry && entry.desc) {
              if (!presentDescs[entry.desc]) presentDescs[entry.desc] = [];
              presentDescs[entry.desc].push(srcName);
            }
          });

          /* Price grading */
          if (distinctPrices.length > 1) {
            var sorted = distinctPrices.slice().sort(function (a, b) { return a - b; });
            var lo = sorted[0], hi = sorted[sorted.length - 1];
            var msg = "Prices disagree: " + fmtMoney(hi) + " − " + fmtMoney(lo) + " = " + fmtMoney(hi - lo) + " apart.";
            var majorityCents = null, outlierIdx = [];
            if (pricedIdx.length >= 3) {
              var keys = Object.keys(priceCount);
              for (var k = 0; k < keys.length; k++) {
                if (priceCount[keys[k]] === pricedIdx.length - 1) {
                  majorityCents = parseInt(keys[k], 10);
                  break;
                }
              }
              if (majorityCents !== null) {
                pricedIdx.forEach(function (si) {
                  if (rec.per[si].priceCents !== majorityCents) outlierIdx.push(si);
                });
                msg += " MAJORITY price is " + fmtMoney(majorityCents) + " (" + priceCount[majorityCents] + " of " + pricedIdx.length + " priced copies); OUTLIER: " +
                  outlierIdx.map(function (si) { return sources[si].name + " at " + fmtMoney(rec.per[si].priceCents); }).join(", ") + ".";
              } else {
                msg += " NO MAJORITY — the priced copies tie, so no winner is picked.";
              }
            } else if (pricedIdx.length === 2) {
              msg += " With only 2 priced copies there is no majority to break the tie.";
            }
            item.findings.push({ level: "BLOCKER", tag: "PRICE MISMATCH", text: msg });
          } else if (distinctPrices.length === 1 && pricedIdx.length >= 2) {
            item.findings.push({ level: "OK", tag: "MATCH", text: "Price agrees at " + fmtMoney(distinctPrices[0]) + " in every copy that states one." });
          }

          /* NO PRICE STATED */
          item.perSource.forEach(function (ps) {
            if (ps.state === "NO PRICE STATED") {
              item.findings.push({ level: "WARNING", tag: "NO PRICE STATED", text: "Named in " + ps.source + " with no parseable price. That is not the same as the item being absent." });
            }
          });

          /* Presence grading */
          var missing = item.perSource.filter(function (ps) { return ps.state === "MISSING FROM"; });
          if (missing.length >= 2) {
            item.findings.push({ level: "BLOCKER", tag: "MISSING FROM", text: "Absent from " + missing.length + " copies: " + missing.map(function (m) { return m.source; }).join(", ") + ". Missing from 2 or more copies is a BLOCKER." });
          } else if (missing.length === 1) {
            item.findings.push({ level: "WARNING", tag: "MISSING FROM", text: "Absent from " + missing[0].source + ". Missing from any copy is at least a WARNING." });
          }

          /* Description grading */
          var descKeys = Object.keys(presentDescs);
          if (descKeys.length > 1) {
            var f = { level: "WARNING", tag: "DESCRIPTION DIFFERS", text: "Copies give this item different descriptions:", quotes: [] };
            descKeys.forEach(function (d) {
              f.quotes.push({ sources: presentDescs[d].join(", "), desc: d });
            });
            item.findings.push(f);
          }

          var hasBlocker = item.findings.some(function (x) { return x.level === "BLOCKER"; });
          var hasWarning = item.findings.some(function (x) { return x.level === "WARNING"; });
          item.grade = hasBlocker ? "BLOCKER" : (hasWarning ? "WARNING" : "MATCH");
          result.items.push(item);
        });

        /* Possible matches: distinct keys, same first word, similar length */
        for (var a = 0; a < order.length; a++) {
          for (var b = a + 1; b < order.length; b++) {
            var ka = order[a], kb = order[b];
            var fa = ka.split(" ")[0], fb = kb.split(" ")[0];
            var prefix = 0;
            while (prefix < ka.length && prefix < kb.length && ka.charAt(prefix) === kb.charAt(prefix)) prefix++;
            var similar = Math.abs(ka.length - kb.length) <= 3 &&
              ((fa && fa === fb) || prefix >= 5);
            if (similar) {
              result.possibleMatches.push({
                a: byKey[ka].name, b: byKey[kb].name,
                text: "POSSIBLE MATCH: “" + byKey[ka].name + "” and “" + byKey[kb].name + "” share a first word and a similar length — they may be spelling variants of one item. They were graded as separate items and NOT merged."
              });
            }
          }
        }

        return finishCounts(result);
      }

      function finishCounts(result) {
        var blockers = 0, warnings = 0, matched = 0;
        result.items.forEach(function (item) {
          item.findings.forEach(function (f) {
            if (f.level === "BLOCKER") blockers++;
            else if (f.level === "WARNING") warnings++;
          });
          if (item.grade === "MATCH") matched++;
        });
        result.counts.blockers = blockers;
        result.counts.warnings = warnings;
        result.counts.matched = matched;
        result.counts.notes = result.excluded.length + result.possibleMatches.length + result.duplicateNotes.length;

        if (result.sources.length < 2) {
          result.verdict = "NOT ENOUGH TO COMPARE";
          result.verdictClass = "warn";
        } else if (blockers > 0) {
          result.verdict = "DO NOT PUBLISH";
          result.verdictClass = "bad";
          result.verdictNote = blockers + (blockers === 1 ? " blocker" : " blockers") + " must be fixed before any copy goes out — the copies disagree with each other.";
        } else if (warnings > 0) {
          result.verdict = "PUBLISH WITH FIXES";
          result.verdictClass = "warn";
          result.verdictNote = "No blockers, but " + warnings + (warnings === 1 ? " warning" : " warnings") + " to fix so every copy tells the same story.";
        } else {
          result.verdict = "SAFE TO PUBLISH";
          result.verdictClass = "ok";
          result.verdictNote = "Every copy agrees on items, prices, and descriptions.";
        }
        if (result.sources.length === 2 && result.verdict !== "NOT ENOUGH TO COMPARE") {
          result.verdictNote += " Only 2 copies were compared: no majority is possible with 2 copies, and the verdict is capped at PUBLISH WITH FIXES unless there are zero findings.";
        }
        return result;
      }

      /* ---------- Rendering ---------- */
      function esc(s) {
        return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_1": (typeof EXAMPLE_1 !== 'undefined' ? EXAMPLE_1 : undefined), "EXAMPLE_2": (typeof EXAMPLE_2 !== 'undefined' ? EXAMPLE_2 : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-menu-price-consistency-auditortm',
  name: 'J-Dawgs Menu & Price Consistency Auditor',
  description: 'Each platform shows its own menu copy and stops; this grades 2–4 pasted copies of the same menu against each other — price differences with arithmetic, MAJORITY/OUTLIER naming, items missing from a copy, differing descriptions — into one publish verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_1": __core["EXAMPLE_1"], "EXAMPLE_2": __core["EXAMPLE_2"] }
};
