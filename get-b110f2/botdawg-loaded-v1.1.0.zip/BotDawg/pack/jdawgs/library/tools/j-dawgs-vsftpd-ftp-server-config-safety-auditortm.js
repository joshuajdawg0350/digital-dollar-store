'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs vsftpd FTP Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

var KNOWN = {};
var knownList = ["anonymous_enable","anon_upload_enable","anon_mkdir_write_enable","anon_other_write_enable","anon_world_readable_only","anon_max_rate","anon_umask","anon_root","no_anon_password","deny_email_enable","banned_email_file","secure_email_list_enable","email_password_file","anon_mib_enable","write_enable","local_enable","local_umask","local_max_rate","local_root","chown_uploads","chown_username","ftp_username","ftp_nopriv_user","nopriv_user","ssl_enable","force_local_logins_ssl","force_local_data_ssl","force_anon_logins_ssl","force_anon_data_ssl","allow_anon_ssl","ssl_tlsv1","ssl_tlsv1_1","ssl_tlsv1_2","ssl_sslv2","ssl_sslv3","ssl_ciphers","ssl_sni_hostname","require_ssl_reuse","require_cert","validate_cert","rsa_cert_file","rsa_private_key_file","dsa_cert_file","dsa_private_key_file","cert_file","key_file","ca_certs_file","ssl_request_cert","chroot_local_user","allow_writeable_chroot","chroot_list_enable","chroot_list_file","secure_chroot_dir","pasv_enable","pasv_min_port","pasv_max_port","pasv_address","pasv_addr_resolve","pasv_promiscuous","port_enable","port_promiscuous","connect_from_port_20","ftp_data_port","listen_port","listen","listen_ipv6","listen_address","listen_address6","background","setproctitle_enable","session_support","userlist_enable","userlist_deny","userlist_file","hide_ids","hide_file","deny_file","max_clients","max_per_ip","max_login_fails","delay_failed_login","delay_successful_login","seccomp_sandbox","xferlog_enable","xferlog_file","xferlog_std_format","log_ftp_protocol","syslog_enable","dual_log_enable","vsftpd_log_file","debug_ssl","idle_session_timeout","data_connection_timeout","accept_timeout","connect_timeout","dirmessage_enable","message_file","banner_file","ftpd_banner","pam_service_name","guest_enable","guest_username","virtual_use_local_privs","cmds_allowed","cmds_denied","tcp_wrappers","tcp_wrappers_options","use_localtime","use_sendfile","ascii_download_enable","ascii_upload_enable","download_enable","dirlist_enable","file_open_mode","lock_upload_files","ls_recurse_enable","munge_symlinks_enable","text_userdb_names","tilde_user_enable","user_config_dir","user_sub_token","pasv_log_syslog_enable","utf8_filesystem_enable"];
for (var ki=0; ki<knownList.length; ki++){ KNOWN[knownList[ki]] = true; }

var KEY_DIRECTIVES = {"rsa_cert_file":true,"rsa_private_key_file":true,"dsa_cert_file":true,"dsa_private_key_file":true,"cert_file":true,"key_file":true,"ca_certs_file":true};

var RISKY = [
"# Risky example - for testing this auditor only",
"listen=YES",
"anonymous_enable=YES",
"anon_upload_enable=YES",
"anon_mkdir_write_enable=YES",
"local_enable=YES",
"write_enable=YES",
"ssl_enable=NO",
"chroot_local_user=NO",
"pasv_min_port=50000",
"pasv_max_port=40000"
].join("\n");

var HARDENED = [
"# Hardened example",
"listen=YES",
"anonymous_enable=NO",
"local_enable=YES",
"write_enable=NO",
"ssl_enable=YES",
"force_local_logins_ssl=YES",
"force_local_data_ssl=YES",
"ssl_tlsv1=NO",
"ssl_sslv2=NO",
"ssl_sslv3=NO",
"rsa_cert_file=/etc/ssl/certs/vsftpd.pem",
"rsa_private_key_file=/etc/ssl/private/vsftpd.key",
"chroot_local_user=YES",
"allow_writeable_chroot=NO",
"pasv_enable=YES",
"pasv_min_port=40000",
"pasv_max_port=40100",
"userlist_enable=YES",
"userlist_deny=YES",
"hide_ids=YES",
"max_clients=50",
"max_per_ip=5",
"seccomp_sandbox=YES"
].join("\n");

function el(id){ return document.getElementById(id); }

function parseConfig(text){
  var rawLines = text.split("\n");
  var occurrences = {}; // key -> array of {line, value}
  var order = [];
  var commented = []; // {name, line}
  var activeCount = 0;
  for (var i=0; i<rawLines.length; i++){
    var lineNo = i+1;
    var raw = rawLines[i];
    var trimmed = raw.replace(/^\s+|\s+$/g, "");
    if (trimmed === ""){ continue; }
    if (trimmed.charAt(0) === "#"){
      var cm = trimmed.match(/^#\s*([A-Za-z0-9_]+)\s*=/);
      if (cm){ commented.push({name: cm[1].toLowerCase(), line: lineNo}); }
      continue;
    }
    var eq = trimmed.indexOf("=");
    if (eq < 1){ continue; }
    var key = trimmed.substring(0, eq).replace(/\s+/g, "").toLowerCase();
    var value = trimmed.substring(eq+1).replace(/^\s+|\s+$/g, "");
    if (!occurrences[key]){ occurrences[key] = []; order.push(key); }
    occurrences[key].push({line: lineNo, value: value});
    activeCount++;
  }
  return {occurrences: occurrences, order: order, commented: commented, activeCount: activeCount, totalLines: rawLines.length};
}

function eff(parsed, key){
  var occ = parsed.occurrences[key];
  if (!occ || occ.length === 0){ return null; }
  var last = occ[occ.length-1];
  return {value: last.value, upper: last.value.toUpperCase(), line: last.line};
}
function isYes(e){ return !!e && e.upper === "YES"; }
function isNo(e){ return !!e && e.upper === "NO"; }
function commentedNote(parsed, key){
  var notes = [];
  for (var i=0; i<parsed.commented.length; i++){
    if (parsed.commented[i].name === key){ notes.push(parsed.commented[i].line); }
  }
  return notes;
}

function audit(text){
  var parsed = parseConfig(text);
  var findings = [];
  function add(sev, line, title, detail, tag){
    findings.push({sev: sev, line: line, title: title, detail: detail, tag: tag || ""});
  }
  if (parsed.activeCount === 0){ return {empty: true, parsed: parsed}; }

  var anon = eff(parsed, "anonymous_enable");
  var anonOn = isYes(anon);
  var local = eff(parsed, "local_enable");
  var ssl = eff(parsed, "ssl_enable");
  var sslOn = isYes(ssl);

  // --- Anonymous access ---
  if (anonOn){
    add("BLOCKER", anon.line, "anonymous_enable=YES - anonymous FTP logins are allowed",
      "Anyone who can reach the server can log in as the anonymous user with no real credential. Turn it off (anonymous_enable=NO) unless this server is deliberately a public file drop, and even then pair it with the upload and chroot checks below.");
  } else if (isNo(anon)){
    add("INFO", anon.line, "anonymous_enable=NO - anonymous logins are off", "Anonymous access is explicitly disabled on line " + anon.line + ".");
  } else if (anon){
    add("WARNING", anon.line, "anonymous_enable has an unrecognised value",
      "The value on line " + anon.line + " is not YES or NO, so this audit cannot confirm the anonymous posture. Set anonymous_enable=NO explicitly. The value itself is not reproduced here.");
  } else {
    var ac = commentedNote(parsed, "anonymous_enable");
    add("WARNING", null, "anonymous_enable is not set",
      "It does not appear as an active directive" + (ac.length ? " (it appears commented out on line " + ac.join(", line ") + ", and commented-out directives are treated as unset)" : "") + ", so the compiled-in default of the vsftpd build decides - and on many builds that default allows anonymous logins. Set anonymous_enable=NO explicitly.");
  }

  // --- Anonymous writes ---
  var anonUp = eff(parsed, "anon_upload_enable");
  if (isYes(anonUp) && anonOn){
    add("BLOCKER", anonUp.line, "anon_upload_enable=YES while anonymous access is on",
      "Anonymous visitors can upload files to the server. That is the classic drop-box abuse pattern: strangers storing and redistributing files at your expense. Set anon_upload_enable=NO.");
  } else if (isYes(anonUp)){
    add("WARNING", anonUp.line, "anon_upload_enable=YES (anonymous access is currently off)",
      "Not exploitable while anonymous_enable is off, but it is a loaded setting: the moment anonymous access is switched on, strangers can upload. Set it to NO unless anonymous uploads are the point of the server.");
  }
  var anonMk = eff(parsed, "anon_mkdir_write_enable");
  if (isYes(anonMk) && anonOn){
    add("BLOCKER", anonMk.line, "anon_mkdir_write_enable=YES while anonymous access is on",
      "Anonymous visitors can create directories and write into them. Combined with anonymous upload this hands strangers an organised file store on your server. Set anon_mkdir_write_enable=NO.");
  } else if (isYes(anonMk)){
    add("WARNING", anonMk.line, "anon_mkdir_write_enable=YES (anonymous access is currently off)",
      "Latent risk only while anonymous access stays off. Set it to NO so a later change to anonymous_enable cannot silently open anonymous directory writes.");
  }
  var anonOther = eff(parsed, "anon_other_write_enable");
  if (isYes(anonOther) && anonOn){
    add("BLOCKER", anonOther.line, "anon_other_write_enable=YES while anonymous access is on",
      "Anonymous visitors can rename and delete files and perform other write operations beyond plain upload. Set anon_other_write_enable=NO.");
  } else if (isYes(anonOther)){
    add("WARNING", anonOther.line, "anon_other_write_enable=YES (anonymous access is currently off)",
      "Latent risk only while anonymous access stays off. Set it to NO.");
  }

  // --- Local logins and plaintext ---
  if (isYes(local) && !sslOn){
    var sslLineTxt = ssl ? ("ssl_enable is set to NO on line " + ssl.line) : "ssl_enable does not appear in the file at all";
    add("BLOCKER", local.line, "local_enable=YES with no SSL - local passwords cross the wire in plain text",
      "Local user logins are enabled on line " + local.line + ", and " + sslLineTxt + ". FTP sends usernames and passwords unencrypted, so anyone who can watch the traffic can read real system credentials. This grade assumes the server is reachable beyond a trusted local network: this tool cannot know the network the server sits on, and on a fully isolated LAN the same file is less exposed - but the passwords are still in clear text on the wire. Set ssl_enable=YES and provide a certificate.");
  } else if (isYes(local) && sslOn){
    add("INFO", local.line, "local_enable=YES with ssl_enable=YES", "Local logins are enabled and SSL is available to protect them. The force flags below decide whether that protection is mandatory.");
    var fl = eff(parsed, "force_local_logins_ssl");
    if (!isYes(fl)){
      add("WARNING", fl ? fl.line : null, "force_local_logins_ssl is not YES",
        "SSL is available but local logins are not forced to use it, so a client can still log in over a plaintext connection and expose its password. Set force_local_logins_ssl=YES.");
    } else {
      add("INFO", fl.line, "force_local_logins_ssl=YES", "Local logins are forced onto SSL.");
    }
    var fd = eff(parsed, "force_local_data_ssl");
    if (!isYes(fd)){
      add("WARNING", fd ? fd.line : null, "force_local_data_ssl is not YES",
        "SSL is available but data connections are not forced to use it, so file contents can still travel unencrypted even when the login is protected. Set force_local_data_ssl=YES.");
    } else {
      add("INFO", fd.line, "force_local_data_ssl=YES", "Data connections are forced onto SSL.");
    }
  } else if (local && isNo(local)){
    add("INFO", local.line, "local_enable=NO - no local user logins", "Local (system account) logins are disabled; only anonymous or virtual-user access can apply.");
  } else if (!local){
    add("INFO", null, "local_enable is not set", "Not present as an active directive, so local logins follow the build default (commonly enabled). Set it explicitly so the posture is a decision, not an accident.");
  }

  // --- TLS strength (only meaningful when ssl is on, but flag bad values regardless) ---
  var tlsv1 = eff(parsed, "ssl_tlsv1");
  if (isYes(tlsv1)){
    add("WARNING", tlsv1.line, "ssl_tlsv1=YES - obsolete TLS 1.0 is allowed",
      "TLS 1.0 is long obsolete and is refused by modern clients and scanners. Set ssl_tlsv1=NO; current vsftpd builds negotiate TLS 1.2 and later by default.");
  }
  var sslv2 = eff(parsed, "ssl_sslv2");
  if (isYes(sslv2)){
    add("BLOCKER", sslv2.line, "ssl_sslv2=YES - SSLv2 is enabled",
      "SSLv2 is broken cryptography with known practical attacks. Set ssl_sslv2=NO.");
  }
  var sslv3 = eff(parsed, "ssl_sslv3");
  if (isYes(sslv3)){
    add("BLOCKER", sslv3.line, "ssl_sslv3=YES - SSLv3 is enabled",
      "SSLv3 is broken (POODLE and successors). Set ssl_sslv3=NO.");
  }
  var ciphers = eff(parsed, "ssl_ciphers");
  if (ciphers && /(RC4|3DES|DES|MD5|LOW|EXP|NULL|ADH|AECDH)/i.test(ciphers.value)){
    add("WARNING", ciphers.line, "ssl_ciphers names weak cipher families",
      "The cipher list on line " + ciphers.line + " includes families modern scanners flag as weak. The list itself is not reproduced here; replace it with a current high-strength cipher string.");
  }
  if (sslOn){
    var hasCert = eff(parsed, "rsa_cert_file") || eff(parsed, "dsa_cert_file") || eff(parsed, "cert_file");
    if (!hasCert){
      add("WARNING", ssl.line, "ssl_enable=YES but no certificate file directive is set",
        "SSL cannot start without a certificate. Set rsa_cert_file to the certificate (and rsa_private_key_file to the key, if they are stored separately).");
    }
  }

  // --- write_enable posture ---
  var we = eff(parsed, "write_enable");
  if (isYes(we)){
    add("WARNING", we.line, "write_enable=YES - logged-in users can write",
      "Any account that can log in (and, while anonymous access and its write flags are on, anonymous visitors too) can upload, rename, and delete within its permissions. That is correct for a working file server and dangerous for a read-only one - confirm writes are actually needed, and keep them jailed with chroot_local_user.");
  } else if (isNo(we)){
    add("INFO", we.line, "write_enable=NO - the server is read-only for uploads", "Writes are off; no login can upload or modify files through FTP.");
  } else {
    add("INFO", null, "write_enable is not set", "Not present as an active directive; vsftpd's default posture is read-only for writes until write_enable=YES appears.");
  }

  // --- chroot ---
  var chroot = eff(parsed, "chroot_local_user");
  if (!chroot){
    var cc = commentedNote(parsed, "chroot_local_user");
    add("WARNING", null, "chroot_local_user is not set",
      "Local users are not confined to their home directories" + (cc.length ? " (it appears commented out on line " + cc.join(", line ") + ", and commented-out directives are treated as unset)" : "") + ", so a logged-in user can browse the wider filesystem wherever file permissions allow. Set chroot_local_user=YES.");
  } else if (isNo(chroot)){
    add("WARNING", chroot.line, "chroot_local_user=NO - local users are not jailed",
      "Local users can wander outside their home directories as far as filesystem permissions let them. Set chroot_local_user=YES unless there is a specific reason not to.");
  } else if (isYes(chroot)){
    add("INFO", chroot.line, "chroot_local_user=YES - local users are jailed to their home directories", "A logged-in local user is confined to its own home tree.");
  }
  var awc = eff(parsed, "allow_writeable_chroot");
  if (isYes(awc)){
    add("WARNING", awc.line, "allow_writeable_chroot=YES - the chroot jail is weakened",
      "This setting exists to let vsftpd run when the jailed home directory is writable by the user - which is exactly the condition that lets a jailed user tamper with the jail root. Prefer making the home directory itself non-writable (uploads go in a writable subdirectory) and set allow_writeable_chroot=NO.");
  }

  // --- Passive mode ---
  var pasv = eff(parsed, "pasv_enable");
  var pmin = eff(parsed, "pasv_min_port");
  var pmax = eff(parsed, "pasv_max_port");
  if (pmin && pmax){
    var mn = parseInt(pmin.value, 10);
    var mx = parseInt(pmax.value, 10);
    if (!isNaN(mn) && !isNaN(mx)){
      if (mn > mx){
        add("BLOCKER", pmin.line, "Passive port range is backwards: pasv_min_port=" + mn + " is greater than pasv_max_port=" + mx,
          "pasv_min_port is set to " + mn + " on line " + pmin.line + " and pasv_max_port to " + mx + " on line " + pmax.line + ". With the minimum above the maximum there is no usable passive range, so passive data connections will fail. Swap them or set a sane range, and open exactly that range in the firewall.");
      } else {
        if (mn < 1024){
          add("WARNING", pmin.line, "pasv_min_port=" + mn + " is in the privileged range",
            "Ports below 1024 are privileged and often collide with other services. Move the passive range to high ports, for example 40000-40100.");
        }
        if ((mx - mn) > 1000){
          add("WARNING", pmin.line, "Passive port range is very wide (" + mn + "-" + mx + ")",
            "That is " + (mx - mn + 1) + " ports to open in the firewall for one service. Narrow the range to what concurrent transfers actually need.");
        }
        if (mn >= 1024 && (mx - mn) <= 1000){
          add("INFO", pmin.line, "Passive port range is sane: " + mn + "-" + mx, "pasv_min_port on line " + pmin.line + " and pasv_max_port on line " + pmax.line + " form a usable range. Make sure the firewall opens exactly this range.");
        }
      }
    } else {
      add("WARNING", pmin.line, "Passive port values are not plain numbers",
        "pasv_min_port (line " + pmin.line + ") and pasv_max_port (line " + pmax.line + ") must both be plain port numbers. The values are not reproduced here.");
    }
  } else if (pmin || pmax){
    var only = pmin || pmax;
    var onlyName = pmin ? "pasv_min_port" : "pasv_max_port";
    add("WARNING", only.line, "Only one end of the passive port range is set (" + onlyName + ")",
      "Set both pasv_min_port and pasv_max_port so the range is deliberate and matches the firewall, instead of leaving one end to the build default.");
  }
  if (pasv && isNo(pasv)){
    add("INFO", pasv.line, "pasv_enable=NO - passive mode is disabled",
      "Clients must use active-mode data connections, which many client-side firewalls and NAT setups block. Most public servers need passive mode on with a fixed, firewalled range.");
  } else if (!pasv && !pmin && !pmax){
    add("INFO", null, "No passive-mode directives are set",
      "pasv_enable, pasv_min_port, and pasv_max_port are all absent, so passive behaviour and its port range follow build and operating-system defaults rather than a range you chose and firewalled.");
  }

  // --- userlist ---
  var ul = eff(parsed, "userlist_enable");
  var uld = eff(parsed, "userlist_deny");
  if (isYes(ul)){
    if (uld && isNo(uld)){
      add("INFO", ul.line, "userlist_enable=YES with userlist_deny=NO - the user list is an allow list",
        "Only users named in the userlist file may log in; everyone else is refused. Keep that file short and current.");
    } else {
      add("INFO", ul.line, "userlist_enable=YES with userlist_deny in effect - the user list is a deny list",
        "Users named in the userlist file are refused before a password is even asked; everyone else may try. That blocks known-bad accounts early but is not an allow list.");
    }
  } else if (ul && isNo(ul)){
    add("INFO", ul.line, "userlist_enable=NO - no user list filtering", "Any account may attempt a login; there is no list-based early refusal.");
  } else {
    add("INFO", null, "userlist_enable is not set", "No list-based login filtering is configured. Enabling it gives either an early deny list or (with userlist_deny=NO) a strict allow list.");
  }

  // --- hide_ids ---
  var hide = eff(parsed, "hide_ids");
  if (isYes(hide)){
    add("INFO", hide.line, "hide_ids=YES - listings show a fake owner", "Directory listings present files as owned by the ftp user instead of real usernames and groups, so listings leak less about the system's accounts.");
  } else {
    add("INFO", hide ? hide.line : null, "hide_ids is not YES - listings show real owners",
      "Directory listings expose real usernames and group names of file owners. Not a hole by itself, but it hands an onlooker a list of valid account names. Consider hide_ids=YES.");
  }

  // --- connection limits ---
  var mc = eff(parsed, "max_clients");
  if (!mc){
    add("INFO", null, "max_clients is not set", "There is no cap on total simultaneous connections in the file, so connection floods are bounded only by the machine. Set max_clients to a number the server can honestly serve.");
  } else {
    add("INFO", mc.line, "max_clients is set (line " + mc.line + ")", "A total connection cap is configured.");
  }
  var mpi = eff(parsed, "max_per_ip");
  if (!mpi){
    add("INFO", null, "max_per_ip is not set", "There is no per-address connection cap, so one client can hold every slot. Set max_per_ip alongside max_clients.");
  } else {
    add("INFO", mpi.line, "max_per_ip is set (line " + mpi.line + ")", "A per-address connection cap is configured.");
  }

  // --- seccomp sandbox ---
  var sec = eff(parsed, "seccomp_sandbox");
  if (sec && isNo(sec)){
    add("WARNING", sec.line, "seccomp_sandbox=NO - the syscall sandbox is off",
      "vsftpd's seccomp sandbox limits what a compromised child process can do. It is sometimes disabled to work around old-kernel quirks; if that is not the case here, set seccomp_sandbox=YES.");
  } else if (isYes(sec)){
    add("INFO", sec.line, "seccomp_sandbox=YES - the syscall sandbox is on", "The modern vsftpd sandbox is explicitly enabled.");
  } else {
    add("INFO", null, "seccomp_sandbox is not set", "Absent from the file; current vsftpd builds enable the sandbox by default, older ones may not. Setting seccomp_sandbox=YES makes the posture explicit.");
  }

  // --- Certificate / key directives: name + line only ---
  var keyNames = Object.keys(KEY_DIRECTIVES);
  for (var k=0; k<keyNames.length; k++){
    var kd = eff(parsed, keyNames[k]);
    if (kd){
      add("INFO", kd.line, keyNames[k] + " is set (line " + kd.line + ")",
        "This directive points vsftpd at a certificate or key file. Reported by directive name and line only: the path and value are never reproduced by this tool, and a config never contains the certificate or key contents themselves. What matters operationally: the file it names must exist, must be readable by vsftpd, and the private key file must not be readable by anyone else.");
    }
  }

  // --- Duplicates: last value wins ---
  for (var d=0; d<parsed.order.length; d++){
    var dkey = parsed.order[d];
    var occ = parsed.occurrences[dkey];
    if (occ && occ.length > 1){
      var lineList = [];
      for (var o=0; o<occ.length; o++){ lineList.push(occ[o].line); }
      var winLine = occ[occ.length-1].line;
      var extra = KEY_DIRECTIVES[dkey] ? " The winning value is not reproduced here because this directive names a certificate or key file." : "";
      add("WARNING", winLine, "Duplicate directive: " + dkey + " appears on lines " + lineList.join(" and "),
        "vsftpd reads the file top to bottom and the last value wins, so line " + winLine + " is the value this audit graded; the earlier line " + lineList[0] + " is dead text that will mislead the next reader. Delete the stale line." + extra);
    }
  }

  // --- Commented-out directives summary ---
  if (parsed.commented.length){
    var names = {};
    var parts = [];
    for (var c=0; c<parsed.commented.length; c++){
      var cn = parsed.commented[c];
      if (!names[cn.name]){ names[cn.name] = true; parts.push(cn.name + " (line " + cn.line + ")"); }
    }
    if (parts.length){
      add("INFO", null, "Commented-out directives were treated as unset: " + parts.join(", "),
        "Those lines are switched off in the file as pasted, so this audit graded the server as if they were absent - which is also how vsftpd reads them. If one of them was meant to protect the server, uncomment it and re-run the audit.");
    }
  }

  // --- Unknown directives: NOT AUDITED ---
  for (var u=0; u<parsed.order.length; u++){
    var ukey = parsed.order[u];
    if (!KNOWN[ukey]){
      var uocc = parsed.occurrences[ukey];
      var uline = uocc[uocc.length-1].line;
      add("INFO", uline, "NOT AUDITED: " + ukey + " (line " + uline + ")",
        "This directive is not in this auditor's rule set, so its effect was not checked and is not guessed here. It may be a typo of a real directive (in which case vsftpd will refuse to start), a directive from a newer vsftpd than this rule set covers, or a fork-specific option. Its value is not reproduced.");
    }
  }

  // Sort: BLOCKER, WARNING, INFO; then by line (unset last)
  var rank = {"BLOCKER":0, "WARNING":1, "INFO":2};
  findings.sort(function(a, b){
    if (rank[a.sev] !== rank[b.sev]){ return rank[a.sev] - rank[b.sev]; }
    var la = (a.line === null ? 99999 : a.line);
    var lb = (b.line === null ? 99999 : b.line);
    return la - lb;
  });

  var blockers = 0, warnings = 0, infos = 0;
  for (var f=0; f<findings.length; f++){
    if (findings[f].sev === "BLOCKER"){ blockers++; }
    else if (findings[f].sev === "WARNING"){ warnings++; }
    else { infos++; }
  }
  var verdict, vclass, why;
  if (blockers > 0){
    verdict = "DO NOT DEPLOY"; vclass = "dont";
    why = "This config has " + blockers + " blocker finding" + (blockers === 1 ? "" : "s") + ". Fix every blocker before this file goes on a reachable server.";
  } else if (warnings > 0){
    verdict = "DEPLOY WITH FIXES"; vclass = "fixes";
    why = "No blockers, but " + warnings + " warning" + (warnings === 1 ? "" : "s") + " should be fixed before this config is trusted in production.";
  } else {
    verdict = "SAFE TO DEPLOY"; vclass = "safe";
    why = "No blockers and no warnings. The INFO notes below record the posture the audit confirmed and the limits of a text-only check.";
  }
  return {empty: false, parsed: parsed, findings: findings, blockers: blockers, warnings: warnings, infos: infos, verdict: verdict, vclass: vclass, why: why};
}

function buildReport(r){
  var out = [];
  out.push("J-Dawgs vsftpd FTP Server Config Safety Auditor - Audit Report");
  out.push("Verdict: " + r.verdict);
  out.push("Findings: " + r.blockers + " BLOCKER, " + r.warnings + " WARNING, " + r.infos + " INFO");
  out.push("");
  out.push("Grading rules used: duplicate directives graded last-value-wins; commented-out directives treated as unset; certificate and key directives reported by name and line only; no value that could be a secret is ever included in this report; directives outside the rule set are listed as NOT AUDITED and never guessed.");
  out.push("");
  var sevs = ["BLOCKER", "WARNING", "INFO"];
  for (var s=0; s<sevs.length; s++){
    out.push("--- " + sevs[s] + " ---");
    var any = false;
    for (var i=0; i<r.findings.length; i++){
      var f = r.findings[i];
      if (f.sev !== sevs[s]){ continue; }
      any = true;
      var where = (f.line === null) ? "not set / no line" : "line " + f.line;
      out.push("[" + f.sev + "] (" + where + ") " + f.title);
      out.push("    " + f.detail);
    }
    if (!any){ out.push("(none)"); }
    out.push("");
  }
  out.push("Limits: this is a heuristic text audit, not the vsftpd binary. The tool never connected to any server and cannot know the network the server sits on; findings that depend on exposure are graded for a server reachable beyond a trusted local network.");
  return out.join("\n");
}

function render(r){
  var box = el("results");
  if (r.empty){
    box.classList.add("hidden");
    el("auditStatus").textContent = "No active directives found. Paste the text of a vsftpd.conf file (commented-out lines alone do not configure anything) and run the audit again.";
    return;
  }
  el("auditStatus").textContent = "";
  box.classList.remove("hidden");
  var vb = el("verdictBox");
  vb.className = "verdict " + r.vclass;
  el("verdictLabel").textContent = r.verdict;
  el("verdictWhy").textContent = r.why;
  el("countChips").innerHTML =
    '<span class="chip">BLOCKER: ' + r.blockers + '</span>' +
    '<span class="chip">WARNING: ' + r.warnings + '</span>' +
    '<span class="chip">INFO: ' + r.infos + '</span>' +
    '<span class="chip">Active directives audited from ' + r.parsed.totalLines + ' pasted lines</span>';
  var html = "";
  var sevs = ["BLOCKER", "WARNING", "INFO"];
  var heads = {"BLOCKER": "Blockers - fix before this file goes live", "WARNING": "Warnings - fix before trusting it in production", "INFO": "Info - posture notes and limits"};
  // Build finding cards with empty title/detail slots; the text is filled in
  // via textContent below so pasted config text is never treated as markup.
  for (var s2=0; s2<sevs.length; s2++){
    var grp = [];
    for (var j=0; j<r.findings.length; j++){ if (r.findings[j].sev === sevs[s2]){ grp.push(j); } }
    if (!grp.length){ continue; }
    html += "<h3>" + heads[sevs[s2]] + " (" + grp.length + ")</h3>";
    for (var k=0; k<grp.length; k++){
      var fi = grp[k];
      var ff = r.findings[fi];
      var bd = (ff.line === null) ? "Not set" : "Line " + ff.line;
      html += '<div class="finding"><div class="fhead"><span class="sev ' + ff.sev + '">' + ff.sev + '</span>' +
        '<span class="linebadge">' + bd + '</span>' +
        '<span class="ftitle" data-fi="' + fi + '"></span></div>' +
        '<p class="fdetail" data-fi="' + fi + '"></p></div>';
    }
  }
  el("findingsList").innerHTML = html;
  var titles = el("findingsList").querySelectorAll(".ftitle");
  for (var t=0; t<titles.length; t++){
    var idx = parseInt(titles[t].getAttribute("data-fi"), 10);
    titles[t].textContent = r.findings[idx].title;
  }
  var details = el("findingsList").querySelectorAll(".fdetail");
  for (var d2=0; d2<details.length; d2++){
    var idx2 = parseInt(details[d2].getAttribute("data-fi"), 10);
    details[d2].textContent = r.findings[idx2].detail;
  }
  el("reportOut").value = buildReport(r);
  el("copyStatus").textContent = "";
}

function updateLineCount(){
  var v = el("configInput").value;
  if (!v){ el("lineCount").textContent = ""; return; }
  var n = v.split("\n").length;
  el("lineCount").textContent = n + (n === 1 ? " line" : " lines") + " pasted. Line numbers in the findings count from the top of exactly this text.";
}
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-vsftpd-ftp-server-config-safety-auditortm',
  name: 'J-Dawgs vsftpd FTP Server Config Safety Auditor',
  description: 'Paste a vsftpd.conf, get one deploy verdict: anonymous access and anonymous writes, plaintext logins, TLS posture, chroot, and passive-port sanity graded offline, with secrets reported by key name only — never the value.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
