'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs CSV & Tabular Integrity Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";
      var $ = function (id) { return document.getElementById(id); };
      function esc(s) {
        return String(s).replace(/[&<>"']/g, function (c) {
          return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
        });
      }

      /* ---------------- Samples ---------------- */
      var MESSY_SAMPLE = [
        "id,name,score,signup_date,zip,score",
        "1,Alice,88,2024-01-15,01234,good",
        "2,Bob,92,03/22/2024,90210,ok",
        "3,Carol,pending,2024-02-10,00501,good",
        "4,Dan,74,04/18/2024,60614,fair",
        "5,Erin,N/A,2024-03-05,02139,good",
        "6,Frank,81,2024-04-11,10001,ok",
        "7,Grace,79,2024-05-09",
        "2,Bob,92,03/22/2024,90210,ok",
        "8,Heidi,85,05/30/2024,73301,fair",
        '9,"Ivan,95,2024-06-01,94110,ok'
      ].join("\n");

      var CLEAN_SAMPLE = [
        "id,name,score,signup_date,zip",
        "1,Alice,88,2024-01-15,90210",
        "2,Bob,92,2024-02-20,60614",
        "3,Carol,74,2024-03-25,10001",
        "4,Dan,81,2024-04-30,73301",
        "5,Erin,67,2024-05-14,55401"
      ].join("\n");

      var PASS_ON_TEXT = [
        "AI Tool Store — Tools AIs actually need, built by J-Dawgs: https://muse.ai/s/ai-tool-store-xng6xkxwjkxl2xab/UoF72OkKI7j33Q2ITxmrZyIr4nv40QtYfj2AgESh_k8",
        "J-Dawgs Agent Exchange — Shareware for AIs: agent tools free to try in the browser, pay per use only if they earn it: https://muse.ai/s/j-dawgs-agent-exchange-ih6xlnihzxdhxc/ZbleqxFHRE0NcswaBkyN13y9lLp5rPAgHTb6t8ii-PY",
        "Trust the Inputs Stack: CSV & Tabular Integrity Auditor + Schema Inference Forge + URL & Link Trust Auditor — profile the table, infer the schema, vet the links, before you trust any of it."
      ].join("\n");

      /* ---------------- Parsing ---------------- */
      // Quote-aware single-line split (used only for delimiter detection).
      function splitLineQuoteAware(line, delim) {
        var out = [], field = "", inQ = false, i, c;
        for (i = 0; i < line.length; i++) {
          c = line[i];
          if (inQ) {
            if (c === '"') {
              if (line[i + 1] === '"') { field += '"'; i++; }
              else inQ = false;
            } else field += c;
          } else if (c === '"' && field === "") {
            inQ = true;
          } else if (c === delim) {
            out.push(field); field = "";
          } else field += c;
        }
        out.push(field);
        return out;
      }

      var DELIM_NAMES = { ",": "comma (,)", "\t": "tab", ";": "semicolon (;)", "|": "pipe (|)" };

      function detectDelimiter(text) {
        var cands = [",", "\t", ";", "|"];
        var lines = text.split(/\r\n|\r|\n/).filter(function (l) { return l.trim() !== ""; }).slice(0, 12);
        var best = null, d, counts, freq, k, modal, modalN, consistency, score;
        for (var ci = 0; ci < cands.length; ci++) {
          d = cands[ci];
          counts = lines.map(function (l) { return splitLineQuoteAware(l, d).length; });
          freq = {}; modal = 0; modalN = 0;
          counts.forEach(function (c) { freq[c] = (freq[c] || 0) + 1; });
          for (k in freq) { if (freq[k] > modalN) { modalN = freq[k]; modal = +k; } }
          if (modal < 2) continue;
          consistency = modalN / counts.length;
          score = consistency * 100 + modal * 0.1;
          if (!best || score > best.score) best = { delim: d, score: score, consistency: consistency };
        }
        if (!best) {
          return { delim: ",", name: "none detected — treated as a single column", confidence: 0, label: "low", single: true };
        }
        var conf = Math.round(best.consistency * 100);
        return {
          delim: best.delim,
          name: DELIM_NAMES[best.delim],
          confidence: conf,
          label: conf >= 90 ? "high" : conf >= 70 ? "medium" : "low",
          single: false
        };
      }

      // Full state-machine parser: handles quoted fields, escaped quotes (""),
      // embedded newlines inside quotes, CR/LF/CRLF. Returns rows:
      // { cells:[...], startLine:Number, unclosedLine:Number|null }
      function parseDelimited(text, delim) {
        var rows = [], row = [], field = "";
        var inQ = false, line = 1, rowStart = 1, quoteLine = null;
        var touched = false; // current row has seen any content
        var i = 0, c, n = text.length;

        function endRow(unclosed) {
          row.push(field);
          rows.push({ cells: row, startLine: rowStart, unclosedLine: unclosed ? quoteLine : null });
          row = []; field = ""; touched = false; quoteLine = null;
        }

        while (i < n) {
          c = text[i];
          if (inQ) {
            if (c === '"') {
              if (text[i + 1] === '"') { field += '"'; i += 2; continue; }
              inQ = false; i++; continue;
            }
            if (c === "\n") line++;
            field += c; i++; continue;
          }
          if (c === '"' && field === "") {
            inQ = true; quoteLine = line; touched = true; i++; continue;
          }
          if (c === delim) { row.push(field); field = ""; touched = true; i++; continue; }
          if (c === "\r" || c === "\n") {
            endRow(false);
            if (c === "\r" && text[i + 1] === "\n") i++;
            i++; line++; rowStart = line; continue;
          }
          field += c; touched = true; i++;
        }
        if (inQ) {
          endRow(true);
        } else if (field !== "" || row.length > 0 || touched) {
          endRow(false);
        }
        return rows;
      }

      function isMarkdownTable(lines) {
        var content = lines.filter(function (l) { return l.trim() !== ""; });
        if (content.length < 2) return false;
        if (content[0].trim().charAt(0) !== "|") return false;
        var sep = content[1].trim();
        return /^\|?[\s:|-]+\|?$/.test(sep) && sep.indexOf("-") !== -1;
      }

      function parseMarkdown(lines) {
        var content = lines.filter(function (l) { return l.trim() !== ""; });
        var rows = [];
        content.forEach(function (l, idx) {
          if (idx === 1) return; // separator row
          var t = l.trim();
          if (t.charAt(0) === "|") t = t.slice(1);
          if (t.charAt(t.length - 1) === "|") t = t.slice(0, -1);
          rows.push({
            cells: t.split("|").map(function (s) { return s.trim(); }),
            startLine: idx + 1,
            unclosedLine: null
          });
        });
        return rows;
      }

      /* ---------------- Type inference ---------------- */
      var MONTHS = "jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec";
      function dateFormatOf(v) {
        var m;
        if (/^\d{4}-\d{2}-\d{2}$/.test(v)) return "ISO (YYYY-MM-DD)";
        if (/^\d{4}\/\d{2}\/\d{2}$/.test(v)) return "ISO slash (YYYY/MM/DD)";
        m = v.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
        if (m) {
          var a = +m[1], b = +m[2];
          if (a > 12 && b <= 12) return "EU (DD/MM/YYYY)";
          if (b > 12 && a <= 12) return "US (MM/DD/YYYY)";
          return "slash date (MM/DD or DD/MM — ambiguous)";
        }
        m = v.match(/^(\d{1,2})\.(\d{1,2})\.(\d{4})$/);
        if (m) {
          return (+m[1]) > 12 ? "EU dotted (DD.MM.YYYY)" : "dotted date (DD.MM or MM.DD — ambiguous)";
        }
        if (new RegExp("^\\d{1,2} (" + MONTHS + ")[a-z]* \\d{4}$", "i").test(v)) return "textual (e.g. 15 Mar 2024)";
        if (new RegExp("^(" + MONTHS + ")[a-z]* \\d{1,2}, \\d{4}$", "i").test(v)) return "textual (e.g. Mar 15, 2024)";
        return null;
      }
      function classify(v) {
        if (/^(true|false|yes|no)$/i.test(v)) return "boolean";
        if (/^[+-]?\d+$/.test(v)) return "integer";
        if (/^[+-]?(\d+\.\d*|\.\d+|\d+)([eE][+-]?\d+)?$/.test(v) && /[.eE]/.test(v)) return "decimal";
        if (dateFormatOf(v)) return "date";
        return "string";
      }

      /* ---------------- Audit ---------------- */
      function audit(text) {
        var findings = []; // {sev, stage, msg, detail, fix}
        function add(sev, stage, msg, detail, fix) {
          findings.push({ sev: sev, stage: stage, msg: msg, detail: detail || "", fix: fix || "" });
        }

        var rawLines = text.split(/\r\n|\r|\n/);
        var mode, delimInfo, rows;
        if (isMarkdownTable(rawLines)) {
          mode = "markdown";
          rows = parseMarkdown(rawLines);
          delimInfo = { name: "Markdown table (pipe)", confidence: 100, label: "high", single: false };
        } else {
          mode = "delimited";
          delimInfo = detectDelimiter(text);
          rows = parseDelimited(text, delimInfo.delim);
        }

        if (delimInfo.label === "low" && !delimInfo.single) {
          add("warn", "Parse",
            "Delimiter detection confidence is low (" + delimInfo.confidence + "%).",
            "Detected: " + delimInfo.name + ". If the columns look wrong, the source may mix delimiters.",
            "Re-export the table with one consistent delimiter before trusting this audit.");
        }
        if (delimInfo.single) {
          add("warn", "Parse",
            "No delimiter detected — the input parsed as a single column.",
            "None of comma, tab, semicolon, or pipe produced consistent multi-column rows.",
            "Check that the pasted text actually contains a table with a consistent delimiter.");
        }

        if (!rows.length) {
          return { empty: true };
        }

        var header = rows[0].cells;
        var H = header.length;
        var headerNames = header.map(function (h) { return h.trim(); });
        var dataRows = [];
        var i, r;
        for (i = 1; i < rows.length; i++) {
          dataRows.push({ rowNum: i + 1, cells: rows[i].cells, startLine: rows[i].startLine, unclosedLine: rows[i].unclosedLine });
        }
        // Header itself could carry an unclosed quote (row 1).
        if (rows[0].unclosedLine !== null) {
          add("error", "Parse",
            "Unclosed quote in the header row, starting on line " + rows[0].unclosedLine + ".",
            "Everything after the opening quote was swallowed into one field, so the header cannot be trusted.",
            "Close the quote in the header row at line " + rows[0].unclosedLine + " and re-audit.");
        }

        /* ---- Stage 1 findings: unclosed quotes ---- */
        var unclosedRows = {};
        dataRows.forEach(function (dr) {
          if (dr.unclosedLine !== null) {
            unclosedRows[dr.rowNum] = true;
            add("error", "Parse",
              "Unclosed quote in row " + dr.rowNum + ", starting on line " + dr.unclosedLine + ".",
              "The quoted field that opens on line " + dr.unclosedLine + " never closes; the rest of the input was swallowed into that one field.",
              "Close the quote on line " + dr.unclosedLine + " (row " + dr.rowNum + "), or escape it by doubling it, then re-audit.");
          }
        });

        /* ---- Stage 2: structure ---- */
        // Completely empty rows
        var emptyRowNums = [];
        dataRows.forEach(function (dr) {
          if (dr.cells.every(function (c) { return c.trim() === ""; })) emptyRowNums.push(dr.rowNum);
        });
        var emptySet = {};
        emptyRowNums.forEach(function (n) { emptySet[n] = true; });
        if (emptyRowNums.length) {
          add("warn", "Structure",
            emptyRowNums.length + " completely empty row" + (emptyRowNums.length > 1 ? "s" : "") + " found.",
            "Rows: " + emptyRowNums.join(", ") + ". Empty rows are excluded from column profiling and duplicate checks.",
            "Delete the empty rows: " + emptyRowNums.join(", ") + ".");
        }

        // Ragged rows (skip empty rows and rows already broken by unclosed quotes)
        var ragged = [];
        dataRows.forEach(function (dr) {
          if (emptySet[dr.rowNum] || unclosedRows[dr.rowNum]) return;
          if (dr.cells.length !== H) ragged.push(dr);
        });
        ragged.forEach(function (dr) {
          add("error", "Structure",
            "Row " + dr.rowNum + " is ragged: expected " + H + " fields, found " + dr.cells.length + ".",
            "Row " + dr.rowNum + ": " + dr.cells.map(function (c) { return c.trim(); }).join(" | "),
            "Fix row " + dr.rowNum + " to have exactly " + H + " fields (quote any field that contains the delimiter).");
        });

        // Duplicate header names
        var seenHeader = {}, dupHeaders = {};
        headerNames.forEach(function (name, idx) {
          if (name === "") return;
          if (seenHeader[name] !== undefined) {
            if (!dupHeaders[name]) dupHeaders[name] = [seenHeader[name] + 1];
            dupHeaders[name].push(idx + 1);
          } else seenHeader[name] = idx;
        });
        Object.keys(dupHeaders).forEach(function (name) {
          add("error", "Structure",
            'Duplicate header name "' + name + '" (columns ' + dupHeaders[name].join(" and ") + ").",
            "Anything addressing this column by name is ambiguous — code and agents will silently pick one of them.",
            'Rename one of the "' + name + '" columns (columns ' + dupHeaders[name].join(", ") + ") so every header is unique.");
        });

        // Empty / whitespace-only header names
        var emptyHeaders = [];
        headerNames.forEach(function (name, idx) { if (name === "") emptyHeaders.push(idx + 1); });
        // Trailing empty column: last header empty AND every data row's last cell empty/absent.
        var trailingEmptyCol = false;
        if (H > 0 && headerNames[H - 1] === "") {
          trailingEmptyCol = dataRows.every(function (dr) {
            return dr.cells.length < H || dr.cells[H - 1].trim() === "";
          });
        }
        var emptyHeadersExclTrailing = emptyHeaders.filter(function (n) { return !(trailingEmptyCol && n === H); });
        if (emptyHeadersExclTrailing.length) {
          add("error", "Structure",
            "Empty or whitespace-only header name at column" + (emptyHeadersExclTrailing.length > 1 ? "s " : " ") + emptyHeadersExclTrailing.join(", ") + ".",
            "A column with no name cannot be referenced reliably.",
            "Give column" + (emptyHeadersExclTrailing.length > 1 ? "s " : " ") + emptyHeadersExclTrailing.join(", ") + " a real header name, or remove the column.");
        }
        if (trailingEmptyCol) {
          add("warn", "Structure",
            "Trailing empty column: column " + H + " has no header and no values.",
            "Usually caused by a trailing delimiter at the end of every line.",
            "Remove the trailing delimiter / empty column " + H + ".");
        }

        if (!dataRows.length) {
          add("warn", "Structure",
            "The table has a header but no data rows.",
            "There is nothing to profile — and nothing to use.",
            "Paste the data rows along with the header.");
        }

        /* ---- Stage 3: column profiling ---- */
        var usableRows = dataRows.filter(function (dr) { return !emptySet[dr.rowNum] && !unclosedRows[dr.rowNum]; });
        var profiles = [];
        var totalDrift = 0;
        for (var c = 0; c < H; c++) {
          var colName = headerNames[c] === "" ? "(unnamed)" : headerNames[c];
          var vals = []; // {row, raw, v, type}
          var emptyCount = 0, missingCount = 0;
          dataRows.forEach(function (dr) {
            if (emptySet[dr.rowNum] || unclosedRows[dr.rowNum]) { missingCount++; return; } // row excluded from profiling
            if (c >= dr.cells.length) { missingCount++; return; } // cell absent — this row is shorter than the header
            var raw = dr.cells[c];
            var v = raw.trim();
            if (v === "") { emptyCount++; return; }
            vals.push({ row: dr.rowNum, raw: raw, v: v, type: classify(v) });
          });
          var n = vals.length;
          var typeCounts = {};
          vals.forEach(function (x) { typeCounts[x.type] = (typeCounts[x.type] || 0) + 1; });
          var domType = "empty", domCount = 0;
          Object.keys(typeCounts).forEach(function (t) { if (typeCounts[t] > domCount) { domCount = typeCounts[t]; domType = t; } });
          var pct = n ? Math.round((domCount / n) * 1000) / 10 : 0;
          var isMixed = n > 0 && domCount / n < 0.5;
          if (isMixed) domType = "mixed";

          var drift = [];
          if (n > 0 && !isMixed && domType !== "empty") {
            drift = vals.filter(function (x) { return x.type !== domType; });
          }
          totalDrift += drift.length;

          // Mixed date formats
          var fmtCounts = {};
          vals.forEach(function (x) { if (x.type === "date") { var f = dateFormatOf(x.v); fmtCounts[f] = (fmtCounts[f] || 0) + 1; } });
          var fmtKeys = Object.keys(fmtCounts);

          // Leading-zero loss risk
          var lz = [];
          if (domType === "integer" || domType === "decimal") {
            lz = vals.filter(function (x) { return /^0\d+$/.test(x.v); });
          }
          // Surrounding whitespace
          var ws = vals.filter(function (x) { return x.raw !== x.v; });

          profiles.push({
            idx: c + 1, name: colName, type: n === 0 ? "empty" : domType, pct: n === 0 ? 0 : pct,
            nonempty: n, empty: emptyCount, missing: missingCount, drift: drift, fmtCounts: fmtCounts, fmtKeys: fmtKeys, lz: lz, ws: ws
          });

          if (drift.length) {
            var cap = drift.slice(0, 25);
            var detail = cap.map(function (x) {
              return "row " + x.row + ", column \"" + colName + "\": \"" + x.v + "\" is " + x.type + ", column is " + domType;
            }).join("\n");
            if (drift.length > cap.length) detail += "\n… and " + (drift.length - cap.length) + " more (total " + drift.length + " drift cells in this column)";
            add("warn", "Column profile",
              "Type drift in column \"" + colName + "\" (column " + (c + 1) + "): " + drift.length + " value" + (drift.length > 1 ? "s do" : " does") + " not match the dominant type " + domType + " (" + pct + "%).",
              detail,
              "Fix the " + drift.length + " drifted value" + (drift.length > 1 ? "s" : "") + " in column \"" + colName + "\" so the whole column is " + domType + ", or treat the column as text on purpose.");
          }
          if (fmtKeys.length > 1) {
            add("warn", "Column profile",
              "Mixed date formats in column \"" + colName + "\" (column " + (c + 1) + ").",
              fmtKeys.map(function (f) { return f + ": " + fmtCounts[f] + " value" + (fmtCounts[f] > 1 ? "s" : ""); }).join("\n"),
              "Standardize column \"" + colName + "\" to one date format (ISO YYYY-MM-DD is the safe choice) before parsing any of it as a date.");
          }
          if (lz.length) {
            add("warn", "Column profile",
              "Leading-zero loss risk in column \"" + colName + "\" (column " + (c + 1) + "): " + lz.length + " value" + (lz.length > 1 ? "s start" : " starts") + " with 0.",
              lz.slice(0, 25).map(function (x) { return "row " + x.row + ": \"" + x.v + "\""; }).join("\n") +
                (lz.length > 25 ? "\n… and " + (lz.length - 25) + " more" : ""),
              "Keep column \"" + colName + "\" as text end-to-end — parsing values like \"" + lz[0].v + "\" as numbers silently drops the leading zero.");
          }
          if (ws.length) {
            add("warn", "Column profile",
              ws.length + " value" + (ws.length > 1 ? "s" : "") + " in column \"" + colName + "\" (column " + (c + 1) + ") ha" + (ws.length > 1 ? "ve" : "s") + " surrounding whitespace.",
              ws.slice(0, 25).map(function (x) { return "row " + x.row + ": \"" + x.raw + "\""; }).join("\n") +
                (ws.length > 25 ? "\n… and " + (ws.length - 25) + " more" : ""),
              "Trim whitespace from the values in column \"" + colName + "\" — stray spaces break joins, lookups, and exact matches.");
          }
        }

        /* ---- Stage 4: row checks ---- */
        // Exact duplicate rows
        var rowMap = {}, dupGroups = [];
        usableRows.forEach(function (dr) {
          var key = dr.cells.map(function (x) { return x.trim(); }).join("");
          if (rowMap[key]) rowMap[key].push(dr.rowNum);
          else rowMap[key] = [dr.rowNum];
        });
        Object.keys(rowMap).forEach(function (k) { if (rowMap[k].length > 1) dupGroups.push(rowMap[k]); });
        if (dupGroups.length) {
          var totalDupRows = dupGroups.reduce(function (s, g) { return s + g.length; }, 0);
          add("warn", "Row checks",
            dupGroups.length + " set" + (dupGroups.length > 1 ? "s" : "") + " of exact duplicate rows (" + totalDupRows + " rows involved).",
            dupGroups.map(function (g) { return "rows " + g.join(", ") + " are identical"; }).join("\n"),
            "Remove the duplicate copies: " + dupGroups.map(function (g) { return "rows " + g.join(", "); }).join("; ") + " — keep one of each.");
        }

        // Near-duplicate rows: differ in exactly one column (full-length rows only)
        var fullRows = usableRows.filter(function (dr) { return dr.cells.length === H; });
        var nearPairs = [], nearSkipped = false;
        if (fullRows.length > 600) {
          nearSkipped = true;
        } else {
          for (var a = 0; a < fullRows.length; a++) {
            for (var b = a + 1; b < fullRows.length; b++) {
              var diffCols = [];
              for (var cc = 0; cc < H; cc++) {
                if (fullRows[a].cells[cc].trim() !== fullRows[b].cells[cc].trim()) diffCols.push(cc);
              }
              if (diffCols.length === 1) {
                nearPairs.push({ r1: fullRows[a].rowNum, r2: fullRows[b].rowNum, col: diffCols[0] });
              }
            }
          }
        }
        if (nearPairs.length) {
          var nearCap = nearPairs.slice(0, 20);
          add("warn", "Row checks",
            nearPairs.length + " near-duplicate pair" + (nearPairs.length > 1 ? "s" : "") + " differ in exactly one column.",
            nearCap.map(function (p) {
              var nm = headerNames[p.col] === "" ? "(unnamed)" : headerNames[p.col];
              return "rows " + p.r1 + " and " + p.r2 + " differ only in column \"" + nm + "\" (column " + (p.col + 1) + ")";
            }).join("\n") + (nearPairs.length > nearCap.length ? "\n… and " + (nearPairs.length - nearCap.length) + " more pairs" : ""),
            "Review each near-duplicate pair — one of the two rows is usually a stale or mistyped copy.");
        }

        // Rows empty except one cell
        var singleCell = usableRows.filter(function (dr) {
          return dr.cells.filter(function (x) { return x.trim() !== ""; }).length === 1;
        });
        if (singleCell.length) {
          add("warn", "Row checks",
            singleCell.length + " row" + (singleCell.length > 1 ? "s are" : " is") + " empty except for one cell.",
            singleCell.map(function (dr) {
              var j = dr.cells.findIndex(function (x) { return x.trim() !== ""; });
              var nm = headerNames[j] === "" ? "(unnamed)" : headerNames[j];
              return "row " + dr.rowNum + ": only column \"" + nm + "\" has a value (\"" + dr.cells[j].trim() + "\")";
            }).join("\n"),
            "Check rows " + singleCell.map(function (dr) { return dr.rowNum; }).join(", ") + " — a lone value usually means the rest of the row was lost or never filled in.");
        }

        /* ---- Stage 5: verdict ---- */
        var errors = findings.filter(function (f) { return f.sev === "error"; }).length;
        var warns = findings.filter(function (f) { return f.sev === "warn"; }).length;
        var verdict, vClass;
        if (errors > 0) { verdict = "DO NOT TRUST THIS TABLE"; vClass = "err"; }
        else if (warns > 0) { verdict = "USE WITH FIXES"; vClass = "warn"; }
        else { verdict = "CLEAN ENOUGH TO USE"; vClass = "ok"; }

        return {
          empty: false, mode: mode, delimInfo: delimInfo, header: header, headerNames: headerNames,
          dataRowCount: dataRows.length, findings: findings, profiles: profiles,
          errors: errors, warns: warns, verdict: verdict, vClass: vClass,
          nearSkipped: nearSkipped, totalDrift: totalDrift
        };
      }

      /* ---------------- Rendering ---------------- */
      function colDisplayName(p) {
        return p.name === "(unnamed)" ? "column " + p.idx + " (unnamed)" : '"' + p.name + '" (col ' + p.idx + ")";
      }

      function buildReport(res) {
        var L = [];
        L.push("J-DAWGS CSV & TABULAR INTEGRITY AUDITOR — AUDIT REPORT");
        L.push("========================================================");
        L.push("Verdict: " + res.verdict);
        L.push("Format: " + (res.mode === "markdown" ? "Markdown table" : "Delimited text"));
        L.push("Delimiter: " + res.delimInfo.name + " — confidence " + res.delimInfo.confidence + "% (" + res.delimInfo.label + ")");
        L.push("Size: " + res.dataRowCount + " data rows, " + res.header.length + " columns (row 1 is the header)");
        L.push("Findings: " + res.errors + " error(s), " + res.warns + " warning(s)");
        L.push("");
        L.push("FINDINGS");
        L.push("--------");
        if (!res.findings.length) {
          L.push("None. No errors, no warnings — the table passed every check.");
        } else {
          res.findings.forEach(function (f) {
            L.push("[" + f.sev.toUpperCase() + "] (" + f.stage + ") " + f.msg);
            if (f.detail) {
              f.detail.split("\n").forEach(function (d) { L.push("    " + d); });
            }
          });
        }
        if (res.nearSkipped) L.push("[INFO] Near-duplicate check skipped: more than 600 data rows.");
        L.push("");
        L.push("FIX CHECKLIST (severity order)");
        L.push("------------------------------");
        var sorted = res.findings.slice().sort(function (a, b) {
          return (a.sev === "error" ? 0 : 1) - (b.sev === "error" ? 0 : 1);
        });
        if (!sorted.length) L.push("Nothing to fix.");
        sorted.forEach(function (f, i) {
          if (f.fix) L.push((i + 1) + ". [" + f.sev.toUpperCase() + "] " + f.fix);
        });
        L.push("");
        L.push("COLUMN PROFILES");
        L.push("---------------");
        L.push("Counts reconcile: non-empty + empty + missing/excluded = " + res.dataRowCount + " data rows, for every column.");
        res.profiles.forEach(function (p) {
          var notes = [];
          if (p.drift.length) notes.push(p.drift.length + " drift cell(s)");
          if (p.fmtKeys.length > 1) notes.push("date formats: " + p.fmtKeys.map(function (k) { return k + " x" + p.fmtCounts[k]; }).join(", "));
          if (p.lz.length) notes.push(p.lz.length + " leading-zero value(s)");
          if (p.ws.length) notes.push(p.ws.length + " whitespace value(s)");
          L.push("- " + colDisplayName(p) + ": dominant type " + p.type +
            ", " + p.pct + "% of " + p.nonempty + " non-empty values match; " + p.empty + " empty, " + p.missing + " missing/excluded" +
            (notes.length ? "; " + notes.join("; ") : ""));
        });
        L.push("");
        L.push("Note: this report covers the pasted text only. Well-formed values can still be wrong.");
        return L.join("\n");
      }

      function render(res) {
        $("empty-msg").classList.add("hidden");
        $("results").classList.remove("hidden");

        var vSub = res.errors > 0
          ? res.errors + " error(s) and " + res.warns + " warning(s). Structural or parse damage means values can be silently shifted, merged, or misattributed — fix the errors and re-audit before using any of it."
          : res.warns > 0
            ? "No errors, but " + res.warns + " warning(s) need attention. Work through the fix checklist, then re-audit."
            : "Zero errors, zero warnings. Every check passed — parse, structure, column types, and rows.";
        $("verdict").className = "verdict " + res.vClass;
        $("verdict").innerHTML =
          '<div class="v-label">Verdict</div>' +
          '<div class="v-text">' + esc(res.verdict) + "</div>" +
          '<div class="v-sub">' + esc(vSub) + "</div>";

        var chips = [
          "<b>Format:</b>&nbsp;" + (res.mode === "markdown" ? "Markdown table" : "Delimited text"),
          "<b>Delimiter:</b>&nbsp;" + esc(res.delimInfo.name),
          "<b>Delimiter confidence:</b>&nbsp;" + res.delimInfo.confidence + "% (" + res.delimInfo.label + ")",
          "<b>Rows:</b>&nbsp;" + res.dataRowCount + " data + header",
          "<b>Columns:</b>&nbsp;" + res.header.length,
          "<b>Errors:</b>&nbsp;" + res.errors,
          "<b>Warnings:</b>&nbsp;" + res.warns
        ];
        $("chips").innerHTML = chips.map(function (ch) { return '<span class="chip">' + ch + "</span>"; }).join("");

        if (!res.findings.length) {
          $("findings").innerHTML = '<div class="clean-note">No findings. The table passed parsing, structure, column profiling, and row checks with nothing to flag.</div>';
        } else {
          $("findings").innerHTML = res.findings.map(function (f) {
            return '<div class="finding ' + f.sev + '">' +
              '<span class="sev">' + (f.sev === "error" ? "Error" : "Warning") + "</span>" +
              '<span class="stage">' + esc(f.stage) + "</span>" +
              esc(f.msg) +
              (f.detail ? '<span class="detail">' + esc(f.detail) + "</span>" : "") +
              "</div>";
          }).join("") + (res.nearSkipped
            ? '<div class="finding warn"><span class="sev">Warning</span><span class="stage">Row checks</span>Near-duplicate check skipped: more than 600 data rows.</div>'
            : "");
        }

        var rowsHtml = res.profiles.map(function (p) {
          var notes = [];
          if (p.drift.length) notes.push(p.drift.length + " drift cell" + (p.drift.length > 1 ? "s" : ""));
          if (p.fmtKeys.length > 1) notes.push("formats: " + p.fmtKeys.map(function (k) { return k + " ×" + p.fmtCounts[k]; }).join(", "));
          else if (p.fmtKeys.length === 1) notes.push("format: " + p.fmtKeys[0]);
          if (p.lz.length) notes.push(p.lz.length + " leading-zero value" + (p.lz.length > 1 ? "s" : ""));
          if (p.ws.length) notes.push(p.ws.length + " whitespace value" + (p.ws.length > 1 ? "s" : ""));
          return "<tr>" +
            '<td class="colname" data-label="Column">' + esc(p.name) + " <span style='color:var(--ink-soft)'>(col " + p.idx + ")</span></td>" +
            '<td data-label="Dominant type">' + esc(p.type) + "</td>" +
            '<td class="num" data-label="Match">' + p.pct + "%</td>" +
            '<td class="num" data-label="Non-empty">' + p.nonempty + "</td>" +
            '<td class="num" data-label="Empty">' + p.empty + "</td>" +
            '<td class="num" data-label="Missing">' + p.missing + "</td>" +
            '<td data-label="Notes">' + (notes.length ? esc(notes.join("; ")) : "—") + "</td>" +
            "</tr>";
        }).join("");
        $("profiles").innerHTML =
          '<table class="profile"><thead><tr>' +
          "<th>Column</th><th>Dominant type</th><th class='num'>Match</th><th class='num'>Non-empty</th><th class='num'>Empty</th><th class='num'>Missing</th><th>Notes</th>" +
          "</tr></thead><tbody>" + rowsHtml + "</tbody></table>" +
          '<p class="hint">Counts reconcile to the data-row total: Non-empty + Empty + Missing = ' + res.dataRowCount + ' data rows, for every column. “Missing” counts cells that are absent because a row is shorter than the header, plus every cell of rows excluded from profiling (completely empty rows, and any row with an unclosed quote).</p>';

        var sorted = res.findings.slice().sort(function (a, b) {
          return (a.sev === "error" ? 0 : 1) - (b.sev === "error" ? 0 : 1);
        }).filter(function (f) { return f.fix; });
        $("fixes").innerHTML = sorted.length
          ? '<ol class="fixes">' + sorted.map(function (f) {
              return '<li><span class="sev ' + f.sev + '">' + f.sev + "</span> — " + esc(f.fix) + "</li>";
            }).join("") + "</ol>"
          : '<div class="clean-note">Nothing to fix.</div>';

        $("report").value = buildReport(res);
      }

      function runAudit() {
        var text = $("input").value;
        if (text.trim() === "") {
          $("results").classList.add("hidden");
          $("empty-msg").classList.remove("hidden");
          return;
        }
        var res = audit(text);
        if (res.empty) {
          $("results").classList.add("hidden");
          $("empty-msg").classList.remove("hidden");
          return;
        }
        render(res);
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "MESSY_SAMPLE": (typeof MESSY_SAMPLE !== 'undefined' ? MESSY_SAMPLE : undefined), "CLEAN_SAMPLE": (typeof CLEAN_SAMPLE !== 'undefined' ? CLEAN_SAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-csv-tabular-integrity-auditor',
  name: 'J-Dawgs CSV & Tabular Integrity Auditor',
  description: 'Audits a pasted CSV/TSV/Markdown table for ragged rows, duplicate headers, column type drift, mixed date formats, leading-zero loss, and duplicate rows, with a trust verdict and fix checklist before an agent uses the data',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "MESSY_SAMPLE": __core["MESSY_SAMPLE"], "CLEAN_SAMPLE": __core["CLEAN_SAMPLE"] }
};
