'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Jenkins Controller Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

    "use strict";

    /* ---------- Worked examples (line numbers matter; keep arrays tidy) ---------- */

    var RISKY_EXAMPLE = [
      'jenkins:',
      '  systemMessage: "Team build controller"',
      '  numExecutors: 4',
      '  securityRealm:',
      '    legacy:',
      '      allowsSignup: true',
      '  authorizationStrategy:',
      '    loggedInUsersCanDoAnything:',
      '      allowAnonymousRead: true',
      '  agentProtocols:',
      '    - "JNLP-connect"',
      '    - "JNLP2-connect"',
      '    - "JNLP4-connect"',
      '  markupFormatter:',
      '    rawHtml:',
      '      disableSyntaxHighlighting: false',
      'unclassified:',
      '  location:',
      '    url: "http://builds.example.internal:8080/"',
      'credentials:',
      '  system:',
      '    domainCredentials:',
      '      - credentials:',
      '          - usernamePassword:',
      '              scope: GLOBAL',
      '              id: "deploy-creds"',
      '              username: "deploybot"',
      '              password: "Tr0ub4dor-plaintext-7429"'
    ].join("\n");

    var HARDENED_EXAMPLE = [
      'jenkins:',
      '  systemMessage: "Team build controller"',
      '  numExecutors: 0',
      '  mode: EXCLUSIVE',
      '  securityRealm:',
      '    local:',
      '      allowsSignup: false',
      '      users:',
      '        - id: "admin"',
      '          password: "${ADMIN_INITIAL_PASSWORD}"',
      '  authorizationStrategy:',
      '    globalMatrix:',
      '      entries:',
      '        - user:',
      '            name: "admin"',
      '            permissions:',
      '              - "Overall/Administer"',
      '        - group:',
      '            name: "authenticated"',
      '            permissions:',
      '              - "Overall/Read"',
      '              - "Job/Read"',
      '  agentProtocols:',
      '    - "JNLP4-connect"',
      '    - "Ping"',
      '  crumbIssuer:',
      '    standard:',
      '      excludeClientIPFromCrumb: true',
      '  markupFormatter:',
      '    safeHtml: {}',
      'unclassified:',
      '  location:',
      '    url: "https://builds.example.com/"',
      'credentials:',
      '  system:',
      '    domainCredentials:',
      '      - credentials:',
      '          - string:',
      '              scope: GLOBAL',
      '              id: "deploy-token"',
      '              secret: "${DEPLOY_TOKEN}"'
    ].join("\n");

    /* ---------- Small helpers ---------- */

    function indentOf(line) {
      var m = line.match(/^[ \t]*/);
      return m ? m[0].length : 0;
    }

    /* Lines belonging to the YAML block that starts at keyIdx (exclusive),
       stopping when indentation returns to the key's level or less. */
    function blockLines(lines, keyIdx) {
      var base = indentOf(lines[keyIdx]);
      var out = [];
      for (var i = keyIdx + 1; i < lines.length; i++) {
        var raw = lines[i];
        if (raw.trim() === "") { continue; }
        if (indentOf(raw) <= base) { break; }
        out.push({ idx: i, line: i + 1, text: raw });
      }
      return out;
    }

    function findYamlKey(lines, keyName) {
      var re = new RegExp("^\\s*" + keyName + "\\s*:\\s*(.*)$");
      for (var i = 0; i < lines.length; i++) {
        var m = lines[i].match(re);
        if (m) { return { idx: i, line: i + 1, inline: (m[1] || "").trim() }; }
      }
      return null;
    }

    function stripQuotes(v) {
      v = v.trim();
      if (v.length >= 2) {
        var first = v.charAt(0), last = v.charAt(v.length - 1);
        if ((first === '"' && last === '"') || (first === "'" && last === "'")) {
          return v.slice(1, -1);
        }
      }
      return v;
    }

    function makeFinding(severity, check, line, title, detail, fix) {
      return { severity: severity, check: check, line: line, title: title, detail: detail, fix: fix || null };
    }

    /* ---------- Secret scanning: key name + line + length ONLY.
       The value itself is never stored on a finding, a report, or the JSON. ---------- */

    var SECRET_KEY_RE = /(password|passwd|pwd|token|secret|credential|api[-_]?key|private[-_]?key)/i;

    function auditSecretsYaml(lines, findings, stats) {
      var re = /^\s*-?\s*"?([A-Za-z0-9_.\-]+)"?\s*:\s*(\S.*?)\s*$/;
      for (var i = 0; i < lines.length; i++) {
        var m = lines[i].match(re);
        if (!m) { continue; }
        var key = m[1];
        if (!SECRET_KEY_RE.test(key)) { continue; }
        var value = stripQuotes(m[2].replace(/\s+#.*$/, ""));
        if (value === "" || value === "~" || value === "null" || value === "{}" || value === "[]") { continue; }
        if (value.indexOf("${") === 0) { stats.envSecrets++; continue; }
        if (value.charAt(0) === "{" && value.charAt(value.length - 1) === "}") { stats.encryptedSecrets++; continue; }
        findings.push(makeFinding("HIGH", "plaintext-secret", i + 1,
          "Plaintext secret inline: key \"" + key + "\"",
          "A secret-looking value is written directly in the config at line " + (i + 1) + " under the key \"" + key + "\" (value length: " + value.length + " characters; the value itself is never shown by this tool). Anyone who can read this file — a repo, a backup, a screenshot — has the credential.",
          "Move the value for \"" + key + "\" out of the config: reference an environment variable (e.g. ${VARIABLE_NAME}) or a secrets file, and rotate the exposed credential since it has been committed in plaintext."));
        stats.plaintextSecrets++;
      }
    }

    function auditSecretsXml(lines, findings, stats) {
      var re = /<([A-Za-z0-9_.\-]+)>\s*([^<>]+?)\s*<\/\1>/;
      for (var i = 0; i < lines.length; i++) {
        var m = lines[i].match(re);
        if (!m) { continue; }
        var key = m[1];
        if (!SECRET_KEY_RE.test(key)) { continue; }
        var value = m[2].trim();
        if (value === "") { continue; }
        if (value.charAt(0) === "{" && value.charAt(value.length - 1) === "}") { stats.encryptedSecrets++; continue; }
        findings.push(makeFinding("HIGH", "plaintext-secret", i + 1,
          "Unencrypted secret value: element <" + key + ">",
          "The <" + key + "> element at line " + (i + 1) + " holds a value that is not in Jenkins' encrypted {…} form (value length: " + value.length + " characters; the value itself is never shown by this tool). Jenkins normally encrypts these values at rest, so a bare value means it was hand-edited in or exported unprotected.",
          "Let Jenkins re-encrypt the value for <" + key + "> (re-save it through the UI or credentials store) and rotate the credential, since it has existed in plaintext."));
        stats.plaintextSecrets++;
      }
    }

    /* ---------- YAML (JCasC) audit ---------- */

    function auditYaml(lines, findings, notChecked, stats) {
      /* --- securityRealm --- */
      var realm = findYamlKey(lines, "securityRealm");
      if (!realm) {
        findings.push(makeFinding("BLOCKER", "security-realm", null,
          "No security realm declared",
          "The paste declares no securityRealm. If this file is the controller's configuration, Jenkins has no defined way to authenticate users — on a fresh controller that means the setup falls back to defaults that were never reviewed.",
          "Declare a real securityRealm (for example the local user database, LDAP, or an SSO/OIDC realm) in the JCasC file."));
      } else {
        var realmType = null, realmTypeLine = realm.line;
        if (realm.inline) {
          realmType = stripQuotes(realm.inline).replace(/:$/, "");
        } else {
          var rBlock = blockLines(lines, realm.idx);
          for (var r = 0; r < rBlock.length; r++) {
            var rm = rBlock[r].text.match(/^\s*-?\s*([A-Za-z0-9_]+)\s*:/);
            if (rm) { realmType = rm[1]; realmTypeLine = rBlock[r].line; break; }
          }
          for (var s = 0; s < rBlock.length; s++) {
            if (/allowsSignup\s*:\s*true/i.test(rBlock[s].text)) {
              findings.push(makeFinding("MEDIUM", "security-realm-signup", rBlock[s].line,
                "Self-signup is open on the security realm",
                "Line " + rBlock[s].line + " sets allowsSignup: true, so anyone who can reach the controller login page can create their own account.",
                "Set allowsSignup to false and provision accounts deliberately."));
            }
          }
        }
        if (realmType && realmType.toLowerCase() === "none") {
          findings.push(makeFinding("BLOCKER", "security-realm", realmTypeLine,
            "Security realm is set to \"none\"",
            "Line " + realmTypeLine + " selects the \"none\" security realm: the controller performs no authentication at all. Anyone who can reach it is effectively an administrator.",
            "Replace the \"none\" realm with a real realm (local database, LDAP, or SSO) before this controller is reachable by anyone else."));
        } else if (realmType && realmType.toLowerCase() === "legacy") {
          findings.push(makeFinding("BLOCKER", "security-realm", realmTypeLine,
            "Security realm is set to \"legacy\" mode",
            "Line " + realmTypeLine + " selects the legacy realm, which delegates to the servlet container the way very old Jenkins versions did. It is a compatibility fallback, not a reviewed authentication setup, and it is commonly left over from migrations.",
            "Move to an explicit realm (local user database, LDAP, or an SSO/OIDC plugin realm) and confirm logins work before decommissioning the legacy setting."));
        }
      }

      /* --- authorizationStrategy --- */
      var strat = findYamlKey(lines, "authorizationStrategy");
      if (!strat) {
        findings.push(makeFinding("HIGH", "authorization-strategy", null,
          "No authorization strategy declared",
          "The paste declares no authorizationStrategy. Who is allowed to do what is then decided by whatever the controller already has, not by this reviewed file.",
          "Declare an authorizationStrategy (for example a matrix strategy) that grants Overall/Administer only to named administrators."));
      } else {
        var stratType = null, stratTypeLine = strat.line;
        var sBlock = blockLines(lines, strat.idx);
        if (strat.inline) {
          stratType = stripQuotes(strat.inline).replace(/:$/, "");
        } else if (sBlock.length > 0) {
          var sm = sBlock[0].text.match(/^\s*-?\s*([A-Za-z0-9_]+)\s*:/);
          if (sm) { stratType = sm[1]; stratTypeLine = sBlock[0].line; }
        }
        if (stratType && stratType.toLowerCase() === "unsecured") {
          findings.push(makeFinding("BLOCKER", "authorization-strategy", stratTypeLine,
            "Authorization strategy is \"unsecured\"",
            "Line " + stratTypeLine + " selects the unsecured strategy: every visitor, signed in or not, can do everything, including administering the controller and running arbitrary code through it.",
            "Replace \"unsecured\" with a restrictive strategy (logged-in users or a matrix) that grants anonymous users nothing."));
        }
        var blockText = sBlock.map(function (b) { return b.text; }).join("\n");
        var anonLine = null;
        for (var a = 0; a < sBlock.length; a++) {
          if (/anonymous/i.test(sBlock[a].text)) { anonLine = sBlock[a].line; break; }
        }
        if (anonLine !== null || /allowAnonymousRead\s*:\s*true/i.test(blockText)) {
          var grantsAdmin = /Overall\/Administer/.test(blockText) || /Hudson\.Administer/.test(blockText) || /Administer\s*:\s*anonymous/i.test(blockText) || /Administer:anonymous/.test(blockText);
          var grantsRead = /Overall\/Read/.test(blockText) || /Hudson\.Read/.test(blockText) || /Read\s*:\s*anonymous/i.test(blockText) || /allowAnonymousRead\s*:\s*true/i.test(blockText);
          var readLine = anonLine;
          for (var q = 0; q < sBlock.length; q++) {
            if (/allowAnonymousRead\s*:\s*true/i.test(sBlock[q].text)) { readLine = sBlock[q].line; break; }
          }
          if (grantsAdmin && anonLine !== null) {
            findings.push(makeFinding("BLOCKER", "authorization-strategy", anonLine,
              "Anonymous users are granted Overall/Administer",
              "The authorization strategy block gives the anonymous user administrative control of the controller (see line " + anonLine + "). An unauthenticated visitor with Overall/Administer can run arbitrary code on the controller host.",
              "Remove every permission granted to anonymous; administer rights belong to named, authenticated administrators only."));
          } else if (grantsRead) {
            findings.push(makeFinding("HIGH", "authorization-strategy", readLine,
              "Anonymous users can read the controller",
              "The authorization strategy lets unauthenticated visitors read the controller (line " + readLine + "). Anonymous read exposes job names, build history, console output, and configuration details that help an attacker plan the next step.",
              "Remove anonymous read (set allowAnonymousRead to false, or drop the anonymous entries from the matrix) unless this controller is deliberately public."));
          }
        }
      }

      /* --- CSRF crumb issuer --- */
      var crumb = findYamlKey(lines, "crumbIssuer");
      if (!crumb) {
        findings.push(makeFinding("MEDIUM", "csrf-crumb", null,
          "No CSRF crumb issuer declared",
          "The paste declares no crumbIssuer. Current Jenkins enables a default crumb issuer on its own, but a configuration-managed controller should state its CSRF protection explicitly so the posture is reviewed rather than assumed — and anything that disables it elsewhere would go unnoticed.",
          "Declare the standard crumb issuer under jenkins: (crumbIssuer: standard:) so CSRF protection is explicit in the file."));
      }

      /* --- Agent protocols --- */
      var proto = findYamlKey(lines, "agentProtocols");
      if (!proto) {
        notChecked.push("Agent (JNLP) protocol posture — no agentProtocols list is stated in the paste");
      } else {
        var pBlock = blockLines(lines, proto.idx);
        var oldProtos = { "jnlp-connect": 1, "jnlp2-connect": 1, "jnlp3-connect": 1 };
        for (var p = 0; p < pBlock.length; p++) {
          var pm = pBlock[p].text.match(/-\s*"?([A-Za-z0-9\-]+)"?/);
          if (!pm) { continue; }
          var name = pm[1];
          var lower = name.toLowerCase();
          if (oldProtos[lower]) {
            findings.push(makeFinding("HIGH", "agent-protocols", pBlock[p].line,
              "Unsafe agent protocol enabled: " + name,
              "Line " + pBlock[p].line + " enables " + name + ", an early JNLP agent protocol generation that predates the current protocol's security fixes. Controllers should only speak the current generation (JNLP4-connect) plus Ping.",
              "Remove " + name + " from agentProtocols, leaving JNLP4-connect and Ping, and reconnect agents so they negotiate the current protocol."));
          } else if (lower === "cli-connect") {
            findings.push(makeFinding("HIGH", "agent-protocols", pBlock[p].line,
              "CLI remoting protocol enabled: " + name,
              "Line " + pBlock[p].line + " enables the legacy CLI remoting protocol, a long-standing attack surface that current Jenkins disables by default.",
              "Remove CLI-connect from agentProtocols and use the HTTP-based CLI or SSH access instead."));
          }
        }
      }

      /* --- Agent listener port --- */
      var portM = null;
      for (var pi = 0; pi < lines.length; pi++) {
        var pmatch = lines[pi].match(/slaveAgentPort\s*:\s*(-?\d+)/);
        if (pmatch) { portM = { line: pi + 1, value: parseInt(pmatch[1], 10) }; break; }
      }
      if (!portM) {
        notChecked.push("Inbound agent listener (TCP port) posture — no slaveAgentPort is stated in the paste");
      } else if (portM.value > 0) {
        findings.push(makeFinding("INFO", "agent-listener", portM.line,
          "Inbound agent listener on fixed port " + portM.value,
          "Line " + portM.line + " pins the inbound agent (JNLP) listener to TCP port " + portM.value + ". That is a normal setup — just make sure firewalls and security groups only let actual agents reach it, since it is a direct line into the controller.",
          null));
      }

      /* --- Markup formatter --- */
      var markup = findYamlKey(lines, "markupFormatter");
      if (!markup) {
        notChecked.push("Markup formatter — not stated in the paste (current Jenkins defaults to escaping HTML in job descriptions)");
      } else {
        var mBlock = blockLines(lines, markup.idx);
        var mType = null, mLine = markup.line;
        if (markup.inline) { mType = stripQuotes(markup.inline); }
        else if (mBlock.length > 0) {
          var mm = mBlock[0].text.match(/^\s*-?\s*([A-Za-z0-9_]+)\s*:/);
          if (mm) { mType = mm[1]; mLine = mBlock[0].line; }
        }
        if (mType && mType.toLowerCase() === "rawhtml") {
          findings.push(makeFinding("HIGH", "markup-formatter", mLine,
            "Markup formatter renders raw HTML",
            "Line " + mLine + " selects the raw HTML markup formatter: job descriptions and other user-supplied text are rendered as HTML in the browser. Any user who can edit a job description can inject script into the pages of everyone who views it, including administrators.",
            "Switch the markup formatter to safeHtml (or plain text) so user-supplied markup is sanitized."));
        }
      }

      /* --- Root URL --- */
      var urlInfo = null;
      var loc = findYamlKey(lines, "location");
      if (loc) {
        var lBlock = blockLines(lines, loc.idx);
        for (var u = 0; u < lBlock.length; u++) {
          var um = lBlock[u].text.match(/url\s*:\s*"?([^"\s]+)"?/);
          if (um) { urlInfo = { line: lBlock[u].line, value: um[1] }; break; }
        }
      }
      if (!urlInfo) {
        for (var u2 = 0; u2 < lines.length; u2++) {
          var um2 = lines[u2].match(/^\s*url\s*:\s*"?(https?:\/\/[^"\s]+)"?/);
          if (um2) { urlInfo = { line: u2 + 1, value: um2[1] }; break; }
        }
      }
      if (!urlInfo) {
        notChecked.push("Controller root URL — no location URL is stated in the paste");
      } else if (urlInfo.value.toLowerCase().indexOf("http://") === 0) {
        findings.push(makeFinding("MEDIUM", "root-url", urlInfo.line,
          "Controller root URL uses plain HTTP",
          "Line " + urlInfo.line + " sets the controller root URL to an http:// address. Links Jenkins generates (build emails, webhooks, agent connections, OAuth callbacks) will point at the unencrypted address, and users following them send credentials and session cookies in the clear wherever TLS is not terminated in front.",
          "Put the controller behind HTTPS and set the root URL to the https:// address."));
      }

      /* --- numExecutors on the controller --- */
      var exec = findYamlKey(lines, "numExecutors");
      if (!exec) {
        notChecked.push("Controller executor count — no numExecutors is stated in the paste");
      } else {
        var n = parseInt(exec.inline, 10);
        if (!isNaN(n) && n > 0) {
          findings.push(makeFinding("MEDIUM", "controller-executors", exec.line,
            "Builds run on the controller itself (numExecutors: " + n + ")",
            "Line " + exec.line + " gives the controller " + n + " build executor(s). Every build script then runs on the controller host with the controller's own access — a malicious or careless build can read controller credentials and configuration. Builds belong on agents.",
            "Set numExecutors to 0 on the controller and run builds on agents."));
        }
      }

      auditSecretsYaml(lines, findings, stats);
    }

    /* ---------- XML (config.xml) audit ---------- */

    function findXmlLine(lines, re) {
      for (var i = 0; i < lines.length; i++) {
        if (re.test(lines[i])) { return i + 1; }
      }
      return null;
    }

    function auditXml(lines, text, findings, notChecked, stats) {
      var useSecFalseLine = findXmlLine(lines, /<useSecurity>\s*false\s*<\/useSecurity>/i);
      if (useSecFalseLine !== null) {
        findings.push(makeFinding("BLOCKER", "security-enabled", useSecFalseLine,
          "Security is switched off (useSecurity: false)",
          "Line " + useSecFalseLine + " sets <useSecurity>false</useSecurity>: the controller performs no authentication or authorization at all. Anyone who can reach it can administer it and run code on the host.",
          "Set useSecurity to true and configure a security realm and authorization strategy."));
      }

      /* securityRealm */
      var realmLine = findXmlLine(lines, /<securityRealm[\s>]/);
      var realmClassM = text.match(/<securityRealm[^>]*class="([^"]+)"/);
      if (!realmClassM && !realmLine) {
        if (useSecFalseLine === null) {
          findings.push(makeFinding("BLOCKER", "security-realm", null,
            "No securityRealm element in config.xml",
            "The pasted config.xml contains no <securityRealm> element. A controller without a realm has no defined way to authenticate users.",
            "Configure a security realm (for example the Jenkins user database or LDAP) so the controller authenticates users."));
        }
      } else if (realmClassM) {
        var rc = realmClassM[1];
        if (/NoneSecurityRealm/i.test(rc)) {
          findings.push(makeFinding("BLOCKER", "security-realm", realmLine,
            "Security realm is \"none\" (NoneSecurityRealm)",
            "The securityRealm at line " + realmLine + " is the none realm: the controller authenticates nobody, so every visitor is treated as trusted.",
            "Replace NoneSecurityRealm with a real realm (Jenkins user database, LDAP, or SSO)."));
        } else if (/LegacySecurityRealm/i.test(rc)) {
          findings.push(makeFinding("BLOCKER", "security-realm", realmLine,
            "Security realm is legacy mode (LegacySecurityRealm)",
            "The securityRealm at line " + realmLine + " is the legacy realm, a compatibility fallback that delegates to the servlet container instead of a reviewed authentication setup.",
            "Move to an explicit realm (Jenkins user database, LDAP, or an SSO plugin realm)."));
        }
        if (/HudsonPrivateSecurityRealm/i.test(rc)) {
          var signupLine = findXmlLine(lines, /<disableSignup>\s*false\s*<\/disableSignup>/i);
          if (signupLine !== null) {
            findings.push(makeFinding("MEDIUM", "security-realm-signup", signupLine,
              "Self-signup is open on the Jenkins user database",
              "Line " + signupLine + " leaves signup enabled (<disableSignup>false</disableSignup>), so anyone who can reach the login page can create an account.",
              "Disable signup and create accounts deliberately."));
          }
        }
      }

      /* authorizationStrategy */
      var stratLine = findXmlLine(lines, /<authorizationStrategy[\s>]/);
      var stratClassM = text.match(/<authorizationStrategy[^>]*class="([^"]+)"/);
      if (!stratLine && useSecFalseLine === null) {
        findings.push(makeFinding("HIGH", "authorization-strategy", null,
          "No authorizationStrategy element in config.xml",
          "The pasted config.xml contains no <authorizationStrategy> element, so who may do what is not defined by this file.",
          "Configure an authorization strategy that grants Overall/Administer only to named administrators."));
      }
      if (stratClassM && /Unsecured/i.test(stratClassM[1])) {
        findings.push(makeFinding("BLOCKER", "authorization-strategy", stratLine,
          "Authorization strategy is unsecured",
          "The authorizationStrategy at line " + stratLine + " is the unsecured strategy: every visitor can do everything, including administering the controller.",
          "Replace it with a restrictive strategy (logged-in users or matrix-based)."));
      }
      if (stratLine !== null) {
        var startIdx = stratLine - 1;
        var blockArr = [];
        for (var bi = startIdx; bi < lines.length; bi++) {
          blockArr.push({ line: bi + 1, text: lines[bi] });
          if (/<\/authorizationStrategy>/.test(lines[bi])) { break; }
        }
        var anonAdminLine = null, anonReadLine = null, allowAnonLine = null;
        for (var bj = 0; bj < blockArr.length; bj++) {
          var bt = blockArr[bj].text;
          if (/(Administer|Hudson\.Administer)\s*[:>]\s*anonymous/i.test(bt) || />[^<]*Administer:anonymous/.test(bt)) { anonAdminLine = blockArr[bj].line; }
          if (/(Read|Hudson\.Read)\s*[:>]\s*anonymous/i.test(bt) || />[^<]*Read:anonymous/.test(bt)) { anonReadLine = blockArr[bj].line; }
          if (/<allowAnonymousRead>\s*true\s*<\/allowAnonymousRead>/i.test(bt)) { allowAnonLine = blockArr[bj].line; }
        }
        if (anonAdminLine !== null) {
          findings.push(makeFinding("BLOCKER", "authorization-strategy", anonAdminLine,
            "Anonymous users are granted Administer permission",
            "Line " + anonAdminLine + " grants an Administer permission to anonymous. An unauthenticated visitor with Administer can run arbitrary code on the controller host.",
            "Remove every permission granted to anonymous; administer rights belong to named, authenticated administrators only."));
        } else if (anonReadLine !== null || allowAnonLine !== null) {
          findings.push(makeFinding("HIGH", "authorization-strategy", allowAnonLine !== null ? allowAnonLine : anonReadLine,
            "Anonymous users can read the controller",
            "The authorization strategy lets unauthenticated visitors read the controller (line " + (allowAnonLine !== null ? allowAnonLine : anonReadLine) + "), exposing job names, build history, and console output.",
            "Remove anonymous read permissions unless this controller is deliberately public."));
        }
      }

      /* CSRF crumb issuer */
      var crumbLine = findXmlLine(lines, /<crumbIssuer[\s>]/);
      if (crumbLine === null) {
        findings.push(makeFinding("MEDIUM", "csrf-crumb", null,
          "No crumbIssuer element in config.xml",
          "The pasted config.xml declares no CSRF crumb issuer. Current Jenkins enables a default issuer on its own, but the posture should be stated and reviewed rather than assumed.",
          "Enable the default crumb issuer in the controller's global security settings so it is recorded in config.xml."));
      }

      /* Markup formatter */
      var markupLine = findXmlLine(lines, /<markupFormatter[\s>]/);
      var markupClassM = text.match(/<markupFormatter[^>]*class="([^"]+)"/);
      if (!markupLine) {
        notChecked.push("Markup formatter — no markupFormatter element in the paste (current Jenkins defaults to escaping HTML in job descriptions)");
      } else if (markupClassM && /RawHtmlMarkupFormatter/i.test(markupClassM[1])) {
        findings.push(makeFinding("HIGH", "markup-formatter", markupLine,
          "Markup formatter renders raw HTML",
          "The markupFormatter at line " + markupLine + " is RawHtmlMarkupFormatter: user-supplied text such as job descriptions is rendered as HTML, so a user who can edit a job can inject script into administrators' browsers.",
          "Switch the markup formatter to the escaped/safe HTML formatter."));
      }

      /* numExecutors */
      var execM = text.match(/<numExecutors>\s*(\d+)\s*<\/numExecutors>/);
      if (!execM) {
        notChecked.push("Controller executor count — no numExecutors element in the paste");
      } else if (parseInt(execM[1], 10) > 0) {
        findings.push(makeFinding("MEDIUM", "controller-executors", findXmlLine(lines, /<numExecutors>/),
          "Builds run on the controller itself (numExecutors: " + execM[1] + ")",
          "config.xml gives the controller " + execM[1] + " build executor(s), so build scripts run on the controller host with the controller's access. Builds belong on agents.",
          "Set the controller's executor count to 0 and run builds on agents."));
      }

      /* Agent listener port */
      var portM2 = text.match(/<slaveAgentPort>\s*(-?\d+)\s*<\/slaveAgentPort>/);
      if (!portM2) {
        notChecked.push("Inbound agent listener (TCP port) posture — no slaveAgentPort element in the paste");
      } else if (parseInt(portM2[1], 10) > 0) {
        findings.push(makeFinding("INFO", "agent-listener", findXmlLine(lines, /<slaveAgentPort>/),
          "Inbound agent listener on fixed port " + portM2[1],
          "config.xml pins the inbound agent (JNLP) listener to TCP port " + portM2[1] + ". That is a normal setup — just make sure only actual agents can reach it through the firewall.",
          null));
      }
      notChecked.push("Enabled agent (JNLP) protocol list — config.xml records disabled protocols, not the enabled set, so the enabled protocols cannot be graded from this file");
      notChecked.push("Controller root URL — stored in a separate location-configuration file, not in config.xml");

      auditSecretsXml(lines, findings, stats);
    }

    /* ---------- Top-level audit ---------- */

    function auditConfig(raw) {
      var text = (raw || "").replace(/\r\n?/g, "\n");
      var lines = text.split("\n");
      var trimmed = text.trim();

      var strongMarkers = 0, weakMarkers = 0;
      if (/securityRealm/.test(text)) { strongMarkers++; }
      if (/authorizationStrategy/.test(text)) { strongMarkers++; }
      if (/^\s*jenkins\s*:/m.test(text)) { strongMarkers++; }
      if (/<hudson[\s>]/.test(text)) { strongMarkers++; }
      if (/<jenkins[\s>]/.test(text)) { strongMarkers++; }
      if (/numExecutors/.test(text)) { weakMarkers++; }
      if (/markupFormatter/.test(text)) { weakMarkers++; }
      if (/crumbIssuer/.test(text)) { weakMarkers++; }
      if (/slaveAgentPort/.test(text)) { weakMarkers++; }
      if (/^\s*unclassified\s*:/m.test(text)) { weakMarkers++; }
      if (/agentProtocols/.test(text)) { weakMarkers++; }

      if (trimmed === "" || (strongMarkers === 0 && weakMarkers < 2)) {
        return {
          status: "notenough",
          format: null,
          verdict: "NOT ENOUGH TO GRADE",
          findings: [],
          notChecked: [],
          stats: null,
          lineCount: lines.length
        };
      }

      var isXml = trimmed.charAt(0) === "<";
      var format = isXml ? "XML (config.xml)" : "JCasC YAML";
      var findings = [];
      var notChecked = [
        "Script console and CLI-over-HTTP posture — not determinable from a pasted configuration file",
        "Plugin inventory and plugin-level security settings — not present in the paste",
        "Controller network exposure (bind interface, reverse proxy, TLS termination) — lives outside this file",
        "Any global setting not written in the pasted text"
      ];
      var stats = { plaintextSecrets: 0, envSecrets: 0, encryptedSecrets: 0 };

      if (isXml) { auditXml(lines, text, findings, notChecked, stats); }
      else { auditYaml(lines, findings, notChecked, stats); }

      var order = { BLOCKER: 0, HIGH: 1, MEDIUM: 2, INFO: 3 };
      findings.sort(function (x, y) {
        if (order[x.severity] !== order[y.severity]) { return order[x.severity] - order[y.severity]; }
        var lx = x.line === null ? 99999 : x.line;
        var ly = y.line === null ? 99999 : y.line;
        return lx - ly;
      });

      var counts = { BLOCKER: 0, HIGH: 0, MEDIUM: 0, INFO: 0 };
      findings.forEach(function (f) { counts[f.severity]++; });

      var verdict;
      if (counts.BLOCKER > 0) { verdict = "DO NOT RUN"; }
      else if (counts.HIGH > 0 || counts.MEDIUM > 0) { verdict = "RUN WITH FIXES"; }
      else { verdict = "SAFE TO RUN"; }

      var fixes = [];
      findings.forEach(function (f) {
        if (f.fix && (f.severity === "BLOCKER" || f.severity === "HIGH" || f.severity === "MEDIUM")) {
          if (fixes.indexOf(f.fix) === -1) { fixes.push(f.fix); }
        }
      });

      return {
        status: "graded",
        format: format,
        verdict: verdict,
        findings: findings,
        fixes: fixes,
        notChecked: notChecked,
        counts: counts,
        stats: stats,
        lineCount: lines.length
      };
    }

    /* ---------- Report builders (secret values can never appear here:
       findings carry key name, line, and length only) ---------- */

    function buildTextReport(result) {
      var out = [];
      out.push("J-Dawgs Jenkins Controller Config Safety Auditor(TM) - Audit Report");
      out.push("================================================================");
      if (result.status === "notenough") {
        out.push("Verdict: NOT ENOUGH TO GRADE");
        out.push("");
        out.push("The pasted text was empty or did not contain a recognizable Jenkins");
        out.push("controller configuration (no securityRealm, authorizationStrategy,");
        out.push("jenkins: root, or config.xml structure was found). No verdict was");
        out.push("issued: paste a JCasC YAML file or the security-relevant part of");
        out.push("config.xml and run the audit again.");
        return out.join("\n");
      }
      out.push("Format detected: " + result.format);
      out.push("Lines audited: " + result.lineCount);
      out.push("Verdict: " + result.verdict);
      out.push("Findings: " + result.findings.length +
        " (BLOCKER " + result.counts.BLOCKER +
        ", HIGH " + result.counts.HIGH +
        ", MEDIUM " + result.counts.MEDIUM +
        ", INFO " + result.counts.INFO + ")");
      out.push("");
      out.push("FINDINGS");
      out.push("--------");
      if (result.findings.length === 0) {
        out.push("None. No problems were found in the pasted configuration.");
      } else {
        result.findings.forEach(function (f, i) {
          out.push((i + 1) + ". [" + f.severity + "] " + f.title +
            " (" + (f.line === null ? "not line-specific" : "line " + f.line) + ")");
          out.push("   " + f.detail);
          if (f.fix) { out.push("   Fix: " + f.fix); }
        });
      }
      out.push("");
      out.push("FIX LIST");
      out.push("--------");
      if (result.fixes.length === 0) {
        out.push("Nothing to fix in the pasted configuration.");
      } else {
        result.fixes.forEach(function (fx, i) { out.push((i + 1) + ". " + fx); });
      }
      out.push("");
      out.push("NOT CHECKED");
      out.push("-----------");
      result.notChecked.forEach(function (n) { out.push("- " + n); });
      out.push("");
      out.push("SECRETS HANDLING");
      out.push("----------------");
      out.push("Secret values are never printed by this tool - in the findings, in");
      out.push("this report, or in the JSON export. A secret finding names only the");
      out.push("key, its line, and the value length.");
      out.push("Plaintext secret values found: " + result.stats.plaintextSecrets);
      out.push("Secrets referenced via environment variables: " + result.stats.envSecrets);
      out.push("Secrets stored in encrypted form: " + result.stats.encryptedSecrets);
      out.push("");
      out.push("Scope: heuristic text audit of the pasted configuration only. This");
      out.push("tool does not run Jenkins and does not connect to any controller.");
      return out.join("\n");
    }

    function buildJson(result) {
      if (result.status === "notenough") {
        return {
          tool: "J-Dawgs Jenkins Controller Config Safety Auditor",
          status: "NOT ENOUGH TO GRADE",
          verdict: null,
          note: "The paste was empty or not a recognizable Jenkins controller configuration. No verdict was issued."
        };
      }
      return {
        tool: "J-Dawgs Jenkins Controller Config Safety Auditor",
        formatDetected: result.format,
        linesAudited: result.lineCount,
        verdict: result.verdict,
        counts: result.counts,
        findings: result.findings.map(function (f) {
          return { severity: f.severity, check: f.check, line: f.line, title: f.title, detail: f.detail, fix: f.fix };
        }),
        fixList: result.fixes,
        notChecked: result.notChecked,
        secretsHandling: {
          valuesPrinted: false,
          note: "Secret findings carry key name, line, and value length only - never the value.",
          plaintextSecretsFound: result.stats.plaintextSecrets,
          environmentReferencedSecrets: result.stats.envSecrets,
          encryptedSecrets: result.stats.encryptedSecrets
        },
        scope: "Heuristic text audit of the pasted configuration only. Does not run Jenkins; does not connect to a controller."
      };
    }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-jenkins-controller-config-safety-auditortm',
  name: 'J-Dawgs Jenkins Controller Config Safety Auditor',
  description: 'Jenkins config is only exercised by starting the controller and stops at will-it-load; ours grades the pasted JCasC YAML or config.xml offline before you run it — security realm, anonymous permissions, CSRF crumb issuer, agent protocols, raw-HTML formatter, root-URL scheme, controller executors, and',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
