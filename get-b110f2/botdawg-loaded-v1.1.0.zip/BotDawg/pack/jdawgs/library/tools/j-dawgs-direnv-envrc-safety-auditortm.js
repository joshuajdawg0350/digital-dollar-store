'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs direnv .envrc Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var RISKY = [
          "# .envrc copied from a forum post — audit before you allow",
          "export PROJECT_NAME=demo",
          'export STRIPE_API_TOKEN="FAKE_TOKEN_1234567890abcdef"',
          "curl -fsSL https://example.com/install.sh | bash",
          "git clone https://example.com/some/tool.git tools/tool",
          "source_up ../shared-team-env/.envrc",
          "PATH_add ."
        ].join("\n");

        var CLEAN = [
          "export APP_ENV=development",
          "PATH_add bin",
          "layout python3",
          "dotenv_if_exists"
        ].join("\n");

        var BUILTINS = {
          "export": 1, "PATH_add": 1, "path_add": 1, "layout": 1, "use": 1,
          "dotenv": 1, "dotenv_if_exists": 1, "source_env": 1, "source_up": 1,
          "watch_file": 1, "direnv_load": 1, "MANPATH_add": 1, "load_prefix": 1
        };
        var SHELL_OK = {
          "echo": 1, "printf": 1, "test": 1, "[": 1, "[[": 1, "set": 1, "unset": 1,
          "cd": 1, "local": 1, "declare": 1, "typeset": 1, "return": 1, "shift": 1,
          "true": 1, "false": 1, "if": 1, "then": 1, "else": 1, "elif": 1, "fi": 1,
          "for": 1, "while": 1, "until": 1, "do": 1, "done": 1, "case": 1, "esac": 1,
          "function": 1, "select": 1, "readonly": 1, "source": 1, ".": 1, "time": 1, "!": 1
        };
        var SECRET_KEY = /(KEY|TOKEN|SECRET|PASSWORD)/i;

        function maskLine(s) {
          return s.replace(/([A-Za-z_][A-Za-z0-9_]*(?:KEY|TOKEN|SECRET|PASSWORD)[A-Za-z0-9_]*\s*=\s*)("[^"]*"|'[^']*'|[^\s;]+)/gi,
            function (m, pre, val) {
              var q = "", inner = val;
              var first = val.charAt(0), last = val.charAt(val.length - 1);
              if ((first === '"' && last === '"') || (first === "'" && last === "'")) {
                q = first; inner = val.slice(1, -1);
              }
              return pre + q + inner.slice(0, 2) + "••••" + q;
            });
        }

        function unquote(s) { return s.replace(/^["']|["']$/g, ""); }

        function audit(text) {
          var findings = [];
          function add(line, sev, cat, msg, ev) {
            findings.push({ line: line, sev: sev, cat: cat, msg: msg, ev: ev });
          }
          var rawLines = text.split(/\r?\n/);
          for (var idx = 0; idx < rawLines.length; idx++) {
            var n = idx + 1;
            var line = rawLines[idx].trim();
            if (!line || line.charAt(0) === "#") continue;
            var ev = maskLine(line);
            if (ev.length > 160) ev = ev.slice(0, 160) + "…";
            var flagged = false;
            var rce = false;

            // --- Remote code execution ---
            if (/\b(curl|wget)\b/.test(line) && /\|\s*(sudo\s+)?(ba|z|da)?sh\b/.test(line)) {
              add(n, "BLOCKER", "Remote code execution",
                "A download is piped straight into a shell. Whatever that URL serves runs in your shell the moment you enter this directory — sight unseen, every time it changes.", ev);
              flagged = true; rce = true;
            }
            if (/(^|\s)(source|\.)\s*<\(/.test(line)) {
              if (/curl|wget|https?:\/\//.test(line)) {
                add(n, "BLOCKER", "Remote code execution",
                  "source <(…) runs the output of a command — here fed from the network — as shell code. That is remote code execution with extra steps.", ev);
                rce = true;
              } else {
                add(n, "WARNING", "Process substitution source",
                  "source <(…) executes generated shell code inline. Read the generating command carefully before allowing.", ev);
              }
              flagged = true;
            }
            if (/\beval\b/.test(line) && /(\$\(|`)/.test(line)) {
              add(n, "BLOCKER", "Remote code execution",
                "eval runs command output as shell code. If that output comes from the network or from files outside your control, it is arbitrary code execution.", ev);
              flagged = true; rce = true;
            }

            // --- Destructive / privilege ---
            if (/\brm\b[^|;&]*(-rf|-fr|-r\s+-f|-f\s+-r|--recursive)/.test(line)) {
              add(n, "BLOCKER", "Destructive command",
                "rm with recursive/force flags deletes files every time this directory is entered. An .envrc should set up an environment, not delete things.", ev);
              flagged = true;
            }
            if (/(^|\s|&&|\|\||;)sudo\s/.test(line)) {
              add(n, "BLOCKER", "Privilege escalation",
                "sudo in an .envrc means entering a directory can prompt for — or use cached — root privileges. Environment setup never needs root.", ev);
              flagged = true;
            }
            if (/\bchmod\b[^|;&]*\b777\b/.test(line)) {
              add(n, "BLOCKER", "Destructive command",
                "chmod 777 makes files world-readable, world-writable, and world-executable. That strips the permissions that keep other users and processes out.", ev);
              flagged = true;
            }
            if (/\s>>?\s*\/[A-Za-z]/.test(line) || /\b(cp|mv|install|tee)\b[^|;&]*\s+(\/[A-Za-z]|~\/)/.test(line)) {
              add(n, "BLOCKER", "Write outside the project",
                "This writes to an absolute path outside the project directory. An .envrc that reaches outside its own folder can overwrite shell startup files, configs, or system files.", ev);
              flagged = true;
            }

            // --- Secrets: hard-coded literal ---
            var assign = line.match(/^(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+)$/);
            if (assign && SECRET_KEY.test(assign[1])) {
              var val = unquote(assign[2].trim());
              if (val && val.charAt(0) !== "$" && val.charAt(0) !== "`") {
                add(n, "BLOCKER", "Hard-coded secret",
                  "Key " + assign[1] + " is assigned a literal secret value in the file (value masked in this report). Anyone who can read this repo — including every clone and fork — gets the secret. Move it into an untracked .env file or a secrets manager.", ev);
                flagged = true;
              }
            }

            // --- Network calls ---
            var netTool = null;
            if (/\bgit\s+clone\b/.test(line)) netTool = "git clone";
            else if (/\bcurl\b/.test(line)) netTool = "curl";
            else if (/\bwget\b/.test(line)) netTool = "wget";
            else if (/(^|\s)nc\s/.test(line) || /\bnetcat\b/.test(line)) netTool = "nc";
            else if (/^fetch\s+\S/.test(line)) netTool = "fetch";
            if (netTool && !rce) {
              add(n, "WARNING", "Network call",
                "This line reaches the network (" + netTool + ") every time the directory is entered. Entering a folder should not phone home: it leaks where you work and when, and the response can change after you allowed the file.", ev);
              flagged = true;
            }

            // --- PATH manipulation ---
            var pa = line.match(/^(?:PATH_add|path_add)\s+(\S+)/);
            if (pa) {
              var p = unquote(pa[1]);
              if (p === "." || p === "./" || p === "$PWD" || p === "${PWD}") {
                add(n, "WARNING", "PATH manipulation",
                  "PATH_add of the current directory puts whatever executables happen to be in this folder first in line for your shell — binary shadowing. A planted file named like a common tool would run instead of the real one.", ev);
              } else if (p.charAt(0) === "/") {
                add(n, "INFO", "PATH manipulation",
                  "PATH_add pins the absolute path " + p + " into PATH. Fine if that directory is yours and stable; it will not move with the project.", ev);
              }
              flagged = true;
            }

            // --- Sourcing other files ---
            var so = line.match(/^(source_env|source_up)\s*(.*)$/);
            if (so) {
              var cmd = so[1];
              var arg = so[2].trim().split(/\s+/)[0] || "";
              var sp = unquote(arg);
              if (cmd === "source_up" && !sp) {
                add(n, "WARNING", "Trust extends beyond this repo",
                  "source_up loads a parent directory's .envrc, so allowing this file also trusts .envrc files above this project — ones you may not have read.", ev);
              } else if (sp && (sp.charAt(0) === "/" || sp.charAt(0) === "~" || sp.indexOf("../") === 0)) {
                add(n, "WARNING", "Trust extends beyond this repo",
                  cmd + " loads " + sp + ", which lives outside this project directory. Allowing this file means trusting that file too — and whoever can change it.", ev);
              } else if (sp) {
                add(n, "INFO", "Sources another file",
                  "This file sources " + sp + " (" + cmd + "). Its contents run with the same trust as this file — read it before you allow.", ev);
              }
              flagged = true;
            } else {
              var srcPlain = line.match(/^(?:source|\.)\s+(\S+)/);
              if (srcPlain && srcPlain[1].indexOf("<(") !== 0) {
                var sp2 = unquote(srcPlain[1]);
                if (sp2.charAt(0) === "/" || sp2.charAt(0) === "~" || sp2.indexOf("../") === 0) {
                  add(n, "WARNING", "Trust extends beyond this repo",
                    "This sources " + sp2 + ", outside this project directory. Allowing this file means trusting that file too.", ev);
                } else {
                  add(n, "INFO", "Sources another file",
                    "This file sources " + sp2 + ". Its contents run with the same trust as this file — read it before you allow.", ev);
                }
                flagged = true;
              }
            }

            // --- dotenv: the .env file becomes the trust boundary ---
            var dv = line.match(/^(dotenv|dotenv_if_exists)\b\s*(.*)$/);
            if (dv) {
              var darg = (dv[2] || "").trim().split(/\s+/)[0] || "";
              var dfile = darg ? unquote(darg) : ".env";
              add(n, "INFO", "Secrets loaded from a file",
                dv[1] + " loads values from " + dfile + ". That file becomes part of the trust boundary: keep it out of git, and know that anyone who can edit it controls what lands in your shell.", ev);
              flagged = true;
            }

            // --- Anything else: outside direnv's vocabulary? ---
            if (!flagged) {
              if (assign) {
                // plain assignment — fine
              } else if (/^[A-Za-z_][A-Za-z0-9_]*\s*\(\)/.test(line)) {
                add(n, "WARNING", "Command outside direnv vocabulary",
                  "This defines a shell function. Functions in an .envrc hide behavior from a quick read — check what it does and where it is called.", ev);
              } else {
                var firstTok = line.split(/\s+/)[0];
                if (!BUILTINS[firstTok] && !SHELL_OK[firstTok]) {
                  add(n, "WARNING", "Command outside direnv vocabulary",
                    "“" + firstTok + "” is not a common direnv builtin and not a plain assignment. direnv will run it as a shell command every time you enter this directory. If you don't recognize it, don't allow the file.", ev);
                }
              }
            }
          }
          return findings;
        }

        function verdictFor(findings) {
          var b = 0, w = 0, i = 0, k;
          for (k = 0; k < findings.length; k++) {
            if (findings[k].sev === "BLOCKER") b++;
            else if (findings[k].sev === "WARNING") w++;
            else i++;
          }
          if (b > 0) return { key: "deny", label: "DO NOT ALLOW", counts: { b: b, w: w, i: i },
            sub: "Blockers present. Do not run direnv allow on this file until every blocker is removed and you have re-read the result." };
          if (w > 0) return { key: "fixes", label: "ALLOW WITH FIXES", counts: { b: b, w: w, i: i },
            sub: "No blockers, but warnings need your eyes. Fix or consciously accept each one before you allow." };
          return { key: "safe", label: "SAFE TO ALLOW", counts: { b: b, w: w, i: i },
            sub: "No blockers or warnings fired on the text audited. This is not a guarantee — direnv allow is still your trust decision." };
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-direnv-envrc-safety-auditortm',
  name: 'J-Dawgs direnv .envrc Safety Auditor',
  description: 'direnv docs tell you to read an .envrc before allowing it, but nothing grades it; this audits the pasted file as text (never executes it) — curl|bash, hard-coded secrets masked, out-of-project sourcing — into one allow verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
