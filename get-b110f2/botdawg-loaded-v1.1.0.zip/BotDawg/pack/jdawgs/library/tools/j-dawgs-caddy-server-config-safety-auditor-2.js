'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Caddy Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var RISKY_EXAMPLE = [
        "{",
        "\tauto_https off",
        "\tadmin 0.0.0.0:2019",
        "}",
        "",
        "http://files.example.com {",
        "\troot * /srv/files",
        "\tfile_server browse",
        "\ttls internal",
        "}",
        "",
        "api.example.com {",
        "\treverse_proxy http://203.0.113.10:8080",
        "\theader X-Api-Key FAKE-TEST-KEY-7f3a9c1e-DO-NOT-SHIP",
        "}"
      ].join("\n");

      var HARDENED_EXAMPLE = [
        "{",
        "\tadmin off",
        "\temail ops@example.com",
        "\tauto_https on",
        "}",
        "",
        "example.com {",
        "\troot * /srv/www",
        "\tencode gzip",
        "\tfile_server",
        "\treverse_proxy https://localhost:9000",
        "}"
      ].join("\n");

      var KNOWN = {};
      ("auto_https admin email debug default_bind default_sni order storage http_port https_port " +
       "grace_period shutdown_delay servers acme_ca acme_ca_root acme_eab acme_dns key_type renew_interval " +
       "cert_issuer preferred_chains local_certs skip_install_trust pki on_demand " +
       "abort acme_server basicauth basic_auth bind encode error file_server forward_auth handle handle_errors " +
       "handle_path header headers import invoke log map metrics php_fastcgi redir request_header respond " +
       "reverse_proxy rewrite root route templates tls tracing try_files uri vars intercept replace_path method " +
       "browse hide index precompressed status protocols ciphers curves alpn client_auth issuers mode require " +
       "optional transport header_up header_down lb_policy lb_retries fail_duration max_fails max_conns " +
       "dial_timeout read_timeout write_timeout flush_interval compression trusted_proxies except within " +
       "using dns source destination expression path_regexp host query remote_ip client_ip header_regexp " +
       "not group sticky_cookie health_uri health_interval health_timeout health_status health_body " +
       "tls_insecure_skip_verify tls_client_auth tls_server_name resolve upstream dynamic ask check_interval " +
       "disable_redirects ignore_loaded_certs internal h2c unix localhost").split(/\s+/).forEach(function (w) {
        if (w) KNOWN[w] = true;
      });

      var SECRET_RE = /(api[-_]?key|apikey|access[-_]?token|auth[-_]?token|token|password|passwd|secret|credential|private[-_]?key|client[-_]?secret)/i;

      function esc(s) {
        return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
          .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
      }
      function stripComment(line) {
        var i = line.indexOf("#");
        return i >= 0 ? line.slice(0, i) : line;
      }
      function countChar(s, ch) {
        var n = 0;
        for (var i = 0; i < s.length; i++) if (s.charAt(i) === ch) n++;
        return n;
      }
      function isLocalHost(host) {
        if (!host) return false;
        host = host.toLowerCase();
        if (host === "localhost" || host === "127.0.0.1" || host === "::1") return true;
        if (host.indexOf("127.") === 0) return true;
        if (host.indexOf("10.") === 0 || host.indexOf("192.168.") === 0) return true;
        if (/^172\.(1[6-9]|2[0-9]|3[01])\./.test(host)) return true;
        if (/\.local$/.test(host) || /\.internal$/.test(host) || /\.lan$/.test(host) || /\.localhost$/.test(host)) return true;
        return false;
      }
      function parseAddress(raw) {
        var scheme = "";
        var rest = raw;
        var m = raw.match(/^([a-zA-Z][a-zA-Z0-9+.-]*):\/\/(.*)$/);
        if (m) { scheme = m[1].toLowerCase(); rest = m[2]; }
        rest = rest.split("/")[0];
        var host = rest, port = "";
        if (rest.charAt(0) === "[") {
          var close = rest.indexOf("]");
          host = rest.slice(1, close);
          if (rest.charAt(close + 1) === ":") port = rest.slice(close + 2);
        } else {
          var ci = rest.lastIndexOf(":");
          if (ci >= 0 && /^\d+$/.test(rest.slice(ci + 1))) { host = rest.slice(0, ci); port = rest.slice(ci + 1); }
          else if (ci === 0) { host = ""; port = rest.slice(1); }
        }
        if (host.charAt(0) === "*") host = host.slice(1);
        if (host.charAt(0) === ".") host = host.slice(1);
        return { raw: raw, scheme: scheme, host: host.toLowerCase(), port: port };
      }
      function looksLikeAddress(tok) {
        if (!tok || /[{}]/.test(tok)) return false;
        if (tok.indexOf("://") >= 0) return true;
        if (tok.charAt(0) === ":") return true;
        if (tok === "localhost") return true;
        if (tok.indexOf(".") >= 0) return true;
        if (tok.indexOf(":") >= 0) return true;
        return false;
      }

      function audit(text) {
        var findings = [];
        var notAuditedMap = {};   // name -> [lines]
        var notAuditedOrder = [];
        var lines = text.split(/\r?\n/);
        var stack = [];           // {type:'global'|'site'|'block'|'snippet', name, line, sites:[], hasHttpsRedir}
        var sites = [];           // {raw, host, scheme, port, local, line, ctx}
        var globalInfo = { seen: false, line: 0, email: false };
        var depth = 0;
        var braceError = null;    // {line, msg}
        var implicitSite = null;  // ctx-like object for brace-less single site

        function add(sev, line, title, detail, fix) {
          findings.push({ sev: sev, line: line, title: title, detail: detail, fix: fix || "" });
        }
        function noteUnknown(name, line) {
          if (!name || KNOWN[name]) return;
          if (!notAuditedMap[name]) { notAuditedMap[name] = []; notAuditedOrder.push(name); }
          if (notAuditedMap[name].indexOf(line) < 0) notAuditedMap[name].push(line);
        }
        function topCtx() { return stack.length ? stack[stack.length - 1] : null; }
        function currentSiteCtx() {
          for (var i = stack.length - 1; i >= 0; i--) if (stack[i].type === "site") return stack[i];
          return implicitSite;
        }
        function currentBlockName() {
          var t = topCtx();
          return t && t.type === "block" ? t.name : "";
        }

        function secretCheck(trimmed, lineNo) {
          var toks = trimmed.split(/\s+/);
          for (var i = 0; i < toks.length; i++) {
            var t = toks[i].replace(/^["'({]+/, "").replace(/["')},;]+$/, "");
            if (!t) continue;
            var eq = t.indexOf("=");
            var keyPart = eq > 0 ? t.slice(0, eq) : t;
            if (!SECRET_RE.test(keyPart)) continue;
            var valTok = eq > 0 ? t.slice(eq + 1) : (i + 1 < toks.length ? toks[i + 1] : "");
            if (!valTok) continue;
            if (/^\{?(env|file|\$)/i.test(valTok)) continue; // placeholder reference, not a literal secret
            var shaped = /[-_]/.test(keyPart) || keyPart === keyPart.toUpperCase() ||
              /[a-z][A-Z]/.test(keyPart) ||
              /^(password|passwd|secret|token|apikey|credential|credentials)$/i.test(keyPart);
            if (!shaped) continue;
            add("WARNING", lineNo,
              "Possible secret written in plain text",
              "The key name \u201C" + keyPart + "\u201D on this line suggests a credential is stored directly in the Caddyfile. The value is never shown in these findings or in the report.",
              "Move the value into an environment variable or a secrets store and reference it (for example with a {env.…} placeholder) instead of pasting it into the config.");
            return;
          }
        }

        function checkDirective(trimmed, lineNo, ctxKind) {
          var toks = trimmed.split(/\s+/);
          var name = toks[0];
          if (!name || name.charAt(0) === "@" || name === "}") return;
          var siteCtx = currentSiteCtx();

          if (name === "auto_https") {
            var mode = (toks[1] || "").toLowerCase();
            if (mode === "off") {
              add("BLOCKER", lineNo, "Automatic HTTPS is off (auto_https off)",
                "With auto_https off, sites lose automatic HTTPS: no automatic certificates and no automatic HTTP-to-HTTPS redirects unless you wire them up by hand.",
                "Remove auto_https off (or set auto_https on) so Caddy obtains certificates and redirects HTTP to HTTPS automatically.");
            } else if (mode === "disable_redirects") {
              add("WARNING", lineNo, "HTTPS redirects disabled (auto_https disable_redirects)",
                "Certificates are still managed, but visitors who arrive over plain HTTP are not redirected to HTTPS, so the insecure version of the site stays reachable.",
                "Drop disable_redirects unless you handle the HTTP-to-HTTPS redirect somewhere else.");
            } else if (mode === "on") {
              add("GOOD", lineNo, "Automatic HTTPS is on (auto_https on)",
                "Caddy will obtain and renew certificates and redirect HTTP to HTTPS automatically.");
            }
          }

          if (name === "admin") {
            var target = (toks[1] || "").toLowerCase();
            if (target === "off") {
              add("GOOD", lineNo, "Admin endpoint is off (admin off)",
                "The admin API is disabled, so nothing can reconfigure this server over the network.");
            } else if (target) {
              var a = parseAddress(target);
              if (isLocalHost(a.host)) {
                add("INFO", lineNo, "Admin endpoint bound to localhost",
                  "The admin endpoint listens on " + target + ", which is only reachable from this machine.");
              } else {
                add("BLOCKER", lineNo, "Admin endpoint exposed on a non-localhost address",
                  "The admin endpoint listens on " + target + ". Anyone who can reach it can read and replace the server's entire configuration.",
                  "Set admin off, or bind the admin endpoint to localhost (for example admin localhost:2019) and reach it through a tunnel.");
              }
            }
          }

          if (name === "email") {
            var tc = topCtx();
            if (tc && tc.type === "global") globalInfo.email = true;
          }

          if (name === "file_server") {
            if (toks.indexOf("browse") >= 0) {
              add("WARNING", lineNo, "Directory browsing is enabled (file_server browse)",
                "Anyone can list the contents of served directories, which exposes file names, backups, and anything else left in the tree.",
                "Remove browse from file_server, or serve only the exact paths you mean to publish.");
            }
          }
          if (name === "browse" && currentBlockName() === "file_server") {
            add("WARNING", lineNo, "Directory browsing is enabled (browse inside file_server)",
              "Anyone can list the contents of served directories, which exposes file names, backups, and anything else left in the tree.",
              "Remove the browse option from the file_server block, or serve only the exact paths you mean to publish.");
          }

          if (name === "reverse_proxy") {
            for (var i = 1; i < toks.length; i++) {
              var up = toks[i];
              if (up === "{") break;
              if (!looksLikeAddress(up) && up.indexOf("unix/") !== 0) continue;
              var ua = parseAddress(up.replace(/^unix\//, ""));
              if (up.indexOf("unix/") === 0) continue;
              if (ua.scheme === "http") {
                if (isLocalHost(ua.host)) {
                  add("INFO", lineNo, "Proxy upstream is on this machine",
                    "reverse_proxy sends traffic to " + up + " over plain HTTP, but the upstream is local, so the plaintext hop stays on this machine.");
                } else {
                  add("WARNING", lineNo, "Proxy upstream is plaintext HTTP",
                    "reverse_proxy sends traffic to " + up + " over plain HTTP, so requests and responses cross the network unencrypted.",
                    "Serve the upstream over HTTPS, or keep the upstream on the same machine or a private network you control.");
                }
              } else if (!ua.scheme && isLocalHost(ua.host)) {
                add("INFO", lineNo, "Proxy upstream is on this machine",
                  "reverse_proxy sends traffic to the local upstream " + up + ".");
              }
            }
          }

          if (name === "tls") {
            var second = (toks[1] || "").toLowerCase();
            if (second === "internal") {
              add("WARNING", lineNo, "Site uses Caddy's internal CA (tls internal)",
                "Certificates come from Caddy's internal CA, which public browsers do not trust — visitors will see certificate warnings.",
                "Use a publicly trusted certificate (automatic HTTPS) for public sites; keep tls internal for private, internal-only services.");
            }
          }
          if (trimmed.indexOf("on_demand") >= 0 &&
              (name === "tls" || currentBlockName() === "tls" || (ctxKind === "global" && name === "on_demand"))) {
            add("WARNING", lineNo, "On-demand TLS is enabled",
              "On-demand TLS issues a certificate the first time any hostname is requested, which is an abuse and denial-of-service surface: strangers can make the server request certificates for names you do not own.",
              "Keep on-demand TLS only behind an ask endpoint that approves each hostname, and rate-limit it.");
          }
          if (/(^|\s)protocols(\s|$)/.test(trimmed) && /tls1\.[01](?![0-9])/.test(trimmed)) {
            add("BLOCKER", lineNo, "Very old TLS version allowed (TLS 1.0 / 1.1)",
              "A protocols setting on this line names TLS 1.0 or TLS 1.1. Both are deprecated and considered unsafe; modern browsers reject them.",
              "Allow TLS 1.2 or newer only (for example: protocols tls1.2 tls1.3).");
          }

          if (name === "redir" && siteCtx && trimmed.indexOf("https://") >= 0) {
            siteCtx.hasHttpsRedir = true;
          }

          noteUnknown(name, lineNo);
        }

        for (var idx = 0; idx < lines.length; idx++) {
          var lineNo = idx + 1;
          var code = stripComment(lines[idx]);
          var trimmed = code.trim();
          var opens = countChar(code, "{"), closes = countChar(code, "}");
          var net = opens - closes;
          depth += net;
          if (depth < 0 && !braceError) {
            braceError = { line: lineNo, msg: "a closing brace on this line has no matching opening brace" };
          }

          if (trimmed) secretCheck(trimmed, lineNo);
          if (!trimmed) {
            if (net < 0) for (var p0 = 0; p0 < -net; p0++) stack.pop();
            continue;
          }

          var isOpener = net > 0 && trimmed.charAt(trimmed.length - 1) === "{" || trimmed === "{";

          if (trimmed.charAt(0) === "}" && net < 0) {
            for (var p1 = 0; p1 < -net; p1++) stack.pop();
            continue;
          }

          if (isOpener) {
            if (stack.length === 0 && trimmed.charAt(0) === "{") {
              if (!globalInfo.seen) {
                globalInfo.seen = true;
                globalInfo.line = lineNo;
                stack.push({ type: "global", name: "", line: lineNo, sites: [], hasHttpsRedir: false });
              } else {
                stack.push({ type: "block", name: "", line: lineNo, sites: [], hasHttpsRedir: false });
              }
              implicitSite = null;
            } else if (stack.length === 0 && trimmed.charAt(0) === "(") {
              stack.push({ type: "snippet", name: trimmed.split(/\s+/)[0], line: lineNo, sites: [], hasHttpsRedir: false });
              implicitSite = null;
            } else if (stack.length === 0) {
              var addrPart = trimmed.slice(0, trimmed.indexOf("{")).trim();
              var parts = addrPart.split(/[,\s]+/).filter(Boolean);
              var allAddr = parts.length > 0 && parts.every(looksLikeAddress);
              if (allAddr) {
                var ctx = { type: "site", name: "", line: lineNo, sites: [], hasHttpsRedir: false };
                parts.forEach(function (pa) {
                  var rec = parseAddress(pa);
                  rec.line = lineNo; rec.ctx = ctx;
                  rec.local = isLocalHost(rec.host);
                  ctx.sites.push(rec); sites.push(rec);
                });
                stack.push(ctx);
                implicitSite = null;
              } else {
                checkDirective(trimmed, lineNo, "top");
                stack.push({ type: "block", name: trimmed.split(/\s+/)[0], line: lineNo, sites: [], hasHttpsRedir: false });
              }
            } else {
              var ctxKindIn = topCtx() && topCtx().type === "global" ? "global" : "site";
              checkDirective(trimmed, lineNo, ctxKindIn);
              stack.push({ type: "block", name: trimmed.split(/\s+/)[0], line: lineNo, sites: [], hasHttpsRedir: false });
            }
            continue;
          }

          if (net < 0) {
            for (var p2 = 0; p2 < -net; p2++) stack.pop();
            continue;
          }

          // Plain directive line.
          var tc = topCtx();
          if (!tc) {
            var toksTop = trimmed.split(/[,\s]+/).filter(Boolean);
            var firstTok = trimmed.split(/\s+/)[0];
            if (!implicitSite && toksTop.length > 0 && toksTop.every(looksLikeAddress) && !KNOWN[firstTok]) {
              var ictx = { type: "site", name: "", line: lineNo, sites: [], hasHttpsRedir: false };
              toksTop.forEach(function (pa) {
                var rec2 = parseAddress(pa);
                rec2.line = lineNo; rec2.ctx = ictx;
                rec2.local = isLocalHost(rec2.host);
                ictx.sites.push(rec2); sites.push(rec2);
              });
              implicitSite = ictx;
              continue;
            }
            checkDirective(trimmed, lineNo, implicitSite ? "site" : "top");
          } else if (tc.type === "global") {
            checkDirective(trimmed, lineNo, "global");
          } else {
            checkDirective(trimmed, lineNo, "site");
          }
        }

        if (depth > 0 && !braceError) {
          var unclosed = stack.length ? stack[stack.length - 1] : null;
          braceError = {
            line: unclosed ? unclosed.line : lines.length,
            msg: "a block opened on this line is never closed"
          };
        }
        if (braceError) {
          add("BLOCKER", braceError.line, "Unbalanced braces — NOT PARSED",
            "The braces in this file do not balance: " + braceError.msg + ". The file's structure could not be fully parsed, so the rest of this audit may be incomplete.",
            "Match every opening brace with a closing brace and run the audit again.");
        }

        // Email (ACME) note.
        if (!globalInfo.email) {
          add("INFO", globalInfo.seen ? globalInfo.line : 1, "No ACME account email set",
            "No email directive was found in the global options. The email is where the certificate authority sends expiry and account notices, and it speeds up recovery if a key is lost.",
            "Add an email line to the global options block, for example: email ops@example.com");
        }

        // Site exposure grading + duplicates (needs the whole file).
        var httpsHosts = {};
        sites.forEach(function (s) {
          if (!s.local && (s.scheme === "https" || (s.scheme === "" && s.port !== "80"))) {
            if (s.host) httpsHosts[s.host] = true;
          }
        });
        var seenAddr = {};
        sites.forEach(function (s) {
          var key = (s.host || "") + "|" + (s.port || "");
          if (seenAddr[key] !== undefined && s.host) {
            add("WARNING", s.line, "Duplicate site address: " + s.raw,
              "This site address is defined twice — first on line " + seenAddr[key] + " and again on line " + s.line + ". Caddy merges or rejects conflicting definitions, so behavior is unpredictable.",
              "Keep one definition for " + s.raw + " and merge the two blocks.");
          } else {
            seenAddr[key] = s.line;
          }
          var isHttp = s.scheme === "http" || (s.scheme === "" && s.port === "80" && s.host !== "");
          var isPort80Only = s.scheme === "" && s.port === "80" && s.host === "";
          if (s.local) {
            add("INFO", s.line, "Local / internal site: " + s.raw,
              "This address is localhost or an internal name, so it is noted separately and not graded as public exposure.");
          } else if (isHttp || isPort80Only) {
            var label = s.raw;
            if (s.ctx && s.ctx.hasHttpsRedir || (s.host && httpsHosts[s.host])) {
              add("WARNING", s.line, "Site served over plain HTTP: " + label,
                "This site answers over unencrypted HTTP. A redirect to HTTPS appears to be handled elsewhere in the file, but anything served before the redirect is still plaintext.",
                "Prefer letting automatic HTTPS handle the redirect, and make sure no content is served over HTTP itself.");
            } else {
              add("BLOCKER", s.line, "Site served over plain HTTP with no HTTPS redirect: " + label,
                "This site is served over unencrypted HTTP, and nothing in the file redirects it to HTTPS or serves the same name over HTTPS. Logins, cookies, and content cross the network in the clear.",
                "Serve the site over HTTPS (a bare hostname with automatic HTTPS on) or add an explicit redirect from the HTTP address to its HTTPS version.");
            }
          } else if (s.scheme === "https" || (s.scheme === "" && s.host)) {
            add("GOOD", s.line, "Site served over HTTPS: " + s.raw,
              "This address is served over HTTPS (automatic HTTPS applies to bare hostnames).");
          }
        });

        var sevRank = { BLOCKER: 0, WARNING: 1, GOOD: 2, INFO: 3 };
        findings.sort(function (a, b) {
          if (sevRank[a.sev] !== sevRank[b.sev]) return sevRank[a.sev] - sevRank[b.sev];
          return a.line - b.line;
        });

        var counts = { BLOCKER: 0, WARNING: 0, GOOD: 0, INFO: 0 };
        findings.forEach(function (f) { counts[f.sev]++; });
        var verdict = counts.BLOCKER > 0 ? "DO NOT DEPLOY" : (counts.WARNING > 0 ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY");
        var notAudited = notAuditedOrder.map(function (n) { return { name: n, lines: notAuditedMap[n] }; });
        return { verdict: verdict, counts: counts, findings: findings, notAudited: notAudited };
      }

      function buildReport(r) {
        var out = [];
        out.push("J-Dawgs Caddy Server Config Safety Auditor\u2122 — audit report");
        out.push("Verdict: " + r.verdict);
        out.push("Counts: " + r.counts.BLOCKER + " blocker(s), " + r.counts.WARNING + " warning(s), " +
                 r.counts.GOOD + " good, " + r.counts.INFO + " info, " + r.notAudited.length + " not audited");
        out.push("");
        out.push("Findings (line-numbered):");
        if (!r.findings.length) out.push("  None.");
        r.findings.forEach(function (f) {
          out.push("[" + f.sev + "] Line " + f.line + " — " + f.title);
          out.push("    " + f.detail);
          if (f.fix) out.push("    Fix: " + f.fix);
        });
        out.push("");
        if (r.notAudited.length) {
          out.push("Not audited (directives this tool does not grade):");
          r.notAudited.forEach(function (n) {
            out.push("  " + n.name + " (line " + n.lines.join(", ") + ")");
          });
        } else {
          out.push("Not audited: none — every directive in the file is one this tool grades or recognizes.");
        }
        out.push("");
        out.push("Secret values are never included in this report; possible secrets are flagged by key name and line only.");
        out.push("Graded locally in the browser from the pasted text alone. Nothing was uploaded, saved, or sent to a server.");
        return out.join("\n");
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-caddy-server-config-safety-auditor-2',
  name: 'J-Dawgs Caddy Server Config Safety Auditor',
  description: '',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
