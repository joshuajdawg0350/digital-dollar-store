'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Service Decommission & Dependency Shutdown Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var MIXED_EXAMPLE = [
          "SERVICE: Legacy Billing API",
          "SHUTDOWN: 2026-12-15",
          "DECISION DATE: 2026-12-05",
          "",
          "DEPEND: payments-checkout | OWNER: Ana Ruiz | STATUS: migrated | EVIDENCE: Cutover ticket PAY-221 closed 2026-11-20; all traffic on the new billing API since 2026-11-21",
          "DEPEND: invoicing-worker | OWNER: Ben Okafor | STATUS: migrated | EVIDENCE:",
          "DEPEND: report-exporter | OWNER: Priya Shah | STATUS: not-started | EVIDENCE:",
          "DEPEND: legacy-sync-job | OWNER: | STATUS: in-progress | EVIDENCE: Draft runbook started, no cutover date set",
          "DEPEND: mobile-app-backend | OWNER: Dana Kim | STATUS: migrated | EVIDENCE: Release 4.2.0 shipped 2026-11-28 pointing at the new gateway",
          "",
          "NOTICE: Ana Ruiz | DATE: 2026-11-25",
          "NOTICE: Ben Okafor | DATE: 2026-11-25",
          "NOTICE: Priya Shah | DATE: 2026-11-26"
        ].join("\n");

        var CLEAN_EXAMPLE = [
          "SERVICE: Old Image Resizer",
          "SHUTDOWN: 2027-01-30",
          "DECISION DATE: 2026-12-05",
          "",
          "DEPEND: web-frontend | OWNER: Ana Ruiz | STATUS: migrated | EVIDENCE: Pull request 482 merged 2026-11-15; the CDN now calls the new resizer only",
          "DEPEND: thumbnail-cron | OWNER: Ben Okafor | STATUS: migrated | EVIDENCE: Job config updated 2026-11-18; logs since then show the new endpoint only",
          "",
          "NOTICE: Ana Ruiz | DATE: 2026-11-20",
          "NOTICE: Ben Okafor | DATE: 2026-11-20"
        ].join("\n");

        var input = document.getElementById("input");
        var results = document.getElementById("results");

        function esc(s) {
          return String(s).replace(/[&<>"']/g, function (c) {
            return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
          });
        }

        function normName(s) {
          return s.replace(/\s+/g, " ").replace(/^\s+|\s+$/g, "").toLowerCase();
        }

        function parseDate(s) {
          var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s);
          if (!m) return null;
          var y = +m[1], mo = +m[2], d = +m[3];
          var dt = new Date(Date.UTC(y, mo - 1, d));
          if (dt.getUTCFullYear() !== y || dt.getUTCMonth() !== mo - 1 || dt.getUTCDate() !== d) return null;
          return dt;
        }

        function parseAll(text) {
          var plan = { service: "", shutdown: null, shutdownStr: "", decision: null, decisionStr: "" };
          var deps = [], notices = [], bad = [];
          var lines = text.split(/\r?\n/);
          for (var i = 0; i < lines.length; i++) {
            var n = i + 1;
            var raw = lines[i];
            var line = raw.replace(/^\s+|\s+$/g, "");
            if (!line) continue;
            var m;
            if ((m = /^SERVICE\s*:\s*(.+)$/i.exec(line))) {
              plan.service = m[1].replace(/\s+$/g, "");
            } else if ((m = /^SHUTDOWN\s*:\s*(.+)$/i.exec(line))) {
              var ds = m[1].replace(/\s+$/g, "");
              var dd = parseDate(ds);
              if (dd) { plan.shutdown = dd; plan.shutdownStr = ds; }
              else bad.push({ n: n, text: line, why: "the SHUTDOWN value is not a valid YYYY-MM-DD date" });
            } else if ((m = /^DECISION\s+DATE\s*:\s*(.+)$/i.exec(line))) {
              var es = m[1].replace(/\s+$/g, "");
              var ed = parseDate(es);
              if (ed) { plan.decision = ed; plan.decisionStr = es; }
              else bad.push({ n: n, text: line, why: "the DECISION DATE value is not a valid YYYY-MM-DD date" });
            } else if (/^DEPEND\s*:/i.test(line)) {
              var parts = line.split("|");
              var nm = null, om = null, sm = null, em = null;
              if (parts.length === 4) {
                nm = /^DEPEND\s*:\s*(.*)$/i.exec(parts[0].replace(/\s+$/g, ""));
                om = /^OWNER\s*:\s*(.*)$/i.exec(parts[1].replace(/^\s+|\s+$/g, ""));
                sm = /^STATUS\s*:\s*(.*)$/i.exec(parts[2].replace(/^\s+|\s+$/g, ""));
                em = /^EVIDENCE\s*:\s*(.*)$/i.exec(parts[3].replace(/^\s+/, ""));
              }
              if (!nm || !om || !sm || !em || !nm[1]) {
                bad.push({ n: n, text: line, why: "a DEPEND line needs exactly: DEPEND: <name> | OWNER: <owner or blank> | STATUS: <status> | EVIDENCE: <text or blank>" });
              } else {
                var statusRaw = sm[1].replace(/^\s+|\s+$/g, "");
                var status = statusRaw.toLowerCase();
                if (status !== "migrated" && status !== "in-progress" && status !== "not-started") {
                  bad.push({ n: n, text: line, why: "STATUS must be migrated, in-progress, or not-started — \"" + statusRaw + "\" is not one of them" });
                } else {
                  deps.push({
                    line: n,
                    name: nm[1],
                    owner: om[1].replace(/^\s+|\s+$/g, ""),
                    status: status,
                    statusRaw: statusRaw,
                    evidence: em[1].replace(/\s+$/g, "")
                  });
                }
              }
            } else if (/^NOTICE\s*:/i.test(line)) {
              var np = line.split("|");
              var am = null, dm = null;
              if (np.length === 2) {
                am = /^NOTICE\s*:\s*(.*)$/i.exec(np[0].replace(/\s+$/g, ""));
                dm = /^DATE\s*:\s*(.*)$/i.exec(np[1].replace(/^\s+|\s+$/g, ""));
              }
              if (!am || !dm || !am[1]) {
                bad.push({ n: n, text: line, why: "a NOTICE line needs exactly: NOTICE: <audience or owner> | DATE: <YYYY-MM-DD>" });
              } else {
                var nd = parseDate(dm[1].replace(/\s+$/g, ""));
                if (!nd) {
                  bad.push({ n: n, text: line, why: "the NOTICE DATE value is not a valid YYYY-MM-DD date" });
                } else {
                  notices.push({ line: n, audience: am[1], dateStr: dm[1].replace(/\s+$/g, "") });
                }
              }
            } else {
              bad.push({ n: n, text: line, why: "it matches none of the SERVICE, SHUTDOWN, DECISION DATE, DEPEND, or NOTICE formats" });
            }
          }
          return { plan: plan, deps: deps, notices: notices, bad: bad };
        }

        function audit(text) {
          var parsed = parseAll(text);
          var plan = parsed.plan, deps = parsed.deps, notices = parsed.notices, bad = parsed.bad;

          var noticeByName = {};
          notices.forEach(function (nt) {
            var k = normName(nt.audience);
            if (!noticeByName[k]) noticeByName[k] = nt;
          });

          deps.forEach(function (dep) {
            if (!dep.owner) {
              dep.grade = "NO OWNER";
            } else if (dep.status === "migrated" && dep.evidence) {
              dep.grade = "MIGRATED WITH EVIDENCE";
            } else if (dep.status === "migrated") {
              dep.grade = "CLAIMED MIGRATED, NO EVIDENCE";
            } else if (dep.status === "in-progress") {
              dep.grade = "IN PROGRESS";
            } else {
              dep.grade = "NOT STARTED";
            }
            dep.finished = dep.grade === "MIGRATED WITH EVIDENCE";
            dep.notice = dep.owner ? (noticeByName[normName(dep.owner)] || null) : null;
            dep.notNotified = !!dep.owner && !dep.notice;

            if (!dep.owner) {
              dep.basis = 'rests on OWNER: (blank) — the status word is STATUS: "' + dep.statusRaw + '" but a blank owner is a gap regardless of status';
            } else if (dep.grade === "MIGRATED WITH EVIDENCE") {
              dep.basis = 'rests on STATUS: "' + dep.statusRaw + '" and EVIDENCE: "' + dep.evidence + '"';
            } else if (dep.grade === "CLAIMED MIGRATED, NO EVIDENCE") {
              dep.basis = 'rests on STATUS: "' + dep.statusRaw + '" with EVIDENCE: (blank)';
            } else {
              dep.basis = 'rests on STATUS: "' + dep.statusRaw + '"';
            }
          });

          var days = null, datePassed = false;
          if (plan.shutdown && plan.decision) {
            days = Math.round((plan.shutdown.getTime() - plan.decision.getTime()) / 86400000);
            datePassed = days < 0;
          }

          var unfinished = deps.filter(function (d) { return !d.finished; });
          var notStarted = deps.filter(function (d) { return d.grade === "NOT STARTED"; });
          var noOwner = deps.filter(function (d) { return d.grade === "NO OWNER"; });
          var claimed = deps.filter(function (d) { return d.grade === "CLAIMED MIGRATED, NO EVIDENCE"; });
          var inProgress = deps.filter(function (d) { return d.grade === "IN PROGRESS"; });
          var notNotified = deps.filter(function (d) { return d.notNotified; });

          var reasons = [];
          var verdict, verdictClass;

          if (deps.length === 0) {
            verdict = "DO NOT SHUT DOWN YET";
            verdictClass = "bad";
            reasons.push("No DEPEND lines parsed — nothing was cross-checked, so there is nothing to declare safe.");
          } else {
            var blocked = false;
            if (notStarted.length) {
              blocked = true;
              notStarted.forEach(function (d) { reasons.push('"' + d.name + '" is NOT STARTED (STATUS: "' + d.statusRaw + '").'); });
            }
            if (noOwner.length) {
              blocked = true;
              noOwner.forEach(function (d) { reasons.push('"' + d.name + '" has NO OWNER (OWNER: blank) — always a gap, regardless of status.'); });
            }
            if (datePassed && unfinished.length) {
              blocked = true;
              reasons.push("DATE PASSED: SHUTDOWN " + plan.shutdownStr + " is " + Math.abs(days) + " day(s) before DECISION DATE " + plan.decisionStr + ", and " + unfinished.length + " dependenc" + (unfinished.length === 1 ? "y is" : "ies are") + " not MIGRATED WITH EVIDENCE.");
            } else if (days !== null && days <= 14 && unfinished.length) {
              blocked = true;
              reasons.push("Clock escalation: only " + days + " day(s) remain (14 or fewer) and " + unfinished.length + " dependenc" + (unfinished.length === 1 ? "y is" : "ies are") + " not MIGRATED WITH EVIDENCE — no slack left to finish and absorb a surprise.");
            }
            if (blocked) {
              verdict = "DO NOT SHUT DOWN YET";
              verdictClass = "bad";
            } else if (claimed.length || inProgress.length || notNotified.length) {
              verdict = "SHUT DOWN WITH GAPS";
              verdictClass = "warn";
            } else {
              verdict = "SAFE TO SHUT DOWN";
              verdictClass = "ok";
            }
            claimed.forEach(function (d) { reasons.push('"' + d.name + '" is CLAIMED MIGRATED, NO EVIDENCE (STATUS: "' + d.statusRaw + '", EVIDENCE: blank).'); });
            inProgress.forEach(function (d) { if (d.grade === "IN PROGRESS") reasons.push('"' + d.name + '" is IN PROGRESS (STATUS: "' + d.statusRaw + '").'); });
            notNotified.forEach(function (d) { reasons.push('"' + d.owner + '", owner of "' + d.name + '", is NOT NOTIFIED — no NOTICE line names "' + d.owner + '".'); });
            if (verdict === "SAFE TO SHUT DOWN") {
              reasons.push("Every parsed dependency is MIGRATED WITH EVIDENCE and every owner has a matching NOTICE line.");
            }
          }
          if (bad.length) {
            reasons.push(bad.length + " line(s) were UNPARSEABLE and excluded — the verdict does not cover them.");
          }
          if (days === null && deps.length) {
            reasons.push("The clock could not be computed — the SHUTDOWN or DECISION DATE line is missing or unparseable, so no date check or 14-day escalation was applied.");
          }

          return {
            plan: plan, deps: deps, notices: notices, bad: bad,
            days: days, datePassed: datePassed,
            verdict: verdict, verdictClass: verdictClass, reasons: reasons,
            notNotified: notNotified, unfinished: unfinished
          };
        }

        function chipClass(grade) {
          if (grade === "MIGRATED WITH EVIDENCE") return "ok";
          if (grade === "CLAIMED MIGRATED, NO EVIDENCE") return "warn";
          if (grade === "IN PROGRESS") return "info";
          return "bad";
        }

        function clockText(r) {
          if (r.days === null) {
            return { arith: "Clock not computed", detail: "The SHUTDOWN or DECISION DATE line is missing or unparseable, so no day count, DATE PASSED check, or 14-day escalation was applied." };
          }
          var arith = "SHUTDOWN " + r.plan.shutdownStr + " − DECISION DATE " + r.plan.decisionStr + " = " + r.days + " day(s) remaining";
          var detail;
          if (r.datePassed) {
            detail = "DATE PASSED: the shutdown date was already " + Math.abs(r.days) + " day(s) in the past at the decision date.";
          } else if (r.days <= 14) {
            detail = "Inside the 14-day escalation window: any dependency not MIGRATED WITH EVIDENCE escalates the verdict.";
          } else {
            detail = "Outside the 14-day escalation window.";
          }
          return { arith: arith, detail: detail };
        }

        function buildReport(r) {
          var out = [];
          out.push("J-DAWGS SERVICE DECOMMISSION & DEPENDENCY SHUTDOWN AUDITOR — REPORT");
          out.push("Service: " + (r.plan.service || "(no SERVICE line parsed)"));
          out.push("Verdict: " + r.verdict);
          out.push("");
          out.push("CLOCK");
          var ck = clockText(r);
          out.push(ck.arith + ".");
          out.push(ck.detail);
          out.push("");
          out.push("DEPENDENCIES (" + r.deps.length + " parsed)");
          if (!r.deps.length) out.push("None parsed.");
          r.deps.forEach(function (d, i) {
            out.push((i + 1) + ". " + d.name + " — " + d.grade);
            out.push("   Owner: " + (d.owner || "(blank)"));
            out.push("   Grade " + d.basis + ".");
            if (!d.owner) {
              out.push("   Notice: no owner to notify.");
            } else if (d.notice) {
              out.push('   Notice: covered — NOTICE: "' + d.notice.audience + '" | DATE: ' + d.notice.dateStr + " (line " + d.notice.line + ").");
            } else {
              out.push('   Notice: NOT NOTIFIED — no NOTICE line names "' + d.owner + '".');
            }
          });
          out.push("");
          out.push("NOTICE GAPS");
          if (!r.notNotified.length) {
            out.push("None — every dependency owner has a matching NOTICE line.");
          } else {
            r.notNotified.forEach(function (d) {
              out.push('- "' + d.owner + '" (owner of "' + d.name + '") — NOT NOTIFIED.');
            });
          }
          out.push("");
          out.push("UNPARSEABLE LINES (" + r.bad.length + ") — excluded, never guessed");
          if (!r.bad.length) {
            out.push("None.");
          } else {
            r.bad.forEach(function (b) {
              out.push("- Line " + b.n + ": UNPARSEABLE — " + b.why + ".");
              out.push('  "' + b.text + '"');
            });
          }
          out.push("");
          out.push("WHY THIS VERDICT");
          r.reasons.forEach(function (x) { out.push("- " + x); });
          out.push("");
          out.push("Limits: this report is a text cross-check of what was pasted only. It does not verify that a migration actually happened, that evidence is genuine, or that the dependency list is complete. An unlisted dependent is invisible to it.");
          return out.join("\n");
        }

        var lastReport = "";
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "MIXED_EXAMPLE": (typeof MIXED_EXAMPLE !== 'undefined' ? MIXED_EXAMPLE : undefined), "CLEAN_EXAMPLE": (typeof CLEAN_EXAMPLE !== 'undefined' ? CLEAN_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-service-decommission-dependency-shutdown-auditortm',
  name: 'J-Dawgs Service Decommission & Dependency Shutdown Auditor',
  description: 'Cross-checks a shutdown plan\'s dependency list against migration evidence and the notice log on one clock: per-dependency grades + days-to-shutdown arithmetic — into one shutdown verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "MIXED_EXAMPLE": __core["MIXED_EXAMPLE"], "CLEAN_EXAMPLE": __core["CLEAN_EXAMPLE"] }
};
