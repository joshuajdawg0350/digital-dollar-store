'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs SmartDNS Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var EXAMPLES = {
          risky: [
            "# Risky example - wide-open home router",
            "bind [::]:53",
            "bind 0.0.0.0:53",
            "server 8.8.8.8",
            "server 114.114.114.114",
            "cache-size 0",
            "serve-expired yes",
            "serve-expired-ttl 604800",
            "prefetch-domain yes",
            "speed-check-mode none",
            "dualstack-ip-selection yes",
            "response-mode fastest-ip",
            "log-level debug",
            "log-file /var/log/smartdns.log",
            "edns-client-subnet 203.0.113.0/24",
            "auth-password demoSecretValue12345"
          ].join("\n"),
          hardened: [
            "# Hardened example - loopback only, encrypted upstreams",
            "bind 127.0.0.1:53",
            "bind-tcp 127.0.0.1:53",
            "server-tls 1.1.1.1 -host-name cloudflare-dns.com",
            "server-tls 9.9.9.9 -host-name dns.quad9.net",
            "server-https https://cloudflare-dns.com/dns-query",
            "cache-size 4096",
            "serve-expired yes",
            "serve-expired-ttl 3600",
            "prefetch-domain yes",
            "speed-check-mode ping",
            "dualstack-ip-selection yes",
            "response-mode first-ping",
            "log-level info",
            "force-qtype-SOA 65 99"
          ].join("\n")
        };

        var SECRET_KEY_RE = /(api[-_]?key|secret|token|password|passwd|private[-_]?key|auth|credential)/i;

        function isYes(v) { return /^(yes|on|true|1)$/i.test(v || ""); }

        function auditConfig(text) {
          var rawLines = String(text || "").split(/\r?\n/);
          var findings = [];
          function add(sev, line, check, title, detail, fix) {
            findings.push({ severity: sev, line: line, check: check, title: title, detail: detail, fix: fix });
          }

          var directives = []; // {line, name, args[], rest}
          var i, raw, trimmed, parts, name;
          for (i = 0; i < rawLines.length; i++) {
            raw = rawLines[i];
            trimmed = raw.trim();
            if (!trimmed || trimmed.charAt(0) === "#") continue;
            parts = trimmed.split(/\s+/);
            name = parts[0].toLowerCase();
            directives.push({ line: i + 1, name: name, args: parts.slice(1), rest: parts.slice(1).join(" ") });
          }

          function byName(n) {
            var out = [];
            for (var j = 0; j < directives.length; j++) if (directives[j].name === n) out.push(directives[j]);
            return out;
          }
          function firstOf(n) { var a = byName(n); return a.length ? a[0] : null; }

          // --- Secret scan: every raw line, key name + line + length ONLY ---
          for (i = 0; i < rawLines.length; i++) {
            var lineText = rawLines[i];
            var t = lineText.trim();
            if (!t) continue;
            var keyName = null, valLen = 0, m;
            // key=value or key: value anywhere (covers URL query params too)
            var kvRe = /([A-Za-z0-9_-]*?(?:api[-_]?key|secret|token|password|passwd|private[-_]?key|credential)[A-Za-z0-9_-]*)\s*[:=]\s*"?([^\s"&]+)/gi;
            while ((m = kvRe.exec(lineText)) !== null) {
              if (SECRET_KEY_RE.test(m[1])) { keyName = m[1]; valLen = m[2].length; break; }
            }
            if (!keyName) {
              // leading "key value" directive form, e.g. auth-password <value>
              var lead = t.match(/^([A-Za-z0-9_-]+)\s+(\S+)/);
              if (lead && SECRET_KEY_RE.test(lead[1])) { keyName = lead[1]; valLen = lead[2].replace(/^["']|["']$/g, "").length; }
            }
            if (keyName) {
              add("HIGH", i + 1, "secret-in-config",
                "Secret material stored in the config under key \u201C" + keyName + "\u201D",
                "Line " + (i + 1) + " assigns a value to the secret key \u201C" + keyName + "\u201D (value length: " + valLen + " characters). The value itself is never shown by this tool. Anyone who can read this file — a backup, a screenshot, a pasted config — holds the secret.",
                "Move the secret out of the config file into an environment variable or a root-only secret file, tighten the config file permissions (chmod 600, owned by the service user), and rotate the secret if the file was ever shared.");
            }
          }

          var stats = {
            directiveLines: directives.length,
            binds: 0, plainUpstreams: 0, encryptedUpstreams: 0
          };

          var bindDirs = byName("bind").concat(byName("bind-tcp"));
          stats.binds = bindDirs.length;
          stats.plainUpstreams = byName("server").length;
          stats.encryptedUpstreams = byName("server-tls").length + byName("server-https").length + byName("server-quic").length;

          if (directives.length < 3) {
            return { notEnough: true, findings: findings, stats: stats };
          }
          bindDirs.forEach(function (d) {
            var addr = (d.args[0] || "");
            var host = "";
            if (addr.charAt(0) === "[") { host = addr.slice(1, addr.indexOf("]")); }
            else if (addr.indexOf(":") !== -1) { host = addr.slice(0, addr.lastIndexOf(":")); }
            else { host = addr; }
            if (host === "0.0.0.0" || host === "::" || host === "*" || host === "") {
              add("BLOCKER", d.line, "bind-all-interfaces",
                "Resolver bound to all interfaces (" + (host || "no address") + ")",
                "The " + d.name + " directive on line " + d.line + " listens on every interface. Unless a firewall or ACL in front of it says otherwise, anyone who can reach this host can use it as a resolver — the classic open-resolver setup used for DNS amplification.",
                "Bind to loopback or a specific LAN address instead, e.g. bind 127.0.0.1:53 for local use, and add firewall rules so UDP/TCP 53 is only reachable from networks you intend to serve.");
            }
          });
          if (bindDirs.length === 0) {
            add("MEDIUM", null, "bind-missing",
              "No bind directive stated",
              "The config never says which address SmartDNS listens on, so the daemon default decides the exposure for you.",
              "Add an explicit bind line for loopback or the exact LAN address you intend to serve, e.g. bind 127.0.0.1:53.");
          }

          // --- Upstreams ---
          var plain = byName("server");
          var tls = byName("server-tls");
          var https = byName("server-https");
          var quic = byName("server-quic");
          var encrypted = tls.concat(https).concat(quic);
          stats.plainUpstreams = plain.length;
          stats.encryptedUpstreams = encrypted.length;
          if (plain.length === 0 && encrypted.length === 0) {
            add("HIGH", null, "no-upstream",
              "No upstream servers configured",
              "There is no server, server-tls, or server-https directive, so SmartDNS has nothing to forward queries to.",
              "Add at least one encrypted upstream, e.g. server-tls 1.1.1.1 -host-name cloudflare-dns.com.");
          } else if (plain.length > 0 && encrypted.length === 0) {
            add("HIGH", plain[0].line, "plaintext-only-upstreams",
              "All upstreams are plaintext UDP — no TLS or HTTPS upstream",
              "Every upstream is a plain server directive (" + plain.length + " configured, first on line " + plain[0].line + "). Queries and answers cross the network unencrypted: visible to on-path observers and open to tampering.",
              "Replace plaintext upstreams with encrypted ones, e.g. server-tls 1.1.1.1 -host-name cloudflare-dns.com or a server-https DoH endpoint, and remove the plain server lines.");
            add("LOW", plain[0].line, "dnssec-posture",
              "No DNSSEC-grade integrity path",
              "With plaintext-only upstreams there is no authenticated channel and no stated validation posture, so forged answers have nothing standing in their way.",
              "Use DNS-over-TLS or DNS-over-HTTPS upstreams that perform DNSSEC validation, so answers arrive over an authenticated channel from a validating resolver.");
          } else if (plain.length > 0 && encrypted.length > 0) {
            add("MEDIUM", plain[0].line, "mixed-upstreams",
              "Plaintext upstreams mixed with encrypted upstreams",
              plain.length + " plaintext server directive(s) sit alongside " + encrypted.length + " encrypted one(s). Queries SmartDNS sends to the plaintext upstreams still leak and can still be tampered with.",
              "Remove the plaintext server lines, or restrict them to a named server-group used only for networks you control.");
          }

          // --- Cache size ---
          var cache = firstOf("cache-size");
          if (!cache) {
            add("MEDIUM", null, "cache-size-missing",
              "cache-size is not set",
              "The config sets no cache bound, so the compiled-in default decides how much memory the cache may grow to on this host.",
              "Set an explicit bound sized to the host, e.g. cache-size 4096.");
          } else {
            var cs = parseInt(cache.args[0], 10);
            if (isNaN(cs) || cs === 0) {
              add("HIGH", cache.line, "cache-size-unbounded",
                "cache-size is 0 — no effective cache bound",
                "Line " + cache.line + " sets cache-size to 0, which leaves the cache without a working bound: memory growth and stale answers are left unmanaged.",
                "Set a positive, host-sized bound, e.g. cache-size 4096, and restart SmartDNS.");
            } else if (cs > 100000) {
              add("HIGH", cache.line, "cache-size-oversized",
                "cache-size is very large (" + cs + " entries)",
                "A cache bound of " + cs + " entries on line " + cache.line + " can hold a very large working set in memory and keep stale answers alive far longer than a small host needs.",
                "Reduce cache-size to a bound the host can comfortably hold, e.g. cache-size 4096.");
            }
          }

          // --- Serve expired ---
          var se = firstOf("serve-expired");
          var seTtl = firstOf("serve-expired-ttl");
          var ttlVal = seTtl ? parseInt(seTtl.args[0], 10) : NaN;
          if (se && isYes(se.args[0])) {
            if (!seTtl) {
              add("MEDIUM", se.line, "serve-expired-no-ttl",
                "serve-expired is on with no serve-expired-ttl bound",
                "Line " + se.line + " enables serving expired answers, but nothing bounds how old an answer may be when it is served.",
                "Add a short bound, e.g. serve-expired-ttl 3600, so expired answers are a brief outage cushion, not a long-term source of truth.");
            } else if (!isNaN(ttlVal) && ttlVal > 86400) {
              add("HIGH", seTtl.line, "serve-expired-long-ttl",
                "serve-expired-ttl is " + ttlVal + " seconds (over 24 hours)",
                "Line " + seTtl.line + " lets SmartDNS serve expired answers for up to " + ttlVal + " seconds. Clients can receive days-old records while real upstream failures stay hidden.",
                "Lower serve-expired-ttl to an hour or less, e.g. serve-expired-ttl 3600, or turn serve-expired off.");
            }
          }

          // --- Prefetch posture ---
          if (!firstOf("prefetch-domain")) {
            add("LOW", null, "prefetch-unstated",
              "prefetch-domain posture is not stated",
              "The config never states whether hot domains are prefetched before expiry, so the default decides the freshness-versus-upstream-load tradeoff.",
              "State it deliberately: prefetch-domain yes keeps hot names fresh at the cost of extra upstream queries; no keeps upstream traffic minimal.");
          }

          // --- Speed check ---
          var scm = firstOf("speed-check-mode");
          if (!scm) {
            add("LOW", null, "speed-check-unstated",
              "speed-check-mode is not stated",
              "Nothing states how SmartDNS should test answer speed, so the default decides which upstream answer your clients get.",
              "Set speed-check-mode ping (or tcp) so SmartDNS measures and picks the fastest answer.");
          } else if ((scm.args[0] || "").toLowerCase() === "none") {
            add("MEDIUM", scm.line, "speed-check-none",
              "speed-check-mode is none",
              "Line " + scm.line + " disables speed checking. SmartDNS cannot compare answers, so clients get an unmeasured result instead of the fastest healthy one.",
              "Set speed-check-mode ping so answers are measured before one is served.");
          }

          // --- Dualstack posture ---
          if (!firstOf("dualstack-ip-selection")) {
            add("LOW", null, "dualstack-unstated",
              "dualstack-ip-selection posture is not stated",
              "The config never states how IPv4/IPv6 answers are preferred, so the default family preference applies to every dual-stack name.",
              "State it deliberately, e.g. dualstack-ip-selection yes if you want SmartDNS to prefer the faster family after speed checks.");
          }

          // --- Response mode ---
          var rm = firstOf("response-mode");
          if (rm && (rm.args[0] || "").toLowerCase() === "fastest-ip") {
            add("LOW", rm.line, "response-mode-fastest-ip",
              "response-mode fastest-ip probes every candidate address",
              "Line " + rm.line + " connects toward every candidate IP to find the fastest. That reveals more of your query pattern to networks along those paths and adds connection noise.",
              "If that tradeoff is not deliberate, use response-mode first-ping so the first measured answer wins.");
          }

          // --- Logging ---
          var ll = firstOf("log-level");
          var lf = firstOf("log-file");
          var isDebug = ll && (ll.args[0] || "").toLowerCase() === "debug";
          if (isDebug && lf) {
            add("HIGH", ll.line, "log-debug-to-file",
              "Debug logging is written to a log file",
              "log-level debug (line " + ll.line + ") combined with log-file (line " + lf.line + ") writes a full, detailed query history to disk. Anyone who reads that file — a shared backup, a support bundle — sees every name this resolver looked up.",
              "Drop log-level to info for normal serving, debug only while actively troubleshooting, and treat any existing debug log file as private data.");
          } else if (isDebug) {
            add("MEDIUM", ll.line, "log-level-debug",
              "log-level is debug",
              "Debug logging records detailed per-query information. Left on during normal serving it grows fast and exposes the full query history to anyone with log access.",
              "Set log-level info for normal serving and raise it only while troubleshooting.");
          } else if (lf) {
            add("LOW", lf.line, "log-file-present",
              "Queries are logged to a file",
              "log-file on line " + lf.line + " keeps a query history on disk. That is often intended — just make sure the file's permissions and retention match that sensitivity.",
              "Restrict the log file to the service account (chmod 600) and set a rotation/retention period.");
          }

          // --- force-qtype-SOA ---
          var fq = firstOf("force-qtype-soa");
          if (!fq) {
            add("LOW", null, "qtype-posture-unstated",
              "No force-qtype-SOA posture stated",
              "The config does not state which query types are refused with SOA responses, so odd or abusive qtypes are answered by default behaviour.",
              "Add a deliberate list for qtypes you never serve, e.g. force-qtype-SOA 65 99 — never A (1) or AAAA (28).");
          } else {
            var nums = fq.args.map(function (a) { return parseInt(a, 10); });
            if (nums.indexOf(1) !== -1 || nums.indexOf(28) !== -1) {
              add("HIGH", fq.line, "qtype-blocks-core",
                "force-qtype-SOA blocks A or AAAA queries",
                "Line " + fq.line + " includes qtype 1 (A) or 28 (AAAA) in the forced-SOA list. Ordinary hostname resolution will fail for clients.",
                "Remove 1 and 28 from force-qtype-SOA; block only qtypes you never legitimately serve.");
            }
          }

          // --- EDNS client subnet ---
          var ecs = firstOf("edns-client-subnet");
          if (ecs) {
            add("MEDIUM", ecs.line, "edns-client-subnet",
              "edns-client-subnet forwards your network location to upstreams",
              "Line " + ecs.line + " sends client subnet information to upstream resolvers with every query. That improves CDN localisation and quietly tells every upstream which network each query came from.",
              "Remove edns-client-subnet unless you deliberately need subnet-based CDN answers, and keep the prefix as coarse as the upstream allows.");
          }

          var rank = { BLOCKER: 0, HIGH: 1, MEDIUM: 2, LOW: 3 };
          findings.sort(function (a, b) {
            if (rank[a.severity] !== rank[b.severity]) return rank[a.severity] - rank[b.severity];
            return (a.line || 0) - (b.line || 0);
          });

          var counts = { BLOCKER: 0, HIGH: 0, MEDIUM: 0, LOW: 0 };
          findings.forEach(function (f) { counts[f.severity]++; });

          var verdict, why;
          if (counts.BLOCKER > 0) {
            verdict = "DO NOT SERVE";
            why = counts.BLOCKER + " blocker finding(s) must be fixed before this config serves anyone.";
          } else if (counts.HIGH > 0 || counts.MEDIUM > 0) {
            verdict = "SERVE WITH FIXES";
            why = "No blockers, but " + (counts.HIGH + counts.MEDIUM) + " high/medium finding(s) should be fixed before this config is trusted.";
          } else {
            verdict = "SAFE TO SERVE";
            why = findings.length === 0
              ? "No findings. Binds, upstreams, cache, and logging posture all check out."
              : "No blockers and no high or medium findings — only low advisories to consider.";
          }
          return { notEnough: false, verdict: verdict, why: why, counts: counts, findings: findings, stats: stats };
        }

        function buildReport(r) {
          var out = [];
          out.push("J-Dawgs SmartDNS Server Config Safety Auditor - Report");
          out.push("======================================================");
          if (r.notEnough) {
            out.push("Verdict: NOT ENOUGH TO GRADE");
            out.push("Too little config was pasted to grade (fewer than three directive lines).");
          } else {
            out.push("Verdict: " + r.verdict);
            out.push(r.why);
            out.push("Counts: BLOCKER " + r.counts.BLOCKER + " | HIGH " + r.counts.HIGH + " | MEDIUM " + r.counts.MEDIUM + " | LOW " + r.counts.LOW);
          }
          out.push("Parsed: " + r.stats.directiveLines + " directive line(s), " + r.stats.binds + " bind(s), " +
            r.stats.plainUpstreams + " plaintext upstream(s), " + r.stats.encryptedUpstreams + " encrypted upstream(s).");
          out.push("");
          if (r.findings.length === 0 && !r.notEnough) {
            out.push("Findings: none.");
          } else {
            out.push("Findings:");
            r.findings.forEach(function (f, idx) {
              out.push("");
              out.push((idx + 1) + ". [" + f.severity + "] " + (f.line ? "Line " + f.line + " - " : "Config-wide - ") + f.title);
              out.push("   " + f.detail);
              out.push("   Fix: " + f.fix);
            });
          }
          out.push("");
          out.push("Note: secret values are never included in this report - secrets are reported by key name, line, and value length only.");
          out.push("Generated locally in your browser. Nothing was uploaded or saved.");
          return out.join("\n");
        }

        function buildJSON(r) {
          var payload = {
            tool: "J-Dawgs SmartDNS Server Config Safety Auditor",
            verdict: r.notEnough ? "NOT ENOUGH TO GRADE" : r.verdict,
            verdictReason: r.notEnough ? "Fewer than three directive lines were pasted." : r.why,
            counts: r.notEnough ? { BLOCKER: 0, HIGH: 0, MEDIUM: 0, LOW: 0 } : r.counts,
            stats: r.stats,
            findings: r.findings.map(function (f) {
              return { severity: f.severity, line: f.line, check: f.check, title: f.title, detail: f.detail, fix: f.fix };
            }),
            secretHandling: "Secrets are reported by key name, line, and value length only. Secret values and raw config lines are never included."
          };
          return JSON.stringify(payload, null, 2);
        }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLES": (typeof EXAMPLES !== 'undefined' ? EXAMPLES : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-smartdns-server-config-safety-auditor',
  name: 'J-Dawgs SmartDNS Server Config Safety Auditor',
  description: 'Host tools only tell you the daemon started; ours grades a pasted SmartDNS config offline into one serve verdict — all-interface binds, plaintext vs TLS upstreams, cache/serve-expired posture, and secrets by key name/line/length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLES": __core["EXAMPLES"] }
};
