'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Grafana Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        // Grafana's well-known published default secret_key (from the shipped
        // defaults.ini). Compared in memory only — never rendered.
        var DEFAULT_SECRET_KEY = "SW2YcwTIb9zpOOhoPsMm";
        var WEAK_PASSWORD_LEN = 12;
        var WEAK_SECRET_LEN = 16;

        var RISKY_EXAMPLE = [
          "; Grafana server configuration — risky example",
          "[server]",
          "http_addr = 0.0.0.0",
          "http_port = 3000",
          "root_url = http://grafana.example.com/",
          "",
          "[security]",
          "admin_user = admin",
          "admin_password = admin",
          "secret_key = SW2YcwTIb9zpOOhoPsMm",
          "allow_embedding = true",
          "",
          "[auth.anonymous]",
          "enabled = true",
          "org_role = Admin",
          "",
          "[users]",
          "allow_sign_up = true",
          "auto_assign_org_role = Editor"
        ].join("\n");

        var HARDENED_EXAMPLE = [
          "; Grafana server configuration — hardened example",
          "[server]",
          "http_addr = 127.0.0.1",
          "http_port = 3000",
          "protocol = https",
          "root_url = https://grafana.example.com/",
          "",
          "[security]",
          "admin_user = grafana-admin",
          "admin_password = Tr7!velvet-harbor-lantern-92",
          "secret_key = 9f2Kd8sQpL4xZm7vN1bR6tY3wH5jC0a",
          "cookie_secure = true",
          "allow_embedding = false",
          "",
          "[auth.anonymous]",
          "enabled = false",
          "",
          "[users]",
          "allow_sign_up = false",
          "auto_assign_org_role = Viewer"
        ].join("\n");

        var PITCHES = {
          pitch1: "Before you ship that Grafana server, paste its config into the J-Dawgs Grafana Server Config Safety Auditor — one deploy verdict, every finding named by section, key, and line, and secret values never shown. AI Tool Store: https://muse.ai/s/ai-tool-store-xng6xkxwjkxl2xab/UoF72OkKI7j33Q2ITxmrZyIr4nv40QtYfj2AgESh_k8",
          pitch2: "A Grafana config that loads can still ship default admin credentials, anonymous Admin access, and a published default secret key — the Auditor grades all three before your users ever see the login page. J-Dawgs Agent Exchange: https://muse.ai/s/j-dawgs-agent-exchange-ih6xlnihzxdhxc/ZbleqxFHRE0NcswaBkyN13y9lLp5rPAgHTb6t8ii-PY",
          pitch3: "Serve It, Store It, Find It Stack: Grafana Server Config Safety Auditor + CouchDB Server Config Safety Auditor + Business Listing NAP & Hours Consistency Auditor — check the dashboard server, check the database server, check the listings customers actually find."
        };

        // Keys this audit grades, used for the NOT SET IN FILE report.
        var AUDITED_KEYS = [
          ["server", "http_addr"],
          ["server", "root_url"],
          ["server", "protocol"],
          ["security", "admin_user"],
          ["security", "admin_password"],
          ["security", "secret_key"],
          ["security", "allow_embedding"],
          ["security", "cookie_secure"],
          ["auth.anonymous", "enabled"],
          ["auth.anonymous", "org_role"],
          ["users", "allow_sign_up"],
          ["users", "auto_assign_org_role"]
        ];

        function el(id) { return document.getElementById(id); }

        function parseIni(text) {
          var entries = [];      // {section, key, value, line}
          var unparsed = [];     // line numbers
          var section = "(no section)";
          var lines = text.split(/\r\n|\r|\n/);
          for (var i = 0; i < lines.length; i++) {
            var lineNo = i + 1;
            var raw = lines[i];
            var t = raw.trim();
            if (t === "") continue;
            if (t.charAt(0) === ";" || t.charAt(0) === "#") continue;
            var secMatch = /^\[([^\]]+)\]$/.exec(t);
            if (secMatch) {
              section = secMatch[1].trim();
              continue;
            }
            var eq = t.indexOf("=");
            if (eq > 0) {
              var key = t.slice(0, eq).trim();
              var value = t.slice(eq + 1).trim();
              if (key !== "" && !/\s/.test(key)) {
                entries.push({ section: section, key: key, value: value, line: lineNo });
                continue;
              }
            }
            unparsed.push(lineNo);
          }
          return { entries: entries, unparsed: unparsed };
        }

        function getEntry(entries, section, key) {
          var found = null;
          for (var i = 0; i < entries.length; i++) {
            if (entries[i].section.toLowerCase() === section && entries[i].key.toLowerCase() === key) {
              found = entries[i]; // last occurrence wins, as in Grafana
            }
          }
          return found;
        }

        function isTrue(v) { return typeof v === "string" && v.trim().toLowerCase() === "true"; }
        function isFalse(v) { return typeof v === "string" && v.trim().toLowerCase() === "false"; }

        function audit(text) {
          var parsed = parseIni(text);
          var entries = parsed.entries;
          var findings = [];

          function add(level, section, key, line, msg, fix) {
            findings.push({ level: level, section: section, key: key, line: line, msg: msg, fix: fix || null });
          }

          // --- Gather the entries the checks depend on ---
          var adminUser = getEntry(entries, "security", "admin_user");
          var adminPass = getEntry(entries, "security", "admin_password");
          var secretKey = getEntry(entries, "security", "secret_key");
          var allowEmbedding = getEntry(entries, "security", "allow_embedding");
          var cookieSecure = getEntry(entries, "security", "cookie_secure");
          var anonEnabled = getEntry(entries, "auth.anonymous", "enabled");
          var anonRole = getEntry(entries, "auth.anonymous", "org_role");
          var allowSignUp = getEntry(entries, "users", "allow_sign_up");
          var autoRole = getEntry(entries, "users", "auto_assign_org_role");
          var httpAddr = getEntry(entries, "server", "http_addr");
          var rootUrl = getEntry(entries, "server", "root_url");
          var protocol = getEntry(entries, "server", "protocol");

          var anonOn = !!(anonEnabled && isTrue(anonEnabled.value));
          var anonRoleVal = anonRole ? anonRole.value.trim() : "";
          var defaultCreds = !!(adminPass && adminPass.value === "admin");

          // --- [security] admin_password ---
          if (adminPass) {
            if (defaultCreds) {
              add("BLOCKER", "security", "admin_password", adminPass.line,
                "admin_password is still the well-known default value \"admin\". Anyone who knows Grafana's defaults can sign in as the admin. (The value is named here only because it is the published default; no other value is ever shown.)",
                "Set [security] admin_password to a long, unique password before this server is reachable by anyone else.");
            } else if (adminUser && adminUser.value.trim().toLowerCase() === "admin" && adminPass.value.length < WEAK_PASSWORD_LEN) {
              add("WARNING", "security", "admin_password", adminPass.line,
                "admin_user is \"admin\" and admin_password is short (" + adminPass.value.length + " characters, graded by length only — the value is never shown). The default username paired with a short password is easy to guess.",
                "Use a longer admin_password (12+ characters) or rename admin_user away from the default.");
            } else if (adminPass.value.length < WEAK_PASSWORD_LEN) {
              add("WARNING", "security", "admin_password", adminPass.line,
                "admin_password is short (" + adminPass.value.length + " characters, graded by length only — the value is never shown).",
                "Use a longer admin_password (12+ characters).");
            } else {
              add("NOTE", "security", "admin_password", adminPass.line,
                "admin_password is set (" + adminPass.value.length + " characters) and is not the well-known default. The value is never shown.",
                null);
            }
          }

          // --- [security] secret_key ---
          if (secretKey) {
            if (secretKey.value === DEFAULT_SECRET_KEY) {
              add("BLOCKER", "security", "secret_key", secretKey.line,
                "secret_key is still Grafana's well-known published default value (the one shipped in defaults.ini). Anyone can read it in Grafana's public source and use it to forge signed data. The value itself is never rendered here.",
                "Set [security] secret_key to a unique, random value that appears in no other file or deployment.");
            } else if (secretKey.value.length < WEAK_SECRET_LEN) {
              add("WARNING", "security", "secret_key", secretKey.line,
                "secret_key is set but short (" + secretKey.value.length + " characters, graded by length only — the value is never shown). A short signing key is easier to brute-force.",
                "Use a unique, random secret_key of at least 16 characters.");
            } else {
              add("NOTE", "security", "secret_key", secretKey.line,
                "secret_key is set to a unique value (" + secretKey.value.length + " characters) and is not the published default. The value is never shown.",
                null);
            }
          }

          // --- [auth.anonymous] ---
          if (anonEnabled && isTrue(anonEnabled.value)) {
            if (anonRoleVal.toLowerCase() === "admin") {
              add("BLOCKER", "auth.anonymous", "enabled", anonEnabled.line,
                "Anonymous access is enabled and [auth.anonymous] org_role = Admin (line " + (anonRole ? anonRole.line : anonEnabled.line) + "). Anyone who can reach this server gets full admin rights with no login at all.",
                "Set [auth.anonymous] enabled = false, or lower org_role to Viewer if anonymous read-only access is truly intended.");
            } else if (anonRoleVal.toLowerCase() === "editor") {
              add("WARNING", "auth.anonymous", "enabled", anonEnabled.line,
                "Anonymous access is enabled with org_role = Editor (line " + (anonRole ? anonRole.line : anonEnabled.line) + "). Unauthenticated visitors can create and change dashboards — escalated warning.",
                "Disable anonymous access, or drop org_role to Viewer if anonymous read-only access is intended.");
            } else {
              add("WARNING", "auth.anonymous", "enabled", anonEnabled.line,
                "Anonymous access is enabled" + (anonRoleVal ? " with org_role = " + anonRoleVal : "") + ". Unauthenticated visitors can reach this Grafana without signing in.",
                "Set [auth.anonymous] enabled = false unless anonymous read-only access is a deliberate, reviewed decision.");
            }
          } else if (anonEnabled && isFalse(anonEnabled.value)) {
            add("NOTE", "auth.anonymous", "enabled", anonEnabled.line,
              "Anonymous access is disabled. Visitors must sign in.",
              null);
          }

          // --- [users] ---
          if (allowSignUp && isTrue(allowSignUp.value)) {
            add("WARNING", "users", "allow_sign_up", allowSignUp.line,
              "allow_sign_up = true. Anyone who can reach the login page can create their own account on this server.",
              "Set [users] allow_sign_up = false and create accounts deliberately instead.");
          }
          if (autoRole) {
            var role = autoRole.value.trim().toLowerCase();
            if (role === "admin") {
              add("BLOCKER", "users", "auto_assign_org_role", autoRole.line,
                "auto_assign_org_role = Admin. Every new account is automatically made an administrator.",
                "Set [users] auto_assign_org_role = Viewer and grant higher roles by hand.");
            } else if (role === "editor") {
              add("WARNING", "users", "auto_assign_org_role", autoRole.line,
                "auto_assign_org_role = Editor. Every new account can create and change dashboards without review.",
                "Set [users] auto_assign_org_role = Viewer unless Editor-by-default is deliberate.");
            }
          }

          // --- [server] exposure ---
          if (httpAddr) {
            var addr = httpAddr.value.trim();
            if (addr === "" || addr === "0.0.0.0" || addr === "::") {
              var pairings = [];
              if (anonOn) pairings.push("anonymous access is enabled" + (anonRoleVal ? " with org_role = " + anonRoleVal : "") + " ([auth.anonymous] line " + anonEnabled.line + ")");
              if (defaultCreds) pairings.push("the default admin password is in use ([security] admin_password, line " + adminPass.line + ")");
              if (pairings.length > 0) {
                add("WARNING", "server", "http_addr", httpAddr.line,
                  "http_addr " + (addr === "" ? "is empty" : "= " + addr) + ", so Grafana listens on all network interfaces — and that exposure is paired with: " + pairings.join("; ") + ". The pairing, not the bind alone, is what makes this dangerous.",
                  "Bind http_addr to 127.0.0.1 behind a reverse proxy, or fix the paired credential/anonymous-access findings before exposing this server.");
              } else {
                add("NOTE", "server", "http_addr", httpAddr.line,
                  "http_addr " + (addr === "" ? "is empty" : "= " + addr) + ", so Grafana listens on all network interfaces. That is normal behind a firewall or reverse proxy, but the server is reachable from every network it touches.",
                  "If this host is directly internet-facing, bind http_addr to 127.0.0.1 and front Grafana with a reverse proxy.");
              }
            } else {
              add("NOTE", "server", "http_addr", httpAddr.line,
                "http_addr = " + addr + " — Grafana binds only to that address rather than all interfaces.",
                null);
            }
          }

          // --- [server] root_url / protocol ---
          var rootVal = rootUrl ? rootUrl.value.trim() : "";
          if (rootUrl && /^http:\/\//i.test(rootVal)) {
            add("WARNING", "server", "root_url", rootUrl.line,
              "root_url starts with http://, not https://. Logins and session cookies travel unencrypted unless a proxy in front terminates TLS.",
              "Serve Grafana over HTTPS and set root_url to the https:// address.");
          }
          if (protocol && protocol.value.trim().toLowerCase() === "http" && rootUrl) {
            var isLocal = /localhost|127\.0\.0\.1|\[::1\]/i.test(rootVal);
            if (!isLocal && rootVal !== "") {
              add("WARNING", "server", "protocol", protocol.line,
                "protocol = http while root_url (" + rootVal + ") is not a localhost address. Grafana itself is serving plain HTTP to real users.",
                "Set protocol = https with a certificate, or terminate TLS at a reverse proxy.");
            }
          }

          // --- [security] allow_embedding ---
          if (allowEmbedding && isTrue(allowEmbedding.value)) {
            add("WARNING", "security", "allow_embedding", allowEmbedding.line,
              "allow_embedding = true. Other sites can frame this Grafana in their own pages, which enables clickjacking against signed-in users.",
              "Set [security] allow_embedding = false unless embedding dashboards in another trusted site is required.");
          }

          // --- [security] cookie_secure contradiction ---
          if (cookieSecure && isFalse(cookieSecure.value) && rootUrl && /^https:\/\//i.test(rootVal)) {
            add("WARNING", "security", "cookie_secure", cookieSecure.line,
              "cookie_secure = false is explicitly set while root_url is https://. The Secure flag is switched off on an HTTPS site, so session cookies are not restricted to encrypted connections.",
              "Set [security] cookie_secure = true to match the https:// root_url.");
          }

          // --- Sensitive-key inventory ---
          var inventory = [];
          for (var j = 0; j < entries.length; j++) {
            var lk = entries[j].key.toLowerCase();
            if (lk.indexOf("password") !== -1 || lk.indexOf("secret") !== -1 || lk.indexOf("token") !== -1) {
              inventory.push(entries[j]);
            }
          }

          // --- NOT SET IN FILE ---
          var notSet = [];
          for (var k = 0; k < AUDITED_KEYS.length; k++) {
            if (!getEntry(entries, AUDITED_KEYS[k][0], AUDITED_KEYS[k][1])) {
              notSet.push("[" + AUDITED_KEYS[k][0] + "] " + AUDITED_KEYS[k][1]);
            }
          }

          var blockers = findings.filter(function (f) { return f.level === "BLOCKER"; }).length;
          var warnings = findings.filter(function (f) { return f.level === "WARNING"; }).length;
          var notes = findings.filter(function (f) { return f.level === "NOTE"; }).length;
          var verdict = blockers > 0 ? "DO NOT DEPLOY" : (warnings > 0 ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY");

          return {
            findings: findings,
            inventory: inventory,
            notSet: notSet,
            unparsed: parsed.unparsed,
            counts: { blockers: blockers, warnings: warnings, notes: notes },
            verdict: verdict,
            keyCount: entries.length
          };
        }

        function locString(f) {
          return "[" + f.section + "] " + f.key + " — line " + f.line;
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-grafana-server-config-safety-auditor',
  name: 'J-Dawgs Grafana Server Config Safety Auditor',
  description: 'Grades a pasted Grafana INI config offline — default admin credentials, published default secret key, anonymous access, exposure pairings — into one deploy verdict. Grafana\'s startup checks only ask whether the server loads on its own host; ours grades a pasted config anywhere, security posture incl',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
