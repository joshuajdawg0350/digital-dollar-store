'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs AFFiNE Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Worked examples (line numbers matter — do not reflow) ---------- */
      var RISKY_EXAMPLE = [
        "# Risky example - do not deploy as-is",
        "AFFINE_SERVER_EXTERNAL_URL=http://notes.example.com",
        "DATABASE_URL=postgres://affine:shortpass123@db.example.com:5432/affine",
        "REDIS_URL=redis://:redis-pass-123@cache.example.com:6379/0",
        "JWT_SECRET=changeme",
        "AFFINE_SERVER_SESSION_SECRET=abc123",
        "AFFINE_ENABLE_SIGNUP=true",
        "AFFINE_EMAIL_VERIFICATION_ENABLED=false",
        "DEBUG=true",
        "LOG_LEVEL=debug",
        "AFFINE_SERVER_HOST=0.0.0.0",
        "CORS_ALLOWED_ORIGINS=*",
        "MAILER_HOST=smtp.example.com",
        "MAILER_SECURE=false"
      ].join("\n");

      var HARDENED_EXAMPLE = [
        "# Hardened example",
        "AFFINE_SERVER_EXTERNAL_URL=https://notes.example.com",
        "DATABASE_URL=postgres://affine:${DB_PASSWORD}@db.internal:5432/affine?sslmode=require",
        "REDIS_URL=rediss://cache.internal:6380/0",
        "JWT_SECRET=9f2c7a41d8e04b6fA35c91e7d2048b6cF19a73d5e8024b",
        "AFFINE_SERVER_SESSION_SECRET=4b8e01f7c3a94d62B8506e1f9a27c4d3E65b08f1a93c72d",
        "AFFINE_ENABLE_SIGNUP=false",
        "AFFINE_EMAIL_VERIFICATION_ENABLED=true",
        "DEBUG=false",
        "LOG_LEVEL=info",
        "AFFINE_SERVER_HOST=notes.example.com",
        "CORS_ALLOWED_ORIGINS=https://notes.example.com",
        "MAILER_HOST=smtp.example.com",
        "MAILER_PORT=465",
        "MAILER_SECURE=true"
      ].join("\n");

      /* ---------- Parsing ---------- */
      function parseConfig(text) {
        var entries = [];
        var lines = String(text == null ? "" : text).split(/\r?\n/);
        for (var i = 0; i < lines.length; i++) {
          var raw = lines[i];
          var trimmed = raw.trim();
          if (!trimmed || trimmed.charAt(0) === "#") continue;
          var m = trimmed.match(/^([A-Za-z_][A-Za-z0-9_.\-]*)\s*=\s*(.*)$/);
          if (!m) continue;
          var value = m[2].trim();
          if (value.length >= 2 &&
              ((value.charAt(0) === '"' && value.charAt(value.length - 1) === '"') ||
               (value.charAt(0) === "'" && value.charAt(value.length - 1) === "'"))) {
            value = value.slice(1, -1);
          }
          entries.push({ line: i + 1, key: m[1], keyUpper: m[1].toUpperCase(), value: value });
        }
        return entries;
      }

      function isTruthy(v) {
        return ["true", "1", "yes", "on", "enabled", "enable", "open", "allow", "allowed", "public"].indexOf(String(v).trim().toLowerCase()) !== -1;
      }
      function isFalsy(v) {
        return ["false", "0", "no", "off", "disabled", "disable", "closed", "none"].indexOf(String(v).trim().toLowerCase()) !== -1;
      }

      var EXAMPLE_SECRETS = ["changeme", "change-me", "change_me", "change me", "secret", "password",
        "passw0rd", "letmein", "admin", "default", "example", "test", "testing", "demo",
        "123456", "12345678", "123456789", "qwerty", "supersecret", "your-secret", "your_secret",
        "please-change", "todo", "xxx", "placeholder"];

      function isExampleSecret(v) {
        var lv = String(v).trim().toLowerCase();
        if (EXAMPLE_SECRETS.indexOf(lv) !== -1) return true;
        if (lv.indexOf("changeme") !== -1) return true;
        if (lv.indexOf("change-me") !== -1 || lv.indexOf("change_me") !== -1) return true;
        if (lv.indexOf("example") !== -1) return true;
        if (lv.indexOf("your-") === 0 || lv.indexOf("your_") === 0) return true;
        if (lv.indexOf("placeholder") !== -1) return true;
        if (lv.charAt(0) === "<" && lv.charAt(lv.length - 1) === ">") return true;
        return false;
      }

      function isSecretKey(keyUpper) {
        return /SECRET|TOKEN|PASSWORD|PASSWD|PRIVATE_KEY|API_KEY|ACCESS_KEY|JWT|ENCRYPTION|SESSION_KEY|AUTH_KEY/.test(keyUpper);
      }

      /* Extract the password segment of a URL's userinfo, without ever returning it to the UI.
         Returns { found:boolean, length:number, isReference:boolean } */
      function urlPasswordInfo(value) {
        var m = String(value).match(/^[a-zA-Z][a-zA-Z0-9+.\-]*:\/\/([^/?#]*)/);
        if (!m) return { found: false, length: 0, isReference: false };
        var authority = m[1];
        var at = authority.lastIndexOf("@");
        if (at === -1) return { found: false, length: 0, isReference: false };
        var userinfo = authority.slice(0, at);
        var colon = userinfo.indexOf(":");
        if (colon === -1) return { found: false, length: 0, isReference: false };
        var pw = userinfo.slice(colon + 1);
        if (!pw) return { found: false, length: 0, isReference: false };
        var isRef = pw.indexOf("${") === 0 || pw.charAt(0) === "$" || pw === "***" || pw.indexOf("${") !== -1;
        return { found: true, length: pw.length, isReference: isRef };
      }

      function urlHost(value) {
        var m = String(value).match(/^http:\/\/([^/?#:]+)/i);
        return m ? m[1].toLowerCase() : null;
      }

      /* ---------- Audit ----------
         Findings NEVER contain config values. Secrets are described by key,
         line and length only, so a report or JSON export cannot leak them. */
      function auditConfig(text) {
        var entries = parseConfig(text);
        var findings = [];
        function add(line, key, severity, code, message) {
          findings.push({ line: line, key: key, severity: severity, code: code, message: message });
        }

        if (entries.length < 3) {
          return { verdict: "NOT ENOUGH TO GRADE", entries: entries.length, findings: [] };
        }

        var mailerHostEntry = null;
        var mailerSecureEntry = null;

        for (var i = 0; i < entries.length; i++) {
          var e = entries[i];
          var k = e.keyUpper;
          var v = e.value;
          var lv = v.trim().toLowerCase();

          /* 1. Short / example / default secrets */
          if (isSecretKey(k)) {
            if (isExampleSecret(v)) {
              add(e.line, e.key, "critical", "EXAMPLE_SECRET",
                "Secret is a known example, default, or placeholder value (length " + v.length + "). Replace it with a long random value from a generator. The value itself is not shown here.");
            } else if (v.length < 16) {
              add(e.line, e.key, "critical", "SHORT_SECRET",
                "Secret is only " + v.length + " characters long. Use at least 32 random characters. The value itself is not shown here.");
            } else if (v.length < 32) {
              add(e.line, e.key, "high", "SHORT_SECRET",
                "Secret is " + v.length + " characters long — below the 32-character floor for a deployed server. The value itself is not shown here.");
            }
          }

          /* 2. Plaintext passwords inside DATABASE_URL / Redis-style URLs */
          if (/DATABASE|REDIS|POSTGRES|MYSQL|MONGO|AMQP/.test(k) && /^[a-zA-Z][a-zA-Z0-9+.\-]*:\/\//.test(v)) {
            var pw = urlPasswordInfo(v);
            if (pw.found && !pw.isReference) {
              add(e.line, e.key, "critical", "PLAINTEXT_URL_PASSWORD",
                "A plaintext password (length " + pw.length + ") is embedded in this URL. Move it to a secret store or an environment reference and rotate it — anyone who can read this file now has it. The password itself is not shown here.");
            }
          }

          /* 3. http (non-https) public URLs */
          if (/^http:\/\//i.test(v)) {
            var host = urlHost(v);
            if (host && host !== "localhost" && host !== "127.0.0.1" && host !== "[::1]") {
              add(e.line, e.key, "high", "INSECURE_HTTP_URL",
                "Public URL uses plain http, so traffic — including sessions — crosses the network unencrypted. Serve it over https.");
            }
          }

          /* 4. Open registration / signup */
          if (/SIGNUP|SIGN_UP|REGISTRATION|REGISTER/.test(k) && (isTruthy(v) || lv === "open" || lv === "public")) {
            add(e.line, e.key, "high", "OPEN_SIGNUP",
              "Registration / signup is open, so anyone on the internet can create an account on this server. Close it or gate it behind invites unless public signup is deliberate.");
          }

          /* 5. Email verification disabled */
          if (/EMAIL_VERIFICATION|VERIFY_EMAIL|EMAIL_VERIFY|VERIFICATION/.test(k) && isFalsy(v)) {
            add(e.line, e.key, "high", "EMAIL_VERIFICATION_OFF",
              "Email verification is disabled, so accounts can be created with addresses the owner never proved they control. Turn verification on.");
          }

          /* 6. Debug / verbose logging */
          if ((k === "DEBUG" || /_DEBUG$/.test(k) || k === "VERBOSE" || /_VERBOSE$/.test(k)) && isTruthy(v)) {
            add(e.line, e.key, "medium", "DEBUG_ON",
              "Debug / verbose mode is switched on. Debug output can leak internals and credentials into responses and logs. Turn it off for deployment.");
          }
          if (/LOG_LEVEL|LOGGING|LOGLEVEL/.test(k) && ["debug", "verbose", "trace", "silly"].indexOf(lv) !== -1) {
            add(e.line, e.key, "medium", "VERBOSE_LOGGING",
              "Log level is set to a verbose setting. Verbose logs can record tokens, URLs, and user data. Use info or warn in production.");
          }
          if (k === "NODE_ENV" && (lv === "development" || lv === "dev")) {
            add(e.line, e.key, "medium", "DEV_MODE",
              "Runtime is set to a development mode. Deploy with the production setting so dev error pages and reloaders stay off.");
          }

          /* 7. Wildcard hosts / CORS */
          if (/HOST|CORS|ORIGIN|ALLOWED/.test(k) && (lv === "*" || lv === "0.0.0.0" || lv === "::" || /(^|[,\s])\*($|[,\s])/.test(v))) {
            add(e.line, e.key, "high", "WILDCARD_HOST_OR_CORS",
              "A wildcard host / origin is allowed, so any site or network peer can reach or call this server as a trusted origin. Name the exact hostnames and origins instead.");
          } else if (lv === "*") {
            add(e.line, e.key, "high", "WILDCARD_VALUE",
              "This setting is a bare wildcard. Replace it with the exact values the deployment needs.");
          }

          /* 8. Mailer TLS bookkeeping (evaluated after the loop) */
          if (/^(MAILER|SMTP|MAIL)_/.test(k) || /SMTP|MAILER/.test(k)) {
            if (/HOST/.test(k)) mailerHostEntry = e;
            if (/SECURE|TLS|SSL/.test(k)) mailerSecureEntry = e;
            if (/PORT/.test(k) && v.trim() === "25") {
              add(e.line, e.key, "medium", "MAILER_PLAINTEXT_PORT",
                "Mailer port 25 is the plaintext relay port. Use a submission port with TLS (465 or 587 with TLS on).");
            }
          }
        }

        if (mailerHostEntry) {
          if (mailerSecureEntry && isFalsy(mailerSecureEntry.value)) {
            add(mailerSecureEntry.line, mailerSecureEntry.key, "high", "MAILER_TLS_OFF",
              "A mailer host is configured but its TLS / secure setting is off, so mail credentials and message content can cross the network in plaintext. Turn mailer TLS on.");
          } else if (!mailerSecureEntry) {
            add(mailerHostEntry.line, mailerHostEntry.key, "medium", "MAILER_TLS_UNSET",
              "A mailer host is configured but no TLS / secure setting appears anywhere in the config. Set the mailer secure / TLS option explicitly.");
          }
        }

        var sevRank = { critical: 0, high: 1, medium: 2 };
        findings.sort(function (a, b) {
          if (a.line !== b.line) return a.line - b.line;
          return sevRank[a.severity] - sevRank[b.severity];
        });

        var verdict;
        var hasCritical = findings.some(function (f) { return f.severity === "critical"; });
        if (hasCritical) verdict = "DO NOT DEPLOY";
        else if (findings.length > 0) verdict = "DEPLOY WITH FIXES";
        else verdict = "SAFE TO DEPLOY";

        return { verdict: verdict, entries: entries.length, findings: findings };
      }

      /* ---------- Report / JSON (built only from findings — no raw values) ---------- */
      function buildReport(result) {
        var lines = [];
        lines.push("J-Dawgs AFFiNE Server Config Safety Auditor - audit report");
        lines.push("Verdict: " + result.verdict);
        lines.push("Config lines graded: " + result.entries);
        lines.push("Findings: " + result.findings.length);
        lines.push("");
        if (result.verdict === "NOT ENOUGH TO GRADE") {
          lines.push("Not enough config to grade: fewer than 3 KEY=VALUE lines were found. Paste an env-style config and audit again.");
        } else if (result.findings.length === 0) {
          lines.push("No findings. The pasted config passed every check in this heuristic text audit.");
        } else {
          for (var i = 0; i < result.findings.length; i++) {
            var f = result.findings[i];
            lines.push("Line " + f.line + " | " + f.severity.toUpperCase() + " | " + f.key + " | " + f.code);
            lines.push("  " + f.message);
          }
        }
        lines.push("");
        lines.push("Note: heuristic text audit only. It does not start the server and cannot verify the deployment actually runs. Secret values are never included in this report.");
        return lines.join("\n");
      }

      function buildJson(result) {
        return {
          tool: "J-Dawgs AFFiNE Server Config Safety Auditor",
          verdict: result.verdict,
          configLinesGraded: result.entries,
          findingCount: result.findings.length,
          findings: result.findings.map(function (f) {
            return { line: f.line, key: f.key, severity: f.severity, code: f.code, message: f.message };
          }),
          note: "Heuristic text audit only; secret values are never included."
        };
      }

      /* ---------- UI wiring ---------- */
      var lastResult = null;
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined), "EXAMPLE_SECRETS": (typeof EXAMPLE_SECRETS !== 'undefined' ? EXAMPLE_SECRETS : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-affine-server-config-safety-auditortm',
  name: 'J-Dawgs AFFiNE Server Config Safety Auditor',
  description: 'Grades a pasted AFFiNE self-hosted config offline into one deploy verdict — secrets by key name/line/length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"], "EXAMPLE_SECRETS": __core["EXAMPLE_SECRETS"] }
};
