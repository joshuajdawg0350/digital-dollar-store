'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs OpenTelemetry Collector Config Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

    /*AUDIT-CORE-START*/
    // Heuristic YAML subset parser + deterministic checks.
    // Reads only the structure this auditor reports on; anything outside the
    // subset is recorded as NOT PARSED with its line number, never guessed.

    var COMPONENT_SECTIONS = ["receivers", "processors", "exporters", "extensions"];
    // Exporter base types this auditor recognizes. Endpoint-needing types are
    // checked for plaintext http:// only — defaults are never invented.
    var KNOWN_EXPORTERS = {
      "otlp": 1, "otlphttp": 1, "kafka": 1, "jaeger": 1, "zipkin": 1,
      "prometheusremotewrite": 1, "loki": 1, "elasticsearch": 1,
      "clickhouse": 1, "awss3": 1, "azuremonitor": 1, "datadog": 1,
      "googlecloud": 1, "honeycomb": 1, "logzio": 1, "newrelic": 1,
      "signalfx": 1, "splunkhec": 1, "debug": 1, "logging": 1, "nop": 1,
      "file": 1, "prometheus": 1, "loadbalancing": 1, "spanmetrics": 1
    };

    function baseType(name) {
      var i = name.indexOf("/");
      return i === -1 ? name : name.slice(0, i);
    }
    function stripQuotes(s) {
      s = s.replace(/^\s+|\s+$/g, "");
      if (s.length >= 2 && ((s.charAt(0) === '"' && s.charAt(s.length - 1) === '"') ||
          (s.charAt(0) === "'" && s.charAt(s.length - 1) === "'"))) {
        return s.slice(1, -1);
      }
      return s;
    }
    // Remove a trailing # comment, honoring simple quoting.
    function stripComment(line) {
      var inS = false, inD = false;
      for (var i = 0; i < line.length; i++) {
        var c = line.charAt(i);
        if (c === "'" && !inD) inS = !inS;
        else if (c === '"' && !inS) inD = !inD;
        else if (c === "#" && !inS && !inD && (i === 0 || line.charAt(i - 1) === " " || line.charAt(i - 1) === "\t")) {
          return line.slice(0, i);
        }
      }
      return line;
    }
    function countIndent(raw) {
      var n = 0;
      while (n < raw.length && raw.charAt(n) === " ") n++;
      return n;
    }
    var KEY_RE = /^([A-Za-z0-9_.\/-]+):\s*(.*)$/;

    // Parse a flow list "[a, b]" or a single bare scalar into names.
    // Returns null when the shape is not readable.
    function parseNameList(value) {
      value = value.replace(/^\s+|\s+$/g, "");
      if (value === "") return [];
      if (value.charAt(0) === "[") {
        if (value.charAt(value.length - 1) !== "]") return null;
        var inner = value.slice(1, -1).replace(/^\s+|\s+$/g, "");
        if (inner === "") return [];
        var parts = inner.split(",");
        var out = [];
        for (var i = 0; i < parts.length; i++) {
          var p = stripQuotes(parts[i]);
          if (p === "") return null;
          out.push(p);
        }
        return out;
      }
      if (value.charAt(0) === "{" || value.charAt(0) === "-") return null;
      var single = stripQuotes(value);
      if (single === "" || /[\[\]{}]/.test(single)) return null;
      return [single];
    }

    function parseConfig(text) {
      var lines = text.split(/\r?\n/);
      var result = {
        sections: { receivers: {}, processors: {}, exporters: {}, extensions: {} },
        sectionSeen: {},
        duplicates: [],       // {section, name, firstLine, line}
        endpoints: [],        // {exporter, value, line}
        exporterHasEndpoint: {},
        pipelines: [],        // {name, line, receivers:[{name,line}], processors:[], exporters:[]}
        pipelineByName: {},
        serviceExtensions: [],// {name, line}
        notParsed: [],        // {line, text, reason}
        sawAnySection: false
      };
      var top = null;           // current top-level key
      var currentComponent = null;
      var currentExporter = null;
      var inPipelines = false;
      var currentPipeline = null;
      var pendingList = null;   // {kind: 'pipeline', key} | {kind:'serviceExtensions'}
      var serviceSub = null;    // current indent-2 key under service

      function notParsed(lineNo, rawText, reason) {
        result.notParsed.push({ line: lineNo, text: rawText.replace(/\s+$/g, ""), reason: reason });
      }

      for (var idx = 0; idx < lines.length; idx++) {
        var lineNo = idx + 1;
        var raw = lines[idx];
        if (/^\t/.test(raw) || /^ +\t/.test(raw)) {
          notParsed(lineNo, raw, "tab indentation is outside the readable subset");
          continue;
        }
        var noComment = stripComment(raw);
        var trimmed = noComment.replace(/^\s+|\s+$/g, "");
        if (trimmed === "" || trimmed === "---" || trimmed === "...") continue;
        var indent = countIndent(noComment);
        var m = trimmed.match(KEY_RE);
        var isListItem = trimmed.charAt(0) === "-" && (trimmed.length === 1 || trimmed.charAt(1) === " ");

        if (indent === 0) {
          pendingList = null; currentPipeline = null; inPipelines = false;
          currentComponent = null; currentExporter = null; serviceSub = null;
          if (!m) { notParsed(lineNo, raw, "not a readable top-level mapping key"); top = null; continue; }
          top = m[1];
          if (COMPONENT_SECTIONS.indexOf(top) !== -1 || top === "service") {
            result.sawAnySection = true;
            result.sectionSeen[top] = lineNo;
          }
          continue;
        }

        if (top === null) { notParsed(lineNo, raw, "content outside any top-level section"); continue; }

        if (COMPONENT_SECTIONS.indexOf(top) !== -1) {
          if (indent === 2) {
            pendingList = null;
            if (!m) { notParsed(lineNo, raw, "not a readable component definition"); currentComponent = null; currentExporter = null; continue; }
            var cname = m[1];
            currentComponent = cname;
            if (result.sections[top][cname]) {
              result.duplicates.push({ section: top, name: cname, firstLine: result.sections[top][cname].line, line: lineNo });
            } else {
              result.sections[top][cname] = { line: lineNo };
            }
            if (top === "exporters") currentExporter = cname;
            continue;
          }
          // Deeper lines are component body config: not interpreted, except
          // an exporter's endpoint, which this audit grades.
          if (top === "exporters" && currentExporter && m && m[1] === "endpoint") {
            var val = stripQuotes(m[2]);
            result.endpoints.push({ exporter: currentExporter, value: val, line: lineNo });
            result.exporterHasEndpoint[currentExporter] = true;
          }
          continue;
        }

        if (top === "service") {
          if (indent === 2) {
            pendingList = null; currentPipeline = null; inPipelines = false;
            if (!m) { notParsed(lineNo, raw, "not a readable service key"); serviceSub = null; continue; }
            serviceSub = m[1];
            if (serviceSub === "extensions") {
              var extNames = parseNameList(m[2]);
              if (extNames === null) notParsed(lineNo, raw, "service.extensions list is not readable");
              else for (var e = 0; e < extNames.length; e++) result.serviceExtensions.push({ name: extNames[e], line: lineNo });
              if (m[2].replace(/\s/g, "") === "") pendingList = { kind: "serviceExtensions" };
            } else if (serviceSub === "pipelines") {
              inPipelines = true;
            }
            continue;
          }
          if (serviceSub === "extensions" && pendingList && pendingList.kind === "serviceExtensions" && isListItem && indent > 2) {
            var itemName = stripQuotes(trimmed.slice(1));
            if (itemName && !/[\[\]{}:]/.test(itemName)) result.serviceExtensions.push({ name: itemName, line: lineNo });
            else notParsed(lineNo, raw, "service.extensions entry is not readable");
            continue;
          }
          if (inPipelines) {
            if (indent === 4) {
              pendingList = null;
              if (!m) { notParsed(lineNo, raw, "not a readable pipeline definition"); currentPipeline = null; continue; }
              currentPipeline = { name: m[1], line: lineNo, receivers: [], processors: [], exporters: [] };
              result.pipelines.push(currentPipeline);
              result.pipelineByName[m[1]] = currentPipeline;
              continue;
            }
            if (indent === 6 && currentPipeline) {
              pendingList = null;
              if (!m || ["receivers", "processors", "exporters"].indexOf(m[1]) === -1) {
                if (m) { /* other pipeline keys (mode etc.) are body config: not interpreted */ continue; }
                notParsed(lineNo, raw, "not a readable pipeline entry");
                continue;
              }
              var refs = parseNameList(m[2]);
              if (refs === null) { notParsed(lineNo, raw, "pipeline component list is not readable"); continue; }
              for (var r = 0; r < refs.length; r++) currentPipeline[m[1]].push({ name: refs[r], line: lineNo });
              if (m[2].replace(/\s/g, "") === "") pendingList = { kind: "pipeline", key: m[1] };
              continue;
            }
            if (pendingList && pendingList.kind === "pipeline" && isListItem && currentPipeline && indent > 6) {
              var refName = stripQuotes(trimmed.slice(1));
              var colonAt = refName.indexOf(":");
              if (colonAt !== -1) refName = refName.slice(0, colonAt).replace(/\s+$/g, "");
              if (refName && !/[\[\]{}]/.test(refName)) currentPipeline[pendingList.key].push({ name: refName, line: lineNo });
              else notParsed(lineNo, raw, "pipeline list entry is not readable");
              continue;
            }
            if (indent > 6) continue; // deeper pipeline body config: not interpreted
            notParsed(lineNo, raw, "line inside service.pipelines is outside the readable subset");
            continue;
          }
          continue; // other service subsections (telemetry, etc.): not interpreted
        }
        // Any other top-level section (connectors, etc.): body not interpreted.
      }
      return result;
    }

    function auditConfig(text) {
      var findings = [];
      function add(sev, msg, line) { findings.push({ severity: sev, message: msg, line: line || null }); }

      if (text.replace(/\s/g, "") === "") {
        return { verdict: "COULD NOT AUDIT", reason: "The input is empty — there is no configuration to audit.", findings: [], parsed: null };
      }
      var parsed = parseConfig(text);
      if (!parsed.sawAnySection) {
        var npLines = [];
        for (var i = 0; i < parsed.notParsed.length; i++) npLines.push(parsed.notParsed[i].line);
        return {
          verdict: "COULD NOT AUDIT",
          reason: "No recognizable collector configuration structure was found — none of the receivers, processors, exporters, extensions, or service sections could be located." +
            (npLines.length ? " NOT PARSED lines: " + npLines.join(", ") + "." : ""),
          findings: [], parsed: parsed
        };
      }

      var sections = parsed.sections;
      var used = { receivers: {}, processors: {}, exporters: {} };
      var memoryReferenced = false;
      var debugPipelines = [];   // {pipeline, line}
      var tracesMissingBatch = [];

      // Check 1: pipeline wiring — every referenced component must be defined.
      for (var p = 0; p < parsed.pipelines.length; p++) {
        var pipe = parsed.pipelines[p];
        var kinds = ["receivers", "processors", "exporters"];
        for (var k = 0; k < kinds.length; k++) {
          var kind = kinds[k];
          var singular = kind.slice(0, -1);
          for (var j = 0; j < pipe[kind].length; j++) {
            var ref = pipe[kind][j];
            used[kind][ref.name] = true;
            if (!sections[kind][ref.name]) {
              add("BLOCKER", "Pipeline '" + pipe.name + "' references undefined " + singular + " '" + ref.name + "'.", ref.line);
            }
            if (kind === "processors" && baseType(ref.name) === "memory_limiter") memoryReferenced = true;
            if (kind === "processors" && baseType(ref.name) === "batch") { /* noted below per pipeline */ }
            if (kind === "exporters" && baseType(ref.name) === "debug") {
              var seenDbg = false;
              for (var d = 0; d < debugPipelines.length; d++) if (debugPipelines[d].pipeline === pipe.name) seenDbg = true;
              if (!seenDbg) debugPipelines.push({ pipeline: pipe.name, line: ref.line });
            }
          }
        }
        // Check 6 (data): traces pipeline without batch.
        if (baseType(pipe.name) === "traces") {
          var hasBatch = false;
          for (var b = 0; b < pipe.processors.length; b++) if (baseType(pipe.processors[b].name) === "batch") hasBatch = true;
          if (!hasBatch) tracesMissingBatch.push(pipe);
        }
      }

      // Check 8: duplicate component names within one section.
      for (var du = 0; du < parsed.duplicates.length; du++) {
        var dup = parsed.duplicates[du];
        add("BLOCKER", "Duplicate " + dup.section.slice(0, -1) + " '" + dup.name + "' defined twice in the " + dup.section + " section (first at line " + dup.firstLine + ", again at line " + dup.line + ").", dup.line);
      }

      // Check 2: defined but never used in any pipeline (dead config).
      var deadKinds = ["receivers", "processors", "exporters"];
      for (var dk = 0; dk < deadKinds.length; dk++) {
        var dkind = deadKinds[dk];
        for (var dname in sections[dkind]) {
          if (!used[dkind][dname]) {
            add("WARNING", dkind.slice(0, -1).charAt(0).toUpperCase() + dkind.slice(0, -1).slice(1) + " '" + dname + "' is defined but never used in any pipeline — dead configuration.", sections[dkind][dname].line);
          }
        }
      }

      // Check 3: extension defined but not enabled under service.extensions.
      var enabledExt = {};
      for (var se = 0; se < parsed.serviceExtensions.length; se++) enabledExt[parsed.serviceExtensions[se].name] = true;
      for (var xname in sections.extensions) {
        if (!enabledExt[xname]) {
          add("WARNING", "Extension '" + xname + "' is defined but not listed under service.extensions — it will not run.", sections.extensions[xname].line);
        }
      }

      // Check 4: exporter endpoint posture.
      for (var ep = 0; ep < parsed.endpoints.length; ep++) {
        var endpoint = parsed.endpoints[ep];
        if (/^http:\/\//i.test(endpoint.value)) {
          add("WARNING", "Exporter '" + endpoint.exporter + "' endpoint '" + endpoint.value + "' uses plaintext http:// — traffic to it is unencrypted.", endpoint.line);
        }
      }
      for (var ename in sections.exporters) {
        if (!parsed.exporterHasEndpoint[ename] && !KNOWN_EXPORTERS[baseType(ename)]) {
          add("INFO", "Endpoint posture for exporter '" + ename + "' was NOT PARSED: the exporter type is not one this auditor recognizes and no endpoint field was found — no default is assumed.", sections.exporters[ename].line);
        }
      }

      // Check 5: memory protection — memory_limiter defined AND used.
      var memoryDefinedAndUsed = false;
      for (var mname in sections.processors) {
        if (baseType(mname) === "memory_limiter" && used.processors[mname]) memoryDefinedAndUsed = true;
      }
      if (!memoryDefinedAndUsed && !memoryReferenced) {
        add("WARNING", "No memory_limiter processor is defined and used in any pipeline — the collector has no memory protection against out-of-memory kills under load.", null);
      }

      // Check 6: traces pipeline without a batch processor (one INFO each).
      for (var t = 0; t < tracesMissingBatch.length; t++) {
        add("INFO", "Traces pipeline '" + tracesMissingBatch[t].name + "' uses no batch processor — spans are exported one by one, which costs far more network and CPU than batching.", tracesMissingBatch[t].line);
      }

      // Check 7: debug exporter in use (one INFO).
      if (debugPipelines.length) {
        var dbgNames = [];
        for (var dg = 0; dg < debugPipelines.length; dg++) dbgNames.push("'" + debugPipelines[dg].pipeline + "'");
        add("INFO", "Debug exporter is used in pipeline" + (debugPipelines.length > 1 ? "s" : "") + " " + dbgNames.join(", ") + " — debug output is verbose in production and writes every payload to the log.", debugPipelines[0].line);
      }

      // NOT PARSED lines are reported, never guessed.
      for (var np = 0; np < parsed.notParsed.length; np++) {
        var npl = parsed.notParsed[np];
        add("NOT PARSED", "Line could not be read (" + npl.reason + "): \"" + (npl.text.length > 80 ? npl.text.slice(0, 80) + "…" : npl.text) + "\"", npl.line);
      }

      var sevRank = { "BLOCKER": 0, "WARNING": 1, "INFO": 2, "NOT PARSED": 3 };
      findings.sort(function (a, b2) {
        if (sevRank[a.severity] !== sevRank[b2.severity]) return sevRank[a.severity] - sevRank[b2.severity];
        return (a.line || 0) - (b2.line || 0);
      });

      var blockers = 0, warnings = 0;
      for (var f = 0; f < findings.length; f++) {
        if (findings[f].severity === "BLOCKER") blockers++;
        if (findings[f].severity === "WARNING") warnings++;
      }
      var verdict, reason;
      if (blockers > 0) {
        verdict = "DO NOT DEPLOY";
        reason = blockers + " blocker" + (blockers > 1 ? "s" : "") + " would stop this collector from starting or silently drop a pipeline. Fix every blocker first.";
      } else if (warnings > 0) {
        verdict = "DEPLOY WITH FIXES";
        reason = "Nothing here blocks startup, but " + warnings + " warning" + (warnings > 1 ? "s" : "") + " should be fixed before this runs in production.";
      } else {
        verdict = "READY TO DEPLOY";
        reason = "Every pipeline reference resolves, endpoints and memory posture check out, and nothing unreadable was found in the parts this audit reads.";
      }
      return { verdict: verdict, reason: reason, findings: findings, parsed: parsed };
    }
    /*AUDIT-CORE-END*/

    var WORKED_EXAMPLE = [
      "receivers:",
      "  otlp:",
      "    protocols:",
      "      grpc:",
      "      http:",
      "  hostmetrics:",
      "    collection_interval: 10s",
      "    scrapers:",
      "      cpu:",
      "      memory:",
      "",
      "processors:",
      "  batch:",
      "",
      "exporters:",
      "  otlp:",
      "    endpoint: http://collector.example.com:4317",
      "  debug:",
      "",
      "extensions:",
      "  health_check:",
      "",
      "service:",
      "  pipelines:",
      "    traces:",
      "      receivers: [otlp]",
      "      processors: [batch, memory_limiter]",
      "      exporters: [otlp]",
      "    metrics:",
      "      receivers: [hostmetrics]",
      "      exporters: [debug]"
    ].join("\n");

    var CLEAN_EXAMPLE = [
      "receivers:",
      "  otlp:",
      "    protocols:",
      "      grpc:",
      "      http:",
      "",
      "processors:",
      "  memory_limiter:",
      "    check_interval: 1s",
      "    limit_mib: 512",
      "  batch:",
      "",
      "exporters:",
      "  otlp:",
      "    endpoint: https://collector.example.com:4317",
      "",
      "extensions:",
      "  health_check:",
      "",
      "service:",
      "  extensions: [health_check]",
      "  pipelines:",
      "    traces:",
      "      receivers: [otlp]",
      "      processors: [memory_limiter, batch]",
      "      exporters: [otlp]",
      "    metrics:",
      "      receivers: [otlp]",
      "      processors: [batch]",
      "      exporters: [otlp]"
    ].join("\n");
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "WORKED_EXAMPLE": (typeof WORKED_EXAMPLE !== 'undefined' ? WORKED_EXAMPLE : undefined), "CLEAN_EXAMPLE": (typeof CLEAN_EXAMPLE !== 'undefined' ? CLEAN_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-opentelemetry-collector-config-auditor',
  name: 'J-Dawgs OpenTelemetry Collector Config Auditor',
  description: 'otelcol validation needs the binary and a live pipeline; this audits a pasted collector config anywhere, wiring every pipeline reference and grading endpoint and memory posture into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "WORKED_EXAMPLE": __core["WORKED_EXAMPLE"], "CLEAN_EXAMPLE": __core["CLEAN_EXAMPLE"] }
};
