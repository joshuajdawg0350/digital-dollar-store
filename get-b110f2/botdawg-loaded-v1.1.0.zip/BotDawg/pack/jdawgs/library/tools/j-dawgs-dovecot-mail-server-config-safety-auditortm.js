'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Dovecot Mail Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

var RISKY = [
"# Risky example — graded DO NOT DEPLOY. Do not ship a config like this.",
"protocols = imap pop3 lmtp",
"listen = *",
"disable_plaintext_auth = no",
"ssl = yes",
"ssl_cert = </etc/dovecot/certs/mail.example.net.pem",
"ssl_key = </etc/dovecot/private/mail.example.net.key",
"ssl_key_password = PlantedSecret-7391",
"ssl_min_protocol = TLSv1.0",
"ssl_prefer_server_ciphers = no",
"auth_mechanisms = plain login cram-md5",
"auth_verbose = yes",
"auth_debug = yes",
"mail_debug = yes",
"mail_privileged_group = mail",
"service imap-login {",
"  inet_listener imap {",
"    port = 143",
"  }",
"  inet_listener imaps {",
"    port = 993",
"    ssl = yes",
"  }",
"}",
"service auth {",
"  user = root",
"}"
].join("\n");

var HARDENED = [
"# Hardened example — graded SAFE TO DEPLOY.",
"protocols = imap lmtp submission",
"listen = *",
"disable_plaintext_auth = yes",
"ssl = required",
"ssl_cert = </etc/dovecot/certs/mail.example.net.pem",
"ssl_key = </etc/dovecot/private/mail.example.net.key",
"ssl_min_protocol = TLSv1.2",
"ssl_prefer_server_ciphers = yes",
"auth_mechanisms = plain login",
"auth_verbose = no",
"auth_debug = no",
"mail_debug = no",
"service imap-login {",
"  inet_listener imaps {",
"    port = 993",
"    ssl = yes",
"  }",
"}",
"service auth {",
"  user = dovecot",
"}"
].join("\n");

var KNOWN = {};
[
"protocols","disable_plaintext_auth","auth_allow_cleartext","ssl","ssl_cert","ssl_key","ssl_ca_file",
"ssl_min_protocol","ssl_prefer_server_ciphers","ssl_cipher_list","ssl_options","ssl_dh","ssl_key_password",
"ssl_cert_username_field","ssl_verify_client_cert","auth_ssl_require_client_cert","auth_ssl_username_from_cert",
"auth_mechanisms","auth_verbose","auth_debug","auth_debug_passwords","auth_realms","auth_username_chars",
"auth_username_translation","auth_cache_size","auth_cache_ttl","auth_socket_path","master_user_separator",
"mail_privileged_group","mail_access_groups","mail_location","mail_uid","mail_gid","mail_debug",
"mail_chroot","mail_attachment_dir","mail_attachment_min_size","mail_attachment_hash","mailbox_list_layout",
"listen","base_dir","login_greeting","login_trusted_networks","imap_capability","pop3_uidl_format",
"submission_relay_host","submission_relay_port","submission_relay_trusted","hostname","postmaster_address",
"first_valid_uid","last_valid_uid","first_valid_gid","last_valid_gid","valid_chroot_dirs",
"verbose_proctitle","shutdown_clients","doveadm_worker_count","lmtp_save_to_detail_mailbox",
"recipient_delimiter","lda_mailbox_autocreate","lda_mailbox_autosubscribe","sieve","managesieve_title",
"service_count","process_min_avail","process_limit","client_limit","vsz_limit","idle_kill",
"args","driver","default_fields","override_fields","skip","deny","master","pass","inbox","location",
"separator","prefix","type","mailbox","comment","special_use","quota_max_mail_size","dict","plugin",
"fts","fts_languages","fts_language_config","remote_ip","local_ip","port","address","user","group","mode",
"chroot","executable","inet_listener","unix_listener","fifo_listener","service","protocol","namespace",
"passdb","userdb","mailbox_driver","storage","control","alt","listescape_char","hidden","subscriptions"
].forEach(function(k){ KNOWN[k]=true; });

var SECRET_KEY_RE = /(password|passwd|secret|api[_-]?key|shared[_-]?secret|access[_-]?token)/i;

function isSecretLine(key, raw){
  if(/BEGIN [A-Z ]*PRIVATE KEY/.test(raw)) return true;
  if(key && SECRET_KEY_RE.test(key)) return true;
  var m = raw.match(/[\s{](password|passwd|secret|api_key)\s*=\s*\S+/i);
  if(m) return true;
  return false;
}
function quoteFor(rec){
  if(rec.secret) return rec.key + " = [REDACTED — value never shown]";
  var t = rec.raw.trim();
  if(t.length > 120) t = t.slice(0,117) + "...";
  return t;
}
function tlsRank(v){
  var map = {"sslv2":0,"sslv3":1,"tlsv1":2,"tlsv1.0":2,"tlsv1.1":3,"tlsv1.2":4,"tlsv1.3":5};
  var k = String(v||"").toLowerCase();
  return (k in map) ? map[k] : null;
}
function yes(v){ return String(v||"").toLowerCase() === "yes" || String(v||"").toLowerCase() === "true"; }
function no(v){ return String(v||"").toLowerCase() === "no" || String(v||"").toLowerCase() === "false"; }

function parse(text){
  var lines = text.split(/\r?\n/);
  var records = [];      // key=value records
  var includes = [];     // !include lines
  var commented = [];    // commented-out directives
  var stack = [];        // block context stack
  var ports = [];        // port records inside inet_listener
  var serviceUsers = []; // user records inside service blocks
  for(var i=0;i<lines.length;i++){
    var lineNo = i+1;
    var raw = lines[i];
    var trimmed = raw.trim();
    if(trimmed === "") continue;
    if(trimmed.charAt(0) === "#"){
      var cm = trimmed.match(/^#\s*([a-zA-Z_][a-zA-Z0-9_]*)\s*=/);
      if(cm) commented.push({line:lineNo, key:cm[1]});
      continue;
    }
    var inc = trimmed.match(/^!include\s+(.+)$/);
    if(inc){ includes.push({line:lineNo, target:inc[1].trim()}); continue; }
    if(/^\}/.test(trimmed)){ stack.pop(); continue; }
    var block = trimmed.match(/^([a-zA-Z_][a-zA-Z0-9_-]*)(?:\s+([^{]+?))?\s*\{\s*$/);
    if(block){
      stack.push((block[1] + (block[2] ? " " + block[2].trim() : "")).trim());
      continue;
    }
    var kv = trimmed.match(/^([a-zA-Z_][a-zA-Z0-9_]*)\s*=\s*(.*)$/);
    if(kv){
      var key = kv[1], value = kv[2].trim();
      var ctx = stack.join(" > ");
      var rec = {line:lineNo, key:key, value:value, raw:raw, ctx:ctx, secret:isSecretLine(key, raw)};
      records.push(rec);
      if(key === "port" && /inet_listener/.test(ctx)) ports.push(rec);
      if(key === "user" && /^service/.test(ctx)) serviceUsers.push(rec);
      continue;
    }
    if(/^[a-zA-Z_][a-zA-Z0-9_-]*\s*\{/.test(trimmed)){ stack.push(trimmed.replace(/\{\s*$/,"").trim()); continue; }
  }
  return {records:records, includes:includes, commented:commented, ports:ports, serviceUsers:serviceUsers};
}

function audit(text){
  var findings = [];
  function add(sev, line, label, quoted, issue, fix){
    findings.push({sev:sev, line:line, label:label, quoted:quoted, issue:issue, fix:fix});
  }
  var p = parse(text);
  var eff = {};   // top-level effective values, last wins
  var seen = {};  // context|key -> first record (duplicates)
  p.records.forEach(function(rec){
    var id = rec.ctx + "|" + rec.key;
    if(seen[id]){
      add("WARNING", rec.line, "Duplicate key",
        quoteFor(rec),
        "“" + rec.key + "” is set twice in the same block — first on line " + seen[id].line + ", again on line " + rec.line + ". Dovecot grading here is last-value-wins, so line " + rec.line + " is the value that counts.",
        "Delete the stale line " + seen[id].line + " entry so only one value for " + rec.key + " remains.");
    } else {
      seen[id] = rec;
    }
    if(rec.ctx === "") eff[rec.key] = rec;
    if(rec.secret){
      add("WARNING", rec.line, "Secret in config text",
        rec.key + " = [REDACTED — value never shown]",
        "Line " + rec.line + " carries a secret-shaped value under “" + rec.key + "”. The value is not shown anywhere in this audit. If this text was pasted anywhere shared, treat that secret as exposed.",
        "Move the secret into a root-only file (mode 0600) referenced by path, and rotate it if it ever left the server.");
    }
    if(!KNOWN[rec.key]){
      add("INFO", rec.line, "NOT AUDITED",
        rec.key,
        "“" + rec.key + "” is not in this tool’s rule set, so it was NOT AUDITED. No judgement is made about it — it is named, never guessed at.",
        "Check this directive against the Dovecot documentation for your version before deploying.");
    }
  });
  p.includes.forEach(function(inc){
    add("WARNING", inc.line, "NOT CHECKED",
      "!include " + inc.target,
      "This file is pulled in by !include, but its contents cannot be seen from the pasted text, so everything in it is NOT CHECKED — including any plaintext-auth or TLS settings it may override.",
      "Paste the contents of " + inc.target + " into the config and re-run the audit so those lines are graded too.");
  });
  p.commented.forEach(function(c){
    add("INFO", c.line, "Commented out",
      "# " + c.key + " = …",
      "“" + c.key + "” on line " + c.line + " is commented out, so it is treated as unset — it provides no protection.",
      "If you rely on this setting, uncomment it and set the value deliberately.");
  });

  // Listener locality
  var listenRec = eff["listen"];
  var localOnly = false;
  if(listenRec){
    var lv = listenRec.value.replace(/\s+/g,"");
    if(lv === "127.0.0.1" || lv === "localhost" || lv === "::1" || lv === "127.0.0.1,::1") localOnly = true;
  }
  var nonLocal = !localOnly; // Dovecot's default listen is all interfaces

  // Plaintext auth
  var dpa = eff["disable_plaintext_auth"];
  var plaintextAllowed;
  if(!dpa){
    plaintextAllowed = true;
    add("WARNING", null, "Plaintext auth — NOT SETTLED",
      "disable_plaintext_auth (not present)",
      "disable_plaintext_auth is not set in the pasted text, so its effective value is NOT SETTLED here — it depends on your Dovecot version’s default and on any !include files this audit cannot see. Do not assume plaintext logins are disabled.",
      "Set disable_plaintext_auth = yes explicitly.");
  } else if(no(dpa.value)){
    plaintextAllowed = true;
    if(nonLocal){
      add("BLOCKER", dpa.line, "Plaintext auth allowed",
        quoteFor(dpa),
        "disable_plaintext_auth = no lets clients send passwords in cleartext, and the listeners are not restricted to localhost (Dovecot listens on all interfaces unless listen says otherwise), so credentials can cross the network unencrypted.",
        "Set disable_plaintext_auth = yes so passwords are only accepted over TLS or from localhost.");
    } else {
      add("WARNING", dpa.line, "Plaintext auth allowed (local only)",
        quoteFor(dpa),
        "disable_plaintext_auth = no permits cleartext passwords. Listeners appear localhost-only in this text, which limits exposure, but any future listener change exposes credentials.",
        "Set disable_plaintext_auth = yes unless a named local-only service truly needs cleartext.");
    }
  } else if(yes(dpa.value)){
    plaintextAllowed = false;
    add("INFO", dpa.line, "Plaintext auth disabled",
      quoteFor(dpa),
      "disable_plaintext_auth = yes: passwords are refused on unencrypted connections. Good posture.",
      "No change needed.");
  } else {
    plaintextAllowed = true;
    add("WARNING", dpa.line, "Plaintext auth — NOT SETTLED",
      quoteFor(dpa),
      "The value of disable_plaintext_auth is not a recognised yes/no in this text, so plaintext-auth posture is NOT SETTLED.",
      "Set disable_plaintext_auth = yes explicitly.");
  }

  var acc = eff["auth_allow_cleartext"];
  if(acc && yes(acc.value)){
    if(nonLocal && plaintextAllowed){
      add("BLOCKER", acc.line, "Cleartext logins allowed",
        quoteFor(acc),
        "auth_allow_cleartext = yes explicitly permits cleartext logins on listeners that are not localhost-only.",
        "Remove auth_allow_cleartext or set it to no, and require TLS.");
    } else {
      add("WARNING", acc.line, "Cleartext logins allowed",
        quoteFor(acc),
        "auth_allow_cleartext = yes permits cleartext logins in the contexts where it applies.",
        "Remove auth_allow_cleartext or set it to no unless a named local service requires it.");
    }
  }

  // TLS posture
  var sslRec = eff["ssl"];
  var sslMode = sslRec ? String(sslRec.value).toLowerCase() : null;
  if(!sslRec){
    add("WARNING", null, "TLS — NOT SETTLED",
      "ssl (not present)",
      "No top-level ssl setting appears in the pasted text, so whether TLS is required is NOT SETTLED by this text.",
      "Set ssl = required explicitly.");
  } else if(sslMode === "no"){
    add("BLOCKER", sslRec.line, "TLS disabled",
      quoteFor(sslRec),
      "ssl = no turns TLS off entirely. Combined with any plaintext login path, passwords and mail cross the network in cleartext.",
      "Set ssl = required and configure ssl_cert and ssl_key.");
  } else if(sslMode === "yes" || sslMode === "optional"){
    add("WARNING", sslRec.line, "TLS optional, not required",
      quoteFor(sslRec),
      "ssl = " + sslRec.value + " allows TLS but does not require it — clients can still connect without encryption, and plaintext ports stay useful to an attacker.",
      "Set ssl = required so unencrypted connections are refused.");
  } else if(sslMode === "required"){
    add("INFO", sslRec.line, "TLS required",
      quoteFor(sslRec),
      "ssl = required: unencrypted connections are refused. Good posture.",
      "No change needed.");
  }
  var sslOn = sslMode === "yes" || sslMode === "required" || sslMode === "optional";
  if(sslOn){
    ["ssl_cert","ssl_key"].forEach(function(k){
      var r = eff[k];
      if(!r || r.value === ""){
        add("WARNING", r ? r.line : null, "TLS file setting missing — NOT SETTLED",
          k + " (not set)",
          k + " is not set while SSL is on, so the TLS setup is NOT SETTLED by this text — Dovecot may fail to start or fall back to an unexpected certificate. This audit also cannot see inside certificate or key files; a path in the text would not prove the file is valid.",
          "Set " + k + " = <</path/to/file and confirm the file exists, is readable only as needed, and matches the certificate.");
      } else {
        add("INFO", r.line, "TLS file path present",
          quoteFor(r),
          k + " is set in the text. The file it points at cannot be seen or validated from a paste — this is presence only, not verification.",
          "Confirm the file exists on the server and, for ssl_key, that its permissions are root-only.");
      }
    });
  }
  var minProto = eff["ssl_min_protocol"];
  if(minProto){
    var rank = tlsRank(minProto.value);
    if(rank !== null && rank < 4){
      add("WARNING", minProto.line, "TLS version floor too low",
        quoteFor(minProto),
        "ssl_min_protocol = " + minProto.value + " permits TLS versions below 1.2, which carry known weaknesses.",
        "Set ssl_min_protocol = TLSv1.2 (TLSv1.3 is also fine).");
    } else if(rank !== null){
      add("INFO", minProto.line, "TLS version floor OK",
        quoteFor(minProto),
        "ssl_min_protocol = " + minProto.value + " sets the floor at TLS 1.2 or better.",
        "No change needed.");
    } else {
      add("WARNING", minProto.line, "TLS floor — NOT SETTLED",
        quoteFor(minProto),
        "The ssl_min_protocol value “" + minProto.value + "” is not a recognised protocol name in this tool’s rule set, so the TLS floor is NOT SETTLED.",
        "Set ssl_min_protocol = TLSv1.2 explicitly.");
    }
  } else if(sslOn){
    add("WARNING", null, "TLS floor — NOT SETTLED",
      "ssl_min_protocol (not present)",
      "ssl_min_protocol is not set while SSL is on, so the minimum TLS version depends on version defaults this audit cannot see — NOT SETTLED.",
      "Set ssl_min_protocol = TLSv1.2 explicitly.");
  }
  var psc = eff["ssl_prefer_server_ciphers"];
  if(psc && no(psc.value)){
    add("WARNING", psc.line, "Cipher preference (heuristic)",
      quoteFor(psc),
      "Heuristic: ssl_prefer_server_ciphers = no lets the client pick the cipher, so a weak client choice can win. This is a text-level heuristic, not a cipher-suite test.",
      "Set ssl_prefer_server_ciphers = yes so the server’s stronger ordering wins.");
  } else if(psc && yes(psc.value)){
    add("INFO", psc.line, "Cipher preference (heuristic)",
      quoteFor(psc),
      "Heuristic: ssl_prefer_server_ciphers = yes — the server’s cipher ordering wins. The actual cipher list itself is not tested by a text audit.",
      "No change needed.");
  }
  var cipherList = eff["ssl_cipher_list"];
  if(cipherList && /(RC4|3DES|DES|MD5|aNULL|eNULL|EXPORT|LOW)/i.test(cipherList.value)){
    add("WARNING", cipherList.line, "Weak cipher names (heuristic)",
      quoteFor(cipherList),
      "Heuristic: ssl_cipher_list names cipher families commonly classed as weak (RC4/DES/3DES/MD5/NULL/EXPORT/LOW). A text audit can flag the names; it cannot test what the server actually negotiates.",
      "Remove the weak families from ssl_cipher_list and prefer a modern, maintained cipher string.");
  }

  // Auth mechanisms
  var mech = eff["auth_mechanisms"];
  if(mech){
    var tokens = mech.value.toLowerCase().split(/\s+/);
    var hasPlain = tokens.indexOf("plain") >= 0 || tokens.indexOf("login") >= 0;
    if(hasPlain && plaintextAllowed && nonLocal){
      add("BLOCKER", mech.line, "Plaintext mechanisms + plaintext allowed",
        quoteFor(mech) + "  ‖  line " + (dpa ? dpa.line : "—") + ": disable_plaintext_auth",
        "auth_mechanisms offers plain/login (line " + mech.line + ") while plaintext authentication is allowed (disable_plaintext_auth, line " + (dpa ? dpa.line : "not set") + ") on non-local listeners. Together they invite cleartext password theft.",
        "Set disable_plaintext_auth = yes and ssl = required; keep plain/login only behind TLS, or drop them for stronger mechanisms.");
    } else if(hasPlain){
      add("INFO", mech.line, "Plaintext mechanisms behind TLS controls",
        quoteFor(mech),
        "auth_mechanisms offers plain/login, but plaintext auth is disabled in this text, so those mechanisms only run over protected connections. That is the normal, acceptable arrangement.",
        "Keep disable_plaintext_auth = yes and ssl = required so this stays true.");
    }
    if(tokens.indexOf("cram-md5") >= 0 || tokens.indexOf("digest-md5") >= 0){
      add("INFO", mech.line, "Legacy auth mechanisms",
        quoteFor(mech),
        "CRAM-MD5 / DIGEST-MD5 are legacy challenge-response mechanisms: they avoid sending the password itself but force servers to store passwords in recoverable form. Noted as legacy, not a blocker.",
        "Prefer plain/login over enforced TLS, or a modern SCRAM mechanism, and plan migration off CRAM-MD5/DIGEST-MD5.");
    }
  } else {
    add("INFO", null, "Auth mechanisms — NOT SETTLED",
      "auth_mechanisms (not present)",
      "auth_mechanisms is not set in the pasted text, so the offered mechanisms depend on defaults this audit cannot see — NOT SETTLED.",
      "Set auth_mechanisms explicitly so the offered set is a deliberate choice.");
  }

  // Protocols / POP3 / submission
  var proto = eff["protocols"];
  if(proto){
    var ptoks = proto.value.toLowerCase().split(/\s+/);
    if(ptoks.indexOf("pop3") >= 0){
      add("INFO", proto.line, "POP3 enabled (legacy)",
        quoteFor(proto),
        "POP3 is enabled. It is a legacy protocol: it works, but it expands the attack surface and its plaintext port (110) is a common cleartext-login path.",
        "If no client needs POP3, remove pop3 from protocols. Otherwise require TLS for it exactly as for IMAP.");
    }
    if(ptoks.indexOf("submission") >= 0){
      add("INFO", proto.line, "Submission service enabled",
        quoteFor(proto),
        "The submission service is enabled. Its safety depends on SASL authentication being required and on TLS — this text audit can note the service but cannot test a live SASL login.",
        "Require authentication and TLS on submission (port 587), and never relay unauthenticated mail.");
    }
  }

  // Listeners / ports
  p.ports.forEach(function(pr){
    var pv = pr.value.trim();
    if(pv === "143"){
      if(plaintextAllowed){
        add("WARNING", pr.line, "Plaintext IMAP port 143 offered",
          quoteFor(pr) + "  (in " + pr.ctx + ")",
          "An inet_listener offers IMAP on port 143 — the plaintext port — while plaintext authentication is allowed. That combination is exactly how cleartext credentials get captured.",
          "Set disable_plaintext_auth = yes and ssl = required, or remove the port 143 listener and serve IMAPS on 993 only.");
      } else {
        add("INFO", pr.line, "IMAP port 143 offered",
          quoteFor(pr) + "  (in " + pr.ctx + ")",
          "Port 143 is offered, but plaintext auth is disabled in this text, so 143 can only be used to upgrade via STARTTLS. Acceptable when TLS is required.",
          "Keep ssl = required so 143 never serves a cleartext login.");
      }
    } else if(pv === "110"){
      add("WARNING", pr.line, "Plaintext POP3 port 110 offered",
        quoteFor(pr) + "  (in " + pr.ctx + ")",
        "An inet_listener offers POP3 on port 110, the plaintext POP3 port. If any cleartext login path remains, credentials are exposed.",
        "Serve POP3S on 995 with TLS required, or drop POP3 if no client needs it.");
    }
  });

  // Privilege
  var mpg = eff["mail_privileged_group"];
  if(mpg){
    if(mpg.value.trim().toLowerCase() === "root"){
      add("WARNING", mpg.line, "Privileged group is root",
        quoteFor(mpg),
        "mail_privileged_group = root hands mail processes a group with full system privilege — far more than mail delivery needs.",
        "Use a dedicated group (commonly mail) for mail_privileged_group.");
    } else {
      add("INFO", mpg.line, "Privileged group named",
        quoteFor(mpg),
        "mail_privileged_group is set to “" + mpg.value.trim() + "”. Processes delivering to system mailboxes get this group’s access — confirm every member of that group is intentional.",
        "Keep the group membership minimal and mail-only.");
    }
  }
  p.serviceUsers.forEach(function(su){
    if(su.value.trim().toLowerCase() === "root"){
      add("WARNING", su.line, "Service runs as root",
        quoteFor(su) + "  (in " + su.ctx + ")",
        "The service “" + su.ctx + "” runs as user root. A flaw in that service is then a root compromise, not a mail-only one. (Dovecot’s master process starts as root and drops privilege per service — a service explicitly pinned to root keeps it.)",
        "Run the service as a dedicated unprivileged user (for example dovecot or dovenull) unless the service is the one component that genuinely requires root.");
    }
  });

  // Verbose / debug logging
  [["auth_verbose","auth_verbose = yes logs authentication attempts in detail; usernames, IPs, and failure reasons land in logs that are often shipped to third-party log systems."],
   ["auth_debug","auth_debug = yes turns on deep auth debugging — the output can include the data exchanged during login attempts."],
   ["auth_debug_passwords","auth_debug_passwords = yes can write actual passwords into the debug log. That is a credential store you never meant to keep."],
   ["mail_debug","mail_debug = yes turns on verbose mail debugging, which can surface mailbox paths, user data, and session detail in logs."]]
  .forEach(function(pair){
    var r = eff[pair[0]];
    if(r && yes(r.value)){
      add("WARNING", r.line, "Verbose/debug logging on",
        quoteFor(r),
        pair[1] + " Credential leakage into logs is the risk.",
        "Set " + pair[0] + " = no in production. Turn it on only briefly, on purpose, and scrub the logs afterwards.");
    }
  });

  findings.sort(function(a,b){
    var la = (a.line === null ? 9999 : a.line), lb = (b.line === null ? 9999 : b.line);
    var sevRank = {BLOCKER:0, WARNING:1, INFO:2};
    if(la !== lb) return la - lb;
    return sevRank[a.sev] - sevRank[b.sev];
  });
  // Blockers first overall for the verdict summary order in report? Keep line order in UI; report groups by line too.
  var blockers = findings.filter(function(f){return f.sev==="BLOCKER";}).length;
  var warnings = findings.filter(function(f){return f.sev==="WARNING";}).length;
  var infos = findings.filter(function(f){return f.sev==="INFO";}).length;
  var verdict = blockers > 0 ? "DO NOT DEPLOY" : (warnings > 0 ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY");
  return {verdict:verdict, findings:findings, blockers:blockers, warnings:warnings, infos:infos};
}

function esc(s){
  return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
}
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-dovecot-mail-server-config-safety-auditortm',
  name: 'J-Dawgs Dovecot Mail Server Config Safety Auditor',
  description: 'Paste a Dovecot config, get one deploy verdict: plaintext auth, TLS posture, debug logging and privilege graded line by line — doveconf only tells you the config loads.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
