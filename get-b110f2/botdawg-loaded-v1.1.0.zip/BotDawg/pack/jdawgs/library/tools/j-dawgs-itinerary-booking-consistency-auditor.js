'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Itinerary & Booking Consistency Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var TYPES = ["FLIGHT", "HOTEL", "TRAIN", "BUS", "TRANSFER", "EVENT", "OTHER"];
        var PRESENCE = { FLIGHT: 1, TRAIN: 1, BUS: 1, TRANSFER: 1, EVENT: 1 };
        var ARRIVAL_TYPES = { FLIGHT: 1, TRAIN: 1, BUS: 1 };

        var WORKED_EXAMPLE = [
          "# Worked example — three problems planted on purpose",
          "FLIGHT | UA 2416 Denver to Chicago | 2026-12-10 13:05 | 2026-12-10 17:40 | America/Chicago |",
          "FLIGHT | UA 1187 Chicago to Springfield | 2026-12-10 18:15 | 2026-12-10 19:20 | America/Chicago |",
          "HOTEL | Riverwalk Hotel, Springfield | 2026-12-10 20:00 | 2026-12-12 11:00 | America/Chicago | nights: 3",
          "EVENT | Client dinner | 2026-12-10 17:00 |  | America/Chicago |"
        ].join("\n");

        var CLEAN_EXAMPLE = [
          "# Clean example — everything lines up",
          "FLIGHT | UA 2416 Denver to Chicago | 2026-12-10 09:05 | 2026-12-10 13:05 | America/Chicago |",
          "FLIGHT | UA 1187 Chicago to Springfield | 2026-12-10 15:05 | 2026-12-10 16:10 | America/Chicago |",
          "HOTEL | Riverwalk Hotel, Springfield | 2026-12-10 17:00 | 2026-12-12 11:00 | America/Chicago | nights: 2",
          "EVENT | Client dinner | 2026-12-10 19:00 | 2026-12-10 21:00 | America/Chicago |",
          "FLIGHT | UA 1188 Springfield to Chicago (return) | 2026-12-12 13:30 | 2026-12-12 14:35 | America/Chicago |"
        ].join("\n");

        // ---------- timezone math (Intl only, DST-honest) ----------
        var dtfCache = {};
        function getDtf(tz) {
          if (!dtfCache[tz]) {
            dtfCache[tz] = new Intl.DateTimeFormat("en-US", {
              timeZone: tz, hourCycle: "h23",
              year: "numeric", month: "2-digit", day: "2-digit",
              hour: "2-digit", minute: "2-digit", second: "2-digit"
            });
          }
          return dtfCache[tz];
        }
        function isValidZone(tz) {
          try { getDtf(tz); return true; } catch (e) { return false; }
        }
        function partsInZone(tz, ms) {
          var out = {};
          var parts = getDtf(tz).formatToParts(new Date(ms));
          for (var i = 0; i < parts.length; i++) {
            if (parts[i].type !== "literal") out[parts[i].type] = parseInt(parts[i].value, 10);
          }
          return out;
        }
        function offsetMs(tz, ms) {
          var p = partsInZone(tz, ms);
          var asUTC = Date.UTC(p.year, p.month - 1, p.day, p.hour, p.minute, p.second || 0);
          return asUTC - Math.floor(ms / 1000) * 1000;
        }
        // Convert a wall-clock time in tz to a UTC instant. Verify by formatting the
        // candidate back into the zone: if the wall time doesn't come back, it fell in
        // a DST gap and does not exist — report it, never shift it.
        function localToUtc(tz, dt) {
          var target = Date.UTC(dt.y, dt.mo - 1, dt.d, dt.h, dt.mi, 0);
          var guess = target;
          for (var i = 0; i < 4; i++) {
            var next = target - offsetMs(tz, guess);
            if (next === guess) break;
            guess = next;
          }
          var p = partsInZone(tz, guess);
          var back = Date.UTC(p.year, p.month - 1, p.day, p.hour, p.minute, p.second || 0);
          return { utcMs: guess, exists: back === target };
        }
        function pad(n) { return (n < 10 ? "0" : "") + n; }
        function fmtLocal(tz, ms) {
          var p = partsInZone(tz, ms);
          return p.year + "-" + pad(p.month) + "-" + pad(p.day) + " " + pad(p.hour) + ":" + pad(p.minute);
        }
        function fmtDateInZone(tz, ms) {
          var p = partsInZone(tz, ms);
          return p.year + "-" + pad(p.month) + "-" + pad(p.day);
        }
        function fmtHuman(tz, ms) {
          return new Intl.DateTimeFormat("en-US", {
            timeZone: tz, weekday: "short", month: "short", day: "numeric",
            hour: "numeric", minute: "2-digit", hourCycle: "h12"
          }).format(new Date(ms));
        }
        function dateStrToMs(s) {
          var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s);
          return Date.UTC(+m[1], +m[2] - 1, +m[3]);
        }
        function msToDateStr(ms) {
          var d = new Date(ms);
          return d.getUTCFullYear() + "-" + pad(d.getUTCMonth() + 1) + "-" + pad(d.getUTCDate());
        }

        // ---------- parsing ----------
        function parseDateTime(str) {
          var m = /^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})$/.exec(str);
          if (!m) return { error: "not in YYYY-MM-DD HH:MM format" };
          var y = +m[1], mo = +m[2], d = +m[3], h = +m[4], mi = +m[5];
          if (mo < 1 || mo > 12) return { error: "month " + mo + " is out of range" };
          if (h > 23) return { error: "hour " + h + " is out of range" };
          if (mi > 59) return { error: "minute " + mi + " is out of range" };
          var check = new Date(Date.UTC(y, mo - 1, d));
          if (check.getUTCFullYear() !== y || check.getUTCMonth() !== mo - 1 || check.getUTCDate() !== d) {
            return { error: "date " + m[1] + "-" + m[2] + "-" + m[3] + " does not exist" };
          }
          return { dt: { y: y, mo: mo, d: d, h: h, mi: mi } };
        }

        function parseItinerary(text, defaultZone) {
          var rawLines = text.split(/\r?\n/);
          var bookings = [];   // parsed OK (may still carry flags)
          var errors = [];     // {lineNo, reason, raw}
          for (var i = 0; i < rawLines.length; i++) {
            var lineNo = i + 1;
            var raw = rawLines[i];
            var trimmed = raw.trim();
            if (!trimmed || trimmed.charAt(0) === "#") continue;
            var fields = raw.split("|");
            for (var f = 0; f < fields.length; f++) fields[f] = fields[f].trim();
            if (fields.length < 3) {
              errors.push({ lineNo: lineNo, raw: trimmed, reason: "needs at least TYPE | label | start — only " + fields.length + " field(s) found" });
              continue;
            }
            var type = fields[0].toUpperCase();
            if (TYPES.indexOf(type) === -1) {
              errors.push({ lineNo: lineNo, raw: trimmed, reason: "unknown TYPE \"" + fields[0] + "\" (want FLIGHT, HOTEL, TRAIN, BUS, TRANSFER, EVENT, or OTHER)" });
              continue;
            }
            var label = fields[1];
            if (!label) {
              errors.push({ lineNo: lineNo, raw: trimmed, reason: "label is empty" });
              continue;
            }
            if (!fields[2]) {
              errors.push({ lineNo: lineNo, raw: trimmed, reason: "start is missing" });
              continue;
            }
            var sp = parseDateTime(fields[2]);
            if (sp.error) {
              errors.push({ lineNo: lineNo, raw: trimmed, reason: "start \"" + fields[2] + "\" " + sp.error });
              continue;
            }
            var endStr = fields.length > 3 ? fields[3] : "";
            var ep = null;
            if (endStr) {
              ep = parseDateTime(endStr);
              if (ep.error) {
                errors.push({ lineNo: lineNo, raw: trimmed, reason: "end \"" + endStr + "\" " + ep.error });
                continue;
              }
            }
            var tzField = fields.length > 4 ? fields[4] : "";
            var tz = tzField || defaultZone;
            var assumed = !tzField;
            if (!isValidZone(tz)) {
              errors.push({ lineNo: lineNo, raw: trimmed, reason: "unknown timezone \"" + tzField + "\" (want an IANA name like America/Chicago)" });
              continue;
            }
            var details = fields.length > 5 ? fields.slice(5).join(" | ") : "";

            var sConv = localToUtc(tz, sp.dt);
            var b = {
              lineNo: lineNo, type: type, label: label, details: details,
              tz: tz, assumed: assumed,
              startStr: fields[2], endStr: endStr,
              startMs: sConv.utcMs, endMs: null,
              startExists: sConv.exists, endExists: true,
              usable: sConv.exists
            };
            if (ep) {
              var eConv = localToUtc(tz, ep.dt);
              b.endMs = eConv.utcMs;
              b.endExists = eConv.exists;
              if (!eConv.exists) b.usable = false;
            }
            bookings.push(b);
          }
          return { bookings: bookings, errors: errors };
        }

        // ---------- checks ----------
        function audit(text, defaultZone, minConnect) {
          var parsed = parseItinerary(text, defaultZone);
          var bookings = parsed.bookings;
          var findings = [];
          function add(sev, lineNos, head, text) {
            findings.push({ sev: sev, lines: lineNos, head: head, text: text });
          }
          function ref(b) { return "\"" + b.label + "\" (line " + b.lineNo + ")"; }

          var usable = [];
          var i, j, b;

          // Per-line: nonexistent local times + assumed zones + end before start
          for (i = 0; i < bookings.length; i++) {
            b = bookings[i];
            if (!b.startExists) {
              add("BLOCKER", [b.lineNo], "NONEXISTENT LOCAL TIME",
                ref(b) + " starts at " + b.startStr + " in " + b.tz + ", a local time that never occurs (it falls in a daylight-saving gap). The line was not shifted or guessed — fix the time or the zone. The line is excluded from the cross-checks.");
            }
            if (b.endStr && !b.endExists) {
              add("BLOCKER", [b.lineNo], "NONEXISTENT LOCAL TIME",
                ref(b) + " ends at " + b.endStr + " in " + b.tz + ", a local time that never occurs (it falls in a daylight-saving gap). The line was not shifted or guessed — fix the time or the zone. The line is excluded from the cross-checks.");
            }
            if (b.assumed) {
              add("NOTE", [b.lineNo], "TIMEZONE ASSUMED",
                ref(b) + " names no timezone, so it was computed in the default zone " + b.tz + ".");
            }
            if (b.usable && b.endMs !== null && b.endMs < b.startMs) {
              add("BLOCKER", [b.lineNo], "END BEFORE START",
                ref(b) + " ends at " + fmtLocal(b.tz, b.endMs) + " " + b.tz + ", before it starts at " + fmtLocal(b.tz, b.startMs) + " " + b.tz + ".");
              b.badInterval = true;
            }
            if (b.usable && !b.badInterval) usable.push(b);
          }

          // Duplicates: same type, label, start
          var seen = {};
          for (i = 0; i < bookings.length; i++) {
            b = bookings[i];
            var key = b.type + "||" + b.label.toLowerCase() + "||" + b.startStr;
            if (seen[key]) {
              add("WARNING", [seen[key].lineNo, b.lineNo], "POSSIBLE DOUBLE BOOKING",
                ref(b) + " duplicates " + ref(seen[key]) + " — same type, label, and start (" + b.startStr + ").");
            } else {
              seen[key] = b;
            }
          }

          // Return / homeward leg starting before the outward leg ends
          var returnPairs = {};
          var legs = usable.filter(function (x) { return ARRIVAL_TYPES[x.type]; });
          for (i = 0; i < legs.length; i++) {
            var leg = legs[i];
            if (!/return|homeward/i.test(leg.label)) continue;
            var outward = null;
            for (j = 0; j < legs.length; j++) {
              var o = legs[j];
              if (o === leg || o.type !== leg.type) continue;
              if (!outward || o.startMs < outward.startMs) outward = o;
            }
            if (outward && outward.endMs !== null && leg.startMs < outward.endMs) {
              add("BLOCKER", [outward.lineNo, leg.lineNo], "RETURN LEG LEAVES BEFORE OUTWARD LEG LANDS",
                "Return leg " + ref(leg) + " starts at " + fmtLocal(leg.tz, leg.startMs) + " " + leg.tz + ", before the outward leg " + ref(outward) + " ends at " + fmtLocal(outward.tz, outward.endMs) + " " + outward.tz + ".");
              returnPairs[outward.lineNo + ":" + leg.lineNo] = true;
              returnPairs[leg.lineNo + ":" + outward.lineNo] = true;
            }
          }

          // Overlaps between presence-demanding bookings + EVENT during a FLIGHT
          var presence = usable.filter(function (x) { return PRESENCE[x.type]; });
          for (i = 0; i < presence.length; i++) {
            for (j = i + 1; j < presence.length; j++) {
              var a = presence[i], c = presence[j];
              if (returnPairs[a.lineNo + ":" + c.lineNo]) continue;
              var overlap = false, pointIn = null, ranged = null;
              if (a.endMs !== null && c.endMs !== null) {
                overlap = a.startMs < c.endMs && c.startMs < a.endMs;
              } else if (a.endMs === null && c.endMs !== null) {
                if (a.startMs >= c.startMs && a.startMs < c.endMs) { overlap = true; pointIn = a; ranged = c; }
              } else if (c.endMs === null && a.endMs !== null) {
                if (c.startMs >= a.startMs && c.startMs < a.endMs) { overlap = true; pointIn = c; ranged = a; }
              }
              if (!overlap) continue;
              if (pointIn && pointIn.type === "EVENT" && ranged.type === "FLIGHT") {
                add("BLOCKER", [pointIn.lineNo, ranged.lineNo], "EVENT SCHEDULED WHILE A FLIGHT IS IN THE AIR",
                  "EVENT " + ref(pointIn) + " is at " + fmtLocal(pointIn.tz, pointIn.startMs) + " " + pointIn.tz + ", while FLIGHT " + ref(ranged) + " is still in the air (it lands at " + fmtLocal(ranged.tz, ranged.endMs) + " " + ranged.tz + ").");
              } else if (pointIn) {
                add("BLOCKER", [pointIn.lineNo, ranged.lineNo], "OVERLAPPING BOOKINGS",
                  ref(pointIn) + " falls at " + fmtLocal(pointIn.tz, pointIn.startMs) + " " + pointIn.tz + ", inside " + ref(ranged) + " (" + fmtLocal(ranged.tz, ranged.startMs) + " – " + fmtLocal(ranged.tz, ranged.endMs) + " " + ranged.tz + "). Both demand the traveler's presence.");
              } else {
                var first = a.startMs <= c.startMs ? a : c;
                var second = first === a ? c : a;
                add("BLOCKER", [a.lineNo, c.lineNo], "OVERLAPPING BOOKINGS",
                  ref(first) + " (" + fmtLocal(first.tz, first.startMs) + " – " + fmtLocal(first.tz, first.endMs) + " " + first.tz + ") overlaps " + ref(second) + " (" + fmtLocal(second.tz, second.startMs) + " – " + fmtLocal(second.tz, second.endMs) + " " + second.tz + "). Both demand the traveler's presence.");
              }
            }
          }

          // Tight connections: arrival (flight/train/bus end) -> next presence booking
          var arrivals = usable.filter(function (x) { return ARRIVAL_TYPES[x.type] && x.endMs !== null; });
          for (i = 0; i < arrivals.length; i++) {
            var arr = arrivals[i];
            var next = null;
            for (j = 0; j < presence.length; j++) {
              var cand = presence[j];
              if (cand === arr) continue;
              if (cand.startMs >= arr.endMs && (!next || cand.startMs < next.startMs)) next = cand;
            }
            if (next) {
              var gapMin = Math.round((next.startMs - arr.endMs) / 60000);
              if (gapMin < minConnect) {
                add("WARNING", [arr.lineNo, next.lineNo], "TIGHT CONNECTION — " + gapMin + " MINUTES",
                  ref(next) + " starts only " + gapMin + " minutes after " + ref(arr) + " arrives (at " + fmtLocal(arr.tz, arr.endMs) + " " + arr.tz + "), under the " + minConnect + "-minute minimum connection you set.");
              }
            }
          }

          // Hotel checks
          var hotels = bookings.filter(function (x) { return x.type === "HOTEL"; });
          var firstArrival = null;
          for (i = 0; i < arrivals.length; i++) {
            if (firstArrival === null || arrivals[i].endMs < firstArrival) firstArrival = arrivals[i].endMs;
          }
          var coveredNights = {};
          for (i = 0; i < hotels.length; i++) {
            var h = hotels[i];
            if (!h.usable || h.endMs === null) continue;
            var inDate = fmtDateInZone(h.tz, h.startMs);
            var outDate = fmtDateInZone(h.tz, h.endMs);
            var nights = Math.round((dateStrToMs(outDate) - dateStrToMs(inDate)) / 86400000);
            var nm = /nights:\s*(\d+)/i.exec(h.details || "");
            if (nm && parseInt(nm[1], 10) !== nights) {
              add("WARNING", [h.lineNo], "HOTEL NIGHTS DON'T MATCH",
                ref(h) + " says \"nights: " + nm[1] + "\" in its details, but check-in " + inDate + " to check-out " + outDate + " is " + nights + " night" + (nights === 1 ? "" : "s") + ".");
            }
            if (firstArrival !== null && h.startMs < firstArrival) {
              add("WARNING", [h.lineNo], "CHECK-IN BEFORE THE FIRST ARRIVAL",
                ref(h) + " checks in at " + fmtLocal(h.tz, h.startMs) + " " + h.tz + ", before the trip's first arrival lands at " + fmtLocal(h.tz, firstArrival) + " " + h.tz + ".");
            }
            for (var dMs = dateStrToMs(inDate); dMs < dateStrToMs(outDate); dMs += 86400000) {
              coveredNights[msToDateStr(dMs)] = true;
            }
          }
          // Uncovered nights — only when at least one HOTEL line exists
          if (hotels.length > 0 && usable.length > 0) {
            var tripStart = null, tripEnd = null, startB = null, endB = null;
            for (i = 0; i < usable.length; i++) {
              b = usable[i];
              if (tripStart === null || b.startMs < tripStart) { tripStart = b.startMs; startB = b; }
              var e = b.endMs !== null ? b.endMs : b.startMs;
              if (tripEnd === null || e > tripEnd) { tripEnd = e; endB = b; }
            }
            var firstDate = fmtDateInZone(startB.tz, tripStart);
            var lastDate = fmtDateInZone(endB.tz, tripEnd);
            for (var nMs = dateStrToMs(firstDate); nMs < dateStrToMs(lastDate); nMs += 86400000) {
              var nightStr = msToDateStr(nMs);
              if (!coveredNights[nightStr]) {
                add("WARNING", [], "UNCOVERED NIGHT — " + nightStr,
                  "No hotel covers the night of " + nightStr + ", inside a trip that runs from " + firstDate + " to " + lastDate + " and does include hotel bookings.");
              }
            }
          }

          var sevRank = { BLOCKER: 0, WARNING: 1, NOTE: 2 };
          findings.sort(function (x, y) {
            if (sevRank[x.sev] !== sevRank[y.sev]) return sevRank[x.sev] - sevRank[y.sev];
            var xl = x.lines.length ? Math.min.apply(null, x.lines) : 9999;
            var yl = y.lines.length ? Math.min.apply(null, y.lines) : 9999;
            return xl - yl;
          });

          var blockers = findings.filter(function (f) { return f.sev === "BLOCKER"; }).length;
          var warnings = findings.filter(function (f) { return f.sev === "WARNING"; }).length;
          var verdict, vclass;
          if (blockers > 0) { verdict = "CONTRADICTIONS — DO NOT BOOK YET"; vclass = "bad"; }
          else if (warnings > 0 || parsed.errors.length > 0) { verdict = "CONSISTENT WITH WARNINGS"; vclass = "warn"; }
          else { verdict = "CONSISTENT — READY TO BOOK"; vclass = "ok"; }

          var timeline = bookings.slice().sort(function (x, y) {
            if (x.startMs !== y.startMs) return x.startMs - y.startMs;
            return x.lineNo - y.lineNo;
          });

          return {
            bookings: bookings, errors: parsed.errors, findings: findings,
            blockers: blockers, warnings: warnings,
            verdict: verdict, vclass: vclass, timeline: timeline
          };
        }

        // ---------- report ----------
        function buildReport(res, defaultZone, minConnect) {
          var out = [];
          out.push("J-DAWGS ITINERARY & BOOKING CONSISTENCY AUDITOR — REPORT");
          out.push("Generated: " + new Date().toISOString() + " (this page's clock)");
          out.push("Settings: default timezone " + defaultZone + "; minimum connection " + minConnect + " minutes");
          out.push("");
          out.push("VERDICT: " + res.verdict);
          out.push("Blockers: " + res.blockers + " | Warnings: " + res.warnings + " | Lines parsed: " + res.bookings.length + " | Lines rejected: " + res.errors.length);
          out.push("");
          out.push("FINDINGS:");
          if (res.findings.length === 0 && res.errors.length === 0) out.push("  None. Every line parsed and every check passed.");
          res.findings.forEach(function (f) {
            var where = f.lines.length ? " [line" + (f.lines.length > 1 ? "s " : " ") + f.lines.join(", ") + "]" : "";
            out.push("  [" + f.sev + "] " + f.head + where);
            out.push("      " + f.text);
          });
          res.errors.forEach(function (e) {
            out.push("  [PARSE ERROR] Line " + e.lineNo + ": " + e.reason);
            out.push("      Rejected line: " + e.raw);
          });
          out.push("");
          out.push("TIMELINE (chronological):");
          res.timeline.forEach(function (b) {
            var local = fmtLocal(b.tz, b.startMs) + (b.endMs !== null ? " – " + fmtLocal(b.tz, b.endMs) : "") + " " + b.tz;
            var utc = fmtLocal("UTC", b.startMs) + (b.endMs !== null ? " – " + fmtLocal("UTC", b.endMs) : "") + " UTC";
            out.push("  Line " + b.lineNo + " [" + b.type + "] " + b.label);
            out.push("      Local: " + local);
            out.push("      UTC:   " + utc);
            var flags = [];
            if (b.assumed) flags.push("TIMEZONE ASSUMED (default zone used)");
            if (!b.startExists || (b.endStr && !b.endExists)) flags.push("NONEXISTENT LOCAL TIME");
            if (flags.length) out.push("      Flags: " + flags.join("; "));
          });
          out.push("");
          out.push("Scope: consistency of the pasted lines only. No real flight times, prices, or availability were looked up, and nothing was booked.");
          return out.join("\n");
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "WORKED_EXAMPLE": (typeof WORKED_EXAMPLE !== 'undefined' ? WORKED_EXAMPLE : undefined), "CLEAN_EXAMPLE": (typeof CLEAN_EXAMPLE !== 'undefined' ? CLEAN_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-itinerary-booking-consistency-auditor',
  name: 'J-Dawgs Itinerary & Booking Consistency Auditor',
  description: 'Booking sites check one reservation at a time; ours cross-checks a whole pasted itinerary — tight connections, hotel-night mismatches, events scheduled while a flight is airborne, DST-gap times — and returns one book/don\'t-book verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "WORKED_EXAMPLE": __core["WORKED_EXAMPLE"], "CLEAN_EXAMPLE": __core["CLEAN_EXAMPLE"] }
};
