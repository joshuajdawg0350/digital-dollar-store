'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs AdGuard Home Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

var RISKY = [
"bind_host: 0.0.0.0",
"bind_port: 3000",
"http_proxy: \"\"",
"language: en",
"theme: auto",
"dns:",
"  bind_hosts:",
"    - 0.0.0.0",
"  port: 53",
"  anonymize_client_ip: false",
"  ratelimit: 0",
"  refuse_any: false",
"  upstream_dns:",
"    - https://dns10.quad9.net/dns-query",
"  bootstrap_dns:",
"    - 9.9.9.10",
"  all_servers: false",
"tls:",
"  enabled: false",
"  server_name: \"\"",
"  force_https: false",
"  port_https: 443",
"  port_dns_over_tls: 853",
"  certificate_path: \"\"",
"  private_key_path: \"\"",
"querylog:",
"  dir_path: \"\"",
"  ignored: []",
"  interval: 2160h",
"  size_memory: 1000",
"  enabled: true",
"  file_enabled: true",
"  anonymize_client_ip: false",
"users:",
"  - name: admin",
"    password: admin123",
"auth_attempts: 5",
"block_auth_min: 15",
"dhcp:",
"  enabled: true",
"  interface_name: eth0",
"  local_domain_name: lan",
"filters:",
"  - enabled: true",
"    url: https://adguardteam.github.io/HostlistsRegistry/assets/filter_1.txt",
"    name: AdGuard DNS filter",
"    id: 1",
"filtering:",
"  protection_enabled: true",
"  filtering_enabled: true",
"schema_version: 28"
].join("\n");

var HARDENED = [
"bind_host: 127.0.0.1",
"bind_port: 3000",
"http_proxy: \"\"",
"language: en",
"theme: auto",
"dns:",
"  bind_hosts:",
"    - 127.0.0.1",
"    - 192.168.1.2",
"  port: 53",
"  anonymize_client_ip: true",
"  ratelimit: 20",
"  refuse_any: true",
"  allowed_clients: []",
"  upstream_dns:",
"    - https://dns10.quad9.net/dns-query",
"    - tls://dns.quad9.net:853",
"  bootstrap_dns:",
"    - 9.9.9.10",
"  all_servers: false",
"  allow_unencrypted_doh: false",
"tls:",
"  enabled: true",
"  server_name: dns.example-home.lan",
"  force_https: true",
"  port_https: 443",
"  port_dns_over_tls: 853",
"  port_dns_over_quic: 853",
"  certificate_path: /opt/adguardhome/certs/fullchain.pem",
"  private_key_path: /opt/adguardhome/certs/privkey.pem",
"  allow_unencrypted_doh: false",
"querylog:",
"  dir_path: \"\"",
"  ignored: []",
"  interval: 24h",
"  size_memory: 1000",
"  enabled: true",
"  file_enabled: false",
"  anonymize_client_ip: true",
"users:",
"  - name: admin",
"    password: $2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy",
"auth_attempts: 5",
"block_auth_min: 15",
"dhcp:",
"  enabled: false",
"  interface_name: \"\"",
"  local_domain_name: lan",
"filters:",
"  - enabled: true",
"    url: https://adguardteam.github.io/HostlistsRegistry/assets/filter_1.txt",
"    name: AdGuard DNS filter",
"    id: 1",
"filtering:",
"  protection_enabled: true",
"  filtering_enabled: true",
"schema_version: 28"
].join("\n");

function stripVal(v){ return v.replace(/^["']|["']$/g,"").trim(); }
function isAllInterfaces(v){ v=(v||"").toLowerCase(); return v==="0.0.0.0"||v==="::"||v==="[::]"||v===""||v==="0:0:0:0:0:0:0:0"; }

function audit(text){
  var findings=[];
  function add(line,sev,check,msg){ findings.push({line:line||null,severity:sev,check:check,finding:msg}); }
  var rawLines=text.split(/\r?\n/);
  var lines=rawLines.map(function(l,i){return {n:i+1,raw:l};});
  var nonEmpty=lines.filter(function(l){return l.raw.trim()!=="" && l.raw.trim().charAt(0)!=="#";});
  var joined=text;

  // Enough to grade?
  var hasDns=/^\s*dns\s*:/m.test(joined);
  var hasBind=/bind_host|bind_hosts/.test(joined);
  var hasAnyKey=/^[A-Za-z_][\w-]*\s*:/m.test(joined);
  if(!text.trim() || nonEmpty.length<5 || !hasAnyKey || (!hasDns && !hasBind)){
    add(null,"info","Completeness","The pasted text does not look like an AdGuard Home config with gradeable settings (dns / bind sections were not found). Paste the full AdGuardHome.yaml contents.");
    return {verdict:"NOT ENOUGH TO GRADE",reason:"No recognizable AdGuard Home structure was found in the pasted text.",findings:findings};
  }

  // Parse simple key paths with indentation + list items
  var section=""; var subSection="";
  var entries=[]; // {line, indent, key, value, section}
  lines.forEach(function(l){
    var m=l.raw.match(/^(\s*)-\s+([A-Za-z_][\w-]*)\s*:\s*(.*)$/);
    var km=l.raw.match(/^(\s*)([A-Za-z_][\w-]*)\s*:\s*(.*)$/);
    var lm=l.raw.match(/^(\s*)-\s+(.+)$/);
    if(km && !m){
      var indent=km[1].length, key=km[2], val=stripVal(km[3]||"");
      if(indent===0){ section=key; subSection=""; }
      entries.push({line:l.n,indent:indent,key:key,value:val,section:section,raw:l.raw});
    } else if(m){
      entries.push({line:l.n,indent:m[1].length+2,key:m[2],value:stripVal(m[3]||""),section:section,raw:l.raw,listItem:true});
    } else if(lm){
      entries.push({line:l.n,indent:lm[1].length,key:"__list__",value:stripVal(lm[2]),section:section,raw:l.raw,listItem:true});
    }
  });
  function find(key,sec){ return entries.filter(function(e){return e.key===key && (sec===undefined||e.section===sec);}); }
  function first(key,sec){ var f=find(key,sec); return f.length?f[0]:null; }

  var sawWebBind=false, sawDnsBind=false;

  // Web UI bind
  var bh=first("bind_host");
  if(bh){ sawWebBind=true;
    if(isAllInterfaces(bh.value)) add(bh.line,"critical","Web UI exposure","bind_host is set to all interfaces ("+ (bh.value||"empty") +"). Anyone who can reach this host can attempt the admin login. Bind to 127.0.0.1 and use a VPN / SSH tunnel / reverse proxy, or bind to one trusted LAN address only.");
    else add(bh.line,"pass","Web UI exposure","bind_host is scoped to a specific address ("+bh.value+"). Keep it that way and confirm that address is not forwarded from the internet.");
  } else add(null,"warning","Web UI exposure","No top-level bind_host was found. AdGuard Home may fall back to its default listener — verify the web UI is not reachable on all interfaces after first start.");

  var bp=first("bind_port");
  if(bp && bh && isAllInterfaces(bh.value)) add(bp.line,"high","Web UI exposure","The admin UI port ("+bp.value+") is combined with an all-interfaces bind. An exposed admin port plus a weak password is the most common way these installs get taken over.");

  // DNS binds
  var dnsBindEntries=entries.filter(function(e){return e.section==="dns" && (e.key==="__list__");});
  // Only list items directly under bind_hosts: approximate by scanning lines after dns.bind_hosts
  var inBindHosts=false, dnsBindLines=[];
  lines.forEach(function(l){
    if(/^\s*bind_hosts\s*:/.test(l.raw)){ inBindHosts=true; var inline=l.raw.split(":")[1].trim(); if(inline && inline!=="[]") dnsBindLines.push({line:l.n,value:stripVal(inline)}); return; }
    if(inBindHosts){
      var lm=l.raw.match(/^\s*-\s+(.+)$/);
      if(lm) dnsBindLines.push({line:l.n,value:stripVal(lm[1])});
      else if(/^\s*[A-Za-z_]/.test(l.raw)) inBindHosts=false;
    }
  });
  var dnsBindHostKey=first("bind_hosts","dns");
  if(dnsBindHostKey && dnsBindHostKey.value && dnsBindHostKey.value!=="[]"){ dnsBindLines.push({line:dnsBindHostKey.line,value:dnsBindHostKey.value}); }
  if(dnsBindLines.length){ sawDnsBind=true;
    dnsBindLines.forEach(function(b){
      if(isAllInterfaces(b.value)) add(b.line,"critical","DNS listener exposure","A DNS bind_hosts entry listens on all interfaces. Combined with no client restrictions this is an open resolver that third parties can abuse for amplification attacks. Bind DNS to loopback / specific LAN addresses only.");
      else add(b.line,"pass","DNS listener exposure","DNS listener is scoped to "+b.value+".");
    });
  } else add(null,"warning","DNS listener exposure","No dns.bind_hosts entries were found. Verify the DNS listener addresses in the running config — the default can listen more widely than intended.");

  var dnsPort=first("port","dns");
  // Open resolver: all-interfaces DNS + no allowed_clients restriction + ratelimit 0/missing
  var allowed=first("allowed_clients","dns");
  var ratelimit=first("ratelimit","dns");
  var dnsPublic=dnsBindLines.some(function(b){return isAllInterfaces(b.value);});
  if(dnsPublic){
    var restricted = allowed && allowed.value && allowed.value!=="[]" ;
    var rlOk = ratelimit && parseInt(ratelimit.value,10)>0;
    if(!restricted && !rlOk) add(dnsPort?dnsPort.line:(dnsBindHostKey?dnsBindHostKey.line:null),"critical","Open resolver risk","DNS is public-facing with no allowed_clients restriction and no positive ratelimit found. This host can be used as an open resolver. Restrict clients, enable rate limiting, or scope the listener to your LAN.");
    else add(null,"warning","Open resolver risk","DNS listens on all interfaces. Client restrictions / rate limiting were found, but re-check them after deploy — a public resolver still attracts abuse traffic.");
  }
  if(ratelimit){
    if(parseInt(ratelimit.value,10)===0) add(ratelimit.line,"high","Rate limiting","dns.ratelimit is 0 (disabled). Re-enable rate limiting (for example 20) before exposing DNS beyond a trusted LAN.");
    else add(ratelimit.line,"pass","Rate limiting","dns.ratelimit is set to "+ratelimit.value+".");
  }
  var refuseAny=first("refuse_any","dns");
  if(refuseAny && refuseAny.value==="false") add(refuseAny.line,"info","Amplification hardening","dns.refuse_any is false. Setting it to true reduces DNS amplification abuse via ANY queries.");

  // TLS
  var tlsEnabled=entries.filter(function(e){return e.section==="tls" && e.key==="enabled";})[0];
  var certPath=entries.filter(function(e){return e.section==="tls" && e.key==="certificate_path";})[0];
  var keyPath=entries.filter(function(e){return e.section==="tls" && e.key==="private_key_path";})[0];
  var forceHttps=entries.filter(function(e){return e.section==="tls" && e.key==="force_https";})[0];
  var webExposed = bh && isAllInterfaces(bh.value);
  if(!tlsEnabled) add(null,"warning","TLS for web UI","No tls.enabled setting was found. Confirm HTTPS is configured (or that the UI is only reachable over a trusted private network / VPN).");
  else if(tlsEnabled.value!=="true"){
    add(tlsEnabled.line, webExposed?"critical":"high","TLS for web UI","tls.enabled is not true, so the web UI and its login travel over plain HTTP. Anyone on the path can read credentials. Enable TLS with a valid certificate, or restrict the UI to loopback + VPN.");
  } else {
    add(tlsEnabled.line,"pass","TLS for web UI","tls.enabled is true.");
    if(certPath && !certPath.value) add(certPath.line,"high","TLS certificate","TLS is enabled but tls.certificate_path is empty. The UI may fail to serve HTTPS or fall back unexpectedly. Point it at a real full-chain certificate file.");
    if(keyPath && !keyPath.value) add(keyPath.line,"high","TLS certificate","TLS is enabled but tls.private_key_path is empty. Set the matching private key path (and keep that file readable only by the service account).");
  }
  if(tlsEnabled && tlsEnabled.value==="true" && certPath && !certPath.value && !keyPath) add(tlsEnabled.line,"warning","TLS certificate","TLS is on but no certificate path was found in the tls section.");
  if(forceHttps && tlsEnabled && tlsEnabled.value==="true" && forceHttps.value!=="true") add(forceHttps.line,"info","TLS for web UI","tls.force_https is not true. With TLS enabled, forcing HTTPS stops accidental plain-HTTP logins.");

  // DoH / DoT posture
  var allowPlainDoh=entries.filter(function(e){return e.key==="allow_unencrypted_doh";});
  allowPlainDoh.forEach(function(e){
    if(e.value==="true") add(e.line,"warning","Encrypted DNS posture","allow_unencrypted_doh is true — unencrypted DNS-over-HTTPS is accepted. Set it to false unless a specific local client requires it.");
    else add(e.line,"pass","Encrypted DNS posture","allow_unencrypted_doh is false in the "+e.section+" section.");
  });
  var upstreams=find("upstream_dns","dns");
  var upstreamLists=entries.filter(function(e){return e.section==="dns" && e.key==="__list__";});
  var hasEncryptedUpstream = /tls:\/\/|https:\/\//.test(joined.split("upstream_dns:")[1] ? joined.split("upstream_dns:")[1].split(/\n\S/)[0] : "");
  if(upstreams.length || true){
    if(hasEncryptedUpstream) add(null,"pass","Upstream DNS encryption","Encrypted upstream(s) (https:// or tls://) were found under dns.upstream_dns. Good — queries leave this box encrypted.");
    else if(/upstream_dns/.test(joined)) add(null,"info","Upstream DNS encryption","No https:// or tls:// upstream was detected under dns.upstream_dns. Plain UDP upstreams expose queries to the network path — prefer DoH/DoT upstreams.");
  }
  var dotPort=entries.filter(function(e){return e.section==="tls" && e.key==="port_dns_over_tls";})[0];
  if(dotPort && tlsEnabled && tlsEnabled.value!=="true") add(dotPort.line,"info","DNS-over-TLS","A port_dns_over_tls value is present while tls.enabled is not true — DoT will not actually be served encrypted until TLS is enabled with a certificate.");

  // Users & passwords — NEVER echo values
  var usersPresent=/^\s*users\s*:/m.test(joined);
  var pwEntries=entries.filter(function(e){return e.key==="password";});
  if(!usersPresent || pwEntries.length===0){
    add(null,"critical","Authentication","No users / password entries were found. An AdGuard Home install with no admin account (or setup left incomplete) can be claimed by whoever reaches the setup wizard first. Create a named admin user with a strong, unique password before exposing the UI anywhere.");
  }
  var exampleWords=["admin","password","changeme","change-me","example","letmein","adguard","123456","qwerty","test"];
  pwEntries.forEach(function(e){
    var len=e.value.length; var v=e.value;
    var isBcrypt=/^\$2[aby]\$\d{2}\$/.test(v);
    var lower=v.toLowerCase();
    var isExample=exampleWords.some(function(w){return lower.indexOf(w)!==-1;});
    if(isBcrypt){
      if(len<50) add(e.line,"warning","Password (key: password)","Key \"password\" at line "+e.line+": value length "+len+" looks like a truncated bcrypt hash. Re-copy the full hash from the config generator — a truncated hash will lock the user out. (Value not shown.)");
      else add(e.line,"pass","Password (key: password)","Key \"password\" at line "+e.line+": bcrypt-format hash, length "+len+". Shape only was checked — this tool does not verify hashes. (Value not shown.)");
    } else if(isExample || len<12){
      add(e.line,"critical","Password (key: password)","Key \"password\" at line "+e.line+": plaintext / short / example credential, value length "+len+". Replace it with a long, unique password stored as a bcrypt hash (AdGuard Home hashes it when set through the UI). Never deploy with an example password. (Value not shown.)");
    } else {
      add(e.line,"high","Password (key: password)","Key \"password\" at line "+e.line+": value length "+len+" does not look like a bcrypt hash ($2a$/$2b$…). It may be stored in plaintext. Set the password through the AdGuard Home UI so it is saved hashed. (Value not shown.)");
    }
  });
  // Any other secret-ish keys
  entries.filter(function(e){return /api_key|secret|token/i.test(e.key) && e.key!=="password";}).forEach(function(e){
    add(e.line,"info","Secret handling (key: "+e.key+")","Key \""+e.key+"\" at line "+e.line+": a secret-like value is present, length "+e.value.length+". Confirm this file's permissions are 600 and it is not committed to a public repo. (Value not shown.)");
  });

  // DHCP
  var dhcpEnabled=entries.filter(function(e){return e.section==="dhcp" && e.key==="enabled";})[0];
  if(dhcpEnabled){
    if(dhcpEnabled.value==="true") add(dhcpEnabled.line,"warning","DHCP server","dhcp.enabled is true. Two DHCP servers on one network (this box plus your router) will hand out conflicting leases and break clients at random. Only enable this if AdGuard Home is deliberately the network's sole DHCP server, with the router's DHCP turned off and the range / gateway / DNS settings double-checked.");
    else add(dhcpEnabled.line,"pass","DHCP server","dhcp.enabled is false — the router keeps DHCP duty. That is the safe default for most homes.");
  } else add(null,"info","DHCP server","No dhcp.enabled setting was found. If DHCP is enabled elsewhere in the file or UI, make sure only one DHCP server runs on the network.");

  // Query log
  var qEnabled=entries.filter(function(e){return e.section==="querylog" && e.key==="enabled";})[0];
  var qFile=entries.filter(function(e){return e.section==="querylog" && e.key==="file_enabled";})[0];
  var qAnon=entries.filter(function(e){return (e.section==="querylog"||e.section==="dns") && e.key==="anonymize_client_ip";});
  var qInterval=entries.filter(function(e){return e.section==="querylog" && e.key==="interval";})[0];
  if(qEnabled && qEnabled.value==="true"){
    add(qEnabled.line,"info","Query log privacy","The query log is enabled. It records every domain every device looks up — treat the log file like browsing history: restrict who can open the UI and how long logs are kept.");
    if(qFile && qFile.value==="true") add(qFile.line,"warning","Query log privacy","querylog.file_enabled is true, so logs persist to disk. Shorten retention and protect the data directory, or disable file logging if you do not need history.");
    if(qInterval){
      var iv=qInterval.value; var hours=null;
      var mm=iv.match(/^(\d+(?:\.\d+)?)h$/); if(mm) hours=parseFloat(mm[1]);
      var dm=iv.match(/^(\d+(?:\.\d+)?)d$/); if(dm) hours=parseFloat(dm[1])*24;
      if(hours!==null && hours>720) add(qInterval.line,"warning","Query log privacy","querylog.interval is "+iv+" (over 30 days). Long DNS-log retention is a privacy liability — 24h to 7 days covers most troubleshooting.");
      else add(qInterval.line,"pass","Query log privacy","querylog.interval is "+iv+".");
    }
  } else if(qEnabled) add(qEnabled.line,"pass","Query log privacy","The query log is disabled — the most private setting, at the cost of troubleshooting history.");
  qAnon.forEach(function(e){
    if(e.value!=="true") add(e.line,"warning","Query log privacy","anonymize_client_ip is not true in the "+e.section+" section. Client IPs will be stored in full in the query log. Enable anonymization unless you specifically need per-device history.");
    else add(e.line,"pass","Query log privacy","anonymize_client_ip is true in the "+e.section+" section.");
  });

  // Filters
  var filterEnabled=entries.filter(function(e){return e.section==="filters" && e.key==="enabled";});
  var hasEnabledFilter=filterEnabled.some(function(e){return e.value==="true";});
  if(!/^\s*filters\s*:/m.test(joined)) add(null,"info","Filtering","No filters section was found. AdGuard Home without any enabled blocklist filters DNS but blocks very little — add at least one maintained filter list.");
  else if(!hasEnabledFilter) add(null,"info","Filtering","A filters section exists but no enabled filter was detected. Confirm at least one list is enabled in the UI.");
  else add(null,"pass","Filtering","At least one enabled filter list was found.");

  // Verdict
  var hasCrit=findings.some(function(f){return f.severity==="critical";});
  var hasHigh=findings.some(function(f){return f.severity==="high";});
  var hasWarn=findings.some(function(f){return f.severity==="warning";});
  var verdict, reason;
  if(hasCrit){ verdict="DO NOT DEPLOY"; reason="Critical exposure or credential problems were found. Fix every critical finding before this config goes on a reachable host."; }
  else if(hasHigh||hasWarn){ verdict="DEPLOY WITH FIXES"; reason="No critical findings, but warnings / high items should be fixed before or immediately after deploy — especially anything touching exposure, TLS, or DHCP."; }
  else { verdict="SAFE TO DEPLOY"; reason="No critical, high, or warning findings on the checks this tool runs. This is a config review, not a penetration test — still confirm firewall rules on the host itself."; }
  return {verdict:verdict,reason:reason,findings:findings};
}

var lastResult=null;
function sevLabel(s){return s.toUpperCase();}
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-adguard-home-server-config-safety-auditortm',
  name: 'J-Dawgs AdGuard Home Server Config Safety Auditor',
  description: 'Grades a pasted AdGuard Home config fully offline into one deploy verdict — SAFE TO DEPLOY / DEPLOY WITH FIXES / DO NOT DEPLOY / NOT ENOUGH TO GRADE — plaintext admin credentials, an admin interface bound to every interface, and TLS left off, with secrets shown by key name, line, and length only, ne',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
