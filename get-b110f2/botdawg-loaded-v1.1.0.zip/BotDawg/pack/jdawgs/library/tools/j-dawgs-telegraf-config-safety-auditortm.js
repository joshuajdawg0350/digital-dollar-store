'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Telegraf Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var RISKY = [
        '# Risky example — planted problems for the auditor to catch',
        '[agent]',
        '  interval = "10s"',
        '  flush_interval = "10s"',
        '  hostname = "metrics-edge-01"',
        '',
        '[[outputs.influxdb_v2]]',
        '  urls = ["http://influxdb.internal:8086"]',
        '  token = "abc123"',
        '  organization = "ops"',
        '  bucket = "telegraf"',
        '  insecure_skip_verify = true',
        '',
        '[[inputs.http_listener_v2]]',
        '  service_address = ":8186"',
        '  paths = ["/telegraf"]',
        '',
        '[[inputs.cpu]]',
        '  percpu = true',
        '  totalcpu = true'
      ].join('\n');

      var CLEAN = [
        '# Clean example — hardened configuration',
        '[agent]',
        '  interval = "10s"',
        '  flush_interval = "10s"',
        '  omit_hostname = false',
        '',
        '[[outputs.influxdb_v2]]',
        '  urls = ["https://influxdb.example.net:8086"]',
        '  token = "$INFLUX_TOKEN"',
        '  organization = "ops"',
        '  bucket = "telegraf"',
        '  tls_ca = "/etc/telegraf/ca.pem"',
        '',
        '[[inputs.http_listener_v2]]',
        '  service_address = "127.0.0.1:8186"',
        '  paths = ["/telegraf"]',
        '  tls_cert = "/etc/telegraf/listener.crt"',
        '  tls_key = "/etc/telegraf/listener.key"',
        '  basic_username = "telegraf-writer"',
        '  basic_password = "${LISTENER_PASSWORD}"'
      ].join('\n');

      var CRED_WORDS = ['password','token','secret','api_key','authorization'];
      var PLACEHOLDERS = ['password','changeme','change-me','test','example','secret','token','default','admin','letmein','12345678','xxxxxxxx','your-token','your_password','your-password'];

      function isCredKey(key){
        var k = key.toLowerCase();
        for (var i=0;i<CRED_WORDS.length;i++){ if (k.indexOf(CRED_WORDS[i]) !== -1) return true; }
        return false;
      }
      function isEnvRef(v){
        return /^\$[A-Za-z_][A-Za-z0-9_]*$/.test(v) || /^\$\{[A-Za-z_][A-Za-z0-9_]*\}$/.test(v);
      }
      function stripComment(s){
        var inD=false, inS=false, esc=false;
        for (var i=0;i<s.length;i++){
          var c=s.charAt(i);
          if (esc){ esc=false; continue; }
          if (c==='\\' && inD){ esc=true; continue; }
          if (c==='"' && !inS) inD=!inD;
          else if (c==="'" && !inD) inS=!inS;
          else if (c==='#' && !inD && !inS) return s.slice(0,i);
        }
        return s;
      }
      function bracketBalance(s){
        var inD=false, inS=false, esc=false, bal=0;
        for (var i=0;i<s.length;i++){
          var c=s.charAt(i);
          if (esc){ esc=false; continue; }
          if (c==='\\' && inD){ esc=true; continue; }
          if (c==='"' && !inS){ inD=!inD; continue; }
          if (c==="'" && !inD){ inS=!inS; continue; }
          if (inD||inS) continue;
          if (c==='[') bal++;
          else if (c===']') bal--;
        }
        return bal;
      }
      function parseStringValue(vt){
        vt = vt.replace(/^\s+/,'');
        if (vt.charAt(0) === '"'){
          var out='', esc=false;
          for (var i=1;i<vt.length;i++){
            var c=vt.charAt(i);
            if (esc){ out+=c; esc=false; continue; }
            if (c==='\\'){ esc=true; continue; }
            if (c==='"') return out;
            out+=c;
          }
          return out;
        }
        if (vt.charAt(0) === "'"){
          var end = vt.indexOf("'",1);
          return end===-1 ? vt.slice(1) : vt.slice(1,end);
        }
        return null;
      }
      function parseArrayStrings(vt){
        var res=[], m, re=/"((?:[^"\\]|\\.)*)"|'([^']*)'/g;
        while ((m = re.exec(vt)) !== null){ res.push(m[1] !== undefined ? m[1] : m[2]); }
        return res;
      }
      function parseDurationSeconds(v){
        if (v === null || v === undefined) return null;
        var s = String(v).trim();
        if (/^\d+(\.\d+)?$/.test(s)) return parseFloat(s);
        var total=0, matched=false, re=/(\d+(?:\.\d+)?)\s*(ns|us|µs|ms|s|m|h)/g, m;
        var mult={'ns':1e-9,'us':1e-6,'µs':1e-6,'ms':0.001,'s':1,'m':60,'h':3600};
        while ((m = re.exec(s)) !== null){ total += parseFloat(m[1]) * mult[m[2]]; matched=true; }
        return matched ? total : null;
      }
      function urlHost(u){
        var rest = u.replace(/^https?:\/\//,'');
        var at = rest.lastIndexOf('@');
        if (at !== -1) rest = rest.slice(at+1);
        var slash = rest.indexOf('/');
        return slash===-1 ? rest : rest.slice(0,slash);
      }

      function parseConfig(text){
        var lines = text.split('\n');
        var sections = [];
        var notParsed = [];
        var current = { name:'(top level)', kind:'table', headerLine:0, entries:[] };
        sections.push(current);
        var i = 0;
        while (i < lines.length){
          var raw = lines[i], lineNo = i+1, t = raw.trim();
          i++;
          if (t === '' || t.charAt(0) === '#') continue;
          var mh = t.match(/^\[\[\s*([^\]]+?)\s*\]\]\s*(#.*)?$/) || t.match(/^\[\s*([^\]]+?)\s*\]\s*(#.*)?$/);
          if (mh){
            var isArr = t.indexOf('[[') === 0;
            current = { name: mh[1].trim(), kind: isArr ? 'array' : 'table', headerLine: lineNo, entries: [] };
            sections.push(current);
            continue;
          }
          var mk = t.match(/^"?([A-Za-z0-9_.\-]+)"?\s*=\s*(.+)$/);
          if (mk){
            var key = mk[1], valueText = mk[2];
            // Multi-line array continuation
            var guard = 0;
            while (valueText.replace(/^\s+/,'').charAt(0) === '[' && bracketBalance(stripComment(valueText)) > 0 && i < lines.length && guard < 500){
              valueText += '\n' + lines[i];
              i++; guard++;
            }
            // Multi-line basic/literal string
            guard = 0;
            var vs = valueText.replace(/^\s+/,'');
            var triple = null;
            if (vs.indexOf('"""') === 0) triple = '"""';
            else if (vs.indexOf("'''") === 0) triple = "'''";
            if (triple && vs.indexOf(triple,3) === -1){
              while (i < lines.length && guard < 500){
                valueText += '\n' + lines[i];
                var done = lines[i].indexOf(triple) !== -1;
                i++; guard++;
                if (done) break;
              }
              vs = valueText.replace(/^\s+/,'');
              var closeIdx = vs.indexOf(triple,3);
              var innerML = closeIdx===-1 ? vs.slice(3) : vs.slice(3,closeIdx);
              current.entries.push({ key:key, line:lineNo, valueText:valueText, str:innerML, arr:null, bool:null });
              continue;
            }
            var clean = stripComment(valueText).trim();
            var entry = { key:key, line:lineNo, valueText:clean, str:null, arr:null, bool:null };
            if (clean.charAt(0) === '[') entry.arr = parseArrayStrings(clean);
            else {
              var sv = parseStringValue(clean);
              if (sv !== null) entry.str = sv;
              else if (clean === 'true') entry.bool = true;
              else if (clean === 'false') entry.bool = false;
            }
            current.entries.push(entry);
            continue;
          }
          notParsed.push(lineNo);
        }
        return { sections: sections, notParsed: notParsed, lineCount: lines.length };
      }

      function sectionHasCred(sec){
        for (var i=0;i<sec.entries.length;i++){
          var e = sec.entries[i];
          if (isCredKey(e.key) && e.str !== null && e.str.length > 0) return true;
        }
        return false;
      }

      function audit(text){
        var parsed = parseConfig(text);
        var sections = parsed.sections;
        var findings = [];
        function add(sev, line, section, key, message, fix){
          findings.push({ severity:sev, line:line, section:section, key:key, message:message, fix:fix });
        }

        parsed.notParsed.forEach(function(ln){
          add('NOT PARSED', ln, '', '',
            'Line ' + ln + ' could not be parsed by the heuristic parser — it is not a section header, a key = value pair, a comment, or an array continuation, so it was not audited.',
            'Check the line by hand. If Telegraf accepts it, treat this as a parser limit of this tool, not a config fault.');
        });

        var hasOutputs = false;
        var outputGroups = {};

        sections.forEach(function(sec){
          var name = sec.name;
          var isOutput = name.indexOf('outputs.') === 0;
          var isInput = name.indexOf('inputs.') === 0;
          if (isOutput){
            hasOutputs = true;
            if (!outputGroups[name]) outputGroups[name] = [];
            outputGroups[name].push(sec);
          }
          var secHasCred = sectionHasCred(sec);

          sec.entries.forEach(function(e){
            var keyL = e.key.toLowerCase();

            // Credential keys — value itself is NEVER copied into a finding.
            if (isCredKey(e.key) && e.str !== null && e.str.length > 0){
              if (isEnvRef(e.str)){
                add('INFO', e.line, name, e.key,
                  'Key "' + e.key + '" in [[' + name + ']] is loaded from environment — not verified (value length not applicable).',
                  'No change needed for storage, but confirm the environment actually sets this variable on the host; its strength cannot be checked here.');
              } else {
                var low = e.str.toLowerCase();
                var placeholder = PLACEHOLDERS.indexOf(low) !== -1 || low.indexOf('example') !== -1 || low.indexOf('changeme') !== -1 || low.indexOf('your-') === 0 || low.indexOf('your_') === 0;
                if (placeholder || e.str.length < 8){
                  add('BLOCKER', e.line, name, e.key,
                    'Key "' + e.key + '" in [[' + name + ']] holds a plaintext literal of ' + e.str.length + ' characters that ' + (placeholder ? 'matches a known placeholder value' : 'is under 8 characters') + '. The value itself is never shown here.',
                    'Replace it with a real, unique credential loaded from an environment variable (for example ' + e.key + ' = "$TELEGRAF_SECRET") or a secrets manager — and rotate it, because it has existed in plaintext.');
                } else {
                  add('WARNING', e.line, name, e.key,
                    'Key "' + e.key + '" in [[' + name + ']] holds a plaintext literal credential (' + e.str.length + ' characters) stored directly in the config file. The value itself is never shown here.',
                    'Move it out of the file into an environment variable (for example ' + e.key + ' = "$TELEGRAF_SECRET") or a secrets manager, and restrict the config file\u2019s permissions until then.');
                }
              }
            }

            // insecure_skip_verify in outputs / processors / aggregators
            if (e.key === 'insecure_skip_verify' && e.bool === true &&
                (isOutput || name.indexOf('processors.') === 0 || name.indexOf('aggregators.') === 0 || name === 'agent')){
              add('BLOCKER', e.line, name, e.key,
                '[[' + name + ']] sets insecure_skip_verify = true at line ' + e.line + ': TLS certificate verification is disabled, so the connection can be intercepted without detection.',
                'Remove insecure_skip_verify (or set it to false) and fix the underlying certificate problem — install the correct CA with tls_ca instead of skipping verification.');
            }

            // Plain-HTTP URLs in outputs / inputs
            if ((isOutput || isInput) && (keyL.indexOf('url') !== -1 || keyL === 'endpoint' || keyL === 'endpoints')){
              var urls = [];
              if (e.arr) urls = e.arr;
              else if (e.str !== null) urls = [e.str];
              urls.forEach(function(u){
                if (typeof u === 'string' && u.indexOf('http://') === 0){
                  if (secHasCred){
                    add('BLOCKER', e.line, name, e.key,
                      'URL for key "' + e.key + '" in [[' + name + ']] (host: ' + urlHost(u) + ') uses plain http://, and this same section carries a credential key — the credential crosses the network unencrypted.',
                      'Switch the URL to https:// with a valid certificate so the credential and the metrics are encrypted in transit.');
                  } else {
                    add('WARNING', e.line, name, e.key,
                      'URL for key "' + e.key + '" in [[' + name + ']] (host: ' + urlHost(u) + ') uses plain http:// — metrics travel unencrypted and can be read or altered in transit.',
                      'Switch the URL to https:// with a valid certificate.');
                  }
                }
              });
            }
          });

          // HTTP listener inputs
          if (name === 'inputs.http_listener_v2' || name === 'inputs.http_listener'){
            var authKeys = ['tls_cert','tls_key','tls_ca','basic_username','basic_password','bearer_token','bearer_token_file','auth_file'];
            var hasAuth = false, tlsCert = null, tlsKey = null, svcAddr = null;
            sec.entries.forEach(function(e2){
              var k2 = e2.key.toLowerCase();
              if (authKeys.indexOf(k2) !== -1 || isCredKey(e2.key) || k2.indexOf('tls_') === 0 || k2.indexOf('auth') !== -1) hasAuth = true;
              if (k2 === 'tls_cert') tlsCert = e2;
              if (k2 === 'tls_key') tlsKey = e2;
              if (k2 === 'service_address' && e2.str !== null) svcAddr = e2;
            });
            var bindsAll = false, addrNote = '';
            if (svcAddr){
              var a = svcAddr.str.replace(/^(tcp|udp):\/\//,'');
              if (a.charAt(0) === ':' || a.indexOf('0.0.0.0') === 0){ bindsAll = true; addrNote = ' Its service_address "' + svcAddr.str + '" binds every network interface.'; }
            }
            if (!hasAuth){
              add('BLOCKER', sec.headerLine, name, '',
                '[[' + name + ']] at line ' + sec.headerLine + ' exposes an HTTP metrics listener with no authentication or TLS keys in the section — anyone who can reach it can push or read metrics.' + addrNote,
                'Add TLS (tls_cert + tls_key) and authentication (for example basic auth or a bearer token) to this listener, or bind service_address to 127.0.0.1 if only local agents should reach it.');
            } else if (bindsAll){
              add('WARNING', svcAddr.line, name, 'service_address',
                '[[' + name + ']] has auth/TLS keys, but service_address "' + svcAddr.str + '" still binds every network interface (' + (svcAddr.str.indexOf('0.0.0.0') === 0 ? '0.0.0.0' : ':port') + '), so the listener is reachable from the whole network.',
                'If only local or trusted-network agents should write metrics, bind service_address to a specific address such as 127.0.0.1 or a private interface.');
            }
            if ((tlsCert && !tlsKey) || (!tlsCert && tlsKey)){
              var present = tlsCert ? tlsCert : tlsKey;
              add('WARNING', present.line, name, present.key,
                '[[' + name + ']] sets ' + present.key + ' without its pair (' + (tlsCert ? 'tls_key' : 'tls_cert') + ' is missing) — TLS on this listener is incomplete and will fail or fall back unexpectedly.',
                'Set both tls_cert and tls_key, or remove both and terminate TLS at a reverse proxy in front of the listener.');
            }
          }

          // exec / execd inputs
          if (name === 'inputs.exec' || name === 'inputs.execd'){
            sec.entries.forEach(function(e3){
              if (e3.key !== 'commands' && e3.key !== 'command') return;
              var cmds = [];
              if (e3.arr) cmds = e3.arr;
              else if (e3.str !== null) cmds = [e3.str];
              cmds.forEach(function(cmd, idx){
                if (typeof cmd !== 'string') return;
                var pipesToShell = /\|\s*(sudo\s+)?(ba|z)?sh\b/.test(cmd) || /(curl|wget)[^|]*\|\s*(sudo\s+)?(ba|z)?sh\b/.test(cmd);
                if (pipesToShell){
                  add('BLOCKER', e3.line, name, e3.key,
                    'Command #' + (idx+1) + ' in [[' + name + ']] pipes into a shell (curl | sh pattern) — downloaded or streamed content would execute with Telegraf\u2019s privileges.',
                    'Never pipe into a shell from a metrics agent. Download the script through a verified channel, pin and review it, and run it as a fixed local command instead.');
                } else if (/\bsudo\b/.test(cmd)){
                  add('WARNING', e3.line, name, e3.key,
                    'Command #' + (idx+1) + ' in [[' + name + ']] runs through sudo — Telegraf gains standing root-level reach for whatever this command does.',
                    'Prefer a narrowly-scoped sudoers rule for the exact command, or give the telegraf user the specific file/device permissions it needs instead of sudo.');
                }
              });
            });
          }

          // [agent] checks
          if (name === 'agent'){
            sec.entries.forEach(function(e4){
              if (e4.key === 'interval' || e4.key === 'flush_interval'){
                var raw = e4.str !== null ? e4.str : e4.valueText;
                var secs = parseDurationSeconds(raw);
                if (secs !== null && secs > 3600){
                  add('WARNING', e4.line, name, e4.key,
                    '[agent] ' + e4.key + ' = "' + raw + '" is ' + Math.round(secs) + ' seconds (arithmetic: ' + raw + ' = ' + Math.round(secs) + 's), which is over the 3600-second (1h) line — metrics can sit stale for over an hour before anyone sees them.',
                    'Bring ' + e4.key + ' back to a minute-scale value (for example "10s" or "60s") unless this agent is deliberately a slow batch collector.');
                }
              }
              if (e4.key === 'omit_hostname' && e4.bool === true){
                add('INFO', e4.line, name, e4.key,
                  '[agent] sets omit_hostname = true — metrics from this host will carry no hostname tag, so hosts can be hard to tell apart downstream.',
                  'Leave it on only if another tag (for example a static global tag) identifies the host just as reliably.');
              }
            });
          }
        });

        // Duplicate identical outputs
        Object.keys(outputGroups).forEach(function(nm){
          var group = outputGroups[nm];
          for (var a=0;a<group.length;a++){
            for (var b=a+1;b<group.length;b++){
              var sig = function(s){ return s.entries.map(function(x){ return x.key + '=' + x.valueText; }).sort().join('|'); };
              if (sig(group[a]) === sig(group[b])){
                add('WARNING', group[b].headerLine, nm, '',
                  'Duplicate identical [[' + nm + ']] sections start at line ' + group[a].headerLine + ' and line ' + group[b].headerLine + ' — every metric is written to the same destination twice.',
                  'Delete one of the two [[' + nm + ']] sections (starting at line ' + group[b].headerLine + '), or change one of them if two different destinations were intended.');
              }
            }
          }
        });

        if (!hasOutputs){
          var agentLine = 1;
          sections.forEach(function(s2){ if (s2.name === 'agent') agentLine = s2.headerLine; });
          add('BLOCKER', agentLine, '', '',
            'No [[outputs.*]] section exists anywhere in this config — there is nowhere to send metrics, so Telegraf would collect data and drop it.',
            'Add at least one output section (for example [[outputs.influxdb_v2]] or [[outputs.file]]) so collected metrics have a destination.');
        }

        var order = { 'BLOCKER':0, 'WARNING':1, 'NOT PARSED':2, 'INFO':3 };
        findings.sort(function(x,y){
          if (x.line !== y.line) return x.line - y.line;
          return order[x.severity] - order[y.severity];
        });

        var counts = { BLOCKER:0, WARNING:0, INFO:0, 'NOT PARSED':0 };
        findings.forEach(function(f){ counts[f.severity]++; });
        var verdict = counts.BLOCKER > 0 ? 'DO NOT DEPLOY' : (counts.WARNING > 0 || counts['NOT PARSED'] > 0) ? 'DEPLOY WITH FIXES' : 'SAFE TO DEPLOY';
        return { verdict:verdict, counts:counts, findings:findings, lineCount:parsed.lineCount };
      }

      function buildReport(result){
        var out = [];
        out.push('J-Dawgs Telegraf Config Safety Auditor\u2122 — Audit Report');
        out.push('Verdict: ' + result.verdict);
        out.push('Findings: ' + result.counts.BLOCKER + ' BLOCKER, ' + result.counts.WARNING + ' WARNING, ' + result.counts.INFO + ' INFO, ' + result.counts['NOT PARSED'] + ' NOT PARSED');
        out.push('Config lines audited: ' + result.lineCount);
        out.push('Note: credential values are never printed — findings report key, section, line, and value length only.');
        out.push('');
        if (result.findings.length === 0){ out.push('No findings.'); }
        result.findings.forEach(function(f, idx){
          out.push((idx+1) + '. [' + f.severity + '] Line ' + f.line + (f.section ? ' — [[' + f.section + ']]' : '') + (f.key ? ' — key "' + f.key + '"' : ''));
          out.push('    ' + f.message);
          out.push('    Fix: ' + f.fix);
        });
        return out.join('\n');
      }
      function buildJson(result){
        return JSON.stringify({
          tool: 'J-Dawgs Telegraf Config Safety Auditor\u2122',
          verdict: result.verdict,
          counts: { blocker: result.counts.BLOCKER, warning: result.counts.WARNING, info: result.counts.INFO, notParsed: result.counts['NOT PARSED'] },
          linesAudited: result.lineCount,
          findings: result.findings.map(function(f){
            return { severity:f.severity, line:f.line, section:f.section, key:f.key, message:f.message, fix:f.fix };
          })
        }, null, 2);
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-telegraf-config-safety-auditortm',
  name: 'J-Dawgs Telegraf Config Safety Auditor',
  description: 'Telegraf startup only answers whether the config loads; ours grades a pasted telegraf.conf anywhere — credential storage, TLS posture, and listener exposure included — into one deploy verdict, secrets by key name, section, line, and length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
