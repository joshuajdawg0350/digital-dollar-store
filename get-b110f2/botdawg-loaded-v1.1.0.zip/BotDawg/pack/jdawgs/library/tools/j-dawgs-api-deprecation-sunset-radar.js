'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs API Deprecation & Sunset Radar".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the analyze function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var MONTHS_FULL = ["January","February","March","April","May","June","July","August","September","October","November","December"];
        var MONTHS_SHORT = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
        var MONTH_LOOKUP = {};
        MONTHS_FULL.forEach(function (m, i) { MONTH_LOOKUP[m.toLowerCase()] = i; MONTH_LOOKUP[MONTHS_SHORT[i].toLowerCase()] = i; });

        var KEYWORD_RE = /deprecat|sunset|end of life|end-of-life|\bEOL\b|will be removed|will be discontinued|discontinu|shut\s?down|no longer supported|retir(e|ed|ing|ement)|support ends/i;

        function pad2(n) { return (n < 10 ? "0" : "") + n; }
        function toISODate(d) { return d.getFullYear() + "-" + pad2(d.getMonth() + 1) + "-" + pad2(d.getDate()); }
        function longDate(d) { return MONTHS_FULL[d.getMonth()] + " " + d.getDate() + ", " + d.getFullYear(); }
        function shortDate(d) { return MONTHS_SHORT[d.getMonth()] + " " + d.getDate() + ", " + d.getFullYear(); }
        function addDays(d, n) { var x = new Date(d.getFullYear(), d.getMonth(), d.getDate()); x.setDate(x.getDate() + n); return x; }
        function dayDiff(from, to) { var a = new Date(from.getFullYear(), from.getMonth(), from.getDate()); var b = new Date(to.getFullYear(), to.getMonth(), to.getDate()); return Math.round((b - a) / 86400000); }
        function validDate(y, m, d) {
          if (m < 0 || m > 11 || d < 1 || d > 31) return null;
          var dt = new Date(y, m, d);
          if (dt.getFullYear() !== y || dt.getMonth() !== m || dt.getDate() !== d) return null;
          return dt;
        }

        // Find every date written in a line: ISO, "Month D, YYYY", "D Month YYYY", M/D/YYYY.
        function findDates(line) {
          var found = [];
          var m, re;
          re = /\b(\d{4})-(\d{2})-(\d{2})\b/g;
          while ((m = re.exec(line)) !== null) {
            var d1 = validDate(+m[1], +m[2] - 1, +m[3]);
            if (d1) found.push({ date: d1, index: m.index, kind: "iso", text: m[0] });
          }
          re = /\b(January|February|March|April|May|June|July|August|September|October|November|December|Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\.?\s+(\d{1,2}),\s*(\d{4})\b/gi;
          while ((m = re.exec(line)) !== null) {
            var d2 = validDate(+m[3], MONTH_LOOKUP[m[1].toLowerCase()], +m[2]);
            if (d2) found.push({ date: d2, index: m.index, kind: "long", text: m[0] });
          }
          re = /\b(\d{1,2})\s+(January|February|March|April|May|June|July|August|September|October|November|December|Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\.?\s+(\d{4})\b/gi;
          while ((m = re.exec(line)) !== null) {
            var d3 = validDate(+m[3], MONTH_LOOKUP[m[2].toLowerCase()], +m[1]);
            if (d3) found.push({ date: d3, index: m.index, kind: "long", text: m[0] });
          }
          re = /\b(\d{1,2})\/(\d{1,2})\/(\d{4})\b/g;
          while ((m = re.exec(line)) !== null) {
            var d4 = validDate(+m[3], +m[1] - 1, +m[2]);
            if (d4) found.push({ date: d4, index: m.index, kind: "slash", text: m[0] });
          }
          found.sort(function (a, b) { return a.index - b.index; });
          return found;
        }

        // A date that directly follows a "Version" label is a version pin
        // (e.g. "Stripe-Version: 2023-10-16"), not the event date — a notice
        // like "Webhook-Version: 2022-08-01 is deprecated." carries no date.
        function isVersionPin(line, idx) {
          var before = line.slice(Math.max(0, idx - 24), idx);
          return /version\s*[:\-–—]?\s*$/i.test(before);
        }

        // Pick the date in a notice line that is the event date (not a version pin).
        // Long-form and slash dates win; among ISO dates, one introduced by
        // on/by/after/before/effective/until wins; ties go to the last date.
        function extractEventDate(line) {
          var dates = findDates(line).filter(function (d) { return !isVersionPin(line, d.index); });
          if (!dates.length) return null;
          var nonIso = dates.filter(function (d) { return d.kind !== "iso"; });
          if (nonIso.length) return nonIso[0];
          var scored = dates.map(function (d) {
            var before = line.slice(Math.max(0, d.index - 16), d.index).toLowerCase();
            var score = /\b(on|by|after|before|effective|until|ending|ends)\s*$/.test(before) || /(on|by|after|before|effective|until)\s+\S{0,3}$/.test(before) ? 2 : 0;
            return { d: d, score: score };
          });
          scored.sort(function (a, b) { return (a.score - b.score) || (a.d.index - b.d.index); });
          return scored[scored.length - 1].d;
        }

        function versionTokens(text) {
          var out = [], seen = {}, m, re;
          re = /\b\d{4}-\d{2}-\d{2}\b/g;
          while ((m = re.exec(text)) !== null) { if (!seen[m[0]]) { seen[m[0]] = 1; out.push(m[0]); } }
          re = /\bv\d+(?:\.\d+){0,2}\b/gi;
          while ((m = re.exec(text)) !== null) { var k = m[0].toLowerCase(); if (!seen[k]) { seen[k] = 1; out.push(k); } }
          return out;
        }

        function parseCalled(text) {
          return text.split(/\r?\n/).map(function (raw) { return raw.trim(); }).filter(function (s) { return s.length > 0; })
            .map(function (line, i) {
              var pathMatch = line.match(/\/[^\s,;]+/);
              var path = pathMatch ? pathMatch[0].replace(/[)\].]+$/, "") : "";
              var segments = path ? path.split("/").filter(function (s) { return s.length > 0; }) : [];
              return { idx: i, line: line, path: path, segments: segments, versions: versionTokens(line) };
            });
        }

        function parseEvents(text) {
          var events = [];
          text.split(/\r?\n/).forEach(function (raw, ln) {
            var line = raw.trim();
            if (!line) return;
            if (!KEYWORD_RE.test(line)) return;
            var ev = extractEventDate(line);
            events.push({
              lineNo: ln + 1,
              line: line,
              date: ev ? ev.date : null,
              dateText: ev ? ev.text : null,
              versions: versionTokens(line)
            });
          });
          return events;
        }

        function escapeReg(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); }

        function linePaths(line) {
          var out = [], m, re = /\/[^\s,;]+/g;
          while ((m = re.exec(line)) !== null) out.push(m[0].replace(/[)\].]+$/, "").toLowerCase());
          return out;
        }

        function matchEvent(item, ev) {
          var evLineLow = ev.line.toLowerCase();
          var shared = item.versions.filter(function (v) { return ev.versions.indexOf(v) !== -1; });
          var strong = shared.filter(function (v) { return !/^v\d+$/.test(v); });
          if (strong.length) return { by: "version " + strong.join(", ") };
          var bare = shared.filter(function (v) { return /^v\d+$/.test(v); });
          if (bare.length) {
            // A bare "v1"/"v2" match is weak evidence: when the notice names
            // a different endpoint path, that vN belongs to the named path,
            // not to every other endpoint that happens to share the prefix.
            var foreign = linePaths(ev.line).some(function (p) { return !item.path || p !== item.path.toLowerCase(); });
            if (!foreign) return { by: "version " + bare.join(", ") };
          }
          if (item.path && evLineLow.indexOf(item.path.toLowerCase()) !== -1) return { by: "path " + item.path };
          for (var i = 0; i < item.segments.length; i++) {
            var seg = item.segments[i];
            if (seg.length >= 4 && !/^v\d/i.test(seg)) {
              var re = new RegExp("(^|[^a-z0-9])" + escapeReg(seg) + "([^a-z0-9]|$)", "i");
              if (re.test(ev.line)) return { by: "path segment “" + seg + "”" };
            }
          }
          return null;
        }

        function classify(days) {
          if (days === null) return "nodate";
          if (days < 30) return "urgent";
          if (days <= 90) return "plan";
          return "watch";
        }
        var STATUS_LABEL = { urgent: "URGENT", plan: "PLAN NOW", watch: "WATCH", nodate: "NO DATE FOUND", nonotice: "NO NOTICE FOUND" };
        var STATUS_RANK = { urgent: 0, plan: 1, watch: 2, nodate: 3, nonotice: 4 };

        var els = {
          today: document.getElementById("today"),
          called: document.getElementById("called"),
          notices: document.getElementById("notices"),
          chips: document.getElementById("chips"),
          priority: document.getElementById("priority"),
          events: document.getElementById("events"),
          report: document.getElementById("report"),
          reportMsg: document.getElementById("report-msg")
        };

        function getToday() {
          var v = els.today.value;
          var parts = v ? v.split("-") : null;
          if (parts && parts.length === 3) {
            var d = validDate(+parts[0], +parts[1] - 1, +parts[2]);
            if (d) return d;
          }
          var now = new Date();
          return new Date(now.getFullYear(), now.getMonth(), now.getDate());
        }

        function esc(s) {
          return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
        }

        function analyze() {
          var today = getToday();
          var items = parseCalled(els.called.value);
          var events = parseEvents(els.notices.value);

          var results = items.map(function (item) {
            var matched = [];
            events.forEach(function (ev) {
              var how = matchEvent(item, ev);
              if (how) matched.push({ ev: ev, by: how.by });
            });
            var dated = matched.filter(function (x) { return x.ev.date; });
            var status, days = null, date = null;
            if (dated.length) {
              dated.sort(function (a, b) { return a.ev.date - b.ev.date; });
              date = dated[0].ev.date;
              days = dayDiff(today, date);
              status = classify(days);
            } else if (matched.length) {
              status = "nodate";
            } else {
              status = "nonotice";
            }
            return { item: item, matched: matched, status: status, days: days, date: date };
          });

          results.sort(function (a, b) {
            if (a.days !== null && b.days !== null) return a.days - b.days;
            if (a.days !== null) return -1;
            if (b.days !== null) return 1;
            return STATUS_RANK[a.status] - STATUS_RANK[b.status] || a.item.idx - b.item.idx;
          });

          var matchedEventIdx = {};
          results.forEach(function (r) { r.matched.forEach(function (x) { matchedEventIdx[events.indexOf(x.ev)] = true; }); });

          return { today: today, items: items, events: events, results: results, matchedEventIdx: matchedEventIdx };
        }

        function daysPhrase(r) {
          if (r.days === null) return "";
          if (r.days < 0) return Math.abs(r.days) + (Math.abs(r.days) === 1 ? " day" : " days") + " past the date";
          if (r.days === 0) return "the date is today";
          return r.days + (r.days === 1 ? " day" : " days") + " remaining";
        }

        function render() {
          var a = analyze();
          var counts = { urgent: 0, plan: 0, watch: 0, nodate: 0, nonotice: 0 };
          a.results.forEach(function (r) { counts[r.status]++; });

          els.chips.innerHTML =
            '<span class="chip st-urgent">URGENT <b>' + counts.urgent + "</b></span>" +
            '<span class="chip st-plan">PLAN NOW <b>' + counts.plan + "</b></span>" +
            '<span class="chip st-watch">WATCH <b>' + counts.watch + "</b></span>" +
            '<span class="chip st-nodate">NO DATE FOUND <b>' + counts.nodate + "</b></span>" +
            '<span class="chip st-nonotice">NO NOTICE FOUND <b>' + counts.nonotice + "</b></span>";

          if (!a.results.length) {
            els.priority.innerHTML = '<p class="empty">Nothing to scan yet. Paste at least one called endpoint or version on the left, then run the scan.</p>';
          } else {
            els.priority.innerHTML = a.results.map(function (r, i) {
              var head = '<div class="item-head"><span class="item-name">' + (i + 1) + ". " + esc(r.item.line) + '</span>' +
                '<span class="badge st-' + r.status + '">' + STATUS_LABEL[r.status] + "</span>" +
                (r.days !== null ? '<span class="days">' + daysPhrase(r) + "</span>" : "") + "</div>";
              var meta = "";
              if (r.date) meta = '<p class="meta">Earliest matched event date: <strong>' + esc(shortDate(r.date)) + "</strong> (" + esc(toISODate(r.date)) + "), counted from " + esc(shortDate(a.today)) + ".</p>";
              else if (r.status === "nodate") meta = '<p class="meta">A deprecation notice matches this item, but the notice gives no date. No date has been invented for it — go find the date from the provider.</p>';
              else if (r.status === "nonotice") meta = '<p class="meta">None of the pasted notices mention this item. That is <strong>not</strong> a clean bill of health — it only means your notices are silent about it.</p>';
              var ev = r.matched.map(function (x) {
                return '<blockquote class="evidence"><span class="src">Evidence · matched by ' + esc(x.by) + " · notice line " + x.ev.lineNo + "</span>“" + esc(x.ev.line) + "”</blockquote>";
              }).join("");
              return '<div class="item ' + r.status + '">' + head + meta + ev + "</div>";
            }).join("");
          }

          if (!a.events.length) {
            els.events.innerHTML = '<p class="empty">No deprecation events found in the pasted notices — no line carried deprecation language (“deprecated”, “sunset”, “end of life”, “will be removed”, …).</p>';
          } else {
            els.events.innerHTML = a.events.map(function (ev, i) {
              var when = ev.date ? esc(shortDate(ev.date)) + " · " + (dayDiff(a.today, ev.date) < 0 ? Math.abs(dayDiff(a.today, ev.date)) + " days ago" : dayDiff(a.today, ev.date) + " days from today") : "No date in this line";
              var matchedTo = [];
              a.results.forEach(function (r) { if (r.matched.some(function (x) { return x.ev === ev; })) matchedTo.push(r.item.line); });
              var mtxt = matchedTo.length ? "Matched: " + matchedTo.join(" · ") : "Matched: nothing in your called list";
              return '<div class="event-row"><span class="when">' + when + '</span><blockquote class="evidence" style="margin-top:6px;"><span class="src">Notice line ' + ev.lineNo + "</span>“" + esc(ev.line) + "”</blockquote>" +
                '<p class="matched" style="margin:4px 0 0;">' + esc(mtxt) + "</p></div>";
            }).join("");
          }

          els.report.value = buildReport(a, counts);
        }

        function buildReport(a, counts) {
          var L = [];
          L.push("J-DAWGS API DEPRECATION & SUNSET RADAR™ — MIGRATION REPORT");
          L.push("Counted from: " + shortDate(a.today) + " (" + toISODate(a.today) + ")");
          L.push("Called items checked: " + a.results.length + " · Notice events extracted: " + a.events.length);
          L.push("URGENT: " + counts.urgent + " · PLAN NOW: " + counts.plan + " · WATCH: " + counts.watch + " · NO DATE FOUND: " + counts.nodate + " · NO NOTICE FOUND: " + counts.nonotice);
          L.push("");
          L.push("MIGRATION PRIORITY LIST (soonest date first)");
          if (!a.results.length) L.push("(no called items were pasted)");
          a.results.forEach(function (r, i) {
            var line = (i + 1) + ". [" + STATUS_LABEL[r.status] + (r.days !== null ? " · " + r.days + " days" : "") + "] " + r.item.line;
            L.push(line);
            if (r.date) L.push("   Event date: " + shortDate(r.date) + " (" + toISODate(r.date) + ") — " + daysPhrase(r) + ".");
            if (r.status === "nodate") L.push("   A matching notice gives no date. No date was invented; find the date from the provider.");
            if (r.status === "nonotice") L.push("   No pasted notice mentions this item. NO NOTICE FOUND does not mean safe.");
            r.matched.forEach(function (x) {
              L.push("   Evidence (matched by " + x.by + ", notice line " + x.ev.lineNo + "): \"" + x.ev.line + "\"");
            });
          });
          L.push("");
          L.push("ALL EVENTS EXTRACTED FROM THE PASTED NOTICES");
          if (!a.events.length) L.push("(no deprecation language found in the pasted notices)");
          a.events.forEach(function (ev) {
            L.push("- [" + (ev.date ? shortDate(ev.date) + " (" + toISODate(ev.date) + ")" : "no date in line") + "] \"" + ev.line + "\"");
          });
          L.push("");
          L.push("BASIS & LIMITS: This report is built only from the notices pasted into the tool. No provider documentation was fetched and no external request was made. A missing notice never means an API is safe, and no date in this report was invented — undated deprecations are reported as NO DATE FOUND.");
          L.push("J-Dawgs · © 2026 Joshua Dawson");
          return L.join("\n");
        }

        // ---- Samples (dates rebuilt from "today" so the cases stay exact) ----
        function loadSample() {
          var today = getToday();
          var past = addDays(today, -12);
          var soon = addDays(today, 20);
          els.called.value = [
            "GET /v1/charges — Stripe-Version: 2023-10-16",
            "GET /v2/invoices — API-Version: 2024-02-01",
            "POST /v1/webhooks — Webhook-Version: 2022-08-01",
            "GET /v3/reports — API-Version: 2025-01-15"
          ].join("\n");
          els.notices.value = [
            "Provider changelog — please review before your next deploy:",
            "The Stripe-Version 2023-10-16 is deprecated and reached its sunset on " + longDate(past) + ". Calls pinned to version 2023-10-16 will be removed from the /v1/charges endpoint.",
            "API version 2024-02-01 will be removed on " + toISODate(soon) + " — that is the end of life date for /v2/invoices traffic pinned to 2024-02-01.",
            "Notice: Webhook-Version 2022-08-01 is deprecated. Please migrate your /v1/webhooks listeners to the current webhook schema as soon as you can."
          ].join("\n");
          render();
        }

        function loadClean() {
          var today = getToday();
          var far = addDays(today, 240);
          els.called.value = [
            "GET /v3/charges — Stripe-Version: 2025-06-30",
            "POST /v3/refunds — API-Version: 2025-06-30"
          ].join("\n");
          els.notices.value = [
            "Provider changelog:",
            "The legacy API version 2019-05-16 is deprecated and will be removed on " + toISODate(addDays(today, 300)) + ".",
            "API version 2025-06-30 will reach end of life on " + longDate(far) + "; plan migrations well ahead of that date."
          ].join("\n");
          render();
        }
  return { "analyze": (typeof analyze !== 'undefined' ? analyze : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["analyze"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-api-deprecation-sunset-radar',
  name: 'J-Dawgs API Deprecation & Sunset Radar',
  description: 'Paste deprecation notices and the API versions you call; get a dated sunset timeline and a migration priority order. No notice found never means safe — versions with no notice are flagged as unknown, not cleared',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["analyze"]) return { ok: false, output: null, summary: 'Extracted core has no analyze function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
