'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Mosquitto MQTT Broker Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var KNOWN = {};
      ("listener port bind_address bind_interface protocol allow_anonymous password_file acl_file " +
       "cafile capath certfile keyfile ciphers require_certificate tls_version use_identity_as_username " +
       "use_subject_as_username use_username_as_clientid allow_zero_length_clientid auto_id_prefix " +
       "max_connections max_inflight_messages max_queued_messages max_packet_size message_size_limit " +
       "persistent_client_expiration queue_qos0_messages set_tcp_nodelay upgrade_outgoing_qos " +
       "user persistence persistence_location persistence_file autosave_interval autosave_on_changes " +
       "log_dest log_type log_timestamp log_timestamp_format connection_messages sys_interval pid_file " +
       "include_dir per_listener_settings plugin auth_plugin max_keepalive " +
       "connection address addresses topic remote_username remote_password remote_clientid local_clientid " +
       "local_username local_password try_private cleansession notifications notification_topic " +
       "keepalive_interval idle_timeout max_qos start_type restart_timeout threshold round_robin " +
       "bridge_cafile bridge_capath bridge_certfile bridge_keyfile bridge_tls_version bridge_tls_psk " +
       "bridge_insecure bridge_alpn bridge_protocol_version").split(/\s+/).forEach(function (n) { KNOWN[n] = true; });

      var SECRET_RE = /(password|passwd|secret|psk)/i;
      var SEV_ORDER = { BLOCKER: 0, WARNING: 1, INFO: 2, GOOD: 3 };

      function makeScope(type, label, id) {
        return { type: type, label: label, id: id, entries: [], byName: {} };
      }
      function addEntry(scope, name, value, line) {
        var e = { name: name, value: value, line: line };
        scope.entries.push(e);
        (scope.byName[name] = scope.byName[name] || []).push(e);
      }
      function lastEntry(scope, name) {
        var a = scope.byName[name];
        return a && a.length ? a[a.length - 1] : null;
      }
      function firstToken(value) {
        return value.split(/\s+/)[0];
      }
      function isLocalhost(host) {
        if (!host) return false;
        var h = host.toLowerCase();
        return h === "localhost" || h === "127.0.0.1" || h === "::1" || h.indexOf("127.") === 0;
      }
      function isSecretName(name) {
        return SECRET_RE.test(name) && !/_file$/.test(name);
      }

      function audit(text) {
        var findings = [];
        function add(sev, line, scopeLabel, directive, msg, scopeId) {
          findings.push({
            severity: sev,
            line: (typeof line === "number" ? line : null),
            scope: scopeLabel,
            directive: directive || null,
            message: msg,
            scopeId: scopeId || "global"
          });
        }

        var global = makeScope("global", "Global", "global");
        var listeners = [];
        var bridges = [];
        var current = global;
        var directiveLines = 0;

        var rawLines = text.replace(/\r\n?/g, "\n").split("\n");
        rawLines.forEach(function (raw, idx) {
          var lineNo = idx + 1;
          var t = raw.trim();
          if (!t || t.charAt(0) === "#") return;
          var m = t.match(/^([A-Za-z][A-Za-z0-9_]*)\s+(\S[\s\S]*)$/);
          if (!m) {
            add("WARNING", lineNo, current.label, null,
              "NOT PARSED — this line could not be read as a \"directive value\" pair, so it was not graded. Check it against the mosquitto.conf format (one directive per line).",
              current.id);
            return;
          }
          var name = m[1].toLowerCase();
          var value = m[2].trim();
          directiveLines++;

          if (name === "listener") {
            var toks = value.split(/\s+/);
            var port = parseInt(toks[0], 10);
            if (!/^\d+$/.test(toks[0]) || port < 1 || port > 65535) {
              add("WARNING", lineNo, "Global", "listener",
                "NOT PARSED — the listener directive does not carry a valid port (1–65535), so no listener block was started from this line and the directives after it stay in the previous scope.", "global");
              return;
            }
            var L = makeScope("listener", "Listener " + port + " (line " + lineNo + ")", "listener-" + listeners.length);
            L.port = port; L.host = toks[1] || null; L.startLine = lineNo; L.implicit = false;
            listeners.push(L); current = L; return;
          }
          if (name === "connection") {
            var B = makeScope("bridge", "Bridge \"" + firstToken(value) + "\"", "bridge-" + bridges.length);
            bridges.push(B); current = B; return;
          }
          addEntry(current, name, value, lineNo);
        });

        if (directiveLines === 0 && listeners.length === 0) {
          return { empty: true };
        }

        /* ---- generic per-scope checks: duplicates, unknown, secrets, log verbosity ---- */
        var allScopes = [global].concat(listeners, bridges);
        allScopes.forEach(function (sc) {
          Object.keys(sc.byName).forEach(function (name) {
            var arr = sc.byName[name];
            if (arr.length > 1 && name !== "log_type" && name !== "log_dest") {
              var linesList = arr.map(function (e) { return e.line; }).join(", ");
              var last = arr[arr.length - 1];
              add("WARNING", last.line, sc.label, name,
                "Duplicate directive \"" + name + "\" in " + sc.label + " — it appears on lines " + linesList + ". Mosquitto applies last-value-wins, so the value on line " + last.line + " is the one that counts; remove the stale line so the intent is unambiguous.",
                sc.id);
            }
            if (!KNOWN[name]) {
              add("INFO", arr[0].line, sc.label, name,
                "NOT AUDITED — directive \"" + name + "\" is not in this tool's known-directive list, so its effect on deploy safety was not graded.",
                sc.id);
            }
            if (isSecretName(name)) {
              arr.forEach(function (e) {
                add("WARNING", e.line, sc.label, name,
                  "Secret-shaped directive \"" + name + "\" holds a value in the pasted config (flagged by name and line only — the value never appears in this tool's findings or reports). Anyone who can read this config file can read that secret: lock down the file's permissions and prefer a secrets store or environment-supplied credentials where your setup allows.",
                  sc.id);
              });
            }
          });
          (sc.byName["log_type"] || []).forEach(function (e) {
            var toks = e.value.toLowerCase().split(/[\s,]+/);
            if (toks.indexOf("all") !== -1 || toks.indexOf("debug") !== -1) {
              add("WARNING", e.line, sc.label, "log_type",
                "\"log_type " + firstToken(e.value) + "\" turns on verbose logging. Debug-level broker logs can capture connection detail, client identifiers, and credential-adjacent material — keep verbose logging off in production unless you are actively debugging.",
                sc.id);
            }
          });
        });

        /* ---- broker user (global) ---- */
        var userE = lastEntry(global, "user");
        if (!userE) {
          add("INFO", null, "Global", "user",
            "NOT SET — no \"user\" directive in the paste. If the broker is started as root, it may keep running with more privilege than it needs; set \"user\" to a dedicated unprivileged account.",
            "global");
        } else if (firstToken(userE.value).toLowerCase() === "root") {
          add("BLOCKER", userE.line, "Global", "user",
            "\"user root\" — the broker is configured to run as root. A broker flaw then becomes a full host compromise. Drop to a dedicated unprivileged user (for example \"user mosquitto\").",
            "global");
        } else {
          add("GOOD", userE.line, "Global", "user",
            "\"user " + firstToken(userE.value) + "\" — the broker drops to a named non-root user, limiting the blast radius of a broker flaw.",
            "global");
        }

        /* ---- listener model ---- */
        var work = listeners.slice();
        if (work.length === 0) {
          var portE = lastEntry(global, "port");
          var imp = makeScope("listener", "Default listener (no listener directive — global settings apply)", "listener-0");
          imp.port = portE ? (parseInt(firstToken(portE.value), 10) || 1883) : 1883;
          imp.host = null; imp.startLine = portE ? portE.line : null; imp.implicit = true;
          imp.entries = global.entries; imp.byName = global.byName;
          work = [imp];
        }
        function eff(L, name) { return lastEntry(L, name) || lastEntry(global, name); }

        var summaries = [];
        work.forEach(function (L) {
          var bindAddrE = eff(L, "bind_address");
          var bindIfaceE = eff(L, "bind_interface");
          var host = L.host || (bindAddrE ? firstToken(bindAddrE.value) : null);
          var local = isLocalhost(host);
          var bindDesc = host ? ("bound to " + host)
            : bindIfaceE ? ("bound to interface " + firstToken(bindIfaceE.value))
            : "all interfaces (no bind restriction)";

          var anonE = eff(L, "allow_anonymous");
          var anon = anonE ? firstToken(anonE.value).toLowerCase() : null;

          /* allow_anonymous posture */
          if (anon === "true") {
            if (local) {
              add("WARNING", anonE.line, L.label, "allow_anonymous",
                "allow_anonymous is true on listener " + L.port + ". The listener is bound to localhost only, which contains the exposure — but any local process or forwarded tunnel can still connect with no credentials. Set it false unless local anonymous access is deliberate.",
                L.id);
            } else {
              add("BLOCKER", anonE.line, L.label, "allow_anonymous",
                "allow_anonymous true on listener " + L.port + ", which is " + bindDesc + " — not restricted to localhost. Anyone who can reach this port can connect, publish, and subscribe with no credentials at all. Set allow_anonymous false and require authentication, or bind the listener to localhost.",
                L.id);
            }
          } else if (anon === "false") {
            add("GOOD", anonE.line, L.label, "allow_anonymous",
              "allow_anonymous false on listener " + L.port + " — anonymous connections are refused; clients must authenticate.",
              L.id);
          } else if (anon === null) {
            if (local) {
              add("INFO", L.startLine, L.label, "allow_anonymous",
                "NOT SET — allow_anonymous is not set for listener " + L.port + " (bound to localhost). Absent means the Mosquitto default for your version and build applies, so the anonymous posture is unsettled; set it explicitly either way.",
                L.id);
            } else {
              add("WARNING", L.startLine, L.label, "allow_anonymous",
                "NOT SET — allow_anonymous is not set for listener " + L.port + ", which is " + bindDesc + ". Absent means the Mosquitto default for your version and build applies, so the anonymous posture is unsettled — and on some versions that default permits anonymous access. Set allow_anonymous explicitly before deploying.",
                L.id);
            }
          } else {
            add("WARNING", anonE.line, L.label, "allow_anonymous",
              "allow_anonymous on listener " + L.port + " carries a value that is neither \"true\" nor \"false\" — the anonymous posture cannot be graded from it. Use an explicit true or false.",
              L.id);
          }

          /* TLS posture */
          var ca = eff(L, "cafile"), ce = eff(L, "certfile"), ke = eff(L, "keyfile");
          var tlsCount = (ca ? 1 : 0) + (ce ? 1 : 0) + (ke ? 1 : 0);
          var tlsState;
          if (tlsCount === 3) {
            tlsState = "Full TLS (cafile + certfile + keyfile)";
            add("GOOD", ke.line, L.label, "keyfile",
              "Listener " + L.port + " names a full TLS file set — cafile, certfile, and keyfile — so broker traffic on this listener is encrypted.",
              L.id);
          } else if (tlsCount > 0) {
            tlsState = "Partial TLS";
            var present = [], missing = [];
            [["cafile", ca], ["certfile", ce], ["keyfile", ke]].forEach(function (pair) {
              (pair[1] ? present : missing).push(pair[0]);
            });
            var anchor = ke || ce || ca;
            add("WARNING", anchor.line, L.label, present[0],
              "Partial TLS on listener " + L.port + ": " + present.join(", ") + " set, but " + missing.join(", ") + " missing. A listener TLS setup needs the CA file, the server certificate, and the server key together; as pasted, this listener's encryption posture is incomplete and the broker may refuse the listener or fall back in ways you did not intend.",
              L.id);
          } else {
            tlsState = "None (plaintext)";
          }

          var rcE = eff(L, "require_certificate");
          if (rcE && firstToken(rcE.value).toLowerCase() === "true") {
            add("GOOD", rcE.line, L.label, "require_certificate",
              "require_certificate true on listener " + L.port + " — clients must present a certificate, giving mutual TLS authentication on top of any password check.",
              L.id);
          }
          var tvE = eff(L, "tls_version");
          if (tvE) {
            var tv = tvE.value.toLowerCase();
            var mm = tv.match(/(\d+)\.(\d+)/);
            var below = false;
            if (mm) { below = parseFloat(mm[1] + "." + mm[2]) < 1.2; }
            else if (tv.indexOf("tlsv1") === 0) { below = true; }
            if (below) {
              add("BLOCKER", tvE.line, L.label, "tls_version",
                "tls_version on listener " + L.port + " permits TLS protocol versions below 1.2, which carry known weaknesses. Set tls_version to tlsv1.2 or higher (prefer tlsv1.3 where your clients support it).",
                L.id);
            }
          }

          /* plaintext exposure */
          if (tlsCount === 0) {
            if (local) {
              add("INFO", L.startLine, L.label, null,
                "Listener " + L.port + " is plaintext (no TLS files) but bound to localhost only — acceptable for local-only use; do not expose it beyond this host without TLS.",
                L.id);
            } else if (anon === "true") {
              add("BLOCKER", L.startLine, L.label, null,
                "Plaintext exposure with anonymous access: listener " + L.port + " listens on " + bindDesc + " with no TLS files, and allow_anonymous is true. Anyone in reach can connect without credentials and read or inject every message in cleartext. Add TLS (cafile, certfile, keyfile) and require authentication.",
                L.id);
            } else {
              add("WARNING", L.startLine, L.label, null,
                "Plaintext exposure: listener " + L.port + " listens on " + bindDesc + " with no TLS files (no cafile / certfile). MQTT traffic — including client credentials — crosses the network unencrypted. Add a full TLS file set, or bind the listener to localhost.",
                L.id);
            }
          }

          /* authentication & ACL files (effective scope) */
          var pwE = eff(L, "password_file");
          if (anon === "false") {
            if (pwE) {
              add("GOOD", pwE.line, L.label, "password_file",
                "password_file is named for listener " + L.port + ", matching allow_anonymous false — password authentication has a credential source in the config.",
                L.id);
            } else {
              add("WARNING", anonE.line, L.label, "password_file",
                "allow_anonymous is false on listener " + L.port + ", but no password_file is named anywhere in the pasted config — is authentication supplied another way, for example by an auth plugin or a password file set in configuration that was not pasted here? If not, no client will be able to authenticate at all.",
                L.id);
            }
          }
          var aclE = eff(L, "acl_file");
          if (aclE) {
            add("GOOD", aclE.line, L.label, "acl_file",
              "acl_file is named for listener " + L.port + " — per-user topic restrictions have a defined source.",
              L.id);
          } else {
            add("INFO", L.startLine, L.label, "acl_file",
              "NOT SET — no acl_file named for listener " + L.port + ". Without an ACL file (or a plugin providing one), every authenticated client can publish and subscribe to every topic.",
              L.id);
          }

          /* capacity limits (INFO only) */
          if (!eff(L, "max_connections")) {
            add("INFO", L.startLine, L.label, "max_connections",
              "NOT SET — max_connections is not set for listener " + L.port + ", so no connection cap is stated in the paste; the Mosquitto default (unlimited) applies.",
              L.id);
          }
          if (!eff(L, "max_queued_messages")) {
            add("INFO", L.startLine, L.label, "max_queued_messages",
              "NOT SET — max_queued_messages is not set for listener " + L.port + ", so queued-message memory for offline clients is bounded only by the Mosquitto default.",
              L.id);
          }

          summaries.push({
            id: L.id,
            port: L.port,
            line: L.startLine,
            implicit: !!L.implicit,
            bind: bindDesc,
            tls: tlsState,
            anonymous: anon === null ? "NOT SET" : anon,
            passwordFile: !!pwE,
            aclFile: !!aclE,
            counts: { BLOCKER: 0, WARNING: 0, INFO: 0, GOOD: 0 }
          });
        });

        /* ---- tally, sort, verdict ---- */
        var counts = { BLOCKER: 0, WARNING: 0, INFO: 0, GOOD: 0 };
        findings.forEach(function (f) {
          counts[f.severity]++;
          summaries.forEach(function (s) { if (s.id === f.scopeId) s.counts[f.severity]++; });
        });
        findings.sort(function (a, b) {
          var d = SEV_ORDER[a.severity] - SEV_ORDER[b.severity];
          if (d !== 0) return d;
          var la = a.line === null ? 1e9 : a.line, lb = b.line === null ? 1e9 : b.line;
          return la - lb;
        });
        var verdict = counts.BLOCKER > 0 ? "DO NOT DEPLOY"
          : counts.WARNING > 0 ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY";
        return { empty: false, verdict: verdict, counts: counts, findings: findings, listeners: summaries };
      }

      /* ============================ examples ============================ */
      var RISKY = [
        "# Risky example — for demonstration only. Do not deploy anything like this.",
        "user root",
        "",
        "listener 1883",
        "allow_anonymous true",
        "",
        "connection upstream",
        "address 203.0.113.10:1883",
        "remote_username bridgeuser",
        "remote_password FAKE-EXAMPLE-ONLY-456",
        ""
      ].join("\n");

      var HARDENED = [
        "# Hardened example — authentication required, full TLS, unprivileged user.",
        "user mosquitto",
        "persistence true",
        "",
        "listener 8883 192.168.1.50",
        "allow_anonymous false",
        "password_file /etc/mosquitto/passwd",
        "acl_file /etc/mosquitto/acl",
        "cafile /etc/mosquitto/certs/ca.crt",
        "certfile /etc/mosquitto/certs/server.crt",
        "keyfile /etc/mosquitto/certs/server.key",
        "require_certificate true",
        "tls_version tlsv1.2",
        "max_connections 200",
        "max_queued_messages 1000",
        ""
      ].join("\n");

      /* ============================ reporting ============================ */
      function findingText(f) {
        return "[" + f.severity + "] " +
          (f.line !== null ? "Line " + f.line + " · " : "") +
          f.scope + (f.directive ? " · " + f.directive : "") + " — " + f.message;
      }
      function buildTextReport(r) {
        var out = [];
        out.push("J-Dawgs Mosquitto MQTT Broker Config Safety Auditor — Audit Report");
        out.push("Verdict: " + r.verdict);
        out.push("Findings: " + r.counts.BLOCKER + " BLOCKER · " + r.counts.WARNING + " WARNING · " +
                 r.counts.INFO + " INFO · " + r.counts.GOOD + " GOOD");
        out.push("");
        out.push("FINDINGS");
        r.findings.forEach(function (f) { out.push(findingText(f)); });
        out.push("");
        out.push("PER-LISTENER SUMMARY");
        r.listeners.forEach(function (s) {
          out.push("- Listener " + s.port + (s.line ? " (line " + s.line + ")" : "") + (s.implicit ? " [default listener]" : "") +
            ": bind = " + s.bind + "; TLS = " + s.tls + "; allow_anonymous = " + s.anonymous +
            "; password_file = " + (s.passwordFile ? "set" : "not set") +
            "; acl_file = " + (s.aclFile ? "set" : "not set") +
            "; findings: " + s.counts.BLOCKER + " BLOCKER, " + s.counts.WARNING + " WARNING, " +
            s.counts.INFO + " INFO, " + s.counts.GOOD + " GOOD.");
        });
        out.push("");
        out.push("Notes: heuristic text audit only — not the Mosquitto parser. The broker was not started, " +
                 "no connection was made, and no credentials were tested. Secret-shaped directives are flagged " +
                 "by name and line only; their values never appear in this report.");
        return out.join("\n");
      }
      function buildJsonReport(r) {
        var obj = {
          tool: "J-Dawgs Mosquitto MQTT Broker Config Safety Auditor",
          verdict: r.verdict,
          counts: {
            blocker: r.counts.BLOCKER, warning: r.counts.WARNING,
            info: r.counts.INFO, good: r.counts.GOOD
          },
          listeners: r.listeners.map(function (s) {
            return {
              port: s.port, line: s.line, defaultListener: s.implicit, bind: s.bind,
              tls: s.tls, allowAnonymous: s.anonymous,
              passwordFile: s.passwordFile, aclFile: s.aclFile,
              counts: {
                blocker: s.counts.BLOCKER, warning: s.counts.WARNING,
                info: s.counts.INFO, good: s.counts.GOOD
              }
            };
          }),
          findings: r.findings.map(function (f) {
            return {
              severity: f.severity, line: f.line, scope: f.scope,
              directive: f.directive, message: f.message
            };
          }),
          notes: "Heuristic text audit only — not the Mosquitto parser. No broker was contacted and no credentials were tested. Secret-shaped directives are flagged by name and line only; their values are never included."
        };
        return JSON.stringify(obj, null, 2);
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-mosquitto-mqtt-broker-config-safety-auditor',
  name: 'J-Dawgs Mosquitto MQTT Broker Config Safety Auditor',
  description: 'Mosquitto’s own config test is host-bound and stops at load validity; ours grades a pasted mosquitto.conf offline — anonymous access, listener exposure, TLS posture, per-listener summary — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
