'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Formbricks Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var RELEVANT_KEYS = {
        ENCRYPTION_KEY:1, NEXTAUTH_SECRET:1, NEXTAUTH_URL:1, WEBAPP_URL:1, DATABASE_URL:1,
        SIGNUP_DISABLED:1, PUBLIC_SIGNUP:1, ALLOW_SIGNUP:1, SIGNUPS_OPEN:1,
        EMAIL_VERIFICATION_DISABLED:1, REQUIRE_EMAIL_VERIFICATION:1,
        MAIL_FROM:1, SMTP_HOST:1, SMTP_PORT:1, SMTP_USER:1, SMTP_PASSWORD:1, SMTP_SECURE:1,
        CRON_SECRET:1, FORMBRICKS_API_KEY:1, API_KEY:1
      };

      function isRelevant(key){
        if (RELEVANT_KEYS[key]) return true;
        if (key.indexOf("SMTP_") === 0) return true;
        if (key.indexOf("FORMBRICKS") === 0) return true;
        return false;
      }

      function isPlaceholder(v){
        var s = v.toLowerCase();
        var subs = ["example","changeme","change-me","change_this","changethis","your-","placeholder","test","secret123","password123"];
        for (var i=0;i<subs.length;i++){ if (s.indexOf(subs[i]) !== -1) return true; }
        if (s === "secret" || s === "password") return true;
        if (/^(.)\1+$/.test(v)) return true;
        if (v.length >= 4 && /^(.{1,4})\1+$/.test(v)) return true;
        return false;
      }

      function truthy(v){ var s=v.toLowerCase(); return s==="true"||s==="1"||s==="yes"||s==="allow"||s==="allowed"||s==="open"||s==="enabled"||s==="on"; }
      function falsy(v){ var s=v.toLowerCase(); return s==="false"||s==="0"||s==="no"||s==="disabled"||s==="off"||s==="closed"; }

      function auditConfig(text){
        var lines = String(text == null ? "" : text).split(/\r?\n/);
        var entries = [];           // {key, value, line}
        var byKey = {};
        var parseFindings = [];

        for (var i=0;i<lines.length;i++){
          var lineNo = i+1;
          var raw = lines[i];
          var trimmed = raw.trim();
          if (trimmed === "") continue;
          if (trimmed.charAt(0) === "#") continue;
          var work = trimmed;
          if (work.indexOf("export ") === 0) work = work.slice(7).trim();
          var eq = work.indexOf("=");
          if (eq === -1){
            // Malformed: looks like config (leading ALL-CAPS key-like token) but no = sign
            if (/^[A-Z][A-Z0-9_]{2,}\b/.test(work) || /^[A-Z][A-Z0-9_]*\s+\S/.test(work)){
              parseFindings.push({severity:"WARNING", key: work.split(/\s+/)[0].slice(0,60), line: lineNo, message:"Line looks like configuration but has no = sign, so it was not read as a setting.", valueLength: null});
            }
            continue;
          }
          var key = work.slice(0, eq).trim();
          var value = work.slice(eq+1).trim();
          if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(key)) continue;
          key = key.toUpperCase();
          if (value.length >= 2 && ((value.charAt(0)==='"' && value.charAt(value.length-1)==='"') || (value.charAt(0)==="'" && value.charAt(value.length-1)==="'"))){
            value = value.slice(1, -1);
          }
          var entry = {key:key, value:value, line:lineNo};
          if (byKey[key]){
            parseFindings.push({severity:"WARNING", key:key, line:lineNo, message:"Duplicate key: this key was already set on line " + byKey[key].line + "; the later value is the one used here.", valueLength: value.length});
          }
          entries.push(entry);
          byKey[key] = entry;
        }

        var relevantCount = 0;
        var seenRel = {};
        entries.forEach(function(e){ if (isRelevant(e.key) && !seenRel[e.key]){ seenRel[e.key]=1; relevantCount++; } });

        // Not enough to grade: too few recognizable lines, or nothing Formbricks-relevant.
        if (entries.length < 3 || relevantCount === 0){
          return {
            verdict: "NOT ENOUGH TO GRADE",
            note: entries.length < 3
              ? "Fewer than 3 recognizable KEY=value config lines were found, so there is not enough configuration here to grade."
              : "No Formbricks-relevant keys were found in the pasted text, so there is nothing to grade.",
            configLines: entries.length,
            relevantKeys: relevantCount,
            critical: 0, warnings: 0,
            findings: []
          };
        }

        var findings = parseFindings.slice();

        function add(sev, key, line, msg, vlen, extra){
          var f = {severity:sev, key:key, line:line, message:msg, valueLength:(vlen === undefined ? null : vlen)};
          if (extra){ for (var k in extra) f[k]=extra[k]; }
          findings.push(f);
        }
        function missingLine(key){ return byKey[key] ? byKey[key].line : null; }

        // 1 & 2: ENCRYPTION_KEY and NEXTAUTH_SECRET
        ["ENCRYPTION_KEY","NEXTAUTH_SECRET"].forEach(function(k){
          var e = byKey[k];
          if (!e){
            add("CRITICAL", k, null, k + " is missing. The deployment needs a long, random value here before it can be trusted.", null);
          } else if (isPlaceholder(e.value)){
            add("CRITICAL", k, e.line, k + " looks like a placeholder or example value, not a real secret. Replace it with a long, random value.", e.value.length);
          } else if (e.value.length < 32){
            add("CRITICAL", k, e.line, k + " is too short: " + e.value.length + " characters (minimum 32). Use a long, random value.", e.value.length);
          }
        });

        // 3: WEBAPP_URL
        var web = byKey["WEBAPP_URL"];
        if (!web){
          add("WARNING", "WEBAPP_URL", null, "WEBAPP_URL is missing. Set it to the public https address where this deployment is reached.", null);
        } else {
          var wv = web.value;
          if (/^http:\/\//i.test(wv)){
            add("CRITICAL", "WEBAPP_URL", web.line, "WEBAPP_URL starts with http:// — it must use https:// so logins and survey data are encrypted in transit.", wv.length);
          }
          if (/(localhost|127\.0\.0\.1)/i.test(wv)){
            add("WARNING", "WEBAPP_URL", web.line, "WEBAPP_URL points at localhost / 127.0.0.1. That only works on the same machine; a deployed (non-local) instance needs its public address.", wv.length);
          }
        }

        // 4: DATABASE_URL
        var db = byKey["DATABASE_URL"];
        if (!db){
          add("WARNING", "DATABASE_URL", null, "DATABASE_URL is missing. The deployment cannot store data without a database connection string.", null);
        } else {
          var dv = db.value;
          var m = /^[a-z][a-z0-9+.-]*:\/\/([^@/?#]+)@/i.exec(dv);
          if (m && m[1].indexOf(":") !== -1){
            var pwLen = m[1].slice(m[1].indexOf(":")+1).length;
            add("WARNING", "DATABASE_URL", db.line, "DATABASE_URL embeds a password in plaintext in the configuration (password length: " + pwLen + " characters — the password itself is never shown here). Anyone who can read this file has the database password; prefer a secrets manager or a restricted file.", dv.length, {passwordLength: pwLen});
          }
          if (/sslmode=disable/i.test(dv)){
            add("WARNING", "DATABASE_URL", db.line, "DATABASE_URL sets sslmode=disable, so the database connection is not encrypted. Use sslmode=require or stronger.", dv.length);
          } else if (!/(sslmode=(require|verify-ca|verify-full)|ssl=true|sslmode=prefer)/i.test(dv)){
            add("WARNING", "DATABASE_URL", db.line, "DATABASE_URL shows no TLS indication (no sslmode=require or equivalent), so it is unclear whether the database connection is encrypted.", dv.length);
          }
        }

        // 5: Public signup
        var sd = byKey["SIGNUP_DISABLED"];
        if (sd && falsy(sd.value)){
          add("WARNING", "SIGNUP_DISABLED", sd.line, "SIGNUP_DISABLED is set to a false value, so public signup is open: anyone can create an account. Disable signup once your team is in, unless open registration is intended.", sd.value.length);
        }
        ["PUBLIC_SIGNUP","ALLOW_SIGNUP","SIGNUPS_OPEN"].forEach(function(k){
          var e = byKey[k];
          if (e && truthy(e.value)){
            add("WARNING", k, e.line, k + " allows open public signup: anyone can create an account. Close it unless open registration is intended.", e.value.length);
          }
        });

        // 6: Email verification + mail settings
        var verificationDisabled = false;
        var evd = byKey["EMAIL_VERIFICATION_DISABLED"];
        if (evd && truthy(evd.value)){
          verificationDisabled = true;
          add("WARNING", "EMAIL_VERIFICATION_DISABLED", evd.line, "Email verification is disabled, so accounts can be created with addresses the owner never proved they control.", evd.value.length);
        }
        var rev = byKey["REQUIRE_EMAIL_VERIFICATION"];
        if (rev && falsy(rev.value)){
          verificationDisabled = true;
          add("WARNING", "REQUIRE_EMAIL_VERIFICATION", rev.line, "Email verification is not required, so accounts can be created with unproven email addresses.", rev.value.length);
        }
        if (!verificationDisabled){
          var hasMailFrom = !!byKey["MAIL_FROM"];
          var hasSmtp = !!(byKey["SMTP_HOST"] || byKey["SMTP_USER"] || byKey["SMTP_PORT"]);
          if (!hasMailFrom && !hasSmtp){
            add("WARNING", "MAIL_FROM", null, "Email verification is expected, but no MAIL_FROM and no SMTP settings are present, so verification mail has no way to be sent. Add MAIL_FROM and your SMTP settings.", null);
          }
        }

        // 7: Other secret-like keys
        entries.forEach(function(e){
          if (e.key === "ENCRYPTION_KEY" || e.key === "NEXTAUTH_SECRET") return;
          if (!/(SECRET|KEY|PASSWORD|TOKEN)/.test(e.key)) return;
          if (e.value.length < 16){
            add("WARNING", e.key, e.line, "Secret-like key " + e.key + " is short: " + e.value.length + " characters (under 16). Use a longer, random value.", e.value.length);
          } else if (isPlaceholder(e.value)){
            add("WARNING", e.key, e.line, "Secret-like key " + e.key + " looks like a placeholder or example value. Replace it with a real, random value.", e.value.length);
          }
        });

        var crit = 0, warn = 0;
        findings.forEach(function(f){ if (f.severity==="CRITICAL") crit++; else if (f.severity==="WARNING") warn++; });

        var verdict, note;
        if (crit > 0){ verdict = "DO NOT DEPLOY"; note = "At least one CRITICAL finding must be fixed before this configuration is deployed."; }
        else if (warn > 0){ verdict = "DEPLOY WITH FIXES"; note = "No critical problems, but at least one warning should be fixed before or right after deploying."; }
        else if (relevantCount >= 3){ verdict = "SAFE TO DEPLOY"; note = "At least 3 relevant keys are present and no critical or warning findings were raised against the rules on this page. This grades the pasted text only — it is not a guarantee about the rest of the deployment."; }
        else { verdict = "NOT ENOUGH TO GRADE"; note = "Not enough relevant configuration to grade."; }

        return { verdict: verdict, note: note, configLines: entries.length, relevantKeys: relevantCount, critical: crit, warnings: warn, findings: findings };
      }

      function buildReport(result){
        return {
          tool: "J-Dawgs Formbricks Server Config Safety Auditor",
          verdict: result.verdict,
          counts: { configLines: result.configLines, relevantKeys: result.relevantKeys, critical: result.critical, warnings: result.warnings, totalFindings: result.findings.length },
          findings: result.findings
        };
      }

      function summaryText(result){
        var out = [];
        out.push("Verdict: " + result.verdict);
        out.push("Config lines: " + result.configLines + " | Relevant keys: " + result.relevantKeys + " | Critical: " + result.critical + " | Warnings: " + result.warnings + " | Total findings: " + result.findings.length);
        if (result.findings.length === 0){ out.push("Findings: none."); }
        result.findings.forEach(function(f){
          out.push("- [" + f.severity + "] " + f.key + " (line " + (f.line === null ? "not present" : f.line) + ", value length: " + (f.valueLength === null ? "n/a" : f.valueLength) + "): " + f.message);
        });
        return out.join("\n");
      }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-formbricks-server-config-safety-auditortm',
  name: 'J-Dawgs Formbricks Server Config Safety Auditor',
  description: 'Grades a pasted Formbricks server config offline into one deploy verdict, secrets by key name/line/length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
