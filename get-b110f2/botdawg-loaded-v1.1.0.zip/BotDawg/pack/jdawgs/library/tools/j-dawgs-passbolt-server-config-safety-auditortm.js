'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Passbolt Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

/* ---------- Example configs (all credentials planted and fake) ---------- */

var RISKY_LINES = [
  "<?php",
  "// FAKE example config - planted issues only, not real credentials",
  "return [",
  "    'App' => [",
  "        'fullBaseUrl' => 'http://passbolt.example.test',",
  "        'debug' => true,",
  "    ],",
  "    'Datasources' => [",
  "        'default' => [",
  "            'host' => 'localhost',",
  "            'database' => 'passbolt_fake',",
  "            'username' => 'passbolt_fake_user',",
  "            'password' => 'db-pass-planted-123',",
  "        ],",
  "    ],",
  "    'EmailTransport' => [",
  "        'default' => [",
  "            'username' => 'alerts@example.test',",
  "            'password' => 'smtp-pass-planted-456',",
  "        ],",
  "    ],",
  "    'passbolt' => [",
  "        'gpg' => [",
  "            'serverKey' => [",
  "                'fingerprint' => '',",
  "                'passphrase' => 'gpg-pass-planted-789',",
  "            ],",
  "        ],",
  "        'registration' => [",
  "            'public' => true,",
  "        ],",
  "        'ssl' => [",
  "            'force' => false,",
  "        ],",
  "    ],",
  "];"
];
var RISKY = RISKY_LINES.join("\n");

var HARDENED_LINES = [
  "# FAKE hardened example - no real credentials, secrets by reference only",
  "APP_FULL_BASE_URL=https://passbolt.example.test",
  "APP_DEBUG=false",
  "PASSBOLT_SSL_FORCE=true",
  "DATASOURCES_DEFAULT_HOST=db.internal",
  "DATASOURCES_DEFAULT_DATABASE=passbolt_fake",
  "DATASOURCES_DEFAULT_PASSWORD=${DB_PASSWORD_FROM_VAULT}",
  "EMAIL_TRANSPORT_DEFAULT_PASSWORD_FILE=/run/secrets/smtp_password",
  "PASSBOLT_GPG_KEY_FINGERPRINT=0123456789ABCDEF0123456789ABCDEF01234567",
  "PASSBOLT_GPG_KEY_PASSPHRASE=${GPG_PASSPHRASE_FROM_VAULT}",
  "PASSBOLT_REGISTRATION_PUBLIC=false"
];
var HARDENED = HARDENED_LINES.join("\n");

var NON_PASSBOLT = "Shopping list\n- eggs\n- coffee\nMeeting moved to Friday afternoon.";

var LEAK_LINES = [
  "APP_FULL_BASE_URL=https://passbolt.example.test",
  "APP_DEBUG=false",
  "PASSBOLT_SSL_FORCE=true",
  "DATASOURCES_DEFAULT_HOST=db.internal",
  "DATASOURCES_DEFAULT_DATABASE=passbolt_fake",
  "DATASOURCES_DEFAULT_PASSWORD=leak-check-secret-999",
  "PASSBOLT_GPG_KEY_FINGERPRINT=0123456789ABCDEF0123456789ABCDEF01234567",
  "PASSBOLT_GPG_KEY_PASSPHRASE=${GPG_PASSPHRASE_FROM_VAULT}",
  "PASSBOLT_REGISTRATION_PUBLIC=false"
];
var LEAK_CASE = LEAK_LINES.join("\n");

/* ---------- Parsing helpers ---------- */

function normKey(k){ return String(k).toLowerCase().replace(/[_\-.]/g, ""); }

function cleanValue(raw){
  var v = String(raw).trim();
  if (v.charAt(v.length - 1) === ",") v = v.slice(0, -1).trim();
  var m = v.match(/^'([^']*)'/) || v.match(/^"([^"]*)"/);
  if (m) return m[1];
  return v;
}

function parseBool(v){
  var s = String(v).trim().toLowerCase();
  if (s === "true" || s === "1" || s === "yes" || s === "on") return true;
  if (s === "false" || s === "0" || s === "no" || s === "off" || s === "") return false;
  return null;
}

function isRefValue(v){
  var s = String(v);
  return s.indexOf("${") !== -1 || s.indexOf("env(") !== -1 ||
         s.indexOf("getenv") !== -1 || s.toUpperCase().indexOf("_FILE") !== -1;
}

function parseConfig(text){
  var lines = String(text).split(/\r?\n/);
  var entries = [];
  var notParsed = [];
  var stack = [];
  var i, raw, t, m, key, rawVal, val;
  for (i = 0; i < lines.length; i++){
    raw = lines[i];
    t = raw.trim();
    var lineNo = i + 1;
    if (t === "") continue;
    if (t.indexOf("//") === 0 || t.indexOf("#") === 0 || t.indexOf("/*") === 0 ||
        t.indexOf("*") === 0 || t.indexOf("<!--") === 0) continue;
    if (t === "<?php" || t === "?>") continue;
    if (/^return\s+(array\s*\()?\[?\s*$/.test(t)) { stack.push("root"); continue; }
    if (t === "]," || t === "]" || t === "];" || t === ")," || t === ");" || t === "]" ) { stack.pop(); continue; }

    m = t.match(/^['"]([^'"]+)['"]\s*=>\s*(.*)$/) || t.match(/^([A-Za-z_][A-Za-z0-9_]*)\s*=>\s*(.*)$/);
    if (m){
      key = m[1]; rawVal = m[2];
      var section = stack.join("/");
      if (/^\[?\s*$/.test(rawVal) || /^\[\s*$/.test(rawVal.trim()) || rawVal.trim() === "[" || rawVal.trim() === "array("){
        entries.push({ key:key, nkey:normKey(key), value:"", line:lineNo, format:"php", section:section, isArray:true });
        stack.push(normKey(key));
      } else {
        val = cleanValue(rawVal);
        entries.push({ key:key, nkey:normKey(key), value:val, line:lineNo, format:"php", section:section, isArray:false });
      }
      continue;
    }
    m = t.match(/^([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/);
    if (m){
      key = m[1];
      val = cleanValue(m[2]);
      entries.push({ key:key, nkey:normKey(key), value:val, line:lineNo, format:"env", section:"", isArray:false });
      continue;
    }
    if (/^[\]\[\(\)\{\};,\s]+$/.test(t)) { if (t.indexOf("]") !== -1 || t.indexOf(")") !== -1) stack.pop(); continue; }
    notParsed.push({ line: lineNo, length: t.length });
  }
  return { entries: entries, notParsed: notParsed, lineCount: lines.length };
}

function findEntries(entries, test){
  var out = [];
  for (var i = 0; i < entries.length; i++) if (test(entries[i])) out.push(entries[i]);
  return out;
}

/* ---------- Audit ---------- */

var KNOWN_TOKENS = ["fullbaseurl","debug","fingerprint","passphrase","datasources","passbolt","gpg","ssl","registration","smtp","emailtransport","password"];

function audit(text){
  var parsed = parseConfig(text);
  var entries = parsed.entries;
  var findings = [];
  function add(grade, line, key, message, category){
    findings.push({ grade:grade, line:(typeof line === "number" ? line : null), key:key || "", category:category || "", message:message });
  }

  var recognizable = false;
  var j;
  for (j = 0; j < entries.length; j++){
    for (var k = 0; k < KNOWN_TOKENS.length; k++){
      if (entries[j].nkey.indexOf(KNOWN_TOKENS[k]) !== -1){ recognizable = true; break; }
    }
    if (recognizable) break;
  }
  if (!recognizable && String(text).toLowerCase().indexOf("passbolt") !== -1 && entries.length > 0) recognizable = true;

  if (!recognizable){
    add("INFO", null, "", "This paste contains no recognizable Passbolt config keys (no fullBaseUrl, debug, datasource, GPG, registration, or Passbolt env keys were found), so there is not enough Passbolt config here to grade.");
    return finish("NOT ENOUGH TO GRADE", findings, parsed);
  }

  /* NOT PARSED lines */
  for (j = 0; j < parsed.notParsed.length; j++){
    add("INFO", parsed.notParsed[j].line, "", "NOT PARSED: this line matches neither a PHP key line nor a KEY=VALUE line (" + parsed.notParsed[j].length + " chars) - content not shown.", "NOT PARSED");
  }

  /* debug */
  var debugs = findEntries(entries, function(e){ return e.nkey === "debug" || e.nkey === "appdebug"; });
  for (j = 0; j < debugs.length; j++){
    if (parseBool(debugs[j].value) === true)
      add("BLOCKER", debugs[j].line, debugs[j].key, "Debug mode is ON (key " + debugs[j].key + "). Debug output leaks config and stack details - turn it off for production.");
    else if (parseBool(debugs[j].value) === false)
      add("INFO", debugs[j].line, debugs[j].key, "Debug mode is off (key " + debugs[j].key + "). Good production posture.");
  }

  /* fullBaseUrl */
  var urls = findEntries(entries, function(e){ return e.nkey.indexOf("fullbaseurl") !== -1; });
  var urlEntry = urls.length ? urls[0] : null;
  var urlIsHttp = false;
  if (!urlEntry){
    add("WARNING", null, "fullBaseUrl", "No fullBaseUrl setting found. Passbolt builds links and redirects from this URL - set it explicitly to the public https address.");
  } else if (String(urlEntry.value).trim() === ""){
    add("WARNING", urlEntry.line, urlEntry.key, "fullBaseUrl is present but empty (key " + urlEntry.key + "). Set it to the public https address of the server.");
  } else if (/^http:\/\//i.test(urlEntry.value)){
    urlIsHttp = true;
    add("HIGH", urlEntry.line, urlEntry.key, "fullBaseUrl uses plain http:// (key " + urlEntry.key + "). Session cookies and password-manager traffic would cross the network unencrypted - use https://.");
  } else if (/^https:\/\//i.test(urlEntry.value)){
    add("INFO", urlEntry.line, urlEntry.key, "fullBaseUrl uses https:// (key " + urlEntry.key + "). Good.");
  } else {
    add("WARNING", urlEntry.line, urlEntry.key, "fullBaseUrl value does not start with http:// or https:// (key " + urlEntry.key + ", value length " + String(urlEntry.value).length + "). Use a full https:// URL.");
  }

  /* SSL force */
  var forces = findEntries(entries, function(e){
    return e.nkey.indexOf("sslforce") !== -1 || e.nkey.indexOf("forcessl") !== -1 ||
           (e.nkey === "force" && e.section.indexOf("ssl") !== -1) ||
           e.nkey === "passboltsslforce";
  });
  var forceEntry = forces.length ? forces[0] : null;
  if (urlIsHttp){
    if (!forceEntry)
      add("HIGH", urlEntry.line, urlEntry.key, "The URL is http:// and no SSL force setting was found. Enable SSL forcing (ssl force = true) together with an https:// fullBaseUrl.");
    else if (parseBool(forceEntry.value) !== true)
      add("HIGH", forceEntry.line, forceEntry.key, "SSL forcing is disabled (key " + forceEntry.key + ") while fullBaseUrl is http://. Enable SSL forcing and switch the URL to https://.");
  } else if (forceEntry && parseBool(forceEntry.value) === false && urlEntry && /^https:\/\//i.test(urlEntry.value)){
    add("WARNING", forceEntry.line, forceEntry.key, "SSL forcing is disabled (key " + forceEntry.key + ") even though the URL is https. Turning it on closes off plain-http access paths.");
  } else if (forceEntry && parseBool(forceEntry.value) === true){
    add("INFO", forceEntry.line, forceEntry.key, "SSL forcing is enabled (key " + forceEntry.key + "). Good.");
  }

  /* Passwords - classified, values never shown */
  var passEntries = findEntries(entries, function(e){ return !e.isArray && (e.nkey.indexOf("password") !== -1 || e.nkey.indexOf("passphrase") !== -1); });
  var hasDbPassword = false, hasSmtpPassword = false, gpgPassEntry = null;
  for (j = 0; j < passEntries.length; j++){
    var e = passEntries[j];
    var isFileKey = /_FILE$/i.test(e.key) || e.nkey.slice(-4) === "file" && e.nkey.indexOf("password") !== -1;
    var isPassphrase = e.nkey.indexOf("passphrase") !== -1 || (e.section.indexOf("gpg") !== -1 && e.nkey.indexOf("password") !== -1);
    var hay = (e.nkey + "/" + e.section);
    var isSmtp = hay.indexOf("email") !== -1 || hay.indexOf("smtp") !== -1;
    var isDb = hay.indexOf("datasources") !== -1 || hay.indexOf("database") !== -1 || e.nkey.indexOf("dbpassword") !== -1 || (!isSmtp && !isPassphrase);
    var label = isPassphrase ? "GPG server key passphrase" : (isSmtp ? "SMTP / email password" : "database password");
    if (isPassphrase) gpgPassEntry = e;
    if (isDb && !isPassphrase) hasDbPassword = true;
    if (isSmtp) hasSmtpPassword = true;

    if (isFileKey){
      add("INFO", e.line, e.key, label + " is supplied through a *_FILE secret file reference (key " + e.key + ") - value not read, treated as safe.");
    } else if (String(e.value).trim() === ""){
      if (isPassphrase)
        add("WARNING", e.line, e.key, "GPG server key passphrase is empty (key " + e.key + "). An unprotected server key means anyone who copies the key file can use it.");
      else
        add("WARNING", e.line, e.key, "The " + label + " is present but empty (key " + e.key + "). Confirm the credential is injected at deploy time, not left blank.");
    } else if (isRefValue(e.value)){
      add("INFO", e.line, e.key, label + " is supplied via an environment / secret reference (key " + e.key + ") rather than a plaintext value. Good.");
    } else {
      add("HIGH", e.line, e.key, "Plaintext " + label + " on key " + e.key + ", line " + e.line + ", length " + String(e.value).length + " - value not shown. Move it to an environment reference or a *_FILE secret so it does not live in the config file.");
    }
  }

  /* GPG fingerprint */
  var fps = findEntries(entries, function(e){ return e.nkey.indexOf("fingerprint") !== -1; });
  var fpEntry = fps.length ? fps[0] : null;
  if (!fpEntry){
    add("BLOCKER", null, "fingerprint", "No GPG server key fingerprint found. Passbolt cannot verify its server key without one - set the fingerprint of the server GPG key.");
  } else if (String(fpEntry.value).trim() === ""){
    add("BLOCKER", fpEntry.line, fpEntry.key, "GPG server key fingerprint is missing / empty (key " + fpEntry.key + "). Passbolt cannot verify its server key without a fingerprint.");
  } else {
    var stripped = String(fpEntry.value).replace(/\s+/g, "");
    if (/^[0-9a-fA-F]{40}$/.test(stripped))
      add("INFO", fpEntry.line, fpEntry.key, "GPG server key fingerprint is present and well-formed (40 hex characters, key " + fpEntry.key + ").");
    else
      add("HIGH", fpEntry.line, fpEntry.key, "GPG server key fingerprint looks malformed (key " + fpEntry.key + "): after removing spaces it is " + stripped.length + " characters, not the expected 40 hex characters - value not shown. Copy the exact fingerprint from the server key.");
  }
  if (fpEntry && String(fpEntry.value).trim() !== "" && !gpgPassEntry){
    add("WARNING", fpEntry.line, fpEntry.key, "A GPG server key is configured but no passphrase setting was found alongside it. If the key has a passphrase, supply it via an environment reference or *_FILE secret; if it truly has none, note that the key file alone is enough to use it.");
  }

  /* Registration */
  var regs = findEntries(entries, function(e){
    return e.nkey.indexOf("registrationpublic") !== -1 || e.nkey === "openregistration" ||
           (e.nkey === "public" && e.section.indexOf("registration") !== -1) ||
           (e.nkey === "registration" && !e.isArray);
  });
  for (j = 0; j < regs.length; j++){
    if (parseBool(regs[j].value) === true)
      add("HIGH", regs[j].line, regs[j].key, "Public / open registration is enabled (key " + regs[j].key + "). Anyone who can reach the server could try to register - close public registration for production and invite users instead.");
    else if (parseBool(regs[j].value) === false)
      add("INFO", regs[j].line, regs[j].key, "Public registration is closed (key " + regs[j].key + "). Good.");
  }

  /* Datasource host / database */
  var hosts = findEntries(entries, function(e){ return !e.isArray && (e.nkey === "host" || e.nkey.slice(-4) === "host") && (e.section.indexOf("datasources") !== -1 || e.nkey.indexOf("datasources") !== -1 || e.nkey === "host"); });
  var dbs = findEntries(entries, function(e){ return !e.isArray && (e.nkey === "database" || e.nkey.slice(-8) === "database") && (e.section.indexOf("datasources") !== -1 || e.nkey.indexOf("datasources") !== -1 || e.nkey === "database"); });
  if (!hosts.length)
    add("INFO", null, "host", "No datasource host setting was found in the paste. If the database host is set elsewhere this is fine; otherwise Passbolt needs it to reach the database.");
  if (!dbs.length)
    add("WARNING", null, "database", "No datasource database name was found in the paste. Confirm the database name is set, or Passbolt will not know which database to use.");

  return finish(null, findings, parsed);
}

function finish(forcedVerdict, findings, parsed){
  var order = { BLOCKER:0, HIGH:1, WARNING:2, INFO:3 };
  findings.sort(function(a,b){
    var la = a.line === null ? 99999 : a.line;
    var lb = b.line === null ? 99999 : b.line;
    if (la !== lb) return la - lb;
    return order[a.grade] - order[b.grade];
  });
  var counts = { BLOCKER:0, HIGH:0, WARNING:0, INFO:0 };
  for (var i = 0; i < findings.length; i++) counts[findings[i].grade]++;
  var verdict = forcedVerdict;
  if (!verdict){
    if (counts.BLOCKER > 0) verdict = "DO NOT DEPLOY";
    else if (counts.HIGH > 0) verdict = "DEPLOY WITH FIXES";
    else verdict = "SAFE TO DEPLOY";
  }
  return { verdict:verdict, counts:counts, findings:findings, linesAudited: parsed.lineCount };
}

/* ---------- Report / JSON builders (secret-free by construction) ---------- */

function buildReport(r){
  var out = [];
  out.push("J-Dawgs Passbolt Server Config Safety Auditor - Report");
  out.push("Verdict: " + r.verdict);
  out.push("Counts: BLOCKER " + r.counts.BLOCKER + " | HIGH " + r.counts.HIGH + " | WARNING " + r.counts.WARNING + " | INFO " + r.counts.INFO);
  out.push("Lines audited: " + r.linesAudited);
  out.push("Secret values are never included in this report - secrets are named by key, line, and value length only.");
  out.push("");
  out.push("Findings:");
  if (!r.findings.length) out.push("  (none)");
  for (var i = 0; i < r.findings.length; i++){
    var f = r.findings[i];
    out.push("  [" + f.grade + "] Line " + (f.line === null ? "-" : f.line) + (f.key ? " (" + f.key + ")" : "") + " - " + f.message);
  }
  return out.join("\n");
}

function buildJSON(r){
  var obj = {
    tool: "J-Dawgs Passbolt Server Config Safety Auditor",
    verdict: r.verdict,
    counts: r.counts,
    linesAudited: r.linesAudited,
    secretHandling: "Secret values are never exported. Secrets are reported by key name, line number, and value length only.",
    findings: r.findings.map(function(f){
      return { grade:f.grade, line:f.line, key:f.key, category:f.category, message:f.message };
    })
  };
  return JSON.stringify(obj, null, 2);
}

/* ---------- UI ---------- */

var lastResult = null;
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-passbolt-server-config-safety-auditortm',
  name: 'J-Dawgs Passbolt Server Config Safety Auditor',
  description: 'Grades a pasted Passbolt config offline into one deploy verdict: debug mode left on, an http base URL, plaintext DB/SMTP passwords, and GPG key posture all graded, with secrets reported by key name, line, and length only, never values.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
