'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs WireGuard Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var KEY_SHAPE = /^[A-Za-z0-9+/]{43}=$/;
        var HOOKS = { preup: "PreUp", postup: "PostUp", predown: "PreDown", postdown: "PostDown" };
        var SENSITIVE = /key|token|password|passwd|secret|credential/i;

        /* ---------- CIDR helpers (BigInt based, values are routing data, safe to show) ---------- */
        function ipToBigInt(ip) {
          var i, parts, v;
          if (ip.indexOf(":") !== -1) {
            var halves = ip.split("::");
            if (halves.length > 2) return null;
            var left = halves[0] ? halves[0].split(":") : [];
            var right = halves.length === 2 ? (halves[1] ? halves[1].split(":") : []) : null;
            var groups;
            if (right === null) {
              if (left.length !== 8) return null;
              groups = left;
            } else {
              var missing = 8 - left.length - right.length;
              if (missing < 0) return null;
              groups = left.slice();
              for (i = 0; i < missing; i++) groups.push("0");
              groups = groups.concat(right);
            }
            v = 0n;
            for (i = 0; i < groups.length; i++) {
              if (!/^[0-9a-fA-F]{1,4}$/.test(groups[i])) return null;
              v = (v << 16n) + BigInt(parseInt(groups[i], 16));
            }
            return { v: v, bits: 128, family: 6 };
          }
          parts = ip.split(".");
          if (parts.length !== 4) return null;
          v = 0n;
          for (i = 0; i < parts.length; i++) {
            if (!/^\d{1,3}$/.test(parts[i])) return null;
            var num = Number(parts[i]);
            if (num > 255) return null;
            v = (v << 8n) + BigInt(num);
          }
          return { v: v, bits: 32, family: 4 };
        }

        function parseCIDR(s) {
          var parts = String(s).split("/");
          if (parts.length > 2) return null;
          var ip = ipToBigInt(parts[0].trim());
          if (!ip) return null;
          var prefix = ip.bits, hadSlash = false, invalidPrefix = false;
          if (parts.length === 2) {
            hadSlash = true;
            var p = parts[1].trim();
            if (!/^\d+$/.test(p)) return null;
            prefix = Number(p);
            if (prefix > ip.bits) invalidPrefix = true;
          }
          var effPrefix = invalidPrefix ? ip.bits : prefix;
          var hostBits = BigInt(ip.bits - effPrefix);
          var start = hostBits === 0n ? ip.v : (ip.v >> hostBits) << hostBits;
          var end = start + ((1n << hostBits) - 1n);
          return { family: ip.family, bits: ip.bits, prefix: prefix, hadSlash: hadSlash, invalidPrefix: invalidPrefix, start: start, end: end };
        }

        function splitList(value) {
          return String(value).split(",").map(function (s) { return s.trim(); }).filter(function (s) { return s.length > 0; });
        }

        /* ---------- The audit ---------- */
        function audit(text, shareMode) {
          var findings = [];
          function add(sev, line, title, detail, fix) {
            findings.push({ sev: sev, line: line, title: title, detail: detail, fix: fix });
          }

          var lines = String(text).split(/\r?\n/);
          var sections = [];
          var current = null;
          var i, n, raw, t;

          for (i = 0; i < lines.length; i++) {
            n = i + 1;
            raw = lines[i];
            t = raw.trim();
            if (!t) continue;
            if (t.charAt(0) === "#" || t.charAt(0) === ";") continue;

            var secMatch = t.match(/^\[(.+)\]$/);
            if (secMatch) {
              var name = secMatch[1].trim();
              var low = name.toLowerCase();
              var type = low === "interface" ? "interface" : (low === "peer" ? "peer" : "unknown");
              current = { type: type, name: name, line: n, dirs: [], eff: {} };
              sections.push(current);
              if (type === "unknown") {
                add("WARNING", n, "Unknown section [" + name + "]",
                  "wg-quick only understands [Interface] and [Peer]. Anything under [" + name + "] will be ignored or will stop the config from loading.",
                  "Rename the section to [Interface] or [Peer], or remove it.");
              }
              continue;
            }

            var eq = t.indexOf("=");
            if (eq > 0) {
              var key = t.slice(0, eq).trim();
              var value = t.slice(eq + 1).trim();
              if (!current) {
                add("WARNING", n, "Directive outside any section",
                  "The directive “" + key + "” on line " + n + " appears before any [Interface] or [Peer] header, so wg-quick will not apply it where you expect.",
                  "Move line " + n + " under the section it belongs to.");
                continue;
              }
              var lk = key.toLowerCase();
              var prev = current.eff[lk];
              current.dirs.push({ key: key, lk: lk, value: value, line: n });
              if (prev) {
                add("WARNING", n, "Duplicate directive: " + key,
                  key + " is set on line " + prev.line + " and again on line " + n + " inside the same section. In wg-quick the last value wins, so the line " + prev.line + " value is silently discarded.",
                  "Delete one of the two " + key + " lines and keep the value you actually mean.");
              }
              current.eff[lk] = { key: key, value: value, line: n };
              continue;
            }

            add("WARNING", n, "NOT PARSED — line " + n,
              "Line " + n + " is not a section header and not a Key = Value directive, so it was reported as-is and not guessed at. wg-quick would fail on this line.",
              "Fix line " + n + " into a comment (start it with #), a section header, or a Key = Value directive — or delete it.");
          }

          var interfaces = sections.filter(function (s) { return s.type === "interface"; });
          var peerSections = sections.filter(function (s) { return s.type === "peer"; });

          if (interfaces.length === 0) {
            add("BLOCKER", null, "Missing [Interface] section",
              "The config has no [Interface] section, so it defines no local identity, address, or key. wg-quick cannot bring this tunnel up.",
              "Add an [Interface] section with a PrivateKey and an Address.");
          }
          if (interfaces.length > 1) {
            add("WARNING", interfaces[1].line, "Multiple [Interface] sections",
              "wg-quick expects exactly one [Interface] section. Extra ones make the effective settings hard to reason about.",
              "Merge everything into a single [Interface] section.");
          }
          if (peerSections.length === 0) {
            add("BLOCKER", null, "Missing [Peer] section",
              "The config has no [Peer] section, so there is nobody for the tunnel to talk to.",
              "Add at least one [Peer] section with a PublicKey.");
          }

          /* --- Parse peers first: full-tunnel and overlap facts feed the interface checks --- */
          var peers = peerSections.map(function (sec, idx) {
            var ai = sec.eff["allowedips"];
            var entries = ai ? splitList(ai.value) : [];
            var parsed = [];
            entries.forEach(function (e) {
              var c = parseCIDR(e);
              if (c && !c.invalidPrefix) parsed.push({ raw: e, cidr: c });
            });
            var full = parsed.some(function (p) { return p.cidr.prefix === 0; });
            return { index: idx + 1, sec: sec, eff: sec.eff, allowedEntries: entries, allowedParsed: parsed, fullTunnel: full };
          });
          var anyFullTunnel = peers.some(function (p) { return p.fullTunnel; });

          var iface = interfaces.length ? interfaces[0] : null;
          var listenPort = iface ? iface.eff["listenport"] : null;
          var dnsDir = iface ? iface.eff["dns"] : null;
          var addrDir = iface ? iface.eff["address"] : null;
          var addrPrefixes = [];
          if (addrDir) {
            splitList(addrDir.value).forEach(function (e) {
              var c = parseCIDR(e);
              if (c && !c.invalidPrefix && c.prefix !== 0) addrPrefixes.push(c.prefix);
            });
          }

          /* --- [Interface] checks --- */
          if (iface) {
            var pk = iface.eff["privatekey"];
            if (!pk) {
              add("BLOCKER", iface.line, "PrivateKey missing in [Interface]",
                "Without a PrivateKey the tunnel cannot authenticate, so it cannot start. (No key value is ever shown by this tool — keys are reported by name and line only.)",
                "Add the PrivateKey line for this interface, generated on the machine that will use it — never received over chat or email.");
            } else if (shareMode) {
              add("BLOCKER", pk.line, "PrivateKey embedded — do not share this file",
                "A PrivateKey is present on line " + pk.line + " (name and line only — the value is never shown). You marked this file as about to be shared or committed: a file containing a PrivateKey is a live credential, and anyone who gets it can impersonate this tunnel endpoint.",
                "Do not share or commit this file. Send a redacted copy with the PrivateKey line removed, and treat the key as exposed if the file already went out.");
            } else {
              add("INFO", pk.line, "PrivateKey present — this file is a credential",
                "A PrivateKey is present on line " + pk.line + " (name and line only — the value is never shown). Key present, file is a credential — store it like one: owner-only file permissions, out of chat, email, and git.",
                "Keep the file private. If you ever need to share the config, share a copy with the PrivateKey line removed.");
            }

            if (!addrDir) {
              add("BLOCKER", iface.line, "Address missing in [Interface]",
                "Without an Address, wg-quick has no tunnel IP to assign, so the interface cannot come up as intended.",
                "Add an Address line, for example Address = 10.8.0.2/32, using an address inside the tunnel subnet that no other peer uses.");
            } else {
              var addrEntries = splitList(addrDir.value);
              if (addrEntries.length === 0) {
                add("BLOCKER", addrDir.line, "Address is empty in [Interface]",
                  "The Address directive on line " + addrDir.line + " has no value, so the interface gets no tunnel IP.",
                  "Give Address a value in CIDR form, for example 10.8.0.2/32.");
              } else {
                var badAddr = null;
                addrEntries.forEach(function (e) {
                  if (badAddr) return;
                  var c = parseCIDR(e);
                  if (!c || c.invalidPrefix || c.prefix === 0) badAddr = e;
                });
                if (badAddr) {
                  add("BLOCKER", addrDir.line, "Invalid Address CIDR: " + badAddr,
                    "The Address entry “" + badAddr + "” on line " + addrDir.line + " is not a usable interface address — the prefix is invalid (a /0 would claim the interface sits in every network at once, which wg-quick cannot assign).",
                    "Use a real host address inside the tunnel subnet, for example 10.8.0.2/32.");
                } else {
                  add("INFO", addrDir.line, "Address present",
                    "Address is set on line " + addrDir.line + " (" + addrEntries.join(", ") + ") and every entry parses as a valid CIDR.",
                    "No change needed. Make sure no other peer or interface uses the same tunnel address.");
                }
              }
            }

            if (listenPort) {
              add("INFO", listenPort.line, "ListenPort present — listener posture (inference)",
                "ListenPort is set on line " + listenPort.line + ". Inference, labeled as such: this reads like a listener / server-style config that accepts inbound peers on that port.",
                "No change needed if this machine should accept connections. Make sure the firewall actually passes that UDP port.");
            } else {
              add("INFO", iface.line, "No ListenPort — client posture (inference)",
                "There is no ListenPort directive. Inference, labeled as such: this reads like a client-style config that initiates outbound connections and takes an ephemeral local port.",
                "No change needed for a client. Add a ListenPort only if this machine must accept inbound peers.");
            }

            if (dnsDir) {
              add("INFO", dnsDir.line, "DNS present",
                "A DNS directive is set on line " + dnsDir.line + ", so wg-quick will configure the resolver while the tunnel is up.",
                "No change needed. Confirm the DNS server named there is reachable through the tunnel.");
            } else if (anyFullTunnel) {
              var ftPeer = peers.filter(function (p) { return p.fullTunnel; })[0];
              var ftAi = ftPeer.sec.eff["allowedips"];
              add("WARNING", ftAi ? ftAi.line : ftPeer.sec.line, "Full tunnel with no DNS — DNS leak risk",
                "Peer " + ftPeer.index + " routes 0.0.0.0/0 or ::/0 (all traffic) through the tunnel, but [Interface] has no DNS directive. Queries can then keep going to the pre-tunnel resolver, outside the tunnel — a DNS leak that exposes what you look up even while the traffic itself is tunneled.",
                "Add a DNS line to [Interface] naming a resolver reachable through the tunnel, for example the tunnel's own server address.");
            }

            var sc = iface.eff["saveconfig"];
            if (sc) {
              if (sc.value.trim().toLowerCase() === "true") {
                add("WARNING", sc.line, "SaveConfig = true",
                  "SaveConfig is true on line " + sc.line + ". Any runtime change to the live interface overwrites this file, so hand edits and drift appear without anyone editing the file on purpose.",
                  "Set SaveConfig = false unless you deliberately manage this interface at runtime and accept the overwrites.");
              } else {
                add("INFO", sc.line, "SaveConfig present",
                  "SaveConfig is set on line " + sc.line + " and is not “true”, so runtime changes will not overwrite this file.",
                  "No change needed.");
              }
            }

            var mtu = iface.eff["mtu"];
            if (mtu) {
              var mtuNum = Number(mtu.value.trim());
              if (!isFinite(mtuNum) || mtuNum < 576 || mtuNum > 9216) {
                add("WARNING", mtu.line, "MTU value looks off",
                  "The MTU on line " + mtu.line + " is not a plausible packet size (sane range is roughly 576–9216). A wrong MTU causes silent stalls on large packets.",
                  "Set MTU to a sane value — 1280 is the safe WireGuard default for tunnels over unknown paths — or remove the line and let wg-quick choose.");
              } else {
                add("INFO", mtu.line, "MTU present",
                  "MTU is set on line " + mtu.line + " to a sane value.",
                  "No change needed.");
              }
            }

            var table = iface.eff["table"];
            if (table) {
              add("INFO", table.line, "Table present",
                "A Table directive is set on line " + table.line + ", so wg-quick will place the tunnel routes in a custom routing table (or “off” leaves routing to you).",
                "No change needed if the custom routing is deliberate. If you do not know why it is there, remove it and let wg-quick manage routes.");
            }
          }

          /* --- Hook directives in any section --- */
          sections.forEach(function (sec) {
            sec.dirs.forEach(function (d) {
              var canon = HOOKS[d.lk];
              if (!canon) return;
              var sensitive = SENSITIVE.test(d.value);
              var firstWord = d.value.split(/\s+/)[0] || "";
              var shown = (!sensitive && firstWord) ? " It begins with the command “" + firstWord + "” (only the command name is shown here; the rest of the line is not)." : " The command text is not shown here at all.";
              add("WARNING", d.line, canon + " hook present — runs shell commands as root",
                canon + " is set on line " + d.line + "." + shown + " Hook directives (PreUp, PostUp, PreDown, PostDown) run arbitrary shell commands as root when the tunnel goes up or down. A config you received from someone else can carry anything in these lines.",
                "Open the file and read the entire " + canon + " line before using this config. Remove the directive if you do not recognize and trust every command in it.");
            });
          });

          /* --- [Peer] checks --- */
          var seenPubKeys = {};
          peers.forEach(function (peer) {
            var sec = peer.sec, eff = peer.eff, idx = peer.index;
            var pub = eff["publickey"];
            if (!pub) {
              add("BLOCKER", sec.line, "Peer " + idx + ": PublicKey missing",
                "Peer " + idx + " (section starting line " + sec.line + ") has no PublicKey, so WireGuard cannot authenticate or encrypt to that peer.",
                "Add the PublicKey line for peer " + idx + ", taken from that peer's own [Interface] — by name only, never invented.");
            } else {
              if (KEY_SHAPE.test(pub.value)) {
                add("INFO", pub.line, "Peer " + idx + ": PublicKey present",
                  "A PublicKey is present on line " + pub.line + " and matches the 44-character base64 shape (shape check only — the value is never shown and is not verified).",
                  "No change needed.");
              } else {
                add("WARNING", pub.line, "Peer " + idx + ": PublicKey is not 44-character base64-shaped",
                  "The PublicKey value on line " + pub.line + " does not match the 44-character base64 shape every WireGuard key has (shape check only — the value is never shown). It may be truncated, pasted with extra characters, or not a key at all.",
                  "Re-copy the key from the peer itself and confirm the line ends with a single = and totals 44 characters.");
              }
              var seen = seenPubKeys[pub.value];
              if (seen) {
                add("WARNING", pub.line, "Duplicate PublicKey — peers " + seen.index + " and " + idx,
                  "Peer " + seen.index + " (PublicKey on line " + seen.line + ") and peer " + idx + " (PublicKey on line " + pub.line + ") carry the same PublicKey value (the value itself is never shown). Two different machines cannot share one key pair, so one of these entries is almost certainly a copy-paste error.",
                  "Replace the wrong entry with that machine's real PublicKey.");
              } else {
                seenPubKeys[pub.value] = { index: idx, line: pub.line };
              }
            }

            var psk = eff["presharedkey"];
            if (psk) {
              if (shareMode) {
                add("WARNING", psk.line, "Peer " + idx + ": PresharedKey embedded — do not share this file",
                  "A PresharedKey is present on line " + psk.line + " (name and line only — the value is never shown). You marked this file as about to be shared or committed, and a preshared key is a shared secret.",
                  "Share a redacted copy with the PresharedKey line removed.");
              } else {
                add("INFO", psk.line, "Peer " + idx + ": PresharedKey present",
                  "A PresharedKey is present on line " + psk.line + " (name and line only — the value is never shown). That is an extra symmetric layer on top of the key exchange.",
                  "No change needed. The same PresharedKey must be set on the other side or the tunnel will not pass traffic.");
              }
            } else if (peer.fullTunnel) {
              add("INFO", sec.line, "Peer " + idx + ": no PresharedKey on a full-tunnel peer",
                "Peer " + idx + " routes all traffic but has no PresharedKey. That is optional — the tunnel still works — it is noted because a preshared key is the standard extra layer on a peer that carries everything.",
                "Optional: add a PresharedKey to peer " + idx + " and the matching side if you want the extra symmetric layer.");
            }

            var ep = eff["endpoint"];
            if (!ep) {
              add("WARNING", sec.line, "Peer " + idx + ": no Endpoint",
                "Peer " + idx + " has no Endpoint, stated plainly: this side cannot start a connection to that peer — the peer can only be reached inbound, when it connects first (a roaming posture). If that peer sits behind NAT and never calls in, the tunnel stays silent.",
                "Add an Endpoint (host:port) for peer " + idx + " if this side should be able to reach it, or leave it off deliberately for a peer that always dials in.");
            } else {
              var v = ep.value.trim();
              var host = v, port = null;
              if (v.charAt(0) === "[") {
                var close = v.indexOf("]");
                if (close > 0) {
                  host = v.slice(1, close);
                  var rest = v.slice(close + 1);
                  if (rest.charAt(0) === ":") port = rest.slice(1);
                }
              } else {
                var fc = v.indexOf(":"), lc = v.lastIndexOf(":");
                if (fc === -1) { host = v; }
                else if (fc === lc) { host = v.slice(0, fc); port = v.slice(fc + 1); }
                else { host = v; }
              }
              var isIP = ipToBigInt(host) !== null;
              add("INFO", ep.line, "Peer " + idx + ": Endpoint is " + (isIP ? "an IP address" : "a hostname"),
                isIP
                  ? "The Endpoint on line " + ep.line + " is an IP literal, so no name resolution is involved when the tunnel starts."
                  : "The Endpoint on line " + ep.line + " is a hostname. It is resolved when the tunnel starts (and re-resolved on roaming); this tool notes the form only and never resolves it.",
                "No change needed.");
              if (port === null || port === "") {
                add("INFO", ep.line, "Peer " + idx + ": Endpoint has no port",
                  "The Endpoint on line " + ep.line + " names no port. Most servers expect one to be given explicitly.",
                  "Confirm the port with whoever issued the config — 51820 is the common default — and write it in as host:port.");
              } else if (!/^\d+$/.test(port) || Number(port) < 1 || Number(port) > 65535) {
                add("WARNING", ep.line, "Peer " + idx + ": Endpoint port looks invalid",
                  "The port in the Endpoint on line " + ep.line + " is not a number in the 1–65535 range, so wg-quick cannot dial it.",
                  "Fix the Endpoint to host:port form with the real port.");
              }
            }

            var ai = eff["allowedips"];
            if (!ai || ai.value.trim() === "" || peer.allowedEntries.length === 0) {
              add("BLOCKER", ai ? ai.line : sec.line, "Peer " + idx + ": AllowedIPs is empty",
                "Peer " + idx + " has an empty or missing AllowedIPs. Cryptokey routing drops traffic that matches no AllowedIPs entry, so this peer routes nothing.",
                "Add the networks this peer may send and receive, for example AllowedIPs = 10.8.0.0/24 — or 0.0.0.0/0, ::/0 for a deliberate full tunnel.");
            } else {
              peer.allowedEntries.forEach(function (e) {
                var c = parseCIDR(e);
                if (!c || c.invalidPrefix) {
                  add("WARNING", ai.line, "Peer " + idx + ": AllowedIPs entry is not a valid CIDR",
                    "The AllowedIPs entry “" + e + "” on line " + ai.line + " does not parse as an IP address with a valid prefix, so wg-quick will reject it.",
                    "Write every AllowedIPs entry in CIDR form, for example 10.8.0.0/24 or 0.0.0.0/0.");
                }
              });
              if (peer.fullTunnel && dnsDir) {
                add("INFO", ai.line, "Peer " + idx + ": full tunnel — all traffic routes via this peer",
                  "AllowedIPs on line " + ai.line + " includes 0.0.0.0/0 or ::/0, so all traffic routes via peer " + idx + " while the tunnel is up. A DNS directive is present, so the usual leak warning does not apply.",
                  "No change needed if a full tunnel is what you intend.");
              }
              if (listenPort && addrPrefixes.length) {
                var minAddrPrefix = Math.min.apply(null, addrPrefixes);
                peer.allowedParsed.forEach(function (p) {
                  if (p.cidr.prefix < minAddrPrefix) {
                    add("WARNING", ai.line, "Peer " + idx + ": AllowedIPs broader than this interface's Address space — routing risk",
                      "This is a listener-style config (ListenPort is set), and peer " + idx + " may claim “" + p.raw + "” (line " + ai.line + "), which is broader than this interface's own Address space. On a server-style config that lets one peer claim routes far beyond its own tunnel address — a routing risk if the peer is not fully trusted.",
                      "Narrow peer " + idx + "'s AllowedIPs to the tunnel addresses that peer actually owns, typically a single /32.");
                  }
                });
              }
            }

            var ka = eff["persistentkeepalive"];
            if (ka) {
              add("INFO", ka.line, "Peer " + idx + ": PersistentKeepalive present",
                "PersistentKeepalive is set on line " + ka.line + " (value " + ka.value.trim() + "), so this side sends keepalives to hold NAT mappings and firewall state open.",
                "No change needed.");
            } else if (ep && !listenPort) {
              add("INFO", sec.line, "Peer " + idx + ": no PersistentKeepalive",
                "Peer " + idx + " is a client-style peer (it has an Endpoint and this interface has no ListenPort) with no PersistentKeepalive. NAT mappings may expire when the tunnel goes quiet, and the peer can look unreachable until traffic restarts them.",
                "Add PersistentKeepalive = 25 to peer " + idx + " — 25 seconds is the common value — if either side sits behind NAT.");
            }
          });

          /* --- Overlapping AllowedIPs across peers --- */
          for (var a = 0; a < peers.length; a++) {
            for (var b = a + 1; b < peers.length; b++) {
              var overlap = false;
              peers[a].allowedParsed.forEach(function (pa) {
                peers[b].allowedParsed.forEach(function (pb) {
                  if (pa.cidr.family === pb.cidr.family && pa.cidr.start <= pb.cidr.end && pb.cidr.start <= pa.cidr.end) overlap = true;
                });
              });
              if (overlap) {
                var aiB = peers[b].sec.eff["allowedips"];
                add("WARNING", aiB ? aiB.line : peers[b].sec.line, "AllowedIPs overlap — peers " + peers[a].index + " and " + peers[b].index,
                  "Peers " + peers[a].index + " and " + peers[b].index + " claim overlapping AllowedIPs space. WireGuard routes matching traffic to the last matching peer, so the overlap silently sends that traffic to peer " + peers[b].index + " — rarely what was intended.",
                  "Split the ranges so each destination belongs to exactly one peer.");
              }
            }
          }

          var sevRank = { BLOCKER: 0, WARNING: 1, INFO: 2 };
          findings.sort(function (x, y) {
            if (sevRank[x.sev] !== sevRank[y.sev]) return sevRank[x.sev] - sevRank[y.sev];
            var lx = x.line === null ? 0 : x.line, ly = y.line === null ? 0 : y.line;
            return lx - ly;
          });

          var counts = { BLOCKER: 0, WARNING: 0, INFO: 0 };
          findings.forEach(function (f) { counts[f.sev]++; });
          var verdict = counts.BLOCKER > 0 ? "DO NOT USE" : (counts.WARNING > 0 ? "USE WITH FIXES" : "SAFE TO USE");
          return { findings: findings, counts: counts, verdict: verdict };
        }

        var NOT_CHECKED = [
          "Whether any key is cryptographically valid — keys are shape-checked only, never verified.",
          "Whether any peer exists, is listening, or has a matching config on the other side.",
          "Any hostname — endpoints are noted as hostname or IP, never resolved.",
          "Firewall rules, NAT behavior, and routing on any device.",
          "Whether the tunnel will actually start or carry traffic."
        ];
        var LIMITS = "Honest limits: this audit parses pasted text only. It does not verify any key cryptographically, does not connect, ping, or resolve any endpoint, and does not check firewall rules or whether the peer exists. A SAFE TO USE verdict means no risk in the checks performed was found in the text — not that the tunnel will work.";

        /* ---------- Examples (dummy keys only: repeated characters, 44 chars, labeled in-file) ---------- */
        var DUMMY_A = "A".repeat(43) + "=";
        var DUMMY_B = "B".repeat(43) + "=";
        var DUMMY_C = "C".repeat(43) + "=";

        var RISKY = [
          "# RISKY CLIENT - training example. Every key in it is a dummy string of repeated characters, not a real key.",
          "[Interface]",
          "PrivateKey = " + DUMMY_A,
          "Address = 10.8.0.2/0",
          "PostUp = iptables -A FORWARD -i wg0 -j ACCEPT",
          "",
          "[Peer]",
          "PublicKey = " + DUMMY_B,
          "Endpoint = vpn.example.com:51820",
          "AllowedIPs = 0.0.0.0/0",
          "",
          "[Peer]",
          "PublicKey = " + DUMMY_B,
          "AllowedIPs = 10.8.0.0/24"
        ].join("\n");

        var HARDENED = [
          "# HARDENED CLIENT - training example. Every key in it is a dummy string of repeated characters, not a real key.",
          "[Interface]",
          "PrivateKey = " + DUMMY_A,
          "Address = 10.8.0.2/32",
          "DNS = 10.8.0.1",
          "",
          "[Peer]",
          "PublicKey = " + DUMMY_C,
          "Endpoint = vpn.example.com:51820",
          "AllowedIPs = 10.8.0.0/24",
          "PersistentKeepalive = 25"
        ].join("\n");
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-wireguard-config-safety-auditor',
  name: 'J-Dawgs WireGuard Config Safety Auditor',
  description: 'Grades a pasted WireGuard config offline — embedded keys by name only, full-tunnel DNS leaks, PostUp hooks, AllowedIPs routing traps — into one use verdict. WireGuard\'s own tooling tests only on a device with the real keys and answers only whether the tunnel starts; this grades the file anywhere bef',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
