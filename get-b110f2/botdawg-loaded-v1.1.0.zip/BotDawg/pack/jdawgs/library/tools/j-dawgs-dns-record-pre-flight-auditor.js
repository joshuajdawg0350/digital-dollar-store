'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs DNS Record Pre-Flight Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var TYPES = ["A", "AAAA", "CNAME", "MX", "TXT", "NS", "SRV", "CAA"];
      var DAY = 7 * 24 * 3600;

      var BAD_SAMPLE = [
        "$ORIGIN example.com.",
        "@       IN MX 10 mail.example.com.",
        "@       IN TXT \"v=spf1 include:_spf.example.com +all\"",
        "@       IN TXT \"v=spf1 -all\"",
        "mail    IN A 192.0.2.25",
        "www     IN CNAME web.example.net.",
        "www     IN TXT \"site verification token\"",
        "shop    IN CNAME storefront.vendor-example.com."
      ].join("\n");

      var CLEAN_SAMPLE = [
        "$ORIGIN example.com.",
        "@       IN A 192.0.2.10 3600",
        "@       IN MX 10 mail.example.com.",
        "@       IN TXT \"v=spf1 mx -all\"",
        "_dmarc  IN TXT \"v=DMARC1; p=none\"",
        "mail    IN A 192.0.2.25",
        "www     IN CNAME example.com."
      ].join("\n");

      /* ---------- parsing ---------- */

      function stripComment(line) {
        var out = "", inQ = false;
        for (var i = 0; i < line.length; i++) {
          var ch = line[i];
          if (ch === '"') inQ = !inQ;
          if (!inQ && (ch === ";" || ch === "#")) break;
          out += ch;
        }
        return out;
      }

      function tokenize(text) {
        var tokens = [], cur = "", inQ = false;
        for (var i = 0; i < text.length; i++) {
          var ch = text[i];
          if (ch === '"') { inQ = !inQ; cur += ch; }
          else if (!inQ && /\s/.test(ch)) { if (cur) { tokens.push(cur); cur = ""; } }
          else cur += ch;
        }
        if (cur) tokens.push(cur);
        return tokens;
      }

      function parenDepth(text) {
        var d = 0, inQ = false;
        for (var i = 0; i < text.length; i++) {
          var ch = text[i];
          if (ch === '"') inQ = !inQ;
          else if (!inQ && ch === "(") d++;
          else if (!inQ && ch === ")") d--;
        }
        return d;
      }

      // Join multi-line parenthesised records into logical lines.
      function logicalLines(raw) {
        var src = raw.split(/\r?\n/);
        var out = [], buf = null;
        for (var i = 0; i < src.length; i++) {
          var line = src[i];
          if (buf === null) {
            if (stripComment(line).trim() === "") continue;
            buf = { text: line, lineNo: i + 1, startsWS: /^\s/.test(line) };
          } else {
            buf.text += "\n" + line;
          }
          if (parenDepth(stripComment(buf.text)) <= 0) { out.push(buf); buf = null; }
        }
        if (buf !== null) out.push(buf);
        return out;
      }

      function normHost(name, origin) {
        // Returns a lowercase comparison key, trailing dot removed, relative names expanded.
        if (!name) return "";
        var n = name.trim();
        if (n === "@") return origin ? origin.replace(/\.$/, "").toLowerCase() : "@";
        var abs = /\.$/.test(n);
        n = n.replace(/\.$/, "").toLowerCase();
        if (!abs && origin) n = n + "." + origin.replace(/\.$/, "").toLowerCase();
        return n;
      }

      function displayName(rawName, origin) {
        if (rawName === "@") return origin || "@";
        return rawName;
      }

      function parseRecord(ll, state) {
        var cleaned = stripComment(ll.text).replace(/[()]/g, " ");
        var tokens = tokenize(cleaned);
        if (!tokens.length) return null; // blank / comment-only

        if (tokens[0].charAt(0) === "$") {
          var dir = tokens[0].toUpperCase();
          if (dir === "$ORIGIN" && tokens[1]) { state.origin = tokens[1]; return null; }
          if (dir === "$TTL" && tokens[1] && /^\d+$/.test(tokens[1])) { state.defaultTTL = parseInt(tokens[1], 10); return null; }
          return { error: true };
        }

        var typeIdx = -1;
        for (var i = 0; i < tokens.length; i++) {
          if (TYPES.indexOf(tokens[i].toUpperCase()) !== -1) { typeIdx = i; break; }
        }
        if (typeIdx === -1) return { error: true };
        var type = tokens[typeIdx].toUpperCase();

        var name = null, ttl = null;
        var head = tokens.slice(0, typeIdx);
        if (ll.startsWS || head.length === 0) {
          name = state.lastName;
          if (!name) return { error: true };
        } else {
          name = head[0];
          head = head.slice(1);
        }
        for (var h = 0; h < head.length; h++) {
          var t = head[h];
          if (/^\d+$/.test(t)) ttl = parseInt(t, 10);
          else if (/^(IN|CH|HS)$/i.test(t)) { /* class — accepted, ignored */ }
          else return { error: true };
        }

        var rdata = tokens.slice(typeIdx + 1);
        // "name TYPE value TTL" style: a trailing bare number is the TTL,
        // unless a TTL was already given before the type.
        if (ttl === null && rdata.length >= 2 && /^\d+$/.test(rdata[rdata.length - 1])) {
          ttl = parseInt(rdata[rdata.length - 1], 10);
          rdata = rdata.slice(0, -1);
        }
        if (!rdata.length) return { error: true };

        state.lastName = name;
        return {
          name: displayName(name, state.origin),
          nameKey: normHost(name, state.origin),
          type: type,
          value: rdata.join(" "),
          rdataTokens: rdata,
          ttl: ttl,
          lineNo: ll.lineNo,
          raw: ll.text.replace(/\s*\n\s*/g, " ").trim()
        };
      }

      function txtText(rec) {
        // Concatenate quoted segments the way BIND does.
        var parts = [];
        for (var i = 0; i < rec.rdataTokens.length; i++) {
          parts.push(rec.rdataTokens[i].replace(/^"|"$/g, ""));
        }
        return parts.join("");
      }

      function hostOf(rec, origin) {
        // Target hostname for CNAME / NS, and the host part of MX / SRV.
        var toks = rec.rdataTokens;
        if (rec.type === "MX" || rec.type === "SRV") {
          return normHost(toks[toks.length - 1], origin);
        }
        return normHost(toks.join(" "), origin);
      }

      /* ---------- audit ---------- */

      function audit(text) {
        var state = { origin: null, defaultTTL: null, lastName: null };
        var records = [], unparsed = [];
        var lines = logicalLines(text);
        for (var i = 0; i < lines.length; i++) {
          var r;
          try { r = parseRecord(lines[i], state); }
          catch (e) { r = { error: true }; }
          if (r === null) continue;
          if (r.error) unparsed.push({ lineNo: lines[i].lineNo, text: lines[i].text.trim() });
          else records.push(r);
        }

        var findings = [];
        function add(sev, cls, stage, rec, reason) {
          findings.push({ sev: sev, cls: cls, stage: stage, lineNo: rec ? rec.lineNo : null, raw: rec ? rec.raw : "", reason: reason });
        }

        var origin = state.origin;
        var byName = {}, namesPresent = {}, counts = {}, total = 0;
        TYPES.forEach(function (t) { counts[t] = 0; });
        records.forEach(function (rec) {
          counts[rec.type]++; total++;
          namesPresent[rec.nameKey] = true;
          (byName[rec.nameKey] = byName[rec.nameKey] || []).push(rec);
        });

        var txts = records.filter(function (r) { return r.type === "TXT"; });
        function isSPF(rec) { return /^\s*v=spf1\b/i.test(txtText(rec)); }
        var spfs = txts.filter(isSPF);
        var mxs = records.filter(function (r) { return r.type === "MX"; });
        var hasDMARC = txts.some(function (r) {
          return r.nameKey.indexOf("_dmarc") === 0 && /v=DMARC1/i.test(txtText(r));
        });

        /* Stage 1 — mail readiness */
        if (mxs.length && !spfs.length) {
          add("REVIEW", "rev", "Stage 1 · Mail readiness", mxs[0],
            "MX records are present but there is no SPF TXT record (a TXT starting “v=spf1”) in the pasted set. Receiving servers will have no published list of hosts allowed to send mail for this domain.");
        }
        var spfByName = {};
        spfs.forEach(function (r) { (spfByName[r.nameKey] = spfByName[r.nameKey] || []).push(r); });
        Object.keys(spfByName).forEach(function (k) {
          var list = spfByName[k];
          if (list.length > 1) {
            add("CRITICAL", "crit", "Stage 1 · Mail readiness", list[1],
              list.length + " SPF records for the name “" + list[0].name + "”. RFC 7208 allows exactly one SPF record per name — multiple SPF records are invalid and make SPF validation fail with permerror. Merge them into a single record.");
          }
        });
        spfs.forEach(function (r) {
          var body = txtText(r).trim();
          var toks = body.split(/\s+/);
          if (/^\+all$/i.test(toks[toks.length - 1])) {
            add("CRITICAL", "crit", "Stage 1 · Mail readiness", r,
              "This SPF record ends with “+all”, which authorizes every host on the internet to send mail as this domain. Use “-all” (or “~all”) instead.");
          }
          var lookups = 0;
          toks.forEach(function (tok) {
            var m = tok.replace(/^[+\-~?]/, "").toLowerCase();
            if (/^include:/.test(m) || /^redirect=/.test(m) || m === "a" || /^a[:\/]/.test(m) || m === "mx" || /^mx[:\/]/.test(m)) lookups++;
          });
          if (lookups > 10) {
            add("CRITICAL", "crit", "Stage 1 · Mail readiness", r,
              "This SPF record uses " + lookups + " DNS-lookup mechanisms (include / a / mx / redirect). RFC 7208 caps SPF evaluation at 10 lookups — over the limit, validation fails with permerror. Flatten or trim the record.");
          }
        });
        if (spfs.length && !hasDMARC) {
          add("REVIEW", "rev", "Stage 1 · Mail readiness", spfs[0],
            "SPF is present but there is no DMARC record in the pasted set (a TXT at _dmarc starting “v=DMARC1”). Without DMARC, receivers get no policy for what to do with mail that fails SPF/DKIM, and you get no failure reports.");
        }

        /* Stage 2 — structural risks */
        records.forEach(function (rec) {
          if (rec.type === "CNAME") {
            var target = hostOf(rec, origin);
            if (target && !namesPresent[target]) {
              add("DANGLING", "dang", "Stage 2 · Structural risks", rec,
                "This CNAME points at “" + rec.rdataTokens.join(" ") + "”, which has no record within this pasted set only. If the target is defined in records you didn’t paste, this is fine — the auditor cannot see them.");
            }
          }
          if ((rec.nameKey === "*" || rec.nameKey.indexOf("*.") === 0) && rec.type === "A") {
            add("REVIEW", "rev", "Stage 2 · Structural risks", rec,
              "Wildcard A record: any otherwise-undefined name under this domain will resolve to this address. That is sometimes intended (catch-all hosting) and sometimes a surprise — confirm it is deliberate.");
          }
          if (rec.ttl !== null && (rec.ttl < 60 || rec.ttl > DAY)) {
            add("REVIEW", "rev", "Stage 2 · Structural risks", rec,
              "TTL of " + rec.ttl + "s is " + (rec.ttl < 60 ? "under 60 seconds — extremely short TTLs multiply query load and can look like a misconfiguration" : "over 7 days (604800s) — changes to this record will take more than a week to fully take effect") + ".");
          }
        });
        Object.keys(byName).forEach(function (k) {
          var list = byName[k];
          var hasCNAME = list.some(function (r) { return r.type === "CNAME"; });
          if (!hasCNAME) return;
          var others = list.filter(function (r) { return r.type !== "CNAME"; });
          var cnameRec = list.filter(function (r) { return r.type === "CNAME"; })[0];
          if (others.length) {
            add("CRITICAL", "crit", "Stage 2 · Structural risks", cnameRec,
              "The name “" + cnameRec.name + "” holds a CNAME and also " + others.map(function (r) { return r.type; }).join(", ") + ". A CNAME cannot coexist with any other record type at the same name (RFC 1034/2181) — most providers will refuse or break this. Keep the CNAME alone, or replace it with A/AAAA records.");
          } else if (list.length > 1) {
            add("CRITICAL", "crit", "Stage 2 · Structural risks", list[1],
              "The name “" + cnameRec.name + "” holds more than one CNAME record. A name may have at most one CNAME.");
          }
        });
        mxs.forEach(function (rec) {
          var target = hostOf(rec, origin);
          var targetRecs = byName[target] || [];
          if (targetRecs.some(function (r) { return r.type === "CNAME"; })) {
            add("REVIEW", "rev", "Stage 2 · Structural risks", rec,
              "This MX points at “" + rec.rdataTokens[rec.rdataTokens.length - 1] + "”, which is a CNAME within this pasted set. MX targets should be hostnames with their own A/AAAA records (RFC 2181) — some receivers reject or mishandle mail routed via a CNAME.");
          }
        });

        /* Stage 3 — duplicates */
        var seen = {};
        records.forEach(function (rec) {
          var key = rec.nameKey + "|" + rec.type + "|" + rec.value.replace(/\s+/g, " ").trim().toLowerCase();
          if (seen[key]) {
            add("DUPLICATE", "info", "Stage 3 · Duplicates", rec,
              "Identical to the record on line " + seen[key].lineNo + " (same name, type, and value). Harmless to most resolvers, but it is dead weight in the zone — remove one copy.");
          } else seen[key] = rec;
        });

        var verdict, vcls;
        if (findings.some(function (f) { return f.sev === "CRITICAL"; })) { verdict = "DO NOT PUBLISH"; vcls = "stop"; }
        else if (findings.length) { verdict = "PUBLISH WITH FIXES"; vcls = "fixes"; }
        else { verdict = "SAFE TO PUBLISH"; vcls = "safe"; }

        return { records: records, unparsed: unparsed, findings: findings, counts: counts, total: total, verdict: verdict, vcls: vcls };
      }

      /* ---------- rendering ---------- */

      function esc(s) {
        return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
      }

      function buildReport(res) {
        var out = [];
        out.push("J-Dawgs DNS Record Pre-Flight Auditor — audit report");
        out.push("Verdict: " + res.verdict);
        out.push("Records parsed: " + res.total);
        out.push("");
        out.push("Record counts by type:");
        TYPES.forEach(function (t) { if (res.counts[t]) out.push("  " + t + ": " + res.counts[t]); });
        out.push("");
        if (res.unparsed.length) {
          out.push("Lines that could not be parsed (excluded from the audit):");
          res.unparsed.forEach(function (u) { out.push("  Line " + u.lineNo + ": " + u.text); });
          out.push("");
        }
        if (!res.findings.length) {
          out.push("Findings: none. No problems found in the pasted set.");
        } else {
          out.push("Findings (" + res.findings.length + "):");
          res.findings.forEach(function (f, i) {
            out.push("");
            out.push((i + 1) + ". [" + f.sev + "] " + f.stage + (f.lineNo ? " — line " + f.lineNo : ""));
            if (f.raw) out.push("   Record: " + f.raw);
            out.push("   " + f.reason);
          });
        }
        out.push("");
        out.push("Limits: this audit covers only the records that were pasted. No live DNS lookup was performed, and records that were not pasted cannot be seen.");
        return out.join("\n");
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "BAD_SAMPLE": (typeof BAD_SAMPLE !== 'undefined' ? BAD_SAMPLE : undefined), "CLEAN_SAMPLE": (typeof CLEAN_SAMPLE !== 'undefined' ? CLEAN_SAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-dns-record-pre-flight-auditor',
  name: 'J-Dawgs DNS Record Pre-Flight Auditor',
  description: 'Pasted DNS records audited pre-publish for SPF/DMARC gaps, CNAME conflicts, and dangling targets; no live lookups',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "BAD_SAMPLE": __core["BAD_SAMPLE"], "CLEAN_SAMPLE": __core["CLEAN_SAMPLE"] }
};
