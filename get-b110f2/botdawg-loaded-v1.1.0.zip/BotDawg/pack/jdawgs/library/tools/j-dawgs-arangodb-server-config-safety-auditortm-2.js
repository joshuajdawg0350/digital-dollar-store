'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs ArangoDB Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var RISKY = [
        "# Risky example — arangod.conf (do not deploy)",
        "[server]",
        "endpoint = tcp://0.0.0.0:8529",
        "authentication = false",
        "jwt-secret = changeme123",
        "",
        "[database]",
        "directory = /tmp/arangodb-data",
        "password = hunter2example",
        "encryption-at-rest = true",
        "",
        "[cluster]",
        "agency-endpoint = http://agency1.internal:8529",
        "",
        "[log]",
        "level = debug",
        "file = /tmp/arangod.log",
        "Remember to ask the team about backups sometime"
      ].join("\n");

      var HARDENED = [
        "# Hardened example — arangod.conf",
        "[server]",
        "endpoint = ssl://127.0.0.1:8529",
        "authentication = true",
        "jwt-secret-file = /etc/arangodb3/jwt-secret.txt",
        "ssl.keyfile = /etc/arangodb3/ssl/server.pem",
        "ssl.certificate = /etc/arangodb3/ssl/server.crt",
        "",
        "[database]",
        "directory = /var/lib/arangodb3",
        "encryption-at-rest = true",
        "",
        "[encryption]",
        "keyfile = /etc/arangodb3/encryption.key",
        "",
        "[cluster]",
        "agency-endpoint = https://agency1.internal:8529",
        "agency-endpoint = https://agency2.internal:8529",
        "",
        "[log]",
        "level = info",
        "file = /var/log/arangodb3/arangod.log"
      ].join("\n");

      function esc(s){
        return String(s).replace(/[&<>"']/g, function(c){
          return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c];
        });
      }
      function unquote(v){
        v = v.trim();
        if (v.length >= 2 && ((v.charAt(0) === '"' && v.charAt(v.length-1) === '"') || (v.charAt(0) === "'" && v.charAt(v.length-1) === "'"))) {
          return v.slice(1, -1);
        }
        return v;
      }
      function truthy(v){ var s = String(v).trim().toLowerCase(); return s === "true" || s === "yes" || s === "on" || s === "1"; }
      function falsy(v){ var s = String(v).trim().toLowerCase(); return s === "false" || s === "no" || s === "off" || s === "0"; }
      function firstToken(v){ return String(v).trim().split(/\s+/)[0] || ""; }

      function parseConfig(text){
        var lines = String(text).split(/\r?\n/);
        var entries = [], notParsed = [], commented = [], commentedText = [];
        var section = "";
        lines.forEach(function(raw, i){
          var lineNo = i + 1;
          var t = raw.trim();
          if (!t) return;
          if (t.charAt(0) === "#" || t.charAt(0) === ";" || t.indexOf("//") === 0) {
            commented.push(lineNo); commentedText.push({ line: lineNo, text: t }); return;
          }
          var sec = t.match(/^\[([^\]]+)\]\s*$/);
          if (sec) { section = sec[1].trim().toLowerCase(); return; }
          if (t.indexOf("--") === 0 || /^arangod(\s|$)/i.test(t)) {
            var s = t;
            if (s.indexOf("--") !== 0) s = s.slice(s.indexOf("--"));
            var re = /--([a-zA-Z0-9._-]+)(?:\s*=\s*("[^"]*"|'[^']*'|\S+)|[ \t]+("[^"]*"|'[^']*'|(?!-)[^\s]+))?/g;
            var m, found = 0;
            while ((m = re.exec(s)) !== null) {
              found++;
              var val = m[2] !== undefined ? m[2] : (m[3] !== undefined ? m[3] : "true");
              entries.push({ key: m[1].toLowerCase(), value: unquote(val), line: lineNo, section: "" });
            }
            if (!found) notParsed.push(lineNo);
            return;
          }
          var kv = t.match(/^([a-zA-Z0-9._\/-]+)\s*=\s*(.*)$/);
          if (kv) {
            var rawKey = kv[1].toLowerCase();
            var full = rawKey.indexOf(".") >= 0 ? rawKey : (section ? section + "." + rawKey : rawKey);
            entries.push({ key: full, value: unquote(kv[2].trim()), line: lineNo, section: section });
            return;
          }
          notParsed.push(lineNo);
        });
        return { entries: entries, notParsed: notParsed, commented: commented, commentedText: commentedText };
      }

      function keyIs(e, name){ return e.key === name || e.key.slice(-(name.length + 1)) === "." + name; }
      function findAll(entries, pred){ return entries.filter(pred); }
      function lastOf(list){ return list.length ? list[list.length - 1] : null; }

      function audit(text){
        var parsed = parseConfig(text);
        var entries = parsed.entries;
        var findings = [], passes = [];
        function add(sev, line, key, check, msg){ findings.push({ severity: sev, line: line, key: key, check: check, message: msg }); }

        if (!entries.length) {
          return { verdict: "NOT ENOUGH TO GRADE", findings: findings, passes: passes, parsed: parsed,
            note: "No parseable config settings were found. Paste arangod.conf key = value lines, [section] blocks, or arangod --flags." };
        }

        /* --- Authentication --- */
        var authEntry = lastOf(findAll(entries, function(e){ return keyIs(e, "server.authentication") || e.key === "authentication"; }));
        var authOn = false;
        if (!authEntry) {
          var msg = "server.authentication is not set anywhere in the pasted config. Authentication left unset is treated as off for deployment purposes — set --server.authentication true (or authentication = true in the [server] section) explicitly.";
          var commentedAuth = parsed.commentedText.filter(function(c){ return /authentication/i.test(c.text); });
          if (commentedAuth.length) msg += " Note: an authentication setting appears commented out at line " + commentedAuth[0].line + " — commented lines are not active and do not count.";
          add("BLOCKER", null, "server.authentication", "authentication", msg);
        } else if (falsy(firstToken(authEntry.value))) {
          add("BLOCKER", authEntry.line, "server.authentication", "authentication", "Authentication is disabled (server.authentication = false). Anyone who can reach the endpoint can read and write the database with no credentials.");
        } else if (truthy(firstToken(authEntry.value))) {
          authOn = true;
          passes.push("Authentication is enabled (server.authentication, line " + authEntry.line + ").");
        } else {
          add("MEDIUM", authEntry.line, "server.authentication", "authentication", "server.authentication has a value this auditor cannot read as true or false — confirm authentication is actually enabled before deploying.");
        }

        /* --- Endpoint + TLS --- */
        var epEntry = lastOf(findAll(entries, function(e){
          return (keyIs(e, "server.endpoint") || e.key === "endpoint") && e.key.indexOf("agency") < 0;
        }));
        var sslKeyfile = lastOf(findAll(entries, function(e){ return keyIs(e, "ssl.keyfile") || e.key.indexOf("ssl") >= 0 && e.key.indexOf("keyfile") >= 0; }));
        var sslCert = lastOf(findAll(entries, function(e){ return e.key.indexOf("ssl") >= 0 && e.key.indexOf("cert") >= 0; }));
        if (!epEntry) {
          add("MEDIUM", null, "server.endpoint", "endpoint", "No server.endpoint was found in the pasted config, so the bind address cannot be graded. ArangoDB's default endpoint may not match what you intend to expose.");
        } else {
          var epVal = firstToken(epEntry.value);
          var scheme = epVal.indexOf("://") >= 0 ? epVal.split("://")[0].toLowerCase() : "";
          var rest = epVal.indexOf("://") >= 0 ? epVal.split("://")[1] : epVal;
          var host = "";
          if (rest.charAt(0) === "[") { host = rest.slice(0, rest.indexOf("]") + 1); }
          else { host = rest.split(/[:\/]/)[0]; }
          var hostLc = host.toLowerCase();
          var wildcard = hostLc === "0.0.0.0" || hostLc === "::" || hostLc === "[::]" || hostLc === "";
          var localhost = hostLc === "127.0.0.1" || hostLc === "localhost" || hostLc === "::1" || hostLc === "[::1]";
          var isSSL = scheme.indexOf("ssl") >= 0 || scheme.indexOf("https") >= 0;
          if (wildcard) {
            if (authOn) {
              add("HIGH", epEntry.line, "server.endpoint", "endpoint", "Endpoint binds to all interfaces (" + (host || "wildcard") + "). The database is reachable from every network this host touches — restrict the bind or put it behind a firewall / reverse proxy.");
            } else {
              add("BLOCKER", epEntry.line, "server.endpoint", "endpoint", "Endpoint binds to all interfaces (" + (host || "wildcard") + ") AND authentication is off or unset. That combination is an open database on the network — do not deploy.");
            }
          }
          if (!isSSL && !localhost) {
            if (!sslKeyfile && !sslCert) {
              add("HIGH", epEntry.line, "server.endpoint", "tls", "Endpoint is plaintext (" + (scheme || "tcp") + "://) on a non-localhost host, and no ssl.keyfile or ssl.certificate is configured anywhere in the pasted config. Traffic — including credentials and JWTs — crosses the network unencrypted.");
            } else {
              add("MEDIUM", epEntry.line, "server.endpoint", "tls", "TLS material is configured, but the endpoint scheme is plaintext (" + (scheme || "tcp") + "://). Use an ssl:// endpoint so the configured keyfile and certificate are actually used.");
            }
          }
          if (isSSL && !sslKeyfile) {
            add("HIGH", epEntry.line, "server.endpoint", "tls", "Endpoint uses TLS (" + scheme + "://) but no ssl.keyfile is configured in the pasted config — the server has no key/certificate pair to serve TLS with.");
          }
          if (!wildcard && localhost && isSSL && sslKeyfile) passes.push("Endpoint is bound to localhost over TLS with an ssl.keyfile configured (line " + epEntry.line + ").");
          if (!wildcard && localhost && !isSSL) passes.push("Endpoint is limited to localhost (line " + epEntry.line + ").");
          if (sslKeyfile && isSSL) passes.push("ssl.keyfile is configured (line " + sslKeyfile.line + ").");
        }

        /* --- JWT secret --- */
        var jwtPlain = lastOf(findAll(entries, function(e){ return keyIs(e, "jwt-secret") || keyIs(e, "server.jwt-secret"); }));
        var jwtFile = lastOf(findAll(entries, function(e){ return keyIs(e, "jwt-secret-file") || keyIs(e, "server.jwt-secret-file"); }));
        var BADWORDS = ["example", "changeme", "change-me", "default"];
        if (jwtPlain && jwtPlain.value !== "") {
          var jv = jwtPlain.value, jlen = jv.length, jlow = jv.toLowerCase(), bad = null;
          BADWORDS.forEach(function(w){ if (jlow.indexOf(w) >= 0) bad = w; });
          if (jlen < 32) {
            add("HIGH", jwtPlain.line, "server.jwt-secret", "jwt", "Inline JWT secret is short: " + jlen + " characters (32 or more is the floor). Graded by length only — the value is never shown. Move it to a jwt-secret-file with a long random value.");
          } else if (bad) {
            add("HIGH", jwtPlain.line, "server.jwt-secret", "jwt", "Inline JWT secret (" + jlen + " characters) contains a placeholder-style word (\"" + bad + "\"). Graded by key name, line, and length only — the value is never shown. Replace it with a long random secret in a jwt-secret-file.");
          } else {
            add("MEDIUM", jwtPlain.line, "server.jwt-secret", "jwt", "JWT secret is set inline in the config text (" + jlen + " characters; value never shown). Anyone who can read this config owns the token-signing secret — prefer server.jwt-secret-file with tight file permissions.");
          }
        } else if (jwtFile) {
          passes.push("JWT secret is supplied via a secret file (server.jwt-secret-file, line " + jwtFile.line + ") rather than inline text.");
        } else if (authOn) {
          add("MEDIUM", null, "server.jwt-secret-file", "jwt", "Authentication is on, but neither jwt-secret nor jwt-secret-file appears in the pasted config, so the JWT secret posture cannot be confirmed from this text.");
        }

        /* --- Passwords (length only, values never shown) --- */
        var pwEntries = findAll(entries, function(e){
          return (keyIs(e, "database.password") || e.key === "password" || keyIs(e, "server.password")) && e.key.indexOf("file") < 0;
        });
        pwEntries.forEach(function(e){
          if (!e.value) return;
          if (/^\$\{/.test(e.value) || /^env:/i.test(e.value)) return;
          var len = e.value.length, low = e.value.toLowerCase(), badw = null;
          BADWORDS.concat(["password", "letmein"]).forEach(function(w){ if (low.indexOf(w) >= 0) badw = w; });
          if (len < 12 || badw) {
            add("HIGH", e.line, e.key, "password", "Plaintext password in config text: " + len + " characters" + (badw ? ", containing a placeholder-style word" : "") + ". Graded by key name, line, and length only — the value is never shown. Remove it from the config and supply it through a protected channel.");
          } else {
            add("MEDIUM", e.line, e.key, "password", "Plaintext password present in config text (" + len + " characters; value never shown). Config files get copied, committed, and pasted — keep passwords out of them.");
          }
        });
        var pwFile = findAll(entries, function(e){ return e.key.indexOf("password") >= 0 && e.key.indexOf("file") >= 0; });
        if (pwFile.length && !pwEntries.length) passes.push("Password is supplied via a file reference rather than inline text (line " + pwFile[0].line + ").");
        if (!pwEntries.length && !pwFile.length) passes.push("No plaintext password keys found in the pasted config.");

        /* --- Cluster / agency endpoints --- */
        var agency = findAll(entries, function(e){ return e.key.indexOf("agency") >= 0 && e.key.indexOf("endpoint") >= 0; });
        var agencyBad = 0;
        agency.forEach(function(e){
          var v = firstToken(e.value).toLowerCase();
          if (v.indexOf("http://") === 0 || v.indexOf("tcp://") === 0) {
            agencyBad++;
            add("HIGH", e.line, e.key, "agency", "Cluster agency endpoint is plaintext (" + (v.indexOf("http://") === 0 ? "http://" : "tcp://") + "). Agency traffic carries cluster coordination and credentials — use https:// endpoints.");
          }
        });
        if (agency.length && !agencyBad) passes.push("All " + agency.length + " cluster agency endpoint(s) use HTTPS.");

        /* --- Encryption at rest --- */
        var encClaim = lastOf(findAll(entries, function(e){
          return e.key.indexOf("encryption-at-rest") >= 0 || e.key.indexOf("encryption_at_rest") >= 0;
        }));
        var encKeyfile = lastOf(findAll(entries, function(e){
          return e.key.indexOf("encryption") >= 0 && e.key.indexOf("keyfile") >= 0;
        }));
        if (encClaim && truthy(firstToken(encClaim.value))) {
          if (!encKeyfile) {
            add("HIGH", encClaim.line, encClaim.key, "encryption", "Encryption at rest is claimed (line " + encClaim.line + ") but no encryption keyfile is configured anywhere in the pasted config. Without the keyfile, the claim does not hold.");
          } else {
            passes.push("Encryption at rest is claimed and an encryption keyfile is configured (line " + encKeyfile.line + ").");
          }
        }

        /* --- Log & file exposure --- */
        var logLevels = findAll(entries, function(e){ return keyIs(e, "log.level") || e.key === "level"; });
        logLevels.forEach(function(e){
          var lv = firstToken(e.value).toLowerCase();
          if (lv === "debug" || lv === "trace") {
            add("MEDIUM", e.line, e.key, "logging", "Log level is \"" + lv + "\" — verbose logs can record queries, tokens, and document contents. Use info or warning in production.");
          }
        });
        var pathKeys = findAll(entries, function(e){
          return keyIs(e, "database.directory") || keyIs(e, "log.file") || keyIs(e, "log.output") || e.key.indexOf("agency") < 0 && (keyIs(e, "log.file"));
        });
        pathKeys.forEach(function(e){
          var v = firstToken(e.value);
          if (/^\/tmp(\/|$)/.test(v) || v.indexOf("/tmp/") >= 0) {
            add("LOW", e.line, e.key, "paths", "Path " + v + " sits under /tmp — world-readable on many systems and wiped on reboot. Keep database and log files in dedicated, permission-restricted directories.");
          } else if (/\/www\/|htdocs|public_html|\/public\//.test(v)) {
            add("MEDIUM", e.line, e.key, "paths", "Path " + v + " sits inside a web-served directory — files there may be downloadable over HTTP. Move it outside the web root.");
          }
        });

        /* --- Extra posture checks --- */
        findAll(entries, function(e){ return e.key.indexOf("trusted-origin") >= 0 || e.key.indexOf("allow-origin") >= 0; }).forEach(function(e){
          if (firstToken(e.value) === "*") add("MEDIUM", e.line, e.key, "cors", "Trusted/allowed origin is the wildcard \"*\". Any website can make credentialed browser requests to this database — restrict it to named origins.");
        });
        findAll(entries, function(e){ return keyIs(e, "server.uid"); }).forEach(function(e){
          var v = firstToken(e.value).toLowerCase();
          if (v === "root" || v === "0") add("MEDIUM", e.line, e.key, "runtime", "Server is configured to run as root. Run arangod as a dedicated unprivileged user.");
        });

        var order = { BLOCKER: 0, HIGH: 1, MEDIUM: 2, LOW: 3 };
        findings.sort(function(a, b){
          if (order[a.severity] !== order[b.severity]) return order[a.severity] - order[b.severity];
          return (a.line || 0) - (b.line || 0);
        });

        var counts = { BLOCKER: 0, HIGH: 0, MEDIUM: 0, LOW: 0 };
        findings.forEach(function(f){ counts[f.severity]++; });

        var verdict;
        if (counts.BLOCKER > 0 || counts.HIGH > 0) verdict = "DO NOT DEPLOY";
        else if (counts.MEDIUM > 0 || counts.LOW > 0) verdict = "DEPLOY WITH FIXES";
        else verdict = "SAFE TO DEPLOY";

        return { verdict: verdict, findings: findings, passes: passes, parsed: parsed, counts: counts, note: null };
      }

      function buildReport(r){
        var L = [];
        L.push("J-Dawgs ArangoDB Server Config Safety Auditor\u2122 — Audit Report");
        L.push("Verdict: " + r.verdict);
        if (r.note) { L.push(""); L.push(r.note); }
        var p = r.parsed;
        L.push("Parsed settings: " + p.entries.length +
          " | Commented lines (not graded): " + (p.commented.length ? p.commented.join(", ") : "none") +
          " | Not parsed lines (numbers only): " + (p.notParsed.length ? p.notParsed.join(", ") : "none"));
        if (r.counts) L.push("Findings: " + r.counts.BLOCKER + " BLOCKER, " + r.counts.HIGH + " HIGH, " + r.counts.MEDIUM + " MEDIUM, " + r.counts.LOW + " LOW");
        if (r.findings.length) {
          L.push(""); L.push("FINDINGS");
          r.findings.forEach(function(f){
            L.push("[" + f.severity + "] " + (f.line ? "Line " + f.line : "Not set") + " · " + f.key + " — " + f.message);
          });
        }
        if (r.passes.length) {
          L.push(""); L.push("PASSED CHECKS");
          r.passes.forEach(function(s){ L.push("- " + s); });
        }
        L.push("");
        L.push("Scope: text audit only. This tool does not connect to any server and does not verify JWT secrets actually in use. Secret values are never shown; secrets are graded by key name, line, and length only.");
        return L.join("\n");
      }

      function buildJson(r){
        var obj = {
          tool: "J-Dawgs ArangoDB Server Config Safety Auditor\u2122",
          verdict: r.verdict,
          note: r.note || undefined,
          summary: {
            parsedSettings: r.parsed.entries.length,
            commentedLines: r.parsed.commented,
            notParsedLines: r.parsed.notParsed,
            counts: r.counts || { BLOCKER: 0, HIGH: 0, MEDIUM: 0, LOW: 0 }
          },
          findings: r.findings,
          passedChecks: r.passes,
          scope: "Text audit only. Does not connect to any server. Does not verify JWT secrets actually in use. Secret values are never included; secrets are graded by key name, line, and length only."
        };
        return JSON.stringify(obj, null, 2);
      }

      var lastResult = null;
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-arangodb-server-config-safety-auditortm-2',
  name: 'J-Dawgs ArangoDB Server Config Safety Auditor',
  description: '',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
