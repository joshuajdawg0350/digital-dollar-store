'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Curl Command Safety & Portability Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        /* ---------------- Examples ---------------- */
        var RISKY = [
          "curl -k -X POST https://api.example.com/v1/charges?api_key=sk_live_4eC39HqLyjWDarjtT1zdp7dc \\",
          "  -H \"Authorization: Bearer sk_live_4eC39HqLyjWDarjtT1zdp7dc\" \\",
          "  -H \"Content-Type: application/json\" \\",
          "  -d '{\"amount\": 2000, \"currency\": \"usd\"}'"
        ].join("\n");

        var CLEAN = [
          "curl --max-time 30 --retry 2 --retry-delay 5 \\",
          "  -H \"Accept: application/json\" \\",
          "  https://api.example.com/v1/status"
        ].join("\n");

        /* ---------------- Flag tables ---------------- */
        var VALUE_LONG = {};
        ("request header data data-raw data-binary data-ascii data-urlencode form form-string user output user-agent referer url max-time connect-timeout retry retry-delay retry-max-time cacert capath cert key config proxy proxy-user proxy-header cookie cookie-jar oauth2-bearer resolve connect-to upload-file write-out dump-header range time-cond limit-rate max-redirs max-filesize expect100-timeout keepalive-time keepalive-cnt interface local-port dns-servers cert-type key-type pass engine crlfile login-options aws-sigv4 proto request-target ciphers tls-max tlsauthtype unix-socket abstract-unix-socket alt-svc hsts mail-from mail-rcpt tftp-blksize service-name speed-limit speed-time ftp-alternative pubkey hostpubmd5 trace trace-ascii stderr socks5-gssapi-service doh-url etag-save etag-compare ipfs-gateway-prefix libcurl sasl-authzid ssl-sessions vlan-priority happy-eyeballs-timeout-ms proxy-cacert proxy-capath proxy-cert proxy-key proxy-pass proxy-ciphers proxy-tlsauthtype proxy-pinnedpubkey pinnedpubkey doh-cert-status create-file-mode remove-target attr xattr").split(" ").forEach(function (n) { VALUE_LONG[n] = true; });

        var BOOL_LONG = {};
        ("insecure verbose silent show-error include head location fail remote-name remote-header-name globoff compressed no-buffer netrc netrc-optional disable help version http1.0 http1.1 http2 http2-prior-knowledge http3 ssl-reqd tcp-nodelay create-dirs remove-on-error fail-with-body retry-connrefused retry-all-errors location-trusted junk-session-cookies json cert-status digest basic anyauth ntlm negotiate path-as-is proxy-basic proxy-digest proxy-ntlm proxy-negotiate suppress-connect-headers parallel parallel-immediate progress-bar progress-meter no-progress-meter raw list-only ftp-skip-pasv-ip ftp-pret ftp-use-epsv ftp-use-epv ftp-create-dirs crlf proxy-http2 proxy-http3 skip-existing no-clobber test-event trace-config trace-ids trace-time no-keepalive no-sessionid no-alpn no-npn disable-epsv disable-eprt sasl-ir ssl ssl-allow-beast tlsv1 tlsv1.0 tlsv1.1 tlsv1.2 tlsv1.3 no-revoke best-effort socks5-hostname tls-earlydata false-start tcp-fastopen proxy-insecure proxy-ssl-allow-beast proxy-tlsv1 post301 post302 post303 remote-name-all remote-time use-ascii append writeout-xattr globoff-x").split(" ").forEach(function (n) { BOOL_LONG[n] = true; });
        delete BOOL_LONG["globoff-x"];

        var SHORT_VALUE = { X: "request", H: "header", d: "data", F: "form", u: "user", o: "output", A: "user-agent", e: "referer", m: "max-time", K: "config", x: "proxy", U: "proxy-user", b: "cookie", c: "cookie-jar", E: "cert", T: "upload-file", r: "range", z: "time-cond", w: "write-out", D: "dump-header", Y: "speed-limit", y: "speed-time" };
        var SHORT_BOOL = { k: "insecure", v: "verbose", s: "silent", S: "show-error", i: "include", I: "head", L: "location", f: "fail", O: "remote-name", g: "globoff", N: "no-buffer", n: "netrc", q: "disable", h: "help", V: "version", "4": "ipv4", "6": "ipv6", p: "proxy-tunnel", a: "append", B: "use-ascii", j: "junk-session-cookies", l: "list-only", R: "remote-time", t: "telnet-option-x", "#": "progress-bar" };
        delete SHORT_BOOL["telnet-option-x"];

        var DATA_FLAGS = { "data": 1, "data-raw": 1, "data-binary": 1, "data-ascii": 1, "data-urlencode": 1, "form": 1, "form-string": 1 };
        var SENSITIVE_PARAM = /key|token|secret|pass|auth|sig|session|cred|jwt/i;
        var SENSITIVE_FIELD = /pass|token|secret|key|auth|card|cvv|cvc|ssn|pin/i;
        var SENSITIVE_FLAGNAME = /token|secret|pass|api[-_]?key|apikey|credential|auth/i;

        function esc(s) {
          return String(s).replace(/[&<>"']/g, function (c) {
            return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
          });
        }
        function escRe(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); }
        function lineOf(text, idx) {
          var line = 1;
          for (var i = 0; i < idx && i < text.length; i++) if (text[i] === "\n") line++;
          return line;
        }

        /* ---------------- Tokenizer ----------------
           Splits shell-style text into tokens. Tracks the raw span of every
           token in the original string so secrets can be masked in place and
           the rest of the command stays byte-identical. */
        function tokenize(input) {
          var tokens = [], comments = [];
          var i = 0, n = input.length, cur = null;
          function startToken(idx) { cur = { value: "", start: idx, end: idx, quote: null }; }
          function endToken(endIdx) { if (cur) { cur.end = endIdx; tokens.push(cur); cur = null; } }

          while (i < n) {
            var ch = input[i];
            if (!cur) {
              if (ch === " " || ch === "\t" || ch === "\r" || ch === "\n") { i++; continue; }
              if (ch === "\\" && input[i + 1] === "\n") { i += 2; continue; }
              if (ch === "#") {
                var j = input.indexOf("\n", i); if (j < 0) j = n;
                comments.push(input.slice(i, j)); i = j; continue;
              }
              startToken(i);
            }
            if (ch === "'") {
              if (!cur.quote) cur.quote = "'";
              var openS = i; i++;
              var closedS = false;
              while (i < n) {
                if (input[i] === "'") { closedS = true; i++; break; }
                cur.value += input[i]; i++;
              }
              if (!closedS) return { error: { kind: "quote", pos: openS, quote: "'" } };
              continue;
            }
            if (ch === '"') {
              if (!cur.quote) cur.quote = '"';
              var openD = i; i++;
              var closedD = false;
              while (i < n) {
                var c = input[i];
                if (c === '"') { closedD = true; i++; break; }
                if (c === "\\" && i + 1 < n && '"$`\\\n'.indexOf(input[i + 1]) >= 0) {
                  if (input[i + 1] !== "\n") cur.value += input[i + 1];
                  i += 2; continue;
                }
                cur.value += c; i++;
              }
              if (!closedD) return { error: { kind: "quote", pos: openD, quote: '"' } };
              continue;
            }
            if (ch === " " || ch === "\t" || ch === "\r" || ch === "\n") { endToken(i); i++; continue; }
            if (ch === "\\") {
              if (input[i + 1] === "\n") { i += 2; continue; }
              if (i + 1 < n) { cur.value += input[i + 1]; i += 2; continue; }
              cur.value += "\\"; i++; continue;
            }
            cur.value += ch; i++;
          }
          endToken(n);
          tokens.forEach(function (t) { t.line = lineOf(input, t.start); });
          return { tokens: tokens, comments: comments };
        }

        function requote(val, quote) {
          if (val === "") return "''";
          if (!/[\s'"\\$`]/.test(val)) return val;
          if (quote === "'" && val.indexOf("'") < 0) return "'" + val + "'";
          if (quote === '"' && !/["$`]/.test(val)) return '"' + val + '"';
          if (val.indexOf("'") < 0) return "'" + val + "'";
          return '"' + val.replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\$/g, "\\$").replace(/`/g, "\\`") + '"';
        }

        /* ---------------- URL helpers ---------------- */
        function sensitiveParamsIn(url) {
          var names = [];
          var qi = url.indexOf("?");
          if (qi < 0) return names;
          var query = url.slice(qi + 1).split("#")[0];
          query.split("&").forEach(function (pair) {
            var eq = pair.indexOf("=");
            if (eq > 0) {
              var name = pair.slice(0, eq);
              try { name = decodeURIComponent(name); } catch (e) {}
              if (SENSITIVE_PARAM.test(name)) names.push(name);
            }
          });
          return names;
        }
        function urlHasUserinfoPassword(url) {
          var m = /^[a-zA-Z][a-zA-Z0-9+.-]*:\/\/([^\/@?#]+)@/.exec(url);
          return !!(m && m[1].indexOf(":") >= 0);
        }
        function maskUrlValue(url) {
          var out = url.replace(/^([a-zA-Z][a-zA-Z0-9+.-]*:\/\/)([^\/@?#:]+):([^@\/?#]*)@/, "$1$2:***@");
          out = out.replace(/([?&])([^=&#]+)=([^&#]*)/g, function (m, pre, name) {
            var nm = name; try { nm = decodeURIComponent(name); } catch (e) {}
            return SENSITIVE_PARAM.test(nm) ? pre + name + "=***" : m;
          });
          return out;
        }
        function maskUrlRaw(raw) {
          var out = raw.replace(/(:\/\/)([^\/@\s'":]+):([^@\s'"]+)@/, "$1$2:***@");
          out = out.replace(/([?&])([^=&#\s'"]+)=([^&#\s'"]*)/g, function (m, pre, name) {
            return SENSITIVE_PARAM.test(name) ? pre + name + "=***" : m;
          });
          return out;
        }

        /* ---------------- Data body helpers ---------------- */
        function dataFields(name, v) {
          if (v == null) return [];
          if (name === "form" || name === "form-string") {
            var first = v.split(";")[0];
            var eq = first.indexOf("=");
            return [eq >= 0 ? first.slice(0, eq) : first];
          }
          var t = v.replace(/^\s+/, "");
          if (t.charAt(0) === "@") return [];
          if (t.charAt(0) === "{") {
            try { return Object.keys(JSON.parse(t)); } catch (e) {
              var ks = [], re = /"([^"]+)"\s*:/g, m;
              while ((m = re.exec(t))) ks.push(m[1]);
              return ks;
            }
          }
          if (t.indexOf("=") >= 0) {
            return t.split("&").map(function (p) {
              var e2 = p.indexOf("=");
              return e2 >= 0 ? p.slice(0, e2) : p;
            });
          }
          return [];
        }
        function maskDataValue(name, v) {
          var t = v.replace(/^\s+/, "");
          if (name === "form" || name === "form-string") {
            var semi = v.indexOf(";");
            var head = semi >= 0 ? v.slice(0, semi) : v;
            var tail = semi >= 0 ? v.slice(semi) : "";
            var eq = head.indexOf("=");
            if (eq >= 0 && SENSITIVE_FIELD.test(head.slice(0, eq))) return head.slice(0, eq + 1) + "***" + tail;
            return v;
          }
          if (t.charAt(0) === "{") {
            return v.replace(/"([^"]+)"\s*:\s*("(?:[^"\\]|\\.)*"|-?\d[\d.]*|true|false|null)/g, function (m, key) {
              return SENSITIVE_FIELD.test(key) ? '"' + key + '": "***"' : m;
            });
          }
          if (v.indexOf("=") >= 0) {
            return v.split("&").map(function (p) {
              var e2 = p.indexOf("=");
              if (e2 < 0) return p;
              return SENSITIVE_FIELD.test(p.slice(0, e2)) ? p.slice(0, e2 + 1) + "***" : p;
            }).join("&");
          }
          return v;
        }

        /* ---------------- Audit ---------------- */
        function audit(input) {
          var findings = [];
          var replacements = []; // {start,end,text}
          function add(sev, title, where, detail) {
            findings.push({ sev: sev, title: title, where: where, detail: detail });
          }
          function replaceToken(tok, newValue) {
            replacements.push({ start: tok.start, end: tok.end, text: requote(newValue, tok.quote) });
          }

          if (!input || !input.replace(/\s+/g, "")) {
            return { empty: true };
          }

          var tk = tokenize(input);
          if (tk.error) {
            return {
              parseError: "Unterminated " + (tk.error.quote === "'" ? "single" : "double") + " quote starting at character " + (tk.error.pos + 1) + " (line " + lineOf(input, tk.error.pos) + "). The audit stopped there rather than guess at the rest of the command."
            };
          }
          var tokens = tk.tokens;
          if (!tokens.length) return { empty: true };

          var first = tokens[0].value;
          var base = first.split(/[\\/]/).pop().toLowerCase();
          if (base !== "curl" && base !== "curl.exe") {
            return {
              parseError: "COULD NOT PARSE — the first word at character 1 is \"" + first.slice(0, 40) + "\", not \"curl\". Paste a single curl command."
            };
          }

          /* --- parse flags --- */
          var occ = [], unknown = [], positional = [];
          var endOfFlags = false, idx = 1, extraCurl = 0;
          while (idx < tokens.length) {
            var t = tokens[idx];
            if (t.value === "curl" && idx > 1) extraCurl++;
            if (!endOfFlags && t.value === "--") { endOfFlags = true; idx++; continue; }
            if (!endOfFlags && t.value.length > 2 && t.value.slice(0, 2) === "--") {
              var body = t.value.slice(2), eqPos = body.indexOf("=");
              var lname = eqPos >= 0 ? body.slice(0, eqPos) : body;
              if (VALUE_LONG[lname]) {
                if (eqPos >= 0) {
                  occ.push({ name: lname, display: "--" + lname, value: body.slice(eqPos + 1), attachedPrefix: "--" + lname + "=", tokenIdx: idx, valueTokenIdx: idx });
                } else {
                  var nt = tokens[idx + 1];
                  occ.push({ name: lname, display: "--" + lname, value: nt ? nt.value : null, tokenIdx: idx, valueTokenIdx: nt ? idx + 1 : -1 });
                  if (nt) idx++;
                }
              } else if (BOOL_LONG[lname]) {
                occ.push({ name: lname, display: "--" + lname, value: null, tokenIdx: idx, valueTokenIdx: -1 });
              } else {
                unknown.push({ display: "--" + lname, line: t.line, hasEq: eqPos >= 0 });
              }
              idx++; continue;
            }
            if (!endOfFlags && t.value.length > 1 && t.value[0] === "-" && t.value !== "-") {
              var s = t.value.slice(1), j = 0, consumedNext = false;
              while (j < s.length) {
                var c = s[j];
                if (SHORT_VALUE[c]) {
                  var rest = s.slice(j + 1);
                  if (rest) {
                    occ.push({ name: SHORT_VALUE[c], display: "-" + c, value: rest, attachedPrefix: t.value.slice(0, j + 2), tokenIdx: idx, valueTokenIdx: idx });
                  } else {
                    var nt2 = tokens[idx + 1];
                    occ.push({ name: SHORT_VALUE[c], display: "-" + c, value: nt2 ? nt2.value : null, tokenIdx: idx, valueTokenIdx: nt2 ? idx + 1 : -1 });
                    consumedNext = !!nt2;
                  }
                  break;
                }
                if (SHORT_BOOL[c]) { occ.push({ name: SHORT_BOOL[c], display: "-" + c, value: null, tokenIdx: idx, valueTokenIdx: -1 }); j++; continue; }
                unknown.push({ display: "-" + c, line: t.line, hasEq: false });
                j++;
              }
              idx += consumedNext ? 2 : 1;
              continue;
            }
            positional.push(idx); idx++;
          }

          function byName(name) { return occ.filter(function (o) { return o.name === name; }); }
          function has(name) { return byName(name).length > 0; }
          function where(o) {
            var tok = tokens[o.tokenIdx];
            return "line " + tok.line + " · " + o.display;
          }
          function maskOccurrence(o, maskedValue) {
            if (o.valueTokenIdx === o.tokenIdx) {
              // value attached to the flag token itself
              replaceToken(tokens[o.tokenIdx], (o.attachedPrefix || "") + maskedValue);
            } else if (o.valueTokenIdx >= 0) {
              replaceToken(tokens[o.valueTokenIdx], maskedValue);
            }
          }

          /* --- URL --- */
          var urlOcc = byName("url")[0];
          var urlTokIdx = urlOcc ? urlOcc.valueTokenIdx : (positional.length ? positional[0] : -1);
          var urlValue = urlOcc ? urlOcc.value : (urlTokIdx >= 0 ? tokens[urlTokIdx].value : null);
          var urlTok = urlTokIdx >= 0 && tokens[urlTokIdx] ? tokens[urlTokIdx] : null;

          var secretCount = 0;

          /* --- secrets: URL --- */
          if (urlValue) {
            var sp = sensitiveParamsIn(urlValue);
            sp.forEach(function (pname) {
              secretCount++;
              add("secret", "Secret in URL query parameter \"" + pname + "\"",
                "line " + urlTok.line + " · URL",
                "Credentials in a URL are stored in shell history, server logs, and browser history. The value is never shown here; it is masked as *** in the share-safe copy. Prefer a header instead.");
            });
            if (urlHasUserinfoPassword(urlValue)) {
              secretCount++;
              add("secret", "Password embedded in the URL userinfo (user:pass@host)",
                "line " + urlTok.line + " · URL",
                "The password is never shown here and is masked as *** in the share-safe copy.");
            }
            var maskedRaw = maskUrlRaw(input.slice(urlTok.start, urlTok.end));
            if (maskedRaw !== input.slice(urlTok.start, urlTok.end)) {
              replacements.push({ start: urlTok.start, end: urlTok.end, text: maskedRaw });
            }
          }

          /* --- secrets & checks per flag occurrence --- */
          var headerNames = [], dataFieldList = [], verboseSeen = false;

          occ.forEach(function (o) {
            var tok = tokens[o.tokenIdx];

            if (o.name === "header" && o.value != null) {
              var ci = o.value.indexOf(":");
              if (ci >= 0) {
                var hname = o.value.slice(0, ci).replace(/\s+$/, "");
                var hval = o.value.slice(ci + 1).replace(/^\s+/, "");
                var lh = hname.toLowerCase();
                headerNames.push(hname);
                if (lh === "authorization" || lh === "proxy-authorization") {
                  var parts = hval.split(/\s+/);
                  var scheme = parts[0] || "";
                  secretCount++;
                  if (/^(bearer|basic|digest|ntlm|negotiate)$/i.test(scheme) && parts.length > 1) {
                    add("secret", "Secret in header: " + hname + " (" + scheme + " credential)",
                      where(o),
                      "The credential value is never shown here. It is masked as *** in the share-safe copy — anyone holding the real value can call the API as you.");
                    maskOccurrence(o, hname + ": " + scheme + " ***");
                  } else {
                    add("secret", "Secret in header: " + hname, where(o),
                      "The header value is never shown here. It is masked as *** in the share-safe copy.");
                    maskOccurrence(o, hname + ": ***");
                  }
                  return;
                }
                if (lh === "cookie") {
                  secretCount++;
                  add("secret", "Secret in header: Cookie", where(o),
                    "Cookie values are session credentials. The value is never shown here and is masked as *** in the share-safe copy.");
                  maskOccurrence(o, hname + ": ***");
                  return;
                }
                if (/key|token|secret|auth/.test(lh)) {
                  secretCount++;
                  add("secret", "Secret in header: " + hname, where(o),
                    "This header's name marks its value as a credential. The value is never shown here and is masked as *** in the share-safe copy.");
                  maskOccurrence(o, hname + ": ***");
                  return;
                }
              }
              return;
            }

            if (o.name === "user" && o.value != null) {
              var uc = o.value.indexOf(":");
              if (uc >= 0) {
                secretCount++;
                add("secret", "Password in -u / --user credentials", where(o),
                  "The password after the colon is never shown here. It is masked in the share-safe copy, and it also sits in your shell history in plain text.");
                maskOccurrence(o, o.value.slice(0, uc + 1) + "***");
              } else {
                add("note", "Username only in " + o.display, where(o),
                  "No password is in the command (curl would prompt for one), so nothing leaks here — but the username still lands in shell history.");
              }
              return;
            }

            if (o.name === "proxy-user" && o.value != null && o.value.indexOf(":") >= 0) {
              secretCount++;
              add("secret", "Password in --proxy-user credentials", where(o),
                "The proxy password is never shown here and is masked in the share-safe copy.");
              maskOccurrence(o, o.value.slice(0, o.value.indexOf(":") + 1) + "***");
              return;
            }

            if (o.name === "oauth2-bearer") {
              secretCount++;
              add("secret", "Bearer token passed via --oauth2-bearer", where(o),
                "The token value is never shown here and is masked as *** in the share-safe copy.");
              if (o.value != null) maskOccurrence(o, "***");
              return;
            }

            if (o.name === "cookie" && o.value != null) {
              if (o.value.indexOf("=") >= 0) {
                secretCount++;
                add("secret", "Session cookie passed via " + o.display, where(o),
                  "An inline name=value here is a live session cookie, not a cookie file. The value is never shown here and is masked as *** in the share-safe copy.");
                maskOccurrence(o, "***");
              } else {
                add("note", "Cookie file referenced via " + o.display, where(o),
                  "This names a file on disk rather than an inline cookie, so no cookie value is in the command. The file itself stays sensitive.");
              }
              return;
            }

            if (DATA_FLAGS[o.name]) {
              if (o.value != null) {
                var fields = dataFields(o.name, o.value);
                fields.forEach(function (f) { dataFieldList.push({ field: f, display: o.display, line: tok.line }); });
                var sensFields = fields.filter(function (f) { return SENSITIVE_FIELD.test(f); });
                sensFields.forEach(function (f) {
                  secretCount++;
                  add("secret", "Secret field \"" + f + "\" in request body (" + o.display + ")",
                    where(o),
                    "Only the field name is reported — the value is never shown here and is masked as *** in the share-safe copy.");
                });
                if (/^\s*@/.test(o.value) && o.name !== "data-raw" && o.name !== "form" && o.name !== "form-string") {
                  add("note", "Request body is read from a file (" + o.display + " @file)", where(o),
                    "The body is not in the pasted command, so its contents were not audited. Check the file before sharing the command.");
                }
                var maskedData = maskDataValue(o.name, o.value);
                if (maskedData !== o.value) maskOccurrence(o, maskedData);
              }
              return;
            }

            // generic credential-named flags not handled above
            if (o.value != null && SENSITIVE_FLAGNAME.test(o.name) &&
                ["header", "user", "proxy-user", "oauth2-bearer", "cookie"].indexOf(o.name) < 0) {
              secretCount++;
              add("secret", "Credential value passed via " + o.display, where(o),
                "The flag's name marks its value as a credential. The value is never shown here and is masked as *** in the share-safe copy.");
              maskOccurrence(o, "***");
              return;
            }

            if (o.name === "output" && o.value != null) {
              if (/^(\/etc\/|\/usr\/|\/bin\/|\/sbin\/|\/var\/|\/System\/|\/root\/|\/dev\/|~\/|[A-Za-z]:\\(Windows|Program Files|System32))/i.test(o.value)) {
                add("warning", "Output file writes to a system path: " + o.value, where(o),
                  "The response body will be written into a system location. That can overwrite system files or fail without admin rights; write to a working folder instead.");
              }
            }

            if (o.name === "verbose") verboseSeen = true;
          });
          if (has("verbose")) verboseSeen = true;

          /* --- safety flags --- */
          var blockers = 0, warnings = 0;

          byName("insecure").forEach(function (o) {
            blockers++;
            add("blocker", "-k / --insecure disables TLS certificate verification", where(o),
              "BLOCKER for sharing, WARNING for running: with verification off, anyone on the network path can intercept or alter the response — and any credentials it carries. Remove it and fix the certificate problem instead.");
          });

          var isHttp = urlValue != null && /^http:\/\//i.test(urlValue);
          if (isHttp) {
            if (secretCount > 0) {
              blockers++;
              add("blocker", "Cleartext http:// URL with secrets present", "line " + urlTok.line + " · URL",
                "Everything — including the credentials flagged above — crosses the network unencrypted. Switch to https:// before running or sharing.");
            } else {
              warnings++;
              add("warning", "Cleartext http:// URL", "line " + urlTok.line + " · URL",
                "The request and response travel unencrypted and can be read or modified in transit. Prefer https://.");
            }
          }

          var method = null, methodOcc = null;
          byName("request").forEach(function (o) { if (o.value) { method = o.value.toUpperCase(); methodOcc = o; } });
          var hasData = occ.some(function (o) { return DATA_FLAGS[o.name]; });
          var effectiveMethod = method || (hasData ? "POST" : "GET");
          if (method && /^(DELETE|PUT|PATCH)$/.test(method)) {
            var hasConfirm = /confirm/i.test(input);
            if (hasConfirm) {
              add("note", method + " request with a confirm note present", where(methodOcc),
                "A note mentioning \"confirm\" appears in the command, so the destructive method looks deliberate. Make sure the target is the one you mean.");
            } else {
              warnings++;
              add("warning", "Destructive method " + method + " with no confirm note", where(methodOcc),
                method + " changes or removes server state. There is no note in the command confirming that is intended — add one (a comment or an X-Confirm header) so nobody runs it by accident.");
            }
          }

          var hasMaxTime = has("max-time"), hasRetry = has("retry");
          if (hasRetry && !hasMaxTime) {
            warnings++;
            add("warning", "--retry is set but there is no --max-time", "flags · --retry",
              "Retries multiply however long each attempt hangs. With no overall time cap, a dead endpoint can keep this command retrying far longer than you expect.");
          }
          if (!hasMaxTime) {
            warnings++;
            add("warning", "No timeout at all — this command can hang forever", "flags · (missing --max-time)",
              "Without --max-time (or at least --connect-timeout), a stalled server or network holds the command open indefinitely. Add something like --max-time 30.");
          }

          if (verboseSeen && secretCount > 0) {
            warnings++;
            add("warning", "-v / --verbose combined with secrets", "flags · -v",
              "Verbose output prints every header — including the credentials flagged above — to the terminal and into any log or screenshot that captures it. Drop -v, or never share the output.");
          }

          if (!urlValue) {
            warnings++;
            add("warning", "No URL found", "command",
              "No URL argument and no --url flag were found. curl has nothing to call — check the paste is complete.");
          }
          if (positional.length > 1 && !urlOcc) {
            add("note", positional.length + " positional arguments found", "command",
              "The first is treated as the URL; the rest would each be fetched by curl too. If they are values for a flag this auditor does not know, see the NOT EVALUATED list.");
          }
          if (extraCurl > 0) {
            add("note", "More than one command in the paste", "command",
              "Another \"curl\" appears later in the text. One command at a time — only the first was audited as a single command.");
          }

          /* --- portability --- */
          var varNames = [], varSeen = {};
          tokens.forEach(function (tok) {
            var re = /\$\{([A-Za-z_][A-Za-z0-9_]*)\}|\$([A-Za-z_][A-Za-z0-9_]*)/g, m;
            while ((m = re.exec(tok.value))) {
              var vn = m[1] || m[2];
              if (!varSeen[vn]) { varSeen[vn] = true; varNames.push(vn); }
            }
          });
          if (varNames.length) {
            add("note", "Shell variable expansions: " + varNames.map(function (v) { return "$" + v; }).join(", "),
              "portability",
              "These expand from the shell environment of whoever runs the command. Their values are unknown to this audit and are never invented — a recipient without the same variables set gets a different command.");
          }
          var singleQuoted = tokens.some(function (tok) { return tok.quote === "'"; });
          if (singleQuoted) {
            add("note", "Single-quoted arguments — not portable to Windows cmd.exe",
              "portability",
              "cmd.exe does not treat single quotes as quoting, so this command breaks or misfires there. Use double quotes (escaping inner ones) or run it in PowerShell / Git Bash / WSL.");
          }
          if (input.indexOf("\\\n") >= 0) {
            add("note", "Backslash line continuations are Unix-shell style",
              "portability",
              "The trailing \\ joins lines in bash/zsh. PowerShell uses a backtick (`) instead, and cmd.exe needs ^ — reformat before handing this to a Windows user.");
          }
          if (headerNames.length) {
            add("note", "Headers present: " + headerNames.join(", "), "summary",
              "Header names only — values were audited above and are not repeated here.");
          }

          /* --- unknown flags --- */
          unknown.forEach(function (u) {
            add("noteval", "NOT EVALUATED: " + u.display, "line " + u.line + " · " + u.display,
              "This flag is not in the auditor's table, so nothing about it was checked — including whether it takes a value or carries a credential." + (u.hasEq ? " Its attached =value was left untouched." : ""));
          });

          /* --- counts & verdict --- */
          findings.forEach(function (f) {
            if (f.sev === "warning") warnings += 0; // already counted inline where needed
          });
          var blockerTotal = findings.filter(function (f) { return f.sev === "blocker" || f.sev === "secret"; }).length;
          var warningTotal = findings.filter(function (f) { return f.sev === "warning"; }).length;
          var noteTotal = findings.filter(function (f) { return f.sev === "note" || f.sev === "noteval"; }).length;

          var verdict, vclass;
          if (blockerTotal > 0) { verdict = "DO NOT SHARE"; vclass = "bad"; }
          else if (warningTotal > 0) { verdict = "RUN WITH FIXES"; vclass = "warn"; }
          else { verdict = "SAFE TO RUN & SHARE"; vclass = "ok"; }

          /* --- sanitized copy --- */
          var sanitized = input.replace(/\s+$/, "");
          replacements.sort(function (a, b) { return b.start - a.start; });
          var appliedFrom = Infinity;
          replacements.forEach(function (r) {
            if (r.end > appliedFrom) return; // skip overlaps, inner-first by sort order on start desc
            sanitized = sanitized.slice(0, r.start) + r.text + sanitized.slice(r.end);
            appliedFrom = r.start;
          });

          var facts = [];
          facts.push({ label: "Method", value: effectiveMethod + (method ? " (explicit)" : hasData ? " (implied by data flag)" : " (default)"), mono: true });
          if (urlValue) facts.push({ label: "URL (secrets masked)", value: maskUrlValue(urlValue), mono: true });
          facts.push({ label: "Timeout", value: hasMaxTime ? "--max-time set" : "none set", mono: false });
          facts.push({ label: "Retry", value: hasRetry ? "--retry set" : "not set", mono: false });
          if (dataFieldList.length) {
            facts.push({ label: "Data fields (names only)", value: dataFieldList.map(function (d) { return d.field; }).join(", "), mono: true });
          }
          if (varNames.length) {
            facts.push({ label: "Variables (names only)", value: varNames.map(function (v) { return "$" + v; }).join(", "), mono: true });
          }
          var outOcc = byName("output")[0];
          if (outOcc && outOcc.value) facts.push({ label: "Output file", value: outOcc.value, mono: true });
          if (has("remote-name")) facts.push({ label: "Output file", value: "-O: remote filename, written to the current directory", mono: false });

          var order = { secret: 0, blocker: 1, warning: 2, note: 3, noteval: 4 };
          findings.sort(function (a, b) { return order[a.sev] - order[b.sev]; });

          return {
            verdict: verdict, vclass: vclass,
            counts: { blockers: blockerTotal, warnings: warningTotal, notes: noteTotal },
            findings: findings, facts: facts, sanitized: sanitized
          };
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-curl-command-safety-auditor',
  name: 'J-Dawgs Curl Command Safety & Portability Auditor',
  description: 'about to run or share a curl command',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
