'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Kea DHCP Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var $ = function(id){ return document.getElementById(id); };
      var cfgInput = $("cfgInput"), verdictBox = $("verdictBox"), countsRow = $("countsRow"),
          findingsList = $("findingsList"), notVerifiedBox = $("notVerifiedBox"),
          notVerifiedList = $("notVerifiedList"), reportOut = $("reportOut"), jsonOut = $("jsonOut");

      var NOT_VERIFIED_ITEMS = [
        "Lease state on disk (lease files / lease database contents) — NOT VERIFIED: this tool reads config text only, never the live lease store.",
        "Actual interface existence — NOT VERIFIED: whether the interfaces named in interfaces-config exist and are up on the target host cannot be checked from pasted text.",
        "Hook library contents — NOT VERIFIED: hook libraries are listed by name and path, but their code is never loaded or inspected here, so hook safety cannot be confirmed.",
        "Live daemon behavior — NOT VERIFIED: whether kea-dhcp4, kea-dhcp6, or kea-ctrl-agent actually starts, binds its sockets, and serves leases on your host is only proven by running the daemon there."
      ];

      var KNOWN_HOOKS = [
        "libdhcp_lease_cmds.so","libdhcp_stat_cmds.so","libdhcp_host_cmds.so","libdhcp_subnet_cmds.so",
        "libdhcp_class_cmds.so","libdhcp_ha.so","libdhcp_flex_option.so","libdhcp_host_cache.so",
        "libdhcp_legal_log.so","libdhcp_bootp.so","libdhcp_ddns_tuning.so","libdhcp_run_script.so",
        "libdhcp_radius.so","libdhcp_perfmon.so","libdhcp_gss_tsig.so","libdhcp_ping_check.so",
        "libdhcp_user_chk.so","libdhcp_mysql.so","libdhcp_pgsql.so","libdhcp_cb_cmds.so",
        "libdhcp_mysql_cb.so","libdhcp_pgsql_cb.so","libdhcp_subnet_parsers.so"
      ];

      /* ---------- JSON tokenizer: records key line numbers + duplicate keys ---------- */
      function tokenize(text){
        var tokens = [], i = 0, line = 1, n = text.length;
        while (i < n){
          var c = text[i];
          if (c === "\n"){ line++; i++; }
          else if (c === " " || c === "\t" || c === "\r"){ i++; }
          else if (c === "{" || c === "}" || c === "[" || c === "]" || c === "," || c === ":"){
            tokens.push({ type: c, line: line }); i++;
          }
          else if (c === '"'){
            var startLine = line, raw = '"'; i++;
            while (i < n && text[i] !== '"'){
              if (text[i] === "\\"){
                raw += text.substr(i, 2); i += 2;
              } else {
                if (text[i] === "\n") line++;
                raw += text[i]; i++;
              }
            }
            if (i < n){ raw += '"'; i++; }
            var val = raw;
            try { val = JSON.parse(raw); } catch(e){ /* keep raw */ }
            tokens.push({ type: "str", value: val, line: startLine });
          }
          else {
            var start = i;
            while (i < n && /[0-9a-zA-Z.+-]/.test(text[i])) i++;
            tokens.push({ type: "value", line: line });
            if (i === start) i++;
          }
        }
        return tokens;
      }

      function scanKeys(tokens){
        var keyLines = {}, duplicates = [], pos = 0;
        function parseValue(path){
          var t = tokens[pos];
          if (!t) return;
          if (t.type === "{"){ pos++; parseObject(path); }
          else if (t.type === "["){ pos++; parseArray(path); }
          else { pos++; }
        }
        function parseObject(path){
          var seen = {};
          while (pos < tokens.length){
            var t = tokens[pos];
            if (t.type === "}"){ pos++; return; }
            if (t.type === ","){ pos++; continue; }
            if (t.type === "str"){
              var key = String(t.value), keyLine = t.line; pos++;
              if (tokens[pos] && tokens[pos].type === ":") pos++;
              var keyPath = path ? path + "." + key : key;
              if (Object.prototype.hasOwnProperty.call(seen, key)){
                duplicates.push({ key: key, firstLine: seen[key], line: keyLine, path: path || "(root)" });
              } else { seen[key] = keyLine; }
              if (keyLines[keyPath] === undefined) keyLines[keyPath] = keyLine;
              parseValue(keyPath);
            } else { pos++; }
          }
        }
        function parseArray(path){
          var idx = 0;
          while (pos < tokens.length){
            var t = tokens[pos];
            if (t.type === "]"){ pos++; return; }
            if (t.type === ","){ pos++; continue; }
            parseValue(path + "[" + idx + "]"); idx++;
          }
        }
        parseValue("");
        return { keyLines: keyLines, duplicates: duplicates };
      }

      /* ---------- helpers ---------- */
      function joinPath(base, key){ return base ? base + "." + key : key; }
      function isObj(v){ return v !== null && typeof v === "object" && !Array.isArray(v); }
      function isLocalHost(host){
        if (host === undefined || host === null || host === "") return true;
        var h = String(host).toLowerCase();
        return h === "localhost" || h === "127.0.0.1" || h === "::1" || h.charAt(0) === "/";
      }
      function walk(node, path, cb){
        cb(node, path);
        if (Array.isArray(node)){
          for (var i = 0; i < node.length; i++) walk(node[i], path + "[" + i + "]", cb);
        } else if (isObj(node)){
          var keys = Object.keys(node);
          for (var j = 0; j < keys.length; j++) walk(node[keys[j]], joinPath(path, keys[j]), cb);
        }
      }

      /* IP math on BigInt so v4 and v6 share one code path */
      function ipToBig(str){
        str = String(str).trim();
        if (str.indexOf(":") >= 0){
          var halves = str.split("::"), left = [], right = [], i, groups = [];
          if (halves.length > 2) return null;
          if (halves.length === 2){
            left = halves[0] ? halves[0].split(":") : [];
            right = halves[1] ? halves[1].split(":") : [];
            var missing = 8 - left.length - right.length;
            if (missing < 0) return null;
            groups = left.slice();
            for (i = 0; i < missing; i++) groups.push("0");
            groups = groups.concat(right);
          } else {
            groups = str.split(":");
          }
          if (groups.length !== 8) return null;
          var v = 0n;
          for (i = 0; i < 8; i++){
            if (!/^[0-9a-fA-F]{1,4}$/.test(groups[i])) return null;
            v = (v << 16n) | BigInt(parseInt(groups[i], 16));
          }
          return { value: v, bits: 128 };
        }
        var parts = str.split(".");
        if (parts.length !== 4) return null;
        var out = 0n;
        for (var k = 0; k < 4; k++){
          if (!/^\d{1,3}$/.test(parts[k])) return null;
          var octet = parseInt(parts[k], 10);
          if (octet > 255) return null;
          out = (out << 8n) | BigInt(octet);
        }
        return { value: out, bits: 32 };
      }
      function bigToIp(v, bits){
        if (bits === 32){
          var parts = [];
          for (var s = 24; s >= 0; s -= 8) parts.push(String(Number((v >> BigInt(s)) & 255n)));
          return parts.join(".");
        }
        var groups = [];
        for (var g = 112; g >= 0; g -= 16) groups.push(((v >> BigInt(g)) & 65535n).toString(16));
        return groups.join(":");
      }
      function parseCidr(cidr){
        var bits = String(cidr).split("/");
        if (bits.length !== 2) return null;
        var ip = ipToBig(bits[0]);
        if (!ip) return null;
        var prefix = parseInt(bits[1], 10);
        if (isNaN(prefix) || prefix < 0 || prefix > ip.bits) return null;
        var hostBits = BigInt(ip.bits - prefix);
        var size = 1n << hostBits;
        var mask = ip.value >> hostBits << hostBits;
        return { network: mask, broadcast: mask + size - 1n, size: size, bits: ip.bits, prefix: prefix };
      }

      /* ---------- main audit ---------- */
      function audit(text){
        var findings = [];
        function add(severity, check, line, title, detail, escalated){
          findings.push({ severity: severity, check: check, line: (line === undefined ? null : line),
                          title: title, detail: detail, escalated: !!escalated });
        }

        var parsed;
        try {
          parsed = JSON.parse(text);
        } catch (err) {
          var msg = String(err && err.message ? err.message : err);
          var posMatch = msg.match(/position\s+(\d+)/i);
          var posInfo = "parser position not reported";
          if (posMatch){
            var p = parseInt(posMatch[1], 10);
            var before = text.slice(0, p);
            var ln = before.split("\n").length;
            var col = p - before.lastIndexOf("\n");
            posInfo = "position " + p + " (line " + ln + ", column " + col + ")";
          }
          add("BLOCKER", "JSON syntax", null, "Config NOT PARSED",
              "The pasted text is not valid JSON, so no checks were run and nothing was guessed. Parser said: " + msg + " — " + posInfo + ". Fix the syntax error and run the audit again.");
          return { status: "notparsed", parsed: null, findings: findings };
        }

        var scan = scanKeys(tokenize(text));
        var keyLines = scan.keyLines;
        function lineOf(path){ return keyLines[path] !== undefined ? keyLines[path] : null; }

        if (!isObj(parsed) && !Array.isArray(parsed)){
          add("BLOCKER", "Config shape", null, "Top level is not a JSON object",
              "A Kea config file is a JSON object holding a Dhcp4, Dhcp6, or CtrlAgent section. The pasted JSON parsed, but its top level is not an object, so no Kea checks apply.");
          return { status: "parsed", parsed: parsed, findings: findings };
        }

        /* (8) Duplicate JSON keys */
        scan.duplicates.forEach(function(d){
          add("WARNING", "Duplicate JSON keys", d.line,
              'Duplicate key "' + d.key + '" at lines ' + d.firstLine + " and " + d.line,
              'The key "' + d.key + '" appears twice in the same object (object path: ' + d.path + "), first at line " + d.firstLine + " and again at line " + d.line + ". JSON parsers — Kea included — apply last-value-wins: the second value silently replaces the first. Remove one of the two entries so the config says what you think it says.");
        });

        /* Locate the server / agent sections */
        var ctrlAgent = null, ctrlPath = "";
        var sections = []; /* {name, obj, path, subnetKey} */
        Object.keys(parsed).forEach(function(k){
          var lk = k.toLowerCase();
          if (lk === "ctrlagent" && isObj(parsed[k])){ ctrlAgent = parsed[k]; ctrlPath = k; }
          if (lk === "dhcp4" && isObj(parsed[k])) sections.push({ name: "Dhcp4", obj: parsed[k], path: k, subnetKey: "subnet4" });
          if (lk === "dhcp6" && isObj(parsed[k])) sections.push({ name: "Dhcp6", obj: parsed[k], path: k, subnetKey: "subnet6" });
        });
        if (!ctrlAgent && sections.length === 0 && (parsed["subnet4"] || parsed["subnet6"] || parsed["interfaces-config"])){
          sections.push({ name: parsed["subnet6"] ? "Dhcp6" : "Dhcp4", obj: parsed, path: "", subnetKey: parsed["subnet6"] ? "subnet6" : "subnet4" });
        }
        if (!ctrlAgent && sections.length === 0){
          add("INFO", "Config shape", null, "No Dhcp4, Dhcp6, or CtrlAgent section recognized",
              "The JSON parsed, but it holds no top-level Dhcp4, Dhcp6, or CtrlAgent object, so only the generic checks (duplicates, databases, hooks, logging) could run.");
        }

        /* (1) Control-agent exposure */
        if (ctrlAgent){
          var host = ctrlAgent["http-host"], hostStr = host === undefined ? "" : String(host);
          var hostLine = lineOf(joinPath(ctrlPath, "http-host"));
          var wildcard = hostStr === "0.0.0.0" || hostStr === "::";
          var external = hostStr !== "" && !isLocalHost(hostStr);
          var auth = ctrlAgent["authentication"];
          var authHasCreds = false;
          if (isObj(auth) && Array.isArray(auth.clients)){
            auth.clients.forEach(function(c){
              if (isObj(c) && (c.user || c.password || c["password-file"])) authHasCreds = true;
            });
          }
          var hasTls = !!(ctrlAgent["cert-file"] && ctrlAgent["key-file"]);
          var portNote = ctrlAgent["http-port"] !== undefined ? " on http-port " + ctrlAgent["http-port"] : "";
          if ((wildcard || external) && !authHasCreds){
            add("BLOCKER", "Control agent", hostLine,
                'Control agent listens on "' + hostStr + '" with no authentication',
                "CtrlAgent http-host is \"" + hostStr + "\"" + portNote + " and the config carries no working authentication (the \"authentication\" block is missing, or its clients list is empty / holds no user, password, or password-file). Anyone who can reach this host can read and change the DHCP server's configuration and leases through the control agent. Bind it to 127.0.0.1, or add authentication and TLS before this config goes anywhere near a network.");
          } else if (authHasCreds && !hasTls){
            var authType = isObj(auth) && auth.type ? String(auth.type) : "basic";
            if (wildcard || external){
              add("WARNING", "Control agent", hostLine,
                  "Control agent uses " + authType + " authentication without TLS on an external host",
                  "Authentication is present, but there is no cert-file / key-file pair, so credentials cross the network as plain HTTP basic-auth — and http-host \"" + hostStr + "\" is reachable beyond this machine. Escalated: an external listener plus cleartext credentials means anyone on the path can capture them. Add TLS (cert-file + key-file, or terminate TLS in front of the agent) or bind the agent to localhost.",
                  true);
            } else {
              add("INFO", "Control agent", hostLine,
                  "Control agent authentication without TLS (loopback only)",
                  "Authentication is present and http-host is loopback, so credentials stay on this machine — acceptable. There is no cert-file / key-file pair, so if you ever widen http-host beyond localhost, add TLS at the same time.");
            }
          } else if (!authHasCreds && hostStr !== "" && isLocalHost(hostStr)){
            add("WARNING", "Control agent", hostLine,
                "Control agent on loopback with no authentication",
                "http-host is \"" + hostStr + "\", so only local processes can reach the control agent — but any local user or compromised service on the box can still reconfigure DHCP through it. Add an \"authentication\" block with at least one client.");
          }
        }

        /* (2) Database credentials — key name and line ONLY, never the value */
        var DB_KEYS = ["config-database", "lease-database", "hosts-database"];
        walk(parsed, "", function(node, path){
          if (!isObj(node)) return;
          DB_KEYS.forEach(function(dbKey){
            var db = node[dbKey];
            if (!isObj(db)) return;
            var dbPath = joinPath(path, dbKey);
            if (typeof db.password === "string" && db.password.length > 0){
              var dbHost = db.host;
              var ext = dbHost !== undefined && !isLocalHost(dbHost);
              var typeNote = db.type ? " (" + String(db.type) + ")" : "";
              var hostNote = dbHost !== undefined ? " Database host: " + String(dbHost) + "." : " No host key is set, so Kea's default (localhost) applies.";
              if (ext){
                add("WARNING", "Database credentials", lineOf(joinPath(dbPath, "password")),
                    '"' + dbKey + '" holds a "password" key for an external database host',
                    "The \"" + dbKey + "\" block" + typeNote + " contains a key named \"password\" at line " + lineOf(joinPath(dbPath, "password")) + "." + hostNote + " The password value is deliberately not printed anywhere in this audit. Escalated: the credential sits in a plain-text config file AND the database is on another host, so the secret travels and is stored in the clear. Move it to a password-file / restricted-permissions file, or use a dedicated least-privilege database account.",
                    true);
              } else {
                add("WARNING", "Database credentials", lineOf(joinPath(dbPath, "password")),
                    '"' + dbKey + '" holds a "password" key in the config file',
                    "The \"" + dbKey + "\" block" + typeNote + " contains a key named \"password\" at line " + lineOf(joinPath(dbPath, "password")) + "." + hostNote + " The password value is deliberately not printed anywhere in this audit. A password in the config at all is the finding: anyone who can read this file owns the database account. Prefer a password-file with tight permissions, or a least-privilege database user.",
                    false);
              }
            }
          });
        });

        /* (3) Hook libraries */
        walk(parsed, "", function(node, path){
          if (!isObj(node) || !Array.isArray(node["hooks-libraries"])) return;
          var hooksPath = joinPath(path, "hooks-libraries");
          node["hooks-libraries"].forEach(function(entry, i){
            if (!isObj(entry) || typeof entry.library !== "string") return;
            var lib = entry.library;
            var base = lib.split("/").pop();
            var libLine = lineOf(hooksPath + "[" + i + "].library");
            if (/^\/tmp(\/|$)/.test(lib) || /^\/var\/tmp(\/|$)/.test(lib) || /^\/dev\/shm(\/|$)/.test(lib)){
              add("WARNING", "Hook libraries", libLine,
                  'Hook library "' + base + '" loads from a world-writable-style path',
                  "Hook library path: " + lib + ". Hooks run inside the daemon with its privileges, and this path sits in a world-writable-style directory (the /tmp family), where another local user could replace the file and get code executed as the DHCP service. Move hook libraries into a root-owned directory such as /usr/lib/kea/hooks.");
            } else if (KNOWN_HOOKS.indexOf(base) >= 0){
              add("INFO", "Hook libraries", libLine,
                  'Hook library "' + base + '" listed (standard Kea hook name)',
                  "Path: " + lib + ". This is a standard Kea hook library name. Contents NOT VERIFIED — this tool lists hooks by name and path only and never loads or inspects the binary.");
            } else {
              add("INFO", "Hook libraries", libLine,
                  'Hook library "' + base + '" — NOT VERIFIED',
                  "Path: " + lib + ". This is not a standard Kea hook name this tool recognizes, so it reads as an unknown / third-party hook. NOT VERIFIED: hook safety cannot be verified from a config file — a hook runs arbitrary code inside the daemon. Only load hooks from sources you trust.");
            }
          });
        });

        /* (4) + (6) Interfaces and DDNS, per node */
        walk(parsed, "", function(node, path){
          if (!isObj(node)) return;
          var ic = node["interfaces-config"];
          if (isObj(ic) && Array.isArray(ic.interfaces) && ic.interfaces.indexOf("*") >= 0){
            var hasSubnets = Array.isArray(node["subnet4"]) && node["subnet4"].length > 0 ||
                             Array.isArray(node["subnet6"]) && node["subnet6"].length > 0;
            add("WARNING", "Interfaces", lineOf(joinPath(joinPath(path, "interfaces-config"), "interfaces")),
                'interfaces-config listens on all interfaces ("*")',
                "The interfaces list contains \"*\", so the server will listen for DHCP traffic on every interface the host has — including any future or unexpected network it gets attached to." + (hasSubnets ? " Subnets are declared in this section, which limits which requests get answers, but the sockets still open everywhere." : " Paired with no subnet restriction in this section, nothing narrows that exposure.") + " Prefer naming the intended interfaces explicitly (for example \"eth0\") when the host has more than one network.");
          }
          if (node["ddns-send-updates"] === true){
            var suffix = node["ddns-qualifying-suffix"];
            if (suffix === undefined || suffix === null || String(suffix).trim() === ""){
              add("WARNING", "DDNS", lineOf(joinPath(path, "ddns-send-updates")),
                  "ddns-send-updates is true but ddns-qualifying-suffix is missing",
                  "With ddns-send-updates on and no ddns-qualifying-suffix, client hostnames that arrive without a domain get qualified with an empty suffix — updates to the DHCP-DDNS service can land in the wrong zone or fail silently. Set \"ddns-qualifying-suffix\" to your DNS zone suffix (for example \"example.org.\") or turn ddns-send-updates off.");
            }
          }
        });

        /* (7) Logging privacy */
        walk(parsed, "", function(node, path){
          if (!isObj(node) || !Array.isArray(node.loggers)) return;
          var loggersPath = joinPath(path, "loggers");
          node.loggers.forEach(function(logger, i){
            if (!isObj(logger)) return;
            var dl = logger.debuglevel;
            if (typeof dl !== "number" || dl < 50) return;
            var outputs = [];
            if (Array.isArray(logger["output-options"])){
              logger["output-options"].forEach(function(o){
                if (isObj(o) && typeof o.output === "string") outputs.push(o.output);
              });
            }
            var fileOutputs = outputs.filter(function(o){
              return o !== "stdout" && o !== "stderr" && o.indexOf("syslog") !== 0;
            });
            if (fileOutputs.length > 0){
              add("INFO", "Logging", lineOf(loggersPath + "[" + i + "].debuglevel"),
                  "High debug logging to a file — privacy note",
                  "Logger \"" + (logger.name || "unnamed") + "\" runs at debuglevel " + dl + " and writes to file (" + fileOutputs.join(", ") + "). At that verbosity Kea logs client details — MAC addresses, hostnames, requested options, lease assignments — to disk. That is operationally useful and a privacy exposure at the same time: treat the log file as client data, restrict its permissions, rotate it, and drop the debuglevel for production. Honestly labeled: this is a privacy note, not a malfunction.");
            }
          });
        });

        /* (5) Subnet / pool arithmetic */
        sections.forEach(function(section){
          var list = section.obj[section.subnetKey];
          if (!Array.isArray(list)) return;
          var listPath = joinPath(section.path, section.subnetKey);
          list.forEach(function(subnet, i){
            if (!isObj(subnet)) return;
            var subnetPath = listPath + "[" + i + "]";
            var subnetLine = lineOf(joinPath(subnetPath, "subnet"));
            var cidrText = typeof subnet.subnet === "string" ? subnet.subnet : null;
            var net = cidrText ? parseCidr(cidrText) : null;

            /* reservations first (v4: ip-address, v6: ip-addresses) */
            var reservations = [];
            if (Array.isArray(subnet.reservations)){
              subnet.reservations.forEach(function(r){
                if (!isObj(r)) return;
                if (typeof r["ip-address"] === "string") reservations.push(r["ip-address"]);
                if (Array.isArray(r["ip-addresses"])) r["ip-addresses"].forEach(function(a){ if (typeof a === "string") reservations.push(a); });
                if (typeof r["ip-addresses"] === "string") reservations.push(r["ip-addresses"]);
              });
            }

            var detailLines = [];
            if (net){
              detailLines.push("Network: " + cidrText + " = " + net.size.toString() + " addresses, " +
                bigToIp(net.network, net.bits) + " through " + bigToIp(net.broadcast, net.bits) + ".");
            } else if (cidrText){
              detailLines.push("Subnet value \"" + cidrText + "\" could not be parsed as CIDR, so pool arithmetic against it was skipped rather than guessed.");
            } else {
              detailLines.push("This subnet entry carries no \"subnet\" CIDR value, so no arithmetic could be run for it.");
            }

            var pools = Array.isArray(subnet.pools) ? subnet.pools : [];
            if (pools.length === 0){
              detailLines.push("Pools: none declared — this subnet hands out no dynamic pool addresses (reservations / static assignments only).");
            }
            pools.forEach(function(poolEntry, pi){
              if (!isObj(poolEntry) || typeof poolEntry.pool !== "string") return;
              var poolPath = subnetPath + ".pools[" + pi + "].pool";
              var poolLine = lineOf(poolPath);
              var range = poolEntry.pool.split("-");
              var startIp = null, endIp = null;
              if (range.length === 2){
                startIp = ipToBig(range[0]); endIp = ipToBig(range[1]);
              } else if (poolEntry.pool.indexOf("/") >= 0){
                var pc = parseCidr(poolEntry.pool);
                if (pc){ startIp = { value: pc.network, bits: pc.bits }; endIp = { value: pc.broadcast, bits: pc.bits }; }
              }
              if (!startIp || !endIp){
                detailLines.push("Pool \"" + poolEntry.pool + "\" could not be parsed, so its size was not computed.");
                return;
              }
              var size = endIp.value - startIp.value + 1n;
              var arith = "Pool " + poolEntry.pool.trim() + ": size = end − start + 1 = " +
                           range[0].trim() + " … " + range[range.length - 1].trim() + " → " + endIp.value.toString() + " − " + startIp.value.toString() + " + 1 = " + size.toString() + " addresses.";
              if (range.length === 2){
                arith = "Pool " + range[0].trim() + " - " + range[1].trim() + ": size = " + range[1].trim() + " − " + range[0].trim() + " + 1 = " + size.toString() + " addresses.";
              }
              detailLines.push(arith);

              if (net && startIp.bits === net.bits){
                if (startIp.value < net.network || endIp.value > net.broadcast){
                  add("WARNING", "Subnet / pool arithmetic", poolLine,
                      "Pool reaches outside its subnet " + cidrText,
                      arith + " The subnet " + cidrText + " runs " + bigToIp(net.network, net.bits) + " through " + bigToIp(net.broadcast, net.bits) + ", but this pool starts at " + range[0].trim() + " and ends at " + range[range.length - 1].trim() + ". Addresses outside the subnet will not be served the way the config suggests — shrink the pool to fit inside the subnet.");
                }
                reservations.forEach(function(rAddr){
                  var rIp = ipToBig(rAddr);
                  if (rIp && rIp.bits === startIp.bits && rIp.value >= startIp.value && rIp.value <= endIp.value){
                    add("WARNING", "Subnet / pool arithmetic", poolLine,
                        "Reservation " + rAddr + " falls inside the dynamic pool",
                        arith + " A reservation pins " + rAddr + " to a specific client, but that address also sits inside this dynamic pool, so the server can hand it to a different client first and the reservation then conflicts. Carve reserved addresses out of the pool range.");
                  }
                });
              }
            });

            add("INFO", "Subnet / pool arithmetic", subnetLine,
                "Subnet " + (cidrText || "(no CIDR)") + " — network and pool arithmetic",
                detailLines.join("\n"));

            if (!("valid-lifetime" in subnet) && !("valid-lifetime" in section.obj)){
              add("INFO", "Subnet / pool arithmetic", subnetLine,
                  "valid-lifetime not set for subnet " + (cidrText || "(no CIDR)"),
                  "Neither this subnet nor the " + section.name + " section sets \"valid-lifetime\", so lease length falls back to Kea's built-in default. That is legal and common — this note exists so the choice is deliberate, not accidental. Set valid-lifetime on the subnet (or globally) to state the lease time you intend.");
            }
          });
        });

        return { status: "parsed", parsed: parsed, findings: findings };
      }

      function verdictFor(result){
        if (result.status === "notparsed") return { key: "notparsed", label: "NOT PARSED", cls: "notparsed" };
        var b = 0, w = 0;
        result.findings.forEach(function(f){
          if (f.severity === "BLOCKER") b++;
          if (f.severity === "WARNING") w++;
        });
        if (b > 0) return { key: "donotdeploy", label: "DO NOT DEPLOY", cls: "danger" };
        if (w > 0) return { key: "withfixes", label: "DEPLOY WITH FIXES", cls: "fixes" };
        return { key: "safe", label: "SAFE TO DEPLOY", cls: "safe" };
      }
      function countsFor(result){
        var c = { BLOCKER: 0, WARNING: 0, INFO: 0 };
        result.findings.forEach(function(f){ c[f.severity]++; });
        return c;
      }

      var lastResult = null;

      function buildReport(result){
        var v = verdictFor(result), c = countsFor(result);
        var lines = [];
        lines.push("J-Dawgs Kea DHCP Server Config Safety Auditor — Audit Report");
        lines.push("Verdict: " + v.label);
        lines.push("Counts: " + c.BLOCKER + " BLOCKER · " + c.WARNING + " WARNING · " + c.INFO + " INFO");
        lines.push("Input: pasted Kea config, analyzed locally in the browser. Nothing was uploaded or saved.");
        lines.push("Credential rule: password values are never printed in this report — credentials are flagged by key name and line only.");
        lines.push("");
        lines.push("Findings:");
        if (result.findings.length === 0){
          lines.push("(none)");
        }
        result.findings.forEach(function(f, idx){
          lines.push((idx + 1) + ". [" + f.severity + (f.escalated ? " — ESCALATED" : "") + "] " + f.check + (f.line ? " — line " + f.line : "") + ": " + f.title);
          lines.push("   " + f.detail.replace(/\n/g, "\n   "));
        });
        lines.push("");
        lines.push("NOT VERIFIED by this tool:");
        NOT_VERIFIED_ITEMS.forEach(function(item){ lines.push("- " + item); });
        return lines.join("\n");
      }

      function buildJson(result){
        var v = verdictFor(result), c = countsFor(result);
        var obj = {
          tool: "J-Dawgs Kea DHCP Server Config Safety Auditor™",
          verdict: v.label,
          counts: { blocker: c.BLOCKER, warning: c.WARNING, info: c.INFO },
          findings: result.findings.map(function(f){
            return { severity: f.severity, escalated: f.escalated, check: f.check, line: f.line, title: f.title, detail: f.detail };
          }),
          not_verified: NOT_VERIFIED_ITEMS.slice()
        };
        return JSON.stringify(obj, null, 2);
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-kea-dhcp-server-config-safety-auditortm',
  name: 'J-Dawgs Kea DHCP Server Config Safety Auditor',
  description: 'Grades a pasted Kea DHCP config (Dhcp4/Dhcp6/CtrlAgent JSON) offline — control-agent exposure, database passwords flagged by key name and line only, hook listing, subnet/pool arithmetic shown, and duplicate keys, with a NOT VERIFIED section — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
