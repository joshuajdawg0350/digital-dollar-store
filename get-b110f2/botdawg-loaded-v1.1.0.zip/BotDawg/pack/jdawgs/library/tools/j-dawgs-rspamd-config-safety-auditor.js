'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Rspamd Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

    "use strict";

    /* ================================================================
       J-Dawgs Rspamd Config Safety Auditor
       Heuristic TEXT audit. It does not parse UCL fully and never
       renders secret values: findings carry key name + line + length
       band only. Everything runs locally; nothing is stored or sent.
       ================================================================ */

    /* ---------- Worked examples (fake values only) ---------- */
    var RISKY_EXAMPLE = [
      '# Risky example — fake values only, never use in production',
      'options {',
      '    dns {',
      '        timeout = 1s;',
      '    }',
      '}',
      'worker "normal" {',
      '    bind_socket = "127.0.0.1:11333";',
      '    count = 2;',
      '}',
      'worker "controller" {',
      '    bind_socket = "*:11334";',
      '    password = "abc123";',
      '    enable_password = "abc123";',
      '    count = 1;',
      '}',
      'worker "fuzzy" {',
      '    bind_socket = "0.0.0.0:11335";',
      '    count = 1;',
      '}',
      'redis {',
      '    servers = "127.0.0.1:6379";',
      '    password = "PlantedSecretValue!234";',
      '}'
    ].join('\n');
    /* Controller findings in the risky example, by construction:
       line 12 bind exposure, line 13 short plaintext password,
       line 14 short enable_password, line 18 fuzzy exposure,
       line 23 planted long secret (length band only, value never shown). */

    var HARDENED_EXAMPLE = [
      '# Hardened example — fake values only',
      'worker "normal" {',
      '    bind_socket = "127.0.0.1:11333";',
      '    count = 2;',
      '}',
      'worker "controller" {',
      '    bind_socket = "127.0.0.1:11334";',
      '    password = "$2$fakehashfakehashfakehash$fakehashfakehashfakehashfakehashfakehash00";',
      '    enable_password = "$2$fakehashfakehashfakehash$fakehashfakehashfakehashfakehashfakehash11";',
      '    secure_ip = "127.0.0.1";',
      '    secure_ip = "::1";',
      '    count = 1;',
      '}',
      'worker "proxy" {',
      '    bind_socket = "127.0.0.1:11332";',
      '    count = 1;',
      '}',
      'worker "fuzzy" {',
      '    bind_socket = "127.0.0.1:11335";',
      '    count = 1;',
      '}',
      'redis {',
      '    servers = "127.0.0.1:6379";',
      '    password = "correct-horse-battery-staple-42";',
      '}',
      'dkim_signing {',
      '    check_pubkey = true;',
      '}'
    ].join('\n');

    /* ---------- small text helpers ---------- */
    function stripComment(s){
      var inQ = null;
      for (var i = 0; i < s.length; i++){
        var c = s[i];
        if (inQ){
          if (c === '\\'){ i++; continue; }
          if (c === inQ) inQ = null;
          continue;
        }
        if (c === '"' || c === "'"){ inQ = c; continue; }
        if (c === '#') return s.slice(0, i);
        if (c === '/' && s[i + 1] === '/') return s.slice(0, i);
      }
      return s;
    }
    function bracketDelta(s){
      var d = 0, inQ = null;
      for (var i = 0; i < s.length; i++){
        var c = s[i];
        if (inQ){
          if (c === '\\'){ i++; continue; }
          if (c === inQ) inQ = null;
          continue;
        }
        if (c === '"' || c === "'"){ inQ = c; continue; }
        if (c === '[') d++;
        if (c === ']') d--;
      }
      return d;
    }
    function unquote(v){
      v = v.trim();
      if (v.length >= 2 &&
          ((v.charAt(0) === '"' && v.charAt(v.length - 1) === '"') ||
           (v.charAt(0) === "'" && v.charAt(v.length - 1) === "'"))){
        return v.slice(1, -1);
      }
      return v;
    }
    function cleanValue(raw){
      var s = stripComment(raw).trim();
      var inQ = null, out = '';
      for (var i = 0; i < s.length; i++){
        var c = s[i];
        if (inQ){
          out += c;
          if (c === '\\' && i + 1 < s.length){ out += s[i + 1]; i++; continue; }
          if (c === inQ) inQ = null;
          continue;
        }
        if (c === '"' || c === "'"){ inQ = c; out += c; continue; }
        if (c === ';') break;
        out += c;
      }
      return out.trim();
    }
    function quotedStrings(s){
      var m = [], re = /"([^"]*)"|'([^']*)'/g, x;
      while ((x = re.exec(s)) !== null){ m.push(x[1] !== undefined ? x[1] : x[2]); }
      return m;
    }
    function extractSockets(value){
      var qs = quotedStrings(value);
      if (qs.length) return qs;
      return value.replace(/[\[\]]/g, '').split(',')
        .map(function(x){ return unquote(x.trim()); })
        .filter(function(x){ return x.length > 0; });
    }
    function classifySocket(sock){
      var s = sock.trim();
      if (!s) return 'unknown';
      if (s.charAt(0) === '/' || s.indexOf('unix:') === 0 || /\.sock\b/.test(s)) return 'unix';
      var host;
      if (s.charAt(0) === '['){
        var end = s.indexOf(']');
        host = end === -1 ? s : s.slice(1, end);
      } else {
        var idx = s.lastIndexOf(':');
        if (idx === -1){ host = /^\d+$/.test(s) ? '' : s; }
        else { host = s.slice(0, idx); }
      }
      host = host.trim().toLowerCase();
      if (host === '' || host === '*' || host === '0.0.0.0' || host === '::') return 'all';
      if (host === 'localhost' || host === '::1' || /^127\./.test(host)) return 'loopback';
      return 'specific';
    }
    function exposureRank(level){
      return { all: 3, specific: 2, loopback: 1, unix: 0, unknown: 0, none: -1 }[level];
    }

    /* ---------- secret grading: length band only, value never kept ---------- */
    var PLACEHOLDERS = ['changeme','change-me','change_me','password','passw0rd','secret',
      'letmein','admin','test','example','default','rspamd','123456','12345678',
      'qwerty','yourpassword','your-password','todo','xxx','none','null'];
    function isPlaceholder(v){
      var s = v.trim().toLowerCase();
      if (!s) return false;
      if (PLACEHOLDERS.indexOf(s) !== -1) return true;
      return /(change|placeholder|example|todo|insert[-_ ]|your[-_ ])/.test(s);
    }
    function gradeSecret(rawValue){
      var v = unquote((rawValue || '').trim());
      if (v === '') return { kind: 'empty', len: 0 };
      if (/^\$\d+\$/.test(v)) return { kind: 'encrypted', len: v.length };
      if (/^\$\{[^}]*\}$/.test(v) || /^\$[A-Za-z_][A-Za-z0-9_]*$/.test(v)) return { kind: 'varref', len: v.length };
      if (isPlaceholder(v)) return { kind: 'placeholder', len: v.length };
      if (v.length < 8) return { kind: 'short', len: v.length };
      if (v.length <= 15) return { kind: 'mid', len: v.length };
      return { kind: 'long', len: v.length };
    }
    function bandText(g){
      if (g.kind === 'short' || g.kind === 'empty') return 'under 8 characters';
      if (g.kind === 'mid') return '8–15 characters (marginal)';
      if (g.kind === 'long') return '16+ characters (strong band)';
      return g.kind;
    }

    /* ---------- heuristic parser ---------- */
    function parseConfig(text){
      var rawLines = text.split(/\r?\n/);
      var logical = [];
      var i = 0;
      while (i < rawLines.length){
        var startLine = i + 1;
        var buf = rawLines[i];
        i++;
        var hd = buf.match(/<<\s*"?([A-Za-z_][A-Za-z0-9_]*)"?/);
        if (hd){
          var tag = hd[1];
          while (i < rawLines.length && rawLines[i].trim() !== tag) i++;
          if (i < rawLines.length) i++;
          logical.push({ line: startLine, text: buf });
          continue;
        }
        var guard = 0;
        while (bracketDelta(buf) > 0 && i < rawLines.length && guard < 50){
          buf += '\n' + rawLines[i];
          i++; guard++;
        }
        logical.push({ line: startLine, text: buf });
      }

      var root = { name: '(top level)', rawName: '', workerType: null, isWorker: false, startLine: 0, endLine: null, parent: null };
      var stack = [root];
      var blocks = [root];
      var statements = [];
      var notParsed = [];

      logical.forEach(function(L){
        var t = L.text.trim();
        if (t === '' || t.charAt(0) === '#') return;
        var s = stripComment(L.text).trim();
        if (s === '' || s.indexOf('//') === 0) return;
        var top = stack[stack.length - 1];

        if (/^\.(try_)?include(_glob)?\b/.test(s)){
          statements.push({ line: L.line, key: '.include', rawKey: '.include', value: '', block: top, isInclude: true });
          return;
        }
        if (/^\}\s*;?$/.test(s)){
          if (stack.length > 1){ stack.pop().endLine = L.line; }
          return;
        }
        if (/\{\s*$/.test(s)){
          var head = s.slice(0, s.lastIndexOf('{')).trim();
          var name = head, isWorker = false, wtype = null;
          var eq = head.indexOf('=');
          if (eq !== -1) name = head.slice(0, eq).trim();
          var wm = head.match(/^worker\s+(?:"([^"]+)"|'([^']+)'|([A-Za-z0-9_.-]+))/i);
          if (wm){ isWorker = true; wtype = (wm[1] || wm[2] || wm[3] || '').toLowerCase(); name = 'worker'; }
          else if (/^worker$/i.test(head)){ isWorker = true; name = 'worker'; }
          var blk = { name: unquote(name), rawName: name, workerType: wtype, isWorker: isWorker, startLine: L.line, endLine: null, parent: top };
          blocks.push(blk);
          stack.push(blk);
          return;
        }
        var kv = s.match(/^([A-Za-z0-9_.\/-]+)\s*[:=]\s*([\s\S]*)$/);
        if (kv){
          var st = { line: L.line, key: kv[1].toLowerCase(), rawKey: kv[1], value: cleanValue(kv[2]), block: top };
          statements.push(st);
          if (st.key === 'type' && top.isWorker && !top.workerType){
            top.workerType = unquote(st.value).toLowerCase();
          }
          return;
        }
        var bare = s.match(/^([A-Za-z0-9_.\/-]+)\s+("[^"]*"|'[^']*'|[^\s;]+)\s*;?$/);
        if (bare){
          statements.push({ line: L.line, key: bare[1].toLowerCase(), rawKey: bare[1], value: cleanValue(bare[2]), block: top });
          return;
        }
        notParsed.push(L.line);
      });

      return { statements: statements, blocks: blocks, notParsed: notParsed, lineCount: rawLines.length };
    }

    function blockLabel(b){
      if (!b || b.name === '(top level)') return 'top level';
      if (b.isWorker) return 'worker "' + (b.workerType || 'unnamed') + '"';
      return '"' + b.name + '" section';
    }
    function statementsIn(parsed, block, key){
      return parsed.statements.filter(function(st){ return st.block === block && st.key === key; });
    }
    function workerExposure(parsed, block){
      var sts = statementsIn(parsed, block, 'bind_socket');
      var best = 'none', line = null;
      sts.forEach(function(st){
        extractSockets(st.value).forEach(function(sock){
          var c = classifySocket(sock);
          if (exposureRank(c) > exposureRank(best)){ best = c; line = st.line; }
        });
      });
      if (best === 'none' && sts.length) { best = 'unknown'; line = sts[0].line; }
      return { level: best, line: line, count: sts.length };
    }

    /* ---------- the audit ---------- */
    var SECRET_KEY_RE = /password|passwd|pwd|secret|token|api[-_]?key|private[-_]?key|auth[-_]?key/i;
    var UNAUTH_KEY_RE = /unauthenticated|allow[-_]?unauth|skip[-_]?auth|disable[-_]?auth|no[-_]?auth/i;

    function auditConfig(text){
      var findings = [];
      function F(sev, line, title, detail, fix, kind){
        findings.push({ severity: sev, line: (typeof line === 'number' ? line : null),
          title: title, detail: detail, fix: fix || null, kind: kind || 'finding' });
      }

      if (!text || text.trim() === ''){
        F('INFO', null, 'No configuration text was provided',
          'The input was empty, so there is nothing to grade. This auditor will not invent a verdict for an empty config.',
          'Paste a Rspamd config (or load a worked example) and run the audit again.');
        return finish('NOT ENOUGH TO GRADE', findings, 0);
      }

      var parsed = parseConfig(text);
      var workers = parsed.blocks.filter(function(b){ return b.isWorker; });
      var controllers = workers.filter(function(b){ return b.workerType === 'controller'; });
      var ctrl = controllers.length ? controllers[0] : null;

      /* ----- controller worker ----- */
      var ctrlExposure = null, ctrlPwGrade = null, ctrlPwStmt = null;
      if (ctrl){
        ctrlExposure = workerExposure(parsed, ctrl);
        var pwStmts = statementsIn(parsed, ctrl, 'password');
        var epStmts = statementsIn(parsed, ctrl, 'enable_password');
        ctrlPwStmt = pwStmts.length ? pwStmts[0] : null;
        ctrlPwGrade = ctrlPwStmt ? gradeSecret(ctrlPwStmt.value) : { kind: 'missing', len: 0 };
        var pwBad = ['missing','empty','placeholder','short'].indexOf(ctrlPwGrade.kind) !== -1;
        var exposedNet = (ctrlExposure.level === 'all' || ctrlExposure.level === 'specific');
        var expLine = ctrlExposure.line || ctrl.startLine;

        /* exposure paired with authentication */
        if (ctrlExposure.level === 'all'){
          if (pwBad){
            F('BLOCKER', expLine,
              'Controller worker is exposed on all interfaces with a weak or missing password',
              'The controller bind_socket listens on every network interface, so its HTTP web UI and control API are reachable from any network this host touches. Paired with ' +
                (ctrlPwGrade.kind === 'missing' ? 'no password set at all' :
                 ctrlPwGrade.kind === 'empty' ? 'an empty password' :
                 ctrlPwGrade.kind === 'placeholder' ? 'a placeholder password' : 'a password under 8 characters') +
                ', that is an open control panel. rspamadm configtest would still pass this config — it only checks that the file loads.',
              'Bind the controller to 127.0.0.1, set a long password stored encrypted (generate it with rspamadm pw), and add a secure_ip allow-list for the hosts that genuinely need access.');
          } else {
            F('WARNING', expLine,
              'Controller worker is exposed on all interfaces',
              'The controller bind_socket listens on every network interface, so its HTTP web UI and control API are reachable from any network this host touches. The password on file is not in the weak band, but the controller is the most sensitive surface Rspamd has — exposure this wide is rarely intended.',
              'Bind the controller to 127.0.0.1 (or a management address), and add a secure_ip allow-list.');
          }
        } else if (ctrlExposure.level === 'specific'){
          if (pwBad){
            F('BLOCKER', expLine,
              'Controller worker is bound to a non-loopback address with a weak or missing password',
              'The controller answers on a specific network address, and its authentication is ' +
                (ctrlPwGrade.kind === 'missing' ? 'missing entirely' : 'in the weak band') +
                '. Any host that can route to that address can attempt to control rspamd.',
              'Set a long, encrypted controller password (rspamadm pw), add secure_ip, or move the bind to loopback.');
          } else {
            F('INFO', expLine,
              'Controller worker is bound to a specific non-loopback address',
              'The controller is not on loopback, but it is bound to one address rather than all interfaces, and its password is not in the weak band. Confirm that address is on a trusted or firewalled interface.',
              'If that interface is not trusted, bind to 127.0.0.1 and add secure_ip.');
          }
        } else if (ctrlExposure.level === 'loopback'){
          F('INFO', expLine, 'Controller worker is bound to loopback only',
            'The controller bind_socket points at 127.0.0.1 / ::1 / localhost, so it is not reachable from the network. That is the safe default posture for the controller.',
            null);
        } else if (ctrlExposure.level === 'unix'){
          F('INFO', expLine, 'Controller worker is on a Unix socket only',
            'The controller bind_socket is a filesystem socket, not a network port, so it is not exposed to the network.',
            null);
        } else {
          F('INFO', ctrl.startLine, 'Controller worker has no bind_socket line in this text',
            'No bind_socket was found inside the controller block, so the compiled-in rspamd default applies. This audit grades only what the pasted text says, and the default is not in the text.',
            'If the bind is set in another file (local.d / override.d), audit that file too.');
        }

        /* password storage + length (value never shown) */
        if (ctrlPwStmt){
          var g = ctrlPwGrade, pl = ctrlPwStmt.line;
          if (g.kind === 'encrypted'){
            F('INFO', pl, 'Controller "password" appears to be stored encrypted',
              'The value for key "password" carries the rspamadm-style $…$ encrypted marker, so it is not sitting in the file as readable plaintext. Length grading does not apply to a hash.',
              null);
          } else if (g.kind === 'varref'){
            F('INFO', pl, 'Controller "password" is a variable reference, not a literal',
              'The value for key "password" is a variable/include reference rather than a literal secret, so its strength cannot be graded from this text.',
              'Make sure the referenced value is itself long and kept out of the config files you share.');
          } else if (g.kind === 'placeholder'){
            F('BLOCKER', pl, 'Controller "password" is a placeholder value',
              'The value for key "password" matches a well-known placeholder pattern. A placeholder is public knowledge — it is the same as having no password wherever this controller can be reached.',
              'Replace it with a long, unique password stored encrypted (rspamadm pw).');
          } else if (g.kind === 'short' || g.kind === 'empty'){
            F('BLOCKER', pl, 'Controller "password" is too short (under 8 characters)',
              'Graded by length only — the value itself is never shown in this report. A controller password under 8 characters falls to password guessing almost immediately wherever the controller port is reachable.',
              'Use a password of 16+ characters and store it encrypted (rspamadm pw).');
          } else if (g.kind === 'mid'){
            F('WARNING', pl, 'Controller "password" length is marginal (8–15 characters)',
              'Graded by length only — the value itself is never shown in this report. 8–15 characters is guessable on a determined attempt against an exposed controller.',
              'Move to 16+ characters and store it encrypted (rspamadm pw).');
          } else {
            F('INFO', pl, 'Controller "password" length is in the strong band (16+ characters)',
              'Graded by length only — the value itself is never shown in this report.',
              null);
          }
          if (g.kind !== 'encrypted' && g.kind !== 'varref'){
            F('WARNING', pl, 'Controller "password" is stored in plaintext',
              'The value for key "password" has no encrypted marker, so anyone who can read this config file — backups, repos, pasted snippets — can read the controller password.',
              'Store it encrypted: run rspamadm pw and paste the $…$ output as the value.');
          }
        } else {
          if (ctrlExposure.level === 'loopback' || ctrlExposure.level === 'unix'){
            F('WARNING', ctrl.startLine, 'No "password" is set in the controller block',
              'With no password set, controller access leans entirely on the bind staying on loopback and on secure_ip. That is tolerable only while the bind never changes.',
              'Set a long, encrypted controller password (rspamadm pw) so a later bind change does not silently open the controller.');
          }
          /* if network-exposed with no password, the exposure BLOCKER above already names it */
        }

        /* enable_password vs password distinction */
        if (epStmts.length){
          var ep = epStmts[0], eg = gradeSecret(ep.value);
          if (!ctrlPwStmt){
            F('WARNING', ep.line, '"enable_password" is set, but "password" is not',
              'These are different keys: "enable_password" guards only the privileged actions (learning, enabling/disabling), while "password" is the controller\'s main login. With "password" unset, ordinary controller access is unauthenticated no matter how strong "enable_password" is.',
              'Set "password" as well — a long value, stored encrypted (rspamadm pw).');
          }
          if (eg.kind === 'placeholder' || eg.kind === 'short' || eg.kind === 'empty'){
            F(exposedNet ? 'BLOCKER' : 'WARNING', ep.line,
              'Controller "enable_password" is ' + (eg.kind === 'placeholder' ? 'a placeholder value' : 'too short (under 8 characters)'),
              'Graded by length only — the value itself is never shown in this report. "enable_password" protects the privileged controller actions, so a weak one hands those actions to anyone who reaches the port' + (exposedNet ? ' — and this controller is network-exposed.' : '.'),
              'Use a distinct "enable_password" of 16+ characters, stored encrypted (rspamadm pw).');
          } else if (eg.kind === 'mid'){
            F('WARNING', ep.line, 'Controller "enable_password" length is marginal (8–15 characters)',
              'Graded by length only — the value itself is never shown in this report.',
              'Move "enable_password" to 16+ characters, stored encrypted (rspamadm pw).');
          } else if (eg.kind === 'encrypted'){
            F('INFO', ep.line, 'Controller "enable_password" appears to be stored encrypted',
              'The value carries the rspamadm-style $…$ encrypted marker. Good — it is also distinct from "password", which is the right separation.',
              null);
          } else if (eg.kind === 'long'){
            F('INFO', ep.line, 'Controller "enable_password" is set and distinct from "password"',
              'Length is in the strong band (16+ characters), graded by length only. Keeping "enable_password" different from "password" limits what a leaked read-level password can do.',
              null);
          } else if (eg.kind === 'varref'){
            F('INFO', ep.line, 'Controller "enable_password" is a variable reference, not a literal',
              'Its strength cannot be graded from this text.',
              null);
          }
        } else if (ctrlPwStmt){
          F('INFO', ctrl.startLine, '"enable_password" is not set separately from "password"',
            'In rspamd, when "enable_password" is absent it falls back to "password" for the privileged actions (learning, enabling/disabling) — so one secret currently guards both ordinary and privileged controller access.',
            'Set a distinct "enable_password" if you want privileged actions behind a different secret.');
        }

        /* secure_ip / source restrictions on the controller */
        var siStmts = statementsIn(parsed, ctrl, 'secure_ip');
        var siPresent = siStmts.some(function(st){
          var v = unquote(st.value).trim();
          return v !== '' && v !== '[]';
        });
        if (siPresent){
          F('INFO', siStmts[0].line, 'Controller has a "secure_ip" allow-list',
            'secure_ip restricts which source addresses may use the controller even before the password is tried. Having one set is the right companion to any bind you keep.',
            null);
        } else if (siStmts.length){
          F(exposedNet ? 'WARNING' : 'INFO', siStmts[0].line,
            'Controller "secure_ip" is set but empty',
            'An empty secure_ip list restricts nothing — it reads as configured while allowing every source address.' + (exposedNet ? ' Escalated by exposure: this controller is reachable beyond this host, so the password is the only barrier.' : ''),
            'List the management hosts allowed to reach the controller, or remove the empty setting so nobody mistakes it for protection.');
        } else if (exposedNet){
          F('WARNING', expLine, 'No "secure_ip" restriction on a network-exposed controller',
            'secure_ip is the controller\'s source-address allow-list. Without it, every host that can reach the bind gets unlimited password attempts. Escalated by exposure: this bind reaches beyond the local host, so the missing allow-list matters more than it would on loopback.',
            'Add secure_ip entries for the hosts allowed to administer rspamd.');
        } else {
          F('INFO', ctrl.startLine, 'No "secure_ip" set on the controller',
            'Acceptable while the controller stays bound to loopback or a Unix socket — but add an allow-list before any bind change exposes it.',
            null);
        }
      } else if (workers.length){
        F('INFO', null, 'No controller worker block in this text',
          'Controller exposure and authentication cannot be graded here. Rspamd setups often split workers across rspamd.conf, local.d, and override.d files.',
          'Audit the file that defines worker "controller" as well.');
      }

      /* ----- other workers: bind exposure per worker ----- */
      var WORKER_NOTES = {
        normal: {
          label: 'Normal worker (HTTP scan API)',
          all: 'The normal worker\'s HTTP endpoints accept messages for scanning and answer stats/API queries. Bound to all interfaces, any host can submit mail content to it and probe it — it is an API surface, not just a port.',
          fix: 'Bind the normal worker to 127.0.0.1 or the specific address your MTA uses, and firewall the port.'
        },
        proxy: {
          label: 'Proxy worker (milter)',
          all: 'The proxy worker speaks milter to MTAs. Bound to all interfaces, any host can connect as if it were your MTA and feed it traffic.',
          fix: 'Bind the proxy worker to 127.0.0.1 or the exact MTA address, and firewall the port.'
        },
        fuzzy: {
          label: 'Fuzzy worker (fuzzy storage)',
          all: 'The fuzzy worker serves the fuzzy-hash storage. Bound to all interfaces, any host can query the storage — and wherever updates are accepted, poison the shared fuzzy database your filters trust.',
          fix: 'Bind the fuzzy worker to 127.0.0.1 or your internal network only, and keep fuzzy updates limited to trusted hosts.'
        }
      };
      workers.forEach(function(w){
        if (ctrl && w === ctrl) return;
        var type = w.workerType || '';
        var note = WORKER_NOTES[type];
        var label = note ? note.label : ('Worker "' + (type || 'unnamed') + '"');
        var exp = workerExposure(parsed, w);
        var wl = exp.line || w.startLine;
        if (exp.level === 'all'){
          F('WARNING', wl, label + ' is bound to all interfaces',
            note ? note.all : 'This worker listens on every network interface. Confirm it is meant to be reachable from other hosts.',
            note ? note.fix : 'Bind it to loopback or a specific trusted address, and firewall the port.');
        } else if (exp.level === 'specific'){
          F('INFO', wl, label + ' is bound to a specific non-loopback address',
            'Not loopback, but bound to one address rather than all interfaces. Confirm that interface is the intended one (typically the MTA or an internal network).',
            null);
        } else if (exp.level === 'loopback'){
          F('INFO', wl, label + ' is bound to loopback only',
            'Not reachable from the network — the usual safe posture for this worker.',
            null);
        } else if (exp.level === 'unix'){
          F('INFO', wl, label + ' is on a Unix socket only',
            'A filesystem socket, not a network port — not exposed to the network.',
            null);
        } else {
          F('INFO', w.startLine, label + ' has no bind_socket line in this text',
            'The compiled-in rspamd default applies. This audit grades only what the pasted text says.',
            'If the bind is set in another file, audit that file too.');
        }
      });

      /* ----- generic secret scan: key name + line only, value NEVER used ----- */
      parsed.statements.forEach(function(st){
        if (st.isInclude) return;
        if (!SECRET_KEY_RE.test(st.rawKey)) return;
        if (ctrl && st.block === ctrl && (st.key === 'password' || st.key === 'enable_password')) return;
        var where = blockLabel(st.block);
        var g = gradeSecret(st.value);
        var keyName = '"' + st.rawKey + '"';
        if (g.kind === 'encrypted'){
          F('INFO', st.line, 'Secret key ' + keyName + ' (' + where + ') appears stored encrypted',
            'The value carries an encrypted $…$ marker, so no plaintext secret is sitting in this file. Length grading does not apply to a hash. The value is never shown in this report.',
            null);
        } else if (g.kind === 'varref'){
          F('INFO', st.line, 'Secret key ' + keyName + ' (' + where + ') is a variable reference',
            'The value is a reference, not a literal secret, so there is nothing to grade — and nothing to leak — in this text.',
            null);
        } else if (g.kind === 'placeholder'){
          F('BLOCKER', st.line, 'Secret key ' + keyName + ' (' + where + ') is a placeholder value',
            'The value matches a well-known placeholder pattern. Placeholders are public knowledge — treat this secret as nonexistent until it is replaced. The value is never shown in this report.',
            'Replace it with a long, unique secret and keep the real value out of shared copies of this file.');
        } else if (g.kind === 'short' || g.kind === 'empty'){
          F('BLOCKER', st.line, 'Secret key ' + keyName + ' (' + where + ') is under 8 characters',
            'Graded by length only (' + bandText(g) + ') — the value is never shown in this report. Backend and service passwords this short fall to guessing and credential-stuffing.',
            'Rotate it to 16+ characters.');
        } else if (g.kind === 'mid'){
          F('WARNING', st.line, 'Secret key ' + keyName + ' (' + where + ') has marginal length (8–15 characters)',
            'Graded by length only — the value is never shown in this report.',
            'Rotate it to 16+ characters when convenient.');
        } else {
          F('INFO', st.line, 'Secret key ' + keyName + ' (' + where + ') has strong-band length (16+ characters)',
            'Graded by length only — the value is never shown in this report. Length is the only thing this audit can see; it cannot tell a strong passphrase from a long predictable one.',
            null);
        }
      });

      /* ----- unauthenticated-access flags ----- */
      parsed.statements.forEach(function(st){
        if (!UNAUTH_KEY_RE.test(st.rawKey)) return;
        var v = unquote(st.value).trim().toLowerCase();
        if (!/^(true|yes|on|1)$/.test(v)) return;
        var sev = 'WARNING';
        if (st.block && st.block.isWorker){
          var be = workerExposure(parsed, st.block);
          if (be.level === 'all' || be.level === 'specific') sev = 'BLOCKER';
        }
        F(sev, st.line, 'Unauthenticated access is switched on ("' + st.rawKey + '")',
          'This flag turns off authentication for whatever it governs in ' + blockLabel(st.block) + '. On a network-reachable service that means no credential stands between a stranger and the function it protects.',
          'Turn it off, or fence the service to loopback/trusted hosts with bind_socket and secure_ip so the flag can never be reached from outside.');
      });

      /* ----- empty secure_ip outside the controller ----- */
      parsed.statements.forEach(function(st){
        if (st.key !== 'secure_ip') return;
        if (ctrl && st.block === ctrl) return;
        var v = unquote(st.value).trim();
        if (v === '' || v === '[]'){
          F('WARNING', st.line, '"secure_ip" is set but empty in ' + blockLabel(st.block),
            'An empty secure_ip list restricts nothing — it reads as configured while allowing every source address.',
            'List the allowed source addresses, or remove the empty setting.');
        }
      });

      /* ----- DKIM signing presence (section only; keys/DNS not verified) ----- */
      var hasDkim = parsed.blocks.some(function(b){ return b.name === 'dkim_signing'; });
      if (hasDkim){
        var dk = parsed.blocks.filter(function(b){ return b.name === 'dkim_signing'; })[0];
        F('INFO', dk.startLine, 'A "dkim_signing" section is present',
          'DKIM signing is at least configured in this text. This audit sees the section only — it does not verify selectors, signing keys, or DNS records.',
          null);
      } else {
        F('INFO', null, 'No "dkim_signing" section in this text',
          'If this host is supposed to sign outgoing mail with DKIM, the signing setup lives in another file or is missing. This audit cannot verify DKIM keys or DNS either way — the absence is noted, not graded as a fault.',
          'If this host should sign, audit the file that holds dkim_signing and confirm the selector DNS record is published.');
      }

      /* ----- lines that could not be understood ----- */
      parsed.notParsed.forEach(function(ln){
        F('INFO', ln, 'Line ' + ln + ' was not understood (NOT PARSED)',
          'This heuristic text audit could not classify the line as a section, a key/value setting, a comment, or an include. Its content is withheld from this report. An unrecognized line can hide a setting this audit never graded.',
          'Check the line by hand against rspamd\'s UCL syntax — and if it sets anything security-relevant, do not rely on this audit for it.',
          'not_parsed');
      });

      /* ----- verdict ----- */
      if (!workers.length){
        F('INFO', null, 'No worker blocks were found in this text',
          'A deploy verdict needs the worker configuration (controller, normal, fuzzy, proxy). This text may be a module snippet from local.d/override.d that is fine on its own — but graded alone it cannot support a verdict, so none is given.',
          'Paste the rspamd.conf (or the merged config) that includes the worker blocks.');
        return finish('NOT ENOUGH TO GRADE', findings, parsed.notParsed.length);
      }
      var blockers = findings.filter(function(f){ return f.severity === 'BLOCKER'; }).length;
      var warnings = findings.filter(function(f){ return f.severity === 'WARNING'; }).length;
      var verdict = blockers > 0 ? 'DO NOT DEPLOY' : (warnings > 0 ? 'DEPLOY WITH FIXES' : 'SAFE TO DEPLOY');
      return finish(verdict, findings, parsed.notParsed.length);
    }

    function finish(verdict, findings, notParsedCount){
      var order = { BLOCKER: 0, WARNING: 1, INFO: 2 };
      findings.sort(function(a, b){
        var d = order[a.severity] - order[b.severity];
        if (d !== 0) return d;
        var la = a.line === null ? 1e9 : a.line, lb = b.line === null ? 1e9 : b.line;
        return la - lb;
      });
      var counts = {
        blocker: findings.filter(function(f){ return f.severity === 'BLOCKER'; }).length,
        warning: findings.filter(function(f){ return f.severity === 'WARNING'; }).length,
        info: findings.filter(function(f){ return f.severity === 'INFO' && f.kind !== 'not_parsed'; }).length,
        notParsed: notParsedCount
      };
      return { verdict: verdict, counts: counts, findings: findings };
    }

    /* ---------- report + JSON rendering (built from findings only) ---------- */
    function verdictWhy(v){
      switch (v){
        case 'SAFE TO DEPLOY': return 'No BLOCKERs and no WARNINGs in what this text audit can see. The honest limits below still apply — this is a heuristic grade of the pasted text, not a live-server check.';
        case 'DEPLOY WITH FIXES': return 'Nothing here is an outright deployment blocker, but the WARNINGs below should be fixed first — each one ships with its fix.';
        case 'DO NOT DEPLOY': return 'At least one BLOCKER was found. Fix every BLOCKER below before this config goes on a host anyone else can reach.';
        default: return 'There is not enough gradeable configuration in the pasted text to support a verdict, so none is given.';
      }
    }
    function buildReport(r){
      var L = [];
      L.push('J-Dawgs Rspamd Config Safety Auditor™ — audit report');
      L.push('Verdict: ' + r.verdict);
      L.push('Counts: BLOCKER ' + r.counts.blocker + ' · WARNING ' + r.counts.warning + ' · INFO ' + r.counts.info + ' · NOT PARSED ' + r.counts.notParsed);
      L.push('Method: heuristic text audit (not a full UCL parser; does not replace rspamadm configtest). Secret values are never shown — findings give the key name, line, and length band only. Lines not understood are listed by number only, content withheld.');
      L.push('');
      r.findings.forEach(function(f, i){
        L.push((i + 1) + '. [' + f.severity + (f.kind === 'not_parsed' ? ' · NOT PARSED' : '') + '] ' +
          (f.line !== null ? 'Line ' + f.line + ' — ' : '') + f.title);
        L.push('   ' + f.detail);
        if (f.fix) L.push('   Fix: ' + f.fix);
      });
      if (!r.findings.length) L.push('No findings.');
      return L.join('\n');
    }
    function buildJson(r){
      var obj = {
        tool: 'J-Dawgs Rspamd Config Safety Auditor™',
        audit_type: 'heuristic text audit (not a UCL parser)',
        verdict: r.verdict,
        counts: { blocker: r.counts.blocker, warning: r.counts.warning, info: r.counts.info, not_parsed: r.counts.notParsed },
        findings: r.findings.map(function(f){
          return { severity: f.severity, kind: f.kind, line: f.line, title: f.title, detail: f.detail, fix: f.fix };
        }),
        notes: 'Secret values are never included; secrets are graded by length band only. NOT PARSED lines are listed by line number only, content withheld.'
      };
      return JSON.stringify(obj, null, 2);
    }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-rspamd-config-safety-auditor',
  name: 'J-Dawgs Rspamd Config Safety Auditor',
  description: 'Grades a pasted Rspamd config offline into one deploy verdict — controller exposure paired with auth, secrets by key name/line/length only, values never rendered.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
