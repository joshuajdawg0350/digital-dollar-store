'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs ScyllaDB Cluster Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";
      var RISKY = document.getElementById('cfgInput').value;
      var HARDENED = [
        "cluster_name: 'production-cluster'",
        "listen_address: 10.0.1.11",
        "rpc_address: 10.0.1.11",
        "broadcast_address: 10.0.1.11",
        "broadcast_rpc_address: 10.0.1.11",
        "seed_provider:",
        "  - class_name: org.apache.cassandra.locator.SimpleSeedProvider",
        "    parameters:",
        "      - seeds: \"10.0.1.11,10.0.1.12,10.0.1.13\"",
        "authenticator: PasswordAuthenticator",
        "authorizer: CassandraAuthorizer",
        "partitioner: org.apache.cassandra.dht.Murmur3Partitioner",
        "endpoint_snitch: GossipingPropertyFileSnitch",
        "native_transport_ssl: true",
        "client_encryption_options:",
        "    enabled: true",
        "    optional: false",
        "server_encryption_options:",
        "    internode_encryption: all",
        "experimental_enabled: false"
      ].join("\n");

      var RECOGNIZED = {};
      ["cluster_name","listen_address","rpc_address","broadcast_address","broadcast_rpc_address",
       "seed_provider","seeds","class_name","parameters","authenticator","authorizer","partitioner",
       "endpoint_snitch","native_transport_ssl","client_encryption_options","server_encryption_options",
       "internode_encryption","experimental_enabled","data_file_directories","commitlog_directory",
       "num_tokens","listen_interface","rpc_interface","ssl_storage_port","storage_port","native_transport_port"
      ].forEach(function(k){ RECOGNIZED[k]=1; });

      var SECRET_RE = /(password|passwd|pwd|secret|token|api[_-]?key|access[_-]?key|private[_-]?key|credential)/i;
      var BIND_KEYS = {listen_address:1, rpc_address:1, broadcast_address:1, broadcast_rpc_address:1};
      var WILDCARDS = {"0.0.0.0":1, "::":1, "*":1, "0.0.0.0/0":1, "::0":1, "[::]":1};

      function unquote(v){
        v = v.trim();
        if (v.length >= 2 && ((v.charAt(0)==='"' && v.charAt(v.length-1)==='"') || (v.charAt(0)==="'" && v.charAt(v.length-1)==="'"))) {
          return v.slice(1,-1);
        }
        return v;
      }
      function stripComment(v){
        v = v.trim();
        if (v.charAt(0)==='"' || v.charAt(0)==="'") {
          var q = v.charAt(0), end = v.indexOf(q, 1);
          if (end >= 0) return v.slice(0, end+1);
          return v;
        }
        var idx = v.indexOf(" #");
        if (idx >= 0) v = v.slice(0, idx);
        return v.trim();
      }

      function parse(text){
        var lines = text.split(/\r?\n/);
        var entries = [], commented = [], notParsed = [];
        var stack = [];
        for (var i=0;i<lines.length;i++){
          var lineNo = i+1, raw = lines[i], trimmed = raw.replace(/^\s+|\s+$/g,"");
          if (trimmed === "") continue;
          if (trimmed.charAt(0) === "#"){
            var cm = trimmed.slice(1).replace(/^\s+/,"").match(/^([A-Za-z0-9_.\-]+)\s*:/);
            if (cm) commented.push({line: lineNo, key: cm[1]});
            continue;
          }
          var indent = raw.replace(/\t/g,"    ").match(/^\s*/)[0].length;
          var isList = /^-\s+/.test(trimmed);
          var content = isList ? trimmed.replace(/^-\s+/,"") : trimmed;
          var effIndent = indent + (isList ? 2 : 0);
          while (stack.length && stack[stack.length-1].indent >= effIndent) stack.pop();
          var m = content.match(/^([A-Za-z0-9_.\-]+)\s*:\s*(.*)$/);
          if (!m){
            if (isList) continue; /* bare list value under a parent key */
            notParsed.push({line: lineNo});
            continue;
          }
          var key = m[1];
          var value = unquote(stripComment(m[2]));
          var ctx = stack.map(function(s){ return s.key; });
          entries.push({line: lineNo, key: key, value: value, context: ctx});
          if (value === "") stack.push({indent: effIndent, key: key});
        }
        return {entries: entries, commented: commented, notParsed: notParsed, lineCount: lines.length};
      }

      function audit(text){
        var parsed = parse(text);
        var entries = parsed.entries;
        var findings = [];
        function add(line, severity, key, message){ findings.push({line: line, severity: severity, key: key, message: message}); }

        var prodContext = false, prodWhy = "";
        entries.forEach(function(e){
          if (e.key === "cluster_name" && /prod/i.test(e.value)) { prodContext = true; prodWhy = "cluster_name says production"; }
          if (/production/i.test(e.value) && e.key !== "cluster_name") { prodContext = true; if (!prodWhy) prodWhy = "the config names a production context"; }
        });

        var recognized = 0;
        entries.forEach(function(e){ if (RECOGNIZED[e.key]) recognized++; });

        entries.forEach(function(e){
          var key = e.key, val = e.value, line = e.line;
          /* Secrets first: report key name, line and length ONLY. */
          if (SECRET_RE.test(key) && val !== ""){
            if (val.indexOf("${") === 0) {
              add(line, "OK", key, "secret is supplied by reference, not written in the config.");
            } else {
              add(line, "HIGH", key, "plaintext secret written in the config — value not shown (length: " + val.length + " characters). Move it to a secrets manager or an environment reference.");
            }
            return;
          }
          if (BIND_KEYS[key]) {
            if (WILDCARDS[val]) add(line, "CRITICAL", key, "bound to wildcard address " + val + "; any network interface can reach this node.");
            else if (val) add(line, "OK", key, "bound to a specific address (" + val + ").");
            return;
          }
          if (key === "authenticator") {
            if (/allowall/i.test(val) || /^(disabled|none|off)$/i.test(val)) add(line, "CRITICAL", key, val + " lets any client connect with no credentials.");
            else if (val) add(line, "OK", key, val + " requires credentials.");
            return;
          }
          if (key === "authorizer") {
            if (/allowall/i.test(val) || /^(disabled|none|off)$/i.test(val)) add(line, "CRITICAL", key, val + " grants every permission to every client.");
            else if (val) add(line, "OK", key, val + " enforces permissions.");
            return;
          }
          if (key === "native_transport_ssl") {
            if (/^false$/i.test(val)) add(line, "HIGH", key, "client-to-node TLS is off (native_transport_ssl: false); CQL traffic is plaintext.");
            else if (/^true$/i.test(val)) add(line, "OK", key, "client-to-node TLS is on.");
            return;
          }
          if (key === "enabled" && e.context.indexOf("client_encryption_options") >= 0) {
            if (/^false$/i.test(val)) add(line, "HIGH", key, "client_encryption_options is disabled; client connections are not encrypted.");
            else if (/^true$/i.test(val)) add(line, "OK", key, "client_encryption_options is enabled.");
            return;
          }
          if (key === "internode_encryption") {
            if (/^none$/i.test(val)) add(line, "HIGH", key, "internode_encryption: none — node-to-node traffic crosses the network in plaintext.");
            else if (/^(all|dc|rack)$/i.test(val)) add(line, "OK", key, "internode_encryption: " + val + " encrypts node-to-node traffic.");
            else if (val) add(line, "MEDIUM", key, "unrecognized internode_encryption value \"" + val + "\"; expected all, dc, rack, or none.");
            return;
          }
          if (key === "endpoint_snitch") {
            if (/SimpleSnitch/i.test(val)) {
              if (prodContext) add(line, "HIGH", key, "SimpleSnitch in a production context (" + prodWhy + "); it does not understand racks or data centers.");
              else add(line, "MEDIUM", key, "SimpleSnitch does not understand racks or data centers; fine for a single local node, wrong for production.");
            } else if (val) add(line, "OK", key, val + " is topology-aware.");
            return;
          }
          if (key === "seeds") {
            if (val === "") { add(line, "CRITICAL", key, "seed list is empty; a new node has no cluster to join."); return; }
            var parts = val.split(",").map(function(s){ return s.replace(/^\s+|\s+$/g,""); }).filter(function(s){ return s !== ""; });
            var localOnly = parts.length > 0 && parts.every(function(s){ return s === "127.0.0.1" || s === "localhost" || s === "::1"; });
            if (parts.length <= 1 || localOnly) add(line, "HIGH", key, "seed list is a single simple seed (\"" + (parts[0] || "") + "\"); list at least two seed nodes from the cluster so a new node can join when one is down.");
            else add(line, "OK", key, parts.length + " seed nodes listed.");
            return;
          }
          if (key === "experimental_enabled" || key === "experimental") {
            if (/^true$/i.test(val)) add(line, "MEDIUM", key, "experimental features are enabled in this config; they are not held to production stability guarantees.");
            return;
          }
          if (key === "partitioner") {
            if (/RandomPartitioner|ByteOrderedPartitioner/i.test(val)) add(line, "HIGH", key, val + " is not Murmur3Partitioner; a non-murmur3 partitioner causes hot spots and cannot be changed on a live cluster without a rebuild.");
            else if (/Murmur3Partitioner/i.test(val)) add(line, "OK", key, "Murmur3Partitioner, as expected.");
            else if (val) add(line, "MEDIUM", key, "unrecognized partitioner \"" + val + "\"; ScyllaDB clusters are built on Murmur3Partitioner.");
            return;
          }
        });

        parsed.commented.forEach(function(c){
          add(c.line, "COMMENTED", c.key, "COMMENTED / NOT ACTIVE — this line is commented out and was not graded as an active setting.");
        });
        parsed.notParsed.forEach(function(n){
          add(n.line, "NOT PARSED", "", "NOT PARSED — this line could not be read as a config key: value line.");
        });
        findings.sort(function(a,b){ return a.line - b.line; });

        var counts = {CRITICAL:0, HIGH:0, MEDIUM:0, OK:0, COMMENTED:0, "NOT PARSED":0};
        findings.forEach(function(f){ counts[f.severity]++; });

        var verdict;
        if (text.replace(/\s+/g,"") === "" || recognized < 2) verdict = "NOT ENOUGH TO GRADE";
        else if (counts.CRITICAL > 0) verdict = "DO NOT DEPLOY";
        else if (counts.HIGH > 0 || counts.MEDIUM > 0 || counts["NOT PARSED"] > 0) verdict = "DEPLOY WITH FIXES";
        else verdict = "SAFE TO DEPLOY";

        return {verdict: verdict, findings: findings, counts: counts, recognized: recognized, lineCount: parsed.lineCount};
      }

      function verdictClass(v){
        return v === "SAFE TO DEPLOY" ? "v-safe" : v === "DEPLOY WITH FIXES" ? "v-fixes" : v === "DO NOT DEPLOY" ? "v-no" : "v-na";
      }
      function chipClass(s){
        return s === "CRITICAL" ? "crit" : s === "HIGH" ? "high" : s === "MEDIUM" ? "med" : s === "OK" ? "ok" : "info";
      }
      function summaryLine(r){
        return "Lines audited: " + r.lineCount + " · Critical: " + r.counts.CRITICAL + " · High: " + r.counts.HIGH +
          " · Medium: " + r.counts.MEDIUM + " · OK: " + r.counts.OK + " · Commented / not active: " + r.counts.COMMENTED +
          " · Not parsed: " + r.counts["NOT PARSED"];
      }
      function buildReport(r){
        var out = [];
        out.push("J-Dawgs ScyllaDB Cluster Config Safety Auditor\u2122 \u2014 Audit Report");
        out.push("Verdict: " + r.verdict);
        out.push(summaryLine(r));
        out.push("");
        out.push("Findings:");
        if (!r.findings.length) out.push("(none)");
        r.findings.forEach(function(f){
          out.push("[Line " + f.line + "] " + f.severity + (f.key ? " \u00B7 " + f.key : "") + " \u2014 " + f.message);
        });
        out.push("");
        out.push("Notes: secret values are never shown \u2014 only the key name, line, and value length are reported. Commented-out lines are COMMENTED / NOT ACTIVE and are not graded as active settings.");
        out.push("Scope: offline text audit only. This tool does not start ScyllaDB, does not connect to any cluster, and does not verify that the config loads.");
        return out.join("\n");
      }
      function buildJson(r){
        return JSON.stringify({
          tool: "J-Dawgs ScyllaDB Cluster Config Safety Auditor\u2122",
          verdict: r.verdict,
          summary: {lines_audited: r.lineCount, recognized_keys: r.recognized, critical: r.counts.CRITICAL, high: r.counts.HIGH, medium: r.counts.MEDIUM, ok: r.counts.OK, commented_not_active: r.counts.COMMENTED, not_parsed: r.counts["NOT PARSED"]},
          findings: r.findings.map(function(f){ return {line: f.line, severity: f.severity, key: f.key || null, message: f.message}; }),
          scope: "Offline text audit only. Does not start ScyllaDB, does not connect to any cluster, does not verify the config loads. Secret values are never included; secrets are reported by key name, line, and value length only."
        }, null, 2);
      }

      var lastResult = null;
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-scylladb-cluster-config-safety-auditortm',
  name: 'J-Dawgs ScyllaDB Cluster Config Safety Auditor',
  description: '',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
