'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Audiobookshelf Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

var RISKY_EXAMPLE = [
"# Risky Audiobookshelf example - teaching sample only, do not deploy",
"HOST=0.0.0.0",
"PORT=3333",
"TOKEN_SECRET=changeme",
"CONFIG_PATH=/config",
"METADATA_PATH=/metadata",
"OPEN_REGISTRATION=true",
"DATABASE_PASSWORD=short",
"AUDIBLE_API_KEY=plaintext-demo-key-123",
"SSL_ENABLED=false",
"BACKUP_PATH="
].join("\n");

var HARDENED_EXAMPLE = [
"# Hardened Audiobookshelf example - teaching sample",
"HOST=127.0.0.1",
"PORT=3333",
"TOKEN_SECRET=a-very-long-random-token-value-48-chars-9f3k2x7q",
"CONFIG_PATH=/config",
"METADATA_PATH=/metadata",
"OPEN_REGISTRATION=false",
"DATABASE_PASSWORD=${DB_PASSWORD_FROM_VAULT}",
"AUDIBLE_API_KEY=${AUDIBLE_KEY_FROM_VAULT}",
"BACKUP_PATH=/backups",
"BACKUP_RETENTION_DAYS=14",
"BACKUP_SCHEDULE=0 2 * * *",
"REVERSE_PROXY=true",
"TRUST_PROXY=true",
"TLS_ENABLED=true",
"SERVER_URL=https://audio.example.local"
].join("\n");

var EXAMPLE_VALUES = ["changeme","change-me","change_me","example","secret","password","test","demo","your-secret","your_secret","replace-me","replace_me","default","audiobookshelf","mysecret","my-secret","letmein","admin","12345","123456","short","token","jwtsecret","supersecret"];
function isExampleValue(v){
  var s = String(v||"").toLowerCase().trim();
  if(!s) return false;
  for(var i=0;i<EXAMPLE_VALUES.length;i++){ if(s===EXAMPLE_VALUES[i]) return true; }
  if(s.indexOf("changeme")!==-1||s.indexOf("example")!==-1||s.indexOf("your-")!==-1||s.indexOf("replace")!==-1) return true;
  if(/^(.)\1+$/.test(s)) return true;
  return false;
}
function isVaultRef(v){
  var s=String(v||"").trim();
  return /^\$\{[^}]+\}$/.test(s)||/^\$[A-Z_][A-Z0-9_]*$/.test(s)||s.indexOf("vault:")===0||s.indexOf("/run/secrets/")===0||s.indexOf("file:")===0;
}
function cleanValue(raw){
  var v=String(raw||"").trim();
  if(v.charAt(v.length-1)===",") v=v.slice(0,-1).trim();
  if(v.length>=2 && ((v.charAt(0)==='"'&&v.charAt(v.length-1)==='"')||(v.charAt(0)==="'"&&v.charAt(v.length-1)==="'"))) v=v.slice(1,-1);
  return v;
}
function truthy(v){ var s=String(v||"").toLowerCase().trim(); return s==="true"||s==="yes"||s==="1"||s==="on"||s==="enabled"||s==="open"||s==="enable"; }
function falsy(v){ var s=String(v||"").toLowerCase().trim(); return s==="false"||s==="no"||s==="0"||s==="off"||s==="disabled"||s==="closed"||s==="disable"; }

function parseConfig(text){
  var lines=String(text||"").split(/\r?\n/);
  var entries=[], notParsed=[], nonEmpty=0;
  var structural=/^(services|environment|ports|volumes|image|container_name|restart|depends_on|networks|version|build|command|user|working_dir)\s*:?\s*$/i;
  for(var i=0;i<lines.length;i++){
    var lineNum=i+1, raw=lines[i], t=raw.trim();
    if(t==="") continue;
    nonEmpty++;
    if(t.charAt(0)==="#"||t.indexOf("//")===0){ continue; }
    if(/^[{}\[\],]+$/.test(t)){ continue; }
    if(structural.test(t)){ continue; }
    var m=null;
    m=t.match(/^-\s*e\s+([A-Za-z_][A-Za-z0-9_.\-]*)=(.*)$/);
    if(!m) m=t.match(/^-\s+([A-Za-z_][A-Za-z0-9_.\-]*)=(.*)$/);
    if(!m) m=t.match(/^(?:export\s+)?"?([A-Za-z_][A-Za-z0-9_.\-]*)"?\s*[:=]\s*(.*)$/);
    if(m){
      entries.push({key:m[1].toUpperCase(), rawKey:m[1], value:cleanValue(m[2]), line:lineNum});
    } else {
      notParsed.push(lineNum);
    }
  }
  return {entries:entries, notParsed:notParsed, nonEmpty:nonEmpty, totalLines:lines.length};
}
function findEntries(entries, test){
  var out=[]; for(var i=0;i<entries.length;i++){ if(test(entries[i].key, entries[i])) out.push(entries[i]); } return out;
}
function isSecretKey(k){ return /SECRET|PASSWORD|PASSWD|PWD|API_?KEY|PRIVATE_?KEY|SESSION|CREDENTIAL|AUTH_?TOKEN/.test(k) || k==="TOKEN" || /_TOKEN$/.test(k); }

function auditConfig(text){
  var parsed=parseConfig(text);
  var entries=parsed.entries, findings=[];
  function add(sev,title,detail,key,line,len){
    findings.push({severity:sev,title:title,detail:detail,key:key||null,line:line||null,secretLength:(typeof len==="number"?len:null)});
  }
  // NOT ENOUGH TO GRADE gate
  if(entries.length<2 || parsed.nonEmpty===0 || (parsed.notParsed.length>0 && parsed.notParsed.length/parsed.nonEmpty>0.5)){
    return {verdict:"NOT ENOUGH TO GRADE", findings:[{severity:"INFO",title:"Not enough recognised configuration to grade",detail:"Only "+entries.length+" recognised key line(s) were found. Paste environment variables, docker env lines, or JSON-style key lines. Unrecognised lines are listed as NOT PARSED by line number.",key:null,line:null,secretLength:null}], parsed:parsed};
  }

  // 1 Token secret
  var tokenEntries=findEntries(entries,function(k){ return k==="TOKEN_SECRET"||k==="JWT_SECRET"||k==="JWT_TOKEN_SECRET"||k.indexOf("JWT")!==-1; });
  if(tokenEntries.length===0){
    add("CRITICAL","Token / JWT secret missing","No TOKEN_SECRET (or JWT secret) line was found. Audiobookshelf signs session tokens with this secret; leaving it unset or to a default is unsafe.",null,null,null);
  } else {
    tokenEntries.forEach(function(e){
      if(isVaultRef(e.value)){ add("PASS","Token secret supplied by reference",e.key+" on line "+e.line+" uses a vault / environment reference rather than a literal value.",e.key,e.line,e.value.length); }
      else if(e.value===""){ add("CRITICAL","Token secret is empty",e.key+" on line "+e.line+" has an empty value (length 0).",e.key,e.line,0); }
      else if(isExampleValue(e.value)){ add("CRITICAL","Token secret is an example / known value",e.key+" on line "+e.line+" has length "+e.value.length+" and matches a known example value. Replace it with a long random secret. The value itself is not shown.",e.key,e.line,e.value.length); }
      else if(e.value.length<16){ add("CRITICAL","Token secret is far too short",e.key+" on line "+e.line+" has length "+e.value.length+". Use at least 32 random characters.",e.key,e.line,e.value.length); }
      else if(e.value.length<32){ add("HIGH","Token secret is short",e.key+" on line "+e.line+" has length "+e.value.length+". Use at least 32 random characters.",e.key,e.line,e.value.length); }
      else { add("PASS","Token secret length looks adequate",e.key+" on line "+e.line+" has length "+e.value.length+" (32 or more) and is not a known example value.",e.key,e.line,e.value.length); }
    });
  }

  // 2 Host / port
  var hostEntries=findEntries(entries,function(k){ return k==="HOST"||k==="BIND"||k==="BIND_ADDRESS"||k==="LISTEN_ADDRESS"||k==="SERVER_HOST"||k==="ADDRESS"; });
  var publicBind=false, localBind=false;
  if(hostEntries.length===0){
    add("MEDIUM","Host binding not stated","No HOST / bind line was found. State the binding explicitly — do not rely on a default that may listen on all interfaces.",null,null,null);
  } else {
    hostEntries.forEach(function(e){
      var v=e.value.trim();
      if(v==="0.0.0.0"||v==="::"||v==="*"||v===""){ publicBind=true; add("HIGH","Server bound to all interfaces",e.key+" on line "+e.line+" is set to all interfaces ("+(v===""?"empty":v)+"). That exposes the server on every network interface unless a firewall / proxy controls access.",e.key,e.line,null); }
      else if(v==="127.0.0.1"||v.toLowerCase()==="localhost"||v==="::1"){ localBind=true; add("PASS","Server bound locally",e.key+" on line "+e.line+" binds to a local address only — a good default when a reverse proxy fronts the server.",e.key,e.line,null); }
      else { add("INFO","Host binding noted",e.key+" on line "+e.line+" is set (value length "+v.length+"). Confirm that address is the one you intend to expose.",e.key,e.line,null); }
    });
  }
  var portEntries=findEntries(entries,function(k){ return k==="PORT"||k==="SERVER_PORT"; });
  if(portEntries.length>0){
    portEntries.forEach(function(e){ add("INFO","Port noted",e.key+" on line "+e.line+" = "+e.value+". Confirm this port is firewalled or proxied as intended.",e.key,e.line,null); });
  }

  // 3 TLS / reverse proxy
  var tlsEntries=findEntries(entries,function(k){ return k.indexOf("TLS")!==-1||k.indexOf("SSL")!==-1||k.indexOf("HTTPS")!==-1||k.indexOf("CERT")!==-1; });
  var proxyEntries=findEntries(entries,function(k){ return k.indexOf("PROXY")!==-1; });
  var urlEntries=findEntries(entries,function(k){ return k==="SERVER_URL"||k==="BASE_URL"||k==="PUBLIC_URL"; });
  var hasHttpsUrl=urlEntries.some(function(e){ return e.value.toLowerCase().indexOf("https://")===0; });
  var tlsOn=tlsEntries.some(function(e){ return truthy(e.value)||e.value.trim()!==""; }) && tlsEntries.some(function(e){ return truthy(e.value); });
  // SSL_ENABLED=false counts as explicitly off, not on
  var tlsExplicitOff=tlsEntries.some(function(e){ return falsy(e.value); }) && !tlsOn;
  var proxyOn=proxyEntries.some(function(e){ return truthy(e.value); });
  var hasPosture = tlsOn || proxyOn || hasHttpsUrl;
  if(publicBind && !hasPosture){
    add("CRITICAL","Public binding with no TLS / reverse-proxy posture","The server is bound to all interfaces and no TLS, certificate, reverse-proxy, trust-proxy, or https:// server URL posture is stated. Do not expose plain HTTP this way.",null,null,null);
  } else if(!hasPosture){
    add("HIGH","No TLS / reverse-proxy posture stated","No TLS/SSL, certificate, reverse-proxy, trust-proxy, or https:// server URL line was found. State how HTTPS is terminated before deploying beyond localhost.",null,null,null);
  } else {
    add("PASS","TLS / reverse-proxy posture stated","A TLS, proxy, or https:// URL posture is present in the pasted config."+(tlsExplicitOff?" Note: a TLS/SSL line is also set to off — confirm the proxy, not the app, terminates TLS.":""),null,null,null);
  }
  if(tlsExplicitOff && publicBind){
    add("HIGH","TLS explicitly disabled on a public bind","A TLS/SSL setting is off while the server binds to all interfaces. Enable TLS or put a TLS-terminating reverse proxy in front.",null,null,null);
  }

  // 4 Open registration
  var regEntries=findEntries(entries,function(k){ return k.indexOf("REGISTRATION")!==-1||k.indexOf("SIGNUP")!==-1||k.indexOf("REGISTER")!==-1; });
  if(regEntries.length===0){
    add("LOW","Registration posture not stated","No registration / signup line was found. Verify in the server settings that registration is closed unless you intend to invite users.",null,null,null);
  } else {
    regEntries.forEach(function(e){
      if(truthy(e.value)){
        if(publicBind){ add("CRITICAL","Open registration on a publicly bound server",e.key+" on line "+e.line+" enables registration while the server binds to all interfaces. Anyone who can reach it can create an account.",e.key,e.line,null); }
        else { add("HIGH","Open registration enabled",e.key+" on line "+e.line+" enables registration. Close it unless open signup is deliberate.",e.key,e.line,null); }
      } else if(falsy(e.value)){ add("PASS","Registration closed",e.key+" on line "+e.line+" disables registration.",e.key,e.line,null); }
      else { add("LOW","Registration value unclear",e.key+" on line "+e.line+" has an unrecognised value. Confirm registration is closed.",e.key,e.line,null); }
    });
  }

  // 5 Plaintext secrets (excluding token secret already graded, and excluding TLS/proxy booleans)
  entries.forEach(function(e){
    if(tokenEntries.indexOf(e)!==-1) return;
    if(!isSecretKey(e.key)) return;
    if(e.value===""){ add("MEDIUM","Secret key present but empty",e.key+" on line "+e.line+" has length 0. Set it via a secret store or remove the line.",e.key,e.line,0); return; }
    if(isVaultRef(e.value)){ add("PASS","Secret supplied by reference",e.key+" on line "+e.line+" uses a reference (length "+e.value.length+") rather than a literal value — preferred.",e.key,e.line,e.value.length); return; }
    var isProvider=/API_?KEY|AUDIBLE|OPEN_?LIBRARY|GOOGLE|PROVIDER/.test(e.key);
    if(isExampleValue(e.value)){ add("CRITICAL",(isProvider?"Provider API key":"Secret")+" is an example / known value",e.key+" on line "+e.line+" has length "+e.value.length+" and matches a known example value. Rotate it. The value itself is not shown.",e.key,e.line,e.value.length); }
    else if(e.value.length<12){ add("HIGH",(isProvider?"Provider API key":"Plaintext secret")+" is very short",e.key+" on line "+e.line+" has length "+e.value.length+". Short secrets are guessable; rotate to a long random value and prefer a vault / file reference. The value itself is not shown.",e.key,e.line,e.value.length); }
    else { add("MEDIUM",(isProvider?"Provider / metadata API key in plaintext":"Plaintext secret in config"),e.key+" on line "+e.line+" holds a literal value of length "+e.value.length+". Prefer a vault, Docker secret, or file reference, and rotate it if this paste was shared. The value itself is not shown.",e.key,e.line,e.value.length); }
  });

  // 6 Backup
  var backupEntries=findEntries(entries,function(k){ return k.indexOf("BACKUP")!==-1; });
  var hasRetention=backupEntries.some(function(e){ return e.key.indexOf("RETENTION")!==-1 && e.value.trim()!==""; });
  var hasSchedule=backupEntries.some(function(e){ return (e.key.indexOf("SCHEDULE")!==-1||e.key.indexOf("CRON")!==-1||e.key.indexOf("INTERVAL")!==-1) && e.value.trim()!==""; });
  var backupPathEmpty=backupEntries.some(function(e){ return e.key.indexOf("PATH")!==-1 && e.value.trim()===""; });
  if(backupEntries.length===0){
    add("MEDIUM","No backup settings found","No BACKUP line was found. Audiobookshelf holds your library database and progress — set a backup path, schedule, and retention before deploying.",null,null,null);
  } else if(backupPathEmpty){
    add("MEDIUM","Backup path is empty","A backup path line is present but empty. Set a real backup destination and a retention period.",null,null,null);
  } else if(!hasRetention && !hasSchedule){
    add("MEDIUM","Backup retention / schedule unset","Backup lines exist but neither a retention nor a schedule setting was found. Unbounded or unscheduled backups both fail when you need them.",null,null,null);
  } else if(!hasRetention){
    add("MEDIUM","Backup retention unset","A backup schedule is set but no retention setting was found. Add a retention period so backups do not grow without bound.",null,null,null);
  } else {
    add("PASS","Backup settings present","Backup configuration includes a retention setting"+(hasSchedule?" and a schedule":"")+".",null,null,null);
  }

  // Verdict
  var hasCrit=findings.some(function(f){return f.severity==="CRITICAL";});
  var hasFix=findings.some(function(f){return f.severity==="HIGH"||f.severity==="MEDIUM";});
  var verdict = hasCrit ? "DO NOT DEPLOY" : (hasFix ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY");
  return {verdict:verdict, findings:findings, parsed:parsed};
}

function buildReport(result, sourceText){
  var lines=[];
  lines.push("J-Dawgs Audiobookshelf Server Config Safety Auditor - Text Report");
  lines.push("Verdict: "+result.verdict);
  lines.push("Recognised key lines: "+result.parsed.entries.length+" | Non-empty lines: "+result.parsed.nonEmpty+" | NOT PARSED lines: "+(result.parsed.notParsed.length?result.parsed.notParsed.join(", "):"none"));
  lines.push("Note: Secret values are never included. Secrets are listed by key name, line number, and length only.");
  lines.push("--- Findings ---");
  result.findings.forEach(function(f,i){
    lines.push((i+1)+". ["+f.severity+"] "+f.title+(f.key?" ("+f.key+(f.line?", line "+f.line:"")+(typeof f.secretLength==="number"?", length "+f.secretLength:"")+")":""));
    lines.push("   "+f.detail);
  });
  if(result.parsed.notParsed.length){
    lines.push("--- NOT PARSED ---");
    result.parsed.notParsed.forEach(function(n){ lines.push("NOT PARSED: line "+n); });
  }
  lines.push("--- End of report ---");
  lines.push("Heuristic text audit only. This tool does not start a server and does not guarantee a running deployment is secure.");
  return lines.join("\n");
}
function buildJson(result){
  return {
    tool:"J-Dawgs Audiobookshelf Server Config Safety Auditor",
    verdict:result.verdict,
    summary:{
      recognisedKeyLines:result.parsed.entries.length,
      nonEmptyLines:result.parsed.nonEmpty,
      critical:result.findings.filter(function(f){return f.severity==="CRITICAL";}).length,
      high:result.findings.filter(function(f){return f.severity==="HIGH";}).length,
      medium:result.findings.filter(function(f){return f.severity==="MEDIUM";}).length,
      pass:result.findings.filter(function(f){return f.severity==="PASS";}).length
    },
    findings:result.findings.map(function(f){ return {severity:f.severity,title:f.title,detail:f.detail,key:f.key,line:f.line,secretLength:f.secretLength}; }),
    notParsedLines:result.parsed.notParsed.slice(),
    note:"Secret values are never included. Secrets appear by key name, line number, and length only."
  };
}

var currentResult=null;
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined), "EXAMPLE_VALUES": (typeof EXAMPLE_VALUES !== 'undefined' ? EXAMPLE_VALUES : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-audiobookshelf-server-config-safety-auditor',
  name: 'J-Dawgs Audiobookshelf Server Config Safety Auditor',
  description: 'Host tools only tell you the server started; ours grades a pasted Audiobookshelf config offline into one deploy verdict — token secrets and admin credentials by key name/line/length only, and port-exposure and authentication posture.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"], "EXAMPLE_VALUES": __core["EXAMPLE_VALUES"] }
};
