'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs ActiveMQ Artemis Broker Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the analyze function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var RISKY_EXAMPLE = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<configuration xmlns="urn:activemq"',
        '               xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"',
        '               xsi:schemaLocation="urn:activemq /schema/artemis-configuration.xsd">',
        '   <core xmlns="urn:activemq:core">',
        '      <name>broker-0</name>',
        '      <persistence-enabled>true</persistence-enabled>',
        '      <security-enabled>false</security-enabled>',
        '      <cluster-user>artemis</cluster-user>',
        '      <cluster-password>shortpw</cluster-password>',
        '      <acceptors>',
        '         <acceptor name="artemis">tcp://0.0.0.0:61616?tcpSendBufferSize=1048576;tcpReceiveBufferSize=1048576</acceptor>',
        '         <acceptor name="artemis">tcp://127.0.0.1:61617</acceptor>',
        '         <acceptor name="management">tcp://0.0.0.0:8161</acceptor>',
        '         <!-- <acceptor name="old-amqp">tcp://0.0.0.0:5672</acceptor> -->',
        '      </acceptors>',
        '      <address-settings>',
        '         <address-setting match="#">',
        '            <dead-letter-address>DLQ</dead-letter-address>',
        '            <expiry-address>ExpiryQueue</expiry-address>',
        '         </address-setting>',
        '      </address-settings>',
        '   </core>',
        '</configuration>'
      ].join("\n");

      var HARDENED_EXAMPLE = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<configuration xmlns="urn:activemq"',
        '               xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"',
        '               xsi:schemaLocation="urn:activemq /schema/artemis-configuration.xsd">',
        '   <core xmlns="urn:activemq:core">',
        '      <name>broker-0</name>',
        '      <persistence-enabled>true</persistence-enabled>',
        '      <security-enabled>true</security-enabled>',
        '      <cluster-user>broker-cluster-svc</cluster-user>',
        '      <cluster-password>long-unique-cluster-secret-7f3a9c</cluster-password>',
        '      <max-disk-usage>90</max-disk-usage>',
        '      <acceptors>',
        '         <acceptor name="artemis">tcp://127.0.0.1:61616?ssl-enabled=true;key-store-path=/etc/artemis/keystore.jks</acceptor>',
        '      </acceptors>',
        '      <security-settings>',
        '         <security-setting match="#">',
        '            <permission type="send" roles="producers"/>',
        '            <permission type="consume" roles="consumers"/>',
        '         </security-setting>',
        '      </security-settings>',
        '      <address-settings>',
        '         <address-setting match="#">',
        '            <dead-letter-address>DLQ</dead-letter-address>',
        '            <expiry-address>ExpiryQueue</expiry-address>',
        '            <max-size-bytes>104857600</max-size-bytes>',
        '            <page-size-bytes>10485760</page-size-bytes>',
        '            <address-full-policy>PAGE</address-full-policy>',
        '         </address-setting>',
        '      </address-settings>',
        '   </core>',
        '</configuration>'
      ].join("\n");

      var EXAMPLE_CREDENTIAL_WORDS = ["artemis", "admin", "password", "passwd", "changeme", "change-me", "default", "secret", "cluster", "user", "guest", "test", "example", "letmein"];

      function lineStarts(text) {
        var starts = [0];
        for (var i = 0; i < text.length; i++) {
          if (text.charAt(i) === "\n") starts.push(i + 1);
        }
        return starts;
      }
      function lineOf(starts, offset) {
        var lo = 0, hi = starts.length - 1, ans = 0;
        while (lo <= hi) {
          var mid = (lo + hi) >> 1;
          if (starts[mid] <= offset) { ans = mid; lo = mid + 1; } else { hi = mid - 1; }
        }
        return ans + 1;
      }

      // Split text into active (non-comment) text and comment segments.
      // Active text keeps identical length/newlines so offsets map to lines.
      function splitComments(text) {
        var active = "", segments = [], i = 0, segStart = -1;
        while (i < text.length) {
          if (segStart < 0 && text.substr(i, 4) === "<!--") {
            segStart = i; segments.push({ start: i, text: "" }); i += 4;
            active += "    ";
          } else if (segStart >= 0 && text.substr(i, 3) === "-->") {
            segments[segments.length - 1].end = i + 3;
            segStart = -1; i += 3; active += "   ";
          } else {
            var ch = text.charAt(i);
            if (segStart >= 0) {
              segments[segments.length - 1].text += ch;
              active += (ch === "\n" ? "\n" : " ");
            } else {
              active += ch;
            }
            i++;
          }
        }
        if (segStart >= 0 && segments.length) segments[segments.length - 1].end = text.length;
        return { active: active, segments: segments, unterminatedComment: segStart >= 0 };
      }

      function findAll(re, text) {
        var out = [], m;
        re.lastIndex = 0;
        while ((m = re.exec(text)) !== null) {
          out.push(m);
          if (m.index === re.lastIndex) re.lastIndex++;
        }
        return out;
      }

      function analyze(raw) {
        var findings = [];
        function add(severity, line, check, title, detail, fix) {
          findings.push({ severity: severity, line: line, check: check, title: title, detail: detail, fix: fix || "" });
        }

        var trimmed = raw.replace(/^\s+|\s+$/g, "");
        var starts = lineStarts(raw);
        var totalLines = raw.length ? raw.split("\n").length : 0;

        if (!trimmed) {
          return { verdict: "NOT ENOUGH TO GRADE", why: "Nothing was pasted. Paste a broker.xml to grade it.", findings: [], parseStatus: "NOT PARSED — empty input", totalLines: 0, acceptorCount: 0 };
        }

        var markers = /<configuration\b|urn:activemq|<core\b|<acceptors?\b|artemis/i.test(raw);
        if (!markers) {
          return { verdict: "NOT ENOUGH TO GRADE", why: "This paste does not look like an ActiveMQ Artemis configuration: no <configuration>, <core>, acceptor, or Artemis namespace markers were found.", findings: [], parseStatus: "NOT PARSED — no Artemis markers found", totalLines: totalLines, acceptorCount: 0 };
        }

        var split = splitComments(raw);
        var active = split.active;

        // --- XML well-formedness (reported, never guessed) ---
        var parseStatus = "Parsed as well-formed XML";
        var parseProblem = "";
        try {
          var doc = new DOMParser().parseFromString(raw, "text/xml");
          var err = doc.getElementsByTagName("parsererror")[0];
          if (err) {
            parseProblem = (err.textContent || "XML parser error").replace(/\s+/g, " ").trim();
            if (parseProblem.length > 220) parseProblem = parseProblem.substring(0, 220) + "…";
            parseStatus = "NOT PARSED — malformed XML";
          }
        } catch (e) {
          parseProblem = String(e && e.message ? e.message : e);
          parseStatus = "NOT PARSED — malformed XML";
        }
        if (split.unterminatedComment && !parseProblem) {
          parseProblem = "An XML comment opens with <!-- and is never closed with -->.";
          parseStatus = "NOT PARSED — malformed XML";
        }
        if (parseProblem) {
          add("NOT PARSED", null, "xml-wellformed", "XML did not parse cleanly", "Problem reported by the parser: " + parseProblem + " The readable parts were still graded with the line-based scanner below; nothing about the broken part was guessed.", "Fix the XML syntax at the reported problem, then re-grade.");
        }

        // --- Commented-out blocks: reported, never graded as set ---
        var commentPatterns = [
          { re: /<acceptor\b/i, label: "an <acceptor> element" },
          { re: /<security-enabled>/i, label: "a <security-enabled> element" },
          { re: /<cluster-(user|password)>/i, label: "a cluster credential element (value not read)" },
          { re: /<max-disk-usage>/i, label: "a <max-disk-usage> element" },
          { re: /<max-size-bytes>/i, label: "a <max-size-bytes> element" }
        ];
        split.segments.forEach(function (seg) {
          commentPatterns.forEach(function (p) {
            if (p.re.test(seg.text)) {
              add("COMMENTED", lineOf(starts, seg.start), "commented-block", "Commented out — NOT ACTIVE", "An XML comment starting here contains " + p.label + ". Commented settings do not run, so this was reported but never graded as set.", "");
            }
          });
        });

        // --- Security enabled ---
        var secMatches = findAll(/<security-enabled>\s*(true|false)\s*<\/security-enabled>/gi, active);
        var securityDisabled = false, securityEnabledSeen = false;
        secMatches.forEach(function (m) {
          var line = lineOf(starts, m.index);
          if (m[1].toLowerCase() === "false") {
            securityDisabled = true;
            add("BLOCKER", line, "security-disabled", "<security-enabled> is false", "Broker security is switched off: any client that can reach an acceptor can connect, send, and consume without authenticating.", "Set <security-enabled>true</security-enabled> and define security-settings with roles for every address pattern.");
          } else {
            securityEnabledSeen = true;
            add("INFO", line, "security-enabled", "Security is enabled", "<security-enabled> is true, so clients must authenticate and pass the security-settings role checks.", "");
          }
        });
        var hasSecuritySettings = /<security-settings>/.test(active);
        var noSecurityPosture = !secMatches.length && !hasSecuritySettings;

        // --- Acceptors ---
        var acceptorRe = /<acceptor\b([^>]*?)(?:\/>|>([\s\S]*?)<\/acceptor>)/g;
        var acceptorMatches = findAll(acceptorRe, active);
        var nameLines = {};
        acceptorMatches.forEach(function (m) {
          var attrs = m[1] || "";
          var body = m[2] || "";
          var line = lineOf(starts, m.index);
          var nameM = /name\s*=\s*"([^"]*)"/.exec(attrs) || /name\s*=\s*'([^']*)'/.exec(attrs);
          var name = nameM ? nameM[1] : "(unnamed)";
          if (!nameLines[name]) nameLines[name] = [];
          nameLines[name].push(line);

          var urlText = body.replace(/^\s+|\s+$/g, "");
          var urlAttr = /url\s*=\s*"([^"]*)"/.exec(attrs);
          if (!urlText && urlAttr) urlText = urlAttr[1];
          var hostM = /^[a-zA-Z][a-zA-Z0-9+.-]*:\/\/(\[[^\]]*\]|[^:\/?#]+)/.exec(urlText);
          var host = hostM ? hostM[1].replace(/^\[|\]$/g, "") : "";
          var wide = (host === "0.0.0.0" || host === "::");
          var fullText = attrs + " " + body;
          var sslOn = /ssl[-_]?enabled\s*=\s*true/i.test(fullText);
          var isManagement = /management|jolokia/i.test(name) || /jolokia/i.test(urlText);

          if (wide && !sslOn) {
            if (securityDisabled || noSecurityPosture) {
              add("BLOCKER", line, "acceptor-plaintext-wide", "Acceptor \"" + name + "\" is plain-text on all interfaces with no security behind it", "This acceptor binds " + host + " (every network interface) and sets no ssl-enabled parameter, so messaging crosses the network unencrypted — and with broker security off or absent, anyone who can reach the port can use it.", "Bind the acceptor to a specific interface or localhost, set ssl-enabled=true with a key store, and turn security on.");
            } else {
              add("HIGH", line, "acceptor-plaintext-wide", "Acceptor \"" + name + "\" is plain-text on all interfaces", "This acceptor binds " + host + " (every network interface) and sets no ssl-enabled parameter, so credentials and message payloads cross the network unencrypted.", "Bind the acceptor to a specific interface or localhost, or set ssl-enabled=true with a key store.");
            }
          }
          if (isManagement) {
            add("WARNING", line, "management-acceptor", "Management acceptor \"" + name + "\" is present", "A dedicated management acceptor widens the attack surface: it is reachable wherever it binds and is a prime target for credential guessing.", "Bind the management acceptor to localhost or a management network only, and require TLS (ssl-enabled=true).");
          }
        });
        Object.keys(nameLines).forEach(function (name) {
          var lines = nameLines[name];
          if (lines.length > 1) {
            add("WARNING", lines[0], "duplicate-acceptor-name", "Duplicate acceptor name \"" + name + "\"", "The acceptor name \"" + name + "\" is used " + lines.length + " times (lines " + lines.join(", ") + "). Duplicate names make acceptor references ambiguous and one definition can shadow the other.", "Give every acceptor a unique name.");
          }
        });

        // --- Cluster credentials (values NEVER reported) ---
        var clusterRe = /<cluster-(user|password)>\s*([\s\S]*?)\s*<\/cluster-(user|password)>/gi;
        findAll(clusterRe, active).forEach(function (m) {
          var kind = m[1].toLowerCase();
          var value = m[2] || "";
          var len = value.length;
          var line = lineOf(starts, m.index);
          var lower = value.toLowerCase();
          var isExample = EXAMPLE_CREDENTIAL_WORDS.indexOf(lower) >= 0 || lower.indexOf("example") >= 0 || lower.indexOf("change-me") >= 0 || lower.indexOf("changeme") >= 0;
          if (kind === "password") {
            if (isExample) {
              add("HIGH", line, "cluster-password", "<cluster-password> holds an example/default-style value", "The element is present at this line and its value is " + len + " characters long and matches a well-known example/default pattern. The value itself is never shown in this report.", "Replace the cluster password with a long, unique secret stored outside the config file.");
            } else if (len < 16) {
              add("HIGH", line, "cluster-password", "<cluster-password> is short", "The element is present at this line and its value is only " + len + " characters long. Short cluster passwords are guessable, and the cluster password authenticates brokers to each other. The value itself is never shown in this report.", "Use a cluster password of at least 16 characters, unique to this cluster, stored outside the config file.");
            } else {
              add("INFO", line, "cluster-password", "<cluster-password> is present", "The element is present at this line with a value of " + len + " characters. The value itself is never shown in this report.", "");
            }
          } else {
            if (isExample || len <= 8) {
              add("WARNING", line, "cluster-user", "<cluster-user> looks like a default/example user", "The element is present at this line and its value is " + len + " characters long and matches a well-known example/default pattern. The value itself is never shown in this report.", "Rename the cluster user to something unique to this deployment.");
            } else {
              add("INFO", line, "cluster-user", "<cluster-user> is present", "The element is present at this line with a value of " + len + " characters. The value itself is never shown in this report.", "");
            }
          }
        });

        // --- Management / console exposure in pasted text ---
        var jolokiaLines = [];
        active.split("\n").forEach(function (ln, idx) { if (/jolokia/i.test(ln)) jolokiaLines.push(idx + 1); });
        var jolokiaInAcceptor = acceptorMatches.some(function (m) { return /jolokia/i.test(m[0]); });
        if (jolokiaLines.length && !jolokiaInAcceptor) {
          add("WARNING", jolokiaLines[0], "jolokia", "Jolokia management API is referenced", "Jolokia appears in the pasted settings (first at line " + jolokiaLines[0] + "). Jolokia exposes broker management over HTTP; exposed beyond a management network it hands attackers a control channel.", "Restrict Jolokia to localhost or a management network, require authentication, and prefer HTTPS.");
        }
        var hawtioLine = 0;
        active.split("\n").forEach(function (ln, idx) { if (!hawtioLine && /hawtio|web-console|console/i.test(ln) && /hawtio/i.test(ln)) hawtioLine = idx + 1; });
        if (hawtioLine) {
          add("WARNING", hawtioLine, "hawtio-console", "Hawtio web console is referenced", "A Hawtio/console reference appears at line " + hawtioLine + ". A web console reachable from untrusted networks is a direct path to broker administration.", "Serve the console only on a management network or behind authenticated HTTPS, never on a public interface.");
        }

        // --- max-disk-usage ---
        var mdu = /<max-disk-usage>\s*(\d+)\s*<\/max-disk-usage>/i.exec(active);
        if (!mdu) {
          add("WARNING", null, "max-disk-usage", "<max-disk-usage> is missing", "No max-disk-usage element was found in the active (non-commented) config, so the broker has no configured point at which it blocks producers to protect a filling disk.", "Add <max-disk-usage> below 100 (for example 90) inside <core> so the broker protects itself before the disk is full.");
        } else if (parseInt(mdu[1], 10) >= 100) {
          add("WARNING", lineOf(starts, mdu.index), "max-disk-usage", "<max-disk-usage> is 100", "At 100 the disk-full protection never engages before the disk is actually full, which is the failure it exists to prevent.", "Set <max-disk-usage> below 100 (for example 90).");
        }

        // --- address-settings memory / paging posture ---
        var asRe = /<address-setting\b([^>]*)>([\s\S]*?)<\/address-setting>/g;
        var asMatches = findAll(asRe, active);
        if (!/<address-settings>/.test(active)) {
          add("INFO", null, "address-settings", "No <address-settings> section found", "Without address-settings, every address runs on broker defaults for memory limits, paging, dead-letter and expiry handling.", "Add an <address-settings> block with a match=\"#\" catch-all that sets max-size-bytes and a paging policy.");
        }
        asMatches.forEach(function (m) {
          var line = lineOf(starts, m.index);
          var matchM = /match\s*=\s*"([^"]*)"/.exec(m[1] || "");
          var matchVal = matchM ? matchM[1] : "(no match attribute)";
          var msb = /<max-size-bytes>\s*(-?\d+)\s*<\/max-size-bytes>/i.exec(m[2] || "");
          if (!msb) {
            add("WARNING", line, "max-size-bytes", "Address-setting \"" + matchVal + "\" sets no <max-size-bytes>", "With no max-size-bytes, this address pattern has no configured memory ceiling before paging or blocking policy engages — a fast producer can push the broker's memory until the JVM is in trouble.", "Set <max-size-bytes> on this address-setting and pair it with an address-full-policy (PAGE is the usual choice).");
          } else if (parseInt(msb[1], 10) < 0) {
            add("WARNING", line, "max-size-bytes", "Address-setting \"" + matchVal + "\" has max-size-bytes of " + msb[1], "A negative max-size-bytes means unlimited: this address pattern can consume memory without bound.", "Set a positive <max-size-bytes> sized to the broker's heap, with an address-full-policy of PAGE.");
          }
        });

        // --- Verdict ---
        var counts = { BLOCKER: 0, HIGH: 0, WARNING: 0, INFO: 0, COMMENTED: 0, "NOT PARSED": 0 };
        findings.forEach(function (f) { counts[f.severity] = (counts[f.severity] || 0) + 1; });
        var verdict, why;
        if (counts.BLOCKER > 0) {
          verdict = "DO NOT DEPLOY";
          why = counts.BLOCKER + " blocker finding" + (counts.BLOCKER === 1 ? "" : "s") + " must be fixed before this broker config goes anywhere near production.";
        } else if (counts.HIGH > 0 || counts.WARNING > 0) {
          verdict = "DEPLOY WITH FIXES";
          why = "No blockers, but " + (counts.HIGH + counts.WARNING) + " high/warning finding" + ((counts.HIGH + counts.WARNING) === 1 ? "" : "s") + " should be fixed first.";
        } else {
          verdict = "SAFE TO DEPLOY";
          why = "No blocker, high, or warning findings in the pasted config. Info notes below are observations, not obstacles.";
        }

        var order = { "BLOCKER": 0, "HIGH": 1, "WARNING": 2, "NOT PARSED": 3, "INFO": 4, "COMMENTED": 5 };
        findings.sort(function (a, b) {
          var d = order[a.severity] - order[b.severity];
          if (d !== 0) return d;
          var la = a.line == null ? 999999 : a.line, lb = b.line == null ? 999999 : b.line;
          return la - lb;
        });

        return { verdict: verdict, why: why, findings: findings, counts: counts, parseStatus: parseStatus, totalLines: totalLines, acceptorCount: acceptorMatches.length };
      }

      function buildTextReport(r) {
        var out = [];
        out.push("J-Dawgs ActiveMQ Artemis Broker Config Safety Auditor — text report");
        out.push("Verdict: " + r.verdict);
        out.push("Why: " + r.why);
        out.push("Parse status: " + r.parseStatus);
        out.push("Lines scanned: " + r.totalLines + " | Acceptors found: " + r.acceptorCount);
        out.push("Note: credential values are never printed — element name, line, and character length only.");
        out.push("");
        if (!r.findings.length) {
          out.push("Findings: none.");
        } else {
          out.push("Findings (" + r.findings.length + "):");
          r.findings.forEach(function (f, i) {
            out.push("");
            out.push((i + 1) + ". [" + f.severity + "] " + f.title + (f.line != null ? " (line " + f.line + ")" : " (whole config)"));
            out.push("   " + f.detail);
            if (f.fix) out.push("   Fix: " + f.fix);
          });
        }
        var fixes = r.findings.filter(function (f) { return f.fix && (f.severity === "BLOCKER" || f.severity === "HIGH" || f.severity === "WARNING" || f.severity === "NOT PARSED"); });
        out.push("");
        out.push("Fix list (" + fixes.length + "):");
        if (!fixes.length) out.push("  Nothing to fix.");
        fixes.forEach(function (f, i) { out.push("  " + (i + 1) + ". " + f.fix); });
        return out.join("\n");
      }

      function buildJsonReport(r) {
        var obj = {
          tool: "J-Dawgs ActiveMQ Artemis Broker Config Safety Auditor",
          verdict: r.verdict,
          why: r.why,
          parse_status: r.parseStatus,
          lines_scanned: r.totalLines,
          acceptors_found: r.acceptorCount,
          counts: r.counts || {},
          secret_values_included: false,
          findings: r.findings.map(function (f) {
            return { severity: f.severity, line: f.line, check: f.check, title: f.title, detail: f.detail, fix: f.fix };
          })
        };
        return JSON.stringify(obj, null, 2);
      }

      function esc(s) {
        return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
      }

      var lastResult = null;
  return { "analyze": (typeof analyze !== 'undefined' ? analyze : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined), "EXAMPLE_CREDENTIAL_WORDS": (typeof EXAMPLE_CREDENTIAL_WORDS !== 'undefined' ? EXAMPLE_CREDENTIAL_WORDS : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["analyze"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-activemq-artemis-broker-config-safety-auditortm',
  name: 'J-Dawgs ActiveMQ Artemis Broker Config Safety Auditor',
  description: '',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["analyze"]) return { ok: false, output: null, summary: 'Extracted core has no analyze function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"], "EXAMPLE_CREDENTIAL_WORDS": __core["EXAMPLE_CREDENTIAL_WORDS"] }
};
