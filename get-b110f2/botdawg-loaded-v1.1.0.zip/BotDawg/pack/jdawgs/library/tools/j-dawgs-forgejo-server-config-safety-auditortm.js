'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Forgejo Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

var RISKY = [
"; Risky worked example — a fresh Forgejo install nobody hardened.",
"APP_NAME = Forgejo",
"RUN_MODE = prod",
"",
"[server]",
"DOMAIN = 192.168.1.50",
"ROOT_URL = http://192.168.1.50:3000/",
"HTTP_ADDR = 0.0.0.0",
"HTTP_PORT = 3000",
"DISABLE_SSH = false",
"SSH_LISTEN_HOST = 0.0.0.0",
"SSH_PORT = 22",
"LFS_START_SERVER = true",
"",
"[database]",
"DB_TYPE = mysql",
"HOST = 127.0.0.1:3306",
"NAME = forgejo",
"USER = forgejo",
"PASSWD = Tr0picDb!Risky-4815",
"",
"[security]",
"INSTALL_LOCK = false",
"SECRET_KEY = short1",
"INTERNAL_TOKEN = changeme",
"MIN_PASSWORD_LENGTH = 6",
"PASSWORD_COMPLEXITY = off",
"",
"[service]",
"DISABLE_REGISTRATION = false",
"REQUIRE_CAPTCHA = false",
"ENABLE_OPENID_SIGNUP = true",
"",
"[mailer]",
"ENABLED = true",
"PROTOCOL = smtp",
"SMTP_HOST = mail.example.com:25",
"USER = forgejo@example.com",
"PASSWD = MailJet!Risky-7731",
"",
"[oauth2]",
"JWT_SECRET = secret"
].join("\n");

var HARDENED = [
"; Hardened example — locked installer, closed signups, long secrets, HTTPS, loopback binds.",
"APP_NAME = Forgejo",
"RUN_MODE = prod",
"",
"[server]",
"PROTOCOL = https",
"DOMAIN = git.example.com",
"ROOT_URL = https://git.example.com/",
"HTTP_ADDR = 127.0.0.1",
"HTTP_PORT = 3000",
"DISABLE_SSH = false",
"SSH_DOMAIN = git.example.com",
"SSH_LISTEN_HOST = 127.0.0.1",
"SSH_PORT = 22",
"LFS_START_SERVER = true",
"LFS_JWT_SECRET = k7Qm2xP9vR4sT8wZ1nB6cH3jF5dA0eG2k7Qm2xP9vR4sT8wZ",
"",
"[database]",
"DB_TYPE = sqlite3",
"PATH = /var/lib/forgejo/data/forgejo.db",
"",
"[security]",
"INSTALL_LOCK = true",
"SECRET_KEY = X9f2Kq7Lm4Rt8Vz1Pw6Ns3Bd5Hy0Jc2Ga9Ek7Mn4Qr8Ut1Wv6Sz3Bp5Fy0Hc2J",
"INTERNAL_TOKEN = eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9k7Qm2xP9vR4sT8wZ1nB6cH3jF5dA0e",
"REVERSE_PROXY_TRUSTED_PROXIES = 127.0.0.1",
"MIN_PASSWORD_LENGTH = 14",
"PASSWORD_COMPLEXITY = lower,upper,digit,spec",
"",
"[session]",
"COOKIE_SECURE = true",
"",
"[service]",
"DISABLE_REGISTRATION = true",
"REQUIRE_CAPTCHA = true",
"REGISTER_EMAIL_CONFIRM = true",
"ENABLE_OPENID_SIGNUP = false",
"",
"[mailer]",
"ENABLED = false",
"",
"[oauth2]",
"JWT_SECRET = Z3x8Qm2kP9vR4sT7wN1bH6cF3jD5aG0eK2m7Qp9xV4rT8sW1nB6"
].join("\n");

var PLACEHOLDERS = ["changeme","change-me","change_me","placeholder","example","secret","password","passwd","letmein","your-secret","your_secret","insert","generate-me","testtest","123456","default","short1","todo","replace-me","replace_me","xxx","forgejo","gitea"];
function isPlaceholder(v){
  var s = v.toLowerCase();
  for (var i=0;i<PLACEHOLDERS.length;i++){ if (s===PLACEHOLDERS[i] || s.indexOf(PLACEHOLDERS[i])!==-1) return true; }
  if (/^(.)\1+$/.test(s)) return true;
  return false;
}
function isTrue(v){ return /^(true|yes|on|1)$/i.test(v.trim()); }
function isFalse(v){ return /^(false|no|off|0)$/i.test(v.trim()); }
function stripQuotes(v){ v=v.trim(); if ((v.charAt(0)==='"'&&v.charAt(v.length-1)==='"')||(v.charAt(0)==="'"&&v.charAt(v.length-1)==="'")) return v.slice(1,-1); return v; }
function isLoopback(v){ v=v.trim().toLowerCase(); return v==="127.0.0.1"||v==="localhost"||v==="::1"||v==="[::1]"; }
function isAllInterfaces(v){ v=v.trim(); return v==="0.0.0.0"||v==="::"||v==="[::]"||v==="*"; }
function isExternalRef(v){ return v.indexOf("${")===0 || v.indexOf("$")===0 || /_FILE$/i.test(v) || v.toLowerCase().indexOf("env:")===0; }

function parseConfig(text){
  var lines = text.split(/\r?\n/);
  var isCompose = /(^|\n)\s*services\s*:/.test(text) || /(^|\n)\s*environment\s*:/.test(text) && /image\s*:/.test(text);
  var envStyleLines = 0;
  lines.forEach(function(l){ if (/^\s*-?\s*(FORGEJO|GITEA)__/.test(l)) envStyleLines++; });
  var format = isCompose ? "docker-compose snippet" : (envStyleLines>=2 ? "server environment" : "app.ini");
  var entries = []; var sections = []; var section = "";
  lines.forEach(function(raw, idx){
    var lineNo = idx+1;
    var t = raw.trim();
    if (!t || t.charAt(0)===";" || t.charAt(0)==="#") return;
    var mSec = t.match(/^\[([^\]]+)\]\s*$/);
    if (mSec && format==="app.ini"){ section = mSec[1].trim().toLowerCase(); sections.push({name:section, line:lineNo}); return; }
    var body = t.replace(/^-\s+/, "");
    var key=null, val=null;
    var eq = body.indexOf("=");
    var colon = body.match(/^([A-Za-z0-9_.\-]+)\s*:\s+(.+)$/);
    if (eq>0){ key=body.slice(0,eq).trim(); val=body.slice(eq+1).trim(); }
    else if (colon && format!=="app.ini"){ key=colon[1].trim(); val=colon[2].trim(); }
    else return;
    val = stripQuotes(val.replace(/\s*[;#].*$/,"").trim());
    var sec = section, k = key.toUpperCase();
    var envMatch = k.match(/^(?:FORGEJO|GITEA)__([A-Z0-9]+)__([A-Z0-9_]+)$/);
    if (envMatch){ sec = envMatch[1].toLowerCase(); k = envMatch[2]; }
    else {
      var plainEnv = k.match(/^(?:FORGEJO|GITEA)_([A-Z0-9_]+)$/);
      if (plainEnv && format!=="app.ini"){ k = plainEnv[1]; }
    }
    entries.push({line:lineNo, section:sec, key:k, value:val});
  });
  return {format:format, entries:entries, sections:sections, lineCount:lines.length};
}
function find(entries, key, section){
  var fallback=null;
  for (var i=0;i<entries.length;i++){
    if (entries[i].key===key){
      if (section && entries[i].section===section) return entries[i];
      if (!fallback) fallback=entries[i];
    }
  }
  return fallback;
}
function findAll(entries, keys){
  var out=[];
  entries.forEach(function(e){ if (keys.indexOf(e.key)!==-1) out.push(e); });
  return out;
}

function audit(text){
  var parsed = parseConfig(text);
  var entries = parsed.entries;
  var findings = [];
  function add(sev, line, directive, explanation, fix){
    findings.push({severity:sev, line:(line==null?null:line), directive:directive, explanation:explanation, fix:fix});
  }
  if (entries.length===0){
    add("WARNING", null, "(no directives)", "No recognizable Forgejo directives were found in the paste, so no posture could be graded.", "Paste the full app.ini, the FORGEJO__ environment lines, or the compose environment block and run the audit again.");
    return {format:parsed.format, findings:findings};
  }

  // Missing [security] section (app.ini only)
  if (parsed.format==="app.ini"){
    var secFound=null;
    parsed.sections.forEach(function(s){ if(s.name==="security") secFound=s; });
    if (!secFound) add("BLOCKER", null, "[security] section", "There is no [security] section in this file, so INSTALL_LOCK, SECRET_KEY, and the password policy have nowhere deliberate to live and fall back to defaults.", "Add a [security] section and set INSTALL_LOCK, SECRET_KEY, INTERNAL_TOKEN, MIN_PASSWORD_LENGTH, and PASSWORD_COMPLEXITY inside it.");
    else add("INFO", secFound.line, "[security] section", "A [security] section is present, so the core secrets and installer lock are set deliberately rather than inherited.", "Keep the [security] section under the same review as the rest of this file on every deploy.");
  }

  // INSTALL_LOCK
  var installLock = find(entries,"INSTALL_LOCK","security");
  if (!installLock) add("WARNING", null, "INSTALL_LOCK", "INSTALL_LOCK is not set. Without it the web installer can stay reachable and anyone who finds it first can create the initial admin account.", "Set INSTALL_LOCK = true in [security] once installation is finished.");
  else if (isFalse(installLock.value)) add("BLOCKER", installLock.line, "INSTALL_LOCK", "INSTALL_LOCK is off, so the web installer is open. Anyone who reaches it can run setup and take over the instance.", "Finish any pending setup, then set INSTALL_LOCK = true in [security] and restart Forgejo.");
  else if (isTrue(installLock.value)) add("INFO", installLock.line, "INSTALL_LOCK", "INSTALL_LOCK is on — the web installer is closed.", "Leave INSTALL_LOCK = true; only turn it off briefly for a deliberate reinstall.");

  // Registration
  var disReg = find(entries,"DISABLE_REGISTRATION","service");
  var regOpen = false;
  if (!disReg) { add("WARNING", null, "DISABLE_REGISTRATION", "DISABLE_REGISTRATION is not set, and Forgejo's default allows open self-registration — strangers can create accounts on your server.", "Set DISABLE_REGISTRATION = true in [service] unless this is a deliberately public forge, and create accounts as an admin instead."); regOpen=true; }
  else if (isFalse(disReg.value)) { add("BLOCKER", disReg.line, "DISABLE_REGISTRATION", "Registration is open: anyone on the internet can sign up for an account, which invites spam, abuse hosting, and credential-stuffing targets.", "Set DISABLE_REGISTRATION = true in [service] (and SERVICE.DISABLE_REGISTRATION in any mirrored config), or pair open signups with REQUIRE_CAPTCHA = true and email confirmation if signups must stay public."); regOpen=true; }
  else if (isTrue(disReg.value)) add("INFO", disReg.line, "DISABLE_REGISTRATION", "Self-registration is disabled — accounts are created deliberately.", "Keep registration disabled, or reopen it only with a captcha and email confirmation in place.");

  var openid = find(entries,"ENABLE_OPENID_SIGNUP","service") || find(entries,"ENABLE_OPEN_ID_SIGNUP","service");
  if (openid && isTrue(openid.value) && regOpen) add("WARNING", openid.line, "ENABLE_OPENID_SIGNUP", "OpenID signup is on while registration is open, giving strangers a second self-service door into the instance.", "Set ENABLE_OPENID_SIGNUP = false in [service] unless federated signup is a deliberate policy.");

  // CAPTCHA
  var captcha = find(entries,"REQUIRE_CAPTCHA","service");
  if (!captcha) add("WARNING", null, "REQUIRE_CAPTCHA", "REQUIRE_CAPTCHA is not set. If signups or forms are ever opened, nothing slows bulk bot registrations.", "Set REQUIRE_CAPTCHA = true in [service] and configure a captcha provider.");
  else if (isFalse(captcha.value)) add("WARNING", captcha.line, "REQUIRE_CAPTCHA", "REQUIRE_CAPTCHA is off, so public forms have no bot friction — a real problem the moment registration opens.", "Set REQUIRE_CAPTCHA = true in [service] and configure the captcha keys.");
  else if (isTrue(captcha.value)) add("INFO", captcha.line, "REQUIRE_CAPTCHA", "A captcha is required on public forms.", "Keep REQUIRE_CAPTCHA = true while any public form exists.");

  // Secrets — name, line, length ONLY
  var secretSpecs = [
    {key:"SECRET_KEY", section:"security", missing:"BLOCKER"},
    {key:"INTERNAL_TOKEN", section:"security", missing:"WARNING"},
    {key:"JWT_SECRET", section:"oauth2", missing:"WARNING"}
  ];
  secretSpecs.forEach(function(spec){
    var e = find(entries, spec.key, spec.section);
    if (!e){ add(spec.missing, null, spec.key, spec.key+" is not set in the paste. Forgejo then relies on a generated or default value, which can invalidate sessions or be guessable depending on how it was produced.", "Generate a long random value (at least 32 characters) and set "+spec.key+" in its section; store the real value in a secrets manager, not in chat or tickets."); return; }
    var len = e.value.length;
    if (len===0) add("BLOCKER", e.line, spec.key, spec.key+" is set but empty (length 0). An empty secret is no secret.", "Set "+spec.key+" to a freshly generated random value of at least 32 characters.");
    else if (isPlaceholder(e.value)) add("BLOCKER", e.line, spec.key, spec.key+" at this line is a placeholder value (length "+len+"). Placeholders are public knowledge — anyone who has read a tutorial knows them.", "Replace "+spec.key+" with a freshly generated random value of at least 32 characters and restart Forgejo.");
    else if (len<16) add("BLOCKER", e.line, spec.key, spec.key+" is too short (length "+len+"). Short secrets can be brute-forced, and this one signs or encrypts real things.", "Replace "+spec.key+" with a freshly generated random value of at least 32 characters.");
    else if (len<32) add("WARNING", e.line, spec.key, spec.key+" is only length "+len+". It works, but it is below the 32-character floor expected for a signing/encryption secret.", "Rotate "+spec.key+" to a freshly generated random value of at least 32 characters at the next maintenance window.");
    else add("INFO", e.line, spec.key, spec.key+" is set with length "+len+", which meets the 32-character floor. (Value never shown.)", "Rotate "+spec.key+" on a schedule and after any suspected leak.");
  });

  // ROOT_URL
  var rootUrl = find(entries,"ROOT_URL","server");
  if (!rootUrl) add("WARNING", null, "ROOT_URL", "ROOT_URL is not set. Links, clone URLs, webhooks, and OAuth redirects are then built from whatever host the request used, which breaks behind proxies and can be spoofed.", "Set ROOT_URL in [server] to the exact public address, starting with https://.");
  else if (/^http:\/\//i.test(rootUrl.value)){
    var hostPart = rootUrl.value.replace(/^http:\/\//i,"").split("/")[0].split(":")[0];
    if (isLoopback(hostPart)) add("WARNING", rootUrl.line, "ROOT_URL", "ROOT_URL uses plain http on a loopback host. Fine for a local test, wrong for anything another machine reaches.", "Keep http only for local testing; use an https ROOT_URL for any shared deployment.");
    else add("BLOCKER", rootUrl.line, "ROOT_URL", "ROOT_URL uses plain http on a public host. Logins, sessions, and clone traffic tied to that URL travel unencrypted, and links Forgejo generates point at the insecure address.", "Put Forgejo behind an HTTPS reverse proxy (or terminate TLS in front of it) and set ROOT_URL to the https:// address.");
  }
  else if (/^https:\/\//i.test(rootUrl.value)) add("INFO", rootUrl.line, "ROOT_URL", "ROOT_URL uses https, so generated links point at the encrypted address.", "Keep ROOT_URL exactly matching the public https address, including any sub-path.");
  else add("WARNING", rootUrl.line, "ROOT_URL", "ROOT_URL is set but does not start with http:// or https://, so generated links will be malformed.", "Set ROOT_URL to the full public address including the https:// scheme.");

  var protocol = find(entries,"PROTOCOL","server");
  if (protocol && protocol.value.toLowerCase()==="http" && rootUrl && /^https:/i.test(rootUrl.value))
    add("WARNING", protocol.line, "PROTOCOL", "PROTOCOL is http while ROOT_URL is https. That is the normal reverse-proxy shape only if the proxy is trusted and strips forwarding headers correctly.", "Confirm the reverse proxy is the only path in and that REVERSE_PROXY_TRUSTED_PROXIES is limited to it.");

  // HTTP bind
  var httpAddr = find(entries,"HTTP_ADDR","server");
  if (!httpAddr) add("WARNING", null, "HTTP_ADDR", "HTTP_ADDR is not set, so the web listener uses Forgejo's default bind, which can expose the web UI on every network interface.", "Set HTTP_ADDR = 127.0.0.1 in [server] if a reverse proxy fronts Forgejo, or document why a wider bind is intended.");
  else if (isAllInterfaces(httpAddr.value)) add("WARNING", httpAddr.line, "HTTP_ADDR", "The web listener binds to all interfaces (0.0.0.0 / ::). Every network this host joins — LAN, VPN, container bridge — can reach the Forgejo web UI directly, bypassing any reverse-proxy rules.", "Set HTTP_ADDR = 127.0.0.1 in [server] and let the reverse proxy be the only public door, or firewall the port deliberately.");
  else if (isLoopback(httpAddr.value)) add("INFO", httpAddr.line, "HTTP_ADDR", "The web listener binds to loopback only, so a reverse proxy or local tunnel is the way in.", "Keep the loopback bind and make sure the proxy passes the correct host and scheme headers.");
  else add("INFO", httpAddr.line, "HTTP_ADDR", "The web listener binds to a specific interface rather than all of them.", "Confirm that interface is the one you intend to expose.");

  // SSH
  var disSsh = find(entries,"DISABLE_SSH","server");
  var sshListen = find(entries,"SSH_LISTEN_HOST","server");
  var sshPassAuth = findAll(entries,["SSH_PASSWORD_AUTH","ALLOW_SSH_PASSWORD_AUTH","SSH_ALLOW_PASSWORD_AUTH","PASSWORD_AUTH"]);
  sshPassAuth.forEach(function(e){ if (isTrue(e.value)) add("BLOCKER", e.line, e.key, "SSH password authentication appears to be enabled. Password-based SSH is the most brute-forced door on the internet.", "Disable SSH password authentication and require public-key auth for git-over-SSH."); });
  if (disSsh && isTrue(disSsh.value)) add("INFO", disSsh.line, "DISABLE_SSH", "The built-in SSH server is disabled — git-over-SSH either uses the system sshd deliberately or is off.", "If you rely on system sshd, keep its hardening reviewed separately.");
  else if (disSsh && isFalse(disSsh.value)){
    if (sshListen && isAllInterfaces(sshListen.value)) add("WARNING", sshListen.line, "SSH_LISTEN_HOST", "SSH is enabled and listens on all interfaces. Git SSH is reachable from every network the host joins, so key hygiene and fail2ban-style protection carry the whole load.", "Set SSH_LISTEN_HOST = 127.0.0.1 in [server] if SSH should only be local or proxied, or harden and monitor the exposed port deliberately.");
    else if (sshListen && isLoopback(sshListen.value)) add("INFO", sshListen.line, "SSH_LISTEN_HOST", "SSH is enabled but bound to loopback, limiting who can reach it.", "Keep the loopback bind unless public git-over-SSH is a deliberate requirement.");
    else add("WARNING", disSsh.line, "DISABLE_SSH", "SSH is enabled and no SSH_LISTEN_HOST narrows it, so it follows the default bind on all interfaces.", "Set SSH_LISTEN_HOST explicitly in [server] — 127.0.0.1 for local/proxied SSH, or a specific interface you intend to expose.");
  } else if (!disSsh) add("WARNING", null, "DISABLE_SSH", "DISABLE_SSH is not set, so whether the built-in SSH server runs is left to defaults.", "Set DISABLE_SSH explicitly in [server] and, if SSH stays on, set SSH_LISTEN_HOST to the intended interface.");

  // Database credentials — name and line ONLY
  var dbPasses = findAll(entries,["PASSWD","PASSWORD","DB_PASSWD","DATABASE_PASSWORD"]);
  var dbPassReported=false;
  dbPasses.forEach(function(e){
    if (e.section==="database" || e.key.indexOf("DB")===0 || e.key==="DATABASE_PASSWORD"){
      dbPassReported=true;
      if (!e.value) add("INFO", e.line, e.key, "The database credential directive "+e.key+" is present but empty at this line — consistent with sqlite or a password supplied elsewhere. (Name and line only; no value is ever shown.)", "If the database needs a password, supply it from an environment variable or secret file instead of this file.");
      else if (isExternalRef(e.value)) add("INFO", e.line, e.key, "The database credential at "+e.key+" points at an external reference rather than sitting in plaintext in this file. (Name and line only.)", "Keep database credentials in the external secret store.");
      else add("WARNING", e.line, e.key, "A database password is stored in plaintext in this config at "+e.key+". Anyone who can read this file — backups, repos, screenshots, tickets — has the database. (Name and line only; the value is never shown.)", "Move the database password out of app.ini into an environment variable, a Docker secret, or a permission-locked secret file, and rotate it — it has been sitting in a shareable file.");
    }
  });
  if (!dbPassReported){
    var dbType = find(entries,"DB_TYPE","database");
    if (dbType && dbType.value.toLowerCase()==="sqlite3") add("INFO", dbType.line, "DB_TYPE", "The database is sqlite3 and no database password is stored in this config.", "Keep the sqlite file itself permission-locked; it is the whole database.");
    else if (dbType) add("INFO", dbType.line, "DB_TYPE", "No plaintext database password directive was found in the paste — the password is either supplied outside the file or still to be configured.", "Confirm the database password really comes from an environment variable or secret file, not from a second config file.");
  }
  var sslMode = find(entries,"SSL_MODE","database");
  if (sslMode && /^(disable|prefer)$/i.test(sslMode.value)) add("WARNING", sslMode.line, "SSL_MODE", "The database connection does not require TLS, so credentials and data cross the database hop unencrypted.", "Set SSL_MODE = require (or verify-full) for the database connection where the server supports it.");

  // Password policy
  var minLen = find(entries,"MIN_PASSWORD_LENGTH","security");
  if (!minLen) add("WARNING", null, "MIN_PASSWORD_LENGTH", "No minimum password length is set, so Forgejo's short default decides how weak an account password may be.", "Set MIN_PASSWORD_LENGTH = 12 or higher in [security].");
  else {
    var n = parseInt(minLen.value,10);
    if (isNaN(n)) add("WARNING", minLen.line, "MIN_PASSWORD_LENGTH", "MIN_PASSWORD_LENGTH is set but is not a readable number, so the effective policy is unclear.", "Set MIN_PASSWORD_LENGTH to a plain number, 12 or higher.");
    else if (n<8) add("BLOCKER", minLen.line, "MIN_PASSWORD_LENGTH", "The minimum password length is under 8, which permits passwords that fall to trivial guessing.", "Set MIN_PASSWORD_LENGTH = 12 or higher in [security].");
    else if (n<12) add("WARNING", minLen.line, "MIN_PASSWORD_LENGTH", "The minimum password length is under 12 — workable, but short for accounts that administer a code host.", "Raise MIN_PASSWORD_LENGTH to 12 or higher in [security].");
    else add("INFO", minLen.line, "MIN_PASSWORD_LENGTH", "The minimum password length is 12 or more.", "Keep the minimum at 12 or higher.");
  }
  var complexity = find(entries,"PASSWORD_COMPLEXITY","security");
  if (!complexity) add("WARNING", null, "PASSWORD_COMPLEXITY", "PASSWORD_COMPLEXITY is not set, so a long-but-simple password (all lowercase, no digits) passes the length check.", "Set PASSWORD_COMPLEXITY = lower,upper,digit,spec in [security].");
  else if (/^(off|none|false)$/i.test(complexity.value)) add("WARNING", complexity.line, "PASSWORD_COMPLEXITY", "Password complexity checks are turned off, so only length stands between users and weak passwords.", "Set PASSWORD_COMPLEXITY = lower,upper,digit,spec in [security].");
  else add("INFO", complexity.line, "PASSWORD_COMPLEXITY", "Password complexity requirements are switched on.", "Keep at least lower, upper, and digit required; add spec for admin-heavy instances.");

  // Mailer credentials — name and line ONLY
  var mailerEnabled = find(entries,"ENABLED","mailer");
  var mailPasses = [];
  entries.forEach(function(e){ if (e.section==="mailer" && (e.key==="PASSWD"||e.key==="PASSWORD"||e.key==="SMTP_PASSWD"||e.key==="SMTP_PASSWORD")) mailPasses.push(e); });
  if (mailerEnabled && isFalse(mailerEnabled.value)) add("INFO", mailerEnabled.line, "[mailer] ENABLED", "The mailer is disabled, so no SMTP credential needs to live in this file and no mail-based account recovery runs.", "If you enable mail later, supply the SMTP password from a secret store, not this file.");
  mailPasses.forEach(function(e){
    if (e.value && !isExternalRef(e.value)) add("WARNING", e.line, e.key, "A mailer password is stored in plaintext in this config at "+e.key+". A leaked SMTP credential is a ready-made spam and phishing account in your domain's name. (Name and line only; the value is never shown.)", "Move the mailer password into an environment variable or secret file and rotate it.");
  });
  if (mailerEnabled && isTrue(mailerEnabled.value) && mailPasses.length===0)
    add("INFO", mailerEnabled.line, "[mailer] ENABLED", "The mailer is enabled and no plaintext mailer password directive appears in the paste.", "Confirm the SMTP password is supplied from outside the file.");

  // LFS
  var lfs = find(entries,"LFS_START_SERVER","server");
  if (lfs && isTrue(lfs.value)){
    var lfsSecret = find(entries,"LFS_JWT_SECRET","server");
    if (!lfsSecret) add("WARNING", lfs.line, "LFS_START_SERVER", "Git LFS is enabled with no LFS_JWT_SECRET in the paste. LFS serves large files over signed tokens; without a deliberate secret and auth review, LFS endpoints are a common soft spot.", "Set a long random LFS_JWT_SECRET in [server], confirm LFS requests require authentication for private repos, and note the decision in your runbook.");
    else if (lfsSecret.value.length<32 || isPlaceholder(lfsSecret.value)) add("WARNING", lfsSecret.line, "LFS_JWT_SECRET", "LFS is enabled but its JWT secret is short or a placeholder (reported by length only: "+lfsSecret.value.length+"). LFS download tokens signed with a weak secret can be forged.", "Set LFS_JWT_SECRET to a freshly generated random value of at least 32 characters.");
    else add("INFO", lfs.line, "LFS_START_SERVER", "Git LFS is enabled with a long LFS_JWT_SECRET in place, so LFS tokens are signed with a deliberate secret.", "Keep LFS auth checks on for private repositories and rotate LFS_JWT_SECRET with the other secrets.");
  } else if (lfs && isFalse(lfs.value)) add("INFO", lfs.line, "LFS_START_SERVER", "Git LFS is not started by this config.", "Enable LFS only with a long LFS_JWT_SECRET and an auth review.");

  // Reverse proxy wildcard + cookie
  var proxies = find(entries,"REVERSE_PROXY_TRUSTED_PROXIES","security");
  if (proxies && proxies.value.trim()==="*") add("WARNING", proxies.line, "REVERSE_PROXY_TRUSTED_PROXIES", "Every proxy is trusted, so any hop can spoof the forwarding headers Forgejo uses for client IPs and rate limits.", "Limit REVERSE_PROXY_TRUSTED_PROXIES to the actual proxy addresses, e.g. 127.0.0.1.");
  var cookie = find(entries,"COOKIE_SECURE","session");
  if (cookie && isFalse(cookie.value) && rootUrl && /^https:/i.test(rootUrl.value)) add("WARNING", cookie.line, "COOKIE_SECURE", "Session cookies are not marked Secure even though the site runs on https, so a stray http request can leak the session cookie.", "Set COOKIE_SECURE = true in [session].");
  else if (cookie && isTrue(cookie.value)) add("INFO", cookie.line, "COOKIE_SECURE", "Session cookies are marked Secure.", "Keep COOKIE_SECURE = true on the https deployment.");

  // Admin / default credential directives — name and line only
  entries.forEach(function(e){
    if (/^(ADMIN_PASSWORD|DEFAULT_PASSWORD|INITIAL_ADMIN_PASSWORD)$/.test(e.key) && e.value)
      add("BLOCKER", e.line, e.key, "An admin or default password directive ("+e.key+") is present in this config. Default credentials in a file are the first thing an attacker tries. (Name and line only; the value is never shown.)", "Remove the default/admin password from the config, create the admin interactively, and rotate the password.");
  });
  var runUser = find(entries,"RUN_USER",null);
  if (runUser && runUser.value.toLowerCase()==="root") add("WARNING", runUser.line, "RUN_USER", "Forgejo is configured to run as root, so any Forgejo compromise is a full host compromise.", "Run Forgejo as a dedicated unprivileged user and set RUN_USER to it.");

  return {format:parsed.format, findings:findings};
}

function verdictFor(findings){
  var b=0,w=0,i=0;
  findings.forEach(function(f){ if(f.severity==="BLOCKER")b++; else if(f.severity==="WARNING")w++; else i++; });
  var verdict = b>0 ? "DO NOT DEPLOY" : (w>0 ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY");
  return {verdict:verdict, blockers:b, warnings:w, info:i};
}
function lineLabel(f){ return f.line==null ? "missing" : "line "+f.line; }
function buildReport(format, v, findings){
  var out=[];
  out.push("J-Dawgs Forgejo Server Config Safety Auditor\u2122 — audit report");
  out.push("Format detected: "+format);
  out.push("Verdict: "+v.verdict);
  out.push("Counts: "+v.blockers+" BLOCKER, "+v.warnings+" WARNING, "+v.info+" INFO");
  out.push("Secret values are never included in this report.");
  out.push("");
  findings.forEach(function(f, idx){
    out.push((idx+1)+". ["+f.severity+"] "+f.directive+" ("+lineLabel(f)+")");
    out.push("   "+f.explanation);
    out.push("   Fix: "+f.fix);
  });
  return out.join("\n");
}
function escapeHtml(s){ return s.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"); }

var lastResult=null;
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-forgejo-server-config-safety-auditortm',
  name: 'J-Dawgs Forgejo Server Config Safety Auditor',
  description: 'Forgejo\'s own checks only answer whether the server starts on the host; ours grades a pasted Forgejo server config (app.ini / env / compose) fully offline — installer left open, open registration, short secrets, and an http ROOT_URL all graded, with secrets shown by key name/line/length only — into ',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
