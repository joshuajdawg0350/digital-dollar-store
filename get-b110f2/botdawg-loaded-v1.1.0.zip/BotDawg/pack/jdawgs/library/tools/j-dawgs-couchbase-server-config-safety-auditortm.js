'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Couchbase Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

var RISKY = [
"[cluster]",
"rest_host = 0.0.0.0",
"rest_port = 8091",
"rest_url = http://0.0.0.0:8091",
"admin_user = Administrator",
"admin_password = password",
"auth_enabled = false",
"ssl_enabled = false",
"xdcr_remote_cluster = http://192.168.1.50:8091",
"xdcr_password = couchbase",
"query_port = 8093",
"query_url = http://0.0.0.0:8093",
"analytics_port = 8095",
"analytics_url = http://0.0.0.0:8095",
"auto_failover = false",
"audit_enabled = false"
].join("\n");

var HARDENED = [
"[cluster]",
"rest_host = 127.0.0.1",
"rest_port = 8091",
"ssl_port = 18091",
"rest_url = https://127.0.0.1:18091",
"ssl_enabled = true",
"tls_enabled = true",
"admin_user = Administrator",
"admin_password = ${COUCHBASE_ADMIN_PASSWORD}",
"auth_enabled = true",
"rbac_enabled = true",
"xdcr_remote_cluster = https://cb-remote.example.internal:18091",
"xdcr_password = ${XDCR_SECRET_FROM_VAULT}",
"query_port = 18096",
"query_tls_enabled = true",
"query_auth_enabled = true",
"analytics_port = 18095",
"analytics_tls_enabled = true",
"analytics_auth_enabled = true",
"auto_failover = true",
"auto_failover_timeout = 120",
"audit_enabled = true",
"audit_log_path = /var/log/couchbase/audit.log"
].join("\n");

document.getElementById("riskyPre").textContent = RISKY.split("\n").map(function(l,i){return (i+1)+": "+l;}).join("\n");
document.getElementById("hardenedPre").textContent = HARDENED.split("\n").map(function(l,i){return (i+1)+": "+l;}).join("\n");

var lastResult = null;

function stripVal(v){
  if(v==null) return "";
  v = String(v).trim();
  v = v.replace(/,$/,"").trim();
  if((v.charAt(0)==='"'&&v.charAt(v.length-1)==='"')||(v.charAt(0)==="'"&&v.charAt(v.length-1)==="'")) v=v.slice(1,-1);
  return v.trim();
}
function isFalsy(v){ var s=String(v||"").toLowerCase().trim(); return ["false","no","0","disabled","disable","off","none"].indexOf(s)>=0; }
function isTruthy(v){ var s=String(v||"").toLowerCase().trim(); return ["true","yes","1","enabled","enable","on"].indexOf(s)>=0; }
function isSecretRef(v){
  var s=String(v||"").trim();
  if(!s) return false;
  if(s.indexOf("${")===0) return true;
  if(s.charAt(0)==="$") return true;
  var l=s.toLowerCase();
  if(l.indexOf("vault:")===0||l.indexOf("env:")===0||l.indexOf("file:")===0||l.indexOf("secret:")===0) return true;
  if(l.indexOf("***")>=0||l==="redacted"||l.indexOf("<")===0) return true;
  return false;
}
function hasPort(line,port){
  var re = new RegExp("(^|[^0-9])"+port+"([^0-9]|$)");
  return re.test(line);
}
function parseLine(raw, num){
  var t = raw.trim();
  if(!t) return {num:num,type:"blank"};
  if(t.charAt(0)==="#"||t.indexOf("//")===0||t.charAt(0)===";") return {num:num,type:"commented"};
  if(t.charAt(0)==="["&&t.charAt(t.length-1)==="]") return {num:num,type:"parsed",key:"section",value:t.slice(1,-1),raw:raw};
  var key=null,value=null,m;
  // couchbase-cli flag --key=value or --key value
  m = t.match(/^--?([A-Za-z0-9_\-\.]+)(?:\s*=\s*|\s+)?(.*)$/);
  if(t.indexOf("--")===0 && m){ key=m[1]; value=stripVal(m[2]||""); return {num:num,type:"parsed",key:key,value:value,raw:raw}; }
  // JSON-ish "key": value  or 'key': value
  m = t.match(/^["']([^"']+)["']\s*:\s*(.*)$/);
  if(m){ key=m[1]; value=stripVal(m[2]); return {num:num,type:"parsed",key:key,value:value,raw:raw}; }
  m = t.match(/^[{,]?\s*["']([^"']+)["']\s*:\s*(.*)$/);
  if(m){ key=m[1]; value=stripVal(m[2]); return {num:num,type:"parsed",key:key,value:value,raw:raw}; }
  // key = value  / key: value
  m = t.match(/^([A-Za-z0-9_\-\.\/]+)\s*(=|:)\s*(.*)$/);
  if(m){ key=m[1]; value=stripVal(m[3]); return {num:num,type:"parsed",key:key,value:value,raw:raw}; }
  // key value (space separated, key looks like identifier)
  m = t.match(/^([A-Za-z0-9_\-\.]+)\s+(\S.*)$/);
  if(m && /(_|\-|port|host|url|ssl|tls|auth|xdcr|audit|failover|password|admin|rest|query|analytics|cluster|rbac)/i.test(m[1])){ key=m[1]; value=stripVal(m[2]); return {num:num,type:"parsed",key:key,value:value,raw:raw}; }
  // bare URL / port / known keyword line
  if(/https?:\/\//i.test(t)||hasPort(t,"8091")||hasPort(t,"18091")||hasPort(t,"8093")||hasPort(t,"8095")||/xdcr|failover|audit|ssl|tls/i.test(t)){
    return {num:num,type:"parsed",key:"",value:t,raw:raw};
  }
  return {num:num,type:"notparsed"};
}

function audit(text){
  var rawLines = String(text||"").split(/\r?\n/);
  // If input is a single empty string, treat as zero lines meaningfully
  var parsed=[],commented=[],notParsed=[],blank=0;
  var entries=[];
  for(var i=0;i<rawLines.length;i++){
    var e=parseLine(rawLines[i],i+1);
    entries.push(e);
    if(e.type==="parsed") parsed.push(e);
    else if(e.type==="commented") commented.push(e.num);
    else if(e.type==="notparsed") notParsed.push(e.num);
    else blank++;
  }
  if(String(text||"").trim()===""){ parsed=[];commented=[];notParsed=[];blank=0; rawLines=[]; }

  var findings=[],passes=[];
  function add(sev,code,title,detail,lines){ findings.push({severity:sev,code:code,title:title,detail:detail,lines:lines||[]}); }
  function pass(code,title,detail,lines){ passes.push({severity:"PASS",code:code,title:title,detail:detail,lines:lines||[]}); }

  var lowerAll = parsed.map(function(e){return (e.key+" "+e.value+" "+(e.raw||"")).toLowerCase();}).join("\n");
  var relevant = /(8091|18091|8093|8095|18093|18095|xdcr|password|admin|rest|query|analytics|failover|audit|ssl|tls|cluster|rbac|auth)/i.test(lowerAll);

  // Auth disabled detection
  var authDisabledLines=[];
  parsed.forEach(function(e){
    var k=(e.key||"").toLowerCase(), v=String(e.value||"");
    var lineLow=((e.raw||"")+"").toLowerCase();
    if((k.indexOf("auth")>=0 && isFalsy(v))||/auth\w*\s*[:=]\s*(false|disabled|none|off)/.test(lineLow)||lineLow.indexOf("no auth")>=0) authDisabledLines.push(e.num);
  });
  var authDisabled = authDisabledLines.length>0;

  // Password keys — graded by key/line/length ONLY
  var DEFAULTS=["password","admin","administrator","changeme","change-me","couchbase","letmein","default","123456","12345678","password1","admin123","secret","test"];
  var defaultPwLines=[], plaintextPw=[];
  parsed.forEach(function(e){
    var k=(e.key||"").toLowerCase();
    var isPw = k.indexOf("password")>=0||k.indexOf("passwd")>=0||k==="pwd"||k.indexOf("rbac_password")>=0;
    // also catch --password style already normalised to key 'password'
    if(!isPw) return;
    var v=String(e.value||"");
    var len=v.length;
    if(isSecretRef(v)){ pass("pw-ref","Password key uses a secret reference — '"+e.key+"' (line "+e.num+")","Key '"+e.key+"' on line "+e.num+" points at a secret reference (length "+len+"), not a plaintext value. Value not shown.",[e.num]); return; }
    if(len===0){ add("HIGH","pw-empty","Plaintext password key with empty value — '"+e.key+"'","Key '"+e.key+"' on line "+e.num+" has a value length of 0. Value not shown.",[e.num]); plaintextPw.push(e.num); return; }
    var sev = len<8 ? "HIGH" : "HIGH";
    add(sev,"pw-plaintext","Plaintext password in pasted text — '"+e.key+"'","Key '"+e.key+"' on line "+e.num+" — value length "+len+" characters. The value itself is never shown in this report. Move it to a secret store or environment reference and rotate it if it was ever shared.",[e.num]);
    plaintextPw.push(e.num);
    if(DEFAULTS.indexOf(v.toLowerCase())>=0||len<=6) defaultPwLines.push(e.num);
  });

  // Administrator presence
  var adminLines=[];
  parsed.forEach(function(e){
    if(String(e.value||"").toLowerCase()==="administrator"||(e.key||"").toLowerCase().indexOf("administrator")>=0) adminLines.push(e.num);
  });
  var hasDefaultAdmin = defaultPwLines.length>0 && (adminLines.length>0 || plaintextPw.length>0);
  if(defaultPwLines.length>0){
    add(hasDefaultAdmin?"BLOCKER":"HIGH","default-admin","Default-looking Administrator / password value flagged","Line(s) "+defaultPwLines.join(", ")+" use a default-looking or very short password value. This tool cannot know if the database password was changed on the live cluster — it only flags pasted / default-looking values in the text you provided. If this value is (or was) the live Administrator password, change it now and store the new one in a secret store.",defaultPwLines.slice());
  }

  if(authDisabled){
    add("HIGH","auth-disabled","Authentication appears disabled","Authentication is set to a disabled / false value on line(s) "+authDisabledLines.join(", ")+". A Couchbase node with authentication off exposes data and admin actions to anyone who can reach it.",authDisabledLines.slice());
  }

  // Admin UI / REST 8091 plain http on 0.0.0.0
  var exposureLines=[];
  parsed.forEach(function(e){
    var raw=e.raw||"";
    if(hasPort(raw,"8091") && (raw.indexOf("http://")>=0||raw.indexOf("0.0.0.0")>=0)) if(exposureLines.indexOf(e.num)<0) exposureLines.push(e.num);
  });
  // cross-line: host 0.0.0.0 + port 8091 on different lines
  var hostLines=[],portLines=[];
  parsed.forEach(function(e){
    var k=(e.key||"").toLowerCase();
    if((k.indexOf("host")>=0||k.indexOf("bind")>=0||k.indexOf("address")>=0) && String(e.value||"").indexOf("0.0.0.0")>=0) hostLines.push(e.num);
    if(k.indexOf("port")>=0 && hasPort(String(e.value||""),"8091")) portLines.push(e.num);
    if(String(e.value||"").indexOf("0.0.0.0")>=0 && hasPort(e.raw||"","8091")) { /* already covered */ }
  });
  if(hostLines.length && portLines.length){ hostLines.concat(portLines).forEach(function(n){ if(exposureLines.indexOf(n)<0) exposureLines.push(n); }); }
  exposureLines.sort(function(a,b){return a-b;});
  if(exposureLines.length){
    if(authDisabled||hasDefaultAdmin){
      add("BLOCKER","admin-http-blocker","Admin UI / REST port 8091 on plain HTTP at 0.0.0.0 — with auth disabled or default admin","Line(s) "+exposureLines.join(", ")+" expose port 8091 over plain http on 0.0.0.0 (all interfaces), and the same config disables authentication or uses a default-looking Administrator credential. Anyone on the network can reach the admin UI. Bind to a private interface, require TLS on 18091, enable authentication, and change the Administrator password.",exposureLines.slice());
    } else {
      add("HIGH","admin-http","Admin UI / REST port 8091 on plain HTTP at 0.0.0.0","Line(s) "+exposureLines.join(", ")+" expose port 8091 over plain http on 0.0.0.0 (all interfaces). Admin credentials and session data cross the network in clear text. Prefer https on 18091 and bind the admin UI to localhost or a management network only.",exposureLines.slice());
    }
  }

  // SSL 18091 missing
  var has18091 = parsed.some(function(e){ return hasPort(e.raw||"","18091")||hasPort(String(e.value||""),"18091"); });
  if(parsed.length && relevant && !has18091){
    add("MEDIUM","ssl-missing","SSL port 18091 not found","No parsed line mentions the TLS admin port 18091. Without it there is no encrypted admin / REST endpoint in this config. Enable TLS, configure 18091, and redirect or disable plain-http admin access.");
  } else if(has18091){
    pass("ssl-present","SSL port 18091 present","A parsed line references port 18091, the TLS admin / REST port.", parsed.filter(function(e){return hasPort(e.raw||"","18091");}).map(function(e){return e.num;}));
  }
  // TLS explicitly disabled
  var tlsOffLines=[];
  parsed.forEach(function(e){ var k=(e.key||"").toLowerCase(); if((k.indexOf("ssl")>=0||k.indexOf("tls")>=0)&&isFalsy(e.value)) tlsOffLines.push(e.num); });
  if(tlsOffLines.length) add("HIGH","tls-disabled","SSL / TLS explicitly disabled","SSL/TLS is set to a disabled / false value on line(s) "+tlsOffLines.join(", ")+". Enable TLS for the admin UI, XDCR, and client traffic.",tlsOffLines.slice());

  // XDCR over http
  var xdcrHttpLines=[];
  parsed.forEach(function(e){
    var low=(e.raw||"").toLowerCase();
    if(low.indexOf("http://")>=0 && (low.indexOf("xdcr")>=0||low.indexOf("remote_cluster")>=0||low.indexOf("remotecluster")>=0||low.indexOf("replication")>=0||(e.key||"").toLowerCase().indexOf("xdcr")>=0)) xdcrHttpLines.push(e.num);
  });
  if(xdcrHttpLines.length) add("HIGH","xdcr-http","XDCR remote cluster over plain HTTP","Line(s) "+xdcrHttpLines.join(", ")+" point XDCR at an http:// remote cluster URL. Replication traffic — including data and credentials — is unencrypted. Use https:// with port 18091 and verify the remote certificate.",xdcrHttpLines.slice());
  var xdcrHttps = parsed.some(function(e){ var low=(e.raw||"").toLowerCase(); return low.indexOf("xdcr")>=0&&low.indexOf("https://")>=0; });
  if(xdcrHttps && !xdcrHttpLines.length) pass("xdcr-https","XDCR uses HTTPS","A parsed XDCR line uses https://.", parsed.filter(function(e){var low=(e.raw||"").toLowerCase();return low.indexOf("xdcr")>=0&&low.indexOf("https://")>=0;}).map(function(e){return e.num;}));

  // Query 8093 / Analytics 8095
  function serviceCheck(port,name,tlsKeys){
    var lines=[];
    parsed.forEach(function(e){ if(hasPort(e.raw||"",port)) lines.push(e.num); });
    if(!lines.length) return;
    var hasTlsAuth = parsed.some(function(e){ var k=(e.key||"").toLowerCase(); var low=(e.raw||"").toLowerCase(); return tlsKeys.some(function(tk){return k.indexOf(tk)>=0;}) && (isTruthy(e.value)||low.indexOf("https")>=0); });
    var plain = lines.some(function(n){ var e=parsed.filter(function(x){return x.num===n;})[0]; var raw=e?e.raw||"":""; return raw.indexOf("http://")>=0||raw.indexOf("0.0.0.0")>=0; });
    if(hasTlsAuth && !plain){ pass(name+"-tls",name+" service not on plain port "+port,"No plain "+port+" exposure with TLS/auth signals present.",lines); return; }
    add(plain?"HIGH":"MEDIUM",name+"-exposed",name+" service port "+port+" exposed without clear TLS / auth","Line(s) "+lines.join(", ")+" reference port "+port+" ("+name+")"+(plain?" over plain http / 0.0.0.0":"")+" with no clear TLS or authentication setting for that service in the pasted text. Use the TLS port, require authentication, and do not expose this service to untrusted networks.",lines.slice());
  }
  serviceCheck("8093","Query",["query_tls","query_ssl","query_auth","query_https"]);
  serviceCheck("8095","Analytics",["analytics_tls","analytics_ssl","analytics_auth","analytics_https"]);

  // Auto-failover
  var foLines=parsed.filter(function(e){return (e.key||"").toLowerCase().indexOf("failover")>=0;});
  var foOff=foLines.filter(function(e){return isFalsy(e.value);});
  var foOn=foLines.filter(function(e){return isTruthy(e.value);});
  if(foOff.length) add("MEDIUM","failover-off","Auto-failover disabled","Auto-failover is set to a disabled / false value on line(s) "+foOff.map(function(e){return e.num;}).join(", ")+". A failed node will not be failed over automatically. Enable auto-failover (with a timeout that suits your cluster size) for production.",foOff.map(function(e){return e.num;}));
  else if(foOn.length) pass("failover-on","Auto-failover enabled","Auto-failover is enabled on line(s) "+foOn.map(function(e){return e.num;}).join(", ")+".",foOn.map(function(e){return e.num;}));
  else if(relevant) add("INFO","failover-unmentioned","Auto-failover not mentioned","No parsed line sets auto-failover. The audit cannot tell whether it is enabled on the live cluster — confirm it in the cluster settings.");

  // Audit logging
  var auLines=parsed.filter(function(e){return (e.key||"").toLowerCase().indexOf("audit")>=0;});
  var auOff=auLines.filter(function(e){return isFalsy(e.value);});
  var auOn=auLines.filter(function(e){return isTruthy(e.value);});
  if(auOff.length) add("MEDIUM","audit-off","Audit logging disabled","Audit logging is set to a disabled / false value on line(s) "+auOff.map(function(e){return e.num;}).join(", ")+". Without audit logs you cannot reconstruct who changed settings or accessed data. Enable auditing for production.",auOff.map(function(e){return e.num;}));
  else if(auOn.length) pass("audit-on","Audit logging enabled","Audit logging is enabled on line(s) "+auOn.map(function(e){return e.num;}).join(", ")+".",auOn.map(function(e){return e.num;}));
  else if(relevant) add("INFO","audit-unmentioned","Audit logging not mentioned","No parsed line sets audit logging. The audit cannot tell whether it is enabled on the live cluster — confirm it in the cluster settings.");

  // Verdict
  var blockers=findings.filter(function(f){return f.severity==="BLOCKER";}).length;
  var highs=findings.filter(function(f){return f.severity==="HIGH";}).length;
  var meds=findings.filter(function(f){return f.severity==="MEDIUM";}).length;
  var verdict;
  if(!parsed.length||!relevant) verdict="NOT ENOUGH TO GRADE";
  else if(blockers>0||highs>=2) verdict="DO NOT DEPLOY";
  else if(highs===1||meds>0) verdict="DEPLOY WITH FIXES";
  else verdict="SAFE TO DEPLOY";

  var order={BLOCKER:0,HIGH:1,MEDIUM:2,LOW:3,INFO:4};
  findings.sort(function(a,b){return order[a.severity]-order[b.severity];});

  return {
    verdict:verdict,
    total: String(text||"").trim()===""?0:rawLines.length,
    parsedCount:parsed.length, commented:commented, notParsed:notParsed, blank:blank,
    findings:findings, passes:passes,
    counts:{blocker:blockers,high:highs,medium:meds,low:findings.filter(function(f){return f.severity==="LOW";}).length,info:findings.filter(function(f){return f.severity==="INFO";}).length,pass:passes.length}
  };
}

function esc(s){ return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;"); }
function linePills(nums){
  if(!nums||!nums.length) return '<span class="small">None</span>';
  return nums.map(function(n){return '<span class="pill">Line '+n+'</span>';}).join("");
}
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-couchbase-server-config-safety-auditortm',
  name: 'J-Dawgs Couchbase Server Config Safety Auditor',
  description: '',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
