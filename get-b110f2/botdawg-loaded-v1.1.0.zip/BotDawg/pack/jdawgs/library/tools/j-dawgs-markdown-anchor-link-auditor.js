'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Markdown Anchor & Link Integrity Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the analyze function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

'use strict';

/* ================= helpers ================= */

function byId(id) { return document.getElementById(id); }

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, function (c) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
  });
}

function normalizeLabel(s) {
  return s.trim().replace(/\s+/g, ' ').toLowerCase();
}

function levenshtein(a, b) {
  var m = a.length, n = b.length, i, j;
  if (!m) return n;
  if (!n) return m;
  var prev = [], cur = [];
  for (j = 0; j <= n; j++) prev[j] = j;
  for (i = 1; i <= m; i++) {
    cur[0] = i;
    for (j = 1; j <= n; j++) {
      var cost = a.charAt(i - 1) === b.charAt(j - 1) ? 0 : 1;
      cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost);
    }
    var t = prev; prev = cur; cur = t;
  }
  return prev[n];
}

/* ================= GitHub slugging =================
   Mirrors github-slugger: rendered heading text -> lowercase ->
   drop everything that is not a letter, number, mark, connector
   punctuation (underscore), hyphen, or space -> spaces to hyphens.
   Duplicates get -1, -2, ... suffixes, skipping names already taken. */

function slugifyBase(plain) {
  return plain.toLowerCase()
    .replace(/[^\p{L}\p{N}\p{M}\p{Pc}\- ]/gu, '')
    .replace(/ /g, '-');
}

function makeSlugger() {
  var occurrences = Object.create(null);
  return function (base) {
    var result = base, original = base;
    while (Object.prototype.hasOwnProperty.call(occurrences, result)) {
      occurrences[original] += 1;
      result = original + '-' + occurrences[original];
    }
    occurrences[result] = 0;
    return result;
  };
}

/* Rendered text of a heading: markup stripped, link/image markup
   replaced by its visible text, inline code kept as its content. */
function headingPlainText(raw) {
  var t = raw;
  t = t.replace(/`+([^`]*)`+/g, '$1');
  t = t.replace(/!\[([^\]]*)\]\([^)]*\)/g, '$1');
  t = t.replace(/!\[([^\]]*)\]\[[^\]]*\]/g, '$1');
  t = t.replace(/\[([^\]]*)\]\([^)]*\)/g, '$1');
  t = t.replace(/\[([^\]]*)\]\[[^\]]*\]/g, '$1');
  t = t.replace(/\[([^\]]*)\]/g, '$1');
  t = t.replace(/<[^>]*>/g, '');
  t = t.replace(/\*\*([^*]+)\*\*/g, '$1');
  t = t.replace(/__([^_]+)__/g, '$1');
  t = t.replace(/\*([^*]+)\*/g, '$1');
  t = t.replace(/(^|[^A-Za-z0-9])_([^_]+)_(?![A-Za-z0-9])/g, '$1$2');
  t = t.replace(/~~([^~]+)~~/g, '$1');
  t = t.replace(/\\([\\`*{}\[\]()#+\-.!_>~|])/g, '$1');
  t = t.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
       .replace(/&quot;/g, '"').replace(/&#0?39;/g, "'");
  return t.replace(/\s+/g, ' ').trim();
}

/* ================= line preprocessing ================= */

/* Remove HTML comment spans from a line, tracking multi-line state.
   Commented-out text is replaced by a space so nothing inside it is
   seen as a heading or a link. */
function stripComments(line, state) {
  var out = '', i = 0, n = line.length;
  while (i < n) {
    if (state.inComment) {
      var end = line.indexOf('-->', i);
      if (end === -1) { i = n; }
      else { state.inComment = false; i = end + 3; out += ' '; }
    } else {
      var start = line.indexOf('<!--', i);
      if (start === -1) { out += line.slice(i); i = n; }
      else { out += line.slice(i, start) + ' '; state.inComment = true; i = start + 4; }
    }
  }
  return out;
}

/* Blank out inline code spans (same length, filler chars) so brackets
   and parens inside code are never mistaken for links. An unmatched
   backtick run is literal text in CommonMark, so it is left alone. */
function stripCodeSpans(line) {
  var out = '', i = 0, n = line.length;
  while (i < n) {
    if (line.charAt(i) === '`') {
      var run = 1;
      while (i + run < n && line.charAt(i + run) === '`') run++;
      var close = -1, j = i + run;
      while (j < n) {
        if (line.charAt(j) === '`') {
          var r2 = 1;
          while (j + r2 < n && line.charAt(j + r2) === '`') r2++;
          if (r2 === run) { close = j; break; }
          j += r2;
        } else { j++; }
      }
      if (close === -1) { out += line.slice(i); break; }
      var spanLen = close + run - i, filler = '';
      for (var k = 0; k < spanLen; k++) filler += 'x';
      out += filler;
      i = close + run;
    } else {
      out += line.charAt(i);
      i++;
    }
  }
  return out;
}

/* ================= the audit ================= */

function analyze(md) {
  var lines = md.split(/\r\n|\r|\n/);
  var headings = [];
  var slugger = makeSlugger();
  var anchorSet = new Set();
  var baseGroups = Object.create(null);
  var defs = Object.create(null);
  var defList = [];
  var scannable = []; // per line: cleaned text to scan for links, or null

  var inFront = false;
  var fence = null;
  var commentState = { inComment: false };
  var prevPara = null;

  function addHeading(level, rawText, lineNo) {
    var plain = headingPlainText(rawText);
    var base = slugifyBase(plain);
    var slug = slugger(base);
    var h = { level: level, plain: plain, slug: slug, base: base, line: lineNo };
    headings.push(h);
    anchorSet.add(slug);
    if (!baseGroups[base]) baseGroups[base] = [];
    baseGroups[base].push(h);
    return h;
  }

  /* ---- pass 1: structure — front matter, fences, headings, definitions ---- */
  for (var idx = 0; idx < lines.length; idx++) {
    var raw = lines[idx], lineNo = idx + 1;
    scannable.push(null);

    if (idx === 0 && /^---[ \t]*$/.test(raw)) { inFront = true; continue; }
    if (inFront) {
      if (/^(---|\.\.\.)[ \t]*$/.test(raw)) inFront = false;
      continue;
    }
    if (fence) {
      var closeM = /^ {0,3}(`{3,}|~{3,})[ \t]*$/.exec(raw);
      if (closeM && closeM[1].charAt(0) === fence.char && closeM[1].length >= fence.len) fence = null;
      continue;
    }

    var cleaned = stripComments(raw, commentState);

    var fenceM = /^ {0,3}(`{3,}|~{3,})(.*)$/.exec(cleaned);
    if (fenceM && !(fenceM[1].charAt(0) === '`' && fenceM[2].indexOf('`') !== -1)) {
      fence = { char: fenceM[1].charAt(0), len: fenceM[1].length };
      prevPara = null;
      continue;
    }

    var defM = /^ {0,3}\[([^\]]+)\]:[ \t]*(<[^>]*>|\S+)/.exec(cleaned);
    if (defM && defM[1].charAt(0) !== '^') {
      var norm = normalizeLabel(defM[1]);
      if (!defs[norm]) {
        var dest = defM[2];
        if (dest.charAt(0) === '<') dest = dest.slice(1, -1);
        var def = { label: defM[1].trim(), norm: norm, dest: dest, line: lineNo, used: false };
        defs[norm] = def;
        defList.push(def);
      }
      prevPara = null;
      continue;
    }

    var atxM = /^ {0,3}(#{1,6})(?:[ \t]+(.*))?$/.exec(cleaned);
    if (atxM) {
      var htext = (atxM[2] || '').replace(/[ \t]+#+[ \t]*$/, '');
      if (/^#+$/.test(htext.trim())) htext = '';
      addHeading(atxM[1].length, htext, lineNo);
      scannable[idx] = cleaned;
      prevPara = null;
      continue;
    }

    var setextM = /^ {0,3}(=+|-+)[ \t]*$/.exec(cleaned);
    if (setextM && prevPara) {
      addHeading(setextM[1].charAt(0) === '=' ? 1 : 2, prevPara.text, prevPara.line);
      prevPara = null;
      continue;
    }

    scannable[idx] = cleaned;

    var trimmed = cleaned.trim();
    if (trimmed === '') { prevPara = null; continue; }
    var isPara = !/^ {0,3}([-*+]|\d{1,9}[.)])[ \t]/.test(cleaned)
      && cleaned.trim().charAt(0) !== '>'
      && cleaned.trim().charAt(0) !== '|'
      && cleaned.trim().charAt(0) !== '<'
      && !/^ {0,3}([-*_])([ \t]*\1){2,}[ \t]*$/.test(cleaned);
    prevPara = isPara ? { text: cleaned, line: lineNo } : null;
  }

  /* ---- pass 2: links, references, images ---- */
  var ctx = {
    defs: defs,
    anchorSet: anchorSet,
    headings: headings,
    brokenAnchors: [],
    undefinedRefs: [],
    emptyLinkText: [],
    missingAlt: [],
    relativeLinks: [],
    externalCount: 0,
    anchorLinksChecked: 0
  };

  function nearestAnchor(target) {
    var best = null, bestD = Infinity;
    for (var i = 0; i < headings.length; i++) {
      var d = levenshtein(String(target).toLowerCase(), headings[i].slug);
      if (d < bestD) { bestD = d; best = headings[i].slug; }
    }
    return best;
  }

  function classifyDest(dest, lineNo) {
    if (!dest) return;
    if (dest.charAt(0) === '#') {
      var target = dest.slice(1);
      if (target === '') { ctx.anchorLinksChecked++; return; }
      ctx.anchorLinksChecked++;
      var decoded = target;
      try { decoded = decodeURIComponent(target); } catch (e) { /* keep raw */ }
      if (!ctx.anchorSet.has(target) && !ctx.anchorSet.has(decoded)) {
        ctx.brokenAnchors.push({ line: lineNo, target: target, suggestion: nearestAnchor(decoded) });
      }
      return;
    }
    if (/^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(dest) || dest.indexOf('//') === 0) {
      ctx.externalCount++;
      return;
    }
    ctx.relativeLinks.push({ line: lineNo, dest: dest });
  }

  function handleInline(isImg, text, dest, lineNo) {
    if (isImg) {
      if (text.trim() === '') ctx.missingAlt.push({ line: lineNo, src: dest || '(no source)' });
      return;
    }
    if (text.trim() === '') ctx.emptyLinkText.push({ line: lineNo, dest: dest || '(empty destination)' });
    classifyDest(dest, lineNo);
  }

  function handleRef(isImg, text, labelRaw, lineNo) {
    var labelText = labelRaw.trim() === '' ? text : labelRaw;
    var def = ctx.defs[normalizeLabel(labelText)];
    if (isImg) {
      if (text.trim() === '') {
        ctx.missingAlt.push({ line: lineNo, src: def ? def.dest : '(unresolved reference)' });
      }
      if (def) { def.used = true; }
      else { ctx.undefinedRefs.push({ line: lineNo, text: text, label: labelText, image: true }); }
      return;
    }
    if (text.trim() === '') {
      ctx.emptyLinkText.push({ line: lineNo, dest: def ? def.dest : '[' + labelText + ']' });
    }
    if (!def) {
      ctx.undefinedRefs.push({ line: lineNo, text: text, label: labelText, image: false });
      return;
    }
    def.used = true;
    classifyDest(def.dest, lineNo);
  }

  function handleShortcut(isImg, text, lineNo) {
    var def = ctx.defs[normalizeLabel(text)];
    if (!def) return;
    if (isImg) {
      if (text.trim() !== '') def.used = true;
      return;
    }
    def.used = true;
    classifyDest(def.dest, lineNo);
  }

  function findClosingBracket(s, openIdx) {
    var depth = 0, i = openIdx;
    while (i < s.length) {
      var c = s.charAt(i);
      if (c === '\\') { i += 2; continue; }
      if (c === '[') depth++;
      else if (c === ']') { depth--; if (depth === 0) return i; }
      i++;
    }
    return -1;
  }

  function scanHtmlImages(s, lineNo) {
    var re = /<img\b[^>]*>/gi, m;
    while ((m = re.exec(s)) !== null) {
      var tag = m[0];
      var altM = /\balt\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/i.exec(tag);
      var altVal = null;
      if (altM) altVal = altM[1] !== undefined ? altM[1] : (altM[2] !== undefined ? altM[2] : altM[3]);
      if (altVal === null || altVal.trim() === '') {
        var srcM = /\bsrc\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/i.exec(tag);
        var src = '(HTML img tag)';
        if (srcM) src = srcM[1] !== undefined ? srcM[1] : (srcM[2] !== undefined ? srcM[2] : srcM[3]);
        ctx.missingAlt.push({ line: lineNo, src: src });
      }
    }
  }

  function scanLine(s, lineNo) {
    var i = 0, n = s.length;
    while (i < n) {
      var isImg = false, open = -1;
      if (s.charAt(i) === '!' && s.charAt(i + 1) === '[') { isImg = true; open = i + 1; }
      else if (s.charAt(i) === '[') { open = i; }
      else if (s.charAt(i) === '\\') { i += 2; continue; }
      if (open === -1) { i++; continue; }
      var close = findClosingBracket(s, open);
      if (close === -1) { i = open + 1; continue; }
      var text = s.slice(open + 1, close);
      var j = close + 1;
      if (s.charAt(j) === '(') {
        var k = j + 1;
        while (k < n && (s.charAt(k) === ' ' || s.charAt(k) === '\t')) k++;
        var dest = '';
        if (s.charAt(k) === '<') {
          var e = s.indexOf('>', k);
          if (e === -1) { i = j + 1; continue; }
          dest = s.slice(k + 1, e);
          k = e + 1;
        } else {
          var start = k, depth = 0;
          while (k < n) {
            var c = s.charAt(k);
            if (c === '\\') { k += 2; continue; }
            if (c === '(') depth++;
            else if (c === ')') { if (depth === 0) break; depth--; }
            else if ((c === ' ' || c === '\t') && depth === 0) break;
            k++;
          }
          dest = s.slice(start, k);
        }
        handleInline(isImg, text, dest, lineNo);
        i = k;
        continue;
      }
      if (s.charAt(j) === '[') {
        var close2 = findClosingBracket(s, j);
        if (close2 === -1) { i = j; continue; }
        handleRef(isImg, text, s.slice(j + 1, close2), lineNo);
        i = close2 + 1;
        continue;
      }
      handleShortcut(isImg, text, lineNo);
      i = close + 1;
    }
  }

  for (var s2 = 0; s2 < lines.length; s2++) {
    if (scannable[s2] === null) continue;
    var stripped = stripCodeSpans(scannable[s2]);
    scanHtmlImages(stripped, s2 + 1);
    scanLine(stripped, s2 + 1);
  }

  /* ---- duplicates & unused ---- */
  var duplicates = [];
  Object.keys(baseGroups).forEach(function (base) {
    var g = baseGroups[base];
    if (g.length > 1) duplicates.push({ text: g[0].plain, group: g });
  });
  var unusedRefs = defList.filter(function (d) { return !d.used; });

  return {
    lineCount: lines.length,
    headings: headings,
    brokenAnchors: ctx.brokenAnchors,
    undefinedRefs: ctx.undefinedRefs,
    unusedRefs: unusedRefs,
    emptyLinkText: ctx.emptyLinkText,
    missingAlt: ctx.missingAlt,
    relativeLinks: ctx.relativeLinks,
    externalCount: ctx.externalCount,
    anchorLinksChecked: ctx.anchorLinksChecked,
    duplicates: duplicates
  };
}
  return { "analyze": (typeof analyze !== 'undefined' ? analyze : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["analyze"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-markdown-anchor-link-auditor',
  name: 'J-Dawgs Markdown Anchor & Link Integrity Auditor',
  description: '',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["analyze"]) return { ok: false, output: null, summary: 'Extracted core has no analyze function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
