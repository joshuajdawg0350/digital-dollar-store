'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs OpenDKIM Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

  "use strict";

  var RISKY = [
    "# Risky example — a config that boots fine and is dangerous anyway.",
    "# Load it, audit it: it must grade DO NOT RUN.",
    "Syslog No",
    "Mode v",
    "Socket inet:8891@0.0.0.0",
    "RequireSafeKeys No",
    "Canonicalization relaxed/relaxed",
    "SignatureAlgorithm rsa-sha1",
    "PrivateKey /etc/opendkim/keys/default.private",
    "Domain example.com",
    "Selector default",
    "TestSecretKey PLANTED-FAKE-SECRET-a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4"
  ].join("\n");

  var HARDENED = [
    "# Hardened example — load it, audit it: it must grade SAFE TO RUN.",
    "Syslog Yes",
    "SyslogSuccess Yes",
    "LogWhy Yes",
    "Mode sv",
    "Socket local:/run/opendkim/opendkim.sock",
    "PidFile /run/opendkim/opendkim.pid",
    "BaseDirectory /run/opendkim",
    "RequireSafeKeys Yes",
    "KeyTable refile:/etc/opendkim/KeyTable",
    "SigningTable refile:/etc/opendkim/SigningTable",
    "ExternalIgnoreList refile:/etc/opendkim/TrustedHosts",
    "TrustedHosts /etc/opendkim/TrustedHosts",
    "Canonicalization simple/simple",
    "SignatureAlgorithm rsa-sha256",
    "MinimumKeyBits 2048",
    "OversignHeaders From"
  ].join("\n");

  var KNOWN = {
    Mode:1, Socket:1, RequireSafeKeys:1, KeyTable:1, SigningTable:1, TrustedHosts:1,
    ExternalIgnoreList:1, InternalHosts:1, Canonicalization:1, SignatureAlgorithm:1,
    MinimumKeyBits:1, Syslog:1, SyslogSuccess:1, LogWhy:1, PidFile:1, BaseDirectory:1,
    OversignHeaders:1, PrivateKey:1, KeyFile:1, Domain:1, Selector:1, UserID:1, UMask:1,
    MTA:1, Nameservers:1, TemporaryDirectory:1, MaximumSignedBytes:1, SignHeaders:1,
    PeerList:1, "On-Default":1, "On-BadAddress":1, "On-BadDomain":1, "On-NoSignature":1,
    "On-MissingFrom":1, AutoRestart:1, AutoRestartRate:1, Background:1, DNSTimeout:1,
    SignatureTTL:1, ClockDrift:1, SubDomains:1, DomainKeysCompat:1, BodyLengthDB:1,
    DiagnosticsDirectoryDB:1, FixCRLF:1, KeepTemporaryFiles:1, MilterDebug:1,
    MultipleSignatures:1, OversignDB:1, Quarantine:1, RemoveARAll:1, RemoveARFrom:1,
    RemoveOldSignatures:1, ReportAddress:1, ReportBccAddress:1, ResignAll:1,
    ResolvConf:1, SenderHeaders:1, SignatureDomainHeader:1, StrictHeaders:1,
    TestAddress:1, TestMode:1, TrustAnchorFile:1, UnprotectedPolicy:1, VBR:1
  };
  var CHECKED = { Mode:1, Socket:1, RequireSafeKeys:1, KeyTable:1, SigningTable:1,
    TrustedHosts:1, ExternalIgnoreList:1, Canonicalization:1, SignatureAlgorithm:1,
    MinimumKeyBits:1, Syslog:1, SyslogSuccess:1, LogWhy:1, PidFile:1, BaseDirectory:1,
    OversignHeaders:1, PrivateKey:1 };

  var NOT_CHECKED = [
    "Actual permissions and ownership of key files on disk (paths in text only; the files are never read).",
    "The DNS DKIM public-key record for each selector, and whether it matches the private key in use.",
    "Contents of referenced KeyTable, SigningTable, TrustedHosts, or ExternalIgnoreList files.",
    "Whether opendkim actually starts and stays up with this config on the host.",
    "Whether the MTA restricts which local processes may reach the milter socket.",
    "Host firewall rules and any other service that could expose the socket."
  ];

  var el = function(id){ return document.getElementById(id); };
  var detectedSecrets = []; // raw strings, held only in memory for scrubbing + containment count

  function isTrue(v){ return /^(yes|true|on|1)$/i.test(String(v).trim()); }
  function isFalse(v){ return /^(no|false|off|0)$/i.test(String(v).trim()); }
  function isBool(v){ return isTrue(v) || isFalse(v); }

  function scrub(text){
    var out = String(text);
    for (var i = 0; i < detectedSecrets.length; i++){
      var s = detectedSecrets[i];
      if (s && out.indexOf(s) !== -1){
        out = out.split(s).join("[REDACTED — " + s.length + " chars]");
      }
    }
    return out;
  }
  function countOccurrences(haystack){
    var n = 0;
    for (var i = 0; i < detectedSecrets.length; i++){
      var s = detectedSecrets[i];
      if (!s) continue;
      var idx = 0;
      while ((idx = haystack.indexOf(s, idx)) !== -1){ n++; idx += Math.max(1, s.length); }
    }
    return n;
  }

  function detectSecretsInLine(lineText, directiveName, value){
    var found = [];
    if (/BEGIN [A-Z ]*PRIVATE KEY/i.test(lineText)){
      found.push({ kind:"key-block", token: lineText.trim() });
    }
    var tokens = String(value || "").split(/[\s,;]+/);
    for (var i = 0; i < tokens.length; i++){
      var t = tokens[i];
      if (t.length >= 40 && /^[A-Za-z0-9+/=_-]+$/.test(t)){
        found.push({ kind:"long-token", token: t });
      }
    }
    if (directiveName && /secret|password|passwd|apikey|api_key|token/i.test(directiveName)){
      var v = String(value || "").trim();
      if (v.length >= 8){ found.push({ kind:"named-secret", token: v }); }
    }
    return found;
  }

  function parse(text){
    var lines = String(text).split(/\r?\n/);
    var directives = {};   // name -> [{value, line}]
    var order = [];
    var notParsed = [];    // line numbers
    var secrets = [];      // [{line, directive, length, kind}]
    var knownCount = 0;

    function addDirective(name, value, lineNo){
      if (!directives[name]){ directives[name] = []; order.push(name); }
      directives[name].push({ value: value, line: lineNo });
      if (KNOWN[name]) knownCount++;
    }

    for (var i = 0; i < lines.length; i++){
      var lineNo = i + 1;
      var raw = lines[i];
      var t = raw.trim();
      if (t === "" ) continue;
      if (t.charAt(0) === "#" || t.charAt(0) === ";") continue;
      if (/^\[.*\]\s*$/.test(t)){ notParsed.push(lineNo); continue; }

      var candidate = t.replace(/^-\s+/, "").replace(/^["']|["']$/g, "");
      var m = candidate.match(/^([A-Za-z][A-Za-z0-9-]*)\s+(.+)$/);
      if (m && m[2].charAt(0) !== "="){
        var name = m[1], value = m[2].trim();
        var sec = detectSecretsInLine(t, name, value);
        var seenTokens = {};
        for (var s = 0; s < sec.length; s++){
          if (seenTokens[sec[s].token]) continue;
          seenTokens[sec[s].token] = 1;
          secrets.push({ line: lineNo, directive: name, length: sec[s].token.length, kind: sec[s].kind });
          if (detectedSecrets.indexOf(sec[s].token) === -1) detectedSecrets.push(sec[s].token);
        }
        addDirective(name, value, lineNo);
      } else {
        // Try "Name=value" style used inside some fragments.
        var m2 = candidate.match(/^([A-Za-z][A-Za-z0-9-]*)=(.+)$/);
        if (m2 && KNOWN[m2[1]]){
          addDirective(m2[1], m2[2].trim(), lineNo);
        } else {
          notParsed.push(lineNo);
        }
      }
    }
    return { directives: directives, order: order, notParsed: notParsed, secrets: secrets, knownCount: knownCount, totalLines: lines.length };
  }

  function get(directives, name){
    var arr = directives[name];
    return (arr && arr.length) ? arr[0] : null;
  }

  function audit(text, intent){
    detectedSecrets = [];
    var parsed = parse(text);
    var d = parsed.directives;
    var findings = [];
    function add(sev, line, directive, detail, fix){
      findings.push({ severity: sev, line: (line == null ? null : line), directive: directive, detail: scrub(detail), fix: fix ? scrub(fix) : "" });
    }

    if (String(text).trim() === ""){
      return { gradeable:false, reason:"The paste is empty — there is nothing to audit.", parsed: parsed, findings: findings };
    }
    if (parsed.knownCount < 2){
      return { gradeable:false, reason:"Only " + parsed.knownCount + " recognizable OpenDKIM directive(s) were found. This does not look like an opendkim.conf (or a fragment containing one), so there is not enough to grade.", parsed: parsed, findings: findings };
    }

    var signing = intent.indexOf("s") !== -1;
    var verifying = intent.indexOf("v") !== -1;

    // Duplicate directives
    parsed.order.forEach(function(name){
      if (parsed.directives[name].length > 1){
        add("WARNING", parsed.directives[name][1].line, name,
          name + " appears " + parsed.directives[name].length + " times. OpenDKIM uses one value and ignores or overrides the rest, so the running behaviour may not be the line you are reading.",
          "Keep exactly one " + name + " line.");
      }
    });

    // Secrets first — blockers.
    parsed.secrets.forEach(function(s){
      add("BLOCKER", s.line, s.directive,
        "Plaintext secret-looking material sits in the config on this line (value length: " + s.length + " characters). The value itself is never shown by this audit. Key material and secrets do not belong inside opendkim.conf — anyone who can read the file owns the key.",
        "Remove the value from the config, put key material in a separate key file with owner-only permissions, and rotate anything that was pasted — treat it as exposed.");
    });

    // Mode
    var mode = get(d, "Mode");
    if (!mode){
      add("WARNING", null, "Mode",
        "Mode is not set. The milter falls back to its compiled default instead of the behaviour you stated (" + intentLabel(intent) + "), so signing/verification coverage is whatever the build chose.",
        "Set Mode explicitly to " + intent + ".");
    } else {
      var mv = mode.value.toLowerCase().replace(/[^sv]/g, "");
      if (mv === intent){
        add("PASS", mode.line, "Mode",
          "Mode is '" + mode.value + "', matching the stated intent (" + intentLabel(intent) + ").",
          "");
      } else {
        var missing = [];
        if (signing && mv.indexOf("s") === -1) missing.push("signing");
        if (verifying && mv.indexOf("v") === -1) missing.push("verification");
        var extra = [];
        if (!signing && mv.indexOf("s") !== -1) extra.push("signing");
        if (!verifying && mv.indexOf("v") !== -1) extra.push("verification");
        if (missing.length){
          add("BLOCKER", mode.line, "Mode",
            "Mode is '" + mode.value + "' but the stated intent is " + intentLabel(intent) + ". Missing: " + missing.join(" and ") + ". The milter will boot and look healthy while that job silently never happens.",
            "Set Mode to " + intent + ".");
        } else if (extra.length){
          add("WARNING", mode.line, "Mode",
            "Mode is '" + mode.value + "' — it also does " + extra.join(" and ") + ", beyond the stated intent (" + intentLabel(intent) + "). Extra coverage is easy to forget you are running.",
            "Set Mode to " + intent + " if the extra work is not intended.");
        }
      }
    }

    // Socket
    var sock = get(d, "Socket");
    if (!sock){
      add("WARNING", null, "Socket",
        "Socket is not set. The milter falls back to a default socket that may not be the one your MTA is configured to use.",
        "Set Socket explicitly, and prefer a local unix socket or a loopback inet socket.");
    } else {
      var sv = sock.value.trim();
      if (/^(local|unix):/i.test(sv)){
        add("PASS", sock.line, "Socket",
          "Socket is a local filesystem socket (" + sv + "). Only processes on this host with filesystem access to it can reach the milter.",
          "");
      } else if (/^inet6?:/i.test(sv)){
        var mm = sv.match(/^inet6?:(\d+)@(.+)$/i);
        var host = mm ? mm[2].trim() : "";
        if (!mm || host === "" ){
          add("BLOCKER", sock.line, "Socket",
            "Socket '" + sv + "' names no bind address, so the milter listens on every interface. Anything that can route to this host can reach the signing milter.",
            "Bind to loopback (inet:8891@127.0.0.1) or switch to a local unix socket.");
        } else if (host === "0.0.0.0" || host === "::" || host === "[::]"){
          add("BLOCKER", sock.line, "Socket",
            "Socket '" + sv + "' binds to all interfaces. The milter is reachable from anywhere that can route to this host — an exposed signing oracle and an attack surface.",
            "Bind to loopback (inet:8891@127.0.0.1) or switch to a local unix socket (local:/run/opendkim/opendkim.sock).");
        } else if (host === "127.0.0.1" || host === "localhost" || host === "::1" || host === "[::1]"){
          add("PASS", sock.line, "Socket",
            "Socket '" + sv + "' binds to loopback only. Remote hosts cannot reach the milter directly.",
            "");
        } else {
          add("WARNING", sock.line, "Socket",
            "Socket '" + sv + "' binds to a specific non-loopback address (" + host + "). Every host that can reach that interface can reach the milter.",
            "Confirm that interface is private and firewalled, or move the socket to loopback / a local unix socket.");
        }
      } else {
        add("INFO", sock.line, "Socket",
          "Socket value '" + sv + "' is not a format this audit recognizes (expected local:, unix:, or inet:port@host). It was not graded further.",
          "Confirm the socket format against the OpenDKIM documentation.");
      }
    }

    // RequireSafeKeys
    var rsk = get(d, "RequireSafeKeys");
    var pk = get(d, "PrivateKey");
    if (!rsk){
      add("WARNING", null, "RequireSafeKeys",
        "RequireSafeKeys is not set. Without it, opendkim does not refuse to load a private key whose file permissions are too open.",
        "Set RequireSafeKeys Yes.");
    } else if (isTrue(rsk.value)){
      add("PASS", rsk.line, "RequireSafeKeys",
        "RequireSafeKeys is on. The milter refuses key files whose permissions are too permissive.",
        "");
    } else if (isFalse(rsk.value)){
      add("BLOCKER", rsk.line, "RequireSafeKeys",
        "RequireSafeKeys is off" + (pk ? ", and a PrivateKey path is configured" : "") + ". Nothing stops the milter from loading a private key that other users on the host can read — a readable DKIM key is a forgeable domain.",
        "Set RequireSafeKeys Yes and restrict key files to the opendkim user (for example mode 600).");
    } else {
      add("INFO", rsk.line, "RequireSafeKeys",
        "RequireSafeKeys value '" + rsk.value + "' is not a recognized yes/no value and was not graded further.", "Use Yes or No.");
    }

    // PrivateKey (legacy single-key) posture
    if (pk){
      add(signing ? "WARNING" : "INFO", pk.line, "PrivateKey",
        "A bare PrivateKey path is configured (value not shown). That is the legacy single-key setup: one key, no per-domain separation, and its safety rests entirely on that file's permissions — which a paste cannot prove.",
        "Prefer KeyTable + SigningTable so keys are selected per domain/selector, and keep RequireSafeKeys on.");
    }

    // KeyTable / SigningTable
    var kt = get(d, "KeyTable"), st = get(d, "SigningTable");
    if (signing){
      if (kt && st){
        add("PASS", kt.line, "KeyTable",
          "KeyTable and SigningTable are both configured (SigningTable on line " + st.line + "). Key selection is separated from signing policy, which is the maintainable setup.",
          "");
      } else if (!kt && !st && !pk){
        add("BLOCKER", null, "KeyTable",
          "Signing is intended, but there is no KeyTable, no SigningTable, and no PrivateKey — the milter has no key to sign with.",
          "Configure KeyTable and SigningTable (or, for a single domain, Domain + Selector + KeyFile/PrivateKey).");
      } else if (!kt){
        add("WARNING", null, "KeyTable",
          "Signing is intended but no KeyTable is set. Without a KeyTable there is no per-selector key separation.",
          "Add a KeyTable mapping selectors to key files.");
      } else if (!st){
        add("WARNING", kt.line, "KeyTable",
          "KeyTable is set but SigningTable is missing, so which senders get signed falls back to defaults instead of an explicit table.",
          "Add a SigningTable that states exactly which From domains/addresses are signed.");
      }
    } else {
      if (kt || st){
        add("INFO", (kt || st).line, kt ? "KeyTable" : "SigningTable",
          "Key/signing tables are configured although the stated intent is verify-only. Harmless, but unused signing configuration is configuration nobody maintains.",
          "Remove signing tables if this host will never sign.");
      } else {
        add("INFO", null, "KeyTable",
          "No KeyTable/SigningTable — expected for a verify-only milter.", "");
      }
    }

    // TrustedHosts / ExternalIgnoreList
    var th = get(d, "TrustedHosts"), eil = get(d, "ExternalIgnoreList");
    if (th){
      add("PASS", th.line, "TrustedHosts", "TrustedHosts is configured, so the set of trusted/internal hosts is stated explicitly.", "");
    } else {
      add(signing ? "WARNING" : "INFO", null, "TrustedHosts",
        "TrustedHosts is not set. The milter has no explicit list of internal/trusted hosts, so trust decisions fall back to defaults.",
        "Add TrustedHosts listing your internal hosts (commonly 127.0.0.1, ::1, and your own hostnames).");
    }
    if (eil){
      add("PASS", eil.line, "ExternalIgnoreList", "ExternalIgnoreList is configured, so hosts that are never treated as internal are named explicitly.", "");
    } else if (signing){
      add("WARNING", null, "ExternalIgnoreList",
        "ExternalIgnoreList is not set while signing is intended. Without it — and with permissive signing tables — a milter can end up signing for hosts it should treat as strangers: open-relay-style signing for arbitrary senders.",
        "Set ExternalIgnoreList (it commonly points at the same file as TrustedHosts) and keep SigningTable entries explicit.");
    } else {
      add("INFO", null, "ExternalIgnoreList", "ExternalIgnoreList is not set — lower stakes on a verify-only milter, but worth setting for completeness.", "Set ExternalIgnoreList to your trusted-hosts file.");
    }

    // Canonicalization
    var can = get(d, "Canonicalization");
    if (!can){
      add("INFO", null, "Canonicalization",
        "Canonicalization is not set, so the compiled default applies. Defaults are survivable but invisible — set it so the next reader knows the choice was deliberate.",
        "Set Canonicalization simple/simple for the strictest handling.");
    } else {
      var parts = can.value.toLowerCase().split("/");
      var head = parts[0].trim(), body = (parts[1] || parts[0]).trim();
      if (head === "relaxed" && body === "relaxed"){
        add("WARNING", can.line, "Canonicalization",
          "Canonicalization is relaxed/relaxed. Relaxed body handling tolerates content changes in transit — the most forgiving, and therefore weakest, combination.",
          "Use simple/simple unless a specific sending path genuinely breaks under it, and document why if you keep relaxed.");
      } else if (head === "relaxed" || body === "relaxed"){
        add("INFO", can.line, "Canonicalization",
          "Canonicalization is " + can.value + " — one half is relaxed, which tolerates some in-transit modification of that half.",
          "simple/simple is the strictest option if your sending paths allow it.");
      } else {
        add("PASS", can.line, "Canonicalization",
          "Canonicalization is " + can.value + " — the strict setting; signatures break if the signed content is altered.",
          "");
      }
    }

    // SignatureAlgorithm
    var alg = get(d, "SignatureAlgorithm");
    if (!alg){
      add("INFO", null, "SignatureAlgorithm",
        "SignatureAlgorithm is not set, so the compiled default applies.",
        "Set it explicitly (rsa-sha256 or ed25519-sha256).");
    } else if (/sha1/i.test(alg.value)){
      add("BLOCKER", alg.line, "SignatureAlgorithm",
        "SignatureAlgorithm is '" + alg.value + "', which uses SHA-1. SHA-1 signatures are deprecated and rejected or distrusted by modern verifiers.",
        "Use rsa-sha256 or ed25519-sha256 (and publish the matching DNS record).");
    } else if (/^(rsa-sha256|ed25519-sha256)$/i.test(alg.value.trim())){
      add("PASS", alg.line, "SignatureAlgorithm",
        "SignatureAlgorithm is " + alg.value + " — a current, accepted algorithm.", "");
    } else {
      add("INFO", alg.line, "SignatureAlgorithm",
        "SignatureAlgorithm value '" + alg.value + "' is not one this audit grades (expected rsa-sha256 or ed25519-sha256).", "Confirm it is a currently accepted algorithm.");
    }

    // MinimumKeyBits
    var mkb = get(d, "MinimumKeyBits");
    if (!mkb){
      add("INFO", null, "MinimumKeyBits",
        "MinimumKeyBits is not set, so no floor on RSA key size is enforced by the config.",
        "Set MinimumKeyBits 2048.");
    } else {
      var bits = parseInt(mkb.value, 10);
      if (isNaN(bits)){
        add("INFO", mkb.line, "MinimumKeyBits", "MinimumKeyBits value '" + mkb.value + "' is not a number and was not graded further.", "Use a number such as 2048.");
      } else if (bits < 1024){
        add("BLOCKER", mkb.line, "MinimumKeyBits", "MinimumKeyBits is " + bits + " — far below any safe RSA key size. Keys that small are factorable.", "Set MinimumKeyBits 2048.");
      } else if (bits < 2048){
        add("WARNING", mkb.line, "MinimumKeyBits", "MinimumKeyBits is " + bits + ". That permits keys below the current 2048-bit norm.", "Set MinimumKeyBits 2048.");
      } else {
        add("PASS", mkb.line, "MinimumKeyBits", "MinimumKeyBits is " + bits + " — at or above the current 2048-bit norm.", "");
      }
    }

    // Syslog / SyslogSuccess / LogWhy
    var sys = get(d, "Syslog");
    if (!sys){
      add("INFO", null, "Syslog", "Syslog is not set explicitly. Logging posture should be a decision, not an accident.", "Set Syslog Yes.");
    } else if (isFalse(sys.value)){
      add("WARNING", sys.line, "Syslog",
        "Syslog is off. Signing and verification failures will leave little or no trace — a broken milter looks exactly like a quiet one.",
        "Set Syslog Yes so failures are visible in the mail log.");
    } else if (isTrue(sys.value)){
      add("PASS", sys.line, "Syslog", "Syslog is on — milter activity and failures land in the system log.", "");
    }
    var syss = get(d, "SyslogSuccess");
    if (syss && isTrue(syss.value)){
      add("PASS", syss.line, "SyslogSuccess", "SyslogSuccess is on — successful operations are logged too, so 'working' is provable, not assumed.", "");
    } else if (syss && isFalse(syss.value)){
      add("INFO", syss.line, "SyslogSuccess", "SyslogSuccess is off — failures log, successes do not. Reasonable, but absence of errors is then your only health signal.", "");
    } else if (!syss){
      add("INFO", null, "SyslogSuccess", "SyslogSuccess is not set; successful operations may not be logged.", "Set SyslogSuccess Yes if you want positive proof of signing in the log.");
    }
    var lw = get(d, "LogWhy");
    if (lw && isTrue(lw.value)){
      add("PASS", lw.line, "LogWhy", "LogWhy is on — log entries explain why each message was or was not signed/verified.", "");
    } else if (lw && isFalse(lw.value)){
      add("INFO", lw.line, "LogWhy", "LogWhy is off — the log records outcomes without reasons, which makes debugging slower.", "Consider LogWhy Yes.");
    }

    // PidFile / BaseDirectory
    var pid = get(d, "PidFile");
    if (!pid){
      add("INFO", null, "PidFile", "PidFile is not set; the pid-file location falls back to defaults, which can collide with packaged service scripts.", "Set PidFile under a runtime directory (for example /run/opendkim/opendkim.pid).");
    } else if (/^\/(tmp|var\/tmp)\//.test(pid.value.trim())){
      add("WARNING", pid.line, "PidFile", "PidFile points into a world-writable temp directory (" + pid.value + "). A pid file in shared space can be pre-created or replaced by another user.", "Move PidFile under /run/opendkim/ with opendkim ownership.");
    } else {
      add("PASS", pid.line, "PidFile", "PidFile is " + pid.value + " — a dedicated runtime location, not shared temp space.", "");
    }
    var bd = get(d, "BaseDirectory");
    if (!bd){
      add("INFO", null, "BaseDirectory", "BaseDirectory is not set; runtime files land wherever the defaults put them.", "Set BaseDirectory to the same runtime directory as PidFile (for example /run/opendkim).");
    } else if (/^\/(tmp|var\/tmp)(\/|$)/.test(bd.value.trim())){
      add("WARNING", bd.line, "BaseDirectory", "BaseDirectory is a world-writable temp directory (" + bd.value + "). Runtime state there can be tampered with by other users.", "Move BaseDirectory under /run/opendkim/ with opendkim ownership.");
    } else {
      add("PASS", bd.line, "BaseDirectory", "BaseDirectory is " + bd.value + " — a dedicated directory, not shared temp space.", "");
    }

    // OversignHeaders
    var osh = get(d, "OversignHeaders");
    if (osh){
      add("PASS", osh.line, "OversignHeaders", "OversignHeaders is set (" + osh.value + "). Oversigning stops a later header being added under cover of your signature.", "");
    } else if (signing){
      add("WARNING", null, "OversignHeaders",
        "OversignHeaders is not set while signing is intended. Without oversigning, an attacker can append an extra copy of a signed header (a second From:, for instance) and the signature still verifies.",
        "Set OversignHeaders From (and any other header your mail must never gain a second copy of).");
    } else {
      add("INFO", null, "OversignHeaders", "OversignHeaders is not set — only relevant to hosts that sign.", "");
    }

    // Recognized but not graded directives
    parsed.order.forEach(function(name){
      if (KNOWN[name] && !CHECKED[name]){
        var rec = parsed.directives[name][0];
        add("INFO", rec.line, name, name + " is a recognized OpenDKIM directive. This audit notes its presence but does not grade its value.", "");
      }
      if (!KNOWN[name]){
        var rec2 = parsed.directives[name][0];
        add("INFO", rec2.line, name, "'" + name + "' is not a directive this audit recognizes. If it is a typo of a real directive, opendkim may reject or ignore the line — either way the intent is lost.", "Check the spelling against the OpenDKIM configuration documentation.");
      }
    });

    var counts = { BLOCKER:0, WARNING:0, INFO:0, PASS:0 };
    findings.forEach(function(f){ counts[f.severity]++; });
    var verdict = counts.BLOCKER > 0 ? "DO NOT RUN" : (counts.WARNING > 0 ? "RUN WITH FIXES" : "SAFE TO RUN");
    return { gradeable:true, verdict:verdict, counts:counts, findings:findings, parsed:parsed };
  }

  function intentLabel(intent){
    if (intent === "sv") return "sign and verify (sv)";
    if (intent === "s") return "sign only (s)";
    return "verify only (v)";
  }

  function buildOutputs(result, intent){
    var lines = [];
    lines.push("J-Dawgs OpenDKIM Config Safety Auditor — plain-text report");
    lines.push("Verdict: " + result.verdict);
    lines.push("Stated intent: " + intentLabel(intent));
    lines.push("Counts: " + result.counts.BLOCKER + " BLOCKER, " + result.counts.WARNING + " WARNING, " + result.counts.INFO + " INFO, " + result.counts.PASS + " PASS");
    lines.push("");
    lines.push("FINDINGS");
    result.findings.forEach(function(f){
      lines.push("[" + f.severity + "] " + (f.line == null ? "Line: not present" : "Line " + f.line) + " · " + f.directive + " — " + f.detail + (f.fix ? " Fix: " + f.fix : ""));
    });
    lines.push("");
    lines.push("NOT PARSED LINES");
    lines.push(result.parsed.notParsed.length ? ("Lines not parsed: " + result.parsed.notParsed.join(", ") + " (comments and blank lines are ignored, not counted here).") : "None — every non-comment line was parsed.");
    lines.push("");
    lines.push("NOT CHECKED (a paste cannot prove these)");
    NOT_CHECKED.forEach(function(n){ lines.push("- " + n); });
    lines.push("");
    lines.push("Secret handling: key/secret values are never printed in this report or the JSON export — they are reported by directive name, line, and value length only.");
    var report = lines.join("\n");

    var payload = {
      tool: "J-Dawgs OpenDKIM Config Safety Auditor",
      verdict: result.verdict,
      intent: intent,
      intentLabel: intentLabel(intent),
      counts: result.counts,
      findings: result.findings,
      notParsedLines: result.parsed.notParsed,
      notChecked: NOT_CHECKED,
      secretFindings: result.parsed.secrets.map(function(s){
        return { line: s.line, directive: s.directive, valueLength: s.length, kind: s.kind, value: "[NEVER RENDERED]" };
      })
    };
    var json = JSON.stringify(payload, null, 2);
    return { report: scrub(report), json: scrub(json), payload: payload };
  }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-opendkim-config-safety-auditortm',
  name: 'J-Dawgs OpenDKIM Config Safety Auditor',
  description: 'OpenDKIM\'s own config check runs only on an installed host and stops at whether it loads; ours grades a pasted opendkim.conf offline anywhere — Mode vs intent, socket exposure, RequireSafeKeys, key posture, with secrets shown by name/line/length only — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
