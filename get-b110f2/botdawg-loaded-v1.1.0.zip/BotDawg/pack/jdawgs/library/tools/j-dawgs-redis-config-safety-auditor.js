'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Redis Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        /* ---------- Reference data ---------- */
        var KNOWN = {};
        ("bind protected-mode port tls-port tls-cert-file tls-key-file tls-ca-cert-file tls-ca-cert-dir " +
         "tls-dh-params-file tls-auth-clients tls-replication tls-cluster tls-protocols tls-ciphers " +
         "tls-ciphersuites tls-prefer-server-ciphers tls-session-caching tls-session-cache-size " +
         "tls-session-cache-timeout unixsocket unixsocketperm tcp-backlog timeout tcp-keepalive " +
         "daemonize supervised pidfile loglevel logfile syslog-enabled syslog-ident syslog-facility " +
         "databases always-show-logo set-proc-title proc-title-template save stop-writes-on-bgsave-error " +
         "rdbcompression rdbchecksum dbfilename rdb-del-sync-files dir replicaof slaveof masterauth " +
         "masteruser requirepass user aclfile acllog-max-len replica-serve-stale-data replica-read-only " +
         "repl-diskless-sync repl-diskless-sync-delay repl-diskless-load repl-ping-replica-period " +
         "repl-timeout repl-disable-tcp-nodelay repl-backlog-size repl-backlog-ttl min-replicas-to-write " +
         "min-replicas-max-lag replica-priority maxclients maxmemory maxmemory-policy maxmemory-samples " +
         "maxmemory-eviction-tenacity maxmemory-clients appendonly appendfilename appenddirname appendfsync " +
         "no-appendfsync-on-rewrite auto-aof-rewrite-percentage auto-aof-rewrite-min-size aof-load-truncated " +
         "aof-use-rdb-preamble aof-rewrite-incremental-fsync rdb-save-incremental-fsync activerehashing " +
         "client-output-buffer-limit client-query-buffer-limit proto-max-bulk-len hz dynamic-hz " +
         "notify-keyspace-events hash-max-listpack-entries hash-max-ziplist-entries list-max-listpack-size " +
         "list-max-ziplist-size list-compress-depth set-max-intset-entries zset-max-listpack-entries " +
         "zset-max-ziplist-entries hll-sparse-max-bytes stream-node-max-bytes stream-node-max-entries " +
         "lazyfree-lazy-eviction lazyfree-lazy-expire lazyfree-lazy-server-del lazyfree-lazy-user-del " +
         "lazyfree-lazy-user-flush io-threads io-threads-do-reads rename-command cluster-enabled " +
         "cluster-config-file cluster-node-timeout cluster-announce-ip cluster-announce-port " +
         "cluster-announce-bus-port cluster-require-full-coverage cluster-allow-reads-when-down " +
         "cluster-link-sendbuf-limit cluster-announce-hostname cluster-preferred-endpoint-type " +
         "slowlog-log-slower-than slowlog-max-len latency-monitor-threshold latency-tracking " +
         "latency-tracking-info-percentiles tracking-table-max-keys activedefrag active-defrag-ignore-bytes " +
         "active-defrag-threshold-lower active-defrag-threshold-upper active-defrag-cycle-min " +
         "active-defrag-cycle-max active-defrag-max-scan-fields jemalloc-bg-thread include loadmodule " +
         "enable-debug-command enable-module-command hide-user-data-from-log max-new-connections-per-cycle " +
         "socket-mark-id").split(" ").forEach(function (n) { KNOWN[n] = true; });

        var MULTI = { "save": true, "rename-command": true, "user": true, "include": true, "loadmodule": true };
        var DANGEROUS = ["FLUSHALL", "FLUSHDB", "CONFIG", "DEBUG", "SHUTDOWN", "KEYS"];
        var PLACEHOLDERS = ["changeme", "change-me", "change_me", "password", "password123", "passw0rd",
          "redis", "redispass", "redispassword", "test", "testing", "letmein", "secret", "default",
          "admin", "root", "pleasechange", "yourpassword", "your-password", "example", "demo", "123456", "12345678"];

        /* ---------- Parsing ---------- */
        function tokenize(s) {
          var out = [], cur = "", inQ = false, has = false;
          for (var i = 0; i < s.length; i++) {
            var c = s.charAt(i);
            if (inQ) {
              if (c === '"') { inQ = false; }
              else if (c === "\\" && i + 1 < s.length) { cur += s.charAt(++i); }
              else { cur += c; }
            } else if (c === '"') { inQ = true; has = true; }
            else if (c === " " || c === "\t") {
              if (cur.length || has) { out.push(cur); cur = ""; has = false; }
            } else { cur += c; }
          }
          if (cur.length || has) { out.push(cur); }
          return out;
        }

        function parseConfig(text) {
          var lines = text.split(/\r?\n/);
          var occ = {};       // name -> [{line, args}]
          var commented = {}; // name -> [line,...]
          var order = [];
          for (var i = 0; i < lines.length; i++) {
            var lineNo = i + 1;
            var t = lines[i].replace(/^\s+/, "");
            if (!t) { continue; }
            if (t.charAt(0) === "#") {
              var inner = t.slice(1).replace(/^\s+/, "");
              var ctoks = tokenize(inner);
              if (ctoks.length && /^[A-Za-z][A-Za-z0-9_-]*$/.test(ctoks[0])) {
                var cn = ctoks[0].toLowerCase();
                if (!commented[cn]) { commented[cn] = []; }
                commented[cn].push(lineNo);
              }
              continue;
            }
            var toks = tokenize(t);
            if (!toks.length) { continue; }
            var name = toks[0].toLowerCase();
            if (!occ[name]) { occ[name] = []; order.push(name); }
            occ[name].push({ line: lineNo, args: toks.slice(1) });
          }
          return { occ: occ, commented: commented, order: order, lineCount: lines.length };
        }

        function eff(parsed, name) {
          var list = parsed.occ[name];
          return list && list.length ? list[list.length - 1] : null;
        }
        function commentNote(parsed, name) {
          var c = parsed.commented[name];
          if (c && c.length) {
            return " Note: \"" + name + "\" was found only as a comment at line " +
              c.join(", line ") + " — a commented-out directive sets nothing in Redis.";
          }
          return "";
        }
        function isLoopback(addr) {
          var a = addr.replace(/^-/, "").toLowerCase();
          return a === "127.0.0.1" || a === "::1" || a === "localhost" || a.indexOf("127.") === 0;
        }
        function maskSecret(v) {
          if (!v) { return "(empty)"; }
          var head = v.length <= 2 ? v : v.slice(0, 2);
          return "\"" + head + "…\" (" + v.length + " characters)";
        }
        function isPlaceholder(v) {
          return PLACEHOLDERS.indexOf(String(v).toLowerCase()) !== -1;
        }

        /* ---------- Audit ---------- */
        function audit(text) {
          var parsed = parseConfig(text);
          var findings = [];
          function add(sev, directive, line, what, fix, exposure) {
            findings.push({ sev: sev, directive: directive, line: line, what: what, fix: fix || "", exposure: !!exposure });
          }

          var totalDirectives = 0;
          parsed.order.forEach(function (n) { totalDirectives += parsed.occ[n].length; });
          if (totalDirectives === 0) { return null; }

          /* --- bind posture --- */
          var bindEff = eff(parsed, "bind");
          var bindAddrs = bindEff ? bindEff.args : [];
          var loopbackOnly = bindAddrs.length > 0 && bindAddrs.every(isLoopback);
          var nonLoopback = bindAddrs.some(function (a) { return !isLoopback(a); });
          var wildcard = bindAddrs.some(function (a) {
            var x = a.replace(/^-/, "");
            return x === "0.0.0.0" || x === "::" || x === "*";
          });

          /* --- authentication state --- */
          var rpEff = eff(parsed, "requirepass");
          var rpValue = rpEff ? rpEff.args.join(" ") : "";
          var requirepassSet = !!(rpEff && rpValue.length > 0);
          var userOcc = parsed.occ["user"] || [];
          var defaultOff = false, anyUserPassword = false;
          userOcc.forEach(function (u) {
            var uname = (u.args[0] || "").toLowerCase();
            var rules = u.args.slice(1);
            var hasPw = rules.some(function (r) { return r.charAt(0) === ">" || r.charAt(0) === "#"; });
            if (hasPw) { anyUserPassword = true; }
            if (uname === "default" && rules.some(function (r) { return r.toLowerCase() === "off"; })) { defaultOff = true; }
          });
          var aclRestricted = defaultOff || anyUserPassword;
          var hasAuth = requirepassSet || aclRestricted;

          if (!bindEff) {
            add("BLOCKER", "bind", null,
              "No bind directive is set. What Redis binds to then depends on defaults that differ between versions and builds — some end up reachable beyond this machine. Do not rely on a default you have not read." + commentNote(parsed, "bind"),
              "Add an explicit bind line, e.g. \"bind 127.0.0.1 -::1\" for loopback-only, or list only the private interface addresses this instance must serve.",
              true);
          } else if (nonLoopback && !hasAuth) {
            add("BLOCKER", "bind", bindEff.line,
              "Network-exposed without authentication: bind includes " + (wildcard ? "a wildcard address (0.0.0.0 / ::)" : "non-loopback address(es)") +
              " (" + bindAddrs.join(", ") + "), and there is no requirepass and no ACL user restriction. Anyone who can reach this port can read, write, and delete the data — and use commands like CONFIG to write files.",
              "Bind to loopback or a private interface only, and set a strong requirepass (or lock access down with ACL users) before this config goes anywhere near a network.",
              true);
          } else if (nonLoopback && hasAuth) {
            add("WARNING", "bind", bindEff.line,
              "This instance listens on non-loopback address(es) (" + bindAddrs.join(", ") + "). Authentication is set, so the password is the only thing standing between the network and the data.",
              "Prefer binding to loopback or a private/VPN interface even with a password set, and restrict the port in the firewall to the hosts that need it.",
              false);
          } else if (loopbackOnly) {
            add("INFO", "bind", bindEff.line,
              "Good posture: bind is loopback-only (" + bindAddrs.join(", ") + "), so the instance is not reachable from other machines.",
              "", false);
          }

          /* --- protected-mode --- */
          var pmEff = eff(parsed, "protected-mode");
          if (pmEff) {
            var pmVal = (pmEff.args[0] || "").toLowerCase();
            if (pmVal === "no") {
              if (nonLoopback || !bindEff) {
                add("BLOCKER", "protected-mode", pmEff.line,
                  "protected-mode is off and the instance is not restricted to loopback. Redis's last-resort safety net — refusing outside connections when no password is set — is disabled exactly where it is needed.",
                  "Set \"protected-mode yes\", and pair it with an explicit loopback or private bind plus a password.",
                  true);
              } else {
                add("WARNING", "protected-mode", pmEff.line,
                  "protected-mode is off. The bind is loopback-only, so this is not reachable from the network today — but the safety net is gone if the bind is ever widened.",
                  "Set \"protected-mode yes\" unless you have a specific, documented reason to disable it.",
                  false);
              }
            } else if (pmVal === "yes") {
              add("INFO", "protected-mode", pmEff.line,
                "protected-mode is on: with no password set, Redis refuses non-loopback connections. Good defense in depth.",
                "", false);
            }
          }

          /* --- port / TLS / unix socket --- */
          var portEff = eff(parsed, "port");
          var portVal = portEff ? (portEff.args[0] || "") : null;
          var tlsEff = eff(parsed, "tls-port");
          var unixEff = eff(parsed, "unixsocket");
          if (tlsEff) {
            if (portVal !== "0") {
              add("WARNING", "tls-port", tlsEff.line,
                "tls-port is set (" + (tlsEff.args[0] || "") + ") but the plaintext port is still open (port " +
                (portVal === null ? "defaults to 6379" : portVal) + "). Clients — and attackers — can still connect without TLS.",
                "Set \"port 0\" so only the TLS port accepts TCP connections.",
                false);
            } else {
              add("INFO", "tls-port", tlsEff.line,
                "TLS-only TCP setup: port is 0 and tls-port is " + (tlsEff.args[0] || "") + ", so plaintext TCP is closed.",
                "", false);
            }
          }
          if (portVal === "0") {
            if (unixEff) {
              add("INFO", "port", portEff.line,
                "port 0 with a unix socket (" + (unixEff.args[0] || "") + ") is fine: TCP is off and local clients connect over the socket.",
                "", false);
            } else if (!tlsEff) {
              add("INFO", "port", portEff.line,
                "port 0 disables TCP entirely and no unixsocket is set — nothing can connect until one of them is configured. Safe, but check it is intentional.",
                "", false);
            }
          }

          /* --- requirepass / masterauth --- */
          if (requirepassSet) {
            if (isPlaceholder(rpValue)) {
              add("WARNING", "requirepass", rpEff.line,
                "Placeholder-looking password: a requirepass is set (masked: " + maskSecret(rpValue) +
                "), but the value matches a common placeholder word. Checked case-insensitively against a small built-in placeholder list — a password can be weak without matching it, so treat this as a floor, not a guarantee of strength.",
                "Replace it with a long, randomly generated password stored in a secrets manager.",
                false);
            } else {
              add("INFO", "requirepass", rpEff.line,
                "A password is set (masked: " + maskSecret(rpValue) + "). The full value is never printed by this tool.",
                "", false);
            }
          } else {
            if (nonLoopback) {
              add("BLOCKER", "requirepass", null,
                "requirepass is missing (no line — the directive is absent) while the bind at line " + bindEff.line +
                " exposes non-loopback addresses: the instance answers anyone who can reach the port, no password asked." + commentNote(parsed, "requirepass"),
                "Set a long, random requirepass — or restrict access with ACL users and disable or password-protect the default user.",
                true);
            } else if (!bindEff) {
              add("WARNING", "requirepass", null,
                "requirepass is missing, and with no bind directive set either, whether a password is needed depends on version defaults rather than on anything in this file." + commentNote(parsed, "requirepass"),
                "Set an explicit bind and a requirepass so the posture is decided by the config, not by defaults.",
                false);
            } else {
              add("INFO", "requirepass", null,
                "No requirepass is set. That is acceptable only because the bind is loopback-only; the moment the bind widens, a password becomes mandatory." + commentNote(parsed, "requirepass"),
                "", false);
            }
          }
          var maEff = eff(parsed, "masterauth");
          if (maEff && maEff.args.join(" ").length > 0) {
            var maValue = maEff.args.join(" ");
            if (isPlaceholder(maValue)) {
              add("WARNING", "masterauth", maEff.line,
                "masterauth is set (masked: " + maskSecret(maValue) + ") but the value is a placeholder-looking word from the small built-in list.",
                "Use the same long, random secret as the primary's requirepass, stored in a secrets manager.",
                false);
            } else {
              add("INFO", "masterauth", maEff.line,
                "masterauth is set for replication (masked: " + maskSecret(maValue) + "). The full value is never printed by this tool.",
                "", false);
            }
          }

          /* --- ACL users --- */
          userOcc.forEach(function (u) {
            var uname = u.args[0] || "";
            var rules = u.args.slice(1);
            var low = rules.map(function (r) { return r.toLowerCase(); });
            var hasPw = rules.some(function (r) { return r.charAt(0) === ">" || r.charAt(0) === "#"; });
            var hasNopass = low.indexOf("nopass") !== -1;
            if (uname.toLowerCase() === "default" && low.indexOf("on") !== -1 && (hasNopass || !hasPw)) {
              add("BLOCKER", "user", u.line,
                "The ACL default user is switched on with " + (hasNopass ? "nopass — any password is accepted" : "no password set on the line") +
                ". Combined with a reachable bind, that is an unauthenticated, fully privileged login. (Passwords on this line are never printed by this tool.)",
                "Give the default user a strong password, or turn it off (\"user default off\") and create named users with only the access they need.",
                true);
            }
            var broadKeys = low.indexOf("~*") !== -1, broadCh = low.indexOf("&*") !== -1;
            var allCmds = low.indexOf("allcommands") !== -1 || low.indexOf("+@all") !== -1;
            if ((broadKeys || broadCh) && allCmds) {
              add("WARNING", "user", u.line,
                "ACL user \"" + uname + "\" is over-broad: it can reach " +
                (broadKeys ? "every key (~*)" : "") + (broadKeys && broadCh ? " and " : "") + (broadCh ? "every channel (&*)" : "") +
                " and run all commands. That is an admin account wearing an application account's name.",
                "Scope the user to the key patterns and command categories the application actually uses (e.g. \"~cache:* +get +set\").",
                false);
            }
          });
          var aclFileEff = eff(parsed, "aclfile");
          if (aclFileEff) {
            add("INFO", "aclfile", aclFileEff.line,
              "An external ACL file is configured. Its users and rules are not in the pasted text, so they are not audited here — audit that file separately.",
              "", false);
          }

          /* --- dangerous commands --- */
          var renameOcc = parsed.occ["rename-command"] || [];
          var addressed = {};
          renameOcc.forEach(function (r) {
            var cmd = (r.args[0] || "").toUpperCase();
            var newName = r.args.length > 1 ? r.args[1] : "";
            if (cmd) { addressed[cmd] = { line: r.line, newName: newName }; }
            if (DANGEROUS.indexOf(cmd) !== -1 && newName === "") {
              add("INFO", "rename-command", r.line,
                "Good: " + cmd + " is disabled (renamed to an empty string), so it cannot be run at all.",
                "", false);
            } else if (DANGEROUS.indexOf(cmd) !== -1) {
              add("INFO", "rename-command", r.line,
                cmd + " is renamed to \"" + newName + "\". Renaming hides the command from casual use; disabling it (empty name) is stronger.",
                "", false);
            }
          });
          if (nonLoopback) {
            var unaddressed = DANGEROUS.filter(function (c) { return !addressed[c]; });
            if (unaddressed.length === DANGEROUS.length) {
              add("WARNING", "rename-command", null,
                "None of the dangerous commands — " + DANGEROUS.join(", ") + " — are renamed or disabled, and this instance is network-exposed. Anyone who gets in (or any compromised app credential) can wipe data with FLUSHALL, read every key with KEYS, or shut the server down.",
                "Disable the ones you do not operationally need, e.g. rename-command FLUSHALL \"\" — and rename or disable CONFIG and DEBUG at minimum on exposed instances.",
                false);
            } else if (unaddressed.length > 0) {
              add("WARNING", "rename-command", null,
                "These dangerous commands are still live under their real names on a network-exposed instance: " + unaddressed.join(", ") + ".",
                "Disable or rename the remaining ones you do not operationally need, e.g. rename-command " + unaddressed[0] + " \"\".",
                false);
            }
          }

          /* --- persistence --- */
          var saveOcc = parsed.occ["save"] || [];
          var rdbConfigured = saveOcc.some(function (s) {
            return !(s.args.length === 1 && s.args[0] === "");
          });
          var aoEff = eff(parsed, "appendonly");
          var aoYes = !!(aoEff && (aoEff.args[0] || "").toLowerCase() === "yes");
          if (aoYes) {
            add("INFO", "appendonly", aoEff.line,
              "appendonly is on: every write is logged to the AOF, so data survives a restart. Good persistence posture.",
              "", false);
          }
          if (!rdbConfigured && !aoYes) {
            add("BLOCKER", "save", null,
              "No persistence configured: there are no save points (no line — the directive is absent) and appendonly is not on" +
              (aoEff ? " (appendonly is set to \"" + (aoEff.args[0] || "") + "\" at line " + aoEff.line + ")" : "") +
              ". If this process restarts, the data is gone — that is expected behavior for this config, not a bug." +
              commentNote(parsed, "save") + commentNote(parsed, "appendonly"),
              "Turn on at least one: add save points (e.g. \"save 900 1\") and/or set \"appendonly yes\".",
              false);
          } else if (rdbConfigured && !aoYes) {
            add("INFO", "save", saveOcc[0].line,
              "RDB snapshot save points are configured (" + saveOcc.length + " save line" + (saveOcc.length > 1 ? "s" : "") +
              "). Snapshots alone can lose everything written since the last one; appendonly yes closes most of that gap.",
              "", false);
          }

          /* --- maxmemory --- */
          var mmEff = eff(parsed, "maxmemory");
          if (mmEff) {
            var mmRaw = (mmEff.args[0] || "0");
            var mmNum = parseFloat(mmRaw);
            if (mmNum === 0) {
              add("INFO", "maxmemory", mmEff.line,
                "maxmemory is 0 — unlimited. Redis will use as much memory as the data demands; on a shared host it can grow until the operating system kills it.",
                "", false);
            } else if (!eff(parsed, "maxmemory-policy")) {
              add("WARNING", "maxmemory", mmEff.line,
                "maxmemory is set (" + mmRaw + ") but no maxmemory-policy line exists. The default policy is noeviction: once the limit is hit, writes start failing with errors instead of evicting old keys — a classic production surprise.",
                "Set maxmemory-policy explicitly (e.g. allkeys-lru for a cache, volatile-lru or noeviction if every key matters) so the behavior at the limit is a decision, not a default.",
                false);
            }
          }

          /* --- write targets --- */
          var dirEff = eff(parsed, "dir");
          if (dirEff) {
            var dirVal = dirEff.args[0] || "";
            if (dirVal === "/" || dirVal.indexOf("/etc") === 0 || dirVal.indexOf("/root") === 0) {
              add("WARNING", "dir", dirEff.line,
                "Write-target risk: dir points at \"" + dirVal + "\", a system location. Redis writes its RDB/AOF files there — and an attacker who reaches CONFIG can redirect those writes at system files.",
                "Point dir at a dedicated data directory owned by the Redis user, e.g. /var/lib/redis.",
                false);
            }
          }
          var dbfEff = eff(parsed, "dbfilename");
          if (dbfEff) {
            var dbfVal = dbfEff.args[0] || "";
            if (dbfVal.indexOf("/etc") === 0 || dbfVal.indexOf("/root") === 0 || dbfVal === "/") {
              add("WARNING", "dbfilename", dbfEff.line,
                "Write-target risk: dbfilename points into a system path (\"" + dbfVal + "\"). The dump file should live inside the Redis data directory under a plain filename.",
                "Use a plain filename like \"dump.rdb\" and control the location with dir instead.",
                false);
            }
          }

          /* --- daemonize / supervised (INFO only) --- */
          var dEff = eff(parsed, "daemonize");
          var sEff = eff(parsed, "supervised");
          if (dEff || sEff) {
            var dVal = dEff ? (dEff.args[0] || "").toLowerCase() : "(unset)";
            var sVal = sEff ? (sEff.args[0] || "").toLowerCase() : "(unset)";
            var note = "Process management: daemonize is " + dVal + ", supervised is " + sVal + ".";
            if (dVal === "yes" && (sVal === "auto" || sVal === "systemd" || sVal === "upstart")) {
              note += " These two can fight: daemonize forks into the background while supervised mode expects the process to stay in the foreground for the supervisor. Under systemd, the usual pairing is daemonize no with supervised auto.";
            } else if (dVal === "yes") {
              note += " Self-daemonizing is fine for manual runs; under a service manager, foreground mode (daemonize no) with supervision is the usual setup.";
            }
            note += " Informational only — it does not change the verdict.";
            add("INFO", "daemonize / supervised", dEff ? dEff.line : sEff.line, note, "", false);
          }

          /* --- include files --- */
          var incOcc = parsed.occ["include"] || [];
          incOcc.forEach(function (inc) {
            add("INFO", "include", inc.line,
              "This file includes another config file (\"" + (inc.args[0] || "") + "\"). Its contents were not pasted, so anything set there is not audited here.",
              "", false);
          });

          /* --- duplicates: last value wins --- */
          parsed.order.forEach(function (name) {
            var list = parsed.occ[name];
            if (MULTI[name] || list.length < 2) { return; }
            var last = list[list.length - 1];
            var earlier = list.slice(0, -1).map(function (o) { return o.line; });
            add("INFO", name, last.line,
              "Duplicate directive: \"" + name + "\" appears " + list.length + " times. Redis semantics: the last value wins, so line " +
              last.line + " is the effective setting and line" + (earlier.length > 1 ? "s" : "") + " " + earlier.join(", ") +
              " " + (earlier.length > 1 ? "are" : "is") + " overridden.",
              "", false);
          });

          /* --- unknown directives: NOT AUDITED --- */
          var unknown = parsed.order.filter(function (n) { return !KNOWN[n]; });
          unknown.forEach(function (name) {
            var first = parsed.occ[name][0];
            add("NOT AUDITED", name, first.line,
              "\"" + name + "\" is not a directive this auditor knows, so it was not audited — it may be a typo, a module directive, or from a newer Redis version. Nothing about it was guessed.",
              "Check the spelling against your Redis version's documentation.",
              false);
          });

          /* --- verdict --- */
          var blockers = findings.filter(function (f) { return f.sev === "BLOCKER"; });
          var warnings = findings.filter(function (f) { return f.sev === "WARNING"; });
          var infos = findings.filter(function (f) { return f.sev === "INFO"; });
          var nas = findings.filter(function (f) { return f.sev === "NOT AUDITED"; });
          var exposedBlocker = blockers.some(function (f) { return f.exposure; }) && (nonLoopback || !bindEff);
          var verdict, vClass;
          if (exposedBlocker) { verdict = "DO NOT DEPLOY — EXPOSED"; vClass = "v-exposed"; }
          else if (blockers.length || warnings.length) { verdict = "DEPLOY WITH FIXES"; vClass = "v-fixes"; }
          else { verdict = "SAFE TO DEPLOY"; vClass = "v-safe"; }

          var rank = { "BLOCKER": 0, "WARNING": 1, "INFO": 2, "NOT AUDITED": 3 };
          findings.sort(function (a, b) {
            if (rank[a.sev] !== rank[b.sev]) { return rank[a.sev] - rank[b.sev]; }
            return (a.line || 0) - (b.line || 0);
          });

          return {
            verdict: verdict, vClass: vClass, findings: findings,
            counts: { b: blockers.length, w: warnings.length, i: infos.length, na: nas.length }
          };
        }

        /* ---------- Report text ---------- */
        function buildReport(result) {
          var lines = [];
          lines.push("J-Dawgs Redis Server Config Safety Auditor™ — text audit report");
          lines.push("Verdict: " + result.verdict);
          lines.push("Findings: " + result.counts.b + " blocker(s), " + result.counts.w +
            " warning(s), " + result.counts.i + " info, " + result.counts.na + " not audited");
          lines.push("");
          result.findings.forEach(function (f) {
            lines.push("[" + f.sev + "] " + f.directive + " — " + (f.line ? "line " + f.line : "no line (directive absent)"));
            lines.push("  What: " + f.what);
            if (f.fix) { lines.push("  Fix: " + f.fix); }
            lines.push("");
          });
          lines.push("Notes: heuristic text audit of pasted redis.conf text only. No server was contacted and no password was tested. " +
            "Commented-out directives do not count as set; for duplicate directives the last value wins. Secret values are masked everywhere in this report.");
          return lines.join("\n");
        }

        /* ---------- UI ---------- */
        var RISKY = "bind 0.0.0.0\nprotected-mode no\nport 6379\nappendonly no\ndaemonize yes";
        var CLEAN = "bind 127.0.0.1 -::1\nprotected-mode yes\nport 6379\n" +
          "requirepass Tr7!falcon-harbor-lantern-92-zephyr\nappendonly yes\n" +
          "save 900 1\nsave 300 10\nsave 60 10000\nrename-command FLUSHALL \"\"";
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-redis-config-safety-auditor',
  name: 'J-Dawgs Redis Server Config Safety Auditor',
  description: 'Redis checklists live in docs and the server binary answers nothing about a staged file; ours grades a pasted redis.conf anywhere — exposed bind without auth, protected-mode, persistence, dangerous commands — into one deploy verdict, secrets masked by name only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
