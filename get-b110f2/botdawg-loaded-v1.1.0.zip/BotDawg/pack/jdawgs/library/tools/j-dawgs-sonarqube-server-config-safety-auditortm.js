'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs SonarQube Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var RISKY = [
          "# Risky example - evaluation-style settings headed for production",
          "sonar.web.host=0.0.0.0",
          "sonar.web.port=9000",
          "sonar.forceAuthentication=false",
          "sonar.jdbc.url=jdbc:h2:tcp://localhost:9092/sonar",
          "sonar.jdbc.username=sonar",
          "sonar.jdbc.password=FAKEplantedSecretValue123!",
          "sonar.auth.jwtBase64Hs256Secret=shortsecret",
          "sonar.search.host=0.0.0.0",
          "sonar.updatecenter.activate=true",
          "sonar.web.context=/sonar",
          "sonar.web.context=/sonarqube",
          "this line is not a property at all",
          "#sonar.forceAuthentication=true"
        ].join("\n");

        var HARDENED = [
          "# Hardened example - external database, forced sign-in, secrets from the environment",
          "sonar.web.host=127.0.0.1",
          "sonar.web.https.port=8443",
          "sonar.web.port=9001",
          "sonar.forceAuthentication=true",
          "sonar.jdbc.url=jdbc:postgresql://db.internal:5432/sonarqube",
          "sonar.jdbc.username=sonar",
          "sonar.jdbc.password=${env:SONAR_JDBC_PASSWORD}",
          "sonar.auth.jwtBase64Hs256Secret=${env:SONAR_JWT_SECRET}",
          "sonar.ldap.url=ldaps://ldap.internal:636",
          "sonar.ldap.bindPassword=${env:LDAP_BIND_PASSWORD}",
          "sonar.search.host=127.0.0.1",
          "sonar.cluster.enabled=false",
          "sonar.updatecenter.activate=false",
          "sonar.telemetry.enable=false"
        ].join("\n");

        var JWT_EXAMPLES = ["secret","changeme","change-me","example","demo","test","sonar","password","s3cr3t","your-jwt-secret","aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"];
        var WIDE = {"0.0.0.0":true, "::":true, "[::]":true, "*":true};
        var EXPLICIT_SECRET_KEYS = {
          "sonar.jdbc.password":true,
          "sonar.ldap.bindpassword":true,
          "sonar.auth.saml.certificate":true,
          "sonar.auth.saml.privatekey":true,
          "sonar.auth.saml.privatekeypassword":true
        };
        var SEV_RANK = {"BLOCKER":0,"HIGH":1,"WARNING":2,"INFO":3};

        function isEnvRef(v){ return /^\$\{[^}]*\}$/.test((v||"").trim()); }
        function isWide(v){ return WIDE[(v||"").trim()] === true; }
        function esc(s){ return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;"); }

        function parse(text){
          var lines = String(text).split(/\r?\n/);
          var entries = [], commented = [], notParsed = [];
          for (var i = 0; i < lines.length; i++){
            var lineNo = i + 1;
            var raw = lines[i];
            var t = raw.trim();
            if (t === "") continue;
            if (t.charAt(0) === "#" || t.charAt(0) === "!"){
              var body = t.replace(/^[#!]\s*/, "");
              var key = null;
              var eq = body.indexOf("=");
              if (eq > 0){
                var ck = body.slice(0, eq).trim();
                if (/^[A-Za-z0-9_.\-]+$/.test(ck)) key = ck;
              }
              commented.push({line: lineNo, key: key});
              continue;
            }
            var eqIdx = raw.indexOf("=");
            if (eqIdx < 0){ notParsed.push({line: lineNo}); continue; }
            var k = raw.slice(0, eqIdx).trim();
            var v = raw.slice(eqIdx + 1).trim();
            if (!/^[A-Za-z0-9_.\-]+$/.test(k)){ notParsed.push({line: lineNo}); continue; }
            entries.push({key: k, value: v, line: lineNo});
          }
          var map = {}, order = [];
          entries.forEach(function(e){
            if (!map[e.key]) order.push(e.key);
            map[e.key] = e;
          });
          var dupGroups = {};
          entries.forEach(function(e){
            if (!dupGroups[e.key]) dupGroups[e.key] = [];
            dupGroups[e.key].push(e.line);
          });
          var duplicates = [];
          Object.keys(dupGroups).forEach(function(k){
            if (dupGroups[k].length > 1) duplicates.push({key: k, lines: dupGroups[k]});
          });
          return {entries: entries, commented: commented, notParsed: notParsed, map: map, duplicates: duplicates};
        }

        function audit(text){
          var findings = [], positives = [];
          var trimmed = String(text).trim();
          var parsed = parse(text);
          var map = parsed.map;

          function get(key){ return map[key] || null; }
          function val(key){ var e = get(key); return e ? e.value : null; }
          function add(sev, line, key, issue, fix, lines){
            findings.push({severity: sev, line: line, lines: lines || null, key: key, issue: issue, fix: fix});
          }

          var sonarCount = parsed.entries.filter(function(e){ return e.key.indexOf("sonar.") === 0; }).length;
          var jsonLike = trimmed.charAt(0) === "{" || trimmed.charAt(0) === "[";
          if (trimmed === "" || jsonLike || sonarCount === 0){
            return {
              verdict: "NOT ENOUGH TO GRADE",
              reason: trimmed === "" ? "The paste was empty."
                : jsonLike ? "The paste looks like JSON, not a sonar.properties file."
                : "No active sonar.* settings were found, so there is no SonarQube configuration posture to grade.",
              findings: [], positives: [], counts: {BLOCKER:0,HIGH:0,WARNING:0,INFO:0},
              commented: parsed.commented, notParsed: parsed.notParsed,
              activeCount: parsed.entries.length
            };
          }

          var lowerText = String(text).toLowerCase();
          var proxyNote = lowerText.indexOf("proxy") >= 0 || lowerText.indexOf("nginx") >= 0 ||
                          lowerText.indexOf("air-gap") >= 0 || lowerText.indexOf("airgap") >= 0 ||
                          lowerText.indexOf("traefik") >= 0 || lowerText.indexOf("haproxy") >= 0;
          var httpsEntry = get("sonar.web.https.port");
          var hasTls = !!(httpsEntry && httpsEntry.value !== "");
          var webHost = get("sonar.web.host");
          var webWide = webHost ? isWide(webHost.value) : false;

          // forceAuthentication
          var fa = get("sonar.forceAuthentication");
          if (fa && fa.value.toLowerCase() === "false"){
            if (webWide){
              add("BLOCKER", fa.line, "sonar.forceAuthentication",
                "sonar.forceAuthentication=false lets anonymous users browse projects, and sonar.web.host is bound to every interface, so the anonymous surface is reachable beyond this machine.",
                "Set sonar.forceAuthentication=true and restart; give anonymous users nothing and grant project access to signed-in groups only.");
            } else {
              add("HIGH", fa.line, "sonar.forceAuthentication",
                "sonar.forceAuthentication=false lets anonymous users browse projects without signing in.",
                "Set sonar.forceAuthentication=true and restart; grant project access to signed-in groups only.");
            }
          }

          // Database posture
          var jdbc = get("sonar.jdbc.url");
          if (!jdbc){
            add("HIGH", null, "sonar.jdbc.url",
              "No sonar.jdbc.url is configured, so SonarQube falls back to the embedded H2 database.",
              "Configure an external database, e.g. sonar.jdbc.url=jdbc:postgresql://db-host:5432/sonarqube with sonar.jdbc.username and sonar.jdbc.password set. H2 is evaluation only, and its data is lost on upgrade.");
          } else if (jdbc.value.toLowerCase().indexOf("jdbc:h2") === 0){
            add("HIGH", jdbc.line, "sonar.jdbc.url",
              "sonar.jdbc.url points at the embedded H2 database (jdbc:h2).",
              "Move to a supported external database (PostgreSQL, Oracle, or Microsoft SQL Server) before any real use. H2 is evaluation only, and its data is lost on upgrade.");
          }

          // Secrets — explicit keys, serverBaseURL credentials, then a generic sweep
          var flaggedSecretKeys = {};
          function secretFinding(e, label){
            if (!e || e.value === "" || isEnvRef(e.value)) return;
            flaggedSecretKeys[e.key.toLowerCase()] = true;
            add("HIGH", e.line, e.key,
              label + " is stored as a plaintext value in the file (value length: " + e.value.length + " characters). The value itself is never shown in this audit.",
              "Remove the literal value, supply the secret from the environment (for example ${env:...}) or a secrets manager, restrict the file's permissions, and rotate the secret since it has existed in plaintext.");
          }
          Object.keys(map).forEach(function(k){
            if (EXPLICIT_SECRET_KEYS[k.toLowerCase()]) secretFinding(map[k], "Secret " + k);
          });
          var baseUrl = get("sonar.core.serverBaseURL");
          if (baseUrl && baseUrl.value){
            var m = baseUrl.value.match(/^[a-z][a-z0-9+.-]*:\/\/([^/@]+)@/i);
            if (m && m[1].indexOf(":") >= 0){
              flaggedSecretKeys["sonar.core.serverbaseurl"] = true;
              add("HIGH", baseUrl.line, "sonar.core.serverBaseURL",
                "sonar.core.serverBaseURL embeds credentials in the URL (full value length: " + baseUrl.value.length + " characters). The value itself is never shown in this audit.",
                "Remove the credentials from the URL; a server base URL should be a plain https address with no user name or password in it.");
            }
          }
          Object.keys(map).forEach(function(k){
            var lk = k.toLowerCase();
            if (lk === "sonar.auth.jwtbase64hs256secret") return;
            if (flaggedSecretKeys[lk]) return;
            if (/(password|secret|privatekey|private_key|certificate|bindpassword)/.test(lk)){
              secretFinding(map[k], "Secret " + k);
            }
          });

          // JWT secret
          var jwt = get("sonar.auth.jwtBase64Hs256Secret");
          if (!jwt || jwt.value === ""){
            add("HIGH", jwt ? jwt.line : null, "sonar.auth.jwtBase64Hs256Secret",
              "sonar.auth.jwtBase64Hs256Secret is missing, so session tokens are not signed with an installation-specific secret you control.",
              "Generate a random Base64 secret of at least 32 characters (for example with openssl rand -base64 32), set sonar.auth.jwtBase64Hs256Secret to it or supply it via ${env:...}, and restart.");
          } else if (!isEnvRef(jwt.value)){
            if (JWT_EXAMPLES.indexOf(jwt.value.toLowerCase()) >= 0){
              add("HIGH", jwt.line, "sonar.auth.jwtBase64Hs256Secret",
                "sonar.auth.jwtBase64Hs256Secret matches a documented example / placeholder value (value length: " + jwt.value.length + " characters). The value itself is never shown in this audit.",
                "Replace it with a random Base64 secret of at least 32 characters generated on this machine, and restart.");
            } else if (jwt.value.length < 32){
              add("HIGH", jwt.line, "sonar.auth.jwtBase64Hs256Secret",
                "sonar.auth.jwtBase64Hs256Secret is only " + jwt.value.length + " characters long; session-token signing needs at least 32.",
                "Generate a random Base64 secret of at least 32 characters (for example with openssl rand -base64 32), set it, and restart.");
            }
          }

          // Web host binding
          if (webHost && webWide){
            if (!hasTls && !proxyNote){
              add("HIGH", webHost.line, "sonar.web.host",
                "sonar.web.host=" + webHost.value + " binds the web server to every network interface, and no TLS port (sonar.web.https.port) or reverse-proxy note is present, so the plain-HTTP UI is exposed as-is.",
                "Bind to 127.0.0.1 and put a TLS-terminating reverse proxy in front, or set sonar.web.https.port with a real certificate; do not expose the plain-HTTP UI directly.");
            } else {
              add("WARNING", webHost.line, "sonar.web.host",
                "sonar.web.host=" + webHost.value + " binds the web server to every network interface.",
                "Confirm the TLS / reverse-proxy layer in front of it is the only intended entry point, and firewall direct access to the SonarQube port.");
            }
          }

          // Default port
          var port = get("sonar.web.port");
          if (port && port.value === "9000"){
            add("WARNING", port.line, "sonar.web.port",
              "sonar.web.port is the default 9000 serving plain HTTP — the well-known port every scanner tries first.",
              "Serve SonarQube over HTTPS (sonar.web.https.port or a TLS reverse proxy) and avoid exposing the default plain-HTTP port in production.");
          }

          // Search host / cluster posture
          var search = get("sonar.search.host");
          var cluster = get("sonar.cluster.enabled");
          var clusterOn = cluster && cluster.value.toLowerCase() === "true";
          if (search && isWide(search.value)){
            if (clusterOn){
              add("WARNING", search.line, "sonar.search.host",
                "sonar.search.host=" + search.value + " binds the Elasticsearch node to every network interface in a clustered setup.",
                "Bind each search node to its private cluster address only and firewall the search ports (9001 range) to cluster members.");
            } else {
              add("HIGH", search.line, "sonar.search.host",
                "sonar.search.host=" + search.value + " binds the single-node Elasticsearch to every network interface; the search index has no authentication of its own.",
                "Set sonar.search.host=127.0.0.1 for a single-node install so Elasticsearch is reachable only from the SonarQube process on the same machine.");
            }
          }
          if (clusterOn){
            Object.keys(map).forEach(function(k){
              var lk = k.toLowerCase();
              if (lk.indexOf("sonar.cluster") === 0 && /(secret|password)/.test(lk)){
                var e = map[k];
                if (e.value !== "" && !isEnvRef(e.value) && !flaggedSecretKeys[lk]){
                  flaggedSecretKeys[lk] = true;
                  add("HIGH", e.line, k,
                    "Cluster is enabled and " + k + " is a plaintext value in the file (value length: " + e.value.length + " characters). The value itself is never shown in this audit.",
                    "Supply cluster node secrets from the environment or a secrets manager, identically on every node, and rotate the exposed value.");
                }
              }
            });
          }

          // Update center
          var uc = get("sonar.updatecenter.activate");
          if (uc && uc.value.toLowerCase() === "true" && !proxyNote){
            add("INFO", uc.line, "sonar.updatecenter.activate",
              "sonar.updatecenter.activate=true lets the server reach the SonarQube update center, and no proxy or air-gap note is present.",
              "If this server is meant to be isolated, set sonar.updatecenter.activate=false; if outbound access is intended, route it through the approved proxy and note that here.");
          }

          // Duplicates
          parsed.duplicates.forEach(function(d){
            add("WARNING", d.lines[0], d.key,
              "Duplicate active key " + d.key + " is set on lines " + d.lines.join(" and ") + ". The last value (line " + d.lines[d.lines.length-1] + ") wins; the earlier line is silently ignored by the server.",
              "Delete the earlier " + d.key + " line and keep only the value you intend on line " + d.lines[d.lines.length-1] + ".",
              d.lines);
          });

          // Positives (never findings)
          var tel = get("sonar.telemetry.enable");
          if (tel && tel.value.toLowerCase() === "false"){
            positives.push("Line " + tel.line + " — sonar.telemetry.enable=false: telemetry is disabled. Good posture; recorded as a positive note, not a finding.");
          }
          if (fa && fa.value.toLowerCase() === "true"){
            positives.push("Line " + fa.line + " — sonar.forceAuthentication=true: anonymous browsing is off.");
          }
          Object.keys(map).forEach(function(k){
            var e = map[k];
            if (EXPLICIT_SECRET_KEYS[k.toLowerCase()] && isEnvRef(e.value)){
              positives.push("Line " + e.line + " — " + k + " is an environment reference, not a value in the file.");
            }
          });
          if (jwt && isEnvRef(jwt.value)){
            positives.push("Line " + jwt.line + " — sonar.auth.jwtBase64Hs256Secret is supplied from the environment, not stored in the file.");
          }

          findings.sort(function(a,b){
            var r = SEV_RANK[a.severity] - SEV_RANK[b.severity];
            if (r !== 0) return r;
            return (a.line || 0) - (b.line || 0);
          });

          var counts = {BLOCKER:0, HIGH:0, WARNING:0, INFO:0};
          findings.forEach(function(f){ counts[f.severity]++; });

          var verdict;
          if (counts.BLOCKER > 0 || counts.HIGH >= 3) verdict = "DO NOT DEPLOY";
          else if (counts.HIGH > 0 || counts.WARNING > 0) verdict = "DEPLOY WITH FIXES";
          else verdict = "SAFE TO DEPLOY";

          return {
            verdict: verdict, reason: "",
            findings: findings, positives: positives, counts: counts,
            commented: parsed.commented, notParsed: parsed.notParsed,
            activeCount: parsed.entries.length
          };
        }

        function locText(f){
          if (f.lines && f.lines.length) return "Lines " + f.lines.join(", ");
          if (f.line) return "Line " + f.line;
          return "Not present in file";
        }

        function buildReport(r){
          var out = [];
          out.push("SONARQUBE SERVER CONFIG SAFETY AUDIT");
          out.push("Verdict: " + r.verdict);
          if (r.reason) out.push("Why: " + r.reason);
          out.push("Active settings parsed: " + r.activeCount);
          out.push("Counts: BLOCKER " + r.counts.BLOCKER + " / HIGH " + r.counts.HIGH + " / WARNING " + r.counts.WARNING + " / INFO " + r.counts.INFO);
          out.push("");
          if (r.findings.length){
            out.push("FINDINGS");
            r.findings.forEach(function(f, i){
              out.push((i+1) + ". [" + f.severity + "] " + locText(f) + " - " + f.key);
              out.push("   Issue: " + f.issue);
              out.push("   Fix: " + f.fix);
            });
          } else if (r.verdict !== "NOT ENOUGH TO GRADE"){
            out.push("FINDINGS");
            out.push("None. No BLOCKER, HIGH, WARNING, or INFO findings.");
          }
          if (r.positives.length){
            out.push("");
            out.push("POSITIVE NOTES");
            r.positives.forEach(function(p){ out.push("- " + p); });
          }
          out.push("");
          out.push("COMMENTED / NOT ACTIVE (never graded as set)");
          if (r.commented.length){
            r.commented.forEach(function(c){
              out.push("- Line " + c.line + " - " + (c.key ? c.key : "(comment)") + " - COMMENTED / NOT ACTIVE");
            });
          } else out.push("- None.");
          out.push("");
          out.push("NOT PARSED");
          if (r.notParsed.length){
            r.notParsed.forEach(function(n){ out.push("- Line " + n.line + " - NOT PARSED"); });
          } else out.push("- None.");
          out.push("");
          out.push("Note: this audit grades the pasted file only. Whether the default admin password was changed lives in the database, not in this file, so this report cannot speak to it.");
          out.push("Secret values are never included in this report; secrets are reported by key, line, and value length only.");
          return out.join("\n");
        }

        function buildJson(r){
          var obj = {
            tool: "J-Dawgs SonarQube Server Config Safety Auditor",
            verdict: r.verdict,
            reason: r.reason || null,
            activeSettingsParsed: r.activeCount,
            counts: r.counts,
            findings: r.findings.map(function(f){
              return {severity: f.severity, line: f.line, lines: f.lines, key: f.key, issue: f.issue, fix: f.fix};
            }),
            positiveNotes: r.positives,
            commentedNotActive: r.commented.map(function(c){ return {line: c.line, key: c.key, status: "COMMENTED / NOT ACTIVE"}; }),
            notParsed: r.notParsed.map(function(n){ return {line: n.line, status: "NOT PARSED"}; }),
            note: "Secret values are never included in this export; secrets are reported by key, line, and value length only. Whether the default admin password was changed lives in the database, not in this file."
          };
          return JSON.stringify(obj, null, 2);
        }

        var lastJson = "";
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "JWT_EXAMPLES": (typeof JWT_EXAMPLES !== 'undefined' ? JWT_EXAMPLES : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-sonarqube-server-config-safety-auditortm',
  name: 'J-Dawgs SonarQube Server Config Safety Auditor',
  description: 'Grades a pasted sonar.properties fully offline into one deploy verdict — forceAuthentication=false, the embedded H2 database used beyond evaluation, plaintext JDBC and LDAP passwords, and short JWT secrets. Those faults pass silently at startup; ours catches them first — and commented-out settings a',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "JWT_EXAMPLES": __core["JWT_EXAMPLES"] }
};
