'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Nextcloud Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------------- Worked examples ---------------- */
      var RISKY_EXAMPLE = [
        "<?php",
        "$CONFIG = array (",
        "  'instanceid' => 'oc8f4k2example',",
        "  'passwordsalt' => 'FAKE-SALT-not-a-real-value-0001',",
        "  'secret' => 'FAKE-SECRET-not-a-real-value-0002',",
        "  'trusted_domains' =>",
        "  array (",
        "    0 => '*',",
        "  ),",
        "  'datadirectory' => '/var/www/nextcloud/data',",
        "  'dbtype' => 'mysql',",
        "  'version' => '29.0.0.19',",
        "  'overwrite.cli.url' => 'http://cloud.example.com',",
        "  'dbname' => 'nextcloud',",
        "  'dbhost' => 'localhost',",
        "  'dbuser' => 'nc_admin',",
        "  'dbpassword' => 'CANARY-DBPASS-4f8c2e-not-a-real-password',",
        "  'installed' => true,",
        "  'maintenance' => false,",
        "  'debug' => true,",
        "  'loglevel' => 0,",
        "  'mail_smtpmode' => 'smtp',",
        "  'mail_smtphost' => 'mail.example.com',",
        "  'mail_smtppassword' => 'FAKE-SMTP-not-a-real-value-0003',",
        "  'memcache.local' => '\\OC\\Memcache\\Redis',",
        "  'redis' =>",
        "  array (",
        "    'host' => 'localhost',",
        "    'port' => 6379,",
        "  ),",
        "  'allow_local_remote_servers' => true,",
        ");"
      ].join("\n");

      var HARDENED_EXAMPLE = [
        "<?php",
        "$CONFIG = array (",
        "  'instanceid' => 'oc9h7d3example',",
        "  'passwordsalt' => 'REPLACE-with-the-real-salt',",
        "  'secret' => 'REPLACE-with-the-real-secret',",
        "  'trusted_domains' =>",
        "  array (",
        "    0 => 'cloud.example.com',",
        "  ),",
        "  'datadirectory' => '/srv/nextcloud/data',",
        "  'dbtype' => 'pgsql',",
        "  'version' => '30.0.2.2',",
        "  'overwrite.cli.url' => 'https://cloud.example.com',",
        "  'overwriteprotocol' => 'https',",
        "  'dbname' => 'nextcloud',",
        "  'dbhost' => 'db.internal',",
        "  'dbuser' => 'nc_admin',",
        "  'dbpassword' => 'REPLACE-with-the-real-db-password',",
        "  'installed' => true,",
        "  'maintenance' => false,",
        "  'debug' => false,",
        "  'loglevel' => 2,",
        "  'log_type' => 'file',",
        "  'memcache.local' => '\\OC\\Memcache\\APCu',",
        "  'memcache.distributed' => '\\OC\\Memcache\\Redis',",
        "  'memcache.locking' => '\\OC\\Memcache\\Redis',",
        "  'redis' =>",
        "  array (",
        "    'host' => '127.0.0.1',",
        "    'port' => 6379,",
        "    'password' => 'REPLACE-with-the-real-redis-password',",
        "  ),",
        "  'updater.release.channel' => 'stable',",
        "  'appstoreenabled' => true,",
        "  'allow_local_remote_servers' => false,",
        ");"
      ].join("\n");

      /* ---------------- Tokenizer ---------------- */
      function tokenize(text){
        var tokens = [];
        var i = 0, line = 1, n = text.length;
        function push(type, value, ln){ tokens.push({type:type, value:value, line:ln}); }
        while (i < n){
          var c = text[i];
          if (c === "\n"){ line++; i++; continue; }
          if (c === " " || c === "\t" || c === "\r"){ i++; continue; }
          if (c === "/" && text[i+1] === "/"){ while (i < n && text[i] !== "\n") i++; continue; }
          if (c === "#"){ while (i < n && text[i] !== "\n") i++; continue; }
          if (c === "/" && text[i+1] === "*"){
            var commentClosed = false; i += 2;
            while (i < n){
              if (text[i] === "*" && text[i+1] === "/"){ commentClosed = true; i += 2; break; }
              if (text[i] === "\n") line++;
              i++;
            }
            if (!commentClosed) return { error: { line: line, msg: "Unterminated block comment" } };
            continue;
          }
          if (c === "<" || c === "?"){ i++; continue; } /* <?php tag pieces */
          if (c === "$"){
            var j = i + 1, name = "";
            while (j < n && /[A-Za-z0-9_]/.test(text[j])){ name += text[j]; j++; }
            if (name){ push("var", name, line); i = j; } else { i++; }
            continue;
          }
          if (c === "'" || c === "\""){
            var q = c, startLine = line, s = "", closed = false;
            i++;
            while (i < n){
              var ch = text[i];
              if (ch === "\\" && i + 1 < n){
                var nx = text[i+1];
                if (q === "'"){
                  if (nx === "'" || nx === "\\") s += nx; else s += "\\" + nx;
                } else {
                  if (nx === "n") s += "\n";
                  else if (nx === "t") s += "\t";
                  else if (nx === "r") s += "\r";
                  else s += nx;
                }
                i += 2; continue;
              }
              if (ch === q){ closed = true; i++; break; }
              if (ch === "\n") line++;
              s += ch; i++;
            }
            if (!closed) return { error: { line: startLine, msg: "Unterminated string starting on this line" } };
            push("string", s, startLine);
            continue;
          }
          if (/[0-9]/.test(c) || (c === "-" && /[0-9]/.test(text[i+1] || ""))){
            var num = "", numLine = line;
            while (i < n && /[0-9a-fA-FxX._-]/.test(text[i])){ num += text[i]; i++; }
            push("number", num, numLine);
            continue;
          }
          if (/[A-Za-z_]/.test(c)){
            var id = "", idLine = line;
            while (i < n && /[A-Za-z0-9_\\]/.test(text[i])){ id += text[i]; i++; }
            push("ident", id, idLine);
            continue;
          }
          if (c === "=" && text[i+1] === ">"){ push("arrow", null, line); i += 2; continue; }
          if (c === "="){ push("eq", null, line); i++; continue; }
          if (c === "("){ push("lparen", null, line); i++; continue; }
          if (c === ")"){ push("rparen", null, line); i++; continue; }
          if (c === "["){ push("lbracket", null, line); i++; continue; }
          if (c === "]"){ push("rbracket", null, line); i++; continue; }
          if (c === ","){ push("comma", null, line); i++; continue; }
          if (c === ";"){ push("semi", null, line); i++; continue; }
          i++; /* any other character is ignored punctuation */
        }
        return { tokens: tokens };
      }

      /* Balance pre-check: catches unbalanced input before parsing. */
      function balanceError(tokens){
        var stack = [];
        for (var k = 0; k < tokens.length; k++){
          var t = tokens[k];
          if (t.type === "lparen" || t.type === "lbracket") stack.push(t);
          else if (t.type === "rparen" || t.type === "rbracket"){
            var want = (t.type === "rparen") ? "lparen" : "lbracket";
            if (!stack.length || stack[stack.length-1].type !== want){
              return { line: t.line, msg: "Unbalanced input — a closing bracket on this line has no matching opening bracket" };
            }
            stack.pop();
          }
        }
        if (stack.length){
          return { line: stack[0].line, msg: "Unbalanced input — the bracket opened on this line is never closed" };
        }
        return null;
      }

      /* ---------------- Parser (recursive descent over the array literal) ---------------- */
      function ParseFail(line, msg){ this.line = line; this.msg = msg; }

      function parseValue(tokens, pos){
        var t = tokens[pos];
        if (!t) throw new ParseFail(tokens.length ? tokens[tokens.length-1].line : 1, "Unexpected end of input");
        if (t.type === "ident" && t.value.toLowerCase() === "array"){
          var open = tokens[pos+1];
          if (!open || open.type !== "lparen") throw new ParseFail(t.line, "Expected '(' after 'array' on this line");
          return parseArrayBody(tokens, pos + 2, "rparen", t.line);
        }
        if (t.type === "lbracket") return parseArrayBody(tokens, pos + 1, "rbracket", t.line);
        if (t.type === "string") return { node: { kind:"scalar", vtype:"string", value:t.value, line:t.line }, pos: pos + 1 };
        if (t.type === "number") return { node: { kind:"scalar", vtype:"number", value:parseFloat(t.value), raw:t.value, line:t.line }, pos: pos + 1 };
        if (t.type === "ident"){
          var low = t.value.toLowerCase();
          if (low === "true")  return { node: { kind:"scalar", vtype:"bool", value:true,  line:t.line }, pos: pos + 1 };
          if (low === "false") return { node: { kind:"scalar", vtype:"bool", value:false, line:t.line }, pos: pos + 1 };
          if (low === "null")  return { node: { kind:"scalar", vtype:"null", value:null,  line:t.line }, pos: pos + 1 };
          return { node: { kind:"scalar", vtype:"const", value:t.value, line:t.line }, pos: pos + 1 };
        }
        throw new ParseFail(t.line, "Unexpected token on this line — the config text could not be parsed here");
      }

      function parseArrayBody(tokens, pos, closer, openLine){
        var entries = [];
        while (true){
          var t = tokens[pos];
          if (!t) throw new ParseFail(openLine, "Unbalanced input — the array opened on this line is never closed");
          if (t.type === closer) return { node: { kind:"array", entries:entries, line:openLine }, pos: pos + 1 };
          if (t.type === "comma"){ pos++; continue; }
          var key = null, keyLine = t.line;
          if ((t.type === "string" || t.type === "number") && tokens[pos+1] && tokens[pos+1].type === "arrow"){
            key = t.value; keyLine = t.line; pos += 2;
          }
          var res = parseValue(tokens, pos);
          pos = res.pos;
          entries.push({ key: key, keyLine: keyLine, value: res.node });
          var nt = tokens[pos];
          if (nt && nt.type === "comma"){ pos++; continue; }
          if (nt && nt.type === closer) return { node: { kind:"array", entries:entries, line:openLine }, pos: pos + 1 };
          if (!nt) throw new ParseFail(openLine, "Unbalanced input — the array opened on this line is never closed");
          throw new ParseFail(nt.line, "Expected a comma or a closing bracket on this line");
        }
      }

      function parseConfig(text){
        var tk = tokenize(text);
        if (tk.error) return { error: tk.error };
        var tokens = tk.tokens;
        var bal = balanceError(tokens);
        if (bal) return { error: bal };
        /* Find $CONFIG = <value> */
        var startPos = -1;
        for (var k = 0; k < tokens.length; k++){
          if (tokens[k].type === "var" && tokens[k].value === "CONFIG" &&
              tokens[k+1] && tokens[k+1].type === "eq"){ startPos = k + 2; break; }
        }
        if (startPos < 0){
          for (var m = 0; m < tokens.length; m++){
            if (tokens[m].type === "lbracket" ||
               (tokens[m].type === "ident" && tokens[m].value.toLowerCase() === "array")){ startPos = m; break; }
          }
        }
        if (startPos < 0 || startPos >= tokens.length){
          return { error: { line: tokens.length ? tokens[0].line : 1,
            msg: "No $CONFIG array found in the pasted text" } };
        }
        try {
          var res = parseValue(tokens, startPos);
          if (res.node.kind !== "array"){
            return { error: { line: res.node.line, msg: "The $CONFIG value is not an array" } };
          }
          return { root: res.node };
        } catch (e){
          if (e instanceof ParseFail) return { error: { line: e.line, msg: e.msg } };
          return { error: { line: 1, msg: "The pasted text could not be parsed" } };
        }
      }

      /* ---------------- Audit checks ---------------- */
      var KNOWN_KEYS = {
        "instanceid":1, "passwordsalt":1, "secret":1, "trusted_domains":1,
        "datadirectory":1, "dbtype":1, "version":1, "overwrite.cli.url":1,
        "overwriteprotocol":1, "overwritehost":1, "overwritewebroot":1,
        "overwritecondaddr":1, "htaccess.RewriteBase":1, "dbname":1,
        "dbhost":1, "dbport":1, "dbtableprefix":1, "dbuser":1, "dbpassword":1,
        "mysql.utf8mb4":1, "installed":1, "maintenance":1, "maintenance_window_start":1,
        "theme":1, "default_language":1, "default_locale":1, "default_phone_region":1,
        "defaultapp":1, "skeletondirectory":1, "templatedirectory":1,
        "knowledgebaseenabled":1, "enable_previews":1, "preview_max_x":1, "preview_max_y":1,
        "loglevel":1, "log_type":1, "logfile":1, "logdateformat":1, "logtimezone":1,
        "log_rotate_size":1, "syslog_tag":1,
        "mail_smtpmode":1, "mail_smtpsecure":1, "mail_sendmailmode":1,
        "mail_from_address":1, "mail_domain":1, "mail_smtpauth":1,
        "mail_smtpauthtype":1, "mail_smtphost":1, "mail_smtpport":1,
        "mail_smtpname":1, "mail_smtppassword":1, "mail_smtpdebug":1,
        "memcache.local":1, "memcache.distributed":1, "memcache.locking":1,
        "redis":1, "memcached_servers":1, "filelocking.enabled":1, "cache_path":1,
        "debug":1, "updater.release.channel":1, "updater.server.url":1,
        "updatechecker":1, "has_internet_connection":1, "check_for_working_htaccess":1,
        "appstoreenabled":1, "appstoreurl":1, "apps_paths":1,
        "allow_local_remote_servers":1, "allow_user_to_change_display_name":1,
        "trusted_proxies":1, "forwarded_for_headers":1, "proxy":1, "proxyuserpwd":1,
        "session_lifetime":1, "session_keepalive":1, "auto_logout":1,
        "remember_login_cookie_lifetime":1, "token_auth_enforced":1,
        "auth.bruteforce.protection.enabled":1, "ratelimit.protection.enabled":1,
        "csrf.optout":1, "simpleSignUpLink.shown":1, "lost_password_link":1,
        "shareapi_enabled":1, "shareapi_allow_links":1, "shareapi_allow_public_upload":1,
        "encryption_enabled":1, "encryption_skip_signature_check":1,
        "openssl":1, "integrity.check.disabled":1, "localstorage.allowsymlinks":1,
        "filesystem_check_changes":1, "quota_include_external_storage":1,
        "versions_retention_obligation":1, "trashbin_retention_obligation":1,
        "activity_expire_days":1, "comments.managerFactory":1,
        "twofactor_enforced":1, "profile.enabled":1, "bulkupload.enabled":1,
        "reference_opengraph":1, "unified_search.providers_allowed":1,
        "davstorage.request_timeout":1, "cardigans":1, "ldapProviderFactory":1,
        "objectstore":1, "objectstore_multibucket":1, "preview":1, "preview_libreoffice_path":1,
        "enable_file_metadata":1, "file_metadata":1, "update_server":1,
        "config_is_read_only":1, "app_install_overwrite":1, "debugwindow":1,
        "mail_template_class":1, "mail_send_plaintext_only":1, "overwritehost.exclude":1
      };
      var CREDENTIAL_KEYS = ["dbpassword", "mail_smtppassword", "proxyuserpwd"];
      var INSTANCE_SECRET_KEYS = ["instanceid", "passwordsalt", "secret"];
      var LOCAL_HOSTS = { "localhost":1, "127.0.0.1":1, "::1":1, "[::1]":1, "0.0.0.0":1 };

      function isScalar(node, vtype){ return node && node.kind === "scalar" && node.vtype === vtype; }
      function scalarStr(node){ return isScalar(node, "string") ? node.value : null; }
      function scalarBool(node){ return isScalar(node, "bool") ? node.value : null; }
      function scalarNum(node){ return isScalar(node, "number") ? node.value : null; }

      function hostOf(url){
        var s = url.replace(/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//, "");
        s = s.split("/")[0].split("@").pop();
        if (s.charAt(0) === "["){ var end = s.indexOf("]"); return end > 0 ? s.slice(0, end + 1) : s; }
        return s.split(":")[0];
      }
      function schemeOf(url){
        var m = /^([a-zA-Z][a-zA-Z0-9+.-]*):\/\//.exec(url);
        return m ? m[1].toLowerCase() : null;
      }

      function audit(text){
        if (!text || !text.trim()){
          return { state: "empty" };
        }
        var parsed = parseConfig(text);
        if (parsed.error){
          return { state: "error", errorLine: parsed.error.line, errorMsg: parsed.error.msg };
        }
        var root = parsed.root;
        var findings = [];
        function add(sev, line, msg){ findings.push({ sev: sev, line: line, msg: msg }); }

        /* Index top-level keyed entries; collect duplicates. */
        var byKey = {}, unknownCount = 0, totalKeyed = 0;
        root.entries.forEach(function(e){
          if (e.key === null) return;
          totalKeyed++;
          if (!byKey[e.key]) byKey[e.key] = [];
          byKey[e.key].push(e);
          if (!KNOWN_KEYS[e.key]) unknownCount++;
        });
        function entries(key){ return byKey[key] || []; }
        function last(key){ var l = entries(key); return l.length ? l[l.length - 1] : null; }
        function val(key){ var e = last(key); return e ? e.value : null; }
        function lineOf(key, fallback){ var e = last(key); return e ? e.keyLine : fallback; }

        Object.keys(byKey).forEach(function(key){
          var list = byKey[key];
          if (list.length > 1 && KNOWN_KEYS[key]){
            var lines = list.map(function(e){ return e.keyLine; });
            add("warning", lines[lines.length - 1],
              "Duplicate key '" + key + "' — set on lines " + lines.join(" and ") +
              ". PHP keeps the last value, so line " + lines[lines.length - 1] + " wins; delete the stale entry so the config says one thing.");
          }
        });

        /* --- Locality context (drives the debug severity) --- */
        var cliUrlNode = val("overwrite.cli.url");
        var cliUrl = cliUrlNode ? scalarStr(cliUrlNode) : null;
        var cliScheme = cliUrl ? schemeOf(cliUrl) : null;
        var cliHost = cliUrl ? hostOf(cliUrl) : null;

        var tdEntry = last("trusted_domains");
        var tdDomains = null, tdWildcardLine = null, tdHasNonLocal = false;
        if (tdEntry && tdEntry.value.kind === "array"){
          tdDomains = [];
          tdEntry.value.entries.forEach(function(e){
            var v = scalarStr(e.value);
            if (v !== null){
              tdDomains.push(v);
              if (v === "*") tdWildcardLine = e.value.line;
              if (!LOCAL_HOSTS[v.toLowerCase()]) tdHasNonLocal = true;
            }
          });
        }
        var nonLocal = tdHasNonLocal || (cliHost !== null && !LOCAL_HOSTS[cliHost.toLowerCase()]);

        /* --- trusted_domains --- */
        if (!tdEntry){
          add("blocker", root.line,
            "'trusted_domains' is missing entirely. Nextcloud refuses web access from any host until at least one trusted domain is listed — add the exact hostnames this instance will serve.");
        } else if (tdEntry.value.kind !== "array"){
          add("blocker", tdEntry.keyLine,
            "'trusted_domains' is present but is not an array — Nextcloud cannot use it as a host allowlist. Give it an array of exact hostnames.");
        } else if (tdDomains !== null && tdDomains.length === 0){
          add("blocker", tdEntry.keyLine,
            "'trusted_domains' is an empty array — no host is trusted, so the instance is unreachable over the web. List at least one exact hostname.");
        } else if (tdWildcardLine !== null){
          add("blocker", tdWildcardLine,
            "'trusted_domains' contains the wildcard '*' — every Host header is trusted, which switches off the protection this list exists for. Replace it with the exact hostnames this instance serves.");
        } else if (tdDomains !== null){
          add("note", tdEntry.keyLine,
            "'trusted_domains' lists " + tdDomains.length + " exact hostname" + (tdDomains.length === 1 ? "" : "s") + " and no wildcard. Good posture.");
        }

        /* --- debug --- */
        var debugNode = val("debug");
        var debugVal = debugNode ? scalarBool(debugNode) : null;
        if (debugVal === true){
          if (nonLocal){
            add("blocker", lineOf("debug", root.line),
              "'debug' is true in a non-local config (a public trusted domain or CLI URL is in play). Debug mode exposes detailed error output, paths, and internals to visitors — turn it off before this instance serves anyone.");
          } else {
            add("warning", lineOf("debug", root.line),
              "'debug' is true. Nothing non-local was found in this text, so it reads as a local development setup — still, ship with debug off; it leaks detailed error output.");
          }
        } else if (debugVal === false){
          add("note", lineOf("debug", root.line), "'debug' is off. Good — production posture.");
        }

        /* --- URL / protocol pairing --- */
        var protoNode = val("overwriteprotocol");
        var proto = protoNode ? scalarStr(protoNode) : null;
        var hostKeyEntry = last("overwritehost");
        if (cliUrl !== null){
          if (cliScheme === "http"){
            add("warning", lineOf("overwrite.cli.url", root.line),
              "'overwrite.cli.url' uses http:// — links and redirects the instance generates for cron jobs, mail, and sharing go out over plain HTTP. Serve the instance over HTTPS and update this URL to match.");
          } else if (cliScheme === "https"){
            add("note", lineOf("overwrite.cli.url", root.line),
              "'overwrite.cli.url' uses https://. Good.");
          } else {
            add("warning", lineOf("overwrite.cli.url", root.line),
              "'overwrite.cli.url' has no recognisable http/https scheme — generated links may be wrong. Set it to the full public URL of the instance, starting with https://.");
          }
          if (proto !== null && cliScheme !== null && proto.toLowerCase() !== cliScheme){
            add("warning", lineOf("overwriteprotocol", root.line),
              "Protocol pairing mismatch: 'overwriteprotocol' is '" + proto + "' but 'overwrite.cli.url' uses '" + cliScheme + "'. Behind a proxy this pairing decides the scheme of every generated link — make the two agree.");
          } else if (proto !== null && cliScheme !== null){
            add("note", lineOf("overwriteprotocol", root.line),
              "Protocol pairing agrees: 'overwriteprotocol' and 'overwrite.cli.url' both use " + cliScheme + ".");
          }
        } else {
          add("note", root.line,
            "'overwrite.cli.url' is not set — Nextcloud falls back to the request host for CLI and cron-generated links, which is often wrong behind proxies or in containers. Setting it explicitly is safer.");
        }
        if (hostKeyEntry && proto === null){
          add("note", hostKeyEntry.keyLine,
            "'overwritehost' is set without 'overwriteprotocol' — the protocol half of the pairing is left to detection. Setting both explicitly avoids wrong-scheme links behind proxies.");
        }

        /* --- Secret posture: key name and line only, values NEVER read into output --- */
        CREDENTIAL_KEYS.forEach(function(key){
          var e = last(key);
          if (!e) return;
          var v = scalarStr(e.value);
          if (v !== null && v === ""){
            add("warning", e.keyLine,
              "'" + key + "' is present but empty. An empty credential in the config means the service behind it runs unauthenticated or mail/database access fails — set a real value, or remove the feature that needs it.");
          } else if (e.value.kind === "scalar"){
            add("note", e.keyLine,
              "Plaintext credential present in the pasted text: '" + key + "' (this line). The value is never shown in this audit or its report. A server-side config.php holding credentials is normal for Nextcloud — keep the file out of any repo, ticket, or chat, and keep its file permissions tight.");
          }
        });
        var presentInstanceSecrets = INSTANCE_SECRET_KEYS.filter(function(k){ return !!last(k); });
        if (presentInstanceSecrets.length){
          var parts = presentInstanceSecrets.map(function(k){
            return "'" + k + "' (line " + lineOf(k, root.line) + ")";
          });
          add("note", lineOf(presentInstanceSecrets[0], root.line),
            "Instance secrets present in the text: " + parts.join(", ") + ". Values are never shown in this audit or its report. These keys belong in the server-side config only — if this text ever left the server, rotate them.");
        }
        var smtpAuth = scalarBool(val("mail_smtpauth"));
        if (smtpAuth === true && !last("mail_smtppassword")){
          add("warning", lineOf("mail_smtpauth", root.line),
            "'mail_smtpauth' is on but no 'mail_smtppassword' key exists in the text — outbound mail will fail authentication until the credential is set (by key, on the server — never paste its value here).");
        }

        /* --- installed / maintenance posture --- */
        var installedNode = val("installed");
        var installedVal = installedNode ? scalarBool(installedNode) : null;
        var maintNode = val("maintenance");
        var maintVal = maintNode ? scalarBool(maintNode) : null;
        if (installedVal === false){
          add("warning", lineOf("installed", root.line),
            "'installed' is false — this config describes an instance that has not finished setup. Run the installer (or restore the real config) before treating this as a deploy.");
        } else if (installedVal === null && installedNode === null){
          add("note", root.line,
            "'installed' key is not in the text — the audit cannot confirm install state from the config alone.");
        }
        if (maintVal === true){
          add("warning", lineOf("maintenance", root.line),
            "'maintenance' is true — the instance is in maintenance mode and users are locked out. Fine mid-upgrade; set it back to false before calling the deploy done.");
        }
        if (installedVal === true && maintVal === false){
          add("note", lineOf("installed", root.line),
            "Instance posture reads live: 'installed' is true and 'maintenance' is false.");
        }

        /* --- Logging posture --- */
        var logNode = val("loglevel");
        var logVal = logNode ? scalarNum(logNode) : null;
        if (logVal === 0){
          add("warning", lineOf("loglevel", root.line),
            "'loglevel' is 0 — the most verbose setting. Debug-level logs grow fast and can record sensitive detail; production instances usually run 2 (warnings and above).");
        } else if (logVal === 1){
          add("note", lineOf("loglevel", root.line),
            "'loglevel' is 1 (info) — chattier than production needs; expect large log files.");
        } else if (logVal !== null){
          add("note", lineOf("loglevel", root.line),
            "'loglevel' is " + logVal + " — a calm production setting.");
        }
        var logTypeNode = val("log_type");
        var logType = logTypeNode ? scalarStr(logTypeNode) : null;
        if (logType !== null){
          add("note", lineOf("log_type", root.line),
            "'log_type' is '" + logType + "' — make sure that destination is actually collected and rotated on the server, or problems will pass unnoticed.");
        }

        /* --- Memcache / Redis password posture --- */
        var redisEntry = last("redis");
        var redisHasPassword = false, redisPasswordEmpty = false, redisPasswordLine = null;
        if (redisEntry && redisEntry.value.kind === "array"){
          redisEntry.value.entries.forEach(function(e){
            if (e.key === "password"){
              var pv = scalarStr(e.value);
              redisPasswordLine = e.keyLine;
              if (pv !== null && pv !== "") redisHasPassword = true;
              else redisPasswordEmpty = true;
            }
          });
        }
        var memcacheUsesRedis = false, memcacheRedisLine = null;
        ["memcache.local", "memcache.distributed", "memcache.locking"].forEach(function(k){
          var e = last(k);
          if (!e) return;
          var v = scalarStr(e.value);
          if (v !== null && /redis/i.test(v)){ memcacheUsesRedis = true; memcacheRedisLine = e.keyLine; }
        });
        if (redisEntry){
          if (redisHasPassword){
            add("note", redisPasswordLine || redisEntry.keyLine,
              "The 'redis' array sets a password (named by key only — the value is never shown). Good: the cache is not left open.");
          } else {
            add("warning", redisEntry.keyLine,
              "Redis is configured with no password in its 'redis' array. Anyone who can reach the Redis port can read and write the cache and session data — set a 'password' entry in the redis array and requirepass on the server.");
          }
        } else if (memcacheUsesRedis){
          add("warning", memcacheRedisLine || root.line,
            "A memcache key points at Redis, but no 'redis' connection array was found in the text — so no Redis password is configured anywhere the audit can see. Add the 'redis' array with a 'password' entry.");
        }
        if (!redisEntry && redisPasswordEmpty){ /* unreachable guard, kept for clarity */ }
        if (!last("memcache.local")){
          add("note", root.line,
            "No 'memcache.local' is configured — Nextcloud runs noticeably slower without a local cache. APCu or Redis is the usual fix.");
        }

        /* --- Updater / app store / local remote posture --- */
        var channelNode = val("updater.release.channel");
        var channel = channelNode ? scalarStr(channelNode) : null;
        if (channel !== null){
          if (channel === "daily" || channel === "beta"){
            add("warning", lineOf("updater.release.channel", root.line),
              "'updater.release.channel' is '" + channel + "' — pre-release builds on a production instance trade stability for novelty. 'stable' or 'production' is the deploy-grade channel.");
          } else {
            add("note", lineOf("updater.release.channel", root.line),
              "'updater.release.channel' is '" + channel + "'.");
          }
        }
        if (scalarBool(val("updatechecker")) === false){
          add("note", lineOf("updatechecker", root.line),
            "'updatechecker' is off — nobody will be told when security updates land. Someone has to watch releases manually instead.");
        }
        var appstoreNode = val("appstoreenabled");
        var appstoreVal = appstoreNode ? scalarBool(appstoreNode) : null;
        if (appstoreVal === false){
          add("note", lineOf("appstoreenabled", root.line),
            "'appstoreenabled' is false — apps install and update by hand only. A deliberate, defensible posture.");
        } else if (appstoreVal === true){
          add("note", lineOf("appstoreenabled", root.line),
            "'appstoreenabled' is true — admins can install apps from the store; make sure only trusted admins hold that right.");
        }
        var alrsNode = val("allow_local_remote_servers");
        var alrsVal = alrsNode ? scalarBool(alrsNode) : null;
        if (alrsVal === true){
          add("warning", lineOf("allow_local_remote_servers", root.line),
            "'allow_local_remote_servers' is true — the instance is allowed to fetch from local-network addresses, which widens server-side request forgery risk. Turn it off unless a federation or preview feature genuinely needs it.");
        }

        /* --- Unknown keys: counted, never named --- */
        if (unknownCount > 0){
          add("note", root.line,
            unknownCount + " top-level key" + (unknownCount === 1 ? " is" : "s are") +
            " outside this auditor's check list — NOT AUDITED. (Keys are counted, never named here.) A clean verdict covers the audited keys only.");
        }

        /* --- Verdict --- */
        var blockers = findings.filter(function(f){ return f.sev === "blocker"; }).length;
        var warnings = findings.filter(function(f){ return f.sev === "warning"; }).length;
        var notes = findings.filter(function(f){ return f.sev === "note"; }).length;
        var verdict = blockers > 0 ? "DO NOT DEPLOY" : (warnings > 0 ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY");
        return {
          state: "ok", verdict: verdict, findings: findings,
          counts: {
            blockers: blockers, warnings: warnings, notes: notes,
            keys: totalKeyed, unknown: unknownCount
          }
        };
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-nextcloud-server-config-safety-auditor',
  name: 'J-Dawgs Nextcloud Server Config Safety Auditor',
  description: 'Nextcloud startup only answers whether the config loads; this grades a pasted config.php offline, anywhere — debug mode left on, trusted_domains gaps, and secret posture judged by key name and line only — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
