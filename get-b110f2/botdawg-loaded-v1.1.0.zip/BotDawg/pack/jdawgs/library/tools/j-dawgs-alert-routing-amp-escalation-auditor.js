'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Alert Routing & Escalation Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var SEVERITIES = { critical: true, high: true, medium: true, low: true };
      var STATUSES = { active: true, departed: true, "on-leave": true };

      var EXAMPLES = {
        broken: {
          routing: "DatabaseDown | critical | Priya | 30 | \nPaymentFailures | critical | Omar | 15 | Priya\nDiskFull | high | Omar | 60 | ",
          roster: "Priya | departed | America/Chicago\nOmar | active | America/Chicago"
        },
        clean: {
          routing: "DatabaseDown | critical | Omar | 15 | Lena\nPaymentFailures | critical | Lena | 15 | Omar\nDiskFull | high | Omar | 60 | Lena",
          roster: "Omar | active | America/Chicago\nLena | active | America/Chicago"
        }
      };

      function el(id) { return document.getElementById(id); }

      function splitLines(text) {
        return String(text || "").split(/\r\n|\r|\n/);
      }

      function parseRoster(text) {
        var people = {};   // lowercased name -> {name, status, timezone, line}
        var order = [];
        var findings = [];
        var lines = splitLines(text);
        for (var i = 0; i < lines.length; i++) {
          var raw = lines[i];
          var lineNo = i + 1;
          if (!raw.trim()) continue;
          var parts = raw.split("|").map(function (s) { return s.trim(); });
          if (parts.length < 2 || !parts[0] || !parts[1]) {
            findings.push({
              level: "WARNING", source: "roster", line: lineNo, alert: null,
              check: "UNPARSABLE LINE",
              message: "Roster line " + lineNo + " could not be parsed — expected \"name | status | timezone (optional)\".",
              fix: "Rewrite the line in the roster format, or remove it. The line was excluded from the audit."
            });
            continue;
          }
          var status = parts[1].toLowerCase();
          if (!STATUSES[status]) {
            findings.push({
              level: "WARNING", source: "roster", line: lineNo, alert: null,
              check: "INVALID STATUS",
              message: "Roster line " + lineNo + " (\"" + parts[0] + "\") has status \"" + parts[1] + "\", which is not one of active / departed / on-leave.",
              fix: "Set the status to active, departed, or on-leave. This person was excluded from the audit, so alerts routed to them will also read as unknown recipients."
            });
            continue;
          }
          var key = parts[0].toLowerCase();
          if (!people[key]) order.push(key);
          people[key] = { name: parts[0], status: status, timezone: parts[2] || "", line: lineNo };
        }
        return { people: people, order: order, findings: findings };
      }

      function parseRouting(text) {
        var alerts = [];
        var findings = [];
        var lines = splitLines(text);
        for (var i = 0; i < lines.length; i++) {
          var raw = lines[i];
          var lineNo = i + 1;
          if (!raw.trim()) continue;
          var parts = raw.split("|").map(function (s) { return s.trim(); });
          if (parts.length < 4 || !parts[0] || !parts[2]) {
            findings.push({
              level: "WARNING", source: "routing", line: lineNo, alert: parts[0] || null,
              check: "UNPARSABLE LINE",
              message: "Routing line " + lineNo + " could not be parsed — expected \"alert name | severity | recipient | response window in minutes | escalation recipient or blank\".",
              fix: "Rewrite the line in the routing format, or remove it. The line was excluded from the audit."
            });
            continue;
          }
          var severity = (parts[1] || "").toLowerCase();
          if (!SEVERITIES[severity]) {
            findings.push({
              level: "WARNING", source: "routing", line: lineNo, alert: parts[0],
              check: "INVALID SEVERITY",
              message: "Routing line " + lineNo + " (\"" + parts[0] + "\") has severity \"" + parts[1] + "\", which is not one of critical / high / medium / low.",
              fix: "Set the severity to critical, high, medium, or low. The line was excluded from the audit."
            });
            continue;
          }
          var windowRaw = parts[3] || "";
          var windowMin = null;
          if (windowRaw !== "") {
            var n = Number(windowRaw);
            if (isFinite(n)) windowMin = n;
          }
          alerts.push({
            name: parts[0],
            severity: severity,
            recipient: parts[2],
            windowRaw: windowRaw,
            windowMin: windowMin,
            escalation: parts.length > 4 ? (parts[4] || "") : "",
            line: lineNo,
            worst: null // filled in during checks: "BLOCKER" | "WARNING" | null
          });
        }
        return { alerts: alerts, findings: findings };
      }

      function audit(routingText, rosterText) {
        var roster = parseRoster(rosterText);
        var routing = parseRouting(routingText);
        var findings = routing.findings.concat(roster.findings);
        var people = roster.people;

        function flag(alert, level, check, message, fix) {
          findings.push({
            level: level, source: "routing", line: alert.line, alert: alert.name,
            check: check, message: message, fix: fix
          });
          if (level === "BLOCKER") alert.worst = "BLOCKER";
          else if (level === "WARNING" && alert.worst !== "BLOCKER") alert.worst = "WARNING";
        }

        // Per-alert checks
        routing.alerts.forEach(function (a) {
          var recKey = a.recipient.toLowerCase();
          var rec = people[recKey];
          if (!rec) {
            flag(a, "BLOCKER", "UNKNOWN RECIPIENT",
              "\"" + a.name + "\" (routing line " + a.line + ") is routed to " + a.recipient + ", who is not on the roster at all.",
              "Add " + a.recipient + " to the roster with a status, or route the alert to someone who is on it.");
          } else if (rec.status === "departed" || rec.status === "on-leave") {
            flag(a, "BLOCKER", "RECIPIENT " + rec.status.toUpperCase(),
              "\"" + a.name + "\" (routing line " + a.line + ") is routed to " + a.recipient + ", whose roster status is " + rec.status + " — the alert fires to someone who cannot act on it.",
              "Route \"" + a.name + "\" to an active roster member.");
          }

          if (a.escalation) {
            var escKey = a.escalation.toLowerCase();
            var esc = people[escKey];
            if (!esc) {
              flag(a, "BLOCKER", "UNKNOWN RECIPIENT",
                "\"" + a.name + "\" (routing line " + a.line + ") escalates to " + a.escalation + ", who is not on the roster at all.",
                "Add " + a.escalation + " to the roster with a status, or change the escalation to someone who is on it.");
            } else if (esc.status === "departed" || esc.status === "on-leave") {
              flag(a, "BLOCKER", "ESCALATION " + esc.status.toUpperCase(),
                "\"" + a.name + "\" (routing line " + a.line + ") escalates to " + a.escalation + ", whose roster status is " + esc.status + " — if the first responder misses it, the escalation lands on someone who cannot act.",
                "Change the escalation for \"" + a.name + "\" to an active roster member.");
            }
          }

          if (a.severity === "critical" && !a.escalation) {
            flag(a, "BLOCKER", "NO ESCALATION",
              "\"" + a.name + "\" (routing line " + a.line + ") is critical and has no escalation recipient — if the first responder misses it, nobody else ever hears about it.",
              "Add an escalation recipient for \"" + a.name + "\".");
            flag(a, "WARNING", "SINGLE POINT OF FAILURE",
              "\"" + a.name + "\" (routing line " + a.line + ") is critical and its whole chain is one human: " + a.recipient + ". One missed page and the alert is gone.",
              "Add a second, active human to the chain for \"" + a.name + "\" as the escalation recipient.");
          } else if (a.severity === "critical" && a.escalation &&
                     a.escalation.toLowerCase() === a.recipient.toLowerCase()) {
            flag(a, "WARNING", "SINGLE POINT OF FAILURE",
              "\"" + a.name + "\" (routing line " + a.line + ") is critical and both the recipient and the escalation are " + a.recipient + " — the whole chain is one human.",
              "Set a different, active person as the escalation recipient for \"" + a.name + "\".");
          }

          if (a.windowRaw === "" || a.windowMin === null) {
            flag(a, "WARNING", "MISSING RESPONSE WINDOW",
              "\"" + a.name + "\" (routing line " + a.line + ") has no usable response window" + (a.windowRaw ? " (\"" + a.windowRaw + "\" is not a number of minutes)" : "") + " — nobody can tell how fast a human must respond.",
              "Give \"" + a.name + "\" a response window in minutes.");
          } else if (a.severity === "critical" && a.windowMin > 60) {
            flag(a, "WARNING", "SLOW CRITICAL WINDOW",
              "\"" + a.name + "\" (routing line " + a.line + ") is critical but allows a " + a.windowMin + "-minute response window — over the 60-minute line for a critical alert.",
              "Bring the response window for \"" + a.name + "\" down to 60 minutes or less.");
          }
        });

        // Conflict check: same alert name twice with different recipients or windows
        var firstByName = {};
        routing.alerts.forEach(function (a) {
          var key = a.name.toLowerCase();
          if (!firstByName[key]) { firstByName[key] = a; return; }
          var first = firstByName[key];
          var diffs = [];
          if (first.recipient.toLowerCase() !== a.recipient.toLowerCase()) diffs.push("different recipients (" + first.recipient + " vs " + a.recipient + ")");
          if (first.windowRaw !== a.windowRaw) diffs.push("different response windows (" + (first.windowRaw || "blank") + " vs " + (a.windowRaw || "blank") + ")");
          if (diffs.length) {
            findings.push({
              level: "WARNING", source: "routing", line: a.line, alert: a.name,
              check: "CONFLICT",
              message: "\"" + a.name + "\" appears on routing lines " + first.line + " and " + a.line + " with " + diffs.join(" and ") + " — the two rows disagree about who gets paged.",
              fix: "Keep one row for \"" + a.name + "\", or make both rows identical, so there is exactly one routing for this alert."
            });
            if (a.worst !== "BLOCKER") a.worst = "WARNING";
            if (first.worst !== "BLOCKER") first.worst = "WARNING";
          }
        });

        // INFO: roster members who receive no alert at all
        var used = {};
        routing.alerts.forEach(function (a) {
          used[a.recipient.toLowerCase()] = true;
          if (a.escalation) used[a.escalation.toLowerCase()] = true;
        });
        roster.order.forEach(function (key) {
          if (!used[key]) {
            var p = people[key];
            findings.push({
              level: "INFO", source: "roster", line: p.line, alert: null,
              check: "RECEIVES NO ALERTS",
              message: p.name + " (roster line " + p.line + ", status " + p.status + ") is on the roster but receives no alert — not as a recipient and not as an escalation.",
              fix: "No fix required. If " + p.name + " should be in a chain, add them to a routing row; otherwise this is just spare coverage."
            });
          }
        });

        var rank = { BLOCKER: 0, WARNING: 1, INFO: 2 };
        findings.sort(function (x, y) {
          if (rank[x.level] !== rank[y.level]) return rank[x.level] - rank[y.level];
          if (x.source !== y.source) return x.source === "routing" ? -1 : 1;
          return x.line - y.line;
        });

        var counts = { blocker: 0, warning: 0, info: 0, total: findings.length };
        findings.forEach(function (f) {
          if (f.level === "BLOCKER") counts.blocker++;
          else if (f.level === "WARNING") counts.warning++;
          else counts.info++;
        });

        var verdict;
        if (counts.blocker > 0) verdict = "ALERTS WILL BE MISSED";
        else if (counts.warning > 0) verdict = "ROUTING GAPS";
        else verdict = "EVERY ALERT HAS A HUMAN";

        var coverage = routing.alerts.map(function (a) {
          var rec = people[a.recipient.toLowerCase()];
          var esc = a.escalation ? people[a.escalation.toLowerCase()] : null;
          return {
            alert: a.name,
            severity: a.severity,
            line: a.line,
            firstResponder: a.recipient,
            firstResponderStatus: rec ? rec.status : "not on roster",
            escalation: a.escalation || null,
            escalationStatus: a.escalation ? (esc ? esc.status : "not on roster") : null,
            responseWindowMinutes: a.windowMin,
            verdict: a.worst === "BLOCKER" ? "BLOCKER" : (a.worst === "WARNING" ? "WARNING" : "COVERED")
          };
        });

        return { verdict: verdict, counts: counts, findings: findings, coverage: coverage, alertCount: routing.alerts.length };
      }

      function verdictNote(result, hasInput) {
        if (!hasInput) return "Load a worked example above, or paste your own — the audit runs as soon as there is something to check.";
        if (result.verdict === "ALERTS WILL BE MISSED") return result.counts.blocker + (result.counts.blocker === 1 ? " blocker" : " blockers") + " — at least one alert is routed to someone who cannot act on it, or has no escalation. Those alerts fire into the void.";
        if (result.verdict === "ROUTING GAPS") return "Every alert reaches an active human, but there are gaps worth fixing — a single point of failure, a missing or slow window, or conflicting rows.";
        return "Every parsed alert routes to an active roster member, every critical alert has an escalation, and no chain depends on a single human.";
      }

      function buildTextReport(result) {
        var lines = [];
        lines.push("J-Dawgs Alert Routing & Escalation Auditor — report");
        lines.push("Verdict: " + result.verdict);
        lines.push("Counts: " + result.counts.blocker + " BLOCKER / " + result.counts.warning + " WARNING / " + result.counts.info + " INFO (" + result.counts.total + " findings)");
        lines.push("");
        if (!result.findings.length) {
          lines.push("Findings: none.");
        } else {
          lines.push("Findings:");
          result.findings.forEach(function (f, idx) {
            lines.push((idx + 1) + ". [" + f.level + "] " + f.check + " — " + f.message);
            lines.push("   Fix: " + f.fix);
          });
        }
        lines.push("");
        lines.push("Coverage:");
        if (!result.coverage.length) {
          lines.push("(no parseable alert rows)");
        } else {
          result.coverage.forEach(function (c) {
            lines.push("- " + c.alert + " (" + c.severity + ") -> " + c.firstResponder + " [" + c.firstResponderStatus + "]" +
              (c.escalation ? ", escalates to " + c.escalation + " [" + c.escalationStatus + "]" : ", no escalation") +
              ", window " + (c.responseWindowMinutes === null ? "not set" : c.responseWindowMinutes + " min") +
              " => " + c.verdict);
          });
        }
        return lines.join("\n");
      }

      function buildJsonReport(result) {
        return JSON.stringify({
          tool: "J-Dawgs Alert Routing & Escalation Auditor",
          verdict: result.verdict,
          counts: {
            blocker: result.counts.blocker,
            warning: result.counts.warning,
            info: result.counts.info,
            total: result.counts.total
          },
          alertsAudited: result.alertCount,
          findings: result.findings.map(function (f) {
            return {
              level: f.level,
              check: f.check,
              source: f.source,
              line: f.line,
              alert: f.alert,
              message: f.message,
              fix: f.fix
            };
          }),
          coverage: result.coverage
        }, null, 2);
      }

      function esc(s) {
        return String(s == null ? "" : s)
          .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
          .replace(/"/g, "&quot;");
      }

      function render() {
        var routingText = el("routing").value;
        var rosterText = el("roster").value;
        var hasInput = routingText.trim() !== "" || rosterText.trim() !== "";
        var result = audit(routingText, rosterText);

        var box = el("verdict-box");
        el("verdict-text").textContent = hasInput ? result.verdict : "Paste a routing table and a roster";
        el("verdict-note").textContent = verdictNote(result, hasInput);
        box.className = "verdict" + (hasInput ? (result.verdict === "EVERY ALERT HAS A HUMAN" ? " ok" : (result.verdict === "ROUTING GAPS" ? " gaps" : " missed")) : "");

        el("count-blocker").textContent = result.counts.blocker;
        el("count-warning").textContent = result.counts.warning;
        el("count-info").textContent = result.counts.info;
        el("count-total").textContent = result.counts.total;

        var fwrap = el("findings");
        if (!result.findings.length) {
          fwrap.innerHTML = '<p class="empty-note">' + (hasInput ? "No findings. Nothing in the paste breaks a check." : "No findings yet — paste a routing table and a roster, or load a worked example.") + "</p>";
        } else {
          fwrap.innerHTML = result.findings.map(function (f) {
            var lvl = f.level.toLowerCase();
            return '<div class="finding ' + lvl + '">' +
              '<div class="fhead"><span class="tag ' + lvl + '">' + f.level + '</span>' +
              '<span class="fname">' + esc(f.alert || (f.source === "roster" ? "Roster" : "Routing")) + '</span>' +
              '<span class="fline">' + f.source + " line " + f.line + " · " + esc(f.check) + '</span></div>' +
              "<p>" + esc(f.message) + "</p>" +
              '<p class="fix"><strong>Fix:</strong> ' + esc(f.fix) + "</p></div>";
          }).join("");
        }

        var cwrap = el("coverage");
        if (!result.coverage.length) {
          cwrap.innerHTML = '<p class="empty-note">No parseable alert rows yet.</p>';
        } else {
          var rows = result.coverage.map(function (c) {
            var rowClass = c.verdict === "BLOCKER" ? "blocker" : (c.verdict === "WARNING" ? "warning" : "ok");
            var rowLabel = c.verdict === "COVERED" ? "Covered" : c.verdict;
            return "<tr>" +
              '<td data-label="Alert"><strong>' + esc(c.alert) + '</strong> <span class="st">(line ' + c.line + ")</span></td>" +
              '<td data-label="Severity"><span class="pill sev-' + c.severity + '">' + c.severity + "</span></td>" +
              '<td data-label="First responder">' + esc(c.firstResponder) + ' <span class="st">(' + esc(c.firstResponderStatus) + ")</span></td>" +
              '<td data-label="Escalation">' + (c.escalation ? esc(c.escalation) + ' <span class="st">(' + esc(c.escalationStatus) + ")</span>" : '<span class="st">— none —</span>') + "</td>" +
              '<td data-label="Verdict"><span class="pill ' + rowClass + '">' + rowLabel + "</span></td>" +
              "</tr>";
          }).join("");
          cwrap.innerHTML = '<table class="coverage"><thead><tr><th>Alert</th><th>Severity</th><th>First responder</th><th>Escalation</th><th>Verdict</th></tr></thead><tbody>' + rows + "</tbody></table>";
        }

        el("report-text").value = hasInput ? buildTextReport(result) : "";
        el("report-json").value = hasInput ? buildJsonReport(result) : "";
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLES": (typeof EXAMPLES !== 'undefined' ? EXAMPLES : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-alert-routing-amp-escalation-auditor',
  name: 'J-Dawgs Alert Routing & Escalation Auditor',
  description: 'Alert checkers grade whether an alert fires; this cross-checks the routing table against the roster — departed recipients, missing escalations, single points of failure — into one verdict on whether every alert reaches a human who can act.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLES": __core["EXAMPLES"] }
};
