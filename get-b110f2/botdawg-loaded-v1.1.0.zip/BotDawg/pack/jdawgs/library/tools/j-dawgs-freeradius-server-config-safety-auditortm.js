'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs FreeRADIUS Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var RISKY = [
          "# Risky example — do not deploy anything like this.",
          "client world {",
          "    ipaddr = 0.0.0.0/0",
          "    secret = testing123",
          "    require_message_authenticator = no",
          "    nas_type = other",
          "}",
          "",
          "client world-backup {",
          "    ipaddr = 0.0.0.0/0",
          "    secret = testing123",
          "    require_message_authenticator = no",
          "}",
          "",
          "listen {",
          "    ipaddr = 0.0.0.0",
          "    port = 1812",
          "    type = auth",
          "}"
        ].join("\n");

        var HARDENED = [
          "# Hardened example — one NAS, one strong secret, one bound listener.",
          "# The secret below is a made-up placeholder, not a real credential.",
          "client core-nas-01 {",
          "    ipaddr = 192.0.2.10/32",
          "    secret = Kx9f-example-only-not-a-real-secret-7Qm2",
          "    require_message_authenticator = yes",
          "    nas_type = cisco",
          "}",
          "",
          "listen {",
          "    ipaddr = 192.0.2.5",
          "    port = 1812",
          "    type = auth",
          "}",
          "",
          "listen {",
          "    ipaddr = 192.0.2.5",
          "    port = 2083",
          "    type = auth+tls",
          "}"
        ].join("\n");

        var ta = document.getElementById("config");
        var resultsEl = document.getElementById("results");
        var verdictEl = document.getElementById("verdict");
        var countsEl = document.getElementById("counts");
        var findingsEl = document.getElementById("findings");
        var notparsedEl = document.getElementById("notparsed");
        var copyBtn = document.getElementById("btn-copy");
        var copyStatus = document.getElementById("copy-status");
        var lastReport = "";

        function stripQuotes(v) {
          v = v.trim();
          if (v.length >= 2 && ((v.charAt(0) === '"' && v.charAt(v.length - 1) === '"') || (v.charAt(0) === "'" && v.charAt(v.length - 1) === "'"))) {
            return v.slice(1, -1);
          }
          return v;
        }
        function firstToken(v) {
          var m = stripQuotes(v).split(/[\s#]/);
          return m[0] || "";
        }

        function parseIPv4Scope(value) {
          var m = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})(?:\/(\d{1,2}))?$/.exec(value.trim());
          if (!m) return null;
          return { text: value.trim(), prefix: m[5] !== undefined ? parseInt(m[5], 10) : 32 };
        }

        function audit(text) {
          var lines = text.split(/\r?\n/);
          var findings = [];   // {sev, line, msg}
          var notParsed = [];  // line numbers
          var clients = [];
          var listens = [];
          var stack = [];      // {kind: 'client'|'listen'|'unknown', data}

          // Pass 1 scan: the default secret anywhere is a blocker.
          // The value itself is never stored in any finding.
          var defaultSecretLines = {};
          lines.forEach(function (raw, i) {
            var m = /^\s*secret\s*=\s*(.+?)\s*$/.exec(raw.trim());
            if (m && stripQuotes(m[1]) === "testing123") {
              defaultSecretLines[i + 1] = true;
              findings.push({
                sev: "BLOCKER", line: i + 1,
                msg: "the secret on line " + (i + 1) + " is the well-known default secret value that ships in sample FreeRADIUS configs. Anyone who knows FreeRADIUS knows this value; replace it with a long random secret unique to this client."
              });
            }
          });

          function top() { return stack.length ? stack[stack.length - 1] : null; }

          lines.forEach(function (raw, idx) {
            var n = idx + 1;
            var line = raw.trim();
            if (line === "") return;
            if (line.charAt(0) === "#") return;
            var ctx = top();

            if (line === "}") {
              if (!stack.length) { notParsed.push(n); return; }
              var f = stack.pop();
              if (f.kind === "client") finalizeClient(f.data);
              else if (f.kind === "listen") finalizeListen(f.data);
              return;
            }

            if (!ctx) {
              var cm = /^client\s+([^\s{]+)?\s*\{$/.exec(line);
              if (cm) {
                var c = { name: cm[1] || "(unnamed)", startLine: n };
                clients.push(c);
                stack.push({ kind: "client", data: c });
                return;
              }
              if (/^listen\s*\{$/.test(line)) {
                var l = { startLine: n };
                listens.push(l);
                stack.push({ kind: "listen", data: l });
                return;
              }
            }

            var am = /^([A-Za-z][A-Za-z0-9_.-]*)\s*=\s*(.+)$/.exec(line);
            if (am && (!ctx || ctx.kind === "client" || ctx.kind === "listen")) {
              var key = am[1].toLowerCase();
              var val = am[2].trim();
              if (ctx && ctx.kind === "client") {
                var d = ctx.data;
                if ((key === "ipaddr" || key === "ipv4addr" || key === "ipnet") && !d.scope) {
                  d.scope = { value: stripQuotes(val), line: n };
                }
                if (key === "secret" && !d.secret) {
                  d.secret = { len: stripQuotes(val).length, line: n };
                }
                if (key === "require_message_authenticator" && !d.rma) {
                  d.rma = { value: firstToken(val).toLowerCase(), line: n };
                }
              } else if (ctx && ctx.kind === "listen") {
                var ld = ctx.data;
                if ((key === "ipaddr" || key === "ipv4addr") && !ld.ip) ld.ip = { value: stripQuotes(val), line: n };
                if (key === "port" && !ld.port) ld.port = { value: firstToken(val), line: n };
                if (key === "type" && !ld.type) ld.type = { value: firstToken(val).toLowerCase(), line: n };
              }
              // Top-level assignments are understood global settings; no check applies.
              return;
            }

            if (/\{$/.test(line)) {
              // A block this parser does not model (nested or unknown section).
              stack.push({ kind: "unknown" });
              notParsed.push(n);
              return;
            }
            notParsed.push(n);
          });

          while (stack.length) {
            var f2 = stack.pop();
            if (f2.kind === "client") finalizeClient(f2.data);
            else if (f2.kind === "listen") finalizeListen(f2.data);
          }

          // Duplicate client scopes.
          var seen = {};
          clients.forEach(function (c) {
            var scope = clientScope(c);
            if (!scope) return;
            var key = scope.value.toLowerCase();
            if (seen[key]) {
              findings.push({
                sev: "WARNING", line: scope.line,
                msg: "duplicate client definitions for " + scope.value + " on lines " + seen[key] + " and " + scope.line + ". In practice the later definition shadows the earlier one, so the first block's settings may silently not apply. Merge them into one block."
              });
            } else {
              seen[key] = scope.line;
            }
          });

          // RadSec / TLS posture (config-wide INFO, never a blocker).
          var hasTLS = listens.some(function (l) {
            return (l.type && l.type.value.indexOf("tls") !== -1) || (l.port && l.port.value === "2083");
          });
          if (!hasTLS) {
            findings.push({
              sev: "INFO", line: 1,
              msg: "no TLS/RadSec listener (type auth+tls or port 2083) appears anywhere in the pasted config. RadSec is optional and plain UDP RADIUS is the common setup, so this is a note, not a failure."
            });
          }

          var order = { BLOCKER: 0, WARNING: 1, INFO: 2 };
          findings.sort(function (a, b) {
            if (order[a.sev] !== order[b.sev]) return order[a.sev] - order[b.sev];
            return a.line - b.line;
          });
          notParsed.sort(function (a, b) { return a - b; });
          return { findings: findings, notParsed: notParsed };

          function clientScope(c) {
            if (c.scope) return c.scope;
            if (parseIPv4Scope(c.name) || c.name.indexOf(":") !== -1) {
              return { value: c.name, line: c.startLine };
            }
            return null;
          }

          function finalizeClient(c) {
            // Secret length (default-secret lines already reported above).
            if (c.secret && !defaultSecretLines[c.secret.line]) {
              if (c.secret.len < 8) {
                findings.push({
                  sev: "BLOCKER", line: c.secret.line,
                  msg: "the secret on line " + c.secret.line + " is only " + c.secret.len + " characters long (under 8). Short shared secrets are guessable; use at least 16 random characters."
                });
              } else if (c.secret.len < 16) {
                findings.push({
                  sev: "WARNING", line: c.secret.line,
                  msg: "the secret on line " + c.secret.line + " is " + c.secret.len + " characters long (under 16). Use at least 16 random characters for a shared secret."
                });
              }
            }
            // require_message_authenticator.
            if (!c.rma) {
              findings.push({
                sev: "WARNING", line: c.startLine,
                msg: "client \"" + c.name + "\" (line " + c.startLine + ") does not set require_message_authenticator. Without it, forged requests without a valid Message-Authenticator can be attempted against this client. Set require_message_authenticator = yes."
              });
            } else if (c.rma.value === "no" || c.rma.value === "false" || c.rma.value === "0") {
              findings.push({
                sev: "BLOCKER", line: c.rma.line,
                msg: "client \"" + c.name + "\" sets require_message_authenticator = " + c.rma.value + " on line " + c.rma.line + ". That switches off Message-Authenticator checking and opens the client to forged requests. Set it to yes."
              });
            } else if (c.rma.value !== "yes" && c.rma.value !== "true" && c.rma.value !== "1") {
              findings.push({
                sev: "WARNING", line: c.rma.line,
                msg: "client \"" + c.name + "\" has an unrecognized require_message_authenticator value on line " + c.rma.line + ". Use yes so Message-Authenticator checking is on."
              });
            }
            // Scope.
            var scope = clientScope(c);
            if (scope) {
              var parsed = parseIPv4Scope(scope.value);
              if (parsed) {
                if (parsed.prefix < 16) {
                  findings.push({
                    sev: "BLOCKER", line: scope.line,
                    msg: "client \"" + c.name + "\" covers " + parsed.text + " (line " + scope.line + ") — a prefix broader than /16. Anyone in that range, up to the whole internet at 0.0.0.0/0, can attempt authentication against this server. Narrow it to the actual NAS addresses."
                  });
                } else if (parsed.prefix <= 24) {
                  findings.push({
                    sev: "WARNING", line: scope.line,
                    msg: "client \"" + c.name + "\" accepts a /" + parsed.prefix + " network (" + parsed.text + ", line " + scope.line + "). Every host in that range can attempt authentication; narrow it to the NAS addresses that actually need access."
                  });
                }
              }
            }
          }

          function finalizeListen(l) {
            if (l.type && l.type.value === "status") {
              findings.push({
                sev: "WARNING", line: l.type.line,
                msg: "a listen section enables type = status on line " + l.type.line + ". The status listener answers server-status queries; leave it off unless something you run depends on it."
              });
              return;
            }
            if (l.ip && (l.ip.value === "0.0.0.0" || l.ip.value === "*" || l.ip.value === "0.0.0.0/0")) {
              var t = l.type ? l.type.value : "auth";
              if (t === "auth" || t === "acct" || t === "auth+acct" || !l.type) {
                findings.push({
                  sev: "WARNING", line: l.ip.line,
                  msg: "a listen section binds " + l.ip.value + " on line " + l.ip.line + " with type " + t + ", so the server answers authentication traffic on every interface. Bind a specific address unless the server really must listen everywhere."
                });
              }
            }
          }
        }

        function verdictFor(findings) {
          var b = 0, w = 0;
          findings.forEach(function (f) { if (f.sev === "BLOCKER") b++; if (f.sev === "WARNING") w++; });
          if (b > 0) return { key: "no", label: "DO NOT DEPLOY", sub: "At least one blocker must be fixed before this config goes near a production server." };
          if (w > 0) return { key: "fixes", label: "DEPLOY WITH FIXES", sub: "No blockers, but the warnings below should be fixed before this config is deployed." };
          return { key: "safe", label: "SAFE TO DEPLOY", sub: "No blockers or warnings found by the checks this auditor runs. It is still a heuristic text audit, not a live test." };
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-freeradius-server-config-safety-auditortm',
  name: 'J-Dawgs FreeRADIUS Server Config Safety Auditor',
  description: 'radiusd -C only checks a config on an installed host and stops at will-it-load; ours grades a pasted FreeRADIUS config anywhere — default/short secrets flagged by key name and line only (values never shown), require_message_authenticator, client scope breadth, duplicate clients — into one deploy ver',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
