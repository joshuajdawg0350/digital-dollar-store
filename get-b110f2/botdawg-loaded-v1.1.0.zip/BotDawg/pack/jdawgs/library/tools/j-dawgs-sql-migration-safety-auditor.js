'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs SQL Migration Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

  "use strict";

  var RISKY_MIGRATION = [
    "-- Worked example migration (risky) — preloaded so you can see a full audit",
    "BEGIN;",
    "CREATE INDEX idx_orders_customer ON orders (customer_id);",
    "ALTER TABLE users ADD COLUMN status text NOT NULL;",
    "ALTER TABLE users DROP COLUMN legacy_flag;",
    "DELETE FROM sessions;",
    "COMMIT;"
  ].join("\n");

  var CLEAN_MIGRATION = [
    "-- Clean example migration",
    "SET lock_timeout = '5s';",
    "CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_orders_customer ON orders (customer_id);",
    "ALTER TABLE users ADD COLUMN nickname text;",
    "ALTER TABLE orders ADD CONSTRAINT fk_orders_customer FOREIGN KEY (customer_id) REFERENCES customers (id) NOT VALID;"
  ].join("\n");

  var CLEAN_ROLLBACK = [
    "-- Clean example rollback — undoes each change above",
    "ALTER TABLE orders DROP CONSTRAINT IF EXISTS fk_orders_customer;",
    "ALTER TABLE users DROP COLUMN IF EXISTS nickname;",
    "DROP INDEX CONCURRENTLY IF EXISTS idx_orders_customer;"
  ].join("\n");

  var PITCH_TEXT = [
    "AI Tool Store — Tools AIs actually need, built by J-Dawgs: https://muse.ai/s/ai-tool-store-xng6xkxwjkxl2xab/UoF72OkKI7j33Q2ITxmrZyIr4nv40QtYfj2AgESh_k8",
    "J-Dawgs Agent Exchange — Shareware for AIs: https://muse.ai/s/j-dawgs-agent-exchange-ih6xlnihzxdhxc/ZbleqxFHRE0NcswaBkyN13y9lLp5rPAgHTb6t8ii-PY",
    "Ship the Change Safely Stack — SQL Migration Safety Auditor + Diff Intent & Scope Auditor + Stack Trace Triage Bench (vet the migration, vet the diff, triage the fallout)."
  ].join("\n");

  var migrationInput = document.getElementById("migrationInput");
  var rollbackInput = document.getElementById("rollbackInput");
  var statusLine = document.getElementById("statusLine");
  var resultsEl = document.getElementById("results");
  var lastReport = "";

  function setStatus(msg){ statusLine.textContent = msg; }

  function copyText(text, doneMsg){
    function fallback(){
      var ta = document.createElement("textarea");
      ta.value = text; ta.style.position = "fixed"; ta.style.opacity = "0";
      document.body.appendChild(ta); ta.select();
      try { document.execCommand("copy"); setStatus(doneMsg); }
      catch(e){ setStatus("Copy failed — select the text manually."); }
      document.body.removeChild(ta);
    }
    if (navigator.clipboard && navigator.clipboard.writeText){
      navigator.clipboard.writeText(text).then(function(){ setStatus(doneMsg); }, fallback);
    } else { fallback(); }
  }

  /* ---------- statement splitting (line-aware, comment-aware) ---------- */
  function stripLineComment(line){
    var idx = line.indexOf("--");
    return idx === -1 ? line : line.slice(0, idx);
  }

  function splitStatements(sql){
    var lines = sql.split("\n");
    var stmts = [];
    var buf = "", startLine = 0, inBlock = false;
    for (var i = 0; i < lines.length; i++){
      var raw = lines[i];
      var line = raw;
      // crude /* */ handling
      if (inBlock){
        var endB = line.indexOf("*/");
        if (endB === -1){ continue; }
        line = line.slice(endB + 2); inBlock = false;
      }
      var startB = line.indexOf("/*");
      if (startB !== -1 && line.indexOf("*/", startB) === -1){
        line = line.slice(0, startB); inBlock = true;
      } else if (startB !== -1){
        line = line.slice(0, startB) + line.slice(line.indexOf("*/", startB) + 2);
      }
      line = stripLineComment(line);
      if (!line.trim()){
        if (!buf) continue;
        else { buf += "\n"; continue; }
      }
      if (!buf) startLine = i + 1;
      buf += (buf ? "\n" : "") + line;
      if (line.indexOf(";") !== -1){
        stmts.push({ text: buf, line: startLine });
        buf = ""; startLine = 0;
      }
    }
    if (buf.trim()) stmts.push({ text: buf, line: startLine || lines.length });
    return stmts;
  }

  function quoteStart(text){
    var q = text.replace(/\s+/g, " ").trim();
    if (q.length > 76) q = q.slice(0, 76) + "…";
    return q;
  }

  var KNOWN_START = /^(ALTER|CREATE|DROP|DELETE|UPDATE|INSERT|TRUNCATE|LOCK|BEGIN|COMMIT|ROLLBACK|SET|GRANT|REVOKE|COMMENT|VACUUM|ANALYZE|DO|WITH|SELECT|START)\b/;

  /* ---------- the audit ---------- */
  function audit(migrationSql, rollbackSql){
    var findings = [];       // {line, sev, cat, title, quote, why, fix}
    var destructiveOps = []; // {kind, table, column, line, label}
    var lockTitles = [];

    function add(line, sev, cat, title, quote, why, fix){
      findings.push({ line: line, sev: sev, cat: cat, title: title, quote: quote, why: why, fix: fix });
      if (cat === "Lock risk") lockTitles.push(title);
    }

    var stmts = splitStatements(migrationSql);
    var hasBegin = /\bBEGIN\b/i.test(migrationSql);
    var hasLockTimeout = /lock_timeout/i.test(migrationSql);
    var concurrentlyLines = [];

    if (!migrationSql.trim()){
      add(1, "info", "Input", "Empty migration input",
        "(nothing pasted)",
        "There is no SQL to audit, so there is nothing to approve. An empty migration proves nothing either way.",
        "Paste the migration script, then run the audit again.");
    }

    stmts.forEach(function(st){
      var text = st.text;
      var up = text.toUpperCase().replace(/\s+/g, " ").trim();
      var quote = quoteStart(text);
      var line = st.line;

      if (!KNOWN_START.test(up)){
        add(line, "low", "Unparsable", "Line could not be parsed — excluded from checks",
          quote,
          "This statement does not start with a recognised SQL command, so the auditor cannot tell what it does. It was excluded from every other check rather than guessed at.",
          "Fix the syntax, or remove the line if it is not SQL. Re-run the audit once it parses.");
        return;
      }

      if (/\bCONCURRENTLY\b/.test(up)) concurrentlyLines.push(line);

      /* ----- DESTRUCTIVE ----- */
      var m;
      if (/^DROP\s+DATABASE\b/.test(up)){
        m = up.match(/^DROP\s+DATABASE\s+(?:IF\s+EXISTS\s+)?"?([A-Z0-9_]+)"?/);
        destructiveOps.push({ kind:"DROP DATABASE", table:(m?m[1].toLowerCase():""), column:"", line:line, label:"DROP DATABASE at line " + line });
        add(line, "critical", "Destructive", "DROP DATABASE — entire database destroyed", quote,
          "This deletes the whole database: every table, every row, gone in one statement. There is no undo inside SQL once it commits.",
          "Do not ship this in a normal migration. If a database really must go, take a verified backup first and run the drop as a separate, manual step.");
        if (!/\bIF\s+EXISTS\b/.test(up)) add(line, "low", "Guard missing", "DROP DATABASE without IF EXISTS", quote,
          "If the database name is wrong or already gone, this errors out mid-migration and can leave the deploy half-applied.", "Add IF EXISTS so the statement is safe to re-run.");
        return;
      }
      if (/^DROP\s+TABLE\b/.test(up)){
        m = up.match(/^DROP\s+TABLE\s+(?:IF\s+EXISTS\s+)?"?([A-Z0-9_.]+)"?/);
        var tname = m ? m[1].toLowerCase().replace(/"/g,"") : "";
        destructiveOps.push({ kind:"DROP TABLE", table:tname, column:"", line:line, label:"DROP TABLE " + (tname||"") + " at line " + line });
        add(line, "critical", "Destructive", "DROP TABLE — table and all its data destroyed", quote,
          "Dropping a table permanently deletes its structure and every row in it. Application code that still reads or writes this table will break immediately.",
          "Confirm nothing references this table, take a backup, and make sure the rollback recreates the table (data restore needs a backup — SQL alone cannot bring rows back).");
        if (!/\bIF\s+EXISTS\b/.test(up)) add(line, "low", "Guard missing", "DROP TABLE without IF EXISTS", quote,
          "Without IF EXISTS, re-running this migration errors on the missing table and can stall a deploy.", "Add IF EXISTS.");
        return;
      }
      if (/^TRUNCATE\b/.test(up)){
        m = up.match(/^TRUNCATE\s+(?:TABLE\s+)?"?([A-Z0-9_.]+)"?/);
        var trname = m ? m[1].toLowerCase().replace(/"/g,"") : "";
        destructiveOps.push({ kind:"TRUNCATE", table:trname, column:"", line:line, label:"TRUNCATE " + (trname||"") + " at line " + line });
        add(line, "critical", "Destructive", "TRUNCATE — every row deleted, near-instantly", quote,
          "TRUNCATE empties the whole table. It is fast precisely because it does not process rows one by one — and the data is gone just as fast, with no WHERE safety net.",
          "If only some rows should go, use DELETE with a WHERE clause instead. Otherwise, back the table up first and make sure the rollback plan restores from that backup.");
        return;
      }
      if (/^DELETE\b/.test(up) && !/\bWHERE\b/.test(up)){
        m = up.match(/^DELETE\s+FROM\s+"?([A-Z0-9_.]+)"?/);
        var dname = m ? m[1].toLowerCase().replace(/"/g,"") : "";
        destructiveOps.push({ kind:"DELETE (no WHERE)", table:dname, column:"", line:line, label:"DELETE without WHERE on " + (dname||"a table") + " at line " + line });
        add(line, "critical", "Destructive", "DELETE without a WHERE clause — deletes every row", quote,
          "With no WHERE clause, this DELETE removes every row in the table. That is almost never what a migration intends, and committed rows cannot be recovered without a backup.",
          "Add a WHERE clause that names exactly the rows to remove — and test it as a SELECT first to see what it would hit.");
        return;
      }
      if (/^UPDATE\b/.test(up) && !/\bWHERE\b/.test(up)){
        m = up.match(/^UPDATE\s+"?([A-Z0-9_.]+)"?/);
        var uname = m ? m[1].toLowerCase().replace(/"/g,"") : "";
        destructiveOps.push({ kind:"UPDATE (no WHERE)", table:uname, column:"", line:line, label:"UPDATE without WHERE on " + (uname||"a table") + " at line " + line });
        add(line, "critical", "Destructive", "UPDATE without a WHERE clause — rewrites every row", quote,
          "With no WHERE clause, this UPDATE overwrites the column(s) on every single row. The old values are lost unless you captured them first.",
          "Add a WHERE clause that scopes the change, and consider storing the old values somewhere before overwriting them.");
        return;
      }

      /* ----- ALTER TABLE family ----- */
      if (/^ALTER\s+TABLE\b/.test(up)){
        var tm = up.match(/^ALTER\s+TABLE\s+(?:IF\s+EXISTS\s+)?"?([A-Z0-9_.]+)"?/);
        var atable = tm ? tm[1].toLowerCase().replace(/"/g,"") : "";

        if (/\bDROP\s+COLUMN\b/.test(up)){
          var cm = up.match(/\bDROP\s+COLUMN\s+(?:IF\s+EXISTS\s+)?"?([A-Z0-9_]+)"?/);
          var cname = cm ? cm[1].toLowerCase().replace(/"/g,"") : "";
          destructiveOps.push({ kind:"DROP COLUMN", table:atable, column:cname, line:line, label:"DROP COLUMN " + (cname||"") + " on " + (atable||"a table") + " at line " + line });
          add(line, "critical", "Destructive", "DROP COLUMN — column and its data destroyed", quote,
            "Dropping a column permanently deletes that data for every row, and any running code that still selects or writes the column will error.",
            "First ship code that no longer uses the column, confirm nothing reads it, back up the data if it has any value, and make sure the rollback re-adds the column.");
        }
        if (/\bRENAME\s+COLUMN\b/.test(up) || /\bRENAME\s+TO\b/.test(up)){
          var isTable = /\bRENAME\s+TO\b/.test(up) && !/\bRENAME\s+COLUMN\b/.test(up);
          add(line, "medium", "Data risk", isTable ? "RENAME TABLE — breaks running code that uses the old name" : "RENAME COLUMN — breaks running code that uses the old name", quote,
            "A rename is instant, but every query, view, and line of already-deployed application code using the old name breaks the moment it lands. Old and new code cannot both work across the rename.",
            "Use an expand-and-contract approach: add the new name, dual-write, migrate readers, then drop the old name in a later migration.");
        }
        // ADD COLUMN checks
        var addCol = up.match(/\bADD\s+COLUMN\s+(?:IF\s+NOT\s+EXISTS\s+)?"?([A-Z0-9_]+)"?\s+([A-Z0-9_]+(?:\s*\(\s*\d+(?:\s*,\s*\d+)?\s*\))?)/) ||
                     up.match(/\bADD\s+(?!CONSTRAINT\b|FOREIGN\b|PRIMARY\b|UNIQUE\b|CHECK\b)"?([A-Z0-9_]+)"?\s+([A-Z0-9_]+(?:\s*\(\s*\d+(?:\s*,\s*\d+)?\s*\))?)/);
        if (addCol && !/\bADD\s+CONSTRAINT\b/.test(up) && !/\bADD\s+FOREIGN\s+KEY\b/.test(up)){
          var colSegment = up.slice(up.indexOf(addCol[0]));
          var volatile = /\bDEFAULT\s+[^,]*?(NOW\s*\(|RANDOM\s*\(|GEN_RANDOM_UUID\s*\(|UUID_GENERATE|NEXTVAL\s*\(|CLOCK_TIMESTAMP\s*\(|TXID_CURRENT)/.test(up);
          if (volatile){
            add(line, "high", "Lock risk", "ADD COLUMN with a volatile DEFAULT — full table rewrite risk", quote,
              "A default like now(), random(), or a UUID generator is computed per row, so PostgreSQL versions before 11 — and several other engines — rewrite the entire table to fill it in, holding a lock the whole time. Even on newer versions it deserves a second look.",
              "Add the column nullable with no default, backfill it in small batches, then set the default and any NOT NULL afterwards.");
          } else if (/\bNOT\s+NULL\b/.test(colSegment) && !/\bDEFAULT\b/.test(colSegment)){
            add(line, "high", "Lock risk", "ADD COLUMN … NOT NULL with no DEFAULT — fails or locks on a live table", quote,
              "Existing rows have no value for this column. PostgreSQL before version 11 refuses or rewrites the table; version 11+ still takes a lock to validate, and any insert path that doesn't supply the column breaks.",
              "Add the column nullable (or with a constant DEFAULT), backfill existing rows, then add the NOT NULL constraint in a separate step — ideally NOT VALID, then VALIDATE.");
          }
        }
        if (/\bADD\s+CONSTRAINT\b/.test(up) || /\bADD\s+FOREIGN\s+KEY\b/.test(up) || (/\bADD\b/.test(up) && /\bFOREIGN\s+KEY\b/.test(up))){
          if (!/\bNOT\s+VALID\b/.test(up)){
            add(line, "high", "Lock risk", "ADD CONSTRAINT / FOREIGN KEY without NOT VALID — scans and locks the table", quote,
              "Without NOT VALID, PostgreSQL validates the constraint against every existing row while holding a lock that blocks writes for the duration of the scan. On a large table that is real downtime.",
              "Add the constraint with NOT VALID, then run VALIDATE CONSTRAINT as a separate step — it holds a much weaker lock.");
          }
        }
        if (/\bALTER\s+COLUMN\b/.test(up) && /\bTYPE\b/.test(up) || /\bSET\s+DATA\s+TYPE\b/.test(up)){
          add(line, "high", "Lock risk", "ALTER COLUMN TYPE — rewrites and locks the table", quote,
            "Changing a column's type usually forces PostgreSQL to rewrite the whole table while holding an ACCESS EXCLUSIVE lock — reads and writes both block until it finishes.",
            "If the change is unavoidable, schedule it for a quiet window. The expand-and-contract pattern (new column, backfill, swap) avoids one long lock.");
          var vm = up.match(/\b(?:VARCHAR|CHARACTER\s+VARYING)\s*\(\s*(\d+)\s*\)/);
          if (vm){
            add(line, "medium", "Data risk", "Possible type narrowing — varchar(" + vm[1] + ") in a TYPE change", quote,
              "This changes the column to varchar(" + vm[1] + "). If the current type allows longer values, any stored value longer than " + vm[1] + " characters will fail the migration or be truncated. This auditor cannot see the existing definition, so verify it before applying.",
              "Check the column's current length first (information_schema) and only shrink when the longest stored value fits.");
          }
        }
      }

      /* ----- INDEXES ----- */
      if (/^CREATE\s+(UNIQUE\s+)?INDEX\b/.test(up)){
        if (!/\bCONCURRENTLY\b/.test(up)){
          add(line, "high", "Lock risk", "CREATE INDEX without CONCURRENTLY — blocks writes during the build", quote,
            "A plain CREATE INDEX takes a lock that blocks INSERT, UPDATE, and DELETE on the table for the entire build. On a busy or large table, that is downtime measured in the build's full duration.",
            "Use CREATE INDEX CONCURRENTLY — and remember it cannot run inside a transaction block, so remove the surrounding BEGIN/COMMIT for that statement.");
        }
        if (!/\bIF\s+NOT\s+EXISTS\b/.test(up)){
          add(line, "low", "Guard missing", "CREATE INDEX without IF NOT EXISTS", quote,
            "If this migration is re-run (after a partial failure, say), it errors on the already-existing index and stalls the deploy.", "Add IF NOT EXISTS.");
        }
      }
      if (/^DROP\s+INDEX\b/.test(up)){
        if (!/\bCONCURRENTLY\b/.test(up)){
          add(line, "high", "Lock risk", "DROP INDEX without CONCURRENTLY — takes a strong lock", quote,
            "A plain DROP INDEX locks the table briefly but exclusively; under load even a brief exclusive lock queues up behind long queries and can stall writes.",
            "Use DROP INDEX CONCURRENTLY (outside any transaction block).");
        }
        if (!/\bIF\s+EXISTS\b/.test(up)){
          add(line, "low", "Guard missing", "DROP INDEX without IF EXISTS", quote,
            "Re-running this migration errors if the index is already gone.", "Add IF EXISTS.");
        }
      }
      if (/^CREATE\s+TABLE\b/.test(up) && !/\bIF\s+NOT\s+EXISTS\b/.test(up)){
        add(line, "low", "Guard missing", "CREATE TABLE without IF NOT EXISTS", quote,
          "Re-running this migration errors on the already-existing table, which can leave a deploy stuck halfway.", "Add IF NOT EXISTS, or accept the failure mode knowingly.");
      }
      if (/^LOCK\s+TABLE\b/.test(up) || /^LOCK\b/.test(up) && /\bTABLE\b/.test(up)){
        add(line, "high", "Lock risk", "LOCK TABLE — explicit lock held until the transaction ends", quote,
          "An explicit LOCK TABLE holds its lock until COMMIT or ROLLBACK. In ACCESS EXCLUSIVE mode nothing else can even read the table; other modes still queue traffic behind it.",
          "Only lock when the migration truly requires it, keep the transaction as short as possible, and set a lock_timeout so it fails fast instead of queueing forever.");
      }
    });

    /* ----- transaction posture ----- */
    if (hasBegin && concurrentlyLines.length){
      add(concurrentlyLines[0], "high", "Transaction conflict", "CONCURRENTLY inside a BEGIN block — this combination fails", 
        "Line " + concurrentlyLines[0] + " uses CONCURRENTLY; the script also opens a transaction (BEGIN).",
        "CREATE / DROP INDEX CONCURRENTLY cannot run inside a transaction block — PostgreSQL rejects it outright, so this migration will fail at that statement, possibly after earlier statements have already run.",
        "Run the CONCURRENTLY statement outside the BEGIN…COMMIT block, as its own step in the deploy.");
    }
    if (!hasLockTimeout && migrationSql.trim()){
      add(0, "info", "Safety posture", "No lock_timeout set — informational only",
        "SET lock_timeout — not present anywhere in the script",
        "Without a lock_timeout, a migration statement that needs a strong lock will wait in line behind long-running queries — and everything behind it queues up too. This is a note, not a failure.",
        "Add SET lock_timeout = '5s'; (or similar) near the top so the migration fails fast and can be retried instead of blocking production.");
    }

    /* ----- rollback coverage ----- */
    var rb = (rollbackSql || "");
    var rbUp = rb.toUpperCase();
    var rollbackGaps = [];
    var rollbackText, rollbackState; // good | bad | neutral

    if (!rb.trim()){
      if (destructiveOps.length){
        rollbackText = "No rollback pasted — destructive changes have no proven undo here.";
        rollbackState = "bad";
      } else {
        rollbackText = "No rollback pasted. This audit found no destructive operations, so no undo was required by this check — but any change can still surprise you in production, and a rollback is cheap insurance.";
        rollbackState = "neutral";
      }
    } else if (!destructiveOps.length){
      rollbackText = "A rollback was pasted and no destructive operations were found in the migration, so there is nothing irreversible for it to cover. Coverage only — this tool does not run the rollback and cannot prove it works.";
      rollbackState = "good";
    } else {
      destructiveOps.forEach(function(op){
        var covered = false;
        if (op.kind === "DROP COLUMN"){
          covered = rbUp.indexOf("ADD COLUMN") !== -1 && op.column && rbUp.indexOf(op.column.toUpperCase()) !== -1 ||
                    rbUp.indexOf("ADD") !== -1 && op.column && rbUp.indexOf(op.column.toUpperCase()) !== -1;
        } else if (op.kind === "DROP TABLE"){
          covered = rbUp.indexOf("CREATE TABLE") !== -1 && op.table && rbUp.indexOf(op.table.toUpperCase().split(".").pop()) !== -1;
        } else if (op.kind === "DROP DATABASE"){
          covered = rbUp.indexOf("CREATE DATABASE") !== -1 && op.table && rbUp.indexOf(op.table.toUpperCase()) !== -1;
        } else if (op.kind === "TRUNCATE" || op.kind === "DELETE (no WHERE)"){
          covered = op.table && rbUp.indexOf(op.table.toUpperCase().split(".").pop()) !== -1 && (/\bINSERT\b/.test(rbUp) || /\bCOPY\b/.test(rbUp) || /\bRESTORE\b/.test(rbUp));
        } else if (op.kind === "UPDATE (no WHERE)"){
          covered = op.table && rbUp.indexOf(op.table.toUpperCase().split(".").pop()) !== -1 && (/\bUPDATE\b/.test(rbUp) || /\bINSERT\b/.test(rbUp) || /\bRESTORE\b/.test(rbUp));
        }
        if (!covered) rollbackGaps.push(op);
      });
      if (rollbackGaps.length){
        rollbackState = "bad";
        rollbackText = "ROLLBACK GAP — the pasted rollback does not cover " + rollbackGaps.length + " of " + destructiveOps.length +
          " destructive operation(s): " + rollbackGaps.map(function(o){ return o.label; }).join("; ") +
          ". A dropped column or table cannot be restored by SQL alone — data recovery needs a backup taken before the migration. Coverage only — this tool does not run the rollback and cannot prove it works.";
        rollbackGaps.forEach(function(op){
          add(op.line, "critical", "Rollback gap", "ROLLBACK GAP — no restore found for the destructive operation at line " + op.line,
            op.label,
            "The migration destroys data or structure here, and nothing in the pasted rollback restores it. If this migration goes wrong, there is no proven way back from this statement.",
            "Add a rollback statement that restores it (re-add the column / recreate the table), and back up the affected data before applying — a rollback script alone cannot resurrect dropped rows.");
        });
      } else {
        rollbackState = "good";
        rollbackText = "Rollback coverage: every destructive operation found has a corresponding restore statement in the pasted rollback (" +
          destructiveOps.map(function(o){ return o.label; }).join("; ") +
          "). Coverage only — this tool does not run the rollback and cannot prove it works. Test the rollback itself before you need it.";
      }
    }

    /* ----- verdict ----- */
    var critCount = findings.filter(function(f){ return f.sev === "critical"; }).length;
    var highCount = findings.filter(function(f){ return f.sev === "high"; }).length;
    var medCount  = findings.filter(function(f){ return f.sev === "medium"; }).length;
    var verdict, verdictClass, verdictWhy;
    if (critCount){
      verdict = "DO NOT APPLY"; verdictClass = "v-crit";
      verdictWhy = critCount + " critical finding(s): this script destroys data or structure, or has a rollback gap, exactly as written. Fix the critical items — or consciously accept each one with a backup in hand — before this goes anywhere near a real database.";
    } else if (highCount || medCount){
      verdict = "APPLY WITH FIXES"; verdictClass = "v-warn";
      verdictWhy = "Nothing irreversibly destructive was found, but " + (highCount + medCount) + " lock-risk or data-risk item(s) should be fixed first — they are the kind that turn a routine deploy into downtime.";
    } else {
      verdict = "SAFE TO APPLY"; verdictClass = "v-ok";
      verdictWhy = "No destructive, lock-risk, or data-risk operations were detected in the pasted text, and the transaction posture checks passed. This is a heuristic text verdict, not a guarantee — still test against a copy of your data.";
    }

    findings.sort(function(a,b){ return (a.line || 0) - (b.line || 0); });

    return {
      findings: findings, destructiveOps: destructiveOps, lockTitles: lockTitles,
      verdict: verdict, verdictClass: verdictClass, verdictWhy: verdictWhy,
      rollbackText: rollbackText, rollbackState: rollbackState,
      counts: { crit: critCount, high: highCount, med: medCount, total: findings.length }
    };
  }

  /* ---------- rendering ---------- */
  function esc(s){
    return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
  }
  var SEV_LABEL = { critical:"Critical", high:"High", medium:"Medium", low:"Low", info:"Info" };
  var SEV_CLASS = { critical:"crit", high:"high", medium:"med", low:"low", info:"info" };

  function buildReport(r){
    var out = [];
    out.push("J-Dawgs SQL Migration Safety Auditor(TM) — Audit Report");
    out.push("======================================================");
    out.push("VERDICT: " + r.verdict);
    out.push(r.verdictWhy);
    out.push("");
    out.push("Destructive operations: " + r.destructiveOps.length +
      (r.destructiveOps.length ? " (" + r.destructiveOps.map(function(o){return o.label;}).join("; ") + ")" : ""));
    out.push("Lock-risk findings: " + r.lockTitles.length +
      (r.lockTitles.length ? " (" + r.lockTitles.join("; ") + ")" : ""));
    out.push("Total findings: " + r.findings.length);
    out.push("");
    out.push("ROLLBACK CHECK");
    out.push(r.rollbackText);
    out.push("");
    out.push("FINDINGS BY LINE");
    if (!r.findings.length) out.push("(none)");
    r.findings.forEach(function(f){
      out.push("[" + SEV_LABEL[f.sev].toUpperCase() + "] " + (f.line ? "Line " + f.line : "Script-wide") + " — " + f.title + " (" + f.cat + ")");
      out.push("  Statement: " + f.quote);
      out.push("  Risk: " + f.why);
      out.push("  Fix: " + f.fix);
    });
    out.push("");
    out.push("LIMITS: Heuristic text audit of pasted SQL — not a real SQL parser, not a database-connected linter, and nothing was executed or connected to. Lock impact is graded by operation type, not row counts. PostgreSQL rules are the focus; other dialects get the general destructive checks only.");
    return out.join("\n");
  }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-sql-migration-safety-auditor',
  name: 'J-Dawgs SQL Migration Safety Auditor',
  description: 'Audits a pasted SQL migration and its optional rollback entirely offline — destructive operations, lock risks, and rollback gaps flagged by line, with one verdict and line-numbered fixes. It never connects to a database',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
