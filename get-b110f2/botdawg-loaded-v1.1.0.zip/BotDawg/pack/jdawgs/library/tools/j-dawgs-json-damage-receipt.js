'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs JSON Damage Receipt".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the analyze function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ================= examples ================= */
      var DAMAGED_EXAMPLE = [
        '{',
        '  "order_id": "ORD-8417",',
        '  "customer": "M. Alvarez",',
        '  "status": "packed",',
        '  "total": 129.95,',
        '  "items": [',
        '    { "sku": "WDG-100", "qty": 2, "note": "gift wrap" },',
        '    { "sku": "WDG-204", "qty": 1, "note": "leave at porch" },',
        '    { "sku": "WDG-317", "qty": 4, "note": "fragile - this end up, do not stack on the'
      ].join("\n");

      var EXAMPLE_SCHEMA = [
        '{',
        '  "type": "object",',
        '  "required": ["order_id", "customer", "status", "total", "items", "tracking_id"],',
        '  "properties": {',
        '    "order_id": { "type": "string" },',
        '    "customer": { "type": "string" },',
        '    "status": { "type": "string" },',
        '    "total": { "type": "number" },',
        '    "items": { "type": "array" },',
        '    "tracking_id": { "type": "string" }',
        '  }',
        '}'
      ].join("\n");

      var CLEAN_EXAMPLE = [
        '{',
        '  "order_id": "ORD-9001",',
        '  "customer": "J. Park",',
        '  "status": "delivered",',
        '  "total": 42.50,',
        '  "items": [',
        '    { "sku": "WDG-100", "qty": 1, "note": "none" }',
        '  ],',
        '  "tracking_id": "TRK-555-01"',
        '}'
      ].join("\n");

      /* ================= helpers ================= */
      function esc(s) {
        return String(s).replace(/[&<>"']/g, function (c) {
          return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
        });
      }
      function lineCol(text, offset) {
        var line = 1, col = 1;
        for (var k = 0; k < offset && k < text.length; k++) {
          if (text[k] === "\n") { line++; col = 1; } else { col++; }
        }
        return { line: line, col: col };
      }
      function trunc(s, max) {
        s = String(s);
        return s.length > max ? s.slice(0, max - 1) + "…" : s;
      }
      function previewOf(value) {
        var s;
        try { s = JSON.stringify(value); } catch (e) { s = String(value); }
        if (s === undefined) s = String(value);
        return trunc(s, 72);
      }
      function joinPath(base, key) {
        if (/^[A-Za-z_$][A-Za-z0-9_$]*$/.test(key)) return base + "." + key;
        return base + "[" + JSON.stringify(key) + "]";
      }

      /* ================= tolerant scanner =================
         Walks the raw text once, tracking string/escape state, a stack of
         open containers (as parent-linked nodes), and every recovered field. */
      function scan(text) {
        var n = text.length;
        var i = 0;
        var fields = [];      // {path, node, previewOverride, noteOverride}
        var containers = [];  // object/array nodes in opening order
        var syntaxError = null; // {offset, kind, detail, path}
        var cut = null;         // {offset, path, state, partial}
        var rootNode = null;

        function skipWs() { while (i < n && /\s/.test(text[i])) i++; }

        function decodeInner(inner) {
          return inner.replace(/\\(u[0-9a-fA-F]{4}|.)/g, function (m, g) {
            if (g.charAt(0) === "u") {
              try { return String.fromCharCode(parseInt(g.slice(1), 16)); } catch (e) { return m; }
            }
            switch (g) {
              case "n": return "\n"; case "t": return "\t"; case "r": return "\r";
              case "b": return "\b"; case "f": return "\f";
              default: return g;
            }
          });
        }

        function parseStringRaw() {
          var start = i;
          i++; // opening quote
          var inner = "";
          var closed = false;
          while (i < n) {
            var c = text[i];
            if (c === "\\") {
              if (i + 1 < n) { inner += text.substr(i, 2); i += 2; }
              else { inner += c; i = n; }
              continue;
            }
            if (c === '"') { closed = true; i++; break; }
            inner += c; i++;
          }
          return { closed: closed, value: decodeInner(inner), start: start };
        }

        function registerField(mark, path, node, previewOverride, noteOverride) {
          var f = { path: path, node: node, previewOverride: previewOverride || null, noteOverride: noteOverride || null };
          fields.splice(mark, 0, f);
          return f;
        }

        function parseValue(path, parent) {
          skipWs();
          if (i >= n) {
            if (!cut) cut = { offset: n, path: path, state: "the text ends where a value was expected" };
            return { type: "missing", complete: false, cut: true, parent: parent, path: path };
          }
          var c = text[i];
          if (c === "{") return parseObject(path, parent);
          if (c === "[") return parseArray(path, parent);
          if (c === '"') {
            var s = parseStringRaw();
            if (!s.closed) {
              if (!cut) cut = { offset: n, path: path, state: "the text ends mid-string", partial: s.value };
              return { type: "string", complete: false, cut: true, value: s.value, parent: parent, path: path };
            }
            return { type: "string", complete: true, value: s.value, parent: parent, path: path };
          }
          if (c === "-" || (c >= "0" && c <= "9")) {
            var ns = i;
            while (i < n && /[0-9eE+\-.]/.test(text[i])) i++;
            var rawNum = text.slice(ns, i);
            if (i >= n) {
              if (!cut) cut = { offset: n, path: path, state: "the text ends mid-number — the digits run to the very end of input", partial: rawNum };
              return { type: "number", complete: false, cut: true, value: rawNum, raw: rawNum, parent: parent, path: path };
            }
            return { type: "number", complete: true, value: Number(rawNum), raw: rawNum, parent: parent, path: path };
          }
          if (/[A-Za-z]/.test(c)) {
            var ls = i;
            while (i < n && /[A-Za-z]/.test(text[i])) i++;
            var word = text.slice(ls, i);
            if (word === "true" || word === "false" || word === "null") {
              return { type: "literal", complete: true, value: word, raw: word, parent: parent, path: path };
            }
            if (("true".indexOf(word) === 0 || "false".indexOf(word) === 0 || "null".indexOf(word) === 0) && word.length > 0) {
              if (i >= n) {
                if (!cut) cut = { offset: n, path: path, state: "the text ends mid-literal", partial: word };
                return { type: "literal", complete: false, cut: true, value: word, raw: word, parent: parent, path: path };
              }
            }
            if (!syntaxError) syntaxError = { offset: ls, kind: "stray token", detail: '"' + word + '" is not a JSON value (true, false, or null)', path: path };
            return { type: "invalid", complete: false, value: word, parent: parent, path: path };
          }
          if (!syntaxError) syntaxError = { offset: i, kind: "stray token", detail: 'unexpected character "' + c + '" where a value was expected', path: path };
          i++;
          return { type: "invalid", complete: false, parent: parent, path: path };
        }

        function parseObject(path, parent) {
          var node = { type: "object", path: path, parent: parent, closed: false, entries: [], startOffset: i };
          containers.push(node);
          i++; // {
          while (true) {
            skipWs();
            if (i >= n) {
              if (!cut) cut = { offset: n, path: path, state: "the text ends inside this object — its closing brace never arrived" };
              break;
            }
            if (text[i] === "}") { i++; node.closed = true; break; }
            if (text[i] !== '"') {
              if (/[A-Za-z_$]/.test(text[i])) {
                var ks0 = i;
                while (i < n && /[\w$]/.test(text[i])) i++;
                if (!syntaxError) syntaxError = { offset: ks0, kind: "unquoted key", detail: 'the key ' + text.slice(ks0, i) + " is not in quotes", path: path };
              } else if (!syntaxError) {
                syntaxError = { offset: i, kind: "stray token", detail: 'expected a quoted key but found "' + text[i] + '"', path: path };
              }
              break;
            }
            var ks = parseStringRaw();
            if (!ks.closed) {
              if (!cut) cut = { offset: n, path: joinPath(path, ks.value), state: "the text ends mid-string, inside a key", partial: ks.value };
              registerField(fields.length, joinPath(path, ks.value), { type: "string", complete: false, cut: true, value: ks.value, parent: node, path: joinPath(path, ks.value) }, '"' + trunc(ks.value, 60), "the key itself is cut off — its value never arrived");
              break;
            }
            var key = ks.value;
            var fpath = joinPath(path, key);
            skipWs();
            if (i >= n) {
              if (!cut) cut = { offset: n, path: fpath, state: "the text ends right after this key — its value never arrived" };
              registerField(fields.length, fpath, { type: "missing", complete: false, cut: true, parent: node, path: fpath }, "(no value)", "key is present, value never arrived");
              break;
            }
            if (text[i] !== ":") {
              if (!syntaxError) syntaxError = { offset: i, kind: "missing colon", detail: 'expected ":" after the key "' + key + '" but found "' + text[i] + '"', path: fpath };
              break;
            }
            i++; // :
            var mark = fields.length;
            var val = parseValue(fpath, node);
            node.entries.push({ key: key, value: val });
            registerField(mark, fpath, val);
            if (cut || syntaxError) break;
            skipWs();
            if (i >= n) {
              if (!cut) cut = { offset: n, path: path, state: "the text ends inside this object — its closing brace never arrived" };
              break;
            }
            if (text[i] === ",") {
              var commaPos = i; i++;
              skipWs();
              if (i < n && text[i] === "}") {
                if (!syntaxError) syntaxError = { offset: commaPos, kind: "trailing comma", detail: "a comma with no entry after it, right before }", path: path };
                i++; node.closed = true; break;
              }
              if (i >= n) {
                if (!cut) cut = { offset: n, path: path, state: "the text ends right after a comma inside this object" };
                break;
              }
              continue;
            }
            if (text[i] === "}") { i++; node.closed = true; break; }
            if (!syntaxError) syntaxError = { offset: i, kind: "stray token", detail: 'expected "," or "}" but found "' + text[i] + '"', path: path };
            break;
          }
          return node;
        }

        function parseArray(path, parent) {
          var node = { type: "array", path: path, parent: parent, closed: false, items: [], startOffset: i };
          containers.push(node);
          i++; // [
          var idx = 0;
          while (true) {
            skipWs();
            if (i >= n) {
              if (!cut) cut = { offset: n, path: path, state: "the text ends inside this array — its closing bracket never arrived" };
              break;
            }
            if (text[i] === "]") { i++; node.closed = true; break; }
            var epath = path + "[" + idx + "]";
            var mark = fields.length;
            var val = parseValue(epath, node);
            node.items.push(val);
            registerField(mark, epath, val);
            idx++;
            if (cut || syntaxError) break;
            skipWs();
            if (i >= n) {
              if (!cut) cut = { offset: n, path: path, state: "the text ends inside this array — its closing bracket never arrived" };
              break;
            }
            if (text[i] === ",") {
              var cp = i; i++;
              skipWs();
              if (i < n && text[i] === "]") {
                if (!syntaxError) syntaxError = { offset: cp, kind: "trailing comma", detail: "a comma with no element after it, right before ]", path: path };
                i++; node.closed = true; break;
              }
              if (i >= n) {
                if (!cut) cut = { offset: n, path: path, state: "the text ends right after a comma inside this array" };
                break;
              }
              continue;
            }
            if (text[i] === "]") { i++; node.closed = true; break; }
            if (!syntaxError) syntaxError = { offset: i, kind: "stray token", detail: 'expected "," or "]" but found "' + text[i] + '"', path: path };
            break;
          }
          return node;
        }

        skipWs();
        var rootStart = i;
        rootNode = parseValue("$", null);
        // trailing garbage after a complete root value = syntax damage
        if (rootNode && !cut && !syntaxError && (rootNode.type === "object" || rootNode.type === "array" ? rootNode.closed : rootNode.complete)) {
          skipWs();
          if (i < n) {
            syntaxError = { offset: i, kind: "stray token", detail: 'extra content after the root value: "' + trunc(text.slice(i), 24) + '"', path: "$" };
          }
        }
        return { fields: fields, containers: containers, syntaxError: syntaxError, cut: cut, root: rootNode, rootStart: rootStart };
      }

      /* ================= classification ================= */
      function ancestorsClosed(node) {
        var p = node.parent;
        while (p) {
          if ((p.type === "object" || p.type === "array") && !p.closed) return false;
          p = p.parent;
        }
        return true;
      }
      function classifyField(f) {
        var node = f.node;
        if (f.noteOverride && node.cut) {
          return { cls: "GUESSED / AT RISK", key: "guessed", preview: f.previewOverride, note: f.noteOverride };
        }
        if (node.type === "object" || node.type === "array") {
          var count = node.type === "object" ? node.entries.length : node.items.length;
          var label = node.type === "object"
            ? "{" + count + " field" + (count === 1 ? "" : "s") + " recovered}"
            : "[" + count + " element" + (count === 1 ? "" : "s") + " recovered]";
          if (!node.closed) {
            return { cls: "GUESSED / AT RISK", key: "guessed", preview: label + " — never closed", note: "this container never closed — it may be missing members past the cut" };
          }
          return ancestorsClosed(node)
            ? { cls: "INTACT", key: "intact", preview: label, note: "" }
            : { cls: "COMPLETED", key: "completed", preview: label, note: "value whole, but a container around it never closed" };
        }
        if (!node.complete) {
          var pv = node.type === "string" ? '"' + trunc(node.value, 60) : trunc(node.raw || node.value, 60);
          return { cls: "GUESSED / AT RISK", key: "guessed", preview: pv, note: "this value is the cut tail itself — treat it as partial" };
        }
        var pv2 = node.type === "string" ? previewOf(node.value) : (node.raw !== undefined ? node.raw : previewOf(node.value));
        return ancestorsClosed(node)
          ? { cls: "INTACT", key: "intact", preview: pv2, note: "" }
          : { cls: "COMPLETED", key: "completed", preview: pv2, note: "value whole, but a container around it never closed" };
      }

      /* ================= schema ================= */
      function schemaInfo(schemaText) {
        if (!schemaText || !schemaText.trim()) return { present: false };
        var parsed;
        try { parsed = JSON.parse(schemaText); }
        catch (e) { return { present: true, valid: false }; }
        if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return { present: true, valid: false };
        var required = Array.isArray(parsed.required) ? parsed.required.filter(function (r) { return typeof r === "string"; }) : [];
        var props = parsed.properties && typeof parsed.properties === "object" && !Array.isArray(parsed.properties) ? Object.keys(parsed.properties) : [];
        return { present: true, valid: true, required: required, properties: props };
      }
      function missingReport(info, rootKeys, fieldClassByPath) {
        // returns {missing:[], cutRequired:[], absentOptional:[]}
        var missing = [], cutRequired = [], absentOptional = [];
        if (!info.present || !info.valid) return null;
        info.required.forEach(function (r) {
          if (rootKeys.indexOf(r) === -1) missing.push(r);
          else {
            var cls = fieldClassByPath["$." + r] || fieldClassByPath['$["' + r + '"]'];
            if (cls === "guessed") cutRequired.push(r);
          }
        });
        info.properties.forEach(function (p) {
          if (info.required.indexOf(p) === -1 && rootKeys.indexOf(p) === -1) absentOptional.push(p);
        });
        return { missing: missing, cutRequired: cutRequired, absentOptional: absentOptional };
      }

      /* ================= clean walk ================= */
      function walkClean(value, path, parentClosed, out) {
        if (value !== null && typeof value === "object") {
          if (Array.isArray(value)) {
            value.forEach(function (el, idx) {
              var p = path + "[" + idx + "]";
              out.push({ path: p, cls: "INTACT", key: "intact", preview: previewOf(el), note: "" });
              walkClean(el, p, true, out);
            });
          } else {
            Object.keys(value).forEach(function (k) {
              var p = joinPath(path, k);
              out.push({ path: p, cls: "INTACT", key: "intact", preview: previewOf(value[k]), note: "" });
              walkClean(value[k], p, true, out);
            });
          }
        }
      }

      /* ================= main analysis ================= */
      function analyze(jsonText, schemaText) {
        var info = schemaInfo(schemaText);
        var trimmed = jsonText.replace(/^\s+/, "");
        var first = trimmed.charAt(0);

        // Not JSON at all: first character cannot begin any JSON value.
        var canStart = first === "{" || first === "[" || first === '"' || first === "-" ||
          (first >= "0" && first <= "9") || first === "t" || first === "f" || first === "n";
        if (!canStart) {
          return { kind: "notjson", firstChar: first, schema: info };
        }

        var parsed, parseOk = true;
        try { parsed = JSON.parse(jsonText); } catch (e) { parseOk = false; }

        if (parseOk) {
          var fields = [];
          if (parsed !== null && typeof parsed === "object") {
            walkClean(parsed, "$", true, fields);
          } else {
            fields.push({ path: "$", cls: "INTACT", key: "intact", preview: previewOf(parsed), note: "" });
          }
          var rootKeys = (parsed !== null && typeof parsed === "object" && !Array.isArray(parsed)) ? Object.keys(parsed) : [];
          var byPath = {};
          fields.forEach(function (f) { byPath[f.path] = f.key; });
          return {
            kind: "clean", fields: fields, schema: info,
            missing: missingReport(info, rootKeys, byPath),
            rootIsObject: rootKeys.length > 0 || (parsed !== null && typeof parsed === "object" && !Array.isArray(parsed))
          };
        }

        var res = scan(jsonText);
        // A stray-token error at the very first character with nothing recovered
        // (e.g. a lone symbol) is still "not JSON".
        if (res.fields.length === 0 && res.containers.length === 0 && res.syntaxError && res.syntaxError.offset === res.rootStart) {
          return { kind: "notjson", firstChar: first, schema: info };
        }

        var classified = res.fields.map(function (f) {
          var c = classifyField(f);
          return { path: f.path, cls: c.cls, key: c.key, preview: c.preview, note: c.note };
        });
        var counts = { intact: 0, completed: 0, guessed: 0 };
        classified.forEach(function (f) { counts[f.key]++; });

        var rootKeys2 = [];
        if (res.root && res.root.type === "object") {
          rootKeys2 = res.root.entries.map(function (e) { return e.key; });
        }
        var byPath2 = {};
        classified.forEach(function (f) { byPath2[f.path] = f.key; });
        var missing = missingReport(info, rootKeys2, byPath2);

        var unclosed = res.containers.filter(function (c) { return !c.closed; }).map(function (c) { return c.path; });

        var damage, verdict, verdictKey, reason;
        if (res.syntaxError) {
          var se = res.syntaxError;
          var lc = lineCol(jsonText, se.offset);
          damage = {
            kindLabel: "SYNTAX DAMAGE",
            pointLine: "Break at character offset " + se.offset + " (line " + lc.line + ", column " + lc.col + "), inside " + se.path + ".",
            detail: "Error kind: " + se.kind + " — " + se.detail + ". This error sits before the end of the text, so it is not a truncation."
          };
          verdict = "DAMAGED — DO NOT INGEST";
          verdictKey = "donot";
          reason = "A concrete syntax error breaks the text before it ends; recovery past that point cannot be trusted.";
        } else {
          var cutInfo = res.cut || { offset: jsonText.length, path: "$", state: "the text ends unexpectedly" };
          var lc2 = lineCol(jsonText, jsonText.length);
          var partialLine = cutInfo.partial !== undefined ? ' Partial tail: "' + trunc(cutInfo.partial, 60) + '"' : "";
          damage = {
            kindLabel: "TRUNCATION",
            pointLine: "Text ends at character offset " + jsonText.length + " (line " + lc2.line + ", column " + lc2.col + "). Innermost open path at the cut: " + cutInfo.path + ".",
            detail: "What happened: " + cutInfo.state + "." + partialLine
          };
          var trustworthy = counts.intact + counts.completed;
          if (trustworthy === 0) {
            verdict = "DAMAGED — DO NOT INGEST";
            verdictKey = "donot";
            reason = "The damage is inside the first field or before anything complete could be recovered — nothing here is trustworthy.";
          } else {
            verdict = "DAMAGED — PARTS TRUSTWORTHY";
            verdictKey = "parts";
            reason = trustworthy + " field" + (trustworthy === 1 ? "" : "s") + " recovered whole before the cut, and the damage is localized to one tail — the rest was cut off, not corrupted.";
          }
        }

        return {
          kind: "damaged", fields: classified, counts: counts, schema: info, missing: missing,
          unclosed: unclosed, damage: damage, verdict: verdict, verdictKey: verdictKey, reason: reason,
          textLength: jsonText.length
        };
      }
  return { "analyze": (typeof analyze !== 'undefined' ? analyze : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "DAMAGED_EXAMPLE": (typeof DAMAGED_EXAMPLE !== 'undefined' ? DAMAGED_EXAMPLE : undefined), "EXAMPLE_SCHEMA": (typeof EXAMPLE_SCHEMA !== 'undefined' ? EXAMPLE_SCHEMA : undefined), "CLEAN_EXAMPLE": (typeof CLEAN_EXAMPLE !== 'undefined' ? CLEAN_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["analyze"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-json-damage-receipt',
  name: 'J-Dawgs JSON Damage Receipt',
  description: 'A forensics receipt for truncated or repaired JSON: where the cut happened, and which fields are intact, completed, guessed, or missing. It reports the damage — it does not repair',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["analyze"]) return { ok: false, output: null, summary: 'Extracted core has no analyze function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "DAMAGED_EXAMPLE": __core["DAMAGED_EXAMPLE"], "EXAMPLE_SCHEMA": __core["EXAMPLE_SCHEMA"], "CLEAN_EXAMPLE": __core["CLEAN_EXAMPLE"] }
};
