'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Parse Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var RISKY_EXAMPLE = [
        "appId: myApp",
        "masterKey: abc123",
        "serverURL: http://api.example.com/parse",
        "databaseURI: mongodb://admin:P@ssw0rd-Planted-9911@db.example.com:27017/prod",
        "clientKey: abc123",
        "allowClientClassCreation: true",
        "enableAnonymousUsers: true",
        "verifyUserEmails: false"
      ].join("\n");

      var HARDENED_EXAMPLE = [
        "appId: jdawgs-prod-app-7f3k9q2x",
        "masterKey: K9vX2mQ7pL4wR8tY3nB6sD1fG5hJ0kM9xZ2qW7eR4tY6",
        "serverURL: https://parse.jdawgsindustries.com/parse",
        "databaseURI: mongodb+srv://cluster0.jdawgsindustries.net/prod",
        "# Database credentials are supplied through environment variables at deploy time.",
        "clientKey: A7bC3dE9fG2hJ5kL8mN1pQ4rS6tU0vW3xY7zB2cD5",
        "restAPIKey: M4nB7vC2xZ9lK6jH3gF8dS1aP5oI0uY7tR4eW9q",
        "javascriptKey: Q2wE5rT8yU1iO4pA7sD0fG3hJ6kL9zX2cV5bN8",
        "fileKey: Z8xC4vB7nM1qW5eR9tY2uI6oP3aS7dF0gH4j",
        "allowClientClassCreation: false",
        "enableAnonymousUsers: false",
        "publicServerURL: https://parse.jdawgsindustries.com/parse",
        "mountPath: /parse",
        "maxUploadSize: 20mb",
        "verifyUserEmails: true",
        "accountLockoutThreshold: 5",
        "lockoutDuration: 15"
      ].join("\n");

      // ---- Key normalization -------------------------------------------------
      var KEY_MAP = {
        "appid": "appId",
        "masterkey": "masterKey",
        "serverurl": "serverURL",
        "databaseuri": "databaseURI",
        "databaseurl": "databaseURI",
        "dburi": "databaseURI",
        "clientkey": "clientKey",
        "restapikey": "restAPIKey",
        "javascriptkey": "javascriptKey",
        "filekey": "fileKey",
        "allowclientclasscreation": "allowClientClassCreation",
        "enableanonymoususers": "enableAnonymousUsers",
        "publicserverurl": "publicServerURL",
        "mountpath": "mountPath",
        "maxuploadsize": "maxUploadSize",
        "verifyuseremails": "verifyUserEmails",
        "emailverifytokenvalidityduration": "emailVerifyTokenValidityDuration",
        "accountlockout": "accountLockout",
        "lockoutduration": "lockoutDuration",
        "accountlockoutduration": "lockoutDuration",
        "accountlockoutthreshold": "accountLockoutThreshold",
        "lockoutthreshold": "accountLockoutThreshold",
        "threshold": "threshold",
        "duration": "duration",
        "push": "push",
        "senderid": "senderId"
      };

      function squashKey(raw){
        return String(raw).toLowerCase().replace(/[_\-\s\.]/g, "");
      }
      function canonicalFor(raw, context){
        var sq = squashKey(raw);
        var base = KEY_MAP[sq] || null;
        if(context === "accountLockout" && (sq === "threshold" || sq === "duration")){
          return "accountLockout." + sq;
        }
        if(context === "push"){
          if(base){ return "push." + base; }
          return "push." + String(raw);
        }
        return base;
      }
      function topKey(canonical){
        if(!canonical){ return null; }
        var i = canonical.indexOf(".");
        return i === -1 ? canonical : canonical.slice(0, i);
      }

      var RECOGNIZED_TOP = {
        "appId":1, "masterKey":1, "serverURL":1, "databaseURI":1, "clientKey":1,
        "restAPIKey":1, "javascriptKey":1, "fileKey":1, "allowClientClassCreation":1,
        "enableAnonymousUsers":1, "publicServerURL":1, "mountPath":1, "maxUploadSize":1,
        "verifyUserEmails":1, "emailVerifyTokenValidityDuration":1, "accountLockout":1,
        "lockoutDuration":1, "accountLockoutThreshold":1, "push":1, "senderId":1
      };
      var SECRET_TOP = {
        "masterKey":1, "databaseURI":1, "clientKey":1, "restAPIKey":1,
        "javascriptKey":1, "fileKey":1, "appId":1, "push":1
      };

      function cleanValue(v){
        var s = String(v).trim();
        if(s.length && s.charAt(s.length - 1) === ","){ s = s.slice(0, s.length - 1).trim(); }
        if(s.length >= 2){
          var first = s.charAt(0), last = s.charAt(s.length - 1);
          if((first === '"' && last === '"') || (first === "'" && last === "'")){
            s = s.slice(1, s.length - 1);
          }
        }
        return s;
      }

      // ---- Parser -------------------------------------------------------------
      // Returns entries: {canonical, rawKey, value, line, context}
      function parseConfig(text){
        var lines = String(text).split(/\r?\n/);
        var entries = [];
        var contextStack = [];
        for(var idx = 0; idx < lines.length; idx++){
          var lineNo = idx + 1;
          var trimmed = lines[idx].trim();
          if(trimmed === ""){ continue; }
          if(trimmed.charAt(0) === "#" ){ continue; }
          if(trimmed.slice(0, 2) === "//"){ continue; }
          if(trimmed === "}" || trimmed === "}," || trimmed === "]" || trimmed === "],"){
            if(contextStack.length){ contextStack.pop(); }
            continue;
          }
          if(trimmed === "{"){
            continue;
          }
          var m = trimmed.match(/^["']?([A-Za-z0-9_.\-]+)["']?\s*[:=]\s*(.*)$/);
          if(!m){ continue; }
          var rawKey = m[1];
          var rest = m[2].trim();
          var context = contextStack.length ? contextStack[contextStack.length - 1] : null;
          var canonical = canonicalFor(rawKey, context);

          // Inline object on one line, e.g. accountLockout: { threshold: 5, duration: 15 }
          if(rest.charAt(0) === "{" && rest.indexOf("}") !== -1 && canonical){
            entries.push({ canonical: canonical, rawKey: rawKey, value: "{object}", line: lineNo, context: context });
            var inner = rest.slice(1, rest.lastIndexOf("}"));
            var innerCtx = (canonical === "accountLockout") ? "accountLockout" : (canonical === "push" ? "push" : canonical);
            var parts = inner.split(",");
            for(var p = 0; p < parts.length; p++){
              var pm = parts[p].trim().match(/^["']?([A-Za-z0-9_.\-]+)["']?\s*[:=]\s*(.*)$/);
              if(pm){
                var subCanon = canonicalFor(pm[1], innerCtx === "accountLockout" || innerCtx === "push" ? innerCtx : null);
                if(innerCtx === "push" && !subCanon){ subCanon = "push." + pm[1]; }
                if(subCanon){
                  entries.push({ canonical: subCanon, rawKey: pm[1], value: cleanValue(pm[2]), line: lineNo, context: innerCtx });
                }
              }
            }
            continue;
          }

          var value = cleanValue(rest);
          if(canonical){
            entries.push({ canonical: canonical, rawKey: rawKey, value: value, line: lineNo, context: context });
          } else {
            // Keep unrecognized-but-structured entries for push credential detection.
            entries.push({ canonical: null, rawKey: rawKey, value: value, line: lineNo, context: context });
          }

          if(rest.charAt(0) === "{" && rest.indexOf("}") === -1){
            if(canonical === "accountLockout"){ contextStack.push("accountLockout"); }
            else if(canonical === "push" || topKey(canonical || "") === "push"){ contextStack.push("push"); }
            else { contextStack.push(canonical || rawKey); }
          }
          if(rest.charAt(rest.length - 1) === "}" && contextStack.length){
            contextStack.pop();
          }
        }
        return entries;
      }

      function findEntry(entries, canonical){
        for(var i = 0; i < entries.length; i++){
          if(entries[i].canonical === canonical){ return entries[i]; }
        }
        return null;
      }
      function isTrueVal(v){ var s = String(v).toLowerCase().trim(); return s === "true" || s === "1" || s === "yes"; }
      function isFalseVal(v){ var s = String(v).toLowerCase().trim(); return s === "false" || s === "0" || s === "no"; }
      function isPlaceholder(v){
        var s = String(v).toLowerCase();
        return /(change[-_ ]?me|changeme|example|password|secret|your[-_]|placeholder|dummy|sample|replace[-_]|insert[-_]|todo)/.test(s)
          || s === "test" || s === "master" || s.indexOf("test-") === 0 || s.indexOf("test_") === 0;
      }
      function isLocalHost(url){
        var m = String(url).match(/^[a-z][a-z0-9+.\-]*:\/\/([^\/:?#]+)/i);
        if(!m){ return false; }
        var host = m[1].toLowerCase();
        return host === "localhost" || host === "127.0.0.1" || host === "::1" || host.slice(-10) === ".localhost";
      }
      function parseSizeMB(v){
        var s = String(v).toLowerCase().trim().replace(/["']/g, "");
        if(s.indexOf("unlimited") !== -1 || s === "-1" || s.indexOf("infinity") !== -1){ return Infinity; }
        var m = s.match(/^(\d+(?:\.\d+)?)\s*(b|byte|bytes|kb|mb|gb|tb)?$/);
        if(!m){ return null; }
        var n = parseFloat(m[1]);
        var unit = m[2] || "b";
        if(unit === "b" || unit === "byte" || unit === "bytes"){ return n / 1048576; }
        if(unit === "kb"){ return n / 1024; }
        if(unit === "mb"){ return n; }
        if(unit === "gb"){ return n * 1024; }
        if(unit === "tb"){ return n * 1048576; }
        return null;
      }

      // ---- Audit ---------------------------------------------------------------
      var SEV_ORDER = { "CRITICAL":0, "HIGH":1, "MEDIUM":2, "LOW":3, "PASS":4 };

      function audit(text){
        var entries = parseConfig(text);
        var findings = [];
        function add(sev, key, entry, isSecret, fix){
          findings.push({
            severity: sev,
            key: key,
            line: entry ? entry.line : null,
            length: (isSecret && entry) ? String(entry.value).length : null,
            fix: fix
          });
        }

        // Recognized key count (distinct top-level canonical keys)
        var seenTop = {};
        var i, e;
        for(i = 0; i < entries.length; i++){
          var t = topKey(entries[i].canonical);
          if(t && RECOGNIZED_TOP[t]){ seenTop[t] = 1; }
          // lockout flat keys count toward accountLockout recognition
          if(entries[i].canonical === "lockoutDuration" || entries[i].canonical === "accountLockoutThreshold"){ seenTop["accountLockout"] = 1; }
          if(entries[i].canonical === "accountLockout.threshold" || entries[i].canonical === "accountLockout.duration"){ seenTop["accountLockout"] = 1; }
        }
        var recognizedCount = 0;
        for(var k in seenTop){ if(Object.prototype.hasOwnProperty.call(seenTop, k)){ recognizedCount++; } }

        // masterKey
        var master = findEntry(entries, "masterKey");
        if(!master){
          add("CRITICAL", "masterKey", null, false, "Add a masterKey: generate a long random value (32 characters or more) and keep it only on the server, never in client code.");
        } else if(isPlaceholder(master.value)){
          add("CRITICAL", "masterKey", master, true, "This masterKey matches a placeholder or example pattern. Replace it with a long random value (32 characters or more) that has never been published.");
        } else if(master.value.length < 16){
          add("CRITICAL", "masterKey", master, true, "This masterKey is too short to resist guessing. Replace it with a random value of at least 32 characters.");
        } else if(master.value.length < 32){
          add("HIGH", "masterKey", master, true, "This masterKey is weak. Lengthen it to at least 32 random characters.");
        } else {
          add("PASS", "masterKey", master, true, "Master key is at least 32 characters with no placeholder pattern. Keep it server-side only.");
        }

        // appId
        var appId = findEntry(entries, "appId");
        if(!appId){
          add("HIGH", "appId", null, false, "Add an appId so clients and the server agree on which application this is.");
        } else if(isPlaceholder(appId.value)){
          add("HIGH", "appId", appId, true, "This appId matches a placeholder or example pattern. Set a real, unique appId of at least 8 characters.");
        } else if(appId.value.length < 8){
          add("HIGH", "appId", appId, true, "This appId is very short. Use a unique appId of at least 8 characters.");
        } else {
          add("PASS", "appId", appId, true, "App ID is set and is not a placeholder pattern.");
        }

        // databaseURI
        var db = findEntry(entries, "databaseURI");
        if(!db){
          add("HIGH", "databaseURI", null, false, "Add a databaseURI pointing at your MongoDB or Postgres database, with credentials supplied from the environment rather than pasted into shared config.");
        } else {
          var schemeM = db.value.match(/^([a-z][a-z0-9+.\-]*):\/\//i);
          var scheme = schemeM ? schemeM[1].toLowerCase() : "";
          var afterScheme = schemeM ? db.value.slice(schemeM[0].length) : db.value;
          var authority = afterScheme.split("/")[0];
          var atIdx = authority.lastIndexOf("@");
          var hasEmbeddedPassword = false;
          if(atIdx !== -1){
            var userinfo = authority.slice(0, atIdx);
            if(userinfo.indexOf(":") !== -1){ hasEmbeddedPassword = true; }
          }
          var knownScheme = (scheme === "mongodb" || scheme === "mongodb+srv" || scheme === "postgres" || scheme === "postgresql");
          if(hasEmbeddedPassword){
            add("CRITICAL", "databaseURI", db, true, "This database URI embeds a plaintext password in the connection string. Remove the password from the URI and supply credentials through environment variables or a secret store, then rotate the exposed password.");
          } else if(!knownScheme){
            add("MEDIUM", "databaseURI", db, true, "This database URI does not use a MongoDB or Postgres scheme. Confirm the URI scheme matches the database Parse Server is configured for.");
          } else {
            add("PASS", "databaseURI", db, true, "Database URI uses a MongoDB or Postgres scheme with no embedded password in the pasted text.");
          }
        }

        // serverURL
        var serverURL = findEntry(entries, "serverURL");
        if(!serverURL){
          add("HIGH", "serverURL", null, false, "Add a serverURL so Parse knows the address the API is served from, and use https in production.");
        } else if(/^http:\/\//i.test(serverURL.value)){
          if(isLocalHost(serverURL.value)){
            add("LOW", "serverURL", serverURL, false, "This serverURL uses http on a local host, which is fine for local development only. Use https before deploying.");
          } else {
            add("HIGH", "serverURL", serverURL, false, "This serverURL uses http, not https, on a public host. Serve Parse over https so keys and session tokens are not sent in the clear.");
          }
        } else if(/^https:\/\//i.test(serverURL.value)){
          add("PASS", "serverURL", serverURL, false, "Server URL uses https.");
        } else {
          add("MEDIUM", "serverURL", serverURL, false, "This serverURL has no clear http or https scheme. Set a full https URL for production.");
        }

        // publicServerURL
        var publicURL = findEntry(entries, "publicServerURL");
        if(!publicURL){
          add("LOW", "publicServerURL", null, false, "No publicServerURL is set. Set it to the public https address when email links, password resets, or push features need absolute URLs.");
        } else if(/^http:\/\//i.test(publicURL.value) && !isLocalHost(publicURL.value)){
          add("HIGH", "publicServerURL", publicURL, false, "This publicServerURL uses http, not https, on a public host. Change it to the public https address.");
        } else if(/^http:\/\//i.test(publicURL.value)){
          add("LOW", "publicServerURL", publicURL, false, "This publicServerURL uses http on a local host — fine for local development, https before deploying.");
        } else if(/^https:\/\//i.test(publicURL.value)){
          add("PASS", "publicServerURL", publicURL, false, "Public server URL uses https.");
        } else {
          add("LOW", "publicServerURL", publicURL, false, "This publicServerURL has no clear scheme. Use the full public https address.");
        }

        // allowClientClassCreation
        var accc = findEntry(entries, "allowClientClassCreation");
        if(!accc){
          add("MEDIUM", "allowClientClassCreation", null, false, "allowClientClassCreation is not set, so the Parse default applies and clients may be able to create new classes. Set it to false in production and create classes from the dashboard or server code.");
        } else if(isTrueVal(accc.value)){
          add("CRITICAL", "allowClientClassCreation", accc, false, "Client class creation is turned on: any client can create new classes in your database. Set allowClientClassCreation to false in production.");
        } else if(isFalseVal(accc.value)){
          add("PASS", "allowClientClassCreation", accc, false, "Client class creation is off.");
        } else {
          add("MEDIUM", "allowClientClassCreation", accc, false, "This allowClientClassCreation value is not a clear true or false. Set it explicitly to false for production.");
        }

        // enableAnonymousUsers
        var anon = findEntry(entries, "enableAnonymousUsers");
        if(!anon){
          add("LOW", "enableAnonymousUsers", null, false, "enableAnonymousUsers is not set, so the Parse default applies. Set it to false unless your app deliberately uses anonymous users.");
        } else if(isTrueVal(anon.value)){
          add("HIGH", "enableAnonymousUsers", anon, false, "Anonymous users are enabled: anyone can create an account with no credentials. Set enableAnonymousUsers to false unless the app truly needs anonymous accounts.");
        } else if(isFalseVal(anon.value)){
          add("PASS", "enableAnonymousUsers", anon, false, "Anonymous users are disabled.");
        } else {
          add("MEDIUM", "enableAnonymousUsers", anon, false, "This enableAnonymousUsers value is not a clear true or false. Set it explicitly, and prefer false.");
        }

        // Optional keys: clientKey, restAPIKey, javascriptKey, fileKey
        var optKeys = ["clientKey", "restAPIKey", "javascriptKey", "fileKey"];
        for(i = 0; i < optKeys.length; i++){
          var ok = optKeys[i];
          var oe = findEntry(entries, ok);
          if(!oe){
            add("LOW", ok, null, false, "No " + ok + " is set. That is acceptable when the key is unused, but any client key you do set should be long, random, and different from the masterKey.");
          } else if(isPlaceholder(oe.value)){
            add("HIGH", ok, oe, true, "This " + ok + " matches a placeholder or example pattern. Replace it with a long random value.");
          } else if(oe.value.length < 16){
            add("HIGH", ok, oe, true, "This " + ok + " is too short. Use a random value of at least 24 characters.");
          } else if(oe.value.length < 24){
            add("MEDIUM", ok, oe, true, "This " + ok + " is shorter than recommended. Lengthen it to at least 24 random characters.");
          } else {
            add("PASS", ok, oe, true, "This key is at least 24 characters with no placeholder pattern.");
          }
        }

        // Key reuse (compared internally only; values never shown)
        var secretKeys = ["masterKey", "clientKey", "restAPIKey", "javascriptKey", "fileKey"];
        for(i = 0; i < secretKeys.length; i++){
          for(var j = i + 1; j < secretKeys.length; j++){
            var a = findEntry(entries, secretKeys[i]);
            var b = findEntry(entries, secretKeys[j]);
            if(a && b && a.value !== "" && a.value === b.value){
              add("CRITICAL", secretKeys[j], b, true, "This key reuses the exact same value as " + secretKeys[i] + ". Every key must be unique — if the client key leaks, a reused value hands over the master key too. Generate a different random value for each key.");
            }
          }
        }

        // mountPath
        var mount = findEntry(entries, "mountPath");
        if(!mount){
          add("LOW", "mountPath", null, false, "No mountPath is set, so the Parse default mount applies. Setting an explicit mount path such as /parse keeps the API off the site root.");
        } else if(mount.value === "/"){
          add("MEDIUM", "mountPath", mount, false, "Parse is mounted at the root path. Mount it under a sub-path such as /parse so the API does not sit on the site root.");
        } else {
          add("PASS", "mountPath", mount, false, "Mount path is set to a sub-path rather than the root.");
        }

        // maxUploadSize
        var upload = findEntry(entries, "maxUploadSize");
        if(!upload){
          add("LOW", "maxUploadSize", null, false, "No maxUploadSize is set, so the Parse default upload limit applies. Set an explicit limit sized to what your app actually accepts.");
        } else {
          var mb = parseSizeMB(upload.value);
          if(mb === Infinity){
            add("HIGH", "maxUploadSize", upload, false, "The upload size is effectively unlimited. Set a finite maxUploadSize so uploads cannot fill the disk.");
          } else if(mb === null){
            add("MEDIUM", "maxUploadSize", upload, false, "This maxUploadSize value could not be read as a size. Use a plain value such as 20mb or a byte count.");
          } else if(mb > 500){
            add("HIGH", "maxUploadSize", upload, false, "This upload limit is very large (over 500 MB). Lower maxUploadSize to what the app genuinely needs.");
          } else if(mb > 100){
            add("MEDIUM", "maxUploadSize", upload, false, "This upload limit is over 100 MB. Confirm uploads that large are really needed, or lower maxUploadSize.");
          } else {
            add("PASS", "maxUploadSize", upload, false, "Upload size limit is finite and within a reasonable range.");
          }
        }

        // Account lockout
        var lockEntry = findEntry(entries, "accountLockout");
        var durEntry = findEntry(entries, "lockoutDuration") || findEntry(entries, "accountLockout.duration");
        var thrEntry = findEntry(entries, "accountLockoutThreshold") || findEntry(entries, "accountLockout.threshold");
        // Also accept a bare threshold/duration pair that arrived with lockout context or alongside lockout keys.
        if(!thrEntry){
          var bareThr = findEntry(entries, "threshold");
          if(bareThr && (lockEntry || durEntry)){ thrEntry = bareThr; }
        }
        if(!durEntry){
          var bareDur = findEntry(entries, "duration");
          if(bareDur && (lockEntry || thrEntry)){ durEntry = bareDur; }
        }
        var hasLockout = !!(lockEntry || durEntry || thrEntry);
        var lockAnchor = thrEntry || durEntry || lockEntry;
        if(!hasLockout){
          add("MEDIUM", "accountLockout", null, false, "No account lockout settings were found. Configure account lockout (for example a threshold of 5 failed attempts and a lockout duration of at least 5 minutes) so password guessing gets throttled.");
        } else {
          var thr = thrEntry ? parseFloat(thrEntry.value) : null;
          var dur = durEntry ? parseFloat(durEntry.value) : null;
          if(thr === null || isNaN(thr) || dur === null || isNaN(dur)){
            add("MEDIUM", "accountLockout", lockAnchor, false, "Account lockout is present but its threshold and duration could not both be read from the pasted config. Set an explicit threshold (5 or fewer failed attempts) and duration (at least 5 minutes).");
          } else if(thr > 10 || dur < 1){
            add("MEDIUM", "accountLockout", lockAnchor, false, "This lockout configuration is too loose: the threshold is over 10 attempts or the duration is under 1 minute. Tighten it to a threshold of 5 or fewer and a duration of at least 5 minutes.");
          } else if(thr <= 5 && dur >= 5){
            add("PASS", "accountLockout", lockAnchor, false, "Account lockout is configured with a threshold of 5 or fewer attempts and a duration of at least 5 minutes.");
          } else {
            add("MEDIUM", "accountLockout", lockAnchor, false, "This lockout configuration is weaker than recommended. Aim for a threshold of 5 or fewer failed attempts and a duration of at least 5 minutes.");
          }
        }

        // verifyUserEmails
        var verify = findEntry(entries, "verifyUserEmails");
        if(!verify){
          add("LOW", "verifyUserEmails", null, false, "verifyUserEmails is not set. Turn on email verification so accounts are tied to an address the user controls.");
        } else if(isTrueVal(verify.value)){
          add("PASS", "verifyUserEmails", verify, false, "Email verification is turned on.");
        } else if(isFalseVal(verify.value)){
          add("MEDIUM", "verifyUserEmails", verify, false, "Email verification is off, so anyone can register with an address they do not own. Set verifyUserEmails to true.");
        } else {
          add("LOW", "verifyUserEmails", verify, false, "This verifyUserEmails value is not a clear true or false. Set it explicitly to true.");
        }

        // emailVerifyTokenValidityDuration (only when present)
        var tokenDur = findEntry(entries, "emailVerifyTokenValidityDuration");
        if(tokenDur){
          var td = parseFloat(tokenDur.value);
          if(isNaN(td)){
            add("LOW", "emailVerifyTokenValidityDuration", tokenDur, false, "This email verification token duration could not be read as a number. Set it in seconds and keep it reasonably short.");
          } else {
            add("PASS", "emailVerifyTokenValidityDuration", tokenDur, false, "Email verification token duration is set.");
          }
        }

        // Push credentials
        for(i = 0; i < entries.length; i++){
          e = entries[i];
          var rawLow = String(e.rawKey).toLowerCase();
          var canon = e.canonical || "";
          var inPush = (e.context === "push") || canon.indexOf("push.") === 0 || canon === "push";
          var pushNamed = rawLow.indexOf("push") !== -1 || rawLow.indexOf("apn") !== -1 || rawLow === "senderid"
            || rawLow.indexOf("p12") !== -1 || rawLow.indexOf("cert") !== -1;
          var credNamed = rawLow.indexOf("apikey") !== -1 || rawLow.indexOf("password") !== -1
            || rawLow.indexOf("privatekey") !== -1 || rawLow.indexOf("key") !== -1 || rawLow.indexOf("token") !== -1;
          if(!inPush && !pushNamed){ continue; }
          if(e.value === "{object}" || e.value === "{" || e.value === ""){ continue; }
          if(isTrueVal(e.value) || isFalseVal(e.value)){ continue; }
          if(!credNamed && !pushNamed && canon !== "push.senderId"){ continue; }
          var displayKey = canon || ("push." + e.rawKey);
          if(isPlaceholder(e.value)){
            add("HIGH", displayKey, e, true, "This push credential matches a placeholder or example pattern. Replace it with the real credential, supplied from the environment or a secret store — not pasted into shared config.");
          } else {
            add("MEDIUM", displayKey, e, true, "A push credential appears in plaintext in the pasted config. Move push credentials to environment variables or a secret store so they do not travel with the config file.");
          }
        }

        // Sort: severity first, then line (missing last within a severity)
        findings.sort(function(x, y){
          var d = SEV_ORDER[x.severity] - SEV_ORDER[y.severity];
          if(d !== 0){ return d; }
          var xl = (x.line === null ? 9999 : x.line);
          var yl = (y.line === null ? 9999 : y.line);
          return xl - yl;
        });

        var counts = { CRITICAL:0, HIGH:0, MEDIUM:0, LOW:0, PASS:0 };
        for(i = 0; i < findings.length; i++){ counts[findings[i].severity]++; }

        var rawEmpty = String(text).trim() === "";
        var verdict;
        if(rawEmpty || recognizedCount < 3){
          verdict = "NOT ENOUGH TO GRADE";
        } else if(counts.CRITICAL > 0){
          verdict = "DO NOT DEPLOY";
        } else if(counts.HIGH > 0 || counts.MEDIUM > 0){
          verdict = "DEPLOY WITH FIXES";
        } else {
          var coreOk = !!(findEntry(entries, "appId") && findEntry(entries, "masterKey") && findEntry(entries, "serverURL") && findEntry(entries, "databaseURI"));
          verdict = coreOk ? "SAFE TO DEPLOY" : "DEPLOY WITH FIXES";
        }

        return { verdict: verdict, findings: findings, counts: counts, recognizedCount: recognizedCount };
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-parse-server-config-safety-auditortm',
  name: 'J-Dawgs Parse Server Config Safety Auditor',
  description: 'Grades a pasted Parse Server config offline into one deploy verdict (SAFE TO DEPLOY / DEPLOY WITH FIXES / DO NOT DEPLOY / NOT ENOUGH TO GRADE) — secrets reported by key name, line, and length only, never the secret value.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
