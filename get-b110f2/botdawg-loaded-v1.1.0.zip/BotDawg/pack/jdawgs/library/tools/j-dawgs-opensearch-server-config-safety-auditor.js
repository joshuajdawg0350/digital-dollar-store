'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs OpenSearch Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var RISKY_EXAMPLE = [
          "# OpenSearch node config - production candidate (risky example)",
          "cluster.name: prod-search",
          "node.name: node-1",
          "network.host: 0.0.0.0",
          "http.port: 9200",
          "discovery.type: single-node",
          "plugins.security.disabled: true",
          "plugins.security.ssl.http.enabled: false",
          "OPENSEARCH_INITIAL_ADMIN_PASSWORD=Kx9!demo"
        ].join("\n");

        var HARDENED_EXAMPLE = [
          "# OpenSearch node config - hardened example",
          "cluster.name: prod-search",
          "node.name: node-1",
          "node.roles: [ cluster_manager, data, ingest ]",
          "network.host: 192.168.10.11",
          "http.port: 9200",
          "transport.port: 9300",
          'discovery.seed_hosts: ["192.168.10.11", "192.168.10.12", "192.168.10.13"]',
          'cluster.initial_cluster_manager_nodes: ["node-1", "node-2", "node-3"]',
          "plugins.security.disabled: false",
          "plugins.security.ssl.http.enabled: true",
          "plugins.security.ssl.http.verify_hostname: true",
          "plugins.security.ssl.transport.enabled: true",
          "plugins.security.ssl.transport.verify_hostname: true",
          "plugins.security.ssl.http.keystore_password: ${HTTP_KEYSTORE_PASSWORD}",
          "plugins.security.ssl.transport.keystore_password: ${TRANSPORT_KEYSTORE_PASSWORD}",
          "path.data: /var/lib/opensearch",
          "path.logs: /var/log/opensearch"
        ].join("\n");

        var SHARE_BLOCK = [
          "J-Dawgs OpenSearch Server Config Safety Auditor\u2122 - pass it on",
          "",
          "Connect It, Search It, Fix It Right Stack \u2014 EMQX Broker Config Safety Auditor + OpenSearch Server Config Safety Auditor + Appliance Repair Estimate, Work Order & Final Invoice Consistency Auditor: grade the broker, grade the search cluster, cross-check the repair bill.",
          "",
          "AI Tool Store: https://muse.ai/s/ai-tool-store-xng6xkxwjkxl2xab/UoF72OkKI7j33Q2ITxmrZyIr4nv40QtYfj2AgESh_k8",
          "J-Dawgs Agent Exchange: https://muse.ai/s/j-dawgs-agent-exchange-ih6xlnihzxdhxc/ZbleqxFHRE0NcswaBkyN13y9lLp5rPAgHTb6t8ii-PY"
        ].join("\n");

        /* ---------------- Parsing ---------------- */

        function cleanValue(raw) {
          var v = (raw || "").trim();
          if (v.length >= 2 && ((v.charAt(0) === '"' && v.charAt(v.length - 1) === '"') || (v.charAt(0) === "'" && v.charAt(v.length - 1) === "'"))) {
            return v.slice(1, -1);
          }
          var hashIdx = v.indexOf(" #");
          if (hashIdx >= 0) v = v.slice(0, hashIdx).trim();
          return v;
        }

        function parseConfig(text) {
          var lines = text.split(/\r?\n/);
          var entries = [];      // {key, keyLower, value, line}
          var notParsed = [];    // line numbers
          var stack = [];        // {indent, key}
          var lastEntry = null;

          function addEntry(key, value, line) {
            var e = { key: key, keyLower: key.toLowerCase(), value: value, line: line, listItems: [] };
            entries.push(e);
            lastEntry = e;
            return e;
          }

          for (var i = 0; i < lines.length; i++) {
            var lineNo = i + 1;
            var rawLine = lines[i].replace(/\t/g, "  ");
            var trimmed = rawLine.trim();
            if (!trimmed || trimmed.charAt(0) === "#") continue;
            var indent = rawLine.length - rawLine.replace(/^ +/, "").length;

            // List item: "- something"
            if (/^-\s+/.test(trimmed)) {
              var item = trimmed.replace(/^-\s+/, "");
              var mEnv = item.match(/^([A-Za-z][A-Za-z0-9_.\/-]*)\s*=\s*(.*)$/);
              var mYaml = item.match(/^([A-Za-z][A-Za-z0-9_.\/-]*)\s*:\s+(.+)$/);
              if (mEnv) {
                addEntry(mEnv[1], cleanValue(mEnv[2]), lineNo);
              } else if (mYaml) {
                addEntry(mYaml[1], cleanValue(mYaml[2]), lineNo);
              } else if (lastEntry) {
                lastEntry.listItems.push(cleanValue(item));
              } else {
                notParsed.push(lineNo);
              }
              continue;
            }

            // KEY=value (environment / docker-compose style)
            var mEq = trimmed.match(/^([A-Za-z][A-Za-z0-9_.\/-]*)\s*=\s*(.*)$/);
            if (mEq) {
              while (stack.length && stack[stack.length - 1].indent >= indent) stack.pop();
              addEntry(mEq[1], cleanValue(mEq[2]), lineNo);
              continue;
            }

            // YAML key: value (possibly nested)
            var mY = trimmed.match(/^"?([A-Za-z0-9_.\/-]+)"?\s*:\s*(.*)$/);
            if (mY) {
              while (stack.length && stack[stack.length - 1].indent >= indent) stack.pop();
              var parts = [];
              for (var s = 0; s < stack.length; s++) parts.push(stack[s].key);
              parts.push(mY[1]);
              var fullKey = parts.join(".");
              // Avoid doubling when the leaf already carries the full dotted path
              if (stack.length && mY[1].indexOf(parts[0]) === 0 && mY[1].indexOf(".") > 0) fullKey = mY[1];
              var val = cleanValue(mY[2]);
              addEntry(fullKey, val, lineNo);
              if (val === "") stack.push({ indent: indent, key: mY[1] });
              continue;
            }

            notParsed.push(lineNo);
          }
          return { entries: entries, notParsed: notParsed, lineCount: lines.length };
        }

        function getSetting(entries, name) {
          var found = null;
          for (var i = 0; i < entries.length; i++) {
            if (entries[i].keyLower === name) found = entries[i];
          }
          return found;
        }

        function truthy(v) {
          var s = (v || "").toLowerCase();
          return s === "true" || s === "yes" || s === "on" || s === "1";
        }
        function falsy(v) {
          var s = (v || "").toLowerCase();
          return s === "false" || s === "no" || s === "off" || s === "0";
        }

        function listCount(entry) {
          if (!entry) return 0;
          var v = entry.value || "";
          var n = 0;
          if (v.charAt(0) === "[") {
            var inner = v.replace(/^\[/, "").replace(/\]$/, "").trim();
            if (inner) n = inner.split(",").filter(function (x) { return x.trim() !== ""; }).length;
          } else if (v.indexOf(",") >= 0) {
            n = v.split(",").filter(function (x) { return x.trim() !== ""; }).length;
          } else if (v) {
            n = 1;
          }
          return n + (entry.listItems ? entry.listItems.length : 0);
        }

        var RECOGNIZED_PREFIXES = ["cluster.", "node.", "network.", "discovery.", "plugins.", "http.", "transport.", "path.", "bootstrap.", "gateway.", "indices.", "thread_pool.", "opensearch"];
        function isRecognized(keyLower) {
          for (var i = 0; i < RECOGNIZED_PREFIXES.length; i++) {
            if (keyLower.indexOf(RECOGNIZED_PREFIXES[i]) === 0) return true;
          }
          return keyLower.indexOf("opensearch") >= 0;
        }

        /* ---------------- Audit ---------------- */

        var SEV_RANK = { "BLOCKER": 0, "HIGH": 1, "WARNING": 2, "INFO": 3 };

        function audit(text) {
          var result = {
            verdict: "NOT ENOUGH TO GRADE",
            verdictWhy: "",
            counts: { "BLOCKER": 0, "HIGH": 0, "WARNING": 0, "INFO": 0 },
            findings: [],
            linesAudited: 0,
            settingsRecognized: 0
          };

          if (!text || !text.trim()) {
            result.verdictWhy = "The paste box is empty. Paste an OpenSearch configuration (opensearch.yml contents, or environment / docker-compose style lines) and run the audit again - there is nothing here to grade.";
            return result;
          }

          var parsed = parseConfig(text);
          result.linesAudited = parsed.lineCount;
          var recognized = 0;
          var i, e;
          for (i = 0; i < parsed.entries.length; i++) {
            if (isRecognized(parsed.entries[i].keyLower)) recognized++;
          }
          result.settingsRecognized = recognized;

          if (recognized === 0) {
            result.verdictWhy = "No recognizable OpenSearch settings were found in this paste. The auditor looks for keys such as cluster.name, node.name, network.host, discovery.type, discovery.seed_hosts, cluster.initial_cluster_manager_nodes, http.port, transport.port, and plugins.security.* - none were present, so no honest verdict can be given.";
            return result;
          }

          var findings = [];
          function add(severity, line, key, title, detail, fix) {
            findings.push({ severity: severity, line: line, key: key || null, title: title, detail: detail, fix: fix });
          }

          var entries = parsed.entries;
          var secDisabled = getSetting(entries, "plugins.security.disabled");
          var securityOff = !!(secDisabled && truthy(secDisabled.value));
          var anySecurityKeys = false;
          for (i = 0; i < entries.length; i++) {
            if (entries[i].keyLower.indexOf("plugins.security") === 0) { anySecurityKeys = true; break; }
          }

          /* 1. Security plugin disabled */
          if (securityOff) {
            add("BLOCKER", secDisabled.line, secDisabled.key,
              "Security plugin is disabled",
              "plugins.security.disabled is set to true, so this node runs with no authentication, no authorization, and no audit logging from the security plugin. Anyone who can reach the REST or transport port can read, change, or delete every index.",
              "Remove plugins.security.disabled (or set it to false), configure the security plugin's certificates and internal users, and restart the node. Never expose a node with the security plugin disabled beyond a throwaway local sandbox.");
          }

          /* TLS posture facts */
          var httpSsl = getSetting(entries, "plugins.security.ssl.http.enabled");
          var transportSsl = getSetting(entries, "plugins.security.ssl.transport.enabled");
          var httpSslOn = !!(httpSsl && truthy(httpSsl.value));
          var transportSslOn = !!(transportSsl && truthy(transportSsl.value));
          var tlsPosture = httpSslOn || transportSslOn;

          /* 2. network.host all-interfaces bind */
          var bindEntry = getSetting(entries, "network.host") || getSetting(entries, "network.bind_host");
          var discoveryType = getSetting(entries, "discovery.type");
          var singleNode = !!(discoveryType && (discoveryType.value || "").toLowerCase() === "single-node");
          if (bindEntry) {
            var bindVal = (bindEntry.value || "").toLowerCase();
            var allInterfaces = bindVal === "0.0.0.0" || bindVal === "_site_" || bindVal === "_global_" ||
              bindVal === "_non_loopback_" || bindVal === "_non_loopback:ipv4_" || bindVal === "*" ||
              bindVal.indexOf("0.0.0.0") >= 0;
            if (allInterfaces && !tlsPosture) {
              add("HIGH", bindEntry.line, bindEntry.key,
                "Node binds to all network interfaces with no TLS posture",
                "network.host is bound to " + bindEntry.value + ", which listens on every interface, and the paste shows no enabled TLS on the transport or REST layer to protect that exposure. Combined with a reachable network, the cluster ports answer anyone who can route to this host.",
                "Bind to a specific interface (for example the node's private IP, or _local_ / _site_ scoped deliberately), and enable TLS: plugins.security.ssl.transport.enabled: true and plugins.security.ssl.http.enabled: true with real certificates.");
            }
            if (allInterfaces && singleNode) {
              add("WARNING", bindEntry.line, bindEntry.key,
                "Single-node discovery combined with an all-interfaces bind",
                "discovery.type is single-node - a development-style setting - while network.host listens on all interfaces. Whether this is dangerous depends entirely on exposure: on an isolated laptop or a firewalled private network it may be acceptable; on any host reachable from untrusted networks it is an open cluster. The paste alone cannot tell which, so this is flagged honestly rather than graded as a definite hole.",
                "If this node is reachable beyond a trusted private network, bind network.host to a specific interface and drop single-node discovery in favor of a real cluster configuration. Keep the bind wide only where a firewall or private network provably contains it.");
            }
          }

          /* 3. Plaintext secrets (value never printed - key, line, length only) */
          var SECRET_NAME = /(password|passwd|pwd|secret|token|keypass)/i;
          function isSecretKey(keyLower) {
            if (SECRET_NAME.test(keyLower)) return true;
            var segs = keyLower.split(/[._\-]+/);
            for (var j = 0; j < segs.length; j++) { if (segs[j] === "key") return true; }
            return false;
          }
          for (i = 0; i < entries.length; i++) {
            e = entries[i];
            if (!isSecretKey(e.keyLower)) continue;
            var v = e.value || "";
            if (!v || v === "~" || v.toLowerCase() === "null") continue;
            if (v.indexOf("${") === 0) {
              add("INFO", e.line, e.key,
                "Secret supplied by environment substitution - not flagged",
                "The value for this key is an environment-variable substitution rather than a literal, so no secret is written into the config text. (Key name and line only, as with all secret handling in this tool.)",
                "No fix needed. Keep the real value in the environment or a secrets manager, out of the config file and out of version control.");
              continue;
            }
            var len = v.length;
            var demoLike = /(demo|example|changeme|change_me|change-me)/i.test(v) ||
              /^(admin|password|passwd|letmein|default|secret|test)$/i.test(v);
            if (demoLike) {
              add("BLOCKER", e.line, e.key,
                "Demo/example-grade secret value in plaintext",
                "This key holds a literal value of length " + len + " that matches a demo, example, or well-known placeholder pattern. The value itself is never shown by this tool - only its key name, line, and length. Demo-grade credentials are the first thing tried against an exposed node.",
                "Replace the value with a long, unique, randomly generated secret supplied through an environment variable (for example ${ENV_VAR}) or a secrets manager, and rotate it anywhere it was ever used.");
            } else if (len < 8) {
              add("BLOCKER", e.line, e.key,
                "Very short plaintext secret",
                "This key holds a literal secret of length " + len + " - far too short to resist guessing - written in plaintext in the config. The value itself is never shown by this tool - only its key name, line, and length.",
                "Replace it with a long, unique, randomly generated secret (16+ characters) supplied through an environment variable (for example ${ENV_VAR}) or a secrets manager, and rotate the old one.");
            } else if (len < 12) {
              add("HIGH", e.line, e.key,
                "Short plaintext secret",
                "This key holds a literal secret of length " + len + " - under the 12-character floor this auditor accepts - written in plaintext in the config. The value itself is never shown by this tool - only its key name, line, and length.",
                "Replace it with a long, unique, randomly generated secret supplied through an environment variable (for example ${ENV_VAR}) or a secrets manager, and rotate the old one.");
            } else {
              add("HIGH", e.line, e.key,
                "Plaintext secret in config",
                "This key holds a literal secret of length " + len + " written in plaintext in the config text, where anyone with read access to the file - or to its copy in version control - has the credential. The value itself is never shown by this tool - only its key name, line, and length.",
                "Move the value out of the config: supply it through an environment variable (for example ${ENV_VAR}), the OpenSearch keystore, or a secrets manager, and rotate it if the config was ever shared or committed.");
            }
          }

          /* 4. REST layer SSL + hostname verification */
          if (!securityOff) {
            if (httpSsl && falsy(httpSsl.value)) {
              add("HIGH", httpSsl.line, httpSsl.key,
                "REST layer served over plain HTTP while security is on",
                "plugins.security.ssl.http.enabled is false, so the REST API on http.port answers over unencrypted HTTP even though the security plugin is enabled. Credentials and data cross the network in the clear.",
                "Set plugins.security.ssl.http.enabled: true and configure plugins.security.ssl.http.keystore_filepath / keystore_password (via environment substitution), or terminate TLS at a trusted proxy that is the only path to the node.");
            } else if (!httpSsl && anySecurityKeys) {
              add("WARNING", null, "plugins.security.ssl.http.enabled",
                "REST-layer SSL not stated while security settings are present",
                "The paste configures the security plugin but never states plugins.security.ssl.http.enabled. On a stock OpenSearch install the REST layer may still be plain HTTP unless SSL is enabled and certificates are configured - the paste cannot prove the REST port is encrypted.",
                "State it explicitly: plugins.security.ssl.http.enabled: true with a configured HTTP keystore, so the deployed posture is visible in the config itself.");
            }
            if (transportSsl && falsy(transportSsl.value)) {
              add("WARNING", transportSsl.line, transportSsl.key,
                "Transport-layer SSL explicitly disabled",
                "plugins.security.ssl.transport.enabled is false, so node-to-node transport traffic is unencrypted and nodes do not verify each other by certificate.",
                "Set plugins.security.ssl.transport.enabled: true and configure the transport keystore/truststore so cluster traffic is encrypted and mutually verified.");
            }
          } else if (httpSsl && falsy(httpSsl.value)) {
            add("WARNING", httpSsl.line, httpSsl.key,
              "REST-layer SSL switched off (security plugin already disabled)",
              "plugins.security.ssl.http.enabled is false. With the security plugin disabled (see the BLOCKER above) this changes nothing today - the REST layer has neither authentication nor encryption - but it records an intent to run plain HTTP that will survive if the plugin is later re-enabled without revisiting SSL.",
              "When the security plugin is re-enabled, set plugins.security.ssl.http.enabled: true in the same change.");
          }
          var verifyKeys = ["plugins.security.ssl.http.verify_hostname", "plugins.security.ssl.transport.verify_hostname"];
          for (i = 0; i < verifyKeys.length; i++) {
            var vk = getSetting(entries, verifyKeys[i]);
            if (vk && falsy(vk.value)) {
              add("WARNING", vk.line, vk.key,
                "SSL hostname verification disabled",
                verifyKeys[i] + " is false, so certificates are accepted without checking that the hostname matches. That weakens TLS to encryption without peer identity - a machine with any trusted-looking certificate can impersonate a node or the REST endpoint.",
                "Set " + verifyKeys[i] + ": true and issue certificates whose SANs match the node hostnames.");
            }
          }

          /* 5. Anonymous / demo / admin posture keys (by name only) */
          for (i = 0; i < entries.length; i++) {
            e = entries[i];
            var k = e.keyLower;
            if (k.indexOf("anonymous") >= 0 && truthy(e.value)) {
              add("HIGH", e.line, e.key,
                "Anonymous authentication enabled (by key name)",
                "This key turns on anonymous access to the cluster. Reported by key name only. Anonymous callers reach whatever the anonymous role can touch, with no credential and no per-user audit trail.",
                "Disable anonymous authentication unless a specific, reviewed use case needs it - and then scope the anonymous role to the minimum read-only indices.");
            } else if (k.indexOf("allow_unsafe_democertificates") >= 0 && truthy(e.value)) {
              add("HIGH", e.line, e.key,
                "Unsafe demo certificates allowed (by key name)",
                "This key permits the built-in demo certificates in a running node. Reported by key name only. Demo certificates are publicly known material - anyone can present or impersonate them.",
                "Set this key to false (or remove it) and install certificates issued for this cluster before the node serves real traffic.");
            } else if (k.indexOf("allow_default_init_securityindex") >= 0 && truthy(e.value)) {
              add("HIGH", e.line, e.key,
                "Default security-index initialization allowed (by key name)",
                "This key allows the security index to be initialized with default content, including default internal users, when it is absent. Reported by key name only. On a production node that means known default credentials can come into existence silently.",
                "Set this key to false on production nodes and initialize the security index deliberately with the security admin tooling and your own credentials.");
            } else if (k.indexOf("demo") >= 0 && truthy(e.value) && k.indexOf("plugins.") === 0) {
              add("BLOCKER", e.line, e.key,
                "Demo configuration enabled (by key name)",
                "A demo configuration option is switched on. Reported by key name only. Demo configurations exist to get a throwaway node running fast - they ship example users, example roles, and known credentials, and are not a production posture.",
                "Remove the demo option and configure real users, roles, and certificates for this cluster.");
            }
          }

          /* 6. Cluster formation: seed hosts / initial cluster-manager nodes */
          var seedHosts = getSetting(entries, "discovery.seed_hosts");
          var initialNodes = getSetting(entries, "cluster.initial_cluster_manager_nodes") || getSetting(entries, "cluster.initial_master_nodes");
          var multiIntent = listCount(seedHosts) > 1 || listCount(initialNodes) > 1;
          if (multiIntent) {
            if (!seedHosts) {
              add("WARNING", null, "discovery.seed_hosts",
                "discovery.seed_hosts missing on a multi-node config",
                "The paste names multiple cluster-manager nodes, so a multi-node cluster is intended, but discovery.seed_hosts is not stated - nodes have no listed peers to discover each other through.",
                "Add discovery.seed_hosts with the addresses of the cluster-manager/data nodes so nodes can find each other at startup.");
            }
            if (!initialNodes) {
              add("WARNING", null, "cluster.initial_cluster_manager_nodes",
                "cluster.initial_cluster_manager_nodes missing on a multi-node config",
                "The paste lists multiple discovery hosts, so a multi-node cluster is intended, but cluster.initial_cluster_manager_nodes is not stated - a fresh cluster cannot elect its first cluster manager deterministically.",
                "Add cluster.initial_cluster_manager_nodes naming the cluster-manager-eligible nodes for the first bootstrap (it is only used when the cluster first forms).");
            }
          } else if (!singleNode) {
            if (!seedHosts) {
              add("INFO", null, "discovery.seed_hosts",
                "discovery.seed_hosts: NOT STATED",
                "The paste does not state discovery.seed_hosts, and it does not clearly declare a multi-node or single-node intent either, so cluster discovery cannot be judged from the paste alone.",
                "If this node belongs to a cluster, state discovery.seed_hosts explicitly. If it is a deliberate single-node setup, say so with discovery.type: single-node.");
            }
            if (!initialNodes) {
              add("INFO", null, "cluster.initial_cluster_manager_nodes",
                "cluster.initial_cluster_manager_nodes: NOT STATED",
                "The paste does not state cluster.initial_cluster_manager_nodes. For an already-formed cluster this is normal (the setting only matters at first bootstrap); for a fresh multi-node cluster it is required. The paste alone cannot tell which case applies.",
                "For a fresh multi-node cluster, set cluster.initial_cluster_manager_nodes for the first bootstrap. For an existing cluster, no action is needed.");
            }
          }

          /* Security posture not stated at all */
          if (!anySecurityKeys) {
            add("INFO", null, "plugins.security.*",
              "Security plugin posture: NOT STATED",
              "The paste contains no plugins.security.* settings at all, so the state of the security plugin - enabled or disabled, its SSL settings, its users - cannot be confirmed from the paste. A stock OpenSearch distribution ships with the security plugin enabled, but a partial paste cannot prove what the running node uses.",
              "Audit the node's full effective configuration (including any defaults and environment overrides) before deploying, and state the security settings explicitly in opensearch.yml.");
          }

          /* 7. Malformed lines */
          for (i = 0; i < parsed.notParsed.length; i++) {
            add("WARNING", parsed.notParsed[i], null,
              "NOT PARSED: line is not a recognizable setting",
              "This line could not be parsed as a key/value setting, a section header, or a list item. OpenSearch may ignore it or refuse to start on it, and if it was meant to be a security setting, that setting is not in effect. The line's content is not reproduced here.",
              "Check the line for a missing colon or equals sign, stray characters, or broken indentation, and rewrite it as a standard key: value (or KEY=value) line.");
          }

          findings.sort(function (a, b) {
            var r = SEV_RANK[a.severity] - SEV_RANK[b.severity];
            if (r !== 0) return r;
            var la = a.line === null ? 99999 : a.line;
            var lb = b.line === null ? 99999 : b.line;
            return la - lb;
          });

          result.findings = findings;
          for (i = 0; i < findings.length; i++) result.counts[findings[i].severity]++;

          if (result.counts.BLOCKER > 0 || result.counts.HIGH > 0) {
            result.verdict = "DO NOT DEPLOY";
            result.verdictWhy = "The paste contains " + result.counts.BLOCKER + " BLOCKER and " + result.counts.HIGH + " HIGH finding(s). Fix every BLOCKER and HIGH item below before this configuration goes anywhere near a reachable network.";
          } else if (result.counts.WARNING > 0) {
            result.verdict = "DEPLOY WITH FIXES";
            result.verdictWhy = "No BLOCKER or HIGH findings, but " + result.counts.WARNING + " WARNING(s) need attention. Fix them, or record a deliberate reason for each one, before deploying.";
          } else {
            result.verdict = "SAFE TO DEPLOY";
            result.verdictWhy = "No BLOCKER, HIGH, or WARNING findings in the pasted text. INFO items below are notes about what the paste does not state - they do not block deployment. This verdict covers the pasted text only; it does not verify the running node.";
          }
          return result;
        }

        /* ---------------- Reports ---------------- */

        function buildTextReport(r) {
          var out = [];
          out.push("J-Dawgs OpenSearch Server Config Safety Auditor\u2122 - audit report");
          out.push("Verdict: " + r.verdict);
          out.push("Lines audited: " + r.linesAudited + " | OpenSearch settings recognized: " + r.settingsRecognized);
          out.push("Counts: BLOCKER " + r.counts.BLOCKER + " | HIGH " + r.counts.HIGH + " | WARNING " + r.counts.WARNING + " | INFO " + r.counts.INFO);
          out.push("");
          if (r.verdict === "NOT ENOUGH TO GRADE") {
            out.push(r.verdictWhy);
          } else if (r.findings.length === 0) {
            out.push("No findings.");
          } else {
            for (var i = 0; i < r.findings.length; i++) {
              var f = r.findings[i];
              out.push("[" + f.severity + "] " + (f.line !== null ? "Line " + f.line : "Not stated in paste") + (f.key ? " | " + f.key : "") + " - " + f.title);
              out.push("  " + f.detail);
              out.push("  Fix: " + f.fix);
              out.push("");
            }
          }
          out.push("Note: secret values are never reproduced in this report - findings name the key, the line, and the value length only.");
          out.push("Limits: heuristic text audit of pasted text only. This tool does not start OpenSearch, connect to a cluster, or verify certificates.");
          return out.join("\n");
        }

        function buildJsonReport(r) {
          var obj = {
            tool: "J-Dawgs OpenSearch Server Config Safety Auditor",
            verdict: r.verdict,
            verdictReason: r.verdictWhy,
            linesAudited: r.linesAudited,
            settingsRecognized: r.settingsRecognized,
            counts: { BLOCKER: r.counts.BLOCKER, HIGH: r.counts.HIGH, WARNING: r.counts.WARNING, INFO: r.counts.INFO },
            findings: r.findings.map(function (f) {
              return { severity: f.severity, line: f.line, key: f.key, title: f.title, detail: f.detail, fix: f.fix };
            }),
            secretHandling: "Secret values never appear in this report. Secret findings carry key name, line, and value length only.",
            limits: "Heuristic text audit of pasted text only. Does not start OpenSearch, connect to a cluster, or verify certificates."
          };
          return JSON.stringify(obj, null, 2);
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-opensearch-server-config-safety-auditor',
  name: 'J-Dawgs OpenSearch Server Config Safety Auditor',
  description: 'Grades a pasted OpenSearch opensearch.yml fully offline — security plugin posture, bind exposure, and TLS all graded, with secrets shown by name, line, and length only — into one deploy verdict: SAFE TO DEPLOY / DEPLOY WITH FIXES / DO NOT DEPLOY.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
