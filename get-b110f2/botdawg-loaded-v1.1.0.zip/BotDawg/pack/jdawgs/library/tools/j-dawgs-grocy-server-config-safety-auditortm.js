'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Grocy Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

    'use strict';

    /* ================= Sample configs (worked examples) ================= */

    var RISKY_SAMPLE = [
      "<?php",
      "// Risky sample — a Grocy config with the classic mistakes left in",
      "Setting('MODE', 'demo');",
      "Setting('BASE_URL', 'http://grocy.home-server.net');",
      "Setting('DEBUG', true);",
      "Setting('DISABLE_AUTH', false);",
      "Setting('DB_PASSWORD', 'grocy123');",
      "Setting('ADMIN_PASSWORD', 'admin');",
      "Setting('API_KEY', 'k9x2');",
      "Setting('ALLOW_REGISTRATION', true);",
      "Setting('CURRENCY', 'US DOLLARS');",
      "Setting('DEFAULT_LOCALE', 'en');"
    ].join("\n");

    var HARDENED_SAMPLE = [
      "# Hardened sample — secrets come from the environment, not the file",
      "services:",
      "  grocy:",
      "    image: grocy/grocy:latest",
      "    environment:",
      "      - GROCY_MODE=production",
      "      - GROCY_BASE_URL=https://grocy.home.example",
      "      - GROCY_DEBUG=false",
      "      - GROCY_DB_PASSWORD=${GROCY_DB_PASSWORD}",
      "      - GROCY_ADMIN_PASSWORD=${GROCY_ADMIN_PASSWORD}",
      "      - GROCY_API_KEY=${GROCY_API_KEY}",
      "      - GROCY_ALLOW_REGISTRATION=false",
      "      - GROCY_CURRENCY=USD",
      "      - GROCY_CULTURE=en",
      "    ports:",
      '      - "9283:80"'
    ].join("\n");

    /* ================= Parser =================
       Reads three shapes of pasted config text:
       PHP Setting('KEY', value); / define('KEY', value); / $x['KEY'] = value;
       .env KEY=value lines, docker-compose "- KEY=value" items, YAML KEY: value.
       A parsed value is classified as 'env' (pulled from the environment,
       e.g. getenv(...) or ${VAR}), 'bool', 'number', 'null', or 'string'. */

    function parseValue(raw) {
      var s = String(raw).trim();
      if (/^getenv\s*\(/i.test(s) || /^env\s*\(/i.test(s) ||
          /^\$\{[^}]*\}$/.test(s) || /^\$[A-Za-z_][A-Za-z0-9_]*$/.test(s)) {
        return { kind: 'env', value: null };
      }
      var q = s.match(/^'([^']*)'$/) || s.match(/^"([^"]*)"$/);
      if (q) {
        var inner = q[1];
        if (/^\$\{[^}]*\}$/.test(inner) || /^getenv/i.test(inner)) return { kind: 'env', value: null };
        return { kind: 'string', value: inner };
      }
      if (/^(true|yes|on)$/i.test(s)) return { kind: 'bool', value: true };
      if (/^(false|no|off)$/i.test(s)) return { kind: 'bool', value: false };
      if (/^-?\d+$/.test(s)) return { kind: 'number', value: parseInt(s, 10) };
      if (/^(null|~)$/i.test(s)) return { kind: 'null', value: null };
      return { kind: 'string', value: s };
    }

    function makeEntry(keyRaw, valRaw, lineNo, fmt) {
      var key = String(keyRaw).toUpperCase();
      var core = key.indexOf('GROCY_') === 0 ? key.slice(6) : key;
      var pv = parseValue(valRaw);
      return { key: key, core: core, line: lineNo, fmt: fmt, kind: pv.kind, value: pv.value };
    }

    function parseConfig(text) {
      var entries = [];
      var lines = String(text == null ? '' : text).split(/\r?\n/);
      for (var i = 0; i < lines.length; i++) {
        var lineNo = i + 1;
        var line = lines[i].trim();
        if (!line) continue;
        if (line.indexOf('//') === 0) continue;
        if (line.charAt(0) === '#' && !/^[A-Za-z_][A-Za-z0-9_]*\s*=/.test(line)) continue;
        if (line === '<?php' || line === '?>') continue;
        var m;
        m = line.match(/Setting\(\s*['"]([A-Za-z0-9_]+)['"]\s*,\s*(.+)\)\s*;?$/) ||
            line.match(/define\(\s*['"]([A-Za-z0-9_]+)['"]\s*,\s*(.+)\)\s*;?$/) ||
            line.match(/\$[A-Za-z_][A-Za-z0-9_]*\[\s*['"]([A-Za-z0-9_]+)['"]\s*\]\s*=\s*(.+?);?$/);
        if (m) { entries.push(makeEntry(m[1], m[2], lineNo, 'php')); continue; }
        m = line.match(/^-\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/);
        if (m) { entries.push(makeEntry(m[1], m[2], lineNo, 'env')); continue; }
        m = line.match(/^([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/);
        if (m) { entries.push(makeEntry(m[1], m[2], lineNo, 'env')); continue; }
        m = line.match(/^-\s*([A-Za-z_][A-Za-z0-9_]*)\s*:\s+(.+)$/) ||
            line.match(/^([A-Za-z_][A-Za-z0-9_]*)\s*:\s+(.+)$/);
        if (m) { entries.push(makeEntry(m[1], m[2], lineNo, 'yaml')); continue; }
      }
      return entries;
    }

    function detectFormat(text, entries) {
      if (/Setting\s*\(|<\?php|define\s*\(/.test(text)) return 'PHP (config.php style)';
      if (/^\s*services\s*:/m.test(text) || /^\s*image\s*:/m.test(text)) return 'docker-compose YAML';
      var hasEnv = false, hasYaml = false, j;
      for (j = 0; j < entries.length; j++) {
        if (entries[j].fmt === 'env') hasEnv = true;
        if (entries[j].fmt === 'yaml') hasYaml = true;
      }
      if (hasEnv) return '.env style';
      if (hasYaml) return 'YAML';
      return 'unrecognized';
    }

    /* ================= Check helpers ================= */

    var DEFAULT_SECRETS = ['admin','administrator','password','passwd','passw0rd','changeme',
      'change-me','letmein','123456','12345678','1234','root','secret','demo','grocy',
      'example','default','test','qwerty'];
    var RECOGNIZED = /(MODE|URL|DEBUG|AUTH|PASS|SECRET|TOKEN|KEY|REGIST|CURRENCY|LOCALE|CULTURE|LANGUAGE|DB_|DATABASE|BASE|DEMO|ENVIRONMENT|TIMEZONE|^TZ$|SIGNUP|SIGN_UP)/;

    function isSecretKey(core) {
      return /(PASSWORD|PASSWD|SECRET|TOKEN|API_?KEY|PRIVATE_?KEY|ACCESS_?KEY|CREDENTIAL)/.test(core) || core === 'PASS';
    }
    function isDbPasswordKey(core) {
      return /PASS/.test(core) && /(DB|DATABASE|MYSQL|MARIADB|POSTGRES)/.test(core);
    }
    function isAdminCredentialKey(core) {
      return /ADMIN/.test(core) && /(PASSWORD|PASSWD|PASS|USER|NAME|CREDENTIAL)/.test(core);
    }
    function isTrue(e) {
      if (e.kind === 'bool') return e.value === true;
      if (e.kind === 'string') return /^(true|yes|on|1)$/i.test(e.value);
      if (e.kind === 'number') return e.value === 1;
      return false;
    }
    function isFalse(e) {
      if (e.kind === 'bool') return e.value === false;
      if (e.kind === 'string') return /^(false|no|off|0)$/i.test(e.value);
      if (e.kind === 'number') return e.value === 0;
      return false;
    }
    function literalString(e) {
      if (e.kind === 'string') return e.value;
      if (e.kind === 'number') return String(e.value);
      return null;
    }
    function looksDefaultSecret(v) {
      var lv = v.toLowerCase();
      if (DEFAULT_SECRETS.indexOf(lv) !== -1) return true;
      if (lv.indexOf('example') !== -1) return true;
      if (/^your[-_]/.test(lv)) return true;
      if (/^x{3,}$/.test(lv)) return true;
      if (v.length > 1 && /^(.)\1+$/.test(v)) return true;
      return false;
    }

    /* ================= The auditor =================
       Findings for secrets carry ONLY the key name, the line number, and
       the value length. Secret values are never copied into a finding,
       the text report, or the JSON export. */

    function auditConfig(text) {
      var entries = parseConfig(text);
      var findings = [];
      function add(severity, check, e, detail, valueLength) {
        var f = { severity: severity, check: check, key: e ? e.key : null, line: e ? e.line : null, detail: detail };
        if (typeof valueLength === 'number') f.valueLength = valueLength;
        findings.push(f);
      }

      var recognized = 0, i, e;
      for (i = 0; i < entries.length; i++) if (RECOGNIZED.test(entries[i].core)) recognized++;
      var gradeable = entries.length >= 3 && recognized >= 2;

      var sawMode = false, sawUrl = false;

      for (i = 0; i < entries.length; i++) {
        e = entries[i];
        var core = e.core;
        var sv = literalString(e);

        /* --- Mode: demo / non-production / production --- */
        if (core === 'MODE' || core === 'APP_MODE' || core === 'ENVIRONMENT') {
          sawMode = true;
          if (sv !== null) {
            var lv = sv.toLowerCase();
            if (lv === 'demo' || lv === 'demonstration') {
              add('critical', 'demo-mode', e, "Demo mode is switched on. A demo Grocy instance runs with demo data and demo behavior — never expose it as your real server. Set the mode to production.");
            } else if (lv === 'dev' || lv === 'development' || lv === 'debug' || lv === 'testing') {
              add('high', 'non-production-mode', e, "A non-production mode is set. Development and debug modes leak internals and skip hardening — set the mode to production for a deployed server.");
            } else if (lv === 'production' || lv === 'prod') {
              add('pass', 'demo-mode', e, "Mode is set to production.");
            } else {
              add('info', 'mode-value', e, "The mode value is not one of the usual values (production / demo / dev) — double-check it is spelled the way Grocy expects.");
            }
          }
        }
        if ((core === 'DEMO_MODE' || core === 'DEMO') && isTrue(e)) {
          sawMode = true;
          add('critical', 'demo-mode', e, "Demo mode is switched on. A demo Grocy instance runs with demo data and demo behavior — never expose it as your real server.");
        }

        /* --- Authentication disabled --- */
        if (core === 'DISABLE_AUTH') {
          if (isTrue(e)) add('critical', 'auth-disabled', e, "Authentication is disabled. Anyone who can reach the page is in — no password stands in the way. Turn this off before deploying.");
          else if (isFalse(e)) add('pass', 'auth-disabled', e, "Authentication is not disabled.");
        }

        /* --- Debug mode --- */
        if (core === 'DEBUG' || core === 'APP_DEBUG' || core === 'DEBUG_MODE') {
          if (isTrue(e)) add('high', 'debug-mode', e, "Debug mode is on. Debug output leaks file paths, settings, and stack traces to whoever asks. Set it to false for a deployed server.");
          else if (isFalse(e)) add('pass', 'debug-mode', e, "Debug mode is off.");
        }

        /* --- Base / public URL scheme --- */
        if (core.indexOf('URL') !== -1) {
          sawUrl = true;
          if (sv !== null && sv.length) {
            if (/^http:\/\//i.test(sv)) {
              var host = sv.replace(/^http:\/\//i, '').split('/')[0].split(':')[0].toLowerCase();
              if (host === 'localhost' || host === '127.0.0.1' || host === '[::1]') {
                add('info', 'base-url-scheme', e, "The base URL uses HTTP on a local address. Fine on the machine itself — switch to HTTPS before the server is reachable from anywhere else.");
              } else {
                add('high', 'base-url-scheme', e, "The base URL uses plain HTTP, not HTTPS. Logins and API keys cross the network unencrypted. Serve Grocy over HTTPS and set the base URL to the https:// address.");
              }
            } else if (/^https:\/\//i.test(sv)) {
              add('pass', 'base-url-scheme', e, "The base URL uses HTTPS.");
            } else {
              add('info', 'base-url-scheme', e, "The base URL does not start with https:// — check it points at the address people actually use to reach this server.");
            }
          }
        }

        /* --- Open registration --- */
        if (/REGISTR|SIGNUP|SIGN_UP/.test(core)) {
          if (isTrue(e)) add('medium', 'open-registration', e, "Open registration is on — anyone who can reach the login page can create an account. Turn it off unless this server is deliberately shared with people who sign themselves up.");
          else if (isFalse(e)) add('pass', 'open-registration', e, "Open registration is off.");
        }

        /* --- Secrets: default / plaintext DB / short / literal / env-sourced --- */
        if (isSecretKey(core) || isAdminCredentialKey(core)) {
          if (e.kind === 'env') {
            add('pass', 'secret-source', e, "This secret is read from the environment rather than pasted as a literal — the right pattern.");
          } else if (sv !== null) {
            var len = sv.length;
            var isDb = isDbPasswordKey(core);
            if (looksDefaultSecret(sv)) {
              if (isAdminCredentialKey(core) || isDb) {
                add('critical', 'default-credential', e, "This key holds a known default or example credential (value length " + len + "). Default credentials are public knowledge — anyone can try them. Replace it with a long random value before deploying.", len);
              } else {
                add('high', 'default-credential', e, "This secret matches a known default or example value (value length " + len + "). Replace it with a long random value before deploying.", len);
              }
            } else if (isDb && len > 0) {
              add('high', 'db-password-plaintext', e, "The database password sits in the pasted config as plain text (value length " + len + "). Anyone who reads this file — a backup, a repo, a screenshot — has the database password. Move it to an environment variable or a secret file.", len);
            } else if (len === 0) {
              add('high', 'short-secret', e, "This secret is empty (value length 0). Set a long random value before deploying.", 0);
            } else if (len < 12) {
              add('high', 'short-secret', e, "This secret is short (value length " + len + "). Short secrets fall to guessing fast — use at least 16 random characters.", len);
            } else {
              add('medium', 'literal-secret', e, "This secret is written into the config as a literal value (value length " + len + "). It works, but the file itself becomes the secret — prefer an environment variable or a secret file so the config can be shared and backed up safely.", len);
            }
          }
        }

        /* --- Currency / locale sanity (info only, never blocks a verdict) --- */
        if (core === 'CURRENCY') {
          if (sv !== null) {
            if (/^[A-Z]{3}$/.test(sv)) add('pass', 'currency-sanity', e, "Currency is a standard 3-letter code.");
            else add('info', 'currency-sanity', e, "The currency value does not look like a standard 3-letter code (such as USD or EUR), so prices may display oddly. Info only — it never changes the verdict by itself.");
          }
        }
        if (core === 'DEFAULT_LOCALE' || core === 'LOCALE' || core === 'CULTURE' || core === 'LANGUAGE' || core === 'DEFAULT_LANGUAGE') {
          if (sv !== null) {
            if (/^[a-z]{2}([_-][A-Za-z]{2})?$/.test(sv)) add('pass', 'locale-sanity', e, "Locale is a standard language code.");
            else add('info', 'locale-sanity', e, "The locale value does not look like a standard language code (such as en or en_US), so dates and sorting may surprise you. Info only — it never changes the verdict by itself.");
          }
        }
      }

      if (gradeable && !sawMode) {
        add('info', 'mode-missing', null, "No MODE setting was found in the paste, so the demo/production state cannot be confirmed from the config alone.");
      }
      if (gradeable && !sawUrl) {
        add('info', 'base-url-missing', null, "No base URL setting was found in the paste. If Grocy sits behind a reverse proxy, set its public base URL to the HTTPS address, or generated links will point at the wrong place.");
      }

      var counts = { critical: 0, high: 0, medium: 0, info: 0, pass: 0 };
      for (i = 0; i < findings.length; i++) counts[findings[i].severity]++;

      var verdict;
      if (!gradeable) verdict = 'NOT ENOUGH TO GRADE';
      else if (counts.critical > 0) verdict = 'DO NOT DEPLOY';
      else if (counts.high > 0 || counts.medium > 0) verdict = 'DEPLOY WITH FIXES';
      else verdict = 'SAFE TO DEPLOY';

      if (!gradeable) {
        findings.push({ severity: 'info', check: 'not-enough-input', key: null, line: null,
          detail: "Only " + entries.length + " config " + (entries.length === 1 ? 'entry' : 'entries') + " could be read (" + recognized + " recognized as Grocy settings). Paste more of the config — at least a few Setting(...) lines, KEY=value lines, or docker-compose environment entries — and grade again." });
        counts.info++;
      }

      var rank = { critical: 0, high: 1, medium: 2, info: 3, pass: 4 };
      findings.sort(function (a, b) {
        if (rank[a.severity] !== rank[b.severity]) return rank[a.severity] - rank[b.severity];
        return (a.line || 0) - (b.line || 0);
      });

      return {
        verdict: verdict,
        format: detectFormat(text, entries),
        entriesRead: entries.length,
        recognized: recognized,
        counts: counts,
        findings: findings
      };
    }

    /* ================= Report + JSON builders ================= */

    function lineLabel(f) { return f.line ? 'Line ' + f.line : 'Line –'; }

    function buildReport(r) {
      var out = [];
      out.push("J-Dawgs Grocy Server Config Safety Auditor™ — audit report");
      out.push("Verdict: " + r.verdict);
      out.push("Format detected: " + r.format);
      out.push("Settings read: " + r.entriesRead + " (" + r.recognized + " recognized)");
      out.push("Counts: " + r.counts.critical + " critical · " + r.counts.high + " high · " +
               r.counts.medium + " medium · " + r.counts.info + " info · " + r.counts.pass + " passed");
      out.push("");
      var problems = r.findings.filter(function (f) { return f.severity !== 'pass'; });
      var passes = r.findings.filter(function (f) { return f.severity === 'pass'; });
      if (problems.length) {
        out.push("Findings (worst first):");
        problems.forEach(function (f) {
          out.push("[" + f.severity.toUpperCase() + "] " + lineLabel(f) + (f.key ? " · " + f.key : "") + " — " + f.detail);
        });
        out.push("");
      } else {
        out.push("Findings: none. No problems were found in the pasted config.");
        out.push("");
      }
      if (passes.length) {
        out.push("Checks that passed:");
        passes.forEach(function (f) {
          out.push("[PASS] " + lineLabel(f) + (f.key ? " · " + f.key : "") + " — " + f.detail);
        });
        out.push("");
      }
      out.push("Secret handling: secret values never appear in this report. Secrets are identified by key name, line number, and value length only.");
      return out.join("\n");
    }

    function buildJSON(r) {
      var obj = {
        tool: "J-Dawgs Grocy Server Config Safety Auditor™",
        verdict: r.verdict,
        formatDetected: r.format,
        entriesRead: r.entriesRead,
        recognizedSettings: r.recognized,
        counts: { critical: r.counts.critical, high: r.counts.high, medium: r.counts.medium, info: r.counts.info, pass: r.counts.pass },
        findings: r.findings.filter(function (f) { return f.severity !== 'pass'; }).map(function (f) {
          var o = { severity: f.severity, check: f.check, key: f.key, line: f.line, detail: f.detail };
          if (typeof f.valueLength === 'number') o.valueLength = f.valueLength;
          return o;
        }),
        passed: r.findings.filter(function (f) { return f.severity === 'pass'; }).map(function (f) {
          return { check: f.check, key: f.key, line: f.line, detail: f.detail };
        }),
        secretHandling: "Secrets are reported by key name, line number, and value length only. Secret values never appear in this export."
      };
      return JSON.stringify(obj, null, 2);
    }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_SAMPLE": (typeof RISKY_SAMPLE !== 'undefined' ? RISKY_SAMPLE : undefined), "HARDENED_SAMPLE": (typeof HARDENED_SAMPLE !== 'undefined' ? HARDENED_SAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-grocy-server-config-safety-auditortm',
  name: 'J-Dawgs Grocy Server Config Safety Auditor',
  description: 'Host tools only tell you the server started; ours grades a pasted Grocy config offline into one deploy verdict — secrets by key name/line/length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_SAMPLE": __core["RISKY_SAMPLE"], "HARDENED_SAMPLE": __core["HARDENED_SAMPLE"] }
};
