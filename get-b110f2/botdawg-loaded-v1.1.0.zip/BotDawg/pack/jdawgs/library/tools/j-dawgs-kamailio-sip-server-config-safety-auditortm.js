'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Kamailio SIP Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var RISKY_LINES = [
          '# RISKY kamailio.cfg - do not deploy',
          'debug=3',
          'log_stderror=yes',
          'listen=udp:0.0.0.0:5060',
          'listen=tcp:0.0.0.0:5060',
          'loadmodule "db_mysql.so"',
          'loadmodule "auth.so"',
          'modparam("auth_db", "db_url", "mysql://kamailio:SuperSecretPass123@db.example.com/kamailio")',
          'modparam("usrloc", "db_url", "mysql://root:AnotherSecret99@localhost/kamailio")',
          'request_route {',
          '  if (is_method("REGISTER")) { save("location"); exit; }',
          '  if (is_method("INVITE")) { route(RELAY); exit; }',
          '  route(RELAY);',
          '}',
          'route[RELAY] { t_relay(); }'
        ];

        var HARDENED_LINES = [
          '# HARDENED kamailio.cfg',
          'debug=1',
          'log_stderror=no',
          'listen=tls:10.0.0.5:5061',
          'listen=udp:10.0.0.5:5060',
          'loadmodule "tls.so"',
          'loadmodule "auth_db.so"',
          'loadmodule "pike.so"',
          'loadmodule "ratelimit.so"',
          'modparam("auth_db", "db_url", "mysql://kamailio:${DB_PASS}@db.internal/kamailio")',
          'modparam("pike", "sampling_time_unit", 2)',
          'modparam("pike", "reqs_density_per_unit", 16)',
          'request_route {',
          '  if (!pike_check_req()) { sl_send_reply("503", "Too Many Requests"); exit; }',
          '  if (is_method("REGISTER")) { if (!www_authenticate("example.com", "subscriber")) { www_challenge("example.com", 0); exit; } save("location"); exit; }',
          '  if (is_method("INVITE")) { if (!proxy_authenticate("example.com", "subscriber")) { proxy_challenge("example.com", "0"); exit; } route(RELAY); exit; }',
          '}',
          'route[RELAY] { t_relay(); }'
        ];

        var SEV_ORDER = { CRITICAL: 0, WARNING: 1, INFO: 2 };

        function isExemptValue(v) {
          if (!v) return true;
          if (v.indexOf("${") !== -1 || v.indexOf("$(") !== -1) return true;
          var low = v.toLowerCase();
          if (low.indexOf("redacted") !== -1) return true;
          if (low.indexOf("change_me") !== -1 || low.indexOf("changeme") !== -1) return true;
          if (low.indexOf("placeholder") !== -1) return true;
          if (low === "example" || low === "password" || low === "passwd" || low === "secret") return true;
          return false;
        }

        function auditConfig(text) {
          var raw = typeof text === "string" ? text : "";
          var lines = raw.split(/\r?\n/);
          var nonEmpty = lines.filter(function (l) { return l.trim().length > 0; });
          var result = {
            verdict: "NOT ENOUGH TO GRADE",
            linesAudited: lines.length,
            counts: { CRITICAL: 0, WARNING: 0, INFO: 0 },
            findings: []
          };
          if (raw.trim().length === 0 || nonEmpty.length < 3 || raw.trim().length < 20) {
            return result;
          }

          var findings = [];
          function add(sev, cat, line, title, expl, fix, extra) {
            var f = { severity: sev, category: cat, line: line, title: title, explanation: expl, fix: fix };
            if (extra) { for (var k in extra) { f[k] = extra[k]; } }
            findings.push(f);
          }

          var lower = raw.toLowerCase();

          /* ---- Check 1: Listeners / TLS ---- */
          var listenIdx = [];
          var i, lineText;
          for (i = 0; i < lines.length; i++) {
            if (/^\s*listen\s*=/.test(lines[i])) listenIdx.push(i);
          }
          var hasTlsListener = listenIdx.some(function (idx) {
            return lines[idx].toLowerCase().indexOf("tls:") !== -1;
          });
          var hasTlsModule = /loadmodule\s+"[^"]*tls[^"]*"/i.test(raw) || /modparam\s*\(\s*"tls"/i.test(raw);
          var hasTlsSignal = hasTlsListener || hasTlsModule;
          var allIfaceIdx = listenIdx.filter(function (idx) {
            return lines[idx].indexOf("0.0.0.0") !== -1;
          });

          if (!hasTlsSignal) {
            if (allIfaceIdx.length > 0) {
              allIfaceIdx.forEach(function (idx) {
                add("CRITICAL", "Listeners/TLS", idx + 1,
                  "Listener bound to all interfaces (0.0.0.0) with no TLS anywhere in the config",
                  "This listen line exposes SIP on every network interface, and the config has no TLS listener and no TLS module loaded — signalling crosses the network unencrypted. The TLS module is missing entirely.",
                  "Bind listeners to a specific interface address, add a TLS listener (for example listen=tls:<address>:5061), and load the tls module (loadmodule \"tls.so\") with a valid certificate.");
              });
            } else {
              var warnLine = listenIdx.length > 0 ? listenIdx[0] + 1 : 1;
              add("WARNING", "Listeners/TLS", warnLine,
                "No TLS listener in the config",
                "No listen line uses tls:, and no TLS module is loaded, so there is no encrypted signalling path. The TLS module is missing entirely.",
                "Add a TLS listener on a specific address (for example listen=tls:<address>:5061) and load the tls module (loadmodule \"tls.so\") with a valid certificate.");
            }
          } else if (!hasTlsListener && hasTlsModule) {
            add("INFO", "Listeners/TLS", 1,
              "TLS module present but no TLS listener declared",
              "The TLS module is referenced, but no listen line uses tls:, so no encrypted listener is actually opened.",
              "Add a listen=tls:<address>:5061 line so the TLS module has a listener to serve.");
          }

          /* ---- Check 2: Authentication posture ---- */
          var authCallNames = ["www_authenticate", "proxy_authenticate", "auth_check", "pv_auth_check"];
          var hasAuthCall = authCallNames.some(function (n) { return raw.indexOf(n) !== -1; });
          var firstRegisterLine = 0, firstInviteLine = 0;
          for (i = 0; i < lines.length; i++) {
            if (!firstRegisterLine && lines[i].indexOf("REGISTER") !== -1) firstRegisterLine = i + 1;
            if (!firstInviteLine && lines[i].indexOf("INVITE") !== -1) firstInviteLine = i + 1;
          }
          var handlesMethods = firstRegisterLine > 0 || firstInviteLine > 0;
          var authModuleLoaded = /loadmodule\s+"[^"]*auth[^"]*"/i.test(raw);
          if (handlesMethods && !hasAuthCall) {
            var atLine = firstRegisterLine || firstInviteLine;
            var which = firstRegisterLine && firstInviteLine
              ? "REGISTER (and INVITE on line " + firstInviteLine + ")"
              : (firstRegisterLine ? "REGISTER" : "INVITE");
            add("CRITICAL", "Authentication", atLine,
              "Requests handled with no authentication check",
              "The config handles " + which + " but never calls www_authenticate, proxy_authenticate, auth_check, or pv_auth_check. Loading an auth module is not enough — nothing ever challenges the request, so anyone can register or call as anyone.",
              "Challenge REGISTER with www_authenticate / www_challenge and INVITE with proxy_authenticate / proxy_challenge (backed by auth_db or an equivalent credential store) before routing or saving locations.");
          } else if (hasAuthCall && !authModuleLoaded) {
            var callLine = 1;
            for (i = 0; i < lines.length; i++) {
              if (authCallNames.some(function (n) { return lines[i].indexOf(n) !== -1; })) { callLine = i + 1; break; }
            }
            add("WARNING", "Authentication", callLine,
              "Authentication calls used but no auth module is loaded",
              "The config calls an authentication function, but no loadmodule line loads an auth or auth_db module, so the call has nothing behind it on a real host.",
              "Load the matching module (for example loadmodule \"auth.so\" and loadmodule \"auth_db.so\") before the routes that call it.");
          }

          /* ---- Check 3: Plaintext DB credentials (values NEVER rendered) ---- */
          var dbUrlRe = /(mysql|mariadb|postgres|postgresql):\/\/([^:\/\s"']+):([^@\/\s"']+)@/i;
          var modparamRe = /modparam\s*\(\s*"[^"]*"\s*,\s*"([^"]+)"\s*,\s*"([^"]*)"\s*\)/;
          for (i = 0; i < lines.length; i++) {
            lineText = lines[i];
            var m = lineText.match(dbUrlRe);
            if (m) {
              var pw = m[3];
              if (!isExemptValue(pw)) {
                var keyName = "db_url";
                var km = lineText.match(modparamRe);
                if (km) keyName = km[1];
                add("CRITICAL", "Credentials", i + 1,
                  "Plaintext database password embedded in a DB URL",
                  "Key \"" + keyName + "\" on this line carries a database password written directly into the connection string. Password length: " + pw.length + " characters. The value itself is never shown in this audit — anyone who can read this file already has it, which is exactly the problem.",
                  "Remove the password from the config: pull it from an environment variable or a secrets file with restricted permissions, and rotate the exposed credential — it must be treated as compromised.",
                  { key: keyName, valueLength: pw.length, redacted: true });
                continue;
              } else {
                continue;
              }
            }
            var gm = lineText.match(modparamRe);
            if (gm && /db_url|password|passwd|pwd/i.test(gm[1])) {
              var val = gm[2];
              if (!isExemptValue(val) && val.length >= 6 && /[A-Za-z]/.test(val) && /[0-9]/.test(val)) {
                add("CRITICAL", "Credentials", i + 1,
                  "Plaintext credential stored as a literal value",
                  "Key \"" + gm[1] + "\" on this line is set to a literal value that looks like a real secret. Value length: " + val.length + " characters. The value itself is never shown in this audit.",
                  "Move the secret out of the config file into an environment variable or a restricted secrets file, and rotate it — treat the written-out value as compromised.",
                  { key: gm[1], valueLength: val.length, redacted: true });
              }
            }
          }

          /* ---- Check 4: Rate limiting / anti-fraud ---- */
          var rlTokens = ["pike", "ratelimit", "pike_check_req", "rl_check", "htable", "permissions"];
          var hasRl = rlTokens.some(function (t) { return lower.indexOf(t) !== -1; });
          if (!hasRl) {
            var rrLine = 1;
            for (i = 0; i < lines.length; i++) {
              if (lines[i].indexOf("request_route") !== -1) { rrLine = i + 1; break; }
            }
            add("WARNING", "Rate Limiting", rrLine,
              "No rate limiting or anti-fraud control found",
              "Nothing in the config references pike, ratelimit, pike_check_req, rl_check, htable-based fraud tracking, or permissions. A public SIP server with no flood control is an open invitation to scanning and toll fraud.",
              "Load pike and ratelimit, call pike_check_req() early in request_route, and answer floods with a 503; add htable or permissions-based source controls where you can.");
          }

          /* ---- Check 5: Debug logging ---- */
          var debugVal = -1, debugLine = 0, stderrLine = 0;
          for (i = 0; i < lines.length; i++) {
            var dm = lines[i].match(/^\s*debug\s*=\s*(\d+)/);
            if (dm) { debugVal = parseInt(dm[1], 10); debugLine = i + 1; }
            if (/^\s*log_stderror\s*=\s*yes/i.test(lines[i])) stderrLine = i + 1;
          }
          if (debugVal >= 3) {
            add("WARNING", "Logging", debugLine,
              "Debug level set to " + debugVal + " (3 or higher)",
              "A production config running at debug=" + debugVal + " writes heavy diagnostic detail and slows the server. Debug output can also capture signalling detail you do not want sitting in logs.",
              "Drop debug to 1 (or 2 at most) for production and raise it only while actively troubleshooting.");
            if (stderrLine) {
              add("WARNING", "Logging", stderrLine,
                "log_stderror=yes combined with high debug level",
                "With debug at " + debugVal + " and log_stderror=yes, the full debug stream goes to stderr, where it is easily captured, forwarded, and forgotten about.",
                "Set log_stderror=no in production and send logs through the normal syslog path with a sane retention policy.");
            }
          }

          findings.sort(function (a, b) {
            if (SEV_ORDER[a.severity] !== SEV_ORDER[b.severity]) return SEV_ORDER[a.severity] - SEV_ORDER[b.severity];
            return a.line - b.line;
          });

          result.findings = findings;
          findings.forEach(function (f) { result.counts[f.severity]++; });
          if (result.counts.CRITICAL > 0) result.verdict = "DO NOT DEPLOY";
          else if (result.counts.WARNING > 0) result.verdict = "DEPLOY WITH FIXES";
          else result.verdict = "SAFE TO DEPLOY";
          return result;
        }

        function buildReport(r) {
          var out = [];
          out.push("J-Dawgs Kamailio SIP Server Config Safety Auditor - Audit Report");
          out.push("Verdict: " + r.verdict);
          out.push("Lines audited: " + r.linesAudited);
          out.push("Findings: " + r.counts.CRITICAL + " critical, " + r.counts.WARNING + " warning, " + r.counts.INFO + " info");
          out.push("");
          if (r.verdict === "NOT ENOUGH TO GRADE") {
            out.push("The pasted text was empty or too short to grade (needs at least 3 non-empty lines and 20 characters).");
          } else if (r.findings.length === 0) {
            out.push("No findings. No critical, warning, or info items were detected by the heuristic checks.");
          } else {
            r.findings.forEach(function (f, n) {
              out.push((n + 1) + ". [" + f.severity + "] Line " + f.line + " - " + f.category + ": " + f.title);
              out.push("   " + f.explanation);
              out.push("   Fix: " + f.fix);
              if (f.key) out.push("   Credential detail (redacted): key=" + f.key + ", line=" + f.line + ", value length=" + f.valueLength + " characters. Value never rendered.");
              out.push("");
            });
          }
          out.push("Note: heuristic text audit only - not a real Kamailio parser, no live server was contacted. Credential values are never rendered; findings show key name, line number, and value length only.");
          return out.join("\n");
        }

        function buildJson(r) {
          var obj = {
            tool: "J-Dawgs Kamailio SIP Server Config Safety Auditor",
            verdict: r.verdict,
            linesAudited: r.linesAudited,
            counts: { critical: r.counts.CRITICAL, warning: r.counts.WARNING, info: r.counts.INFO },
            redaction: "Credential values are never included. Credential findings carry key name, line number, and value length only.",
            findings: r.findings.map(function (f) {
              var o = {
                severity: f.severity,
                category: f.category,
                line: f.line,
                title: f.title,
                explanation: f.explanation,
                fix: f.fix
              };
              if (f.key) { o.key = f.key; o.valueLength = f.valueLength; o.valueRedacted = true; }
              return o;
            })
          };
          return JSON.stringify(obj, null, 2);
        }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-kamailio-sip-server-config-safety-auditortm',
  name: 'J-Dawgs Kamailio SIP Server Config Safety Auditor',
  description: 'Grades a pasted kamailio.cfg offline — listeners/TLS, auth posture, plaintext DB credentials by key/line/length only — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
