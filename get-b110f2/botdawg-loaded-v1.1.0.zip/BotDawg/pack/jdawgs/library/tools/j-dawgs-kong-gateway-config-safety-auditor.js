'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Kong Gateway Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

/* ---------- Worked examples (line numbers are part of the spec) ---------- */
var RISKY = [
  '# Risky Kong gateway - sample paste',
  'admin_listen = 0.0.0.0:8001',
  'proxy_listen = 0.0.0.0:8000',
  'database = postgres',
  'pg_host = 127.0.0.1',
  'pg_password = k0ng-pw-7',
  'pg_ssl = off',
  'trusted_ips = 0.0.0.0/0',
  'cluster_listen = 0.0.0.0:8005',
  'anonymous_reports = on',
  'KONG_ADMIN_API_URI=http://gateway.example.com:8001',
  '# pg_password_old = oldcommentedsecret99',
  'this line is not a kong setting at all'
].join('\n');

var HARDENED = [
  '# Hardened Kong gateway - sample paste',
  'admin_listen = 127.0.0.1:8001 ssl',
  'admin_ssl_cert = /etc/kong/tls/admin.crt',
  'admin_ssl_cert_key = /etc/kong/tls/admin.key',
  'proxy_listen = 0.0.0.0:8443 ssl',
  'ssl_cert = /etc/kong/tls/proxy.crt',
  'ssl_cert_key = /etc/kong/tls/proxy.key',
  'database = postgres',
  'pg_password = ${KONG_PG_PASSWORD}',
  'pg_ssl = on',
  'trusted_ips = 127.0.0.1, 10.0.0.0/8',
  'cluster_listen = 127.0.0.1:8005',
  'cluster_cert = /etc/kong/tls/cluster.crt',
  'cluster_cert_key = /etc/kong/tls/cluster.key',
  'headers = off',
  'anonymous_reports = off',
  'KONG_ADMIN_API_URI=https://gateway.example.com:8444'
].join('\n');

var PROSE = [
  'The gateway migration is planned for next Tuesday.',
  'We should talk to the platform team before changing anything.',
  'Nothing in this note is a configuration file.'
].join('\n');

/* ---------- Parsing helpers ---------- */
var SECRET_RE = /(password|secret|token|api_key|apikey|private_key)/i;
var DEFAULT_SECRETS = ['kong','password','changeme','example','secret','admin','letmein','default','test','kongadmin','postgres'];
var KNOWN_KEYS = {
  prefix:1, role:1, database:1, pg_host:1, pg_port:1, pg_user:1, pg_password:1, pg_database:1,
  pg_ssl:1, pg_ssl_verify:1, pg_timeout:1, admin_listen:1, admin_api_uri:1, admin_gui_listen:1,
  admin_gui_url:1, admin_gui:1, proxy_listen:1, proxy_listen_ssl:1, ssl_cert:1, ssl_cert_key:1,
  admin_ssl_cert:1, admin_ssl_cert_key:1, cluster_listen:1, cluster_cert:1, cluster_cert_key:1,
  cluster_tls:1, trusted_ips:1, headers:1, real_ip_header:1, real_ip_recursive:1,
  anonymous_reports:1, error_default_type:1, upstream_keepalive:1, client_max_body_size:1,
  _format_version:1, services:1, routes:1, plugins:1, consumers:1, upstreams:1, certificates:1,
  name:1, host:1, port:1, path:1, protocol:1, username:1, keyauth_credentials:1, key:1,
  anonymous:1, https_redirect_status_code:1, config:1, targets:1, retries:1, connect_timeout:1,
  enabled:1, strip_path:1, protocols:1, methods:1, hosts:1, paths:1, snis:1
};
var STRONG_KEYS = { admin_listen:1, proxy_listen:1, database:1, _format_version:1, cluster_listen:1,
  pg_password:1, pg_ssl:1, trusted_ips:1, admin_api_uri:1, services:1, consumers:1 };

function stripQuotes(v){
  v = (v || '').trim();
  if (v.length >= 2 && ((v.charAt(0) === '"' && v.charAt(v.length-1) === '"') ||
      (v.charAt(0) === "'" && v.charAt(v.length-1) === "'"))) v = v.slice(1, -1);
  return v.trim();
}
function isEnvRef(v){
  return /^\$\{[^}]+\}$/.test(v) || /^\$[A-Za-z_][A-Za-z0-9_]*$/.test(v) ||
         v.indexOf('vault://') === 0 || v.indexOf('{vault') === 0;
}
function isTruthy(v){ v = (v||'').toLowerCase(); return v === 'on' || v === 'true' || v === 'yes' || v === '1'; }
function isFalsy(v){ v = (v||'').toLowerCase(); return v === 'off' || v === 'false' || v === 'no' || v === '0'; }

/* Parse one config-looking line. Returns {key, norm, value} or null. */
function parseLine(raw){
  var m;
  m = raw.match(/^\s*(?:export\s+)?(KONG_[A-Z0-9_]+)\s*=\s*(.*)$/);
  if (m) return { key: m[1], norm: m[1].replace(/^KONG_/, '').toLowerCase(), value: stripQuotes(m[2]) };
  m = raw.match(/^\s*"?([A-Za-z_][A-Za-z0-9_.-]*)"?\s*[:=]\s*(.*)$/);
  if (m) return { key: m[1], norm: m[1].toLowerCase(), value: stripQuotes(m[2]) };
  m = raw.match(/^\s*-\s*"?([A-Za-z_][A-Za-z0-9_.-]*)"?\s*:\s*(.*)$/);
  if (m) return { key: m[1], norm: m[1].toLowerCase(), value: stripQuotes(m[2]) };
  return null;
}

function audit(text){
  var findings = [], passes = [], noted = [];
  var lines = text.split(/\r?\n/);
  var entries = [];           /* active parsed entries {line,key,norm,value} */
  var byKey = {};             /* norm -> [entries] */
  var recognized = 0, strong = 0;

  function add(sev, line, key, msg, fix){ findings.push({severity:sev, line:line, key:key, message:msg, fix:fix || ''}); }
  function pass(line, key, msg){ passes.push({severity:'PASS', line:line, key:key, message:msg, fix:''}); }

  /* --- Pass 1: classify every line --- */
  lines.forEach(function(raw, idx){
    var lineNo = idx + 1;
    var t = raw.trim();
    if (!t) return;
    if (t === '---' || t === '{' || t === '}' || t === '[' || t === ']') return;
    if (t.charAt(0) === '#'){
      var inner = t.replace(/^#+\s*/, '');
      var cp = parseLine(inner);
      if (cp && (KNOWN_KEYS[cp.norm] || SECRET_RE.test(cp.key))){
        if (SECRET_RE.test(cp.key)){
          noted.push({severity:'COMMENTED', line:lineNo, key:cp.key,
            message:'Commented-out line (COMMENTED / NOT ACTIVE) naming a secret-style key. Reported by key name and value length only (' + cp.value.length + ' characters); the value is never printed. Not graded as an active setting.',
            fix:'Remove old credentials from config files entirely, even commented out, and rotate any that were real.'});
        } else {
          noted.push({severity:'COMMENTED', line:lineNo, key:cp.key,
            message:'Commented-out line (COMMENTED / NOT ACTIVE). Not graded as an active setting.',
            fix:''});
        }
      }
      return;
    }
    var p = parseLine(raw);
    if (!p){
      noted.push({severity:'NOT_PARSED', line:lineNo, key:'(unrecognized line)',
        message:'NOT PARSED: this non-empty line does not match any recognized Kong setting format (kong.conf property, KONG_* line, or YAML/JSON key), so it was not graded.',
        fix:'If this line was meant to be a setting, rewrite it as key = value, a KONG_* line, or a YAML/JSON key.'});
      return;
    }
    entries.push({line:lineNo, key:p.key, norm:p.norm, value:p.value});
    if (!byKey[p.norm]) byKey[p.norm] = [];
    byKey[p.norm].push(entries[entries.length-1]);
    if (KNOWN_KEYS[p.norm]){ recognized++; if (STRONG_KEYS[p.norm]) strong++; }
  });

  var gradeable = recognized >= 2 || strong >= 1;
  if (!gradeable){
    return { verdict:'NOT ENOUGH TO GRADE', gradeable:false, findings:findings, passes:passes, noted:noted,
      counts: countAll(findings, passes, noted) };
  }

  function first(norm){ return byKey[norm] ? byKey[norm][0] : null; }
  function has(norm){ return !!byKey[norm]; }
  var declarative = has('_format_version') || has('services') || has('consumers');

  /* --- Secrets anywhere (values never rendered) --- */
  entries.forEach(function(e){
    if (!SECRET_RE.test(e.key)) return;
    if (e.norm === 'pg_password' || true){
      if (!e.value){ return; }
      if (isEnvRef(e.value)){
        pass(e.line, e.key, 'Secret "' + e.key + '" is supplied as an environment/vault reference, not a plaintext value in the file. That is the safe pattern.');
        return;
      }
      var len = e.value.length;
      if (DEFAULT_SECRETS.indexOf(e.value.toLowerCase()) !== -1){
        add('BLOCKER', e.line, e.key, 'Secret "' + e.key + '" is set to a well-known example/default value (reported by key name and length only: ' + len + ' characters; the value is never printed). Anyone who knows the default can use it.',
          'Replace it with a long random secret supplied from an environment variable or vault reference, and rotate the old value.');
      } else if (len < 16){
        add('BLOCKER', e.line, e.key, 'Secret "' + e.key + '" is stored in plaintext and is short (' + len + ' characters; the value is never printed). Short plaintext secrets are easy to guess and leak with the file.',
          'Use a random secret of at least 16 characters, supplied from an environment variable or vault reference (for example ${KONG_PG_PASSWORD}), and rotate the old value.');
      } else {
        add('HIGH', e.line, e.key, 'Secret "' + e.key + '" is stored in plaintext in the config file (' + len + ' characters; the value is never printed). Anyone who can read the file has the credential.',
          'Move it to an environment variable or vault reference and rotate the exposed value.');
      }
    }
  });

  /* --- Admin API exposure --- */
  if (has('admin_listen')){
    byKey['admin_listen'].forEach(function(e){
      var v = e.value.toLowerCase();
      var loopback = v.indexOf('127.0.0.1') !== -1 || v.indexOf('localhost') !== -1;
      var allIface = v.indexOf('0.0.0.0') !== -1;
      var ssl = /(^|[\s,])ssl([\s,]|$)/.test(v);
      if (allIface && !ssl){
        add('BLOCKER', e.line, e.key, 'Admin API listens on all interfaces (0.0.0.0) with no TLS on the listener. The Admin API can fully control the gateway, so anyone who can reach this port over the network can take it over.',
          'Bind the Admin API to loopback (127.0.0.1) and/or enable ssl on the listener with admin TLS certificates, and restrict it with a firewall.');
      } else if (allIface && ssl){
        add('WARNING', e.line, e.key, 'Admin API listens on all interfaces (0.0.0.0), though TLS is enabled on the listener. The Admin API is still reachable from the whole network.',
          'Prefer binding the Admin API to loopback or a private management network, even with TLS on.');
      } else if (loopback){
        pass(e.line, e.key, 'Admin API is bound to loopback (127.0.0.1), so it is not reachable from other machines.');
      }
    });
  }
  ['admin_api_uri','admin_gui_url','admin_gui'].forEach(function(norm){
    if (!has(norm)) return;
    byKey[norm].forEach(function(e){
      if (/^http:\/\//i.test(e.value)){
        add('HIGH', e.line, e.key, '"' + e.key + '" uses plain http. Admin traffic and credentials sent to this address cross the network unencrypted.',
          'Serve the Admin API / Admin GUI over https with a valid certificate.');
      } else if (/^https:\/\//i.test(e.value)){
        pass(e.line, e.key, '"' + e.key + '" uses https.');
      }
    });
  });

  /* --- Proxy listeners & TLS certs --- */
  var sslListenerLines = [];
  if (has('proxy_listen')){
    var anySsl = false, anyPublic = false, firstProxy = byKey['proxy_listen'][0];
    byKey['proxy_listen'].forEach(function(e){
      var v = e.value.toLowerCase();
      if (/(^|[\s,])ssl([\s,]|$)/.test(v)){ anySsl = true; sslListenerLines.push(e); }
      if (v.indexOf('0.0.0.0') !== -1) anyPublic = true;
    });
    add('INFO', firstProxy.line, firstProxy.key, 'proxy_listen on all interfaces is normal for a gateway — the proxy is meant to receive outside traffic. This is informational, not a problem by itself.',
      '');
    if (anySsl){
      if (!has('ssl_cert') || !has('ssl_cert_key')){
        sslListenerLines.forEach(function(e){
          add('HIGH', e.line, e.key, 'An SSL proxy listener is declared, but ssl_cert / ssl_cert_key are not both set in this config, so the TLS certificate for the listener cannot be confirmed from the file.',
            'Set both ssl_cert and ssl_cert_key to the certificate and key for the SSL listener.');
        });
      } else {
        pass(firstProxy.line, firstProxy.key, 'SSL proxy listener is declared and ssl_cert / ssl_cert_key are both set.');
      }
    } else if (anyPublic){
      add('WARNING', firstProxy.line, firstProxy.key, 'proxy_listen exposes a public listener with SSL disabled on it (no ssl flag on any proxy_listen entry). Traffic to this listener is unencrypted unless a load balancer in front terminates TLS.',
        'Add an ssl listener (for example 0.0.0.0:8443 ssl) with ssl_cert / ssl_cert_key, or confirm TLS is terminated in front of the gateway.');
    }
  }

  /* --- Database posture --- */
  if (has('database')){
    var db = first('database');
    if (db.value.toLowerCase() === 'off'){
      pass(db.line, db.key, 'database = off: DB-less / declarative mode, so there is no database password to expose.');
    } else if (db.value.toLowerCase() === 'postgres'){
      add('INFO', db.line, db.key, 'database = postgres: Kong will store configuration in PostgreSQL. The database connection settings in this file are what protect it.', '');
    }
  }
  if (has('pg_ssl')){
    var pgs = first('pg_ssl');
    if (isFalsy(pgs.value)){
      add('HIGH', pgs.line, pgs.key, 'pg_ssl is off: the connection between Kong and PostgreSQL is not encrypted, so database traffic (including queries and credentials in transit) can be read on the network.',
        'Set pg_ssl = on and configure the database to accept TLS connections.');
    } else if (isTruthy(pgs.value)){
      pass(pgs.line, pgs.key, 'pg_ssl is on: the Kong-to-PostgreSQL connection is encrypted.');
    }
  }

  /* --- Cluster / control plane --- */
  if (has('cluster_listen')){
    byKey['cluster_listen'].forEach(function(e){
      var v = e.value.toLowerCase();
      var allIface = v.indexOf('0.0.0.0') !== -1;
      var loopback = v.indexOf('127.0.0.1') !== -1 || v.indexOf('localhost') !== -1;
      var tls = has('cluster_cert') && has('cluster_cert_key');
      if (allIface && !tls){
        add('HIGH', e.line, e.key, 'cluster_listen is bound to all interfaces (0.0.0.0) but cluster_cert / cluster_cert_key are not both set, so control-plane / cluster traffic has no confirmed mutual TLS.',
          'Set cluster_cert and cluster_cert_key for mutual TLS, and/or bind cluster_listen to a private network or loopback.');
      } else if (allIface && tls){
        add('WARNING', e.line, e.key, 'cluster_listen is bound to all interfaces (0.0.0.0). Cluster TLS certificates are set, but the port is still reachable from the whole network.',
          'Restrict cluster_listen to the private network the data planes use, and firewall the port.');
      } else if (loopback){
        pass(e.line, e.key, 'cluster_listen is bound to loopback, so the cluster port is not reachable from other machines.');
      }
    });
    if (has('cluster_cert') && has('cluster_cert_key') && !has('cluster_listen')){
      pass(first('cluster_cert').line, 'cluster_cert', 'Cluster TLS certificate and key are set.');
    }
  }
  if (has('anonymous_reports')){
    var ar = first('anonymous_reports');
    if (isTruthy(ar.value)){
      add('INFO', ar.line, ar.key, 'anonymous_reports is on: Kong sends anonymous usage telemetry. This is a privacy/egress note, not a vulnerability.', 'Set anonymous_reports = off if you do not want the gateway sending telemetry.');
    } else if (isFalsy(ar.value)){
      pass(ar.line, ar.key, 'anonymous_reports is off: no anonymous telemetry is sent.');
    }
  }

  /* --- Headers / hardening --- */
  if (has('trusted_ips')){
    byKey['trusted_ips'].forEach(function(e){
      var v = e.value.replace(/\s+/g,'');
      if (v.indexOf('0.0.0.0/0') !== -1 || v.indexOf('::/0') !== -1){
        add('HIGH', e.line, e.key, 'trusted_ips trusts every address (0.0.0.0/0). Kong will believe X-Forwarded-For and similar headers from anyone, so clients can spoof their source IP and defeat IP-based restrictions and rate limiting.',
          'Restrict trusted_ips to the actual load balancers / proxies in front of Kong (specific addresses or private CIDR ranges).');
      } else {
        pass(e.line, e.key, 'trusted_ips is restricted to specific addresses/ranges rather than trusting everyone.');
      }
    });
  }
  if (has('headers')){
    var hd = first('headers');
    var hv = hd.value.toLowerCase();
    if (hv === 'off' || hv.indexOf('server_tokens') === -1){
      pass(hd.line, hd.key, 'The headers setting does not emit the Server / server_tokens header, so responses do not advertise the gateway software version.');
    } else {
      add('WARNING', hd.line, hd.key, 'The headers setting still emits server_tokens, so responses advertise the Kong version in the Server header, which helps attackers target known vulnerabilities.',
        'Remove server_tokens from the headers setting (or set headers = off) so the Server header is not sent.');
    }
  }
  if (has('real_ip_header')){
    var ri = first('real_ip_header');
    add('INFO', ri.line, ri.key, 'real_ip_header is set to "' + ri.value + '": Kong takes the client IP from this header. That is only safe when trusted_ips limits who may set it.', '');
  }

  /* --- Declarative config checks --- */
  if (declarative){
    /* services on plain http to public hosts */
    entries.forEach(function(e, i){
      if (e.norm !== 'protocol' || e.value.toLowerCase() !== 'http') return;
      var hostVal = null;
      for (var j = Math.max(0, i-6); j < Math.min(entries.length, i+7); j++){
        if (entries[j].norm === 'host'){ hostVal = entries[j].value; break; }
      }
      var priv = hostVal && (/^(localhost|127\.|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(hostVal) ||
                 /\.(internal|local|svc|lan)$/i.test(hostVal));
      if (hostVal && !priv){
        add('WARNING', e.line, e.key, 'A declarative service uses protocol http to a public host ("' + hostVal + '"), so upstream traffic crosses the network unencrypted.',
          'Use protocol https for public upstreams, or confirm the upstream is inside a private network.');
      } else {
        add('INFO', e.line, e.key, 'A declarative service uses protocol http' + (hostVal ? ' to "' + hostVal + '"' : '') + '. Fine inside a private network; risky for public hosts.', '');
      }
    });
    /* consumer key-auth credentials in the file */
    entries.forEach(function(e){
      if (e.norm === 'keyauth_credentials'){
        add('HIGH', e.line, e.key, 'A consumer has key-auth credentials listed in this declarative file. Those API keys are stored in plaintext wherever this file lives (values are masked in this report).',
          'Provision consumer keys through a secrets manager or the Admin API instead of committing them to a config file, and rotate any keys that were in the file.');
      }
      if (e.norm === 'key' && e.value && !isEnvRef(e.value)){
        add('HIGH', e.line, e.key, 'A credential "key" value is listed in plaintext in this file (reported by line and length only: ' + e.value.length + ' characters; the value is never printed).',
          'Move consumer credentials out of the file into a secrets manager and rotate this key.');
      }
    });
    /* anonymous access in plugins */
    entries.forEach(function(e){
      if (e.norm !== 'anonymous') return;
      var v = e.value;
      if (v && !isFalsy(v) && v.toLowerCase() !== 'null' && v !== '~'){
        add('HIGH', e.line, e.key, 'A plugin has anonymous access enabled (an "anonymous" consumer/fallback is configured). Requests without credentials can still reach the service as the anonymous consumer.',
          'Remove the anonymous setting from the plugin unless unauthenticated fallback access is intended, and scope the anonymous consumer to the minimum access needed.');
      }
    });
    /* routes HTTPS redirect */
    if (has('routes')){
      if (has('https_redirect_status_code')){
        var hr = first('https_redirect_status_code');
        pass(hr.line, hr.key, 'Routes set https_redirect_status_code, so plain-HTTP requests are redirected to HTTPS.');
      } else {
        var rt = first('routes');
        add('WARNING', rt.line, rt.key, 'This declarative config declares routes but no https_redirect_status_code was found, so routes may not redirect plain HTTP to HTTPS.',
          'Set https_redirect_status_code (for example 426 or 301) on routes that should force HTTPS.');
      }
    }
  }

  /* --- Verdict --- */
  var counts = countAll(findings, passes, noted);
  var verdict;
  if (counts.BLOCKER > 0) verdict = 'DO NOT DEPLOY';
  else if (counts.HIGH > 0 || counts.WARNING > 0) verdict = 'DEPLOY WITH FIXES';
  else verdict = 'SAFE TO DEPLOY';
  return { verdict: verdict, gradeable: true, findings: findings, passes: passes, noted: noted, counts: counts };
}

function countAll(findings, passes, noted){
  var c = { BLOCKER:0, HIGH:0, WARNING:0, INFO:0, PASS: passes.length, COMMENTED:0, NOT_PARSED:0 };
  findings.forEach(function(f){ c[f.severity] = (c[f.severity]||0) + 1; });
  noted.forEach(function(n){ c[n.severity] = (c[n.severity]||0) + 1; });
  return c;
}
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-kong-gateway-config-safety-auditor',
  name: 'J-Dawgs Kong Gateway Config Safety Auditor',
  description: 'Grades a pasted Kong Gateway config fully offline into one deploy verdict — SAFE TO DEPLOY / DEPLOY WITH FIXES / DO NOT DEPLOY / NOT ENOUGH TO GRADE — Admin API exposure, pg_password and other plaintext secrets, trusted_ips, and cluster TLS, with secrets shown by key name, line, and length only, nev',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
