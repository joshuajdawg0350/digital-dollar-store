'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Nginx Config Pre-Flight Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------------- Worked examples ---------------- */

      var RISKY = [
        'user www-data;',
        'worker_processes 2;',
        '',
        'events {',
        '    worker_connections 1024;',
        '}',
        '',
        'http {',
        '    server_tokens on;',
        '',
        '    server {',
        '        listen 80 default_server;',
        '        server_name shop.example.com;',
        '        root /var/www/shop;',
        '        autoindex on;',
        '',
        '        location / {',
        '            proxy_pass http://127.0.0.1:3000;',
        '        }',
        '    }',
        '',
        '    server {',
        '        listen 80 default_server;',
        '        listen 443 ssl;',
        '        server_name shop.example.com;',
        '',
        '        ssl_certificate /etc/nginx/certs/shop.crt;',
        '        ssl_protocols TLSv1 TLSv1.2;',
        '',
        '        location /files/ {',
        '            alias /srv/files/;',
        '            autoindex on;',
        '        }',
        '    }',
        '}'
      ].join('\n');

      var CLEAN = [
        'user www-data;',
        'worker_processes auto;',
        '',
        'events {',
        '    worker_connections 1024;',
        '}',
        '',
        'http {',
        '    server_tokens off;',
        '    client_max_body_size 10m;',
        '    ssl_protocols TLSv1.2 TLSv1.3;',
        '',
        '    add_header X-Content-Type-Options "nosniff" always;',
        '    add_header X-Frame-Options "SAMEORIGIN" always;',
        '    add_header Strict-Transport-Security "max-age=31536000" always;',
        '',
        '    server {',
        '        listen 80;',
        '        server_name clean.example.com;',
        '        return 301 https://$host$request_uri;',
        '    }',
        '',
        '    server {',
        '        listen 443 ssl;',
        '        server_name clean.example.com;',
        '',
        '        ssl_certificate /etc/nginx/certs/clean.crt;',
        '        ssl_certificate_key /etc/nginx/certs/clean.key;',
        '        ssl_protocols TLSv1.2 TLSv1.3;',
        '',
        '        add_header X-Content-Type-Options "nosniff" always;',
        '        add_header X-Frame-Options "DENY" always;',
        '        add_header Strict-Transport-Security "max-age=63072000; includeSubDomains" always;',
        '',
        '        root /var/www/clean;',
        '        client_max_body_size 10m;',
        '',
        '        location / {',
        '            proxy_pass https://127.0.0.1:8443;',
        '            proxy_set_header Host $host;',
        '            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;',
        '        }',
        '',
        '        location ~ /\\.(?!well-known) {',
        '            deny all;',
        '        }',
        '    }',
        '}'
      ].join('\n');

      var PITCHES = {
        'pitch-store': 'Pre-flight any nginx config before it ships — the J-Dawgs Nginx Config Pre-Flight Auditor™ checks structure, TLS, headers, and proxy settings right in the browser. Get it at the AI Tool Store: https://muse.ai/s/ai-tool-store-xng6xkxwjkxl2xab/UoF72OkKI7j33Q2ITxmrZyIr4nv40QtYfj2AgESh_k8',
        'pitch-exchange': 'Agents: trade and pick up agent-built tools like the Nginx Config Pre-Flight Auditor™ at the J-Dawgs Agent Exchange: https://muse.ai/s/j-dawgs-agent-exchange-ih6xlnihzxdhxc/ZbleqxFHRE0NcswaBkyN13y9lLp5rPAgHTb6t8ii-PY',
        'pitch-bundle': 'The "Stack & Ship Stack" — Compose Stack Safety Auditor + Nginx Config Pre-Flight Auditor + Few-Shot Example Auditor + Changelog & Version Honesty Auditor (vet the stack, vet the server, vet the examples, vet the release).'
      };

      /* ---------------- Tokenizer ---------------- */

      function tokenize(text) {
        var tokens = [];
        var i = 0, line = 1, n = text.length;
        while (i < n) {
          var c = text.charAt(i);
          if (c === '\n') { line++; i++; continue; }
          if (c === ' ' || c === '\t' || c === '\r') { i++; continue; }
          if (c === '#') { while (i < n && text.charAt(i) !== '\n') i++; continue; }
          if (c === '{' || c === '}' || c === ';') { tokens.push({ type: c, line: line }); i++; continue; }
          if (c === '"' || c === "'") {
            var q = c, val = c, startQ = line; i++;
            while (i < n && text.charAt(i) !== q) {
              if (text.charAt(i) === '\n') line++;
              val += text.charAt(i); i++;
            }
            if (i < n) { val += q; i++; }
            tokens.push({ type: 'word', value: val, line: startQ });
            continue;
          }
          var v = '', startW = line;
          while (i < n && ' \t\r\n{};#'.indexOf(text.charAt(i)) === -1) { v += text.charAt(i); i++; }
          tokens.push({ type: 'word', value: v, line: startW });
        }
        return tokens;
      }

      /* ---------------- Tolerant block parser ---------------- */

      function parseConfig(text) {
        var tokens = tokenize(text);
        var root = { kind: 'block', name: '(top level)', args: [], line: 0, children: [], parent: null };
        var notParsed = [];
        var unbalanced = [];
        var pos = 0;

        function wordsText(ws) { return ws.map(function (w) { return w.value; }).join(' '); }

        function parseInto(node) {
          var pending = [];
          while (pos < tokens.length) {
            var t = tokens[pos];
            if (t.type === 'word') { pending.push(t); pos++; continue; }
            if (t.type === ';') {
              pos++;
              if (pending.length) {
                node.children.push({
                  kind: 'directive', name: pending[0].value,
                  args: pending.slice(1).map(function (w) { return w.value; }),
                  line: pending[0].line, parent: node
                });
                pending = [];
              }
              continue;
            }
            if (t.type === '{') {
              pos++;
              if (!pending.length) {
                notParsed.push({ line: t.line, text: 'A "{" opens a block with no block name in front of it, so the block cannot be placed.' });
                continue;
              }
              var block = {
                kind: 'block', name: pending[0].value,
                args: pending.slice(1).map(function (w) { return w.value; }),
                line: pending[0].line, children: [], parent: node
              };
              node.children.push(block);
              pending = [];
              parseInto(block);
              continue;
            }
            if (t.type === '}') {
              pos++;
              if (pending.length) {
                notParsed.push({ line: pending[0].line, text: 'This statement is never terminated with ";" and never opened as a block, so it was not parsed: "' + wordsText(pending) + '"' });
                pending = [];
              }
              if (node === root) {
                unbalanced.push({ line: t.line, text: 'A "}" on this line closes a block that was never opened.' });
                continue;
              }
              return;
            }
          }
          if (pending.length) {
            notParsed.push({ line: pending[0].line, text: 'This statement runs to the end of the file with no ";" and no block, so it was not parsed: "' + wordsText(pending) + '"' });
          }
          if (node !== root) {
            unbalanced.push({ line: node.line, text: 'The "' + node.name + '" block opened on this line is never closed — a "}" is missing.' });
          }
        }

        parseInto(root);
        return { root: root, notParsed: notParsed, unbalanced: unbalanced };
      }

      /* ---------------- Tree helpers ---------------- */

      function childDirectives(node, name) {
        return node.children.filter(function (c) { return c.kind === 'directive' && c.name === name; });
      }
      function allBlocks(node, name, out) {
        out = out || [];
        node.children.forEach(function (c) {
          if (c.kind === 'block') {
            if (c.name === name) out.push(c);
            allBlocks(c, name, out);
          }
        });
        return out;
      }
      function allDirectives(node, name, out) {
        out = out || [];
        node.children.forEach(function (c) {
          if (c.kind === 'directive' && c.name === name) out.push(c);
          if (c.kind === 'block') allDirectives(c, name, out);
        });
        return out;
      }
      function lookupChain(node, name) {
        var cur = node;
        while (cur) {
          var found = childDirectives(cur, name);
          if (found.length) return { directive: found[0], level: cur };
          cur = cur.parent;
        }
        return null;
      }
      function chainHasHeader(node, headerName) {
        var cur = node;
        while (cur) {
          var hits = childDirectives(cur, 'add_header').filter(function (d) {
            return d.args.length && d.args[0].toLowerCase() === headerName;
          });
          if (hits.length) return { directive: hits[0], level: cur };
          cur = cur.parent;
        }
        return null;
      }
      function chainHasFrameProtection(node) {
        var cur = node;
        while (cur) {
          var hit = null;
          childDirectives(cur, 'add_header').forEach(function (d) {
            if (!d.args.length) return;
            var h = d.args[0].toLowerCase();
            if (h === 'x-frame-options') hit = d;
            if (h === 'content-security-policy' && d.args.join(' ').toLowerCase().indexOf('frame-ancestors') !== -1) hit = d;
          });
          if (hit) return { directive: hit, level: cur };
          cur = cur.parent;
        }
        return null;
      }
      function listenInfo(serverBlock) {
        return childDirectives(serverBlock, 'listen').map(function (d) {
          var addr = d.args.length ? d.args[0] : '';
          var port = addr;
          if (addr.indexOf(']') !== -1) port = addr.slice(addr.lastIndexOf(':') + 1);
          else if (addr.indexOf(':') !== -1) port = addr.slice(addr.lastIndexOf(':') + 1);
          var flags = d.args.slice(1).map(function (a) { return a.toLowerCase(); });
          return { directive: d, port: port, flags: flags, ssl: flags.indexOf('ssl') !== -1 || flags.indexOf('http2') !== -1 && port === '443' };
        });
      }
      function blockHasHttpsRedirect(block) {
        var found = false;
        allDirectives(block, 'return').forEach(function (d) {
          if (d.args.join(' ').toLowerCase().indexOf('https://') !== -1) found = true;
        });
        if (!found) {
          allDirectives(block, 'rewrite').forEach(function (d) {
            var a = d.args.join(' ').toLowerCase();
            if (a.indexOf('https://') !== -1 && (a.indexOf('permanent') !== -1 || a.indexOf('redirect') !== -1)) found = true;
          });
        }
        return found;
      }

      /* ---------------- Audit ---------------- */

      function audit(text) {
        var findings = [];
        function add(sev, line, title, detail, fix) {
          findings.push({ sev: sev, line: line, title: title, detail: detail || '', fix: fix || '' });
        }

        var parsed = parseConfig(text);
        var root = parsed.root;

        parsed.unbalanced.forEach(function (u) {
          add('blocker', u.line, 'Unbalanced braces', u.text, 'Match every "{" with a closing "}" at the same nesting level, then re-run this pre-flight.');
        });
        parsed.notParsed.forEach(function (np) {
          add('notparsed', np.line, 'NOT PARSED', np.text, 'Fix the line so it is a complete directive ending in ";" or a named block, then re-run. Nothing past an unparsed line is guessed at.');
        });

        var servers = allBlocks(root, 'server');

        /* Cross-block: duplicate default_server per port */
        var defaultSeen = {};
        servers.forEach(function (sb) {
          listenInfo(sb).forEach(function (li) {
            if (li.flags.indexOf('default_server') !== -1) {
              if (defaultSeen[li.port]) {
                add('blocker', li.directive.line,
                  'Duplicate default_server on port ' + li.port,
                  'Another server block already claims default_server for port ' + li.port + ' (line ' + defaultSeen[li.port] + '). nginx refuses to load a config with two default servers for the same listen socket.',
                  'Keep default_server on exactly one server block per port; remove it from the others.');
              } else {
                defaultSeen[li.port] = li.directive.line;
              }
            }
          });
        });

        var anySslAnywhere = servers.some(function (sb) {
          return listenInfo(sb).some(function (li) { return li.ssl || li.port === '443'; });
        });

        /* Global: autoindex on anywhere */
        allDirectives(root, 'autoindex').forEach(function (d) {
          if (d.args.length && d.args[0].toLowerCase() === 'on') {
            add('blocker', d.line, 'autoindex is on',
              'Directory listing is enabled here. Anyone can browse the full contents of the affected directory, including files that were never meant to be linked.',
              'Set autoindex off (or remove the directive — off is the default) unless a public file listing is genuinely intended.');
          }
        });

        /* Global: ssl_protocols with dead versions, wherever set */
        allDirectives(root, 'ssl_protocols').forEach(function (d) {
          var bad = d.args.filter(function (a) { return a === 'TLSv1' || a === 'TLSv1.1'; });
          if (bad.length) {
            add('blocker', d.line, 'Obsolete TLS versions enabled: ' + bad.join(', '),
              'ssl_protocols here turns on ' + bad.join(' and ') + '. Both are deprecated, blocked by modern browsers, and fail current compliance scans.',
              'Restrict ssl_protocols to TLSv1.2 and TLSv1.3 only.');
          }
        });

        /* server_tokens */
        var tokensDirs = allDirectives(root, 'server_tokens');
        if (!tokensDirs.length) {
          add('info', null, 'server_tokens is not set anywhere',
            'With no server_tokens directive in the pasted text, nginx\'s default applies and the exact nginx version is disclosed in response headers and error pages.',
            'Add "server_tokens off" at the http level to stop advertising the version.');
        } else {
          tokensDirs.forEach(function (d) {
            if (d.args.length && d.args[0].toLowerCase() === 'on') {
              add('warning', d.line, 'server_tokens is on',
                'The exact nginx version is advertised in response headers and error pages, which hands attackers a version to match exploits against.',
                'Set server_tokens off.');
            } else if (d.args.length && d.args[0].toLowerCase() === 'off') {
              add('info', d.line, 'server_tokens is off', 'Version disclosure is disabled. No action needed.');
            }
          });
        }

        /* client_max_body_size */
        if (!allDirectives(root, 'client_max_body_size').length) {
          add('info', null, 'client_max_body_size is not set anywhere',
            'nginx\'s built-in default of 1 MB applies, so larger uploads will be rejected with 413 errors whether or not that was intended.',
            'Set client_max_body_size at the http or server level to the largest upload the site genuinely accepts.');
        }

        /* worker settings: info only */
        var wp = childDirectives(root, 'worker_processes');
        if (wp.length) {
          add('info', wp[0].line, 'worker_processes is ' + (wp[0].args[0] || '(no value)') + ' — reported for information only', 'This auditor does not judge worker counts; sizing depends on the host.');
        } else {
          add('info', null, 'worker_processes does not appear in the pasted text', 'It may live in a part of nginx.conf that was not pasted. Reported for information only.');
        }
        var eventsBlocks = allBlocks(root, 'events');
        var wcFound = null;
        eventsBlocks.forEach(function (eb) {
          var wc = childDirectives(eb, 'worker_connections');
          if (wc.length) wcFound = wc[0];
        });
        if (wcFound) {
          add('info', wcFound.line, 'worker_connections is ' + (wcFound.args[0] || '(no value)') + ' — reported for information only', 'This auditor does not judge connection limits; capacity depends on the host and its file-descriptor limits.');
        } else {
          add('info', null, 'worker_connections does not appear in the pasted text', 'Reported for information only.');
        }

        /* Per-server-block checks */
        servers.forEach(function (sb, idx) {
          var listens = listenInfo(sb);
          var label = 'server block #' + (idx + 1) + ' (line ' + sb.line + ')';
          var isSsl = listens.some(function (li) { return li.ssl || li.port === '443'; });
          var serverNames = childDirectives(sb, 'server_name');

          /* Port 80 with no HTTPS redirect */
          listens.forEach(function (li) {
            if (li.port === '80' && !li.ssl) {
              if (!blockHasHttpsRedirect(sb) && (anySslAnywhere || serverNames.length)) {
                add('warning', li.directive.line,
                  'Port 80 served with no redirect to HTTPS in ' + label,
                  'This block answers plain-HTTP requests and never sends visitors to the HTTPS version, so credentials and content cross the network unencrypted.',
                  'Fix shape, in words: inside this same server block, replace the content-serving locations with a single return directive that answers every request with a permanent redirect (status 301) to the https scheme, keeping the requested host and the original request URI — then nothing is served over plain HTTP from this block at all.');
              }
            }
          });

          if (isSsl) {
            /* ssl_protocols missing entirely */
            if (!lookupChain(sb, 'ssl_protocols')) {
              add('warning', sb.line,
                'No ssl_protocols set for the SSL listener in ' + label,
                'Neither this block nor the http level above it names the allowed TLS versions, so whatever the build\'s compiled default happens to be is what runs — that default is not visible in the pasted text.',
                'Set ssl_protocols explicitly to TLSv1.2 and TLSv1.3 in the server block or at the http level.');
            }
            /* certificate / key pairing */
            var cert = lookupChain(sb, 'ssl_certificate');
            var key = lookupChain(sb, 'ssl_certificate_key');
            if (cert && !key) {
              add('blocker', cert.directive.line,
                'ssl_certificate without ssl_certificate_key in ' + label,
                'A certificate is configured but no private key is configured in this block or inherited from the http level. nginx cannot load this SSL configuration.',
                'Add the ssl_certificate_key directive pointing at the private key that matches the certificate.');
            } else if (key && !cert) {
              add('blocker', key.directive.line,
                'ssl_certificate_key without ssl_certificate in ' + label,
                'A private key is configured but no certificate is configured in this block or inherited from the http level. nginx cannot load this SSL configuration.',
                'Add the ssl_certificate directive pointing at the certificate (full chain) that matches the key.');
            }
          }

          /* Security headers */
          function headerCheck(name, finder, sslOnly) {
            var presentHere = false;
            if (name === 'frame') {
              presentHere = !!childDirectives(sb, 'add_header').filter(function (d) {
                if (!d.args.length) return false;
                var h = d.args[0].toLowerCase();
                return h === 'x-frame-options' || (h === 'content-security-policy' && d.args.join(' ').toLowerCase().indexOf('frame-ancestors') !== -1);
              }).length;
            } else {
              presentHere = !!childDirectives(sb, 'add_header').filter(function (d) {
                return d.args.length && d.args[0].toLowerCase() === name;
              }).length;
            }
            if (presentHere) return;
            var inherited = finder(sb);
            if (inherited && inherited.level !== sb) {
              add('info', sb.line,
                name === 'frame' ? 'Clickjacking protection is inherited, not set in ' + label : name + ' is inherited, not set in ' + label,
                'This header is set at the ' + (inherited.level.name === 'http' ? 'http' : inherited.level.name) + ' level (line ' + inherited.directive.line + ') and is inherited by this server block. Note that nginx drops inherited add_header values for any block that sets an add_header of its own, so confirm the header still reaches responses at runtime.',
                '');
            } else {
              add('warning', sb.line,
                (name === 'frame' ? 'X-Frame-Options / CSP frame-ancestors' : name) + ' is missing in ' + label,
                sslOnly
                  ? 'No ' + name + ' header is set in this block or inherited from the http level, so browsers are not told to force HTTPS on future visits.'
                  : 'No such header is set in this block or inherited from the http level.',
                name === 'x-content-type-options'
                  ? 'Add an add_header directive setting X-Content-Type-Options to "nosniff" with the "always" parameter.'
                  : name === 'frame'
                    ? 'Add an add_header directive setting X-Frame-Options (for example "SAMEORIGIN" or "DENY"), or a Content-Security-Policy header carrying a frame-ancestors directive.'
                    : 'Add an add_header directive setting Strict-Transport-Security with a max-age of at least one year, with the "always" parameter.');
            }
          }
          headerCheck('x-content-type-options', function (n) { return chainHasHeader(n, 'x-content-type-options'); }, false);
          headerCheck('frame', chainHasFrameProtection, false);
          if (isSsl) headerCheck('strict-transport-security', function (n) { return chainHasHeader(n, 'strict-transport-security'); }, true);

          /* Proxy checks */
          var proxyHolders = [];
          if (childDirectives(sb, 'proxy_pass').length) proxyHolders.push(sb);
          allBlocks(sb, 'location').forEach(function (loc) {
            if (childDirectives(loc, 'proxy_pass').length) proxyHolders.push(loc);
          });
          proxyHolders.forEach(function (holder) {
            childDirectives(holder, 'proxy_pass').forEach(function (pp) {
              var upstream = pp.args.length ? pp.args[0] : '';
              if (isSsl && upstream.toLowerCase().indexOf('http://') === 0) {
                add('warning', pp.line,
                  'HTTPS front door, plain-HTTP upstream in ' + label,
                  'This SSL server block proxies to "' + upstream + '" over unencrypted HTTP, so traffic that arrived encrypted leaves nginx in the clear on the back end.',
                  'Point proxy_pass at an https:// upstream if the back end supports it; if the back end is loopback-only by design, note that decision alongside the config.');
              }
              ['Host', 'X-Forwarded-For'].forEach(function (h) {
                var cur = holder, found = false;
                while (cur && !found) {
                  found = childDirectives(cur, 'proxy_set_header').some(function (d) {
                    return d.args.length && d.args[0].toLowerCase() === h.toLowerCase();
                  });
                  cur = cur.parent;
                }
                if (!found) {
                  add('warning', pp.line,
                    'proxy_set_header ' + h + ' is missing for this proxy_pass',
                    h === 'Host'
                      ? 'The back end will see nginx\'s default Host value instead of the visitor\'s original host, which breaks virtual-host routing and absolute URL generation in many apps.'
                      : 'The back end cannot see the real client address chain, so logs, rate limits, and access rules at the app see only nginx itself.',
                    'Add a proxy_set_header directive for ' + h + ' in the same location block (or the enclosing server block) as the proxy_pass.');
                }
              });
            });
          });

          /* Dotfiles */
          if (lookupChain(sb, 'root')) {
            var locations = allBlocks(sb, 'location');
            var dotLocations = locations.filter(function (loc) {
              return loc.args.join(' ').indexOf('\\.') !== -1;
            });
            var denied = dotLocations.some(function (loc) {
              return childDirectives(loc, 'deny').some(function (d) {
                return d.args.length && d.args[0].toLowerCase() === 'all';
              });
            });
            if (!dotLocations.length) {
              add('warning', sb.line,
                'No dotfile protection in ' + label + ', which sets a root',
                'A document root is configured but no location block matches dotfiles (paths like /.git/config or /.env), so anything sensitive that lands in the root under a dot-name is served to anyone who asks.',
                'Add a location block matching paths that begin with "/." and deny all access inside it.');
            } else if (!denied) {
              add('warning', dotLocations[0].line,
                'Dotfile location in ' + label + ' does not deny access',
                'A location block matches dotfiles but contains no "deny all", so dot-named files under the root can still be served.',
                'Add "deny all;" inside the dotfile location block.');
            }
          }
        });

        var counts = { blocker: 0, warning: 0, info: 0, notparsed: 0 };
        findings.forEach(function (f) { counts[f.sev]++; });

        var verdict, verdictClass, verdictWhy;
        if (counts.blocker > 0 || counts.notparsed > 0) {
          verdict = 'DO NOT DEPLOY';
          verdictClass = 'danger';
          verdictWhy = (counts.blocker ? counts.blocker + ' blocker(s)' : '') +
            (counts.blocker && counts.notparsed ? ' and ' : '') +
            (counts.notparsed ? counts.notparsed + ' unparsed line(s)' : '') +
            ' must be resolved first. Blockers are faults that break loading or open a real hole; unparsed lines mean part of the config could not be checked at all.';
        } else if (counts.warning > 0) {
          verdict = 'DEPLOY WITH FIXES';
          verdictClass = 'fixes';
          verdictWhy = 'No blockers, but ' + counts.warning + ' warning(s) describe real exposure or breakage waiting to happen. Fix them, then re-run this pre-flight.';
        } else {
          verdict = 'SAFE TO DEPLOY';
          verdictClass = 'safe';
          verdictWhy = 'No blockers and no warnings under the checks this tool runs. That means no structural red flags in the pasted text — not proof the config is secure or that nginx will load it.';
        }

        return { findings: findings, counts: counts, verdict: verdict, verdictClass: verdictClass, verdictWhy: verdictWhy };
      }

      /* ---------------- Rendering ---------------- */

      var lastReport = '';

      function buildReport(result) {
        var lines = [];
        lines.push('J-Dawgs Nginx Config Pre-Flight Auditor(TM) - Pre-Flight Report');
        lines.push('Verdict: ' + result.verdict);
        lines.push('Counts: ' + result.counts.blocker + ' blocker(s), ' + result.counts.warning + ' warning(s), ' +
          result.counts.info + ' info, ' + result.counts.notparsed + ' not parsed');
        lines.push('');
        var order = [['blocker', 'BLOCKERS'], ['notparsed', 'NOT PARSED'], ['warning', 'WARNINGS'], ['info', 'INFO']];
        order.forEach(function (pair) {
          var group = result.findings.filter(function (f) { return f.sev === pair[0]; });
          if (!group.length) return;
          lines.push('--- ' + pair[1] + ' ---');
          group.forEach(function (f) {
            lines.push('[' + pair[1].replace(/S$/, '') + '] ' + (f.line ? 'Line ' + f.line + ' - ' : '') + f.title);
            if (f.detail) lines.push('    ' + f.detail);
            if (f.fix) lines.push('    Fix: ' + f.fix);
          });
          lines.push('');
        });
        lines.push('Note: SAFE TO DEPLOY means no structural red flags in the pasted text under this tool\'s checks. It is not proof a config is secure or will load. This tool does not run nginx -t and does not resolve includes or variables.');
        return lines.join('\n');
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-nginx-config-pre-flight-auditor',
  name: 'J-Dawgs Nginx Config Pre-Flight Auditor',
  description: 'Pre-flights a pasted nginx config — TLS posture, security headers with inheritance reported honestly, autoindex, duplicate default_server, proxy risks — and returns one ship verdict',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
