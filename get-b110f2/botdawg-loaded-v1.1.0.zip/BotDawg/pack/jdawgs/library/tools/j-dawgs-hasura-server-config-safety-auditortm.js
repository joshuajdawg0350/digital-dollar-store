'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Hasura Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Worked examples (fake placeholder secrets only) ---------- */
      var RISKY_LINES = [
        "# Hasura production config — risky worked example",
        "HASURA_GRAPHQL_DATABASE_URL=postgres://hasura:p@ssw0rd-db@db.internal:5432/hasura",
        "HASURA_GRAPHQL_METADATA_DATABASE_URL=postgres://hasura:p@ssw0rd-db@db.internal:5432/hasura_meta",
        "HASURA_GRAPHQL_ADMIN_SECRET=letmein123",
        "HASURA_GRAPHQL_JWT_SECRET={\"type\":\"HS256\",\"key\":\"shortjwtkey\"}",
        "HASURA_GRAPHQL_ENABLE_CONSOLE=true",
        "HASURA_GRAPHQL_DEV_MODE=true",
        "HASURA_GRAPHQL_CORS_DOMAIN=*",
        "HASURA_GRAPHQL_WS_READ_COOKIE=true",
        "HASURA_GRAPHQL_UNAUTHORIZED_ROLE=public",
        "HASURA_GRAPHQL_ENABLED_LOG_TYPES=startup,http-log,websocket-log,query-log"
      ];
      var RISKY = RISKY_LINES.join("\n");

      var HARDENED_LINES = [
        "# Hasura production config — hardened worked example",
        "HASURA_GRAPHQL_DATABASE_URL=postgres://hasura:${DB_PASSWORD}@db.internal:5432/hasura?sslmode=require",
        "HASURA_GRAPHQL_METADATA_DATABASE_URL=postgres://hasura:${DB_PASSWORD}@db.internal:5432/hasura_meta?sslmode=require",
        "HASURA_GRAPHQL_ADMIN_SECRET=${HASURA_ADMIN_SECRET}",
        "HASURA_GRAPHQL_JWT_SECRET={\"type\":\"HS256\",\"key\":\"${JWT_SIGNING_KEY}\"}",
        "HASURA_GRAPHQL_ENABLE_CONSOLE=false",
        "HASURA_GRAPHQL_DEV_MODE=false",
        "HASURA_GRAPHQL_CORS_DOMAIN=https://app.example.com,https://admin.example.com",
        "HASURA_GRAPHQL_WS_READ_COOKIE=false",
        "HASURA_GRAPHQL_ENABLED_LOG_TYPES=startup,http-log,websocket-log"
      ];
      var HARDENED = HARDENED_LINES.join("\n");

      /* Planted values in the risky example — used by the self-test to prove
         they never leak into any output. Never rendered anywhere else. */
      var PLANTED = ["p@ssw0rd-db", "letmein123", "shortjwtkey"];

      var KNOWN_WEAK = ["secret", "admin", "adminsecret", "password", "changeme",
        "letmein", "hasura", "mysecret", "test", "demo", "example", "12345678",
        "supersecret", "myadminsecretkey", "your-admin-secret"];

      var RECOGNIZED = [
        "HASURA_GRAPHQL_ADMIN_SECRET",
        "HASURA_GRAPHQL_JWT_SECRET",
        "HASURA_GRAPHQL_DATABASE_URL",
        "HASURA_GRAPHQL_METADATA_DATABASE_URL",
        "HASURA_GRAPHQL_ENABLE_CONSOLE",
        "HASURA_GRAPHQL_DEV_MODE",
        "HASURA_GRAPHQL_CORS_DOMAIN",
        "HASURA_GRAPHQL_WS_READ_COOKIE",
        "HASURA_GRAPHQL_UNAUTHORIZED_ROLE",
        "HASURA_GRAPHQL_ENABLED_LOG_TYPES"
      ];

      function isEnvRef(v) { return /^\$\{[A-Za-z_][A-Za-z0-9_]*\}$/.test(v) || /^\$[A-Za-z_][A-Za-z0-9_]*$/.test(v); }
      function containsEnvRef(v) { return /\$\{[^}]+\}/.test(v); }
      function stripQuotes(v) {
        if (v.length >= 2 && ((v.charAt(0) === '"' && v.charAt(v.length - 1) === '"') || (v.charAt(0) === "'" && v.charAt(v.length - 1) === "'"))) {
          return v.slice(1, -1);
        }
        return v;
      }
      function truthy(v) { return /^(true|1|yes|on)$/i.test(v); }
      function falsy(v) { return /^(false|0|no|off)$/i.test(v); }

      /* Parse pasted text into entries: { key, value, line }.
         Handles KEY=value, KEY: value, and "- KEY=value" compose list items.
         Values are kept in memory for checks only; findings never carry them. */
      function parseConfig(text) {
        var entries = [];
        var lines = String(text || "").split(/\r?\n/);
        for (var i = 0; i < lines.length; i++) {
          var raw = lines[i];
          var t = raw.replace(/^\s+/, "").replace(/^-\s+/, "");
          if (!t || t.charAt(0) === "#") continue;
          var m = t.match(/^([A-Za-z_][A-Za-z0-9_]*)\s*[:=]\s*(.*)$/);
          if (!m) continue;
          var key = m[1].toUpperCase();
          var value = stripQuotes(m[2].replace(/\s+#.*$/, "").trim());
          entries.push({ key: key, value: value, line: i + 1 });
        }
        return entries;
      }

      function auditConfig(text, target) {
        var entries = parseConfig(text);
        var byKey = {};
        entries.forEach(function (e) { byKey[e.key] = e; });
        var recognizedCount = RECOGNIZED.filter(function (k) { return byKey[k]; }).length;
        var findings = [];
        function add(sev, key, line, len, title, detail, fix) {
          findings.push({ severity: sev, key: key, line: line, valueLength: len, title: title, detail: detail, fix: fix });
        }
        var prod = (target === "production");
        var staging = (target === "staging");

        var admin = byKey["HASURA_GRAPHQL_ADMIN_SECRET"];
        var jwt = byKey["HASURA_GRAPHQL_JWT_SECRET"];

        /* --- Admin secret --- */
        if (!admin && !jwt) {
          add("critical", "HASURA_GRAPHQL_ADMIN_SECRET", null, null,
            "No admin secret and no JWT secret configured",
            "With neither an admin secret nor a JWT secret set, the engine has no server-side credential protecting admin and metadata operations.",
            "Set a long random HASURA_GRAPHQL_ADMIN_SECRET (32+ characters) and/or a proper HASURA_GRAPHQL_JWT_SECRET before exposing the server.");
        } else if (!admin && jwt) {
          add("medium", "HASURA_GRAPHQL_ADMIN_SECRET", null, null,
            "No admin secret set (JWT auth only)",
            "JWT-only setups can be valid, but without an admin secret there is no break-glass credential for metadata operations, and a misconfigured JWT secret leaves the API open.",
            "Set a long random admin secret as a fallback credential, stored in your secret manager.");
        }
        if (admin) {
          var av = admin.value;
          if (isEnvRef(av)) {
            add("info", "HASURA_GRAPHQL_ADMIN_SECRET", admin.line, null,
              "Admin secret supplied by environment reference",
              "The value is an environment reference, so no pasted secret was graded. Its strength depends on the referenced variable.",
              "Confirm the referenced variable holds a random value of 32+ characters in your deployment environment.");
          } else if (KNOWN_WEAK.indexOf(av.toLowerCase()) !== -1 || av.length < 12) {
            add("critical", "HASURA_GRAPHQL_ADMIN_SECRET", admin.line, av.length,
              "Admin secret is short or a well-known example value",
              "The admin secret on this line is only " + av.length + " characters long. The admin secret grants full control of the engine, its metadata, and every table it can reach — a guessable one is a full compromise.",
              "Replace it with a randomly generated secret of at least 32 characters, delivered through your secret manager.");
          } else if (av.length < 32) {
            add("high", "HASURA_GRAPHQL_ADMIN_SECRET", admin.line, av.length,
              "Admin secret is shorter than 32 characters",
              "The admin secret on this line is " + av.length + " characters long. It is the master key to the whole GraphQL engine.",
              "Rotate to a randomly generated secret of at least 32 characters.");
          }
        }

        /* --- JWT secret --- */
        if (jwt) {
          var jv = jwt.value;
          var parsed = null;
          try { parsed = JSON.parse(jv); } catch (e) { parsed = null; }
          if (!parsed) {
            add("high", "HASURA_GRAPHQL_JWT_SECRET", jwt.line, jv.length,
              "JWT secret is not valid JSON",
              "Hasura expects the JWT secret as a JSON object with a type and key (or jwk_url). A value that does not parse (length " + jv.length + ") will fail or be ignored depending on version.",
              "Use the documented JSON shape, e.g. {\"type\":\"HS256\",\"key\":\"…\"} with the key supplied from your secret manager.");
          } else {
            if (!parsed.type && !parsed.jwk_url) {
              add("high", "HASURA_GRAPHQL_JWT_SECRET", jwt.line, null,
                "JWT secret JSON has no type or jwk_url",
                "Without a signing type or a jwk_url, Hasura cannot verify tokens as documented.",
                "Set \"type\" (e.g. HS256 or RS256) plus \"key\", or point \"jwk_url\" at your identity provider.");
            }
            if (typeof parsed.key === "string") {
              if (isEnvRef(parsed.key)) {
                add("info", "HASURA_GRAPHQL_JWT_SECRET", jwt.line, null,
                  "JWT signing key supplied by environment reference",
                  "The signing key is an environment reference, so no pasted key was graded.",
                  "Confirm the referenced key is at least 32 characters for HS256 in your deployment environment.");
              } else if (parsed.key.length < 32) {
                add("high", "HASURA_GRAPHQL_JWT_SECRET", jwt.line, parsed.key.length,
                  "JWT signing key is shorter than 32 characters",
                  "The signing key inside the JWT secret on this line is " + parsed.key.length + " characters long. A short HS256 key can be brute-forced offline from any captured token, letting an attacker mint admin claims.",
                  "Use a randomly generated key of at least 32 characters (256 bits) for HS256, or switch to RS256 with a proper key pair.");
              }
            }
          }
        }

        /* --- Database URLs --- */
        ["HASURA_GRAPHQL_DATABASE_URL", "HASURA_GRAPHQL_METADATA_DATABASE_URL"].forEach(function (key) {
          var e = byKey[key];
          if (!e) {
            if (key === "HASURA_GRAPHQL_DATABASE_URL") {
              add("high", key, null, null,
                "No database URL configured",
                "The engine has no database to connect to; a config graded for deployment should name its database explicitly.",
                "Set HASURA_GRAPHQL_DATABASE_URL for the target environment.");
            }
            return;
          }
          var v = e.value;
          var m = v.match(/^[a-z][a-z0-9+.-]*:\/\/([^:@/]+):([^@/]+)@/i);
          if (m && !containsEnvRef(m[2])) {
            add("high", key, e.line, m[2].length,
              "Database password embedded in plaintext in the URL",
              "The URL on this line embeds a plaintext database password (" + m[2].length + " characters). Anyone who can read this config file — a repo, a screenshot, a log — owns the database.",
              "Move the password into your secret manager and inject it at deploy time, or build the URL from separate variables.");
          }
          if (!/sslmode=require/i.test(v) && !containsEnvRef(v)) {
            add("medium", key, e.line, null,
              "Database connection does not require TLS",
              "The URL on this line sets no sslmode=require, so the connection may fall back to plaintext depending on the driver and network.",
              "Append ?sslmode=require (or your provider's TLS setting) for any database reached over a network.");
          }
        });

        /* --- Console --- */
        var consoleE = byKey["HASURA_GRAPHQL_ENABLE_CONSOLE"];
        if (consoleE && truthy(consoleE.value)) {
          add(prod ? "high" : "low", "HASURA_GRAPHQL_ENABLE_CONSOLE", consoleE.line, null,
            "GraphQL console enabled" + (prod ? " in production" : ""),
            "The web console exposes schema exploration and a query window to anyone who can reach the server URL, behind only the admin secret.",
            prod ? "Set HASURA_GRAPHQL_ENABLE_CONSOLE=false in production; use a local instance for console work."
                 : "Fine for local work — make sure it is false before this config reaches production.");
        }

        /* --- Dev mode --- */
        var devE = byKey["HASURA_GRAPHQL_DEV_MODE"];
        if (devE && truthy(devE.value)) {
          add(prod ? "critical" : (staging ? "high" : "low"), "HASURA_GRAPHQL_DEV_MODE", devE.line, null,
            "Dev mode enabled" + (prod ? " in production" : ""),
            "Dev mode returns detailed internal errors, relaxes several checks, and is documented by Hasura as unsafe outside local development.",
            "Set HASURA_GRAPHQL_DEV_MODE=false outside local development.");
        }

        /* --- CORS --- */
        var corsE = byKey["HASURA_GRAPHQL_CORS_DOMAIN"];
        if (!corsE) {
          add("medium", "HASURA_GRAPHQL_CORS_DOMAIN", null, null,
            "CORS domain not set",
            "Without an explicit CORS domain list, you are relying on engine defaults for which websites may call your API from a browser.",
            "Set HASURA_GRAPHQL_CORS_DOMAIN to the explicit list of your own front-end origins.");
        } else {
          var domains = corsE.value.split(",").map(function (s) { return s.trim(); });
          if (domains.indexOf("*") !== -1) {
            add(prod ? "high" : "medium", "HASURA_GRAPHQL_CORS_DOMAIN", corsE.line, null,
              "Wildcard CORS domain",
              "A CORS domain of * lets any website on the internet make browser calls to your API, riding on any credentials or tokens the visitor's browser will send.",
              "Replace * with the explicit origins of your own applications.");
          }
        }

        /* --- WS read cookie --- */
        var wsE = byKey["HASURA_GRAPHQL_WS_READ_COOKIE"];
        if (wsE && truthy(wsE.value)) {
          add("medium", "HASURA_GRAPHQL_WS_READ_COOKIE", wsE.line, null,
            "Websocket cookie reading enabled",
            "With WS_READ_COOKIE on, Hasura reads auth cookies during websocket connections, which widens the cross-site request forgery surface for subscriptions.",
            "Leave HASURA_GRAPHQL_WS_READ_COOKIE unset or false unless your auth design specifically requires cookie-based websocket auth.");
        }

        /* --- Unauthenticated role --- */
        var unauthE = byKey["HASURA_GRAPHQL_UNAUTHORIZED_ROLE"];
        if (unauthE && unauthE.value) {
          add(prod ? "high" : "medium", "HASURA_GRAPHQL_UNAUTHORIZED_ROLE", unauthE.line, unauthE.value.length,
            "Unauthenticated role is set",
            "The role named on this line (" + unauthE.value.length + " characters; the name itself is not printed) can be used by anyone on the internet with no login, for every table and action that role can access.",
            "Remove the unauthorized role for production, or audit that role's permissions down to exactly the public data you intend to publish.");
        }

        /* --- Log types --- */
        var logE = byKey["HASURA_GRAPHQL_ENABLED_LOG_TYPES"];
        if (logE && /(^|,)\s*query-log\s*(,|$)/i.test(logE.value)) {
          add("low", "HASURA_GRAPHQL_ENABLED_LOG_TYPES", logE.line, null,
            "Query logging enabled",
            "The query-log type can record full queries and variables — including auth tokens and personal data — into log files that are often shipped to third-party log services.",
            "Drop query-log from the production log types unless you have a specific, reviewed need for it.");
        }

        /* --- Verdict --- */
        var verdict, why;
        var hasCrit = findings.some(function (f) { return f.severity === "critical"; });
        var hasHighMed = findings.some(function (f) { return f.severity === "high" || f.severity === "medium"; });
        if (recognizedCount < 2) {
          verdict = "NOT ENOUGH TO GRADE";
          why = "Only " + recognizedCount + " recognized Hasura server setting" + (recognizedCount === 1 ? " was" : "s were") + " found in the paste. Paste the engine's environment/config lines — at minimum the database URL and an admin or JWT secret — to get a deploy verdict.";
        } else if (hasCrit) {
          verdict = "DO NOT DEPLOY";
          why = "At least one critical finding would leave the engine or its database exposed. Fix every critical and high finding before this config goes anywhere near production.";
        } else if (hasHighMed) {
          verdict = "DEPLOY WITH FIXES";
          why = "No critical blockers, but one or more high or medium findings should be fixed before this config is deployed.";
        } else {
          verdict = "SAFE TO DEPLOY";
          why = findings.length
            ? "No critical, high, or medium findings. The remaining notes below are informational."
            : "No findings. The pasted settings pass every check in this auditor.";
        }
        return { verdict: verdict, why: why, findings: findings, recognizedCount: recognizedCount, entries: entries.length };
      }

      function countsOf(findings) {
        var c = { critical: 0, high: 0, medium: 0, low: 0, info: 0 };
        findings.forEach(function (f) { c[f.severity]++; });
        return c;
      }

      function reportText(result, target) {
        var c = countsOf(result.findings);
        var out = [];
        out.push("J-Dawgs Hasura Server Config Safety Auditor — report");
        out.push("Target environment: " + target);
        out.push("Verdict: " + result.verdict);
        out.push("Findings: " + result.findings.length + " (critical " + c.critical + ", high " + c.high + ", medium " + c.medium + ", low " + c.low + ", info " + c.info + ")");
        out.push("Secret values are never included in this report; secrets are named by key, line, and length only.");
        result.findings.forEach(function (f, i) {
          out.push("");
          out.push((i + 1) + ". [" + f.severity.toUpperCase() + "] " + f.title);
          out.push("   Key: " + f.key + (f.line ? " — line " + f.line : " — not present in paste") + (f.valueLength != null ? " — value length " + f.valueLength : ""));
          out.push("   " + f.detail);
          out.push("   Fix: " + f.fix);
        });
        return out.join("\n");
      }

      function reportJSON(result, target) {
        return JSON.stringify({
          tool: "J-Dawgs Hasura Server Config Safety Auditor",
          targetEnvironment: target,
          verdict: result.verdict,
          recognizedSettings: result.recognizedCount,
          counts: countsOf(result.findings),
          findings: result.findings.map(function (f) {
            return { severity: f.severity, key: f.key, line: f.line, valueLength: f.valueLength, title: f.title, detail: f.detail, fix: f.fix };
          })
        }, null, 2);
      }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-hasura-server-config-safety-auditortm',
  name: 'J-Dawgs Hasura Server Config Safety Auditor',
  description: 'Grades a pasted Hasura server config offline into one deploy verdict (SAFE TO DEPLOY / DEPLOY WITH FIXES / DO NOT DEPLOY / NOT ENOUGH TO GRADE) — secrets reported by key name, line, and length only, never the secret value.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
