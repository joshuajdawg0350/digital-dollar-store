'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Pi-hole Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var RISKY = [
        "# Pi-hole v6 / FTL config — worked example: a rushed install",
        "# Do not deploy this as-is.",
        "",
        "[dns]",
        '  upstreams = [ "8.8.8.8", "8.8.4.4" ]',
        "  dnssec = false",
        '  interface = ""',
        '  listeningMode = "all"',
        "",
        "[dns.blocking]",
        "  active = true",
        "",
        "[dhcp]",
        "  active = true",
        '  start = "192.168.1.100"',
        '  end = "192.168.1.200"',
        '  router = "192.168.1.1"',
        "",
        "[webserver]",
        '  domain = "pi.hole"',
        '  port = "80"',
        "",
        "[webserver.api]",
        '  password = "admin"',
        '  appPassword = ""',
        "",
        "[misc]",
        "  privacylevel = 0",
        "",
        "[debug]",
        "  all = true"
      ].join("\n");

      var HARDENED = [
        "# Pi-hole v6 / FTL config — worked example: hardened before deploy",
        "",
        "[dns]",
        '  upstreams = [ "1.1.1.1#853", "9.9.9.9#853" ]',
        "  dnssec = true",
        '  interface = "eth0"',
        '  listeningMode = "bind"',
        "",
        "[dns.blocking]",
        "  active = true",
        "",
        "[dhcp]",
        "  active = false",
        "",
        "[webserver]",
        '  domain = "pi.hole"',
        '  port = "443s"',
        "",
        "[webserver.tls]",
        '  cert = "/etc/pihole/tls.pem"',
        "",
        "[webserver.api]",
        '  password = "$BALLOON-SHA256$v=1$s=1024,t=8,p=1$c2FsdHNhbHRzYWx0$0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"',
        '  appPassword = "$BALLOON-SHA256$v=1$s=1024,t=8,p=1$YXBwc2FsdGFwcHNhbHQ$fedcba9876543210fedcba9876543210fedcba9876543210fedcba9876543210"',
        "",
        "[misc]",
        "  privacylevel = 3",
        "",
        "[debug]",
        "  all = false"
      ].join("\n");

      var SETUPVARS_MAP = {
        "webpassword": "webserver.api.password",
        "dhcp_active": "dhcp.active",
        "pihole_interface": "dns.interface"
      };
      var RECOGNIZED_PREFIXES = ["dns.", "webserver.", "dhcp.", "misc.", "resolver.", "database.", "files.", "debug."];
      var EXAMPLE_SECRETS = ["password","admin","pihole","changeme","letmein","raspberry","12345678","admin123","password1","default","secret","pi-hole","123456789"];

      function extractScalar(v){
        v = v.trim();
        if (v.charAt(0) === '"'){
          var end = v.indexOf('"', 1);
          return end > 0 ? v.slice(1, end) : v.slice(1);
        }
        if (v.charAt(0) === "'"){
          var e2 = v.indexOf("'", 1);
          return e2 > 0 ? v.slice(1, e2) : v.slice(1);
        }
        var cut = v.length;
        var h = v.indexOf(" #"); if (h >= 0 && h < cut) cut = h;
        var s = v.indexOf(" ;"); if (s >= 0 && s < cut) cut = s;
        v = v.slice(0, cut).trim();
        if (v.charAt(v.length - 1) === ",") v = v.slice(0, -1).trim();
        return v;
      }

      function extractArray(v){
        var items = [];
        var re = /"([^"]*)"|'([^']*)'|([^\s,\[\]]+)/g, m;
        var inner = v;
        var open = inner.indexOf("["), close = inner.lastIndexOf("]");
        if (open >= 0 && close > open) inner = inner.slice(open + 1, close);
        while ((m = re.exec(inner)) !== null){
          items.push(m[1] !== undefined ? m[1] : (m[2] !== undefined ? m[2] : m[3]));
        }
        return items;
      }

      function parseConfig(text){
        var lines = text.split(/\r?\n/);
        var entries = [];
        var section = "";
        var i = 0;
        while (i < lines.length){
          var lineNo = i + 1;
          var t = lines[i].trim();
          i++;
          if (!t || t.charAt(0) === "#" || t.charAt(0) === ";") continue;
          var sec = t.match(/^\[([A-Za-z0-9_.-]+)\]\s*(#.*)?$/);
          if (sec){ section = sec[1].toLowerCase(); continue; }
          var eq = t.indexOf("=");
          if (eq < 0) continue;
          var keyPart = t.slice(0, eq).trim();
          var valPart = t.slice(eq + 1).trim();
          var guard = 0;
          while (valPart.charAt(0) === "[" && valPart.indexOf("]") < 0 && i < lines.length && guard < 40){
            valPart += " " + lines[i].trim(); i++; guard++;
          }
          var isArray = valPart.charAt(0) === "[";
          var value = isArray ? extractArray(valPart) : extractScalar(valPart);
          var lowerKey = keyPart.toLowerCase();
          var fullKey;
          if (lowerKey.indexOf(".") >= 0) fullKey = lowerKey;
          else if (section) fullKey = section + "." + lowerKey;
          else if (SETUPVARS_MAP[lowerKey]) fullKey = SETUPVARS_MAP[lowerKey];
          else fullKey = lowerKey;
          entries.push({ key: fullKey, rawKey: keyPart, value: value, isArray: isArray, line: lineNo });
        }
        return entries;
      }

      function truthy(v){
        if (Array.isArray(v)) return v.length > 0;
        var s = String(v).toLowerCase();
        return s === "true" || s === "yes" || s === "1" || s === "on";
      }
      function falsy(v){
        var s = String(v).toLowerCase();
        return s === "false" || s === "no" || s === "0" || s === "off";
      }
      function get(entries, key){
        for (var i = 0; i < entries.length; i++) if (entries[i].key === key) return entries[i];
        return null;
      }
      function isRecognized(key){
        for (var i = 0; i < RECOGNIZED_PREFIXES.length; i++) if (key.indexOf(RECOGNIZED_PREFIXES[i]) === 0) return true;
        return false;
      }
      function isSecretKey(key){
        var last = key.split(".").pop();
        return last === "password" || last === "apppassword" || last === "app_password" ||
               last === "pwhash" || last === "webpassword" || last === "totp_secret" ||
               key.indexOf("password") >= 0;
      }
      function looksHashed(v){
        if (/^\$[A-Za-z0-9-]+\$/.test(v)) return true;         // balloon / argon style $…$
        if (/^[a-fA-F0-9]{64}$/.test(v)) return true;          // sha256 hex (setupVars style)
        if (/^[a-fA-F0-9]{32,}$/.test(v) && v.length >= 40) return true;
        return false;
      }

      function audit(text){
        var findings = [];
        function add(sev, line, key, title, detail, fix){
          findings.push({ severity: sev, line: (line == null ? null : line), key: key || "", title: title, detail: detail, fix: fix || "" });
        }

        var entries = parseConfig(text);
        var recognized = 0;
        entries.forEach(function(e){ if (isRecognized(e.key)) recognized++; });

        if (!text.trim()){
          add("info", null, "", "Nothing to grade", "The paste box is empty. Paste a pihole.toml / FTL config, or load one of the worked examples.", "");
          return { verdict: "NOT ENOUGH TO GRADE", findings: findings, recognized: 0, total: 0 };
        }
        if (recognized < 3){
          add("info", null, "", "Too few Pi-hole keys to grade",
            "Only " + recognized + " recognized Pi-hole key(s) found in the pasted text. A gradeable paste normally includes keys from the dns, webserver, dhcp, and misc families.",
            "Paste the full pihole.toml (or the FTL / setupVars lines that set web, DNS, DHCP, and privacy behavior).");
          return { verdict: "NOT ENOUGH TO GRADE", findings: findings, recognized: recognized, total: entries.length };
        }

        var adminExposed = false;   // plain http or all-interfaces binding
        var secretWeak = false;

        /* ---------- Passwords (values never rendered) ---------- */
        var pwEntries = entries.filter(function(e){ return isSecretKey(e.key); });
        if (pwEntries.length === 0){
          secretWeak = true;
          add("critical", null, "webserver.api.password", "No admin / API password entry in the pasted config",
            "No password or app-password key was found, so the web admin and API may be running with no login protection at all.",
            "Set a strong webserver.api password (and an app password) in Pi-hole before this host serves anyone.");
        }
        pwEntries.forEach(function(e){
          var v = Array.isArray(e.value) ? "" : String(e.value);
          var len = v.length;
          var where = "Key " + e.key + ", line " + e.line + ", value length " + len + ".";
          if (len === 0){
            secretWeak = true;
            add("critical", e.line, e.key, "Empty password value", where + " An empty entry means no password protection on that login path.",
              "Set a long, unique password for this entry.");
          } else if (EXAMPLE_SECRETS.indexOf(v.toLowerCase()) >= 0 || v.toLowerCase().indexOf("example") >= 0){
            secretWeak = true;
            add("critical", e.line, e.key, "Example / default password value", where + " The value matches a known example or default-style password — anyone who has read the docs can guess it.",
              "Replace it with a long, unique password that appears in no example or guide.");
          } else if (looksHashed(v)){
            add("pass", e.line, e.key, "Stored password looks like a hash",
              where + " The length and format are consistent with a stored password hash. This tool does not verify hashes, so the underlying password strength is unproven.",
              "");
          } else if (len < 12){
            secretWeak = true;
            add("high", e.line, e.key, "Short password value", where + " Under 12 characters is short for an admin credential, especially on a web-facing login.",
              "Use at least 16 characters, unique to this Pi-hole.");
          } else if (len < 20){
            add("low", e.line, e.key, "Moderate-length password value", where + " Acceptable length, but longer and unique is better for an admin login.",
              "Consider 20+ characters, unique to this Pi-hole.");
          } else {
            add("pass", e.line, e.key, "Password length looks adequate", where + " Length alone does not prove strength — uniqueness matters just as much.", "");
          }
        });

        /* ---------- Web admin: webserver.port ---------- */
        var portEntry = get(entries, "webserver.port");
        if (!portEntry){
          add("medium", null, "webserver.port", "Web admin port not in the pasted config",
            "Without webserver.port, this audit cannot confirm how the admin interface is exposed. Do not assume the default is safe for your network.",
            "Include the webserver.port line in the paste, and confirm the admin UI is not reachable from untrusted networks.");
        } else {
          var spec = Array.isArray(portEntry.value) ? portEntry.value.join(",") : String(portEntry.value);
          var tokens = spec.split(",").map(function(s){ return s.trim(); }).filter(Boolean);
          var hasTls = false, hasPlain = false;
          tokens.forEach(function(tok){
            var m = tok.match(/^(?:(\[[^\]]+\]|[A-Za-z0-9.-]+):)?(\d+)([a-z]*)$/i);
            if (!m) return;
            var host = m[1] || "";
            var suffix = (m[3] || "").toLowerCase();
            var isTls = suffix.indexOf("s") >= 0;
            if (isTls) hasTls = true; else hasPlain = true;
            var allIfaces = !host || host === "0.0.0.0" || host === "::" || host === "[::]";
            var loopback = host === "127.0.0.1" || host === "[::1]" || host === "localhost";
            if (!isTls){
              adminExposed = true;
              add("critical", portEntry.line, "webserver.port", "Web admin served over plain HTTP",
                "Listener \"" + tok + "\" has no TLS marker, so admin logins and session cookies cross the network unencrypted.",
                "Serve the admin UI over HTTPS only (an \"s\" port such as 443s with a certificate), or restrict it to localhost / a VPN.");
            }
            if (allIfaces){
              if (!isTls) adminExposed = true;
              add(isTls ? "low" : "high", portEntry.line, "webserver.port",
                isTls ? "Web admin bound to all interfaces (TLS on)" : "Web admin bound to all interfaces",
                "Listener \"" + tok + "\" names no bind address, so the admin UI answers on every network interface of the host" + (isTls ? ". TLS protects the traffic, but the login page is still offered to every network the host touches." : ", over plain HTTP."),
                "Bind the admin UI to the LAN address or localhost, and keep it off any WAN-facing interface.");
            } else if (loopback){
              add("pass", portEntry.line, "webserver.port", "Web admin bound to localhost only",
                "Listener \"" + tok + "\" keeps the admin UI off the network entirely. Remote admin then needs SSH tunnelling or a VPN — that is the safe pattern.", "");
            }
          });
          if (hasTls){
            var cert = get(entries, "webserver.tls.cert");
            if (!cert){
              add("medium", portEntry.line, "webserver.tls.cert", "TLS port set but no certificate entry pasted",
                "A TLS (\"s\") listener is configured, but no webserver.tls.cert entry appears in the paste, so the certificate setup cannot be confirmed.",
                "Confirm a valid certificate is configured for the TLS listener, or include the webserver.tls.cert line in the paste.");
            } else {
              add("pass", cert.line, "webserver.tls.cert", "TLS certificate entry present", "A certificate path is configured for the HTTPS admin listener.", "");
            }
          }
          if (hasTls && !hasPlain){
            add("pass", portEntry.line, "webserver.port", "No plain-HTTP admin listener", "Every web listener in webserver.port carries the TLS marker.", "");
          }
        }

        /* ---------- DNS listening / open resolver ---------- */
        var modeEntry = get(entries, "dns.listeningmode");
        var ifaceEntry = get(entries, "dns.interface");
        if (modeEntry){
          var mode = String(modeEntry.value).toLowerCase();
          if (mode === "all"){
            add("critical", modeEntry.line, "dns.listeningmode", "DNS listens on all interfaces — open resolver risk",
              "listeningMode \"all\" makes Pi-hole answer DNS queries from any interface and any source that can reach it. Exposed to the internet, this host becomes an open resolver usable for DNS amplification attacks.",
              "Set listeningMode to \"bind\" or \"local\" and permit only your LAN, unless this is a deliberately managed public resolver.");
          } else if (mode === "bind" || mode === "local" || mode === "single"){
            add("pass", modeEntry.line, "dns.listeningmode", "DNS listening is restricted",
              "listeningMode \"" + mode + "\" keeps DNS answers scoped instead of open to all comers.", "");
          } else {
            add("low", modeEntry.line, "dns.listeningmode", "Unrecognized listening mode",
              "listeningMode value \"" + String(modeEntry.value) + "\" is not one of the standard FTL modes (all / bind / local / single), so the exposure could not be confirmed from the paste.", "");
          }
        } else if (ifaceEntry){
          if (String(ifaceEntry.value).trim() === ""){
            add("medium", ifaceEntry.line, "dns.interface", "DNS interface is blank",
              "dns.interface is set but empty, and no dns.listeningMode appears in the paste — the DNS binding cannot be confirmed and may fall back to broad listening.",
              "Name the LAN interface in dns.interface or set dns.listeningMode to \"bind\" / \"local\".");
          } else {
            add("pass", ifaceEntry.line, "dns.interface", "DNS bound to a named interface",
              "dns.interface names \"" + String(ifaceEntry.value) + "\", so DNS is tied to one interface rather than floating across all of them. Confirm that interface is LAN-only.", "");
          }
        } else {
          add("medium", null, "dns.listeningmode", "DNS binding not in the pasted config",
            "Neither dns.listeningMode nor dns.interface appears in the paste, so this audit cannot rule out DNS listening on all interfaces (open resolver risk).",
            "Include the dns.listeningMode / dns.interface lines in the paste and confirm DNS serves the LAN only.");
        }

        /* ---------- DHCP ---------- */
        var dhcpEntry = get(entries, "dhcp.active");
        if (dhcpEntry){
          if (truthy(dhcpEntry.value)){
            add("medium", dhcpEntry.line, "dhcp.active", "Pi-hole DHCP server is active",
              "dhcp.active is on. That is a legitimate setup only when the router's DHCP server is off — two DHCP servers on one LAN hand out conflicting leases and intermittent outages.",
              "Confirm the router's DHCP is disabled and the Pi-hole DHCP range, gateway, and lease settings are deliberate.");
          } else {
            add("pass", dhcpEntry.line, "dhcp.active", "Pi-hole DHCP is off", "Address assignment stays with the router — no DHCP conflict from this host.", "");
          }
        } else {
          add("low", null, "dhcp.active", "DHCP state not in the pasted config",
            "No dhcp.active key appears in the paste, so whether Pi-hole hands out addresses is unconfirmed.", "");
        }

        /* ---------- Upstreams + DNSSEC + encryption ---------- */
        var upEntry = get(entries, "dns.upstreams");
        var dnssecEntry = get(entries, "dns.dnssec");
        if (!upEntry || (Array.isArray(upEntry.value) && upEntry.value.length === 0) || String(upEntry.value).trim() === ""){
          add("medium", upEntry ? upEntry.line : null, "dns.upstreams", "No upstream DNS servers configured",
            "dns.upstreams is missing or empty — the Pi-hole has nowhere to forward queries that miss its cache and blocklists.",
            "Set at least one reputable upstream resolver in dns.upstreams.");
        } else {
          var ups = Array.isArray(upEntry.value) ? upEntry.value : [String(upEntry.value)];
          var encrypted = ups.some(function(u){ return /#853\b/.test(u) || /:853\b/.test(u) || u.toLowerCase().indexOf("tls") >= 0 || u.toLowerCase().indexOf("https") >= 0; });
          add("info", upEntry.line, "dns.upstreams", ups.length + " upstream resolver(s) configured",
            "Upstreams: " + ups.join(", ") + ".", "");
          if (!encrypted){
            add("low", upEntry.line, "dns.upstreams", "Upstream DNS is unencrypted",
              "No upstream entry shows an encrypted transport (no port-853 / DoT-style entry). Pi-hole forwards over plain DNS on port 53, so upstream queries are visible to and alterable by the network path unless a local DoH/DoT proxy is in front of it.",
              "If upstream privacy matters here, point Pi-hole at a local encrypted-DNS proxy (DoH/DoT) and note it alongside the config.");
          } else {
            add("pass", upEntry.line, "dns.upstreams", "Encrypted upstream transport indicated",
              "At least one upstream entry indicates an encrypted transport (port 853 / TLS).", "");
          }
        }
        if (dnssecEntry){
          if (truthy(dnssecEntry.value)){
            add("pass", dnssecEntry.line, "dns.dnssec", "DNSSEC validation is on", "Upstream answers get DNSSEC validation before they reach clients.", "");
          } else {
            add("medium", dnssecEntry.line, "dns.dnssec", "DNSSEC validation is off",
              "dns.dnssec is off, so forged or tampered upstream answers are not cryptographically checked before clients trust them.",
              "Turn dns.dnssec on and use upstreams that return DNSSEC data.");
          }
        } else {
          add("medium", null, "dns.dnssec", "DNSSEC setting not in the pasted config",
            "No dns.dnssec key appears in the paste, so DNSSEC validation cannot be confirmed.",
            "Include dns.dnssec in the paste and set it to true with DNSSEC-capable upstreams.");
        }

        /* ---------- Blocking ---------- */
        var blockEntry = get(entries, "dns.blocking.active") || get(entries, "dns.blocking");
        if (blockEntry){
          if (falsy(blockEntry.value)){
            add("medium", blockEntry.line, blockEntry.key, "DNS blocking is switched off",
              "Blocking is disabled, so this host resolves names but does not filter them — the main protection Pi-hole exists for is off.",
              "Re-enable blocking before deploy unless this is a deliberate, temporary diagnostic state.");
          } else if (truthy(blockEntry.value)){
            add("pass", blockEntry.line, blockEntry.key, "DNS blocking is on", "Filtering is active.", "");
          }
        } else {
          add("low", null, "dns.blocking", "Blocking state not in the pasted config",
            "No dns.blocking key appears in the paste, so filtering state is unconfirmed.", "");
        }

        /* ---------- Privacy level ---------- */
        var privEntry = get(entries, "misc.privacylevel");
        if (privEntry){
          var lvl = parseInt(String(privEntry.value), 10);
          if (lvl === 0){
            add("medium", privEntry.line, "misc.privacylevel", "Privacy level 0 — full query logging",
              "At privacylevel 0, Pi-hole records full query history tied to client identity. On a shared or multi-user network that is a detailed browsing log of everyone on it.",
              "Raise misc.privacylevel (2–3 is typical for a home box) unless full logs are deliberately required, and protect the log store either way.");
          } else if (lvl >= 1 && lvl <= 2){
            add("low", privEntry.line, "misc.privacylevel", "Privacy level " + lvl + " — partial logging",
              "Some query detail is still recorded at this level. Make sure everyone on the network is fine with that.", "");
          } else if (lvl >= 3){
            add("pass", privEntry.line, "misc.privacylevel", "Privacy level " + lvl + " — logging reduced",
              "Query logging is masked or off at this level.", "");
          } else {
            add("low", privEntry.line, "misc.privacylevel", "Privacy level value not recognized",
              "misc.privacylevel value \"" + String(privEntry.value) + "\" is not a standard 0–4 level.", "");
          }
        } else {
          add("low", null, "misc.privacylevel", "Privacy level not in the pasted config",
            "No misc.privacylevel key appears in the paste. FTL's default is full logging (level 0), so silence here means the most-logging option.",
            "Set misc.privacylevel deliberately and include the line in the paste.");
        }

        /* ---------- Debug flags ---------- */
        var debugOn = entries.filter(function(e){
          return (e.key.indexOf("debug.") === 0 || e.key === "debug.all") && truthy(e.value);
        });
        debugOn.forEach(function(e){
          add("medium", e.line, e.key, "Debug logging enabled",
            "Debug flag " + e.key + " is on. Debug output is verbose, lands in FTL logs, and can include query and client detail that normal operation would not record.",
            "Turn debug flags off for a production deploy; enable them only while diagnosing, then turn them back off.");
        });
        var debugEntries = entries.filter(function(e){ return e.key.indexOf("debug.") === 0; });
        if (debugEntries.length && debugOn.length === 0){
          add("pass", debugEntries[0].line, "debug.*", "Debug flags are off", "No enabled debug flags appear in the paste.", "");
        }

        /* ---------- Teleporter exposure note ---------- */
        if (adminExposed || secretWeak){
          var tpLine = portEntry ? portEntry.line : (pwEntries.length ? pwEntries[0].line : null);
          add("medium", tpLine, "webserver.api (teleporter)", "Teleporter export rides on this admin login",
            "Pi-hole's teleporter export — a full backup of settings, blocklists, and configuration — sits behind the same web admin / API login graded above. With the admin exposed or weakly protected, teleporter is exposed with it, and an exported backup is a map of the whole setup.",
            "Fix the admin exposure and password findings above, and treat any teleporter backup file as sensitive: store it offline, never in a shared folder.");
        } else {
          add("info", null, "webserver.api (teleporter)", "Teleporter note",
            "Teleporter backups contain the full Pi-hole configuration. Keep exported backups offline and treat them as sensitive files, even on a hardened install.", "");
        }

        /* ---------- Verdict ---------- */
        var counts = { critical: 0, high: 0, medium: 0, low: 0, pass: 0, info: 0 };
        findings.forEach(function(f){ counts[f.severity]++; });
        var verdict;
        if (counts.critical > 0) verdict = "DO NOT DEPLOY";
        else if (counts.high > 0 || counts.medium > 0) verdict = "DEPLOY WITH FIXES";
        else verdict = "SAFE TO DEPLOY";
        return { verdict: verdict, findings: findings, counts: counts, recognized: recognized, total: entries.length };
      }

      function buildTextReport(r){
        var out = [];
        out.push("J-Dawgs Pi-hole Server Config Safety Auditor™ — audit report");
        out.push("Verdict: " + r.verdict);
        if (r.counts){
          out.push("Findings: " + r.counts.critical + " critical, " + r.counts.high + " high, " + r.counts.medium + " medium, " + r.counts.low + " low, " + r.counts.pass + " passed, " + r.counts.info + " info");
        }
        out.push("Recognized Pi-hole keys: " + r.recognized + " of " + r.total + " pasted key(s)");
        out.push("");
        r.findings.forEach(function(f, idx){
          var loc = f.line ? "Line " + f.line : "Not in pasted config";
          out.push((idx + 1) + ". [" + f.severity.toUpperCase() + "] " + loc + (f.key ? " — " + f.key : "") + " — " + f.title);
          out.push("   " + f.detail);
          if (f.fix) out.push("   Fix: " + f.fix);
        });
        out.push("");
        out.push("Scope: this report grades pasted config text only. It does not start Pi-hole, does not connect to a server, and does not verify password hashes. Secret values were never included — secrets are reported by key name, line number, and length only.");
        return out.join("\n");
      }

      function buildJsonReport(r){
        var payload = {
          tool: "J-Dawgs Pi-hole Server Config Safety Auditor™",
          verdict: r.verdict,
          counts: r.counts || null,
          recognizedKeys: r.recognized,
          pastedKeys: r.total,
          secretsPolicy: "Secrets are reported by key name, line number, and value length only. Secret values are never included.",
          scope: "Grades pasted config text only. Does not start Pi-hole, does not connect to a server, does not verify password hashes.",
          findings: r.findings.map(function(f){
            return { severity: f.severity, line: f.line, key: f.key, title: f.title, detail: f.detail, fix: f.fix };
          })
        };
        return JSON.stringify(payload, null, 2);
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_SECRETS": (typeof EXAMPLE_SECRETS !== 'undefined' ? EXAMPLE_SECRETS : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-pi-hole-server-config-safety-auditortm',
  name: 'J-Dawgs Pi-hole Server Config Safety Auditor',
  description: 'Grades a pasted Pi-hole config — pihole.toml, FTL, or setupVars — fully offline into one deploy verdict — SAFE TO DEPLOY / DEPLOY WITH FIXES / DO NOT DEPLOY / NOT ENOUGH TO GRADE — plaintext admin and API passwords and an exposed web admin interface, with secrets shown by key name, line, and length ',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_SECRETS": __core["EXAMPLE_SECRETS"] }
};
