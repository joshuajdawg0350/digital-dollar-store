'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs MaraDNS Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var RISKY = [
          '# Risky example mararc',
          'ipv4_bind_addresses = "0.0.0.0"',
          'ipv6_bind_addresses = "::"',
          'recursive_acl = "0.0.0.0/0"',
          'admin_acl = "0.0.0.0/0"',
          'hide_disclaimer = "NO"',
          'verbose_level = "3"',
          'secret = "abc123"',
          'csv2 = {}',
          'csv2["example.com."] = "db.example.com"',
          'zone_transfer_acl = "0.0.0.0/0"',
          'upstream_servers = {}',
          'upstream_servers["."] = "8.8.8.8"',
          'maxprocs = "9999"'
        ].join("\n");

        var HARDENED = [
          '# Hardened example mararc',
          'ipv4_bind_addresses = "127.0.0.1"',
          'ipv6_bind_addresses = "::1"',
          'recursive_acl = "127.0.0.0/8"',
          'admin_acl = "127.0.0.1/32"',
          'hide_disclaimer = "YES"',
          'verbose_level = "1"',
          'secret = "kX9f2mQ7vR4tZ8wP1sN6dH3jL5bVcX0a"',
          'random_seed_file = "/etc/maradns/entropy.bin"',
          'csv2 = {}',
          'csv2["example.com."] = "db.example.com"',
          'zone_transfer_acl = "127.0.0.1/32"',
          'upstream_servers = {}',
          'upstream_servers["."] = "9.9.9.9"',
          'maxprocs = "64"',
          'maximum_cache_elements = "65536"'
        ].join("\n");

        var SECRET_KEYS = { secret: true, random_seed_file: true };
        var RANK = { CRITICAL: 0, HIGH: 1, MEDIUM: 2, "NOT PARSED": 3, LOW: 4, INFO: 5, PASS: 6, COMMENTED: 7 };

        function stripQuotes(v) {
          v = v.replace(/^\s+|\s+$/g, "");
          if (v.length >= 2 && v.charAt(0) === '"' && v.charAt(v.length - 1) === '"') {
            return v.slice(1, -1);
          }
          return v;
        }
        function tokens(v) {
          return v.split(",").map(function (s) { return s.replace(/^\s+|\s+$/g, ""); }).filter(function (s) { return s.length > 0; });
        }
        function isWideAcl(v) {
          var t = tokens(v);
          for (var i = 0; i < t.length; i++) {
            if (t[i] === "0.0.0.0/0" || t[i] === "::/0" || t[i] === "0.0.0.0" || t[i] === "::") return true;
          }
          return false;
        }
        function toInt(v) {
          var n = parseInt(v, 10);
          return isNaN(n) ? null : n;
        }

        function audit(text) {
          var findings = [];
          var secretValues = [];
          var entries = {}; // baseKey -> [{value, line, sub}]
          var lines = text.split(/\r?\n/);
          var parsed = 0, commented = 0, notParsed = 0, totalNonBlank = 0;

          function add(sev, line, key, msg) {
            findings.push({ severity: sev, line: line, key: key, message: msg });
          }
          function get(key) {
            var list = entries[key];
            return list && list.length ? list[0] : null;
          }
          function getAll(key) { return entries[key] || []; }

          lines.forEach(function (raw, idx) {
            var n = idx + 1;
            var t = raw.replace(/^\s+|\s+$/g, "");
            if (!t) return;
            totalNonBlank++;
            if (t.charAt(0) === "#") {
              commented++;
              var cm = t.slice(1).match(/([A-Za-z_][A-Za-z0-9_]*)\s*(\[[^\]]*\])?\s*=/);
              if (cm) {
                add("COMMENTED", n, cm[1], 'Commented-out setting for "' + cm[1] + '" — COMMENTED / NOT ACTIVE. It is not graded as a live setting; uncomment it and re-audit if you meant it to apply.');
              }
              return;
            }
            var m = t.match(/^([A-Za-z_][A-Za-z0-9_]*)\s*(\[[^\]]*\])?\s*=\s*(.*)$/);
            if (!m) {
              notParsed++;
              add("NOT PARSED", n, "", "This line is not a mararc key = value assignment — NOT PARSED, so nothing on it was graded. Check it by hand; a typo here means the setting you intended is not in effect.");
              return;
            }
            var key = m[1], sub = m[2] || "", val = stripQuotes(m[3]);
            parsed++;
            (entries[key] = entries[key] || []).push({ value: val, line: n, sub: sub });
            if (SECRET_KEYS[key] && val) secretValues.push(val);
          });

          if (parsed === 0) {
            return {
              verdict: "NOT ENOUGH TO GRADE",
              findings: findings,
              stats: { lines: lines.length, assignments: 0, commented: commented, notParsed: notParsed },
              secretValues: secretValues
            };
          }

          // --- Bind addresses ---
          var b4 = get("ipv4_bind_addresses");
          if (b4) {
            if (tokens(b4.value).indexOf("0.0.0.0") !== -1) {
              add("CRITICAL", b4.line, "ipv4_bind_addresses", 'ipv4_bind_addresses includes 0.0.0.0 — the server listens on every IPv4 interface this host has, including networks you may not intend to serve. Bind to specific addresses (for example 127.0.0.1 for local-only) unless public serving on all interfaces is deliberate.');
            } else {
              add("PASS", b4.line, "ipv4_bind_addresses", "ipv4_bind_addresses is set to specific address(es), not the 0.0.0.0 wildcard.");
            }
          } else {
            add("LOW", null, "ipv4_bind_addresses", "ipv4_bind_addresses is not set in this file, so the server default decides which IPv4 interfaces answer. Set it explicitly so the exposure is your choice, not a default.");
          }
          var b6 = get("ipv6_bind_addresses");
          if (b6) {
            if (tokens(b6.value).indexOf("::") !== -1) {
              add("HIGH", b6.line, "ipv6_bind_addresses", 'ipv6_bind_addresses is "::" — the server listens on every IPv6 interface. Bind to specific addresses (for example ::1 for local-only) unless public serving on all interfaces is deliberate.');
            } else {
              add("PASS", b6.line, "ipv6_bind_addresses", "ipv6_bind_addresses is set to specific address(es), not the :: wildcard.");
            }
          } else {
            add("INFO", null, "ipv6_bind_addresses", "ipv6_bind_addresses is not set in this file. If the host has IPv6, confirm the server default matches what you intend.");
          }

          // --- Recursive ACL ---
          var rac = get("recursive_acl");
          var upstreamCount = getAll("upstream_servers").filter(function (e) { return e.sub; }).length;
          if (rac) {
            if (isWideAcl(rac.value)) {
              add("CRITICAL", rac.line, "recursive_acl", 'recursive_acl allows 0.0.0.0/0 — anyone who can reach this server can use it as a resolver. That is an open resolver, the classic setup for DNS amplification abuse. Restrict it to the networks you actually serve (for example 127.0.0.0/8).');
            } else {
              add("PASS", rac.line, "recursive_acl", "recursive_acl is restricted to named networks rather than open to the world.");
            }
          } else if (upstreamCount > 0 || entries["upstream_servers"]) {
            add("CRITICAL", null, "recursive_acl", "upstream_servers is configured, so recursion is implied, but recursive_acl is not set — nothing in this file limits who may use this server as a resolver. Add a recursive_acl restricted to the networks you serve before this serves anyone.");
          } else {
            add("LOW", null, "recursive_acl", "recursive_acl is not set and no upstream_servers were found, so recursion does not appear to be configured. If you enable recursion later, set recursive_acl first.");
          }

          // --- Admin ACL ---
          var aac = get("admin_acl");
          if (aac) {
            if (isWideAcl(aac.value)) {
              add("HIGH", aac.line, "admin_acl", "admin_acl allows 0.0.0.0/0 — administrative queries are accepted from anywhere. Restrict admin_acl to the hosts that administer this server (for example 127.0.0.1/32).");
            } else {
              add("PASS", aac.line, "admin_acl", "admin_acl is restricted to named hosts rather than open to the world.");
            }
          } else {
            add("HIGH", null, "admin_acl", "admin_acl is not set — nothing in this file restricts administrative queries to named hosts. Set admin_acl to the machines that administer this server (for example 127.0.0.1/32).");
          }

          // --- Information leakage ---
          var hd = get("hide_disclaimer");
          if (hd) {
            if (/^no$/i.test(hd.value)) {
              add("MEDIUM", hd.line, "hide_disclaimer", 'hide_disclaimer = "NO" — the server shows its disclaimer/version banner to anyone who asks. That is free reconnaissance for an attacker. Set hide_disclaimer = "YES".');
            } else if (/^yes$/i.test(hd.value)) {
              add("PASS", hd.line, "hide_disclaimer", 'hide_disclaimer = "YES" — the version disclaimer is hidden from casual queries.');
            } else {
              add("LOW", hd.line, "hide_disclaimer", 'hide_disclaimer is set to an unrecognized value. MaraDNS expects "YES" or "NO"; anything else may not behave as you intend.');
            }
          } else {
            add("LOW", null, "hide_disclaimer", 'hide_disclaimer is not set, so the default applies and the disclaimer is shown. Set hide_disclaimer = "YES" to keep version detail quiet.');
          }
          var vl = get("verbose_level");
          if (vl) {
            var vln = toInt(vl.value);
            if (vln !== null && vln >= 3) {
              add("MEDIUM", vl.line, "verbose_level", "verbose_level is " + vln + " — very chatty logging and responses give strangers (and log readers) more detail about this server than they need. Level 1 is a sane serving default.");
            } else if (vln === 2) {
              add("LOW", vl.line, "verbose_level", "verbose_level is 2 — moderately chatty. Fine for debugging; consider 1 for steady serving.");
            } else if (vln !== null) {
              add("PASS", vl.line, "verbose_level", "verbose_level is " + vln + " — quiet, appropriate for serving.");
            } else {
              add("LOW", vl.line, "verbose_level", "verbose_level is set to a non-numeric value and could not be graded.");
            }
          } else {
            add("INFO", null, "verbose_level", "verbose_level is not set; the server default applies.");
          }

          // --- Secrets (value NEVER rendered — key, line, length only) ---
          var sec = get("secret");
          if (sec) {
            var len = sec.value.length;
            if (len < 16) {
              add("HIGH", sec.line, "secret", "secret is set but short — " + len + " characters (the value is never shown in this audit). Short secrets are guessable; use a long random value of 32 characters or more.");
            } else if (len < 32) {
              add("LOW", sec.line, "secret", "secret is set, " + len + " characters long (the value is never shown in this audit). Workable, but 32 characters or more is the safer target.");
            } else {
              add("PASS", sec.line, "secret", "secret is set with a strong length — " + len + " characters (the value is never shown in this audit). Length is all this tool can judge; it cannot tell whether the value is random or reused.");
            }
          } else {
            add("LOW", null, "secret", "No secret is set in this file. Set a long random secret so the features that rely on it are not running on a default or a guess.");
          }
          var rsf = get("random_seed_file");
          if (rsf) {
            add("INFO", rsf.line, "random_seed_file", "random_seed_file is set (path of " + rsf.value.length + " characters; the path and the file contents are not shown or read by this tool). Make sure the file exists, is readable only by the server, and holds real entropy.");
          } else {
            add("INFO", null, "random_seed_file", "random_seed_file is not set. Point it at a protected entropy file so the server's randomness does not depend on weaker fallbacks.");
          }

          // --- csv2 zones and zone transfers ---
          var csv2Zones = getAll("csv2").filter(function (e) { return e.sub; });
          var csv2Any = getAll("csv2").length > 0;
          if (csv2Any) {
            var firstCsv2 = get("csv2");
            add("INFO", firstCsv2.line, "csv2", "csv2 authoritative zone data is configured (" + csv2Zones.length + " zone assignment(s)). Zone contents are data, not posture — this tool grades the transfer ACL below, not the records.");
          }
          var zta = get("zone_transfer_acl");
          if (zta) {
            if (isWideAcl(zta.value)) {
              add("HIGH", zta.line, "zone_transfer_acl", "zone_transfer_acl allows 0.0.0.0/0 — anyone can request a full zone transfer and walk away with a complete copy of your zone data. Restrict it to your secondary servers only.");
            } else {
              add("PASS", zta.line, "zone_transfer_acl", "zone_transfer_acl is restricted to named hosts rather than open to the world.");
            }
          } else if (csv2Any) {
            add("MEDIUM", null, "zone_transfer_acl", "csv2 zones are defined but zone_transfer_acl is not set — nothing in this file limits full zone transfers to your secondaries. Set zone_transfer_acl to the hosts allowed to copy the zone.");
          }

          // --- Upstream servers (plain config notes) ---
          if (upstreamCount > 0) {
            var firstUp = getAll("upstream_servers").filter(function (e) { return e.sub; })[0];
            add("INFO", firstUp.line, "upstream_servers", "upstream_servers is configured (" + upstreamCount + " assignment(s)) — noted as plain configuration. This tool cannot verify the upstreams are correct, reachable, or trustworthy; that judgment is yours.");
          }

          // --- Resource caps ---
          var mp = get("maxprocs");
          if (mp) {
            var mpn = toInt(mp.value);
            if (mpn !== null && mpn > 256) {
              add("MEDIUM", mp.line, "maxprocs", "maxprocs is " + mpn + " — an effectively unbounded process cap. A flood of queries can push the server to spawn processes until the host is exhausted. Set a cap the machine can actually sustain.");
            } else if (mpn !== null) {
              add("PASS", mp.line, "maxprocs", "maxprocs is " + mpn + " — a bounded process cap.");
            } else {
              add("LOW", mp.line, "maxprocs", "maxprocs is set to a non-numeric value and could not be graded.");
            }
          } else {
            add("LOW", null, "maxprocs", "maxprocs is not set — no explicit process cap in this file. Set one the host can sustain so a query flood cannot exhaust it.");
          }
          var mce = get("maximum_cache_elements");
          if (mce) {
            var mcen = toInt(mce.value);
            if (mcen !== null && mcen > 1000000) {
              add("MEDIUM", mce.line, "maximum_cache_elements", "maximum_cache_elements is " + mcen + " — a very large cache that can grow memory use well past what most hosts should give a resolver. Size it to the machine.");
            } else if (mcen !== null) {
              add("PASS", mce.line, "maximum_cache_elements", "maximum_cache_elements is " + mcen + " — a bounded cache size.");
            } else {
              add("LOW", mce.line, "maximum_cache_elements", "maximum_cache_elements is set to a non-numeric value and could not be graded.");
            }
          } else {
            add("LOW", null, "maximum_cache_elements", "maximum_cache_elements is not set — the cache size is left to the server default. Set it explicitly to size memory use to this host.");
          }

          // --- Address helpers (INFO) ---
          var si = get("synthip");
          if (si) add("INFO", si.line, "synthip", "synthip is configured — noted as information only. Synthetic replies are a deliberate feature; make sure the ranges it answers for are ranges you mean to serve.");
          var alias = getAll("ipv4_alias");
          if (alias.length) add("INFO", alias[0].line, "ipv4_alias", "ipv4_alias entries are configured (" + alias.length + ") — noted as information only. Aliases widen the names this server answers for; keep the list intentional.");

          findings.sort(function (a, b) {
            var r = RANK[a.severity] - RANK[b.severity];
            if (r !== 0) return r;
            var la = a.line === null ? 9999 : a.line, lb = b.line === null ? 9999 : b.line;
            return la - lb;
          });

          var verdict;
          var has = function (sev) { return findings.some(function (f) { return f.severity === sev; }); };
          if (has("CRITICAL")) verdict = "DO NOT SERVE";
          else if (has("HIGH") || has("MEDIUM")) verdict = "SERVE WITH FIXES";
          else verdict = "SAFE TO SERVE";

          return {
            verdict: verdict,
            findings: findings,
            stats: { lines: lines.length, assignments: parsed, commented: commented, notParsed: notParsed },
            secretValues: secretValues
          };
        }

        function sanitize(str, secretValues) {
          var out = str;
          secretValues.forEach(function (v) {
            if (v && v.length >= 3) {
              out = out.split(v).join("[redacted — never printed]");
            }
          });
          return out;
        }

        function verdictSub(v) {
          switch (v) {
            case "SAFE TO SERVE": return "No critical, high, or medium findings in the pasted text. The honest limits below still apply — this grades configuration text, not the running server.";
            case "SERVE WITH FIXES": return "Nothing here is an open door, but the high and medium findings should be fixed before this serves anyone beyond your own bench.";
            case "DO NOT SERVE": return "At least one CRITICAL finding. Do not start a public server on this configuration until the critical items are fixed and the file is re-audited.";
            default: return "The paste did not contain a single parseable mararc key = value assignment, so there is nothing to grade. Paste a mararc file — or load one of the examples — and audit again.";
          }
        }
        function verdictClass(v) {
          switch (v) {
            case "SAFE TO SERVE": return "safe";
            case "SERVE WITH FIXES": return "fixes";
            case "DO NOT SERVE": return "donot";
            default: return "enough";
          }
        }
        function chipClass(sev) { return sev === "NOT PARSED" ? "NOTPARSED" : sev; }
        function esc(s) {
          return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
        }

        function buildReport(result) {
          var out = [];
          out.push("J-Dawgs MaraDNS Server Config Safety Auditor — audit report");
          out.push("Verdict: " + result.verdict);
          out.push("Lines in paste: " + result.stats.lines + " | Active assignments graded: " + result.stats.assignments + " | Commented lines seen: " + result.stats.commented + " | Not-parsed lines: " + result.stats.notParsed);
          out.push("Secrets are reported by key name, line, and character length only. Secret values never appear in this report.");
          out.push("");
          if (!result.findings.length) {
            out.push("No findings — nothing parseable was found in the paste.");
          }
          result.findings.forEach(function (f) {
            out.push("[" + f.severity + "] " + (f.line !== null ? "Line " + f.line : "File level") + (f.key ? " (" + f.key + ")" : "") + " — " + f.message);
          });
          out.push("");
          out.push("Limits: offline text audit only. This tool never starts a server, never connects anywhere, and never runs MaraDNS or Deadwood. Signatures and authentication cannot be verified from configuration text.");
          return sanitize(out.join("\n"), result.secretValues);
        }

        function buildJSON(result) {
          var counts = {};
          result.findings.forEach(function (f) { counts[f.severity] = (counts[f.severity] || 0) + 1; });
          var obj = {
            tool: "J-Dawgs MaraDNS Server Config Safety Auditor",
            verdict: result.verdict,
            summary: {
              lines_in_paste: result.stats.lines,
              active_assignments_graded: result.stats.assignments,
              commented_lines_seen: result.stats.commented,
              not_parsed_lines: result.stats.notParsed,
              findings_by_severity: counts
            },
            findings: result.findings.map(function (f) {
              return { severity: f.severity, line: f.line, key: f.key || null, message: f.message };
            }),
            secret_handling: "Secrets are reported by key name, line, and character length only. Secret values are never included in this export.",
            limits: "Offline text audit only. Never starts a server, never connects anywhere, never runs MaraDNS or Deadwood. Signatures and authentication cannot be verified from configuration text."
          };
          return sanitize(JSON.stringify(obj, null, 2), result.secretValues);
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-maradns-server-config-safety-auditortm',
  name: 'J-Dawgs MaraDNS Server Config Safety Auditor',
  description: 'Grades a pasted mararc offline — wildcard binds, open resolver ACLs, short secrets by length only — into one serve verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
