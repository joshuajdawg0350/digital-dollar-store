'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Coturn TURN Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Directive vocabulary (coturn turnserver.conf) ---------- */
      var KNOWN_KEYS = {
        "listening-port":1,"tls-listening-port":1,"dtls-listening-port":1,"alt-listening-port":1,"alt-tls-listening-port":1,
        "listening-ip":1,"relay-ip":1,"external-ip":1,"min-port":1,"max-port":1,
        "verbose":1,"fingerprint":1,"lt-cred-mech":1,"st-cred-mech":1,"no-auth":1,"no-auth-pdfile":1,
        "use-auth-secret":1,"static-auth-secret":1,"user":1,"userdb":1,"realm":1,"server-name":1,
        "total-quota":1,"user-quota":1,"max-bps":1,"bps-capacity":1,
        "cert":1,"pkey":1,"pkey-pwd":1,"cipher-list":1,"dh-file":1,"ec-curve-name":1,
        "no-tls":1,"no-dtls":1,"no-tcp":1,"no-udp":1,"no-tcp-relay":1,"no-udp-relay":1,
        "denied-peer-ip":1,"allowed-peer-ip":1,"no-multicast-peers":1,"no-loopback-peers":1,
        "stale-nonce":1,"check-origin-consistency":1,"origin":1,
        "log-file":1,"simple-log":1,"no-stdout-log":1,"syslog":1,"pidfile":1,
        "proc-user":1,"proc-group":1,"mobility":1,
        "no-cli":1,"cli-ip":1,"cli-port":1,"cli-password":1,
        "web-admin":1,"web-admin-ip":1,"web-admin-port":1,"web-admin-listen-on-workers":1,
        "secret-key":1,"oauth":1,"prometheus":1,"prometheus-port":1,"prometheus-address":1,
        "redis-userdb":1,"redis-statsdb":1,"psql-userdb":1,"mysql-userdb":1,"mongo-userdb":1,
        "secure-stun":1,"no-rfc5780":1,"no-stun-backward-compatibility":1,
        "response-origin-only-with-rfc5780":1,"rfc5780":1,
        "new-log-timestamp-format":1,"no-software-attribute":1,"allowed-peer-ip-file":1,
        "acme-redirect":1,"aux-server":1,"relay-threads":1,"cpus":1,
        "ne":1,"lt-cred-mech-file":1,"keep-address-family":1,"allocation-default-address-family":1
      };
      var FLAG_KEYS = {
        "verbose":1,"fingerprint":1,"lt-cred-mech":1,"st-cred-mech":1,"no-auth":1,"no-auth-pdfile":1,
        "use-auth-secret":1,"no-tls":1,"no-dtls":1,"no-tcp":1,"no-udp":1,"no-tcp-relay":1,"no-udp-relay":1,
        "no-multicast-peers":1,"no-loopback-peers":1,"mobility":1,"no-cli":1,"syslog":1,"simple-log":1,
        "no-stdout-log":1,"oauth":1,"check-origin-consistency":1,"secure-stun":1,"no-rfc5780":1,
        "no-stun-backward-compatibility":1,"response-origin-only-with-rfc5780":1,"rfc5780":1,
        "no-software-attribute":1,"prometheus":1,"web-admin":1,"keep-address-family":1
      };
      /* Keys whose values are secrets: never rendered anywhere. */
      var SECRET_KEYS = {"user":1,"static-auth-secret":1,"cli-password":1,"pkey-pwd":1,"secret-key":1};
      /* Directives coturn legitimately allows more than once. */
      var MULTI_KEYS = {"listening-ip":1,"relay-ip":1,"external-ip":1,"denied-peer-ip":1,"allowed-peer-ip":1,"user":1,"aux-server":1};

      /* ---------- IP helpers ---------- */
      function ipToInt(ip){
        var parts = ip.split(".");
        if (parts.length !== 4) return null;
        var n = 0;
        for (var i=0;i<4;i++){
          var p = parseInt(parts[i],10);
          if (isNaN(p) || p < 0 || p > 255 || String(p) !== parts[i].replace(/^0+(?=\d)/,"")) { /* lenient below */ }
          if (isNaN(p) || p < 0 || p > 255) return null;
          n = n*256 + p;
        }
        return n;
      }
      function parsePeerRange(v){
        v = (v||"").trim();
        if (!v) return null;
        var dash = v.indexOf("-");
        if (dash > 0){
          var a = ipToInt(v.slice(0,dash).trim()), b = ipToInt(v.slice(dash+1).trim());
          if (a===null || b===null) return null;
          return {start:Math.min(a,b), end:Math.max(a,b)};
        }
        var slash = v.indexOf("/");
        if (slash > 0){
          var base = ipToInt(v.slice(0,slash).trim());
          var bits = parseInt(v.slice(slash+1),10);
          if (base===null || isNaN(bits) || bits<0 || bits>32) return null;
          var size = Math.pow(2, 32-bits);
          var start = Math.floor(base/size)*size;
          return {start:start, end:start+size-1};
        }
        var single = ipToInt(v);
        if (single===null) return null;
        return {start:single, end:single};
      }
      function isPrivateOrLocal(ip){
        var n = ipToInt(ip);
        if (n===null) return false;
        var ranges = [
          [ipToInt("10.0.0.0"), ipToInt("10.255.255.255")],
          [ipToInt("172.16.0.0"), ipToInt("172.31.255.255")],
          [ipToInt("192.168.0.0"), ipToInt("192.168.255.255")],
          [ipToInt("127.0.0.0"), ipToInt("127.255.255.255")],
          [ipToInt("169.254.0.0"), ipToInt("169.254.255.255")],
          [ipToInt("100.64.0.0"), ipToInt("100.127.255.255")]
        ];
        for (var i=0;i<ranges.length;i++){ if (n>=ranges[i][0] && n<=ranges[i][1]) return true; }
        return false;
      }

      /* ---------- Parser ---------- */
      function parseConfig(text){
        var lines = text.split(/\r?\n/);
        var occ = {};        /* key -> [{line, value}] */
        var malformed = [];  /* {line} */
        var order = [];
        function add(key, line, value){
          if (!occ[key]) { occ[key] = []; order.push(key); }
          occ[key].push({line:line, value:value});
        }
        for (var i=0;i<lines.length;i++){
          var lineNo = i+1;
          var raw = lines[i];
          var s = raw.replace(/^\s+|\s+$/g,"");
          if (!s) continue;
          if (s.charAt(0) === "#" || s.charAt(0) === ";") continue;
          /* strip trailing comment: a # preceded by whitespace */
          var hashIdx = s.indexOf(" #");
          if (hashIdx > 0) s = s.slice(0, hashIdx).replace(/\s+$/,"");
          var eq = s.indexOf("=");
          if (eq > 0){
            var key = s.slice(0,eq).replace(/\s+$/,"").toLowerCase();
            var val = s.slice(eq+1).replace(/^\s+|\s+$/g,"");
            if (!key) { malformed.push({line:lineNo}); continue; }
            add(key, lineNo, val);
          } else {
            var token = s.toLowerCase();
            if (FLAG_KEYS[token]) add(token, lineNo, null);
            else malformed.push({line:lineNo});
          }
        }
        return {occ:occ, order:order, malformed:malformed, lineCount:lines.length};
      }

      /* ---------- Auditor ---------- */
      function audit(text){
        var parsed = parseConfig(text);
        var occ = parsed.occ;
        var findings = [];
        function F(sev, check, lines, msg){ findings.push({severity:sev, check:check, lines:lines, message:msg}); }
        function has(k){ return !!occ[k]; }
        function linesOf(k){ return occ[k] ? occ[k].map(function(o){return o.line;}) : []; }
        function first(k){ return occ[k] ? occ[k][0] : null; }

        var directiveCount = parsed.order.reduce(function(n,k){return n+occ[k].length;},0);

        /* --- Check 1+2: authentication posture & wildcard escalation --- */
        var wildcard = [];
        ["listening-ip","relay-ip"].forEach(function(k){
          (occ[k]||[]).forEach(function(o){
            if (o.value === "0.0.0.0" || o.value === "::" || o.value === "[::]"){
              wildcard.push({key:k, line:o.line, value:o.value});
            }
          });
        });
        var authBlocker = null;
        if (has("no-auth")){
          authBlocker = {key:"no-auth", lines:linesOf("no-auth"),
            why:"no-auth is set: the server accepts allocations with no credentials at all"};
        } else if (has("no-auth-pdfile")){
          authBlocker = {key:"no-auth-pdfile", lines:linesOf("no-auth-pdfile"),
            why:"no-auth-pdfile is set: the server accepts allocations with no credentials at all"};
        } else if (!has("lt-cred-mech") && !has("st-cred-mech") && !has("use-auth-secret")){
          authBlocker = {key:null, lines:[],
            why:"no authentication mechanism is configured anywhere in the file — no lt-cred-mech, no st-cred-mech, and no use-auth-secret"};
        }
        if (authBlocker){
          var msg = "Open relay risk: " + authBlocker.why +
            ". Anyone who can reach this server can relay traffic through it at your expense — the classic abused-TURN-server setup.";
          if (authBlocker.lines.length){
            msg += " (" + authBlocker.key + ", line " + authBlocker.lines.join(", ") + ".)";
          }
          if (wildcard.length){
            var wtxt = wildcard.map(function(w){ return w.key + " = " + w.value + " (line " + w.line + ")"; }).join("; ");
            msg += " ESCALATED: the bind is wide open too — " + wtxt +
              ". Wildcard bind plus no authentication means the whole internet can use this relay, not just your LAN.";
          }
          F("BLOCKER","Authentication posture", authBlocker.lines.concat(wildcard.map(function(w){return w.line;})), msg);
        } else {
          var mechs = [];
          if (has("lt-cred-mech")) mechs.push("lt-cred-mech (line " + linesOf("lt-cred-mech").join(", ") + ")");
          if (has("use-auth-secret")) mechs.push("use-auth-secret (line " + linesOf("use-auth-secret").join(", ") + ")");
          if (has("st-cred-mech")) mechs.push("st-cred-mech (line " + linesOf("st-cred-mech").join(", ") + ")");
          F("GOOD","Authentication posture", [], "Authentication is configured: " + mechs.join("; ") + ". Allocations require credentials.");
          if (has("st-cred-mech") && !has("lt-cred-mech") && !has("use-auth-secret")){
            F("INFO","Authentication posture", linesOf("st-cred-mech"),
              "Only st-cred-mech (short-term credentials) is in use. That mechanism is the legacy option; lt-cred-mech or use-auth-secret is the usual modern choice.");
          }
          if (wildcard.length){
            F("INFO","Relay exposure", wildcard.map(function(w){return w.line;}),
              "The server binds the wildcard address (" + wildcard.map(function(w){return w.key + " line " + w.line;}).join("; ") +
              "). That is normal for a public TURN server while authentication is on — it is the missing-auth case above that makes it dangerous.");
          }
        }
        /* fingerprint — graded separately from the auth finding, per spec */
        if (has("fingerprint")){
          F("GOOD","Fingerprint", linesOf("fingerprint"), "fingerprint is set (line " + linesOf("fingerprint").join(", ") + ") — allocations carry the FINGERPRINT attribute, as Coturn's own documentation recommends.");
        } else {
          F("INFO","Fingerprint", [], "fingerprint is not set. Coturn recommends it; without it, some clients and middleboxes handle allocations less predictably. This is graded separately from authentication and does not block deployment on its own.");
        }

        /* --- Check 3: static credentials (key name + line only, NEVER values) --- */
        (occ["user"]||[]).forEach(function(o){
          F("WARNING","Static credentials", [o.line],
            "Line " + o.line + ": the 'user' directive sets a long-term static credential in the config file. Flagged by key name and line only — the value is never shown here. Long-term static credentials never rotate and tend to leak with the file; prefer lt-cred-mech with a userdb, or use-auth-secret with short-lived credentials.");
        });
        (occ["static-auth-secret"]||[]).forEach(function(o){
          if (has("use-auth-secret")){
            F("INFO","Static credentials", [o.line],
              "Line " + o.line + ": 'static-auth-secret' is present and backs use-auth-secret (shared-secret, short-lived credentials). Flagged by key name and line only — the value is never shown here. Treat the file itself as a secret.");
          } else {
            F("WARNING","Static credentials", [o.line],
              "Line " + o.line + ": 'static-auth-secret' is set but use-auth-secret appears nowhere in the file, so this shared secret may not be wired into any live auth mechanism. Flagged by key name and line only — the value is never shown here.");
          }
        });
        (occ["cli-password"]||[]).forEach(function(o){
          F("WARNING","Static credentials", [o.line],
            "Line " + o.line + ": 'cli-password' sets a static password for the telnet CLI. Flagged by key name and line only — the value is never shown here.");
        });
        (occ["pkey-pwd"]||[]).forEach(function(o){
          F("INFO","Static credentials", [o.line],
            "Line " + o.line + ": 'pkey-pwd' is present (the TLS private key is password-protected). Flagged by key name and line only — the value is never shown here.");
        });

        /* --- Check 4: TLS / DTLS posture --- */
        var noTls = has("no-tls"), noDtls = has("no-dtls");
        var externalRelay = (occ["relay-ip"]||[]).some(function(o){
          return o.value === "0.0.0.0" || o.value === "::" || (o.value && !isPrivateOrLocal(o.value));
        });
        if (noTls && noDtls){
          var tlsLines = linesOf("no-tls").concat(linesOf("no-dtls"));
          var tmsg = "Both no-tls (line " + linesOf("no-tls").join(", ") + ") and no-dtls (line " + linesOf("no-dtls").join(", ") +
            ") are set: no encrypted listener at all. TURN credentials and media setup cross the wire unprotected by TLS/DTLS.";
          if (externalRelay){
            F("BLOCKER","TLS/DTLS", tlsLines, tmsg + " ESCALATED to BLOCKER: a relay-ip in this file faces external networks, so the unencrypted posture is exposed beyond the LAN.");
          } else {
            F("WARNING","TLS/DTLS", tlsLines, tmsg);
          }
        } else if (noTls || noDtls){
          var which = noTls ? "no-tls" : "no-dtls";
          F("INFO","TLS/DTLS", linesOf(which),
            which + " is set (line " + linesOf(which).join(", ") + ") but the other encrypted transport remains enabled. Confirm that split is deliberate.");
        }
        var certO = first("cert"), pkeyO = first("pkey");
        if (certO && !pkeyO){
          F("WARNING","TLS/DTLS", [certO.line], "cert is set (line " + certO.line + ") but pkey is not set anywhere: a certificate with no private key cannot start a TLS listener. Set pkey to the matching key file.");
        } else if (!certO && pkeyO){
          F("WARNING","TLS/DTLS", [pkeyO.line], "pkey is set (line " + pkeyO.line + ") but cert is not set anywhere: a private key with no certificate cannot start a TLS listener. Set cert to the matching certificate file.");
        } else if (certO && pkeyO){
          F("GOOD","TLS/DTLS", [certO.line, pkeyO.line], "cert (line " + certO.line + ") and pkey (line " + pkeyO.line + ") are both set — TLS listener material is configured. (Whether the files exist and match on the host is NOT VERIFIED.)");
          if (!has("tls-listening-port")){
            F("INFO","TLS/DTLS", [certO.line], "tls-listening-port is not set while a cert is present. Coturn falls back to its standard TLS port behavior; pin tls-listening-port explicitly so the deployed port is the one you firewall for.");
          }
        } else if (!noTls){
          F("INFO","TLS/DTLS", [], "No cert is set in this file, so no TLS listener can start from it. Plain TURN/STUN listeners still work; add cert + pkey if clients will use TURN over TLS.");
        }

        /* --- Check 5: relay port-range arithmetic --- */
        var portInfo = null;
        var minO = first("min-port"), maxO = first("max-port");
        if (minO && maxO){
          var minV = parseInt(minO.value,10), maxV = parseInt(maxO.value,10);
          if (!isNaN(minV) && !isNaN(maxV)){
            var count = maxV - minV + 1;
            var arith = maxV + " − " + minV + " + 1 = " + count.toLocaleString("en-US") + " relay ports";
            portInfo = {minPort:minV, maxPort:maxV, count:count, arithmetic:arith,
                        minLine:minO.line, maxLine:maxO.line};
            if (maxV < minV){
              F("BLOCKER","Port range", [minO.line, maxO.line],
                "Inverted relay port range: min-port = " + minV + " (line " + minO.line + ") is greater than max-port = " + maxV + " (line " + maxO.line + "). Arithmetic: " + arith + " — a negative count. No allocation can ever get a relay port from this range.");
            } else if (count > 10000){
              F("WARNING","Port range", [minO.line, maxO.line],
                "Very wide relay port range: min-port = " + minV + " (line " + minO.line + "), max-port = " + maxV + " (line " + maxO.line + "). Arithmetic: " + arith + ". Over 10,000 relay ports is a large firewall and abuse surface; narrow it to what your call volume needs.");
            } else {
              F("GOOD","Port range", [minO.line, maxO.line],
                "Relay port range: min-port = " + minV + " (line " + minO.line + "), max-port = " + maxV + " (line " + maxO.line + "). Arithmetic: " + arith + ".");
            }
          } else {
            F("WARNING","Port range", [minO.line, maxO.line],
              "min-port / max-port could not both be read as numbers (lines " + minO.line + " and " + maxO.line + "), so the relay port range arithmetic cannot be verified.");
          }
        } else if (minO || maxO){
          var setOne = minO ? "min-port" : "max-port";
          var setLine = minO ? minO.line : maxO.line;
          F("INFO","Port range", [setLine],
            "Only " + setOne + " is set (line " + setLine + "); the other end of the relay port range is not pinned in this file, so the full range arithmetic cannot be shown. Set both min-port and max-port.");
        } else {
          F("INFO","Port range", [], "Neither min-port nor max-port is set: this file does not pin the relay port range at all, so no port arithmetic can be shown. Set both so the firewall rules and the config agree.");
        }
        if (!has("denied-peer-ip")){
          F("WARNING","Peer blocklist", [],
            "denied-peer-ip is absent: there is no peer blocklist in this file, so nothing in the config stops the relay from connecting onward to addresses you may not want it reaching.");
        }

        /* --- Check 6: allowed / denied peer IPs vs private ranges --- */
        var deniedRanges = (occ["denied-peer-ip"]||[]).map(function(o){ return parsePeerRange(o.value); }).filter(Boolean);
        if (!has("allowed-peer-ip") && !has("denied-peer-ip")){
          F("WARNING","Peer reach", [],
            "Neither allowed-peer-ip nor denied-peer-ip is set. With no peer restrictions, the relay will happily carry traffic toward internal addresses — private LAN hosts, link-local services, and cloud metadata endpoints included. Add denied-peer-ip entries for the private ranges at minimum.");
        } else if (deniedRanges.length){
          var targets = [
            {name:"10.0.0.0/8", start:ipToInt("10.0.0.0"), end:ipToInt("10.255.255.255")},
            {name:"172.16.0.0/12", start:ipToInt("172.16.0.0"), end:ipToInt("172.31.255.255")},
            {name:"192.168.0.0/16", start:ipToInt("192.168.0.0"), end:ipToInt("192.168.255.255")}
          ];
          var uncovered = targets.filter(function(t){
            return !deniedRanges.some(function(r){ return r.start <= t.start && r.end >= t.end; });
          });
          var dLines = linesOf("denied-peer-ip");
          if (uncovered.length === 0){
            F("GOOD","Peer reach", dLines,
              "denied-peer-ip (line " + dLines.join(", ") + ") covers all three RFC1918 private ranges (10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16): the relay is blocked from reaching private LAN addresses as a peer.");
          } else if (uncovered.length < 3){
            F("WARNING","Peer reach", dLines,
              "denied-peer-ip is set but does not cover every private range: " + uncovered.map(function(t){return t.name;}).join(", ") +
              " can still be reached through the relay. Extend denied-peer-ip to cover all of 10.0.0.0/8, 172.16.0.0/12, and 192.168.0.0/16.");
          } else {
            F("WARNING","Peer reach", dLines,
              "denied-peer-ip is set but none of its entries cover the RFC1918 private ranges (10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16), so the relay can still reach private LAN addresses. Add denied-peer-ip entries for those ranges.");
          }
        }
        if (has("allowed-peer-ip")){
          F("INFO","Peer reach", linesOf("allowed-peer-ip"),
            "allowed-peer-ip is set (line " + linesOf("allowed-peer-ip").join(", ") + "): an allowlist is in force, so peers outside it are refused. Make sure it stays in step with the networks your users actually relay to.");
        }

        /* --- Check 7: realm / server-name / nonce posture --- */
        if (!has("realm")){
          F("INFO","Identity", [], "realm is not set. Coturn will use its default realm; set realm explicitly — long-term credentials are tied to it, and a silent default makes later migrations painful.");
        } else {
          F("GOOD","Identity", linesOf("realm"), "realm is set (line " + linesOf("realm").join(", ") + ").");
        }
        if (!has("server-name")){
          F("INFO","Identity", [], "server-name is not set. Set it to the server's public name so logs, OAuth flows, and client configurations refer to the same identity.");
        }
        if (has("stale-nonce")){
          var sn = first("stale-nonce");
          var snV = parseInt(sn.value,10);
          if (isNaN(snV)){
            F("INFO","Nonce posture", [sn.line], "stale-nonce is present (line " + sn.line + ") but its value could not be read as a number of seconds, so the nonce lifetime posture is not graded further.");
          } else if (snV > 3600){
            F("WARNING","Nonce posture", [sn.line],
              "stale-nonce = " + snV + " seconds (line " + sn.line + "): nonces stay valid for over an hour. A captured nonce has a long replay window; Coturn's customary setting is 600 seconds.");
          } else {
            F("INFO","Nonce posture", [sn.line],
              "stale-nonce = " + snV + " seconds (line " + sn.line + "): nonce lifetime is set explicitly and sits in the sane range (Coturn's customary value is 600).");
          }
        }

        /* --- Check 8: duplicate directives --- */
        parsed.order.forEach(function(k){
          if (MULTI_KEYS[k]) return;
          if (occ[k].length > 1){
            var ls = linesOf(k);
            F("WARNING","Duplicate directives", ls.slice(),
              "Duplicate directive: '" + k + "' appears on lines " + ls.join(" and ") +
              ". Coturn applies last-value-wins, so the line " + ls[ls.length-1] + " value is the one that takes effect and the earlier line is dead config. Delete the stale line so the file says what the server does.");
          }
        });

        /* --- Check 9: unknown directives --- */
        var unknown = parsed.order.filter(function(k){ return !KNOWN_KEYS[k]; });
        if (unknown.length){
          var ulist = unknown.map(function(k){
            return "'" + k + "' (line " + linesOf(k).join(", ") + ")";
          }).join(", ");
          F("NOT AUDITED","Unknown directives",
            unknown.reduce(function(a,k){ return a.concat(linesOf(k)); }, []),
            "Not audited — this tool does not recognize these directives and will not guess at them: " + ulist +
            ". They may be typos (a mistyped known directive is silently ignored by Coturn too), directives from a newer Coturn than this checklist, or local extensions. Verify them against your Coturn version's documentation by hand.");
        }

        /* --- Check 10: malformed lines --- */
        parsed.malformed.forEach(function(m){
          F("NOT PARSED","Malformed lines", [m.line],
            "Line " + m.line + " was not parsed: it has no '=' and is not a known flag, so it was excluded from grading. Coturn may refuse or ignore such a line; fix or remove it.");
        });

        /* --- Verdict --- */
        var counts = {BLOCKER:0, WARNING:0, INFO:0, GOOD:0, "NOT AUDITED":0, "NOT PARSED":0};
        findings.forEach(function(f){ counts[f.severity] = (counts[f.severity]||0)+1; });
        var verdict, verdictClass;
        if (counts.BLOCKER > 0){ verdict = "DO NOT DEPLOY"; verdictClass = "bad"; }
        else if (counts.WARNING > 0){ verdict = "DEPLOY WITH FIXES"; verdictClass = "mid"; }
        else { verdict = "SAFE TO DEPLOY"; verdictClass = "ok"; }

        return {
          verdict:verdict, verdictClass:verdictClass, counts:counts,
          findings:findings, portInfo:portInfo, directiveCount:directiveCount,
          notVerified:[
            "NAT / external-ip reachability — whether any external-ip address actually maps to this host and is reachable from the public internet.",
            "Firewall state — host firewalls, cloud security groups, and router rules for the listening and relay ports.",
            "Live relay behavior — whether the running server actually relays, for whom, and how it behaves under real allocations.",
            "Files on the host — whether the cert/pkey files named in the config exist, match, and are unexpired.",
            "External user databases — the strength and currency of credentials in any userdb / Redis / SQL / Mongo store the config points at."
          ]
        };
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-coturn-turn-server-config-safety-auditortm',
  name: 'J-Dawgs Coturn TURN Server Config Safety Auditor',
  description: 'Grades a pasted turnserver.conf offline — open-relay/auth posture escalated by wildcard bind, static secrets by key name and line only, TLS/DTLS posture, relay port-range arithmetic shown, and peer-range coverage — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
