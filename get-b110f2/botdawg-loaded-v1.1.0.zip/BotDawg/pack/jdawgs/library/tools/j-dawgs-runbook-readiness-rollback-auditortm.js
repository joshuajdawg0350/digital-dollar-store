'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Runbook Readiness & Rollback Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var runbookEl = document.getElementById('runbook');
      var refdateEl = document.getElementById('refdate');
      var resultsEl = document.getElementById('results');
      var emptyEl = document.getElementById('emptyMsg');
      var verdictEl = document.getElementById('verdictBox');
      var scoreBody = document.getElementById('scoreBody');
      var findingsEl = document.getElementById('findingsList');
      var reportBox = document.getElementById('reportBox');
      var copyStatus = document.getElementById('copyStatus');
      var pitchStatus = document.getElementById('pitchStatus');
      var lastReport = '';

      function pad(n){ return (n<10?'0':'')+n; }
      function isoOf(d){ return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate()); }

      // Default reference date: today (local).
      refdateEl.value = isoOf(new Date());

      function refDate(){
        var v = refdateEl.value;
        if(v){
          var p = v.split('-');
          if(p.length===3){
            return new Date(parseInt(p[0],10), parseInt(p[1],10)-1, parseInt(p[2],10));
          }
        }
        var t = new Date(); t.setHours(0,0,0,0); return t;
      }

      /* ---------------- Worked examples ---------------- */

      var RISKY = [
        '# Restart the payments worker',
        '',
        '1. Check the dashboard.',
        '2. Run kubectl delete pod -l app=payments-worker -n payments.',
        '3. Wait a bit and see if errors stop.'
      ].join('\n');

      function cleanExample(){
        var ref = refDate();
        var verified = new Date(ref.getTime() - 30*24*60*60*1000);
        var lines = [
          '# Payments worker restart',
          '',
          'Use when: the PaymentsErrorRateHigh alert fires, or payments-worker pods are crash-looping after a deploy and the symptom is failed checkouts.',
          '',
          '## Prerequisites',
          '- kubectl access to the production cluster with the payments namespace role (role: payments-operator).',
          '- The payments deploy dashboard open, and a second responder aware that a restart is starting.',
          '',
          '## Steps',
          '1. Record the current replica state: run `kubectl get deployment/payments-worker -n payments` and note the replica count.',
          '2. Restart the worker: run `kubectl rollout restart deployment/payments-worker -n payments`.',
          '3. Watch the rollout finish: run `kubectl rollout status deployment/payments-worker -n payments --timeout=180s`.',
          '',
          '## Verification',
          'Success signal: error rate below 0.1% for 10 minutes on the payments dashboard, and `kubectl get pods -n payments -l app=payments-worker` shows every pod Running with 0 restarts in the last 5 minutes.',
          '',
          '## Rollback',
          'If verification fails, roll back the restart of payments-worker: run `kubectl rollout undo deployment/payments-worker -n payments`, then repeat the verification above.',
          '',
          'Escalation: if the rollback fails or errors continue for 15 minutes, page the payments on-call rotation in #payments-oncall and hand off to the incident commander.',
          '',
          'Owner: Payments platform team.',
          'Last verified: ' + isoOf(verified) + '.',
          'Estimated total time: about 25 minutes.'
        ];
        return lines.join('\n');
      }

      /* ---------------- Audit engine ---------------- */

      var DESTRUCTIVE_RE = /\b(delete|deleted|drop|truncate|kill|restart|failover|flush|purge|terminate|reboot|disable)\b|\bscale\s+(down|in|to\s+0)\b/i;
      var TRIGGER_RE = /\b(use when|when to use|use this runbook|use if|trigger|symptom|alert|run this (when|if))\b/i;
      var PREREQ_RE = /\b(prerequisites?|prereqs?|before you (start|begin)|you (will )?need|required (access|tools?|permissions?|roles?)|requirements?|preconditions?|access required)\b/i;
      var VERIFY_RE = /(verification|verify|verified when|success (criteria|signal)|smoke test|health ?check|expected (output|result)|error rate|latency|below\s+\d|under\s+\d|<\s?\d|returns?\s+(200|ok)\b|healthy)/i;
      var ESCALATION_RE = /\b(escalat\w*|on-call|on call|contact|page the|rotation|incident commander|slack|pagerduty)\b/i;
      var OWNER_RE = /\b(owner|owned by|maintainer|responsible team)\b/i;
      var DATELINE_RE = /\b(last (verified|reviewed|updated)|verified on|reviewed on|review date|last tested)\b/i;
      var TIME_RE = /(\b\d+\s*(minutes?|mins?|hours?|hrs?)\b|time estimate|estimated (total )?time|expected duration)/i;
      var VAGUE_RE = /(check the dashboard|look into|fix the|wait a bit|see if|check on|investigate|handle (the|it|this)|deal with|sort (it|this|out)|poke around|hope (it|that)|make sure (it|things|everything) (works?|is working))/i;
      var VAGUE_START_RE = /^(check|look|investigate|review|monitor|see|wait|fix|handle|ensure|make sure)\b/i;
      var CONCRETE_RE = /(`|kubectl|curl|systemctl|psql|mysql|aws\s|gcloud|az\s|helm|ssh\s|docker|terraform|SELECT\s|GET\s+http|https?:\/\/|\b\d+\s*(%|ms|s\b|seconds?|minutes?))/i;
      var ROLLBACK_RE = /\b(rollback|roll back|rollout undo|undo|revert|fail ?back)\b/i;
      var NEGATION_RE = /\b(do not|don't|never|avoid)\b/i;

      function isStepLine(line){
        var t = line.replace(/^\s+/, '');
        if(/^(step\s+)?\d+[\.\)]\s+\S/i.test(t)) return true;
        if(/^[-*]\s+\[[ xX]\]\s+\S/.test(t)) return true;
        if(/^step\s+\d+\s*[:\-]/i.test(t)) return true;
        return false;
      }
      function stepText(line){
        var t = line.replace(/^\s+/, '');
        t = t.replace(/^(step\s+)?\d+[\.\)]\s+/i, '');
        t = t.replace(/^[-*]\s+\[[ xX]\]\s+/, '');
        t = t.replace(/^step\s+\d+\s*[:\-]\s*/i, '');
        return t;
      }
      function isHeading(line){ return /^\s*#{1,6}\s/.test(line) || /^\s*(steps?|procedure|prerequisites?|rollback|verification|escalation)\s*:?\s*$/i.test(line); }

      function parseDateIn(text){
        var m = text.match(/(\d{4})-(\d{2})-(\d{2})/);
        if(m){ return new Date(parseInt(m[1],10), parseInt(m[2],10)-1, parseInt(m[3],10)); }
        m = text.match(/\b(January|February|March|April|May|June|July|August|September|October|November|December)\s+(\d{1,2}),?\s+(\d{4})/i);
        if(m){
          var months = {january:0,february:1,march:2,april:3,may:4,june:5,july:6,august:7,september:8,october:9,november:10,december:11};
          return new Date(parseInt(m[3],10), months[m[1].toLowerCase()], parseInt(m[2],10));
        }
        m = text.match(/\b(\d{1,2})\/(\d{1,2})\/(\d{4})\b/);
        if(m){ return new Date(parseInt(m[3],10), parseInt(m[1],10)-1, parseInt(m[2],10)); }
        return null;
      }

      var STOPWORDS = { 'the':1,'and':1,'with':1,'from':1,'this':1,'that':1,'then':1,'into':1,'onto':1,'your':1,'you':1,'run':1,'using':1,'use':1,'for':1,'all':1,'are':1,'was':1,'will':1,'should':1,'after':1,'before':1,'when':1,'what':1,'kubectl':1,'deployment':1,'deployments':1,'service':1,'services':1,'namespace':1,'cluster':1,'command':1,'line':1,'step':1,'steps':1 };
      function strongTokens(line){
        var out = [], seen = {};
        var lower = line.toLowerCase();
        var m, re;
        re = /[a-z0-9]+(?:[-_][a-z0-9]+)+/g;
        while((m = re.exec(lower)) !== null){ if(!seen[m[0]]){ seen[m[0]]=1; out.push(m[0]); } }
        re = /(?:app=|deployment\/|service\/|name=)([a-z0-9][a-z0-9\-]*)/g;
        while((m = re.exec(lower)) !== null){ if(!seen[m[1]]){ seen[m[1]]=1; out.push(m[1]); } }
        return out;
      }
      function plainTokens(line){
        var out = [], seen = {};
        var words = line.toLowerCase().replace(/[^a-z0-9\s\-]/g,' ').split(/\s+/);
        for(var i=0;i<words.length;i++){
          var w = words[i];
          if(w.length>=5 && !STOPWORDS[w] && !seen[w]){ seen[w]=1; out.push(w); }
        }
        return out;
      }

      function audit(text){
        var lines = text.split(/\r?\n/);
        var findings = [];   // {sev, tag, line (1-based or null), msg, reportMsg}
        var score = [];      // {part, status, evidence}
        var blockers = 0, warnings = 0;

        function addFinding(sev, tag, line, msg){
          findings.push({sev:sev, tag:tag, line:line, msg:msg});
          if(sev==='BLOCKER') blockers++;
          if(sev==='WARNING' || sev==='WEAK') warnings++;
        }
        function findLine(re, fromIdx, toIdx){
          var s = (fromIdx==null?0:fromIdx), e = (toIdx==null?lines.length:toIdx);
          for(var i=s;i<e;i++){ if(re.test(lines[i])) return i; }
          return -1;
        }
        function snippet(i){ var t = lines[i].trim(); return t.length>110 ? t.slice(0,107)+'…' : t; }

        // Step lines
        var stepIdx = [];
        for(var i=0;i<lines.length;i++){ if(isStepLine(lines[i])) stepIdx.push(i); }
        var firstStep = stepIdx.length ? stepIdx[0] : -1;

        // Rollback section spans (heading-based) + rollback corpus
        var inRollback = false, rollbackSectionStart = -1;
        var rollbackLineIdx = {};
        for(var j=0;j<lines.length;j++){
          var L = lines[j];
          if(/^\s*#{1,6}\s/.test(L)){
            inRollback = ROLLBACK_RE.test(L);
            if(inRollback && rollbackSectionStart<0) rollbackSectionStart = j;
          } else if(inRollback && /^\s*#{1,6}\s/.test(L)){
            inRollback = false;
          }
          if(inRollback) rollbackLineIdx[j] = true;
          if(ROLLBACK_RE.test(L)) rollbackLineIdx[j] = true;
        }
        var rollbackCorpus = '';
        for(var k in rollbackLineIdx){ rollbackCorpus += lines[k].toLowerCase() + '\n'; }
        var hasRollback = rollbackCorpus.trim().length > 0;

        /* 1. Trigger */
        var tIdx = findLine(TRIGGER_RE);
        if(tIdx >= 0){
          score.push({part:'Trigger / symptom', status:'PRESENT', evidence:'Line '+(tIdx+1)+': '+snippet(tIdx)});
        } else {
          score.push({part:'Trigger / symptom', status:'MISSING', evidence:'No “use when”, alert, symptom, or trigger statement found anywhere.'});
          addFinding('WARNING','WARNING',null,'No trigger or symptom: the runbook never says when to use it (no alert name, symptom, or “use when” line).');
        }

        /* 2. Prerequisites */
        var pIdx = findLine(PREREQ_RE);
        if(pIdx >= 0 && (firstStep < 0 || pIdx < firstStep)){
          score.push({part:'Prerequisites', status:'PRESENT', evidence:'Line '+(pIdx+1)+': '+snippet(pIdx)});
        } else if(pIdx >= 0){
          score.push({part:'Prerequisites', status:'WEAK', evidence:'Line '+(pIdx+1)+' lists prerequisites, but only after the steps begin (first step is line '+(firstStep+1)+').'});
          addFinding('WEAK','WEAK',pIdx+1,'Prerequisites appear after the steps begin — a responder may already be mid-procedure before learning what access or tools are required.');
        } else {
          score.push({part:'Prerequisites', status:'MISSING', evidence:'No prerequisites, required access, roles, or preconditions found.'});
          addFinding('WARNING','WARNING',null,'No prerequisites: required access, roles, tools, or preconditions are never listed.');
        }

        /* 3. Steps */
        var weakSteps = [];
        if(stepIdx.length === 0){
          score.push({part:'Steps', status:'MISSING', evidence:'No numbered or clearly sequenced steps found.'});
          addFinding('BLOCKER','BLOCKER',null,'No steps: there are no numbered or clearly sequenced steps to follow.');
        } else {
          for(var s=0;s<stepIdx.length;s++){
            var si = stepIdx[s], st = stepText(lines[si]);
            var vague = VAGUE_RE.test(st) || VAGUE_START_RE.test(st);
            var concrete = CONCRETE_RE.test(lines[si]);
            if(vague && !concrete) weakSteps.push(si);
          }
          if(weakSteps.length){
            score.push({part:'Steps', status:'WEAK', evidence:stepIdx.length+' step(s) found; '+weakSteps.length+' vague (line'+(weakSteps.length>1?'s ':' ')+weakSteps.map(function(x){return x+1;}).join(', ')+').'});
            for(var w=0;w<weakSteps.length;w++){
              addFinding('WEAK','WEAK STEP',weakSteps[w]+1,'Vague step with no command, query, or concrete action: “'+snippet(weakSteps[w])+'”');
            }
          } else {
            score.push({part:'Steps', status:'PRESENT', evidence:stepIdx.length+' sequenced step(s); first at line '+(stepIdx[0]+1)+': '+snippet(stepIdx[0])});
          }
        }

        /* 4. Destructive steps */
        var destructive = [];
        for(var d=0;d<lines.length;d++){
          if(rollbackLineIdx[d]) continue;
          if(isHeading(lines[d]) && !isStepLine(lines[d])) continue;
          if(NEGATION_RE.test(lines[d])) continue;
          var dm = lines[d].match(DESTRUCTIVE_RE);
          if(dm) destructive.push({idx:d, op:dm[0]});
        }
        for(var dd=0;dd<destructive.length;dd++){
          addFinding('INFO','DESTRUCTIVE STEP',destructive[dd].idx+1,'Destructive operation (“'+destructive[dd].op+'”): “'+snippet(destructive[dd].idx)+'”');
        }

        /* 5. Rollback coverage */
        var uncovered = [];
        var coveredCount = 0;
        if(destructive.length){
          for(var c=0;c<destructive.length;c++){
            var dline = lines[destructive[c].idx];
            var strong = strongTokens(dline);
            var covered = false, via = '';
            for(var t=0;t<strong.length;t++){
              if(rollbackCorpus.indexOf(strong[t]) >= 0){ covered = true; via = strong[t]; break; }
            }
            if(!covered && strong.length===0){
              var plain = plainTokens(dline);
              for(var t2=0;t2<plain.length;t2++){
                if(rollbackCorpus.indexOf(plain[t2]) >= 0){ covered = true; via = plain[t2]; break; }
              }
            }
            if(covered){ coveredCount++; destructive[c].via = via; }
            else uncovered.push(destructive[c]);
          }
        }
        if(!hasRollback && destructive.length){
          score.push({part:'Rollback coverage', status:'MISSING', evidence:'No rollback, undo, or revert text found, but '+destructive.length+' destructive step(s) exist.'});
          addFinding('BLOCKER','BLOCKER',null,'No rollback exists, but the runbook contains destructive steps. There is no stated way back.');
        } else if(!hasRollback && !destructive.length){
          score.push({part:'Rollback coverage', status:'MISSING', evidence:'No rollback, undo, or revert text found (no destructive steps either).'});
          addFinding('WARNING','WARNING',null,'No rollback or undo guidance exists. Nothing destructive was found, so this is a warning, not a blocker — but any change made by hand still needs a way back.');
        } else if(destructive.length && coveredCount===0){
          score.push({part:'Rollback coverage', status:'WEAK', evidence:'Rollback text exists'+(rollbackSectionStart>=0?' (line '+(rollbackSectionStart+1)+')':'')+' but references none of the '+destructive.length+' destructive step(s).'});
          addFinding('WARNING','WARNING',rollbackSectionStart>=0?rollbackSectionStart+1:null,'A rollback section exists but covers nothing: it never references the object or action of any destructive step it is supposed to undo.');
        } else if(destructive.length && uncovered.length){
          score.push({part:'Rollback coverage', status:'WEAK', evidence:coveredCount+' of '+destructive.length+' destructive step(s) covered by rollback text; gaps at line(s) '+uncovered.map(function(u){return u.idx+1;}).join(', ')+'.'});
        } else if(destructive.length){
          score.push({part:'Rollback coverage', status:'PRESENT', evidence:'Rollback text covers all '+destructive.length+' destructive step(s) (shared object/action named in the rollback text).'});
        } else {
          score.push({part:'Rollback coverage', status:'PRESENT', evidence:'Rollback text present'+(rollbackSectionStart>=0?' (line '+(rollbackSectionStart+1)+')':'')+'; no destructive steps require coverage.'});
        }
        for(var u=0;u<uncovered.length;u++){
          addFinding('BLOCKER','ROLLBACK GAP',uncovered[u].idx+1,'Destructive step is not covered by any rollback text: “'+snippet(uncovered[u].idx)+'”'+(hasRollback?'':' (No rollback exists at all.)'));
        }

        /* 6. Verification */
        var vIdx = findLine(VERIFY_RE);
        var rollbackLacks = destructive.length>0 && uncovered.length>0;
        if(vIdx >= 0){
          score.push({part:'Verification', status:'PRESENT', evidence:'Line '+(vIdx+1)+': '+snippet(vIdx)});
        } else if(rollbackLacks){
          score.push({part:'Verification', status:'MISSING', evidence:'No metric/threshold, health check, smoke test, or expected output found anywhere.'});
          addFinding('BLOCKER','BLOCKER',null,'No verification signal anywhere — and destructive steps already lack rollback. A responder cannot tell whether the procedure worked or made things worse.');
        } else {
          score.push({part:'Verification', status:'MISSING', evidence:'No metric/threshold, health check, smoke test, or expected output found anywhere.'});
          addFinding('WARNING','WARNING',null,'No verification: no concrete success signal (metric and threshold, health check, smoke test, or expected output) appears anywhere in the runbook.');
        }

        /* 7. Escalation */
        var eIdx = findLine(ESCALATION_RE);
        if(eIdx >= 0){
          score.push({part:'Escalation', status:'PRESENT', evidence:'Line '+(eIdx+1)+': '+snippet(eIdx)});
        } else {
          score.push({part:'Escalation', status:'MISSING', evidence:'No named person, team, rotation, or contact path found.'});
          addFinding('WARNING','WARNING',null,'No escalation path: no named person, team, rotation, or contact for when this runbook fails.');
        }

        /* 8. Ownership & freshness */
        var oIdx = findLine(OWNER_RE);
        if(oIdx >= 0){
          score.push({part:'Owner', status:'PRESENT', evidence:'Line '+(oIdx+1)+': '+snippet(oIdx)});
        } else {
          score.push({part:'Owner', status:'MISSING', evidence:'No owner named.'});
          addFinding('WARNING','WARNING',null,'No owner: nobody is named as responsible for this runbook.');
        }
        var dateIdx = -1, dateVal = null;
        for(var di=0;di<lines.length;di++){
          if(DATELINE_RE.test(lines[di])){ var pd = parseDateIn(lines[di]); if(pd){ dateIdx = di; dateVal = pd; break; } }
        }
        if(dateVal){
          var ref = refDate(); ref.setHours(0,0,0,0);
          var dv = new Date(dateVal.getTime()); dv.setHours(0,0,0,0);
          var diffDays = Math.round((ref.getTime() - dv.getTime()) / 86400000);
          var arith = 'Last verified/reviewed date '+isoOf(dv)+' vs reference date '+isoOf(ref)+': '+isoOf(ref)+' − '+isoOf(dv)+' = '+diffDays+' days.';
          if(diffDays < 0){
            score.push({part:'Last reviewed date', status:'WEAK', evidence:'Line '+(dateIdx+1)+': '+snippet(dateIdx)+' — '+arith+' The date is after the reference date; check it.'});
            addFinding('WARNING','WARNING',dateIdx+1,'Freshness: '+arith+' A review date in the future relative to the reference date does not check out.');
          } else if(diffDays > 365){
            score.push({part:'Last reviewed date', status:'WEAK', evidence:'Line '+(dateIdx+1)+': '+snippet(dateIdx)+' — '+arith});
            addFinding('WARNING','STALE',dateIdx+1,'STALE: '+arith+' Older than 365 days — treat this runbook as out of date until it is re-verified.');
          } else if(diffDays > 180){
            score.push({part:'Last reviewed date', status:'WEAK', evidence:'Line '+(dateIdx+1)+': '+snippet(dateIdx)+' — '+arith});
            addFinding('WARNING','WARNING',dateIdx+1,'Stale: '+arith+' Older than 180 days.');
          } else {
            score.push({part:'Last reviewed date', status:'PRESENT', evidence:'Line '+(dateIdx+1)+': '+snippet(dateIdx)+' — '+arith+' Within 180 days.'});
          }
        } else {
          score.push({part:'Last reviewed date', status:'MISSING', evidence:'No last-verified / last-reviewed date found.'});
          addFinding('WARNING','WARNING',null,'No last-reviewed or last-verified date: there is no way to tell whether this runbook is current.');
        }

        /* 9. Time estimates (INFO only) */
        var timeIdx = findLine(TIME_RE);
        if(timeIdx >= 0){
          score.push({part:'Time estimates', status:'PRESENT', evidence:'Line '+(timeIdx+1)+': '+snippet(timeIdx)});
        } else {
          score.push({part:'Time estimates', status:'MISSING', evidence:'No time estimate found. (Information only — never counted as a warning.)'});
          addFinding('INFO','INFO',null,'No time estimate for the procedure or its steps. Noted for information only — this never counts against the verdict.');
        }

        /* Verdict */
        var verdict, vclass;
        if(blockers > 0){ verdict = 'DO NOT RUN BLIND'; vclass = 'blind'; }
        else if(warnings > 0){ verdict = 'FOLLOW WITH GAPS'; vclass = 'gaps'; }
        else { verdict = 'READY TO FOLLOW'; vclass = 'ready'; }

        return { verdict:verdict, vclass:vclass, score:score, findings:findings, blockers:blockers, warnings:warnings, lines:lines.length };
      }

      /* ---------------- Rendering ---------------- */

      function esc(s){
        return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
      }

      function runAudit(){
        copyStatus.textContent = '';
        var text = runbookEl.value;
        if(!text || !text.trim()){
          resultsEl.style.display = 'none';
          emptyEl.style.display = 'block';
          lastReport = '';
          return;
        }
        emptyEl.style.display = 'none';
        var r = audit(text);

        var sub = r.blockers+' blocker(s), '+r.warnings+' warning(s)/weak item(s) across '+r.lines+' line(s). Heuristic text audit — completeness on paper, not correctness of the commands.';
        verdictEl.className = 'verdict ' + r.vclass;
        verdictEl.innerHTML = esc(r.verdict) + '<small>'+esc(sub)+'</small>';

        var rows = '';
        for(var i=0;i<r.score.length;i++){
          var sc = r.score[i];
          rows += '<tr><td>'+esc(sc.part)+'</td><td class="status '+sc.status.toLowerCase()+'">'+sc.status+'</td><td class="evidence">'+esc(sc.evidence)+'</td></tr>';
        }
        scoreBody.innerHTML = rows;

        var items = '';
        if(!r.findings.length){
          items = '<li><span class="tag ok">OK</span>No gaps found by the checks.</li>';
        }
        for(var f=0;f<r.findings.length;f++){
          var fd = r.findings[f];
          var tagClass = fd.tag==='BLOCKER' ? 'blocker' : fd.tag==='ROLLBACK GAP' ? 'gap' : fd.tag==='DESTRUCTIVE STEP' ? 'destructive' : fd.tag==='WEAK STEP' || fd.tag==='WEAK' ? 'weak' : fd.tag==='INFO' ? 'info' : fd.tag==='STALE' ? 'warning' : 'warning';
          var lineRef = fd.line ? '<span class="lineref">Line '+fd.line+'</span> — ' : '';
          items += '<li><span class="tag '+tagClass+'">'+esc(fd.tag)+'</span>'+lineRef+esc(fd.msg)+'</li>';
        }
        findingsEl.innerHTML = items;

        // Plain-text report
        var out = [];
        out.push('J-Dawgs Runbook Readiness & Rollback Auditor™ — audit report');
        out.push('Reference date: ' + isoOf(refDate()));
        out.push('VERDICT: ' + r.verdict);
        out.push('Blockers: ' + r.blockers + ' · Warnings/weak: ' + r.warnings + ' · Lines audited: ' + r.lines);
        out.push('');
        out.push('SCORECARD');
        for(var a=0;a<r.score.length;a++){
          out.push('- ' + r.score[a].part + ': ' + r.score[a].status + ' — ' + r.score[a].evidence);
        }
        out.push('');
        out.push('FINDINGS');
        if(!r.findings.length) out.push('- None.');
        for(var b=0;b<r.findings.length;b++){
          var g = r.findings[b];
          out.push('- [' + g.tag + ']' + (g.line ? ' Line ' + g.line + ' — ' : ' ') + g.msg);
        }
        out.push('');
        out.push('Note: heuristic text audit. It grades the document\u2019s completeness and internal coverage, never whether the commands are correct for your system. A READY verdict means the runbook is complete on paper, not that the procedure is right.');
        lastReport = out.join('\n');
        reportBox.value = lastReport;

        resultsEl.style.display = 'block';
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-runbook-readiness-rollback-auditortm',
  name: 'J-Dawgs Runbook Readiness & Rollback Auditor',
  description: 'Paste a runbook or procedure; get one verdict (READY TO FOLLOW / FOLLOW WITH GAPS / DO NOT RUN BLIND) with a nine-part scorecard (trigger, prerequisites, steps, verification, rollback, escalation, owner, freshness, time estimates) — and every destructive step cross-checked against the rollback text,',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
