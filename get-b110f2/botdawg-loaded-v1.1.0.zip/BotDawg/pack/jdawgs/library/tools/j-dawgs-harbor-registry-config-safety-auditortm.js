'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Harbor Registry Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

  "use strict";

  var RISKY = [
    "# Risky Harbor config - example only",
    "hostname: harbor.example.local",
    "http:",
    "  port: 80",
    "harbor_admin_password: " + "Harbor" + "12345",
    "database:",
    "  type: postgresql",
    "  host: db.internal",
    "  password: db123",
    "  max_pool_size: 5",
    "redis:",
    "  host: redis.internal",
    "  port: 6379",
    "trivy:",
    "  skip_update: true",
    "  ignore_unfixed: true",
    "log:",
    "  level: debug",
    "this line is totally broken no colon or equals here"
  ].join("\n");

  var HARDENED = [
    "# Hardened Harbor config - example only",
    "hostname: harbor.example.com",
    "https:",
    "  port: 443",
    "  certificate: /data/cert/harbor.crt",
    "  private_key: /data/cert/harbor.key",
    "harbor_admin_password: Str0ng-Harbor-Admin-2026!",
    "database:",
    "  type: postgresql",
    "  host: db.internal",
    "  password: Db-Str0ng-Pass-2026-XYZ",
    "  max_pool_size: 100",
    "external_redis:",
    "  host: redis.internal",
    "  port: 6379",
    "  password: Redis-Str0ng-Pass-2026!",
    "data_volume: /data",
    "storage_service:",
    "  filesystem:",
    "    rootdirectory: /data/registry",
    "trivy:",
    "  skip_update: false",
    "  ignore_unfixed: false",
    "  insecure: false",
    "log:",
    "  level: info"
  ].join("\n");

  var KNOWN_DEFAULT = "Harbor" + "12345";

  var RECOGNIZABLE = {
    hostname:1, http:1, https:1, certificate:1, private_key:1,
    harbor_admin_password:1, database:1, external_database:1,
    redis:1, external_redis:1, data_volume:1, trivy:1,
    skip_update:1, ignore_unfixed:1, insecure:1,
    storage_service:1, storage:1, filesystem:1, s3:1,
    log:1, level:1, log_level:1, max_pool_size:1, max_pool:1,
    password:1, db_password:1, database_password:1, redis_password:1,
    proxy:1, port:1, host:1, type:1, rootdirectory:1, disable_redirect:1
  };

  var SECRET_KEY_RE = /password|secret|token|passwd/i;

  function cleanVal(v){
    v = (v || "").trim();
    if (v.length >= 2 && ((v.charAt(0)==='"' && v.charAt(v.length-1)==='"') || (v.charAt(0)==="'" && v.charAt(v.length-1)==="'"))) {
      v = v.slice(1, -1);
    }
    return v;
  }
  function isTrue(v){ return /^(true|yes|on)$/i.test(cleanVal(v)); }
  function isFalse(v){ return /^(false|no|off)$/i.test(cleanVal(v)); }

  function parseConfig(text){
    var lines = text.split(/\r?\n/);
    var entries = [];
    var malformed = [];
    var section = "";
    for (var i = 0; i < lines.length; i++){
      var raw = lines[i];
      var lineNo = i + 1;
      var trimmed = raw.trim();
      if (!trimmed) continue;
      if (trimmed.charAt(0) === "#") continue;
      var m = raw.match(/^(\s*)([A-Za-z0-9_\-\.]+)\s*[:=]\s*(.*)$/);
      if (!m){
        malformed.push({ line: lineNo, raw: raw });
        continue;
      }
      var indent = m[1].length;
      var key = m[2];
      var lkey = key.toLowerCase();
      if (indent === 0) section = lkey;
      entries.push({
        key: key, lkey: lkey, value: cleanVal(m[3]),
        rawValue: m[3], line: lineNo,
        section: indent === 0 ? lkey : section, indent: indent
      });
    }
    return { entries: entries, malformed: malformed, lines: lines };
  }

  function findEntry(entries, lkey, sectionContains){
    for (var i = 0; i < entries.length; i++){
      var e = entries[i];
      if (e.lkey === lkey && (!sectionContains || e.section.indexOf(sectionContains) !== -1)) return e;
    }
    return null;
  }
  function findAny(entries, lkeys){
    for (var j = 0; j < lkeys.length; j++){
      var e = findEntry(entries, lkeys[j]);
      if (e) return e;
    }
    return null;
  }

  function audit(text){
    var parsed = parseConfig(text);
    var entries = parsed.entries;
    var findings = [];
    function add(severity, key, line, message, fix){
      findings.push({ severity: severity, key: key, line: (typeof line === "number" ? line : null), message: message, fix: fix });
    }

    var recognized = 0;
    entries.forEach(function(e){ if (RECOGNIZABLE[e.lkey]) recognized++; });

    var trimmedText = text.trim();
    if (!trimmedText || recognized === 0){
      var reason = !trimmedText
        ? "The input is empty — there is nothing to grade."
        : "No recognizable Harbor keys were found in this text (looked for keys such as hostname, https, harbor_admin_password, database, redis, data_volume, trivy, storage_service, log). This looks like prose or a different file, not a Harbor config.";
      return {
        verdict: "NOT ENOUGH TO GRADE",
        note: reason + " Paste a harbor.yml or installer env text and audit again.",
        findings: [],
        malformed: parsed.malformed,
        recognized: recognized
      };
    }

    /* ---- Check 1: hostname + http/https + certificate pairing ---- */
    var hostEntry = findEntry(entries, "hostname");
    var httpsEntry = findEntry(entries, "https");
    var httpEntry = findEntry(entries, "http");
    var certEntry = findEntry(entries, "certificate");
    var keyEntry = findEntry(entries, "private_key");
    if (!hostEntry){
      add("critical", "hostname", null,
        "hostname is missing. Harbor cannot build correct registry URLs or TLS names without it, and a missing hostname usually means the config was never finished.",
        "Set hostname to the DNS name users and robots will reach the registry on.");
    } else if (/^http:\/\//i.test(hostEntry.value)){
      add("critical", "hostname", hostEntry.line,
        "hostname is written with an http:// address, so the registry is exposed over plain HTTP with credentials and tokens in the clear.",
        "Use the bare DNS name (or https://) and configure the https block with a certificate and private key.");
    }
    if (httpsEntry){
      var certOk = !!(certEntry && certEntry.value);
      var keyOk = !!(keyEntry && keyEntry.value);
      if (certOk && keyOk){
        add("pass", "https.certificate / https.private_key", httpsEntry.line,
          "https is configured with both a certificate path and a private_key path.",
          "No change. Confirm both files exist on the host and the certificate matches the hostname before installing.");
      } else {
        var missingParts = [];
        if (!certOk) missingParts.push("certificate");
        if (!keyOk) missingParts.push("private_key");
        add("critical", "https", httpsEntry.line,
          "https is declared but the " + missingParts.join(" and ") + " path is missing or empty. The installer will fail or fall back insecurely, and TLS cannot be served without the pair.",
          "Set both https.certificate and https.private_key to real files on the host, then re-audit.");
      }
    } else {
      add("critical", httpEntry ? "http" : "https", httpEntry ? httpEntry.line : (hostEntry ? hostEntry.line : null),
        "No https block was found — the registry would be served over plain http only. Logins, tokens, and image pulls cross the network unencrypted.",
        "Add an https block with port 443 plus certificate and private_key paths, and remove the http-only posture.");
    }

    /* ---- Check 2: harbor_admin_password ---- */
    var adminEntry = findEntry(entries, "harbor_admin_password");
    if (!adminEntry || !adminEntry.value){
      add("critical", "harbor_admin_password", adminEntry ? adminEntry.line : null,
        "harbor_admin_password is missing or empty. The built-in admin account would be unset or fall back to installer behavior you did not choose.",
        "Set harbor_admin_password to a unique value of at least 16 characters that is not used anywhere else.");
    } else if (adminEntry.value === KNOWN_DEFAULT){
      add("critical", "harbor_admin_password", adminEntry.line,
        "harbor_admin_password is the known default, length 12. Anyone who knows Harbor knows this value — the admin account is effectively open.",
        "Replace it with a unique value of at least 16 characters before the registry is reachable by anyone else.");
    } else if (adminEntry.value.length < 12){
      add("high", "harbor_admin_password", adminEntry.line,
        "harbor_admin_password is short — length " + adminEntry.value.length + " (under 12). The admin account is the highest-value target on the registry.",
        "Use a unique admin password of at least 16 characters.");
    } else if (adminEntry.value.length < 16){
      add("warning", "harbor_admin_password", adminEntry.line,
        "harbor_admin_password length is " + adminEntry.value.length + " — above the minimum, but short for the master admin account.",
        "Lengthen the admin password to at least 16 characters.");
    } else {
      add("pass", "harbor_admin_password", adminEntry.line,
        "harbor_admin_password is set, is not the known default, and has length " + adminEntry.value.length + " (16 or more). Value not shown.",
        "No change. Store it in your password manager and rotate it if it is ever shared.");
    }

    /* ---- Check 3: database password + max_pool ---- */
    var dbSection = findAny(entries, ["database", "external_database"]);
    var dbPw = null;
    for (var a = 0; a < entries.length; a++){
      var ea = entries[a];
      if ((ea.lkey === "password" && ea.section.indexOf("database") !== -1) || ea.lkey === "db_password" || ea.lkey === "database_password"){ dbPw = ea; break; }
    }
    if (!dbPw || !dbPw.value){
      add("high", "database.password", dbSection ? dbSection.line : null,
        "No database password was found. Harbor's core, registry, and jobservice all authenticate to this database; a missing password means a broken or unauthenticated database.",
        "Set a database password of at least 12 characters (16 or more preferred) and keep it only in this file and your vault.");
    } else if (dbPw.value.length < 12){
      add("high", dbPw.key, dbPw.line,
        "Database password is short — length " + dbPw.value.length + " (under 12). Value not shown.",
        "Use a database password of at least 16 characters.");
    } else {
      add("pass", dbPw.key, dbPw.line,
        "Database password is set with length " + dbPw.value.length + ". Value not shown.",
        "No change.");
    }
    var poolEntry = findAny(entries, ["max_pool_size", "max_pool"]);
    if (!poolEntry){
      add("warning", "max_pool_size", dbSection ? dbSection.line : null,
        "max_pool_size is not set for the database. Harbor will use its built-in default, which may not match your registry's load.",
        "Set max_pool_size explicitly (100 is a reasonable starting point for a small registry; valid range here is 10–500).");
    } else {
      var poolNum = Number(poolEntry.value);
      if (!/^\d+$/.test(poolEntry.value) || isNaN(poolNum)){
        add("warning", poolEntry.key, poolEntry.line,
          "max_pool_size is not a plain number, so the database pool size cannot be graded.",
          "Set max_pool_size to a whole number between 10 and 500.");
      } else if (poolNum < 10 || poolNum > 500){
        add("warning", poolEntry.key, poolEntry.line,
          "max_pool_size is " + poolNum + ", outside the sane 10–500 range — too small starves Harbor under load; too large can exhaust database connections.",
          "Set max_pool_size between 10 and 500 (100 is a reasonable default).");
      } else {
        add("pass", poolEntry.key, poolEntry.line,
          "max_pool_size is " + poolNum + ", inside the reasonable 10–500 range.",
          "No change.");
      }
    }

    /* ---- Check 4: redis / external secrets ---- */
    var extRedis = findEntry(entries, "external_redis");
    var extDb = findEntry(entries, "external_database");
    if (extRedis){
      add("info", "external_redis", extRedis.line,
        "An external Redis is configured. Harbor will depend on that service's availability and its own password posture.",
        "Confirm the external Redis requires authentication and is not reachable from untrusted networks.");
    }
    if (extDb){
      add("info", "external_database", extDb.line,
        "An external database is configured. Its backups, TLS, and password rotation are outside this file.",
        "Confirm the external database enforces TLS and that its password is rotated on your schedule.");
    }
    var redisSectionEntry = extRedis || findEntry(entries, "redis");
    var redisPw = null;
    for (var b = 0; b < entries.length; b++){
      var eb = entries[b];
      if ((eb.lkey === "password" && eb.section.indexOf("redis") !== -1) || eb.lkey === "redis_password"){ redisPw = eb; break; }
    }
    if (!redisPw || !redisPw.value){
      add("high", "redis.password", redisSectionEntry ? redisSectionEntry.line : null,
        "No Redis password was found. Harbor uses Redis for caching and job queues; an unauthenticated Redis reachable on the network can be read or poisoned.",
        "Set a Redis password of at least 16 characters, or confirm Redis is bound to localhost / a private network only — a password is still preferred.");
    } else if (redisPw.value.length < 12){
      add("high", redisPw.key, redisPw.line,
        "Redis password is short — length " + redisPw.value.length + " (under 12). Value not shown.",
        "Use a Redis password of at least 16 characters.");
    } else {
      add("pass", redisPw.key, redisPw.line,
        "Redis password is set with length " + redisPw.value.length + ". Value not shown.",
        "No change.");
    }
    var firstSecret = null;
    for (var c = 0; c < entries.length; c++){ if (SECRET_KEY_RE.test(entries[c].lkey) && entries[c].value){ firstSecret = entries[c]; break; } }
    if (firstSecret){
      add("info", firstSecret.key, firstSecret.line,
        "Secret keys appear as plaintext in this config text (that is how harbor.yml works). This report shows key name, line, and length only — never values.",
        "Restrict the config file's permissions (owner read/write only), keep it out of shared repos, and rotate any secret that has been pasted into chat or tickets.");
    }

    /* ---- Check 5: data_volume ---- */
    var dvEntry = findEntry(entries, "data_volume");
    if (!dvEntry || !dvEntry.value){
      add("warning", "data_volume", null,
        "data_volume is missing. Without an explicit data volume, registry data, database files, and certificates can land on ephemeral or installer-default paths and be lost on rebuilds.",
        "Set data_volume to a persistent path (for example /data) on backed-up storage.");
    } else {
      add("pass", "data_volume", dvEntry.line,
        "data_volume is set, so registry persistence has an explicit home.",
        "No change. Confirm the path is on persistent, backed-up storage.");
    }

    /* ---- Check 6: trivy posture ---- */
    var trivySection = findEntry(entries, "trivy");
    var skipEntry = findEntry(entries, "skip_update");
    var offlineMentioned = /offline/i.test(text);
    if (!skipEntry){
      add("info", "trivy.skip_update", trivySection ? trivySection.line : null,
        "trivy.skip_update was not found, so the scanner update posture cannot be confirmed from this text.",
        "Set trivy.skip_update explicitly: false for online installs, true only with a planned offline database update path.");
    } else if (isTrue(skipEntry.value)){
      if (offlineMentioned){
        add("info", "trivy.skip_update", skipEntry.line,
          "trivy.skip_update is true and the config mentions an offline posture — acceptable only if the vulnerability database is refreshed by another process.",
          "Confirm the offline Trivy database is updated on a schedule; a stale database silently misses new CVEs.");
      } else {
        add("warning", "trivy.skip_update", skipEntry.line,
          "trivy.skip_update is true with no offline note. The vulnerability database will go stale and scans will keep passing images with newly published CVEs.",
          "Set skip_update to false, or document and schedule an offline database update process.");
      }
    } else if (isFalse(skipEntry.value)){
      add("pass", "trivy.skip_update", skipEntry.line,
        "trivy.skip_update is false — the scanner will pull vulnerability database updates.",
        "No change.");
    } else {
      add("info", "trivy.skip_update", skipEntry.line,
        "trivy.skip_update has a value that is not a clear true/false, so its posture was not graded.",
        "Set skip_update to true or false explicitly.");
    }
    var iuEntry = findEntry(entries, "ignore_unfixed");
    if (iuEntry){
      if (isTrue(iuEntry.value)){
        add("warning", "trivy.ignore_unfixed", iuEntry.line,
          "trivy.ignore_unfixed is true — vulnerabilities with no available fix will be hidden from scan results, which can make risky images look clean.",
          "Set ignore_unfixed to false unless you have a written reason to hide unfixable findings.");
      } else if (isFalse(iuEntry.value)){
        add("pass", "trivy.ignore_unfixed", iuEntry.line,
          "trivy.ignore_unfixed is false — unfixable vulnerabilities stay visible in scan results.",
          "No change.");
      }
    }
    var insEntry = findEntry(entries, "insecure");
    if (insEntry){
      if (isTrue(insEntry.value)){
        add("warning", "trivy.insecure", insEntry.line,
          "A trivy insecure flag is true — the scanner will skip TLS verification when reaching its data sources.",
          "Set insecure to false and fix the underlying certificate or proxy issue instead.");
      } else if (isFalse(insEntry.value)){
        add("pass", "trivy.insecure", insEntry.line,
          "trivy insecure flag is false — TLS verification stays on for scanner traffic.",
          "No change.");
      }
    }

    /* ---- Check 7: storage + proxy posture ---- */
    var storageSection = findAny(entries, ["storage_service", "storage"]);
    var fsEntry = findEntry(entries, "filesystem");
    var s3Entry = findEntry(entries, "s3");
    if (!storageSection && !fsEntry && !s3Entry){
      add("warning", "storage_service", null,
        "No registry storage configuration was found. Image layers need an explicit filesystem or object-storage home, paired with data_volume.",
        "Configure storage_service — filesystem under data_volume for a single host, or s3-compatible storage for a scaled install.");
    } else if (fsEntry){
      add("pass", "storage_service.filesystem", fsEntry.line,
        "Registry storage uses the filesystem driver. That is a sound single-host posture when the root directory sits under data_volume.",
        "No change. Confirm the filesystem root directory is on the persistent data volume and is backed up.");
    } else if (s3Entry){
      add("info", "storage_service.s3", s3Entry.line,
        "Registry storage uses s3. Confirm the redirect / disable_redirect posture matches your clients and that bucket credentials are scoped to this registry only.",
        "Review s3 region, bucket, and redirect settings, and restrict the storage credentials to the registry bucket.");
    } else {
      add("info", "storage_service", storageSection.line,
        "A storage_service section is present, but no filesystem or s3 driver key was recognized in this text.",
        "Confirm the storage driver is set explicitly (filesystem or s3) before installing.");
    }
    var proxyEntry = findEntry(entries, "proxy");
    if (proxyEntry){
      add("info", "proxy", proxyEntry.line,
        "Proxy components are configured. Remote repositories will be pulled through Harbor's proxy cache.",
        "Confirm the proxy upstreams are the registries you intend, and that proxy credentials are not shared with other systems.");
    } else {
      add("info", "proxy", null,
        "No proxy section was found. That is normal for a standalone registry that does not proxy remote repositories.",
        "No change unless you planned to use Harbor as a pull-through cache.");
    }

    /* ---- Check 8: log level ---- */
    var lvlEntry = null;
    for (var d = 0; d < entries.length; d++){
      var ed = entries[d];
      if ((ed.lkey === "level" && ed.section.indexOf("log") !== -1) || ed.lkey === "log_level"){ lvlEntry = ed; break; }
    }
    if (!lvlEntry){
      add("info", "log.level", null,
        "No log level was found. Harbor will use its default level.",
        "Set log.level explicitly (info is a good production default) so logging behavior is a choice, not a surprise.");
    } else {
      var lvl = lvlEntry.value.toLowerCase();
      if (lvl === "debug"){
        add("warning", lvlEntry.key, lvlEntry.line,
          "Log level is debug. Debug logs are verbose and can capture request details, headers, and other sensitive material in plain log files.",
          "Set log level to info (or warn) for production; use debug only while troubleshooting, then turn it back.");
      } else if (lvl === "info" || lvl === "warn" || lvl === "warning" || lvl === "error"){
        add("pass", lvlEntry.key, lvlEntry.line,
          "Log level is " + lvl + " — a sane production level.",
          "No change.");
      } else {
        add("info", lvlEntry.key, lvlEntry.line,
          "Log level value was not one of the standard levels (debug / info / warn / error), so it was not graded further.",
          "Use a standard log level — info for production.");
      }
    }

    /* ---- Verdict ---- */
    var counts = { critical: 0, high: 0, warning: 0, pass: 0, info: 0, not_parsed: parsed.malformed.length };
    findings.forEach(function(f){ if (counts.hasOwnProperty(f.severity)) counts[f.severity]++; });
    var verdict, note;
    if (counts.critical > 0){
      verdict = "DO NOT DEPLOY";
      note = counts.critical + " critical finding(s) must be fixed before this registry is installed or exposed. Fix the critical items, then re-audit.";
    } else if (counts.high > 0 || counts.warning > 0){
      verdict = "DEPLOY WITH FIXES";
      note = "No critical findings, but " + (counts.high + counts.warning) + " high/warning item(s) should be fixed before this registry handles real images or users.";
    } else {
      verdict = "SAFE TO DEPLOY";
      note = "All graded checks passed (info notes only). This verdict covers the config text — confirm certificates, file permissions, and backups on the host itself.";
    }
    return { verdict: verdict, note: note, findings: findings, malformed: parsed.malformed, counts: counts, recognized: recognized };
  }

  function snippetFor(raw){
    if (/password|secret|token|passwd|private/i.test(raw)) return "[redacted]";
    var s = raw.trim();
    return s.length > 48 ? s.slice(0, 48) + "…" : s;
  }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-harbor-registry-config-safety-auditortm',
  name: 'J-Dawgs Harbor Registry Config Safety Auditor',
  description: 'Grades a pasted Harbor harbor.yml fully offline into one deploy verdict — http vs https, the default admin password, plaintext database and Redis passwords, and Trivy scanner posture — with secrets shown by key name, line, and length only, never by value.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
