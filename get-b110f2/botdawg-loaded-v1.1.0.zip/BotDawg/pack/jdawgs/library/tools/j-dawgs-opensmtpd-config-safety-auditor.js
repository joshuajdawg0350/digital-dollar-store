'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs OpenSMTPD Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var RISKY = [
          "# Risky example — an internet-facing open relay",
          'table aliases file:/etc/mail/aliases',
          "",
          "listen on all",
          "",
          'action "relay_out" relay',
          "",
          "match from any for any action \"relay_out\""
        ].join("\n");

        var HARDENED = [
          "# Hardened example — localhost delivery + authenticated submission",
          'pki mail.example.com cert "/etc/ssl/mail.example.com.crt"',
          'pki mail.example.com key "/etc/ssl/private/mail.example.com.key"',
          "",
          'table aliases file:/etc/mail/aliases',
          'table credentials passwd:/etc/mail/credentials',
          "",
          "listen on lo0",
          "listen on egress port submission tls-require auth <credentials> pki mail.example.com",
          "listen on egress port smtps tls pki mail.example.com auth <credentials>",
          "",
          'action "local_mail" mbox alias <aliases>',
          'action "relay_out" relay',
          "",
          'match from local for local action "local_mail"',
          'match auth from any for any action "relay_out"',
          "",
          "queue encryption",
          "queue compression",
          "bounce warn-interval 4h",
          "mta max-message-size 35M"
        ].join("\n");

        var SEV_ORDER = { critical: 0, high: 1, medium: 2, info: 3 };
        var SEV_LABEL = { critical: "Critical", high: "High", medium: "Medium", info: "Info" };

        // Strip a trailing comment (# ...) that is not inside quotes.
        function stripComment(line) {
          var inQ = false;
          for (var i = 0; i < line.length; i++) {
            var c = line.charAt(i);
            if (c === '"') inQ = !inQ;
            else if (c === "#" && !inQ) return line.slice(0, i);
          }
          return line;
        }

        // Tokenize respecting double quotes.
        function tokenize(line) {
          var tokens = [];
          var cur = "";
          var inQ = false;
          var has = false;
          for (var i = 0; i < line.length; i++) {
            var c = line.charAt(i);
            if (c === '"') {
              inQ = !inQ;
              has = true;
            } else if (!inQ && /\s/.test(c)) {
              if (has || cur.length) { tokens.push(cur); cur = ""; has = false; }
            } else {
              cur += c;
            }
          }
          if (has || cur.length) tokens.push(cur);
          return tokens;
        }

        function audit(text) {
          var rawLines = text.split(/\r?\n/);
          var findings = [];
          var unparsed = [];
          function add(sev, line, title, detail, fix) {
            findings.push({ severity: sev, line: line, title: title, detail: detail, fix: fix });
          }

          var listens = [];
          var actions = {};       // name -> {type, line, hasAuth, host}
          var matchRules = [];     // {line, fromKind, auth, actionName, raw}
          var tables = {};         // name -> {line, type}
          var pkiNames = {};
          var hasPki = false;
          var hasQueueEncryption = false;
          var hasQueueCompression = false;

          var KNOWN_FIRST = {
            "listen": 1, "action": 1, "match": 1, "table": 1, "pki": 1,
            "queue": 1, "bounce": 1, "mta": 1, "filter": 1, "smtp": 1,
            "include": 1
          };

          for (var i = 0; i < rawLines.length; i++) {
            var lineNo = i + 1;
            var raw = rawLines[i];
            var line = stripComment(raw).trim();
            if (!line) continue;
            var tokens = tokenize(line);
            if (!tokens.length) continue;
            var first = tokens[0].toLowerCase();
            if (!KNOWN_FIRST[first]) {
              unparsed.push(lineNo);
              continue;
            }

            if (first === "listen") {
              var rec = {
                line: lineNo,
                iface: null, port: null,
                tls: false, tlsRequire: false, smtps: false,
                auth: false, hasPki: false
              };
              for (var t = 1; t < tokens.length; t++) {
                var tok = tokens[t].toLowerCase();
                if (tok === "on" && t + 1 < tokens.length) { rec.iface = tokens[t + 1].toLowerCase(); t++; }
                else if (tok === "port" && t + 1 < tokens.length) { rec.port = tokens[t + 1].toLowerCase(); t++; }
                else if (tok === "tls") rec.tls = true;
                else if (tok === "tls-require") { rec.tlsRequire = true; rec.tls = true; }
                else if (tok === "smtps") { rec.smtps = true; rec.tls = true; }
                else if (tok === "auth") rec.auth = true;
                else if (tok === "pki") rec.hasPki = true;
              }
              if (rec.port === "smtps") { rec.smtps = true; rec.tls = true; }
              if (rec.port === "587") rec.port = "submission";
              if (rec.port === "465") { rec.port = "smtps"; rec.smtps = true; rec.tls = true; }
              if (rec.port === "25") rec.port = "smtp";
              listens.push(rec);
            } else if (first === "action") {
              var name = tokens[1] || "(unnamed)";
              var a = { type: null, line: lineNo, hasAuth: false, host: null };
              for (var u = 2; u < tokens.length; u++) {
                var at = tokens[u].toLowerCase();
                if (at === "relay" || at === "mbox" || at === "maildir" || at === "lmtp" || at === "mda") {
                  if (!a.type) a.type = at;
                }
                if (at === "auth") a.hasAuth = true;
                if (at === "host" && u + 1 < tokens.length) a.host = tokens[u + 1];
              }
              actions[name] = a;
            } else if (first === "match") {
              var m = { line: lineNo, fromKind: null, auth: false, actionName: null };
              for (var v = 1; v < tokens.length; v++) {
                var mt = tokens[v].toLowerCase();
                if (mt === "auth") m.auth = true;
                if (mt === "from" && v + 1 < tokens.length) {
                  var fv = tokens[v + 1].toLowerCase();
                  if (fv === "any" || fv === "local" || fv === "socket") m.fromKind = fv;
                  v++;
                }
                if (mt === "action" && v + 1 < tokens.length) { m.actionName = tokens[v + 1]; v++; }
              }
              matchRules.push(m);
            } else if (first === "table") {
              var tname = tokens[1] || "(unnamed)";
              var ttype = (tokens[2] || "").toLowerCase();
              tables[tname] = { line: lineNo, type: ttype };
              if (/cred|passwd|secret|auth/.test(tname.toLowerCase()) || /passwd:/.test(ttype)) {
                add("info", lineNo,
                  "Credential table referenced: “" + tname + "”",
                  "Line " + lineNo + " references a credentials table by name. Only the key name and line are reported — secret values are never shown.",
                  "Keep the credentials file readable only by the smtpd user and never commit it to a shared repository.");
              }
            } else if (first === "pki") {
              hasPki = true;
              if (tokens[1]) pkiNames[tokens[1]] = lineNo;
            } else if (first === "queue") {
              var sub = (tokens[1] || "").toLowerCase();
              if (sub === "encryption") hasQueueEncryption = true;
              if (sub === "compression") hasQueueCompression = true;
            }
          }

          if (!listens.length && !Object.keys(actions).length && !matchRules.length && text.trim()) {
            // Input present but nothing recognizable at all beyond unparsed lines.
          }

          // --- Open relay posture ---
          var relayActionNames = {};
          Object.keys(actions).forEach(function (n) {
            if (actions[n].type === "relay") relayActionNames[n] = true;
          });
          matchRules.forEach(function (mr) {
            if (mr.actionName && relayActionNames[mr.actionName]) {
              if (mr.fromKind === "any" && !mr.auth) {
                add("critical", mr.line,
                  "Open relay: unauthenticated relaying from any source",
                  "This match rule sends mail from any sender to relay action “" + mr.actionName + "” with no auth requirement. Anyone on the internet can relay through this server — it will be found and abused for spam within hours.",
                  "Require authentication on the rule (match auth …) or restrict it to local senders (match from local …).");
              } else if (mr.fromKind === "local" && !mr.auth) {
                add("info", mr.line,
                  "Relay restricted to local senders",
                  "Relaying is limited to local sources without auth, which is the normal posture for a host relaying its own mail.",
                  "No change needed. If outside users must relay, add an authenticated submission listener instead of widening this rule.");
              } else if (mr.auth) {
                add("info", mr.line,
                  "Relay requires authentication",
                  "This relay rule only fires for authenticated senders — the safe pattern for remote relaying.",
                  "No change needed.");
              }
            }
          });
          Object.keys(actions).forEach(function (n) {
            var a = actions[n];
            if (a.type === "relay") {
              var used = matchRules.some(function (mr) { return mr.actionName === n; });
              if (!used) {
                add("high", a.line,
                  "Relay action “" + n + "” is defined but never gated by a match rule",
                  "A relay action with no match rule referencing it cannot be evaluated for sender restrictions from this config.",
                  "Add explicit match rules for this action — authenticated or local senders only — or remove the unused action.");
              }
            }
          });

          // --- Listener exposure & TLS / auth posture ---
          var hasInternetListener = false;
          listens.forEach(function (L) {
            var allIface = (L.iface === "all" || L.iface === "*");
            var localIface = (L.iface === "lo0" || L.iface === "localhost");
            if (!localIface) hasInternetListener = true;
            var where = "line " + L.line;

            if (allIface && L.port !== "submission" && L.port !== "smtps") {
              add("high", L.line,
                "Listener bound to all interfaces",
                "This listen directive binds every network interface (" + where + "). Combined with a relay action, that is maximum exposure.",
                "Bind to a specific interface (for example “listen on egress …” or “listen on lo0”) so the daemon only answers where it should.");
            }
            if (L.port === "submission") {
              if (!L.auth) {
                add("critical", L.line,
                  "Submission port accepts mail without authentication",
                  "Port 587 (submission) is where outside users hand in mail. Without “auth”, anyone can submit — an open relay by the side door.",
                  "Add “auth <credentials>” (backed by a credentials table) to the submission listener.");
              }
              if (!L.tlsRequire && !L.tls) {
                add("high", L.line,
                  "Submission port does not require TLS",
                  "Credentials and message bodies cross this listener in cleartext unless TLS is required.",
                  "Add “tls-require” to the submission listener so authentication never happens over a plaintext connection.");
              } else if (L.tls && !L.tlsRequire) {
                add("medium", L.line,
                  "Submission TLS is optional, not required",
                  "“tls” offers encryption but still permits plaintext sessions, including plaintext authentication.",
                  "Change “tls” to “tls-require” on the submission listener.");
              }
            }
            if (L.port === "smtps") {
              if (!L.auth) {
                add("medium", L.line,
                  "SMTPS listener has no authentication requirement",
                  "Port 465 with implicit TLS but no “auth” accepts submissions from anyone who connects.",
                  "Add “auth <credentials>” to the smtps listener if it is used for submission, or remove it if it is not needed.");
              }
            }
            if ((L.port === "smtp" || L.port === null) && !localIface && L.auth) {
              add("info", L.line,
                "Port 25 listener requires auth",
                "Requiring auth on the public SMTP port is stricter than usual — fine for a submission-only host, but it will refuse ordinary inbound mail from other servers.",
                "Leave as-is for a submission-only host; remove “auth” here if this host must receive mail from the internet.");
            }
          });

          if (hasInternetListener && !hasPki) {
            add("high", null,
              "No PKI / certificate configured for an internet-facing server",
              "No “pki” directive appears anywhere in the config, yet at least one listener faces beyond localhost. The server cannot offer TLS with its own certificate.",
              "Add “pki <hostname> cert …” and “pki <hostname> key …” directives and reference the PKI name on each external listener.");
          }
          if (hasInternetListener && hasPki) {
            listens.forEach(function (L) {
              var localIface = (L.iface === "lo0" || L.iface === "localhost");
              if (!localIface && !L.tls && L.port !== "smtp" && L.port !== null) {
                add("medium", L.line,
                  "External listener offers no TLS despite a configured certificate",
                  "A PKI is configured, but this listener never enables TLS, so its sessions stay in cleartext.",
                  "Add “tls” (or “tls-require” for submission) plus “pki <hostname>” to this listener.");
              }
            });
          }
          if (!hasInternetListener && listens.length) {
            add("info", null,
              "All listeners are local-only",
              "Every listen directive binds localhost / lo0. This host cannot be reached from the network, which is the lowest-exposure posture.",
              "No change needed.");
          }

          // --- Match rule breadth beyond relay ---
          matchRules.forEach(function (mr) {
            if (mr.fromKind === "any" && !mr.auth && mr.actionName && !relayActionNames[mr.actionName]) {
              add("medium", mr.line,
                "Broad match rule: “from any” without auth",
                "This rule accepts mail from any source for a non-relay action without authentication. That is normal for inbound delivery to local domains, but worth confirming it is intentional.",
                "Confirm the destination action only delivers to domains this host owns; otherwise restrict the rule.");
            }
          });

          // --- Queue / crypto / limits posture ---
          if (hasQueueEncryption) {
            add("info", null, "Queue encryption is enabled",
              "“queue encryption” encrypts spooled mail at rest — good posture for a host that queues other people's messages.",
              "No change needed.");
          } else if (text.trim()) {
            add("medium", null, "Queue encryption is not enabled",
              "No “queue encryption” directive was found, so spooled messages sit on disk in cleartext.",
              "Add “queue encryption” (with a managed queue key) if this host queues mail for others.");
          }
          if (!hasQueueCompression && text.trim()) {
            add("info", null, "Queue compression is not enabled",
              "No “queue compression” directive was found. Not a safety issue — it only affects spool disk usage.",
              "Optional: add “queue compression” on busy relays to save spool space.");
          }

          // --- NOT PARSED lines ---
          unparsed.forEach(function (ln) {
            add("info", ln, "NOT PARSED — line not recognized",
              "Line " + ln + " does not match any directive this auditor knows. It was reported, not guessed at — check it against the smtpd.conf documentation; a typo here can silently change behavior.",
              "Verify line " + ln + " against the smtpd.conf(5) manual and fix or remove it.");
          });

          findings.sort(function (a, b) {
            var sa = SEV_ORDER[a.severity], sb = SEV_ORDER[b.severity];
            if (sa !== sb) return sa - sb;
            var la = a.line === null ? 1e9 : a.line, lb = b.line === null ? 1e9 : b.line;
            return la - lb;
          });

          var counts = { critical: 0, high: 0, medium: 0, info: 0, total: findings.length };
          findings.forEach(function (f) { counts[f.severity]++; });

          var verdict = "SAFE TO DEPLOY";
          if (counts.critical > 0) verdict = "DO NOT DEPLOY";
          else if (counts.high > 0 || counts.medium > 0) verdict = "DEPLOY WITH FIXES";

          return { verdict: verdict, counts: counts, findings: findings };
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-opensmtpd-config-safety-auditor',
  name: 'J-Dawgs OpenSMTPD Config Safety Auditor',
  description: 'smtpd -n only answers will-it-parse; ours grades a pasted smtpd.conf offline — open relay rules, TLS posture, and listener exposure — into one deploy verdict, secrets by key name and line only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
