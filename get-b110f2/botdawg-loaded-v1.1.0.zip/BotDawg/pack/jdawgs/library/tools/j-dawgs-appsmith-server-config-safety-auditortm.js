'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Appsmith Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Worked examples ---------- */

      var RISKY_EXAMPLE = [
        "# Appsmith docker.env - worked example (RISKY, do not deploy)",
        "APPSMITH_ENCRYPTION_PASSWORD=change-me",
        "APPSMITH_ENCRYPTION_SALT=abc123",
        "APPSMITH_MONGODB_URI=mongodb://admin:mongoP4ss@db.internal:27017/appsmith",
        "APPSMITH_REDIS_URL=redis://:redisP4ss@cache.internal:6379",
        "APPSMITH_SIGNUP_DISABLED=false",
        "APPSMITH_OAUTH2_GITHUB_CLIENT_ID=Iv1exampleclientid",
        "APPSMITH_OAUTH2_GITHUB_CLIENT_SECRET=shortghsecret",
        "APPSMITH_OAUTH2_GOOGLE_CLIENT_ID=000000000000-example.apps.googleusercontent.com",
        "APPSMITH_OAUTH2_GOOGLE_CLIENT_SECRET=shortgooglesecret",
        "APPSMITH_MAIL_ENABLED=true",
        "APPSMITH_MAIL_HOST=mail.example.com",
        "APPSMITH_MAIL_PORT=25",
        "APPSMITH_CUSTOM_DOMAIN=http://apps.example.com"
      ].join("\n");

      var HARDENED_EXAMPLE = [
        "# Appsmith docker.env - worked example (HARDENED)",
        "APPSMITH_ENCRYPTION_PASSWORD=Kx9mQ2vLp8zR4wN7tYb3Hs6Jd1Fc5G0e",
        "APPSMITH_ENCRYPTION_SALT=9f2Kd7QwZx4Lp8Mn3Vb6Hs1Jt5Ry0GaE",
        "APPSMITH_MONGODB_URI=mongodb://db.internal:27017/appsmith",
        "APPSMITH_REDIS_URL=redis://cache.internal:6379",
        "APPSMITH_SIGNUP_DISABLED=true",
        "APPSMITH_OAUTH2_GITHUB_CLIENT_ID=Iv1a2b3c4d5e6f7a8b",
        "APPSMITH_OAUTH2_GITHUB_CLIENT_SECRET=a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0",
        "APPSMITH_OAUTH2_GOOGLE_CLIENT_ID=123456789012-abcdefghijklmnopqrstuvwxyz123456.apps.googleusercontent.com",
        "APPSMITH_OAUTH2_GOOGLE_CLIENT_SECRET=GOCSPXa1B2c3D4e5F6g7H8i9J0k1L2m3N4o5P6",
        "APPSMITH_MAIL_ENABLED=true",
        "APPSMITH_MAIL_HOST=smtp.example.com",
        "APPSMITH_MAIL_PORT=587",
        "APPSMITH_CUSTOM_DOMAIN=https://apps.example.com"
      ].join("\n");

      var GIBBERISH = "hello world this is not a config\nfoo bar baz quux\n??? !!! ;;;\nthe quick brown fox jumps over the lazy dog";

      /* Secret values planted in the examples. Used ONLY by the self-test leak
         scan, which proves these strings appear 0 times in any output. They are
         never written into findings, the report, or the JSON export. */
      var PLANTED_SECRETS = [
        "change-me", "abc123", "mongoP4ss", "redisP4ss",
        "shortghsecret", "shortgooglesecret",
        "Kx9mQ2vLp8zR4wN7tYb3Hs6Jd1Fc5G0e", "9f2Kd7QwZx4Lp8Mn3Vb6Hs1Jt5Ry0GaE",
        "a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0", "GOCSPXa1B2c3D4e5F6g7H8i9J0k1L2m3N4o5P6"
      ];

      /* ---------- Parsing ---------- */

      var PLACEHOLDERS = [
        "password","passwd","changeme","change-me","change_me","change me",
        "your-password","your_password","your-encryption-password","your-encryption-salt",
        "your-secret","your_salt","example","placeholder","secret","appsmith",
        "default","test","testing","demo","123456","12345678","123456789","abc123",
        "letmein","admin","password123","salt","mysalt","mypassword","xxx","xxxx",
        "todo","replace-me","replace_me","insert-here","encryptionpassword","encryption-salt"
      ];

      function isPlaceholder(v) {
        var s = String(v).trim().toLowerCase();
        if (!s) return false;
        if (PLACEHOLDERS.indexOf(s) !== -1) return true;
        if (/^<.*>$/.test(s)) return true;
        if (s.indexOf("your-") === 0 || s.indexOf("your_") === 0) return true;
        if (s.indexOf("example") === 0) return true;
        return false;
      }

      function parseConfig(text) {
        var lines = String(text).split(/\r?\n/);
        var entries = [];
        var unparsed = [];
        var byKey = {};
        for (var i = 0; i < lines.length; i++) {
          var lineNo = i + 1;
          var t = lines[i].trim();
          if (!t || t.charAt(0) === "#") continue;
          var m = t.match(/^(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/);
          if (!m) { unparsed.push(lineNo); continue; }
          var val = m[2].trim();
          if (val.length >= 2 &&
              ((val.charAt(0) === '"' && val.charAt(val.length - 1) === '"') ||
               (val.charAt(0) === "'" && val.charAt(val.length - 1) === "'"))) {
            val = val.slice(1, -1);
          }
          var entry = { key: m[1], value: val, line: lineNo };
          entries.push(entry);
          if (!byKey[entry.key]) byKey[entry.key] = [];
          byKey[entry.key].push(entry);
        }
        return { entries: entries, unparsed: unparsed, byKey: byKey, totalLines: lines.length };
      }

      function firstEntry(parsed, key) {
        var list = parsed.byKey[key];
        return list && list.length ? list[0] : null;
      }

      function truthy(v) {
        var s = String(v).trim().toLowerCase();
        return s === "true" || s === "1" || s === "yes" || s === "on";
      }
      function falsy(v) {
        var s = String(v).trim().toLowerCase();
        return s === "false" || s === "0" || s === "no" || s === "off";
      }

      /* Extract ONLY the length / placeholder status of a password embedded in a
         URI userinfo (scheme://user:password@host). The password itself is never
         returned, stored in a finding, or rendered. */
      function uriPasswordInfo(uri) {
        var m = String(uri).match(/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\/([^/?#]*)/);
        if (!m) return { has: false };
        var authority = m[1];
        var at = authority.lastIndexOf("@");
        if (at === -1) return { has: false };
        var userinfo = authority.slice(0, at);
        var colon = userinfo.indexOf(":");
        if (colon === -1) return { has: false };
        var pw = userinfo.slice(colon + 1);
        try { pw = decodeURIComponent(pw); } catch (e) { /* keep raw length */ }
        if (!pw) return { has: false };
        return { has: true, length: pw.length, placeholder: isPlaceholder(pw) };
      }

      /* ---------- Audit engine ----------
         Findings NEVER contain a secret value. Secrets are described by key
         name, line number, and length only. */

      function audit(text) {
        var parsed = parseConfig(text);
        var findings = [];
        function add(severity, line, key, check, detail) {
          findings.push({ severity: severity, line: line, key: key, check: check, detail: detail });
        }

        var appsmithKeys = parsed.entries.filter(function (e) { return e.key.indexOf("APPSMITH_") === 0; });

        if (appsmithKeys.length < 3) {
          add("info", null, null, "recognizable-config",
            "Only " + appsmithKeys.length + " APPSMITH_* key(s) recognized. A gradeable Appsmith config needs at least 3, including APPSMITH_ENCRYPTION_PASSWORD and APPSMITH_ENCRYPTION_SALT.");
          return finish(parsed, findings, "NOT ENOUGH TO GRADE");
        }

        /* Encryption password */
        var pw = firstEntry(parsed, "APPSMITH_ENCRYPTION_PASSWORD");
        if (!pw) {
          add("critical", null, "APPSMITH_ENCRYPTION_PASSWORD", "encryption-password-present",
            "Key is missing. Appsmith encrypts stored credentials with this password; without one the server falls back to weak or generated behavior.");
        } else if (!pw.value) {
          add("critical", pw.line, pw.key, "encryption-password-present",
            "Key is present but empty (length 0).");
        } else {
          if (isPlaceholder(pw.value)) {
            add("critical", pw.line, pw.key, "encryption-password-placeholder",
              "Value matches a known example/placeholder value (length " + pw.value.length + "). Anyone who has seen the example config can decrypt this server's stored credentials. Value not shown.");
          }
          if (pw.value.length < 16) {
            add("critical", pw.line, pw.key, "encryption-password-length",
              "Encryption password is short: length " + pw.value.length + " (minimum 16, 24+ recommended). Value not shown.");
          } else if (pw.value.length < 24) {
            add("major", pw.line, pw.key, "encryption-password-length",
              "Encryption password length is " + pw.value.length + "; 24+ characters recommended. Value not shown.");
          } else {
            add("pass", pw.line, pw.key, "encryption-password-length",
              "Encryption password present with length " + pw.value.length + ". Value not shown.");
          }
        }

        /* Encryption salt */
        var salt = firstEntry(parsed, "APPSMITH_ENCRYPTION_SALT");
        if (!salt) {
          add("critical", null, "APPSMITH_ENCRYPTION_SALT", "encryption-salt-present",
            "Key is missing. The salt is required alongside the encryption password; without it stored credentials are not properly protected.");
        } else if (!salt.value) {
          add("critical", salt.line, salt.key, "encryption-salt-present",
            "Key is present but empty (length 0).");
        } else {
          if (isPlaceholder(salt.value)) {
            add("critical", salt.line, salt.key, "encryption-salt-placeholder",
              "Value matches a known example/placeholder value (length " + salt.value.length + "). Example salts are public knowledge and defeat the encryption. Value not shown.");
          }
          if (salt.value.length < 16) {
            add("critical", salt.line, salt.key, "encryption-salt-length",
              "Encryption salt is short: length " + salt.value.length + " (minimum 16, 24+ recommended). Value not shown.");
          } else if (salt.value.length < 24) {
            add("major", salt.line, salt.key, "encryption-salt-length",
              "Encryption salt length is " + salt.value.length + "; 24+ characters recommended. Value not shown.");
          } else {
            add("pass", salt.line, salt.key, "encryption-salt-length",
              "Encryption salt present with length " + salt.value.length + ". Value not shown.");
          }
        }

        if (pw && salt && pw.value && pw.value === salt.value) {
          add("critical", salt.line, "APPSMITH_ENCRYPTION_SALT", "encryption-password-equals-salt",
            "Encryption password and salt are identical. They must be two different random values. Values not shown.");
        }

        /* MongoDB URI */
        var mongo = firstEntry(parsed, "APPSMITH_MONGODB_URI");
        if (!mongo) {
          add("minor", null, "APPSMITH_MONGODB_URI", "mongodb-uri-present",
            "Key is not set; the server will rely on its built-in default database settings, which are not a hardened posture.");
        } else {
          var mi = uriPasswordInfo(mongo.value);
          if (mi.has) {
            var mSev = (mi.placeholder || mi.length < 12) ? "critical" : "major";
            add(mSev, mongo.line, mongo.key, "mongodb-uri-plaintext-password",
              "Connection string embeds a plaintext password (password length " + mi.length + (mi.placeholder ? ", matches a known example/placeholder value" : "") + "). Anyone who reads this file owns the database. Prefer a secrets manager or a credential-free internal URI. Password value not shown.");
          } else {
            add("pass", mongo.line, mongo.key, "mongodb-uri-plaintext-password",
              "No password embedded in the MongoDB connection string.");
          }
          if (/^mongodb:\/\//i.test(mongo.value) === false && /^mongodb\+srv:\/\//i.test(mongo.value) === false) {
            add("minor", mongo.line, mongo.key, "mongodb-uri-scheme",
              "Value does not start with mongodb:// or mongodb+srv://; the server may reject it at startup.");
          }
        }

        /* Redis URL */
        var redis = firstEntry(parsed, "APPSMITH_REDIS_URL");
        if (!redis) {
          add("minor", null, "APPSMITH_REDIS_URL", "redis-url-present",
            "Key is not set; the server will rely on its built-in default cache settings.");
        } else {
          var ri = uriPasswordInfo(redis.value);
          if (ri.has) {
            var rSev = (ri.placeholder || ri.length < 12) ? "critical" : "major";
            add(rSev, redis.line, redis.key, "redis-url-plaintext-password",
              "Connection string embeds a plaintext password (password length " + ri.length + (ri.placeholder ? ", matches a known example/placeholder value" : "") + "). Anyone who reads this file owns the cache and its sessions. Password value not shown.");
          } else {
            add("pass", redis.line, redis.key, "redis-url-plaintext-password",
              "No password embedded in the Redis connection string.");
          }
          if (/^rediss:\/\//i.test(redis.value)) {
            add("pass", redis.line, redis.key, "redis-url-tls",
              "Redis URL uses rediss:// (TLS).");
          }
        }

        /* Signup posture */
        var signup = firstEntry(parsed, "APPSMITH_SIGNUP_DISABLED");
        if (!signup) {
          add("major", null, "APPSMITH_SIGNUP_DISABLED", "signup-posture",
            "Key is not set. Appsmith allows public signup by default, so anyone who finds the server can create an account.");
        } else if (truthy(signup.value)) {
          add("pass", signup.line, signup.key, "signup-posture",
            "Public signup is disabled; accounts are invite/admin-created only.");
        } else {
          add("critical", signup.line, signup.key, "signup-posture",
            "Public signup is OPEN (APPSMITH_SIGNUP_DISABLED is not true). Anyone who finds this server can register an account. Set it to true once admin accounts exist.");
        }

        /* OAuth providers */
        [["GITHUB", "GitHub"], ["GOOGLE", "Google"]].forEach(function (pair) {
          var idKey = "APPSMITH_OAUTH2_" + pair[0] + "_CLIENT_ID";
          var secKey = "APPSMITH_OAUTH2_" + pair[0] + "_CLIENT_SECRET";
          var idE = firstEntry(parsed, idKey);
          var secE = firstEntry(parsed, secKey);
          if (!idE && !secE) {
            add("info", null, secKey, "oauth-" + pair[0].toLowerCase(),
              pair[1] + " OAuth is not configured. Fine if unused; password signup posture then carries the full sign-in risk.");
            return;
          }
          if (idE && !secE) {
            add("major", idE.line, secKey, "oauth-" + pair[0].toLowerCase() + "-secret-missing",
              pair[1] + " client ID is set but the client secret key is missing; " + pair[1] + " sign-in will fail and the half-configured provider invites probing.");
            return;
          }
          if (!idE && secE) {
            add("major", secE.line, idKey, "oauth-" + pair[0].toLowerCase() + "-id-missing",
              pair[1] + " client secret is set (length " + secE.value.length + ") but the client ID key is missing. Secret value not shown.");
            return;
          }
          if (!secE.value) {
            add("major", secE.line, secKey, "oauth-" + pair[0].toLowerCase() + "-secret-empty",
              pair[1] + " client secret is present but empty (length 0).");
          } else if (isPlaceholder(secE.value)) {
            add("critical", secE.line, secKey, "oauth-" + pair[0].toLowerCase() + "-secret-placeholder",
              pair[1] + " client secret matches a known example/placeholder value (length " + secE.value.length + "). Rotate it in the provider console. Secret value not shown.");
          } else if (secE.value.length < 20) {
            add("major", secE.line, secKey, "oauth-" + pair[0].toLowerCase() + "-secret-length",
              pair[1] + " client secret is short: length " + secE.value.length + " (real provider secrets are typically 20+). Confirm it was copied in full and rotate it if it is a sample. Secret value not shown.");
          } else {
            add("pass", secE.line, secKey, "oauth-" + pair[0].toLowerCase() + "-secret-length",
              pair[1] + " client secret present with length " + secE.value.length + ". Secret value not shown.");
          }
        });

        /* http:// URLs anywhere */
        parsed.entries.forEach(function (e) {
          if (/http:\/\//i.test(e.value)) {
            if (/http:\/\/(localhost|127\.0\.0\.1|\[::1\])([:\/]|$)/i.test(e.value)) {
              add("info", e.line, e.key, "url-scheme",
                "URL uses http:// but points at localhost; acceptable for local-only development, not for a deployed server.");
            } else {
              add("major", e.line, e.key, "url-scheme",
                "URL uses plaintext http://. Traffic to this address — including sessions and credentials — crosses the network unencrypted. Switch to https://.");
            }
          } else if (/https:\/\//i.test(e.value) && /DOMAIN|URL|HOST/i.test(e.key)) {
            add("pass", e.line, e.key, "url-scheme", "URL uses https://.");
          }
        });

        /* Mail / TLS posture */
        var mailEnabled = firstEntry(parsed, "APPSMITH_MAIL_ENABLED");
        var mailHost = firstEntry(parsed, "APPSMITH_MAIL_HOST");
        var mailPort = firstEntry(parsed, "APPSMITH_MAIL_PORT");
        var mailPw = firstEntry(parsed, "APPSMITH_MAIL_PASSWORD");
        if (mailEnabled && truthy(mailEnabled.value)) {
          if (!mailHost || !mailHost.value) {
            add("major", mailEnabled.line, "APPSMITH_MAIL_HOST", "mail-host",
              "Mail is enabled but APPSMITH_MAIL_HOST is missing or empty; password resets and invites will fail silently.");
          }
          if (mailPort) {
            var portNum = parseInt(mailPort.value, 10);
            if (portNum === 25) {
              add("major", mailPort.line, mailPort.key, "mail-tls",
                "SMTP port 25 is the plaintext relay port. Use 587 (STARTTLS) or 465 (implicit TLS) so mail credentials and reset links are encrypted in transit.");
            } else if (portNum === 587 || portNum === 465) {
              add("pass", mailPort.line, mailPort.key, "mail-tls",
                "SMTP port " + portNum + " is a TLS-capable submission port.");
            } else if (!isNaN(portNum)) {
              add("minor", mailPort.line, mailPort.key, "mail-tls",
                "SMTP port " + portNum + " is non-standard; confirm the provider encrypts this port (STARTTLS or implicit TLS).");
            }
          } else {
            add("minor", mailEnabled.line, "APPSMITH_MAIL_PORT", "mail-tls",
              "Mail is enabled but no SMTP port is set; the default may send on plaintext port 25.");
          }
          parsed.entries.forEach(function (e) {
            if (/TLS|SSL|SECURE/i.test(e.key) && falsy(e.value)) {
              add("major", e.line, e.key, "mail-tls",
                "A mail TLS/SSL setting is explicitly turned off. Turn it on so SMTP traffic is encrypted.");
            }
          });
          if (mailPw && mailPw.value) {
            add("info", mailPw.line, mailPw.key, "mail-password",
              "SMTP password is set in the config file (length " + mailPw.value.length + "). It is graded by length only and its value is not shown; prefer a secrets manager for this file.");
          }
        } else if (mailEnabled && falsy(mailEnabled.value)) {
          add("info", mailEnabled.line, mailEnabled.key, "mail-enabled",
            "Mail is disabled. Password reset and email invites will not work; fine for a locked-down internal install.");
        }

        /* Any other secret-bearing keys: presence + length only */
        parsed.entries.forEach(function (e) {
          if (!/SECRET|PASSWORD|TOKEN|PRIVATE_KEY/.test(e.key)) return;
          if (["APPSMITH_ENCRYPTION_PASSWORD","APPSMITH_OAUTH2_GITHUB_CLIENT_SECRET",
               "APPSMITH_OAUTH2_GOOGLE_CLIENT_SECRET","APPSMITH_MAIL_PASSWORD"].indexOf(e.key) !== -1) return;
          add("info", e.line, e.key, "other-secret-key",
            "Secret-bearing key present (length " + e.value.length + "). Graded by name, line, and length only; value not shown.");
        });

        /* Duplicates + unparsed lines */
        Object.keys(parsed.byKey).forEach(function (k) {
          var list = parsed.byKey[k];
          if (list.length > 1) {
            add("minor", list[1].line, k, "duplicate-key",
              "Key is defined " + list.length + " times (lines " + list.map(function (x) { return x.line; }).join(", ") + "). Only one value wins at startup; remove the extras so the effective value is unambiguous.");
          }
        });
        parsed.unparsed.forEach(function (ln) {
          add("minor", ln, null, "unparsed-line",
            "Line is not a KEY=value pair, comment, or blank line, so it was not graded. Line content not shown.");
        });

        var hasCritical = findings.some(function (f) { return f.severity === "critical"; });
        var hasFix = findings.some(function (f) { return f.severity === "major" || f.severity === "minor"; });
        var verdict = hasCritical ? "DO NOT DEPLOY" : (hasFix ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY");
        return finish(parsed, findings, verdict);
      }

      function finish(parsed, findings, verdict) {
        findings = findings.map(function (f, i) { return { f: f, i: i }; })
          .sort(function (a, b) {
            var la = a.f.line === null ? 9999 : a.f.line;
            var lb = b.f.line === null ? 9999 : b.f.line;
            return la !== lb ? la - lb : a.i - b.i;
          })
          .map(function (x) { return x.f; });
        var counts = { critical: 0, major: 0, minor: 0, pass: 0, info: 0 };
        findings.forEach(function (f) { counts[f.severity] = (counts[f.severity] || 0) + 1; });
        var recognized = parsed.entries.filter(function (e) { return e.key.indexOf("APPSMITH_") === 0; }).length;
        return {
          verdict: verdict,
          findings: findings,
          counts: counts,
          linesScanned: parsed.totalLines,
          keysRecognized: recognized
        };
      }

      /* ---------- Output builders (secret-free by construction) ---------- */

      function buildReport(result) {
        var out = [];
        out.push("J-Dawgs Appsmith Server Config Safety Auditor - Report");
        out.push("Verdict: " + result.verdict);
        out.push("Lines scanned: " + result.linesScanned + " | APPSMITH_* keys recognized: " + result.keysRecognized);
        out.push("Critical: " + result.counts.critical + " | Major: " + result.counts.major +
                 " | Minor: " + result.counts.minor + " | Passed: " + result.counts.pass +
                 " | Info: " + result.counts.info);
        out.push("");
        out.push("Findings:");
        result.findings.forEach(function (f) {
          out.push("[" + f.severity.toUpperCase() + "] Line " + (f.line === null ? "n/a (key not present)" : f.line) +
                   (f.key ? " | " + f.key : "") + " | " + f.check);
          out.push("    " + f.detail);
        });
        out.push("");
        out.push("Note: secret values are never printed. Findings name the key, the line, and the length only.");
        out.push("This audit ran entirely in the browser. Nothing was saved, uploaded, or connected to any server.");
        return out.join("\n");
      }

      function buildJSON(result) {
        return JSON.stringify({
          tool: "J-Dawgs Appsmith Server Config Safety Auditor",
          verdict: result.verdict,
          linesScanned: result.linesScanned,
          keysRecognized: result.keysRecognized,
          counts: result.counts,
          secretValuesIncluded: false,
          findings: result.findings.map(function (f) {
            return { severity: f.severity, line: f.line, key: f.key, check: f.check, detail: f.detail };
          })
        }, null, 2);
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-appsmith-server-config-safety-auditortm',
  name: 'J-Dawgs Appsmith Server Config Safety Auditor',
  description: 'Grades a pasted Appsmith docker.env/.env offline into one deploy verdict (SAFE TO DEPLOY / DEPLOY WITH FIXES / DO NOT DEPLOY / NOT ENOUGH TO GRADE) — secrets reported by key name, line, and length only, never the secret value.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
