'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Calendar Invite & Meeting Readiness Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var WORKED_EXAMPLE = [
        "Title: Q4 Budget Review",
        "Starts: 2026-11-12 2:00 PM",
        "Ends: 2026-11-12 3:30 PM",
        "Timezone:",
        "Attendees: Alex Rivera, Priya Nair, Jordan Lee, Sam Ortiz, Casey Kim, Morgan Blake, Taylor Reed, Jamie Fox, Robin Chen, Drew Patel",
        "Location: virtual",
        "Meeting link:",
        "Agenda:",
        "Attachments:",
        "Description: Quarterly budget review. Please see attached deck before the call and come ready to talk numbers."
      ].join("\n");

      var CLEAN_EXAMPLE = [
        "Title: Decide Q4 hosting vendor and sign off on the contract",
        "Starts: 2026-11-17 10:00 AM",
        "Ends: 2026-11-17 11:00 AM",
        "Timezone: America/Chicago",
        "Attendees: Alex Rivera (organizer), Priya Nair, Jordan Lee",
        "Location: virtual",
        "Meeting link: https://meet.example.com/q4-vendor-decision",
        "Agenda: Compare the two hosting quotes, decide which vendor to approve, and confirm the migration date.",
        "Attachments: hosting-quotes.pdf, migration-outline.docx",
        "Description: Decision meeting. The quotes are attached; please skim them before the call."
      ].join("\n");

      var SHORTENERS = ["bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly", "buff.ly", "is.gd", "rb.gy", "cutt.ly", "shorturl.at", "rebrand.ly", "short.io", "bl.ink"];

      function parseInvite(text) {
        var keyMap = {
          "title": "title", "starts": "starts", "start": "starts",
          "ends": "ends", "end": "ends", "duration": "duration",
          "timezone": "timezone", "time zone": "timezone",
          "attendees": "attendees", "location": "location",
          "meeting link": "link", "link": "link",
          "agenda": "agenda", "attachments": "attachments",
          "description": "description"
        };
        var fields = {};
        var current = null;
        text.split(/\r?\n/).forEach(function (line) {
          var m = line.match(/^\s*([A-Za-z][A-Za-z ]*):\s*(.*)$/);
          if (m && Object.prototype.hasOwnProperty.call(keyMap, m[1].trim().toLowerCase())) {
            current = keyMap[m[1].trim().toLowerCase()];
            fields[current] = m[2].trim();
          } else if (current && line.trim()) {
            fields[current] = (fields[current] ? fields[current] + " " : "") + line.trim();
          }
        });
        return fields;
      }

      function parseDateTime(s) {
        if (!s) return null;
        var d = s.match(/(\d{4})-(\d{1,2})-(\d{1,2})/);
        var t = s.match(/(\d{1,2}):(\d{2})\s*([AaPp][Mm])?/);
        if (!d || !t) return null;
        var h = parseInt(t[1], 10), min = parseInt(t[2], 10);
        if (t[3]) {
          var ap = t[3].toUpperCase();
          if (ap === "PM" && h < 12) h += 12;
          if (ap === "AM" && h === 12) h = 0;
        }
        var days = Math.floor(Date.UTC(+d[1], +d[2] - 1, +d[3]) / 86400000);
        return { abs: days * 1440 + h * 60 + min, label: s };
      }

      function parseDurationMinutes(s) {
        if (!s) return null;
        var m = s.match(/(\d+(?:\.\d+)?)\s*(hours?|hrs?|h|minutes?|mins?|m)\b/i);
        if (!m) return null;
        var v = parseFloat(m[1]);
        return /^h/i.test(m[2]) ? Math.round(v * 60) : Math.round(v);
      }

      function parseAttendees(raw) {
        if (!raw) return [];
        return raw.split(",").map(function (e) { return e.trim(); }).filter(function (e) { return e.length > 0; })
          .map(function (entry) {
            var organizer = /\(organizer\)/i.test(entry) || /\[organizer\]/i.test(entry);
            var zone = null;
            var zm = entry.match(/\(([^()]*\/[^()]*)\)/);
            if (zm) zone = zm[1].trim();
            var clean = entry.replace(/\([^()]*\)/g, "").replace(/\[[^\]]*\]/g, "").trim();
            var emailTok = entry.match(/[^\s@<>()]+@[^\s@<>()]+\.[^\s@<>()]+/);
            var nameish = /^[A-Za-z][A-Za-z .'\-]*$/.test(clean) && clean.length >= 2 && clean.split(/\s+/).length <= 5;
            return { raw: entry, clean: clean, organizer: organizer, zone: zone, parsed: !!emailTok || nameish };
          });
      }

      function domainOf(url) {
        var m = String(url).match(/^(?:https?:\/\/)?(?:www\.)?([^\/:?#]+)/i);
        return m ? m[1].toLowerCase() : "";
      }

      function fmtDuration(mins) {
        if (mins == null) return "not stated";
        if (mins < 60) return mins + " minutes";
        var h = Math.floor(mins / 60), r = mins % 60;
        return r ? (h + "h " + r + "m") : (h + (h === 1 ? " hour" : " hours"));
      }

      function audit(text) {
        var f = parseInvite(text);
        var findings = [];   // {sev, title, detail, fix}
        var grades = [];     // {element, grade, note}
        function add(sev, title, detail, fix) { findings.push({ sev: sev, title: title, detail: detail, fix: fix || null }); }
        function grade(element, g, note) { grades.push({ element: element, grade: g, note: note }); }

        var title = (f.title || "").trim();
        var tz = (f.timezone || "").trim();
        var location = (f.location || "").trim();
        var link = (f.link || "").trim();
        var agenda = (f.agenda || "").trim();
        var description = (f.description || "").trim();
        var attachments = (f.attachments || "").split(",").map(function (a) { return a.trim(); }).filter(Boolean);
        var attendees = parseAttendees(f.attendees || "");
        var start = parseDateTime(f.starts || "");
        var end = parseDateTime(f.ends || "");
        var durField = parseDurationMinutes(f.duration || "");

        var durationMin = null;
        if (start && end) durationMin = end.abs - start.abs;
        else if (durField != null) durationMin = durField;

        /* ---------- (5) Title quality ---------- */
        if (!title) {
          grade("Title", "MISSING", "No title given.");
          add("WARNING", "Title is empty", "Attendees cannot tell what the meeting is for from the invite list. Suggested structure (structural only — it invents none of your facts): verb + topic + outcome, e.g. “Decide [topic] and confirm [outcome]”.", "Give the meeting a title in the form verb + topic + outcome.");
        } else if (title.split(/\s+/).length === 1) {
          grade("Title", "WEAK", "Single-word title.");
          add("WARNING", "Title is a single word: “" + title + "”", "A one-word title carries no topic or outcome. Suggested structure (structural only): verb + topic + outcome.", "Expand the title to verb + topic + outcome.");
        } else if (/^[A-Z][a-z]+ [A-Z][a-z]+$/.test(title)) {
          grade("Title", "WEAK", "Reads as only a person's name (heuristic).");
          add("WARNING", "Title looks like only a person's name: “" + title + "” (heuristic)", "If this title is just who the meeting is with, it says nothing about what will be decided or done. Suggested structure (structural only): verb + topic + outcome.", "Retitle with verb + topic + outcome, not just a name.");
        } else {
          grade("Title", "PRESENT", "“" + title + "”");
        }

        /* ---------- (1) Time completeness ---------- */
        if (!f.starts || !String(f.starts).trim()) {
          grade("Start time", "MISSING", "No Starts line value.");
          add("BLOCKER", "No start time stated", "An invite with no start time cannot be sent. Add a Starts line with a date and time.", "Add the start date and time.");
        } else if (!start) {
          grade("Start time", "WEAK", "Given, but the date/time could not be read: “" + f.starts + "”");
          add("WARNING", "Start time could not be parsed", "“" + f.starts + "” does not match the documented format (YYYY-MM-DD h:MM AM/PM), so the time arithmetic below could not be verified.", "Rewrite the start as YYYY-MM-DD h:MM AM/PM.");
        } else {
          grade("Start time", "PRESENT", f.starts);
        }

        if (start && end) {
          grade("End time", "PRESENT", f.ends);
          if (end.abs < start.abs) {
            add("BLOCKER", "End time is before the start time", "Starts " + f.starts + " but ends " + f.ends + ". The invite's own arithmetic does not work — fix one of the two times before sending.", "Fix the end time so it falls after the start time.");
          } else if (end.abs === start.abs) {
            add("WARNING", "Start and end times are identical", "A zero-length meeting is almost always a typo in one of the two times.", "Check whether the start or end time is a typo.");
          }
        } else if (durField != null) {
          grade("End / duration", "PRESENT", "Duration given: " + fmtDuration(durField) + " (no explicit end time).");
        } else if (f.ends && String(f.ends).trim() && !end) {
          grade("End time", "WEAK", "Given, but could not be read: “" + f.ends + "”");
          add("WARNING", "End time could not be parsed", "“" + f.ends + "” does not match the documented format, so end-before-start could not be verified.", "Rewrite the end as YYYY-MM-DD h:MM AM/PM.");
        } else {
          grade("End / duration", "MISSING", "Neither an Ends time nor a Duration was given.");
          add("WARNING", "No end time or duration stated", "Attendees cannot tell how long to block out, and this audit cannot verify the meeting's length.", "Add an Ends time or a Duration.");
        }

        var zones = {};
        attendees.forEach(function (a) { if (a.zone) zones[a.zone] = true; });
        var zoneList = Object.keys(zones);
        if (!tz) {
          grade("Timezone", "MISSING", "Timezone field is empty.");
          if (start || (f.starts && String(f.starts).trim())) {
            var multi = zoneList.length > 1 ? " Attendees state more than one zone (" + zoneList.join(", ") + "), so a single assumed zone would be wrong for someone." : "";
            add("BLOCKER", "No timezone stated for a timed meeting", "A start time is given but the Timezone field is empty. A bare time with no zone is never assumed by this audit — every attendee would read it in their own local time." + multi, "State the meeting timezone (e.g. America/Chicago) on the invite.");
          } else {
            add("WARNING", "Timezone field is empty", "No start time was given either, so there is nothing yet to anchor — the zone must be filled in with the start time.", "Fill in the timezone together with the start time.");
          }
        } else {
          grade("Timezone", "PRESENT", tz + (zoneList.length > 1 ? " (attendees also state: " + zoneList.join(", ") + ")" : ""));
        }

        if (start) {
          add("NOT CHECKED", "Daylight-saving gap check: NOT CHECKED",
            tz
              ? "Whether " + f.starts + " falls inside a daylight-saving gap for " + tz + " cannot be computed offline — this page carries no timezone database. Reported as not checked, never guessed. Verify the local time exists in " + tz + " before sending."
              : "No timezone is stated, and a gap check needs a stated zone. Reported as not checked, never guessed.",
            null);
        }

        var combinedPrep = (agenda + " " + description);
        if (durationMin != null && durationMin > 180 && !/\b(break|intermission|stretch)\b/i.test(combinedPrep)) {
          add("WARNING", "Long meeting with no break note", "The meeting runs " + fmtDuration(durationMin) + " with no mention of a break in the agenda or description. Anything over 3 hours needs a stated break or attendees will invent their own.", "Add a break note to the agenda or description.");
        }

        /* ---------- (2) Place / link completeness ---------- */
        var isVirtual = /\b(virtual|online|remote|video call)\b/i.test(location);
        if (!location) {
          grade("Location", "MISSING", "No location given.");
          add("WARNING", "No location stated", "Attendees do not know whether to show up somewhere or join a call.", "State a physical address or the word virtual as the location.");
        } else if (isVirtual) {
          grade("Location", "PRESENT", "Virtual (“" + location + "”).");
        } else if (location.split(/\s+/).length === 1) {
          grade("Location", "WEAK", "Single word: “" + location + "” — no address detail.");
          add("WARNING", "Physical location has no address detail", "“" + location + "” is a single word. Attendees need a street address (or building and room) to actually get there.", "Add the street address to the location.");
        } else {
          grade("Location", "PRESENT", "“" + location + "”");
        }

        if (isVirtual && !link) {
          grade("Meeting link", "MISSING", "Location is virtual but the Meeting link field is empty.");
          add("BLOCKER", "Virtual meeting with no meeting link", "The location says “" + location + "” but no meeting link is given. Attendees would have nowhere to join.", "Paste the meeting link into the invite.");
        } else if (link) {
          var dom = domainOf(link);
          if (SHORTENERS.indexOf(dom) !== -1) {
            grade("Meeting link", "WEAK", "Shortened link (" + dom + ") — destination not visible (heuristic).");
            add("REVIEW", "Meeting link uses a known URL shortener: " + dom + " (heuristic)", "The link " + link + " hides its real destination behind a shortener domain. Attendees cannot see where it leads, and some mail filters distrust shortened links. This is a heuristic flag on the domain, not a verdict on the destination.", "Replace the shortened link with the full meeting URL.");
          } else {
            grade("Meeting link", "PRESENT", link);
          }
        } else {
          grade("Meeting link", "PRESENT", "Not required — location is not virtual.");
        }

        /* ---------- (3) Attendee sanity ---------- */
        if (attendees.length === 0) {
          grade("Attendees", "MISSING", "No attendees listed.");
          add("BLOCKER", "Zero attendees", "An invite with nobody on it goes nowhere. Add at least one attendee.", "Add the attendees to the invite.");
        } else {
          var unparsed = attendees.filter(function (a) { return !a.parsed; });
          if (unparsed.length) {
            grade("Attendees", "WEAK", attendees.length + " listed; " + unparsed.length + " could not be parsed.");
            unparsed.forEach(function (a) {
              add("NOT PARSED", "Attendee entry not parsed: “" + a.raw + "”", "This entry is neither email-shaped (name@domain.tld) nor name-shaped (letters, spaces, hyphens), so it is reported as-is rather than guessed at.", "Fix or remove the attendee entry “" + a.raw + "”.");
            });
          } else {
            grade("Attendees", "PRESENT", attendees.length + " listed, all parsed.");
          }
          if (attendees.length > 12 && !agenda) {
            add("WARNING", "More than 12 attendees and no agenda", attendees.length + " people are invited with no agenda to keep the meeting on rails — decision meetings degrade fast at this size with nothing written down.", "Add an agenda, or trim the attendee list to the people who must decide.");
          }
        }

        var organizer = attendees.filter(function (a) { return a.organizer; })[0];
        if (attendees.length && organizer) {
          grade("Organizer", "PRESENT", organizer.clean || organizer.raw);
        } else if (attendees.length) {
          grade("Organizer", "WEAK", "Not marked in the Attendees list.");
          add("NOTE", "Organizer not marked", "No attendee is marked (organizer). Noted for the record — attendees may not know who owns the meeting or who to send regrets to.", "Mark the organizer with (organizer) after their name.");
        } else {
          grade("Organizer", "MISSING", "No attendees, so no organizer.");
        }

        /* ---------- (4) Agenda & prep ---------- */
        var decisionWords = /(decid|decision|approve|approval|choose|choice|vote|confirm|resolve|sign[\s-]?off|whether|which|what|why|how|when|question|\?)/i;
        if (!agenda) {
          grade("Agenda", "MISSING", "Agenda field is empty.");
          if (durationMin != null && durationMin >= 90) {
            add("BLOCKER", "Missing agenda for a " + fmtDuration(durationMin) + " meeting (house rule)", "This tool's stated house rule — not a universal law: a meeting of 90 minutes or longer with an empty agenda is a blocker, because that much of everyone's time is being committed with nothing written down.", "Write the agenda: topics, and what will be decided or answered.");
          } else if (durationMin != null && durationMin >= 45) {
            add("WARNING", "Missing agenda for a " + fmtDuration(durationMin) + " meeting", "Meetings of 45 minutes or longer with an empty agenda are graded MISSING AGENDA by this tool. Attendees cannot prepare for a meeting whose purpose is unstated.", "Write the agenda before sending.");
          } else if (durationMin != null) {
            add("NOTE", "No agenda (short meeting)", "At " + fmtDuration(durationMin) + " an empty agenda is survivable, but one line on what will be covered still helps.", "Add a one-line agenda.");
          } else {
            add("NOTE", "No agenda; length unknown", "The agenda is empty and the meeting length could not be verified, so the 45/90-minute agenda rules could not be applied.", "Add an agenda, and an end time or duration.");
          }
        } else if (!decisionWords.test(agenda)) {
          grade("Agenda", "WEAK", "Present, but no decision or question word found (heuristic).");
          add("WARNING", "Agenda looks weak — no decision or question in it (heuristic)", "The agenda lists material but names nothing to decide, approve, choose, or answer. Heuristic flag: it is based on the absence of decision/question words, not on a judgment of your topics.", "Add what will be decided or answered to the agenda.");
        } else {
          grade("Agenda", "PRESENT", "Present, with a decision or question in it.");
        }

        var attachmentRef = /(see attached|the attached (deck|file|document|doc|slides?|sheet|spreadsheet|presentation|pdf)|attached (deck|file|document|doc|slides?|sheet|spreadsheet|presentation|pdf)|the attachment\b|attachments? (enclosed|included|below))/i;
        var refWhere = [];
        if (attachmentRef.test(agenda)) refWhere.push("agenda");
        if (attachmentRef.test(description)) refWhere.push("description");
        if (refWhere.length && attachments.length === 0) {
          grade("Attachments", "MISSING", "Referenced in the " + refWhere.join(" and ") + " but the Attachments list is empty.");
          add("BLOCKER", "Missing attachment referenced by the invite text", "The " + refWhere.join(" and ") + " point(s) at an attachment (“see attached” / “the attached …”), but the Attachments list is empty. Attendees would arrive without the material the meeting depends on.", "Attach the referenced file(s), or remove the reference from the text.");
        } else if (attachments.length) {
          grade("Attachments", "PRESENT", attachments.join(", "));
        } else {
          grade("Attachments", "PRESENT", "None listed and none referenced.");
        }

        if (!description) {
          grade("Description", "MISSING", "No description given (optional, but useful for context).");
        } else {
          grade("Description", "PRESENT", "Given.");
        }

        /* ---------- Verdict ---------- */
        var blockers = findings.filter(function (x) { return x.sev === "BLOCKER"; });
        var fixCount = findings.filter(function (x) {
          return x.sev === "WARNING" || x.sev === "REVIEW" || x.sev === "NOT PARSED" || x.sev === "BLOCKER";
        });
        var verdict, verdictClass, verdictNote;
        if (blockers.length) {
          verdict = "DO NOT SEND YET";
          verdictClass = "stop";
          verdictNote = blockers.length + (blockers.length === 1 ? " blocker" : " blockers") + " must be fixed before this invite goes out.";
        } else if (fixCount.length) {
          verdict = "SEND WITH FIXES";
          verdictClass = "fixes";
          verdictNote = "No blockers, but " + fixCount.length + (fixCount.length === 1 ? " item needs" : " items need") + " attention first.";
        } else {
          verdict = "READY TO SEND";
          verdictClass = "ready";
          verdictNote = "Every check this audit runs passed on the pasted text.";
        }

        var checklist = findings.filter(function (x) { return x.fix; }).map(function (x) { return x.fix; });

        var summaryLines = [
          "MEETING INVITE — SEND-READY SUMMARY",
          "Title: " + (title || "(none)"),
          "When: " + ((f.starts || "not stated")) + (f.ends ? " to " + f.ends : (durField != null ? " (" + fmtDuration(durField) + ")" : "")),
          "Timezone: " + (tz || "NOT STATED"),
          "Length: " + fmtDuration(durationMin),
          "Attendees: " + (attendees.length ? attendees.map(function (a) { return a.clean || a.raw; }).join(", ") : "none listed"),
          "Location: " + (location || "not stated"),
          "Meeting link: " + (link || "none"),
          "Agenda: " + (agenda || "none"),
          "Attachments: " + (attachments.length ? attachments.join(", ") : "none"),
          "Verdict: " + verdict,
          "Blockers: " + blockers.length + " · Prep items: " + checklist.length
        ];

        return { verdict: verdict, verdictClass: verdictClass, verdictNote: verdictNote, grades: grades, findings: findings, checklist: checklist, summary: summaryLines.join("\n") };
      }

      function esc(s) {
        return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "WORKED_EXAMPLE": (typeof WORKED_EXAMPLE !== 'undefined' ? WORKED_EXAMPLE : undefined), "CLEAN_EXAMPLE": (typeof CLEAN_EXAMPLE !== 'undefined' ? CLEAN_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-calendar-invite-meeting-readiness-auditor',
  name: 'J-Dawgs Calendar Invite & Meeting Readiness Auditor',
  description: 'Calendar apps validate that an invite can be saved; ours audits whether it is ready to send — timezone, meeting link, agenda, and attachments checked together into one verdict (READY TO SEND / SEND WITH FIXES / DO NOT SEND YET).',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "WORKED_EXAMPLE": __core["WORKED_EXAMPLE"], "CLEAN_EXAMPLE": __core["CLEAN_EXAMPLE"] }
};
