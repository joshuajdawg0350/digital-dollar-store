'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs sysctl Kernel Parameter Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

var RISKY = [
"# Risky sysctl file - worked example",
"net.ipv4.ip_forward = 1",
"net.ipv4.conf.all.accept_source_route = 1",
"net.ipv4.conf.all.rp_filter = 0",
"kernel.kptr_restrict = 0",
"vm.swappiness = 60",
"vm.swappiness = 140"
].join("\n");

var HARDENED = [
"# Hardened sysctl file - worked example",
"net.ipv4.ip_forward = 0",
"net.ipv4.conf.all.accept_redirects = 0",
"net.ipv4.conf.default.accept_redirects = 0",
"net.ipv4.conf.all.send_redirects = 0",
"net.ipv4.conf.all.accept_source_route = 0",
"net.ipv4.conf.default.accept_source_route = 0",
"net.ipv4.conf.all.rp_filter = 1",
"net.ipv4.conf.default.rp_filter = 1",
"net.ipv4.tcp_syncookies = 1",
"kernel.kptr_restrict = 2",
"kernel.dmesg_restrict = 1",
"kernel.yama.ptrace_scope = 3",
"kernel.perf_event_paranoid = 3",
"kernel.modules_disabled = 1",
"kernel.unprivileged_bpf_disabled = 2",
"net.core.bpf_jit_harden = 2",
"kernel.core_pattern = core",
"fs.suid_dumpable = 0",
"vm.swappiness = 10",
"net.ipv4.tcp_rfc1337 = 1",
"net.ipv4.icmp_echo_ignore_broadcasts = 1",
"net.ipv4.icmp_ignore_bogus_error_responses = 1"
].join("\n");

var STRING_KEYS = { "kernel.core_pattern": true };

var INT_KEYS = {};
[
"net.ipv4.ip_forward",
"net.ipv6.conf.all.forwarding","net.ipv6.conf.default.forwarding",
"net.ipv4.tcp_syncookies","net.ipv4.tcp_rfc1337",
"net.ipv4.icmp_echo_ignore_broadcasts","net.ipv4.icmp_ignore_bogus_error_responses",
"kernel.kptr_restrict","kernel.dmesg_restrict","kernel.yama.ptrace_scope",
"kernel.perf_event_paranoid","kernel.modules_disabled","kernel.unprivileged_bpf_disabled",
"net.core.bpf_jit_harden","fs.suid_dumpable","vm.swappiness",
"kernel.randomize_va_space","fs.protected_hardlinks","fs.protected_symlinks",
"kernel.sysrq","net.ipv4.tcp_syncookies"
].forEach(function(k){ INT_KEYS[k]=true; });

function isConfKey(key, leaf){
  var parts = key.split(".");
  // net.ipv4.conf.<iface>.<leaf> or net.ipv6.conf.<iface>.<leaf>
  return parts.length===5 && (parts[0]==="net") && (parts[2]==="conf") && parts[4]===leaf;
}
function confLeaf(key){
  var parts = key.split(".");
  if(parts.length===5 && parts[2]==="conf") return parts[4];
  return null;
}
function isKnownIntKey(key){
  if(INT_KEYS[key]) return true;
  var leaf = confLeaf(key);
  if(leaf && ["accept_redirects","send_redirects","accept_source_route","rp_filter","log_martians","forwarding"].indexOf(leaf)>=0) return true;
  return false;
}
function isKnownKey(key){
  return isKnownIntKey(key) || !!STRING_KEYS[key];
}
function isSecretShaped(v){
  if(!v) return false;
  if(/password|secret|token|api[_-]?key|private[_-]?key|BEGIN [A-Z ]*PRIVATE/i.test(v)) return true;
  if(v.length>=32) return true;
  if(v.length>=24 && /^[A-Za-z0-9+\/=_-]+$/.test(v) && /[a-z]/.test(v) && /[A-Z]/.test(v) && /[0-9]/.test(v)) return true;
  return false;
}
function esc(s){
  return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
}
function shownValue(key, raw){
  if(isSecretShaped(raw)) return null; // never rendered
  return raw;
}

function parse(text){
  var lines = text.split(/\r?\n/);
  var entries = []; // {key, rawValue, line}
  var unparsable = []; // {line, }
  for(var i=0;i<lines.length;i++){
    var lineNo = i+1;
    var t = lines[i].trim();
    if(t==="" ) continue;
    if(t.charAt(0)==="#" || t.charAt(0)===";") continue;
    var eq = t.indexOf("=");
    if(eq<0){ unparsable.push({line:lineNo}); continue; }
    var key = t.slice(0,eq).trim();
    var val = t.slice(eq+1).trim();
    // strip inline comment only for non-core_pattern values with space+#
    if(key!=="kernel.core_pattern"){
      var hashIdx = val.indexOf(" #");
      if(hashIdx>=0) val = val.slice(0,hashIdx).trim();
    }
    if(key.charAt(0)==="-") key = key.slice(1).trim();
    if(!/^[A-Za-z0-9_.\-]+$/.test(key) || key.indexOf(".")<0 || val===""){
      unparsable.push({line:lineNo}); continue;
    }
    entries.push({key:key, raw:val, line:lineNo});
  }
  return {entries:entries, unparsable:unparsable};
}

function grade(entry, role, findings, good){
  var key = entry.key, raw = entry.raw, line = entry.line;
  var leaf = confLeaf(key);
  function add(sev, msg, fix){ findings.push({line:line, severity:sev, key:key, message:msg, fix:fix}); }

  if(STRING_KEYS[key]){
    if(raw.charAt(0)==="|"){
      var rest = raw.slice(1).trim();
      var helper = rest.split(/\s+/)[0] || "(unnamed helper)";
      if(isSecretShaped(helper)) helper = "(helper name withheld)";
      add("WARNING","kernel.core_pattern starts with a pipe, so crash dumps are handed to a helper program instead of written as a plain core file. Helper program: " + helper + ". If that helper is compromised or misconfigured, every crash on this host flows through it.","Only keep a piped core_pattern if you run and trust that helper. Otherwise set kernel.core_pattern to a plain file path pattern such as \"core\".");
    }
    return;
  }
  if(!isKnownIntKey(key)){
    return; // NOT AUDITED by name
  }
  // integer check
  if(!/^-?\d+$/.test(raw)){
    if(isSecretShaped(raw)){
      add("BLOCKER","The value for " + key + " is not an integer, so sysctl would reject it. The value itself is not shown because it looks secret-shaped; it is flagged by key name only.","Replace the value for " + key + " with the correct integer for this parameter, and rotate anything secret that was pasted here by mistake.");
    } else {
      add("BLOCKER","The value \"" + raw + "\" for " + key + " is not an integer, so sysctl would reject this line.","Replace the value with a valid integer for " + key + ".");
    }
    return;
  }
  var v = parseInt(raw,10);

  // ---- forwarding ----
  if(key==="net.ipv4.ip_forward" || leaf==="forwarding"){
    if(v===1){
      if(role==="workstation") add("BLOCKER","IP forwarding is on, and this role is workstation/desktop: forwarding turns this host into a router, relaying traffic between networks — not a job a desktop should do.","Set " + key + " = 0 on a workstation unless you deliberately run a VM or container setup that needs forwarding.");
      else if(role==="router") add("INFO","IP forwarding is on. That turns this host into a router, and for the Router-or-VPN role that is expected for the role.","No change needed for the Router-or-VPN role. Make sure the firewall rules match the forwarding you intend.");
      else add("WARNING","IP forwarding is on, which turns this host into a router, relaying packets between networks. This finding is role-dependent: most servers do not need to forward traffic.","Set " + key + " = 0 unless this server is deliberately acting as a router, VPN gateway, or container host that needs forwarding.");
    } else if(v!==0){
      add("WARNING","Expected 0 or 1 for " + key + ", but the effective value is " + v + ".","Set " + key + " to 0 or 1.");
    }
    return;
  }
  // ---- redirects / source route / rp_filter by leaf ----
  if(leaf==="accept_redirects"){
    if(v===1) add("WARNING","Accepting ICMP redirects lets other hosts rewrite this host's routing — a classic man-in-the-middle lever on a shared network.","Set " + key + " = 0.");
    return;
  }
  if(leaf==="send_redirects"){
    if(v===1){
      if(role==="router") add("INFO","Sending ICMP redirects is on. For the Router-or-VPN role that can be expected for the role, since routers legitimately tell hosts about better routes.","No change needed for the Router-or-VPN role; leave off on hosts that are not routing.");
      else add("WARNING","Sending ICMP redirects is on. Only routers should send redirects; a regular host sending them can steer other machines' traffic.","Set " + key + " = 0 on any host that is not acting as a router.");
    }
    return;
  }
  if(leaf==="accept_source_route"){
    if(v===1) add("BLOCKER","Source routing is accepted. Source-routed packets let the sender dictate the path traffic takes, which defeats firewall and routing policy — this is a long-standing attack technique with no normal modern use.","Set " + key + " = 0.");
    return;
  }
  if(leaf==="rp_filter"){
    if(v===0) add("WARNING","Reverse-path filtering is off (rp_filter = 0), so spoofing protection is off: packets arriving on the wrong interface with forged source addresses are not dropped.","Set " + key + " = 1 (strict) — or 2 (loose) only if this host uses asymmetric routing or policy routing that strict mode breaks.");
    return;
  }
  if(leaf==="log_martians"){
    if(v===1) good.push({key:key,line:line,note:"Martian (impossible-source) packets are logged."});
    return;
  }

  switch(key){
    case "net.ipv4.tcp_syncookies":
      if(v===0) add("WARNING","SYN cookies are off (tcp_syncookies = 0). Under a SYN flood, the connection queue fills and legitimate connections get refused.","Set net.ipv4.tcp_syncookies = 1.");
      else if(v===1) good.push({key:key,line:line,note:"SYN cookies on — basic SYN-flood resistance."});
      break;
    case "net.ipv4.tcp_rfc1337":
      if(v===1) good.push({key:key,line:line,note:"RFC 1337 protection on — TIME-WAIT assassination hazards are resisted."});
      else if(v===0) add("WARNING","tcp_rfc1337 = 0 leaves the RFC 1337 TIME-WAIT hazard unmitigated.","Set net.ipv4.tcp_rfc1337 = 1.");
      break;
    case "net.ipv4.icmp_echo_ignore_broadcasts":
      if(v===1) good.push({key:key,line:line,note:"Broadcast ICMP echo is ignored — this host cannot be used as a smurf amplifier."});
      else if(v===0) add("WARNING","icmp_echo_ignore_broadcasts = 0 means this host answers broadcast pings and can be used to amplify a smurf attack.","Set net.ipv4.icmp_echo_ignore_broadcasts = 1.");
      break;
    case "net.ipv4.icmp_ignore_bogus_error_responses":
      if(v===1) good.push({key:key,line:line,note:"Bogus ICMP error responses are ignored, as recommended."});
      else if(v===0) add("WARNING","icmp_ignore_bogus_error_responses = 0 means bogus ICMP error responses are not ignored.","Set net.ipv4.icmp_ignore_bogus_error_responses = 1.");
      break;
    case "kernel.kptr_restrict":
      if(v===0) add("WARNING","kptr_restrict = 0 exposes kernel memory addresses to unprivileged users, which makes kernel exploits easier to aim.","Set kernel.kptr_restrict = 1, or 2 to hide kernel pointers from all users.");
      else if(v<0 || v>2) add("BLOCKER","kptr_restrict = " + v + " is outside its valid range of 0 to 2.","Set kernel.kptr_restrict to 1 or 2.");
      break;
    case "kernel.dmesg_restrict":
      if(v===0) add("WARNING","dmesg_restrict = 0 lets any unprivileged user read the kernel log, which leaks addresses, driver details, and other useful reconnaissance.","Set kernel.dmesg_restrict = 1.");
      else if(v!==1) add("WARNING","Expected 0 or 1 for kernel.dmesg_restrict, but the effective value is " + v + ".","Set kernel.dmesg_restrict = 1.");
      break;
    case "kernel.yama.ptrace_scope":
      if(v===0) add("WARNING","ptrace_scope = 0 lets any process a user owns trace (inspect and control) any other process of that user — a wide debugging and credential-theft surface.","Set kernel.yama.ptrace_scope = 1 at minimum; 2 or 3 if debugging needs allow.");
      else if(v===1) add("INFO","ptrace_scope = 1 restricts tracing to a parent-child relationship — a reasonable default.","No change needed unless you can move to 2 or 3.");
      else if(v===2) add("INFO","ptrace_scope = 2 allows tracing only for administrators (CAP_SYS_PTRACE).","No change needed.");
      else if(v===3) add("INFO","ptrace_scope = 3 is the most restrictive setting: no process can be traced at all, not even by administrators.","No change needed — this is the strictest option.");
      else add("BLOCKER","ptrace_scope = " + v + " is outside its valid range of 0 to 3.","Set kernel.yama.ptrace_scope to a value from 0 to 3 (1 is the usual default).");
      break;
    case "kernel.perf_event_paranoid":
      if(v<=-1) add("WARNING","perf_event_paranoid = " + v + " is the most permissive band: unprivileged users get unrestricted performance-event access, which has repeatedly been an exploit surface. Bands: -1 to 0 = wide open, 1 = per-process measurements only for unprivileged users, 2 = user-space measurements only, 3 = no unprivileged perf access, 4 = maximum restriction on newer kernels.","Set kernel.perf_event_paranoid to 2 or higher unless unprivileged profiling is required.");
      else if(v===0) add("WARNING","perf_event_paranoid = 0 is a permissive band: unprivileged users can collect CPU-wide performance data. Bands: -1 to 0 = wide open, 1 = per-process only, 2 = user-space only, 3 = no unprivileged access, 4 = maximum restriction.","Set kernel.perf_event_paranoid to 2 or higher unless unprivileged profiling is required.");
      else if(v===1) add("INFO","perf_event_paranoid = 1 is a middle band: unprivileged users are limited to per-process measurements (no CPU-wide profiling). Bands run from -1 (wide open) to 4 (maximum restriction).","No change needed for most hosts; 2 or 3 is stricter.");
      else if(v===2) add("INFO","perf_event_paranoid = 2 limits unprivileged users to user-space measurements only — a sound hardened band. Bands run from -1 (wide open) to 4 (maximum restriction).","No change needed.");
      else if(v===3 || v===4) add("INFO","perf_event_paranoid = " + v + " is a restrictive band: unprivileged performance-event access is denied or nearly so. Bands run from -1 (wide open) to 4 (maximum restriction).","No change needed.");
      else add("BLOCKER","perf_event_paranoid = " + v + " is outside its known band of -1 to 4.","Set kernel.perf_event_paranoid to a value from -1 to 4 (2 or 3 recommended).");
      break;
    case "kernel.modules_disabled":
      if(v===0) add("INFO","modules_disabled = 0 means kernel modules can still be loaded. That is not itself unsafe — it is the normal state that lets a running system load drivers — it only means the kernel is not locked against later module loads.","No fix required. Set kernel.modules_disabled = 1 only on a finished, static system, knowing it cannot be undone without a reboot.");
      else if(v===1) add("INFO","modules_disabled = 1 locks the kernel against any further module loading until reboot.","No change needed.");
      break;
    case "kernel.unprivileged_bpf_disabled":
      if(v===0) add("WARNING","unprivileged_bpf_disabled = 0 lets unprivileged users create eBPF programs, a repeated source of kernel privilege-escalation bugs.","Set kernel.unprivileged_bpf_disabled = 1 (or 2 to lock it permanently until reboot).");
      break;
    case "net.core.bpf_jit_harden":
      if(v===0) add("WARNING","bpf_jit_harden = 0 leaves the eBPF JIT without extra hardening, so JIT spray attacks stay easier if unprivileged BPF is reachable.","Set net.core.bpf_jit_harden = 1, or 2 for the strongest hardening.");
      break;
    case "fs.suid_dumpable":
      if(v===2) add("WARNING","suid_dumpable = 2 (\"suidsafe\") lets setuid programs dump core readable by root debugging — core files from privileged programs can contain secrets, and this mode exists for debugging, not production.","Set fs.suid_dumpable = 0 unless you are actively debugging a setuid program.");
      else if(v<0 || v>2) add("BLOCKER","suid_dumpable = " + v + " is outside its valid range of 0 to 2.","Set fs.suid_dumpable to 0.");
      break;
    case "vm.swappiness":
      if(v<0 || v>100) add("BLOCKER","vm.swappiness = " + v + " is outside the valid range of 0 to 100 — arithmetic check failed, and sysctl would reject or misapply this value.","Set vm.swappiness to a value from 0 to 100 (10 is a common server choice; 60 is the kernel default).");
      else if(v>=60 && role==="server") add("INFO","vm.swappiness = " + v + " on a server: this is the kernel-default neighborhood and only an INFO note, never an alarm. Higher swappiness swaps sooner, which some database and latency-sensitive servers prefer to avoid — a tuning preference, not a safety problem.","Optional tuning only: lower vm.swappiness (for example to 10) if this server prefers keeping application memory in RAM.");
      else if(v>=60) add("INFO","vm.swappiness = " + v + " favors swapping sooner rather than reclaiming page cache. That is a performance preference, not a safety problem.","Optional tuning only — adjust to taste for this host's workload.");
      break;
    case "kernel.randomize_va_space":
      if(v===0) add("WARNING","randomize_va_space = 0 disables ASLR, removing address-space randomization that makes memory-corruption exploits unreliable.","Set kernel.randomize_va_space = 2 (full randomization).");
      break;
    case "fs.protected_hardlinks":
      if(v===0) add("WARNING","protected_hardlinks = 0 lets users hardlink files they cannot read or write, a known privilege-escalation helper.","Set fs.protected_hardlinks = 1.");
      break;
    case "fs.protected_symlinks":
      if(v===0) add("WARNING","protected_symlinks = 0 disables symlink protections in world-writable directories, enabling symlink-following attacks on privileged programs.","Set fs.protected_symlinks = 1.");
      break;
    case "kernel.sysrq":
      if(v!==0) add("INFO","kernel.sysrq = " + v + " enables some or all magic SysRq key functions. That is a console-access consideration, not a network risk.","Set kernel.sysrq = 0 on servers where console SysRq is not wanted.");
      break;
    default:
      break;
  }
}

var PROTECTIVE = [
  {key:"net.ipv4.tcp_rfc1337", label:"net.ipv4.tcp_rfc1337 = 1"},
  {key:"net.ipv4.icmp_echo_ignore_broadcasts", label:"net.ipv4.icmp_echo_ignore_broadcasts = 1"},
  {key:"net.ipv4.icmp_ignore_bogus_error_responses", label:"net.ipv4.icmp_ignore_bogus_error_responses = 1"}
];

function audit(text, role){
  var parsed = parse(text);
  var findings = [];
  var good = [];
  // group occurrences
  var byKey = {};
  var order = [];
  parsed.entries.forEach(function(e){
    if(!byKey[e.key]){ byKey[e.key]=[]; order.push(e.key); }
    byKey[e.key].push(e);
  });
  var effective = [];
  order.forEach(function(k){
    var occ = byKey[k];
    var eff = occ[occ.length-1];
    effective.push({key:k, raw:eff.raw, line:eff.line, occurrences:occ.map(function(o){return o.line;}), audited:isKnownKey(k)});
    if(occ.length>1){
      findings.push({
        line: eff.line, severity:"INFO", key:k,
        message:"Duplicate key: " + k + " appears on lines " + occ.map(function(o){return o.line;}).join(" and ") + ". Within one pasted file the LAST value wins, so only the line " + eff.line + " value is graded. Across multiple sysctl.d files the load order decides — NOT SETTLED from one file.",
        fix:"Remove the earlier duplicate line(s) so the file says what it means in one place, keeping the value you actually want."
      });
    }
    grade(eff, role, findings, good);
  });
  parsed.unparsable.forEach(function(u){
    findings.push({line:u.line, severity:"WARNING", key:"(unparsable line)", message:"Line " + u.line + " could not be parsed as a key = value pair, so it was excluded from the audit. Nothing on that line was graded.", fix:"Fix the line to the form key = value, or turn it into a comment starting with #, or delete it."});
  });
  // sort findings: BLOCKER, WARNING, INFO/GOOD order then line
  var rank = {BLOCKER:0, WARNING:1, INFO:2, GOOD:3};
  findings.sort(function(a,b){ return (rank[a.severity]-rank[b.severity]) || (a.line-b.line); });

  var nB = findings.filter(function(f){return f.severity==="BLOCKER";}).length;
  var nW = findings.filter(function(f){return f.severity==="WARNING";}).length;
  var nI = findings.filter(function(f){return f.severity==="INFO";}).length;
  var verdict = nB>0 ? "DO NOT APPLY" : (nW>0 ? "APPLY WITH FIXES" : "SAFE TO APPLY");

  var protectiveStatus = PROTECTIVE.map(function(p){
    var occ = byKey[p.key];
    if(!occ) return {key:p.key, status:"NOT SET", line:null};
    var eff = occ[occ.length-1];
    var isInt = /^-?\d+$/.test(eff.raw);
    if(isInt && parseInt(eff.raw,10)===1) return {key:p.key, status:"GOOD", line:eff.line};
    return {key:p.key, status:"SET — NOT PROTECTIVE VALUE", line:eff.line};
  });
  var unknownCount = effective.filter(function(e){return !e.audited;}).length;
  return {
    role: role, verdict: verdict,
    counts:{blocker:nB, warning:nW, info:nI, good:good.length},
    findings: findings, good: good, effective: effective,
    protective: protectiveStatus,
    unparsable: parsed.unparsable, unknownCount: unknownCount,
    totalLines: text.split(/\r?\n/).length, parsedKeys: parsed.entries.length
  };
}

function roleLabel(role){
  if(role==="workstation") return "Workstation / desktop";
  if(role==="router") return "Router-or-VPN";
  return "Server";
}

var lastResult = null;
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-sysctl-kernel-parameter-safety-auditortm',
  name: 'J-Dawgs sysctl Kernel Parameter Safety Auditor',
  description: 'sysctl --load applies values and grades nothing; ours grades a pasted sysctl file offline with a host-role selector — insecure kernel/network parameters and duplicate keys resolved with both lines named — into one apply verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
