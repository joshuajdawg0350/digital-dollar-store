'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Publish Accessibility Pre-Flight Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var FLAWED = [
          "<h1>Spring Bake Sale</h1>",
          "<p>Join us Saturday for the neighborhood bake sale fundraiser.</p>",
          "<img src=\"bake-sale-table.jpg\">",
          "<img src=\"IMG_2043.jpg\" alt=\"IMG_2043.jpg\">",
          "<h1>What We Are Selling</h1>",
          "<h3>Breads and Pies</h3>",
          "<p>Full price list is posted at the hall. <a href=\"https://example.com/price-list\">click here</a> to see it.</p>",
          "<p>Questions about volunteering? <a href=\"https://example.com/volunteer\">read more</a></p>",
          "",
          "![ ](raffle-prizes.png)",
          "",
          "See the raffle rules: [https://example.com/raffle-rules](https://example.com/raffle-rules)",
          "",
          "## Saturday Schedule",
          "",
          "#### Morning Setup Crew",
          "<p>Setup starts at 7 AM in the community hall.</p>"
        ].join("\n");

        var CLEAN = [
          "<h1>Spring Bake Sale</h1>",
          "<p>Join us Saturday for the neighborhood bake sale fundraiser.</p>",
          "<img src=\"bake-sale-table.jpg\" alt=\"Volunteers arranging pies and bread loaves on the bake sale table\">",
          "<h2>What We Are Selling</h2>",
          "<p>Breads, pies, and preserves, baked by neighbors on our street.</p>",
          "<h3>Breads and Pies</h3>",
          "<p>See the <a href=\"https://example.com/price-list\">full bake sale price list</a> before you come.</p>",
          "<p>Want to help? Read the <a href=\"https://example.com/volunteer\">volunteer shift guide</a> and pick a slot.</p>",
          "",
          "![Three raffle prize baskets wrapped in cellophane on a table](raffle-prizes.png)",
          "",
          "## Saturday Schedule",
          "",
          "Setup starts at 7 AM in the community hall. The full schedule is in the [bake sale day timeline](https://example.com/timeline)."
        ].join("\n");

        var GENERIC_LABELS = [
          "click here", "here", "read more", "learn more", "more", "more info",
          "this", "this link", "this page", "link", "details", "info", "go",
          "go here", "check it out", "see more", "find out more", "click", "tap here"
        ];

        var SEV_RANK = { high: 0, medium: 1, low: 2 };
        var SEV_LABEL = { high: "Blocker", medium: "Warning", low: "Polish" };

        var sourceEl = document.getElementById("source");
        var resultsEl = document.getElementById("results");
        var lastReport = "";

        function lineStarts(text) {
          var starts = [0];
          for (var i = 0; i < text.length; i++) {
            if (text.charCodeAt(i) === 10) starts.push(i + 1);
          }
          return starts;
        }
        function lineOf(starts, idx) {
          var lo = 0, hi = starts.length - 1, ans = 0;
          while (lo <= hi) {
            var mid = (lo + hi) >> 1;
            if (starts[mid] <= idx) { ans = mid; lo = mid + 1; } else { hi = mid - 1; }
          }
          return ans + 1;
        }
        function esc(s) {
          return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
        }
        function stripTags(s) {
          return s.replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim();
        }
        function isUrlText(s) {
          return /^(https?:\/\/|www\.)\S+$/i.test(s.trim());
        }
        function isFilenameAlt(alt, src) {
          var a = alt.trim();
          if (/\.(jpe?g|png|gif|webp|svg|avif|bmp|tiff?)$/i.test(a)) return true;
          if (/^(img|image|dsc|dscn|pic|photo|screenshot|screen shot|untitled|pxl|px|wp)[-_ ]?\d+/i.test(a)) return true;
          if (/^img[-_ ]?\d+$/i.test(a)) return true;
          if (src) {
            var base = src.split("/").pop().split("?")[0];
            if (base && a.toLowerCase() === base.toLowerCase()) return true;
          }
          return false;
        }
        function filenameHint(src) {
          if (!src) return "the image";
          var base = src.split("/").pop().split("?")[0].replace(/\.[a-z0-9]+$/i, "");
          var words = base.replace(/[-_]+/g, " ").replace(/\b(img|image|dsc|pic)\b/gi, "").replace(/\b\d+\b/g, "").trim();
          return words || "the image";
        }
        function pageNameFromHref(href) {
          var clean = href.replace(/[?#].*$/, "").replace(/\/+$/, "");
          var seg = clean.split("/").pop() || "";
          seg = seg.replace(/\.[a-z0-9]+$/i, "").replace(/[-_]+/g, " ").trim();
          if (!seg || /^[0-9]+$/.test(seg)) return "the linked page";
          return "the " + seg + " page";
        }

        function audit(text) {
          var findings = [];
          var starts = lineStarts(text);
          var headings = []; // {level, text, line, kind}
          var i, m;

          function add(sev, check, name, loc, detail, fix) {
            findings.push({ sev: sev, check: check, name: name, loc: loc, detail: detail, fix: fix, order: findings.length });
          }

          /* ---------- HTML images ---------- */
          var imgRe = /<img\b[^>]*>/gi;
          while ((m = imgRe.exec(text)) !== null) {
            var tag = m[0];
            var line = lineOf(starts, m.index);
            var srcM = tag.match(/\bsrc\s*=\s*["']([^"']*)["']/i);
            var src = srcM ? srcM[1] : "";
            var altM = tag.match(/\balt\s*=\s*["']([^"']*)["']/i);
            var decorative = /\brole\s*=\s*["']presentation["']/i.test(tag) || /\baria-hidden\s*=\s*["']true["']/i.test(tag);
            var shown = src ? "<img src=\"" + src + "\">" : tag.slice(0, 80);
            if (!altM) {
              add("high", "images", "Image with no alt attribute",
                "Line " + line + " · " + shown,
                "This image has no alt attribute at all, so a screen reader will read out the file name or skip it entirely — a reader who cannot see the image gets nothing.",
                "Add a short alt that says what the image shows, e.g. alt=\"…\" describing " + filenameHint(src) + " in a few words. If the image is purely decorative, use alt=\"\" together with role=\"presentation\".");
            } else if (altM[1].trim() === "") {
              if (!decorative) {
                add("medium", "images", "Image with empty alt text",
                  "Line " + line + " · " + shown,
                  "alt=\"\" tells assistive technology to skip this image. That is correct only for purely decorative images. This tag is not marked decorative (no role=\"presentation\"), so if the image carries any information, that information is lost.",
                  "If the image matters, write what it shows, e.g. alt=\"…\" describing " + filenameHint(src) + ". If it truly is decoration, keep alt=\"\" and add role=\"presentation\" so the intent is explicit.");
              }
            } else if (isFilenameAlt(altM[1], src)) {
              add("high", "images", "Alt text is just a file name",
                "Line " + line + " · " + shown,
                "alt=\"" + altM[1] + "\" is a file name, not a description. A screen reader will read the file name aloud, which tells the reader nothing about the picture.",
                "Replace the file name with what the image shows, e.g. alt=\"Volunteers packing boxes at the food drive\" — describe " + filenameHint(src) + ", not its file.");
            }
          }

          /* ---------- Markdown images ---------- */
          var mdImgRe = /!\[([^\]]*)\]\(([^)\s]+)(?:\s+["'][^"']*["'])?\)/g;
          while ((m = mdImgRe.exec(text)) !== null) {
            var line2 = lineOf(starts, m.index);
            var alt2 = m[1], src2 = m[2];
            if (alt2.trim() === "") {
              add("high", "images", "Markdown image with empty alt text",
                "Line " + line2 + " · ![](" + src2 + ")",
                "The text between the brackets is empty, so a screen reader gets no description of this image — in Markdown, that bracket text IS the alt text.",
                "Put a description between the brackets, e.g. ![…](" + src2 + ") describing " + filenameHint(src2) + " in a few words.");
            } else if (isFilenameAlt(alt2, src2)) {
              add("high", "images", "Markdown alt text is just a file name",
                "Line " + line2 + " · ![" + alt2 + "](" + src2 + ")",
                "The bracket text is a file name, not a description, so a screen reader reads the file name aloud.",
                "Rewrite the bracket text to describe what the image shows, e.g. ![Volunteers packing boxes](" + src2 + ").");
            }
          }

          /* ---------- HTML links ---------- */
          var aRe = /<a\b[^>]*href\s*=\s*["']([^"']*)["'][^>]*>([\s\S]*?)<\/a>/gi;
          while ((m = aRe.exec(text)) !== null) {
            var href = m[1];
            var label = stripTags(m[2]);
            var line3 = lineOf(starts, m.index);
            checkLink("links", label, href, line3, "<a href=\"" + href + "\">" + (label || "(no text)") + "</a>");
          }

          /* ---------- Markdown links (not images) ---------- */
          var mdLinkRe = /(?<!!)\[([^\]]+)\]\(([^)\s]+)(?:\s+["'][^"']*["'])?\)/g;
          while ((m = mdLinkRe.exec(text)) !== null) {
            var line4 = lineOf(starts, m.index);
            checkLink("links", m[1].trim(), m[2], line4, "[" + m[1] + "](" + m[2] + ")");
          }

          function checkLink(check, label, href, line, shown) {
            var norm = label.toLowerCase().replace(/[.!…]+$/, "").trim();
            if (isUrlText(label)) {
              add("medium", check, "Bare URL used as its own link label",
                "Line " + line + " · " + shown,
                "The link text is the raw URL \"" + label + "\", pointing to " + href + ". Screen readers read URLs out character by character, and the label says nothing about where the link goes or why it is there.",
                "Replace the URL with words that name the destination, e.g. link text like \"" + pageNameFromHref(href) + "\" pointing to " + href + ".");
            } else if (GENERIC_LABELS.indexOf(norm) !== -1) {
              add("medium", check, "Generic link label \"" + label + "\"",
                "Line " + line + " · " + shown,
                "\"" + label + "\" gives a reader no idea where this link leads. It points to " + href + ". Screen-reader users often jump from link to link, and a list of \"click here\" links is meaningless out of context.",
                "Rename the link to describe its destination, e.g. use \"" + pageNameFromHref(href) + "\" as the link text instead of \"" + label + "\".");
            } else if (label.trim() === "") {
              add("medium", check, "Link with no label text",
                "Line " + line + " · destination " + href,
                "This link has no text at all, so there is nothing for a screen reader to announce and nothing visible to click but the bare element.",
                "Give the link descriptive text that names where it goes (" + href + ").");
            }
          }

          /* ---------- HTML headings ---------- */
          var hRe = /<h([1-6])\b[^>]*>([\s\S]*?)<\/h\1>/gi;
          while ((m = hRe.exec(text)) !== null) {
            headings.push({
              level: parseInt(m[1], 10),
              text: stripTags(m[2]),
              line: lineOf(starts, m.index),
              kind: "HTML <h" + m[1] + ">"
            });
          }

          /* ---------- Markdown headings ---------- */
          var lines = text.split("\n");
          var inFence = false;
          for (i = 0; i < lines.length; i++) {
            if (/^\s*```/.test(lines[i])) { inFence = !inFence; continue; }
            if (inFence) continue;
            var hm = lines[i].match(/^(#{1,6})\s+(.*\S)\s*$/);
            if (hm) {
              headings.push({
                level: hm[1].length,
                text: hm[2].replace(/#+\s*$/, "").trim(),
                line: i + 1,
                kind: "Markdown " + hm[1]
              });
            }
          }
          headings.sort(function (a, b) { return a.line - b.line; });

          /* ---------- Heading structure checks ---------- */
          var h1s = headings.filter(function (h) { return h.level === 1; });
          if (h1s.length > 1) {
            var locs = h1s.map(function (h) { return "line " + h.line; }).join(", ");
            add("medium", "headings", h1s.length + " top-level headings (h1) instead of one",
              "Lines: " + locs,
              "A page should have exactly one h1 — the title everything else sits under. This draft has " + h1s.length + ": \"" + h1s.map(function (h) { return h.text; }).join("\", \"") + "\". Multiple h1s flatten the outline a screen reader builds from the headings.",
              "Keep the first h1 (\"" + h1s[0].text + "\") as the page title and demote the others to h2: " + h1s.slice(1).map(function (h) { return "\"" + h.text + "\""; }).join(", ") + ".");
          }
          for (i = 1; i < headings.length; i++) {
            var prev = headings[i - 1], cur = headings[i];
            if (cur.level > prev.level + 1) {
              add("medium", "headings", "Heading level skipped: h" + prev.level + " jumps to h" + cur.level,
                "Line " + cur.line + " · " + cur.kind + " \"" + cur.text + "\" (previous heading h" + prev.level + " on line " + prev.line + ")",
                "Going from h" + prev.level + " straight to h" + cur.level + " skips a level, so the document outline has a hole in it. Readers navigating by heading hear a section appear from nowhere.",
                "Change \"" + cur.text + "\" to h" + (prev.level + 1) + ", or add the missing h" + (prev.level + 1) + " section heading above it.");
            }
          }
          headings.forEach(function (h) {
            if (h.text.length > 120) {
              add("low", "headings", "Heading used as a paragraph (" + h.text.length + " characters)",
                "Line " + h.line + " · " + h.kind,
                "This heading runs " + h.text.length + " characters: \"" + h.text.slice(0, 90) + "…\" Headings are signposts — screen readers list them as an outline, and a paragraph-length entry makes that outline useless.",
                "Shorten it to a brief title (under ~120 characters, ideally far less) and move the rest into a normal paragraph under the heading.");
            }
          });

          findings.sort(function (a, b) {
            return (SEV_RANK[a.sev] - SEV_RANK[b.sev]) || (a.order - b.order);
          });
          return { findings: findings, headings: headings };
        }

        function verdictFor(findings) {
          var high = findings.filter(function (f) { return f.sev === "high"; }).length;
          var med = findings.filter(function (f) { return f.sev === "medium"; }).length;
          var low = findings.filter(function (f) { return f.sev === "low"; }).length;
          if (high > 0) return { key: "bad", stamp: "DO NOT PUBLISH YET", cls: "bad", high: high, med: med, low: low };
          if (findings.length > 0) return { key: "warn", stamp: "PUBLISH WITH FIXES", cls: "warn", high: high, med: med, low: low };
          return { key: "ok", stamp: "READY TO PUBLISH", cls: "ok", high: high, med: med, low: low };
        }

        function buildReport(text, result, v) {
          var out = [];
          out.push("PUBLISH ACCESSIBILITY PRE-FLIGHT REPORT");
          out.push("Tool: J-Dawgs Publish Accessibility Pre-Flight Auditor(TM)");
          out.push("Verdict: " + v.stamp);
          out.push("Source audited: " + text.split("\n").length + " lines, " + text.length + " characters (pasted source only - nothing was fetched or rendered)");
          out.push("Findings: " + result.findings.length + " total - " + v.high + " blocker(s), " + v.med + " warning(s), " + v.low + " polish item(s)");
          out.push("");
          if (result.findings.length === 0) {
            out.push("No findings. Images carry real descriptions, link labels name their destinations, and the heading outline is in order.");
          } else {
            out.push("FIX LIST (worst first):");
            result.findings.forEach(function (f, idx) {
              out.push("");
              out.push((idx + 1) + ". [" + SEV_LABEL[f.sev].toUpperCase() + "] " + f.name);
              out.push("   Where: " + f.loc);
              out.push("   Why it matters: " + f.detail);
              out.push("   Suggested fix: " + f.fix);
            });
          }
          out.push("");
          out.push("Scope note: this is a source-level pre-flight check, not a full WCAG audit. It does not render the page, check color or contrast, or test with a screen reader.");
          return out.join("\n");
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-publish-accessibility-pre-flight-auditor',
  name: 'J-Dawgs Publish Accessibility Pre-Flight Auditor',
  description: 'Pre-publish audit of pasted HTML/Markdown for alt-text, link-label, and heading-structure problems, each named with a fix',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
