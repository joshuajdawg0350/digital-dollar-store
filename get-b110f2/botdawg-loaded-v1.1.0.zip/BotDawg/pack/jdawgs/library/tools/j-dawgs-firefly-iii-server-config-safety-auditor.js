'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Firefly III Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

var RISKY = [
"# Risky example — do not deploy",
"APP_ENV=local",
"APP_DEBUG=true",
"APP_KEY=base64:short",
"APP_URL=http://firefly.example.com",
"SITE_OWNER=admin@example.com",
"ALLOW_REGISTRATION=true",
"TRUSTED_PROXIES=*",
"DB_CONNECTION=mysql",
"DB_HOST=127.0.0.1",
"DB_DATABASE=firefly",
"DB_PASSWORD=secret",
"MYSQL_PASSWORD=123456",
"MAIL_PASSWORD=password",
"WEBHOOK_SECRET=changeme",
"TZ=",
"DISABLE_UPDATE_CHECK=true",
"CRON_ENABLED=false",
"this line cannot be parsed!!!"
].join("\n");

var HARDENED = [
"# Hardened example",
"APP_ENV=production",
"APP_DEBUG=false",
"APP_KEY=base64:Kx9mP2qR7wZ4vN8bT6yU3iO5pA1sD0fG9hJ2kL4mN6pQ8rS0tV",
"APP_URL=https://firefly.internal",
"SITE_OWNER=owner@jdawgs.internal",
"ALLOW_REGISTRATION=false",
"TRUSTED_PROXIES=10.0.0.5,10.0.0.6",
"DB_CONNECTION=mysql",
"DB_HOST=db.internal",
"DB_DATABASE=firefly_prod",
"DB_PASSWORD=X9kLp2QwErTyUiOpAsDfGhJkLzXcVbN8mQ4wE7rT",
"MYSQL_PASSWORD=Z8xCvBnM5qWeRtYuIoP3aSdFgHjKl6zXcVbN9mQ2",
"MAIL_PASSWORD=M4nB8vCxZ2lKjHgFdSaPoIuYtReWq9pLkJhGfDsA",
"WEBHOOK_SECRET=W7eRtYuIoP2aSdFgHjKlZxCvBnM5qWeRtYuIoP3aS",
"TZ=America/Chicago",
"DISABLE_UPDATE_CHECK=false",
"CRON_ENABLED=true"
].join("\n");

var GIBBERISH = "hello world this is not a config\n??? /// ===\njust some random words with no keys at all";

var KNOWN = {"APP_ENV":1,"APP_DEBUG":1,"APP_KEY":1,"APP_URL":1,"SITE_OWNER":1,"ALLOW_REGISTRATION":1,"TRUSTED_PROXIES":1,"DB_CONNECTION":1,"DB_HOST":1,"DB_DATABASE":1,"DB_USERNAME":1,"DB_PASSWORD":1,"MYSQL_PASSWORD":1,"MAIL_PASSWORD":1,"MAIL_HOST":1,"MAIL_FROM":1,"WEBHOOK_SECRET":1,"TZ":1,"DISABLE_UPDATE_CHECK":1,"CRON_ENABLED":1,"CHECK_FOR_UPDATES":1,"SEND_ERROR_MESSAGE":1,"CACHE_DRIVER":1,"SESSION_DRIVER":1,"LOG_CHANNEL":1};
var SECRET_KEYS = {"APP_KEY":1,"DB_PASSWORD":1,"MYSQL_PASSWORD":1,"MAIL_PASSWORD":1,"WEBHOOK_SECRET":1,"MAIL_ENCRYPTION":0};
var EXAMPLE_WORDS = ["example","changeme","change-me","placeholder","your-","your_","password","secret","123456","letmein","default","test123","xxxx","todo","replace-me","insert-"];

function stripQuotes(v){ v=(v||"").trim(); if((v.charAt(0)==='"'&&v.charAt(v.length-1)==='"')||(v.charAt(0)==="'"&&v.charAt(v.length-1)==="'")) v=v.slice(1,-1); return v; }
function isTruthy(v){ v=(v||"").toLowerCase(); return v==="true"||v==="1"||v==="yes"||v==="on"; }
function isFalsy(v){ v=(v||"").toLowerCase(); return v==="false"||v==="0"||v==="no"||v==="off"||v==="disabled"||v==="never"||v==="none"; }
function hasExample(v){ var l=(v||"").toLowerCase(); for(var i=0;i<EXAMPLE_WORDS.length;i++){ if(l.indexOf(EXAMPLE_WORDS[i])!==-1) return true; } return false; }
function esc(s){ return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"); }

function audit(text){
  var findings=[]; var lines=(text||"").split(/\r?\n/);
  var entries=[]; var recognised=0;
  function add(sev,code,line,key,msg){ findings.push({severity:sev,code:code,line:line,key:key,message:msg}); }
  for(var i=0;i<lines.length;i++){
    var ln=i+1; var raw=lines[i]; var t=raw.trim();
    if(t===""||t.charAt(0)==="#") continue;
    var m=t.match(/^([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/);
    if(!m){ add("WARNING","NOT_PARSED",ln,"","NOT PARSED — line "+ln+" could not be parsed as KEY=value and was not graded."); continue; }
    var key=m[1]; var val=stripQuotes(m[2]||"");
    entries.push({key:key,line:ln,value:val,length:val.length});
    if(KNOWN[key]) recognised++;
    var low=val.toLowerCase();
    // APP_ENV
    if(key==="APP_ENV" && low!=="production"){ add("CRITICAL","APP_ENV_NOT_PRODUCTION",ln,key,"APP_ENV is not production (line "+ln+"). Set APP_ENV=production for a live deploy."); }
    // APP_DEBUG
    if(key==="APP_DEBUG" && isTruthy(low)){ add("CRITICAL","APP_DEBUG_TRUE",ln,key,"APP_DEBUG=true on line "+ln+". Debug mode can expose errors and config — set APP_DEBUG=false in production."); }
    // APP_KEY — never render value
    if(key==="APP_KEY"){
      if(val.length===0) add("CRITICAL","APP_KEY_EMPTY",ln,key,"APP_KEY on line "+ln+" is empty (length 0). Generate a full-length key.");
      else if(val.length<32) add("CRITICAL","APP_KEY_SHORT",ln,key,"APP_KEY on line "+ln+" is short (length "+val.length+"). A production key should be full length — regenerate it. Value not shown.");
      else if(hasExample(val)) add("CRITICAL","APP_KEY_EXAMPLE",ln,key,"APP_KEY on line "+ln+" looks like an example / placeholder value (length "+val.length+"). Replace it with a generated key. Value not shown.");
    }
    // SITE_OWNER
    if(key==="SITE_OWNER"){
      if(val.length===0) add("WARNING","SITE_OWNER_EMPTY",ln,key,"SITE_OWNER on line "+ln+" is empty. Set a real owner / admin contact.");
      else if(hasExample(val)||low.indexOf("example.")!==-1||low==="admin"||low.indexOf("@example")!==-1) add("WARNING","SITE_OWNER_EXAMPLE",ln,key,"SITE_OWNER on line "+ln+" looks like a placeholder / example admin contact. Use a real monitored address.");
      else if(val.indexOf("@")===-1) add("WARNING","SITE_OWNER_NOT_EMAIL",ln,key,"SITE_OWNER on line "+ln+" does not look like an email address. Check the admin posture for this install.");
    }
    // Registration
    if((key==="ALLOW_REGISTRATION"||key.indexOf("REGISTRATION")!==-1) && isTruthy(low)){ add("CRITICAL","OPEN_REGISTRATION",ln,key,key+" is true on line "+ln+". Open registration lets anyone create an account — set it to false unless sign-up is intentional and protected."); }
    // APP_URL
    if(key==="APP_URL"){
      if(low.indexOf("http://")===0) add("CRITICAL","APP_URL_HTTP",ln,key,"APP_URL on line "+ln+" uses http://. Use https:// for a finance app.");
      else if(val.indexOf("*")!==-1) add("CRITICAL","APP_URL_WILDCARD",ln,key,"APP_URL on line "+ln+" contains a wildcard. Use the exact HTTPS URL.");
      else if(val.length===0) add("WARNING","APP_URL_EMPTY",ln,key,"APP_URL on line "+ln+" is empty.");
    }
    // TRUSTED_PROXIES
    if(key==="TRUSTED_PROXIES"){
      if(val==="*"||val.indexOf("*")!==-1) add("CRITICAL","TRUSTED_PROXIES_WILDCARD",ln,key,"TRUSTED_PROXIES on line "+ln+" uses wildcard *. Trusting every proxy can spoof client IPs — list only your real proxies.");
      else if(low.indexOf("http")!==-1) add("CRITICAL","TRUSTED_PROXIES_HTTP",ln,key,"TRUSTED_PROXIES on line "+ln+" contains http. List proxy IPs only.");
    }
    // Secrets — name/line/length only
    if(SECRET_KEYS[key] && key!=="APP_KEY"){
      if(val.length===0) add("CRITICAL","SECRET_EMPTY",ln,key,key+" on line "+ln+" is empty (length 0). Set a strong secret via your secret store.");
      else if(val.length<12) add("CRITICAL","SECRET_SHORT",ln,key,key+" on line "+ln+" is short (length "+val.length+"). Use a long, generated secret. Value not shown.");
      else if(hasExample(val)) add("CRITICAL","SECRET_EXAMPLE",ln,key,key+" on line "+ln+" looks like an example / placeholder value (length "+val.length+"). Replace it with a generated secret. Value not shown.");
    }
    // TZ
    if(key==="TZ"){
      if(val.length===0) add("WARNING","TZ_EMPTY",ln,key,"TZ on line "+ln+" is empty. Set an explicit timezone (for example America/Chicago or UTC) so cron and dates behave predictably.");
      else if(hasExample(val)) add("WARNING","TZ_PLACEHOLDER",ln,key,"TZ on line "+ln+" looks like a placeholder. Set a real IANA timezone.");
    }
    // Update checks disabled
    if((key==="DISABLE_UPDATE_CHECK"&&isTruthy(low))||(key==="CHECK_FOR_UPDATES"&&isFalsy(low))||(key.indexOf("UPDATE")!==-1&&key!=="DISABLE_UPDATE_CHECK"&&isFalsy(low))){ add("WARNING","UPDATE_CHECK_DISABLED",ln,key,key+" on line "+ln+" disables update checks. You may miss security updates — re-enable checks or track releases another way."); }
    // Cron disabled
    if((key==="CRON_ENABLED"&&isFalsy(low))||(key==="DISABLE_CRON"&&isTruthy(low))){ add("WARNING","CRON_DISABLED",ln,key,key+" on line "+ln+" disables cron. Scheduled jobs (including security-relevant cleanup and reports) will not run."); }
  }
  // APP_KEY missing check if we have enough context
  var hasKey=false; for(var j=0;j<entries.length;j++) if(entries[j].key==="APP_KEY") hasKey=true;
  if(recognised>=3 && !hasKey){ add("CRITICAL","APP_KEY_MISSING",0,"APP_KEY","APP_KEY is missing entirely. Firefly III needs a full-length generated APP_KEY."); }
  var crit=0,warn=0;
  findings.forEach(function(f){ if(f.severity==="CRITICAL") crit++; else if(f.severity==="WARNING") warn++; });
  var verdict;
  if(recognised<3) verdict="NOT ENOUGH TO GRADE";
  else if(crit>0) verdict="DO NOT DEPLOY";
  else if(warn>0) verdict="DEPLOY WITH FIXES";
  else verdict="SAFE TO DEPLOY";
  return {verdict:verdict,findings:findings,totalLines:lines.length,parsed:entries.length,recognised:recognised,critical:crit,warnings:warn,entries:entries.map(function(e){ return {key:e.key,line:e.line,length:e.length,isSecret:!!SECRET_KEYS[e.key]}; })};
}

function buildReport(r){
  var out=[];
  out.push("J-Dawgs Firefly III Server Config Safety Auditor — Report");
  out.push("Verdict: "+r.verdict);
  out.push("Lines: "+r.totalLines+" | Parsed keys: "+r.parsed+" | Recognised keys: "+r.recognised+" | Critical: "+r.critical+" | Warnings: "+r.warnings);
  out.push("Note: Secrets are reported by key name, line, and length only. No secret values are included.");
  out.push("");
  if(r.findings.length===0){ out.push("No findings."); }
  else r.findings.forEach(function(f){ out.push("["+f.severity+"] Line "+(f.line||"—")+" "+(f.key?f.key+" — ":"")+f.message); });
  out.push("");
  out.push("Heuristic text audit of pasted config only. Does not connect to any server, does not verify secrets, and is not a replacement for the official Firefly III documentation.");
  return out.join("\n");
}

var lastResult=null, lastJson="{}";
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_WORDS": (typeof EXAMPLE_WORDS !== 'undefined' ? EXAMPLE_WORDS : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-firefly-iii-server-config-safety-auditor',
  name: 'J-Dawgs Firefly III Server Config Safety Auditor',
  description: 'Host tools only tell you the server started; ours grades a pasted Firefly III .env offline into one deploy verdict — secrets by key name/line/length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_WORDS": __core["EXAMPLE_WORDS"] }
};
