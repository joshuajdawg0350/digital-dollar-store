'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Placeholder & Leftover-Draft Leakage Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the scan function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var MODE = "prose";
        var lastText = "";
        var lastFindings = null;

        var input = document.getElementById("input");
        var results = document.getElementById("results");
        var checklistCard = document.getElementById("checklist-card");
        var checklistOut = document.getElementById("checklist-out");
        var cleanedZone = document.getElementById("cleaned-zone");

        var WORKED = [
          "Big news from {{store_name}}!",
          "",
          "Our new Trailhead Mug is here — yours for just [insert price].",
          "",
          "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore.",
          "",
          "TODO: add link to the product page before this goes out."
        ].join("\n");

        var CLEAN = [
          "Big news from J-Dawgs Trading Post!",
          "",
          "Our new Trailhead Mug is here — yours for just $18.",
          "",
          "Hand-thrown stoneware, glazed in deep navy. It holds 12 ounces and keeps coffee hot through a morning on the job site.",
          "",
          "Order yours on the J-Dawgs Trading Post page — every mug ships within two business days."
        ].join("\n");

        var CATEGORIES = [
          "TODO & unfinished markers",
          "Placeholders & template variables",
          "Filler text",
          "Example & dummy values",
          "Draft leakage",
          "Dates & relative time"
        ];

        function overlaps(spans, s, e) {
          for (var i = 0; i < spans.length; i++) {
            if (s < spans[i][1] && e > spans[i][0]) return true;
          }
          return false;
        }

        function clip(s, n) {
          s = s.replace(/\s+/g, " ").trim();
          return s.length > n ? s.slice(0, n - 1) + "…" : s;
        }

        function scanLine(lineText, lineNo, mode, findings) {
          var spans = [];
          function add(cat, frag, sev, why, s, e) {
            if (overlaps(spans, s, e)) return;
            spans.push([s, e]);
            findings.push({
              line: lineNo, category: cat, fragment: clip(frag, 90),
              severity: sev, why: why
            });
          }
          function each(re, fn) {
            var m; re.lastIndex = 0;
            while ((m = re.exec(lineText)) !== null) {
              fn(m[0], m.index, m.index + m[0].length, m);
              if (m[0].length === 0) re.lastIndex++;
            }
          }

          /* 1. Unfilled template variables — BLOCKER in every mode. */
          each(/\{\{[^{}\n]{1,60}\}\}/g, function (f, s, e) {
            add("Placeholders & template variables", f, "blocker",
              "Unfilled template variable. The merge never happened, so whatever this ships in will show the raw variable.", s, e);
          });
          if (mode === "config") {
            each(/\$\{[A-Za-z_][\w.]*\}/g, function (f, s, e) {
              add("Placeholders & template variables", f, "blocker",
                "Unfilled ${…} template expression left in a config or code artifact.", s, e);
            });
          }

          /* 2. Lorem ipsum and filler fragments — lorem is a BLOCKER in every mode. */
          each(/lorem ipsum[^.!?\n]*/gi, function (f, s, e) {
            add("Filler text", f, "blocker",
              "Lorem ipsum filler text. The real copy was never written.", s, e);
          });
          each(/\b(dolor sit amet|consectetur adipiscing)\b[^.!?\n]*/gi, function (f, s, e) {
            add("Filler text", f, "blocker",
              "A lorem ipsum fragment — filler text standing where real copy belongs.", s, e);
          });

          /* 3. Bracket and angle placeholders, blank runs. */
          each(/\[[^\]\n]{1,60}\]/g, function (f, s, e, m) {
            var inner = f.slice(1, -1).trim();
            if (/^\d+$/.test(inner) || /https?:/i.test(inner)) return;
            var strong = /\b(insert|your|todo|tbd|replace|placeholder)\b/i.test(inner);
            var weak = /\b(add|enter|fill|name|title|price|link|date|company|product|description|text|email|address|city|amount)\b/i.test(inner)
              || /^[A-Z][a-z]+$/.test(inner)
              || /^[A-Z][a-z]+ [A-Z][a-z]+$/.test(inner)
              || /\.\.\.|…/.test(inner);
            if (strong) {
              add("Placeholders & template variables", f, "blocker",
                "A bracketed slot that was never filled in — the instruction to fill it is still sitting in the finished text.", s, e);
            } else if (weak) {
              add("Placeholders & template variables", f, "warning",
                "Looks like a bracketed placeholder slot (pattern match). If this bracket is deliberate, it can stay.", s, e);
            }
          });
          each(/<insert[^>\n]{0,50}>|<your[^>\n]{0,50}>|<placeholder[^>\n]{0,30}>/gi, function (f, s, e) {
            add("Placeholders & template variables", f, "blocker",
              "An angle-bracket placeholder that was never replaced.", s, e);
          });
          each(/_{3,}/g, function (f, s, e) {
            add("Placeholders & template variables", f, "warning",
              "A blank run waiting to be filled in — an unfilled field in a finished artifact.", s, e);
          });

          /* 4. TODO markers. */
          each(/\b(TODO|FIXME)\b[:\s—-]*/g, function (f, s, e) {
            add("TODO & unfinished markers", clip(lineText.slice(s, Math.min(lineText.length, s + 60)), 90), "blocker",
              "An unfinished-work marker left in a finished artifact. The task it names is still open.", s, Math.min(lineText.length, s + 60));
          });
          each(/\b(TBD|WIP|XXX)\b/g, function (f, s, e) {
            add("TODO & unfinished markers", f, "warning",
              "A to-be-decided / work-in-progress marker. In a finished artifact this reads as undecided, not done.", s, e);
          });
          each(/coming soon/gi, function (f, s, e) {
            add("TODO & unfinished markers", f, "warning",
              "“Coming soon” in a finished artifact means the thing it points at is not there yet.", s, e);
          });

          /* 5. Other filler wording. */
          each(/placeholder text/gi, function (f, s, e) {
            add("Filler text", f, "blocker",
              "The text literally labels itself as placeholder text.", s, e);
          });
          each(/sample text|dummy text|dummy content/gi, function (f, s, e) {
            add("Filler text", f, "warning",
              "Sample/dummy wording — stand-in copy that was meant to be replaced with the real thing.", s, e);
          });
          if (mode !== "config") {
            each(/\bdummy\b/gi, function (f, s, e) {
              add("Filler text", f, "warning",
                "The word “dummy” usually marks stand-in content (heuristic match).", s, e);
            });
          }

          /* 6. Example & dummy values. Severity depends on mode:
                config/code → blocker; prose, page copy, email → warning. */
          var exSev = mode === "config" ? "blocker" : "warning";
          var exWhy = mode === "config"
            ? "An example value in a config or code artifact is a blocker: the config will run against the example instead of the real thing."
            : "An example value in finished copy — readers will see (or write to) the example instead of the real address.";
          each(/[\w.+-]+@example\.(com|org|net)\b/gi, function (f, s, e) {
            add("Example & dummy values", f, exSev, exWhy, s, e);
          });
          each(/(https?:\/\/)?(www\.)?[\w-]*example\.(com|org|net)([^\s"')\]]*)?/gi, function (f, s, e) {
            add("Example & dummy values", f, exSev, exWhy, s, e);
          });
          each(/[\w.+-]*test@test[\w.]*/gi, function (f, s, e) {
            add("Example & dummy values", f, exSev,
              "A test address left where a real one belongs.", s, e);
          });
          each(/change[-_ ]?me\b|your[-_ ]?api[-_ ]?key\b|YOUR_[A-Z0-9_]*_HERE\b|your[-_ ]?key[-_ ]?here\b/gi, function (f, s, e) {
            add("Example & dummy values", f, exSev,
              mode === "config"
                ? "A changeme-style placeholder value. The real credential or value was never filled in."
                : "A changeme-style placeholder value left in the text.", s, e);
          });
          each(/\b[xX]{4,}\b/g, function (f, s, e) {
            add("Example & dummy values", f, exSev,
              "A run of x’s standing in for a real value (an ID, a key, a number) that was never supplied.", s, e);
          });
          if (mode === "config") {
            each(/(?:=|:)\s*["']?(foo|bar|baz)\b/gi, function (f, s, e) {
              add("Example & dummy values", f, "warning",
                "foo/bar/baz used as an actual value in a config — the classic programmer stand-in that was never swapped out.", s, e);
            });
            each(/\b(12345|123456|1234567|12345678|11111|00000)\b/g, function (f, s, e) {
              add("Example & dummy values", f, "warning",
                "A dummy number sequence in a config value — the shape of a number someone typed just to have something there.", s, e);
            });
          }

          /* 7. Draft leakage. */
          each(/\bdo not (send|publish|post)\b[^.!?\n]*/gi, function (f, s, e) {
            add("Draft leakage", f, "blocker",
              "A do-not-send instruction is still in the text. If this ships, the instruction ships with it.", s, e);
          });
          each(/(^|\s)draft\s*[:—–-]/gi, function (f, s, e) {
            add("Draft leakage", f, "blocker",
              "A “draft:” label survived into the finished artifact.", s, e);
          });
          each(/note to self|internal note|as mentioned in my prompt|per my instructions|as (instructed|described) in (the|my) prompt/gi, function (f, s, e) {
            add("Draft leakage", f, "warning",
              "Internal-note phrasing — words written for the author or the drafting process, not for the reader.", s, e);
          });
          if (mode !== "config") {
            each(/as an AI( language model)?\b|I cannot browse|I (don't|do not) have (access|the ability) to/gi, function (f, s, e) {
              add("Draft leakage", f, "warning",
                "AI self-reference left over from the drafting chat. Readers of the finished piece should never meet it.", s, e);
            });
          }

          /* 8. Dates & relative time — INFO only, never blocks. */
          each(/\b\d{4}-\d{2}-\d{2}\b/g, function (f, s, e) {
            add("Dates & relative time", f, "info",
              "A hard date in YYYY-MM-DD form. Listed so a human can eyeball it — wrong dates are the quietest way a finished text goes stale.", s, e);
          });
          if (mode === "email") {
            each(/\b(yesterday|tomorrow)\b/gi, function (f, s, e) {
              add("Dates & relative time", f, "info",
                "A relative date in an email. It rots the moment the send slips a day — worth a human glance before sending.", s, e);
            });
          }
        }

        function scan(text, mode) {
          var findings = [];
          var lines = text.split("\n");
          for (var i = 0; i < lines.length; i++) {
            scanLine(lines[i], i + 1, mode, findings);
          }
          findings.sort(function (a, b) {
            if (a.line !== b.line) return a.line - b.line;
            return CATEGORIES.indexOf(a.category) - CATEGORIES.indexOf(b.category);
          });
          return findings;
        }
  return { "scan": (typeof scan !== 'undefined' ? scan : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["scan"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-placeholder-and-leftover-draft-leakage-auditor',
  name: 'J-Dawgs Placeholder & Leftover-Draft Leakage Auditor',
  description: 'Audit a finished draft, page, listing, or config before it ships: TODOs, [insert …] placeholders, unfilled {{variables}}, lorem ipsum, example.com and dummy values, and leftover draft notes are swept by mode and named by line — it never invents replacements — and one verdict: READY TO SHIP / SHIP WI',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["scan"]) return { ok: false, output: null, summary: 'Extracted core has no scan function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
