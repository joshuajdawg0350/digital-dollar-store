'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Knot Resolver Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var RISKY = [
          "-- Worked example: risky Knot Resolver config",
          "-- Public recursive resolver, wide open",
          "net.listen('0.0.0.0', 53)",
          "net.listen('0.0.0.0', 853, { kind = 'tls' })",
          "net.listen('::', 443, { kind = 'doh2' })",
          "",
          "modules = {",
          "  'stats',",
          "  'prefill',",
          "  http = {",
          "    host = '0.0.0.0',",
          "    port = 8053,",
          "    cert = false,",
          "  },",
          "}",
          "",
          "cache.size = 4096 * MB",
          "prefill.config({",
          "  { url = 'http://keys.example.net/root.keys', interval = 86400 },",
          "})",
          "",
          "management_password = 'kresd123'",
          "api_token = 'abc123'"
        ].join("\n");

        var HARDENED = [
          "-- Worked example: hardened Knot Resolver config",
          "-- Recursive resolver for one trusted LAN only",
          "net.listen('127.0.0.1', 53)",
          "net.listen('10.20.0.53', 53)",
          "net.listen('10.20.0.53', 853, { kind = 'tls' })",
          "net.tls('/etc/knot-resolver/tls/cert.pem', '/etc/knot-resolver/tls/key.pem')",
          "",
          "modules = { 'policy', 'view', 'hints' }",
          "",
          "-- Only the trusted LAN may query; everything else is dropped",
          "view:addr('10.20.0.0/16', policy.all(policy.PASS))",
          "policy.add(policy.all(policy.DROP))",
          "",
          "cache.size = 512 * MB"
        ].join("\n");

        var KNOWN_MODULES = ["policy","view","hints","stats","http","prefill","predict","dntap","nsid",
          "renumber","etc_hosts","graphite","dns64","serve_stale","edns_keepalive","refuse_nord",
          "priming","detect_time_skew","workarounds","bogus_log","ta_signal_query","validate","iterate"];

        var SENSITIVE_KEY = /pass(word|wd)?|secret|token|api[-_]?key|apikey|auth[-_]?key|credential|private[-_]?key|tsig[-_]?key|access[-_]?key/i;

        function isWildcard(addr){
          return addr === "0.0.0.0" || addr === "::" || addr === "[::]" || addr === "*" || addr === "" || addr === "0";
        }
        function isLoopback(addr){
          return addr === "127.0.0.1" || addr === "::1" || addr === "[::1]" || addr === "localhost" || /^127\./.test(addr);
        }
        function isPrivate(addr){
          if (/^10\./.test(addr) || /^192\.168\./.test(addr)) return true;
          var m = addr.match(/^172\.(\d+)\./);
          if (m){ var n = parseInt(m[1],10); if (n >= 16 && n <= 31) return true; }
          return /^fd[0-9a-f]{2}:/i.test(addr) || /^fe80:/i.test(addr);
        }

        function audit(text){
          var findings = [];
          var secrets = [];
          var listeners = [];
          var signals = 0;
          var lines = text.split(/\r?\n/);

          function add(sev, cat, title, detail){
            findings.push({severity:sev, category:cat, title:title, detail:detail});
          }

          /* ---------- Listen addresses ---------- */
          var listenRe = /net\.listen\s*\(\s*['"]([^'"]*)['"]\s*(?:,\s*(\d+))?\s*(?:,\s*\{([^}]*)\})?/g;
          var lm;
          var lineOf = function(idx){ return text.slice(0, idx).split(/\r?\n/).length; };
          while ((lm = listenRe.exec(text)) !== null){
            var kind = "dns";
            if (lm[3]){ var km = lm[3].match(/kind\s*=\s*['"]([a-z0-9]+)['"]/i); if (km) kind = km[1].toLowerCase(); }
            listeners.push({address:lm[1], port: lm[2] ? parseInt(lm[2],10) : null, kind:kind, line: lineOf(lm.index)});
          }
          if (listeners.length) signals += 2;

          var hasPolicy = /policy\s*[.:]/.test(text) || /['"]policy['"]/.test(text);
          var hasView = /view\s*[.:]/.test(text) || /['"]view['"]/.test(text);
          var hasDrop = /policy\.(DROP|DENY)/.test(text) || /policy\.all\s*\(\s*policy\.(DROP|DENY)/.test(text);
          if (hasPolicy) signals += 1;
          if (hasView) signals += 1;
          var hasAcl = hasPolicy || hasView;

          var wildcardDns = false, wildcardAny = false;
          listeners.forEach(function(L){
            var where = "line " + L.line + " — " + (L.address || "(no address)") + (L.port ? ", port " + L.port : "") + ", kind '" + L.kind + "'";
            if (isWildcard(L.address)){
              wildcardAny = true;
              if (L.kind === "dns") wildcardDns = true;
              add("critical","Listen","Wildcard listen address (" + where + ")",
                "This socket answers on every interface. That is only safe behind strict policy/view rules and a firewall — and this scanner grades the config, not your firewall.");
            } else if (isLoopback(L.address)){
              add("pass","Listen","Loopback-only listener (" + where + ")",
                "Bound to loopback: only clients on this host can reach it.");
            } else if (isPrivate(L.address)){
              if (hasAcl){
                add("pass","Listen","Specific private address with policy/view present (" + where + ")",
                  "Bound to one private address, and the config carries policy/view rules to say who may query.");
              } else {
                add("warning","Listen","Specific private address, no policy/view (" + where + ")",
                  "Bound to one private address, but nothing in the config restricts which clients on that network may query it.");
              }
            } else {
              add(hasAcl ? "warning" : "critical","Listen","Specific public address listener (" + where + ")",
                hasAcl
                  ? "Bound to one public address and policy/view rules exist — confirm those rules really cover this socket."
                  : "Bound to a public address with no policy/view rules anywhere in the config: anyone who can reach it can use it.");
            }
          });
          if (!listeners.length){
            add("warning","Listen","No net.listen found",
              "No listener was recognized. Either the paste is incomplete, listeners are built from variables this scanner cannot resolve, or the resolver would run on defaults you have not reviewed here.");
          }

          /* ---------- Open resolver / ACL / policy ---------- */
          if (listeners.length){
            if (!hasAcl){
              add(wildcardDns || wildcardAny ? "critical" : "warning","Policy / ACL","No policy or view rules anywhere",
                "No policy.* calls, no view rules, and neither module is loaded. Nothing in this config says who may query — combined with the listeners above, that is the open-resolver posture kresd will happily start with.");
            } else {
              add("pass","Policy / ACL","Policy/view rules present",
                "The config carries " + (hasPolicy && hasView ? "policy and view" : (hasPolicy ? "policy" : "view")) +
                " rules" + (hasDrop ? ", including a DROP/DENY rule, so there is a default refusal for everyone not allowed" : "") +
                ". Confirm the allowed networks match the listeners above.");
              if (!hasDrop && wildcardAny){
                add("warning","Policy / ACL","Wildcard listener without a DROP/DENY backstop",
                  "Rules exist, but no DROP or DENY rule was found while a socket listens on all interfaces. Anything the allow rules miss may still be answered.");
              }
            }
          }
          if (/policy\.all\s*\(\s*policy\.PASS/.test(text) && !hasView && !hasDrop){
            add("warning","Policy / ACL","policy.all(policy.PASS) with no narrowing rule",
              "An allow-everything policy with no view restriction and no DROP backstop answers every client that reaches the socket.");
          }

          /* ---------- TLS posture ---------- */
          var tlsKinds = listeners.filter(function(L){ return L.kind === "tls" || L.kind === "doh" || L.kind === "doh2"; });
          var tlsConfigured = /net\.tls\s*\(\s*['"][^'"]+['"]\s*,\s*['"][^'"]+['"]/.test(text);
          if (/net\.tls\s*\(/.test(text)) signals += 1;
          if (tlsKinds.length){
            if (tlsConfigured){
              add("pass","TLS","Encrypted listeners have a certificate configured",
                tlsKinds.length + " TLS/DoH listener(s) found and net.tls is given a certificate file and a key file. (File contents and expiry are not checked — kresd and your CA checks still own that.)");
            } else {
              add("critical","TLS","TLS/DoH listener with no certificate configured",
                tlsKinds.length + " listener(s) use kind 'tls'/'doh'/'doh2', but no net.tls(cert, key) with both files was found. Encrypted DNS with no certificate behind it is exactly the silent gap startup will not grade for you.");
            }
          } else if (tlsConfigured){
            add("info","TLS","Certificate configured but no TLS/DoH listener found",
              "net.tls sets a certificate, yet no listener uses kind 'tls', 'doh', or 'doh2'. Harmless, but the encrypted service you think you offer may not exist.");
          } else if (listeners.length){
            add("info","TLS","No DNS-over-TLS / DNS-over-HTTPS listeners",
              "Plain DNS only. Fine for a trusted LAN resolver; a gap if clients were promised encrypted DNS.");
          }
          if (/cert\s*=\s*false/.test(text)){
            add("critical","TLS","Plaintext endpoint: cert = false",
              "An endpoint in this config explicitly disables its certificate. Whatever it serves — classically the http management/webmgmt surface — goes out unencrypted.");
          }

          /* ---------- Modules ---------- */
          var modulesFound = [];
          var modRegion = "";
          var modIdx = text.search(/modules\s*=/);
          if (modIdx >= 0){ modRegion = text.slice(modIdx, modIdx + 1200); signals += 1; }
          var loadRe = /modules\.load\s*\(\s*['"]([a-z0-9_]+)['"]/gi, lmod;
          while ((lmod = loadRe.exec(text)) !== null){ if (modulesFound.indexOf(lmod[1].toLowerCase()) < 0) modulesFound.push(lmod[1].toLowerCase()); }
          KNOWN_MODULES.forEach(function(name){
            if (modRegion && new RegExp("['\"]" + name + "['\"]").test(modRegion) && modulesFound.indexOf(name) < 0) modulesFound.push(name);
          });
          var hasHttpModule = modulesFound.indexOf("http") >= 0 || /\bhttp\s*=\s*\{/.test(text);
          var hasStats = modulesFound.indexOf("stats") >= 0;
          if (modulesFound.length){
            add("info","Modules","Modules recognized: " + modulesFound.join(", "),
              "The loaded set is graded below; an unrecognized module name is not treated as safe or unsafe, just unseen.");
          }
          if (hasHttpModule){
            var httpWild = /host\s*=\s*['"]0\.0\.0\.0['"]/.test(text) || /host\s*=\s*['"]::['"]/.test(text);
            add(httpWild ? "critical" : "warning","Modules","http module loaded — management / webmgmt surface",
              httpWild
                ? "The http module is loaded and an http host is bound to all interfaces. The resolver's management/webmgmt surface should never face every network the host sits on."
                : "The http module exposes management/webmgmt endpoints. Keep its host on loopback or a management network, with a certificate — never as a side door next to the DNS service.");
            signals += 1;
          }
          if (hasStats && hasHttpModule){
            add("warning","Modules","stats + http together publish resolver statistics",
              "With both loaded, resolver statistics are typically served over the http surface. Useful in a lab, an information leak in production.");
          } else if (hasStats){
            add("info","Modules","stats module loaded",
              "Statistics collection on its own is low risk; it becomes exposure when paired with the http module or a remote exporter.");
          }
          if (!hasHttpModule && modulesFound.length){
            add("pass","Modules","No http management module loaded",
              "No http module in the loaded set, so there is no webmgmt/management HTTP surface to expose.");
          }

          /* ---------- Cache & prefill ---------- */
          var cacheMatch = text.match(/cache\.size\s*=\s*([\d.]+)\s*\*\s*(GB|MB|KB)/i) || text.match(/cache\.size\s*=\s*(\d{4,})/);
          if (/cache\s*[.:]/.test(text)) signals += 1;
          if (cacheMatch){
            var mb;
            if (cacheMatch[2]){ var v = parseFloat(cacheMatch[1]); var u = cacheMatch[2].toUpperCase(); mb = u === "GB" ? v*1024 : (u === "KB" ? v/1024 : v); }
            else { mb = parseInt(cacheMatch[1],10) / (1024*1024); }
            mb = Math.round(mb);
            if (mb > 2048){
              add("warning","Cache","Oversized cache: about " + mb + " MB",
                "A multi-GB cache buys little hit-rate and costs real memory on the host. Size the cache to the machine, not to the biggest number that parses.");
            } else if (mb < 16){
              add("warning","Cache","Very small cache: about " + mb + " MB",
                "Under roughly 16 MB the cache churns constantly and upstream traffic climbs. Most LAN resolvers do well in the 100–1000 MB range.");
            } else {
              add("pass","Cache","Sane cache size: about " + mb + " MB",
                "Inside the range a working resolver can actually use without starving the host.");
            }
          } else if (listeners.length){
            add("info","Cache","No cache.size set in the pasted config",
              "kresd will run with its default cache. Defaults are survivable; an explicit size sized to the host is better.");
          }
          if (modulesFound.indexOf("prefill") >= 0 || /prefill\s*[.:]/.test(text)){
            signals += 1;
            if (/url\s*=\s*['"]http:\/\//.test(text)){
              add("warning","Cache / Prefill","Prefill fetches over plain HTTP",
                "A prefill URL using http:// pulls trust-anchor or root data without transport protection. Use the https:// source.");
            } else {
              add("info","Cache / Prefill","prefill module present",
                "Prefill keeps root/trust data warm. Confirm its URLs are https and its interval is sane; this scanner does not fetch them.");
            }
          }

          /* ---------- Secrets (name / line / length only) ---------- */
          lines.forEach(function(lineText, i){
            var re = /([A-Za-z_][A-Za-z0-9_.-]*)\s*=\s*(['"])((?:(?!\2).)*)\2/g, sm;
            while ((sm = re.exec(lineText)) !== null){
              if (SENSITIVE_KEY.test(sm[1])){
                secrets.push({key: sm[1], line: i+1, length: sm[3].length, short: sm[3].length < 12});
              }
            }
            var re2 = /([A-Za-z_][A-Za-z0-9_-]*)\s*:\s*(['"])((?:(?!\2).)*)\2/g;
            while ((sm = re2.exec(lineText)) !== null){
              if (SENSITIVE_KEY.test(sm[1]) && !secrets.some(function(s){ return s.key === sm[1] && s.line === i+1; })){
                secrets.push({key: sm[1], line: i+1, length: sm[3].length, short: sm[3].length < 12});
              }
            }
          });
          if (secrets.length){
            secrets.forEach(function(s){
              add(s.short ? "critical" : "warning","Secrets",
                (s.short ? "Short plaintext secret" : "Plaintext secret") + " — key '" + s.key + "', line " + s.line,
                "Value length: " + s.length + " characters. The value itself is never shown in this audit. " +
                (s.short ? "Under 12 characters is brute-force territory for anything network-reachable. " : "") +
                "Move credentials out of the config file (environment, a root-only include, or the daemon's credential store) and rotate this one — it has been sitting in a file that gets copied around.");
            });
          } else if (listeners.length || modulesFound.length){
            add("pass","Secrets","No plaintext secrets found",
              "No quoted credential assignments matched the secret key patterns. (Keys built from variables or os.getenv are the right shape — they are not flagged.)");
          }

          /* ---------- Coverage: lines not parsed ---------- */
          var recognized = [
            /net\.listen/, /net\.tls/, /net\./, /modules/, /policy/, /view/, /cache/, /prefill/,
            /http/, /stats/, /env/, /user\s*\(/, /workers/, /verbose/, /log/, /hostname/,
            /trust_anchors/, /hints/, /reorder_RR/, /option\(/, /os\.getenv/, /local\s/, /function/, /return/, /if\b/, /end\b/, /for\b/
          ];
          var unparsed = [];
          lines.forEach(function(lineText, i){
            var t = lineText.trim();
            if (!t || t.indexOf("--") === 0) return;
            if (/^[}\]),;]+$/.test(t)) return;
            if (/^[A-Za-z_][\w.-]*\s*=\s*\{?$/.test(t)) return;
            var hit = recognized.some(function(r){ return r.test(t); });
            if (!hit && !SENSITIVE_KEY.test(t)) unparsed.push(i+1);
            if (!hit && SENSITIVE_KEY.test(t)) { /* secret lines are covered by the secrets check */ }
          });
          if (unparsed.length){
            add("info","Coverage","Lines not parsed: " + unparsed.join(", "),
              unparsed.length + " non-empty line(s) matched no known Knot Resolver pattern. They are listed by line number only — check them by hand; the scanner does not guess at Lua it cannot recognize.");
          } else if (listeners.length){
            add("pass","Coverage","Every non-empty line matched a known pattern",
              "Full pattern coverage for this paste. That means the scanner saw the whole file — it does not prove the Lua is valid; only kresd proves that.");
          }

          /* ---------- Verdict ---------- */
          var counts = {critical:0, warning:0, pass:0, info:0};
          findings.forEach(function(f){ counts[f.severity] = (counts[f.severity] || 0) + 1; });

          var verdict, verdictClass, verdictNote;
          if (signals < 3 || text.trim().length < 40){
            verdict = "NOT ENOUGH TO GRADE"; verdictClass = "info";
            verdictNote = "Too little recognizable Knot Resolver signal in this paste (" + signals + " signal point(s)). Paste the whole config / kres.conf — listeners, modules, policy — and audit again. A short or unrelated paste never earns a pass here.";
          } else if (counts.critical > 0){
            verdict = "DO NOT SERVE"; verdictClass = "crit";
            verdictNote = counts.critical + " critical finding(s). Fix those first — kresd would start this config, and that is exactly the problem.";
          } else if (counts.warning > 0){
            verdict = "FIX BEFORE SERVING"; verdictClass = "warn";
            verdictNote = "No critical findings, but " + counts.warning + " warning(s) stand between this config and a clean serve. Work the list, then re-audit.";
          } else {
            verdict = "SAFE TO SERVE"; verdictClass = "ok";
            verdictNote = "No critical or warning findings on the patterns this scanner grades. Still start kresd in a test window and watch its log before production — this audit is a pre-flight, not the flight.";
          }

          return {verdict:verdict, verdictClass:verdictClass, verdictNote:verdictNote,
                  findings:findings, secrets:secrets, listeners:listeners,
                  counts:counts, signals:signals, modules:modulesFound, unparsedLines:unparsed};
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-knot-resolver-server-config-safety-auditor',
  name: 'J-Dawgs Knot Resolver Server Config Safety Auditor',
  description: 'Grades a pasted Knot Resolver (kresd) config fully offline into one serve verdict — SAFE TO SERVE / SERVE WITH FIXES / DO NOT SERVE / NOT ENOUGH TO GRADE.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
