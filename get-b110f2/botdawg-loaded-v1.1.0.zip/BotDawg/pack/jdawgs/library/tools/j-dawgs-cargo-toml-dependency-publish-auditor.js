'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Cargo.toml Dependency & Publish Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var FLAWED = [
          '[package]',
          'name = "widget-forge"',
          'version = "0.3.1"',
          'description = "Worked example with publish problems — audit me."',
          'CARGO_REGISTRY_TOKEN = "FAKE-EXAMPLE-VALUE-123"',
          '',
          '[dependencies]',
          'serde = "*"',
          'http-client = { git = "https://github.com/example/http-client" }',
          'local-util = { path = "../local-util" }',
          'regex = "1"',
          '',
          '[profile.release]',
          'lto = true'
        ].join("\n");

        var CLEAN = [
          '[package]',
          'name = "widget-forge"',
          'version = "1.2.0"',
          'edition = "2021"',
          'rust-version = "1.70"',
          'description = "Clean worked example — ready to ship."',
          'license = "MIT"',
          '',
          '[dependencies]',
          'serde = { version = "=1.0.193", default-features = false, features = ["derive"] }',
          'regex = "1.10.2"',
          'itoa = "~1.0.9"',
          '',
          '[features]',
          'default = []'
        ].join("\n");

        var SHARE_TEXT = [
          'J-Dawgs Cargo.toml Dependency & Publish Auditor™ — paste a Cargo.toml, get one publish verdict.',
          '',
          'AI Tool Store: https://muse.ai/s/ai-tool-store-xng6xkxwjkxl2xab/UoF72OkKI7j33Q2ITxmrZyIr4nv40QtYfj2AgESh_k8',
          'J-Dawgs Agent Exchange: https://muse.ai/s/j-dawgs-agent-exchange-ih6xlnihzxdhxc/ZbleqxFHRE0NcswaBkyN13y9lLp5rPAgHTb6t8ii-PY',
          '',
          'Pack It, Deploy It, Teach It Stack — Cargo.toml Dependency & Publish Auditor + Wrangler Config Safety Auditor + Few-Shot Example Consistency Auditor: pack the crate, deploy the worker, teach the model — $2.50 full pass.'
        ].join("\n");

        var DEP_SECTIONS = { "dependencies": true, "dev-dependencies": true, "build-dependencies": true };
        var SECRET_RE = /(token|secret|pass(word|wd)?|api[-_]?key|access[-_]?key|private[-_]?key|credential|auth[-_]?key)/i;
        var SEMVER_RE = /^\d+\.\d+\.\d+(?:-[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$/;

        function esc(s) {
          return String(s).replace(/[&<>"']/g, function (c) {
            return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
          });
        }

        // Remove a trailing # comment that sits outside any quoted string.
        function stripComment(line) {
          var inD = false, inS = false;
          for (var i = 0; i < line.length; i++) {
            var c = line.charAt(i);
            if (inD) {
              if (c === "\\") { i++; }
              else if (c === '"') { inD = false; }
            } else if (inS) {
              if (c === "'") { inS = false; }
            } else if (c === '"') { inD = true; }
            else if (c === "'") { inS = true; }
            else if (c === "#") { return line.slice(0, i); }
          }
          return line;
        }

        // True when quotes are closed and (), {}, [] balance outside strings.
        function isBalanced(value) {
          var inD = false, inS = false, depth = 0;
          for (var i = 0; i < value.length; i++) {
            var c = value.charAt(i);
            if (inD) {
              if (c === "\\") { i++; }
              else if (c === '"') { inD = false; }
            } else if (inS) {
              if (c === "'") { inS = false; }
            } else if (c === '"') { inD = true; }
            else if (c === "'") { inS = true; }
            else if (c === "{" || c === "[" || c === "(") { depth++; }
            else if (c === "}" || c === "]" || c === ")") { depth--; if (depth < 0) { return false; } }
          }
          return !inD && !inS && depth === 0;
        }

        // Replace quoted-string contents so key scans never see values.
        function blankStrings(line) {
          return line.replace(/"(?:[^"\\]|\\.)*"/g, '""').replace(/'[^']*'/g, "''");
        }

        function unquote(v) {
          v = v.trim();
          if (v.length >= 2 && v.charAt(0) === '"' && v.charAt(v.length - 1) === '"') {
            return v.slice(1, -1).replace(/\\"/g, '"').replace(/\\\\/g, "\\");
          }
          if (v.length >= 2 && v.charAt(0) === "'" && v.charAt(v.length - 1) === "'") {
            return v.slice(1, -1);
          }
          return v;
        }

        // Split a dotted TOML path respecting quoted segments.
        function splitPath(path) {
          var segs = [], cur = "", inD = false, inS = false;
          for (var i = 0; i < path.length; i++) {
            var c = path.charAt(i);
            if (inD) { cur += c; if (c === '"') { inD = false; } }
            else if (inS) { cur += c; if (c === "'") { inS = false; } }
            else if (c === '"') { inD = true; cur += c; }
            else if (c === "'") { inS = true; cur += c; }
            else if (c === ".") { segs.push(cur.trim()); cur = ""; }
            else { cur += c; }
          }
          segs.push(cur.trim());
          return segs.map(unquote);
        }

        // Parse the inside of an inline table { ... } into key -> raw value.
        function parseInlineTable(value) {
          var inner = value.trim();
          if (inner.charAt(0) === "{") { inner = inner.slice(1); }
          if (inner.charAt(inner.length - 1) === "}") { inner = inner.slice(0, -1); }
          var out = {};
          var re = /([A-Za-z0-9_-]+)\s*=\s*("(?:[^"\\]|\\.)*"|'[^']*'|true|false|\[[^\]]*\]|[^,}]+)/g;
          var m;
          while ((m = re.exec(inner)) !== null) { out[m[1]] = m[2].trim(); }
          return out;
        }

        function classifyVersion(req, dep, findings) {
          var where = "line " + dep.line + ", [" + dep.section + "]";
          if (req === "") {
            findings.push({ sev: "BLOCKER", line: dep.line, msg: "Dependency '" + dep.name + "' (" + where + ") has an empty version requirement — nothing pins what gets published." });
            return;
          }
          if (req === "*") {
            findings.push({ sev: "BLOCKER", line: dep.line, msg: "Dependency '" + dep.name + "' (" + where + ") uses version \"*\" — completely unpinned. Any future release can be pulled in; pin an exact or bounded requirement before publishing." });
            return;
          }
          var parts = req.split(",");
          var star = false, wildcardRange = null, majorOnly = false, openGE = false, hasUpper = false, exact = false;
          for (var i = 0; i < parts.length; i++) {
            var p = parts[i].trim();
            if (!p) { continue; }
            var mm = p.match(/^(>=|<=|>|<|=|~|\^)?\s*(.+)$/);
            if (!mm) { continue; }
            var op = mm[1] || "";
            var ver = mm[2].trim();
            if (ver === "*") { star = true; continue; }
            if (ver.indexOf("*") !== -1 || /x$/i.test(ver)) { wildcardRange = ver; continue; }
            if (op === "<" || op === "<=") { hasUpper = true; }
            if (op === "=") { exact = true; }
            if (op === ">=") { openGE = true; }
            var core = ver.split(/[-+]/)[0];
            var comps = core.split(".");
            if (comps.length === 1 && /^\d+$/.test(comps[0])) { majorOnly = true; }
          }
          if (star) {
            findings.push({ sev: "BLOCKER", line: dep.line, msg: "Dependency '" + dep.name + "' (" + where + ") includes a bare \"*\" in its version requirement \"" + req + "\" — unpinned. Pin it before publishing." });
          } else if (wildcardRange) {
            findings.push({ sev: "WARNING", line: dep.line, msg: "Dependency '" + dep.name + "' (" + where + ") uses a wildcard range \"" + req + "\" — it floats across releases. A full caret or exact requirement is safer to publish." });
          } else if (majorOnly) {
            findings.push({ sev: "WARNING", line: dep.line, msg: "Dependency '" + dep.name + "' (" + where + ") names only a major version in \"" + req + "\" — a bare major-only range. Name at least major.minor so the published requirement means what you tested." });
          } else if (openGE && !hasUpper) {
            findings.push({ sev: "WARNING", line: dep.line, msg: "Dependency '" + dep.name + "' (" + where + ") uses an open-ended requirement \"" + req + "\" with no upper bound — future major releases are accepted sight unseen. Add an upper bound." });
          } else if (exact) {
            // Exact pin: the posture we want. No finding.
          }
          // Caret / tilde / bounded ranges: acceptable publish posture. No finding.
        }

        function audit(text) {
          var findings = [];
          var lines = text.split(/\r?\n/);
          var sectionSegs = [];
          var sectionName = "";
          var pkg = { found: false, name: null, nameLine: 0, version: null, versionLine: 0, edition: false, rustVersion: false, publishFalseLine: 0 };
          var deps = [];
          var hasFeatures = false;
          var hasWorkspace = false;
          var parsedAny = false;
          var currentTableDep = null;
          var inML = false;
          var secretSeen = {};

          function sectionIs() {
            if (sectionSegs.length === 1 && sectionSegs[0] === "package") { return "package"; }
            if (sectionSegs.length === 1 && sectionSegs[0] === "features") { return "features"; }
            if (sectionSegs.length === 1 && sectionSegs[0] === "workspace") { return "workspace"; }
            if (sectionSegs.length === 2 && sectionSegs[0] === "profile" && sectionSegs[1] === "release") { return "profile.release"; }
            var last = sectionSegs[sectionSegs.length - 1];
            var prev = sectionSegs[sectionSegs.length - 2];
            if (DEP_SECTIONS[last]) { return "deps"; }
            if (DEP_SECTIONS[prev] && sectionSegs.length >= 2) { return "dep-table"; }
            return "other";
          }

          function scanSecrets(lineText, lineNo) {
            var blanked = blankStrings(lineText);
            var re = /([A-Za-z0-9_][A-Za-z0-9_.-]*)\s*=/g;
            var m;
            while ((m = re.exec(blanked)) !== null) {
              var key = m[1];
              var lastSeg = key.split(".").pop();
              if (SECRET_RE.test(lastSeg)) {
                var id = lineNo + ":" + lastSeg;
                if (!secretSeen[id]) {
                  secretSeen[id] = true;
                  findings.push({ sev: "BLOCKER", line: lineNo, msg: "Secret-named key '" + lastSeg + "' on line " + lineNo + " — a key named like a credential does not belong in a file you publish. Move it to an environment variable or a local-only config. (The value is never shown in this audit.)" });
                }
              }
            }
          }

          for (var i = 0; i < lines.length; i++) {
            var lineNo = i + 1;
            var rawLine = lines[i];
            if (inML) {
              if (rawLine.indexOf('"""') !== -1 || rawLine.indexOf("'''") !== -1) { inML = false; }
              continue;
            }
            var noComment = stripComment(rawLine);
            var t = noComment.trim();
            if (!t) { continue; }
            scanSecrets(noComment, lineNo);

            if (t.indexOf('"""') !== -1 || t.indexOf("'''") !== -1) {
              var opens = (t.split('"""').length - 1) + (t.split("'''").length - 1);
              findings.push({ sev: "NOT PARSED", line: lineNo, msg: "Line " + lineNo + ": multi-line string — this heuristic audit does not follow multi-line strings, so nothing on this construct was checked." });
              if (opens % 2 === 1) { inML = true; }
              continue;
            }

            if (t.charAt(0) === "[") {
              var hdr = t.match(/^\[\[?\s*(.+?)\s*\]\]?$/);
              currentTableDep = null;
              if (!hdr) {
                findings.push({ sev: "NOT PARSED", line: lineNo, msg: "Line " + lineNo + ": section header could not be read by this heuristic audit." });
                sectionSegs = []; sectionName = "";
                continue;
              }
              sectionSegs = splitPath(hdr[1]);
              sectionName = sectionSegs.join(".");
              parsedAny = true;
              var kind0 = sectionIs();
              if (kind0 === "package") { pkg.found = true; }
              if (kind0 === "features") { hasFeatures = true; }
              if (kind0 === "workspace") { hasWorkspace = true; }
              if (kind0 === "dep-table") {
                currentTableDep = {
                  name: sectionSegs[sectionSegs.length - 1],
                  line: lineNo,
                  section: sectionSegs.slice(0, -1).join("."),
                  version: null, git: null, path: null, branch: null, rev: null, tag: null,
                  optional: false, defaultFeatures: null
                };
                deps.push(currentTableDep);
              }
              continue;
            }

            var kv = t.match(/^([A-Za-z0-9_-]+(?:\s*\.\s*[A-Za-z0-9_-]+|"[^"]+"|'[^']+')*)\s*=\s*(.*)$/);
            if (!kv) {
              findings.push({ sev: "NOT PARSED", line: lineNo, msg: "Line " + lineNo + ": not a key = value line this heuristic audit can follow — it was not checked." });
              continue;
            }
            var keyPath = kv[1].replace(/\s+/g, "");
            var key = keyPath.split(".").pop().replace(/^["']|["']$/g, "");
            var value = kv[2].trim();
            if (!isBalanced(value)) {
              findings.push({ sev: "NOT PARSED", line: lineNo, msg: "Line " + lineNo + ": value for '" + key + "' spans lines or has unbalanced quotes/brackets — not checked by this heuristic audit." });
              continue;
            }
            parsedAny = true;
            var kind = sectionIs();

            if (kind === "package") {
              if (key === "name") { pkg.name = unquote(value); pkg.nameLine = lineNo; }
              else if (key === "version") { pkg.version = unquote(value); pkg.versionLine = lineNo; }
              else if (key === "edition") { pkg.edition = true; }
              else if (key === "rust-version") { pkg.rustVersion = true; }
              else if (key === "publish" && value === "false") { pkg.publishFalseLine = lineNo; }
            } else if (kind === "deps") {
              var dep = {
                name: key, line: lineNo, section: sectionName,
                version: null, git: null, path: null, branch: null, rev: null, tag: null,
                optional: false, defaultFeatures: null
              };
              if (value.charAt(0) === '"' || value.charAt(0) === "'") {
                dep.version = unquote(value);
              } else if (value.charAt(0) === "{") {
                var tbl = parseInlineTable(value);
                if (tbl.version !== undefined) { dep.version = unquote(tbl.version); }
                if (tbl.git !== undefined) { dep.git = unquote(tbl.git); }
                if (tbl.path !== undefined) { dep.path = unquote(tbl.path); }
                if (tbl.branch !== undefined) { dep.branch = unquote(tbl.branch); }
                if (tbl.rev !== undefined) { dep.rev = unquote(tbl.rev); }
                if (tbl.tag !== undefined) { dep.tag = unquote(tbl.tag); }
                if (tbl.optional === "true") { dep.optional = true; }
                if (tbl["default-features"] === "false") { dep.defaultFeatures = false; }
                if (tbl["default-features"] === "true") { dep.defaultFeatures = true; }
              } else {
                findings.push({ sev: "NOT PARSED", line: lineNo, msg: "Line " + lineNo + ": dependency '" + key + "' is not a version string or inline table this heuristic audit can follow — not checked." });
                continue;
              }
              deps.push(dep);
            } else if (kind === "dep-table" && currentTableDep) {
              var d = currentTableDep;
              if (key === "version") { d.version = unquote(value); }
              else if (key === "git") { d.git = unquote(value); }
              else if (key === "path") { d.path = unquote(value); }
              else if (key === "branch") { d.branch = unquote(value); }
              else if (key === "rev") { d.rev = unquote(value); }
              else if (key === "tag") { d.tag = unquote(value); }
              else if (key === "optional" && value === "true") { d.optional = true; }
              else if (key === "default-features") { d.defaultFeatures = (value === "false") ? false : (value === "true" ? true : null); }
            } else if (kind === "profile.release") {
              if (key === "panic" && unquote(value) === "abort") {
                findings.push({ sev: "INFO", line: lineNo, msg: "[profile.release] sets panic = \"abort\" (line " + lineNo + ") — publish-relevant posture: consumers building with unwind-based error handling should know. Not an error." });
              } else if (key === "lto") {
                findings.push({ sev: "INFO", line: lineNo, msg: "[profile.release] sets lto = " + value + " (line " + lineNo + ") — link-time optimization posture noted; it shapes build time and binary size for anyone building this crate from source. Not an error." });
              } else if (key === "codegen-units") {
                findings.push({ sev: "INFO", line: lineNo, msg: "[profile.release] sets codegen-units = " + value + " (line " + lineNo + ") — codegen posture noted for source builds. Not an error." });
              }
            }
          }

          // ---- [package] verdicts ----
          if (!pkg.found) {
            findings.push({ sev: "BLOCKER", line: 0, msg: "No [package] section found — without one there is no crate to publish." + (hasWorkspace ? " This file does have a [workspace] section, so it may be a virtual workspace manifest; audit the member crate's own Cargo.toml instead." : "") });
          } else {
            if (!pkg.name) {
              findings.push({ sev: "BLOCKER", line: 0, msg: "[package] has no name — cargo publish cannot proceed without one." });
            }
            if (!pkg.version) {
              findings.push({ sev: "BLOCKER", line: 0, msg: "[package] has no version — cargo publish requires a version." });
            } else if (!SEMVER_RE.test(pkg.version)) {
              findings.push({ sev: "BLOCKER", line: pkg.versionLine, msg: "[package] version \"" + pkg.version + "\" (line " + pkg.versionLine + ") is not valid semver (expected major.minor.patch, e.g. 1.2.0) — crates.io will reject it." });
            }
            if (!pkg.edition) {
              findings.push({ sev: "WARNING", line: 0, msg: "[package] sets no edition — cargo silently defaults to the 2015 edition, so the crate compiles under 2015 rules even if you wrote it for newer ones. Set edition explicitly (2018, 2021, or 2024)." });
            }
            if (!pkg.rustVersion) {
              findings.push({ sev: "INFO", line: 0, msg: "[package] sets no rust-version — consumers get no declared minimum Rust version, so an older toolchain can fail on them without warning." });
            }
            if (pkg.publishFalseLine) {
              findings.push({ sev: "WARNING", line: pkg.publishFalseLine, msg: "publish disabled in the file itself: publish = false (line " + pkg.publishFalseLine + ") — cargo publish will refuse this package until that line is removed or set to true." });
            }
          }

          // ---- dependency verdicts ----
          var optionalCount = 0;
          for (var j = 0; j < deps.length; j++) {
            var dep = deps[j];
            var where = "line " + dep.line + ", [" + dep.section + "]";
            if (dep.optional) { optionalCount++; }
            if (dep.defaultFeatures === false) {
              findings.push({ sev: "INFO", line: dep.line, msg: "Dependency '" + dep.name + "' (" + where + ") sets default-features = false — lean default-feature posture, noted." });
            } else if (dep.defaultFeatures === true) {
              findings.push({ sev: "INFO", line: dep.line, msg: "Dependency '" + dep.name + "' (" + where + ") explicitly sets default-features = true — default features are on, noted." });
            }
            if (dep.git) {
              var pinNote;
              if (dep.rev) { pinNote = "It names a rev, which pins one commit — the strongest git pin, but the source is still outside the registry's review and checksum flow."; }
              else if (dep.tag) { pinNote = "It names a tag, which pins a label — tags can be moved by the repository owner, so it is a soft pin."; }
              else if (dep.branch) { pinNote = "It tracks branch '" + dep.branch + "', which moves — that is not a pin at all."; }
              else { pinNote = "No rev, branch, or tag is named, so it floats to whatever the default branch holds on the day someone builds."; }
              findings.push({ sev: "BLOCKER", line: dep.line, msg: "BLOCKER — review this git dependency: '" + dep.name + "' (" + where + ") comes from a git repository, not the registry. Git dependencies are unpinned by default and a supply-chain risk, and cargo publish will reject a crate whose dependencies are git-only. " + pinNote });
            } else if (dep.path) {
              if (dep.version != null) {
                findings.push({ sev: "INFO", line: dep.line, msg: "Dependency '" + dep.name + "' (" + where + ") is a path dependency that also declares version \"" + dep.version + "\" — cargo publish uses the version and ignores the path, so this one can publish." });
              } else {
                findings.push({ sev: "WARNING", line: dep.line, msg: "Dependency '" + dep.name + "' (" + where + ") is a path dependency with no version — path dependencies break when published, because the path does not exist on anyone else's machine. Add the version it should publish as." });
              }
            } else if (dep.version != null) {
              classifyVersion(dep.version, dep, findings);
            } else {
              findings.push({ sev: "BLOCKER", line: dep.line, msg: "Dependency '" + dep.name + "' (" + where + ") declares no version, no git source, and no path — a registry dependency with no version requirement cannot be published." });
            }
          }

          // ---- duplicates ----
          var byName = {};
          for (var k = 0; k < deps.length; k++) {
            var nm = deps[k].name;
            if (!byName[nm]) { byName[nm] = []; }
            byName[nm].push(deps[k]);
          }
          for (var name in byName) {
            if (Object.prototype.hasOwnProperty.call(byName, name) && byName[name].length > 1) {
              var list = byName[name];
              var spots = list.map(function (x) { return "line " + x.line + " ([" + x.section + "])"; }).join(" and ");
              findings.push({ sev: "WARNING", line: list[1].line, msg: "Duplicate dependency '" + name + "' declared at " + spots + " — the same crate in more than one section can resolve to conflicting requirements; keep one declaration per target and section you actually need." });
            }
          }

          if (optionalCount > 0 && !hasFeatures) {
            findings.push({ sev: "INFO", line: 0, msg: optionalCount + " optional " + (optionalCount === 1 ? "dependency exists" : "dependencies exist") + " but there is no [features] section — optional dependencies create implicit features, but an explicit [features] table documents what each feature turns on." });
          }

          findings.sort(function (a, b) {
            var sevRank = { "BLOCKER": 0, "WARNING": 1, "NOT PARSED": 2, "INFO": 3 };
            var la = a.line === 0 ? 9999 : a.line;
            var lb = b.line === 0 ? 9999 : b.line;
            if (la !== lb) { return la - lb; }
            return sevRank[a.sev] - sevRank[b.sev];
          });

          var counts = { BLOCKER: 0, WARNING: 0, INFO: 0, "NOT PARSED": 0 };
          findings.forEach(function (f) { counts[f.sev]++; });

          var verdict;
          if (!pkg.found || !parsedAny) { verdict = "COULD NOT AUDIT"; }
          else if (counts.BLOCKER > 0) { verdict = "DO NOT PUBLISH YET"; }
          else if (counts.WARNING > 0) { verdict = "PUBLISH WITH FIXES"; }
          else { verdict = "READY TO PUBLISH"; }

          return { verdict: verdict, findings: findings, counts: counts, pkg: pkg, depCount: deps.length };
        }

        function verdictClass(v) {
          if (v === "READY TO PUBLISH") { return "ready"; }
          if (v === "PUBLISH WITH FIXES") { return "fixes"; }
          if (v === "DO NOT PUBLISH YET") { return "donot"; }
          return "couldnot";
        }
        function verdictSub(v) {
          if (v === "READY TO PUBLISH") { return "No blockers and no warnings. Info notes only — this file's publish posture is clean as far as a text audit can tell. The crate name's availability on crates.io is not checked here."; }
          if (v === "PUBLISH WITH FIXES") { return "Nothing here stops a publish outright, but the warnings below are worth fixing first — several become hard errors or silent surprises later."; }
          if (v === "DO NOT PUBLISH YET") { return "At least one blocker below would stop cargo publish or put something risky into the registry. Fix the blockers, then re-audit."; }
          return "This does not look like an auditable crate manifest — see the findings for what was missing. If this is a workspace root, audit a member crate's Cargo.toml instead."; }
        function sevClass(s) {
          if (s === "BLOCKER") { return "blocker"; }
          if (s === "WARNING") { return "warning"; }
          if (s === "INFO") { return "info"; }
          return "notparsed";
        }

        function buildReport(r) {
          var out = [];
          out.push("J-Dawgs Cargo.toml Dependency & Publish Auditor — Audit Report");
          out.push("Verdict: " + r.verdict);
          if (r.pkg && r.pkg.name) { out.push("Package: " + r.pkg.name + (r.pkg.version ? " " + r.pkg.version : "")); }
          out.push("Counts: " + r.counts.BLOCKER + " blocker(s), " + r.counts.WARNING + " warning(s), " + r.counts.INFO + " info, " + r.counts["NOT PARSED"] + " not parsed; " + r.depCount + " dependencies audited.");
          out.push("");
          out.push("Findings:");
          if (r.findings.length === 0) { out.push("(none)"); }
          r.findings.forEach(function (f) {
            out.push("[" + f.sev + "] " + (f.line ? "Line " + f.line + " — " : "") + f.msg);
          });
          out.push("");
          out.push("Limits: heuristic text audit, not a full TOML parser. This tool does not run cargo, does not contact crates.io, and cannot confirm the crate name is available. Secret-named keys are reported by key name and line only; values are never included.");
          return out.join("\n");
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-cargo-toml-dependency-publish-auditor',
  name: 'J-Dawgs Cargo.toml Dependency & Publish Auditor',
  description: 'Cargo\'s own checks need Rust installed and stop at validity; this audits a pasted Cargo.toml anywhere — dependency pinning, git/path risks, publish posture — into one publish verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
