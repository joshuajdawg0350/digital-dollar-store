'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Tool Output Sanity Checker".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the analyze function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

  "use strict";

  /* ---------- Samples ---------- */
  var PROBLEM = [
    { tool:"web_search", status:"ok",
      output:'{\n  "query": "acme corp Q3 revenue",\n  "count": 3,\n  "results": [\n    {"title": "Acme Corp Q3 earnings release", "source": "acme.example"},\n    {"title": "Acme Corp investor relations", "source": "acme.example"},\n    {"title": "Analyst note: Acme Q3 preview", "source": "research.example"}\n  ]\n}' },
    { tool:"database_lookup", status:"error", output:"" },
    { tool:"summarize_results", status:"ok",
      output:"Summary: The web search returned 3 sources on Acme Corp Q3. Per the database lookup, customer account #4471 is in good standing with a current balance, so the account details from the lookup have been folded into this summary alongside the search findings." },
    { tool:"report_writer", status:"ok",
      output:"FINAL REPORT — Acme Corp Q3\nRevenue grew across all three segments. The strongest growth came from the services division, which expanded its recurring contract base to $1,248,9... [truncated]" }
  ];

  var CLEAN = [
    { tool:"web_search", status:"ok",
      output:'{\n  "query": "springfield mo weather november",\n  "count": 2,\n  "results": [\n    {"title": "Springfield forecast", "source": "weather.example"},\n    {"title": "November climate normals", "source": "weather.example"}\n  ]\n}' },
    { tool:"database_lookup", status:"ok",
      output:'{\n  "account": 4471,\n  "standing": "good",\n  "balance": 182.40,\n  "currency": "USD"\n}' },
    { tool:"web_search", status:"ok",
      output:'{\n  "query": "springfield mo events november",\n  "count": 1,\n  "results": [\n    {"title": "Downtown market days", "source": "events.example"}\n  ]\n}' },
    { tool:"summarize_results", status:"ok",
      output:"Summary: The search returned a Springfield forecast and November climate normals. The database lookup confirms account #4471 is in good standing with a balance of $182.40 USD. One local event listing was found for November." }
  ];

  /* ---------- Step editor ---------- */
  var stepsEl = document.getElementById("steps");
  var stepCount = 0;

  function addStep(data){
    stepCount++;
    var div = document.createElement("div");
    div.className = "step";
    var n = stepCount;
    div.innerHTML =
      '<div class="step-head">' +
        '<span class="step-num">STEP ' + n + '</span>' +
        '<input type="text" class="f-tool" aria-label="Tool name for step ' + n + '" placeholder="Tool name — e.g. web_search" />' +
        '<select class="f-status" aria-label="Status for step ' + n + '">' +
          '<option value="ok">status: ok</option>' +
          '<option value="error">status: error</option>' +
          '<option value="timeout">status: timeout</option>' +
        '</select>' +
        '<button type="button" class="small rm">Remove</button>' +
      '</div>' +
      '<label class="flabel" for="out-' + n + '">Raw output — paste exactly as returned</label>' +
      '<textarea id="out-' + n + '" class="f-output" spellcheck="false" placeholder="Paste the raw tool output here. Leave it empty if the tool returned nothing — that is exactly what this checker needs to see."></textarea>';
    div.querySelector(".rm").addEventListener("click", function(){
      div.remove(); renumber();
    });
    if (data){
      div.querySelector(".f-tool").value = data.tool || "";
      div.querySelector(".f-status").value = data.status || "ok";
      div.querySelector(".f-output").value = data.output || "";
    }
    stepsEl.appendChild(div);
    renumber();
    return div;
  }
  function renumber(){
    var cards = stepsEl.querySelectorAll(".step");
    for (var i=0;i<cards.length;i++){
      cards[i].querySelector(".step-num").textContent = "STEP " + (i+1);
    }
    refreshBaselineOptions();
  }
  function refreshBaselineOptions(){
    var sel = document.getElementById("baselineStep");
    if (!sel) return;
    var prev = sel.value;
    var cards = stepsEl.querySelectorAll(".step");
    sel.innerHTML = "";
    for (var i=0;i<cards.length;i++){
      var opt = document.createElement("option");
      opt.value = i;
      var t = cards[i].querySelector(".f-tool").value.trim();
      opt.textContent = "Step " + (i+1) + (t ? " — " + t : "");
      sel.appendChild(opt);
    }
    if (prev !== "" && parseInt(prev, 10) < cards.length) sel.value = prev;
  }
  function readSteps(){
    var out = [];
    var cards = stepsEl.querySelectorAll(".step");
    for (var i=0;i<cards.length;i++){
      out.push({
        tool: cards[i].querySelector(".f-tool").value.trim(),
        status: cards[i].querySelector(".f-status").value,
        output: cards[i].querySelector(".f-output").value
      });
    }
    return out;
  }
  function loadChain(chain){
    stepsEl.innerHTML = ""; stepCount = 0;
    for (var i=0;i<chain.length;i++) addStep(chain[i]);
    runCheck();
    document.getElementById("results").scrollIntoView({behavior:"smooth", block:"start"});
  }

  /* ---------- Analysis ---------- */
  function typeOf(v){
    if (v === null) return "null";
    if (Array.isArray(v)) return "array";
    return typeof v;
  }
  function esc(s){
    return String(s).replace(/[&<>"']/g, function(c){
      return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c];
    });
  }

  /* ---------- Baseline shape diff ----------
     Compares SHAPE only, never values: a string's "format class" (UUID,
     digits-only, a letter/digit skeleton like "A_#") stands in for the value
     itself, so no raw pasted value is ever echoed into a diff report. */
  function classifyString(s){
    if (s === "") return "empty string";
    if (/^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/.test(s)) return "UUID";
    if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s)) return "email address";
    if (/^https?:\/\//i.test(s)) return "URL";
    if (/^\d{4}-\d{2}-\d{2}([T ]\d{2}:\d{2}(:\d{2})?)?/.test(s)) return "ISO date/timestamp";
    if (/^-?\d+$/.test(s)) return "digits only";
    if (/^-?\d+\.\d+$/.test(s)) return "decimal number as text";
    if (/^[0-9a-fA-F]{6,}$/.test(s) && /[a-fA-F]/.test(s) && /\d/.test(s)) return "hex string";
    return '"' + s.replace(/[A-Za-z]+/g, "A").replace(/\d+/g, "#") + '" pattern';
  }
  function pathJoin(path, key){
    if (/^[A-Za-z_$][A-Za-z0-9_$]*$/.test(key)) return path + "." + key;
    return path + '["' + key.replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '"]';
  }
  function diffShapes(b, c, path, diffs){
    if (diffs.length >= 60) return;
    var tb = typeOf(b), tc = typeOf(c);
    if (tb !== tc){
      diffs.push({ path:path, detail:"type changed: " + tb + " → " + tc });
      return;
    }
    var k, i;
    if (tb === "object"){
      for (k in b){ if (Object.prototype.hasOwnProperty.call(b, k) && !Object.prototype.hasOwnProperty.call(c, k))
        diffs.push({ path:pathJoin(path, k), detail:"key removed (present in the baseline, gone now)" }); }
      for (k in c){ if (Object.prototype.hasOwnProperty.call(c, k) && !Object.prototype.hasOwnProperty.call(b, k))
        diffs.push({ path:pathJoin(path, k), detail:"key added (not in the baseline)" }); }
      for (k in b){ if (Object.prototype.hasOwnProperty.call(b, k) && Object.prototype.hasOwnProperty.call(c, k))
        diffShapes(b[k], c[k], pathJoin(path, k), diffs); }
    } else if (tb === "array"){
      if (b.length !== c.length)
        diffs.push({ path:path, detail:"array length changed: " + b.length + " → " + c.length });
      var n = Math.min(b.length, c.length);
      for (i = 0; i < n; i++) diffShapes(b[i], c[i], path + "[" + i + "]", diffs);
    } else if (tb === "string"){
      var fb = classifyString(b), fc = classifyString(c);
      if (fb !== fc) diffs.push({ path:path, detail:"value format changed: " + fb + " → " + fc });
    } else if (tb === "number"){
      if (Number.isInteger(b) !== Number.isInteger(c))
        diffs.push({ path:path, detail:"value format changed: " + (Number.isInteger(b) ? "integer" : "decimal") + " → " + (Number.isInteger(c) ? "integer" : "decimal") });
    }
  }

  function analyze(steps, baseline){
    var results = [];
    var prevByTool = {}; // tool lowercase -> {index, keys:{k:type}, parsed}
    var seenTools = {};  // tool lowercase -> true once any earlier step used it
    var baselineParsed = null, baselineParseError = null;
    if (baseline){
      try { baselineParsed = JSON.parse(String(baseline.text).trim()); }
      catch(e){ baselineParseError = e && e.message ? e.message : String(e); }
    }

    for (var i=0;i<steps.length;i++){
      var s = steps[i];
      var raw = s.output == null ? "" : String(s.output);
      var trimmed = raw.trim();
      var flags = [];      // {code, severity: crit|warn, detail}
      var notes = [];
      var parseError = null;
      var parsed = null, isJson = false, looksJson = false;

      looksJson = trimmed.charAt(0) === "{" || trimmed.charAt(0) === "[";
      if (looksJson && trimmed.length){
        try { parsed = JSON.parse(trimmed); isJson = true; }
        catch(e){ parseError = e && e.message ? e.message : String(e); }
      } else if (trimmed.length){
        try { var p = JSON.parse(trimmed); if (p && typeof p === "object"){ parsed = p; isJson = true; } } catch(e){}
      }

      var isEmpty = trimmed.length === 0;
      var hasLater = i < steps.length - 1;
      var failed = (s.status === "error" || s.status === "timeout");

      /* ERROR-IGNORED */
      if (failed && hasLater){
        var laterMentions = false;
        if (s.tool){
          var variants = [s.tool.toLowerCase(), s.tool.toLowerCase().replace(/_/g, " "), s.tool.toLowerCase().replace(/-/g, " ")];
          for (var j=i+1;j<steps.length;j++){
            if (!steps[j].output) continue;
            var lo = steps[j].output.toLowerCase();
            for (var v=0;v<variants.length;v++){ if (lo.indexOf(variants[v]) !== -1) laterMentions = true; }
          }
        }
        flags.push({ code:"ERROR-IGNORED", severity:"crit",
          detail:"Status was \"" + s.status + "\" but the chain kept going — " + (steps.length-1-i) + " later step(s) follow it" +
                 (laterMentions ? ", and a later step refers to \"" + s.tool + "\" as though it produced results" : "") +
                 ". Anything after this step that rests on its output is resting on a failure." });
      } else if (failed && !hasLater){
        flags.push({ code:"ERROR", severity:"warn",
          detail:"Status was \"" + s.status + "\". It is the last step, so nothing has depended on it yet — but the chain cannot proceed from here until it succeeds." });
      }

      /* EMPTY */
      if (isEmpty && !failed){
        flags.push({ code:"EMPTY", severity:"warn",
          detail:"Status was \"ok\" but the output is " + (raw.length ? "whitespace only" : "completely empty") + ". An ok with no output is not a result." });
      }
      if (isEmpty && failed){
        notes.push("The failed step also returned no output at all — there is nothing to salvage from it.");
      }

      /* MALFORMED */
      if (looksJson && parseError){
        flags.push({ code:"MALFORMED", severity:"crit",
          detail:"The output opens like JSON but does not parse. Do not hand-repair it and continue — the break point can hide missing or shifted values." });
      }

      /* PARTIAL */
      var partialReasons = [];
      var low = trimmed.toLowerCase();
      if (low.indexOf("[truncated]") !== -1 || low.indexOf("[truncated") !== -1) partialReasons.push("it contains a [truncated] marker");
      if (trimmed.indexOf("...") !== -1 || trimmed.indexOf("…") !== -1) partialReasons.push("it contains a \"...\" cut-off marker");
      if (looksJson){
        var open = 0, close = 0, inStr = false, escp = false;
        for (var k=0;k<trimmed.length;k++){
          var ch = trimmed.charAt(k);
          if (escp){ escp = false; continue; }
          if (ch === "\\"){ escp = true; continue; }
          if (ch === '"'){ inStr = !inStr; continue; }
          if (inStr) continue;
          if (ch === "{" || ch === "[") open++;
          if (ch === "}" || ch === "]") close++;
        }
        if (open > close) partialReasons.push("its JSON brackets never close (" + open + " opening vs " + close + " closing) — the output stops mid-structure");
      }
      if (!isEmpty && !looksJson && /,|\$$/.test(trimmed) === false && /,$/.test(trimmed)) partialReasons.push("it ends on a comma, mid-list");
      if (!isEmpty && !looksJson && /\d$/.test(trimmed) && trimmed.length > 60 && low.indexOf("truncated") !== -1) partialReasons.push("it stops mid-value");
      if (partialReasons.length){
        // avoid double-counting pure malformed-unbalanced as the only signal being redundant — still worth flagging per spec
        flags.push({ code:"PARTIAL", severity:"warn",
          detail:"The output looks cut off: " + partialReasons.join("; ") + ". The missing tail is unknown." });
      } else if (low.indexOf("truncated") !== -1){
        flags.push({ code:"PARTIAL", severity:"warn", detail:"The output mentions truncation. Treat its tail as missing." });
      }

      /* TRUNCATION SUSPECT — kept separate from `flags` on purpose: it is a
         suspicion with a stated reason, and it must never change a step's
         classification, the first-bad-step, or the chain verdict. */
      var trunc = null;
      if (!isEmpty){
        if (looksJson){
          var o2 = 0, c2 = 0, inS = false, es2 = false;
          for (var t=0;t<trimmed.length;t++){
            var ch2 = trimmed.charAt(t);
            if (es2){ es2 = false; continue; }
            if (ch2 === "\\"){ es2 = true; continue; }
            if (ch2 === '"'){ inS = !inS; continue; }
            if (inS) continue;
            if (ch2 === "{" || ch2 === "[") o2++;
            if (ch2 === "}" || ch2 === "]") c2++;
          }
          if (inS) trunc = { reason:"the JSON-looking output ends inside an unclosed string — a quote opens and never closes" };
          else if (o2 > c2) trunc = { reason:"the JSON-looking output ends with " + (o2 - c2) + " bracket(s) opened and never closed" };
        }
        if (!trunc && raw.length >= 1000 && raw.length % 1000 === 0){
          trunc = { reason:"the output is exactly " + raw.length + " characters — a round number consistent with a hard size cut" };
        }
      }

      /* SHAPE-DRIFT */
      var drift = null;
      var comparedShape = false;
      var key = (s.tool || "").toLowerCase();
      var firstCallToTool = !(key && seenTools[key]);
      if (key) seenTools[key] = true;
      if (key && isJson && parsed && !Array.isArray(parsed) && typeof parsed === "object"){
        var keys = {};
        for (var kk in parsed){ if (Object.prototype.hasOwnProperty.call(parsed, kk)) keys[kk] = typeOf(parsed[kk]); }
        if (prevByTool[key]){
          comparedShape = true;
          var prev = prevByTool[key];
          var added = [], removed = [], changed = [];
          for (var a in keys){ if (!(a in prev.keys)) added.push(a); }
          for (var r in prev.keys){ if (!(r in keys)) removed.push(r); }
          for (var c in keys){ if (c in prev.keys && prev.keys[c] !== keys[c]) changed.push(c + " (" + prev.keys[c] + " → " + keys[c] + ")"); }
          if (added.length || removed.length || changed.length){
            drift = { fromStep: prev.index + 1, added: added, removed: removed, changed: changed };
            var parts = [];
            if (added.length) parts.push("added: " + added.join(", "));
            if (removed.length) parts.push("removed: " + removed.join(", "));
            if (changed.length) parts.push("type-changed: " + changed.join(", "));
            flags.push({ code:"SHAPE-DRIFT", severity:"warn",
              detail:"Compared with step " + (prev.index+1) + " (the previous \"" + s.tool + "\" call), the top-level keys changed — " + parts.join(" · ") + "." });
          }
        }
        prevByTool[key] = { index:i, keys:keys };
      } else if (key && isJson && Array.isArray(parsed)){
        notes.push("Output is a JSON array; shape-drift compares top-level object keys, so arrays are checked for validity only.");
      }

      /* BASELINE SHAPE DIFF — only when a baseline was pasted for this step.
         Drift is a warning flag; whether it can drive the verdict is decided
         in the verdict section (drift + later steps = the agent relied on it). */
      var baselineInfo = null;
      if (baseline && baseline.index === i){
        if (baselineParseError){
          baselineInfo = { state:"unusable", reason:"The pasted baseline is not valid JSON (" + baselineParseError + "), so no shape comparison was possible. Paste a known-good output that parses as JSON." };
        } else if (!isJson){
          baselineInfo = { state:"unusable", reason:"This step's current output is not parseable JSON, so it has no shape to compare against the baseline." };
        } else {
          var diffs = [];
          diffShapes(baselineParsed, parsed, "$", diffs);
          if (diffs.length){
            baselineInfo = { state:"drifted", diffs:diffs, reliedOn:hasLater };
            var shownPaths = [];
            for (var dp=0; dp<diffs.length && dp<4; dp++) shownPaths.push(diffs[dp].path);
            flags.push({ code:"BASELINE-DRIFT", severity:"warn",
              detail:"SHAPE DRIFTED vs the known-good baseline — " + diffs.length + " difference(s) at: " + shownPaths.join(", ") + (diffs.length > 4 ? ", …" : "") + ". " +
                (hasLater
                  ? "Later steps follow this step, so the chain carried on using the drifted shape."
                  : "No later step follows it, so nothing in this chain used the drifted shape — this is a warning, not a failure.") });
          } else {
            baselineInfo = { state:"same", diffs:[] };
          }
        }
      }

      /* primary classification + action */
      var primary = "HEALTHY", sev = "ok", action = null;
      var order = ["ERROR-IGNORED","MALFORMED","EMPTY","PARTIAL","SHAPE-DRIFT","ERROR","BASELINE-DRIFT"];
      for (var o=0;o<order.length;o++){
        var found = null;
        for (var f=0;f<flags.length;f++) if (flags[f].code === order[o]) found = flags[f];
        if (found){ primary = found.code; sev = found.severity; break; }
      }
      if (primary === "ERROR-IGNORED") action = { verb:"Abort", text:"Stop the chain here. Do not act on any later step that used this output. Re-run the failed tool, then rebuild every step after it from the real result." };
      else if (primary === "MALFORMED") action = { verb:"Re-fetch", text:"Request this output again and require it to parse as valid JSON before anything downstream touches it. Never hand-fix the JSON and carry on." };
      else if (primary === "EMPTY") action = { verb:"Re-fetch", text:"Run the tool again. If it legitimately returns nothing, record \"no results\" explicitly — do not let the next step treat silence as a finding." };
      else if (primary === "PARTIAL") action = { verb:"Re-fetch", text:"Get the complete output (raise the size limit or page through it). Do not fill in, estimate, or summarize the missing tail." };
      else if (primary === "SHAPE-DRIFT") action = { verb:"Verify manually", text:"Confirm the new shape is an expected change (a version bump, a different query type) before using the changed fields. If it is not expected, treat the later call as suspect." };
      else if (primary === "BASELINE-DRIFT") action = { verb:"Verify manually", text:"Walk the drifted paths listed below against the baseline. If the change is expected (a tool update, a new API version), refresh the baseline and re-run. If it is not expected, re-run the tool and do not use the drifted fields until the shape matches again." };
      else if (primary === "ERROR") action = { verb:"Retry", text:"Re-run this tool before adding any step that depends on it. If it keeps failing, stop and report the failure instead of routing around it." };

      results.push({
        index:i, tool:s.tool || "(unnamed tool)", status:s.status, rawLen: raw.length,
        flags:flags, notes:notes, parseError:parseError, primary:primary, severity:sev, action:action, drift:drift,
        comparedShape:comparedShape, firstCallToTool:firstCallToTool, trunc:trunc, baseline:baselineInfo
      });
    }

    /* ---------- Verdict ---------- */
    var firstBad = -1;
    for (var q=0;q<results.length;q++){ if (results[q].flags.length){ firstBad = q; break; } }

    var doNotProceed = false, dnpWhy = "";
    for (var d=0;d<results.length;d++){
      var r = results[d];
      var hasLaterDep = d < results.length - 1;
      for (var g=0;g<r.flags.length;g++){
        if (r.flags[g].code === "ERROR-IGNORED"){
          doNotProceed = true;
          dnpWhy = "Step " + (d+1) + " (" + r.tool + ") failed with status \"" + r.status + "\" and the chain proceeded anyway. Later steps were built on a result that never arrived.";
        }
        if (r.flags[g].code === "MALFORMED" && hasLaterDep && !doNotProceed){
          doNotProceed = true;
          dnpWhy = "Step " + (d+1) + " (" + r.tool + ") produced unparseable JSON and later steps continued past it, so downstream work rests on data nobody actually read.";
        }
      }
      if (doNotProceed) break;
    }

    /* Baseline drift the agent relied on: the step has later steps after it,
       so the chain carried on using a shape that no longer matches the
       known-good baseline. Drift on a final, unused step never reaches here —
       it stays a warning flag on that step only. */
    if (!doNotProceed){
      for (var bd=0; bd<results.length; bd++){
        var br = results[bd];
        if (br.baseline && br.baseline.state === "drifted" && bd < results.length - 1){
          doNotProceed = true;
          dnpWhy = "Step " + (bd+1) + " (" + br.tool + ") no longer matches its known-good baseline shape — " + br.baseline.diffs.length + " difference(s), starting at " + br.baseline.diffs[0].path + " — and the chain carried on past it, so later steps were written against a shape that had already changed underneath them.";
          break;
        }
      }
    }

    var verdict, why;
    if (!results.length){
      verdict = "SUSPECT"; why = "No steps were provided, so there is nothing to trust. Add at least one step and run the check again.";
    } else if (doNotProceed){
      verdict = "DO NOT PROCEED";
      why = dnpWhy + " Halt at the first bad step, fix that call, and re-run everything after it.";
    } else if (firstBad !== -1){
      verdict = "SUSPECT";
      why = "No step was silently built on a failure, but " + results.filter(function(x){return x.flags.length;}).length + " step(s) carry warnings. Resolve them — or consciously accept them — before acting on this chain.";
    } else {
      verdict = "TRUSTWORTHY";
      why = "Every step returned a present, complete-looking output, JSON parsed where JSON was claimed, repeated tools kept the same shape, and no failed step was carried past. (This speaks to the chain's form only — see \"What this does NOT do\" below.)";
    }
    return { results:results, firstBad:firstBad, verdict:verdict, why:why };
  }

  /* ---------- Rendering ---------- */
  var lastReport = null;

  function chipClass(sev){ return sev === "crit" ? "crit" : (sev === "warn" ? "warn" : "healthy"); }
  return { "analyze": (typeof analyze !== 'undefined' ? analyze : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["analyze"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-tool-output-sanity-checker',
  name: 'J-Dawgs Tool Output Sanity Checker',
  description: 'Inspect a chain of tool outputs for silent failures before trusting them. Now exports a copyable first-bad-step incident snippet (secrets masked) and flags per-step output size and truncation suspects — suspicion labelled, never proof. Now also with a Baseline Shape Diff mode',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["analyze"]) return { ok: false, output: null, summary: 'Extracted core has no analyze function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
