'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Joomla Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var KNOWN = {};
      ("offline offline_message display_offline_message offline_image sitename editor captcha list_limit access " +
       "debug debug_lang debug_lang_const dbtype host user password db dbprefix dbencryption dbsslverifyservercert " +
       "dbsslkey dbsslcert dbsslca dbsslcipher secret gzip error_reporting helpurl ftp_host ftp_port ftp_user ftp_pass " +
       "ftp_root ftp_enable offset mailonline mailer mailfrom fromname sendmail smtpauth smtpuser smtppass smtphost " +
       "smtpsecure smtpport caching cache_handler cachetime cache_platformprefix MetaDesc MetaKeys MetaTitle MetaAuthor " +
       "MetaVersion robots feed_limit feed_email log_path tmp_path lifetime session_handler shared_session session_metadata " +
       "cookie_domain cookie_path force_ssl sef sef_rewrite sef_suffix unicodeslugs asset_id behind_loadbalancer " +
       "proxy_enable proxy_host proxy_port proxy_user proxy_pass mailqueue massmailoff memcache_persist memcache_compress " +
       "memcache_server_host memcache_server_port memcached_persist memcached_compress memcached_server_host memcached_server_port " +
       "redis_persist redis_server_host redis_server_port redis_server_db redis_server_auth " +
       "session_memcache_server_host session_memcache_server_port session_memcached_server_host session_memcached_server_port " +
       "session_redis_persist session_redis_server_host session_redis_server_port session_redis_server_db session_redis_server_auth " +
       "cors cors_allow_origin cors_allow_headers cors_allow_methods cors_allow_credentials frontediting debug_lang_const " +
       "session_cookie_lifetime shared_sessions").split(" ").forEach(function(k){ KNOWN[k]=true; });

      var PLACEHOLDERS = ["changeme","change-me","change_me","your-secret","your_secret","yoursecret","secret","password","placeholder","xxxx","todo"];

      var RISKY = [
        "<?php",
        "class JConfig {",
        "\tpublic $offline = '0';",
        "\tpublic $sitename = 'Corner Store';",
        "\tpublic $editor = 'tinymce';",
        "\tpublic $debug = true;",
        "\tpublic $debug_lang = '0';",
        "\tpublic $dbtype = 'mysqli';",
        "\tpublic $host = 'localhost';",
        "\tpublic $user = 'root';",
        "\tpublic $password = 'dbpass12345';",
        "\tpublic $db = 'cornerstore';",
        "\tpublic $dbprefix = 'jos_';",
        "\tpublic $secret = 'changeme';",
        "\tpublic $error_reporting = 'maximum';",
        "\tpublic $log_path = '/var/www/html/logs';",
        "\tpublic $tmp_path = '/var/www/html/tmp';",
        "\tpublic $lifetime = '15';",
        "\tpublic $session_handler = 'database';",
        "\tpublic $mailer = 'smtp';",
        "\tpublic $mailfrom = 'shop@example.com';",
        "\tpublic $smtpauth = '1';",
        "\tpublic $smtpsecure = 'none';",
        "\tpublic $smtphost = 'smtp.example.com';",
        "\tpublic $force_ssl = '0';",
        "\tpublic $sef = '1';",
        "\tpublic $sef_rewrite = '0';",
        "\tpublic $sef_suffix = '1';",
        "\tpublic $caching = '0';",
        "\tpublic $cache_handler = 'file';",
        "}"
      ].join("\n");

      var HARDENED = [
        "<?php",
        "class JConfig {",
        "\tpublic $offline = '0';",
        "\tpublic $sitename = 'Corner Store';",
        "\tpublic $editor = 'tinymce';",
        "\tpublic $debug = '0';",
        "\tpublic $debug_lang = '0';",
        "\tpublic $dbtype = 'mysqli';",
        "\tpublic $host = 'localhost';",
        "\tpublic $user = 'corner_db';",
        "\tpublic $password = 'X9!vault-grade-passphrase-42';",
        "\tpublic $db = 'cornerstore';",
        "\tpublic $dbprefix = 'xk9_';",
        "\tpublic $secret = 'kF83jd92mzQp47xLwR61vNsT05bHyAeC';",
        "\tpublic $error_reporting = 'none';",
        "\tpublic $log_path = '/home/corner/logs';",
        "\tpublic $tmp_path = '/home/corner/tmp';",
        "\tpublic $lifetime = '15';",
        "\tpublic $session_handler = 'database';",
        "\tpublic $mailer = 'smtp';",
        "\tpublic $mailfrom = 'shop@example.com';",
        "\tpublic $smtpauth = '1';",
        "\tpublic $smtpsecure = 'tls';",
        "\tpublic $smtphost = 'smtp.example.com';",
        "\tpublic $force_ssl = '2';",
        "\tpublic $sef = '1';",
        "\tpublic $sef_rewrite = '1';",
        "\tpublic $sef_suffix = '0';",
        "\tpublic $caching = '2';",
        "\tpublic $cache_handler = 'file';",
        "}"
      ].join("\n");

      function $(id){ return document.getElementById(id); }
      function esc(s){ return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;"); }

      /* Mask a sensitive value: at most the first character ever shows. */
      function mask(v){
        if (v === null || v === undefined || v === "") return "(empty)";
        return v.charAt(0) + "••• (" + v.length + " chars)";
      }

      /* Structural scan: unbalanced quotes / braces -> NOT PARSED with a line. */
      function scanStructure(text){
        var depth = 0, inStr = null, escp = false, line = 1, strLine = 0, i, ch;
        var braceStack = [];
        for (i = 0; i < text.length; i++){
          ch = text[i];
          if (ch === "\n"){ line++; continue; }
          if (inStr){
            if (escp){ escp = false; continue; }
            if (ch === "\\"){ escp = true; continue; }
            if (ch === inStr){ inStr = null; }
            continue;
          }
          if (ch === "/" && text[i+1] === "/"){
            while (i < text.length && text[i] !== "\n") i++;
            if (i < text.length) line++;
            continue;
          }
          if (ch === "#"){
            while (i < text.length && text[i] !== "\n") i++;
            if (i < text.length) line++;
            continue;
          }
          if (ch === "/" && text[i+1] === "*"){
            i += 2;
            while (i < text.length && !(text[i] === "*" && text[i+1] === "/")){
              if (text[i] === "\n") line++;
              i++;
            }
            i++;
            continue;
          }
          if (ch === "'" || ch === '"'){ inStr = ch; strLine = line; continue; }
          if (ch === "{"){ depth++; braceStack.push(line); continue; }
          if (ch === "}"){
            depth--;
            if (depth < 0) return { error: "Unbalanced closing brace — a '}' with no matching '{'.", line: line };
            braceStack.pop();
          }
        }
        if (inStr) return { error: "Unterminated " + (inStr === "'" ? "single" : "double") + "-quoted string — the quote opened on this line never closes.", line: strLine };
        if (depth > 0) return { error: "Unclosed opening brace — the '{' on this line is never closed.", line: braceStack[0] };
        return null;
      }

      function parseValue(rhs){
        rhs = rhs.replace(/^\s+/, "");
        var q = rhs.charAt(0), i, c, out = "", escp = false;
        if (q === "'" || q === '"'){
          for (i = 1; i < rhs.length; i++){
            c = rhs[i];
            if (escp){ out += c; escp = false; continue; }
            if (c === "\\"){ escp = true; continue; }
            if (c === q) return { type: "string", value: out };
            out += c;
          }
          return { type: "string", value: out };
        }
        var tok = rhs.split(/[\s;]/)[0];
        if (/^true$/i.test(tok)) return { type: "bool", value: true };
        if (/^false$/i.test(tok)) return { type: "bool", value: false };
        if (/^-?\d+$/.test(tok)) return { type: "number", value: parseInt(tok, 10) };
        if (/^-?\d*\.\d+$/.test(tok)) return { type: "number", value: parseFloat(tok) };
        return { type: "expr", value: null };
      }

      function truthy(e){
        if (!e) return false;
        if (e.type === "bool") return e.value === true;
        if (e.type === "number") return e.value !== 0;
        if (e.type === "string"){ var s = e.value.trim().toLowerCase(); return s === "1" || s === "true"; }
        return false;
      }
      function strVal(e){
        if (!e) return null;
        if (e.type === "string") return e.value;
        if (e.type === "number") return String(e.value);
        if (e.type === "bool") return e.value ? "1" : "0";
        return null;
      }
      function numVal(e){
        var s = strVal(e);
        if (s === null) return null;
        var n = parseFloat(s);
        return isNaN(n) ? null : n;
      }

      function audit(text){
        var findings = [];
        function add(sev, line, key, msg, fix){
          findings.push({ severity: sev, line: (line == null ? null : line), key: key || null, message: msg, fix: fix || null });
        }

        var bad = scanStructure(text);
        if (bad){
          add("NOT PARSED", bad.line, null, bad.error + " The audit stopped here — nothing in this input was graded, because grading a misread file would be guessing.", "Fix the quoting or braces on the named line in the original file, then paste and audit again.");
          return finish(findings, 0, true);
        }

        var lines = text.split("\n");
        var entries = {};   /* name -> {value..., line, occurrences:[lines]} */
        var order = [];
        var assignRe = /^\s*(?:public|var|protected)\s+\$([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*;?\s*$/;
        lines.forEach(function(ln, idx){
          var m = ln.match(assignRe);
          if (!m) return;
          var name = m[1], parsed = parseValue(m[2]), lineNo = idx + 1;
          if (entries[name]){
            entries[name].occurrences.push(lineNo);
            entries[name].value = parsed.value; entries[name].type = parsed.type; entries[name].line = lineNo;
          } else {
            entries[name] = { type: parsed.type, value: parsed.value, line: lineNo, occurrences: [lineNo] };
            order.push(name);
          }
        });

        var parsedCount = order.length;
        if (parsedCount === 0){
          add("NOT PARSED", 1, null, "No Joomla settings were found — no line matches the public $var = 'value'; shape of a configuration.php.", "Paste the whole configuration.php file (or at least its public $… assignment lines) and audit again.");
          return finish(findings, 0, true);
        }

        function E(name){ return entries[name]; }
        function has(name){ return Object.prototype.hasOwnProperty.call(entries, name); }

        /* Duplicates */
        order.forEach(function(name){
          var occ = entries[name].occurrences;
          if (occ.length > 1){
            add("WARNING", occ[occ.length - 1], "$" + name,
              "$" + name + " is assigned " + occ.length + " times — first on line " + occ[0] + ", again on line " + occ[occ.length - 1] + ". PHP keeps the last assignment, so line " + occ[occ.length - 1] + " is the value that actually runs and the earlier line is dead text that will mislead the next reader.",
              "Delete the stale assignment on line " + occ[0] + " so the file says once what it means.");
          }
        });

        /* Unknown keys — counted, never guessed */
        var unknownCount = 0;
        order.forEach(function(name){
          if (!KNOWN[name]){
            unknownCount++;
            add("NOT AUDITED", entries[name].line, "$" + name,
              "$" + name + " is not in this auditor's list of known Joomla configuration settings. It was counted, not graded — its value was not inspected and no claim is made about it.",
              "Check this key against the Joomla version you run; if it belongs to an extension, audit it under that extension's own guidance.");
          }
        });

        /* $debug */
        if (has("debug")){
          if (truthy(E("debug"))){
            add("BLOCKER", E("debug").line, "$debug",
              "$debug is ON. In production posture, debug mode prints stack traces, database queries, and file paths to anyone who triggers an error — a map of the site handed to strangers.",
              "Set public $debug = '0'; before this site faces the public, and debug on a staging copy instead.");
          } else {
            add("PASS", E("debug").line, "$debug", "$debug is off — error detail stays out of visitors' browsers.", null);
          }
        }

        /* $error_reporting */
        if (has("error_reporting")){
          var er = (strVal(E("error_reporting")) || "").toLowerCase();
          if (er === "maximum" || er === "development"){
            add("WARNING", E("error_reporting").line, "$error_reporting",
              "$error_reporting is '" + er + "' — the loudest setting. PHP errors, warnings, and notices are shown in full, which leaks paths and internals on a live site.",
              "Set $error_reporting to 'none' (or 'default') on the production site; keep 'maximum' for staging only.");
          } else if (er === "none"){
            add("PASS", E("error_reporting").line, "$error_reporting", "$error_reporting is 'none' — PHP errors are kept out of the page output.", null);
          }
        }

        /* $offline — paired note */
        if (has("offline")){
          if (truthy(E("offline"))){
            add("NOTE", E("offline").line, "$offline",
              "$offline is ON: visitors see the offline page. That is the safe posture while you fix anything else in this report — just remember the site is not live in this state.",
              "Turn $offline off only when the blockers and warnings above are dealt with.");
          } else {
            add("NOTE", E("offline").line, "$offline",
              "$offline is OFF: the site is live and answering the public right now. That pairs with everything else in this report — any blocker or warning here is exposed to real visitors, not staging.",
              "If fixes are pending, consider switching $offline on until they land.");
          }
        }

        /* Database posture */
        if (has("dbtype")){
          var dt = (strVal(E("dbtype")) || "").toLowerCase();
          if (dt === "mysql"){
            add("NOTE", E("dbtype").line, "$dbtype", "$dbtype is the legacy 'mysql' driver name. The maintained drivers are 'mysqli' and 'pdomysql'.", "Switch $dbtype to 'mysqli' (or 'pdomysql') and confirm the site still connects on staging.");
          } else if (dt){
            add("PASS", E("dbtype").line, "$dbtype", "$dbtype is '" + dt + "' — a current database driver.", null);
          }
        }
        if (has("host")){
          var hv = strVal(E("host"));
          if (hv && hv.toLowerCase() !== "localhost" && hv !== "127.0.0.1" && hv !== "::1"){
            add("NOTE", E("host").line, "$host",
              "$host is '" + hv + "' — not this machine. A remote database host means credentials and queries cross the network to reach it.",
              "Confirm the database connection is encrypted and that the database accepts connections only from this server.");
          }
        }
        if (has("user") && strVal(E("user")) === "root"){
          add("WARNING", E("user").line, "$user",
            "The database user is 'root' — the database's own superuser. If this config or the site is ever compromised, the attacker gets the whole database server, not just this site's tables.",
            "Create a dedicated database user with rights only on this site's database and put its name in $user.");
        }
        if (has("password")){
          var pw = strVal(E("password"));
          if (pw === null || pw === ""){
            add("WARNING", E("password").line, "$password",
              "The database password is empty (key and line reported only — there is no value to mask). An empty database password means anyone who can reach the database service can walk in as this user.",
              "Set a real database password on the database server and in $password.");
          } else {
            add("NOTE", E("password").line, "$password",
              "A database password is present in this file — masked as " + mask(pw) + " (Joomla keeps it here by design; the full value is never printed in this audit). Its safety rests entirely on the file itself: configuration.php permissions and keeping it out of public repositories.",
              "Keep configuration.php at permissions 600, out of version control, and rotate the password if this file was ever shared in full.");
          }
        } else if (has("dbtype") || has("host")){
          add("WARNING", null, "$password", "No $password line was found alongside the other database settings — Joomla cannot connect without one, or it is connecting with an empty password.", "Add the database password to $password in configuration.php.");
        }

        /* $secret — graded by length / placeholder only */
        if (!has("secret")){
          add("BLOCKER", null, "$secret",
            "No $secret line was found. The secret signs sessions and tokens across the site; without one, Joomla falls back to behaviour you did not choose.",
            "Generate a random secret of at least 32 characters and set it as $secret in configuration.php.");
        } else {
          var sv = strVal(E("secret")) || "";
          var low = sv.toLowerCase();
          var isPlaceholder = PLACEHOLDERS.indexOf(low) >= 0 || low.indexOf("changeme") >= 0 || low.indexOf("change-me") >= 0 || low.indexOf("your") === 0;
          if (isPlaceholder){
            add("BLOCKER", E("secret").line, "$secret",
              "$secret is a known placeholder word — graded by placeholder match only; the value itself is never printed here (masked: " + mask(sv) + "). Anyone who has seen a default install knows this word, so every signature it makes can be forged.",
              "Replace $secret with a random value of at least 32 characters that appears in no example, tutorial, or default file.");
          } else if (sv.length < 16){
            add("BLOCKER", E("secret").line, "$secret",
              "$secret is only " + sv.length + " characters long — graded by length only; the value is never printed here (masked: " + mask(sv) + "). Under 16 characters is short enough to brute-force, and this secret signs sessions and tokens.",
              "Replace $secret with a random value of at least 32 characters.");
          } else if (sv.length < 32){
            add("NOTE", E("secret").line, "$secret",
              "$secret is " + sv.length + " characters — graded by length only; the value is never printed here (masked: " + mask(sv) + "). It clears the 16-character floor but sits short of the 32-character mark Joomla generates for new installs.",
              "When convenient, rotate $secret to a random 32+ character value (expect all users to be logged out).");
          } else {
            add("PASS", E("secret").line, "$secret",
              "$secret is " + sv.length + " characters and matches no known placeholder — graded by length and placeholder match only; the value is never printed here (masked: " + mask(sv) + ").", null);
          }
        }

        /* $log_path / $tmp_path */
        [["log_path", "log"], ["tmp_path", "temporary"]].forEach(function(pair){
          var key = pair[0];
          if (!has(key)) return;
          var v = strVal(E(key)) || "";
          var trimmed = v.replace(/\/+$/, "");
          var lastSeg = trimmed.split("/").pop() || "";
          var isRelative = trimmed.charAt(0) !== "/" && !/^[A-Za-z]:\\/.test(trimmed);
          var webRootMark = /(^|\/)(public_html|htdocs|www|html)(\/|$)/.test(trimmed) || /\/administrator\/logs$/.test(trimmed);
          if (isRelative || webRootMark){
            add("WARNING", E(key).line, "$" + key,
              "$" + key + " points at '" + v + "' — " + (isRelative ? "a relative path inside the site folder" : "a path that sits inside the web root / at the default in-root location") + ". " + (key === "log_path" ? "Log files can hold error detail, queries, and visitor data; inside the web root they may be reachable by URL." : "Uploaded and extracted files pass through the temp folder; inside the web root they sit where the web server can be asked for them."),
              "Move $" + key + " to a folder above the web root (for example /home/youraccount/" + (key === "log_path" ? "logs" : "tmp") + ") and update the path here.");
          } else {
            add("PASS", E(key).line, "$" + key,
              "$" + key + " points at '" + v + "', which matches no known web-root or default in-root pattern — the " + pair[1] + " folder reads as outside the public tree (heuristic path match only; this tool cannot see the server).", null);
          }
        });

        /* SEF consistency */
        if (has("sef") || has("sef_rewrite") || has("sef_suffix")){
          var sefOn = truthy(E("sef")), rwOn = truthy(E("sef_rewrite")), sfxOn = truthy(E("sef_suffix"));
          var sefLine = has("sef_rewrite") ? E("sef_rewrite").line : (has("sef") ? E("sef").line : E("sef_suffix").line);
          if (rwOn && !sefOn){
            add("WARNING", sefLine, "$sef_rewrite",
              "$sef_rewrite is on but $sef is off — the two disagree. Rewrite rules have nothing to rewrite while SEF URLs are disabled, so the setting promises clean URLs the site will not produce.",
              "Either turn $sef on to use the rewrite setting, or turn $sef_rewrite off so the file matches the behaviour.");
          } else if (sefOn && !rwOn){
            add("NOTE", sefLine, "$sef_rewrite",
              "$sef is on but $sef_rewrite is off — consistent, but URLs keep index.php in them (…/index.php/page instead of …/page).",
              "For clean URLs, set $sef_rewrite to '1' and rename htaccess.txt to .htaccess on Apache servers.");
          } else if (sefOn && rwOn){
            add("PASS", sefLine, "$sef", "$sef and $sef_rewrite are both on — SEF URLs with rewriting, a consistent pair.", null);
          }
          if (sfxOn && !sefOn){
            add("NOTE", E("sef_suffix").line, "$sef_suffix",
              "$sef_suffix is on while $sef is off — the suffix (.html) only applies to SEF URLs, so this setting currently does nothing.",
              "Turn $sef on to make the suffix real, or turn $sef_suffix off to keep the file honest.");
          }
        }

        /* Mail pairing */
        var mailer = has("mailer") ? (strVal(E("mailer")) || "").toLowerCase() : null;
        if (has("mailfrom")){
          var mf = strVal(E("mailfrom")) || "";
          if (mf === "" || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(mf)){
            add("WARNING", E("mailfrom").line, "$mailfrom",
              "$mailfrom is " + (mf === "" ? "empty" : "'" + mf + "', which is not a valid-looking email address") + " — mail the site sends (password resets, order notices) will fail or look forged to receiving servers.",
              "Set $mailfrom to a real mailbox on the site's own domain.");
          }
        } else if (mailer){
          add("WARNING", null, "$mailfrom", "No $mailfrom line was found, but a mailer is configured — Joomla has no sender address to send from.", "Add $mailfrom with a real mailbox on the site's domain.");
        }
        if (mailer === "smtp"){
          var sLine = has("smtpauth") ? E("smtpauth").line : E("mailer").line;
          if (!has("smtphost") || (strVal(E("smtphost")) || "") === ""){
            add("WARNING", E("mailer").line, "$smtphost", "$mailer is 'smtp' but $smtphost is empty — there is no mail server to send through, so site mail will fail.", "Set $smtphost to your mail provider's SMTP server name.");
          }
          var secure = has("smtpsecure") ? (strVal(E("smtpsecure")) || "").toLowerCase() : "";
          if (truthy(E("smtpauth"))){
            if (secure === "" || secure === "none"){
              add("WARNING", sLine, "$smtpsecure",
                "SMTP authentication is on but $smtpsecure is '" + (secure || "not set") + "' — the SMTP username and password cross the network unencrypted on every send, readable by anyone on the path.",
                "Set $smtpsecure to 'tls' (usually port 587) or 'ssl' (usually port 465), and set $smtpport to match.");
            } else {
              add("PASS", sLine, "$smtpsecure", "SMTP authentication is paired with '" + secure + "' encryption — credentials travel inside TLS.", null);
            }
          } else {
            add("NOTE", sLine, "$smtpauth", "SMTP is configured without authentication. That is sound only if the mail server accepts mail from this host by IP or local trust.", "If the provider issued a username and password, turn $smtpauth on and pair it with $smtpsecure 'tls' or 'ssl'.");
          }
        } else if (mailer === "mail"){
          add("NOTE", E("mailer").line, "$mailer", "$mailer uses PHP mail() — it works only as well as the server's own mail setup, and messages are the most likely of the three mailers to land in spam.", "For reliable delivery, switch $mailer to 'smtp' with authentication over TLS.");
        }

        /* $force_ssl grading */
        if (has("force_ssl")){
          var fs = strVal(E("force_ssl"));
          if (fs === "0"){
            add("WARNING", E("force_ssl").line, "$force_ssl",
              "$force_ssl is 0 — nothing is forced onto HTTPS. If the site answers on plain HTTP at all, logins and session cookies can travel unencrypted.",
              "Once the certificate is live, set $force_ssl to 2 (entire site); use 1 (administrator only) as a minimum step.");
          } else if (fs === "1"){
            add("NOTE", E("force_ssl").line, "$force_ssl",
              "$force_ssl is 1 — the administrator is forced onto HTTPS, but the public front end is not. Visitor sessions and forms still ride plain HTTP where the server allows it.",
              "Prefer $force_ssl 2 (entire site) once you have confirmed the certificate covers the whole domain.");
          } else if (fs === "2"){
            add("PASS", E("force_ssl").line, "$force_ssl", "$force_ssl is 2 — the entire site is forced onto HTTPS.", null);
          } else {
            add("NOTE", E("force_ssl").line, "$force_ssl", "$force_ssl holds '" + fs + "', which is not one of the graded values (0, 1, 2) — it was reported, not reinterpreted.", "Set $force_ssl to 0, 1, or 2; 2 is the production target.");
          }
        }

        /* Sessions */
        if (has("session_handler")){
          var sh = (strVal(E("session_handler")) || "").toLowerCase();
          if (sh === "database"){
            add("PASS", E("session_handler").line, "$session_handler", "$session_handler is 'database' — sessions live in the database, the standard Joomla posture.", null);
          } else if (sh === "none"){
            add("NOTE", E("session_handler").line, "$session_handler", "$session_handler is 'none' — PHP's own default file handler stores the sessions wherever php.ini points, which this file cannot show.", "Confirm on the server that PHP's session.save_path sits outside the web root, or switch $session_handler to 'database'.");
          } else if (sh === "filesystem"){
            add("NOTE", E("session_handler").line, "$session_handler", "$session_handler is 'filesystem' — session files live wherever the server configuration points; that location is a server setting, not visible in this file.", "Confirm the session file folder sits outside the web root, or switch $session_handler to 'database'.");
          } else if (sh){
            add("NOTE", E("session_handler").line, "$session_handler", "$session_handler is '" + sh + "' — sessions depend on that external store being up; if it stops, logins stop with it.", "Make sure the " + sh + " service is monitored, or fall back to 'database'.");
          }
        }
        if (has("lifetime")){
          var lt = numVal(E("lifetime"));
          if (lt !== null){
            var arith = "$lifetime = " + lt + " → session lifetime of " + lt + " minutes (" + lt + " × 60 = " + (lt * 60) + " seconds) of inactivity before a logged-in user is signed out.";
            if (lt > 120){
              add("WARNING", E("lifetime").line, "$lifetime", arith + " Over two hours is a long window for a hijacked session cookie to stay valid.", "Bring $lifetime down toward Joomla's 15-minute default unless the site has a stated reason for long sessions.");
            } else if (lt > 60){
              add("NOTE", E("lifetime").line, "$lifetime", arith + " That is on the long side — common for member sites, generous for an admin session.", "Weigh the convenience against the session-hijack window; 15–60 minutes is the usual band.");
            } else {
              add("PASS", E("lifetime").line, "$lifetime", arith, null);
            }
          }
        }

        /* Caching posture */
        if (has("caching")){
          var cv = strVal(E("caching"));
          if (cv === "0" || cv === "" || cv === null){
            add("NOTE", E("caching").line, "$caching",
              "$caching is off — every page is built fresh on every visit. Not a safety fault, but the first thing to feel on a busy or cheaply hosted site.",
              "When the site is stable, enable conservative caching ($caching = '1') and re-check the pages your visitors use most.");
          } else {
            var chNote = has("cache_handler") ? " via the '" + (strVal(E("cache_handler")) || "") + "' handler" : "";
            add("PASS", E("caching").line, "$caching", "$caching is on (level " + cv + ")" + chNote + " — returning visitors get cached pages instead of full rebuilds.", null);
          }
        }

        /* Other stored credentials — presence only, masked */
        [["smtppass", "SMTP"], ["ftp_pass", "FTP"], ["proxy_pass", "proxy"]].forEach(function(pair){
          var key = pair[0];
          if (has(key)){
            var v = strVal(E(key));
            if (v){
              add("NOTE", E(key).line, "$" + key,
                "A " + pair[1] + " password is stored in this file — masked as " + mask(v) + "; the full value is never printed here. It shares the file with every other credential in this config, so the file's own protection covers it too.",
                "Keep configuration.php permissions tight and rotate this password if the file was ever shared in full.");
            }
          }
        });

        return finish(findings, parsedCount, false);

        function finish(f, count, notParsed){
          var counts = { blockers: 0, warnings: 0, notes: 0, passes: 0, notAudited: 0, notParsed: 0 };
          f.forEach(function(x){
            if (x.severity === "BLOCKER") counts.blockers++;
            else if (x.severity === "WARNING") counts.warnings++;
            else if (x.severity === "NOTE") counts.notes++;
            else if (x.severity === "PASS") counts.passes++;
            else if (x.severity === "NOT AUDITED") counts.notAudited++;
            else if (x.severity === "NOT PARSED") counts.notParsed++;
          });
          var verdict, vclass;
          if (notParsed || counts.notParsed > 0){ verdict = "NOT PARSED"; vclass = "notparsed"; }
          else if (counts.blockers > 0){ verdict = "DO NOT DEPLOY"; vclass = "donot"; }
          else if (counts.warnings > 0){ verdict = "DEPLOY WITH FIXES"; vclass = "fixes"; }
          else { verdict = "SAFE TO DEPLOY"; vclass = "safe"; }
          var rank = { "NOT PARSED": 0, "BLOCKER": 1, "WARNING": 2, "NOTE": 3, "NOT AUDITED": 4, "PASS": 5 };
          f.sort(function(a, b){
            var d = rank[a.severity] - rank[b.severity];
            if (d !== 0) return d;
            return (a.line || 0) - (b.line || 0);
          });
          return { verdict: verdict, vclass: vclass, counts: counts, findings: f, settingsParsed: count };
        }
      }

      var lastResult = null;

      function buildTextReport(r){
        var out = [];
        out.push("J-Dawgs Joomla Config Safety Auditor — text report");
        out.push("Verdict: " + r.verdict);
        out.push("Settings parsed: " + r.settingsParsed +
          " · Blockers: " + r.counts.blockers +
          " · Warnings: " + r.counts.warnings +
          " · Notes: " + r.counts.notes +
          " · Passes: " + r.counts.passes +
          " · Not audited: " + r.counts.notAudited +
          (r.counts.notParsed ? " · Not parsed: " + r.counts.notParsed : ""));
        out.push("Generated in your browser. Nothing was saved or sent. Password and $secret values are never printed in full — key name, line, length, and at most the first character only.");
        out.push("");
        r.findings.forEach(function(f){
          out.push("[" + f.severity + "] " + (f.line ? "Line " + f.line : "Line —") + (f.key ? " · " + f.key : "") + ": " + f.message);
          if (f.fix) out.push("  Fix: " + f.fix);
        });
        if (!r.findings.length) out.push("No findings.");
        return out.join("\n");
      }

      function buildJson(r){
        return JSON.stringify({
          tool: "J-Dawgs Joomla Config Safety Auditor",
          verdict: r.verdict,
          settingsParsed: r.settingsParsed,
          counts: r.counts,
          findings: r.findings.map(function(f){
            return { severity: f.severity, line: f.line, key: f.key, message: f.message, fix: f.fix };
          })
        }, null, 2);
      }

      function render(r){
        lastResult = r;
        $("results-card").hidden = false;
        var box = $("verdict-box");
        box.className = "verdict " + r.vclass;
        $("verdict-label").textContent = r.verdict;
        $("verdict-sub").textContent =
          r.verdict === "DO NOT DEPLOY" ? "At least one blocker must be fixed before this configuration faces the public." :
          r.verdict === "DEPLOY WITH FIXES" ? "No blockers — but fix the warnings before you call this done." :
          r.verdict === "SAFE TO DEPLOY" ? "No blockers and no warnings in the checks this auditor runs. Notes and passes are listed below for the record." :
          "The input could not be read as a Joomla configuration. See the finding below — nothing was guessed.";
        $("counts").innerHTML =
          "<span>Settings parsed <b>" + r.settingsParsed + "</b></span>" +
          "<span>Blockers <b>" + r.counts.blockers + "</b></span>" +
          "<span>Warnings <b>" + r.counts.warnings + "</b></span>" +
          "<span>Notes <b>" + r.counts.notes + "</b></span>" +
          "<span>Passes <b>" + r.counts.passes + "</b></span>" +
          "<span>Not audited <b>" + r.counts.notAudited + "</b></span>";
        var html = "";
        r.findings.forEach(function(f){
          var chipClass = f.severity.replace(" ", "");
          html += "<div class=\"finding\"><div class=\"fhead\">" +
            "<span class=\"chip " + chipClass + "\">" + esc(f.severity) + "</span>" +
            "<span class=\"fline\">" + (f.line ? "Line " + f.line : "No line") + "</span>" +
            (f.key ? "<span class=\"fkey\">" + esc(f.key) + "</span>" : "") +
            "</div><p>" + esc(f.message) + "</p>" +
            (f.fix ? "<p class=\"fix\"><b>Fix:</b> " + esc(f.fix) + "</p>" : "") +
            "</div>";
        });
        $("findings").innerHTML = html || "<p class=\"small\">No findings.</p>";
        $("report-text").textContent = buildTextReport(r);
        $("report-json").textContent = buildJson(r);
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-joomla-config-safety-auditor',
  name: 'J-Dawgs Joomla Config Safety Auditor',
  description: 'Grades a pasted Joomla configuration.php offline — debug, secret, and mail/TLS posture — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
