'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs OAuth Authorize URL & PKCE Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var STANDARD_PARAMS = {
          client_id: true, redirect_uri: true, response_type: true, scope: true,
          state: true, nonce: true, code_challenge: true, code_challenge_method: true,
          prompt: true, max_age: true, login_hint: true, audience: true, resource: true
        };

        var BAD_SAMPLE = "https://idp.example.com/authorize?response_type=token&client_id=spa-client-1234&redirect_uri=http://app.example.com/callback&scope=openid%20profile%20offline_access";
        var CLEAN_URL = "https://idp.example.com/authorize?response_type=code&client_id=web-client-9876&redirect_uri=https://app.example.com/auth/callback&scope=openid%20profile&state=7f3a9c1e5b2d48f0a6c3e9d1b5f70842&nonce=n-0S6_WzA2Mj&code_challenge=E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM&code_challenge_method=S256";
        var CLEAN_EXPECTED = "https://app.example.com/auth/callback";

        var urlInput = document.getElementById("urlInput");
        var expectedInput = document.getElementById("expectedRedirect");
        var results = document.getElementById("results");
        var verdictBox = document.getElementById("verdictBox");
        var verdictWord = document.getElementById("verdictWord");
        var verdictSub = document.getElementById("verdictSub");
        var verdictCounts = document.getElementById("verdictCounts");
        var findingsList = document.getElementById("findingsList");
        var reportBox = document.getElementById("reportBox");
        var reportText = document.getElementById("reportText");
        var copyNote = document.getElementById("copyNote");
        var pitchNote = document.getElementById("pitchNote");

        function clientType() {
          var el = document.querySelector('input[name="clientType"]:checked');
          return el ? el.value : "public";
        }

        function mask(value) {
          if (value === null || value === undefined || value === "") return "(absent)";
          return value.slice(0, 4) + "… · " + value.length + " chars";
        }

        function splitValues(v) {
          if (!v) return [];
          return v.split(/\s+/).filter(function (s) { return s.length > 0; });
        }

        // Extract the raw (still percent-encoded) value of a query parameter
        // from the pasted text, so encoding differences can be detected.
        function rawParam(pasted, name) {
          var q = pasted.indexOf("?");
          if (q === -1) return null;
          var query = pasted.slice(q + 1);
          var hash = query.indexOf("#");
          if (hash !== -1) query = query.slice(0, hash);
          var pairs = query.split("&");
          for (var i = 0; i < pairs.length; i++) {
            var eq = pairs[i].indexOf("=");
            var key = eq === -1 ? pairs[i] : pairs[i].slice(0, eq);
            var decodedKey = key;
            try { decodedKey = decodeURIComponent(key.replace(/\+/g, " ")); } catch (e) { /* keep raw */ }
            if (decodedKey === name) {
              return eq === -1 ? "" : pairs[i].slice(eq + 1);
            }
          }
          return null;
        }

        function explicitPort(str) {
          var m = /^[a-zA-Z][a-zA-Z0-9+.-]*:\/\/[^\/:?#]*:(\d+)/.exec(str || "");
          return m ? m[1] : null;
        }

        function defaultPort(protocol) {
          if (protocol === "https:") return "443";
          if (protocol === "http:") return "80";
          return "";
        }

        function mismatchKinds(rawActual, actual, expected) {
          var kinds = [];
          function add(k) { if (kinds.indexOf(k) === -1) kinds.push(k); }
          if (actual === expected) {
            if (rawActual !== null && rawActual !== expected && /%[0-9A-Fa-f]{2}/.test(rawActual)) {
              add("percent-encoding");
            }
            return kinds;
          }
          if (actual === expected + "/" || expected === actual + "/") add("trailing slash");
          var aU = null, eU = null;
          try { aU = new URL(actual); } catch (e1) { /* not parseable */ }
          try { eU = new URL(expected); } catch (e2) { /* not parseable */ }
          if (aU && eU) {
            if (aU.protocol !== eU.protocol) add("scheme");
            if (aU.hostname !== eU.hostname) add("host");
            var aEff = aU.port || defaultPort(aU.protocol);
            var eEff = eU.port || defaultPort(eU.protocol);
            if (aEff !== eEff) add("port");
            else if (explicitPort(actual) !== explicitPort(expected)) add("port (explicit default port)");
            if (aU.pathname !== eU.pathname) {
              if (aU.pathname.toLowerCase() === eU.pathname.toLowerCase()) add("path (letter case)");
              else add("path");
            }
            if (aU.search !== eU.search) add("query string");
            if (aU.hash !== eU.hash) add("fragment");
          }
          try {
            if (decodeURIComponent(actual) === expected) add("percent-encoding");
          } catch (e3) { /* ignore */ }
          if (!kinds.length) add("value");
          return kinds;
        }

        function audit(pasted, expected, type) {
          var findings = [];
          function push(sev, code, param, message, preview) {
            findings.push({ sev: sev, code: code, param: param, message: message, preview: preview || null });
          }

          var url;
          try {
            url = new URL(pasted);
          } catch (e) {
            return { invalid: true, findings: findings };
          }
          if (!url.protocol || !url.host) {
            return { invalid: true, findings: findings };
          }

          var p = url.searchParams;
          var isPublic = type !== "confidential";

          // client_id
          var clientId = p.get("client_id");
          if (clientId) {
            push("INFO", "CLIENT ID PRESENT", "client_id",
              "A client_id is present. It is shown masked — a client_id is an identifier, not a secret, but there is no reason to print it in full.",
              "client_id = " + mask(clientId));
          } else {
            push("WARNING", "NO CLIENT ID", "client_id",
              "No client_id parameter. An authorize request normally names the client it is for.");
          }

          // (1) response_type
          var rtRaw = p.get("response_type");
          var rt = splitValues(rtRaw);
          var hasCode = rt.indexOf("code") !== -1;
          var frontChannelToken = rt.indexOf("token") !== -1 || rt.indexOf("id_token") !== -1;
          if (rtRaw === null) {
            push("BLOCKER", "MISSING RESPONSE_TYPE", "response_type",
              "No response_type parameter — the provider cannot tell what flow this request is asking for, and a well-formed authorize URL always states it.");
          } else if (frontChannelToken) {
            if (isPublic) {
              push("BLOCKER", "IMPLICIT FLOW", "response_type",
                "response_type \"" + rtRaw + "\" returns tokens through the front channel (the browser redirect itself). Tokens in URLs leak through browser history, logs, and referrer headers, and a public client has no secret to fall back on. Use response_type=code with PKCE instead.",
                "response_type = " + rtRaw);
            } else {
              push("WARNING", "IMPLICIT / HYBRID FLOW", "response_type",
                "response_type \"" + rtRaw + "\" returns tokens through the front channel (the browser redirect itself), where they can leak through browser history, logs, and referrer headers. A confidential client can complete a code exchange at the token endpoint, so this is a warning rather than a blocker — but the code flow is still the safer shape.",
                "response_type = " + rtRaw);
            }
          } else if (hasCode && rt.length === 1) {
            push("INFO", "AUTHORIZATION CODE FLOW", "response_type",
              "response_type=code — the authorization code flow. Codes are exchanged at the token endpoint instead of traveling in the redirect.",
              "response_type = code");
          } else if (hasCode) {
            push("INFO", "CODE FLOW VARIANT", "response_type",
              "response_type \"" + rtRaw + "\" includes code alongside other values. Confirm every extra value is one your provider and client registration actually intend.",
              "response_type = " + rtRaw);
          } else {
            push("WARNING", "UNRECOGNIZED RESPONSE_TYPE", "response_type",
              "response_type \"" + rtRaw + "\" is not the code flow and not a recognized token flow value. Check it against your provider’s documentation.",
              "response_type = " + rtRaw);
          }

          // (2) PKCE — applies when the code flow is in play
          var cc = p.get("code_challenge");
          var ccm = p.get("code_challenge_method");
          if (hasCode) {
            if (!cc) {
              if (isPublic) {
                push("BLOCKER", "NO PKCE", "code_challenge",
                  "response_type=code with no code_challenge. A public client cannot keep a secret, so PKCE is the only thing proving the client that redeems the code is the client that asked for it.");
              } else {
                push("WARNING", "NO PKCE", "code_challenge",
                  "response_type=code with no code_challenge. A confidential client authenticates with its secret at the token endpoint, so this is a warning — but PKCE is still recommended defense in depth.");
              }
            } else {
              if (cc.length < 43 || cc.length > 128) {
                push("WARNING", "MALFORMED CHALLENGE", "code_challenge",
                  "The code_challenge is " + cc.length + " characters long. A PKCE code_challenge must be 43–128 characters (RFC 7636), so this value is outside the valid range.",
                  "code_challenge = " + mask(cc));
              } else {
                push("INFO", "PKCE CHALLENGE PRESENT", "code_challenge",
                  "A code_challenge of valid length (" + cc.length + " characters, within 43–128) is present. Shown masked — the full value is never printed here.",
                  "code_challenge = " + mask(cc));
              }
              if (ccm === null) {
                push("WARNING", "NO PKCE METHOD", "code_challenge_method",
                  "code_challenge is present but code_challenge_method is missing. Providers default a missing method to \"plain\", which exposes the verifier relationship — set code_challenge_method=S256 explicitly.",
                  "code_challenge = " + mask(cc));
              } else if (ccm === "plain") {
                push("BLOCKER", "PLAIN PKCE METHOD", "code_challenge_method",
                  "code_challenge_method=plain sends the challenge unhashed. Anyone who intercepts the authorize request can use it — use S256.",
                  "code_challenge_method = plain");
              } else if (ccm === "S256") {
                push("INFO", "S256 PKCE", "code_challenge_method",
                  "code_challenge_method=S256 — the challenge is a SHA-256 hash of the verifier, the recommended PKCE method.",
                  "code_challenge_method = S256");
              } else {
                push("WARNING", "UNKNOWN PKCE METHOD", "code_challenge_method",
                  "code_challenge_method \"" + ccm + "\" is not a recognized value (plain or S256). Check it against your provider’s documentation.",
                  "code_challenge_method = " + ccm);
              }
            }
          } else if (cc && ccm === "plain") {
            push("BLOCKER", "PLAIN PKCE METHOD", "code_challenge_method",
              "code_challenge_method=plain sends the challenge unhashed. Anyone who intercepts the authorize request can use it — use S256.",
              "code_challenge_method = plain");
          }

          // (3) state & nonce
          var state = p.get("state");
          if (!state) {
            push("BLOCKER", "NO STATE", "state",
              "No state parameter. Without state, the client cannot tie the response to the request it sent, which leaves the flow open to CSRF — an attacker can inject a response into a victim’s session.");
          } else if (state.length < 16) {
            push("WARNING", "SHORT STATE", "state",
              "The state value is only " + state.length + " characters. State should be a long, unguessable random value — at least 16 characters.",
              "state = " + mask(state));
          } else {
            push("INFO", "STATE PRESENT", "state",
              "A state parameter of " + state.length + " characters is present, so the client can bind the response to its request (CSRF protection). Shown masked.",
              "state = " + mask(state));
          }

          var scopeRaw = p.get("scope");
          var scopes = splitValues(scopeRaw);
          var nonce = p.get("nonce");
          var nonceNeeded = rt.indexOf("id_token") !== -1 || scopes.indexOf("openid") !== -1;
          if (nonceNeeded && !nonce) {
            push("WARNING", "NO NONCE", "nonce",
              "This request involves an ID token (response_type includes id_token, or scope includes openid) but carries no nonce. Without a nonce, an ID token can be replayed into the client.");
          } else if (nonce) {
            push("INFO", "NONCE PRESENT", "nonce",
              "A nonce is present, so ID tokens can be bound to this specific request. Shown masked.",
              "nonce = " + mask(nonce));
          }

          // (4) redirect_uri
          var redirect = p.get("redirect_uri");
          if (!redirect) {
            push("WARNING", "NO REDIRECT_URI", "redirect_uri",
              "No redirect_uri parameter. The provider will fall back to a pre-registered default — confirm that is what you intend, because the redirect target is where codes and tokens land.");
          } else {
            push("INFO", "REDIRECT_URI PRESENT", "redirect_uri",
              "The redirect target, shown in full because the exact destination is the thing being audited — it is an address, not a credential.",
              "redirect_uri = " + redirect);
            var rUrl = null;
            try { rUrl = new URL(redirect); } catch (e4) { /* malformed */ }
            if (!rUrl) {
              push("WARNING", "MALFORMED REDIRECT_URI", "redirect_uri",
                "The redirect_uri value does not parse as an absolute URL. Providers require an absolute redirect target.");
            } else {
              var host = rUrl.hostname;
              var isLocal = host === "localhost" || host === "127.0.0.1" || host === "::1";
              if (rUrl.protocol === "http:" && isLocal) {
                push("INFO", "LOCALHOST REDIRECT", "redirect_uri",
                  "The redirect target is http://" + host + " — cleartext on the local machine only, the standard exception for local development and native apps.",
                  "redirect_uri = " + redirect);
              } else if (rUrl.protocol === "http:") {
                push("BLOCKER", "CLEARTEXT REDIRECT", "redirect_uri",
                  "The redirect target uses http:// on a non-localhost host. Authorization codes — and in implicit flows, tokens — travel to this address unencrypted, where anyone on the path can read or steal them.",
                  "redirect_uri = " + redirect);
              } else if (rUrl.protocol === "https:") {
                push("INFO", "ENCRYPTED REDIRECT", "redirect_uri",
                  "The redirect target uses https://, so the response travels encrypted.",
                  "redirect_uri = " + redirect);
              } else {
                push("INFO", "CUSTOM-SCHEME REDIRECT", "redirect_uri",
                  "The redirect target uses the \"" + rUrl.protocol + "\" scheme — typical of native-app claimed or custom schemes. Make sure the scheme is registered to your app only.",
                  "redirect_uri = " + redirect);
              }
              if (redirect.indexOf("#") !== -1) {
                push("BLOCKER", "FRAGMENT IN REDIRECT_URI", "redirect_uri",
                  "The redirect_uri contains a fragment (#…). Fragments are forbidden in redirect_uri (RFC 6749 §3.1.2): they are stripped and can smuggle or swallow response parameters.",
                  "redirect_uri = " + redirect);
              }
              var nestedNames = ["next", "return_to", "redirect"];
              rUrl.searchParams.forEach(function (val, key) {
                if (nestedNames.indexOf(key.toLowerCase()) !== -1 && /^(https?:)?\/\//i.test(val)) {
                  push("WARNING", "OPEN-REDIRECT SUSPECT", "redirect_uri",
                    "The redirect_uri carries a nested URL in its \"" + key + "\" query parameter. If the callback page honors it without an allow-list, an attacker can bounce victims onward to any site after sign-in.",
                    key + " = " + val);
                }
              });
            }
            if (expected) {
              var rawActual = rawParam(pasted, "redirect_uri");
              if (redirect === expected && !(rawActual !== null && rawActual !== expected && /%[0-9A-Fa-f]{2}/.test(rawActual))) {
                push("INFO", "REDIRECT MATCHES EXPECTED", "redirect_uri",
                  "The redirect_uri matches the expected value you supplied, byte-for-byte.",
                  "redirect_uri = " + redirect);
              } else {
                var kinds = mismatchKinds(rawActual, redirect, expected);
                push("BLOCKER", "REDIRECT MISMATCH", "redirect_uri",
                  "The redirect_uri does not byte-exactly match the expected value you supplied. Differing part: " + kinds.join(", ") + ". OAuth providers compare redirect_uri exactly, so even a trailing slash or a case difference means rejection — or, on a lax provider, a redirect somewhere unintended. (This comparison is against the value you supplied; it does not claim which value is registered.)",
                  "redirect_uri = " + redirect);
              }
            }
          }

          // (5) scope & prompt
          if (scopes.length) {
            push("INFO", "SCOPES REQUESTED", "scope",
              "Scopes requested, listed individually: " + scopes.join(", ") + ". Confirm each one is a permission this client actually needs.",
              "scope = " + scopeRaw);
            if (scopes.indexOf("offline_access") !== -1) {
              push("WARNING", "OFFLINE ACCESS", "scope",
                "The scope list includes offline_access, which asks for a long-lived refresh token — access that keeps working while the user is away. Grant it only if the app genuinely needs background access.",
                "scope includes offline_access");
            }
          } else {
            push("INFO", "NO SCOPE", "scope",
              "No scope parameter. The provider will apply its default scope set, if any.");
          }

          var promptRaw = p.get("prompt");
          if (promptRaw) {
            var prompts = splitValues(promptRaw);
            if (prompts.indexOf("none") !== -1 && prompts.length > 1) {
              push("WARNING", "CONTRADICTORY PROMPT", "prompt",
                "prompt combines \"none\" with other values (" + promptRaw + "). prompt=none must be used alone — it promises no UI will be shown, which contradicts any other prompt value.",
                "prompt = " + promptRaw);
            } else {
              push("INFO", "PROMPT SET", "prompt",
                "prompt is set to \"" + promptRaw + "\".",
                "prompt = " + promptRaw);
            }
          }

          // (6) unrecognized parameters — name only, never the value
          var seen = {};
          p.forEach(function (val, key) {
            if (!STANDARD_PARAMS[key] && !seen[key]) {
              seen[key] = true;
              push("INFO", "UNRECOGNIZED PARAMETER", key,
                "A parameter named \"" + key + "\" is not one of the standard OAuth 2.0 / OIDC authorize parameters. It may be a provider extension — confirm it is intentional. Its value is not shown.");
            }
          });

          var blockers = findings.filter(function (f) { return f.sev === "BLOCKER"; }).length;
          var warnings = findings.filter(function (f) { return f.sev === "WARNING"; }).length;
          var infos = findings.filter(function (f) { return f.sev === "INFO"; }).length;
          var verdict, cls, sub;
          if (blockers > 0) {
            verdict = "DO NOT OPEN"; cls = "danger";
            sub = blockers + " blocker" + (blockers === 1 ? "" : "s") + " found. Opening this URL as-is risks leaked tokens, a stolen code, or a response injected into the wrong session. Fix the blockers and audit again.";
          } else if (warnings > 0) {
            verdict = "OPEN WITH FIXES"; cls = "fixes";
            sub = "No blockers, but " + warnings + " warning" + (warnings === 1 ? "" : "s") + " to fix first. Each warning below names the parameter and what to change.";
          } else {
            verdict = "SAFE TO OPEN"; cls = "safe";
            sub = "No blockers and no warnings. The URL’s flow, PKCE, state, and redirect shape all follow the checked rules — for the URL exactly as pasted.";
          }
          return {
            invalid: false, verdict: verdict, cls: cls, sub: sub,
            blockers: blockers, warnings: warnings, infos: infos,
            findings: findings, endpoint: url.protocol + "//" + url.host + url.pathname
          };
        }

        function buildReport(r, type) {
          var lines = [];
          lines.push("J-Dawgs OAuth Authorize URL & PKCE Auditor™ — audit report");
          lines.push("Endpoint (from the pasted URL; never fetched or opened): " + r.endpoint);
          lines.push("Client type audited as: " + (type === "confidential" ? "confidential (server-side)" : "public (mobile / SPA)"));
          lines.push("VERDICT: " + r.verdict);
          lines.push("Counts: " + r.blockers + " blocker(s), " + r.warnings + " warning(s), " + r.infos + " info note(s)");
          lines.push("");
          lines.push("Findings:");
          r.findings.forEach(function (f, i) {
            lines.push((i + 1) + ". [" + f.sev + "] " + f.code + " — parameter: " + f.param);
            lines.push("   " + f.message);
            if (f.preview) lines.push("   " + f.preview);
          });
          lines.push("");
          lines.push("Limits: this grades the URL as pasted only. It cannot verify the client registration, the provider’s actual behavior, or whether a redirect_uri is registered; exact-match comparison is against the expected value supplied at audit time. Sensitive values are masked (first 4 characters + length).");
          return lines.join("\n");
        }

        function showInvalid() {
          results.classList.remove("hidden");
          verdictBox.className = "verdict invalid";
          verdictWord.textContent = "NOT AN AUTHORIZE URL";
          verdictSub.textContent = "What you pasted is not a parseable absolute URL, so there is nothing to grade — no verdict. Paste the full authorize URL, starting with https:// (or http:// for a local test provider), including its query string.";
          verdictCounts.innerHTML = "";
          findingsList.innerHTML = "";
          reportBox.classList.add("hidden");
          copyNote.textContent = "";
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "BAD_SAMPLE": (typeof BAD_SAMPLE !== 'undefined' ? BAD_SAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-oauth-authorize-url-auditor',
  name: 'J-Dawgs OAuth Authorize URL & PKCE Auditor',
  description: 'about to open or send an OAuth authorize / login URL',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "BAD_SAMPLE": __core["BAD_SAMPLE"] }
};
