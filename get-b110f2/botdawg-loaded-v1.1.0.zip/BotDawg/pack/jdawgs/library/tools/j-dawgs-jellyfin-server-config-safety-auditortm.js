'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Jellyfin Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

    /* AUDIT-CORE-START */
    var SECRET_KEY_RE = /(api[-_]?key|access[-_]?key|password|passwd|secret|token|private[-_]?key|credential)/i;
    var KNOWN_KEYS = {};
    (function(){
      var list = ["ENABLEREMOTEACCESS","ENABLEREMOTEACCESSMONITOR","REQUIREHTTPS","ISSTARTUPWIZARDCOMPLETED",
      "PUBLISHEDSERVERURI","PUBLISHEDSERVERURIS","PUBLISHEDSERVERURL","BASEURL","ENABLEHTTPS",
      "CERTIFICATEPATH","CUSTOMCERTIFICATEPATH","CERTIFICATEPASSWORD","ENABLEDLNA","ENABLEDLNASERVER","ENABLEDLNAPLAYTO",
      "ENABLEUPNP","LOCALNETWORKADDRESSES","LOCALNETWORKSUBNETS","BINDADDRESS","LISTENADDRESS","SERVERNAME",
      "HTTPPORTNUMBER","HTTPSPORTNUMBER","PUBLICHTTPPORT","PUBLICHTTPSPORT","METADATAPATH","LIBRARYMETADATAPATH",
      "CACHEPATH","LOGPATH","DATABASEPATH","ENABLEHARDWAREENCODING","ENABLEHARDWAREDECODING","HARDWAREACCELERATIONTYPE",
      "ENCODINGTHREADCOUNT","APIKEY","REPOSITORYURL","PLUGINREPOSITORIES","ENABLEAUTOMATICPORTMAPPING",
      "ISREMOTEIPFILTERBLACKLIST","REMOTEIPFILTER","ENABLECASESENSITIVE","PUBLISHEDSERVERURLS","CUSTOMAUTHENTICATIONPROVIDERS"];
      for (var i=0;i<list.length;i++) KNOWN_KEYS[list[i]] = 1;
    })();
    var URI_KEYS = {PUBLISHEDSERVERURI:1, PUBLISHEDSERVERURIS:1, PUBLISHEDSERVERURL:1, PUBLISHEDSERVERURLS:1, BASEURL:1};
    var STRUCT_KEYS = {VERSION:1,SERVICES:1,ENVIRONMENT:1,IMAGE:1,CONTAINERNAME:1,PORTS:1,VOLUMES:1,RESTART:1,NETWORKS:1,DEPENDSON:1,BUILD:1,COMMAND:1,ENTRYPOINT:1,USER:1,WORKINGDIR:1,EXPOSE:1,HOSTNAME:1,DEVICES:1,EXECSTART:1,UNIT:1,SERVICE:1,INSTALL:1,DESCRIPTION:1,WANTEDBY:1,AFTER:1,TYPE:1};

    function normKey(raw){
      var k = String(raw).replace(/^jellyfin[_-]?/i, "");
      return k.replace(/[^A-Za-z0-9]/g, "").toUpperCase();
    }
    function parseBool(v){
      var s = String(v).trim().toLowerCase();
      if (s==="true"||s==="yes"||s==="1"||s==="on"||s==="enabled") return true;
      if (s==="false"||s==="no"||s==="0"||s==="off"||s==="disabled") return false;
      return null;
    }
    function cleanVal(v){
      v = String(v).trim();
      if (v.length >= 2){
        var a = v.charAt(0), b = v.charAt(v.length-1);
        if ((a==='"' && b==='"') || (a==="'" && b==="'")) v = v.slice(1,-1);
      }
      return v.trim();
    }
    function urlHost(v){
      var m = String(v).match(/^https?:\/\/([^\/:?#]+)/i);
      return m ? m[1].toLowerCase() : null;
    }
    function isLocalHost(h){
      return h === "localhost" || h === "127.0.0.1" || h === "::1" || h === "[::1]";
    }

    function auditConfig(text){
      var raw = (text === null || text === undefined) ? "" : String(text);
      var result = {
        verdict: "", reasonCode: "", reason: "", format: "Not recognized",
        lineCount: 0, entryCount: 0, recognizedCount: 0,
        findings: [], protections: [], notChecked: [], notParsed: []
      };
      if (raw.trim() === ""){
        result.verdict = "NOT ENOUGH TO GRADE";
        result.reasonCode = "EMPTY";
        result.reason = "The paste is empty — there is nothing to grade. Paste a Jellyfin config (a system.xml / network.xml fragment, docker-compose environment lines, or systemd Environment lines) and run the audit again.";
        result.lineCount = 0;
        return result;
      }
      var lines = raw.split(/\r?\n/);
      result.lineCount = lines.length;
      var entries = [];
      var xmlCount = 0, envCount = 0, sawCompose = false, sawSystemd = false;

      for (var i = 0; i < lines.length; i++){
        var lineNo = i + 1;
        var t = lines[i].trim();
        if (t === "") continue;
        if (t.charAt(0) === "#" || t.indexOf("//") === 0) continue;
        if (t.indexOf("<!--") === 0) continue;
        if (t.indexOf("<?") === 0){ xmlCount++; continue; }
        var m;
        m = t.match(/^<([A-Za-z][\w.-]*)>([^<>]*)<\/([A-Za-z][\w.-]*)>$/);
        if (m && m[1] === m[3]){
          entries.push({line: lineNo, rawKey: m[1], key: normKey(m[1]), value: cleanVal(m[2])});
          xmlCount++; continue;
        }
        m = t.match(/^<([A-Za-z][\w.-]*)\s*\/>$/);
        if (m){
          entries.push({line: lineNo, rawKey: m[1], key: normKey(m[1]), value: ""});
          xmlCount++; continue;
        }
        if (/^<\/?[A-Za-z][\w.-]*(\s[^>]*)?>$/.test(t)){ xmlCount++; continue; }
        if (/^\[[A-Za-z]+\]$/.test(t)){ sawSystemd = true; continue; }
        m = t.match(/^Environment\s*=\s*"?([A-Za-z_][\w.-]*)=(.*)$/);
        if (m){
          sawSystemd = true;
          entries.push({line: lineNo, rawKey: m[1], key: normKey(m[1]), value: cleanVal(m[2].replace(/"$/, ""))});
          envCount++; continue;
        }
        m = t.match(/^(?:-\s*)?([A-Za-z_][\w.-]*)\s*[:=]\s*(.*)$/);
        if (m && !/^(https?)$/i.test(m[1])){
          var v = cleanVal(m[2].replace(/\s+#.*$/, ""));
          var nk = normKey(m[1]);
          entries.push({line: lineNo, rawKey: m[1], key: nk, value: v});
          envCount++;
          if (STRUCT_KEYS[nk]) sawCompose = true;
          continue;
        }
        if (/^-\s+\S/.test(t)){ sawCompose = true; continue; }
        result.notParsed.push(lineNo);
      }
      result.entryCount = entries.length;

      function isRecognized(e){
        return !!KNOWN_KEYS[e.key] || /^jellyfin[_-]/i.test(e.rawKey);
      }
      var recognized = 0;
      for (var r = 0; r < entries.length; r++) if (isRecognized(entries[r])) recognized++;
      result.recognizedCount = recognized;

      if (xmlCount > 0 && envCount === 0) result.format = "Jellyfin XML (system.xml / network.xml style)";
      else if (envCount > 0 && xmlCount === 0 && sawSystemd && !sawCompose) result.format = "systemd / environment lines";
      else if (envCount > 0 && xmlCount === 0) result.format = "Environment lines (docker-compose / KEY=value style)";
      else if (xmlCount > 0 && envCount > 0) result.format = "Mixed XML and environment lines";

      if (recognized === 0){
        result.verdict = "NOT ENOUGH TO GRADE";
        result.reasonCode = "NO_KEYS";
        result.reason = "No recognizable Jellyfin settings were found in the paste — it may be a different program's config, or plain prose. Nothing was graded, and nothing was assumed safe.";
        return result;
      }

      function byKey(k){
        var out = [];
        for (var j = 0; j < entries.length; j++) if (entries[j].key === k) out.push(entries[j]);
        return out;
      }
      function first(k){ var a = byKey(k); return a.length ? a[0] : null; }
      function addFinding(sev, line, key, title, detail, fix){
        result.findings.push({severity: sev, line: line, key: key, title: title, detail: detail, fix: fix});
      }
      function addProtection(text){ result.protections.push(text); }

      var remoteEntries = byKey("ENABLEREMOTEACCESS").concat(byKey("ENABLEREMOTEACCESSMONITOR"));
      var remoteOnEntry = null, remoteOffEntry = null;
      remoteEntries.forEach(function(e){
        var b = parseBool(e.value);
        if (b === true && !remoteOnEntry) remoteOnEntry = e;
        if (b === false && !remoteOffEntry) remoteOffEntry = e;
      });
      var remoteOn = !!remoteOnEntry;
      var remotePresent = remoteEntries.length > 0;

      var reqHttps = first("REQUIREHTTPS");
      var reqHttpsVal = reqHttps ? parseBool(reqHttps.value) : null;
      var enableHttps = first("ENABLEHTTPS");
      var enableHttpsVal = enableHttps ? parseBool(enableHttps.value) : null;
      var wizard = first("ISSTARTUPWIZARDCOMPLETED");
      var wizardVal = wizard ? parseBool(wizard.value) : null;

      /* Secrets scan — key name, line, length only. The value is never copied anywhere. */
      var secretKeyPresent = false;
      entries.forEach(function(e){
        if (SECRET_KEY_RE.test(e.rawKey)){
          secretKeyPresent = true;
          if (e.value.length > 0){
            addFinding("BLOCKER", e.line, e.rawKey, "Plaintext secret in the config",
              "The key " + e.rawKey + " holds a plaintext value " + e.value.length + " characters long. Anyone who can read this config file has the secret. The value itself is never shown in this report.",
              "Move the secret out of the config file (environment injection or a secret store) and rotate it — it has been sitting in plaintext.");
          }
        }
      });

      /* Setup wizard */
      if (wizard && wizardVal === false){
        addFinding("BLOCKER", wizard.line, wizard.rawKey, "Setup wizard still open",
          "IsStartupWizardCompleted is false — first-time setup is still open, so anyone who can reach the server can walk through it and create the admin account.",
          "Finish the setup wizard on the server, then confirm this setting reads true.");
      }
      if (wizard && wizardVal === true) addProtection("Setup wizard completed (line " + wizard.line + ") — the open first-time setup, including admin account creation, is closed.");

      /* Remote access + HTTPS pairing */
      if (remoteOn){
        if (!reqHttps){
          addFinding("BLOCKER", remoteOnEntry.line, "RequireHttps", "Remote access on, HTTPS not required anywhere in the paste",
            "Remote access is enabled, but RequireHttps does not appear anywhere in the paste — nothing in this config requires HTTPS for remote connections.",
            "Set RequireHttps to true and serve a valid certificate, or turn remote access off.");
        } else if (reqHttpsVal === false){
          addFinding("BLOCKER", reqHttps.line, reqHttps.rawKey, "Remote access on without required HTTPS",
            "EnableRemoteAccess is on but RequireHttps is false — remote clients can connect over plain HTTP, logins included.",
            "Set RequireHttps to true and serve a valid certificate, or turn remote access off.");
        }
        if (enableHttps && enableHttpsVal === false){
          addFinding("BLOCKER", enableHttps.line, enableHttps.rawKey, "HTTPS listener off while remote access is on",
            "EnableHttps is false while remote access is enabled — the server's own HTTPS listener is off, so remote traffic depends entirely on something upstream providing encryption.",
            "Set EnableHttps to true with a certificate, or put a TLS-terminating reverse proxy in front — and say so in the config — or disable remote access.");
        }
      }
      if (reqHttpsVal === true) addProtection("RequireHttps is true (line " + reqHttps.line + ") — remote connections must use HTTPS.");
      if (enableHttpsVal === true) addProtection("EnableHttps is true (line " + enableHttps.line + ") — Jellyfin's HTTPS listener is on.");
      if (!remoteOn && remoteOffEntry) addProtection("Remote access is off (" + remoteOffEntry.rawKey + " = false, line " + remoteOffEntry.line + ").");

      /* Published URIs / base URL */
      var uriPresent = false;
      entries.forEach(function(e){
        if (!URI_KEYS[e.key]) return;
        uriPresent = true;
        if (e.value === ""){
          addFinding("WARNING", e.line, e.rawKey, "Published server URI is empty",
            "An empty published URI leaves Jellyfin to auto-detect and publish its own address, which can put the server on interfaces you did not choose.",
            "Set the published URI explicitly — an https:// address for remote use, or a localhost address for local-only use.");
          return;
        }
        var host = urlHost(e.value);
        if (host === "0.0.0.0" || host === "::"){
          addFinding(remoteOn ? "BLOCKER" : "WARNING", e.line, e.rawKey, "Published on all interfaces",
            "The published address is " + e.value + " — the all-interfaces address, so the server is offered on every network interface.",
            "Publish a specific address instead — the one interface or name you actually mean to expose.");
          return;
        }
        if (/^http:\/\//i.test(e.value)){
          if (isLocalHost(host || "")){
            addFinding("WARNING", e.line, e.rawKey, "Published address is plain HTTP on localhost",
              "The published address " + e.value + " is plain HTTP. On localhost only that stays on this machine, but anything that starts proxying it inherits the exposure.",
              "Keep it localhost-only, or switch the published address to https://.");
          } else {
            addFinding(remoteOn ? "BLOCKER" : "WARNING", e.line, e.rawKey, "Published address uses plain HTTP",
              "The published address is " + e.value + " — an http:// address sends logins, API keys, and media traffic unencrypted to anyone on the path.",
              "Publish an https:// address instead (Jellyfin's own HTTPS or a TLS reverse proxy).");
          }
          return;
        }
        if (/^https:\/\//i.test(e.value)) addProtection("Published address uses https:// (line " + e.line + ").");
        if (isLocalHost(host || "")) addProtection("Published address is localhost-only (line " + e.line + ") — not reachable from other machines.");
      });

      /* Bind / listen addresses */
      var bindPresent = false;
      ["LOCALNETWORKADDRESSES","BINDADDRESS","LISTENADDRESS"].forEach(function(k){
        byKey(k).forEach(function(e){
          bindPresent = true;
          var v = e.value;
          if (/(^|[,\s])0\.0\.0\.0([,\s]|$)/.test(v) || /(^|[,\s])::([,\s]|$)/.test(v) || v === "*"){
            addFinding(remoteOn ? "BLOCKER" : "WARNING", e.line, e.rawKey, "Binds on all interfaces",
              e.rawKey + " listens on every network interface (0.0.0.0 / ::). Combined with remote features, that is the widest possible exposure.",
              "Bind to the specific LAN address you mean to serve, or 127.0.0.1 for local-only use.");
          } else if (isLocalHost(v.split(",")[0].trim())){
            addProtection("Bound to localhost only via " + e.rawKey + " (line " + e.line + ").");
          }
        });
      });

      /* Custom certificate */
      var certPath = first("CERTIFICATEPATH") || first("CUSTOMCERTIFICATEPATH");
      var certPw = first("CERTIFICATEPASSWORD");
      if (certPath && certPath.value !== ""){
        if (!certPw){
          addFinding("WARNING", certPath.line, certPath.rawKey, "Certificate path set, no certificate password in the paste",
            "A custom HTTPS certificate path is set (" + certPath.value + "), but no certificate password appears in the paste. If that .pfx file is password-protected and the password is not supplied another way, Jellyfin cannot load it and HTTPS fails.",
            "Supply the certificate password through a protected channel, or use a certificate/key pair that needs no password — do not leave the gap to be discovered at startup.");
        } else if (certPw.value === ""){
          addFinding("WARNING", certPath.line, certPath.rawKey, "Certificate password is blank in the paste",
            "A custom HTTPS certificate path is set, but the certificate password in the paste is empty. If the .pfx file is password-protected, Jellyfin cannot load it and HTTPS fails.",
            "Supply the real certificate password through a protected channel, or switch to a certificate/key pair that needs no password.");
        }
      }

      /* DLNA */
      var dlnaPresent = false, dlnaTrue = [];
      ["ENABLEDLNA","ENABLEDLNASERVER","ENABLEDLNAPLAYTO"].forEach(function(k){
        byKey(k).forEach(function(e){
          dlnaPresent = true;
          if (parseBool(e.value) === true) dlnaTrue.push(e);
        });
      });
      dlnaTrue.forEach(function(e){
        addFinding("WARNING", e.line, e.rawKey, "DLNA is on — extra network exposure",
          "DLNA announces this server on the local network and serves media discovery and playback control to devices that ask. That is a wider door than the web UI alone.",
          "Turn DLNA off unless you actively use DLNA players on your network.");
      });
      if (dlnaPresent && dlnaTrue.length === 0) addProtection("DLNA is off (checked on line " + byKey("ENABLEDLNAPLAYTO").concat(byKey("ENABLEDLNASERVER"), byKey("ENABLEDLNA"))[0].line + ").");

      /* UPnP */
      var upnp = first("ENABLEUPNP");
      var upnpPresent = !!upnp;
      if (upnp && parseBool(upnp.value) === true){
        addFinding("WARNING", upnp.line, upnp.rawKey, "UPnP is on — the router may open ports by itself",
          "With UPnP enabled, Jellyfin can ask the router to forward ports automatically. The server's exposure then depends on the router's UPnP behavior, not on a port rule you wrote down.",
          "Turn EnableUPnP off and forward ports manually, so every open port is one you chose.");
      }
      if (upnp && parseBool(upnp.value) === false) addProtection("UPnP is off (line " + upnp.line + ") — no automatic router port-mapping.");

      /* Other plain-HTTP URLs: repositories, metadata, anything else fetched or published */
      var repoPresent = false;
      entries.forEach(function(e){
        if (/REPOSITOR|METADATA/.test(e.key)) repoPresent = true;
        if (URI_KEYS[e.key]) return;
        if (SECRET_KEY_RE.test(e.rawKey)) return;
        if (e.value.indexOf("http://") >= 0){
          var title = "Plain-HTTP URL in the config";
          if (/REPOSITOR/.test(e.key)) title = "Plugin repository over plain HTTP";
          else if (/METADATA/.test(e.key)) title = "Metadata source over plain HTTP";
          addFinding("WARNING", e.line, e.rawKey, title,
            e.rawKey + " points at an http:// address — whatever is fetched from or sent there travels unencrypted and can be altered in transit.",
            "Use the https:// address for this source.");
        }
      });

      /* Not checked list */
      if (!remotePresent) result.notChecked.push("Remote access state — EnableRemoteAccess does not appear in the paste.");
      if (!reqHttps && !remoteOn) result.notChecked.push("HTTPS requirement — RequireHttps does not appear in the paste.");
      if (!wizard) result.notChecked.push("Setup wizard state — IsStartupWizardCompleted does not appear in the paste.");
      if (!uriPresent) result.notChecked.push("Published server URI / base URL — no published address appears in the paste.");
      if (!enableHttps) result.notChecked.push("HTTPS listener — EnableHttps does not appear in the paste.");
      if (!certPath) result.notChecked.push("Custom HTTPS certificate — no certificate path appears in the paste.");
      if (!bindPresent && !uriPresent) result.notChecked.push("Interface binding — no LocalNetworkAddresses / bind address appears in the paste.");
      if (!dlnaPresent) result.notChecked.push("DLNA — EnableDlnaServer / EnableDlnaPlayTo do not appear in the paste.");
      if (!upnpPresent) result.notChecked.push("UPnP — EnableUPnP does not appear in the paste.");
      if (!repoPresent) result.notChecked.push("Remote metadata / plugin repository URLs — none appear in the paste.");

      var gradedAreas = 0;
      [remotePresent, !!wizard, uriPresent, !!enableHttps, !!certPath, dlnaPresent, upnpPresent, bindPresent, repoPresent, secretKeyPresent].forEach(function(b){ if (b) gradedAreas++; });
      if (gradedAreas === 0 && result.findings.length === 0){
        result.verdict = "NOT ENOUGH TO GRADE";
        result.reasonCode = "NO_GRADEABLE";
        result.reason = "The paste does contain Jellyfin-related lines, but none of the settings this auditor grades — remote access, HTTPS, wizard state, published address, binding, DLNA, UPnP, certificates, or secrets. Nothing was graded, and nothing was assumed safe.";
        return result;
      }

      result.findings.sort(function(a, b){
        var sa = a.severity === "BLOCKER" ? 0 : 1, sb = b.severity === "BLOCKER" ? 0 : 1;
        if (sa !== sb) return sa - sb;
        return a.line - b.line;
      });
      var blockers = result.findings.filter(function(f){ return f.severity === "BLOCKER"; }).length;
      var warnings = result.findings.length - blockers;
      if (blockers > 0) result.verdict = "DO NOT DEPLOY";
      else if (warnings > 0) result.verdict = "DEPLOY WITH FIXES";
      else result.verdict = "SAFE TO DEPLOY";
      result.blockers = blockers;
      result.warnings = warnings;
      return result;
    }
    /* AUDIT-CORE-END */

    var RISKY_EXAMPLE = [
      '<?xml version="1.0" encoding="utf-8"?>',
      '<ServerConfiguration>',
      '  <IsStartupWizardCompleted>false</IsStartupWizardCompleted>',
      '  <EnableDlnaPlayTo>true</EnableDlnaPlayTo>',
      '  <EnableUPnP>true</EnableUPnP>',
      '</ServerConfiguration>',
      '<NetworkConfiguration>',
      '  <EnableRemoteAccess>true</EnableRemoteAccess>',
      '  <RequireHttps>false</RequireHttps>',
      '  <EnableHttps>false</EnableHttps>',
      '  <PublishedServerUri>http://media.example.com:8096</PublishedServerUri>',
      '  <CertificatePath>/config/certs/jellyfin.pfx</CertificatePath>',
      '  <ApiKey>jf_live_9f2c7ab41d8e4f0aa3c5e6b7d8091f22</ApiKey>',
      '  <DatabasePassword>Db!Passw0rd-7741</DatabasePassword>',
      '</NetworkConfiguration>'
    ].join("\n");

    var HARDENED_EXAMPLE = [
      '<?xml version="1.0" encoding="utf-8"?>',
      '<ServerConfiguration>',
      '  <IsStartupWizardCompleted>true</IsStartupWizardCompleted>',
      '  <EnableDlnaPlayTo>false</EnableDlnaPlayTo>',
      '  <EnableUPnP>false</EnableUPnP>',
      '</ServerConfiguration>',
      '<NetworkConfiguration>',
      '  <EnableRemoteAccess>true</EnableRemoteAccess>',
      '  <RequireHttps>true</RequireHttps>',
      '  <EnableHttps>true</EnableHttps>',
      '  <PublishedServerUri>https://media.example.com</PublishedServerUri>',
      '  <EnableRemoteAccessMonitor>false</EnableRemoteAccessMonitor>',
      '</NetworkConfiguration>'
    ].join("\n");

    var WORKED_EXAMPLE = [
      'services:',
      '  jellyfin:',
      '    image: jellyfin/jellyfin',
      '    environment:',
      '      - JELLYFIN_PublishedServerUrl=http://jellyfin.example.com:8096',
      '      - TZ=America/Chicago'
    ].join("\n");
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined), "WORKED_EXAMPLE": (typeof WORKED_EXAMPLE !== 'undefined' ? WORKED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-jellyfin-server-config-safety-auditortm',
  name: 'J-Dawgs Jellyfin Server Config Safety Auditor',
  description: 'Jellyfin\'s own checks only answer will-it-start on the host; ours grades a pasted config offline (remote access vs HTTPS, open setup wizard, plaintext secrets by key name/line/length only) and returns one deploy verdict with a located fix list.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"], "WORKED_EXAMPLE": __core["WORKED_EXAMPLE"] }
};
