'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Wger Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

/* ---------- Built-in examples (exact lines; line numbers are graded) ---------- */
var RISKY_EXAMPLE = [
  "# Risky Wger config — for testing only",
  "DEBUG=True",
  "SECRET_KEY=changeme123",
  "ALLOWED_HOSTS=*",
  "DATABASE_URL=postgres://wger:plaintextpass123@db:5432/wger",
  "EMAIL_HOST_PASSWORD=mailpass456",
  "SITE_URL=http://example.com",
  "ALLOW_REGISTRATION=True",
  "EMAIL_USE_TLS=False"
].join("\n");

var HARDENED_EXAMPLE = [
  "DEBUG=False",
  "SECRET_KEY=${SECRET_KEY}",
  "ALLOWED_HOSTS=wger.example.com",
  "DATABASE_URL=postgres://wger:${DB_PASSWORD}@db:5432/wger",
  "EMAIL_HOST_PASSWORD=${EMAIL_HOST_PASSWORD}",
  "SITE_URL=https://wger.example.com",
  "ALLOW_REGISTRATION=False",
  "EMAIL_USE_TLS=True"
].join("\n");

/* ---------- Audit engine (shared by the UI and the self-test) ---------- */
var RECOGNIZED_KEYS = {
  DEBUG:1, SECRET_KEY:1, ALLOWED_HOSTS:1,
  DATABASE_URL:1, DATABASE_URI:1, DATABASE_PASSWORD:1, DB_PASSWORD:1, POSTGRES_PASSWORD:1,
  EMAIL_HOST_PASSWORD:1, EMAIL_PASSWORD:1, SMTP_PASSWORD:1,
  SITE_URL:1, WGER_SITE_URL:1, BASE_URL:1, CSRF_TRUSTED_ORIGINS:1,
  ALLOW_REGISTRATION:1, ALLOW_SIGNUP:1, OPEN_REGISTRATION:1, REGISTRATION_OPEN:1,
  EMAIL_USE_TLS:1, EMAIL_HOST:1, EMAIL_PORT:1, EMAIL_HOST_USER:1, EMAIL_BACKEND:1,
  TIME_ZONE:1, LANGUAGE_CODE:1, USE_TZ:1, STATIC_URL:1, MEDIA_URL:1,
  CELERY_BROKER_URL:1, REDIS_URL:1, CACHE_URL:1, SESSION_COOKIE_SECURE:1, CSRF_COOKIE_SECURE:1, SECURE_SSL_REDIRECT:1
};
var PASSWORD_KEYS = { DATABASE_PASSWORD:1, DB_PASSWORD:1, POSTGRES_PASSWORD:1, EMAIL_HOST_PASSWORD:1, EMAIL_PASSWORD:1, SMTP_PASSWORD:1 };
var EMAIL_PASSWORD_KEYS = { EMAIL_HOST_PASSWORD:1, EMAIL_PASSWORD:1, SMTP_PASSWORD:1 };
var URL_KEYS = { SITE_URL:1, WGER_SITE_URL:1, BASE_URL:1, CSRF_TRUSTED_ORIGINS:1 };
var REGISTRATION_KEYS = { ALLOW_REGISTRATION:1, ALLOW_SIGNUP:1, OPEN_REGISTRATION:1, REGISTRATION_OPEN:1 };
var SECRET_BAD_WORDS = ["changeme", "example", "insecure", "django-insecure", "secret"];
var SEV_ORDER = { CRITICAL:0, HIGH:1, MEDIUM:2 };

function isTruthy(v){ var s = String(v).trim().toLowerCase(); return s==="true"||s==="1"||s==="yes"||s==="on"; }
function isFalsy(v){ var s = String(v).trim().toLowerCase(); return s==="false"||s==="0"||s==="no"||s==="off"; }
function isOnlyEnvRef(v){
  var s = String(v).trim();
  if (/^\$\{[^}]*\}$/.test(s)) return true;
  if (/^\$\([^)]*\)$/.test(s)) return true;
  if (/^env:/i.test(s)) return true;
  return false;
}
function cleanValue(raw){
  var s = String(raw).trim();
  if (s.length >= 2 && ((s.charAt(0)==='"' && s.charAt(s.length-1)==='"') || (s.charAt(0)==="'" && s.charAt(s.length-1)==="'"))) {
    s = s.slice(1, -1);
  }
  return s.trim();
}
function parseConfig(text){
  var entries = [];
  var lines = String(text == null ? "" : text).split(/\r?\n/);
  for (var i = 0; i < lines.length; i++){
    var raw = lines[i];
    var trimmed = raw.trim();
    if (!trimmed || trimmed.charAt(0) === "#") continue;
    var m = trimmed.match(/^(?:export\s+)?([A-Za-z_][A-Za-z0-9_.]*)\s*=\s*(.*)$/);
    if (!m) m = trimmed.match(/^([A-Za-z_][A-Za-z0-9_.]*)\s*:\s+(.*)$/);
    if (!m) continue;
    entries.push({ key: m[1].toUpperCase(), rawKey: m[1], value: cleanValue(m[2]), line: i + 1 });
  }
  return entries;
}

function auditConfig(text){
  var entries = parseConfig(text);
  var findings = [];
  var byKey = {};
  var recognized = {};
  var i, e;
  for (i = 0; i < entries.length; i++){
    e = entries[i];
    if (!byKey[e.key]) byKey[e.key] = [];
    byKey[e.key].push(e);
    if (RECOGNIZED_KEYS[e.key]) recognized[e.key] = 1;
  }
  var recognizedCount = Object.keys(recognized).length;

  function add(severity, key, line, issue, fix, secretLength, secretLengthKind){
    findings.push({ severity: severity, key: key, line: line, issue: issue, fix: fix,
      secretLength: (typeof secretLength === "number" ? secretLength : null),
      secretLengthKind: secretLengthKind || null });
  }

  /* Per-line rules */
  for (i = 0; i < entries.length; i++){
    e = entries[i];
    var v = e.value;

    if (e.key === "DEBUG" && isTruthy(v)){
      add("CRITICAL", "DEBUG", e.line,
        "DEBUG is switched on. Debug mode exposes stack traces, settings, and environment details to anyone who can trigger an error.",
        "Set DEBUG=False for any deployed server and restart the service.");
    }

    if (e.key === "SECRET_KEY" && v !== "" && !isOnlyEnvRef(v)){
      var lower = v.toLowerCase();
      var bad = null;
      for (var b = 0; b < SECRET_BAD_WORDS.length; b++){ if (lower.indexOf(SECRET_BAD_WORDS[b]) !== -1){ bad = SECRET_BAD_WORDS[b]; break; } }
      var reasons = [];
      if (v.length < 32) reasons.push("it is only " + v.length + " characters long (minimum 32)");
      if (bad) reasons.push("it contains a known placeholder word");
      if (reasons.length){
        add("CRITICAL", "SECRET_KEY", e.line,
          "SECRET_KEY is weak plaintext: " + reasons.join(" and ") + ". A guessable key lets an attacker forge sessions and signed data. Reported by length only: value length " + v.length + ".",
          "Generate a fresh random SECRET_KEY of at least 50 characters, store it outside the config file, and reference it as ${SECRET_KEY}.",
          v.length, "value length");
      }
    }

    if (e.key === "ALLOWED_HOSTS" && v.indexOf("*") !== -1){
      add("HIGH", "ALLOWED_HOSTS", e.line,
        "ALLOWED_HOSTS contains the wildcard *. The app will answer requests for any hostname, which enables host-header attacks and cache poisoning.",
        "Replace * with the exact hostnames the server answers for, e.g. ALLOWED_HOSTS=wger.example.com.");
    }

    if ((e.key === "DATABASE_URL" || e.key === "DATABASE_URI") && v){
      var um = v.match(/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\/[^:@\/]+:([^@]*)@/);
      if (um && um[1] && !isOnlyEnvRef(um[1])){
        add("HIGH", e.key, e.line,
          "The database URL carries a plaintext password (password length " + um[1].length + "). Anyone who reads this file owns the database. Reported by password length only.",
          "Move the password out of the URL into an environment reference, e.g. postgres://user:${DB_PASSWORD}@host:5432/dbname, and rotate the exposed password.",
          um[1].length, "password length");
      }
    }

    if (PASSWORD_KEYS[e.key] && v !== "" && !isOnlyEnvRef(v)){
      add("HIGH", e.key, e.line,
        e.key + " is set to a plaintext password (value length " + v.length + "). A config file is not a safe place for a live password. Reported by value length only.",
        "Replace the value with an environment reference such as ${" + e.key + "} and rotate the exposed password.",
        v.length, "value length");
    }

    if (URL_KEYS[e.key] && v){
      var parts = v.split(",");
      var hasHttp = false;
      for (var p = 0; p < parts.length; p++){ if (/^http:\/\//i.test(parts[p].trim().replace(/^[\[\]"']+/, ""))) hasHttp = true; }
      if (hasHttp){
        add("HIGH", e.key, e.line,
          e.key + " uses plain http://. Traffic, logins, and session cookies on that origin travel unencrypted.",
          "Serve the site over HTTPS and set " + e.key + " to the https:// address.");
      }
    }

    if (REGISTRATION_KEYS[e.key] && isTruthy(v)){
      add("HIGH", e.key, e.line,
        e.key + " is switched on, so anyone on the internet can create an account on this server.",
        "Set " + e.key + "=False unless public sign-up is deliberate; create accounts by invitation or admin action instead.");
    }
  }

  /* Missing-key rules */
  if (!byKey["SECRET_KEY"]){
    add("CRITICAL", "SECRET_KEY", null,
      "SECRET_KEY is missing entirely. Django cannot sign sessions or tokens safely without one, and a fallback default is public knowledge.",
      "Add SECRET_KEY as an environment reference, e.g. SECRET_KEY=${SECRET_KEY}, backed by a long random value stored outside the config file.");
  }
  if (!byKey["ALLOWED_HOSTS"]){
    add("MEDIUM", "ALLOWED_HOSTS", null,
      "ALLOWED_HOSTS is not set. Depending on the setup the app may refuse hosts or fall back to permissive behavior.",
      "Set ALLOWED_HOSTS to the exact hostnames the server answers for.");
  }

  /* EMAIL_USE_TLS off while an email password is present */
  var emailPwPresent = false;
  for (var k in EMAIL_PASSWORD_KEYS){ if (byKey[k] && byKey[k][0].value !== "") emailPwPresent = true; }
  if (emailPwPresent && byKey["EMAIL_USE_TLS"]){
    var tls = byKey["EMAIL_USE_TLS"][0];
    if (isFalsy(tls.value)){
      add("MEDIUM", "EMAIL_USE_TLS", tls.line,
        "EMAIL_USE_TLS is off while an email password is present in this config, so mail credentials can cross the network unencrypted.",
        "Set EMAIL_USE_TLS=True (and use the matching TLS mail port), or remove the stored email password.");
    }
  }

  /* Counts + verdict */
  var counts = { CRITICAL:0, HIGH:0, MEDIUM:0 };
  for (i = 0; i < findings.length; i++) counts[findings[i].severity]++;

  var verdict;
  if (recognizedCount < 3) verdict = "NOT ENOUGH TO GRADE";
  else if (counts.CRITICAL > 0 || counts.HIGH >= 2) verdict = "DO NOT DEPLOY";
  else if (counts.HIGH > 0 || counts.MEDIUM > 0) verdict = "DEPLOY WITH FIXES";
  else verdict = "SAFE TO DEPLOY";

  var sorted = findings.slice().sort(function(a, b2){
    if (SEV_ORDER[a.severity] !== SEV_ORDER[b2.severity]) return SEV_ORDER[a.severity] - SEV_ORDER[b2.severity];
    var la = (a.line == null ? 9999 : a.line), lb = (b2.line == null ? 9999 : b2.line);
    return la - lb;
  });

  return { verdict: verdict, findings: findings, sortedFindings: sorted, counts: counts,
    recognizedCount: recognizedCount, recognizedKeys: Object.keys(recognized).sort() };
}

function lineLabel(f){ return f.line == null ? "missing" : String(f.line); }

function buildReport(result){
  var out = [];
  out.push("J-Dawgs Wger Server Config Safety Auditor — Audit Report");
  out.push("Verdict: " + result.verdict);
  out.push("Recognized Wger/Django keys: " + result.recognizedCount + (result.recognizedKeys.length ? " (" + result.recognizedKeys.join(", ") + ")" : ""));
  out.push("Counts: CRITICAL " + result.counts.CRITICAL + " · HIGH " + result.counts.HIGH + " · MEDIUM " + result.counts.MEDIUM);
  out.push("Secrets are reported by key name, line, and length only. Secret values never appear in this report.");
  out.push("");
  out.push("Findings (" + result.findings.length + "):");
  if (!result.findings.length) out.push("None.");
  result.sortedFindings.forEach(function(f, idx){
    var s = (idx + 1) + ". [" + f.severity + "] " + f.key + " — line " + lineLabel(f) + " — " + f.issue;
    if (f.secretLength != null) s += " (Secret length: " + f.secretLength + ", " + f.secretLengthKind + ")";
    out.push(s);
    out.push("   Fix: " + f.fix);
  });
  out.push("");
  out.push("Fix list (priority order):");
  if (!result.sortedFindings.length) out.push("Nothing to fix.");
  result.sortedFindings.forEach(function(f, idx){
    out.push((idx + 1) + ". [" + f.severity + "] Line " + lineLabel(f) + " " + f.key + ": " + f.fix);
  });
  return out.join("\n");
}

function buildJSON(result){
  var obj = {
    tool: "J-Dawgs Wger Server Config Safety Auditor",
    verdict: result.verdict,
    recognizedKeyCount: result.recognizedCount,
    recognizedKeys: result.recognizedKeys,
    counts: result.counts,
    note: "Secrets are reported by key name, line, and length only. Secret values are never included.",
    findings: result.sortedFindings.map(function(f){
      return { severity: f.severity, key: f.key, line: f.line, issue: f.issue, fix: f.fix,
        secretLength: f.secretLength, secretLengthKind: f.secretLengthKind };
    }),
    fixList: result.sortedFindings.map(function(f, idx){
      return { priority: idx + 1, severity: f.severity, key: f.key, line: f.line, fix: f.fix };
    })
  };
  return JSON.stringify(obj, null, 2);
}
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-wger-server-config-safety-auditortm',
  name: 'J-Dawgs Wger Server Config Safety Auditor',
  description: '',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
