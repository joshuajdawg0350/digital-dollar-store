'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Well Pump Installation Proposal, Work Record & Final Invoice Consistency Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Examples (single source of truth) ---------- */
      var BAD = {
        proposal: [
          "Submersible pump 1 HP (Model SP-100) | 1 | 850.00",
          "Pressure tank 44 gal | 1 | 320.00",
          "PVC pipe 1 in | 40 | 2.50",
          "Check valve | 1 | 45.00",
          "Labor | 5 | 90.00",
          "Deposit | 400.00"
        ].join("\n"),
        work: [
          "Submersible pump 1 HP (Model SP-100) | 1 | 850.00",
          "Pressure tank 44 gal | 1 | 320.00",
          "PVC pipe 1 in | 40 | 2.50",
          "Check valve | 1 | 45.00",
          "Labor | 5 | 90.00",
          "Deposit | 400.00"
        ].join("\n"),
        invoice: [
          "Submersible pump 1.5 HP (Model SP-150) | 1 | 1050.00",
          "Pressure tank 44 gal | 1 | 320.00",
          "PVC pipe 1 in | 60 | 2.50",
          "Check valve | 1 | 45.00",
          "Check valve | 1 | 45.00",
          "Labor | 7 | 90.00",
          "Fee: disposal | 1 | 75.00"
        ].join("\n")
      };
      var GOOD = {
        proposal: [
          "Submersible pump 1 HP (Model SP-100) | 1 | 850.00",
          "Pressure tank 44 gal | 1 | 320.00",
          "PVC pipe 1 in | 40 | 2.50",
          "Check valve | 1 | 45.00",
          "Labor | 6 | 95.00",
          "Deposit | 500.00"
        ].join("\n"),
        work: [
          "Submersible pump 1 HP (Model SP-100) | 1 | 850.00",
          "Pressure tank 44 gal | 1 | 320.00",
          "PVC pipe 1 in | 40 | 2.50",
          "Check valve | 1 | 45.00",
          "Labor | 6 | 95.00",
          "Deposit | 500.00"
        ].join("\n"),
        invoice: [
          "Submersible pump 1 HP (Model SP-100) | 1 | 850.00",
          "Pressure tank 44 gal | 1 | 320.00",
          "PVC pipe 1 in | 40 | 2.50",
          "Check valve | 1 | 45.00",
          "Labor | 6 | 95.00",
          "Deposit credit | 1 | -500.00"
        ].join("\n")
      };

      /* ---------- Formatting helpers ---------- */
      function fmtMoney(cents){
        var neg = cents < 0; var v = Math.abs(cents) / 100;
        var s = v.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        return (neg ? "-$" : "$") + s;
      }
      function fmtQty(q){
        if (Math.abs(q - Math.round(q)) < 1e-9) return String(Math.round(q));
        return String(Math.round(q * 100) / 100);
      }
      function fmtHP(h){
        if (h === null || h === undefined) return "?";
        return (Math.abs(h - Math.round(h)) < 1e-9) ? String(Math.round(h)) : String(h);
      }

      /* ---------- Parsing ---------- */
      function parseMoney(s){
        if (s === null || s === undefined) return null;
        var t = String(s).replace(/[$,]/g, "").trim();
        if (t === "") return null;
        var neg = false;
        if (/^\(.*\)$/.test(t)){ neg = true; t = t.slice(1, -1); }
        var v = parseFloat(t);
        if (isNaN(v)) return null;
        return Math.round((neg ? -v : v) * 100);
      }
      function parseNum(s){
        var t = String(s).replace(/[$,]/g, "").trim();
        var v = parseFloat(t);
        return isNaN(v) ? null : v;
      }
      function normName(name){
        return String(name).toLowerCase().replace(/\s+/g, " ").trim();
      }
      function categoryOf(name){
        var n = normName(name);
        if (n.indexOf("deposit") !== -1) return "deposit";
        if (/(^|\s)labor(\s|$)/.test(n) || /(^|\s)labour(\s|$)/.test(n)) return "labor";
        if (n.indexOf("tax") !== -1) return "tax";
        if (/^fee(\s|:|$)/.test(n) || /\sfee$/.test(n)) return "fee";
        if (n.indexOf("pump") !== -1) return "pump";
        return "item";
      }
      function feeKey(entry){
        return entry.key.replace(/^fee[:\s-]*/, "").replace(/[:\s-]*fee$/, "").trim();
      }
      function extractHP(name){
        var m = String(name).match(/(\d+)\s*\/\s*(\d+)\s*hp/i);
        if (m) return parseInt(m[1], 10) / parseInt(m[2], 10);
        m = String(name).match(/(\d+(?:\.\d+)?)\s*hp/i);
        if (m) return parseFloat(m[1]);
        return null;
      }
      function parseDoc(text, docLabel){
        var entries = [], warnings = [];
        var rawLines = String(text || "").split(/\r?\n/);
        rawLines.forEach(function(raw, idx){
          var line = raw.trim();
          if (!line || line.charAt(0) === "#") return;
          var parts = line.split("|").map(function(p){ return p.trim(); });
          var key = normName(parts[0] || "");
          if (!key) return;
          if (key === "total" || key === "subtotal" || key === "balance due" || key === "amount due" || key === "total due") return;
          var cat = categoryOf(parts[0]);
          if (parts.length === 2){
            var amt = parseMoney(parts[1]);
            if (amt === null){ warnings.push({ doc: docLabel, line: idx + 1, text: line }); return; }
            entries.push({ name: parts[0], key: key, cat: cat, qty: 1, unit: amt, ext: amt, lineNo: idx + 1 });
            return;
          }
          if (parts.length >= 3){
            var qty = parseNum(parts[1]);
            var unit = parseMoney(parts[2]);
            if (qty === null || unit === null){ warnings.push({ doc: docLabel, line: idx + 1, text: line }); return; }
            entries.push({ name: parts[0], key: key, cat: cat, qty: qty, unit: unit, ext: Math.round(qty * unit), lineNo: idx + 1 });
            return;
          }
          warnings.push({ doc: docLabel, line: idx + 1, text: line });
        });
        return {
          label: docLabel,
          entries: entries,
          warnings: warnings,
          hasText: String(text || "").trim().length > 0,
          present: entries.length > 0,
          total: entries.reduce(function(a, e){ return a + e.ext; }, 0)
        };
      }
      function byCat(entries, cat){ return entries.filter(function(e){ return e.cat === cat; }); }
      function sumQty(list){ return list.reduce(function(a, e){ return a + e.qty; }, 0); }
      function sumExt(list){ return list.reduce(function(a, e){ return a + e.ext; }, 0); }

      /* ---------- The cross-check ---------- */
      function audit(pText, wText, iText){
        var P = parseDoc(pText, "Proposal");
        var W = parseDoc(wText, "Work Record");
        var I = parseDoc(iText, "Final Invoice");
        var docs = [P, W, I];
        var presentCount = docs.filter(function(d){ return d.present; }).length;
        var missing = docs.filter(function(d){ return !d.present; }).map(function(d){ return d.label; });
        var findings = [];
        function block(type, title, math, amount){
          findings.push({ severity: "block", type: type, title: title, math: math, amount: amount });
        }
        function warn(type, title, math){
          findings.push({ severity: "warn", type: type, title: title, math: math, amount: 0 });
        }

        docs.forEach(function(d){
          d.warnings.forEach(function(w){
            warn("unparsed", "Line not recognized in the " + d.label + " (line " + w.line + ")",
              "\"" + w.text + "\" — expected the form: name | quantity | unit price. The line was skipped; the verdict is based on the lines that did parse.");
          });
          if (d.hasText && !d.present){
            warn("empty-doc", "The " + d.label + " has text but no recognizable lines",
              "Nothing in the " + d.label + " box matched the line format, so it is treated as missing.");
          }
        });

        if (presentCount >= 2){

          /* Duplicate lines on the invoice: flag repeats, keep the first
             occurrence for the other checks so nothing is double-counted. */
          var seen = {}, effInv = [];
          I.entries.forEach(function(e){
            if (e.cat === "deposit" || e.cat === "tax"){ effInv.push(e); return; }
            var k = e.cat + "::" + e.key;
            if (seen[k]){
              block("duplicate", "Duplicate line on the invoice: \"" + e.name + "\"",
                "The invoice lists \"" + e.name + "\" more than once. Repeat line: " + fmtQty(e.qty) + " × " + fmtMoney(e.unit) + " = " + fmtMoney(e.ext) + ", counted as overcharge. The first occurrence is the one used in the other checks, so this amount is not double-counted.", e.ext);
            } else { seen[k] = true; effInv.push(e); }
          });

          /* Quantities billed above the work record (regular items). */
          if (W.present && I.present){
            var recItems = {};
            byCat(W.entries, "item").forEach(function(e){ recItems[e.key] = (recItems[e.key] || 0) + e.qty; });
            var invItems = {};
            byCat(effInv, "item").forEach(function(e){
              if (!invItems[e.key]) invItems[e.key] = { qty: 0, ext: 0, name: e.name };
              invItems[e.key].qty += e.qty; invItems[e.key].ext += e.ext;
            });
            Object.keys(invItems).forEach(function(k){
              var iv = invItems[k];
              if (!(k in recItems)){
                block("not-recorded", "Billed but not in the work record: \"" + iv.name + "\"",
                  "Invoice: " + fmtQty(iv.qty) + " × " + fmtMoney(Math.round(iv.ext / iv.qty)) + " = " + fmtMoney(iv.ext) + ". Work record shows 0 installed, so the full line is counted as overcharge.", iv.ext);
              } else if (iv.qty > recItems[k] + 1e-9){
                var unit = iv.ext / iv.qty;
                var excess = iv.qty - recItems[k];
                var amt = Math.round(excess * unit);
                block("quantity", "Quantity billed above the work record: \"" + iv.name + "\"",
                  "Billed " + fmtQty(iv.qty) + " − recorded " + fmtQty(recItems[k]) + " = " + fmtQty(excess) + " extra × " + fmtMoney(Math.round(unit)) + " = " + fmtMoney(amt) + ".", amt);
              }
            });
          }

          /* Pump model / horsepower tier billed vs. recorded (or proposed). */
          if (I.present){
            var invPumps = byCat(effInv, "pump");
            var recPumps = W.present ? byCat(W.entries, "pump") : null;
            var propPumps = P.present ? byCat(P.entries, "pump") : null;
            invPumps.forEach(function(ip, idx){
              var base = null, baseLabel = "";
              if (recPumps && recPumps[idx]){ base = recPumps[idx]; baseLabel = "work record"; }
              else if (!W.present && propPumps && propPumps[idx]){ base = propPumps[idx]; baseLabel = "proposal"; }
              if (!base){
                if (W.present){
                  block("not-recorded", "Pump billed but not in the work record: \"" + ip.name + "\"",
                    "Invoice: " + fmtQty(ip.qty) + " × " + fmtMoney(ip.unit) + " = " + fmtMoney(ip.ext) + ". No pump line in the work record matches it, so the full line is counted as overcharge.", ip.ext);
                }
                return;
              }
              var amt = 0, notes = [];
              if (ip.qty > base.qty + 1e-9){
                var qAmt = Math.round((ip.qty - base.qty) * ip.unit);
                amt += qAmt;
                notes.push("quantity: billed " + fmtQty(ip.qty) + " − " + baseLabel + " " + fmtQty(base.qty) + " = " + fmtQty(ip.qty - base.qty) + " × " + fmtMoney(ip.unit) + " = " + fmtMoney(qAmt));
              }
              var pd = ip.unit - base.unit;
              if (pd > 0){
                var tierQty = Math.min(ip.qty, base.qty);
                var tAmt = Math.round(pd * tierQty);
                amt += tAmt;
                notes.push("unit price: billed " + fmtMoney(ip.unit) + " − " + baseLabel + " " + fmtMoney(base.unit) + " = " + fmtMoney(pd) + " × " + fmtQty(tierQty) + " = " + fmtMoney(tAmt));
              }
              var ihp = extractHP(ip.name), bhp = extractHP(base.name);
              var hpNote = (ihp !== null && bhp !== null) ? "Horsepower billed: " + fmtHP(ihp) + " HP; " + baseLabel + ": " + fmtHP(bhp) + " HP. " : "";
              if (amt > 0){
                block("pump-tier", "Pump billed above the pump in the " + baseLabel + ": \"" + ip.name + "\" vs \"" + base.name + "\"",
                  hpNote + notes.join(" "), amt);
              } else if (ihp !== null && bhp !== null && Math.abs(ihp - bhp) > 1e-9){
                warn("pump-model", "Pump horsepower differs from the " + baseLabel + " at the same price",
                  "Billed " + fmtHP(ihp) + " HP (\"" + ip.name + "\") vs " + baseLabel + " " + fmtHP(bhp) + " HP (\"" + base.name + "\"), same unit price " + fmtMoney(ip.unit) + ". No dollar amount counted — confirm the installed pump is the one on the paperwork.");
              } else if (normName(ip.name) !== normName(base.name)){
                warn("pump-model", "Pump name differs from the " + baseLabel + " at the same price",
                  "Billed \"" + ip.name + "\" vs " + baseLabel + " \"" + base.name + "\", same unit price " + fmtMoney(ip.unit) + ". No dollar amount counted — confirm the model numbers match the installed unit.");
              }
            });
          }

          /* Labor: hours above the work record; rate above the proposal. */
          if (I.present){
            var invLab = byCat(effInv, "labor");
            if (invLab.length){
              var iH = sumQty(invLab), iExt = sumExt(invLab);
              var iRate = iH > 0 ? iExt / iH : 0;
              var recLab = W.present ? byCat(W.entries, "labor") : [];
              var wH = recLab.length ? sumQty(recLab) : null;
              if (W.present && recLab.length && iH > wH + 1e-9){
                var lAmt = Math.round((iH - wH) * iRate);
                block("labor-hours", "Labor hours billed above the work record",
                  "Billed " + fmtQty(iH) + " hrs − recorded " + fmtQty(wH) + " hrs = " + fmtQty(iH - wH) + " hrs × " + fmtMoney(Math.round(iRate)) + "/hr = " + fmtMoney(lAmt) + ".", lAmt);
              }
              var propLab = P.present ? byCat(P.entries, "labor") : [];
              if (P.present && propLab.length){
                var pH = sumQty(propLab);
                var pRate = pH > 0 ? sumExt(propLab) / pH : 0;
                if (iRate > pRate + 0.5){
                  var baseH = (wH !== null) ? wH : iH;
                  var rAmt = Math.round(baseH * (iRate - pRate));
                  block("labor-rate", "Labor rate billed above the proposal rate",
                    "Billed rate " + fmtMoney(Math.round(iRate)) + "/hr − proposal rate " + fmtMoney(Math.round(pRate)) + "/hr = " + fmtMoney(Math.round(iRate - pRate)) + "/hr × " + fmtQty(baseH) + " hrs = " + fmtMoney(rAmt) + ".", rAmt);
                }
              }
            }
          }

          /* Invoice-only fees: on the invoice, never in the proposal. */
          if (I.present && P.present){
            var propFees = {};
            byCat(P.entries, "fee").forEach(function(e){ propFees[feeKey(e)] = true; });
            byCat(effInv, "fee").forEach(function(f){
              if (!propFees[feeKey(f)]){
                block("invoice-only-fee", "Fee on the invoice that is not in the proposal: \"" + f.name + "\"",
                  f.name + ": " + fmtQty(f.qty) + " × " + fmtMoney(f.unit) + " = " + fmtMoney(f.ext) + ". No matching fee appears in the proposal, so the full fee is counted as overcharge.", f.ext);
              }
            });
          }

          /* Deposit paid but not credited. */
          if (I.present && (P.present || W.present)){
            var paidSrc = P.present ? P : W;
            var paid = byCat(paidSrc.entries, "deposit").reduce(function(a, e){ return a + Math.max(0, e.ext); }, 0);
            var credited = 0;
            byCat(I.entries, "deposit").forEach(function(e){
              if (e.ext < 0) credited += -e.ext;
              else if (/credit/i.test(e.name)) credited += e.ext;
            });
            if (paid > 0 && credited < paid){
              var dAmt = paid - credited;
              block("deposit", "Deposit paid but not credited on the invoice",
                "Deposit shown in the " + (P.present ? "proposal" : "work record") + ": " + fmtMoney(paid) + " − credit on the invoice: " + fmtMoney(credited) + " = " + fmtMoney(dAmt) + " of your deposit never came back off the bill.", dAmt);
            }
          }
        }

        var overcharge = findings.filter(function(f){ return f.severity === "block"; })
                                  .reduce(function(a, f){ return a + f.amount; }, 0);
        var verdict, verdictNote;
        if (presentCount <= 1){
          verdict = "NOT ENOUGH TO COMPARE";
          verdictNote = presentCount === 0
            ? "No documents were pasted. Paste at least two of the three documents — the proposal, the work record, and the final invoice — to run a cross-check."
            : "Only one document was found (" + docs.filter(function(d){ return d.present; })[0].label + "). A cross-check needs at least two documents to compare; all three give the full verdict. Missing: " + missing.join(", ") + ".";
        } else if (overcharge > 0){
          verdict = "DO NOT PAY YET";
          verdictNote = "The documents disagree by " + fmtMoney(overcharge) + " in the contractor's favor. Get the invoice corrected to match the work record and the proposal before paying." +
            (presentCount === 2 ? " Also missing: " + missing.join(", ") + " — paste it for the complete check." : "");
        } else if (presentCount === 2){
          verdict = "PAY WITH FIXES";
          verdictNote = "The two documents pasted agree with each other, but the verdict caps at PAY WITH FIXES until the missing document is checked too. Missing: " + missing.join(", ") + ".";
        } else if (findings.some(function(f){ return f.severity === "warn"; })){
          verdict = "PAY WITH FIXES";
          verdictNote = "No dollar overcharge was found, but the warnings below need a look before you pay.";
        } else {
          verdict = "SAFE TO PAY";
          verdictNote = "All three documents agree: quantities, pump, labor, fees, and the deposit credit all match across the proposal, the work record, and the final invoice. Computed overcharge: $0.00.";
        }

        return {
          verdict: verdict,
          verdictNote: verdictNote,
          presentCount: presentCount,
          missing: missing,
          findings: findings,
          overcharge: overcharge,
          totals: { proposal: P.total, work: W.total, invoice: I.total },
          present: { proposal: P.present, work: W.present, invoice: I.present }
        };
      }

      /* ---------- Report builders ---------- */
      function buildReport(r){
        var lines = [];
        lines.push("J-Dawgs Well Pump Installation Proposal, Work Record & Final Invoice Consistency Auditor");
        lines.push("Cross-check report — arithmetic and consistency of the pasted documents only.");
        lines.push("");
        lines.push("VERDICT: " + r.verdict);
        lines.push(r.verdictNote);
        lines.push("");
        lines.push("Documents found: " + r.presentCount + " of 3" + (r.missing.length ? " (missing: " + r.missing.join(", ") + ")" : ""));
        lines.push("Computed overcharge: " + fmtMoney(r.overcharge));
        lines.push("Line totals as pasted — Proposal: " + fmtMoney(r.totals.proposal) + " · Work Record: " + fmtMoney(r.totals.work) + " · Final Invoice: " + fmtMoney(r.totals.invoice));
        lines.push("");
        if (!r.findings.length){
          lines.push("Findings: none. Every line checked agrees across the documents pasted.");
        } else {
          lines.push("Findings (" + r.findings.length + "):");
          r.findings.forEach(function(f, i){
            lines.push("");
            lines.push((i + 1) + ". [" + (f.severity === "block" ? "OVERCHARGE " + fmtMoney(f.amount) : "WARNING") + "] " + f.title);
            lines.push("   " + f.math);
          });
        }
        lines.push("");
        lines.push("Scope: this report checks only the arithmetic and consistency of the documents pasted into the tool. It does not judge whether any price is a fair market price and does not contact any contractor.");
        return lines.join("\n");
      }
      function buildJSON(r){
        return JSON.stringify({
          tool: "J-Dawgs Well Pump Installation Proposal, Work Record & Final Invoice Consistency Auditor",
          verdict: r.verdict,
          verdict_note: r.verdictNote,
          documents_found: r.presentCount,
          missing_documents: r.missing,
          computed_overcharge: fmtMoney(r.overcharge),
          computed_overcharge_cents: r.overcharge,
          line_totals_as_pasted: {
            proposal: fmtMoney(r.totals.proposal),
            work_record: fmtMoney(r.totals.work),
            final_invoice: fmtMoney(r.totals.invoice)
          },
          findings: r.findings.map(function(f){
            return {
              severity: f.severity, type: f.type, title: f.title, arithmetic: f.math,
              overcharge: fmtMoney(f.amount), overcharge_cents: f.amount
            };
          }),
          scope: "Arithmetic and consistency cross-check of the pasted documents only. Does not judge fair market prices; does not contact any contractor."
        }, null, 2);
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-well-pump-installation-proposal-work-record-final-invoice-consistency-auditor',
  name: 'J-Dawgs Well Pump Installation Proposal, Work Record & Final Invoice Consistency Auditor',
  description: 'Cross-checks a well pump installation proposal against the work record and final invoice — quantities, pump tier, labor, duplicates, invoice-only fees, and an uncredited deposit, with arithmetic shown — into one pay verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
