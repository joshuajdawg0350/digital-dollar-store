'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Hazelcast Cluster Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

var RISKY = [
"hazelcast:",
"  cluster-name: prod-payments-cluster",
"  network:",
"    port: 5701",
"    join:",
"      multicast:",
"        enabled: true",
"      tcp-ip:",
"        enabled: true",
"        members: 10.0.0.11, 10.0.0.12",
"  security:",
"    enabled: false",
"  rest-api:",
"    enabled: true",
"  management-center:",
"    enabled: true",
"    url: http://mancenter.example.internal:8080/hazelcast-mancenter",
"  interfaces:",
"    interface: 0.0.0.0",
"  ssl:",
"    enabled: false",
"  cluster-admin-password: Tr0picThunder-Cluster-Admin-7429",
"  # tls:",
"  #   enabled: true",
"  cluster-name: duplicate-cluster-name",
"  garbage line with no key value structure %%$$"
].join("\n");

var HARDENED = [
"hazelcast:",
"  cluster-name: prod-payments-cluster",
"  network:",
"    port: 5701",
"    join:",
"      multicast:",
"        enabled: false",
"      tcp-ip:",
"        enabled: true",
"        members: 10.0.0.11, 10.0.0.12",
"  security:",
"    enabled: true",
"  rest-api:",
"    enabled: false",
"  management-center:",
"    enabled: true",
"    url: https://mancenter.example.internal:8443/hazelcast-mancenter",
"  interfaces:",
"    interface: 10.0.0.11",
"  ssl:",
"    enabled: true",
"  tls:",
"    enabled: true"
].join("\n");

var RELEVANT = ["hazelcast","multicast","tcp-ip","tcpip","join","security","rest","mancenter",
"management-center","managementcenter","ssl","tls","cluster","network","port","interface",
"member","password","secret","token","cp-subsystem","wan-replication","advanced-network"];

var SECRET_TOKENS = ["password","passwd","secret","token","api-key","apikey","credential",
"license-key","private-key","access-key"];

function normKey(k){ return k.toLowerCase().replace(/_/g,"-").replace(/["']/g,"").trim(); }
function lastSeg(eff){ var p = eff.split("."); return p[p.length-1]; }
function valBool(v){
  if(v === null || v === undefined) return null;
  var s = String(v).toLowerCase().replace(/["']/g,"").trim();
  if(s==="true"||s==="yes"||s==="on"||s==="enabled"||s==="1") return true;
  if(s==="false"||s==="no"||s==="off"||s==="disabled"||s==="0") return false;
  return null;
}
function isPlaceholder(v){
  var s = String(v).trim();
  return s.indexOf("${")===0 || s.indexOf("ENC(")===0 || s.indexOf("***")===0 ||
         s.indexOf("<")===0 || s==="null" || s==="~" || s==="" ||
         s.toLowerCase()==="changeme" || s.toLowerCase()==="redacted";
}
function lineIsRelevant(s){
  var low = s.toLowerCase();
  for(var i=0;i<RELEVANT.length;i++){ if(low.indexOf(RELEVANT[i])!==-1) return true; }
  return false;
}

function parse(text){
  var rawLines = text.split(/\r?\n/);
  var entries = [];      // {line, key, effKey, value}
  var commented = [];    // {line, keyGuess}
  var notParsed = [];    // {line}
  var stack = [];        // {indent, key}
  function pathKeys(){ var a=[]; for(var i=0;i<stack.length;i++) a.push(stack[i].key); return a; }
  function popTo(indent){ while(stack.length && stack[stack.length-1].indent >= indent) stack.pop(); }

  for(var idx=0; idx<rawLines.length; idx++){
    var lineNo = idx+1;
    var raw = rawLines[idx];
    var trimmed = raw.replace(/\s+$/,"").trim();
    if(!trimmed) continue;

    // Commented lines: YAML '#', XML '<!--', or '//'
    if(trimmed.charAt(0)==="#" || trimmed.indexOf("<!--")===0 || trimmed.indexOf("//")===0){
      var cbody = trimmed.replace(/^#+\s?/,"").replace(/^<!--\s?/,"").replace(/-->$/,"").trim();
      var cm = cbody.match(/^([A-Za-z0-9_.\-]+)\s*[:=]/);
      commented.push({line:lineNo, key: cm ? normKey(cm[1]) : (lineIsRelevant(cbody) ? cbody.split(/\s+/)[0].toLowerCase() : null), relevant: lineIsRelevant(cbody) || !!cm});
      continue;
    }

    var indent = raw.length - raw.replace(/^\s+/,"").length;
    if(raw.indexOf("\t")===0) indent = raw.match(/^\t*/)[0].length * 2;

    // XML structural open/close tags on their own line
    var xmlStruct = trimmed.match(/^<(\/?)([A-Za-z0-9_\-]+)([^>]*)>$/);
    if(xmlStruct && trimmed.indexOf("</")!==0 && trimmed.match(/<\/[A-Za-z0-9_\-]+>/)){
      // single-line element with content: <tag>value</tag>
      var xm = trimmed.match(/^<([A-Za-z0-9_\-]+)([^>]*)>([^<]*)<\/\1>$/);
      if(xm){
        popTo(indent);
        var xkey = normKey(xm[1]);
        var xval = xm[3].trim();
        var attrs = xm[2] || "";
        var enAttr = attrs.match(/enabled\s*=\s*["'](true|false)["']/i);
        var eff = pathKeys().concat([xkey]).join(".");
        entries.push({line:lineNo, key:xkey, effKey:eff, value: xval !== "" ? xval : (enAttr ? enAttr[1] : "")});
        if(enAttr) entries.push({line:lineNo, key:"enabled", effKey:eff+".enabled", value:enAttr[1]});
        continue;
      }
    }
    if(xmlStruct){
      var tag = normKey(xmlStruct[2]);
      if(xmlStruct[1]==="/"){
        // closing tag: pop matching
        for(var s=stack.length-1;s>=0;s--){ if(stack[s].key===tag){ stack.length = s; break; } }
      } else if(!/\/>$/.test(trimmed)){
        popTo(indent);
        stack.push({indent:indent, key:tag});
        var aEn = (xmlStruct[3]||"").match(/enabled\s*=\s*["'](true|false)["']/i);
        if(aEn) entries.push({line:lineNo, key:"enabled", effKey:pathKeys().join(".")+".enabled", value:aEn[1]});
      } else {
        popTo(indent);
        var sEn = (xmlStruct[3]||"").match(/enabled\s*=\s*["'](true|false)["']/i);
        var sEff = pathKeys().concat([tag]).join(".");
        entries.push({line:lineNo, key:tag, effKey:sEff, value:""});
        if(sEn) entries.push({line:lineNo, key:"enabled", effKey:sEff+".enabled", value:sEn[1]});
      }
      continue;
    }
    if(trimmed==="<hazelcast>" || trimmed==="</hazelcast>"){ continue; }

    // List item: "- value"
    if(trimmed.indexOf("- ")===0 || trimmed==="-"){
      var itemVal = trimmed.replace(/^-\s?/,"").trim();
      popTo(indent);
      var parentKey = stack.length ? stack[stack.length-1].key : "list";
      entries.push({line:lineNo, key:parentKey+"-item", effKey:pathKeys().join(".")+".item", value:itemVal, listItem:true});
      continue;
    }

    // YAML / property key line
    var km = trimmed.match(/^([A-Za-z0-9_.\-"]+)\s*[:=]\s*(.*)$/);
    if(km){
      var key = normKey(km[1]);
      var value = km[2].trim();
      popTo(indent);
      var effKey = pathKeys().concat([key]).join(".");
      entries.push({line:lineNo, key:key, effKey:effKey, value:value});
      if(value===""){
        stack.push({indent:indent, key:key});
      }
      continue;
    }

    // Braces / lone structural tokens
    if(trimmed==="{" || trimmed==="}" || trimmed==="---"){ continue; }

    notParsed.push({line:lineNo});
  }
  return {entries:entries, commented:commented, notParsed:notParsed, lineCount:rawLines.length};
}

function audit(text){
  var findings = [];
  function add(severity, check, line, lines, message){
    var f = {severity:severity, check:check, message:message};
    if(lines){ f.lines = lines; } else { f.line = line; }
    findings.push(f);
  }

  if(!text || !text.trim()){
    return {verdict:"NOT ENOUGH TO GRADE", findings:[], counts:{}, reason:"The paste is empty. Paste a Hazelcast configuration and run the audit again."};
  }

  var parsed = parse(text);
  var entries = parsed.entries;

  var relevantEntries = entries.filter(function(e){ return lineIsRelevant(e.effKey) || lineIsRelevant(e.key); });
  if(relevantEntries.length < 2){
    return {verdict:"NOT ENOUGH TO GRADE", findings:[], counts:{}, reason:"This does not look like a Hazelcast configuration — fewer than two recognizable Hazelcast keys were found. Paste hazelcast.yaml / hazelcast.xml style key lines and run the audit again."};
  }

  function findEntry(pred){ for(var i=0;i<entries.length;i++){ if(pred(entries[i])) return entries[i]; } return null; }
  function findEntries(pred){ return entries.filter(pred); }

  // Global posture facts
  var secEnabledEntry = findEntry(function(e){ return e.effKey.indexOf("security")!==-1 && lastSeg(e.effKey)==="enabled"; });
  var securityOn = secEnabledEntry ? valBool(secEnabledEntry.value)===true : false;
  var portEntry = findEntry(function(e){ return lastSeg(e.effKey)==="port" && e.value!==""; });
  var networkPresent = !!findEntry(function(e){ return e.effKey.indexOf("network")!==-1 || e.effKey.indexOf("join")!==-1; });
  var portsExposed = !!(portEntry || networkPresent);
  var tlsOnEntry = findEntry(function(e){ return (e.effKey.indexOf("ssl")!==-1 || e.effKey.indexOf("tls")!==-1) && lastSeg(e.effKey)==="enabled" && valBool(e.value)===true; });
  var tlsOffEntry = findEntry(function(e){ return (e.effKey.indexOf("ssl")!==-1 || e.effKey.indexOf("tls")!==-1) && lastSeg(e.effKey)==="enabled" && valBool(e.value)===false; });
  var tlsOn = !!tlsOnEntry;

  // 1. Multicast join enabled
  var mc = findEntry(function(e){ return e.effKey.indexOf("multicast")!==-1 && lastSeg(e.effKey)==="enabled" && valBool(e.value)===true; });
  if(!mc) mc = findEntry(function(e){ return e.key==="multicast" && valBool(e.value)===true; });
  if(mc){
    add("HIGH","multicast-join", mc.line, null,
      "Multicast join is enabled (line " + mc.line + "). Multicast discovery is unauthenticated — any host that can reach the multicast group can find and attempt to join this cluster. Disable multicast and use an explicit TCP/IP member list or a vetted discovery mechanism.");
  }

  // 2. TCP/IP join with no member authentication / security
  var tcpSection = findEntry(function(e){ return e.key==="tcp-ip" || e.key==="tcpip"; });
  var tcpEnabledEntry = findEntry(function(e){ return e.effKey.indexOf("tcp-ip")!==-1 && lastSeg(e.effKey)==="enabled"; });
  var tcpOn = tcpSection && (tcpEnabledEntry ? valBool(tcpEnabledEntry.value)!==false : true);
  if(tcpSection && tcpOn && !securityOn){
    add("HIGH","tcpip-no-auth", tcpSection.line, null,
      "TCP/IP join is enabled (line " + tcpSection.line + ") but member authentication / security is not enabled. Any host that can reach the cluster port can present itself as a member. Enable Hazelcast security with member authentication, or restrict the port to a private network segment.");
  }

  // 3. Security disabled or absent while ports are exposed
  if(secEnabledEntry && valBool(secEnabledEntry.value)===false){
    add("BLOCKER","security-disabled", secEnabledEntry.line, null,
      "security.enabled is false (line " + secEnabledEntry.line + ") while the cluster network is configured. The cluster runs with no member authentication and no authorization. Set security.enabled to true and configure member authentication before deploying.");
  } else if(!secEnabledEntry && portsExposed){
    var atLine = portEntry ? portEntry.line : (networkPresent ? findEntry(function(e){ return e.effKey.indexOf("network")!==-1; }).line : 1);
    add("HIGH","security-absent", atLine, null,
      "No security.enabled setting was found, while network ports are exposed (line " + atLine + "). An absent security section means the cluster defaults to no member authentication. Add an explicit security section with enabled: true and member authentication.");
  }

  // 4. REST API enabled
  var restEnabled = findEntry(function(e){ return e.effKey.indexOf("rest")!==-1 && lastSeg(e.effKey)==="enabled" && valBool(e.value)===true; });
  if(!restEnabled) restEnabled = findEntry(function(e){ return (e.key==="hazelcast.rest.enabled" || e.key==="rest.enabled") && valBool(e.value)===true; });
  if(restEnabled){
    add("HIGH","rest-api-enabled", restEnabled.line, null,
      "The Hazelcast REST API is enabled (line " + restEnabled.line + "). The REST API exposes cluster state and data operations over HTTP. Disable it unless it is required, and if it is required, put it behind authentication, TLS, and network restrictions.");
  }

  // 5. Management Center enabled with no TLS
  var mcSection = findEntry(function(e){ return e.key==="management-center" || e.key==="mancenter" || e.key==="managementcenter"; });
  var mcEnabled = findEntry(function(e){ return (e.effKey.indexOf("management-center")!==-1 || e.effKey.indexOf("mancenter")!==-1) && lastSeg(e.effKey)==="enabled" && valBool(e.value)===true; });
  var mcUrl = findEntry(function(e){ return (e.effKey.indexOf("management-center")!==-1 || e.effKey.indexOf("mancenter")!==-1) && lastSeg(e.effKey)==="url"; });
  if(mcSection && (mcEnabled || mcUrl)){
    var urlVal = mcUrl ? String(mcUrl.value).toLowerCase() : "";
    var urlIsHttp = urlVal.indexOf("http://")===0;
    if(urlIsHttp || (!mcUrl && !tlsOn)){
      add("WARNING","mancenter-no-tls", mcUrl ? mcUrl.line : mcSection.line, null,
        "Management Center is enabled without TLS (line " + (mcUrl ? mcUrl.line : mcSection.line) + "). The console URL is plain HTTP or no TLS is configured, so console traffic and credentials cross the network unencrypted. Serve Management Center over HTTPS.");
    }
  }

  // 6. Plaintext secrets — key name + line + length ONLY
  entries.forEach(function(e){
    if(e.listItem) return;
    var keyLow = e.key.toLowerCase();
    var isSecret = false;
    for(var i=0;i<SECRET_TOKENS.length;i++){ if(keyLow.indexOf(SECRET_TOKENS[i])!==-1){ isSecret = true; break; } }
    if(!isSecret) return;
    var v = String(e.value || "").replace(/^["']|["']$/g,"");
    if(!v || isPlaceholder(v)) return;
    add("HIGH","plaintext-secret", e.line, null,
      "Plaintext secret in key \"" + e.key + "\" (line " + e.line + ", value length " + v.length + " characters). The value is never shown in this report. Move it to a secret manager or environment reference and rotate it — it has been sitting in a config file.");
  });

  // 7. TLS/SSL disabled or absent on an exposed cluster
  if(tlsOffEntry){
    add("WARNING","tls-disabled", tlsOffEntry.line, null,
      "TLS/SSL is explicitly disabled (line " + tlsOffEntry.line + ") on a cluster with network ports configured. Member-to-member and client traffic is unencrypted. Enable SSL/TLS with a proper keystore before deploying.");
  } else if(!tlsOn && portsExposed){
    var pLine = portEntry ? portEntry.line : 1;
    add("WARNING","tls-absent", pLine, null,
      "No enabled TLS/SSL setting was found while network ports are exposed (line " + pLine + "). Cluster traffic is unencrypted by default. Configure SSL/TLS for member and client connections.");
  }

  // 8. Wildcard / public interface binding
  entries.forEach(function(e){
    var v = String(e.value || "").trim();
    if(v==="0.0.0.0" || v==="*" || v==="0.0.0.0/0" || v==="::"){
      add("HIGH","wildcard-binding", e.line, null,
        "Wildcard interface binding (line " + e.line + "): the cluster binds on every network interface, including any public one. Bind to the specific private interface addresses the cluster actually uses.");
    }
  });

  // 9. Duplicate keys
  var seen = {};
  entries.forEach(function(e){
    if(e.listItem || e.value==="") return;
    if(!seen[e.effKey]) seen[e.effKey] = [];
    seen[e.effKey].push(e.line);
  });
  Object.keys(seen).forEach(function(k){
    if(seen[k].length > 1){
      add("WARNING","duplicate-key", null, seen[k].slice(),
        "Duplicate key \"" + k + "\" appears on lines " + seen[k].join(" and ") + ". Which value wins depends on the parser, so the running config may not be the one you reviewed. Keep one definition.");
    }
  });

  // 10. CP Subsystem / WAN replication — only graded when present
  var cpPresent = findEntry(function(e){ return e.effKey.indexOf("cp-subsystem")!==-1; });
  if(cpPresent){
    add("INFO","cp-subsystem-present", cpPresent.line, null,
      "CP Subsystem settings are present (line " + cpPresent.line + ") and were graded from the paste only. Confirm the CP member count is at least 3 and odd, and that data persistence is configured if CP data must survive restarts.");
  }
  var wanPresent = findEntry(function(e){ return e.effKey.indexOf("wan-replication")!==-1; });
  if(wanPresent && !tlsOn){
    add("WARNING","wan-no-tls", wanPresent.line, null,
      "WAN replication is configured (line " + wanPresent.line + ") with no enabled TLS found in the paste. Cross-site replication traffic should be encrypted and authenticated.");
  }

  // 11. Commented-out lines — never graded as active
  parsed.commented.forEach(function(c){
    if(!c.relevant) return;
    add("COMMENTED","commented-line", c.line, null,
      "Line " + c.line + " is commented out — COMMENTED / NOT ACTIVE. It was not graded as an active setting" + (c.key ? " (key: \"" + c.key + "\")" : "") + ". If this setting is meant to protect the cluster, uncomment it and re-audit.");
  });

  // 12. Unparsable lines
  parsed.notParsed.forEach(function(n){
    add("NOT PARSED","not-parsed", n.line, null,
      "Line " + n.line + " could not be parsed as a Hazelcast key line — NOT PARSED. It was not graded. Check it for a typo, a missing colon, or content pasted from another file.");
  });

  // Counts + verdict
  var counts = {BLOCKER:0, HIGH:0, WARNING:0, INFO:0, "NOT PARSED":0, COMMENTED:0};
  findings.forEach(function(f){ if(counts.hasOwnProperty(f.severity)) counts[f.severity]++; });

  var verdict;
  if(counts.BLOCKER > 0 || counts.HIGH >= 2) verdict = "DO NOT DEPLOY";
  else if(counts.HIGH === 1 || counts.WARNING > 0) verdict = "DEPLOY WITH FIXES";
  else verdict = "SAFE TO DEPLOY";

  var order = {BLOCKER:0, HIGH:1, WARNING:2, "NOT PARSED":3, COMMENTED:4, INFO:5};
  findings.sort(function(a,b){
    var d = order[a.severity] - order[b.severity];
    if(d!==0) return d;
    var la = a.line || (a.lines ? a.lines[0] : 0), lb = b.line || (b.lines ? b.lines[0] : 0);
    return la - lb;
  });

  return {verdict:verdict, findings:findings, counts:counts, reason:null};
}

function buildTextReport(result){
  var out = [];
  out.push("J-Dawgs Hazelcast Cluster Config Safety Auditor — Text Report");
  out.push("Verdict: " + result.verdict);
  if(result.reason){ out.push("Note: " + result.reason); }
  if(result.counts && Object.keys(result.counts).length){
    var parts = [];
    Object.keys(result.counts).forEach(function(k){ parts.push(k + ": " + result.counts[k]); });
    out.push("Counts: " + parts.join(" · "));
  }
  out.push("");
  if(!result.findings.length && !result.reason){
    out.push("No graded findings. Every graded check passed on the pasted config.");
  }
  result.findings.forEach(function(f){
    var where = f.lines ? "Lines " + f.lines.join(", ") : "Line " + f.line;
    out.push("[" + f.severity + "] " + where + " (" + f.check + ") — " + f.message);
  });
  out.push("");
  out.push("Scope: text audit of the pasted config only. Hazelcast was not started and no live cluster was probed. Secret values are never included in this report.");
  return out.join("\n");
}

function buildJsonReport(result){
  var obj = {
    tool: "J-Dawgs Hazelcast Cluster Config Safety Auditor",
    verdict: result.verdict,
    counts: result.counts,
    reason: result.reason,
    findings: result.findings.map(function(f){
      var o = {severity:f.severity, check:f.check, message:f.message};
      if(f.lines) o.lines = f.lines; else o.line = f.line;
      return o;
    }),
    scope: "Text audit of the pasted config only. Hazelcast was not started and no live cluster was probed. Secret values are never included; secrets are reported by key name, line, and value length only."
  };
  return JSON.stringify(obj, null, 2);
}
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-hazelcast-cluster-config-safety-auditor',
  name: 'J-Dawgs Hazelcast Cluster Config Safety Auditor',
  description: 'Grades a pasted Hazelcast cluster config fully offline into one deploy verdict — SAFE TO DEPLOY / DEPLOY WITH FIXES / DO NOT DEPLOY / NOT ENOUGH TO GRADE — multicast discovery, security disabled, the REST API exposed, and plaintext secrets, with secrets shown by key name, line, and length only, neve',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
