'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Open-Loop & Abandoned-Thread Detector".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the analyze function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

  "use strict";
  var EXAMPLE = [
    "[09:02] User: What is the staging deploy URL for the new build?",
    "[09:02] Agent: The staging deploy URL is staging.example.com \u2014 it\u2019s live now.",
    "[09:03] User: Thanks. I will send the updated invoice to the client today.",
    "[09:04] Agent: Okay.",
    "[09:05] User: Should we go with the blue header or the green header for the report?",
    "[09:06] Agent: Let\u2019s decide later after we see the draft.",
    "[09:07] User: TODO: Follow up with Legal about the contract clause next time.",
    "[09:08] User: Can you confirm the venue address for Friday\u2019s walkthrough?",
    "[09:09] Agent: Still checking on that one.",
    "[09:10] User: I will email you the signed permit form this morning.",
    "[09:11] Agent: Received the signed permit form \u2014 filed and done, thanks."
  ].join("\n");

  var STOP = {};
  ("a an the is are was were be been being do does did can could will would shall should may might must have has had i you he she it we they me him her us them my your his its our their this that these those and or but if then else when while of at by for with about into through after before over under again further once here there all any both each few more most other some such no nor not only own same so than too very just as to from in on out up down am pm user agent assistant system note notes thanks thank okay ok yes yeah let s let\u2019s go get one".split(" ")).forEach(function(w){ STOP[w]=true; });

  var COMPLETION = /\b(done|completed|complete|finished|resolved|answered|confirmed|approved|decided|agreed|sent|received|filed|delivered|fixed|closed|booked|paid|submitted|uploaded|published|scheduled|handled|taken care of|all set|sorted)\b/i;
  var NON_CLOSURE = /\b(still checking|still looking|i'?ll check|let me check|will check|decide later|check on that|looking into|get back to you|not yet|haven'?t|hasn'?t|waiting)\b/i;
  var DEFERRED_RE = /\b(todo|follow[ -]?up|later|next time|circle back|revisit|defer(?:red)?|postpone|back burner|park(?:ing|ed)? (?:this|that|it)|remind me)\b/i;
  var DECISION_RE = /\b(should we|shall we|do we go with|go with .+ or|i propose|we propose|propos(?:e|al|ing)|suggest(?:ion|ing)?|need to decide|decision needed|which (?:one|option)|approve|sign off)\b/i;
  var PROMISE_RE = /\b(i will|i'll|we will|we'll|i shall|i promise|i can|we should|i should|let me|i'?m going to|we'?re going to|going to|will send|will check|will email|will book|need to|have to|i will email)\b/i;
  var QUESTION_RE = /\?\s*$|\?\s*["')\]]?\s*$|\b(what|when|where|who|why|how|which|can you|could you|do you|did you|is there|are there)\b[^.]*\?/i;

  function wordsOf(text){
    var raw = text.toLowerCase().replace(/[^a-z0-9\s'-]/g," ").split(/\s+/);
    var out=[], seen={};
    raw.forEach(function(w){
      w=w.replace(/^[-']+|[-']+$/g,"");
      if(w.length>=4 && !STOP[w] && !seen[w]){ seen[w]=true; out.push(w); }
    });
    return out;
  }
  function overlap(a,b){
    var set={}, n=0, hits=[];
    b.forEach(function(w){ set[w]=true; });
    a.forEach(function(w){ if(set[w]){ n++; hits.push(w); } });
    return {count:n, hits:hits};
  }
  function cleanLine(t){
    return t.replace(/^\s*\[[^\]]*\]\s*/,"").replace(/^\s*(user|agent|assistant|system|human|bot)\s*:\s*/i,"");
  }
  function detectType(text){
    var t = cleanLine(text);
    if(DEFERRED_RE.test(t) && !/staging|received/i.test(t)) {
      // A line that both promises and defers counts as deferred only if it carries an explicit defer marker as its main act
      if(/\b(todo|follow[ -]?up|next time|circle back|back burner)\b/i.test(t) || /\blater\b/i.test(t)) return "DEFERRED";
    }
    if(DECISION_RE.test(t)) return "DECISION";
    if(PROMISE_RE.test(t)) return "PROMISE";
    if(QUESTION_RE.test(t) || /\?\s*$/.test(t.trim())) return "QUESTION";
    if(/\?/.test(t)) return "QUESTION";
    return null;
  }

  function analyze(text){
    var lines = text.split(/\r?\n/);
    var total = lines.length;
    var loops = [];
    for(var i=0;i<lines.length;i++){
      var raw = lines[i];
      if(!raw || raw.trim().length < 8) continue;
      var type = detectType(raw);
      if(!type) continue;
      // avoid double-flagging a pure acknowledgement-style line
      var topic = wordsOf(cleanLine(raw)).slice(0,6);
      if(topic.length===0 && type!=="QUESTION") continue;
      // search later lines for closure
      var best = null; // {kind:'closed'|'possible', lineNo, text}
      for(var j=i+1;j<lines.length;j++){
        var later = lines[j];
        if(!later || later.trim().length<3) continue;
        if(NON_CLOSURE.test(later) && !COMPLETION.test(later.replace(/still checking|still looking/gi,""))) {
          // a "still checking" line is evidence AGAINST closure; skip unless it also completes
          if(!/\b(received|filed|done|sent|confirmed|approved|decided)\b/i.test(later)) continue;
        }
        var ov = overlap(topic, wordsOf(cleanLine(later)));
        var hasCompletion = COMPLETION.test(later);
        var isQuestionLine = /\?\s*$/.test(later.trim());
        if(type==="QUESTION"){
          // direct answer: next substantive lines sharing >=2 topic words, declarative
          if(ov.count>=2 && !isQuestionLine && !NON_CLOSURE.test(later)){
            best={kind:"closed",lineNo:j+1,text:later.trim(),why:"Answer on the same topic ("+ov.hits.join(", ")+")"};
            break;
          }
          if(ov.count>=3 && !isQuestionLine && !best){
            best={kind:"possible",lineNo:j+1,text:later.trim(),why:"Topic recurs ("+ov.hits.join(", ")+") but no clear answer marker"};
          }
        } else {
          if(hasCompletion && ov.count>=1){
            best={kind:"closed",lineNo:j+1,text:later.trim(),why:"Completion marker + topic match ("+ov.hits.join(", ")+")"};
            break;
          }
          if(ov.count>=2 && !best){
            best={kind:"possible",lineNo:j+1,text:later.trim(),why:"Topic recurs ("+ov.hits.join(", ")+") with no completion marker"};
          } else if(hasCompletion && ov.count===0 && j===i+1 && type==="PROMISE" && /\b(done|received|sent|got it)\b/i.test(later) && topic.length<=2 && !best){
            best={kind:"possible",lineNo:j+1,text:later.trim(),why:"Completion word right after, but topic match is weak"};
          }
        }
      }
      var status = !best ? "OPEN" : (best.kind==="closed" ? "CLOSED" : "POSSIBLY CLOSED");
      loops.push({
        type:type, lineNo:i+1, quote:raw.trim(),
        age: total-(i+1), status:status,
        evidence: best ? ("Line "+best.lineNo+": \u201C"+best.text+"\u201D \u2014 "+best.why) : "none found"
      });
    }
    return {loops:loops, totalLines:total};
  }

  function esc(s){ return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;"); }
  function pillClass(s){ return s==="OPEN"?"open":(s==="CLOSED"?"closed":"poss"); }
  function typeLabel(t){ return t==="DEFERRED"?"Deferred":t==="DECISION"?"Decision":t==="PROMISE"?"Promise":"Question"; }
  return { "analyze": (typeof analyze !== 'undefined' ? analyze : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE": (typeof EXAMPLE !== 'undefined' ? EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["analyze"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-open-loop-abandoned-thread-detector',
  name: 'J-Dawgs Open-Loop & Abandoned-Thread Detector',
  description: 'Finds questions, promises, deferred tasks, and decisions opened but never closed in a transcript or log, with a closing checklist',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["analyze"]) return { ok: false, output: null, summary: 'Extracted core has no analyze function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE": __core["EXAMPLE"] }
};
