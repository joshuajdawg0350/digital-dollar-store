'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Technitium DNS Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var RISKY = [
        "dnsServerDomain=dns.example.local",
        "dnsServerLocalEndPoints=0.0.0.0:53",
        "webServiceLocalAddresses=0.0.0.0",
        "webServiceHttpPort=5380",
        "webServiceEnableTls=false",
        "allowRecursion=true",
        "recursionAclNetworks=0.0.0.0/0",
        "enableDnsOverTls=false",
        "enableDnsOverHttps=false",
        "enableDnsOverQuic=false",
        "forwarders=8.8.8.8, 1.1.1.1",
        "forwarderProtocol=Udp",
        "enableQueryLogging=true",
        "logRetentionDays=0",
        "blockListUrls=",
        "adminPassword=admin",
        "apiToken=abc123",
        "enableTelemetry=true",
        "zoneTransfer=any",
        "zoneType=Secondary",
        "this line cannot be parsed at all"
      ].join("\n");

      var HARDENED = [
        "dnsServerDomain=dns.example.local",
        "dnsServerLocalEndPoints=192.168.1.10:53",
        "webServiceLocalAddresses=127.0.0.1",
        "webServiceHttpPort=5380",
        "webServiceHttpsPort=53443",
        "webServiceEnableTls=true",
        "allowRecursion=true",
        "recursionAclNetworks=192.168.1.0/24",
        "allowRecursionOnlyForPrivateNetworks=true",
        "enableDnsOverTls=true",
        "enableDnsOverHttps=true",
        "enableDnsOverQuic=true",
        "forwarders=https://cloudflare-dns.com/dns-query, https://dns.quad9.net/dns-query",
        "forwarderProtocol=Https",
        "enableQueryLogging=false",
        "logRetentionDays=7",
        "blockListUrls=https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts",
        "adminPassword=X9v!qR7mZ2pL8wKd4s",
        "apiToken=tk7f29c1ab84e04d2fa91b6c3d5e708192ab",
        "enableTelemetry=false",
        "checkForUpdates=true",
        "zoneTransfer=192.168.1.20",
        "zoneType=Primary"
      ].join("\n");

      var WORKED_INPUT = [
        "webServiceLocalAddresses=127.0.0.1",
        "webServiceEnableTls=true",
        "allowRecursion=true",
        "recursionAclNetworks=192.168.1.0/24",
        "enableDnsOverHttps=true",
        "forwarders=https://dns.quad9.net/dns-query",
        "adminPassword=X9v!qR7mZ2pL8wKd4s"
      ].join("\n");

      var RECOGNIZED = /dns|webservice|web_service|forwarder|recursion|acl|log|block|allowlist|zone|transfer|tls|https|http|quic|admin|password|token|api|telemetry|update|listen|endpoint|certificate|query/i;
      var SECRET_KEY = /password|passwd|pwd|token|secret|api[-_]?key|credential|private[-_]?key/i;
      var DEFAULT_WORDS = ["admin","password","passw0rd","changeme","default","example","letmein","technitium","123456","12345678","qwerty","test","dnsadmin","secret"];
      var SEV_RANK = {BLOCKER:0, HIGH:1, MEDIUM:2, LOW:3, INFO:4};

      function isTrue(v){ return /^(true|yes|1|on|enabled)$/i.test(String(v).trim()); }
      function isFalse(v){ return /^(false|no|0|off|disabled)$/i.test(String(v).trim()); }
      function unquote(v){
        v = String(v).trim();
        if (v.length >= 2 && ((v.charAt(0)==='"' && v.charAt(v.length-1)==='"') || (v.charAt(0)==="'" && v.charAt(v.length-1)==="'"))) v = v.slice(1,-1);
        return v.replace(/,\s*$/,"");
      }

      function parseConfig(text){
        var entries = [], notParsed = [];
        var trimmed = text.trim();
        if (trimmed.charAt(0) === "{"){
          try {
            var obj = JSON.parse(trimmed);
            var lines = text.split(/\r?\n/);
            Object.keys(obj).forEach(function(k){
              var ln = 1;
              for (var i=0;i<lines.length;i++){ if (lines[i].indexOf('"'+k+'"') !== -1){ ln = i+1; break; } }
              var val = obj[k];
              entries.push({ key:k, value: (val===null||val===undefined) ? "" : String(val), line: ln });
            });
            return { entries: entries, notParsed: notParsed, json: true };
          } catch(e){ /* fall through to line parsing */ }
        }
        var rawLines = text.split(/\r?\n/);
        for (var n=0;n<rawLines.length;n++){
          var lineNo = n+1;
          var t = rawLines[n].trim();
          if (t === "") continue;
          if (t.charAt(0)==="#" || t.indexOf("//")===0 || t.charAt(0)===";") continue;
          var m = t.match(/^"?([A-Za-z][A-Za-z0-9_.\-]*)"?\s*[:=]\s*(.*)$/);
          if (m){ entries.push({ key: m[1], value: unquote(m[2]), line: lineNo }); }
          else { notParsed.push({ line: lineNo }); }
        }
        return { entries: entries, notParsed: notParsed, json: false };
      }

      function audit(text){
        var parsed = parseConfig(text || "");
        var entries = parsed.entries;
        var notParsed = parsed.notParsed;
        var findings = [];
        var seen = {};
        function add(sev, entry, issue, fix){
          var dedupe = sev+"|"+entry.line+"|"+entry.key+"|"+issue;
          if (seen[dedupe]) return;
          seen[dedupe] = 1;
          findings.push({ severity: sev, line: entry.line, key: entry.key, issue: issue, fix: fix });
        }
        function findEntry(re){
          for (var i=0;i<entries.length;i++){ if (re.test(entries[i].key)) return entries[i]; }
          return null;
        }
        function allEntries(re){
          var out = [];
          for (var i=0;i<entries.length;i++){ if (re.test(entries[i].key)) out.push(entries[i]); }
          return out;
        }

        var recognized = entries.filter(function(e){ return RECOGNIZED.test(e.key); });

        // ---- context: ACL restriction, public exposure, encrypted listeners ----
        var aclEntries = allEntries(/acl/i);
        var restrictedAcl = null;
        aclEntries.forEach(function(e){
          if (e.value && !/0\.0\.0\.0\/0|::\/0|^\*$/.test(e.value.trim())) restrictedAcl = e;
        });
        var allowRec = findEntry(/^allowrecursion$/i);
        var endpointEntry = findEntry(/localendpoints|listen|bindaddress/i);
        var webAddrEntry = findEntry(/webservice.*(localaddress|listen|bind|endpoint)/i);
        var exposureEntry = null;
        if (endpointEntry && /0\.0\.0\.0|::/.test(endpointEntry.value)) exposureEntry = endpointEntry;
        if (!exposureEntry && webAddrEntry && /0\.0\.0\.0|::/.test(webAddrEntry.value)) exposureEntry = webAddrEntry;
        if (!exposureEntry && allowRec && isTrue(allowRec.value) && !restrictedAcl) exposureEntry = allowRec;
        if (!exposureEntry){
          var pub = findEntry(/public|exposure/i);
          if (pub && /true|public|external|internet/i.test(pub.value)) exposureEntry = pub;
        }
        var publicExposure = !!exposureEntry;
        var encTls = findEntry(/^enablednsovertls$/i), encH = findEntry(/^enablednsoverhttps$/i), encQ = findEntry(/^enablednsoverquic$/i);
        var anyEncrypted = [encTls,encH,encQ].some(function(e){ return e && isTrue(e.value); });

        var retentionEntry = findEntry(/retention/i);
        var retentionNoLimit = true;
        if (retentionEntry){
          var rv = retentionEntry.value.trim();
          retentionNoLimit = /^(0|-1)$/.test(rv) || /unlimited|none|forever|no limit/i.test(rv);
        }
        var transferEntries = allEntries(/zonetransfer|transferacl|allowzonetransfer/i);
        var transferRestricted = transferEntries.some(function(e){ return e.value && !/any|all|\*|0\.0\.0\.0/i.test(e.value); });

        // ---- per-entry checks ----
        entries.forEach(function(e){
          var k = e.key, kl = k.toLowerCase(), v = e.value, vt = v.trim();

          // Credentials — value is NEVER copied into any finding.
          if (SECRET_KEY.test(k)){
            var len = vt.length;
            var lowv = vt.toLowerCase();
            var isDefault = DEFAULT_WORDS.indexOf(lowv) !== -1;
            if (len === 0){
              add("HIGH", e, "Credential key present with an empty value (length 0).", "Set a long, unique value (16+ characters) and store it in a password manager.");
            } else if (isDefault){
              add("HIGH", e, "Credential value matches a common default/example pattern class (length "+len+"). The value itself is never shown.", "Rotate this credential now to a long, unique value that has never been used anywhere else.");
            } else if (len < 8){
              add("HIGH", e, "Credential value is very short — length "+len+" only. The value itself is never shown.", "Replace it with a long, unique value (16+ characters) from a password manager or generator.");
            } else if (len < 12){
              add("MEDIUM", e, "Credential value is short — length "+len+". The value itself is never shown.", "Lengthen it to 16+ characters; short tokens and passwords fall to guessing attacks.");
            } else {
              add("INFO", e, "Credential present — value redacted (length "+len+"). No default/example pattern detected.", "No change needed. Keep the value out of shared tickets, chats, and screenshots.");
            }
            return;
          }

          // Web console bind
          if (/webservice/i.test(k) && /(localaddress|listen|bind|endpoint)/i.test(k) && /0\.0\.0\.0|::|^\*$/.test(vt)){
            add("BLOCKER", e, "Web console / HTTP service is listening on all interfaces, so the admin console is reachable from every network this host touches.", "Bind the web service to 127.0.0.1 or one trusted management address, and reach it over a VPN or SSH tunnel instead.");
            return;
          }
          // Web console TLS off
          if (/webservice/i.test(k) && /enabletls|tlsenabled|usessl/i.test(k) && isFalse(vt)){
            add("HIGH", e, "Web console TLS is disabled — the admin console and its logins travel over plain HTTP.", "Enable TLS for the web service (webServiceEnableTls=true) with a real certificate, and use the HTTPS port.");
            return;
          }
          if (/webservice/i.test(k) && /selfsigned/i.test(k) && isTrue(vt)){
            add("LOW", e, "Web console uses a self-signed TLS certificate, so browsers cannot verify the console's identity.", "Install a certificate from a trusted CA (for example Let's Encrypt) for the console hostname.");
            return;
          }
          // Plain DNS-over-HTTP
          if (/^enablednsoverhttp$/i.test(k) && isTrue(vt)){
            add("HIGH", e, "Unencrypted DNS-over-HTTP is enabled, exposing client queries in plain text.", "Disable plain DNS-over-HTTP and serve DNS-over-HTTPS (DoH) over TLS instead.");
            return;
          }
          // Encrypted listeners explicitly off while publicly exposed
          if (/^enablednsover(tls|https|quic)$/i.test(k) && isFalse(vt) && publicExposure){
            add("MEDIUM", e, "This encrypted DNS listener is disabled while the server is publicly exposed, so clients are pushed to plain-text DNS.", "Enable this encrypted listener (DoT, DoH, or DoQ) with a valid certificate before exposing the server publicly.");
            return;
          }
          // Recursion ACL wide open
          if (/acl/i.test(k) && /0\.0\.0\.0\/0|::\/0/.test(vt)){
            add("BLOCKER", e, "The recursion ACL allows every network (0.0.0.0/0), which makes this an open resolver anyone on the internet can abuse.", "Restrict the recursion ACL to only the networks you serve, such as your LAN subnet, and nothing wider.");
            return;
          }
          // Forwarder protocol plain
          if (/forwarderprotocol/i.test(k) && /^(udp|tcp|plain|unencrypted)/i.test(vt)){
            add("HIGH", e, "Upstream forwarders use a plain, unencrypted protocol, so upstream queries can be watched or altered in transit.", "Switch the forwarder protocol to an encrypted one (HTTPS / DoH or TLS / DoT) with an encrypted upstream resolver.");
            return;
          }
          // Forwarders list plain
          if (/^forwarders?$/i.test(k) && vt !== "" && !/https:|tls:|\b853\b|dns-over/i.test(vt)){
            add("MEDIUM", e, "Upstream forwarders are listed without an encrypted endpoint (no https:// URL and no TLS port 853), so they resolve over plain UDP/TCP.", "Point forwarders at encrypted endpoints, for example https://dns.quad9.net/dns-query or a DoT resolver on port 853.");
            return;
          }
          // Query logging
          if (/(querylog|logqueries|enablequerylogging|logallqueries)/i.test(k) && isTrue(vt)){
            if (retentionNoLimit){
              add("MEDIUM", e, "Full client query logging is enabled with no retention limit, so a complete history of client lookups piles up indefinitely — a privacy exposure if the host or logs leak.", "Turn query logging off, or set a short retention limit (for example logRetentionDays=7) and restrict who can read the logs.");
            } else {
              add("LOW", e, "Full client query logging is enabled, but a retention limit is set.", "Confirm the retention window is as short as your troubleshooting actually needs.");
            }
            return;
          }
          // Block / allow lists
          if (/blocklist/i.test(k)){
            if (vt === "" || /^(none|null|false|disabled)$/i.test(vt)){
              add("LOW", e, "No block list is in effect, so known ad, tracking, and malware domains resolve normally.", "Add at least one reputable block list URL, or record the deliberate decision to run without one.");
            } else {
              add("INFO", e, "A block list is configured.", "Keep the list source reputable and let it refresh on schedule.");
            }
            return;
          }
          if (/allowlist/i.test(k)){
            if (/\*|0\.0\.0\.0/.test(vt)){
              add("MEDIUM", e, "The allow list is effectively wide open, which can silently defeat the block list.", "Narrow the allow list to the specific domains that must always resolve.");
            } else if (vt !== ""){
              add("INFO", e, "An allow list is configured with specific entries.", "Review it periodically so stale exceptions do not pile up.");
            }
            return;
          }
          // Telemetry
          if (/telemetry/i.test(k) && isTrue(vt)){
            add("LOW", e, "Telemetry / usage reporting is enabled, sending data about this server to a third party.", "Disable telemetry unless you have a specific reason to share usage data.");
            return;
          }
          // Update checks off
          if (/(checkforupdates|autoupdate|enableupdates)/i.test(k) && isFalse(vt)){
            add("LOW", e, "Update checks are disabled, so security fixes will not be noticed automatically.", "Enable update checks, or track Technitium releases yourself on a schedule.");
            return;
          }
          // Zone transfer posture
          if (/zonetransfer|transferacl|allowzonetransfer/i.test(k)){
            if (/any|all|^\*$|0\.0\.0\.0/i.test(vt)){
              add("HIGH", e, "Zone transfers are unrestricted, so anyone can download your full zone contents.", "Restrict zone transfers to the specific secondary server addresses that need them, or disable transfers you do not use.");
            } else if (vt !== ""){
              add("INFO", e, "Zone transfers are restricted to the stated host(s).", "No change needed; re-check the list when secondaries change.");
            }
            return;
          }
          // Secondary zone without a real transfer restriction
          if (/zonetype/i.test(k) && /secondary/i.test(vt) && !transferRestricted){
            add("MEDIUM", e, "A secondary zone is present with no restricted zone-transfer source in the paste, so its transfer posture cannot be confirmed as locked down.", "Restrict zone transfers for this zone to the primary server's address only, ideally with TSIG authentication.");
            return;
          }
        });

        // ---- global checks ----
        if (allowRec && isTrue(allowRec.value) && !restrictedAcl){
          add("BLOCKER", allowRec, "Recursion is allowed with no restricting ACL in the config, so this DNS service acts as an open resolver for anyone who can reach it.", "Restrict recursion to your own networks with a recursion ACL (for example your LAN subnet), or disable recursion on publicly reachable servers.");
        }
        var privOnly = findEntry(/allowrecursiononlyforprivatenetworks/i);
        if (privOnly && isFalse(privOnly.value) && allowRec && isTrue(allowRec.value) && restrictedAcl){
          add("HIGH", privOnly, "Recursion is not limited to private networks even though an ACL exists, widening who can use this resolver.", "Enable allowRecursionOnlyForPrivateNetworks or tighten the recursion ACL to private ranges only.");
        }
        if (publicExposure && !anyEncrypted){
          add("HIGH", exposureEntry, "The server is publicly exposed but no encrypted DNS listener (DoT, DoH, or DoQ) is enabled, so all client queries travel in plain text.", "Enable at least one encrypted listener — DNS-over-HTTPS or DNS-over-TLS — with a valid certificate before deploying publicly.");
        }
        var httpPort = findEntry(/^webservicehttpport$/i);
        var tlsEntry = findEntry(/webservice.*enabletls/i);
        var httpsPort = findEntry(/^webservicehttpsport$/i);
        if (httpPort && !tlsEntry && !httpsPort){
          add("MEDIUM", httpPort, "A web console HTTP port is set but no TLS setting or HTTPS port appears in the paste, so the console looks HTTP-only.", "Enable web service TLS and set the HTTPS port; use plain HTTP only as a redirect to HTTPS, if at all.");
        }

        findings.sort(function(a,b){
          if (SEV_RANK[a.severity] !== SEV_RANK[b.severity]) return SEV_RANK[a.severity] - SEV_RANK[b.severity];
          return a.line - b.line;
        });

        var counts = { blocker:0, high:0, medium:0, low:0, info:0, notParsed: notParsed.length };
        findings.forEach(function(f){ counts[f.severity.toLowerCase()]++; });

        var verdict, why;
        if (!text || !String(text).trim()){
          verdict = "NOT ENOUGH TO GRADE";
          why = "The paste is empty. Paste a Technitium config export or settings text, or load one of the built-in examples.";
        } else if (recognized.length === 0){
          verdict = "NOT ENOUGH TO GRADE";
          why = "No recognizable Technitium keys were found in the paste, so there is nothing to grade. Lines that could not be parsed are listed below and were excluded.";
        } else if (counts.blocker > 0){
          verdict = "DO NOT DEPLOY";
          why = counts.blocker + " blocker finding(s) must be fixed before this config goes anywhere near a live server.";
        } else if (counts.high > 0 || counts.medium > 0){
          verdict = "DEPLOY WITH FIXES";
          why = "No blockers, but " + (counts.high + counts.medium) + " high/medium finding(s) should be fixed before deployment.";
        } else {
          verdict = "SAFE TO DEPLOY";
          why = "No blocker, high, or medium findings in the pasted config. This grades the paste only — it does not verify the config loads in Technitium.";
        }

        return { verdict: verdict, why: why, counts: counts, findings: findings, notParsed: notParsed, recognizedKeys: recognized.length };
      }

      function buildReport(r){
        var L = [];
        L.push("J-Dawgs Technitium DNS Server Config Safety Auditor\u2122 \u2014 Audit Report");
        L.push("Verdict: " + r.verdict);
        L.push("Why: " + r.why);
        L.push("Counts: Blocker " + r.counts.blocker + " \u00b7 High " + r.counts.high + " \u00b7 Medium " + r.counts.medium + " \u00b7 Low " + r.counts.low + " \u00b7 Info " + r.counts.info + " \u00b7 Not parsed " + r.counts.notParsed);
        L.push("Recognized Technitium keys: " + r.recognizedKeys);
        L.push("");
        L.push("Findings:");
        if (!r.findings.length) L.push("(none)");
        r.findings.forEach(function(f){
          L.push("[" + f.severity + "] Line " + f.line + " \u00b7 " + f.key + " \u2014 " + f.issue + " Fix: " + f.fix);
        });
        L.push("");
        L.push("Not parsed (excluded from grading, never guessed):");
        if (!r.notParsed.length) L.push("(none)");
        r.notParsed.forEach(function(np){ L.push("Line " + np.line + " \u2014 NOT PARSED"); });
        L.push("");
        L.push("Notes: Credential values never appear in this report; credentials are reported by key name, line number, and value length only. This is a heuristic text audit of the pasted config only \u2014 it does not start Technitium, does not connect to any server, does not verify the config loads, and is not a replacement for the server's own validation.");
        return L.join("\n");
      }

      function buildJson(r){
        return {
          tool: "J-Dawgs Technitium DNS Server Config Safety Auditor\u2122",
          verdict: r.verdict,
          counts: { blocker: r.counts.blocker, high: r.counts.high, medium: r.counts.medium, low: r.counts.low, info: r.counts.info, notParsed: r.counts.notParsed },
          recognizedKeys: r.recognizedKeys,
          findings: r.findings.map(function(f){ return { severity: f.severity, line: f.line, key: f.key, issue: f.issue, fix: f.fix }; }),
          notParsed: r.notParsed.map(function(np){ return { line: np.line }; }),
          note: "Credential values are never included; credentials are reported by key, line, and value length only."
        };
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-technitium-dns-server-config-safety-auditortm',
  name: 'J-Dawgs Technitium DNS Server Config Safety Auditor',
  description: 'Grades a pasted Technitium DNS Server config fully offline into one deploy verdict — SAFE TO DEPLOY / DEPLOY WITH FIXES / DO NOT DEPLOY / NOT ENOUGH TO GRADE — web console and TLS exposure, open-resolver posture, DoT/DoH/DoQ posture, forwarders, and query logging, with credentials shown by key, line',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
