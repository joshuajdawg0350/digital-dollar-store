'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Qdrant Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var RISKY_EXAMPLE = [
        "# Qdrant config — quick start, copied from a forum post",
        "log_level: INFO",
        "",
        "service:",
        "  host: 0.0.0.0",
        "  http_port: 6333",
        "  grpc_port: 6334",
        "  enable_cors: true",
        "",
        "storage:",
        "  storage_path: ./storage",
        "",
        "telemetry_disabled: false",
        "",
        "cluster:",
        "  enabled: true",
        "  p2p:",
        "    port: 6335"
      ].join("\n");

      var HARDENED_EXAMPLE = [
        "# Qdrant config — hardened single-node deployment",
        "log_level: INFO",
        "",
        "service:",
        "  host: 127.0.0.1",
        "  http_port: 6333",
        "  grpc_port: 6334",
        "  api_key: \"kX9f2mQ7vR4tZ8pL3nW6sD1hJ5bVcAeG\"",
        "  read_only_api_key: \"rT5yU8iO2pA7sD0fG3hJ6kL9zX4cV1bN\"",
        "  enable_tls: true",
        "  tls_config:",
        "    cert: /etc/qdrant/tls/cert.pem",
        "    key: /etc/qdrant/tls/key.pem",
        "    ca_cert: /etc/qdrant/tls/ca.pem",
        "",
        "storage:",
        "  storage_path: /var/lib/qdrant/storage",
        "",
        "telemetry_disabled: true",
        "",
        "cluster:",
        "  enabled: false"
      ].join("\n");

      /* ---------- known-key tables ---------- */
      var KNOWN_TOP = {
        log_level: 1, service: 1, storage: 1, cluster: 1,
        telemetry_disabled: 1, telemetry: 1, version: 1
      };
      var KNOWN_SERVICE = {
        host: 1, http_port: 1, grpc_port: 1, api_key: 1, read_only_api_key: 1,
        enable_tls: 1, tls_config: 1, enable_cors: 1, max_request_size_mb: 1,
        max_workers: 1, started_at: 1
      };
      var KNOWN_TLS = { cert: 1, key: 1, ca_cert: 1, cert_chain: 1, enable_tls: 1, verify_certificate: 1 };
      var KNOWN_STORAGE = {
        storage_path: 1, snapshots_path: 1, temp_path: 1, on_disk_payload: 1,
        wal: 1, optimizers: 1, hnsw_index: 1, quantization: 1, memmap_threshold_kb: 1,
        memmap_advice: 1, payload_storage_type: 1, max_segment_size_kb: 1,
        segment_number: 1, indexing_threshold_kb: 1, flush_interval_sec: 1,
        deleted_threshold: 1, vacuum_min_vector_number: 1, max_optimization_threads: 1,
        cpu_budget: 1, default_segment_number: 1, mmap_threshold: 1, async_scorer: 1,
        update_rate_limit: 1, payload_mmap_threshold: 1
      };
      var KNOWN_CLUSTER = { enabled: 1, p2p: 1 };
      var KNOWN_P2P = { port: 1, enable_tls: 1, connection_pool_size: 1 };
      var KNOWN_TELEMETRY = { endpoint: 1, app_name: 1, sys_info: 1, posthog: 1 };

      var PLACEHOLDERS = [
        "changeme", "change-me", "change_me", "your-api-key", "your_api_key",
        "yourapikey", "api-key", "apikey", "api_key", "secret", "password",
        "passwd", "letmein", "admin", "default", "example", "placeholder",
        "todo", "fixme", "xxx", "xxxx", "xxxxx", "test", "testing", "demo",
        "qdrant", "12345678", "123456789", "00000000", "aaaaaaaa",
        "<api-key>", "<your-api-key>", "${api_key}", "$api_key", "null",
        "none", "~", "true", "false"
      ];

      /* ---------- helpers ---------- */
      function stripQuotes(v) {
        v = String(v == null ? "" : v).trim();
        if (v.length >= 2) {
          var a = v.charAt(0), b = v.charAt(v.length - 1);
          if ((a === '"' && b === '"') || (a === "'" && b === "'")) return v.slice(1, -1);
        }
        return v;
      }
      function stripComment(v) {
        /* strip a trailing " # comment" that is outside quotes */
        var inS = false, inD = false;
        for (var i = 0; i < v.length; i++) {
          var c = v.charAt(i);
          if (c === "'" && !inD) inS = !inS;
          else if (c === '"' && !inS) inD = !inD;
          else if (c === "#" && !inS && !inD && (i === 0 || /\s/.test(v.charAt(i - 1)))) {
            return v.slice(0, i).replace(/\s+$/, "");
          }
        }
        return v;
      }
      function isTruthy(v) {
        var s = String(v == null ? "" : v).trim().toLowerCase();
        return s === "true" || s === "yes" || s === "on" || s === "1";
      }
      function isFalsy(v) {
        var s = String(v == null ? "" : v).trim().toLowerCase();
        return s === "false" || s === "no" || s === "off" || s === "0";
      }
      function isLocalhostHost(h) {
        if (h == null) return false;
        var s = String(h).trim().toLowerCase();
        return s === "127.0.0.1" || s === "localhost" || s === "::1" || s === "[::1]";
      }
      function isAllInterfaces(h) {
        var s = String(h == null ? "" : h).trim().toLowerCase();
        return s === "0.0.0.0" || s === "::" || s === "[::]" || s === "*";
      }
      function isPlaceholder(v) {
        var s = String(v).trim().toLowerCase();
        if (s === "") return true;
        for (var i = 0; i < PLACEHOLDERS.length; i++) if (s === PLACEHOLDERS[i]) return true;
        if (/^(.)\1{3,}$/.test(s)) return true;             /* aaaa… / 0000… */
        if (/^x{3,}$/.test(s)) return true;
        if (/^(your|my)[-_ ]?api/.test(s)) return true;
        if (/change[-_ ]?me/.test(s)) return true;
        if (/^(insert|put|enter)[-_ ]/.test(s)) return true;
        return false;
      }
      function esc(s) {
        return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
      }

      /* ---------- format detection ---------- */
      function detectFormat(text) {
        var lines = text.split(/\r?\n/);
        var nonEmpty = [];
        var i, ln;
        for (i = 0; i < lines.length; i++) if (lines[i].trim() !== "") nonEmpty.push(lines[i]);
        if (nonEmpty.length === 0) return "empty";

        var envCount = 0, flagCount = 0, yamlCount = 0;
        var hasCompose = false, hasQdrantImage = false, hasPorts = false;
        for (i = 0; i < nonEmpty.length; i++) {
          ln = nonEmpty[i];
          if (/^\s*(export\s+)?QDRANT__[A-Z0-9_]+\s*=/.test(ln) || /^\s*-\s*QDRANT__[A-Z0-9_]+\s*=/.test(ln)) envCount++;
          if (/^\s*services\s*:/.test(ln)) hasCompose = true;
          if (/image\s*:\s*["']?qdrant\/qdrant/.test(ln)) hasQdrantImage = true;
          if (/^\s*ports\s*:/.test(ln)) hasPorts = true;
          if (/(^|\s)--[a-z][a-z0-9-]*/.test(ln)) flagCount++;
          if (/^\s*[A-Za-z_][A-Za-z0-9_.-]*\s*:/.test(ln) && ln.indexOf("=") === -1) yamlCount++;
        }
        if (hasCompose && (hasQdrantImage || hasPorts)) return "docker-compose";
        if (envCount > 0 && envCount >= flagCount && envCount >= yamlCount) return "env";
        if (flagCount > 0 && flagCount >= yamlCount) return "flags";
        if (yamlCount > 0) return "yaml";
        if (envCount > 0) return "env";
        if (flagCount > 0) return "flags";
        return "yaml";
      }
      var FORMAT_LABELS = {
        "yaml": "Qdrant YAML config",
        "env": "environment variables (QDRANT__*)",
        "flags": "command-line flags",
        "docker-compose": "docker-compose snippet",
        "empty": "no input"
      };

      /* ---------- parsing: everything becomes flat entries ----------
         entries: { path, key, value, line } — path uses dots, e.g. service.api_key
         notParsed: { line, description }                                    */
      function newParse() { return { entries: [], notParsed: [], meta: {} }; }

      function addEntry(p, path, key, value, line) {
        p.entries.push({ path: path, key: key, value: value, line: line });
      }
      function addNotParsed(p, line, description) {
        p.notParsed.push({ line: line, description: description });
      }

      function parseEnvText(text, p, lineOffset) {
        var lines = text.split(/\r?\n/);
        for (var i = 0; i < lines.length; i++) {
          var lineNo = i + 1 + (lineOffset || 0);
          var raw = lines[i];
          var t = raw.trim();
          if (t === "" || t.charAt(0) === "#") continue;
          t = t.replace(/^export\s+/, "");
          var m = t.match(/^(QDRANT__[A-Z0-9_]+)\s*=\s*(.*)$/);
          if (m) {
            var path = m[1].substring("QDRANT".length + 2).toLowerCase().split("__").join(".");
            var key = path.split(".").pop();
            addEntry(p, path, key, stripQuotes(stripComment(m[2])), lineNo);
            continue;
          }
          var m2 = t.match(/^([A-Za-z_][A-Za-z0-9_]*)\s*=/);
          if (m2) {
            addNotParsed(p, lineNo, "Environment variable " + m2[1] + " is not a QDRANT__* variable — not a Qdrant setting this auditor can grade.");
          } else {
            addNotParsed(p, lineNo, "Line could not be parsed as an environment assignment (NAME=value).");
          }
        }
      }

      function parseFlagsText(text, p) {
        /* tokenize respecting simple quotes */
        var tokens = [];
        var cur = "", inS = false, inD = false, has = false;
        var flat = text.replace(/\r?\n/g, " ");
        for (var i = 0; i < flat.length; i++) {
          var c = flat.charAt(i);
          if (c === "'" && !inD) { inS = !inS; has = true; continue; }
          if (c === '"' && !inS) { inD = !inD; has = true; continue; }
          if (!inS && !inD && /\s/.test(c)) {
            if (has || cur !== "") { tokens.push(cur); cur = ""; has = false; }
            continue;
          }
          cur += c; has = true;
        }
        if (has || cur !== "") tokens.push(cur);

        var FLAG_BOOL = {
          "enable-tls": "service.enable_tls", "tls": "service.enable_tls",
          "telemetry-disabled": "telemetry_disabled", "disable-telemetry": "telemetry_disabled",
          "enable-cors": "service.enable_cors", "cluster": "cluster.enabled",
          "enable-cluster": "cluster.enabled"
        };
        var FLAG_VALUE = {
          "api-key": "service.api_key", "api_key": "service.api_key",
          "read-only-api-key": "service.read_only_api_key", "read_only_api_key": "service.read_only_api_key",
          "host": "service.host", "http-host": "service.host",
          "http-port": "service.http_port", "port": "service.http_port",
          "grpc-port": "service.grpc_port",
          "tls-cert": "service.tls_config.cert", "tls-key": "service.tls_config.key",
          "tls-ca-cert": "service.tls_config.ca_cert", "cert": "service.tls_config.cert",
          "key": "service.tls_config.key",
          "p2p-port": "cluster.p2p.port", "config-path": "(meta)config_path",
          "log-level": "log_level", "storage-path": "storage.storage_path",
          "uri": "(meta)uri"
        };
        for (i = 0; i < tokens.length; i++) {
          var tok = tokens[i];
          if (tok === "qdrant" && i === 0) continue;
          if (tok.indexOf("--") === 0) {
            var body = tok.substring(2);
            var eq = body.indexOf("=");
            var name = eq >= 0 ? body.substring(0, eq) : body;
            var inlineVal = eq >= 0 ? body.substring(eq + 1) : null;
            if (Object.prototype.hasOwnProperty.call(FLAG_VALUE, name)) {
              var path = FLAG_VALUE[name];
              var val = inlineVal;
              if (val === null && i + 1 < tokens.length && tokens[i + 1].indexOf("--") !== 0) { val = tokens[i + 1]; i++; }
              if (val === null) { addNotParsed(p, 1, "Flag --" + name + " has no value — skipped, not guessed."); continue; }
              if (path.indexOf("(meta)") === 0) { p.meta[path] = val; continue; }
              addEntry(p, path, path.split(".").pop(), stripQuotes(val), 1);
            } else if (Object.prototype.hasOwnProperty.call(FLAG_BOOL, name)) {
              var bpath = FLAG_BOOL[name];
              var bval = inlineVal;
              if (bval === null && i + 1 < tokens.length && /^(true|false)$/i.test(tokens[i + 1])) { bval = tokens[i + 1]; i++; }
              addEntry(p, bpath, bpath.split(".").pop(), bval === null ? "true" : bval, 1);
            } else {
              addNotParsed(p, 1, "Flag --" + name + " is not a Qdrant flag this auditor recognizes — skipped, not guessed.");
            }
          } else if (tok !== "") {
            addNotParsed(p, 1, "Token \"" + (tok.length > 24 ? tok.substring(0, 24) + "…" : tok) + "\" is not part of a recognized flag — skipped, not guessed.");
          }
        }
      }

      /* YAML-ish parser for plain config AND docker-compose.
         Handles indentation nesting and "- item" lists (compose ports / environment). */
      function parseYamlText(text, p, format) {
        var lines = text.split(/\r?\n/);
        var stack = []; /* {indent, path} */
        var listContext = null; /* {indent, path} for "- " items */
        for (var i = 0; i < lines.length; i++) {
          var lineNo = i + 1;
          var rawLine = lines[i];
          if (rawLine.trim() === "") continue;
          var indent = rawLine.length - rawLine.replace(/^\s+/, "").length;
          var t = rawLine.trim();
          if (t.charAt(0) === "#") continue;
          t = stripComment(t).trim();
          if (t === "" || t === "---") continue;

          while (stack.length && indent <= stack[stack.length - 1].indent) stack.pop();
          var parentPath = stack.length ? stack[stack.length - 1].path : "";

          if (t.indexOf("- ") === 0 || t === "-") {
            var item = t === "-" ? "" : t.substring(2).trim();
            handleListItem(item, parentPath, lineNo, p, format);
            continue;
          }
          var m = t.match(/^([A-Za-z_][A-Za-z0-9_.-]*)\s*:\s*(.*)$/);
          if (!m) {
            addNotParsed(p, lineNo, "Line could not be parsed as a YAML key: value pair.");
            continue;
          }
          var key = m[1];
          var value = m[2];
          var path = parentPath ? parentPath + "." + key : key;

          /* compose environment may be a mapping: QDRANT__SERVICE__API_KEY: value */
          if (/^QDRANT__[A-Z0-9_]+$/.test(key)) {
            var ep = key.substring(8).toLowerCase().split("__").join(".");
            addEntry(p, ep, ep.split(".").pop(), stripQuotes(value), lineNo);
            continue;
          }
          if (value === "" || value === "|" || value === ">") {
            stack.push({ indent: indent, path: path });
            listContext = { indent: indent, path: path };
            continue;
          }
          addEntry(p, path, key, stripQuotes(value), lineNo);
        }
      }

      function handleListItem(item, parentPath, lineNo, p, format) {
        if (item === "") return;
        /* compose environment list item: QDRANT__...=value */
        var em = item.match(/^(QDRANT__[A-Z0-9_]+)\s*=\s*(.*)$/);
        if (em) {
          var ep = em[1].substring(8).toLowerCase().split("__").join(".");
          addEntry(p, ep, ep.split(".").pop(), stripQuotes(stripComment(em[2])), lineNo);
          return;
        }
        /* compose ports list item: [ip:]hostPort:containerPort[/proto] */
        if (/(^|\.)ports$/.test(parentPath) || format === "docker-compose") {
          var pm = item.replace(/["']/g, "").match(/^(?:(\d{1,3}(?:\.\d{1,3}){3})|\[?::\]?|localhost)?:?(\d{1,5}):(\d{1,5})(?:\/(tcp|udp))?$/);
          if (pm) {
            p.entries.push({
              path: "(compose-port)", key: "port",
              value: JSON.stringify({ bind: pm[1] || null, hostPort: pm[2], containerPort: pm[3] }),
              line: lineNo
            });
            return;
          }
        }
        addNotParsed(p, lineNo, "List item under \"" + (parentPath || "root") + "\" is not a form this auditor can grade — skipped, not guessed.");
      }

      /* ---------- audit ---------- */
      function find(entries, path) {
        for (var i = entries.length - 1; i >= 0; i--) if (entries[i].path === path) return entries[i];
        return null;
      }
      function findSuffix(entries, suffix) {
        /* last path segment chain match, e.g. ".service.api_key" inside compose nesting */
        var out = [];
        for (var i = 0; i < entries.length; i++) {
          if (entries[i].path === suffix || entries[i].path.slice(-(suffix.length + 1)) === "." + suffix) out.push(entries[i]);
        }
        return out.length ? out[out.length - 1] : null;
      }

      function knownKeyVerdict(path) {
        var parts = path.split(".");
        /* compose nesting: services.<name>.… — audit the tail after the service name */
        var si = parts.indexOf("services");
        if (si >= 0 && parts.length > si + 2) parts = parts.slice(si + 2);
        if (parts[0] === "services") return { known: true }; /* compose scaffolding */
        if (parts.length === 1) return { known: !!KNOWN_TOP[parts[0]] || parts[0] === "services" || parts[0] === "version" || parts[0] === "volumes" || parts[0] === "networks" || ["image", "container_name", "restart", "ports", "environment", "command", "entrypoint", "depends_on", "healthcheck", "deploy", "build", "expose", "user", "working_dir"].indexOf(parts[0]) >= 0 };
        if (parts[0] === "service") {
          if (parts.length === 2) return { known: !!KNOWN_SERVICE[parts[1]] };
          if (parts[1] === "tls_config") return { known: parts.length === 3 && !!KNOWN_TLS[parts[2]] };
          return { known: false };
        }
        if (parts[0] === "storage") {
          if (parts.length === 2) return { known: !!KNOWN_STORAGE[parts[1]] };
          return { known: true }; /* nested optimizer/hnsw sub-keys: recognized family */
        }
        if (parts[0] === "cluster") {
          if (parts.length === 2) return { known: !!KNOWN_CLUSTER[parts[1]] };
          if (parts[1] === "p2p" && parts.length === 3) return { known: !!KNOWN_P2P[parts[2]] };
          return { known: false };
        }
        if (parts[0] === "telemetry") {
          if (parts.length === 2) return { known: !!KNOWN_TELEMETRY[parts[1]] };
          return { known: false };
        }
        /* compose service-level keys */
        if (["image", "container_name", "restart", "ports", "environment", "volumes", "command", "entrypoint", "depends_on", "healthcheck", "deploy", "build", "expose", "networks", "user", "working_dir"].indexOf(parts[0]) >= 0) return { known: true };
        return { known: false };
      }

      function audit(text) {
        var format = detectFormat(text);
        var p = newParse();
        if (format === "empty") return null;
        if (format === "env") parseEnvText(text, p, 0);
        else if (format === "flags") parseFlagsText(text, p);
        else parseYamlText(text, p, format);

        var findings = [];
        function add(sev, line, title, body) {
          findings.push({ severity: sev, line: line, title: title, body: body });
        }

        var entries = p.entries;

        /* --- compose published ports -> synthetic exposure entries --- */
        var composePorts = [];
        for (var ci = 0; ci < entries.length; ci++) {
          if (entries[ci].path === "(compose-port)") {
            try { composePorts.push(JSON.parse(entries[ci].value)); composePorts[composePorts.length - 1].line = entries[ci].line; } catch (e) {}
          }
        }

        /* --- resolve core settings (suffix match so compose nesting works) --- */
        var apiKey = findSuffix(entries, "service.api_key");
        var roKey = findSuffix(entries, "service.read_only_api_key");
        var hostE = findSuffix(entries, "service.host");
        var httpPortE = findSuffix(entries, "service.http_port");
        var grpcPortE = findSuffix(entries, "service.grpc_port");
        var tlsEnableE = findSuffix(entries, "service.enable_tls");
        var tlsCertE = findSuffix(entries, "service.tls_config.cert");
        var tlsKeyE = findSuffix(entries, "service.tls_config.key");
        var tlsCaE = findSuffix(entries, "service.tls_config.ca_cert");
        var tlsChainE = findSuffix(entries, "service.tls_config.cert_chain");
        var telemetryE = find(entries, "telemetry_disabled") || findSuffix(entries, "telemetry_disabled");
        var clusterE = findSuffix(entries, "cluster.enabled");
        var p2pE = findSuffix(entries, "cluster.p2p.port");
        var corsE = findSuffix(entries, "service.enable_cors");

        /* --- exposure model --- */
        var httpPort = httpPortE ? parseInt(httpPortE.value, 10) : 6333;
        if (isNaN(httpPort)) httpPort = 6333;
        var grpcPort = grpcPortE ? parseInt(grpcPortE.value, 10) : 6334;
        if (isNaN(grpcPort)) grpcPort = 6334;

        var hostVal = hostE ? String(hostE.value) : null;
        var localhostOnly = false, exposedAll = false, hostKnown = false;
        if (hostVal !== null && hostVal !== "") {
          hostKnown = true;
          if (isLocalhostHost(hostVal)) localhostOnly = true;
          else if (isAllInterfaces(hostVal)) exposedAll = true;
          else localhostOnly = false; /* a specific non-local IP is network-facing */
        }
        var publishedExternal = false, publishedLocal = false, publishedAny = false;
        for (var pi = 0; pi < composePorts.length; pi++) {
          var cp = composePorts[pi];
          if (cp.containerPort === "6333" || cp.containerPort === "6334" || cp.containerPort === "6335") {
            publishedAny = true;
            if (cp.bind === "127.0.0.1") publishedLocal = true;
            else publishedExternal = true;
          }
        }
        if (publishedExternal) { exposedAll = true; localhostOnly = false; }
        if (!hostKnown && publishedAny && publishedLocal && !publishedExternal) localhostOnly = true;
        if (!hostKnown && !publishedAny) {
          /* Qdrant default: service.host defaults to 0.0.0.0 */
          exposedAll = true;
        }
        var networkExposed = !localhostOnly;

        /* --- TLS model --- */
        var tlsRefs = [];
        if (tlsCertE) tlsRefs.push("cert (line " + tlsCertE.line + ")");
        if (tlsKeyE) tlsRefs.push("key (line " + tlsKeyE.line + ")");
        if (tlsCaE) tlsRefs.push("ca_cert (line " + tlsCaE.line + ")");
        if (tlsChainE) tlsRefs.push("cert_chain (line " + tlsChainE.line + ")");
        var tlsEnabled = tlsEnableE ? isTruthy(tlsEnableE.value) : null;
        var tlsConfigured = tlsRefs.length > 0 || tlsEnabled === true;

        /* ============ CHECKS ============ */

        /* 1 — api_key presence */
        var apiKeyEffective = false;
        if (!apiKey) {
          if (networkExposed) {
            add("BLOCKER", hostE ? hostE.line : (httpPortE ? httpPortE.line : null),
              "service.api_key — missing entirely on a network-exposed bind",
              "No service.api_key is set anywhere in this configuration, and the server is not bound to localhost only. Anyone who can reach the REST port (" + httpPort + ") or gRPC port (" + grpcPort + ") can read, write, and delete every collection with no credential at all. Set a long random service.api_key before this goes anywhere near a network.");
          } else {
            add("WARNING", hostE ? hostE.line : null,
              "service.api_key — missing (localhost-only bind)",
              "No service.api_key is set. The localhost-only binding is the only thing protecting this instance: any local process, forwarded port, or future bind change exposes full read/write/delete access with no credential. Set a service.api_key anyway — defense in depth costs one line.");
          }
        } else if (String(apiKey.value).trim() === "") {
          if (networkExposed) {
            add("BLOCKER", apiKey.line, "service.api_key — set but empty on a network-exposed bind",
              "service.api_key is present on line " + apiKey.line + " but its value is empty (length 0), which is the same as no key at all while the server is reachable beyond localhost. Set a long random value.");
          } else {
            add("WARNING", apiKey.line, "service.api_key — set but empty",
              "service.api_key on line " + apiKey.line + " has an empty value (length 0). An empty key is no key — set a long random value.");
          }
        } else {
          var kv = String(apiKey.value);
          if (isPlaceholder(kv)) {
            add(networkExposed ? "BLOCKER" : "WARNING", apiKey.line,
              "service.api_key — placeholder value (length " + kv.length + ")",
              "The value of service.api_key on line " + apiKey.line + " is a recognizable placeholder (reported by length only: " + kv.length + " characters). A placeholder key is public knowledge — anyone can guess it. Replace it with a long random secret before deploying.");
          } else {
            apiKeyEffective = true;
            if (kv.length < 16) {
              add("WARNING", apiKey.line, "service.api_key — very short (length " + kv.length + ")",
                "service.api_key on line " + apiKey.line + " is only " + kv.length + " characters long. Short keys fall to brute force and guessing. Use at least 32 random characters.");
            } else if (kv.length < 32) {
              add("INFO", apiKey.line, "service.api_key — present, moderate length (" + kv.length + ")",
                "service.api_key is set on line " + apiKey.line + " with a length of " + kv.length + " characters (value never shown). Workable, but 32+ random characters is the safer bar for a full-access key.");
            } else {
              add("INFO", apiKey.line, "service.api_key — present, strong length (" + kv.length + ")",
                "service.api_key is set on line " + apiKey.line + " with a length of " + kv.length + " characters (value never shown). Length is only one part of key quality — this audit cannot verify the key is random or that it works.");
            }
          }
        }

        /* 2 — read_only_api_key posture */
        if (roKey && String(roKey.value).trim() !== "") {
          var rv = String(roKey.value);
          if (apiKey && String(apiKey.value) !== "" && rv === String(apiKey.value)) {
            add("WARNING", roKey.line, "service.read_only_api_key — identical to the full-access key",
              "service.read_only_api_key (line " + roKey.line + ", length " + rv.length + ") is identical to service.api_key. Holders of the \"read-only\" key would actually have full read/write/delete access. Give the read-only key its own distinct random value.");
          } else if (isPlaceholder(rv)) {
            add("WARNING", roKey.line, "service.read_only_api_key — placeholder value (length " + rv.length + ")",
              "service.read_only_api_key on line " + roKey.line + " is a recognizable placeholder (length " + rv.length + ", value never shown). Anyone can guess it and read every collection. Replace it with a random value.");
          } else {
            add("INFO", roKey.line, "service.read_only_api_key — present (length " + rv.length + ")",
              "A separate read-only key is set on line " + roKey.line + " (length " + rv.length + ", value never shown). Remember what it is and is not: it grants read access only — it never substitutes for the full-access service.api_key, and handing it out still exposes all collection data to its holder.");
            if (rv.length < 16) {
              add("WARNING", roKey.line, "service.read_only_api_key — very short (length " + rv.length + ")",
                "The read-only key on line " + roKey.line + " is only " + rv.length + " characters. Read access is still full data exposure — use 32+ random characters.");
            }
          }
        } else if (!roKey) {
          add("INFO", null, "service.read_only_api_key — not set",
            "No read-only key is configured. That is fine if nothing needs read-only access — just do not hand the full-access service.api_key to read-only consumers as a substitute.");
        }

        /* 3 — host binding */
        if (hostKnown && isAllInterfaces(hostVal)) {
          if (!apiKeyEffective) {
            add("BLOCKER", hostE.line, "service.host — bound to all interfaces (" + hostVal + ") with no effective API key",
              "Line " + hostE.line + " binds Qdrant to every network interface. Combined with the missing or placeholder API key above, the REST port (" + httpPort + "), gRPC port (" + grpcPort + "), and the web dashboard are open to anyone who can route to this machine. Bind to 127.0.0.1 or set a real service.api_key — ideally both.");
          } else {
            add("WARNING", hostE.line, "service.host — bound to all interfaces (" + hostVal + ")",
              "Line " + hostE.line + " binds Qdrant to every network interface. The API key is the only gate on ports " + httpPort + "/" + grpcPort + ". Prefer binding 127.0.0.1 behind a reverse proxy, or firewall these ports to known clients.");
          }
        } else if (hostKnown && isLocalhostHost(hostVal)) {
          add("INFO", hostE.line, "service.host — localhost-only (" + hostVal + ")",
            "Binding to " + hostVal + " (line " + hostE.line + ") keeps Qdrant off the network. Anything that later re-binds it — a compose port publish, a proxy, a host change — re-opens every finding that depends on exposure.");
        } else if (hostKnown) {
          add("WARNING", hostE.line, "service.host — bound to a specific network address (" + hostVal + ")",
            "Line " + hostE.line + " binds Qdrant to " + hostVal + ", which is reachable from that network. This audit treats it as network-exposed: the API key and TLS findings above carry their full weight.");
        } else if (format !== "docker-compose") {
          add("INFO", null, "service.host — not set (Qdrant default applies)",
            "No service.host appears in this configuration, so Qdrant's default bind of 0.0.0.0 (all interfaces) applies at startup. If this host is reachable from a network, treat the exposure findings as live, not theoretical.");
        }

        /* compose published ports */
        for (var pj = 0; pj < composePorts.length; pj++) {
          var cpj = composePorts[pj];
          var label = (cpj.bind ? cpj.bind + ":" : "") + cpj.hostPort + " → " + cpj.containerPort;
          if (cpj.bind === "127.0.0.1") {
            add("INFO", cpj.line, "docker-compose port publish — localhost-only (" + label + ")",
              "Line " + cpj.line + " publishes container port " + cpj.containerPort + " on 127.0.0.1 only. Good — the publish does not widen exposure beyond this host.");
          } else {
            if (!apiKeyEffective && (cpj.containerPort === "6333" || cpj.containerPort === "6334")) {
              add("BLOCKER", cpj.line, "docker-compose port publish — " + label + " on all interfaces with no effective API key",
                "Line " + cpj.line + " publishes Qdrant port " + cpj.containerPort + " to every interface on the Docker host, and there is no effective API key. Anyone who can reach the Docker host can use this port. Bind it as 127.0.0.1:" + cpj.hostPort + ":" + cpj.containerPort + " or set a real service.api_key.");
            } else {
              add("WARNING", cpj.line, "docker-compose port publish — " + label + " on all interfaces",
                "Line " + cpj.line + " publishes Qdrant port " + cpj.containerPort + " to every interface on the Docker host. Docker port publishes bypass many host firewall setups — make sure that reach is intended and the API key is strong.");
            }
          }
        }

        /* 4 — TLS */
        if (tlsConfigured) {
          var tlsLine = tlsCertE ? tlsCertE.line : (tlsEnableE ? tlsEnableE.line : null);
          add("INFO", tlsLine, "TLS — configured",
            "TLS settings are present (" + (tlsRefs.length ? tlsRefs.join(", ") : "enable_tls on line " + (tlsEnableE ? tlsEnableE.line : "?")) + "). This text audit confirms the settings exist; it cannot verify the certificate files exist, chain correctly, or are unexpired — check that on the host.");
          if (tlsEnabled === false && tlsRefs.length > 0) {
            add("WARNING", tlsEnableE.line, "TLS — certificate referenced but enable_tls is false",
              "tls_config certificate material is present, yet enable_tls is explicitly false (line " + tlsEnableE.line + "). The server will serve plaintext. Remove the contradiction before deploying.");
          }
        } else if (networkExposed) {
          add("WARNING", null, "TLS — not configured on a network-exposed bind",
            "No tls_config / certificate settings appear, and the server is reachable beyond localhost. API keys and vector data will cross the network in plaintext on ports " + httpPort + "/" + grpcPort + ". Configure TLS (service.tls_config with cert and key) or terminate TLS at a proxy in front of a localhost bind.");
        } else {
          add("INFO", null, "TLS — not configured (localhost-only bind)",
            "No TLS settings appear. On a strictly localhost-only bind that is a defensible choice; the moment this config is bound or published beyond localhost, plaintext HTTP/gRPC becomes a finding, not a detail.");
        }

        /* 5 — telemetry + dashboard */
        if (telemetryE) {
          if (isTruthy(telemetryE.value)) {
            add("INFO", telemetryE.line, "telemetry_disabled — true (telemetry off)",
              "Line " + telemetryE.line + " disables Qdrant's anonymous usage telemetry. Nothing phones home from this config on that front.");
          } else if (isFalsy(telemetryE.value)) {
            add("WARNING", telemetryE.line, "telemetry_disabled — false (telemetry on)",
              "Line " + telemetryE.line + " explicitly leaves telemetry enabled: this instance will send anonymous usage statistics to Qdrant's telemetry endpoint. On an internal or regulated deployment, set telemetry_disabled: true.");
          } else {
            add("INFO", telemetryE.line, "telemetry_disabled — unrecognized value",
              "telemetry_disabled on line " + telemetryE.line + " has a value this auditor cannot read as true or false. Set it explicitly to true to disable telemetry.");
          }
        } else {
          add("INFO", null, "telemetry_disabled — not set (Qdrant default: telemetry on)",
            "telemetry_disabled does not appear in this configuration, so Qdrant's default applies and anonymous usage telemetry is sent. Set telemetry_disabled: true if that outbound traffic is not acceptable.");
        }

        if (networkExposed) {
          add("INFO", httpPortE ? httpPortE.line : null, "Web dashboard — served on the exposed REST port",
            "Qdrant serves its web dashboard on the same REST port (" + httpPort + "). Because that port is reachable beyond localhost, the dashboard is too — the API key is the only thing standing between the network and it. There is no separate dashboard password.");
        } else {
          add("INFO", null, "Web dashboard — localhost-only reach",
            "The web dashboard rides on the REST port (" + httpPort + "), which this configuration keeps on localhost. Keep it that way, or the dashboard inherits full network exposure.");
        }

        /* 6 — CORS */
        if (corsE && isTruthy(corsE.value)) {
          add("INFO", corsE.line, "service.enable_cors — true",
            "CORS is enabled (line " + corsE.line + "). Browser pages from other origins can call this API; the API key remains the gate, but do not embed the full-access key in any web page.");
        }

        /* 7 — cluster / p2p */
        if (clusterE && isTruthy(clusterE.value)) {
          if (networkExposed) {
            add("WARNING", clusterE.line, "cluster.enabled — true on a network-exposed node (p2p port " + (p2pE ? p2pE.value : "6335") + ")",
              "Cluster mode is on (line " + clusterE.line + "). The peer-to-peer port (" + (p2pE ? p2pE.value : "6335 default") + ") must be reachable by cluster peers and by nobody else — it is not a client API and should never face a general network. Firewall it to peer addresses only.");
          } else {
            add("INFO", clusterE.line, "cluster.enabled — true",
              "Cluster mode is on (line " + clusterE.line + "), p2p port " + (p2pE ? p2pE.value + " (line " + p2pE.line + ")" : "6335 (default)") + ". Keep p2p reachable only between cluster peers.");
          }
        } else if (clusterE && isFalsy(clusterE.value)) {
          add("INFO", clusterE.line, "cluster.enabled — false (single node)",
            "Cluster mode is explicitly off (line " + clusterE.line + "). No p2p port exposure from this configuration.");
        }

        /* 8 — unknown keys -> NOT PARSED / INFO */
        var seenUnknown = {};
        for (var ui = 0; ui < entries.length; ui++) {
          var e = entries[ui];
          if (e.path === "(compose-port)") continue;
          var kv = knownKeyVerdict(e.path);
          if (!kv.known) {
            var ukey = e.path + "@" + e.line;
            if (seenUnknown[ukey]) continue;
            seenUnknown[ukey] = true;
            findings.push({
              severity: "NOT PARSED", line: e.line,
              title: "Unrecognized key — " + e.path,
              body: "Line " + e.line + " sets \"" + e.path + "\", which is not a Qdrant configuration key this auditor recognizes. It was recorded, not silently ignored — but nothing about it was audited. Check for typos: a misspelled security key (for example under service) means the protection you think is on may not exist."
            });
          }
        }

        /* 9 — unparsed lines */
        for (var ni = 0; ni < p.notParsed.length; ni++) {
          findings.push({
            severity: "NOT PARSED", line: p.notParsed[ni].line,
            title: "Line " + p.notParsed[ni].line + " — not parsed",
            body: p.notParsed[ni].description + " Unparsed content is never guessed at and never audited."
          });
        }

        /* verdict */
        var counts = { BLOCKER: 0, WARNING: 0, INFO: 0, "NOT PARSED": 0 };
        for (var fi = 0; fi < findings.length; fi++) counts[findings[fi].severity]++;

        var order = { BLOCKER: 0, WARNING: 1, INFO: 2, "NOT PARSED": 3 };
        findings.sort(function (a, b) {
          if (order[a.severity] !== order[b.severity]) return order[a.severity] - order[b.severity];
          var la = a.line == null ? 9999 : a.line, lb = b.line == null ? 9999 : b.line;
          return la - lb;
        });

        var verdict, vclass, why;
        if (counts.BLOCKER > 0) {
          verdict = "DO NOT DEPLOY"; vclass = "bad";
          why = counts.BLOCKER + " blocker finding" + (counts.BLOCKER === 1 ? "" : "s") + " — this configuration starts fine and exposes the database anyway. Fix every blocker before this goes on a network.";
        } else if (counts.WARNING > 0) {
          verdict = "DEPLOY WITH FIXES"; vclass = "mid";
          why = "No blockers, but " + counts.WARNING + " warning" + (counts.WARNING === 1 ? "" : "s") + " to fix before this is a configuration you can defend.";
        } else {
          verdict = "SAFE TO DEPLOY"; vclass = "ok";
          why = "No blockers and no warnings in the pasted configuration. This is a heuristic text audit — it does not verify the certificate files, the key's randomness, or anything on the server itself.";
        }

        return {
          format: format, formatLabel: FORMAT_LABELS[format],
          verdict: verdict, vclass: vclass, why: why,
          counts: counts, findings: findings
        };
      }

      /* ---------- reports ---------- */
      function buildTextReport(r) {
        var out = [];
        out.push("J-Dawgs Qdrant Server Config Safety Auditor™ — audit report");
        out.push("Format detected: " + r.formatLabel);
        out.push("Verdict: " + r.verdict);
        out.push("Findings: " + r.counts.BLOCKER + " BLOCKER / " + r.counts.WARNING + " WARNING / " + r.counts.INFO + " INFO / " + r.counts["NOT PARSED"] + " NOT PARSED");
        out.push("");
        var groups = ["BLOCKER", "WARNING", "INFO", "NOT PARSED"];
        for (var g = 0; g < groups.length; g++) {
          var items = r.findings.filter(function (f) { return f.severity === groups[g]; });
          if (!items.length) continue;
          out.push("== " + groups[g] + " (" + items.length + ") ==");
          for (var i = 0; i < items.length; i++) {
            var f = items[i];
            out.push("- [" + (f.line != null ? "line " + f.line : "no line") + "] " + f.title);
            out.push("  " + f.body);
          }
          out.push("");
        }
        out.push("Notes: heuristic text audit of pasted configuration only. No server was contacted; no key was verified. Secret values are never printed — keys are reported by name, line, and length only.");
        return out.join("\n");
      }
      function buildJsonReport(r) {
        var obj = {
          tool: "J-Dawgs Qdrant Server Config Safety Auditor",
          format_detected: r.formatLabel,
          verdict: r.verdict,
          counts: {
            blocker: r.counts.BLOCKER, warning: r.counts.WARNING,
            info: r.counts.INFO, not_parsed: r.counts["NOT PARSED"]
          },
          findings: r.findings.map(function (f) {
            return { severity: f.severity, line: f.line, title: f.title, detail: f.body };
          }),
          notes: "Heuristic text audit of pasted configuration only. No server contacted; no key verified. Secret values are never included — keys are reported by name, line, and length only."
        };
        return JSON.stringify(obj, null, 2);
      }

      /* ---------- UI wiring ---------- */
      var lastTextReport = "", lastJsonReport = "";
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-qdrant-server-config-safety-auditortm',
  name: 'J-Dawgs Qdrant Server Config Safety Auditor',
  description: 'Qdrant\'s own checks only answer whether the server starts on the host; ours grades a pasted Qdrant vector database config (YAML / env / flags / compose) fully offline — API-key presence, bind exposure, and TLS all graded, with secrets shown by key name and length only — into one deploy verdict: SAFE',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
