'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Samba Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------------- Worked examples ---------------- */
      var RISKY_EXAMPLE = [
        "# RISKY worked example - a small office file server with real problems planted in it.",
        "[global]",
        "   workgroup = WORKGROUP",
        "   server string = Office file server",
        "   server min protocol = NT1",
        "   security = user",
        "   map to guest = Bad User",
        "   encrypt passwords = yes",
        "   unix extensions = no",
        "",
        "[public]",
        "   path = /srv/public",
        "   guest ok = yes",
        "   read only = no",
        "   browseable = yes",
        "   wide links = yes"
      ].join("\n");

      var CLEAN_EXAMPLE = [
        "# CLEAN worked example - a locked-down team share.",
        "[global]",
        "   workgroup = WORKGROUP",
        "   server min protocol = SMB2",
        "   security = user",
        "   map to guest = Never",
        "   encrypt passwords = yes",
        "   hosts allow = 192.168.1. 127.0.0.1",
        "",
        "[team]",
        "   path = /srv/team",
        "   valid users = @team",
        "   guest ok = no",
        "   read only = no",
        "   browseable = yes",
        "   create mask = 0660",
        "   hide dot files = yes"
      ].join("\n");

      /* ---------------- Parsing helpers ---------------- */
      function canonKey(raw) {
        var k = raw.toLowerCase().replace(/_/g, " ").replace(/\s+/g, " ").trim();
        if (k === "writeable") k = "writable";
        if (k === "browsable") k = "browseable";
        if (k === "public") k = "guest ok";
        return k;
      }
      function parseBool(v) {
        if (v == null) return null;
        var t = String(v).trim().toLowerCase();
        if (t === "yes" || t === "true" || t === "1" || t === "on") return true;
        if (t === "no" || t === "false" || t === "0" || t === "off") return false;
        return null;
      }
      function protoRank(v) {
        var t = String(v).trim().toUpperCase().replace(/[\s_-]/g, "");
        if (t === "CORE" || t === "COREPLUS" || t === "COREP" ||
            t === "LANMAN1" || t === "LANMAN2" || t === "NT1" || t === "SMB1") return 1;
        if (t.indexOf("SMB2") === 0 || t === "SMB2_02" || t === "SMB210") return 2;
        if (t.indexOf("SMB3") === 0) return 3;
        return 0; // unrecognized
      }

      /* Keys that contain password-like words but never hold a secret value. */
      var NON_SECRET_KEYS = {
        "encrypt passwords": true,
        "unix password sync": true,
        "passwd program": true,
        "passwd chat": true,
        "passwd chat debug": true,
        "passdb backend": true,
        "password server": true,
        "password level": true,
        "null passwords": true,
        "pam password change": true,
        "ldap password sync": true,
        "smb passwd file": true,
        "machine password timeout": true,
        "obey pam restrictions": true
      };
      var SECRET_KEY_RE = /(password|passwd|secret|credential|api[\s-]?key|auth[\s-]?token|private[\s-]?key)/i;
      var SAFE_SECRET_VALUES = { "yes": 1, "no": 1, "true": 1, "false": 1, "": 1 };

      function looksLikeSecret(keyDisplay, value) {
        var ck = canonKey(keyDisplay);
        if (NON_SECRET_KEYS[ck]) return false;
        if (!SECRET_KEY_RE.test(ck)) return false;
        var v = String(value == null ? "" : value).trim().toLowerCase();
        if (SAFE_SECRET_VALUES[v]) return false;
        return true;
      }

      /* ---------------- The audit ---------------- */
      function auditConfig(text) {
        var findings = [];
        function add(line, severity, section, key, message, fix) {
          findings.push({ line: line, severity: severity, section: section || "", key: key || "", message: message, fix: fix || "" });
        }

        var sections = [];           // [{name, line, entries:{canonKey:{key,value,line}}}]
        var byName = {};
        var current = null;
        var skipNext = false;
        var sawAnySection = false;

        var lines = String(text).split(/\r?\n/);
        for (var i = 0; i < lines.length; i++) {
          var lineNo = i + 1;
          var raw = lines[i];

          if (skipNext) { skipNext = false; continue; }

          // Continuation line: smb.conf joins it to the next line. We do not
          // reconstruct it - report it and leave both lines out.
          if (/\\\s*$/.test(raw) && raw.trim() !== "") {
            add(lineNo, "WARNING", current ? current.name : "", "",
              "Continuation line (ends with a backslash) — NOT PARSED. This audit reads one setting per line, so this setting and the line it continues onto were left out of the grading.",
              "Join the continued lines into a single line and re-run the audit to have this setting graded.");
            skipNext = true;
            continue;
          }

          var t = raw.trim();
          if (t === "") continue;
          if (t.charAt(0) === "#" || t.charAt(0) === ";") continue;

          var secMatch = t.match(/^\[\s*([^\]]+?)\s*\]$/);
          if (secMatch) {
            sawAnySection = true;
            var sname = secMatch[1];
            var lname = sname.toLowerCase();
            if (byName[lname]) {
              current = byName[lname];
            } else {
              current = { name: sname, line: lineNo, entries: {} };
              byName[lname] = current;
              sections.push(current);
            }
            continue;
          }
          if (t.charAt(0) === "[") {
            add(lineNo, "WARNING", current ? current.name : "", "",
              "Malformed section header — this line was reported and excluded from the audit.",
              "Write section headers as [name] on their own line.");
            continue;
          }

          var eq = t.indexOf("=");
          if (eq === -1) {
            add(lineNo, "WARNING", current ? current.name : "", "",
              "Malformed line — it is not a “key = value” setting, so it was reported and excluded from the audit.",
              "Give the line the form key = value, or remove it.");
            continue;
          }
          var keyRaw = t.slice(0, eq).trim();
          var value = t.slice(eq + 1).trim();
          if (!current) {
            add(lineNo, "WARNING", "", keyRaw,
              "Setting appears before any [section] header — reported and excluded from the audit.",
              "Move it under a [global] or share section header.");
            continue;
          }
          var ck = canonKey(keyRaw);

          if (ck === "include") {
            add(lineNo, "WARNING", current.name, keyRaw,
              "An “include” setting points at another file — includes are NOT FOLLOWED by this audit, so anything in that file is ungraded.",
              "Paste the included file's contents in place of the include line if you want them graded.");
            continue;
          }

          if (looksLikeSecret(keyRaw, value)) {
            add(lineNo, "WARNING", current.name, keyRaw,
              "Possible stored secret: the key “" + keyRaw + "” on this line appears to hold a password or secret value in plain text. (The value is never shown in this audit's output.)",
              "Remove secrets from smb.conf — Samba keeps account passwords in its own password database, not in this file. Treat the value as exposed and change it wherever it was used.");
          }

          current.entries[ck] = { key: keyRaw, value: value, line: lineNo };
        }

        var globalSec = byName["global"] || null;
        var g = globalSec ? globalSec.entries : {};
        var gLine = globalSec ? globalSec.line : 1;
        var gName = globalSec ? globalSec.name : "global";

        function gEntry(k) { return g[k] || null; }

        /* ---- Global checks ---- */
        var proto = gEntry("server min protocol") || gEntry("min protocol");
        if (proto) {
          var rank = protoRank(proto.value);
          if (rank === 1) {
            add(proto.line, "BLOCKER", gName, proto.key,
              "“server min protocol” is set to " + proto.value.trim() + " — that is SMB1-era protocol. SMB1 has known remote-attack flaws and has been removed or disabled by default in modern systems for exactly that reason.",
              "Set server min protocol = SMB2 (or SMB3) in [global].");
          } else if (rank === 0) {
            add(proto.line, "WARNING", gName, proto.key,
              "The “server min protocol” value “" + proto.value.trim() + "” is not a protocol name this audit recognizes, so the protocol floor could not be graded.",
              "Use a standard value such as SMB2 or SMB3.");
          } else {
            add(proto.line, "INFO", gName, proto.key,
              "“server min protocol” is " + proto.value.trim() + " — the floor is SMB2 or newer, so SMB1 clients are refused.",
              "");
          }
        } else {
          add(gLine, "WARNING", gName, "server min protocol",
            "No “server min protocol” is set in [global]. The server then falls back to whatever default its Samba build was compiled with — on some builds that default still allows SMB1-era clients.",
            "Add server min protocol = SMB2 (or SMB3) to [global] so the floor is explicit.");
        }

        var secMode = gEntry("security");
        if (secMode) {
          add(secMode.line, "INFO", gName, secMode.key,
            "“security” mode is “" + secMode.value.trim() + "” — noted. (“user” is the normal modern choice: each person logs in with their own account.)",
            "");
        } else {
          add(gLine, "INFO", gName, "security",
            "No “security” mode is set — Samba's default (user) applies: each person logs in with their own account.",
            "");
        }

        var mtg = gEntry("map to guest");
        if (mtg) {
          var mtgVal = mtg.value.trim().toLowerCase();
          if (mtgVal === "bad user" || mtgVal === "always") {
            add(mtg.line, "WARNING", gName, mtg.key,
              "“map to guest” is “" + mtg.value.trim() + "” — logins that fail or name unknown users are silently turned into guest sessions instead of being refused. Combined with any guest share, strangers get in without a real account.",
              "Set map to guest = Never unless you deliberately run guest shares, and then restrict those shares hard.");
          } else if (mtgVal === "bad password") {
            add(mtg.line, "INFO", gName, mtg.key,
              "“map to guest” is “Bad Password” — a known username with a wrong password falls back to guest. Noted; “Never” is the stricter choice.",
              "");
          } else {
            add(mtg.line, "INFO", gName, mtg.key,
              "“map to guest” is “" + mtg.value.trim() + "” — failed logins are not turned into guest sessions. Good posture.",
              "");
          }
        }

        var ga = gEntry("guest account");
        if (ga) {
          if (ga.value.trim().toLowerCase() === "root") {
            add(ga.line, "BLOCKER", gName, ga.key,
              "“guest account” is root — guest sessions would run with full control of the machine.",
              "Point guest account at an unprivileged account (for example “nobody”), or remove guest access entirely.");
          } else {
            add(ga.line, "INFO", gName, ga.key,
              "“guest account” is set to an unprivileged account — guest sessions run as that account. Noted.",
              "");
          }
        }

        var enc = gEntry("encrypt passwords");
        if (enc && parseBool(enc.value) === false) {
          add(enc.line, "BLOCKER", gName, enc.key,
            "“encrypt passwords = no” — passwords would be handled in plain text on the wire and checked against the system password file. Modern Windows clients refuse this, and anyone watching the network can read credentials.",
            "Set encrypt passwords = yes (the modern default).");
        }

        // Bind posture: local-only only if bound to loopback interfaces.
        var ifaces = gEntry("interfaces");
        var bindOnly = gEntry("bind interfaces only");
        var localOnly = false;
        if (ifaces && parseBool(bindOnly && bindOnly.value) === true) {
          var toks = ifaces.value.trim().split(/[\s,]+/).filter(Boolean);
          localOnly = toks.length > 0 && toks.every(function (tk) {
            var x = tk.toLowerCase();
            return x === "lo" || x === "localhost" || x.indexOf("127.") === 0 || x === "::1";
          });
        }
        var hostsAllow = gEntry("hosts allow");
        if (!hostsAllow && !localOnly) {
          add(gLine, "WARNING", gName, "hosts allow",
            "No “hosts allow” in [global], and the server is not bound to this machine only — the shares answer connection attempts from any network this machine is attached to.",
            "Add a hosts allow line naming your own network (for example your LAN range plus 127.0.0.1), or bind the server to a trusted interface only.");
        } else if (hostsAllow) {
          add(hostsAllow.line, "INFO", gName, hostsAllow.key,
            "“hosts allow” is set — connections are limited to the networks it names. Noted.",
            "");
        }

        var ups = gEntry("unix password sync");
        if (ups && parseBool(ups.value) === true) {
          add(ups.line, "INFO", gName, ups.key,
            "“unix password sync” is on — Samba password changes also update the system password. Noted for awareness; not a finding against the config.",
            "");
        }
        var pchat = gEntry("passwd chat");
        if (pchat) {
          add(pchat.line, "INFO", gName, pchat.key,
            "A “passwd chat” script is defined — it drives the password-change conversation with the system passwd program. Noted only.",
            "");
        }

        var gWide = gEntry("wide links");
        var unixExt = gEntry("unix extensions");
        var unixExtOff = unixExt ? parseBool(unixExt.value) === false : false;

        /* ---- Per-share checks ---- */
        var shares = [];
        sections.forEach(function (sec) {
          if (sec.name.toLowerCase() === "global") return;
          var e = sec.entries;
          function ent(k) { return e[k] || null; }

          var pathE = ent("path");
          var pathVal = pathE ? pathE.value.trim() : "";
          var guestE = ent("guest ok");
          var guestOnlyE = ent("guest only");
          var guest = (guestE && parseBool(guestE.value) === true) ||
                      (guestOnlyE && parseBool(guestOnlyE.value) === true);
          var roE = ent("read only");
          var wrE = ent("writable") || ent("write ok");
          var writable;
          if (roE && parseBool(roE.value) !== null) writable = !parseBool(roE.value);
          else if (wrE && parseBool(wrE.value) !== null) writable = parseBool(wrE.value);
          else writable = false;
          var vuE = ent("valid users");
          var rlE = ent("read list");
          var restricted = !!((vuE && vuE.value.trim() !== "") || (rlE && rlE.value.trim() !== ""));
          var before = findings.length;

          if (guest && writable) {
            add(guestE ? guestE.line : sec.line, "BLOCKER", sec.name, "guest ok",
              "Share [" + sec.name + "] is guest-accessible AND writable — anyone who can reach this server can read, change, and delete files in it with no account at all. This is the classic ransomware and data-loss setup.",
              "Set guest ok = no on [" + sec.name + "], or make it read only = yes if it truly must stay public.");
          } else if (guest && !writable) {
            add(guestE ? guestE.line : sec.line, "WARNING", sec.name, "guest ok",
              "Share [" + sec.name + "] allows guest access (read-only). Anyone on a reachable network can read everything in it without an account.",
              "Set guest ok = no unless this folder is deliberately public, and check the path holds nothing private.");
          }

          if (writable && !restricted) {
            add(sec.line, "WARNING", sec.name, "valid users",
              "Share [" + sec.name + "] is writable and names no “valid users” or read list — every account that can log in to the server can write to it.",
              "Add valid users = (the people or @group who should use this share) to [" + sec.name + "].");
          }

          var wideE = ent("wide links") || gWide;
          if (wideE && parseBool(wideE.value) === true && unixExtOff) {
            add(wideE.line, "WARNING", sec.name, "wide links",
              "“wide links = yes” together with “unix extensions = no”: in plain words, a symlink (a file that points somewhere else) placed inside share [" + sec.name + "] can lead outside the share's own folder — to anywhere on the machine the Samba user can read. Someone with write access to the share can use that to reach files that were never shared.",
              "Set wide links = no, or turn unix extensions back on, unless you knowingly need this legacy behaviour.");
          }

          if (pathVal) {
            var norm = pathVal.replace(/\/+$/, "") || "/";
            var broad = guest || !restricted;
            var isRoot = norm === "/";
            var isHomeRoot = /^\/home(\/[^\/]+)?$/.test(norm) || /^\/Users(\/[^\/]+)?$/.test(norm) || norm === "/root";
            if ((isRoot || isHomeRoot) && broad) {
              add(pathE.line, "WARNING", sec.name, "path",
                "Share [" + sec.name + "] points at " + (isRoot ? "the filesystem root" : "a home-folder root") + " (“path = " + pathVal + "”) with broad access — far more of the machine is exposed than a single shared folder.",
                "Point the share at one dedicated folder (for example /srv/" + sec.name.toLowerCase() + ") and restrict it with valid users.");
            }
          }

          var brE = ent("browseable");
          if (brE) {
            var br = parseBool(brE.value);
            add(brE.line, "INFO", sec.name, brE.key,
              "Share [" + sec.name + "] has “browseable = " + brE.value.trim() + "”" + (br === true ? " — its name shows up in network browse lists. Noted." : " — it stays out of network browse lists. Noted."),
              "");
          }

          var fuE = ent("force user");
          if (fuE && fuE.value.trim().toLowerCase() === "root") {
            add(fuE.line, "WARNING", sec.name, fuE.key,
              "“force user = root” on share [" + sec.name + "] — everyone using this share reads and writes files as root, bypassing the file permissions that are supposed to protect the rest of the machine.",
              "Force a dedicated unprivileged user instead, or remove force user.");
          }

          var cmE = ent("create mask") || ent("create mode");
          if (cmE) {
            var digits = cmE.value.trim().replace(/^0+/, "") || "0";
            var lastDigit = parseInt(digits.charAt(digits.length - 1), 8);
            if (!isNaN(lastDigit) && (lastDigit & 2)) {
              add(cmE.line, "WARNING", sec.name, cmE.key,
                "“create mask = " + cmE.value.trim() + "” on share [" + sec.name + "] lets newly created files be writable by everyone, not just their owner and group.",
                "Tighten the mask (for example 0660 or 0640) so “others” get no write bit.");
            }
          }

          var vfE = ent("veto files");
          if (vfE) {
            add(vfE.line, "INFO", sec.name, vfE.key,
              "Share [" + sec.name + "] defines “veto files” — matching names are blocked from the share entirely. Noted.",
              "");
          }
          var hdE = ent("hide dot files");
          if (hdE && parseBool(hdE.value) === true) {
            add(hdE.line, "INFO", sec.name, hdE.key,
              "Share [" + sec.name + "] hides dot files. Note: hidden is not the same as protected — the files are still reachable by name. Noted.",
              "");
          }

          var shareFindings = findings.slice(before);
          var worst = "none";
          shareFindings.forEach(function (f) {
            if (f.severity === "BLOCKER") worst = "BLOCKER";
            else if (f.severity === "WARNING" && worst !== "BLOCKER") worst = "WARNING";
            else if (f.severity === "INFO" && worst === "none") worst = "INFO";
          });
          shares.push({
            name: sec.name,
            path: pathVal || "(no path set)",
            guest: guest ? "yes" : "no",
            writable: writable ? "yes" : "no",
            allowed: restricted ? (vuE && vuE.value.trim() ? "valid users set" : "read list set") : "no restriction",
            findingCount: shareFindings.length,
            worst: worst
          });
        });

        var sevRank = { BLOCKER: 0, WARNING: 1, INFO: 2 };
        findings.sort(function (a, b) {
          if (a.line !== b.line) return a.line - b.line;
          return sevRank[a.severity] - sevRank[b.severity];
        });

        var counts = { BLOCKER: 0, WARNING: 0, INFO: 0 };
        findings.forEach(function (f) { counts[f.severity]++; });

        var verdict = null;
        if (sawAnySection) {
          if (counts.BLOCKER > 0) verdict = "DO NOT DEPLOY";
          else if (counts.WARNING > 0) verdict = "DEPLOY WITH FIXES";
          else verdict = "SAFE TO DEPLOY";
        }
        return { verdict: verdict, counts: counts, findings: findings, shares: shares, sawAnySection: sawAnySection };
      }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "CLEAN_EXAMPLE": (typeof CLEAN_EXAMPLE !== 'undefined' ? CLEAN_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-samba-config-safety-auditortm',
  name: 'J-Dawgs Samba Config Safety Auditor',
  description: 'testparm needs a Samba install and stops at validity; ours grades a pasted smb.conf anywhere — guest access, protocol floor, share writability — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "CLEAN_EXAMPLE": __core["CLEAN_EXAMPLE"] }
};
