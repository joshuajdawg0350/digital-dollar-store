'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Garage Door Proposal, Work Record & Final Invoice Consistency Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- worked examples ---------- */
      var EX_BAD = {
        proposal:
"J-Dawgs Garage Door - Approved Proposal #1042\n" +
"Door: 16x7 insulated steel, R-12 - $1,850\n" +
"Opener: 1/2 HP belt drive - $650\n" +
"Springs: torsion, qty 2 - $240\n" +
"Rollers: nylon, qty 10 - $120\n" +
"Weather seal: bottom seal, qty 1 - $85\n" +
"Labor: 6 hrs @ $85 - $510\n" +
"Deposit paid: $400\n" +
"Proposal total: $3,455",
        record:
"Work Record - Job #1042\n" +
"Door installed: 16x7 non-insulated steel, R-0\n" +
"Opener installed: 1/2 HP chain drive\n" +
"Springs installed: torsion, qty 2\n" +
"Rollers installed: nylon, qty 10\n" +
"Weather seal installed: bottom seal, qty 1\n" +
"Labor: 5 hrs @ $85\n" +
"Deposit paid: $400",
        invoice:
"Final Invoice #1042\n" +
"Door: 16x7 insulated steel, R-12 - $1,850\n" +
"Opener: 1/2 HP belt drive - $650\n" +
"Springs: torsion, qty 2 - $240\n" +
"Rollers: nylon, qty 10 - $120\n" +
"Weather seal: bottom seal, qty 1 - $85\n" +
"Labor: 8 hrs @ $85 - $680\n" +
"Haul-away fee: $95\n" +
"Deposit credit: $0\n" +
"Invoice total: $3,720"
      };

      var EX_GOOD = {
        proposal:
"J-Dawgs Garage Door - Approved Proposal #2047\n" +
"Door: 16x7 insulated steel, R-12 - $1,850\n" +
"Opener: 1/2 HP belt drive - $650\n" +
"Springs: torsion, qty 2 - $240\n" +
"Rollers: nylon, qty 10 - $120\n" +
"Weather seal: bottom seal, qty 1 - $85\n" +
"Labor: 6 hrs @ $85 - $510\n" +
"Deposit paid: $400\n" +
"Proposal total: $3,455",
        record:
"Work Record - Job #2047\n" +
"Door installed: 16x7 insulated steel, R-12\n" +
"Opener installed: 1/2 HP belt drive\n" +
"Springs installed: torsion, qty 2\n" +
"Rollers installed: nylon, qty 10\n" +
"Weather seal installed: bottom seal, qty 1\n" +
"Labor: 6 hrs @ $85\n" +
"Deposit paid: $400",
        invoice:
"Final Invoice #2047\n" +
"Door: 16x7 insulated steel, R-12 - $1,850\n" +
"Opener: 1/2 HP belt drive - $650\n" +
"Springs: torsion, qty 2 - $240\n" +
"Rollers: nylon, qty 10 - $120\n" +
"Weather seal: bottom seal, qty 1 - $85\n" +
"Labor: 6 hrs @ $85 - $510\n" +
"Deposit credit: -$400\n" +
"Invoice total: $3,055"
      };

      /* ---------- parsing helpers ---------- */
      function moneyAll(line){
        var out = [], re = /\$\s*(-?[\d,]+(?:\.\d{1,2})?)/g, m;
        while((m = re.exec(line)) !== null){
          var v = parseFloat(m[1].replace(/,/g,""));
          var before = line.charAt(m.index - 1);
          if(before === "-" || before === "(") v = -Math.abs(v);
          out.push(v);
        }
        return out;
      }
      function moneyIn(line){
        var a = moneyAll(line);
        return a.length ? a[0] : null;
      }
      function moneyLast(line){
        var a = moneyAll(line);
        return a.length ? a[a.length - 1] : null;
      }
      function fmt(n){
        var neg = n < 0; n = Math.abs(Math.round(n*100)/100);
        var s = n.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        return (neg ? "-$" : "$") + s;
      }
      function linesOf(text){ return text.split(/\r?\n/).map(function(l){return l.trim();}).filter(function(l){return l.length>0;}); }
      function findLine(lines, re){ for(var i=0;i<lines.length;i++){ if(re.test(lines[i])) return lines[i]; } return null; }

      var PARTS = [
        {key:"springs", label:"Springs", re:/spring/i},
        {key:"rollers", label:"Rollers", re:/roller/i},
        {key:"tracks",  label:"Tracks",  re:/track/i},
        {key:"weather seal", label:"Weather seal", re:/weather\s*seal|bottom\s*seal/i},
        {key:"keypad",  label:"Keypad",  re:/keypad/i},
        {key:"remotes", label:"Remotes", re:/remote/i}
      ];

      function categoryOf(line){
        var l = line.toLowerCase();
        if(/deposit/.test(l) && /(credit|less|applied|deduct)/.test(l)) return "deposit-credit";
        if(/deposit/.test(l)) return "deposit";
        if(/\bdoor\b/.test(l)) return "door";
        if(/opener/.test(l)) return "opener";
        for(var i=0;i<PARTS.length;i++){ if(PARTS[i].re.test(l)) return PARTS[i].key; }
        if(/labor|labour/.test(l)) return "labor";
        if(/tax/.test(l)) return "tax";
        return "other";
      }

      function parseItems(lines){
        var items = [];
        lines.forEach(function(line){
          if(/total/i.test(line)) return;
          var amt = moneyLast(line);
          if(amt === null) return;
          var cat = categoryOf(line);
          if(cat === "deposit") return; /* deposit paid is not a billed line */
          items.push({label: line.replace(/\s*-\s*\$.*$/,"").replace(/\$\s*-?[\d,\.]+.*$/,"").trim(), amount: amt, category: cat, raw: line});
        });
        return items;
      }
      function statedTotal(lines){
        var found = null;
        lines.forEach(function(line){
          if(/total/i.test(line) && !/subtotal/i.test(line)){
            var amt = moneyIn(line);
            if(amt !== null) found = amt;
          }
        });
        if(found === null){
          lines.forEach(function(line){
            if(/subtotal/i.test(line)){ var amt = moneyIn(line); if(amt !== null) found = amt; }
          });
        }
        return found;
      }
      function parseDoor(lines){
        var line = null, bestScore = -1;
        lines.forEach(function(l){
          if(!/\bdoor\b/i.test(l)) return;
          var score = 0;
          if(/\d{1,2}\s*[x\u00d7]\s*\d{1,2}/i.test(l)) score += 2;
          if(/insulat/i.test(l)) score += 1;
          if(/R[-\s]?\d/i.test(l)) score += 1;
          if(/(steel|aluminum|wood|fiberglass|composite|vinyl)/i.test(l)) score += 1;
          if(score > bestScore){ bestScore = score; line = l; }
        });
        if(!line) return null;
        var size = line.match(/(\d{1,2})\s*[x\u00d7]\s*(\d{1,2})/i);
        var insulated = null;
        if(/non[-\s]?insulated|uninsulated|no insulation/i.test(line)) insulated = false;
        else if(/insulat/i.test(line)) insulated = true;
        var r = line.match(/R[-\s]?(\d+(?:\.\d+)?)/i);
        var mat = line.match(/(steel|aluminum|aluminium|wood|fiberglass|composite|vinyl)/i);
        return {
          raw: line,
          size: size ? (size[1] + "x" + size[2]) : null,
          insulated: insulated,
          rvalue: r ? parseFloat(r[1]) : null,
          material: mat ? mat[1].toLowerCase() : null
        };
      }
      function doorDesc(d){
        if(!d) return "(not stated)";
        var bits = [];
        if(d.size) bits.push(d.size);
        if(d.insulated === true) bits.push("insulated");
        if(d.insulated === false) bits.push("non-insulated");
        if(d.material) bits.push(d.material);
        if(d.rvalue !== null) bits.push("R-" + d.rvalue);
        return bits.length ? bits.join(" ") : d.raw;
      }
      function parseOpener(lines){
        var line = findLine(lines, /opener/i);
        if(!line) return null;
        var drive = line.match(/(belt|chain|screw|direct|wall[-\s]?mount)/i);
        var hp = line.match(/(\d+\s*\/\s*\d+|\d+(?:\.\d+)?)\s*(?:HP|horsepower)/i);
        var hpVal = null;
        if(hp){
          var h = hp[1].replace(/\s/g,"");
          if(h.indexOf("/") >= 0){ var p = h.split("/"); hpVal = parseFloat(p[0])/parseFloat(p[1]); }
          else hpVal = parseFloat(h);
        }
        return { raw: line, drive: drive ? drive[1].toLowerCase().replace(/\s/g,"-") : null, hp: hpVal, hpText: hp ? hp[1].replace(/\s/g,"") : null };
      }
      function openerDesc(o){
        if(!o) return "(not stated)";
        var bits = [];
        if(o.hpText) bits.push(o.hpText + " HP");
        if(o.drive) bits.push(o.drive + " drive");
        return bits.length ? bits.join(" ") : o.raw;
      }
      function parseLabor(lines){
        var line = findLine(lines, /labor|labour/i);
        if(!line) return null;
        var hrs = line.match(/(\d+(?:\.\d+)?)\s*(?:hrs?|hours?)\b/i);
        var rate = line.match(/@\s*\$?\s*([\d,]+(?:\.\d+)?)/);
        return { raw: line, hours: hrs ? parseFloat(hrs[1]) : null, rate: rate ? parseFloat(rate[1].replace(/,/g,"")) : null, amount: moneyLast(line) };
      }
      function parseDepositPaid(lines){
        var best = 0;
        lines.forEach(function(line){
          if(/deposit/i.test(line) && /(paid|received|collected)/i.test(line)){
            var amt = moneyIn(line);
            if(amt !== null && Math.abs(amt) > best) best = Math.abs(amt);
          }
        });
        return best;
      }
      function parseDepositCredit(lines){
        var found = null;
        lines.forEach(function(line){
          if(/deposit/i.test(line) && /(credit|less|applied|deduct)/i.test(line)){
            var amt = moneyIn(line);
            if(amt !== null) found = Math.abs(amt);
          }
        });
        return found;
      }
      function parseQty(line, partRe){
        if(!line) return null;
        var m = line.match(/qty[:\s]*(\d+)/i) || line.match(/[x\u00d7]\s*(\d+)\b/) || line.match(/quantity[:\s]*(\d+)/i);
        if(m) return parseInt(m[1],10);
        m = line.match(/(\d+)\s*[a-z]*\s*(?:springs?|rollers?|tracks?|seals?|keypads?|remotes?)/i);
        if(m) return parseInt(m[1],10);
        if(/\bpair\b/i.test(line) && /spring/i.test(line)) return 2;
        if(partRe && partRe.test(line)) return 1;
        return null;
      }
      function usableDoc(text){
        if(!text || text.trim().length < 30) return false;
        var lines = linesOf(text);
        var money = 0, kw = 0;
        var kwRe = /door|opener|labor|spring|invoice|proposal|total|deposit/i;
        lines.forEach(function(l){ if(moneyIn(l) !== null) money++; if(kwRe.test(l)) kw++; });
        return money >= 1 || kw >= 2;
      }

      function parseDoc(text){
        var lines = linesOf(text || "");
        return {
          lines: lines,
          items: parseItems(lines),
          total: statedTotal(lines),
          door: parseDoor(lines),
          opener: parseOpener(lines),
          labor: parseLabor(lines),
          depositPaid: parseDepositPaid(lines),
          depositCredit: parseDepositCredit(lines)
        };
      }

      /* ---------- audit ---------- */
      function audit(pText, rText, iText){
        var checks = [];
        function add(name, status, detail, arith){ checks.push({name:name, status:status, detail:detail, arith:arith || null}); }

        var docs = [
          {key:"proposal", name:"PROPOSAL", text:pText},
          {key:"record",   name:"WORK RECORD", text:rText},
          {key:"invoice",  name:"FINAL INVOICE", text:iText}
        ];
        docs.forEach(function(d){ d.usable = usableDoc(d.text); d.parsed = d.usable ? parseDoc(d.text) : null; });
        var usableCount = docs.filter(function(d){return d.usable;}).length;
        var missing = docs.filter(function(d){return !d.usable;});

        if(usableCount <= 1){
          add("Documents provided", "INFO",
            "Only " + usableCount + " of the 3 documents is usable text. A cross-check needs at least two documents that disagree-able lines can be compared across; with 0–1 pastes (or pastes with no readable amounts or labeled lines) there is nothing honest to compare.",
            "Usable documents: " + usableCount + " / 3");
          return finish("NOT ENOUGH TO COMPARE", "Fewer than two usable documents were pasted, so no comparison — and no pay verdict — is possible.", checks, docs);
        }

        var P = docs[0].parsed, R = docs[1].parsed, I = docs[2].parsed;
        var hasP = !!P, hasR = !!R, hasI = !!I;
        var blocker = false, flag = false;

        if(missing.length){
          flag = true;
          var names = missing.map(function(d){return d.name;}).join(", ");
          add("Missing document: " + names, "FLAG",
            "The " + names + " was not pasted (or had no readable lines). Every check that needs it is skipped in both directions — nothing was assumed in its place — and the verdict is capped at PAY WITH FIXES no matter how clean the rest looks.",
            "Documents compared: " + usableCount + " / 3 · Missing: " + names);
        }

        /* Door identity */
        if(hasP && hasR && hasI){
          var dp = P.door, dr = R.door, di = I.door;
          if(!dp || !dr || !di){
            flag = true;
            add("Door identity", "FLAG", "A door line could not be read in every document, so the door cannot be fully cross-checked.",
              "Proposal: " + doorDesc(dp) + "\nWork record: " + doorDesc(dr) + "\nInvoice: " + doorDesc(di));
          } else {
            var problems = [];
            if(dp.size && dr.size && dp.size !== dr.size) problems.push("size changed: proposal " + dp.size + " vs installed " + dr.size);
            if(dp.insulated !== null && dr.insulated !== null && dp.insulated !== dr.insulated)
              problems.push("insulation downgrade: proposal " + (dp.insulated ? "insulated" : "non-insulated") + " vs installed " + (dr.insulated ? "insulated" : "non-insulated"));
            if(dp.rvalue !== null && dr.rvalue !== null && dr.rvalue < dp.rvalue)
              problems.push("R-value downgrade: proposal R-" + dp.rvalue + " vs installed R-" + dr.rvalue);
            if(dp.material && dr.material && dp.material !== dr.material)
              problems.push("material changed: proposal " + dp.material + " vs installed " + dr.material);
            var billedMismatch = [];
            if(dr.size && di.size && dr.size !== di.size) billedMismatch.push("invoice size " + di.size + " vs installed " + dr.size);
            if(dr.insulated !== null && di.insulated !== null && dr.insulated !== di.insulated)
              billedMismatch.push("invoice bills " + (di.insulated ? "insulated" : "non-insulated") + " but record shows " + (dr.insulated ? "insulated" : "non-insulated") + " installed");
            if(dr.rvalue !== null && di.rvalue !== null && di.rvalue !== dr.rvalue)
              billedMismatch.push("invoice R-" + di.rvalue + " vs installed R-" + dr.rvalue);
            if(problems.length || billedMismatch.length){
              blocker = true;
              add("Door identity", "BLOCKER",
                "The door installed is not the door proposed and billed. " + problems.concat(billedMismatch).join("; ") + ".",
                "Proposal: " + doorDesc(dp) + "\nWork record (installed): " + doorDesc(dr) + "\nInvoice (billed): " + doorDesc(di));
            } else {
              add("Door identity", "PASS", "Same door in all three documents.",
                "Proposal: " + doorDesc(dp) + " = Work record: " + doorDesc(dr) + " = Invoice: " + doorDesc(di));
            }
          }
        } else {
          add("Door identity", "INFO", "Skipped — needs the proposal, the work record, and the invoice.", null);
        }

        /* Opener identity */
        if(hasP && hasR && hasI){
          var op = P.opener, orr = R.opener, oi = I.opener;
          if(!op || !orr || !oi){
            flag = true;
            add("Opener identity", "FLAG", "An opener line could not be read in every document, so the opener cannot be fully cross-checked.",
              "Proposal: " + openerDesc(op) + "\nWork record: " + openerDesc(orr) + "\nInvoice: " + openerDesc(oi));
          } else {
            var oProbs = [];
            if(op.drive && orr.drive && op.drive !== orr.drive) oProbs.push("drive changed: proposal " + op.drive + " vs installed " + orr.drive);
            if(op.hp !== null && orr.hp !== null && orr.hp < op.hp) oProbs.push("horsepower dropped: proposal " + op.hpText + " HP vs installed " + orr.hpText + " HP");
            if(orr.drive && oi.drive && orr.drive !== oi.drive) oProbs.push("invoice bills a " + oi.drive + " drive but a " + orr.drive + " drive was installed");
            if(oProbs.length){
              blocker = true;
              add("Opener identity", "BLOCKER", "The opener installed is not the opener proposed and billed. " + oProbs.join("; ") + ".",
                "Proposal: " + openerDesc(op) + "\nWork record (installed): " + openerDesc(orr) + "\nInvoice (billed): " + openerDesc(oi));
            } else {
              add("Opener identity", "PASS", "Same opener in all three documents.",
                "Proposal: " + openerDesc(op) + " = Work record: " + openerDesc(orr) + " = Invoice: " + openerDesc(oi));
            }
          }
        } else {
          add("Opener identity", "INFO", "Skipped — needs the proposal, the work record, and the invoice.", null);
        }

        /* Parts billed vs recorded */
        if(hasR && hasI){
          var partFlags = [], partPass = [];
          PARTS.forEach(function(part){
            var invItem = null;
            I.items.forEach(function(it){ if(it.category === part.key) invItem = it; });
            var recLine = findLine(R.lines, part.re);
            if(!invItem && !recLine) return;
            if(invItem && recLine){
              var bq = parseQty(invItem.raw, part.re);
              var rq = parseQty(recLine, part.re);
              if(bq !== null && rq !== null && bq > rq){
                var unit = invItem.amount / bq;
                var over = (bq - rq) * unit;
                partFlags.push({label: part.label, text: part.label + ": billed qty " + bq + " vs installed qty " + rq + " — " + (bq-rq) + " extra × " + fmt(unit) + " unit price = " + fmt(over) + " billed for parts not recorded as installed."});
              } else if(bq !== null && rq !== null){
                partPass.push(part.label + " qty " + bq + " = installed " + rq);
              } else {
                partPass.push(part.label + " present in both (quantity not stated in one of them)");
              }
            } else if(invItem && !recLine){
              partFlags.push({label: part.label, text: part.label + ": billed " + fmt(invItem.amount) + " on the invoice but not mentioned in the work record at all."});
            }
          });
          if(partFlags.length){
            flag = true;
            partFlags.forEach(function(f){ add("Parts billed vs recorded — " + f.label, "FLAG", f.text, null); });
          } else {
            add("Parts billed vs recorded", "PASS", "No part is billed above the quantity the work record shows installed." + (partPass.length ? " (" + partPass.join("; ") + ")" : ""), null);
          }
        } else {
          add("Parts billed vs recorded", "INFO", "Skipped — needs the work record and the invoice.", null);
        }

        /* Labor */
        if(hasR && hasI){
          var rl = R.labor, il = I.labor;
          if(rl && il && rl.hours !== null && il.amount !== null){
            var rate = rl.rate !== null ? rl.rate : (il.rate !== null ? il.rate : (rl.hours ? null : null));
            if(rate !== null){
              var expected = rl.hours * rate;
              var over = il.amount - expected;
              var arith = "Recorded: " + rl.hours + " hrs @ " + fmt(rate) + " = " + fmt(expected) + " expected\nInvoice labor charged: " + fmt(il.amount) + (il.hours !== null ? " (" + il.hours + " hrs billed)" : "") + "\nDifference: " + fmt(il.amount) + " - " + fmt(expected) + " = " + fmt(over);
              if(over > 0.005){
                flag = true;
                add("Labor", "FLAG", "Labor is billed " + fmt(over) + " above the recorded hours × recorded rate.", arith);
              } else if(over < -0.005){
                add("Labor", "PASS", "Labor charged is at or below the recorded hours × rate.", arith);
              } else {
                add("Labor", "PASS", "Recorded hours × recorded rate equals the labor charged, exactly.", arith);
              }
            } else {
              flag = true;
              add("Labor", "FLAG", "Labor lines were found but no hourly rate could be read, so the labor charge cannot be recomputed.", "Work record: " + rl.raw + "\nInvoice: " + il.raw);
            }
          } else {
            flag = true;
            add("Labor", "FLAG", "A labor line with hours (record) and a charged amount (invoice) could not both be read, so labor is unverified.",
              "Work record labor: " + (rl ? rl.raw : "(not stated)") + "\nInvoice labor: " + (il ? il.raw : "(not stated)"));
          }
        } else {
          add("Labor", "INFO", "Skipped — needs the work record and the invoice.", null);
        }

        /* Deposit credit */
        if(hasI && (hasP || hasR)){
          var paid = Math.max(hasP ? P.depositPaid : 0, hasR ? R.depositPaid : 0);
          var credit = I.depositCredit;
          if(paid > 0){
            if(credit === null){
              blocker = true;
              add("Deposit credit", "BLOCKER", "A deposit of " + fmt(paid) + " is stated as paid, but the invoice shows no deposit credit line at all — the deposit is not credited.",
                "Deposit paid (proposal/record): " + fmt(paid) + "\nDeposit credited on invoice: $0.00 (no credit line found)\nUncredited: " + fmt(paid));
            } else if(credit < paid - 0.005){
              blocker = true;
              add("Deposit credit", "BLOCKER", "Only " + fmt(credit) + " of the " + fmt(paid) + " deposit paid is credited on the invoice.",
                "Deposit paid: " + fmt(paid) + "\nDeposit credited: " + fmt(credit) + "\nUncredited: " + fmt(paid) + " - " + fmt(credit) + " = " + fmt(paid - credit));
            } else {
              add("Deposit credit", "PASS", "The deposit paid is fully credited on the invoice.",
                "Deposit paid: " + fmt(paid) + " = Deposit credited: " + fmt(credit));
            }
          } else {
            add("Deposit credit", "PASS", "No deposit is stated as paid in the proposal or work record, so no credit is owed.", null);
          }
        } else {
          add("Deposit credit", "INFO", "Skipped — needs the invoice plus the proposal or work record.", null);
        }

        /* Invoice-only charges */
        if(hasI && (hasP || hasR)){
          var knownCats = {};
          if(hasP) P.items.forEach(function(it){ knownCats[it.category] = true; });
          if(hasR) R.lines.forEach(function(l){ var c = categoryOf(l); if(c !== "other" && c !== "deposit") knownCats[c] = true; });
          var knownWords = {};
          [P, R].forEach(function(D){
            if(!D) return;
            D.lines.forEach(function(l){
              l.toLowerCase().replace(/[^a-z\s]/g," ").split(/\s+/).forEach(function(w){ if(w.length >= 4) knownWords[w] = true; });
            });
          });
          var onlyItems = [];
          I.items.forEach(function(it){
            if(it.category === "deposit-credit" || it.category === "tax") return;
            if(knownCats[it.category]) return;
            if(it.category === "other"){
              var words = it.label.toLowerCase().replace(/[^a-z\s]/g," ").split(/\s+/).filter(function(w){return w.length>=4;});
              var hit = words.some(function(w){ return knownWords[w]; });
              if(hit) return;
            }
            onlyItems.push(it);
          });
          if(onlyItems.length){
            flag = true;
            var listTxt = onlyItems.map(function(it){ return it.label + " — " + fmt(it.amount); }).join("\n");
            var tot = onlyItems.reduce(function(s,it){return s+it.amount;},0);
            add("Invoice-only charges", "FLAG",
              onlyItems.length + " charge(s) appear on the invoice but in neither the proposal nor the work record, totaling " + fmt(tot) + ". Each one needs a paper trail before it is paid.",
              listTxt + "\nInvoice-only total: " + fmt(tot));
          } else {
            add("Invoice-only charges", "PASS", "Every invoice line traces back to the proposal or the work record.", null);
          }
        } else {
          add("Invoice-only charges", "INFO", "Skipped — needs the invoice plus the proposal or work record.", null);
        }

        /* Totals */
        if(hasI){
          var readded = I.items.reduce(function(s,it){return s+it.amount;},0);
          var sumTxt = I.items.map(function(it){ return it.label + ": " + fmt(it.amount); }).join("\n") + "\nRe-added sum: " + fmt(readded);
          if(I.total !== null){
            if(Math.abs(readded - I.total) > 0.005){
              flag = true;
              add("Invoice totals re-added", "FLAG",
                "The invoice's own lines do not add up to its stated total — off by " + fmt(readded - I.total) + ".",
                sumTxt + "\nStated invoice total: " + fmt(I.total) + "\nDifference: " + fmt(readded) + " - " + fmt(I.total) + " = " + fmt(readded - I.total));
            } else {
              add("Invoice totals re-added", "PASS", "The invoice line items re-add exactly to the stated total.",
                sumTxt + "\nStated invoice total: " + fmt(I.total) + " — match");
            }
          } else {
            flag = true;
            add("Invoice totals re-added", "FLAG", "No stated total could be read on the invoice, so its lines cannot be checked against one.", sumTxt);
          }
        } else {
          add("Invoice totals re-added", "INFO", "Skipped — the invoice was not pasted.", null);
        }

        if(hasP && hasI && P.total !== null && I.total !== null){
          var delta = I.total - P.total;
          var byCat = {};
          P.items.forEach(function(it){ byCat[it.category] = (byCat[it.category]||0) - it.amount; });
          I.items.forEach(function(it){ byCat[it.category] = (byCat[it.category]||0) + it.amount; });
          var accounted = 0, parts = [];
          Object.keys(byCat).forEach(function(k){ accounted += byCat[k]; if(Math.abs(byCat[k]) > 0.005) parts.push(k + ": " + fmt(byCat[k])); });
          var unexplained = delta - accounted;
          var arithT = "Invoice total " + fmt(I.total) + " - Proposal total " + fmt(P.total) + " = " + fmt(delta) + " delta\nExplained by line differences: " + (parts.length ? parts.join("; ") : "none") + " = " + fmt(accounted) + "\nUnexplained gap: " + fmt(delta) + " - " + fmt(accounted) + " = " + fmt(unexplained);
          if(Math.abs(unexplained) > 0.005){
            flag = true;
            add("Proposal vs invoice total", "FLAG", "The proposal-to-invoice delta is not fully explained by the line differences — an unexplained gap of " + fmt(unexplained) + " remains.", arithT);
          } else {
            add("Proposal vs invoice total", "PASS",
              delta === 0 ? "Invoice total equals the proposal total exactly." : "The full delta is explained by the line differences in the arithmetic below — whether each difference is justified is judged by the door, labor, deposit, and invoice-only checks above, not hidden here.",
              arithT);
          }
        } else if(hasP && hasI){
          add("Proposal vs invoice total", "INFO", "A stated total could not be read in both documents, so the proposal-to-invoice delta cannot be computed.", null);
        }

        var verdict, why;
        if(blocker){
          verdict = "DO NOT PAY YET";
          why = "At least one BLOCKER: something billed is not what the record shows was installed, or money already paid is not credited. Hold payment until the flagged items are corrected on paper.";
        } else if(flag){
          verdict = "PAY WITH FIXES";
          why = missing.length
            ? "No blockers in what was pasted, but a document is missing, so the verdict is capped here. Get the missing document and re-run before treating this as final."
            : "No blockers, but one or more flags need fixing or explaining before the bill is settled as-is.";
        } else {
          verdict = "SAFE TO PAY";
          why = "All three documents agree: same door, same opener, parts, labor, and deposit all reconcile, and the invoice re-adds exactly.";
        }
        return finish(verdict, why, checks, docs);
      }

      function finish(verdict, why, checks, docs){
        return { verdict: verdict, why: why, checks: checks, documents: docs.map(function(d){ return {document: d.name, usable: d.usable}; }) };
      }

      /* ---------- rendering & reports ---------- */
      var lastResult = null;
      function esc(s){ return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"); }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-garage-door-proposal-work-record-final-invoice-consistency-auditor',
  name: 'J-Dawgs Garage Door Proposal, Work Record & Final Invoice Consistency Auditor',
  description: 'Cross-checks a garage door proposal against the work record and final invoice into one pay verdict — door and opener identity, quantities, labor hours × rate, deposit credit, and invoice-only fees, with arithmetic shown across all pastes. Every other system grades one document alone.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
