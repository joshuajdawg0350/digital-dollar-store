'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Squid Proxy Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var DANGEROUS = [
          "# Dangerous example - copied from a tutorial. Do not deploy.",
          "http_port 3128",
          "acl localnet src 10.0.0.0/8",
          "acl internet src 0.0.0.0/0",
          "acl Safe_ports port 80",
          "acl SSL_ports port 443",
          "acl CONNECT method CONNECT",
          "acl manager proto cache_object",
          "visible_hostname proxy",
          "forwarded_for on",
          "icp_port 3130",
          "cache_peer 203.0.113.8 parent 8080 3130 login=peeruser:s3cretvalue",
          "http_access allow manager internet",
          "http_access allow CONNECT internet",
          "http_access allow all",
          "http_access deny localnet"
        ].join("\n");

        var CLEAN = [
          "# Clean example - locked-down office proxy.",
          "http_port 127.0.0.1:3128",
          "auth_param basic program /usr/lib/squid/basic_ncsa_auth /etc/squid/passwd",
          "auth_param basic children 5 startup=1 idle=1",
          "acl authenticated proxy_auth REQUIRED",
          "acl localnet src 10.0.0.0/8",
          "acl SSL_ports port 443",
          "acl Safe_ports port 80",
          "acl Safe_ports port 443",
          "acl CONNECT method CONNECT",
          "visible_hostname proxy.office.lan",
          "forwarded_for off",
          "via off",
          "http_access deny !Safe_ports",
          "http_access deny CONNECT !SSL_ports",
          "http_access allow localhost manager",
          "http_access deny manager",
          "http_access allow localnet authenticated",
          "http_access allow localhost",
          "http_access deny all"
        ].join("\n");

        // Directives this auditor understands. Anything else on a non-blank,
        // non-comment line is reported as NOT PARSED by line number.
        var KNOWN = {};
        ("http_port https_port ftp_port acl http_access http_reply_access icp_access " +
         "cache no_cache always_direct never_direct prefer_direct forwarded_for follow_x_forwarded_for " +
         "via visible_hostname unique_hostname request_header_access reply_header_access " +
         "request_header_replace reply_header_replace request_header_add reply_header_add " +
         "cache_peer cache_peer_access cache_peer_domain neighbor_type_domain icp_port htcp_port " +
         "snmp_port snmp_access icp_query_timeout dead_peer_timeout hierarchy_stoplist cache_dir " +
         "cache_mem access_log cache_log cache_store_log coredump_dir logfile_rotate logfile_daemon " +
         "logformat emulate_httpd_log mime_table pid_filename client_netmask auth_param " +
         "authenticate_program authenticate_ip_ttl refresh_pattern delay_pools delay_class delay_access " +
         "delay_parameters delay_initial_bucket_level dns_nameservers dns_defnames hosts_file append_domain " +
         "ignore_unknown_nameservers tcp_outgoing_address tcp_outgoing_tos client_persistent_connections " +
         "server_persistent_connections persistent_request_timeout detect_broken_pconn broken_posts " +
         "extension_methods request_entities memory_pools memory_pools_limit maximum_object_size " +
         "minimum_object_size maximum_object_size_in_memory cache_swap_low cache_swap_high quick_abort_min " +
         "quick_abort_max quick_abort_pct negative_ttl positive_dns_ttl negative_dns_ttl connect_timeout " +
         "peer_connect_timeout read_timeout request_timeout client_lifetime max_stale range_offset_limit " +
         "reply_body_max_size request_body_max_size half_closed_clients pconn_timeout ident_timeout " +
         "ident_lookup_access shutdown_lifetime announce_host announce_port announce_period " +
         "log_icp_queries icp_hit_stale query_icmp test_reachability udp_incoming_address " +
         "udp_outgoing_address client_db reload_into_ims store_dir_select_algorithm max_open_disk_fds " +
         "unlinkd_program pinger_program pinger_enable redirect_program redirect_children " +
         "redirect_concurrency redirector_bypass redirector_access url_rewrite_program url_rewrite_children " +
         "url_rewrite_concurrency url_rewrite_host_header url_rewrite_access url_rewrite_bypass " +
         "storeurl_rewrite_program storeurl_rewrite_children storeurl_rewrite_concurrency " +
         "storeurl_rewrite_bypass storeurl_access ssl_unclean_shutdown sslproxy_client_certificate " +
         "sslproxy_client_key sslproxy_version sslproxy_options sslproxy_cipher sslproxy_cafile " +
         "sslproxy_capath sslproxy_cert_error sslproxy_flags ssl_bump sslcrtd_program sslcrtd_children " +
         "dynamic_cert_mem_cache_size generate_host_certificates external_acl_type miss_access " +
         "cachemgr_passwd include workers eui_lookup adaptation_access adaptation_service_set " +
         "icap_enable icap_service collapsed_forwarding netdb_filename netdb_ping_period " +
         "digest_generation store_objects_per_bucket reference_age cache_replacement_policy " +
         "memory_replacement_policy upgrade_http0.9 allow_underscore uri_whitespace dns_v4_first " +
         "ipcache_size fqdncache_size retry_on_error offline_mode strip_query_terms log_mime_hdrs " +
         "buffered_logs nonhierarchical_direct global_internal_static check_hostnames " +
         "minimum_expiry_time max_filedesc max_filedescriptors outgoing_timeout " +
         "client_request_buffer_max_size chunked_request_body_max_size via_off forwarded_for_off"
        ).split(" ").forEach(function (d) { KNOWN[d] = true; });

        var BUILTIN_ACLS = { all: true, localhost: true, manager: true, to_localhost: true };

        function isLoopbackAddr(addr) {
          if (!addr) return false;
          var a = addr.toLowerCase();
          return a === "localhost" || a === "::1" || a.indexOf("127.") === 0 || a === "[::1]";
        }

        function audit(text) {
          var findings = [];
          function add(sev, line, directive, name, detail, fix) {
            findings.push({ sev: sev, line: line, directive: directive, name: name, detail: detail, fix: fix });
          }

          var lines = String(text == null ? "" : text).split(/\r\n|\r|\n/);
          var notParsed = [];
          var aclDefs = {};        // name -> [ {type, values:[], line} ]
          var aclFirstLine = {};   // name -> first definition line
          var rules = [];          // http_access rules in order
          var httpPorts = [];      // {line, port, addr}
          var authPresent = false;
          var hasVisibleHostname = false;
          var alwaysDirectAll = []; // lines
          var safePortsRanges = []; // {line, lo, hi}

          function defEntries(name) { return aclDefs[name] || []; }
          function aclTypeOf(name) {
            var es = defEntries(name);
            return es.length ? es[0].type : null;
          }
          function isAllish(name) {
            if (name === "all") return true;
            var es = defEntries(name), i, j, v;
            for (i = 0; i < es.length; i++) {
              if (es[i].type === "src") {
                for (j = 0; j < es[i].values.length; j++) {
                  v = es[i].values[j];
                  if (v === "0.0.0.0/0" || v === "0.0.0.0/0.0.0.0" || v === "all" || v === "::/0") return true;
                }
              }
            }
            return false;
          }
          function isProxyAuthAcl(name) { return aclTypeOf(name) === "proxy_auth"; }

          var i, raw, trimmed, work, hashIdx, tokens, dir, lower;
          for (i = 0; i < lines.length; i++) {
            var lineNo = i + 1;
            raw = lines[i];
            trimmed = raw.replace(/^\s+|\s+$/g, "");
            if (trimmed === "" || trimmed.charAt(0) === "#") continue;
            work = trimmed;
            hashIdx = work.indexOf(" #");
            if (hashIdx >= 0) work = work.slice(0, hashIdx);
            tokens = work.split(/\s+/);
            dir = tokens[0];
            lower = dir.toLowerCase();

            if (!KNOWN[lower] || tokens.length < 2) { notParsed.push(lineNo); continue; }

            try {
              if (lower === "acl") {
                if (tokens.length < 4) { notParsed.push(lineNo); continue; }
                var aname = tokens[1], atype = tokens[2].toLowerCase();
                if (!aclDefs[aname]) { aclDefs[aname] = []; aclFirstLine[aname] = lineNo; }
                aclDefs[aname].push({ type: atype, values: tokens.slice(3), line: lineNo });
                if (atype === "proxy_auth") authPresent = true;
                if (aname === "Safe_ports" && atype === "port") {
                  tokens.slice(3).forEach(function (v) {
                    var m = /^(\d+)(?:-(\d+))?$/.exec(v);
                    if (m) safePortsRanges.push({ line: lineNo, lo: parseInt(m[1], 10), hi: m[2] ? parseInt(m[2], 10) : parseInt(m[1], 10) });
                  });
                }
              } else if (lower === "http_access") {
                var action = tokens[1].toLowerCase();
                if (action !== "allow" && action !== "deny") { notParsed.push(lineNo); continue; }
                var conds = tokens.slice(2).map(function (t) {
                  if (t.charAt(0) === "!") return { neg: true, name: t.slice(1) };
                  return { neg: false, name: t };
                });
                if (conds.length === 0) { notParsed.push(lineNo); continue; }
                rules.push({ line: lineNo, action: action, conds: conds });
              } else if (lower === "http_port" || lower === "https_port" || lower === "ftp_port") {
                var spec = tokens[1], addr = null, port = null;
                var ci = spec.lastIndexOf(":");
                if (ci > 0 && /^\d+$/.test(spec.slice(ci + 1))) { addr = spec.slice(0, ci); port = spec.slice(ci + 1); }
                else if (/^\d+$/.test(spec)) { port = spec; }
                else { notParsed.push(lineNo); continue; }
                if (lower === "http_port") {
                  httpPorts.push({ line: lineNo, port: port, addr: addr });
                  if (port === "3128") {
                    add("INFO", lineNo, "http_port", "Standard Squid port",
                      "http_port listens on port 3128, the standard Squid port. Scanners probe this port by default, so the rest of this audit matters most here.",
                      "No change needed for the port itself; keep the access rules below tight.");
                  }
                  if (addr === null || addr === "0.0.0.0" || addr === "::") {
                    add("WARNING", lineNo, "http_port", "Proxy listens on all interfaces",
                      "This http_port has " + (addr === null ? "no bind address" : "bind address " + addr) + ", so the proxy answers on every network interface, including any internet-facing one.",
                      "Bind it to a specific internal or loopback address (for example 127.0.0.1:3128 or an internal LAN address) unless outside access is deliberate and authenticated.");
                  }
                } else if (lower === "https_port") {
                  var hasCert = tokens.slice(2).join(" ").indexOf("cert=") >= 0 || spec.indexOf("cert=") >= 0;
                  if (!hasCert) {
                    add("WARNING", lineNo, "https_port", "NOT PARSED - TLS certificate not verifiable",
                      "This https_port names no cert= option, so from the pasted text alone no TLS certificate can be verified for it; the auditor cannot confirm this port can serve HTTPS as configured.",
                      "Add a cert= path (and key= if separate) for this https_port, then confirm on the host with squid -k parse.");
                  } else {
                    add("INFO", lineNo, "https_port", "https_port with certificate option",
                      "This https_port names a cert= option. The certificate file itself lives on the host and cannot be checked from pasted text.",
                      "Confirm the certificate is valid and unexpired on the host.");
                  }
                }
              } else if (lower === "auth_param") {
                authPresent = true;
                if (tokens.length >= 3 && tokens[2].toLowerCase() === "program") {
                  add("INFO", lineNo, "auth_param", "Authentication helper and credentials file referenced",
                    "This auth_param line points Squid at an authentication helper program and its credentials file. For safety, the helper path and credentials file are reported by directive name and line only - their values are never shown.",
                    "Keep the credentials file readable only by the Squid user, and rotate it if this configuration has been shared.");
                }
              } else if (lower === "authenticate_program") {
                authPresent = true;
                add("INFO", lineNo, "authenticate_program", "Legacy authentication helper referenced",
                  "This legacy directive points at an authentication helper and its credentials file; reported by directive name and line only, values never shown.",
                  "Move to auth_param and keep the credentials file readable only by the Squid user.");
              } else if (lower === "cache_peer") {
                var hasLogin = tokens.some(function (t) { return t.indexOf("login=") === 0; });
                if (hasLogin) {
                  add("WARNING", lineNo, "cache_peer", "Peer credentials embedded in cache_peer",
                    "This cache_peer line carries login= credentials for the upstream peer. Reported by directive name and line only - the credential value is never shown.",
                    "Treat the credential as exposed if this file has been shared; rotate it at the peer and restrict who can read this configuration.");
                } else {
                  add("INFO", lineNo, "cache_peer", "Upstream peer defined",
                    "An upstream cache_peer is defined here. Sibling/parent traffic to it follows the peer rules in this file.",
                    "Make sure the peer is one you operate or trust.");
                }
              } else if (lower === "cachemgr_passwd") {
                add("INFO", lineNo, "cachemgr_passwd", "Cache manager password directive present",
                  "A cachemgr_passwd directive is present. Reported by directive name and line only - the password value is never shown.",
                  "Keep manager access restricted to localhost (checked below) and the password strong.");
              } else if (lower === "visible_hostname") {
                hasVisibleHostname = true;
              } else if (lower === "forwarded_for") {
                var fv = tokens[1].toLowerCase();
                if (fv === "on") {
                  add("WARNING", lineNo, "forwarded_for", "Client IPs leak in X-Forwarded-For",
                    "forwarded_for on makes Squid add an X-Forwarded-For header carrying the real client IP address to requests it forwards, disclosing internal client addresses to every origin server.",
                    "Set forwarded_for off (or delete/truncate) unless a downstream system genuinely needs client IPs.");
                } else if (fv === "off") {
                  add("INFO", lineNo, "forwarded_for", "Forwarded-For header suppressed",
                    "forwarded_for off keeps client IP addresses out of forwarded requests.",
                    "No change needed.");
                }
              } else if (lower === "via") {
                if (tokens[1].toLowerCase() === "on") {
                  add("INFO", lineNo, "via", "Via header announces the proxy",
                    "via on adds a Via header that announces this proxy (and its version details) to origin servers.",
                    "Set via off if you do not want the proxy to announce itself.");
                }
              } else if (lower === "request_header_access" || lower === "reply_header_access") {
                add("INFO", lineNo, lower, "Header access rule present",
                  "A " + lower + " rule shapes which headers pass through the proxy. Header rules affect privacy and logging; they are noted here, not graded.",
                  "Review that no rule strips headers your applications or logging depend on.");
              } else if (lower === "icp_port" || lower === "htcp_port" || lower === "snmp_port") {
                var pv = tokens[1].toLowerCase();
                if (pv !== "0" && pv !== "disable" && pv !== "disabled") {
                  var label = lower === "snmp_port" ? "SNMP port enabled" : (lower === "icp_port" ? "ICP port enabled" : "HTCP port enabled");
                  var expl = lower === "snmp_port"
                    ? "An enabled snmp_port answers SNMP queries about the proxy and can disclose its configuration and traffic statistics to anyone who can reach the port."
                    : "An enabled " + lower + " lets other caches (or anything that can reach the port) query this proxy; ICP/HTCP are UDP services historically abused for amplification and peer snooping.";
                  add("WARNING", lineNo, lower, label,
                    expl + " It is set to a non-zero, non-disabled value here.",
                    "Set " + lower + " to 0 or disable unless you deliberately run a cache hierarchy or SNMP monitoring, and firewall the port if you do.");
                }
              } else if (lower === "url_rewrite_program" || lower === "redirect_program" || lower === "storeurl_rewrite_program") {
                add("INFO", lineNo, lower, "External rewrite helper configured",
                  "This directive runs an external helper program for URL rewriting. The helper sees every requested URL and runs with the Squid user's privileges; it is noted by directive name and line only.",
                  "Use only helpers you wrote or audited, from paths writable only by trusted users.");
              } else if (lower === "cache") {
                if (tokens[1].toLowerCase() === "deny") {
                  add("INFO", lineNo, "cache", "Legacy cache deny rule",
                    "A cache deny rule controls what may be stored. The older no_cache spelling of this idea is deprecated in current Squid.",
                    "Keep using the cache directive form; no_cache is not needed.");
                }
              } else if (lower === "no_cache") {
                add("INFO", lineNo, "no_cache", "Deprecated no_cache directive",
                  "no_cache is the deprecated legacy form of the cache directive.",
                  "Rewrite it as a cache directive rule.");
              } else if (lower === "always_direct") {
                if (tokens[1].toLowerCase() === "allow") {
                  var adc = tokens.slice(2).map(function (t) { return t.charAt(0) === "!" ? null : t; });
                  if (adc.some(function (n) { return n && isAllish(n); })) alwaysDirectAll.push(lineNo);
                }
              } else if (lower === "include") {
                add("INFO", lineNo, "include", "Included file not read",
                  "This include directive pulls in another file on the host. Included files are not part of the pasted text, so their contents are not graded.",
                  "Paste the included file's contents too if you want them audited.");
              }
            } catch (e) {
              notParsed.push(lineNo);
            }
          }

          // ---- Duplicate http_port values ----
          var seenPort = {};
          httpPorts.forEach(function (p) {
            if (seenPort[p.port]) {
              add("WARNING", p.line, "http_port", "Duplicate http_port",
                "Port " + p.port + " is bound twice: first at line " + seenPort[p.port] + " and again at line " + p.line + ". Squid will fail or behave unexpectedly with two listeners on the same port.",
                "Remove one of the two http_port lines for port " + p.port + " (lines " + seenPort[p.port] + " and " + p.line + ").");
            } else { seenPort[p.port] = p.line; }
          });

          // ---- Safe_ports sanity ----
          safePortsRanges.forEach(function (r) {
            if (r.lo < 1025 && (r.hi - r.lo) > 100) {
              add("WARNING", r.line, "acl", "Safe_ports range is very broad",
                "This Safe_ports definition opens a wide range that starts in the privileged port range (from port " + r.lo + " to " + r.hi + "), weakening the port restrictions Safe_ports exists to provide.",
                "List the specific ports clients may reach instead of a broad low range.");
            }
          });
          if (!aclDefs["Safe_ports"]) {
            add("INFO", null, "acl", "No Safe_ports ACL defined in the file",
              "No Safe_ports ACL is defined in the pasted text. Squid's compiled-in defaults (from the stock configuration) were not part of the paste and are not graded here.",
              "Define Safe_ports explicitly in the file so the port policy travels with the configuration.");
          }

          // ---- visible_hostname ----
          if (!hasVisibleHostname) {
            add("INFO", null, "visible_hostname", "visible_hostname is not set",
              "Without visible_hostname, Squid guesses the host name; a wrong guess can leak an internal name or stop Squid from starting cleanly.",
              "Set visible_hostname to the name this proxy should announce.");
          }

          // ---- Rule-level analysis ----
          function posNames(rule) {
            return rule.conds.filter(function (c) { return !c.neg; }).map(function (c) { return c.name; });
          }
          function ruleRequiresAuth(rule) {
            return rule.conds.some(function (c) { return !c.neg && isProxyAuthAcl(c.name); });
          }
          function isTerminal(rule) {
            var p = posNames(rule);
            return p.length === 1 && isAllish(p[0]);
          }
          function isUnconditionalBroadAllow(rule) {
            if (rule.action !== "allow") return false;
            var p = posNames(rule), hasAll = false, k;
            for (k = 0; k < p.length; k++) {
              if (isAllish(p[k])) { hasAll = true; continue; }
              if (p[k] === "manager" || p[k] === "to_localhost") return false; // request-type conditions, not pass-throughs
              var t = aclTypeOf(p[k]);
              if (t === "src") continue;          // another source restriction still graded via broad set
              if (BUILTIN_ACLS[p[k]]) continue;
              return false;                        // a real extra condition (method, port, auth, domain...)
            }
            return hasAll;
          }

          var firstDenyIdx = -1, idx;
          for (idx = 0; idx < rules.length; idx++) { if (rules[idx].action === "deny") { firstDenyIdx = idx; break; } }
          var broadAllowExists = rules.some(isUnconditionalBroadAllow);

          // Authentication posture
          var nonLoopbackPort = httpPorts.some(function (p) { return !isLoopbackAddr(p.addr); }) || httpPorts.length === 0;
          var anyPortLine = httpPorts.length ? httpPorts[0].line : null;
          if (!authPresent && nonLoopbackPort) {
            add("WARNING", anyPortLine, "auth_param", "No authentication configured",
              "No auth_param directive and no proxy_auth ACL appear anywhere in the file, while the proxy listens beyond loopback. Anyone who can reach the port can use the proxy without logging in.",
              "Add an auth_param scheme and require a proxy_auth ACL in the allow rules, or bind the proxy to loopback/internal addresses only.");
          }

          // Open proxy, manager exposure, CONNECT, shadowed deny, unreachable
          var terminalIdx = -1, terminalLine = null;
          for (idx = 0; idx < rules.length; idx++) {
            var rule = rules[idx], pnames = posNames(rule);

            if (terminalIdx >= 0) {
              add("WARNING", rule.line, "http_access", "UNREACHABLE rule",
                "This http_access rule sits below the terminal rule at line " + terminalLine + ", which already matches every request. First match wins, so this rule can never apply.",
                "Move this rule above line " + terminalLine + ", or delete it if the terminal rule already says what you mean.");
              continue;
            }

            if (rule.action === "allow") {
              // Open proxy
              var allName = null;
              pnames.forEach(function (n) { if (isAllish(n) && !allName) allName = n; });
              if (allName && isUnconditionalBroadAllow(rule) && !ruleRequiresAuth(rule) &&
                  (firstDenyIdx === -1 || idx < firstDenyIdx)) {
                var defNote = aclFirstLine[allName]
                  ? " The source ACL \"" + allName + "\" is defined at line " + aclFirstLine[allName] + " as covering every address."
                  : " The source ACL \"" + allName + "\" is Squid's built-in match-everything ACL.";
                add("BLOCKER", rule.line, "http_access", "Open proxy - allow from everywhere, no login",
                  "This rule allows proxy use from any source address before any deny rule, and it requires no authentication." + defNote,
                  "Restrict the allow to your own networks (for example a localnet source ACL) and require a proxy_auth ACL, or delete this rule.");
              }
              // Manager exposure
              if (pnames.indexOf("manager") >= 0) {
                var srcs = pnames.filter(function (n) { return n !== "manager"; });
                var exposed = srcs.length === 0 || srcs.some(function (n) { return n !== "localhost"; });
                if (exposed) {
                  var srcDesc = srcs.length === 0 ? "with no source restriction at all"
                    : "from source ACL \"" + srcs[0] + "\"" + (aclFirstLine[srcs[0]] ? " (defined at line " + aclFirstLine[srcs[0]] + ")" : "");
                  add("BLOCKER", rule.line, "http_access", "Cache manager exposed beyond localhost",
                    "This rule allows cache manager access " + srcDesc + ". The manager exposes cache contents, statistics, and shutdown/reconfigure actions.",
                    "Allow manager only from localhost (http_access allow localhost manager) and deny manager from everything else.");
                }
              }
              // CONNECT to arbitrary ports
              var hasConnect = rule.conds.some(function (c) { return !c.neg && (c.name === "CONNECT" || aclTypeOf(c.name) === "method" && defEntries(c.name).some(function (e) { return e.values.indexOf("CONNECT") >= 0; })); });
              if (hasConnect) {
                var restrictedToSsl = rule.conds.some(function (c) { return !c.neg && c.name === "SSL_ports"; });
                if (!restrictedToSsl) {
                  add("BLOCKER", rule.line, "http_access", "CONNECT allowed to arbitrary ports",
                    "This rule allows the CONNECT method without restricting the destination to the SSL_ports ACL, so clients can tunnel through the proxy to any port on any host - mail, databases, internal services.",
                    "Deny CONNECT to non-SSL ports (http_access deny CONNECT !SSL_ports) above this rule, so CONNECT can only reach SSL_ports.");
                }
              }
            }

            if (rule.action === "deny") {
              for (var j = 0; j < idx; j++) {
                if (isUnconditionalBroadAllow(rules[j]) && !isTerminal(rules[j])) {
                  add("BLOCKER", rule.line, "http_access", "SHADOWED DENY",
                    "This deny rule can never fire for the traffic it targets: the broad allow at line " + rules[j].line + " sits above it and matches first, and Squid applies the first matching http_access rule.",
                    "Move this deny above line " + rules[j].line + ", or narrow the allow so it no longer covers what this deny is meant to stop.");
                  break;
                }
              }
            }

            if (isTerminal(rule)) { terminalIdx = idx; terminalLine = rule.line; }
          }

          // Missing final deny all
          if (rules.length === 0) {
            add("WARNING", null, "http_access", "No http_access rules found",
              "The pasted text contains no http_access rules at all, so the file's access policy cannot be graded - and a proxy with no explicit rules falls back to behavior you did not choose.",
              "Add explicit http_access rules ending in http_access deny all.");
          } else {
            var last = rules[rules.length - 1];
            var lastIsDenyAll = last.action === "deny" && posNames(last).length === 1 && isAllish(posNames(last)[0]);
            if (!lastIsDenyAll) {
              add(broadAllowExists ? "BLOCKER" : "WARNING", last.line, "http_access",
                "Missing final \"http_access deny all\"",
                "The last http_access rule (line " + last.line + ") is not a deny of everything. Requests that match no rule fall through to Squid's default behavior - the opposite of the last rule - instead of a policy you wrote down." + (broadAllowExists ? " Combined with the broad allow above, unmatched traffic is let through." : ""),
                "End the http_access list with http_access deny all so anything not explicitly allowed is refused.");
            }
          }

          // always_direct allow all combined with a broad allow
          if (broadAllowExists) {
            alwaysDirectAll.forEach(function (ln) {
              add("WARNING", ln, "always_direct", "always_direct allow all with a broad allow in place",
                "always_direct allow all makes the proxy fetch directly for every request, bypassing any parent peer policy, while a broad http_access allow already lets everyone in.",
                "Restrict always_direct to the destinations that should bypass peers, or remove it.");
            });
          }

          // Not-parsed summary
          if (notParsed.length) {
            notParsed.sort(function (a, b) { return a - b; });
            add("INFO", notParsed[0], "parse", "Lines not parsed - not graded",
              "These lines could not be understood as Squid directives and were not graded: line" + (notParsed.length > 1 ? "s " : " ") + notParsed.join(", ") + ". They may be typos, directives from a different Squid version, or text that is not configuration at all.",
              "Check each listed line against the Squid version you run; a directive this auditor does not know is reported here rather than silently skipped.");
          }

          var counts = { BLOCKER: 0, WARNING: 0, INFO: 0 };
          findings.forEach(function (f) { counts[f.sev]++; });
          var verdict = counts.BLOCKER > 0 ? "DO NOT DEPLOY" : (counts.WARNING > 0 ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY");
          var sevRank = { BLOCKER: 0, WARNING: 1, INFO: 2 };
          findings.sort(function (a, b) {
            if (sevRank[a.sev] !== sevRank[b.sev]) return sevRank[a.sev] - sevRank[b.sev];
            var la = a.line == null ? 99999 : a.line, lb = b.line == null ? 99999 : b.line;
            return la - lb;
          });
          return { verdict: verdict, counts: counts, findings: findings, notParsed: notParsed, lineCount: lines.length };
        }

        function buildReport(r) {
          var out = [];
          out.push("J-Dawgs Squid Proxy Config Safety Auditor - Report");
          out.push("Verdict: " + r.verdict);
          out.push("Counts: " + r.counts.BLOCKER + " BLOCKER, " + r.counts.WARNING + " WARNING, " + r.counts.INFO + " INFO, " + r.notParsed.length + " line(s) not parsed");
          out.push("");
          if (r.findings.length === 0) { out.push("No findings."); }
          r.findings.forEach(function (f) {
            out.push("[" + f.sev + "] " + (f.line == null ? "File level" : "Line " + f.line) + " - " + f.directive + ": " + f.name);
            out.push("  " + f.detail);
            out.push("  Fix: " + f.fix);
          });
          out.push("");
          out.push("Notes: static reading only - no proxy or host was contacted and Squid was not run. ACL order was read as documented (first matching http_access rule wins); this is not a live request simulation and does not prove the config will start (that is squid -k parse on an installed host). Password and secret values are reported by directive name and line only and never appear in this report.");
          return out.join("\n");
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-squid-proxy-config-safety-auditor',
  name: 'J-Dawgs Squid Proxy Config Safety Auditor',
  description: 'squid -k parse checks syntax on an installed host; this grades a pasted squid.conf anywhere — open-proxy posture, ACL order, CONNECT exposure — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
