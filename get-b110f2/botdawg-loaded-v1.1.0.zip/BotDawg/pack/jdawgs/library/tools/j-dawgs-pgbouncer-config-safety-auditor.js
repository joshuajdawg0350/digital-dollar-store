'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs PgBouncer Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var RISKY_EXAMPLE = [
          "; Risky example — a pgbouncer.ini with real problems. Do not ship this shape.",
          "[pgbouncer]",
          "listen_addr = *",
          "listen_port = 6432",
          "auth_type = trust",
          "auth_file = /etc/pgbouncer/userlist.txt",
          "default_pool_size = 500",
          "min_pool_size = 10",
          "reserve_pool_size = 5",
          "max_client_conn = 100",
          "pool_mode = session",
          "",
          "[databases]",
          "appdb = host=10.0.0.5 port=5432 dbname=appdb user=appuser password=PlantedFakePW-246810"
        ].join("\n");

        var HARDENED_EXAMPLE = [
          "; Hardened example — the shape of a config that passes.",
          "[pgbouncer]",
          "listen_addr = 127.0.0.1",
          "listen_port = 6432",
          "auth_type = scram-sha-256",
          "auth_file = /etc/pgbouncer/userlist.txt",
          "pool_mode = transaction",
          "server_reset_query = DISCARD ALL",
          "ignore_startup_parameters = extra_float_digits",
          "default_pool_size = 20",
          "min_pool_size = 2",
          "reserve_pool_size = 2",
          "max_client_conn = 200",
          "admin_users = pooler_admin",
          "stats_users = pooler_admin",
          "",
          "[databases]",
          "appdb = host=127.0.0.1 port=5432 dbname=appdb"
        ].join("\n");

        var KNOWN_PGBOUNCER_KEYS = {};
        ("listen_addr listen_port listen_backlog listen_socket unix_socket_dir unix_socket_mode unix_socket_group " +
         "user pidfile logfile syslog syslog_facility syslog_ident log_connections log_disconnections log_pooler_errors log_stats stats_period " +
         "auth_type auth_file auth_hba_file auth_query auth_dbname auth_user admin_users stats_users " +
         "pool_mode max_prepared_statements server_reset_query server_reset_query_always server_check_query server_check_delay " +
         "server_idle_timeout server_lifetime server_login_retry server_fast_close query_wait_timeout query_timeout " +
         "client_idle_timeout client_login_timeout autodb_idle_timeout ignore_startup_parameters track_extra_parameters " +
         "disable_pqexec application_name_add_host conffile service_name job_name max_client_conn default_pool_size " +
         "min_pool_size reserve_pool_size reserve_pool_timeout max_db_connections max_user_connections " +
         "dns_max_ttl dns_nxdomain_ttl dns_zone_check_period client_tls_sslmode client_tls_ca_file client_tls_cert_file " +
         "client_tls_key_file client_tls_protocols client_tls_dheparams client_tls_ciphers client_tls_ecdhcurve " +
         "server_tls_sslmode server_tls_ca_file server_tls_cert_file server_tls_key_file server_tls_protocols server_tls_ciphers " +
         "so_reuseport tcp_defer_accept tcp_socket_buffer tcp_keepalive tcp_keepcnt tcp_keepidle tcp_keepintvl tcp_user_timeout " +
         "load_balance_hosts pkt_buf sbuf_loopcnt verbose suspend_timeout shutdown_wait restart_wait")
          .split(" ").forEach(function (k) { KNOWN_PGBOUNCER_KEYS[k] = true; });

        var KNOWN_DB_KEYS = {};
        ("host port dbname user password pool_size pool_mode max_db_connections connect_query auth_user prepare_threshold")
          .split(" ").forEach(function (k) { KNOWN_DB_KEYS[k] = true; });

        var SEV_RANK = { BLOCKER: 0, WARNING: 1, INFO: 2, GOOD: 3 };

        function parseIni(text) {
          var sections = {};       // name -> { line, entries: [{key, keyLower, value, line}] }
          var order = [];
          var notParsed = [];      // line numbers only
          var current = null;
          var lines = text.split(/\r\n|\r|\n/);
          for (var i = 0; i < lines.length; i++) {
            var lineNo = i + 1;
            var raw = lines[i];
            var t = raw.replace(/^\s+|\s+$/g, "");
            if (t === "") continue;
            var c0 = t.charAt(0);
            if (c0 === ";" || c0 === "#") continue;
            var secMatch = /^\[([^\]]+)\]\s*$/.exec(t);
            if (secMatch) {
              var name = secMatch[1].replace(/^\s+|\s+$/g, "").toLowerCase();
              if (!sections[name]) { sections[name] = { line: lineNo, entries: [] }; order.push(name); }
              current = sections[name];
              continue;
            }
            var eq = t.indexOf("=");
            if (eq > 0 && current) {
              var key = t.slice(0, eq).replace(/^\s+|\s+$/g, "");
              var value = t.slice(eq + 1).replace(/^\s+|\s+$/g, "");
              if (value.length >= 2 && value.charAt(0) === '"' && value.charAt(value.length - 1) === '"') {
                value = value.slice(1, -1);
              }
              current.entries.push({ key: key, keyLower: key.toLowerCase(), value: value, line: lineNo });
              continue;
            }
            notParsed.push(lineNo);
          }
          return { sections: sections, order: order, notParsed: notParsed };
        }

        function lastEntry(section, keyLower) {
          if (!section) return null;
          var found = null;
          section.entries.forEach(function (e) { if (e.keyLower === keyLower) found = e; });
          return found;
        }

        function allEntries(section, keyLower) {
          var out = [];
          if (!section) return out;
          section.entries.forEach(function (e) { if (e.keyLower === keyLower) out.push(e); });
          return out;
        }

        function audit(text) {
          var parsed = parseIni(text);
          var findings = [];
          var notAudited = []; // {name, line}
          function add(sev, line, key, msg, fix) {
            findings.push({ sev: sev, line: line, key: key, msg: msg, fix: fix || null });
          }

          var pg = parsed.sections["pgbouncer"] || null;
          var dbs = parsed.sections["databases"] || null;
          var users = parsed.sections["users"] || null;

          // Unknown sections: not audited.
          parsed.order.forEach(function (name) {
            if (name !== "pgbouncer" && name !== "databases" && name !== "users") {
              notAudited.push({ name: "[" + name + "] section", line: parsed.sections[name].line });
            }
          });

          if (!pg) {
            add("WARNING", null, "[pgbouncer]",
              "No [pgbouncer] section was found in the paste, so the main pooler settings — auth, listener, pool sizes — could not be graded.",
              "Paste the full pgbouncer.ini, including its [pgbouncer] section.");
          }

          // Duplicate keys: INI last-value-wins, both lines named.
          parsed.order.forEach(function (name) {
            var sec = parsed.sections[name];
            var byKey = {};
            sec.entries.forEach(function (e) {
              if (!byKey[e.keyLower]) byKey[e.keyLower] = [];
              byKey[e.keyLower].push(e);
            });
            Object.keys(byKey).forEach(function (k) {
              var list = byKey[k];
              for (var j = 1; j < list.length; j++) {
                add("WARNING", list[j].line, list[j].key,
                  "Key \"" + list[j].key + "\" is set more than once in [" + name + "] — first on line " + list[0].line + ", again on line " + list[j].line + ". INI parsing is last-value-wins, so line " + list[j].line + " is the value in effect and line " + list[0].line + " is dead text.",
                  "Delete the line you do not mean, so the file says one thing.");
              }
            });
          });

          // Unknown keys in [pgbouncer]: NOT AUDITED by name.
          if (pg) {
            pg.entries.forEach(function (e) {
              if (!KNOWN_PGBOUNCER_KEYS[e.keyLower]) notAudited.push({ name: e.key, line: e.line });
            });
          }

          // ---- auth_type ----
          var authEntry = pg ? lastEntry(pg, "auth_type") : null;
          var authVal = authEntry ? authEntry.value.toLowerCase() : null;
          if (pg) {
            if (!authEntry) {
              add("WARNING", pg.line, "auth_type",
                "auth_type is not set anywhere in [pgbouncer]. Its default depends on the PgBouncer version in use, and that cannot be known from the pasted text — so the effective authentication method is NOT SETTLED by this audit.",
                "Set auth_type explicitly — scram-sha-256 is the strong choice — so the file, not a version default, decides how users are authenticated.");
            } else if (authVal === "trust") {
              add("BLOCKER", authEntry.line, "auth_type",
                "auth_type = trust: anyone who can connect to the pooler is trusted — PgBouncer performs no password check at all. Any user name a client claims is accepted.",
                "Set auth_type = scram-sha-256 and list real credentials in an auth_file (userlist.txt).");
            } else if (authVal === "plain") {
              add("BLOCKER", authEntry.line, "auth_type",
                "auth_type = plain is obsolete weak auth: clients send the password in clear text, readable by anyone who can see the traffic.",
                "Set auth_type = scram-sha-256 and list real credentials in an auth_file (userlist.txt).");
            } else if (authVal === "crypt") {
              add("WARNING", authEntry.line, "auth_type",
                "auth_type = crypt is obsolete weak auth — a legacy password scheme kept only for very old clients.",
                "Move to auth_type = scram-sha-256.");
            } else if (authVal === "md5") {
              add("WARNING", authEntry.line, "auth_type",
                "auth_type = md5 works, but MD5 password hashing is dated and weaker than the modern option.",
                "Prefer auth_type = scram-sha-256.");
            } else if (authVal === "scram-sha-256") {
              add("GOOD", authEntry.line, "auth_type",
                "auth_type = scram-sha-256: the strongest password authentication PgBouncer offers — passwords are never sent or stored in plain form.");
            } else if (authVal === "cert") {
              add("INFO", authEntry.line, "auth_type",
                "auth_type = cert noted: clients authenticate with a TLS client certificate instead of a password. The certificate setup itself lives outside this paste and was not graded.");
            } else if (authVal === "hba") {
              add("INFO", authEntry.line, "auth_type",
                "auth_type = hba noted: authentication is delegated to the rules in auth_hba_file. That file is not part of the paste, so those rules were not graded.");
            } else if (authVal === "any") {
              add("WARNING", authEntry.line, "auth_type",
                "auth_type = any performs no password verification — like trust, a claimed user name is taken at face value.",
                "Set auth_type = scram-sha-256 and list real credentials in an auth_file (userlist.txt).");
            } else {
              add("WARNING", authEntry.line, "auth_type",
                "auth_type is set to a value this audit does not recognize, so how users will be authenticated is NOT SETTLED from the paste.",
                "Use a documented value — scram-sha-256 is the strong choice.");
            }
          }

          // ---- listen_addr ----
          var listenEntry = pg ? lastEntry(pg, "listen_addr") : null;
          if (pg) {
            if (!listenEntry) {
              add("INFO", pg.line, "listen_addr",
                "listen_addr is not set: with no listen address in the file, PgBouncer takes TCP connections on no network interface by default — clients reach it through its unix socket. Noted, not a flaw.");
            } else {
              var tokens = listenEntry.value.split(",").map(function (s) { return s.replace(/^\s+|\s+$/g, "").toLowerCase(); });
              var allInterfaces = tokens.some(function (t) { return t === "*" || t === "0.0.0.0" || t === "::"; });
              var loopbackOnly = tokens.every(function (t) {
                return t === "localhost" || t === "127.0.0.1" || t === "::1" || t.indexOf("127.") === 0;
              });
              if (allInterfaces && authVal === "trust") {
                add("BLOCKER", listenEntry.line, "listen_addr",
                  "listen_addr opens the pooler on every network interface (* / 0.0.0.0) AND auth_type = trust means no password check — anyone who can reach this host and port can use the database as any user.",
                  "Bind listen_addr to 127.0.0.1 (or a private interface behind a firewall) and set auth_type = scram-sha-256.");
              } else if (allInterfaces) {
                add("WARNING", listenEntry.line, "listen_addr",
                  "listen_addr opens the pooler on every network interface (* / 0.0.0.0): anyone who can reach the port can attempt to log in.",
                  "Bind listen_addr to 127.0.0.1 or a specific private address, or firewall the port to known clients.");
              } else if (loopbackOnly) {
                add("GOOD", listenEntry.line, "listen_addr",
                  "listen_addr is localhost-only (" + listenEntry.value + "): the pooler answers only on this machine's loopback interface.");
              } else {
                add("WARNING", listenEntry.line, "listen_addr",
                  "listen_addr binds a non-loopback address (" + listenEntry.value + "), so the pooler is reachable from the network.",
                  "Make sure a firewall limits who can reach the port, or bind 127.0.0.1 if clients are local.");
              }
            }
          }

          // ---- auth_file / credential source ----
          var authFileEntry = pg ? lastEntry(pg, "auth_file") : null;
          var authQueryEntry = pg ? lastEntry(pg, "auth_query") : null;
          var authDbnameEntry = pg ? lastEntry(pg, "auth_dbname") : null;
          var needsCreds = authVal === "md5" || authVal === "scram-sha-256" || authVal === "plain" || authVal === "crypt";
          if (pg) {
            if (authFileEntry && authVal === "trust") {
              add("INFO", authFileEntry.line, "auth_file",
                "auth_file is set, but auth_type = trust never reads it — no password in that file is ever checked while trust is on.");
            } else if (authFileEntry) {
              add("GOOD", authFileEntry.line, "auth_file",
                "auth_file is set: user credentials come from that file. The file itself is not part of the paste, so its contents were not graded.");
            } else if (needsCreds && !authQueryEntry && !authDbnameEntry) {
              add("WARNING", authEntry ? authEntry.line : pg.line, "auth_file",
                "auth_type = " + authVal + " checks passwords, but no auth_file is set and no auth_query / auth_dbname route is configured — the paste names no source of credentials for PgBouncer to check against.",
                "Set auth_file to your userlist.txt, or configure auth_dbname + auth_query so credentials come from the database.");
            } else if (needsCreds && authQueryEntry) {
              add("INFO", authQueryEntry.line, "auth_query",
                "No auth_file is set, but auth_query is configured: credentials are looked up in the database instead. That lookup path was noted, not graded.");
            }
          }

          // ---- admin_users / stats_users ----
          var appUsers = {};
          if (dbs) {
            dbs.entries.forEach(function (e) {
              var m = /(?:^|\s)user\s*=\s*"?([^"\s]+)"?/.exec(e.value);
              if (m) appUsers[m[1]] = true;
            });
          }
          if (users) { users.entries.forEach(function (e) { appUsers[e.key] = true; }); }
          var authUserEntry = pg ? lastEntry(pg, "auth_user") : null;
          if (authUserEntry) appUsers[authUserEntry.value] = true;

          ["admin_users", "stats_users"].forEach(function (keyName) {
            var e = pg ? lastEntry(pg, keyName) : null;
            if (!pg) return;
            if (!e) {
              add("INFO", pg.line, keyName,
                keyName + " is not set: PgBouncer's default leaves the admin console with no named " + (keyName === "admin_users" ? "admin" : "stats") + " users, so nobody gets that console access by name. The default is noted, not graded as a flaw.");
              return;
            }
            var names = e.value.split(",").map(function (s) { return s.replace(/^\s+|\s+$/g, ""); }).filter(Boolean);
            var shared = names.filter(function (n) { return appUsers[n]; });
            if (shared.length) {
              add("WARNING", e.line, keyName,
                keyName + " includes \"" + shared.join("\", \"") + "\", which is also an application database user in this same config — the everyday app credential would also unlock the PgBouncer " + (keyName === "admin_users" ? "admin" : "stats") + " console.",
                "Use a dedicated " + keyName + " account that applications never connect as.");
            } else {
              add("INFO", e.line, keyName,
                keyName + " is set to named user(s) (" + names.join(", ") + ") — and none of them is an application user in this config.");
            }
          });

          // ---- pool arithmetic ----
          function poolNum(keyName, def) {
            var e = pg ? lastEntry(pg, keyName) : null;
            if (!e) return { val: def, line: null, set: false, bad: false };
            var n = parseInt(e.value, 10);
            if (isNaN(n) || String(n) !== e.value.replace(/^\s+|\s+$/g, "") && isNaN(Number(e.value))) {
              return { val: def, line: e.line, set: true, bad: true };
            }
            if (isNaN(n)) return { val: def, line: e.line, set: true, bad: true };
            return { val: n, line: e.line, set: true, bad: false };
          }
          var pool = null;
          if (pg) {
            var dps = poolNum("default_pool_size", 20);
            var mcc = poolNum("max_client_conn", 100);
            var minp = poolNum("min_pool_size", 0);
            var rps = poolNum("reserve_pool_size", 0);
            pool = { dps: dps, mcc: mcc, minp: minp, rps: rps };
            [["default_pool_size", dps], ["max_client_conn", mcc], ["min_pool_size", minp], ["reserve_pool_size", rps]].forEach(function (pair) {
              if (pair[1].bad) {
                add("WARNING", pair[1].line, pair[0],
                  pair[0] + " is set to a value that is not a whole number, so the pool arithmetic below falls back to the PgBouncer default for this key.",
                  "Set " + pair[0] + " to a whole number.");
              }
            });
            if (mcc.val < dps.val) {
              add("WARNING", mcc.line || dps.line, "max_client_conn",
                "Contradiction in the pool arithmetic: max_client_conn = " + mcc.val + " is smaller than default_pool_size = " + dps.val + ". Each database/user pool is sized to hold up to " + dps.val + " server connections, but the whole pooler stops accepting clients at " + mcc.val + " — so with a single pool, at most " + mcc.val + " of the " + dps.val + " pooled server connections can ever be handed out, and " + (dps.val - mcc.val) + " of them are sized for clients who can never connect.",
                "Raise max_client_conn above default_pool_size (with headroom for every pool), or lower default_pool_size to what the database can actually serve.");
            }
            if (dps.val > 100) {
              add("WARNING", dps.line, "default_pool_size",
                "default_pool_size = " + dps.val + " is oversized: that is up to " + dps.val + " PostgreSQL server connections for every single database/user pair, and pairs multiply. PostgreSQL backends are heavyweight — few single servers sustain that per pair.",
                "Size default_pool_size from the database's own capacity (max_connections minus room for admin and other services), not from client count.");
            }
            if (minp.val > dps.val) {
              add("WARNING", minp.line, "min_pool_size",
                "Contradiction in the pool arithmetic: min_pool_size = " + minp.val + " is larger than default_pool_size = " + dps.val + " — the pool is told to always keep more connections warm than its full size.",
                "Set min_pool_size at or below default_pool_size.");
            }
            if (rps.val > dps.val) {
              add("WARNING", rps.line, "reserve_pool_size",
                "reserve_pool_size = " + rps.val + " is larger than default_pool_size = " + dps.val + " itself — the emergency reserve outweighs the whole regular pool.",
                "Keep reserve_pool_size a small fraction of default_pool_size.");
            }
          }

          // ---- pool_mode / server_reset_query / ignore_startup_parameters ----
          var poolModeEntry = pg ? lastEntry(pg, "pool_mode") : null;
          var poolMode = poolModeEntry ? poolModeEntry.value.toLowerCase() : "session";
          if (pg) {
            if (!poolModeEntry) {
              add("INFO", pg.line, "pool_mode",
                "pool_mode is not set: PgBouncer's default is session — a server connection is held for the client's entire session, the longest hold of the three modes.");
            } else if (poolMode === "statement") {
              add("INFO", poolModeEntry.line, "pool_mode",
                "pool_mode = statement noted: the most restrictive mode — a server connection is returned after every single statement, so nothing that needs session state across statements can work through this pooler.");
            } else if (poolMode === "session") {
              add("INFO", poolModeEntry.line, "pool_mode",
                "pool_mode = session noted: a server connection is held for the client's entire session — the longest hold of the three modes, so pooled connections free up the slowest.");
            } else if (poolMode === "transaction") {
              add("INFO", poolModeEntry.line, "pool_mode",
                "pool_mode = transaction noted: a server connection is held only for one transaction, then returned to the pool — the usual middle ground.");
            } else {
              add("WARNING", poolModeEntry.line, "pool_mode",
                "pool_mode is set to a value this audit does not recognize (expected session, transaction, or statement), so how connections are held is NOT SETTLED from the paste.",
                "Use session, transaction, or statement.");
            }
            var srq = lastEntry(pg, "server_reset_query");
            if (!srq && poolMode === "transaction") {
              add("INFO", pg.line, "server_reset_query",
                "No server_reset_query is set with pool_mode = transaction: in transaction pooling PgBouncer falls back to its built-in DISCARD ALL when this is unset. Noted, not a flaw.");
            } else if (srq) {
              add("INFO", srq.line, "server_reset_query",
                "server_reset_query is set (line " + srq.line + "): it runs when a server connection is returned to the pool, clearing session state before the next client uses it.");
            }
            var isp = lastEntry(pg, "ignore_startup_parameters");
            if (isp) {
              add("INFO", isp.line, "ignore_startup_parameters",
                "ignore_startup_parameters is set (line " + isp.line + "): the startup parameters it names are silently accepted and dropped instead of raising an error — make sure nothing a client depends on is being swallowed.");
            }
          }

          // ---- [databases] secrets + sub-keys (values never shown) ----
          if (dbs) {
            dbs.entries.forEach(function (e) {
              if (/(^|\s)password\s*=/i.test(e.value)) {
                add("WARNING", e.line, "password (in [databases] line \"" + e.key + "\")",
                  "The database line for \"" + e.key + "\" (line " + e.line + ") contains a password= key — a plaintext credential sitting in this config file, readable by anyone who can read the file. The value itself is never shown in this audit or its report.",
                  "Move credentials into the auth_file (userlist.txt) and drop password= from the database line.");
              }
              var subRe = /([A-Za-z_][A-Za-z0-9_]*)\s*=/g, m;
              var seenSub = {};
              while ((m = subRe.exec(e.value)) !== null) {
                var sk = m[1].toLowerCase();
                if (!KNOWN_DB_KEYS[sk] && !seenSub[sk]) {
                  seenSub[sk] = true;
                  notAudited.push({ name: sk + " (in [databases] line \"" + e.key + "\")", line: e.line });
                }
              }
            });
          }

          // ---- [users] credentials: key name + line only ----
          if (users) {
            users.entries.forEach(function (e) {
              add("INFO", e.line, e.key + " (in [users])",
                "Line " + e.line + " stores a credential for user \"" + e.key + "\" in the [users] section. The value is never shown in this audit or its report.");
            });
          }

          findings.sort(function (a, b) {
            if (SEV_RANK[a.sev] !== SEV_RANK[b.sev]) return SEV_RANK[a.sev] - SEV_RANK[b.sev];
            var la = a.line === null ? 99999 : a.line, lb = b.line === null ? 99999 : b.line;
            return la - lb;
          });

          var counts = { BLOCKER: 0, WARNING: 0, INFO: 0, GOOD: 0 };
          findings.forEach(function (f) { counts[f.sev]++; });
          var verdict = counts.BLOCKER > 0 ? "DO NOT DEPLOY" : (counts.WARNING > 0 ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY");

          return {
            findings: findings,
            counts: counts,
            verdict: verdict,
            pool: pool,
            poolMode: poolMode,
            notAudited: notAudited,
            notParsed: parsed.notParsed,
            hasPg: !!pg
          };
        }

        function buildReport(r) {
          var out = [];
          out.push("J-Dawgs PgBouncer Config Safety Auditor — audit report");
          out.push("Verdict: " + r.verdict);
          out.push("Findings: " + r.counts.BLOCKER + " blocker(s), " + r.counts.WARNING + " warning(s), " +
                   r.counts.INFO + " info, " + r.counts.GOOD + " good.");
          out.push("Secret values are never included in this report — findings name the key and line only.");
          out.push("");
          if (r.pool) {
            out.push("POOL ARITHMETIC");
            out.push("  default_pool_size = " + r.pool.dps.val + (r.pool.dps.set ? " (line " + r.pool.dps.line + ")" : " (PgBouncer default, not set)"));
            out.push("  min_pool_size     = " + r.pool.minp.val + (r.pool.minp.set ? " (line " + r.pool.minp.line + ")" : " (PgBouncer default, not set)"));
            out.push("  reserve_pool_size = " + r.pool.rps.val + (r.pool.rps.set ? " (line " + r.pool.rps.line + ")" : " (PgBouncer default, not set)"));
            out.push("  max_client_conn   = " + r.pool.mcc.val + (r.pool.mcc.set ? " (line " + r.pool.mcc.line + ")" : " (PgBouncer default, not set)"));
            out.push("  pool_mode         = " + r.poolMode);
            out.push("  Per database/user pool: up to " + r.pool.dps.val + " server connections, plus up to " +
                     r.pool.rps.val + " reserve = " + (r.pool.dps.val + r.pool.rps.val) + " max per pool.");
            out.push("  Client cap vs one pool: max_client_conn " + r.pool.mcc.val + " / default_pool_size " + r.pool.dps.val +
                     " = " + (Math.round((r.pool.mcc.val / r.pool.dps.val) * 100) / 100) + " clients per pooled server connection.");
            out.push("");
          }
          out.push("FINDINGS");
          if (!r.findings.length) out.push("  (none)");
          r.findings.forEach(function (f) {
            out.push("[" + f.sev + "]" + (f.line ? " Line " + f.line : " (whole file)") + " — " + f.key + ": " + f.msg);
            if (f.fix) out.push("    Fix: " + f.fix);
          });
          out.push("");
          out.push("NOT AUDITED (names only — these keys/settings were seen but are outside this audit's checks):");
          if (!r.notAudited.length) out.push("  (none)");
          r.notAudited.forEach(function (n) { out.push("  - " + n.name + " (line " + n.line + ")"); });
          out.push("");
          out.push("NOT PARSED (lines that are not a section header, a comment, or a key = value line):");
          if (!r.notParsed.length) out.push("  (none)");
          r.notParsed.forEach(function (ln) { out.push("  - line " + ln); });
          return out.join("\n");
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-pgbouncer-config-safety-auditor',
  name: 'J-Dawgs PgBouncer Config Safety Auditor',
  description: 'Grades a pasted pgbouncer.ini offline: auth_type and listen_addr exposure, admin users and stats users posture, pool arithmetic shown (max_client_conn against default_pool_size and pool mode), secrets by key name only — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
