'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Mattermost Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Example configs ---------- */

      var RISKY = [
        '{',
        '  "ServiceSettings": {',
        '    "SiteURL": "http://chat.example.internal",',
        '    "ListenAddress": ":8065",',
        '    "TLSCertFile": "",',
        '    "TLSKeyFile": "",',
        '    "EnableInsecureOutgoingConnections": true,',
        '    "SiteURL": "http://chat.example.internal"',
        '  },',
        '  "TeamSettings": {',
        '    "EnableOpenServer": true,',
        '    "EnableUserCreation": true,',
        '    "MaxUsersPerTeam": 50',
        '  },',
        '  "PasswordSettings": {',
        '    "MinimumLength": 5,',
        '    "Lowercase": false,',
        '    "Number": false,',
        '    "Uppercase": false,',
        '    "Symbol": false',
        '  },',
        '  "SqlSettings": {',
        '    "DriverName": "postgres",',
        '    "DataSource": "postgres://mmuser:dbpass@db.internal:5432/mattermost?sslmode=disable",',
        '    "AtRestEncryptKey": ""',
        '  },',
        '  "EmailSettings": {',
        '    "SMTPServer": "smtp.example.internal",',
        '    "SMTPPort": "587",',
        '    "SMTPUsername": "mattermost@example.internal",',
        '    "SMTPPassword": "canary-smtp-pw-9f27-DO-NOT-PRINT",',
        '    "RequireEmailVerification": false',
        '  },',
        '  "FileSettings": {',
        '    "DriverName": "amazons3",',
        '    "AmazonS3AccessKeyId": "AKIAEXAMPLE0000000",',
        '    "AmazonS3SecretKey": "example-s3-secret-value-do-not-print",',
        '    "EnablePublicLink": true,',
        '    "MaxFileSize": 1048576000',
        '  },',
        '  "GuestAccountsSettings": {',
        '    "Enable": true',
        '  },',
        '  "LogSettings": {',
        '    "EnableConsole": true,',
        '    "ConsoleLevel": "DEBUG",',
        '    "EnableFile": true,',
        '    "FileLevel": "DEBUG"',
        '  },',
        '  "ExperimentalSettings": {',
        '    "DisablePostMetadata": true',
        '  }',
        '}'
      ].join("\n");

      var HARDENED = [
        '{',
        '  "ServiceSettings": {',
        '    "SiteURL": "https://chat.example.com",',
        '    "ListenAddress": ":8065",',
        '    "TLSCertFile": "/etc/mattermost/tls/fullchain.pem",',
        '    "TLSKeyFile": "/etc/mattermost/tls/privkey.pem",',
        '    "EnableInsecureOutgoingConnections": false',
        '  },',
        '  "TeamSettings": {',
        '    "EnableOpenServer": false,',
        '    "EnableUserCreation": true,',
        '    "MaxUsersPerTeam": 50',
        '  },',
        '  "PasswordSettings": {',
        '    "MinimumLength": 12,',
        '    "Lowercase": true,',
        '    "Number": true,',
        '    "Uppercase": true,',
        '    "Symbol": true',
        '  },',
        '  "EmailSettings": {',
        '    "SMTPServer": "smtp.example.com",',
        '    "SMTPPort": "587",',
        '    "SMTPUsername": "mattermost@example.com",',
        '    "RequireEmailVerification": true',
        '  },',
        '  "FileSettings": {',
        '    "DriverName": "local",',
        '    "Directory": "/var/mattermost/data/",',
        '    "EnablePublicLink": false,',
        '    "MaxFileSize": 52428800',
        '  },',
        '  "GuestAccountsSettings": {',
        '    "Enable": false',
        '  },',
        '  "LogSettings": {',
        '    "EnableConsole": true,',
        '    "ConsoleLevel": "INFO",',
        '    "EnableFile": true,',
        '    "FileLevel": "INFO"',
        '  }',
        '}'
      ].join("\n");

      /* ---------- JSON text scanner: line map + duplicate keys ----------
         Runs only on text JSON.parse already accepted, so it can stay simple.
         Secret VALUES are never read out of this scanner — keys only. */
      function scanJson(text){
        var i = 0, line = 1, n = text.length;
        var lineMap = {}, duplicates = [];
        function skipWs(){
          while (i < n){
            var c = text.charAt(i);
            if (c === "\n"){ line++; i++; }
            else if (c === " " || c === "\t" || c === "\r"){ i++; }
            else break;
          }
        }
        function readString(){
          var startLine = line, s = "";
          i++; // opening quote
          while (i < n){
            var c = text.charAt(i);
            if (c === "\\"){ s += text.charAt(i + 1); i += 2; continue; }
            if (c === "\""){ i++; break; }
            if (c === "\n"){ line++; }
            s += c; i++;
          }
          return { value: s, line: startLine };
        }
        function parseValue(path){
          skipWs();
          var c = text.charAt(i);
          if (c === "{") parseObject(path);
          else if (c === "[") parseArray(path);
          else if (c === "\"") readString();
          else { while (i < n && ",}] \t\r\n".indexOf(text.charAt(i)) === -1) i++; }
        }
        function parseObject(path){
          i++; // {
          var seen = {};
          skipWs();
          if (text.charAt(i) === "}"){ i++; return; }
          while (i < n){
            skipWs();
            var k = readString();
            var keyPath = path ? path + "." + k.value : k.value;
            if (Object.prototype.hasOwnProperty.call(seen, k.value)){
              duplicates.push({ path: keyPath, line: k.line, firstLine: seen[k.value] });
            } else {
              seen[k.value] = k.line;
            }
            if (!(keyPath in lineMap)) lineMap[keyPath] = k.line;
            skipWs();
            if (text.charAt(i) === ":") i++;
            parseValue(keyPath);
            skipWs();
            if (text.charAt(i) === ","){ i++; continue; }
            if (text.charAt(i) === "}"){ i++; break; }
            break;
          }
        }
        function parseArray(path){
          i++; // [
          var idx = 0;
          skipWs();
          if (text.charAt(i) === "]"){ i++; return; }
          while (i < n){
            parseValue(path + "[" + idx + "]"); idx++;
            skipWs();
            if (text.charAt(i) === ","){ i++; continue; }
            if (text.charAt(i) === "]"){ i++; break; }
            break;
          }
        }
        parseValue("");
        return { lineMap: lineMap, duplicates: duplicates };
      }

      /* ---------- Helpers ---------- */
      function get(obj, path){
        var parts = path.split("."), cur = obj;
        for (var j = 0; j < parts.length; j++){
          if (cur === null || typeof cur !== "object") return undefined;
          cur = cur[parts[j]];
        }
        return cur;
      }
      function isAllInterfaces(listen){
        if (typeof listen !== "string") return false;
        var host = listen;
        var idx = listen.lastIndexOf(":");
        if (idx > -1) host = listen.slice(0, idx);
        host = host.replace(/^\[|\]$/g, "").trim();
        return host === "" || host === "0.0.0.0" || host === "::";
      }
      function humanSize(bytes){
        if (bytes >= 1073741824) return (bytes / 1073741824).toFixed(2) + " GiB";
        if (bytes >= 1048576) return (bytes / 1048576).toFixed(2) + " MiB";
        if (bytes >= 1024) return (bytes / 1024).toFixed(2) + " KiB";
        return bytes + " B";
      }

      var KNOWN_SECTIONS = {
        ServiceSettings:1, TeamSettings:1, SqlSettings:1, LogSettings:1, PasswordSettings:1,
        FileSettings:1, EmailSettings:1, RateLimitSettings:1, PrivacySettings:1, SupportSettings:1,
        AnnouncementSettings:1, ClusterSettings:1, MetricsSettings:1, LocalizationSettings:1,
        SamlSettings:1, LdapSettings:1, GitLabSettings:1, GoogleSettings:1, Office365Settings:1,
        ComplianceSettings:1, NativeAppSettings:1, CacheSettings:1, ElasticsearchSettings:1,
        DataRetentionSettings:1, MessageExportSettings:1, JobSettings:1, PluginSettings:1,
        DisplaySettings:1, GuestAccountsSettings:1, ImageProxySettings:1, BleveSettings:1,
        ImportSettings:1, LicenseSettings:1, PasswordSettings_:0, ExperimentalSettingsX:0
      };
      delete KNOWN_SECTIONS.PasswordSettings_; delete KNOWN_SECTIONS.ExperimentalSettingsX;

      var SECRET_KEY_RE = /(password|passwd|secret|token|api[-_]?key|private[-_]?key|encrypt[-_]?key|credential)/i;

      /* ---------- The audit ---------- */
      function audit(text){
        var findings = [];
        function add(sev, path, msg, line){
          findings.push({ sev: sev, path: path || "—", msg: msg, line: (typeof line === "number" ? line : null) });
        }

        if (!text || !text.trim()){
          return { verdict: "NOT PARSED", counts: null, findings: [
            { sev: "INFO", path: "—", line: null, msg: "Nothing to audit yet — paste a Mattermost config.json, or load one of the examples." }
          ], notAudited: [] };
        }

        var cfg;
        try {
          cfg = JSON.parse(text);
        } catch (e) {
          var posMsg = String(e && e.message || e);
          var where = "";
          var lm = posMsg.match(/line\s+(\d+)\s+column\s+(\d+)/i);
          var pm = posMsg.match(/position\s+(\d+)/i);
          if (lm) {
            where = " Line " + lm[1] + ", column " + lm[2] + ".";
          } else if (pm) {
            var pos = parseInt(pm[1], 10), ln = 1, lastNl = -1;
            for (var q = 0; q < pos && q < text.length; q++){
              if (text.charAt(q) === "\n"){ ln++; lastNl = q; }
            }
            where = " Line " + ln + ", column " + (pos - lastNl) + " (character position " + pos + ").";
          }
          return { verdict: "NOT PARSED", counts: null, findings: [
            { sev: "BLOCKER", path: "(document)", line: null,
              msg: "Invalid JSON — the config was NOT PARSED, so no check could run. Parser reported: " +
                   posMsg.replace(/\s+in JSON.*$/i, "") + "." + where +
                   " Fix the syntax first; a config that does not parse does not start." }
          ], notAudited: [] };
        }

        if (cfg === null || typeof cfg !== "object" || Array.isArray(cfg)){
          return { verdict: "NOT PARSED", counts: null, findings: [
            { sev: "BLOCKER", path: "(document)", line: null,
              msg: "The pasted JSON is not an object at the top level, so it is not a Mattermost config.json shape. No checks ran." }
          ], notAudited: [] };
        }

        var scan = scanJson(text);
        function L(path){ return (path in scan.lineMap) ? scan.lineMap[path] : null; }

        /* Duplicate keys */
        scan.duplicates.forEach(function(d){
          add("WARNING", d.path,
            "Duplicate JSON key — this key appears again at line " + d.line + " (first occurrence line " +
            d.firstLine + "). Standard parsers silently keep only the last value, so the value you think is live may not be.",
            d.line);
        });

        /* Unknown top-level sections */
        var notAudited = [];
        Object.keys(cfg).forEach(function(k){
          if (!KNOWN_SECTIONS[k]){
            notAudited.push(k);
            add("INFO", k, "Unknown top-level section — NOT AUDITED. This auditor has no checks for \"" + k +
              "\"; its contents were not graded.", L(k));
          }
        });

        /* ----- ServiceSettings: SiteURL / listen / TLS / insecure outgoing ----- */
        var svc = get(cfg, "ServiceSettings") || {};
        var siteURL = svc.SiteURL;
        var tlsOn = (typeof svc.TLSCertFile === "string" && svc.TLSCertFile.trim() !== "") &&
                    (typeof svc.TLSKeyFile === "string" && svc.TLSKeyFile.trim() !== "");
        var allIfaces = isAllInterfaces(svc.ListenAddress);

        if (siteURL === undefined || siteURL === null || String(siteURL).trim() === ""){
          add("WARNING", "ServiceSettings.SiteURL",
            "SiteURL is empty or missing. Mattermost builds email links, password resets, and integration URLs from it — set it to the exact public URL of the server.", L("ServiceSettings.SiteURL"));
        } else if (/^http:\/\//i.test(String(siteURL))){
          if (allIfaces && !tlsOn){
            add("BLOCKER", "ServiceSettings.SiteURL",
              "SiteURL uses plain http AND the server listens on all interfaces with TLS off — logins and session cookies cross the network unencrypted to anyone who can reach the host. Serve https (TLS files or a TLS-terminating reverse proxy) before deploying.", L("ServiceSettings.SiteURL"));
          } else {
            add("WARNING", "ServiceSettings.SiteURL",
              "SiteURL uses plain http, not https. Browsers and email clients will treat login and reset links as insecure; move to https unless this sits behind a TLS-terminating proxy that rewrites it.", L("ServiceSettings.SiteURL"));
          }
        } else if (/^https:\/\//i.test(String(siteURL))){
          if (tlsOn || !allIfaces){
            add("OK", "ServiceSettings.SiteURL",
              "SiteURL uses https" + (tlsOn ? " and TLS certificate/key files are set on the server itself." : ". (If TLS terminates at a reverse proxy, confirm the proxy is the only public path in.)"), L("ServiceSettings.SiteURL"));
          } else {
            add("INFO", "ServiceSettings.SiteURL",
              "SiteURL uses https but no TLSCertFile/TLSKeyFile are set in this config — that is correct only if a reverse proxy terminates TLS in front of Mattermost.", L("ServiceSettings.SiteURL"));
          }
        } else {
          add("WARNING", "ServiceSettings.SiteURL",
            "SiteURL does not start with http:// or https://, so link generation will misbehave. Set the full public URL including the scheme.", L("ServiceSettings.SiteURL"));
        }

        if (svc.ListenAddress !== undefined){
          if (allIfaces && !tlsOn){
            add("BLOCKER", "ServiceSettings.ListenAddress",
              "ListenAddress binds all network interfaces while TLS is off (no TLSCertFile/TLSKeyFile). The plaintext service is reachable on every network the host touches. Bind to localhost behind a TLS proxy, or configure TLS.", L("ServiceSettings.ListenAddress"));
          } else if (allIfaces && tlsOn){
            add("INFO", "ServiceSettings.ListenAddress",
              "ListenAddress binds all network interfaces, with TLS enabled in this config. Expected for a directly exposed server; make sure the host firewall agrees.", L("ServiceSettings.ListenAddress"));
          } else {
            add("OK", "ServiceSettings.ListenAddress",
              "ListenAddress does not bind all interfaces (or binds a specific address) — the service surface is limited to the named interface.", L("ServiceSettings.ListenAddress"));
          }
        }

        if (svc.EnableInsecureOutgoingConnections === true){
          add("WARNING", "ServiceSettings.EnableInsecureOutgoingConnections",
            "Insecure outgoing connections are ENABLED — Mattermost will accept invalid/expired TLS certificates from webhooks, integrations, and image proxies, opening those connections to interception. Turn this off outside a lab.", L("ServiceSettings.EnableInsecureOutgoingConnections"));
        } else if (svc.EnableInsecureOutgoingConnections === false){
          add("OK", "ServiceSettings.EnableInsecureOutgoingConnections",
            "Insecure outgoing connections are disabled — outgoing TLS certificates are verified.", L("ServiceSettings.EnableInsecureOutgoingConnections"));
        }

        /* ----- TeamSettings: open server / user creation ----- */
        var team = get(cfg, "TeamSettings") || {};
        if (team.EnableOpenServer === true){
          add("BLOCKER", "TeamSettings.EnableOpenServer",
            "OPEN SERVER IS ON. Anyone who can reach this server can create an account and join — no invitation needed. On any network you do not fully control, this is a do-not-deploy finding. Set EnableOpenServer to false and invite users instead.", L("TeamSettings.EnableOpenServer"));
        } else if (team.EnableOpenServer === false){
          add("OK", "TeamSettings.EnableOpenServer",
            "Open server is off — account creation requires an invitation or an admin-created account.", L("TeamSettings.EnableOpenServer"));
        }
        if (team.EnableUserCreation === false){
          add("INFO", "TeamSettings.EnableUserCreation",
            "Self-service account creation is disabled. Combined with invitations/admin provisioning this is the tightest posture; make sure your onboarding path still works.", L("TeamSettings.EnableUserCreation"));
        } else if (team.EnableUserCreation === true){
          add("INFO", "TeamSettings.EnableUserCreation",
            "Self-service account creation is enabled at the signup page. That is safe only while EnableOpenServer stays off and the signup page itself is not public, or when paired with an allowed email domain / SSO.", L("TeamSettings.EnableUserCreation"));
        }

        /* Guest accounts */
        var guest = get(cfg, "GuestAccountsSettings") || {};
        if (guest.Enable === true){
          add("WARNING", "GuestAccountsSettings.Enable",
            "Guest accounts are ENABLED. Guests see only the channels they are added to, but every guest is an outside account on your server — enable only if you actively use guest access.", L("GuestAccountsSettings.Enable"));
        } else if (guest.Enable === false){
          add("OK", "GuestAccountsSettings.Enable", "Guest accounts are disabled.", L("GuestAccountsSettings.Enable"));
        }

        /* Public links */
        var fileS = get(cfg, "FileSettings") || {};
        if (fileS.EnablePublicLink === true){
          add("WARNING", "FileSettings.EnablePublicLink",
            "Public file links are ENABLED — anyone holding a link can download the file without logging in, and links do not expire with the account. Turn off unless you deliberately share files publicly.", L("FileSettings.EnablePublicLink"));
        } else if (fileS.EnablePublicLink === false){
          add("OK", "FileSettings.EnablePublicLink", "Public file links are disabled — files require a logged-in account.", L("FileSettings.EnablePublicLink"));
        }

        /* ----- PasswordSettings posture ----- */
        var pw = get(cfg, "PasswordSettings");
        if (pw === undefined){
          add("INFO", "PasswordSettings",
            "PasswordSettings section not present in this config — the server's built-in defaults apply and were not graded here. Add the section explicitly so the policy is reviewable.", null);
        } else {
          var minLen = pw.MinimumLength;
          if (typeof minLen === "number"){
            if (minLen < 8){
              add("WARNING", "PasswordSettings.MinimumLength",
                "Minimum password length is " + minLen + " — below the 8-character floor most policies start at, and far below the 12+ recommended for an internet-reachable server. Raise it.", L("PasswordSettings.MinimumLength"));
            } else if (minLen < 12){
              add("INFO", "PasswordSettings.MinimumLength",
                "Minimum password length is " + minLen + ". It clears the 8-character floor; 12 or more is the stronger posture for a public server.", L("PasswordSettings.MinimumLength"));
            } else {
              add("OK", "PasswordSettings.MinimumLength",
                "Minimum password length is " + minLen + " — a solid floor.", L("PasswordSettings.MinimumLength"));
            }
          }
          var rules = ["Lowercase", "Number", "Uppercase", "Symbol"];
          var onCount = 0;
          rules.forEach(function(r){ if (pw[r] === true) onCount++; });
          if (onCount === 0){
            add("WARNING", "PasswordSettings",
              "No complexity rules are on (Lowercase, Number, Uppercase, Symbol are all off) — any characters count toward the minimum length. Enable at least number + mixed case, or rely on length alone at 14+.", L("PasswordSettings"));
          } else if (onCount === rules.length){
            add("OK", "PasswordSettings", "All four complexity rules are on (lowercase, number, uppercase, symbol).", L("PasswordSettings"));
          } else {
            add("INFO", "PasswordSettings",
              onCount + " of 4 complexity rules are on (lowercase, number, uppercase, symbol). Partial rules are a reasonable posture when paired with a longer minimum.", L("PasswordSettings"));
          }
        }

        /* ----- Secrets: flagged by path only, values NEVER rendered ----- */
        var secretPaths = [];
        (function walk(node, path){
          if (node === null || typeof node !== "object") return;
          Object.keys(node).forEach(function(key){
            var p = path ? path + "." + key : key;
            var v = node[key];
            if (typeof v === "string" && v.trim() !== "" && SECRET_KEY_RE.test(key)){
              secretPaths.push(p);
            } else if (v !== null && typeof v === "object"){
              walk(v, p);
            }
          });
        })(cfg, "");

        var ds = get(cfg, "SqlSettings.DataSource");
        if (typeof ds === "string" && ds.trim() !== "" && secretPaths.indexOf("SqlSettings.DataSource") === -1){
          secretPaths.push("SqlSettings.DataSource");
        }

        if (secretPaths.length){
          secretPaths.sort();
          secretPaths.forEach(function(p){
            var extra = "";
            if (p === "SqlSettings.DataSource") extra = " A database connection string normally embeds the database username and password.";
            if (p === "SqlSettings.AtRestEncryptKey") extra = " This key decrypts data at rest — whoever holds this file holds the key; protect and back it up accordingly.";
            add("WARNING", p,
              "Plaintext secret present in the config file at this key — reported by path only; the value is never shown here or in the report." + extra +
              " Make sure this file's permissions are locked down (owner read-only) and prefer environment-variable overrides for secrets on production hosts.",
              L(p));
          });
        } else {
          add("OK", "(secrets sweep)",
            "No non-empty password/secret/token values were found in the pasted config. (Empty fields and values supplied by environment at runtime are outside what a text audit can see.)", null);
        }

        var ark = get(cfg, "SqlSettings.AtRestEncryptKey");
        if (get(cfg, "SqlSettings") !== undefined && (ark === undefined || ark === "")){
          add("INFO", "SqlSettings.AtRestEncryptKey",
            "AtRestEncryptKey is empty or absent. Mattermost can generate one at runtime, but a generated key that is not saved back means data encrypted at rest cannot be recovered after a rebuild. Set and protect an explicit key.", L("SqlSettings.AtRestEncryptKey"));
        }

        /* ----- FileSettings.MaxFileSize arithmetic ----- */
        var mfs = fileS.MaxFileSize;
        if (typeof mfs === "number"){
          var mib = mfs / 1048576;
          var arith = mfs.toLocaleString("en-US") + " bytes ÷ 1,048,576 bytes/MiB = " + mib.toFixed(2) + " MiB" +
            (mib < 1 || mib >= 1024 ? " (" + humanSize(mfs) + ")" : "");
          if (mfs <= 0){
            add("WARNING", "FileSettings.MaxFileSize",
              "MaxFileSize is " + arith + " — a non-positive limit breaks uploads. Set a positive byte count.", L("FileSettings.MaxFileSize"));
          } else if (mib > 100){
            add("WARNING", "FileSettings.MaxFileSize",
              "MaxFileSize arithmetic: " + arith + ". That is a very large per-file upload — check disk headroom and any reverse-proxy upload limit in front of Mattermost, which may silently differ.", L("FileSettings.MaxFileSize"));
          } else {
            add("INFO", "FileSettings.MaxFileSize",
              "MaxFileSize arithmetic: " + arith + " per file. Confirm any reverse proxy in front of Mattermost allows at least this much, or uploads will fail below the configured limit.", L("FileSettings.MaxFileSize"));
          }
        }

        /* ----- LogSettings verbose/debug posture ----- */
        var log = get(cfg, "LogSettings") || {};
        var debugHits = [];
        if (String(log.ConsoleLevel || "").toUpperCase() === "DEBUG") debugHits.push("LogSettings.ConsoleLevel");
        if (String(log.FileLevel || "").toUpperCase() === "DEBUG") debugHits.push("LogSettings.FileLevel");
        if (debugHits.length){
          debugHits.forEach(function(p){
            add("WARNING", p,
              "Log level is DEBUG. Debug logs are verbose, grow fast, and can record message content and tokens — right for troubleshooting, wrong as a standing production setting. Drop to INFO once the issue is solved.", L(p));
          });
        } else if (log.ConsoleLevel !== undefined || log.FileLevel !== undefined){
          add("OK", "LogSettings",
            "Log levels are not at DEBUG (console: " + (log.ConsoleLevel || "default") + ", file: " + (log.FileLevel || "default") + ") — a sane production posture.", L("LogSettings"));
        }

        /* Email verification posture (no secrets involved) */
        var email = get(cfg, "EmailSettings") || {};
        if (email.RequireEmailVerification === false){
          add("INFO", "EmailSettings.RequireEmailVerification",
            "Email verification is not required at signup. Fine for invite-only servers; risky if signup is reachable by the public.", L("EmailSettings.RequireEmailVerification"));
        }

        /* ----- Verdict & counts ----- */
        var counts = { BLOCKER: 0, WARNING: 0, OK: 0, INFO: 0 };
        findings.forEach(function(f){ if (counts.hasOwnProperty(f.sev)) counts[f.sev]++; });
        var verdict = counts.BLOCKER > 0 ? "DO NOT DEPLOY" :
                      counts.WARNING > 0 ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY";
        return { verdict: verdict, counts: counts, findings: findings, notAudited: notAudited };
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-mattermost-server-config-safety-auditor',
  name: 'J-Dawgs Mattermost Server Config Safety Auditor',
  description: 'Mattermost startup only answers whether the config loads; this grades a pasted config.json offline, anywhere — open-server signup posture, TLS/listen pairing, and secrets judged by key path only — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
