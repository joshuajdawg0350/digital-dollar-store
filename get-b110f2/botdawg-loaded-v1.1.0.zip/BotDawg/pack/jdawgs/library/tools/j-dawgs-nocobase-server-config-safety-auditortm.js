'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs NocoBase Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Worked examples (exact text used by the buttons and the self-test) ---------- */

      var RISKY_EXAMPLE = [
        "# Risky example — a NocoBase config with planted problems. Do not deploy as-is.",
        "APP_KEY=abc123def4",
        "DB_DIALECT=postgres",
        "DB_HOST=db.internal",
        "DB_PORT=5432",
        "DB_DATABASE=nocobase",
        "DB_USER=nocobase",
        "DB_PASSWORD=passw0rd",
        "INIT_ROOT_EMAIL=admin@example.com",
        "INIT_ROOT_PASSWORD=admin123",
        "NODE_ENV=development",
        "APP_PORT=13000",
        "APP_URL=http://nocobase.internal.lan:13000"
      ].join("\n");

      var HARDENED_EXAMPLE = [
        "# Hardened example — a production-shaped NocoBase config.",
        "APP_KEY=Kx9Qm2ZpLw7Rt4NvHs3Yc8BjAe6Ug1MkPn5Sr0TvWz2Xd9Qf",
        "DB_DIALECT=postgres",
        "DB_HOST=db.internal",
        "DB_PORT=5432",
        "DB_DATABASE=nocobase_prod",
        "DB_USER=nocobase",
        "DB_PASSWORD=${DB_PASSWORD}",
        "NODE_ENV=production",
        "APP_PORT=13000",
        "APP_URL=https://nocobase.internal.lan"
      ].join("\n");

      /* Secrets planted in the risky example. The self-test scans every output
         surface for these strings and requires 0 occurrences. They are named
         here once, in code, and are never written into any finding or report. */
      var PLANTED_SECRETS = ["abc123def4", "passw0rd", "admin123"];

      var SHARE_STORE = "AI Tool Store — https://muse.ai/s/ai-tool-store-xng6xkxwjkxl2xab/UoF72OkKI7j33Q2ITxmrZyIr4nv40QtYfj2AgESh_k8";
      var SHARE_EXCHANGE = "J-Dawgs Agent Exchange — https://muse.ai/s/j-dawgs-agent-exchange-ih6xlnihzxdhxc/ZbleqxFHRE0NcswaBkyN13y9lLp5rPAgHTb6t8ii-PY";
      var SHARE_BUNDLE = "Serve It, Deploy It, Fix It Right Stack ($2.75 full pass): J-Dawgs NocoBase Server Config Safety Auditor™ + J-Dawgs Coolify Server Config Safety Auditor™ + J-Dawgs Foundation Repair Proposal, Work Record & Final Invoice Consistency Auditor™ — grade the app config, grade the deploy platform, cross-check the foundation bill.";

      /* ---------- Recognition ---------- */

      var EXACT_KEYS = {
        APP_KEY: 1, DB_DIALECT: 1, DB_HOST: 1, DB_PORT: 1, DB_DATABASE: 1,
        DB_USER: 1, DB_PASSWORD: 1, DB_STORAGE: 1, API_BASE_PATH: 1,
        APP_PORT: 1, APP_ENV: 1, NODE_ENV: 1, APP_URL: 1,
        INIT_ROOT_EMAIL: 1, INIT_ROOT_PASSWORD: 1, INIT_ROOT_NICKNAME: 1,
        PLUGIN_STORAGE_PATH: 1
      };

      function isSecretNamed(key) {
        return /SECRET|TOKEN|PASSWORD|KEY|CREDENTIAL/.test(key);
      }
      function isRecognized(key) {
        if (EXACT_KEYS[key]) return true;
        if (key.indexOf("LOGGER_") === 0) return true;
        if (key.indexOf("CACHE_") === 0) return true;
        if (isSecretNamed(key)) return true;
        return false;
      }

      /* ---------- Value helpers (values are inspected, never rendered) ---------- */

      function isEnvRef(v) {
        return /^\$\{[^}]*\}$/.test(v) || /^\$[A-Za-z_][A-Za-z0-9_]*$/.test(v);
      }
      function isExampleValue(v) {
        var s = String(v).toLowerCase();
        if (s.indexOf("example") !== -1) return true;
        if (s.indexOf("changeme") !== -1) return true;
        if (s.indexOf("change-me") !== -1) return true;
        if (s.indexOf("123456") !== -1) return true;
        if (s.indexOf("your-") !== -1 || s.indexOf("your_") !== -1) return true;
        if (s === "test" || s === "testing" || s === "nocobase" || s === "secret" ||
            s === "password" || s === "admin" || s === "admin123" || s === "root" ||
            s === "letmein" || s === "placeholder" || s === "default") return true;
        if (/^(.)\1+$/.test(s)) return true;               /* one repeated character */
        if (s.length >= 6) {                                /* short pattern repeated */
          var uniq = {};
          for (var i = 0; i < s.length; i++) uniq[s.charAt(i)] = 1;
          var n = 0; for (var k in uniq) n++;
          if (n <= 2) return true;
        }
        return false;
      }
      function isTruthyFlag(v) {
        var s = String(v).toLowerCase();
        return s === "true" || s === "1" || s === "yes" || s === "on" || s === "debug" || s === "development";
      }

      /* ---------- Parser ---------- */

      function cleanValue(raw) {
        var v = raw.replace(/\s+$/, "");
        if (v.length >= 2) {
          var first = v.charAt(0), last = v.charAt(v.length - 1);
          if ((first === '"' && last === '"') || (first === "'" && last === "'")) {
            return v.slice(1, -1);
          }
        }
        var hash = v.indexOf(" #");
        if (hash !== -1) v = v.slice(0, hash);
        return v.replace(/\s+$/, "");
      }

      function parseConfig(text) {
        var entries = [];      /* {key, value, line} */
        var notParsed = [];    /* {line} */
        var src = String(text == null ? "" : text).replace(/^\uFEFF/, "");
        var trimmed = src.replace(/^\s+/, "");

        /* JSON object input */
        if (trimmed.charAt(0) === "{") {
          try {
            var obj = JSON.parse(src);
            var lines = src.split(/\r?\n/);
            var collect = function (o) {
              for (var k in o) {
                if (!Object.prototype.hasOwnProperty.call(o, k)) continue;
                var val = o[k];
                if (val && typeof val === "object" && !Array.isArray(val) && (k === "environment" || k === "env")) {
                  collect(val); continue;
                }
                var lineNo = 0;
                for (var i = 0; i < lines.length; i++) {
                  if (lines[i].indexOf('"' + k + '"') !== -1) { lineNo = i + 1; break; }
                }
                entries.push({ key: String(k).toUpperCase(), value: val == null ? "" : String(val), line: lineNo });
              }
            };
            collect(obj);
            return { entries: entries, notParsed: notParsed, totalLines: lines.length };
          } catch (e) {
            /* fall through to line parsing */
          }
        }

        var rawLines = src.split(/\r?\n/);
        for (var n = 0; n < rawLines.length; n++) {
          var lineNo = n + 1;
          var t = rawLines[n].replace(/^\s+/, "").replace(/\s+$/, "");
          if (t === "") continue;
          if (t.charAt(0) === "#" || t.indexOf("//") === 0) continue;
          if (t.indexOf("- ") === 0) t = t.slice(2).replace(/^\s+/, "");
          if (t.indexOf("export ") === 0) t = t.slice(7).replace(/^\s+/, "");
          var m = t.match(/^"?([A-Za-z_][A-Za-z0-9_.\-]*)"?\s*[:=]\s*(.*)$/);
          if (!m) { notParsed.push({ line: lineNo }); continue; }
          entries.push({ key: m[1].toUpperCase(), value: cleanValue(m[2]), line: lineNo });
        }
        return { entries: entries, notParsed: notParsed, totalLines: rawLines.length };
      }

      /* ---------- Audit ---------- */

      function audit(text) {
        var parsed = parseConfig(text);
        var entries = parsed.entries;
        var findings = [];
        var byKey = {};
        var recognizedCount = 0;
        var i, e;

        for (i = 0; i < entries.length; i++) {
          e = entries[i];
          if (!byKey[e.key]) byKey[e.key] = [];
          byKey[e.key].push(e);
          if (isRecognized(e.key)) recognizedCount++;
        }
        function first(key) { return byKey[key] && byKey[key].length ? byKey[key][0] : null; }
        function add(severity, line, key, issue, fix) {
          findings.push({ severity: severity, line: line, key: key, issue: issue, fix: fix });
        }

        /* APP_KEY — missing is its own BLOCKER, separate from short/example. */
        var appKey = first("APP_KEY");
        if (!appKey) {
          add("BLOCKER", null, "APP_KEY",
            "APP_KEY is missing entirely. NocoBase signs sessions and tokens with this key; without one the app falls back to a predictable or absent secret.",
            "Set APP_KEY to a random value of at least 32 characters, generated fresh for this deployment, and keep it out of source control.");
        } else if (!isEnvRef(appKey.value)) {
          if (appKey.value.length < 32) {
            add("BLOCKER", appKey.line, "APP_KEY",
              "APP_KEY is too short (" + appKey.value.length + " characters; minimum 32). A short app key can be brute-forced, which exposes every session and token it signs.",
              "Replace APP_KEY with a randomly generated value of at least 32 characters (48 or more is better).");
          }
          if (isExampleValue(appKey.value)) {
            add("BLOCKER", appKey.line, "APP_KEY",
              "APP_KEY is an example or placeholder value (" + appKey.value.length + " characters). Example keys are public knowledge — anyone who has seen the docs knows this one.",
              "Generate a brand-new random APP_KEY for this deployment; never ship a value copied from documentation or a sample file.");
          }
        }

        /* INIT_ROOT_PASSWORD / INIT_ROOT_EMAIL */
        var rootPw = first("INIT_ROOT_PASSWORD");
        if (rootPw && !isEnvRef(rootPw.value)) {
          if (rootPw.value.length < 12 || isExampleValue(rootPw.value)) {
            add("BLOCKER", rootPw.line, "INIT_ROOT_PASSWORD",
              "INIT_ROOT_PASSWORD is short or an example value (" + rootPw.value.length + " characters). This becomes the first administrator password, so a guessable one hands over the whole app on first boot.",
              "Use a unique root password of at least 12 characters (16 or more is better), or remove the line and set the root account up interactively.");
          }
        }
        var rootEmail = first("INIT_ROOT_EMAIL");
        if (rootEmail) {
          var em = rootEmail.value.toLowerCase();
          if (em.indexOf("@example.com") !== -1 || em.indexOf("@example.org") !== -1 || em.indexOf("@localhost") !== -1 || em === "localhost") {
            add("WARNING", rootEmail.line, "INIT_ROOT_EMAIL",
              "INIT_ROOT_EMAIL uses an example domain. The root account will be created for an address nobody can receive mail at, including password resets.",
              "Set INIT_ROOT_EMAIL to a real mailbox you control before first boot.");
          }
        }

        /* DB_PASSWORD */
        var dbPw = first("DB_PASSWORD");
        if (dbPw && dbPw.value !== "" && !isEnvRef(dbPw.value)) {
          if (dbPw.value.length < 12 || isExampleValue(dbPw.value)) {
            add("BLOCKER", dbPw.line, "DB_PASSWORD",
              "DB_PASSWORD is a short or example plaintext password (" + dbPw.value.length + " characters). Anyone who can read this file owns the database.",
              "Move the database password into a real environment variable or secret store, reference it as ${DB_PASSWORD}, and make it at least 12 random characters.");
          } else {
            add("HIGH", dbPw.line, "DB_PASSWORD",
              "DB_PASSWORD is written in plaintext (" + dbPw.value.length + " characters). Anyone who can read this config file — a leaked repo, a backup, a screenshot — has the database password.",
              "Move the password into an environment variable or secret store and reference it here as ${DB_PASSWORD} instead of the literal value.");
          }
        }

        /* Database dialect / storage / host */
        var dialect = first("DB_DIALECT");
        var storage = first("DB_STORAGE");
        if (dialect && dialect.value.toLowerCase() === "sqlite") {
          var sp = storage ? storage.value.toLowerCase() : "";
          if (!storage || sp === "" || sp.indexOf("example") !== -1 || sp.indexOf("demo") !== -1 ||
              sp.indexOf("storage/db") !== -1 || sp === "db.sqlite" || sp === "./db.sqlite" || sp.indexOf("/tmp/") !== -1) {
            add("WARNING", dialect.line, "DB_DIALECT",
              "DB_DIALECT is sqlite with DB_STORAGE on a default or example path. That is fine for a demo, but it is not graded production-safe: the whole database is one file on a sample path with no separate credentials.",
              "For production, point DB_DIALECT at postgres or mysql with a real DB_HOST, DB_USER, and DB_PASSWORD — or deliberately place the sqlite file on backed-up storage.");
          }
        }
        var dbHost = first("DB_HOST");
        if (dbHost && dbHost.value === "0.0.0.0") {
          add("HIGH", dbHost.line, "DB_HOST",
            "DB_HOST is bound to 0.0.0.0, which listens on every network interface. A database should never be reachable from the open network.",
            "Bind the database to localhost or a private network address, or use the database container's service name inside docker-compose.");
        }

        /* Environment / debug flags */
        var envKeys = ["APP_ENV", "NODE_ENV"];
        for (i = 0; i < envKeys.length; i++) {
          var envEntry = first(envKeys[i]);
          if (envEntry && !isEnvRef(envEntry.value) && envEntry.value.toLowerCase() !== "production") {
            add("HIGH", envEntry.line, envKeys[i],
              envKeys[i] + " is set to \"" + envEntry.value + "\", not \"production\". Non-production modes can enable verbose errors, dev tooling, and weaker defaults.",
              "Set " + envKeys[i] + "=production for any deployment other people can reach.");
          }
        }
        for (i = 0; i < entries.length; i++) {
          e = entries[i];
          if ((e.key.indexOf("DEBUG") !== -1 || e.key === "DEV_MODE" || e.key === "DEVELOPMENT") && isTruthyFlag(e.value)) {
            add("HIGH", e.line, e.key,
              e.key + " enables a debug or development mode. Debug output leaks stack traces, config values, and sometimes secrets to whoever triggers an error.",
              "Turn " + e.key + " off (false / 0) before deploying, and leave it off in production.");
          }
        }

        /* Plaintext http:// transport anywhere in the paste */
        for (i = 0; i < entries.length; i++) {
          e = entries[i];
          if (e.value.toLowerCase().indexOf("http://") !== -1) {
            add("HIGH", e.line, e.key,
              e.key + " uses an http:// URL. Logins, session cookies, and API calls over plain http can be read or altered by anyone on the network path.",
              "Put the app behind https (a reverse proxy with a real certificate) and change this value to the https:// address.");
          }
        }

        /* Any other secret-named value not already graded above */
        var handled = { APP_KEY: 1, DB_PASSWORD: 1, INIT_ROOT_PASSWORD: 1 };
        for (i = 0; i < entries.length; i++) {
          e = entries[i];
          if (!isSecretNamed(e.key) || handled[e.key]) continue;
          if (e.value === "" || isEnvRef(e.value)) continue;
          if (e.value.length < 16 || isExampleValue(e.value)) {
            add("HIGH", e.line, e.key,
              e.key + " holds a short or example secret value in plaintext (" + e.value.length + " characters). Short or copied-from-docs secrets are guessable, and a plaintext one leaks with the file.",
              "Replace " + e.key + " with a randomly generated value of at least 16 characters, supplied through an environment variable or secret store rather than written in the config.");
          }
        }

        /* Verdict */
        var counts = { BLOCKER: 0, HIGH: 0, WARNING: 0, INFO: 0 };
        for (i = 0; i < findings.length; i++) counts[findings[i].severity]++;
        var verdict;
        if (recognizedCount === 0) verdict = "NOT ENOUGH TO GRADE";
        else if (counts.BLOCKER > 0) verdict = "DO NOT DEPLOY";
        else if (counts.HIGH > 0) verdict = "DEPLOY WITH FIXES";
        else verdict = "SAFE TO DEPLOY";

        var rank = { BLOCKER: 0, HIGH: 1, WARNING: 2, INFO: 3 };
        findings.sort(function (a, b) {
          if (rank[a.severity] !== rank[b.severity]) return rank[a.severity] - rank[b.severity];
          return (a.line || 0) - (b.line || 0);
        });

        return {
          tool: "J-Dawgs NocoBase Server Config Safety Auditor™",
          verdict: verdict,
          counts: counts,
          recognizedKeys: recognizedCount,
          linesScanned: parsed.totalLines,
          findings: findings,
          notParsed: parsed.notParsed
        };
      }

      /* ---------- Report builders (one object -> text and JSON) ---------- */

      function lineLabel(f) { return f.line ? "Line " + f.line : "Line — (key absent)"; }

      function buildTextReport(r) {
        var out = [];
        out.push("J-Dawgs NocoBase Server Config Safety Auditor™ — Audit Report");
        out.push("Verdict: " + r.verdict);
        out.push("Counts: BLOCKER " + r.counts.BLOCKER + " · HIGH " + r.counts.HIGH +
                 " · WARNING " + r.counts.WARNING + " · INFO " + r.counts.INFO +
                 " · NOT PARSED " + r.notParsed.length);
        out.push("Recognized NocoBase keys: " + r.recognizedKeys + " · Lines scanned: " + r.linesScanned);
        out.push("Secret values are never shown in this report; secrets are reported by key name, line, and value length only.");
        out.push("");
        if (r.findings.length === 0 && r.verdict !== "NOT ENOUGH TO GRADE") {
          out.push("Findings: none. No BLOCKER, HIGH, WARNING, or INFO findings.");
        } else if (r.findings.length === 0) {
          out.push("Findings: none — no recognizable NocoBase keys were found in the paste.");
        } else {
          out.push("Findings:");
          for (var i = 0; i < r.findings.length; i++) {
            var f = r.findings[i];
            out.push("[" + f.severity + "] " + lineLabel(f) + " · " + f.key);
            out.push("  Issue: " + f.issue);
            out.push("  Fix: " + f.fix);
          }
        }
        out.push("");
        if (r.notParsed.length === 0) {
          out.push("Not parsed lines: none.");
        } else {
          var nums = [];
          for (var j = 0; j < r.notParsed.length; j++) nums.push(r.notParsed[j].line);
          out.push("Not parsed lines (could not be read as KEY=value, KEY: value, or JSON — never guessed): " + nums.join(", "));
        }
        out.push("");
        out.push("Scope: this audit ran entirely in the browser tab. It did not connect to any server, did not start NocoBase, and does not verify the config will load.");
        return out.join("\n");
      }

      /* ---------- Rendering ---------- */

      var lastReport = null;

      function esc(s) {
        return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-nocobase-server-config-safety-auditortm',
  name: 'J-Dawgs NocoBase Server Config Safety Auditor',
  description: 'Grades a pasted NocoBase server config offline into one deploy verdict, secrets by key name/line/length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
