'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Tautulli Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        /* ---------- Built-in examples ---------- */
        var RISKY = [
          "; Tautulli config.ini — risky example",
          "[General]",
          "http_host = 0.0.0.0",
          "http_port = 8181",
          "http_root = /tautulli",
          "https_enabled = 0",
          "http_username =",
          "http_password =",
          "allow_guest_access = 1",
          "api_enabled = 1",
          "api_key = changeme123",
          "pms_token = shorttoken",
          "pms_name = Living Room Plex",
          "discord_enabled = 1",
          "discord_webhook_url = https://discord.com/api/webhooks/110022334455667788/fake-webhook-token-abcdef",
          "data_dir = /tmp/tautulli-data",
          "log_dir = /tmp/tautulli-logs",
          "check_github = 1"
        ].join("\n");

        var HARDENED = [
          "; Tautulli config.ini — hardened example",
          "[General]",
          "http_host = 127.0.0.1",
          "http_port = 8181",
          "http_root = /tautulli",
          "https_enabled = 1",
          "https_cert = /config/certs/tautulli-cert.pem",
          "https_key = /config/certs/tautulli-key.pem",
          "http_username = tautulli_admin",
          "http_password = Kx9!mQ2#vR7$pL4wZ8nB",
          "allow_guest_access = 0",
          "api_enabled = 0",
          "api_key = 9f2c7a41d8e64b05a3f1c6d9e02b5874",
          "pms_token = xT8kQ2mZ9pL4vR7nW3bY6sD1fH5jK0aG",
          "pms_name = Living Room Plex",
          "data_dir = /config/tautulli/data",
          "log_dir = /config/tautulli/logs",
          "backup_dir = /config/tautulli/backups",
          "check_github = 1"
        ].join("\n");

        /* ---------- Parsing ---------- */
        var RECOGNIZED = {
          http_host:1, http_port:1, http_root:1, https_enabled:1, https_cert:1, https_key:1,
          http_username:1, http_password:1, allow_guest_access:1, api_enabled:1, api_key:1,
          pms_token:1, pms_name:1, pms_ip:1, pms_port:1, pms_password:1, pms_username:1,
          data_dir:1, log_dir:1, backup_dir:1, cache_dir:1, check_github:1, log_level:1,
          discord_enabled:1, discord_webhook_url:1
        };
        var WEAK_VALUES = ["changeme","change_me","change-me","example","test","testing","password","passwd","admin","letmein","default","secret","token","tautulli","plex","123456","12345","abc123","shorttoken","your_api_key","your-api-key","apikey","api_key","demo","sample","placeholder","xxxxxxxx","00000000","11111111"];
        var SECRET_KEY_RE = /(token|password|passwd|secret|api_?key|webhook|auth)/i;

        function isTruthy(v){ v = String(v).trim().toLowerCase(); return v==="1"||v==="true"||v==="yes"||v==="on"; }
        function isFalsySet(v){ v = String(v).trim().toLowerCase(); return v==="0"||v==="false"||v==="no"||v==="off"; }
        function stripQuotes(v){ if(v.length>=2 && ((v[0]==='"'&&v[v.length-1]==='"')||(v[0]==="'"&&v[v.length-1]==="'"))){ return v.slice(1,-1); } return v; }
        function isWeakValue(v){
          var s = String(v).trim().toLowerCase();
          if(!s) return false;
          for(var i=0;i<WEAK_VALUES.length;i++){ if(s===WEAK_VALUES[i] || s.indexOf(WEAK_VALUES[i])!==-1 && s.length<=WEAK_VALUES[i].length+6){ return true; } }
          return false;
        }

        function parseConfig(text){
          var lines = String(text||"").split(/\r?\n/);
          var entries = [];
          var section = "";
          for(var i=0;i<lines.length;i++){
            var raw = lines[i];
            var t = raw.trim();
            if(!t || t[0]===";" || t[0]==="#") continue;
            var sec = t.match(/^\[(.+)\]$/);
            if(sec){ section = sec[1].trim(); continue; }
            var eq = t.indexOf("=");
            var colon = t.indexOf(":");
            var idx = -1;
            if(eq!==-1 && (colon===-1 || eq<colon)) idx = eq;
            else if(colon!==-1 && eq===-1) idx = colon;
            if(idx===-1) continue;
            var key = t.slice(0,idx).trim().toLowerCase().replace(/^export\s+/,"");
            var value = stripQuotes(t.slice(idx+1).trim());
            if(!key) continue;
            entries.push({ line:i+1, section:section, key:key, value:value });
          }
          return entries;
        }

        function find(entries, key){
          for(var i=entries.length-1;i>=0;i--){ if(entries[i].key===key) return entries[i]; }
          return null;
        }

        /* ---------- Audit ---------- */
        function audit(text){
          var entries = parseConfig(text);
          var findings = [];
          function add(sev, line, key, secretLen, title, detail, fix){
            findings.push({ severity:sev, line:(line==null?null:line), key:key||null,
              secret_length:(typeof secretLen==="number"?secretLen:null), title:title, detail:detail, fix:fix });
          }

          var recognizedCount = 0;
          entries.forEach(function(e){ if(RECOGNIZED[e.key] || SECRET_KEY_RE.test(e.key) || /dir$/.test(e.key)) recognizedCount++; });
          if(entries.length < 3 || recognizedCount < 3){
            add("info", null, null, null, "Not enough recognizable Tautulli settings to grade",
              "The paste held " + entries.length + " setting line(s), " + recognizedCount + " of them recognizable as Tautulli settings. A grade needs at least 3 recognizable settings.",
              "Paste the full text of config.ini (usually the [General] section) and audit again.");
            return { verdict:"NOT ENOUGH TO GRADE", entries:entries, findings:findings };
          }

          var host = find(entries,"http_host");
          var hostVal = host ? host.value.trim() : "";
          var hostAll = host && (hostVal==="0.0.0.0" || hostVal==="::" || hostVal==="*" || hostVal==="");
          var hostLocal = host && (hostVal==="127.0.0.1" || hostVal.toLowerCase()==="localhost" || hostVal==="::1");
          if(!host){
            add("warning", null, "http_host", null, "http_host is not set in the pasted config",
              "With no explicit bind address, exposure depends on defaults and on anything set only in the database/UI, which this tool cannot see.",
              "Set http_host explicitly — 127.0.0.1 if Tautulli is reached through a local reverse proxy, or a specific LAN address.");
          } else if(hostAll){
            add("critical", host.line, "http_host", null, "Web interface is bound to all network interfaces",
              "http_host is set to \"" + (hostVal===""?"(empty)":hostVal) + "\", so the Tautulli web interface answers on every interface — LAN, and the internet too if the port is forwarded or the host is public.",
              "Bind to 127.0.0.1 and reach Tautulli through an authenticated reverse proxy, or bind to one specific trusted LAN address.");
          } else if(hostLocal){
            add("pass", host.line, "http_host", null, "Web interface is bound to this machine only",
              "http_host is a loopback address, so the interface is not directly reachable from other machines.",
              "No change needed. Keep any reverse proxy in front of it authenticated.");
          } else {
            add("info", host.line, "http_host", null, "Web interface is bound to a specific address",
              "http_host is set to a single address (\"" + hostVal + "\"). Anyone who can reach that address and port can attempt the login page.",
              "Confirm that address is on a trusted network and that the login checks below pass.");
          }

          var https = find(entries,"https_enabled");
          var httpsOn = https && isTruthy(https.value);
          if(https && httpsOn){
            var cert = find(entries,"https_cert"), keyf = find(entries,"https_key");
            if(!cert || !cert.value.trim() || !keyf || !keyf.value.trim()){
              add("warning", https.line, "https_enabled", null, "HTTPS is on but no certificate/key paths are in the config",
                "https_enabled is true, yet https_cert / https_key are missing or empty in the pasted file. The pair may live only in the database/UI, which this tool cannot see.",
                "Set https_cert and https_key to the certificate and key files, or terminate TLS at an authenticated reverse proxy.");
            } else {
              add("pass", https.line, "https_enabled", null, "HTTPS is enabled with certificate and key paths set",
                "Traffic to the web interface is encrypted in transit.", "No change needed.");
            }
          } else {
            if(hostAll){
              add("critical", https?https.line:(host?host.line:null), "https_enabled", null, "No HTTPS while the interface is exposed on all interfaces",
                "https_enabled is off or absent, and the interface is bound to all interfaces — logins, the API key, and the Plex token travel in clear text to anyone on the path.",
                "Enable HTTPS (https_enabled = 1 with a valid cert/key) or put Tautulli behind an HTTPS reverse proxy, and stop binding to all interfaces.");
            } else {
              add("warning", https?https.line:null, "https_enabled", null, "HTTPS is not enabled",
                "https_enabled is off or absent, so web UI traffic is unencrypted HTTP on whatever network can reach it.",
                "Enable HTTPS with a valid certificate, or serve Tautulli only through an HTTPS reverse proxy.");
            }
          }

          var user = find(entries,"http_username");
          var pass = find(entries,"http_password");
          var hasUser = user && user.value.trim().length>0;
          var hasPass = pass && pass.value.trim().length>0;
          if(!hasUser || !hasPass){
            var which = !hasUser && !hasPass ? "http_username and http_password are both empty or missing" :
                        !hasUser ? "http_username is empty or missing" : "http_password is empty or missing";
            add("critical", pass?pass.line:(user?user.line:null), !hasPass?"http_password":"http_username", null,
              "Web UI has no working login", which + ", so anyone who can reach the interface gets in without credentials — full history, settings, and the API surface included.",
              "Set a unique http_username and a long, unique http_password in Tautulli's web UI settings, then re-audit.");
          } else {
            var pw = pass.value;
            if(isWeakValue(pw) || pw.length < 12){
              add("critical", pass.line, "http_password", pw.length, "Web UI password is weak",
                "A password is set for key http_password (line " + pass.line + ", length " + pw.length + " — value never shown), but it is short or a commonly used / placeholder value.",
                "Replace it with a unique password of at least 16 characters, ideally generated by a password manager.");
            } else {
              add("pass", pass.line, "http_password", pw.length, "Web UI login is set with a non-trivial password",
                "http_username is set and http_password is present (line " + pass.line + ", length " + pw.length + " — value never shown).",
                "No change needed. Keep the password unique to Tautulli.");
            }
          }

          entries.forEach(function(e){
            if(/guest/.test(e.key) && isTruthy(e.value)){
              add("critical", e.line, e.key, null, "Guest / unauthenticated access is enabled",
                "Key " + e.key + " is switched on at line " + e.line + ", letting visitors in without a full login.",
                "Turn guest access off (" + e.key + " = 0) unless every guest is on a fully trusted network — and even then, prefer real accounts.");
            }
          });

          var apiOn = find(entries,"api_enabled");
          var apiKey = find(entries,"api_key");
          if(apiOn && isTruthy(apiOn.value)){
            if(!apiKey || !apiKey.value.trim()){
              add("critical", apiOn.line, "api_key", null, "API is enabled with no API key in the config",
                "api_enabled is on but api_key is empty or missing in the pasted file, so API access control cannot be confirmed.",
                "Generate a fresh API key in Tautulli settings, store it in a password manager, and keep api_enabled off unless something actually calls the API.");
            } else if(isWeakValue(apiKey.value)){
              add("critical", apiKey.line, "api_key", apiKey.value.length, "API key is a placeholder or well-known value",
                "api_key is set (line " + apiKey.line + ", length " + apiKey.value.length + " — value never shown) but it matches a placeholder / commonly used pattern, so anyone can guess it.",
                "Regenerate the API key in Tautulli so it is long and random, and rotate any copy of the old key.");
            } else if(apiKey.value.length < 20){
              add("critical", apiKey.line, "api_key", apiKey.value.length, "API key is too short",
                "api_key is set (line " + apiKey.line + ", length " + apiKey.value.length + " — value never shown). Keys this short can be brute-forced against an exposed interface.",
                "Regenerate the API key so it is at least 32 random characters.");
            } else if(apiKey.value.length < 32){
              add("warning", apiKey.line, "api_key", apiKey.value.length, "API key is shorter than recommended",
                "api_key is set (line " + apiKey.line + ", length " + apiKey.value.length + " — value never shown). It is usable, but below the 32-character length Tautulli normally generates.",
                "Regenerate the API key at the next rotation so it is 32+ random characters.");
            } else {
              add("pass", apiKey.line, "api_key", apiKey.value.length, "API is on with a long API key",
                "api_key is present (line " + apiKey.line + ", length " + apiKey.value.length + " — value never shown).",
                "No change needed. Treat the key like a password.");
            }
          } else if(apiKey && apiKey.value.trim()){
            add("info", apiKey.line, "api_key", apiKey.value.length, "API key exists while the API is off",
              "api_enabled is off or absent, and an api_key is present (line " + apiKey.line + ", length " + apiKey.value.length + " — value never shown). It grants nothing while the API stays off, but it is still a live secret sitting in plain text.",
              "Keep the API off unless needed, and store the key in a password manager rather than only in this file.");
          }

          var token = find(entries,"pms_token");
          if(!token || !token.value.trim()){
            add("warning", token?token.line:null, "pms_token", null, "No Plex token (pms_token) in the pasted config",
              "Tautulli normally records the Plex token in the config. Its absence may mean it lives only in the database — which this tool cannot see — or that Plex is not linked yet.",
              "Confirm in the Tautulli UI that Plex is linked, and remember the token in the database is just as sensitive as one in this file.");
          } else if(isWeakValue(token.value) || token.value.length < 20){
            add("critical", token.line, "pms_token", token.value.length, "Plex token looks like a placeholder or is too short",
              "pms_token is set (line " + token.line + ", length " + token.value.length + " — value never shown) but it matches a placeholder pattern or is far shorter than a real Plex token.",
              "Re-link Plex in Tautulli so a real token is issued, and treat the real token like a password — it grants access to your Plex account.");
          } else {
            add("info", token.line, "pms_token", token.value.length, "Plex token is stored in plain text in this file",
              "pms_token is present (line " + token.line + ", length " + token.value.length + " — value never shown). A Plex token is a standing credential: anyone who copies this file can act against your Plex server with it.",
              "Restrict file permissions on config.ini (owner read/write only), never share or screenshot the file, and rotate the token if the file has ever been exposed.");
          }

          var seenSecret = {};
          entries.forEach(function(e){
            var isSecretKey = SECRET_KEY_RE.test(e.key);
            var isWebhookish = /webhook|discord|telegram|slack|pushover|pushbullet|gotify|ntfy|smtp|email/.test(e.key);
            if(!e.value.trim()) return;
            if(isWebhookish && /https?:\/\//.test(e.value)){
              add("warning", e.line, e.key, e.value.length, "Notification setting carries a plaintext webhook URL / credential",
                "Key " + e.key + " (line " + e.line + ", value length " + e.value.length + " — value never shown) holds a webhook URL in plain text. Webhook URLs are credentials: anyone holding one can post as your notification agent, and the URL usually embeds a token.",
                "Keep config.ini permissions locked down, rotate the webhook in the provider if this file was ever shared, and prefer notification agents whose secrets can live in a secrets store.");
              return;
            }
            if(isSecretKey && e.key!=="pms_token" && e.key!=="api_key" && e.key!=="http_password" && !seenSecret[e.key+":"+e.line]){
              seenSecret[e.key+":"+e.line] = 1;
              if(isWeakValue(e.value) || e.value.length < 12){
                add("critical", e.line, e.key, e.value.length, "Weak plaintext secret in config",
                  "Key " + e.key + " is set (line " + e.line + ", length " + e.value.length + " — value never shown) but the value is short or a commonly used / placeholder value.",
                  "Replace it with a long, unique, generated value and rotate it anywhere else it was used.");
              } else {
                add("info", e.line, e.key, e.value.length, "Plaintext secret present in config",
                  "Key " + e.key + " is set (line " + e.line + ", length " + e.value.length + " — value never shown). It is not graded weak, but it sits in this file in plain text.",
                  "Lock down config.ini permissions (owner read/write only) and never share the raw file.");
              }
            }
          });

          ["data_dir","log_dir","backup_dir","cache_dir"].forEach(function(k){
            var e = find(entries,k);
            if(!e || !e.value.trim()) return;
            var v = e.value.trim().toLowerCase();
            if(v.indexOf("/tmp")===0 || v.indexOf("/var/tmp")===0 || v.indexOf("temp")!==-1 && v.indexOf("/tmp")!==-1 || v.indexOf("www")!==-1 || v.indexOf("public")!==-1 || v.indexOf("htdocs")!==-1){
              add("warning", e.line, k, null, "Data path sits in a temporary or web-served location",
                "Key " + k + " (line " + e.line + ") points at \"" + e.value.trim() + "\". Tautulli's database and logs hold your full viewing history; temporary folders can be wiped or read by other local users, and web-served folders can expose them outright.",
                "Move " + k + " to a private folder owned by the Tautulli user (for example under /config), outside any web root.");
            }
          });

          var crit = findings.filter(function(f){return f.severity==="critical";}).length;
          var warn = findings.filter(function(f){return f.severity==="warning";}).length;
          var verdict = crit>0 ? "DO NOT DEPLOY" : (warn>0 ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY");
          return { verdict:verdict, entries:entries, findings:findings };
        }

        /* ---------- Reporting (redacted by construction) ---------- */
        function buildReport(result){
          var counts = { critical:0, warning:0, pass:0, info:0 };
          result.findings.forEach(function(f){ counts[f.severity] = (counts[f.severity]||0)+1; });
          var lines = [];
          lines.push("J-Dawgs Tautulli Server Config Safety Auditor — report");
          lines.push("Verdict: " + result.verdict);
          lines.push("Findings: " + counts.critical + " critical, " + counts.warning + " warning, " + counts.pass + " pass, " + counts.info + " info");
          lines.push("Secrets are reported by key name, line, and length only. No secret values are included.");
          lines.push("");
          result.findings.forEach(function(f, i){
            var loc = f.line ? "line " + f.line : "no line (setting absent)";
            var key = f.key ? " [" + f.key + "]" : "";
            var len = (typeof f.secret_length==="number") ? " (secret length: " + f.secret_length + ")" : "";
            lines.push((i+1) + ". [" + f.severity.toUpperCase() + "] " + f.title + " — " + loc + key + len);
            lines.push("   " + f.detail);
            lines.push("   Fix: " + f.fix);
          });
          return lines.join("\n");
        }
        function buildJson(result){
          var counts = { critical:0, warning:0, pass:0, info:0 };
          result.findings.forEach(function(f){ counts[f.severity] = (counts[f.severity]||0)+1; });
          return {
            tool: "J-Dawgs Tautulli Server Config Safety Auditor",
            verdict: result.verdict,
            counts: counts,
            secret_policy: "Secrets are reported by key name, line, and length only. Secret values are never included.",
            findings: result.findings.map(function(f){
              return { severity:f.severity, line:f.line, key:f.key, secret_length:f.secret_length,
                       title:f.title, detail:f.detail, fix:f.fix };
            })
          };
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-tautulli-server-config-safety-auditortm',
  name: 'J-Dawgs Tautulli Server Config Safety Auditor',
  description: 'Tautulli\'s own checks only answer whether the service starts on the host; ours grades a pasted Tautulli config.ini or env fully offline — authentication disabled, a short or example API key, wildcard bind, SSL off, plaintext Plex and notification credentials — into one deploy verdict, with secrets s',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
