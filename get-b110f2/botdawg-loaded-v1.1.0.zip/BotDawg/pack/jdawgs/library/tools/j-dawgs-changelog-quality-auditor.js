'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Changelog Quality Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var CATEGORIES = ["added", "changed", "deprecated", "removed", "fixed", "security"];
        var BREAKING_RE = /\bremoved\b|\bbreaking\b|\bincompatible\b|dropped support/i;
        var MONTHS = { january: 1, february: 2, march: 3, april: 4, may: 5, june: 6, july: 7, august: 8, september: 9, october: 10, november: 11, december: 12 };

        var FLAWED = [
          "# Changelog",
          "All notable changes to this project are documented here.",
          "",
          "## [Unreleased]",
          "### Added",
          "- Working on faster search",
          "",
          "## [1.2.1] - 2026-10-20",
          "### Fixed",
          "- Removed the legacy CSV export that nobody used",
          "- Misc fixes",
          "",
          "## [1.3.0] - 2027-03-01",
          "### Added",
          "- Dark mode for the settings page",
          "",
          "## [1.2.0] - 2026-09-15",
          "### Added",
          "- CSV export",
          "",
          "## [1.2.0] - 2026-09-15",
          "### Added",
          "- CSV export",
          "",
          "## [1.1.0] - 2026-08-01",
          "",
          "## [1.0.0] - 2026-07-01",
          "### Added",
          "- Initial release"
        ].join("\n");

        var CLEAN = [
          "# Changelog",
          "All notable changes to this project are documented here.",
          "",
          "## [Unreleased]",
          "### Added",
          "- Keyboard shortcuts for the audit view",
          "",
          "## [2.0.0] - 2026-10-01",
          "### Removed",
          "- Legacy CSV export dropped; use the JSON export instead",
          "### Added",
          "- JSON export with column selection",
          "",
          "## [1.1.0] - 2026-08-15",
          "### Added",
          "- Dark mode for the settings page",
          "### Fixed",
          "- Fixed crash when opening an empty project file",
          "",
          "## [1.0.0] - 2026-07-01",
          "### Added",
          "- Initial release with project tracking",
          "",
          "[Unreleased]: https://example.com/project/compare/v2.0.0...HEAD",
          "[2.0.0]: https://example.com/project/compare/v1.1.0...v2.0.0",
          "[1.1.0]: https://example.com/project/compare/v1.0.0...v1.1.0",
          "[1.0.0]: https://example.com/project/releases/tag/v1.0.0"
        ].join("\n");

        var PITCH = [
          "J-Dawgs AI Tool Store — \"The tool store where the AI is the customer.\"",
          "https://muse.ai/s/ai-tool-store-xng6xkxwjkxl2xab/UoF72OkKI7j33Q2ITxmrZyIr4nv40QtYfj2AgESh_k8",
          "",
          "J-Dawgs Agent Exchange — \"Shareware for AIs: agent tools free to try in the browser, pay per use only if they earn it.\"",
          "https://muse.ai/s/j-dawgs-agent-exchange-ih6xlnihzxdhxc/ZbleqxFHRE0NcswaBkyN13y9lLp5rPAgHTb6t8ii-PY",
          "",
          "Accessible, Documented, On Time Stack — Accessibility Pre-Flight Auditor + Changelog Quality Auditor + Estimate & Deadline Sanity Auditor (make it usable, note the change, hit the date) — $2.25 full pass in the AI Tool Store."
        ].join("\n");

        // ---------- helpers ----------
        function pad(n) { return (n < 10 ? "0" : "") + n; }
        function fmtDate(d) { return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate()); }
        function makeDate(y, m, d) {
          var dt = new Date(y, m - 1, d);
          if (dt.getFullYear() !== y || dt.getMonth() !== m - 1 || dt.getDate() !== d) return null;
          return dt;
        }
        function esc(s) {
          return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
        }
        function cmpSemver(a, b) {
          for (var i = 0; i < 3; i++) { if (a[i] !== b[i]) return a[i] - b[i]; }
          return 0;
        }

        // Find a date anywhere in a header string. Returns {date, raw, malformed}.
        function findDate(text) {
          var m = text.match(/\b(\d{4})[-/](\d{1,2})[-/](\d{1,2})\b/);
          if (m) {
            var d = makeDate(+m[1], +m[2], +m[3]);
            if (d) return { date: d, raw: m[0] };
            return { date: null, raw: m[0], malformed: true };
          }
          var mm = text.match(/\b(January|February|March|April|May|June|July|August|September|October|November|December)\s+(\d{1,2}),\s+(\d{4})\b/i);
          if (mm) {
            var d2 = makeDate(+mm[3], MONTHS[mm[1].toLowerCase()], +mm[2]);
            if (d2) return { date: d2, raw: mm[0] };
            return { date: null, raw: mm[0], malformed: true };
          }
          return { date: null, raw: null };
        }

        // Try to read a version out of a heading's text.
        // Returns {kind:'unreleased'} | {kind:'semver', parts, label} | {kind:'datever', date, label} | null
        function extractVersion(text) {
          var t = text.trim();
          if (/\bunreleased\b/i.test(t)) return { kind: "unreleased", label: "Unreleased" };
          var sv = t.match(/\[?\s*v?(\d+)\.(\d+)\.(\d+)(?:[-+][0-9A-Za-z.-]+)?\s*\]?/);
          if (sv && sv.index <= 14) {
            return { kind: "semver", parts: [+sv[1], +sv[2], +sv[3]], label: sv[1] + "." + sv[2] + "." + sv[3] };
          }
          var stripped = t.replace(/^\[|\]$/g, "").trim();
          var dv = stripped.match(/^(\d{4})[-/](\d{1,2})[-/](\d{1,2})\b/);
          if (dv) {
            var d = makeDate(+dv[1], +dv[2], +dv[3]);
            if (d) return { kind: "datever", date: d, label: fmtDate(d) };
          }
          return null;
        }

        function isHeaderLike(line) {
          if (/^#{1,6}\s+/.test(line)) return true;
          if (/^\[?\s*(v?\d+\.\d+\.\d+|unreleased\b)/i.test(line)) return true;
          if (/^version\s+/i.test(line)) return true;
          if (/^\[?\d{4}[-/]\d{1,2}[-/]\d{1,2}\]?/.test(line)) return true;
          return false;
        }

        function categoryOf(text) {
          var t = text.trim().replace(/^\*\*|\*\*$/g, "").replace(/:$/, "").trim().toLowerCase();
          for (var i = 0; i < CATEGORIES.length; i++) { if (t === CATEGORIES[i]) return CATEGORIES[i]; }
          return null;
        }

        function isVague(text) {
          var t = text.toLowerCase().replace(/[*_`#]/g, "").replace(/\.$/, "").trim();
          var words = t.split(/\s+/).filter(Boolean).length;
          if (/\bmisc(ellaneous)?\b/.test(t) && words <= 6) return true;
          if (/\bvarious\b/.test(t) && words <= 6) return true;
          if (/^(bug\s?)?fixes?$/.test(t)) return true;
          if (/\bbug fixes?\b/.test(t) && words <= 5) return true;
          if (/^(minor|general|small|assorted|other)\s+(fixes|improvements|changes|updates)$/.test(t)) return true;
          if (/\bimprovements?$/.test(t) && words <= 4) return true;
          return false;
        }

        // ---------- parse ----------
        function parse(text) {
          var lines = text.split(/\r?\n/);
          var sections = [];
          var linkRefs = {};
          var current = null;
          var currentCategory = null;

          for (var i = 0; i < lines.length; i++) {
            var raw = lines[i];
            var line = raw.trim();
            var lineNo = i + 1;
            if (!line) continue;

            var ref = line.match(/^\[([^\]]+)\]:\s*\S+/);
            if (ref) {
              linkRefs[ref[1].trim().toLowerCase().replace(/^v/, "")] = true;
              continue;
            }

            if (isHeaderLike(line)) {
              var headingText = line.replace(/^#{1,6}\s+/, "").replace(/^version\s+/i, "");
              var v = extractVersion(headingText);
              if (v) {
                var dateInfo = v.kind === "unreleased" ? { date: null, raw: null } : findDate(headingText);
                current = {
                  kind: v.kind, label: v.label, parts: v.parts || null,
                  date: v.kind === "datever" ? v.date : dateInfo.date,
                  dateRaw: dateInfo.raw, dateMalformed: !!dateInfo.malformed,
                  headerLine: line, lineNo: lineNo, entries: []
                };
                sections.push(current);
                currentCategory = null;
                continue;
              }
            }

            var headingMatch = line.match(/^#{1,6}\s+(.*)$/);
            if (headingMatch) {
              var cat = categoryOf(headingMatch[1]);
              if (cat) { currentCategory = cat; continue; }
              if (current) currentCategory = null; // some other sub-heading ends the category run
              continue;
            }
            var boldCat = line.match(/^\*\*([A-Za-z]+)\*\*:?$/);
            if (boldCat) { var bc = categoryOf(boldCat[1]); if (bc) { currentCategory = bc; continue; } }
            var plainCat = categoryOf(line);
            if (plainCat && /:$/.test(line)) { currentCategory = plainCat; continue; }

            if (current) {
              var bullet = line.match(/^[-*+]\s+(.*)$/);
              var entryText = bullet ? bullet[1].trim() : line;
              if (entryText) {
                current.entries.push({ text: entryText, lineNo: lineNo, category: currentCategory });
              }
            }
          }
          return { sections: sections, linkRefs: linkRefs };
        }

        // ---------- audit ----------
        function audit(text, refDate) {
          var parsed = parse(text);
          var sections = parsed.sections;
          var releases = sections.filter(function (s) { return s.kind !== "unreleased"; });
          var findings = [];
          function add(sev, tag, msg) { findings.push({ sev: sev, tag: tag, msg: msg }); }

          var unreleased = null;
          sections.forEach(function (s) { if (s.kind === "unreleased" && !unreleased) unreleased = s; });

          // (5) Unreleased checks
          if (!unreleased) {
            add("INFO", "NO UNRELEASED", "No [Unreleased] section — there is nowhere for the next release's changes to collect as they land.");
          } else if (unreleased.entries.length === 0) {
            add("WARNING", "EMPTY UNRELEASED", "The [Unreleased] section exists (line " + unreleased.lineNo + ") but has no entries — either nothing is in flight, or changes are being written straight into releases.");
          }

          // (3) duplicates
          var seen = {};
          releases.forEach(function (s) {
            if (!seen[s.label]) seen[s.label] = [];
            seen[s.label].push(s);
          });
          Object.keys(seen).forEach(function (label) {
            if (seen[label].length > 1) {
              var lineList = seen[label].map(function (s) { return s.lineNo; }).join(", ");
              add("BLOCKER", "DUPLICATE", "Version " + label + " appears " + seen[label].length + " times (lines " + lineList + "). A version must have exactly one entry — readers cannot tell which one is the real release.");
            }
          });

          // (2) descending order (adjacent pairs of the same version kind)
          for (var i = 1; i < releases.length; i++) {
            var prev = releases[i - 1], cur = releases[i];
            var outOfOrder = false;
            if (prev.kind === "semver" && cur.kind === "semver") outOfOrder = cmpSemver(cur.parts, prev.parts) > 0;
            else if (prev.kind === "datever" && cur.kind === "datever") outOfOrder = cur.date > prev.date;
            if (outOfOrder) {
              add("WARNING", "OUT OF ORDER", "Version " + cur.label + " (line " + cur.lineNo + ") appears after " + prev.label + " but is newer. Changelogs list newest first — " + cur.label + " belongs above " + prev.label + ".");
            }
          }

          // (4) dates: missing / malformed / future / out of order
          var lastDated = null;
          releases.forEach(function (s) {
            if (s.kind === "datever") {
              // the version IS the date; nothing separate to check except order below
            } else if (s.dateMalformed) {
              add("WARNING", "MALFORMED DATE", "Version " + s.label + " (line " + s.lineNo + ") carries the date text \"" + s.dateRaw + "\", which is not a real calendar date.");
            } else if (!s.date) {
              add("WARNING", "NO DATE", "Version " + s.label + " (line " + s.lineNo + ") has no release date. Every release needs one — readers judge freshness by it.");
            } else if (s.date > refDate) {
              add("BLOCKER", "FUTURE DATE", "Version " + s.label + " is dated " + fmtDate(s.date) + ", which is after the reference date " + fmtDate(refDate) + ". A release cannot ship in the future — fix the date or hold the entry.");
            }
            if (s.date) {
              if (lastDated && s.date > lastDated.date) {
                add("WARNING", "DATES OUT OF ORDER", "Version " + s.label + " is dated " + fmtDate(s.date) + " but sits below " + lastDated.label + " dated " + fmtDate(lastDated.date) + ". Dates should descend along with the versions.");
              }
              lastDated = s;
            }
          });

          // semver predecessors for bump checks
          var uniqParts = {};
          releases.forEach(function (s) { if (s.kind === "semver") uniqParts[s.label] = s.parts; });
          var sortedLabels = Object.keys(uniqParts).sort(function (a, b) { return cmpSemver(uniqParts[b], uniqParts[a]); });
          function predecessor(label) {
            var idx = sortedLabels.indexOf(label);
            return idx >= 0 && idx < sortedLabels.length - 1 ? sortedLabels[idx + 1] : null;
          }
          function bumpKind(fromParts, toParts) {
            if (toParts[0] !== fromParts[0]) return "major";
            if (toParts[1] !== fromParts[1]) return "minor";
            return "patch";
          }

          var uncategorized = 0;
          var uncatSections = [];

          releases.concat(unreleased ? [unreleased] : []).forEach(function (s) {
            // (6) empty release sections
            if (s.kind !== "unreleased" && s.entries.length === 0) {
              add("BLOCKER", "EMPTY RELEASE", "Version " + s.label + " (line " + s.lineNo + ") has no entries at all. An empty release section tells readers a version shipped with nothing in it — add its changes or remove the section.");
            }
            // (7) buried breaking changes
            var pred = s.kind === "semver" ? predecessor(s.label) : null;
            var bump = pred ? bumpKind(uniqParts[pred], s.parts) : null;
            s.entries.forEach(function (e) {
              if (pred && (bump === "patch" || bump === "minor") && BREAKING_RE.test(e.text)) {
                add("BLOCKER", "BREAKING CHANGE BURIED", "In version " + s.label + " (line " + e.lineNo + "): \"" + e.text + "\" — but " + s.label + " is only a " + bump + " bump from " + pred + ". Breaking changes need a major bump. Check the bump.");
              }
              // (8) vague entries
              if (isVague(e.text)) {
                add("WARNING", "VAGUE", "Line " + e.lineNo + " (version " + s.label + "): \"" + e.text + "\" — this says nothing a reader can act on. Name what actually changed.");
              }
              // (9) uncategorized
              if (!e.category) { uncategorized++; if (uncatSections.indexOf(s.label) === -1) uncatSections.push(s.label); }
            });
          });

          if (uncategorized > 0) {
            add("WARNING", "UNCATEGORIZED", uncategorized + " entr" + (uncategorized === 1 ? "y sits" : "ies sit") + " outside any Added / Changed / Deprecated / Removed / Fixed / Security heading (in: " + uncatSections.join(", ") + "). Uncategorized entries are where changes go to be missed.");
          }

          // (10) compare-link footer references
          var missingLinks = [];
          releases.forEach(function (s) {
            if (missingLinks.indexOf(s.label) === -1 && !parsed.linkRefs[s.label.toLowerCase()]) missingLinks.push(s.label);
          });
          if (releases.length && missingLinks.length) {
            add("INFO", "COMPARE LINKS", "No compare-link footer reference ([" + "x.y.z]: url) found for: " + missingLinks.join(", ") + ". Keep-a-Changelog readers expect each version to link to its diff or release page.");
          }

          var blockers = findings.filter(function (f) { return f.sev === "BLOCKER"; }).length;
          var warnings = findings.filter(function (f) { return f.sev === "WARNING"; }).length;
          var infos = findings.filter(function (f) { return f.sev === "INFO"; }).length;
          var verdict, verdictClass, verdictSub;
          if (blockers > 0) {
            verdict = "DO NOT RELEASE — CHANGELOG MISLEADS";
            verdictClass = "stop";
            verdictSub = blockers + " blocker" + (blockers === 1 ? "" : "s") + " must be fixed before this changelog can be trusted.";
          } else if (warnings > 0) {
            verdict = "RELEASE WITH FIXES";
            verdictClass = "fixes";
            verdictSub = "No blockers, but " + warnings + " warning" + (warnings === 1 ? "" : "s") + " should be fixed so the record stays honest.";
          } else {
            verdict = "READY TO RELEASE";
            verdictClass = "ready";
            verdictSub = infos > 0 ? "No blockers or warnings. Only optional polish remains (see info notes)." : "No blockers, no warnings, no missing pieces. The record is complete and consistent.";
          }

          // corrected skeleton: headers only, re-sorted
          var skeletonLines = [];
          if (unreleased) skeletonLines.push(unreleased.headerLine);
          var sortedReleases = releases.slice().sort(function (a, b) {
            if (a.kind === "semver" && b.kind === "semver") return cmpSemver(b.parts, a.parts);
            if (a.kind === "datever" && b.kind === "datever") return b.date - a.date;
            return 0;
          });
          sortedReleases.forEach(function (s) { skeletonLines.push(s.headerLine); });

          return {
            sections: sections, releases: releases, findings: findings,
            blockers: blockers, warnings: warnings, infos: infos,
            verdict: verdict, verdictClass: verdictClass, verdictSub: verdictSub,
            skeleton: skeletonLines.join("\n"),
            totalEntries: sections.reduce(function (n, s) { return n + s.entries.length; }, 0)
          };
        }

        function buildReport(result, refDate) {
          var out = [];
          out.push("J-DAWGS CHANGELOG QUALITY AUDITOR — REPORT");
          out.push("Reference date: " + fmtDate(refDate));
          out.push("VERDICT: " + result.verdict);
          out.push("");
          out.push("Versions found (in order): " + (result.sections.length ? result.sections.map(function (s) { return s.label; }).join(", ") : "(none)"));
          out.push("Entries checked: " + result.totalEntries);
          out.push("Blockers: " + result.blockers + " | Warnings: " + result.warnings + " | Info: " + result.infos);
          out.push("");
          ["BLOCKER", "WARNING", "INFO"].forEach(function (sev) {
            var list = result.findings.filter(function (f) { return f.sev === sev; });
            out.push(sev + "S (" + list.length + "):");
            if (!list.length) out.push("- none");
            list.forEach(function (f) { out.push("- [" + f.tag + "] " + f.msg); });
            out.push("");
          });
          out.push("CORRECTED VERSION ORDER (headers only — entry text untouched):");
          out.push(result.skeleton || "(no version headers found)");
          out.push("");
          out.push("Heuristic text audit — checks completeness and consistency, not whether entries are true.");
          return out.join("\n");
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-changelog-quality-auditor',
  name: 'J-Dawgs Changelog Quality Auditor',
  description: 'Format linters check one file inside a repo; ours audits a pasted changelog anywhere and flags buried breaking changes, future dates, and empty releases, not just formatting.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
