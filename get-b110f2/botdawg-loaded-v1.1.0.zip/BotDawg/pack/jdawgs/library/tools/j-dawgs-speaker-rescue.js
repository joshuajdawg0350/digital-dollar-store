'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Speaker Rescue".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the analyze function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";
      var $ = function(id){ return document.getElementById(id); };

      /* ---------- Vibration support: detected once, stated honestly ---------- */
      var vibSupported = (typeof navigator !== "undefined") && ("vibrate" in navigator) && (typeof navigator.vibrate === "function");
      var vibEl = $("vib-status");
      if (vibSupported) {
        vibEl.innerHTML = "<strong class='ok-text'>Vibration is available in this browser.</strong> While Dust Mode runs, the phone also vibrates in short pulses, in time with the tones, to help shake dust loose.";
      } else {
        vibEl.innerHTML = "<strong class='warn-text'>Vibration is not available in this browser</strong> — for example, Safari on iPhone doesn't offer it to web apps. Dust Mode will still play the alternating tones, but it will not vibrate, and it won't pretend to.";
      }

      /* ---------- Audio engine (single owner: one run at a time) ---------- */
      var actx = null;
      function audio(){
        if (!actx) {
          var AC = window.AudioContext || window.webkitAudioContext;
          actx = new AC();
        }
        if (actx.state === "suspended") { actx.resume(); }
        return actx;
      }

      var WATER = { mode:"water", dur:60000, cycleMs:20000, cycles:3,
        freq:function(t){ var ph=(t%20000)/20000; var tri = ph<0.5 ? ph*2 : 2-ph*2; return 140 + 45*tri; } };
      var DUST = { mode:"dust", dur:30000,
        freq:function(t){ return (Math.floor(t/2000)%2===0) ? 120 : 195; } };
      var SWEEP = { mode:"sweep", dur:3000,
        freq:function(t){ return 250 + 950*(t/3000); } };

      var run = null; /* {spec, osc, gain, t0, raf, ui, onDone, lastStep} */

      var ui = {
        water: { inst:$("w-inst"), freq:$("w-freq"), sub:$("w-sub"), fill:$("w-fill"), bar:$("w-bar"),
                 cycle:$("w-cycle"), status:$("w-status"), controls:$("w-controls"), idleFreq:"—",
                 idleCycle:"Ready when you are", label:$("w-inst").querySelector(".mode-label"), labelName:"Water Eject" },
        dust:  { inst:$("d-inst"), freq:$("d-freq"), sub:$("d-sub"), fill:$("d-fill"), bar:$("d-bar"),
                 cycle:$("d-cycle"), status:$("d-status"), controls:$("d-controls"), idleFreq:"—",
                 idleCycle:"Ready when you are", label:$("d-inst").querySelector(".mode-label"), labelName:"Dust Mode" },
        sweep: { inst:$("c-inst"), freq:$("c-freq"), status:$("c-status"), idleFreq:"—",
                 label:$("c-inst").querySelector(".mode-label"), labelName:"Test Sweep" }
      };

      /* Exposed so behavior can be verified: live engine state, not decoration. */
      window.__sr = { running:false, mode:null, freqHz:0, elapsedMs:0, vibSupported:vibSupported, readings:{ before:null, after:null } };

      /* ---------- Pinned HUD: mirrors the same live engine state ---------- */
      var hud = { mode:$("hud-mode"), state:$("hud-state"), freq:$("hud-freq"), fill:$("hud-fill"),
                  before:$("hud-before"), after:$("hud-after") };
      function hudRunning(on){
        hud.state.textContent = on ? "Running" : "Idle";
        hud.state.classList.toggle("on", on);
        if (!on) { hud.freq.textContent = "—"; hud.fill.style.transform = "scaleX(0)"; }
      }
      function hudReading(which, r){
        var el = which === "before" ? hud.before : hud.after;
        var name = which === "before" ? "Before" : "After";
        el.innerHTML = r ? name + ": <b>" + r.db.toFixed(1) + " dB</b>" : name + ": <b>none</b>";
      }

      function setStatus(u, txt){ if (u.status) u.status.textContent = txt; }

      function startRun(spec, u, onDone){
        stopRun("replace", true);
        var ctx = audio();
        var osc = ctx.createOscillator();
        var gain = ctx.createGain();
        osc.type = "sine";
        osc.frequency.value = spec.freq(0);
        var now = ctx.currentTime;
        gain.gain.setValueAtTime(0.0001, now);
        gain.gain.exponentialRampToValueAtTime(0.9, now + 0.15);
        osc.connect(gain); gain.connect(ctx.destination);
        osc.start();
        run = { spec:spec, osc:osc, gain:gain, t0:performance.now(), raf:0, ui:u, onDone:onDone||null, lastStep:-1 };
        window.__sr.running = true; window.__sr.mode = spec.mode; window.__sr.freqHz = spec.freq(0); window.__sr.elapsedMs = 0;
        hudRunning(true); hud.freq.textContent = String(Math.round(spec.freq(0)));
        if (u.inst) u.inst.classList.add("running");
        if (u.label) u.label.textContent = u.labelName + " · Live Frequency";
        if (u.controls) u.controls.classList.add("running-ui");
        setStatus(u, spec.mode === "sweep" ? "Playing test sweep…" : "Running…");
        tick();
      }

      function tick(){
        if (!run) return;
        var t = performance.now() - run.t0;
        var spec = run.spec, u = run.ui;
        if (t >= spec.dur) { var cb = run.onDone; finishRun(); if (cb) cb(); return; }
        var f = spec.freq(t);
        run.osc.frequency.setValueAtTime(f, actx.currentTime);
        window.__sr.freqHz = f; window.__sr.elapsedMs = t;
        if (u.freq) u.freq.textContent = String(Math.round(f));
        hud.freq.textContent = String(Math.round(f));
        hud.fill.style.transform = "scaleX(" + Math.min(1, t/spec.dur) + ")";
        if (u.fill) {
          var pct = Math.min(100, (t/spec.dur)*100);
          u.fill.style.transform = "scaleX(" + (pct/100) + ")";
          if (u.bar) u.bar.setAttribute("aria-valuenow", String(Math.round(pct)));
        }
        if (u.cycle) {
          if (spec.mode === "water") {
            var cyc = Math.min(spec.cycles, Math.floor(t/spec.cycleMs)+1);
            var left = Math.ceil((spec.dur - t)/1000);
            u.cycle.textContent = "Cycle " + cyc + " of " + spec.cycles + " · " + left + " s left";
          } else if (spec.mode === "dust") {
            var dleft = Math.ceil((spec.dur - t)/1000);
            u.cycle.textContent = dleft + " s left";
          }
        }
        if (spec.mode === "dust" && vibSupported) {
          var step = Math.floor(t/2000);
          if (step !== run.lastStep) { run.lastStep = step; try { navigator.vibrate(220); } catch(e){} }
        }
        run.raf = requestAnimationFrame(tick);
      }

      function teardown(r){
        if (!r) return;
        if (r.raf) cancelAnimationFrame(r.raf);
        try {
          var now = actx ? actx.currentTime : 0;
          r.gain.gain.cancelScheduledValues(now);
          r.gain.gain.setTargetAtTime(0.0001, now, 0.02);
          r.osc.stop(now + 0.08);
        } catch(e){}
        try { r.osc.disconnect(); r.gain.disconnect(); } catch(e){}
        if (vibSupported) { try { navigator.vibrate(0); } catch(e){} }
      }

      function resetUi(u){
        if (!u) return;
        if (u.inst) u.inst.classList.remove("running");
        if (u.label) u.label.textContent = u.labelName + " · Frequency";
        if (u.controls) u.controls.classList.remove("running-ui");
        if (u.freq) u.freq.textContent = u.idleFreq;
        if (u.fill) { u.fill.style.transform = "scaleX(0)"; }
        if (u.bar) u.bar.setAttribute("aria-valuenow", "0");
      }

      function stopRun(reason, silent){
        if (!run) return;
        var r = run; run = null;
        teardown(r);
        window.__sr.running = false; window.__sr.mode = null; window.__sr.elapsedMs = 0;
        hudRunning(false);
        resetUi(r.ui);
        if (!silent) {
          if (r.ui.cycle) r.ui.cycle.textContent = r.ui.idleCycle;
          setStatus(r.ui, reason === "user" ? "Stopped" : "Not running");
        }
      }

      function finishRun(){
        if (!run) return;
        var r = run; run = null;
        teardown(r);
        window.__sr.running = false; window.__sr.mode = null;
        hudRunning(false);
        resetUi(r.ui);
        if (r.ui.cycle) r.ui.cycle.textContent = r.ui.idleCycle;
        if (r.spec.mode === "water") setStatus(r.ui, "Done — all 3 cycles finished. Check how the speaker sounds.");
        else if (r.spec.mode === "dust") setStatus(r.ui, "Done — 30 seconds finished. Check how the speaker sounds.");
        else setStatus(r.ui, "Sweep finished");
      }

      /* ---------- Safety gate: warning before the first run of any tone ---------- */
      var safetyOk = false;
      var pendingAction = null;
      var overlay = $("safety");
      function withSafety(fn){
        if (safetyOk) { fn(); return; }
        pendingAction = fn;
        overlay.classList.add("open");
        $("safety-go").focus();
      }
      $("safety-go").addEventListener("click", function(){
        safetyOk = true;
        overlay.classList.remove("open");
        var fn = pendingAction; pendingAction = null;
        if (fn) fn();
      });
      $("safety-cancel").addEventListener("click", function(){
        overlay.classList.remove("open");
        pendingAction = null;
      });

      /* ---------- Water & dust controls ---------- */
      $("w-start").addEventListener("click", function(){ withSafety(function(){ startRun(WATER, ui.water); }); });
      $("w-stop").addEventListener("click", function(){ stopRun("user"); });
      $("d-start").addEventListener("click", function(){ withSafety(function(){ startRun(DUST, ui.dust); }); });
      $("d-stop").addEventListener("click", function(){ stopRun("user"); });

      /* ---------- Sound check: mic capture + real buffer analysis ---------- */
      var readings = { before:null, after:null };
      var capturing = false;
      var cMsg = $("c-msg");

      function fft(re, im){
        var n = re.length, j = 0, i, len, half, ang, wre, wim, tre, tim, ure, uim;
        for (i = 1; i < n; i++) {
          var bit = n >> 1;
          for (; j & bit; bit >>= 1) j ^= bit;
          j ^= bit;
          if (i < j) {
            var t1 = re[i]; re[i] = re[j]; re[j] = t1;
            var t2 = im[i]; im[i] = im[j]; im[j] = t2;
          }
        }
        for (len = 2; len <= n; len <<= 1) {
          ang = -2 * Math.PI / len; half = len >> 1;
          var stepRe = Math.cos(ang), stepIm = Math.sin(ang);
          for (i = 0; i < n; i += len) {
            wre = 1; wim = 0;
            for (j = 0; j < half; j++) {
              var a = i + j, b = i + j + half;
              tre = re[b] * wre - im[b] * wim;
              tim = re[b] * wim + im[b] * wre;
              ure = re[a]; uim = im[a];
              re[a] = ure + tre; im[a] = uim + tim;
              re[b] = ure - tre; im[b] = uim - tim;
              var nwre = wre * stepRe - wim * stepIm;
              wim = wre * stepIm + wim * stepRe; wre = nwre;
            }
          }
        }
      }

      /* Level (dBFS) + clarity (energy-weighted spectral centroid, Hz) from the recorded samples. */
      function analyze(samples, sr){
        var n = samples.length, i;
        if (n < 2048) return null;
        var sum = 0, peak = 0;
        for (i = 0; i < n; i++) { var v = samples[i]; sum += v * v; if (Math.abs(v) > peak) peak = Math.abs(v); }
        var rms = Math.sqrt(sum / n);
        var db = 20 * Math.log10(rms + 1e-9);
        var W = 2048, half = W >> 1;
        var re = new Float64Array(W), im = new Float64Array(W);
        var cSum = 0, wSum = 0;
        for (var off = 0; off + W <= n; off += W) {
          var wEnergy = 0;
          for (i = 0; i < W; i++) {
            var s = samples[off + i];
            var win = 0.5 - 0.5 * Math.cos(2 * Math.PI * i / (W - 1)); /* Hann window: keeps leakage out of the centroid */
            re[i] = s * win; im[i] = 0; wEnergy += s * s;
          }
          if (wEnergy / W < 1e-6) continue; /* skip near-silent windows */
          fft(re, im);
          var num = 0, den = 0;
          for (var k = 2; k < half; k++) {
            var f = k * sr / W;
            if (f < 80 || f > 10000) continue; /* the band a phone speaker and mic actually carry */
            var mag = Math.sqrt(re[k] * re[k] + im[k] * im[k]);
            num += f * mag; den += mag;
          }
          if (den > 0) { var w = Math.sqrt(wEnergy); cSum += (num / den) * w; wSum += w; }
        }
        var centroid = wSum > 0 ? cSum / wSum : 0;
        return { db: db, centroid: centroid, peak: peak };
      }

      function renderReading(which){
        var el = which === "before" ? $("r-before") : $("r-after");
        var r = readings[which];
        var name = which === "before" ? "Before" : "After";
        if (!r) { el.innerHTML = "<div class='r-name'>" + name + "</div><div class='r-empty'>No recording yet</div>"; return; }
        el.innerHTML = "<div class='r-name'>" + name + "</div>" +
          "<div class='r-num'>" + r.db.toFixed(1) + " dB</div><div class='r-lab'>Level (recorded loudness)</div>" +
          "<div class='r-num' style='margin-top:8px;'>" + Math.round(r.centroid) + " Hz</div><div class='r-lab'>Clarity (where the sound centered)</div>";
        window.__sr.readings[which] = { db: r.db, centroidHz: Math.round(r.centroid) };
        hudReading(which, r);
        renderDelta();
      }

      function signed(v, dec, unit){
        var s = (v >= 0 ? "+" : "−") + Math.abs(v).toFixed(dec) + unit;
        var cls = v >= 0 ? "up" : "down";
        return "<span class='" + cls + "'>" + s + "</span>";
      }

      function renderDelta(){
        var d = $("c-delta");
        if (!readings.before || !readings.after) { d.className = "delta"; d.innerHTML = ""; return; }
        var dDb = readings.after.db - readings.before.db;
        var dC = readings.after.centroid - readings.before.centroid;
        var verdict;
        if (dDb > 0.5 || dC > 40) verdict = "The “after” reading came back stronger. That is consistent with a clearer path out of the speaker — indicative only, not proof.";
        else if (dDb < -0.5 || dC < -40) verdict = "The “after” reading came back weaker. That can be mic position or room noise — retake both readings in the same spot before concluding anything. If it still sounds muffled after two eject cycles, see “When this can't help.”";
        else verdict = "The two readings are about the same. If the speaker still sounds muffled after two full eject cycles, the problem is likely hardware — see “When this can't help.”";
        d.innerHTML = "<strong>Change:</strong> Level " + signed(dDb, 1, " dB") + " · Clarity " + signed(dC, 0, " Hz") + "<br>" + verdict;
        d.className = "delta show";
      }

      function setCheckButtons(disabled){
        $("c-before").disabled = disabled;
        $("c-after").disabled = disabled;
        $("c-play").disabled = disabled;
      }

      function recordReading(which){
        if (capturing) return;
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
          cMsg.innerHTML = "<span class='error-text'>The microphone isn't available in this browser, so the sound check can't measure. The eject cycles don't need the mic and still work.</span>";
          return;
        }
        capturing = true;
        setCheckButtons(true);
        cMsg.textContent = "Asking for microphone permission…";
        navigator.mediaDevices.getUserMedia({ audio: { echoCancellation:false, noiseSuppression:false, autoGainControl:false } })
        .then(function(stream){
          var ctx = audio();
          var src = ctx.createMediaStreamSource(stream);
          var proc = ctx.createScriptProcessor(4096, 1, 1);
          var mute = ctx.createGain(); mute.gain.value = 0;
          var chunks = [];
          proc.onaudioprocess = function(e){
            var d = e.inputBuffer.getChannelData(0);
            chunks.push(new Float32Array(d));
          };
          src.connect(proc); proc.connect(mute); mute.connect(ctx.destination);
          cMsg.textContent = "Recording — keep the phone still and the room quiet…";
          var startedAt = performance.now();
          setTimeout(function(){
            startRun(SWEEP, ui.sweep, function(){
              setTimeout(function(){
                try { proc.disconnect(); src.disconnect(); mute.disconnect(); } catch(e){}
                stream.getTracks().forEach(function(tr){ tr.stop(); });
                capturing = false;
                setCheckButtons(false);
                var total = 0, i;
                for (i = 0; i < chunks.length; i++) total += chunks[i].length;
                var flat = new Float32Array(total), pos = 0;
                for (i = 0; i < chunks.length; i++) { flat.set(chunks[i], pos); pos += chunks[i].length; }
                var res = analyze(flat, ctx.sampleRate);
                if (!res || res.db < -55) {
                  cMsg.innerHTML = "<span class='error-text'>Almost nothing was recorded. Check the media volume is up and nothing is covering the mic, then try again.</span>";
                  return;
                }
                readings[which] = res;
                renderReading(which);
                cMsg.innerHTML = "<span class='ok-text'>“" + (which === "before" ? "Before" : "After") + "” reading recorded and measured.</span> Indicative only — not a lab measurement.";
              }, 350);
            });
          }, 250);
        })
        .catch(function(err){
          capturing = false;
          setCheckButtons(false);
          if (err && (err.name === "NotAllowedError" || err.name === "SecurityError")) {
            cMsg.innerHTML = "<span class='error-text'>Microphone permission was not given, so the sound check can't measure. Nothing was recorded. The eject cycles don't need the mic and still work.</span>";
          } else {
            cMsg.innerHTML = "<span class='error-text'>The microphone couldn't be started (" + (err && err.name ? err.name : "unknown error") + "). The eject cycles don't need the mic and still work.</span>";
          }
        });
      }

      $("c-before").addEventListener("click", function(){ withSafety(function(){ recordReading("before"); }); });
      $("c-after").addEventListener("click", function(){ withSafety(function(){ recordReading("after"); }); });
      $("c-play").addEventListener("click", function(){
        withSafety(function(){
          cMsg.textContent = "";
          startRun(SWEEP, ui.sweep);
        });
      });

      /* ---------- Tabs: one job per screen; switching stops any running tone ---------- */
      var screens = { water:$("screen-water"), dust:$("screen-dust"), check:$("screen-check"), help:$("screen-help"), limits:$("screen-limits") };
  return { "analyze": (typeof analyze !== 'undefined' ? analyze : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["analyze"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-speaker-rescue',
  name: 'J-Dawgs Speaker Rescue',
  description: '',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["analyze"]) return { ok: false, output: null, summary: 'Extracted core has no analyze function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
