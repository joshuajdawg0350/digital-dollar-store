'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Dnsmasq Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

  "use strict";

  var RISKY = [
    "# Risky worked example - loaded by default. Do not deploy as-is.",
    "port=53",
    "port=5353",
    "listen-address=0.0.0.0",
    "no-resolv",
    "server=0.0.0.0",
    "dhcp-range=192.168.1.50,192.168.1.150,255.255.255.0,12h",
    "dhcp-range=192.168.1.100,192.168.1.200,255.255.255.0,infinite",
    "dhcp-option=6,10.9.9.9",
    "sync-api-token=example-value-not-a-real-secret",
    "frobnicate-mode=on",
    "this line is not a config line at all"
  ].join("\n");

  var CLEAN = [
    "# Clean worked example - hardened small-network config.",
    "port=53",
    "listen-address=127.0.0.1,192.168.1.2",
    "interface=eth0",
    "bind-interfaces",
    "no-resolv",
    "server=1.1.1.1",
    "server=9.9.9.9",
    "bogus-priv",
    "domain-needed",
    "expand-hosts",
    "domain=lan",
    "local=/lan/",
    "dhcp-range=192.168.1.100,192.168.1.200,255.255.255.0,12h",
    "dhcp-option=3,192.168.1.1",
    "dhcp-option=6,192.168.1.2",
    "dhcp-authoritative",
    "log-queries"
  ].join("\n");

  var KNOWN = {};
  ("port listen-address interface except-interface bind-interfaces bind-dynamic no-dhcp-interface " +
   "server address cname host-record txt-record ptr-record srv-host mx-host naptr-record local " +
   "domain-needed bogus-priv bogus-nxdomain no-resolv no-poll resolv-file strict-order all-servers " +
   "filterwin2k stop-dns-rebind rebind-domain-ok rebind-localhost-ok ignore-address expand-hosts domain " +
   "local-ttl neg-ttl max-ttl min-cache-ttl max-cache-ttl cache-size no-negcache dns-forward-max query-port " +
   "edns-packet-max user group pid-file conf-file conf-dir no-hosts addn-hosts hostsdir read-ethers " +
   "log-queries log-dhcp log-facility log-async quiet-dhcp quiet-dhcp6 quiet-ra local-service " +
   "dhcp-range dhcp-host dhcp-hostsfile dhcp-optsfile dhcp-leasefile dhcp-lease-max dhcp-option " +
   "dhcp-option-force dhcp-boot dhcp-authoritative dhcp-rapid-commit dhcp-name-match dhcp-ignore " +
   "dhcp-ignore-names dhcp-generate-names dhcp-broadcast dhcp-sequential-ip dhcp-mac dhcp-vendorclass " +
   "dhcp-userclass dhcp-circuitid dhcp-remoteid dhcp-subscrid dhcp-match dhcp-proxy dhcp-no-override " +
   "leasefile-ro script-arp dhcp-script dhcp-luascript script-on-renewal enable-dbus enable-tftp " +
   "tftp-root tftp-secure tftp-max tftp-mtu tftp-no-fail tftp-no-blocksize tftp-lowercase tftp-unique-root " +
   "enable-ra ra-param dhcp-reply-delay pxe-service pxe-prompt auth-server auth-zone auth-ttl auth-soa " +
   "auth-peer dnssec trust-anchor dnssec-debug dnssec-check-unsigned dnssec-no-timecheck dnssec-timestamp " +
   "proxy-dnssec ipset nftset conntrack no-ping dhcp-fqdn").split(" ").forEach(function(k){ KNOWN[k] = true; });

  var SINGLE_VALUE = {};
  ("port domain cache-size dhcp-leasefile dhcp-lease-max pid-file user group resolv-file log-facility " +
   "tftp-root local-ttl neg-ttl max-ttl conf-file").split(" ").forEach(function(k){ SINGLE_VALUE[k] = true; });

  var SECRET_RE = /(password|passwd|secret|token|api[-_]?key|private[-_]?key|access[-_]?key)/i;

  function ipToInt(ip){
    var p = ip.split(".");
    if (p.length !== 4) return null;
    var n = 0;
    for (var i = 0; i < 4; i++){
      var v = parseInt(p[i], 10);
      if (isNaN(v) || v < 0 || v > 255 || String(v) !== p[i].replace(/^0+(?=\d)/, "")) { /* tolerate leading zeros below */ }
      if (isNaN(v) || v < 0 || v > 255) return null;
      n = n * 256 + v;
    }
    return n;
  }
  function isIPv4(s){ return ipToInt(s) !== null; }
  function intToIp(n){
    return [Math.floor(n / 16777216) % 256, Math.floor(n / 65536) % 256, Math.floor(n / 256) % 256, n % 256].join(".");
  }
  function trim(s){ return s.replace(/^\s+|\s+$/g, ""); }

  function audit(text){
    var findings = [];
    function add(sev, line, title, detail, fix){
      findings.push({sev: sev, line: line, title: title, detail: detail, fix: fix});
    }

    var rawLines = text.split(/\r?\n/);
    var entries = []; // {line, key, value|null, secret}
    var directiveCount = 0;

    rawLines.forEach(function(raw, idx){
      var lineNo = idx + 1;
      var line = trim(raw);
      if (line === "" || line.charAt(0) === "#") return;
      var m = line.match(/^([A-Za-z][A-Za-z0-9_-]*)\s*(?:=\s*(.*))?$/);
      if (!m){
        add("WARNING", lineNo, "Unparsable line — excluded from the audit",
          "Line " + lineNo + " is not in key or key=value form, so the auditor could not read it and excluded it. Nothing was silently dropped: it is named here.",
          "Fix: rewrite line " + lineNo + " as a dnsmasq directive (name or name=value), or remove it if it is a stray note.");
        return;
      }
      var key = m[1].toLowerCase();
      var value = (typeof m[2] === "string") ? trim(m[2]) : null;
      var secret = SECRET_RE.test(key);
      entries.push({line: lineNo, key: key, value: value, secret: secret});
      directiveCount++;
    });

    if (directiveCount === 0 && findings.length === 0) return null; // caller shows "paste a config first"

    function byKey(k){
      return entries.filter(function(e){ return e.key === k; });
    }
    function has(k){ return byKey(k).length > 0; }

    // --- Secrets: key name and line only, value never used anywhere below ---
    entries.forEach(function(e){
      if (!e.secret) return;
      add("WARNING", e.line, "Secret-named value in the config — flagged by key name and line only",
        "Line " + e.line + " sets \u201C" + e.key + "\u201D, a key name that suggests a secret. Its value is never shown in these findings, in the report, or anywhere else in this audit.",
        "Fix: move the secret out of the shared config into a root-only file or your secret store, and rotate it if this config text has been shared.");
    });

    // --- Unknown directives: NOT AUDITED, never guessed ---
    entries.forEach(function(e){
      if (e.secret) return;
      if (!KNOWN[e.key]){
        add("NOTAUDITED", e.line, "Unknown directive \u201C" + e.key + "\u201D — NOT AUDITED",
          "Line " + e.line + " uses \u201C" + e.key + "\u201D, which is not in this auditor's list of known dnsmasq directives. It may be a typo, a directive from a newer dnsmasq, or a custom note — the auditor does not guess, so this line was not graded.",
          "Fix: check the spelling against the dnsmasq man page for your version; if it is valid there, treat this line as ungraded, not as passed.");
      }
    });

    // --- Duplicates of single-value directives: last value wins ---
    var seenSingle = {};
    entries.forEach(function(e){
      if (e.secret || !SINGLE_VALUE[e.key]) return;
      if (!seenSingle[e.key]) seenSingle[e.key] = [];
      seenSingle[e.key].push(e);
    });
    Object.keys(seenSingle).forEach(function(k){
      var list = seenSingle[k];
      if (list.length < 2) return;
      var first = list[0], last = list[list.length - 1];
      var linesList = list.map(function(e){ return e.line; }).join(" and ");
      add("WARNING", last.line, "Duplicate \u201C" + k + "\u201D — last value wins",
        "\u201C" + k + "\u201D is set on lines " + linesList + ". dnsmasq resolves repeated single-value directives by taking the last one, so the effective value is \u201C" + (last.value === null ? "(no value)" : last.value) + "\u201D from line " + last.line + "; the value on line " + first.line + " is ignored.",
        "Fix: delete the stale \u201C" + k + "\u201D line so the config says one thing in one place.");
    });

    // --- DNS posture ---
    var portEntries = byKey("port");
    var effectivePort = null, portLine = null;
    if (portEntries.length){
      var pe = portEntries[portEntries.length - 1];
      effectivePort = pe.value;
      portLine = pe.line;
    }
    var dnsDisabled = (effectivePort === "0");
    if (dnsDisabled){
      add("INFO", portLine, "DNS is disabled (port=0) — noted, not graded as exposure",
        "Line " + portLine + " sets port=0, which switches the DNS server off entirely. There is no open resolver to grade because dnsmasq will not answer DNS at all; DHCP settings below are still graded, because DHCP keeps running.",
        "Fix: none needed if DNS-off is deliberate. If clients should resolve names here, set port=53 (or remove the port line) and re-audit.");
    }

    var bogusPriv = has("bogus-priv");
    var domainNeeded = has("domain-needed");
    if (!bogusPriv){
      add("WARNING", null, "bogus-priv is missing — private reverse lookups leak upstream",
        "No line in this config sets bogus-priv, so reverse lookups for private addresses (10.x, 172.16–31.x, 192.168.x) are forwarded to the upstream resolver instead of being answered locally. That leaks your internal address plan to an outside server.",
        "Fix: add a line \u201Cbogus-priv\u201D to the config.");
    }
    if (!domainNeeded){
      add("INFO", null, "domain-needed is missing",
        "No line in this config sets domain-needed, so bare names with no domain can be forwarded upstream instead of being answered (or refused) locally.",
        "Fix: add a line \u201Cdomain-needed\u201D unless you deliberately forward bare names.");
    }

    // Listening posture
    var listenEntries = byKey("listen-address");
    var interfaceEntries = byKey("interface");
    var listenAddrs = [];
    listenEntries.forEach(function(e){
      if (e.value) e.value.split(",").forEach(function(a){ a = trim(a); if (a) listenAddrs.push({addr: a, line: e.line}); });
    });
    var bindsAll = false, bindsAllLine = null, restricted = false;
    listenAddrs.forEach(function(la){
      if (la.addr === "0.0.0.0" || la.addr === "::" || la.addr === "*"){ bindsAll = true; bindsAllLine = la.line; }
      else restricted = true;
    });
    interfaceEntries.forEach(function(e){
      if (e.value === "*" || e.value === ""){ bindsAll = true; bindsAllLine = e.line; }
      else restricted = true;
    });
    if (!listenEntries.length && !interfaceEntries.length){
      bindsAll = true; bindsAllLine = null; // dnsmasq default: every interface
    }
    if (bindsAll && !restricted && !dnsDisabled){
      var missing = [];
      if (!bogusPriv) missing.push("bogus-priv");
      if (!domainNeeded) missing.push("domain-needed");
      var sev = missing.length ? "BLOCKER" : "WARNING";
      var where = bindsAllLine ? ("Line " + bindsAllLine + " binds DNS to all interfaces") :
        "No listen-address or interface line restricts where DNS listens";
      add(sev, bindsAllLine, "Open resolver posture — DNS answers on every interface",
        where + ", so dnsmasq answers queries arriving on any network it is plugged into, including an untrusted one." +
        (missing.length ? " The standard protections are also missing: " + missing.join(" and ") + " " + (missing.length > 1 ? "are" : "is") + " not set, which removes the guardrails that keep local lookups local." : " bogus-priv and domain-needed are set, which limits the damage, but the resolver is still open to every network it touches."),
        "Fix: restrict listening to the networks that should use this resolver — for example \u201Clisten-address=127.0.0.1,192.168.1.2\u201D plus \u201Cbind-interfaces\u201D, or name the LAN interface with \u201Cinterface=eth0\u201D — and keep public/WAN interfaces out.");
    }

    // --- Upstreams: server= and no-resolv ---
    var serverEntries = byKey("server");
    var noResolvEntries = byKey("no-resolv");
    serverEntries.forEach(function(e){
      if (!e.value) return;
      var v = e.value;
      var cand = v;
      if (v.indexOf("/") !== -1){
        var parts = v.split("/").filter(function(p){ return p !== ""; });
        cand = parts.length ? parts[parts.length - 1] : "";
      }
      cand = cand.split("#")[0].split("@")[0];
      if (cand === "0.0.0.0" || cand === "::"){
        add("BLOCKER", e.line, "server= points at " + cand + " — not a real upstream",
          "Line " + e.line + " sends forwarded queries to " + cand + ", which is the unspecified address, not a DNS server. Anything dnsmasq forwards there goes nowhere.",
          "Fix: point line " + e.line + " at a real upstream resolver (for example server=1.1.1.1), or remove the line.");
      }
    });
    if (noResolvEntries.length && serverEntries.length === 0){
      add("BLOCKER", noResolvEntries[0].line, "no-resolv with no server= lines — DNS WILL NOT RESOLVE",
        "Line " + noResolvEntries[0].line + " sets no-resolv, which tells dnsmasq to ignore the system resolver file — but the config has no server= lines at all, so dnsmasq has no upstream to forward to. DNS WILL NOT RESOLVE for any client using this server.",
        "Fix: add at least one \u201Cserver=<upstream-ip>\u201D line, or remove no-resolv so dnsmasq falls back to the system resolver file.");
    }

    // --- address= wildcard overrides ---
    byKey("address").forEach(function(e){
      if (!e.value) return;
      var v = e.value.replace(/^\//, "");
      var dom = v.split("/")[0];
      if (dom === "#" || dom === "*" || dom === ""){
        add("WARNING", e.line, "Wildcard address= override answers every name",
          "Line " + e.line + " uses address= with a wildcard domain, so dnsmasq answers EVERY name it is asked about with the address on that line. That breaks resolution for anything the wildcard was not meant to cover.",
          "Fix: name the specific domain the override is for (address=/example.com/<address>), or remove the line.");
      }
    });

    // --- DHCP ranges ---
    function parseRange(e){
      var parts = e.value ? e.value.split(",").map(trim).filter(function(p){ return p !== ""; }) : [];
      parts = parts.filter(function(p){ return !/^(set|tag):/i.test(p); });
      var ips = parts.filter(isIPv4);
      var lease = null;
      parts.forEach(function(p){
        if (/^infinite$/i.test(p)) lease = "infinite";
        else if (/^\d+\s*[smhdw]$/i.test(p)) lease = p;
        else if (/^\d+$/.test(p) && lease === null) lease = p;
      });
      if (ips.length < 2) return {unparsed: true, lease: lease};
      var mask = ips.length > 2 ? ips[2] : "255.255.255.0";
      var startN = ipToInt(ips[0]), endN = ipToInt(ips[1]), maskN = ipToInt(mask);
      var base = (startN & maskN) >>> 0, bcast = (base | (~maskN >>> 0)) >>> 0;
      return {line: e.line, start: ips[0], end: ips[1], startN: startN, endN: endN, base: base, bcast: bcast, lease: lease};
    }
    var ranges = [];
    byKey("dhcp-range").forEach(function(e){
      var r = parseRange(e);
      if (r.unparsed){
        add("INFO", e.line, "dhcp-range on line " + e.line + " was not range-checked",
          "Line " + e.line + " is in a static, tagged, or IPv6 form this auditor does not range-check, so it was excluded from the overlap test — named here, not silently dropped.",
          "Fix: check this pool by hand for overlap with the other ranges.");
        return;
      }
      ranges.push(r);
      if (r.startN > r.endN){
        add("BLOCKER", e.line, "dhcp-range runs backwards",
          "Line " + e.line + " starts at " + r.start + " and ends at " + r.end + " — the end is below the start, so the pool is empty and dnsmasq cannot hand out addresses from it.",
          "Fix: swap the start and end on line " + e.line + ".");
      }
      if (r.lease && /^infinite$/i.test(r.lease)){
        add("WARNING", e.line, "dhcp-range has an infinite lease time",
          "Line " + e.line + " leases addresses from " + r.start + "\u2013" + r.end + " with lease time \u201Cinfinite\u201D. Addresses are never reclaimed, so the pool slowly fills with dead leases and new devices eventually get nothing.",
          "Fix: give line " + e.line + " a finite lease (for example 12h or 24h).");
      }
    });
    for (var i = 0; i < ranges.length; i++){
      for (var j = i + 1; j < ranges.length; j++){
        var a = ranges[i], b = ranges[j];
        var os = Math.max(a.startN, b.startN), oe = Math.min(a.endN, b.endN);
        if (os <= oe){
          var count = oe - os + 1;
          add("BLOCKER", b.line, "Overlapping dhcp-range pools — lines " + a.line + " and " + b.line,
            "Line " + a.line + " leases " + a.start + "\u2013" + a.end + " and line " + b.line + " leases " + b.start + "\u2013" + b.end + ". The pools overlap on " + intToIp(os) + "\u2013" + intToIp(oe) + ": " + intToIp(oe) + " \u2212 " + intToIp(os) + " + 1 = " + count + " address" + (count === 1 ? "" : "es") + " that can be handed to two different devices.",
            "Fix: shrink one pool so the ranges no longer touch — for example end line " + a.line + "'s pool below " + b.start + ", or start line " + b.line + "'s pool above " + a.end + ".");
        }
      }
    }

    // --- dhcp-option router / DNS posture ---
    function inAnySubnet(ip){
      var n = ipToInt(ip);
      if (n === null) return false;
      return ranges.some(function(r){ return n >= r.base && n <= r.bcast; }) ||
             ranges.some(function(r){ return n >= r.startN && n <= r.endN; });
    }
    function isListenAddr(ip){
      return listenAddrs.some(function(la){ return la.addr === ip; });
    }
    byKey("dhcp-option").forEach(function(e){
      if (!e.value) return;
      var parts = e.value.split(",").map(trim).filter(function(p){ return p !== ""; });
      parts = parts.filter(function(p){ return !/^(set|tag):/i.test(p); });
      if (!parts.length) return;
      var optTok = parts[0].toLowerCase();
      var optNum = null;
      if (/^\d+$/.test(optTok)) optNum = parseInt(optTok, 10);
      else if (optTok === "option:router" || optTok === "router") optNum = 3;
      else if (optTok === "option:dns-server" || optTok === "option:domain-name-servers" || optTok === "dns-server") optNum = 6;
      if (optNum !== 3 && optNum !== 6) return;
      var vals = parts.slice(1).filter(isIPv4);
      vals.forEach(function(ip){
        if (optNum === 6){
          if (ip === "0.0.0.0") return; // 0.0.0.0 in option 6 means "this server" in dnsmasq
          if (isListenAddr(ip) || inAnySubnet(ip)) return;
          add("WARNING", e.line, "DHCP advertises a DNS server that is not this server",
            "Line " + e.line + " tells DHCP clients to use " + ip + " for DNS, but this config does not listen on " + ip + (listenAddrs.length ? " (listen-address is " + listenAddrs.map(function(la){ return la.addr; }).join(", ") + ")" : "") + " and " + ip + " is outside every dhcp-range subnet. Clients will send their DNS queries somewhere other than the resolver this config just set up.",
            "Fix: advertise one of this server's own listen addresses in dhcp-option 6, or fix line " + e.line + " if pointing clients at a different, deliberate resolver.");
        } else {
          if (isListenAddr(ip) || inAnySubnet(ip)) return;
          add("WARNING", e.line, "DHCP advertises a router outside the served subnets",
            "Line " + e.line + " tells DHCP clients their default router is " + ip + ", but " + ip + " is not inside any dhcp-range subnet in this config and is not one of this server's listen addresses. Clients will likely get an address they cannot route through.",
            "Fix: set dhcp-option 3 on line " + e.line + " to the real gateway for the pool's subnet.");
        }
      });
    });

    // --- Sort: severity, then line (absent-directive findings last within a severity) ---
    var rank = {BLOCKER: 0, WARNING: 1, INFO: 2, NOTAUDITED: 3};
    findings.sort(function(x, y){
      if (rank[x.sev] !== rank[y.sev]) return rank[x.sev] - rank[y.sev];
      var lx = x.line === null ? 99999 : x.line, ly = y.line === null ? 99999 : y.line;
      return lx - ly;
    });

    var counts = {BLOCKER: 0, WARNING: 0, INFO: 0, NOTAUDITED: 0};
    findings.forEach(function(f){ counts[f.sev]++; });

    var verdict, why, cls;
    if (counts.BLOCKER > 0){
      verdict = "DO NOT DEPLOY";
      cls = "bad";
      why = counts.BLOCKER + " blocker" + (counts.BLOCKER === 1 ? "" : "s") + " must be fixed before this config goes near a live network.";
    } else if (counts.WARNING > 0){
      verdict = "DEPLOY WITH FIXES";
      cls = "warn";
      why = "No blockers, but " + counts.WARNING + " warning" + (counts.WARNING === 1 ? "" : "s") + " should be fixed before this config is trusted.";
    } else {
      verdict = "SAFE TO DEPLOY";
      cls = "good";
      why = "No blockers and no warnings in the graded checks." + (counts.INFO || counts.NOTAUDITED ? " The notes below are informational only." : "");
    }
    return {findings: findings, counts: counts, verdict: verdict, why: why, cls: cls};
  }

  function sevLabel(sev){
    return sev === "NOTAUDITED" ? "NOT AUDITED" : sev;
  }
  function lineLabel(f){
    return f.line === null ? "Whole config (directive absent)" : "Line " + f.line;
  }

  function buildReport(result){
    var out = [];
    out.push("J-Dawgs Dnsmasq Config Safety Auditor\u2122 — audit report");
    out.push("Verdict: " + result.verdict);
    out.push("Counts: " + result.counts.BLOCKER + " blocker(s), " + result.counts.WARNING + " warning(s), " +
             result.counts.INFO + " info, " + result.counts.NOTAUDITED + " not audited");
    out.push("");
    if (!result.findings.length){
      out.push("No findings. Nothing in the graded checks fired.");
    }
    result.findings.forEach(function(f){
      out.push("[" + sevLabel(f.sev) + "] " + lineLabel(f) + ": " + f.title);
      out.push("  " + f.detail);
      out.push("  " + f.fix);
      out.push("");
    });
    out.push("Notes: this audit ran offline in the browser. It did not run dnsmasq, did not resolve any name, and did not connect anywhere. Secret values are never printed in this report — secret-named lines are flagged by key name and line only.");
    return out.join("\n");
  }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-dnsmasq-config-safety-auditor',
  name: 'J-Dawgs Dnsmasq Config Safety Auditor',
  description: 'Grades a pasted dnsmasq.conf offline — open-resolver posture, DHCP-range overlap arithmetic, secrets flagged by key name only — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
