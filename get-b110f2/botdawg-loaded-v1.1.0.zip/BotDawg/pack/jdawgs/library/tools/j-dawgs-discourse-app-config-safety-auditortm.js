'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Discourse App Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";
var RISKY = [
"## Risky example — do not deploy as-is",
"templates:",
'  - "templates/postgres.template.yml"',
'  - "templates/redis.template.yml"',
'  - "templates/web.template.yml"',
'  - "templates/web.ratelimited.template.yml"',
"expose:",
'  - "80:80" # http',
'  - "443:443" # https',
"params:",
'  db_default_text_search_config: "pg_catalog.english"',
"env:",
"  LANG: en_US.UTF-8",
"  DISCOURSE_HOSTNAME: 'discourse.example.com'",
"  DISCOURSE_DEVELOPER_EMAILS: 'admin@example.com, ops@example.com, dev@example.com, owner@example.com, team@example.com'",
"  DISCOURSE_SMTP_ADDRESS: smtp.example.com",
"  DISCOURSE_SMTP_PORT: 25",
"  DISCOURSE_SMTP_USER_NAME: forum@example.com",
'  DISCOURSE_SMTP_PASSWORD: "PlainTextP@ssw0rd!2026"',
"  DISCOURSE_SMTP_ENABLE_START_TLS: false",
"  UNICORN_WORKERS: 2",
"volumes:",
"  - volume:",
"      host: /var/discourse/shared/standalone",
"      guest: /shared"
].join("\n");

var HARDENED = [
"## Hardened example — safer pattern",
"templates:",
'  - "templates/postgres.template.yml"',
'  - "templates/redis.template.yml"',
'  - "templates/web.template.yml"',
'  - "templates/web.ratelimited.template.yml"',
'  - "templates/web.ssl.template.yml"',
'  - "templates/web.letsencrypt.ssl.template.yml"',
"expose:",
'  - "127.0.0.1:80:80"',
'  - "127.0.0.1:443:443"',
"params:",
'  db_default_text_search_config: "pg_catalog.english"',
"env:",
"  LANG: en_US.UTF-8",
"  LANGUAGE: en_US.UTF-8",
"  LC_ALL: en_US.UTF-8",
"  DISCOURSE_HOSTNAME: 'forum.northfield-community.org'",
"  DISCOURSE_DEVELOPER_EMAILS: 'owner@northfield-community.org'",
"  DISCOURSE_SMTP_ADDRESS: smtp.mailprovider.net",
"  DISCOURSE_SMTP_PORT: 587",
"  DISCOURSE_SMTP_USER_NAME: forum@northfield-community.org",
'  DISCOURSE_SMTP_PASSWORD: "${DISCOURSE_SMTP_PASSWORD}"',
"  DISCOURSE_SMTP_ENABLE_START_TLS: true",
"  DISCOURSE_BACKUP_LOCATION: s3",
"  DISCOURSE_S3_REGION: us-east-1",
"  DISCOURSE_S3_BUCKET: northfield-discourse-backups",
'  DISCOURSE_S3_ACCESS_KEY_ID: "${S3_ACCESS_KEY_ID}"',
'  DISCOURSE_S3_SECRET_ACCESS_KEY: "${S3_SECRET_ACCESS_KEY}"',
"  UNICORN_WORKERS: 3",
"  UNICORN_SIDEKIQS: 1",
"volumes:",
"  - volume:",
"      host: /var/discourse/shared/standalone",
"      guest: /shared",
"  - volume:",
"      host: /var/discourse/shared/standalone/log/var-log",
"      guest: /var/log"
].join("\n");

function stripVal(raw){
  var v = (raw||"").trim();
  v = v.replace(/\s+#.*$/,"").trim();
  if((v.charAt(0)==='"' && v.charAt(v.length-1)==='"') || (v.charAt(0)==="'" && v.charAt(v.length-1)==="'")){
    v = v.slice(1,-1);
  }
  return v;
}
function isEnvRef(v){
  return /\$\{|^\{\{|env\.|ENV\[|getenv|vault:|secret:\/\/|\{\{\s*env/i.test(v);
}
function findKey(lines, key){
  for(var i=0;i<lines.length;i++){
    var m = lines[i].match(new RegExp("^\\s*" + key + "\\s*:\\s*(.*)$"));
    if(m) return { line: i+1, value: stripVal(m[1]) };
  }
  return null;
}
function audit(text){
  var findings = [];
  function add(sev, check, title, line, key, valueLength, detail){
    var f = { severity: sev, check: check, title: title, line: (line||null), detail: detail };
    if(key) f.key = key;
    if(typeof valueLength === "number") f.valueLength = valueLength;
    findings.push(f);
  }
  var raw = (text||"");
  var lines = raw.split(/\r?\n/);
  var discourseKeys = (raw.match(/DISCOURSE_[A-Z0-9_]+/g)||[]).length;
  var hasStructure = /templates\s*:|expose\s*:|env\s*:/.test(raw);
  if(raw.trim().length < 40 || discourseKeys < 2 || !hasStructure){
    add("INFO","input","Not enough config to grade",null,null,null,
      "Paste a fuller app.yml-style config — templates, expose, and env with DISCOURSE_ keys — and run the audit again.");
    return { verdict: "NOT ENOUGH TO GRADE", findings: findings };
  }

  /* Templates / SSL */
  var tplLine = null;
  for(var i=0;i<lines.length;i++){ if(/^\s*templates\s*:/.test(lines[i])){ tplLine = i+1; break; } }
  var hasSsl = /web\.ssl\.template\.yml/.test(raw);
  var hasLe = /web\.letsencrypt\.ssl\.template\.yml/.test(raw);
  if(!hasSsl && !hasLe){
    add("CRITICAL","ssl-template","No SSL template — http-only setup",tplLine,null,null,
      "Neither web.ssl.template.yml nor web.letsencrypt.ssl.template.yml appears in templates. The site would serve plain http until a rebuild with an SSL template.");
  } else if(hasSsl && !hasLe){
    add("WARN","ssl-template","SSL template present, Let's Encrypt template missing",tplLine,null,null,
      "web.ssl.template.yml is present but web.letsencrypt.ssl.template.yml is not. Fine with your own certificates; flagged so the choice is deliberate.");
  } else {
    add("PASS","ssl-template","SSL and Let's Encrypt templates present",tplLine,null,null,
      "Both web.ssl.template.yml and web.letsencrypt.ssl.template.yml are in templates.");
  }

  /* Expose ports */
  var inExpose = false, exposeCount = 0;
  for(var j=0;j<lines.length;j++){
    var L = lines[j];
    if(/^\s*expose\s*:/.test(L)){ inExpose = true; continue; }
    if(inExpose && /^\S/.test(L)){ inExpose = false; }
    if(inExpose){
      var em = L.match(/["']?([^"'\s#]+:\d+)["']?/);
      if(em && /^\d/.test(em[1]) || em && /^127\.0\.0\.1:/.test(em[1]) || em && /^localhost:/.test(em[1])){
        exposeCount++;
        var mapping = em[1];
        if(/^127\.0\.0\.1:/.test(mapping) || /^localhost:/.test(mapping)){
          add("PASS","expose-binding","Port mapping bound to localhost only",j+1,null,null,
            "Mapping " + mapping + " binds on 127.0.0.1, so the port is not published on every interface.");
        } else {
          add("HIGH","expose-binding","Port mapping binds on all interfaces",j+1,null,null,
            "Mapping " + mapping + " has no host IP, so Docker publishes it on all interfaces (0.0.0.0). Bind to 127.0.0.1 if a reverse proxy fronts the site.");
        }
      }
    }
  }
  if(exposeCount === 0){
    add("WARN","expose-binding","No expose port mappings found",null,null,null,
      "No port mappings were found under an expose block. If Discourse is reached through another container or proxy, that is expected — confirm the path deliberately.");
  }

  /* Hostname */
  var host = findKey(lines, "DISCOURSE_HOSTNAME");
  if(!host || !host.value){
    add("CRITICAL","hostname","DISCOURSE_HOSTNAME missing",host?host.line:null,"DISCOURSE_HOSTNAME",null,
      "DISCOURSE_HOSTNAME is not set. Discourse needs the real public hostname before deploy.");
  } else if(/example|localhost|yourdomain|your-domain|127\.0\.0\.1|test\.local|domain\.com$/i.test(host.value)){
    add("CRITICAL","hostname","Hostname is a default or example value",host.line,"DISCOURSE_HOSTNAME",null,
      "DISCOURSE_HOSTNAME is set to a default/example/localhost-style value. Replace it with the real public hostname.");
  } else {
    add("PASS","hostname","Hostname set to a non-default value",host.line,"DISCOURSE_HOSTNAME",null,
      "DISCOURSE_HOSTNAME is present and is not an example or localhost value.");
  }

  /* Secrets — value never recorded, length only */
  var secretSeen = {};
  for(var k=0;k<lines.length;k++){
    var sm = lines[k].match(/^\s*([A-Za-z0-9_]*(?:PASSWORD|SECRET)[A-Za-z0-9_]*)\s*:\s*(.+)$/);
    if(sm){
      var key = sm[1], val = stripVal(sm[2]);
      secretSeen[key] = true;
      if(val.length === 0){
        add("WARN","secret-empty","Secret key present but empty",k+1,key,0,
          key + " has an empty value. Set it through the environment before deploy.");
      } else if(isEnvRef(val)){
        add("PASS","secret-env-ref","Secret supplied as an environment reference",k+1,key,val.length,
          key + " uses an environment reference rather than a literal value (value length " + val.length + "). The value itself is never reported.");
      } else {
        add("CRITICAL","secret-plaintext","Plaintext secret in config",k+1,key,val.length,
          key + " holds a literal plaintext value (value length " + val.length + "). Move it to an environment reference or secret store. The value itself is never reported.");
      }
    }
  }
  if(!findKey(lines,"DISCOURSE_SMTP_PASSWORD")){
    add("WARN","secret-missing","DISCOURSE_SMTP_PASSWORD not found",null,"DISCOURSE_SMTP_PASSWORD",null,
      "No DISCOURSE_SMTP_PASSWORD key was found. If mail is configured another way, confirm it deliberately; otherwise SMTP auth will fail.");
  }

  /* Developer emails breadth */
  var dev = findKey(lines, "DISCOURSE_DEVELOPER_EMAILS");
  if(!dev || !dev.value){
    add("WARN","developer-emails","DISCOURSE_DEVELOPER_EMAILS missing",dev?dev.line:null,"DISCOURSE_DEVELOPER_EMAILS",null,
      "No developer emails are set. The first admin path should be deliberate, not discovered after deploy.");
  } else {
    var addrs = dev.value.split(",").map(function(s){return s.trim();}).filter(Boolean);
    if(addrs.length >= 4){
      add("HIGH","developer-emails","Developer emails grant admin broadly",dev.line,"DISCOURSE_DEVELOPER_EMAILS",null,
        addrs.length + " addresses are listed in DISCOURSE_DEVELOPER_EMAILS. Every listed address gets admin-level standing — trim it to the smallest real set.");
    } else if(addrs.length >= 2){
      add("WARN","developer-emails","Multiple developer emails listed",dev.line,"DISCOURSE_DEVELOPER_EMAILS",null,
        addrs.length + " addresses are listed in DISCOURSE_DEVELOPER_EMAILS. Confirm each one genuinely needs admin standing.");
    } else {
      add("PASS","developer-emails","Developer emails kept narrow",dev.line,"DISCOURSE_DEVELOPER_EMAILS",null,
        "Exactly one address is listed in DISCOURSE_DEVELOPER_EMAILS.");
    }
  }

  /* SMTP posture */
  var smtpAddr = findKey(lines, "DISCOURSE_SMTP_ADDRESS");
  if(!smtpAddr || !smtpAddr.value){
    add("WARN","smtp-address","DISCOURSE_SMTP_ADDRESS missing",smtpAddr?smtpAddr.line:null,"DISCOURSE_SMTP_ADDRESS",null,
      "No SMTP address is set, so outbound mail (signups, password resets) has nowhere to go.");
  }
  var port = findKey(lines, "DISCOURSE_SMTP_PORT");
  var tls = findKey(lines, "DISCOURSE_SMTP_ENABLE_START_TLS");
  var tlsOn = tls ? /^(true|yes|1)$/i.test(tls.value) : null;
  if(!port || !port.value){
    add("WARN","smtp-port","DISCOURSE_SMTP_PORT missing",port?port.line:null,"DISCOURSE_SMTP_PORT",null,
      "No SMTP port is set. Set 587 with STARTTLS, or 465 for implicit TLS, per your mail provider.");
  } else if(port.value === "25"){
    add("HIGH","smtp-port","SMTP on port 25",port.line,"DISCOURSE_SMTP_PORT",null,
      "Port 25 is the legacy relay port and is often blocked or unencrypted in transit. Prefer 587 with STARTTLS or 465.");
  } else if(port.value === "587" && tlsOn === true){
    add("PASS","smtp-port","SMTP submission port with STARTTLS on",port.line,"DISCOURSE_SMTP_PORT",null,
      "Port 587 with DISCOURSE_SMTP_ENABLE_START_TLS true is the standard submission posture.");
  } else if(port.value === "465"){
    add("PASS","smtp-port","SMTP on implicit-TLS port 465",port.line,"DISCOURSE_SMTP_PORT",null,
      "Port 465 uses implicit TLS, which is an acceptable mail posture.");
  } else {
    add("INFO","smtp-port","Non-standard SMTP port noted",port.line,"DISCOURSE_SMTP_PORT",null,
      "SMTP port " + port.value + " is set. Confirm it matches your provider and that TLS is enforced on it.");
  }
  if(tls && tlsOn === false){
    add("HIGH","smtp-tls","STARTTLS explicitly disabled",tls.line,"DISCOURSE_SMTP_ENABLE_START_TLS",null,
      "DISCOURSE_SMTP_ENABLE_START_TLS is false, so SMTP credentials and mail can cross the network without TLS. Turn it on (or use port 465).");
  } else if(!tls && port && port.value === "587"){
    add("WARN","smtp-tls","STARTTLS setting not stated for port 587",null,"DISCOURSE_SMTP_ENABLE_START_TLS",null,
      "Port 587 is set but DISCOURSE_SMTP_ENABLE_START_TLS is not stated. Set it explicitly to true.");
  } else if(tls && tlsOn === true){
    add("PASS","smtp-tls","STARTTLS enabled",tls.line,"DISCOURSE_SMTP_ENABLE_START_TLS",null,
      "DISCOURSE_SMTP_ENABLE_START_TLS is true.");
  }

  /* S3 / backups */
  var backupLoc = findKey(lines, "DISCOURSE_BACKUP_LOCATION");
  var s3Bucket = findKey(lines, "DISCOURSE_S3_BUCKET");
  var s3Region = findKey(lines, "DISCOURSE_S3_REGION");
  var hasAnyS3 = /DISCOURSE_S3_|DISCOURSE_USE_S3|DISCOURSE_BACKUP_LOCATION/.test(raw);
  if(!hasAnyS3){
    add("WARN","backup-s3","No S3 backup settings found",null,null,null,
      "No DISCOURSE_BACKUP_LOCATION, DISCOURSE_S3_BUCKET, or related S3 keys appear. Backups would stay on local disk — a single-host failure takes the backups with the forum.");
  } else if(backupLoc && /^s3$/i.test(backupLoc.value) && s3Bucket && s3Bucket.value && s3Region && s3Region.value){
    add("PASS","backup-s3","S3 backups configured",backupLoc.line,"DISCOURSE_BACKUP_LOCATION",null,
      "Backup location is s3 with both a bucket and a region set.");
  } else if(s3Bucket || s3Region || backupLoc){
    add("WARN","backup-s3","S3 backup settings incomplete",backupLoc?backupLoc.line:(s3Bucket?s3Bucket.line:null),null,null,
      "Some S3/backup keys are present but the set is incomplete — backup location, bucket, and region should all be set together.");
  }

  /* INFO: LANG + resources */
  var lang = findKey(lines, "LANG");
  if(lang && lang.value){
    add("INFO","lang","LANG is set",lang.line,"LANG",null,"LANG is set to a locale value. Confirm it matches the community's primary language; informational only.");
  } else {
    add("INFO","lang","LANG not set",null,"LANG",null,"LANG is not set in env. Discourse will fall back to its default locale handling; informational only.");
  }
  var workers = findKey(lines, "UNICORN_WORKERS");
  if(workers && workers.value){
    add("INFO","resources","Unicorn workers configured",workers.line,"UNICORN_WORKERS",null,"UNICORN_WORKERS is set to " + workers.value + ". Size it against the host's RAM; informational only.");
  } else {
    add("INFO","resources","No explicit resource limits found",null,null,null,"No UNICORN_WORKERS or similar resource keys were found. Defaults apply; informational only.");
  }

  var verdict;
  var hasCrit = findings.some(function(f){return f.severity==="CRITICAL";});
  var hasFix = findings.some(function(f){return f.severity==="HIGH"||f.severity==="WARN";});
  if(hasCrit) verdict = "DO NOT DEPLOY";
  else if(hasFix) verdict = "DEPLOY WITH FIXES";
  else verdict = "SAFE TO DEPLOY";
  return { verdict: verdict, findings: findings };
}

function counts(findings){
  var c = {CRITICAL:0,HIGH:0,WARN:0,INFO:0,PASS:0};
  findings.forEach(function(f){ c[f.severity] = (c[f.severity]||0)+1; });
  return c;
}
function buildReport(result){
  var c = counts(result.findings);
  var out = [];
  out.push("J-Dawgs Discourse App Config Safety Auditor — Report");
  out.push("Verdict: " + result.verdict);
  out.push("Counts: CRITICAL " + c.CRITICAL + " · HIGH " + c.HIGH + " · WARN " + c.WARN + " · INFO " + c.INFO + " · PASS " + c.PASS);
  out.push("Secret handling: secrets are reported by key name, line number, and value length only. Secret values never appear in this report.");
  out.push("");
  result.findings.forEach(function(f,i){
    var loc = f.line ? ("line " + f.line) : "no line";
    var extra = "";
    if(f.key) extra += " · key " + f.key;
    if(typeof f.valueLength === "number") extra += " · value length " + f.valueLength;
    out.push((i+1) + ". [" + f.severity + "] " + f.title + " (" + loc + extra + ")");
    out.push("   " + f.detail);
  });
  out.push("");
  out.push("Reminder: this audit ran offline in the browser. It did not rebuild or start any container, connect anywhere, save, or upload anything.");
  return out.join("\n");
}
function buildJson(result){
  var c = counts(result.findings);
  var obj = {
    tool: "J-Dawgs Discourse App Config Safety Auditor",
    verdict: result.verdict,
    counts: c,
    secretHandling: "Secrets are reported by key name, line number, and value length only. Secret values are never included.",
    findings: result.findings
  };
  return JSON.stringify(obj, null, 2);
}

var lastResult = null;
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-discourse-app-config-safety-auditortm',
  name: 'J-Dawgs Discourse App Config Safety Auditor',
  description: '',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
