'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Fencing Installation Proposal, Work Record & Final Invoice Consistency Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- formatting helpers ---------- */
      function round2(n){ return Math.round(n * 100) / 100; }
      function fmt(n){
        return "$" + round2(n).toLocaleString("en-US",{minimumFractionDigits:2, maximumFractionDigits:2});
      }
      function fmtQty(n){
        return (Math.round(n * 100) / 100).toLocaleString("en-US",{maximumFractionDigits:2});
      }
      function parseNum(s){
        if (s === undefined || s === null) return NaN;
        var v = parseFloat(String(s).replace(/[$,\s]/g,""));
        return isNaN(v) ? NaN : v;
      }

      /* ---------- name normalisation ----------
         Lowercase, drop the word "installed", singularise simple plurals,
         so "Cedar Posts", "cedar post" and "Posts installed" line up.
         The base slot is the last word (post / panel / gate / bag ...);
         the words before it are the material descriptor. */
      function normName(raw){
        var n = String(raw).toLowerCase()
          .replace(/[^a-z0-9\s-]/g," ")
          .replace(/\binstalled\b/g," ")
          .replace(/\s+/g," ")
          .trim();
        if (!n) return "";
        var toks = n.split(" ").map(function(t){
          if (t.length > 3 && /s$/.test(t) && !/ss$/.test(t)) t = t.slice(0,-1);
          return t;
        });
        return toks.join(" ");
      }
      function baseOf(norm){ var p = norm.split(" "); return p[p.length - 1]; }
      function descOf(norm){ var p = norm.split(" "); return p.slice(0, p.length - 1).join(" "); }

      /* ---------- document parser ---------- */
      function parseDoc(text, docLabel){
        var doc = { items:[], labor:null, fees:[], deposit:0, hasDeposit:false, total:null, warnings:[] };
        String(text || "").split(/\r?\n/).forEach(function(rawLine, idx){
          var line = rawLine.trim();
          if (!line || line.charAt(0) === "#") return;
          var parts = line.split("|").map(function(p){ return p.trim(); });
          var head = parts[0] || "";
          var headLow = head.toLowerCase();
          var where = docLabel + " line " + (idx + 1) + ": \u201C" + line + "\u201D";

          if (/^fee\s*:/i.test(head)) {
            var fname = head.replace(/^fee\s*:/i,"").trim();
            var famt = parseNum(parts[parts.length - 1]);
            if (!fname || isNaN(famt)) { doc.warnings.push("Could not read the fee on " + where); return; }
            doc.fees.push({ name: fname, norm: normName(fname), amount: famt });
            return;
          }
          if (/^deposit\b/.test(headLow)) {
            var damt = parseNum(parts[parts.length - 1]);
            if (isNaN(damt)) { doc.warnings.push("Could not read the deposit amount on " + where); return; }
            doc.deposit += damt; doc.hasDeposit = true;
            return;
          }
          if (/^total\b/.test(headLow)) {
            var tamt = parseNum(parts[parts.length - 1]);
            if (isNaN(tamt)) { doc.warnings.push("Could not read the total on " + where); return; }
            doc.total = tamt;
            return;
          }
          if (/^labor\b/.test(headLow)) {
            var hrs = parseNum(parts[1]);
            var rate = parts.length > 2 ? parseNum(parts[2]) : NaN;
            if (isNaN(hrs)) { doc.warnings.push("Could not read the labor hours on " + where); return; }
            doc.labor = { hours: hrs, rate: isNaN(rate) ? null : rate };
            return;
          }
          /* plain item line: name | qty | [unit price] */
          var qty = parseNum(parts[1]);
          var price = parts.length > 2 ? parseNum(parts[2]) : NaN;
          if (!head || isNaN(qty)) { doc.warnings.push("Could not read " + where); return; }
          doc.items.push({
            name: head,
            norm: normName(head),
            base: baseOf(normName(head)),
            qty: qty,
            price: isNaN(price) ? null : price
          });
        });
        return doc;
      }

      function findByBase(items, base, norm){
        var exact = null, first = null;
        for (var i = 0; i < items.length; i++){
          if (items[i].base !== base) continue;
          if (!first) first = items[i];
          if (items[i].norm === norm) { exact = items[i]; break; }
        }
        return exact || first;
      }
      function feeNames(doc){
        var s = {};
        doc.fees.forEach(function(f){ s[f.norm] = true; });
        return s;
      }

      /* ---------- the cross-check ---------- */
      function audit(proposalText, workText, invoiceText){
        var prop = parseDoc(proposalText, "Proposal");
        var work = parseDoc(workText, "Work record");
        var inv  = parseDoc(invoiceText, "Invoice");
        var findings = [];   /* {kind, detail, amount|null} — amount counts toward the overcharge total */
        var warnings = prop.warnings.concat(work.warnings, inv.warnings);
        var EPS = 0.005;

        function add(kind, detail, amount){ findings.push({ kind: kind, detail: detail, amount: (amount === null || amount === undefined) ? null : round2(amount) }); }

        /* --- items: quantity, invoice-only, material swap --- */
        inv.items.forEach(function(it){
          var w = findByBase(work.items, it.base, it.norm);
          var p = findByBase(prop.items, it.base, it.norm);
          var lineTotal = (it.price === null) ? null : round2(it.qty * it.price);

          if (!w && !p) {
            if (lineTotal === null) {
              add("Invoice-only item", "\u201C" + it.name + "\u201D is on the invoice but in neither the proposal nor the work record, and it carries no unit price to total.", null);
            } else {
              add("Invoice-only item", "\u201C" + it.name + "\u201D is on the invoice but in neither the proposal nor the work record. Billed " + fmtQty(it.qty) + " \u00D7 " + fmt(it.price) + " = " + fmt(lineTotal) + ", none of it agreed or recorded.", lineTotal);
            }
            return;
          }

          /* material swap: same slot, conflicting material words */
          var ref = w || p;
          var refSrc = w ? "work record" : "proposal";
          var dInv = descOf(it.norm), dRef = descOf(ref.norm);
          if (dInv && dRef && dInv !== dRef) {
            add("Material swap", "Invoice bills \u201C" + it.name + "\u201D, but the " + refSrc + " says \u201C" + ref.name + "\u201D for the same " + it.base + ". Different material than agreed/recorded — no dollar figure assigned; settle the material before paying.", null);
          }

          /* quantity billed above quantity installed */
          var installed = w ? w.qty : 0;
          if (it.qty > installed + EPS) {
            var excess = round2(it.qty - installed);
            if (it.price === null) {
              add("Quantity overbilled", "\u201C" + it.name + "\u201D: invoice bills " + fmtQty(it.qty) + ", work record shows " + fmtQty(installed) + " installed — " + fmtQty(excess) + " too many, but the invoice gives no unit price to total the excess.", null);
            } else {
              var amt = round2(excess * it.price);
              add("Quantity overbilled", "\u201C" + it.name + "\u201D: invoice bills " + fmtQty(it.qty) + ", work record shows " + fmtQty(installed) + " installed. Excess " + fmtQty(excess) + " \u00D7 " + fmt(it.price) + " = " + fmt(amt) + " overcharge.", amt);
            }
          }
        });

        /* --- labor --- */
        if (inv.labor) {
          var il = inv.labor;
          if (work.labor) {
            if (il.hours > work.labor.hours + EPS) {
              var exH = round2(il.hours - work.labor.hours);
              var rate = (il.rate !== null) ? il.rate : (work.labor.rate !== null ? work.labor.rate : (prop.labor ? prop.labor.rate : null));
              if (rate === null) {
                add("Labor overbilled", "Invoice bills " + fmtQty(il.hours) + " labor hours, work record shows " + fmtQty(work.labor.hours) + " hours — " + fmtQty(exH) + " hours too many, but no hourly rate is given to total them.", null);
              } else {
                var lAmt = round2(exH * rate);
                add("Labor overbilled", "Invoice bills " + fmtQty(il.hours) + " labor hours, work record shows " + fmtQty(work.labor.hours) + " hours. Excess " + fmtQty(exH) + " hrs \u00D7 " + fmt(rate) + " = " + fmt(lAmt) + " overcharge.", lAmt);
              }
            }
          } else if (!prop.labor) {
            if (il.rate === null) {
              add("Invoice-only labor", "Invoice bills " + fmtQty(il.hours) + " labor hours that appear in neither the proposal nor the work record, with no rate given.", null);
            } else {
              var liAmt = round2(il.hours * il.rate);
              add("Invoice-only labor", "Invoice bills labor that appears in neither the proposal nor the work record: " + fmtQty(il.hours) + " hrs \u00D7 " + fmt(il.rate) + " = " + fmt(liAmt) + ", none of it agreed or recorded.", liAmt);
            }
          } else {
            add("Labor unverified", "Invoice bills " + fmtQty(il.hours) + " labor hours; the work record lists no labor hours, so the billed time cannot be verified against work done.", null);
          }
        }

        /* --- fees: duplicates + invoice-only --- */
        var propFees = feeNames(prop), workFees = feeNames(work);
        var seenFee = {};
        inv.fees.forEach(function(f){
          if (seenFee[f.norm]) {
            add("Duplicate fee", "\u201C" + f.name + "\u201D fee appears more than once on the invoice. This repeat occurrence: " + fmt(f.amount) + " charged again.", f.amount);
            return;
          }
          seenFee[f.norm] = true;
          if (!propFees[f.norm] && !workFees[f.norm]) {
            add("Invoice-only fee", "\u201C" + f.name + "\u201D fee of " + fmt(f.amount) + " is on the invoice but in neither the proposal nor the work record.", f.amount);
          }
        });

        /* --- deposit credit --- */
        var depositExpected = prop.hasDeposit ? prop.deposit : (work.hasDeposit ? work.deposit : null);
        var depositSrc = prop.hasDeposit ? "proposal" : "work record";
        if (depositExpected !== null && depositExpected > 0) {
          var credited = inv.hasDeposit ? inv.deposit : 0;
          if (credited < depositExpected - EPS) {
            var missing = round2(depositExpected - credited);
            add("Deposit not credited", "Deposit of " + fmt(depositExpected) + " shown paid in the " + depositSrc + ", but the invoice credits only " + fmt(credited) + ". Missing credit: " + fmt(depositExpected) + " \u2212 " + fmt(credited) + " = " + fmt(missing) + ".", missing);
          }
        }

        /* --- invoice total vs sum of its own lines --- */
        var computed = 0, computedComplete = true;
        inv.items.forEach(function(it){
          if (it.price === null) { computedComplete = false; return; }
          computed += it.qty * it.price;
        });
        if (inv.labor) {
          if (inv.labor.rate === null) computedComplete = false;
          else computed += inv.labor.hours * inv.labor.rate;
        }
        inv.fees.forEach(function(f){ computed += f.amount; });
        if (inv.hasDeposit) computed -= inv.deposit;
        computed = round2(computed);

        if (inv.total !== null) {
          var diff = round2(inv.total - computed);
          if (diff > EPS) {
            add("Total mismatch", "Invoice states a total of " + fmt(inv.total) + ", but its own lines add to " + fmt(computed) + ". Difference: " + fmt(inv.total) + " \u2212 " + fmt(computed) + " = " + fmt(diff) + " too much.", diff);
          } else if (diff < -EPS) {
            add("Total mismatch", "Invoice states a total of " + fmt(inv.total) + ", but its own lines add to " + fmt(computed) + " — the stated total is " + fmt(-diff) + " in your favor. No overcharge counted, but get the paperwork corrected.", null);
          }
        }

        var total = 0;
        findings.forEach(function(f){ if (f.amount !== null) total += f.amount; });
        total = round2(total);

        var verdict;
        if (total > 0) verdict = "DO NOT PAY YET";
        else if (findings.length > 0 || warnings.length > 0) verdict = "PAY WITH CORRECTIONS";
        else verdict = "SAFE TO PAY";

        return {
          verdict: verdict,
          overchargeTotal: total,
          findings: findings,
          warnings: warnings,
          invoiceComputedTotal: computed,
          invoiceComputedComplete: computedComplete,
          invoiceStatedTotal: inv.total,
          counts: {
            proposalItems: prop.items.length,
            workItems: work.items.length,
            invoiceItems: inv.items.length,
            invoiceFees: inv.fees.length
          }
        };
      }

      /* ---------- built-in examples ---------- */
      var EXAMPLE_BAD = {
        proposal: [
          "Posts | 40 | 25",
          "Panels | 38 | 60",
          "Gate | 1 | 450",
          "Labor | 20 | 65",
          "Fee: Permit | 150",
          "Deposit paid | 1000"
        ].join("\n"),
        work: [
          "Posts | 38",
          "Panels | 36",
          "Gate | 1",
          "Labor | 18"
        ].join("\n"),
        invoice: [
          "Posts | 40 | 25",
          "Panels | 38 | 60",
          "Gate | 1 | 450",
          "Labor | 22 | 65",
          "Fee: Permit | 150",
          "Fee: Permit | 150",
          "Fee: Haul-away | 275",
          "Total | 5735"
        ].join("\n")
      };
      var EXAMPLE_CLEAN = {
        proposal: [
          "Posts | 20 | 25",
          "Panels | 18 | 60",
          "Gate | 1 | 450",
          "Labor | 10 | 65",
          "Fee: Permit | 150",
          "Deposit paid | 500"
        ].join("\n"),
        work: [
          "Posts | 20",
          "Panels | 18",
          "Gate | 1",
          "Labor | 10"
        ].join("\n"),
        invoice: [
          "Posts | 20 | 25",
          "Panels | 18 | 60",
          "Gate | 1 | 450",
          "Labor | 10 | 65",
          "Fee: Permit | 150",
          "Deposit paid | 500",
          "Total | 2330"
        ].join("\n")
      };

      /* ---------- report builders ---------- */
      function buildTextReport(r){
        var lines = [];
        lines.push("J-Dawgs Fencing Installation Proposal, Work Record & Final Invoice Consistency Auditor\u2122");
        lines.push("Verdict: " + r.verdict);
        lines.push("Documented overcharge total: " + fmt(r.overchargeTotal));
        lines.push("Invoice lines add to: " + fmt(r.invoiceComputedTotal) + (r.invoiceStatedTotal !== null ? " (invoice states " + fmt(r.invoiceStatedTotal) + ")" : " (invoice states no total)"));
        lines.push("");
        if (r.findings.length === 0 && r.warnings.length === 0) {
          lines.push("No discrepancies. All three documents agree.");
        }
        if (r.findings.length > 0) {
          lines.push("Discrepancies (" + r.findings.length + "):");
          r.findings.forEach(function(f, i){
            lines.push((i + 1) + ". [" + f.kind + "] " + f.detail + (f.amount !== null ? "  Amount: " + fmt(f.amount) + "." : ""));
          });
        }
        if (r.warnings.length > 0) {
          lines.push("");
          lines.push("Lines that could not be read (" + r.warnings.length + "):");
          r.warnings.forEach(function(w){ lines.push("- " + w); });
        }
        return lines.join("\n");
      }
      function buildJSON(r){
        return JSON.stringify({
          tool: "J-Dawgs Fencing Installation Proposal, Work Record & Final Invoice Consistency Auditor\u2122",
          verdict: r.verdict,
          documentedOverchargeTotal: r.overchargeTotal,
          invoiceComputedTotal: r.invoiceComputedTotal,
          invoiceStatedTotal: r.invoiceStatedTotal,
          findings: r.findings.map(function(f){
            return { kind: f.kind, detail: f.detail, amount: f.amount };
          }),
          unreadLines: r.warnings
        }, null, 2);
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_BAD": (typeof EXAMPLE_BAD !== 'undefined' ? EXAMPLE_BAD : undefined), "EXAMPLE_CLEAN": (typeof EXAMPLE_CLEAN !== 'undefined' ? EXAMPLE_CLEAN : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-fencing-installation-proposal-work-record-final-invoice-consistency-auditortm',
  name: 'J-Dawgs Fencing Installation Proposal, Work Record & Final Invoice Consistency Auditor',
  description: 'Cross-checks a fencing installation proposal vs work record vs final invoice into one pay verdict with arithmetic shown.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_BAD": __core["EXAMPLE_BAD"], "EXAMPLE_CLEAN": __core["EXAMPLE_CLEAN"] }
};
