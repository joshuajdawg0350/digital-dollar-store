'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Varnish VCL Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var RISKY_EXAMPLE = [
          "vcl 4.1;",
          "",
          "backend default {",
          "    .host = \"127.0.0.1\";",
          "    .port = \"8080\";",
          "}",
          "",
          "sub vcl_recv {",
          "    return (pass);",
          "}",
          "",
          "sub vcl_backend_fetch {",
          "    set bereq.http.Authorization = req.http.Authorization;",
          "}",
          "",
          "sub vcl_backend_response {",
          "    set bereq.http.X-Backend-Secret = \"FAKE-EXAMPLE-SECRET-12345\";",
          "}"
        ].join("\n");

        var CLEAN_EXAMPLE = [
          "vcl 4.1;",
          "",
          "backend default {",
          "    .host = \"127.0.0.1\";",
          "    .port = \"8080\";",
          "    .probe = {",
          "        .url = \"/health\";",
          "        .interval = 5s;",
          "        .timeout = 2s;",
          "        .window = 5;",
          "        .threshold = 3;",
          "    }",
          "}",
          "",
          "sub vcl_recv {",
          "    if (req.method != \"GET\" && req.method != \"HEAD\") {",
          "        return (pass);",
          "    }",
          "    if (req.http.Authorization || req.http.Cookie) {",
          "        return (pass);",
          "    }",
          "    if (req.url ~ \"\\.(css|js|png|jpg|svg|ico)$\") {",
          "        unset req.http.Cookie;",
          "    }",
          "    return (hash);",
          "}",
          "",
          "sub vcl_hash {",
          "    hash_data(req.url);",
          "    if (req.http.host) {",
          "        hash_data(req.http.host);",
          "    } else {",
          "        hash_data(server.ip);",
          "    }",
          "    if (req.http.X-Forwarded-Host) {",
          "        hash_data(req.http.X-Forwarded-Host);",
          "    }",
          "    return (lookup);",
          "}",
          "",
          "sub vcl_backend_response {",
          "    set beresp.grace = 6h;",
          "    return (deliver);",
          "}",
          "",
          "sub vcl_backend_error {",
          "    set beresp.http.Content-Type = \"text/html; charset=utf-8\";",
          "    synthetic({\"<html><body><h1>Service unavailable</h1></body></html>\"});",
          "    return (deliver);",
          "}"
        ].join("\n");

        function braceDelta(s) {
          var d = 0;
          for (var i = 0; i < s.length; i++) {
            if (s[i] === "{") d++;
            else if (s[i] === "}") d--;
          }
          return d;
        }

        // Find a subroutine block. Returns {start, end} as 0-based line indexes, or null.
        function findSub(lines, name) {
          var re = new RegExp("^\\s*sub\\s+" + name + "\\b");
          for (var i = 0; i < lines.length; i++) {
            if (re.test(lines[i])) {
              var depth = 0, seenBrace = false;
              for (var j = i; j < lines.length; j++) {
                var d = braceDelta(lines[j]);
                if (lines[j].indexOf("{") >= 0) seenBrace = true;
                depth += d;
                if (seenBrace && depth <= 0) return { start: i, end: j };
              }
              return { start: i, end: lines.length - 1 };
            }
          }
          return null;
        }

        function subLines(lines, block) {
          var out = [];
          for (var i = block.start; i <= block.end; i++) {
            out.push({ no: i + 1, text: lines[i] });
          }
          return out;
        }

        function subText(lines, block) {
          return lines.slice(block.start, block.end + 1).join("\n");
        }

        // Scan a subroutine's lines for return statements, tracking whether each
        // one sits inside an if/else block or follows a brace-less if on the
        // same statement (guarded), or stands unconditional (not guarded).
        function scanReturns(sLines) {
          var results = [];
          var stack = [];
          var pending = false;
          sLines.forEach(function (L) {
            var s = L.text;
            var i = 0;
            while (i < s.length) {
              var rest = s.slice(i);
              var prevOk = i === 0 || !/[A-Za-z0-9_]/.test(s[i - 1]);
              var m;
              if (prevOk && (m = rest.match(/^if\b/))) { pending = true; i += m[0].length; continue; }
              if (prevOk && (m = rest.match(/^else\b/))) { pending = true; i += m[0].length; continue; }
              var ch = s[i];
              if (ch === "{") { stack.push(pending); pending = false; i++; continue; }
              if (ch === "}") { stack.pop(); pending = false; i++; continue; }
              if (ch === ";") { pending = false; i++; continue; }
              if (prevOk && (m = rest.match(/^return\s*\(\s*([a-z_]+)\s*\)/))) {
                var guarded = pending || stack.some(function (f) { return f; });
                results.push({ line: L.no, action: m[1], guarded: guarded });
                i += m[0].length;
                continue;
              }
              i++;
            }
          });
          return results;
        }

        // For each if statement in a subroutine, capture its condition text and
        // the text of its body (braced block, or the rest of the line).
        function scanIfs(lines, block) {
          var out = [];
          for (var i = block.start; i <= block.end; i++) {
            var line = lines[i];
            var im = line.match(/\bif\s*\((.*)\)/);
            if (!im) continue;
            var body = "";
            if (line.indexOf("{") >= 0) {
              var depth = 0, seen = false;
              for (var j = i; j <= block.end; j++) {
                body += lines[j] + "\n";
                if (lines[j].indexOf("{") >= 0) seen = true;
                depth += braceDelta(lines[j]);
                if (seen && depth <= 0) break;
              }
            } else {
              body = line.slice(line.indexOf(")") + 1);
            }
            out.push({ condition: im[1], body: body, line: i + 1 });
          }
          return out;
        }

        function audit(text) {
          var lines = text.replace(/\r\n?/g, "\n").split("\n");
          var findings = [];
          function add(sev, check, lineLabel, sortLine, message, fix) {
            findings.push({
              sev: sev, check: check, lineLabel: lineLabel,
              sortLine: sortLine, message: message, fix: fix
            });
          }

          var recv = findSub(lines, "vcl_recv");
          var recvLineLabel = recv ? ("line " + (recv.start + 1) + " (sub vcl_recv)") : "file-wide (no vcl_recv found)";
          var recvSort = recv ? recv.start + 1 : 1;

          // Check 1 + 2: vcl_recv behaviour.
          if (recv) {
            var sLines = subLines(lines, recv);
            var returns = scanReturns(sLines);
            returns.forEach(function (r) {
              if ((r.action === "pass" || r.action === "pipe") && !r.guarded) {
                add("BLOCKER", "Blanket bypass in vcl_recv", "line " + r.line, r.line,
                  "vcl_recv returns (" + r.action + ") unconditionally at line " + r.line + ", with no if condition guarding it. " +
                  (r.action === "pipe"
                    ? "Every request is piped straight to the backend: nothing is cached and the connection is handed over raw."
                    : "Every request bypasses the cache, so the cache does no work at all."),
                  "Only return (" + r.action + ") inside an if for the specific requests that need it (for example non-GET/HEAD methods, or requests carrying Authorization or a Cookie), and let cacheable requests fall through to return (hash).");
              }
            });

            var ifs = scanIfs(lines, recv);
            var authPassed = false, cookiePassed = false;
            ifs.forEach(function (f) {
              var passes = /return\s*\(\s*pass\s*\)/.test(f.body);
              if (!passes) return;
              if (/req\.http\.Authorization/.test(f.condition)) authPassed = true;
              if (/req\.http\.Cookie/.test(f.condition)) cookiePassed = true;
            });
            if (!authPassed) {
              add("BLOCKER", "Personalized requests left cacheable — Authorization", recvLineLabel, recvSort,
                "vcl_recv has no return (pass) path conditioned on req.http.Authorization. A response to an authorized request can be stored in the cache and then served to anyone — the classic cache-leak failure.",
                "In vcl_recv, pass requests that carry credentials: if (req.http.Authorization) { return (pass); }");
            }
            if (!cookiePassed) {
              add("BLOCKER", "Personalized requests left cacheable — Cookie", recvLineLabel, recvSort,
                "vcl_recv has no return (pass) path conditioned on req.http.Cookie. Requests with session cookies can be answered from the cache, so one visitor's personalized page can be served to another.",
                "In vcl_recv, pass requests that carry cookies you do not deliberately strip: if (req.http.Cookie) { return (pass); } — or unset the Cookie only for content you know is identical for everyone.");
            }
          } else {
            add("BLOCKER", "Personalized requests left cacheable", "file-wide (no vcl_recv found)", 1,
              "No vcl_recv subroutine was found in the pasted VCL, so this audit cannot confirm that requests bearing Authorization or Cookie headers are passed instead of cached.",
              "Add a vcl_recv that returns (pass) for requests carrying req.http.Authorization or req.http.Cookie.");
          }

          // Check 3: Cookie strip.
          var cookieStripped = /unset\s+req\.http\.Cookie/.test(text) ||
            /set\s+req\.http\.Cookie\s*=\s*""/.test(text);
          if (!cookieStripped) {
            add("WARNING", "Cookie forwarded into the cacheable flow", recvLineLabel, recvSort,
              "The VCL never unsets req.http.Cookie. On requests that stay cacheable, cookies are forwarded into hashing and on to the backend, which fragments the cache and can leak cookie values into logs and backends that never needed them.",
              "For content that is identical for everyone, strip the header before hashing and fetching: unset req.http.Cookie; in vcl_recv (after any Cookie-based return (pass) rule).");
          }

          // Check 4: vcl_hash host variation.
          var hash = findSub(lines, "vcl_hash");
          if (!hash) {
            add("WARNING", "vcl_hash host variation", "file-wide (no vcl_hash found)", 1,
              "No vcl_hash subroutine was found. Without explicit hash input for the host, requests for different hostnames on the same URL can collide in the cache.",
              "Add a vcl_hash that hashes the URL and the host: hash_data(req.http.host); and, behind proxies, hash_data(req.http.X-Forwarded-Host);");
          } else {
            var hashBody = subText(lines, hash);
            var hashesHost = /hash_data\s*\([^)]*req\.http\.host/.test(hashBody);
            var hashesXFH = /hash_data\s*\([^)]*req\.http\.X-Forwarded-Host/.test(hashBody);
            if (!hashesHost && !hashesXFH) {
              add("WARNING", "vcl_hash host variation", "line " + (hash.start + 1) + " (sub vcl_hash)", hash.start + 1,
                "vcl_hash exists but never hashes req.http.host or req.http.X-Forwarded-Host, so host variants of the same URL can collide in the cache and serve the wrong site's content.",
                "In vcl_hash, add hash_data(req.http.host); and hash_data(req.http.X-Forwarded-Host); when the front proxy sets it.");
            }
          }

          // Check 5: grace posture (INFO only).
          var hasGrace = /beresp\.grace/.test(text) || /req\.grace/.test(text) || /saint/i.test(text);
          if (!hasGrace) {
            add("INFO", "Stale-serve posture", "file-wide", 1,
              "Posture note, not a proven risk: no grace is set anywhere (no beresp.grace, no req.grace, no saint-mode equivalent). If a backend goes down or runs slow, Varnish has no window in which it may serve slightly stale content instead of errors.",
              "If serving stale briefly is acceptable for your content, set beresp.grace (for example 6h) in vcl_backend_response.");
          }

          // Check 6: error handling.
          var hasSynth = !!findSub(lines, "vcl_synth");
          var hasBackendError = !!findSub(lines, "vcl_backend_error");
          if (!hasSynth && !hasBackendError) {
            add("WARNING", "Error handling", "file-wide", 1,
              "Neither vcl_synth nor vcl_backend_error exists in this VCL. Errors fall back to Varnish's default pages with no controlled handling, and synthetic responses have no deliberate path.",
              "Add a vcl_backend_error (and vcl_synth if you synthesize responses) that returns a controlled, deliberate error page.");
          }

          // Check 7: Authorization forwarded to backend.
          lines.forEach(function (lineText, idx) {
            if (/set\s+bereq\.http\.Authorization\s*=/.test(lineText) ||
                /bereq\.http\.Authorization\s*=\s*req\.http\.Authorization/.test(lineText)) {
              add("WARNING", "Authorization forwarded to the backend", "line " + (idx + 1), idx + 1,
                "Line " + (idx + 1) + " explicitly sets the backend request's Authorization header from the incoming request. Credentials a client sent to the cache are handed on to the backend, whether or not the backend should see them.",
                "If the backend does not need the client's credentials, remove the line so Authorization is not forwarded. If the backend does need them, make sure the request is passed (never cached) and document why.");
            }
          });

          // Check 8: backend probes.
          lines.forEach(function (lineText, idx) {
            var bm = lineText.match(/^\s*backend\s+([A-Za-z0-9_.\-]+)\s*\{/);
            if (!bm) return;
            var depth = 0, seen = false, body = "";
            for (var j = idx; j < lines.length; j++) {
              body += lines[j] + "\n";
              if (lines[j].indexOf("{") >= 0) seen = true;
              depth += braceDelta(lines[j]);
              if (seen && depth <= 0) break;
            }
            if (!/\.probe\b/.test(body)) {
              add("INFO", "Backend health probe", "line " + (idx + 1), idx + 1,
                "The backend \"" + bm[1] + "\" defined at line " + (idx + 1) + " has no .probe, so Varnish has no health signal for it and will keep sending it traffic even when it is down.",
                "Add a .probe block to the backend (URL, interval, timeout, window, threshold) so Varnish can route around a sick backend.");
            }
          });

          // Check 9: hard-coded secrets — key name and line ONLY, never the value.
          var secretKeyRe = /(password|passwd|secret|token|api[_-]?key)/i;
          lines.forEach(function (lineText, idx) {
            var flagged = null;
            var am = lineText.match(/([A-Za-z0-9_.\-]+)\s*=\s*("[^"]*"|'[^']*'|\S+)/);
            if (am && secretKeyRe.test(am[1])) {
              flagged = am[1];
            }
            if (!flagged && /bearer\s+[A-Za-z0-9._\-~+/=]{4,}/i.test(lineText) &&
                (/\bset\b/.test(lineText) || lineText.indexOf("=") >= 0)) {
              flagged = "Authorization (Bearer value)";
            }
            if (flagged) {
              add("BLOCKER", "Hard-coded secret", "line " + (idx + 1), idx + 1,
                "A key named \"" + flagged + "\" is assigned a value directly in the VCL at line " + (idx + 1) + ". The value is deliberately not shown here. Secrets committed in VCL end up in version control, logs, and every copy of the file.",
                "Remove the secret from the VCL. Load it from outside the file (environment, secret store, or a separate include with tight permissions) and rotate the exposed value.");
            }
          });

          var sevRank = { BLOCKER: 0, WARNING: 1, INFO: 2 };
          findings.sort(function (a, b) {
            if (sevRank[a.sev] !== sevRank[b.sev]) return sevRank[a.sev] - sevRank[b.sev];
            return a.sortLine - b.sortLine;
          });

          var counts = { BLOCKER: 0, WARNING: 0, INFO: 0 };
          findings.forEach(function (f) { counts[f.sev]++; });
          var verdict = counts.BLOCKER > 0 ? "DO NOT DEPLOY"
            : counts.WARNING > 0 ? "DEPLOY WITH FIXES"
            : "SAFE TO DEPLOY";
          return { findings: findings, counts: counts, verdict: verdict };
        }

        function buildReport(result) {
          var out = [];
          out.push("J-Dawgs Varnish VCL Safety Auditor — audit report");
          out.push("Verdict: " + result.verdict);
          out.push("Counts: " + result.counts.BLOCKER + " BLOCKER, " +
            result.counts.WARNING + " WARNING, " + result.counts.INFO + " INFO");
          out.push("");
          if (result.findings.length === 0) {
            out.push("No findings. Nothing in the pasted VCL tripped any of the nine checks.");
          } else {
            result.findings.forEach(function (f, i) {
              out.push((i + 1) + ". [" + f.sev + "] " + f.check + " — " + f.lineLabel);
              out.push("   Finding: " + f.message);
              out.push("   Fix: " + f.fix);
              out.push("");
            });
          }
          out.push("Note: heuristic text audit of pasted VCL only — not a compiler, not varnishd. Secret findings name the key and line only; values are never printed.");
          return out.join("\n");
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "CLEAN_EXAMPLE": (typeof CLEAN_EXAMPLE !== 'undefined' ? CLEAN_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-varnish-vcl-safety-auditortm',
  name: 'J-Dawgs Varnish VCL Safety Auditor',
  description: 'Grades a pasted VCL file offline: blanket pass/pipe bypasses, Authorization forwarded to backends, cookies never stripped before hashing so personalized content gets cached for everyone — into one deploy verdict. Host-bound compile checks stop at will-it-compile; ours grades deploy safety.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "CLEAN_EXAMPLE": __core["CLEAN_EXAMPLE"] }
};
