'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs ntfy Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

/* ---------- Examples (line numbers are contractual — the self-test checks them) ---------- */
var RISKY_LINES = [
  'base-url: "http://alerts.example.com"',              /* line 1  */
  'listen-http: ":80"',                                  /* line 2  */
  'auth-default-access: "allow-all"',                    /* line 3  */
  'enable-signup: true',                                 /* line 4  */
  'enable-login: true',                                  /* line 5  */
  'cache-file: "/var/cache/ntfy/cache.db"',              /* line 6  */
  'attachment-cache-dir: "/var/cache/ntfy/attachments"', /* line 7  */
  'web-root: "app"',                                     /* line 8  */
  'upstream-base-url: "http://ntfy.sh"',                 /* line 9  */
  'smtp-sender-user: "alerts@example.com"',              /* line 10 */
  'smtp-sender-pass: "Sup3rPlainText!"',                 /* line 11 */
  'firebase-key-file: "/srv/ntfy/firebase-service-account.json"', /* line 12 */
  'behind-proxy: false'                                  /* line 13 */
];
var RISKY = RISKY_LINES.join("\n");

var HARDENED_LINES = [
  'base-url: "https://alerts.example.com"',
  'listen-https: ":443"',
  'key-file: "/etc/ntfy/server.key"',
  'cert-file: "/etc/ntfy/server.crt"',
  'auth-file: "/etc/ntfy/user.db"',
  'auth-default-access: "deny-all"',
  'enable-signup: false',
  'enable-login: false',
  'cache-file: "/var/cache/ntfy/cache.db"',
  'cache-duration: "12h"',
  'attachment-cache-dir: "/var/cache/ntfy/attachments"',
  'attachment-total-size-limit: "5G"',
  'attachment-file-size-limit: "15M"',
  'attachment-expiry-duration: "3d"',
  'web-root: "disable"',
  'behind-proxy: true',
  'upstream-base-url: "https://ntfy.sh"',
  'smtp-sender-addr: "ntfy@example.com"',
  'smtp-sender-user: "alerts@example.com"',
  'smtp-sender-pass: "${NTFY_SMTP_PASS}"'
];
var HARDENED = HARDENED_LINES.join("\n");

var PROSE = "This server sends phone alerts for the crew. It has run fine all season and nobody has complained about it yet, so the plan is to keep the same setup when it moves to the new box next week.";

/* ---------- Parsing ---------- */
var KNOWN_KEYS = {};
("base-url listen-http listen-https listen-unix key-file cert-file auth-file auth-default-access " +
 "enable-signup enable-login enable-reservations require-login cache-file cache-duration cache-batch-size " +
 "cache-batch-timeout attachment-cache-dir attachment-total-size-limit attachment-file-size-limit " +
 "attachment-expiry-duration web-root behind-proxy proxy-forwarded-header upstream-base-url upstream-access-token " +
 "smtp-sender-addr smtp-sender-user smtp-sender-pass smtp-sender-from smtp-server-listen smtp-server-domain " +
 "firebase-key-file visitor-subscription-limit visitor-request-limit-burst visitor-request-limit-replenish " +
 "visitor-message-daily-limit message-limit global-topic-limit log-level log-format log-file keepalive-interval " +
 "manager-interval delayed-sender-interval disallowed-topics enable-metrics metrics-listen-http web-push-public-key " +
 "web-push-private-key web-push-file web-push-email-address twilio-account twilio-auth-token twilio-phone-number " +
 "auth-users auth-access visitor-subscriber-rate-limiting unix-socket-permissions cache-startup-queries").split(" ").forEach(function(k){ KNOWN_KEYS[k]=true; });

function unquote(v){
  v = v.replace(/\s+#.*$/, function(m){ return m; }); /* keep simple: no inline-comment stripping inside quotes risk */
  v = v.trim();
  if (v.length >= 2 && ((v.charAt(0)==='"' && v.charAt(v.length-1)==='"') || (v.charAt(0)==="'" && v.charAt(v.length-1)==="'"))) {
    v = v.slice(1, -1);
  }
  return v.trim();
}

function parseConfig(text){
  var lines = String(text == null ? "" : text).split(/\r?\n/);
  var entries = [];
  var byKey = {};
  for (var i = 0; i < lines.length; i++){
    var raw = lines[i];
    var t = raw.trim();
    if (!t || t.charAt(0) === "#") continue;
    var m = t.match(/^([A-Za-z][A-Za-z0-9_-]*)\s*[:=]\s*(.*)$/);
    if (!m) continue;
    var key = m[1].toLowerCase();
    var value = unquote(m[2] || "");
    var e = { key: key, value: value, line: i + 1, known: !!KNOWN_KEYS[key] };
    entries.push(e);
    if (!byKey[key]) byKey[key] = e; /* first occurrence wins, like most parsers */
  }
  return { lines: lines, entries: entries, byKey: byKey };
}

function isEnvRef(v){ return /^\$\{[^}]+\}$/.test(v) || /^\$[A-Za-z_][A-Za-z0-9_]*$/.test(v) || v.indexOf("${") !== -1; }
function isTrue(v){ return /^(true|yes|on)$/i.test(v); }
function isFalse(v){ return /^(false|no|off)$/i.test(v); }
function get(byKey, k){ return byKey[k] || null; }
function val(byKey, k){ var e = get(byKey, k); return e ? e.value : null; }

/* Host part of a listen address: "" / 0.0.0.0 / :: means all interfaces. */
function listenHost(addr){
  if (!addr) return "";
  var a = addr.trim();
  if (a.charAt(0) === "["){ var end = a.indexOf("]"); return end > 0 ? a.slice(1, end) : a; }
  var idx = a.lastIndexOf(":");
  return idx >= 0 ? a.slice(0, idx) : a;
}
function isAllInterfaces(addr){
  var h = listenHost(addr);
  return h === "" || h === "0.0.0.0" || h === "::" || h === "*";
}
function isLocalhost(addr){
  var h = listenHost(addr).toLowerCase();
  return h === "127.0.0.1" || h === "localhost" || h === "::1";
}

/* ---------- Auditor ---------- */
var SEV_RANK = { CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3 };

function audit(text){
  var parsed = parseConfig(text);
  var byKey = parsed.byKey;
  var findings = [];
  function add(sev, line, key, title, detail, fix){
    findings.push({ severity: sev, line: (line == null ? null : line), key: key, title: title, detail: detail, fix: fix });
  }

  var knownCount = parsed.entries.filter(function(e){ return e.known; }).length;

  if (knownCount < 3){
    return { verdict: "NOT ENOUGH TO GRADE", findings: [], stats: {
      linesScanned: parsed.lines.length, entries: parsed.entries.length, knownKeys: knownCount,
      note: "Fewer than three recognized ntfy config keys were found. Paste a server.yml / server.conf style config (key: value lines) to get a grade."
    }};
  }

  var hasTLSListener = !!get(byKey, "listen-https");
  var hasCertPair = !!get(byKey, "key-file") && !!get(byKey, "cert-file");
  var behindProxy = isTrue(val(byKey, "behind-proxy") || "");
  var tlsPosture = hasTLSListener || hasCertPair || behindProxy;
  var authFile = get(byKey, "auth-file");
  var defaultAccess = (val(byKey, "auth-default-access") || "").toLowerCase();

  /* base-url */
  var bu = get(byKey, "base-url");
  if (!bu){
    add("MEDIUM", null, "base-url", "No base-url set",
      "The config never states its public base URL, so links, attachments, and the web app fall back to whatever the request says.",
      "Set base-url to the exact public HTTPS URL of the instance.");
  } else if (!isEnvRef(bu.value) && /^http:\/\//i.test(bu.value)){
    add("HIGH", bu.line, "base-url", "base-url is plain HTTP",
      "The public URL is http, not https. Login sessions, access tokens, and attachment links tied to this URL cross the network unencrypted.",
      "Serve the instance over HTTPS (directly or through a TLS-terminating proxy) and set base-url to the https URL.");
  }

  /* listen-http exposure */
  var lh = get(byKey, "listen-http");
  if (lh && lh.value !== ""){
    if (isAllInterfaces(lh.value) && !tlsPosture){
      add("CRITICAL", lh.line, "listen-http", "Public HTTP listener with no TLS or proxy posture",
        "listen-http binds all interfaces and the config shows no HTTPS listener, no cert/key pair, and behind-proxy is not enabled. Everything — including auth — is plaintext to the whole network.",
        "Bind HTTP to localhost behind a TLS proxy, or configure listen-https with key-file and cert-file, and remove the public plain-HTTP listener.");
    } else if (isAllInterfaces(lh.value)){
      add("MEDIUM", lh.line, "listen-http", "Plain-HTTP listener still bound to all interfaces",
        "A TLS or proxy posture exists elsewhere in the config, but a plain-HTTP listener on all interfaces is still declared.",
        "Restrict listen-http to 127.0.0.1 (proxy-only) or remove it if the proxy talks to the HTTPS or unix listener.");
    }
  }
  if (!lh && !hasTLSListener && !get(byKey, "listen-unix")){
    add("HIGH", null, "listen-http", "No listener declared — the built-in default is public plain HTTP",
      "With no listen-http, listen-https, or listen-unix in the config, the server's own default listener decides, and that default is plain HTTP.",
      "Declare the listener explicitly: listen-https with a cert/key pair, a localhost listen-http behind a TLS proxy, or listen-unix.");
  }

  /* HTTPS listener completeness */
  var lhs = get(byKey, "listen-https");
  if (lhs && lhs.value !== "" && !hasCertPair){
    add("HIGH", lhs.line, "listen-https", "HTTPS listener without a complete cert/key pair",
      "listen-https is set but key-file and cert-file are not both present in the config, so the TLS listener cannot start as configured.",
      "Set both key-file and cert-file to the server's key and certificate, readable only by the service account.");
  }

  /* auth posture */
  var da = get(byKey, "auth-default-access");
  if (da && defaultAccess === "allow-all"){
    if (!authFile){
      add("CRITICAL", da.line, "auth-default-access", "allow-all with no auth file — instance is open by default",
        "auth-default-access is allow-all and no auth-file appears anywhere in the config, so there are no user accounts to restrict anyone with. Every topic is readable and writable by anyone who can reach the server.",
        "Create an auth file, add an admin user, and set auth-default-access to deny-all (or read-only where anonymous reads are truly intended).");
    } else {
      add("HIGH", da.line, "auth-default-access", "Default access is allow-all",
        "Even with an auth file, allow-all means anonymous clients can read and publish to topics that have no explicit ACL.",
        "Set auth-default-access to deny-all and grant access per user and topic instead.");
    }
  }
  if (!da && !authFile){
    add("MEDIUM", null, "auth-file", "No authentication posture stated in the config",
      "Neither auth-file nor auth-default-access appears, so the instance's access rules are whatever the defaults and the environment happen to be — nothing in the config pins them down.",
      "Set auth-file and an explicit auth-default-access (deny-all is the safe default) in the config itself.");
  }

  /* signup / login */
  var su = get(byKey, "enable-signup");
  if (su && isTrue(su.value)){
    add("HIGH", su.line, "enable-signup", "Open signup is enabled",
      "enable-signup is true, so anyone who can reach the server can register an account — on an internet-facing instance that is an open door, not a feature.",
      "Set enable-signup to false and create accounts from the command line instead.");
  }
  var li = get(byKey, "enable-login");
  if (li && isTrue(li.value)){
    if (!authFile){
      add("HIGH", li.line, "enable-login", "Login enabled with no auth file",
        "enable-login turns on the login surface, but no auth-file is configured, so there is no account database behind it — a sign the auth setup was never finished.",
        "Configure auth-file and at least one admin user, or set enable-login to false.");
    } else if (su && isTrue(su.value)){
      add("MEDIUM", li.line, "enable-login", "Login and open signup are both on",
        "With signup open, the login surface gives self-registered strangers a full account session.",
        "Turn enable-signup off; keep login only for accounts you created.");
    }
  }

  /* cache retention */
  var cf = get(byKey, "cache-file");
  if (cf && cf.value !== "" && !get(byKey, "cache-duration")){
    add("MEDIUM", cf.line, "cache-file", "Message cache with no retention limit stated",
      "cache-file persists messages to disk, but no cache-duration appears in the config, so the config itself sets no bound on how long messages are kept.",
      "Set cache-duration explicitly (for example 12h) so retention is a decision, not an accident.");
  }

  /* attachment cache limits */
  var ac = get(byKey, "attachment-cache-dir");
  if (ac && ac.value !== ""){
    if (!get(byKey, "attachment-total-size-limit")){
      add("HIGH", ac.line, "attachment-cache-dir", "Attachment cache with no total size limit",
        "Attachments are cached to disk with no attachment-total-size-limit in the config. A busy or abused instance fills the disk, and a full disk takes the service — and possibly the host — down.",
        "Set attachment-total-size-limit to a size the host can afford (for example 5G).");
    }
    if (!get(byKey, "attachment-file-size-limit")){
      add("MEDIUM", ac.line, "attachment-cache-dir", "Attachment cache with no per-file size limit",
        "No attachment-file-size-limit is stated, so a single oversized attachment is bounded only by defaults you have not reviewed.",
        "Set attachment-file-size-limit explicitly (for example 15M).");
    }
    if (!get(byKey, "attachment-expiry-duration")){
      add("MEDIUM", ac.line, "attachment-cache-dir", "Attachment cache with no expiry stated",
        "No attachment-expiry-duration appears in the config, so cached attachments have no config-level lifetime bound.",
        "Set attachment-expiry-duration explicitly (for example 3d).");
    }
  }

  /* web-root exposure */
  var wr = get(byKey, "web-root");
  if (wr && /^(app|home)$/i.test(wr.value)){
    if (!authFile || defaultAccess === "allow-all"){
      add("MEDIUM", wr.line, "web-root", "Web app served while authentication is open",
        "The web app is served from this instance while the auth posture is open, giving unauthenticated visitors a friendly front door to every public topic.",
        "Fix the auth posture first (auth-file plus deny-all), or set web-root to disable on instances that only serve the API.");
    } else {
      add("LOW", wr.line, "web-root", "Web app is served from this instance",
        "Serving the web app is a deliberate choice on an authenticated instance — just confirm it is intended and reachable only where you expect.",
        "Leave as-is if the web app is wanted; otherwise set web-root to disable.");
    }
  }

  /* upstream */
  var up = get(byKey, "upstream-base-url");
  if (up && up.value !== "" && !isEnvRef(up.value)){
    var cred = up.value.match(/^[a-z][a-z0-9+.-]*:\/\/[^\/:@\s]+:([^\/@\s]+)@/i);
    if (cred){
      add("CRITICAL", up.line, "upstream-base-url", "Credentials embedded in the upstream URL",
        "The upstream URL embeds a password (length " + cred[1].length + "; value not shown). Anyone who reads this config owns that credential.",
        "Move the credential into an environment reference or a dedicated token setting, and rotate the exposed password.");
    } else if (/^http:\/\//i.test(up.value)){
      add("HIGH", up.line, "upstream-base-url", "Upstream reached over plain HTTP",
        "upstream-base-url is http, so messages forwarded upstream — and any upstream credentials — cross the network unencrypted.",
        "Use the https upstream URL.");
    }
  }

  /* plaintext secrets — reported by key, line, and length only */
  var SECRET_KEY = /(pass(word)?|secret|token|api[-_]?key|private[-_]?key|credential)/i;
  parsed.entries.forEach(function(e){
    if (!SECRET_KEY.test(e.key)) return;
    if (/_file$|-file$/.test(e.key)) return;      /* key-file / cert-file / firebase-key-file hold paths, not secrets */
    if (e.key === "web-push-public-key") return;  /* public by design */
    if (!e.value) return;
    if (isEnvRef(e.value)) return;                /* environment references are the safe pattern */
    add("CRITICAL", e.line, e.key, "Plaintext secret in the config",
      "Key '" + e.key + "' holds a literal secret value of length " + e.value.length + " (value not shown). Config files get committed, backed up, and pasted into tickets — a literal secret in one is a published secret.",
      "Replace the value with an environment reference such as ${ENV_NAME}, keep the real secret in the service's environment, and rotate the exposed value.");
  });

  /* firebase credential file */
  var fb = get(byKey, "firebase-key-file");
  if (fb && fb.value !== ""){
    add("MEDIUM", fb.line, "firebase-key-file", "Firebase service-account file referenced",
      "The Firebase service-account JSON this points at is a live credential. The audit cannot see the file's permissions or location from the config text.",
      "Keep the file outside the web root and any repo, owned by the service account with 0600 permissions, and never commit or copy it into images.");
  }

  /* behind-proxy on a public listener */
  var bp = get(byKey, "behind-proxy");
  if (bp && isFalse(bp.value) && lh && isAllInterfaces(lh.value)){
    add("LOW", bp.line, "behind-proxy", "behind-proxy is false on a public listener",
      "With a public listener and behind-proxy off, forwarded-for headers are ignored — rate limits and logs key on the wrong client address if a proxy is ever placed in front, and nothing in the config warns about it.",
      "If a reverse proxy fronts this instance, set behind-proxy to true and configure the forwarded-header to match; if it truly faces the internet directly, fix the listener and TLS findings first.");
  }

  findings.sort(function(a, b){
    var r = SEV_RANK[a.severity] - SEV_RANK[b.severity];
    if (r !== 0) return r;
    return (a.line || 9999) - (b.line || 9999);
  });

  var verdict;
  if (findings.some(function(f){ return f.severity === "CRITICAL"; })) verdict = "DO NOT DEPLOY";
  else if (findings.length > 0) verdict = "DEPLOY WITH FIXES";
  else verdict = "SAFE TO DEPLOY";

  return { verdict: verdict, findings: findings, stats: {
    linesScanned: parsed.lines.length, entries: parsed.entries.length, knownKeys: knownCount, note: null
  }};
}

/* ---------- Report / JSON builders (never include the pasted config) ---------- */
function countBy(findings, sev){ return findings.filter(function(f){ return f.severity === sev; }).length; }

function buildReport(res){
  var out = [];
  out.push("J-Dawgs ntfy Server Config Safety Auditor — Report");
  out.push("Verdict: " + res.verdict);
  out.push("Lines scanned: " + res.stats.linesScanned + " · Config entries parsed: " + res.stats.entries + " · Recognized ntfy keys: " + res.stats.knownKeys);
  if (res.stats.note){ out.push("Note: " + res.stats.note); }
  out.push("Findings: " + res.findings.length +
    " (CRITICAL " + countBy(res.findings, "CRITICAL") +
    ", HIGH " + countBy(res.findings, "HIGH") +
    ", MEDIUM " + countBy(res.findings, "MEDIUM") +
    ", LOW " + countBy(res.findings, "LOW") + ")");
  out.push("");
  if (res.findings.length === 0 && res.verdict === "SAFE TO DEPLOY"){
    out.push("No findings. The pasted config passed every text-level check in this audit.");
  }
  res.findings.forEach(function(f, i){
    out.push((i + 1) + ". [" + f.severity + "] Line " + (f.line == null ? "— (missing)" : f.line) + " · " + f.key + " — " + f.title);
    out.push("   " + f.detail);
    out.push("   Fix: " + f.fix);
  });
  out.push("");
  out.push("Scope: heuristic text audit of the pasted config only. This tool does not start ntfy, does not connect to any server, and cannot verify TLS certificates or live auth behavior.");
  out.push("Secrets are reported by key name, line, and value length only; secret values never appear in this report.");
  out.push("Generated locally in your browser. Nothing was uploaded or saved.");
  return out.join("\n");
}

function buildJSON(res){
  return JSON.stringify({
    tool: "J-Dawgs ntfy Server Config Safety Auditor",
    version: 1,
    verdict: res.verdict,
    stats: res.stats,
    counts: {
      total: res.findings.length,
      critical: countBy(res.findings, "CRITICAL"),
      high: countBy(res.findings, "HIGH"),
      medium: countBy(res.findings, "MEDIUM"),
      low: countBy(res.findings, "LOW")
    },
    findings: res.findings,
    scope: "Heuristic text audit of the pasted config only. Does not start ntfy, connect to any server, or verify TLS certificates or live auth behavior. Secret values are never included; secrets are reported by key, line, and length only."
  }, null, 2);
}

/* ---------- UI wiring ---------- */
var lastResult = null;
var els = {};
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-ntfy-server-config-safety-auditor',
  name: 'J-Dawgs ntfy Server Config Safety Auditor',
  description: 'Grades a pasted ntfy server config offline into one deploy verdict: studied tools stop at whether the server starts — ours also grades allow-all auth, a plain-HTTP base-url, open signup, and unbounded caches, with secrets reported by key name, line, and length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
