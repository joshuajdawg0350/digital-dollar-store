'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Solr Search Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var RISKY_EXAMPLE = [
          '<!-- solrconfig.xml (excerpt) — no security.json was provided with this config -->',
          '<config>',
          '  <luceneMatchVersion>9.7</luceneMatchVersion>',
          '  <requestHandler name="/select" class="solr.SearchHandler">',
          '    <lst name="defaults">',
          '      <str name="echoParams">all</str>',
          '    </lst>',
          '  </requestHandler>',
          '  <requestHandler name="/update" class="solr.UpdateRequestHandler"/>',
          '  <requestHandler name="/update/extract" class="solr.extraction.ExtractingRequestHandler"/>',
          '  <requestHandler name="/admin/ping" class="solr.PingRequestHandler"/>',
          '</config>',
          '',
          '# solr.in.sh (excerpt)',
          'ENABLE_REMOTE_JMX_OPTS="true"',
          'SOLR_HOST="0.0.0.0"',
          'SOLR_AUTHENTICATION_OPTS="-Dbasicauth=solr:SolrRocks"',
          'SOLR_ADMIN_PASSWORD="changeme123"'
        ].join("\n");

        var HARDENED_EXAMPLE = [
          '{',
          '  "authentication": {',
          '    "blockUnknown": true,',
          '    "class": "solr.BasicAuthPlugin",',
          '    "credentials": {',
          '      "searchadmin": "IV0EHq1OnNrj6gvRCwvFwTrZ1+z1oBbn3diVC3otuq0= Nzg5NjU0ZjU0NmI="',
          '    },',
          '    "realm": "SearchRealm",',
          '    "forwardCredentials": false',
          '  },',
          '  "authorization": {',
          '    "class": "solr.RuleBasedAuthorizationPlugin",',
          '    "user-role": {',
          '      "searchadmin": "admin"',
          '    },',
          '    "permissions": [',
          '      { "name": "security-edit", "role": "admin" },',
          '      { "name": "collection-admin-edit", "role": "admin" },',
          '      { "name": "all", "role": "admin" }',
          '    ]',
          '  }',
          '}',
          '',
          '<!-- solrconfig.xml (excerpt) -->',
          '<config>',
          '  <luceneMatchVersion>9.7</luceneMatchVersion>',
          '  <requestHandler name="/select" class="solr.SearchHandler"/>',
          '  <requestHandler name="/update" class="solr.UpdateRequestHandler"/>',
          '</config>',
          '',
          '# solr.in.sh (excerpt)',
          'ENABLE_REMOTE_JMX_OPTS="false"',
          'SOLR_HOST="127.0.0.1"'
        ].join("\n");

        var KNOWN_ENV_KEYS = {
          SOLR_HOST: 1, SOLR_PORT: 1, SOLR_JETTY_HOST: 1, SOLR_JETTY_PORT: 1,
          SOLR_HOME: 1, SOLR_PID_DIR: 1, SOLR_LOGS_DIR: 1, SOLR_DATA_HOME: 1,
          SOLR_ULIMIT_CHECKS: 1, ENABLE_REMOTE_JMX_OPTS: 1, RMI_PORT: 1,
          SOLR_JAVA_MEM: 1, SOLR_JAVA_STACK_SIZE: 1, JAVA_HOME: 1, JAVA_OPTS: 1,
          ZK_HOST: 1, ZK_CLIENT_TIMEOUT: 1, SOLR_TIMEZONE: 1, SOLR_OPTS: 1,
          SOLR_AUTHENTICATION_OPTS: 1, SOLR_ADMIN_PASSWORD: 1, GC_LOG_OPTS: 1,
          GC_TUNE: 1, SOLR_SECURITY_MANAGER_ENABLED: 1, SOLR_MODULES: 1,
          LOG4J_FORMAT_MSG_NO_LOOKUPS: 1, SOLR_STOP_PORT: 1, SOLR_HEAP: 1,
          SOLR_BIN: 1, SOLR_INCLUDE: 1, SOLR_SSL_ENABLED: 1,
          SOLR_SSL_KEY_STORE: 1, SOLR_SSL_TRUST_STORE: 1, SOLR_SSL_KEY_STORE_PASSWORD: 1,
          SOLR_SSL_TRUST_STORE_PASSWORD: 1, JMXREMOTE_PORT: 1
        };

        var AUTH_PLUGINS = /(BasicAuthPlugin|PKIAuthenticationPlugin|JWTAuthPlugin|KerberosPlugin|HadoopAuthPlugin|MultiSchemeAuthPlugin)/;
        var AUTHZ_PLUGIN = /RuleBasedAuthorizationPlugin/;

        function escapeHtml(s) {
          return String(s).replace(/[&<>"']/g, function (c) {
            return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
          });
        }

        function stripQuotes(v) {
          v = v.replace(/^\s+|\s+$/g, "");
          if ((v.charAt(0) === '"' && v.charAt(v.length - 1) === '"') ||
              (v.charAt(0) === "'" && v.charAt(v.length - 1) === "'")) {
            v = v.slice(1, -1);
          }
          return v;
        }

        function lineRef(lines) {
          if (!lines || !lines.length) { return "whole paste"; }
          if (lines.length === 1) { return "line " + lines[0]; }
          return "lines " + lines.join(", ");
        }

        function auditConfig(text) {
          var rawLines = text.split(/\r\n|\r|\n/);
          var findings = [];
          function add(sev, title, lines, detail, fix) {
            findings.push({ sev: sev, title: title, lines: lines || [], detail: detail, fix: fix });
          }

          var hasAuthKey = false, authLine = 0;
          var hasAuthzKey = false, authzLine = 0;
          var hasPermissions = false;
          var blockUnknownFalseLine = 0;
          var credentialsLine = 0;
          var handlers = [];         // {name, line}
          var assignments = {};      // KEY -> [{line, value}]
          var assignmentOrder = [];
          var notParsed = [];
          var notAudited = [];        // {key, line}
          var jmxTrueLine = 0, jmxFalseLine = 0, rmiLine = 0;
          var solrMarkers = 0;

          for (var i = 0; i < rawLines.length; i++) {
            var n = i + 1;
            var line = rawLines[i];
            var t = line.replace(/^\s+|\s+$/g, "");
            if (t === "") { continue; }
            if (t.indexOf("<!--") === 0 || t.indexOf("-->") === 0 || t.charAt(0) === "#" ) {
              if (/luceneMatchVersion|requestHandler/.test(line)) { solrMarkers++; }
              continue;
            }

            var recognized = false;

            // --- security.json structure ---
            if (/"authentication"\s*:/.test(line)) { hasAuthKey = true; if (!authLine) { authLine = n; } recognized = true; solrMarkers++; }
            if (/"authorization"\s*:/.test(line)) { hasAuthzKey = true; if (!authzLine) { authzLine = n; } recognized = true; solrMarkers++; }
            if (AUTH_PLUGINS.test(line)) {
              hasAuthKey = true;
              if (!authLine) { authLine = n; }
              recognized = true; solrMarkers++;
            }
            if (AUTHZ_PLUGIN.test(line)) { hasAuthzKey = true; if (!authzLine) { authzLine = n; } recognized = true; solrMarkers++; }
            if (/"permissions"\s*:/.test(line)) { hasPermissions = true; recognized = true; }
            if (/"credentials"\s*:/.test(line)) { if (!credentialsLine) { credentialsLine = n; } recognized = true; }
            if (/"blockUnknown"\s*:\s*false/.test(line)) { blockUnknownFalseLine = n; recognized = true; }

            // --- default "solr" account as a credentials key ---
            if (/^\s*"solr"\s*:/.test(line)) {
              add("WARNING", 'Default-named "solr" account present in credentials', [n],
                'A credentials entry uses the well-known default account name "solr" (key name and line only — the value is never shown). Default-named admin accounts are the first thing an attacker tries.',
                'Rename the admin account to a non-default name, set a long unique password, and remove the "solr" account once the new one is verified.');
              recognized = true;
            }

            // --- password-bearing lines: key name + line only, value NEVER used ---
            var pwKey = null;
            var pwMatch = line.match(/"?([A-Za-z0-9_.-]*[Pp][Aa][Ss][Ss][Ww][Oo][Rr][Dd][A-Za-z0-9_.-]*)"?\s*[:=]/);
            if (pwMatch) { pwKey = pwMatch[1]; }
            if (pwKey && !/"credentials"\s*:/.test(line)) {
              add("WARNING", 'Password value present in config — key "' + pwKey + '"', [n],
                'A password value is set on this line under the key "' + pwKey + '". The value itself is deliberately not shown anywhere in this report. Plaintext passwords in config files leak through backups, repos, and screenshots.',
                'Move the secret out of the pasted/committed config into your secret store or environment, reference it indirectly, and rotate the password since it has now existed in plaintext.');
              recognized = true;
            }

            // --- default credential pair via basicauth= (e.g. SOLR_AUTHENTICATION_OPTS) ---
            if (/basicauth\s*=\s*"?solr\s*:/i.test(line)) {
              var keyCtx = "basicauth";
              var assignForCtx = line.match(/^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=/);
              if (assignForCtx) { keyCtx = assignForCtx[1]; }
              add("BLOCKER", 'Default "solr" admin credential referenced — key "' + keyCtx + '"', [n],
                'This line passes the well-known default "solr" admin credential (user name and key name only — the credential value is never shown). Anyone who knows Solr knows this default pair.',
                'Change the admin password from the default on the server, update or remove this credential reference, and prefer a named non-default admin account.');
              recognized = true;
            }

            // --- request handlers ---
            var hRe = /<requestHandler\b[^>]*\bname="([^"]+)"/g, hm;
            var foundHandler = false;
            while ((hm = hRe.exec(line)) !== null) {
              handlers.push({ name: hm[1], line: n });
              foundHandler = true;
            }
            if (foundHandler) { recognized = true; solrMarkers++; }

            // --- XML / JSON structural lines ---
            if (/^\s*<\/?[A-Za-z]/.test(line) || /^\s*[{}[\]],?$/.test(t) || /^\s*"[^"]+"\s*:/.test(line) || /^\s*\{[^}]*\},?$/.test(t)) {
              recognized = true;
              if (/luceneMatchVersion|<config|solrconfig/.test(line)) { solrMarkers++; }
            }

            // --- solr.in.sh-style assignments ---
            var am = line.match(/^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/);
            if (am) {
              recognized = true;
              var key = am[1], val = stripQuotes(am[2].replace(/\s+#.*$/, ""));
              if (!assignments[key]) { assignments[key] = []; assignmentOrder.push(key); }
              assignments[key].push({ line: n, value: val });
              if (KNOWN_ENV_KEYS[key]) { solrMarkers++; } else { notAudited.push({ key: key, line: n }); }

              if (key === "ENABLE_REMOTE_JMX_OPTS") {
                if (/^true$/i.test(val)) { jmxTrueLine = n; }
                if (/^false$/i.test(val)) { jmxFalseLine = n; }
              }
              if (key === "RMI_PORT") { rmiLine = n; }
              if ((key === "SOLR_HOST" || key === "SOLR_JETTY_HOST") && val === "0.0.0.0") {
                add("WARNING", key + " binds Solr to all network interfaces (0.0.0.0)", [n],
                  key + ' is set to 0.0.0.0, so Solr listens on every interface — including any public one. Combined with weak or missing authentication, the admin UI and every handler are reachable from the network.',
                  'Bind to a private interface or 127.0.0.1 and reach Solr through a firewall, VPN, or reverse proxy that enforces access control.');
              }
            }

            // --- raw JMX flags in any line shape ---
            if (/jmxremote\.authenticate\s*=\s*false/i.test(line)) {
              add("BLOCKER", "Remote JMX with authentication disabled (jmxremote.authenticate=false)", [n],
                "Unauthenticated remote JMX gives anyone who can reach the port deep control of the JVM — effectively remote code execution.",
                "Set jmxremote.authenticate=true with strong credentials, or disable remote JMX entirely if you do not actively use it.");
              recognized = true;
            }
            if (/com\.sun\.management\.jmxremote/.test(line)) { recognized = true; }

            if (!recognized) { notParsed.push(n); }
          }

          var hasAuth = hasAuthKey;
          var hasAuthz = hasAuthzKey;

          // --- authentication / authorization pairing ---
          if (solrMarkers > 0) {
            if (!hasAuth && !hasAuthz) {
              add("BLOCKER", "No authentication configured at all", [1],
                "This paste is presented as a Solr server config, but it contains no security.json authentication block and no authentication plugin. Solr ships with no authentication by default, so every request handler — including /update and the admin endpoints — is open to anyone who can reach the port.",
                "Add a security.json with an authentication plugin (for example solr.BasicAuthPlugin with blockUnknown set to true), restart or reload security, and verify an unauthenticated request is rejected before deploying.");
            } else if (hasAuth && !hasAuthz) {
              add("WARNING", "Authentication present, authorization missing", [authLine],
                "Users must log in, but no authorization plugin or rules were found. In Solr that means every authenticated user can do everything: edit security, administer collections, and delete indexes.",
                "Add an authorization block (for example solr.RuleBasedAuthorizationPlugin) with named permissions mapped to roles, and give day-to-day users only the roles they need.");
            } else if (!hasAuth && hasAuthz) {
              add("BLOCKER", "Authorization present, authentication missing", [authzLine],
                "Authorization rules were found, but no authentication is configured. With nobody proving an identity, requests arrive anonymous and the rules have nothing solid to attach to — the protection the rules describe is not actually enforced.",
                "Add an authentication block (for example solr.BasicAuthPlugin) alongside the authorization block so every request carries a verified identity the rules can act on.");
            } else {
              add("INFO", "Authentication and authorization are paired", [authLine, authzLine],
                "Both an authentication block and an authorization block are present, so requests carry a verified identity and rules can be enforced against it.",
                "No fix needed for pairing. Keep blockUnknown enabled and review the permission list whenever roles change.");
            }
          } else {
            add("INFO", "No recognizable Solr configuration markers found", [],
              "The paste contains no request handlers, security.json blocks, known solr.in.sh keys, or other Solr markers this auditor recognizes, so no server-config verdict logic was applied beyond line-shape checks.",
              "Paste an actual solrconfig.xml, security.json, or solr.in.sh excerpt to get a graded audit.");
          }

          if (hasAuthz && !hasPermissions) {
            add("WARNING", "Authorization configured but no permissions defined", [authzLine],
              "An authorization block exists, but no \"permissions\" list was found in the paste. Depending on defaults, that can leave collections governed by implicit rules nobody wrote down.",
              "Define explicit permissions (name + role pairs) in the authorization block for security-edit, collection admin, and data access, and re-audit.");
          }
          if (blockUnknownFalseLine) {
            add("WARNING", "blockUnknown is set to false", [blockUnknownFalseLine],
              "With blockUnknown false, requests without credentials are not automatically rejected at the authentication layer, which weakens the BasicAuth setup.",
              "Set \"blockUnknown\": true in the authentication block so unauthenticated requests are refused outright.");
          }
          if (credentialsLine) {
            add("INFO", "Credential hashes present in security.json (values never shown)", [credentialsLine],
              "A credentials block is present. This auditor notes its location only — it never reads, renders, or reports any credential value.",
              "No fix needed if the hashes belong to non-default accounts with strong passwords. Rotate any credential that has ever appeared in plaintext elsewhere.");
          }

          // --- remote JMX verdicts ---
          if (jmxTrueLine) {
            add("BLOCKER", "Remote JMX enabled (ENABLE_REMOTE_JMX_OPTS=true)", [jmxTrueLine],
              "Remote JMX exposes JVM management over the network. Solr's remote JMX path has historically run without strong authentication, and JMX access is effectively code execution inside the Solr process.",
              "Set ENABLE_REMOTE_JMX_OPTS=\"false\" unless you actively monitor through JMX; if you must keep it, restrict the RMI port by firewall to a management host and require JMX authentication.");
          } else if (jmxFalseLine) {
            add("INFO", "Remote JMX is disabled (ENABLE_REMOTE_JMX_OPTS=false)", [jmxFalseLine],
              "Remote JMX is explicitly turned off, so the JVM management surface is not exposed over the network.",
              "No fix needed. Leave it off unless a monitored, firewalled JMX setup is deliberately introduced.");
          }
          if (rmiLine && !jmxTrueLine) {
            add("WARNING", "RMI_PORT is set while remote JMX state needs confirming", [rmiLine],
              "An RMI port is configured. If remote JMX is enabled anywhere else (defaults file, startup flags), this port is the door it listens on.",
              "Confirm remote JMX is disabled, or firewall the RMI port to management hosts only.");
          }

          // --- request handler exposure ---
          if (handlers.length) {
            var hLines = handlers.map(function (h) { return h.line; });
            var hNames = handlers.map(function (h) { return h.name + " (line " + h.line + ")"; }).join(", ");
            var hasExtract = handlers.some(function (h) { return /extract/.test(h.name); });
            var hasUpdate = handlers.some(function (h) { return h.name.indexOf("/update") === 0; });
            var extra = "";
            if (hasUpdate) { extra += " /update accepts writes and deletes — exposed write access means index poisoning or total data loss."; }
            if (hasExtract) { extra += " The extraction (SolrCell) handler parses uploaded rich documents and has a long history of exploitation — it deserves the strictest protection."; }
            if (!hasAuth) {
              add("WARNING", "Request handlers exposed with no authentication in front of them", hLines,
                "Handlers found: " + hNames + ". No authentication is configured in this paste, so nothing stands between the network and these endpoints." + extra,
                "Put authentication (and authorization rules covering these paths) in front of Solr, or bind Solr to a private interface and proxy only the query paths your application needs.");
            } else {
              add("INFO", "Request handlers sit behind configured authentication", hLines,
                "Handlers found: " + hNames + ". Authentication is configured in this paste, so these endpoints are not anonymously reachable." + (hasExtract ? " Note: the extraction (SolrCell) handler parses uploaded documents — keep its permission restricted to admin roles." : ""),
                "No fix needed for exposure. Confirm the authorization permissions actually cover each handler path, especially /update and any extraction handler.");
            }
          }

          // --- duplicate / contradictory assignments ---
          assignmentOrder.forEach(function (k) {
            var occ = assignments[k];
            if (occ.length > 1) {
              var first = occ[0], last = occ[occ.length - 1];
              var allSame = occ.every(function (o) { return o.value === first.value; });
              var ls = occ.map(function (o) { return o.line; });
              if (allSame) {
                add("INFO", 'Setting "' + k + '" is repeated with the same value', ls,
                  '"' + k + '" is assigned the same value on lines ' + ls.join(" and ") + ". Harmless, but it invites drift the day someone edits only one copy.",
                  "Keep one assignment for " + k + " and delete the duplicate line(s): " + ls.slice(1).join(", ") + ".");
              } else {
                add("WARNING", 'Contradictory values for "' + k + '"', [first.line, last.line],
                  '"' + k + '" is set to "' + first.value + '" on line ' + first.line + ' but to "' + last.value + '" on line ' + last.line + ". Which value wins depends on include order — exactly the kind of ambiguity that survives review and bites in production.",
                  "Decide the intended value for " + k + ", keep it on one line, and remove the assignment on line " + (first.value === last.value ? last.line : first.line) + " (the stale one) so the config says one thing.");
              }
            }
          });

          // --- not audited / not parsed ---
          if (notAudited.length) {
            var naLines = notAudited.map(function (x) { return x.line; });
            var naKeys = notAudited.map(function (x) { return x.key + " (line " + x.line + ")"; }).join(", ");
            add("INFO", "Settings NOT AUDITED — keys this auditor does not grade", naLines,
              "These assignments use keys outside this auditor's rule set: " + naKeys + ". They were read as settings but deliberately not graded — no safety claim is made about them either way.",
              "Review these keys against the current Solr reference guide by hand, especially anything touching network binding, SSL, or authentication.");
          }
          if (notParsed.length) {
            add("INFO", "Lines NOT PARSED — the parser could not settle them", notParsed.slice(0, 40),
              "These lines match none of the shapes this auditor understands (XML element, JSON property, shell-style assignment, or comment): " + lineRef(notParsed.slice(0, 40)) + (notParsed.length > 40 ? " — and " + (notParsed.length - 40) + " more" : "") + ". They were not guessed at and no finding is based on them.",
              "Check these lines by hand. If they carry settings, re-paste them in standard solrconfig.xml, security.json, or KEY=value form and re-run the audit.");
          }

          var sevRank = { BLOCKER: 0, WARNING: 1, INFO: 2 };
          findings.sort(function (a, b) {
            if (sevRank[a.sev] !== sevRank[b.sev]) { return sevRank[a.sev] - sevRank[b.sev]; }
            var la = a.lines.length ? a.lines[0] : 0, lb = b.lines.length ? b.lines[0] : 0;
            return la - lb;
          });

          var nb = findings.filter(function (f) { return f.sev === "BLOCKER"; }).length;
          var nw = findings.filter(function (f) { return f.sev === "WARNING"; }).length;
          var ni = findings.filter(function (f) { return f.sev === "INFO"; }).length;
          var verdict = nb > 0 ? "DO NOT DEPLOY" : (nw > 0 ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY");
          return { verdict: verdict, findings: findings, counts: { b: nb, w: nw, i: ni } };
        }

        function buildReport(result) {
          var out = [];
          out.push("J-Dawgs Solr Search Server Config Safety Auditor\u2122 — audit report");
          out.push("Verdict: " + result.verdict);
          out.push("Findings: " + result.counts.b + " blocker(s), " + result.counts.w + " warning(s), " + result.counts.i + " info");
          out.push("Note: secret values are never printed — findings name the key and the line only.");
          out.push("");
          result.findings.forEach(function (f, idx) {
            out.push((idx + 1) + ". [" + f.sev + "] " + f.title + " — " + lineRef(f.lines));
            out.push("   " + f.detail);
            out.push("   Fix: " + f.fix);
            out.push("");
          });
          out.push("Heuristic text audit only — not a replacement for Solr's own startup checks.");
          return out.join("\n");
        }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-solr-search-server-config-safety-auditortm',
  name: 'J-Dawgs Solr Search Server Config Safety Auditor',
  description: 'Grades a pasted Solr config (solrconfig.xml / security.json / solr.in.sh) offline: missing auth, auth/authz pairing, default credentials and JMX exposure, secrets by key name and line only — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
