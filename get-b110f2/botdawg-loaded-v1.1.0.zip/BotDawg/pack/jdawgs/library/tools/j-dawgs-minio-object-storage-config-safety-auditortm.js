'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs MinIO Object Storage Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var RISKY_EXAMPLE = [
          "MINIO_ROOT_USER=minioadmin",
          "MINIO_ROOT_PASSWORD=minioadmin",
          "MINIO_SERVER_URL=http://storage.example.com",
          "MINIO_PROMETHEUS_AUTH_TYPE=public"
        ].join("\n");

        var HARDENED_EXAMPLE = [
          "# Hardened MinIO — example only; every value below is fake.",
          "MINIO_ROOT_USER=storage-admin-ops",
          "MINIO_ROOT_PASSWORD=example-only-fake-password-9f2kQ7zR",
          "MINIO_SERVER_URL=https://storage.example.com",
          "MINIO_BROWSER_REDIRECT_URL=https://storage.example.com",
          "MINIO_KMS_KES_ENDPOINT=https://kes.internal.example.com:7373",
          "MINIO_KMS_SECRET_KEY_NAME=minio-key-2026",
          "minio server /data --address 10.0.0.5:9000 --console-address 127.0.0.1:9001 --certs-dir /etc/minio/certs"
        ].join("\n");

        var input = document.getElementById("configInput");
        var results = document.getElementById("results");

        function stripQuotes(v) {
          v = v.replace(/^\s+|\s+$/g, "");
          if (v.length >= 2) {
            var first = v.charAt(0), last = v.charAt(v.length - 1);
            if ((first === '"' && last === '"') || (first === "'" && last === "'")) {
              v = v.slice(1, -1);
            }
          }
          return v;
        }

        function lineOfIndex(text, idx) {
          var n = 1, i;
          for (i = 0; i < idx && i < text.length; i++) {
            if (text.charAt(i) === "\n") n++;
          }
          return n;
        }

        function hostOf(addr) {
          // addr like ":9000", "0.0.0.0:9000", "127.0.0.1:9001", "[::1]:9000", "host:9000"
          var a = addr.replace(/^\s+|\s+$/g, "");
          if (a.charAt(0) === "[") {
            var close = a.indexOf("]");
            return close > 0 ? a.slice(1, close) : a;
          }
          var colon = a.lastIndexOf(":");
          if (colon >= 0) return a.slice(0, colon);
          return a;
        }

        function isLoopbackHost(host) {
          var h = (host || "").toLowerCase();
          return h === "localhost" || h === "127.0.0.1" || h === "::1" || h === "[::1]" || h === "0:0:0:0:0:0:0:1";
        }

        function urlHost(url) {
          var m = /^[a-z][a-z0-9+.-]*:\/\/([^\/:?#]+)/i.exec(url || "");
          return m ? m[1] : null;
        }

        function audit(text) {
          var lines = text.split(/\r\n|\r|\n/);
          var entries = {};        // KEY -> { value, line } (last value wins)
          var occurrences = {};    // KEY -> [lineNumbers]
          var notParsed = [];
          var flags = {};          // flagName -> { value, line } (last wins)
          var envCount = 0, structuralCount = 0, sawEnvFile = false, envFileLine = 0;

          function record(key, value, lineNo) {
            entries[key] = { value: value, line: lineNo };
            if (!occurrences[key]) occurrences[key] = [];
            occurrences[key].push(lineNo);
          }

          // --- command-line flags, scanned across the whole text so they are
          // found on minio server lines, ExecStart= lines, compose command:
          // lines, and list-item continuations alike.
          var flagRe = /--(address|console-address|certs-dir)[\s=]+(?:-\s*)?["']?([^\s"'\]]+)["']?/g;
          var fm;
          while ((fm = flagRe.exec(text)) !== null) {
            if (fm[2].indexOf("--") === 0) continue;
            flags[fm[1]] = { value: fm[2], line: lineOfIndex(text, fm.index) };
          }
          var certsDirBare = /--certs-dir\b/.test(text);

          // --- line-by-line parse
          var i, raw, t;
          for (i = 0; i < lines.length; i++) {
            var lineNo = i + 1;
            raw = lines[i];
            t = raw.replace(/^\s+|\s+$/g, "");
            if (t === "") continue;
            if (t.charAt(0) === "#" || t.charAt(0) === ";") continue;

            var parsed = false;
            var work = t;

            // compose list item:  - KEY=value
            if (work.indexOf("- ") === 0) work = work.slice(2).replace(/^\s+/, "");
            work = stripQuotes(work);
            // shell export prefix
            if (/^export\s+/.test(work)) work = work.replace(/^export\s+/, "");

            // systemd Environment=KEY=value (possibly quoted)
            var envM = /^Environment\s*=\s*(.+)$/.exec(work);
            if (envM) {
              var inner = stripQuotes(envM[1].replace(/^\s+|\s+$/g, ""));
              var kv = /^([A-Za-z_][A-Za-z0-9_.]*)\s*=\s*(.*)$/.exec(inner);
              if (kv) { record(kv[1], stripQuotes(kv[2]), lineNo); envCount++; }
              parsed = true;
            }
            // systemd EnvironmentFile= — values live in another file
            if (/^EnvironmentFile\s*=/.test(work)) { sawEnvFile = true; envFileLine = lineNo; parsed = true; }

            if (!parsed) {
              var kvEq = /^([A-Za-z_][A-Za-z0-9_.]*)\s*=\s*(.*)$/.exec(work);
              if (kvEq) {
                record(kvEq[1], stripQuotes(kvEq[2]), lineNo);
                if (/^[A-Z][A-Z0-9_]*$/.test(kvEq[1])) envCount++; else structuralCount++;
                parsed = true;
              }
            }
            if (!parsed) {
              // compose environment map style:  KEY: value  (all-caps keys only)
              var kvMap = /^([A-Z][A-Z0-9_]*)\s*:\s+(\S.*)$/.exec(work);
              if (kvMap) { record(kvMap[1], stripQuotes(kvMap[2]), lineNo); envCount++; parsed = true; }
            }
            if (!parsed && /^\[.*\]$/.test(work)) { structuralCount++; parsed = true; } // [Unit] / [Service]
            if (!parsed && /(^|\s)minio\s+server\b/.test(work)) { structuralCount++; parsed = true; }
            if (!parsed && /--(address|console-address|certs-dir)\b/.test(work)) { structuralCount++; parsed = true; }
            if (!parsed && /^\s*-\s*\S/.test(raw)) { structuralCount++; parsed = true; } // YAML list item (ports, volumes…)
            if (!parsed && /^[A-Za-z0-9_][A-Za-z0-9_.\/-]*\s*:\s*(.*)$/.test(work)) { structuralCount++; parsed = true; } // YAML key line

            if (!parsed) notParsed.push(lineNo);
          }

          // --- detected style
          var styles = [];
          var hasCompose = /(^|\n)\s*(services|environment|image|volumes|ports)\s*:/.test(text) || /docker-compose/i.test(text);
          var hasSystemd = /\[Service\]|\[Unit\]|Environment=|EnvironmentFile=|ExecStart=/.test(text);
          if (hasCompose) styles.push("docker-compose");
          if (hasSystemd) styles.push("systemd unit");
          if (envCount > 0 && !hasCompose && !hasSystemd) styles.push("environment variables");
          else if (envCount > 0) styles.push("environment variables");
          if (flags.address || flags["console-address"] || flags["certs-dir"] || certsDirBare) styles.push("command-line flags");
          if (styles.length === 0) styles.push("unrecognized");

          var findings = [];
          function add(sev, line, msg) { findings.push({ sev: sev, line: line, msg: msg }); }

          var rootUser = entries["MINIO_ROOT_USER"];
          var rootPass = entries["MINIO_ROOT_PASSWORD"];

          var credBlocker = false;
          if (rootUser && rootUser.value === "minioadmin") {
            add("BLOCKER", rootUser.line, "MINIO_ROOT_USER is set to the well-known default root user name. Anyone who knows MinIO knows this name — change it.");
            credBlocker = true;
          }
          if (rootPass) {
            if (rootPass.value === "minioadmin") {
              add("BLOCKER", rootPass.line, "MINIO_ROOT_PASSWORD is set to the well-known default root password. This is the first credential every scanner tries — change it before this server is reachable.");
              credBlocker = true;
            } else if (rootPass.value.length < 12) {
              add("BLOCKER", rootPass.line, "MINIO_ROOT_PASSWORD is only " + rootPass.value.length + " characters long. Root passwords under 12 characters are treated as a blocker — use 16 or more. (Length shown; the value itself is never displayed.)");
              credBlocker = true;
            } else if (rootPass.value.length <= 15) {
              add("WARNING", rootPass.line, "MINIO_ROOT_PASSWORD is " + rootPass.value.length + " characters long (12–15 range). It passes the minimum, but 16 or more characters is the safer bar for the root account. (Length shown; the value itself is never displayed.)");
            }
          }
          if (!rootUser && !rootPass) {
            add("INFO", null, "No root credentials (MINIO_ROOT_USER / MINIO_ROOT_PASSWORD) appear in the pasted text — NOT VERIFIED either way: they may be set somewhere the paste doesn't show.");
          }

          // legacy variable names
          var legacyUser = entries["MINIO_ACCESS_KEY"];
          if (legacyUser) {
            add("WARNING", legacyUser.line, "MINIO_ACCESS_KEY is a deprecated legacy name for the root user. Upgrade path: rename it to MINIO_ROOT_USER (value not shown).");
          }
          var legacySecret = entries["MINIO_SECRET_KEY"];
          if (legacySecret) {
            add("WARNING", legacySecret.line, "MINIO_SECRET_KEY is a deprecated legacy name for the root password. Upgrade path: rename it to MINIO_ROOT_PASSWORD (value not shown).");
          }

          // TLS configured?
          var tlsConfigured = !!(flags["certs-dir"] || certsDirBare);
          var tlsKeyLine = null;
          var key;
          for (key in entries) {
            if (Object.prototype.hasOwnProperty.call(entries, key) && key.indexOf("MINIO_TLS_") === 0) {
              tlsConfigured = true; tlsKeyLine = entries[key].line;
            }
          }

          // server exposure
          var addrFlag = flags.address;
          var exposed = false, addrDesc = "", addrLine = null;
          if (addrFlag) {
            var ah = hostOf(addrFlag.value);
            addrLine = addrFlag.line;
            if (ah === "" || ah === "0.0.0.0" || ah === "::" || ah === "*") {
              exposed = true; addrDesc = "bound to all interfaces (" + addrFlag.value + ")";
            } else if (!isLoopbackHost(ah)) {
              exposed = true; addrDesc = "bound to a non-loopback address (" + addrFlag.value + ")";
            } else {
              addrDesc = "bound to loopback only (" + addrFlag.value + ")";
            }
          } else {
            exposed = true;
            addrDesc = "no --address given, so MinIO's default :9000 applies — that binds all interfaces";
          }
          if (exposed && !tlsConfigured) {
            if (credBlocker) {
              add("BLOCKER", addrLine, "Plaintext exposure with weak root credentials: the server API is " + addrDesc + ", and no TLS certificates are configured (no --certs-dir, no MINIO_TLS_* settings). Escalated to BLOCKER because default or short root credentials are also present — credentials and traffic would cross the network in the clear, protected by a password that is already known or easily guessed.");
            } else {
              add("WARNING", addrLine, "Plaintext exposure: the server API is " + addrDesc + ", and no TLS certificates are configured (no --certs-dir, no MINIO_TLS_* settings). API traffic and credentials would cross the network unencrypted. Add TLS certificates or bind the server to loopback behind a TLS-terminating proxy.");
            }
          }

          // console
          var browserEntry = entries["MINIO_BROWSER"];
          var browserOff = browserEntry && browserEntry.value.replace(/\s+/g, "").toLowerCase() === "off";
          if (browserOff) {
            add("INFO", browserEntry.line, "MINIO_BROWSER=off — the web console is disabled in this configuration. Noted; no console exposure to grade.");
          }
          var consoleFlag = flags["console-address"];
          if (consoleFlag && !browserOff) {
            var ch = hostOf(consoleFlag.value);
            if (ch !== "" && !isLoopbackHost(ch) && !tlsConfigured) {
              add("WARNING", consoleFlag.line, "The web console is enabled on an external console address (" + consoleFlag.value + ") with no TLS certificates configured. The console login page — where the root credentials are typed — would be served over plaintext HTTP. Bind it to loopback, put it behind TLS, or disable it with MINIO_BROWSER=off.");
            } else if (isLoopbackHost(ch)) {
              add("INFO", consoleFlag.line, "Console address is bound to loopback (" + consoleFlag.value + ") — reachable only from the host itself.");
            }
          }

          // URL scheme checks
          ["MINIO_SERVER_URL", "MINIO_BROWSER_REDIRECT_URL"].forEach(function (k) {
            var e = entries[k];
            if (!e) return;
            if (/^http:\/\//i.test(e.value)) {
              var uh = urlHost(e.value);
              if (uh && !isLoopbackHost(uh)) {
                var what = k === "MINIO_SERVER_URL" ? "signed URLs" : "browser redirects";
                add("WARNING", e.line, k + " uses http:// for a non-localhost host (" + uh + "). " + (k === "MINIO_SERVER_URL" ? "Signed URLs" : "Redirects") + " and " + what + " traffic would travel over plaintext — switch it to https://.");
              }
            }
          });

          // KMS / encryption
          var kmsConfigured = !!(entries["MINIO_KMS_KES_ENDPOINT"] || entries["MINIO_KMS_SECRET_KEY_NAME"]);
          if (!kmsConfigured) {
            add("INFO", null, "Server-side encryption keys not configured in pasted text (no MINIO_KMS_KES_ENDPOINT, no MINIO_KMS_SECRET_KEY_NAME) — NOT VERIFIED either way: absence in the pasted text is not proof of absence in the deployment.");
          }

          // Prometheus public metrics
          var prom = entries["MINIO_PROMETHEUS_AUTH_TYPE"];
          if (prom && prom.value.replace(/\s+/g, "").toLowerCase() === "public") {
            add("WARNING", prom.line, "MINIO_PROMETHEUS_AUTH_TYPE=public — metrics publicly readable. Anyone who can reach the metrics endpoint can read server metrics without authenticating. Use authenticated metrics unless the endpoint is network-restricted.");
          }

          // duplicates
          for (key in occurrences) {
            if (Object.prototype.hasOwnProperty.call(occurrences, key) && occurrences[key].length > 1) {
              var occ = occurrences[key];
              add("WARNING", occ[occ.length - 1], "Duplicate key " + key + " appears on lines " + occ.join(" and ") + ". The last value wins (line " + occ[occ.length - 1] + ") — remove the earlier line so the effective value is the one you meant.");
            }
          }

          if (sawEnvFile) {
            add("INFO", envFileLine, "An EnvironmentFile is referenced (line " + envFileLine + "). Its contents are not in the pasted text, so any settings inside it are NOT AUDITED.");
          }

          var settingsFound = Object.keys(entries).length + Object.keys(flags).length + (certsDirBare ? 1 : 0);

          var sevRank = { BLOCKER: 0, WARNING: 1, INFO: 2 };
          findings.sort(function (a, b) {
            var r = sevRank[a.sev] - sevRank[b.sev];
            if (r !== 0) return r;
            var la = a.line === null ? 9999 : a.line;
            var lb = b.line === null ? 9999 : b.line;
            return la - lb;
          });

          var blockers = 0, warnings = 0, infos = 0;
          findings.forEach(function (f) {
            if (f.sev === "BLOCKER") blockers++;
            else if (f.sev === "WARNING") warnings++;
            else infos++;
          });

          var verdict = null;
          if (blockers > 0) verdict = "DO NOT DEPLOY";
          else if (warnings > 0) verdict = "DEPLOY WITH FIXES";
          else verdict = "SAFE TO DEPLOY";

          return {
            styles: styles,
            findings: findings,
            notParsed: notParsed,
            verdict: verdict,
            blockers: blockers,
            warnings: warnings,
            infos: infos,
            settingsFound: settingsFound
          };
        }

        function esc(s) {
          return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
        }

        function buildReport(r, styleLabel) {
          var out = [];
          out.push("J-Dawgs MinIO Object Storage Config Safety Auditor — audit report");
          out.push("Detected input style: " + styleLabel);
          out.push("Verdict: " + r.verdict);
          out.push("Counts: " + r.blockers + " blocker(s), " + r.warnings + " warning(s), " + r.infos + " info note(s), " + r.notParsed.length + " line(s) not parsed.");
          out.push("");
          out.push("Findings (line-numbered; secret values are never shown — keys and lines only):");
          if (r.findings.length === 0) out.push("  (none)");
          r.findings.forEach(function (f) {
            out.push("  [" + f.sev + "] " + (f.line !== null ? "Line " + f.line + " — " : "") + f.msg);
          });
          out.push("");
          if (r.notParsed.length > 0) {
            out.push("NOT PARSED lines (not recognized, never guessed): " + r.notParsed.join(", "));
          } else {
            out.push("NOT PARSED lines: none — every non-empty line was recognized.");
          }
          out.push("");
          out.push("Limits: heuristic text audit of pasted text only. Never connects to a server, never runs MinIO. Bucket policies and IAM users are NOT AUDITED.");
          return out.join("\n");
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-minio-object-storage-config-safety-auditortm',
  name: 'J-Dawgs MinIO Object Storage Config Safety Auditor',
  description: 'MinIO only exercises your configuration when the server starts on its host, and startup answers will-it-load; ours grades a pasted MinIO config anywhere — root credentials, TLS pairing, and console exposure included — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
