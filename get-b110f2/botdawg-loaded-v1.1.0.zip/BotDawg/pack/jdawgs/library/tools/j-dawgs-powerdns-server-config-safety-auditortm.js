'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs PowerDNS Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Worked examples ---------- */

      var RISKY = [
        "# recursor.conf - risky worked example. Paste your own config over this.",
        "local-address=0.0.0.0, ::",
        "local-port=53",
        "allow-from=0.0.0.0/0, ::/0",
        "webserver=yes",
        "webserver-address=0.0.0.0",
        "webserver-port=8082",
        "api-key=<demo-key-present-value-redacted>",
        "guardian=no",
        "chroot=",
        "dnssec=off",
        "allow-recursion=192.168.1.0/24",
        "local-port=5353",
        "frobnicate-mode=on"
      ].join("\n");

      var HARDENED = [
        "# pdns.conf - hardened authoritative worked example.",
        "launch=gsqlite3",
        "gsqlite3-database=/var/lib/powerdns/pdns.sqlite3",
        "gsqlite3-dnssec=yes",
        "local-address=203.0.113.10",
        "local-port=53",
        "daemon=yes",
        "guardian=yes",
        "chroot=/var/empty/pdns",
        "setuid=pdns",
        "setgid=pdns",
        "webserver=no",
        "api=no",
        "disable-axfr=yes",
        "allow-axfr-ips=192.0.2.53",
        "version-string=anonymous",
        "server-id=ns1.example.net",
        "loglevel=4"
      ].join("\n");

      /* ---------- Knowledge base ---------- */

      // Secret-bearing keys: their VALUES are never rendered anywhere.
      var SENSITIVE = {
        "api-key": true,
        "webserver-password": true,
        "tcp-control-secret": true,
        "gmysql-password": true,
        "gpgsql-password": true,
        "godbc-password": true
      };

      var AUTH_KEYS = {};
      ("launch,local-address,local-port,local-ipv6,daemon,guardian,chroot,setuid,setgid," +
       "version-string,server-id,webserver,webserver-address,webserver-port,webserver-password," +
       "webserver-allow-from,webserver-print-arguments,api,api-key,api-logfile,allow-axfr-ips," +
       "disable-axfr,master,slave,primary,secondary,also-notify,only-notify,forward-notify,notify," +
       "default-ttl,cache-ttl,negquery-cache-ttl,query-cache-ttl,soa-minimum-ttl,default-soa-name," +
       "default-soa-mail,dnsupdate,allow-dnsupdate-from,forward-dnsupdate,distributor-threads," +
       "receiver-threads,signing-threads,max-tcp-connections,max-tcp-connections-per-client," +
       "tcp-control-address,tcp-control-port,tcp-control-secret,tcp-control-range,carbon-server," +
       "carbon-ourname,carbon-instance,edns-subnet-processing,security-poll-suffix,rng,entropy-source," +
       "udp-truncation-threshold,any-to-tcp,overload-queue-length,max-queue-length,log-dns-details," +
       "log-dns-queries,logging-facility,loglevel,log-common-errors,config-dir,include-dir,module-dir," +
       "socket-dir,bind-config,bind-check-interval,bind-dnssec-db,gsqlite3-database,gsqlite3-dnssec," +
       "gsqlite3-pragmas,gmysql-host,gmysql-port,gmysql-dbname,gmysql-user,gmysql-password,gmysql-dnssec," +
       "gpgsql-host,gpgsql-port,gpgsql-dbname,gpgsql-user,gpgsql-password,gpgsql-dnssec," +
       "lua-prequery-script,allow-empty-zone3,default-ksk-algorithms,default-zsk-algorithms," +
       "direct-dnskey,experimental-json-interface,svc-param").split(",").forEach(function (k) { AUTH_KEYS[k] = true; });

      var REC_KEYS = {};
      ("local-address,local-port,daemon,quiet,guardian,chroot,setuid,setgid,version-string,server-id," +
       "allow-from,allow-from-file,allow-recursion,forward-zones,forward-zones-file,forward-zones-recurse," +
       "auth-zones,hint-file,dont-query,dnssec,trustanchorfile,negative-trustanchorfile,max-cache-entries," +
       "max-cache-ttl,max-negative-ttl,packetcache-ttl,packetcache-servfail-ttl,max-packetcache-entries," +
       "disable-packetcache,threads,stack-size,webserver,webserver-address,webserver-port,webserver-password," +
       "webserver-allow-from,webserver-print-arguments,api-key,log-common-errors,log-timestamp,disable-syslog," +
       "logfile,loglevel,trace,network-timeout,max-total-msec,query-local-address,query-local-address6," +
       "minimum-ttl-override,server-down-max-fails,server-down-throttle-time,ecs-ipv4-bits,ecs-ipv6-bits," +
       "edns-outgoing-bufsize,lowercase-outgoing,any-to-tcp,carbon-server,carbon-ourname,carbon-instance," +
       "export-etc-hosts,etc-hosts-file,serve-rfc1918,additional-processing,delegation-only," +
       "remotes-ringbuffer-entries,stats-ringbuffer-entries,non-local-bind,reuseport,tcp-fast-open-connect," +
       "tcp-fast-open-queue,udp-source-port-min,udp-source-port-max,rng,entropy-source,lua-config-file," +
       "lua-dns-script,lua-maintenance-script,snmp-agent,snmp-daemon,config-dir,socket-dir," +
       "edns-subnet-allow-list,gettag-needs-edns-options,xpf-allow-from").split(",").forEach(function (k) { REC_KEYS[k] = true; });

      var BACKEND_PREFIXES = ["gmysql-", "gsqlite3-", "gpgsql-", "godbc-", "bind-", "geoip-", "ldap-", "remote-", "pipe-", "tinydns-", "lmdb-", "lua-"];

      function isKnown(key, mode) {
        var set = mode === "recursor" ? REC_KEYS : AUTH_KEYS;
        if (set[key]) return true;
        for (var i = 0; i < BACKEND_PREFIXES.length; i++) {
          if (key.indexOf(BACKEND_PREFIXES[i]) === 0) return true;
        }
        return false;
      }

      var REC_SIGNALS = ["allow-from", "allow-recursion", "hint-file", "forward-zones", "forward-zones-file", "dont-query", "dnssec", "max-cache-entries", "packetcache-ttl", "serve-rfc1918", "etc-hosts-file", "trustanchorfile", "udp-source-port-min", "udp-source-port-max"];
      var AUTH_SIGNALS = ["launch", "allow-axfr-ips", "disable-axfr", "api", "dnsupdate", "allow-dnsupdate-from", "bind-config", "default-ttl", "cache-ttl", "master", "slave", "primary", "secondary"];

      /* ---------- Parsing ---------- */

      function parseConfig(text) {
        var lines = text.split(/\r?\n/);
        var entries = [];       // {key, value, line}
        var malformed = [];     // {line, }
        for (var i = 0; i < lines.length; i++) {
          var raw = lines[i];
          var lineNo = i + 1;
          var t = raw.trim();
          if (t === "") continue;
          if (t.charAt(0) === "#" || t.charAt(0) === ";") continue;
          var eq = t.indexOf("=");
          if (eq === -1) { malformed.push({ line: lineNo }); continue; }
          var key = t.slice(0, eq).trim().toLowerCase();
          var value = t.slice(eq + 1).trim();
          if (key === "") { malformed.push({ line: lineNo }); continue; }
          entries.push({ key: key, value: value, line: lineNo });
        }
        return { entries: entries, malformed: malformed, lineCount: lines.length };
      }

      function byKey(entries) {
        var map = {};
        entries.forEach(function (e) {
          if (!map[e.key]) map[e.key] = [];
          map[e.key].push(e);
        });
        return map;
      }
      function last(map, key) {
        var a = map[key];
        return a && a.length ? a[a.length - 1] : null;
      }
      function asBool(v) {
        var s = String(v).trim().toLowerCase();
        if (s === "yes" || s === "true" || s === "on" || s === "1") return true;
        if (s === "no" || s === "false" || s === "off" || s === "0") return false;
        return null;
      }
      function splitList(v) {
        return String(v).split(/[,\s]+/).filter(function (s) { return s.length > 0; });
      }

      /* ---------- Address / range arithmetic ---------- */

      function fmtInt(n) { return n.toLocaleString("en-US"); }

      // Returns {text} describing how many addresses a CIDR or bare IP covers, plus flags.
      function rangeInfo(tok) {
        var t = tok.trim();
        var slash = t.indexOf("/");
        var addr = slash === -1 ? t : t.slice(0, slash);
        var prefix = slash === -1 ? null : parseInt(t.slice(slash + 1), 10);
        if (addr.indexOf(":") !== -1) {
          // IPv6
          var p6 = prefix === null ? 128 : prefix;
          if (isNaN(p6) || p6 < 0 || p6 > 128) return { text: t + " (unparseable range)", open: false, broad: false, local: false, prefix: p6 };
          var exp = 128 - p6;
          var countText = exp <= 20 ? fmtInt(Math.pow(2, exp)) : "2^" + exp + " (about " + Math.pow(2, exp).toExponential(2).replace("e+", "×10^") + ")";
          var local6 = addr === "::1" || /^fe[89ab]/i.test(addr) || /^f[cd]/i.test(addr);
          return { text: t + " covers " + countText + " IPv6 addresses", open: p6 === 0, broad: p6 <= 32 && !local6, local: local6 || p6 === 128, prefix: p6 };
        }
        var parts = addr.split(".");
        if (parts.length !== 4) return { text: t + " (unparseable range)", open: false, broad: false, local: false, prefix: prefix };
        var nums = parts.map(function (x) { return parseInt(x, 10); });
        var p = prefix === null ? 32 : prefix;
        if (isNaN(p) || p < 0 || p > 32 || nums.some(function (n) { return isNaN(n) || n < 0 || n > 255; })) {
          return { text: t + " (unparseable range)", open: false, broad: false, local: false, prefix: p };
        }
        var count = Math.pow(2, 32 - p);
        var local = nums[0] === 10 || nums[0] === 127 ||
          (nums[0] === 172 && nums[1] >= 16 && nums[1] <= 31) ||
          (nums[0] === 192 && nums[1] === 168) ||
          (nums[0] === 169 && nums[1] === 254);
        return {
          text: t + " covers " + fmtInt(count) + " IPv4 address" + (count === 1 ? "" : "es"),
          open: p === 0, broad: p <= 16 && !local, local: local, prefix: p
        };
      }

      /* ---------- Detection ---------- */

      function detectMode(entries) {
        var map = byKey(entries);
        var recHits = [], authHits = [];
        REC_SIGNALS.forEach(function (k) {
          if (map[k]) recHits.push(k + " (line " + map[k][0].line + ")");
        });
        AUTH_SIGNALS.forEach(function (k) {
          if (map[k]) authHits.push(k + " (line " + map[k][0].line + ")");
        });
        entries.forEach(function (e) {
          if (e.key.indexOf("gmysql-") === 0 || e.key.indexOf("gsqlite3-") === 0 || e.key.indexOf("gpgsql-") === 0) {
            var tag = e.key + " (line " + e.line + ")";
            if (authHits.indexOf(tag) === -1) authHits.push(tag);
          }
        });
        var mode, why;
        if (recHits.length > authHits.length) {
          mode = "recursor";
          why = "recursor-only settings found: " + recHits.join(", ") + (authHits.length ? "; authoritative-only settings also present: " + authHits.join(", ") : "; no authoritative-only settings present");
        } else if (authHits.length > 0) {
          mode = "auth";
          why = "authoritative-only settings found: " + authHits.join(", ") + (recHits.length ? "; recursor-only settings also present: " + recHits.join(", ") : "; no recursor-only settings present");
        } else {
          mode = "auth";
          why = "no recursor-only or authoritative-only signature settings found, so the shared default (Authoritative) was assumed — pick Recursor above if this is a recursor.conf";
        }
        return { mode: mode, why: why, recHits: recHits, authHits: authHits };
      }

      /* ---------- Audit ---------- */

      function audit(text, selectedMode) {
        var parsed = parseConfig(text);
        var entries = parsed.entries;
        var map = byKey(entries);
        var det = detectMode(entries);
        var mode = selectedMode === "auto" ? det.mode : selectedMode;
        var modeName = mode === "recursor" ? "Recursor" : "Authoritative";
        var findings = [];
        function add(sev, line, key, title, detail, fix) {
          findings.push({ severity: sev, line: line, key: key, title: title, detail: detail, fix: fix });
        }

        /* Malformed lines */
        parsed.malformed.forEach(function (m) {
          add("WARNING", m.line, "(line " + m.line + ")", "Line is not in key=value form — NOT PARSED",
            "This line has no key=value pair, so the auditor skipped it and the daemon may reject or ignore it at startup.",
            "Rewrite the line as key=value, or comment it out with a leading #.");
        });

        /* Duplicate keys */
        Object.keys(map).forEach(function (key) {
          var occ = map[key];
          for (var i = 1; i < occ.length; i++) {
            add("WARNING", occ[i].line, key, "Duplicate setting: " + key + " is set " + occ.length + " times",
              "Also set at line " + occ[0].line + ". Only one value can take effect, and which one wins is easy to get wrong when the file is edited later.",
              "Delete the duplicate line(s) so exactly one " + key + " line remains — the one with the value you actually mean.");
          }
        });

        /* Unknown keys */
        entries.forEach(function (e) {
          if (SENSITIVE[e.key]) return; // known in both worlds
          if (!isKnown(e.key, mode)) {
            add("INFO", e.line, e.key, "Unknown setting for a " + modeName + " config — NOT PARSED",
              e.key + " is not a recognised " + modeName + " setting, so the auditor did not grade it. A misspelt security setting fails silently: the daemon ignores the line and runs without the protection you thought you set.",
              "Check the spelling against the PowerDNS " + modeName + " settings list, or remove the line if it belongs to the other server type.");
          }
        });

        /* Listen exposure */
        var la = last(map, "local-address");
        if (la) {
          var toks = splitList(la.value);
          var wide = toks.filter(function (t) { return t === "0.0.0.0" || t === "::" || t === "0.0.0.0/0" || t === "::/0"; });
          if (wide.length) {
            if (mode === "recursor") {
              add("WARNING", la.line, "local-address", "Recursor listens on every interface (" + wide.join(", ") + ")",
                "local-address binds the recursor to all IPv4 and/or IPv6 interfaces on this host. That is only safe when allow-from is locked down to your own networks — graded below.",
                "Bind specific addresses (for example the host's own IPs), or keep the wide bind only with a tight allow-from list.");
            } else {
              add("INFO", la.line, "local-address", "Authoritative server listens on every interface (" + wide.join(", ") + ")",
                "A public authoritative server answering the world is normal — the exposure that matters is recursion, zone transfers, and the API, which are graded separately below.",
                "No change needed for a public authoritative server; bind specific addresses if this host should only serve some interfaces.");
            }
          }
        } else {
          if (mode === "auth") {
            add("INFO", null, "local-address", "local-address is not set",
              "Without local-address, the Authoritative Server's compiled default binds all IPv4 interfaces (0.0.0.0).",
              "Set local-address explicitly so the bind is a decision, not a default.");
          } else {
            add("INFO", null, "local-address", "local-address is not set",
              "Without local-address, the Recursor's compiled default binds localhost only — safe, but worth stating explicitly.",
              "Set local-address to the exact addresses this recursor should answer on.");
          }
        }

        /* Recursion posture (recursor) */
        if (mode === "recursor") {
          var af = last(map, "allow-from");
          if (af) {
            splitList(af.value).forEach(function (tok) {
              var r = rangeInfo(tok);
              if (r.open) {
                add("BLOCKER", af.line, "allow-from", "Open recursion: " + tok + " lets the whole internet recurse through this server",
                  "Range math: " + r.text + ". An open recursor is an abuse magnet — it gets used for DNS amplification attacks and floods the host with strangers' queries.",
                  "Restrict allow-from to the networks you actually serve, e.g. allow-from=127.0.0.0/8, ::1, 192.168.0.0/16 — and never 0.0.0.0/0 or ::/0.");
              } else if (r.broad) {
                add("WARNING", af.line, "allow-from", "Very broad recursion range: " + tok,
                  "Range math: " + r.text + ". That is far wider than a home or office network — make sure every one of those addresses is a client you intend to serve.",
                  "Narrow allow-from to the exact subnets of your clients.");
              }
            });
          } else if (!map["allow-from-file"]) {
            add("INFO", null, "allow-from", "allow-from is not set",
              "The Recursor then falls back to its compiled default, which restricts recursion to localhost (127.0.0.0/8 and ::1) — safe, but implicit.",
              "Set allow-from explicitly to the networks this recursor serves, so the posture survives upgrades and edits.");
          }
          var ar = last(map, "allow-recursion");
          if (ar) {
            var arOpen = splitList(ar.value).some(function (tok) { return rangeInfo(tok).open; });
            if (arOpen) {
              add("BLOCKER", ar.line, "allow-recursion", "Open recursion via the legacy allow-recursion setting",
                "allow-recursion includes a /0 range — the whole internet can recurse through this server (see the allow-from finding for the range math).",
                "Remove allow-recursion and express the same intent, narrowed to your own networks, in allow-from.");
            } else {
              add("WARNING", ar.line, "allow-recursion", "Legacy allow-recursion setting is in use",
                "allow-recursion is the deprecated pre-4.0 way to control who may recurse; modern Recursors use allow-from. Range math for this value: " + splitList(ar.value).map(function (t) { return rangeInfo(t).text; }).join("; ") + ".",
                "Move this list into allow-from and delete the allow-recursion line.");
            }
          }
          /* Source-port arithmetic */
          var spMin = last(map, "udp-source-port-min"), spMax = last(map, "udp-source-port-max");
          if (spMin && spMax) {
            var lo = parseInt(spMin.value, 10), hi = parseInt(spMax.value, 10);
            if (!isNaN(lo) && !isNaN(hi) && hi >= lo) {
              var nPorts = hi - lo + 1;
              if (nPorts < 4096) {
                add("WARNING", spMax.line, "udp-source-port-max", "Narrow outgoing source-port range: " + fmtInt(nPorts) + " ports",
                  "Port math: " + hi + " − " + lo + " + 1 = " + fmtInt(nPorts) + " source ports. Fewer ports means less randomisation for attackers to guess when spoofing answers.",
                  "Widen udp-source-port-min / udp-source-port-max to a range of at least several thousand ports.");
              } else {
                add("INFO", spMax.line, "udp-source-port-max", "Outgoing source-port range: " + fmtInt(nPorts) + " ports",
                  "Port math: " + hi + " − " + lo + " + 1 = " + fmtInt(nPorts) + " source ports of query randomisation. That is a healthy range.",
                  "No change needed.");
              }
            }
          }
        }

        /* AXFR posture (authoritative) */
        if (mode === "auth") {
          var disAxfr = last(map, "disable-axfr");
          var disVal = disAxfr ? asBool(disAxfr.value) : null;
          var axfrIps = last(map, "allow-axfr-ips");
          var axfrOpen = false, axfrMath = "";
          if (axfrIps) {
            var infos = splitList(axfrIps.value).map(function (tok) {
              var r = rangeInfo(tok);
              if (r.open) axfrOpen = true;
              return r.text;
            });
            axfrMath = infos.join("; ");
          }
          if (axfrOpen) {
            add("BLOCKER", axfrIps.line, "allow-axfr-ips", "Zone transfers open to the entire internet",
              "allow-axfr-ips includes a /0 range. Range math: " + axfrMath + ". Anyone can download your full zones — every hostname you publish, including internal ones you thought were obscure.",
              "List only your secondary servers' IPs in allow-axfr-ips, or set disable-axfr=yes if you run no secondaries.");
          } else if (disVal === true) {
            /* AXFR fully disabled: clean. */
          } else if (disVal === false) {
            if (axfrIps) {
              add("INFO", disAxfr.line, "disable-axfr", "Zone transfers on, restricted to allow-axfr-ips",
                "disable-axfr=no with an allow-axfr-ips list. Range math: " + axfrMath + ". Transfers are limited to those addresses — the correct posture when you run secondaries.",
                "No change needed, as long as every listed address is really one of your secondaries.");
            } else {
              add("WARNING", disAxfr.line, "disable-axfr", "Zone transfers on with no allow-axfr-ips list",
                "disable-axfr=no and no allow-axfr-ips line, so who may pull a full zone copy rests on the compiled default instead of your decision.",
                "Set allow-axfr-ips to your secondaries' IPs only, or set disable-axfr=yes.");
            }
          } else {
            if (axfrIps) {
              add("INFO", axfrIps.line, "allow-axfr-ips", "Zone transfers restricted by allow-axfr-ips; disable-axfr not stated",
                "Range math: " + axfrMath + ". Transfers are limited to the listed addresses, but disable-axfr itself is left unstated.",
                "Optionally add disable-axfr=no explicitly next to the list so the intent is written down.");
            } else {
              add("WARNING", null, "disable-axfr", "AXFR posture is entirely implicit",
                "Neither disable-axfr nor allow-axfr-ips appears in this file, so zone-transfer exposure depends on compiled defaults that vary by version.",
                "Set disable-axfr=yes if you have no secondaries, or list your secondaries in allow-axfr-ips.");
            }
          }
        }

        /* Webserver + API posture, paired with the key */
        var ws = last(map, "webserver");
        var wsOn = ws ? asBool(ws.value) === true : false;
        var wsAddr = last(map, "webserver-address");
        var wsAddrWide = false;
        if (wsAddr) {
          wsAddrWide = splitList(wsAddr.value).some(function (t) { return t === "0.0.0.0" || t === "::"; });
        }
        var apiKey = last(map, "api-key");
        var apiKeySet = !!(apiKey && apiKey.value.length > 0);
        var apiEntry = last(map, "api");
        var apiOn = mode === "auth" ? (apiEntry ? asBool(apiEntry.value) === true : false)
                                     : (wsOn && apiKeySet); // recursor API rides on webserver + api-key

        if (wsOn) {
          if (wsAddrWide) {
            if (apiOn || apiKeySet) {
              add("BLOCKER", wsAddr.line, "webserver-address", "Webserver/API listens on every interface with an API key in play",
                "webserver-address binds the built-in webserver to all interfaces, and the HTTP API is enabled. Anyone who can reach this host can try the API — the only gate is the single static api-key named at line " + (apiKey ? apiKey.line : "—") + " (value never shown).",
                "Bind webserver-address to 127.0.0.1 (or a management-network IP), and put the API behind your firewall or a reverse proxy.");
            } else {
              add("WARNING", wsAddr.line, "webserver-address", "Webserver listens on every interface",
                "webserver-address binds the built-in webserver/stats pages to all interfaces on this host, reachable by anyone who can route to it.",
                "Set webserver-address=127.0.0.1 unless remote stats access is genuinely required.");
            }
          }
          if (mode === "recursor" && !last(map, "webserver-password")) {
            add("WARNING", ws.line, "webserver", "Webserver on, but no webserver-password is set",
              "The recursor's built-in web UI has no password gate when webserver-password is absent. (The auditor notes presence only — a password's value is never rendered.)",
              "Set a webserver-password, or turn the webserver off with webserver=no.");
          }
          if (mode === "auth" && !apiOn && !apiKeySet) {
            add("INFO", ws.line, "webserver", "Webserver on for statistics; HTTP API not enabled",
              "webserver=yes without api=yes serves status pages only — a smaller surface than the full API.",
              "No change needed if you use the stats pages; otherwise webserver=no removes the surface entirely.");
          }
        }

        if (mode === "auth" && apiEntry) {
          if (apiOn) {
            if (!wsOn) {
              add("WARNING", apiEntry.line, "api", "api=yes but the webserver is not enabled",
                "On the Authoritative Server the HTTP API rides on the built-in webserver, so with webserver off or absent this api=yes line will not actually start the API.",
                "Set webserver=yes if you intend to use the API — together with the api-key and bind fixes — or set api=no.");
            }
            if (apiKeySet) {
              add("WARNING", apiKey.line, "api-key", "API is on and its key sits in this file in plaintext",
                "The auditor confirms an api-key is present (key name and line only — the value is never rendered). Anyone who reads this config file owns your zones: the API can change records.",
                "Keep this file readable only by the service account, rotate the key if the file has ever been shared, and prefer managing the key via your config-management secrets store.");
            } else {
              add("BLOCKER", apiEntry.line, "api", "API enabled with no api-key — unauthenticated zone control",
                "api=yes with no api-key line anywhere in the file. The HTTP API would accept zone and record changes from anyone who can reach the webserver port.",
                "Set a long random api-key, or set api=no if you do not use the API.");
            }
          }
        }
        if (mode === "recursor" && apiKey) {
          if (wsOn && apiKeySet) {
            add("WARNING", apiKey.line, "api-key", "Recursor API is on (webserver + api-key) and the key sits in this file in plaintext",
              "On the Recursor, setting an api-key with webserver=yes enables the HTTP API. The auditor confirms the key is present (key name and line only — the value is never rendered).",
              "Keep this file readable only by the service account, bind webserver-address to localhost or a management network, and rotate the key if the file has ever been shared.");
          } else if (apiKeySet && !wsOn) {
            add("INFO", apiKey.line, "api-key", "api-key is set but the webserver is off, so the API is not reachable",
              "Presence noted only — the value is never rendered. The key takes effect the moment webserver=yes is set.",
              "No change needed; remember the key is live as soon as the webserver is enabled.");
          }
        }

        /* Privilege containment */
        var guardian = last(map, "guardian");
        if (!guardian) {
          add("WARNING", null, "guardian", "guardian is not set",
            "Without guardian=yes, the daemon does not run under a supervising guardian process that restarts it and keeps it contained after a crash or compromise.",
            "Set guardian=yes.");
        } else if (asBool(guardian.value) === false) {
          add("WARNING", guardian.line, "guardian", "guardian is explicitly off",
            "guardian=no disables the supervising guardian process that watches the daemon and restarts it if it dies or is killed.",
            "Set guardian=yes.");
        }
        var chrootE = last(map, "chroot");
        if (!chrootE) {
          add("WARNING", null, "chroot", "chroot is not set",
            "The daemon is not jailed into a chroot directory, so a compromised process can read the whole filesystem its account can reach.",
            "Set chroot to a prepared jail directory (for example chroot=/var/empty/pdns) and test startup inside it.");
        } else if (chrootE.value.trim() === "") {
          add("WARNING", chrootE.line, "chroot", "chroot line is present but empty",
            "An empty chroot value means no jail is applied, even though the line makes the config look contained.",
            "Give chroot a real prepared jail directory, or remove the line so the gap is honest.");
        }
        var su = last(map, "setuid"), sg = last(map, "setgid");
        var missingPriv = [];
        if (!su || su.value.trim() === "") missingPriv.push("setuid");
        if (!sg || sg.value.trim() === "") missingPriv.push("setgid");
        if (missingPriv.length) {
          var anchor = (su && su.line) || (sg && sg.line) || null;
          add("WARNING", anchor, missingPriv.join(" + "), "Privilege drop incomplete: " + missingPriv.join(" and ") + " not set",
            "Without setuid/setgid the daemon keeps running as the user that started it — often root — instead of dropping to a dedicated unprivileged account.",
            "Create a dedicated pdns user/group and set both setuid and setgid to it.");
        }

        /* Version-string exposure */
        var vs = last(map, "version-string");
        if (vs) {
          var v = vs.value.trim().toLowerCase();
          if (v === "full" || v.indexOf("powerdns") !== -1 && v !== "powerdns") {
            add("WARNING", vs.line, "version-string", "Full version string is disclosed to anyone who asks",
              "version-string makes the server answer version queries with its exact build — free reconnaissance for matching exploits to your version.",
              "Set version-string=anonymous (or powerdns) so version queries reveal nothing useful.");
          } else if (v !== "anonymous" && v !== "powerdns" && v !== "") {
            add("INFO", vs.line, "version-string", "Custom version-string is set",
              "A custom string is answered to version queries. Make sure it does not itself disclose the real version or build.",
              "Prefer version-string=anonymous.");
          }
        } else if (mode === "auth") {
          add("WARNING", null, "version-string", "version-string is not set — default discloses the full version",
            "The Authoritative Server's default answers version queries with the full PowerDNS version string, advertising exactly which build you run.",
            "Set version-string=anonymous.");
        } else {
          add("INFO", null, "version-string", "version-string is not set",
            "Unset, the server answers version queries with its standard string. Setting it to anonymous trims that disclosure.",
            "Optionally set version-string=anonymous.");
        }

        /* DNSSEC — graded as posture only */
        if (mode === "recursor") {
          var ds = last(map, "dnssec");
          if (!ds) {
            add("INFO", null, "dnssec", "dnssec setting is not stated (posture grade only)",
              "With no dnssec line, validation posture depends on the compiled default, which differs across versions. This auditor grades the posture written in the file — it cannot test live validation, because it never queries DNS.",
              "Set dnssec=validate explicitly so the posture is a decision, not a default.");
          } else {
            var dv = ds.value.trim().toLowerCase();
            if (dv === "off") {
              add("WARNING", ds.line, "dnssec", "DNSSEC validation is switched off (posture grade)",
                "dnssec=off means clients of this recursor receive answers with no cryptographic validation — spoofed answers are accepted. Posture grade only: this tool cannot test live validation, because it never queries DNS.",
                "Set dnssec=validate so forged answers are rejected, and keep a current trust anchor file.");
            } else if (dv === "process-no-validate" || dv === "process") {
              add("INFO", ds.line, "dnssec", "DNSSEC posture: " + dv + " (processed, not enforced)",
                "The recursor processes DNSSEC records but clients are not protected by validation failures. Posture grade only — live validation cannot be tested from a config file.",
                "Move to dnssec=validate once your trust anchors are current.");
            } else if (dv === "validate" || dv === "log-fail") {
              add("INFO", ds.line, "dnssec", "DNSSEC posture: " + dv,
                "Validation is switched on in the file. Posture grade only: whether validation actually succeeds depends on trust anchors and live data this tool never sees.",
                "No change needed; keep trustanchorfile current.");
            } else {
              add("WARNING", ds.line, "dnssec", "Unrecognised dnssec value",
                "The dnssec value on this line is not one of off / process-no-validate / process / validate / log-fail, so the intended validation posture is unclear.",
                "Set dnssec to a recognised value — validate is the recommended posture.");
            }
          }
        } else {
          var beDnssec = entries.filter(function (e) { return /dnssec$/.test(e.key) && e.key !== "dnssec"; });
          var flag = beDnssec.length ? beDnssec[beDnssec.length - 1] : null;
          add("INFO", flag ? flag.line : null, "dnssec",
            flag ? "Backend DNSSEC flag is on — posture only" : "No DNSSEC statement in this file — posture only",
            "On the Authoritative Server, DNSSEC is per-zone data held in the backend" + (flag ? " (" + flag.key + "=yes noted at line " + flag.line + ")" : "") + ", so a config file cannot prove any zone is actually signed. This finding is an honesty note, not a pass: verify signing in the backend and with a resolver you trust.",
            "Check each production zone's DNSSEC status in the backend (for example with pdnsutil) — this auditor cannot verify zone data.");
        }

        /* Sort: BLOCKER, WARNING, INFO; then line (absent last); then key */
        var rank = { BLOCKER: 0, WARNING: 1, INFO: 2 };
        findings.sort(function (a, b) {
          if (rank[a.severity] !== rank[b.severity]) return rank[a.severity] - rank[b.severity];
          var la2 = a.line === null ? 1e9 : a.line, lb2 = b.line === null ? 1e9 : b.line;
          if (la2 !== lb2) return la2 - lb2;
          return a.key < b.key ? -1 : 1;
        });

        var counts = { BLOCKER: 0, WARNING: 0, INFO: 0 };
        findings.forEach(function (f) { counts[f.severity]++; });
        var verdict = counts.BLOCKER > 0 ? "DO NOT DEPLOY" : (counts.WARNING > 0 ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY");

        var detText;
        if (selectedMode === "auto") {
          detText = "Detected: " + modeName + " — " + det.why + ".";
        } else {
          detText = "Server type set by you: " + modeName + ". (Auto-detect on these settings would have said: " + (det.mode === "recursor" ? "Recursor" : "Authoritative") + " — " + det.why + ".)";
        }

        return {
          mode: mode, modeName: modeName, detection: detText,
          verdict: verdict, counts: counts, findings: findings,
          lineCount: parsed.lineCount, settingCount: entries.length
        };
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-powerdns-server-config-safety-auditortm',
  name: 'J-Dawgs PowerDNS Server Config Safety Auditor',
  description: 'Grades a pasted pdns.conf or recursor.conf offline — open recursion, API/webserver posture, AXFR — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
