'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Beszel Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

/* ---------- Worked examples (line numbers are part of the test fixtures) ---------- */
var RISKY_LINES = [
  '# Risky example — for testing only, do not deploy',   /* line 1 */
  'services:',                                            /* line 2 */
  '  beszel:',                                            /* line 3 */
  '    image: henrygd/beszel:latest',                     /* line 4 */
  '    container_name: beszel',                           /* line 5 */
  '    ports:',                                           /* line 6 */
  '      - "0.0.0.0:8090:8090"',                          /* line 7 */
  '    environment:',                                     /* line 8 */
  '      APP_URL: "http://203.0.113.10:8090"',            /* line 9 */
  '      DISABLE_PASSWORD_AUTH: "true"',                  /* line 10 */
  '      TOKEN: "abc123"',                                /* line 11 */
  '      KEY: "changeme"',                                /* line 12 */
  '      HUB_URL: "http://beszel-hub:8090"',              /* line 13 */
  '      PASSWORD: "P@ssw0rdPlantedSecret99!"',           /* line 14 */
  '      SMTP_PASSWORD: "smtp-planted-secret-12345"',     /* line 15 */
  '    volumes:',                                         /* line 16 */
  '      - ./beszel_data:/beszel_data'                    /* line 17 */
];
var RISKY = RISKY_LINES.join('\n');
var PLANTED_SECRET = 'P@ssw0rdPlantedSecret99!';

var HARDENED_LINES = [
  '# Hardened example',
  'services:',
  '  beszel:',
  '    image: henrygd/beszel',
  '    container_name: beszel',
  '    ports:',
  '      - "127.0.0.1:8090:8090"',
  '    environment:',
  '      APP_URL: "https://beszel.example.com"',
  '      DISABLE_PASSWORD_AUTH: "false"',
  '      TOKEN_FILE: "/run/secrets/beszel_token"',
  '      KEY_FILE: "/run/secrets/beszel_key"',
  '      HUB_URL: "https://beszel.example.com"',
  '    volumes:',
  '      - ./beszel_data:/beszel_data'
];
var HARDENED = HARDENED_LINES.join('\n');

/* ---------- Auditor ---------- */
var EXAMPLE_WORDS = ['changeme','change-me','example','password','passwd','secret','letmein','hunter2','test1234','demo','default','abc123','token123','your-token','your_token','placeholder','xxx','todo'];
var SECRET_HINTS = ['TOKEN','SECRET','PASSWORD','PASSWD','API_KEY','APIKEY','PRIVATE_KEY','ACCESS_KEY'];

function isSecretKey(key){
  if(!key) return false;
  var k = key.toUpperCase();
  if(k === 'KEY') return true;
  for(var i=0;i<SECRET_HINTS.length;i++){ if(k.indexOf(SECRET_HINTS[i]) !== -1) return true; }
  return false;
}
function stripQuotes(v){
  v = (v || '').trim();
  if(v.length >= 2 && ((v.charAt(0)==='"' && v.charAt(v.length-1)==='"') || (v.charAt(0)==="'" && v.charAt(v.length-1)==="'"))){
    v = v.slice(1,-1);
  }
  return v.trim();
}
function isTruthy(v){
  var s = (v||'').toLowerCase();
  return s==='true' || s==='1' || s==='yes' || s==='on';
}

function auditConfig(text){
  var findings = [];
  function add(sev, line, rule, key, len, msg, fix){
    findings.push({severity:sev, line:line, rule:rule, key:key||null, valueLength:(typeof len==='number'?len:null), message:msg, fix:fix});
  }
  var raw = (text === null || text === undefined) ? '' : String(text);
  var lines = raw.split('\n');
  var signals = 0;
  var lowerAll = raw.toLowerCase();
  if(lowerAll.indexOf('beszel') !== -1) signals += 2;
  var hasTLS = lowerAll.indexOf('https://') !== -1 || lowerAll.indexOf('tls') !== -1 ||
               lowerAll.indexOf('traefik') !== -1 || lowerAll.indexOf('caddy') !== -1 ||
               lowerAll.indexOf('nginx') !== -1 || lowerAll.indexOf('reverse proxy') !== -1 ||
               lowerAll.indexOf('reverse_proxy') !== -1;
  var bindAllLines = [];

  for(var i=0;i<lines.length;i++){
    var lineNo = i+1;
    var rawLine = lines[i];
    var line = rawLine.trim();
    if(line === '' || line.charAt(0) === '#') continue;

    /* --- listener / port bindings (checked on every line) --- */
    if(line.indexOf('0.0.0.0') !== -1){
      signals++;
      bindAllLines.push(lineNo);
      add('HIGH', lineNo, 'bind-all-interfaces', null, null,
        'Listener is bound to 0.0.0.0 — every network interface, not just this machine.',
        'Bind to 127.0.0.1 and reach the hub through a TLS reverse proxy, or restrict the port with a firewall.');
    } else {
      var portMatch = line.match(/["']?(\d{2,5}):(\d{2,5})["']?/);
      if(portMatch && line.indexOf('127.0.0.1') === -1 && line.indexOf('localhost') === -1 && /ports|^-/.test(line) || (portMatch && line.charAt(0)==='-' && line.indexOf('127.0.0.1') === -1 && line.indexOf('localhost') === -1 && line.indexOf('0.0.0.0') === -1)){
        signals++;
        bindAllLines.push(lineNo);
        add('HIGH', lineNo, 'bind-implicit-all-interfaces', null, null,
          'Port mapping has no host address, so it binds every interface by default.',
          'Prefix the mapping with 127.0.0.1 (for example 127.0.0.1:8090:8090) unless public exposure is intended and protected.');
      }
    }
    if(/network_mode\s*[:=]\s*["']?host/.test(line)){
      add('HIGH', lineNo, 'host-network-mode', null, null,
        'Host network mode removes the container network boundary for this service.',
        'Use an explicit port mapping instead of host networking.');
    }
    if(/privileged\s*[:=]\s*["']?true/.test(line)){
      add('HIGH', lineNo, 'privileged-container', null, null,
        'Container runs privileged, which removes most isolation from the host.',
        'Remove privileged mode and grant only the specific capabilities the agent needs.');
    }
    if(line.indexOf('/var/run/docker.sock') !== -1){
      add('HIGH', lineNo, 'docker-socket-mount', null, null,
        'The Docker socket is mounted, which gives the container effective root control of the host.',
        'Avoid mounting the Docker socket; if metrics require it, use a read-only socket proxy.');
    }

    /* --- key / value extraction --- */
    var key = null, value = null;
    var kv = line.match(/^-?\s*([A-Za-z_][A-Za-z0-9_-]*)\s*[:=]\s*(.*)$/);
    if(kv){ key = kv[1]; value = stripQuotes(kv[2]); }
    var flag = line.match(/--([a-z0-9-]+)(?:=|\s+)("[^"]*"|'[^']*'|\S+)/i);
    if(flag && !kv){ key = flag[1].replace(/-/g,'_').toUpperCase(); value = stripQuotes(flag[2]); }
    if(!key) continue;

    var keyUp = key.toUpperCase();
    if(['APP_URL','HUB_URL','TOKEN','KEY','DISABLE_PASSWORD_AUTH','ENVIRONMENT','PORTS','SERVICES','IMAGE','LISTEN','HOST','SHARED_SECRET'].indexOf(keyUp) !== -1) signals++;
    if(keyUp.indexOf('BESZEL') !== -1) signals++;

    /* --- safe references: never flagged --- */
    if(keyUp.slice(-5) === '_FILE') continue;
    if(value !== null && value.indexOf('${') !== -1) continue;

    /* --- disabled authentication --- */
    if((keyUp.indexOf('DISABLE') !== -1 && (keyUp.indexOf('AUTH') !== -1 || keyUp.indexOf('PASSWORD') !== -1)) ||
       keyUp === 'AUTH_DISABLED' || keyUp === 'NO_AUTH'){
      if(isTruthy(value)){
        add('CRITICAL', lineNo, 'auth-disabled', key, null,
          'Authentication is disabled by ' + key + '. Anyone who can reach the hub or agent can use it without signing in.',
          'Remove this setting or set it to false, and keep password (or SSO) authentication enabled.');
      }
      continue;
    }

    /* --- URL scheme --- */
    if(value && (keyUp.indexOf('URL') !== -1 || keyUp === 'APP_URL')){
      if(value.indexOf('http://') === 0){
        var local = value.indexOf('http://localhost') === 0 || value.indexOf('http://127.0.0.1') === 0;
        if(local){
          add('WARNING', lineNo, 'http-local-url', key, null,
            key + ' uses plain http on a local address. Fine on this machine only; it must not be the address other hosts use.',
            'Use the https address for anything reachable beyond this machine.');
        } else {
          add('CRITICAL', lineNo, 'http-url', key, null,
            key + ' uses plain http. Tokens and credentials cross the network unencrypted and can be read or altered in transit.',
            'Serve the hub over https (directly or through a reverse proxy) and update ' + key + ' to the https address.');
        }
      }
      continue;
    }
    if(value && value.indexOf('http://') === 0 && keyUp.indexOf('URL') === -1){
      add('HIGH', lineNo, 'http-value', key, null,
        key + ' points at a plain http address, so traffic to it is unencrypted.',
        'Switch this address to https.');
    }

    /* --- listen host key --- */
    if((keyUp === 'HOST' || keyUp === 'LISTEN' || keyUp === 'ADDRESS' || keyUp === 'BIND') && value === '0.0.0.0'){
      bindAllLines.push(lineNo);
      add('HIGH', lineNo, 'bind-all-interfaces', key, null,
        key + ' is set to 0.0.0.0, exposing the listener on every interface.',
        'Bind to 127.0.0.1 unless public exposure is intended and protected by TLS and authentication.');
      continue;
    }

    /* --- secrets: key name, line, length ONLY --- */
    if(isSecretKey(key)){
      if(value === '' || value === null){
        add('WARNING', lineNo, 'secret-empty', key, 0,
          key + ' is present but empty (length 0). The hub or agent may fall back to a default or refuse to authenticate.',
          'Set a long, random value through a secret file or an injected environment variable.');
      } else {
        var low = value.toLowerCase();
        var isExample = false;
        for(var e=0;e<EXAMPLE_WORDS.length;e++){ if(low === EXAMPLE_WORDS[e] || low.indexOf(EXAMPLE_WORDS[e]) !== -1){ isExample = true; break; } }
        if(value.length < 16){
          add('CRITICAL', lineNo, 'secret-too-short', key, value.length,
            key + ' is only ' + value.length + ' characters long. Short tokens and secrets are guessable and are often shared example values.',
            'Generate a fresh random secret of at least 32 characters, unique to this deployment, and deliver it via a secret file.');
        } else if(isExample){
          add('CRITICAL', lineNo, 'secret-example-value', key, value.length,
            key + ' (length ' + value.length + ') matches a known example or placeholder pattern. Example secrets are public knowledge.',
            'Replace it with a fresh random secret of at least 32 characters, delivered via a secret file.');
        } else {
          add('CRITICAL', lineNo, 'secret-plaintext', key, value.length,
            key + ' is stored as plaintext in this config (length ' + value.length + '). Anyone who can read the file, the repo, or a backup has the credential.',
            'Move it out of the config text: use the matching _FILE key pointing at a secret file, or a ${...} reference to an injected variable.');
        }
      }
      continue;
    }

    /* --- unpinned image --- */
    if(keyUp === 'IMAGE' && value && value.indexOf(':latest') !== -1){
      add('WARNING', lineNo, 'image-latest-tag', key, null,
        'Image uses the latest tag, so a redeploy can silently pull different code than the config was audited against.',
        'Pin the image to a specific version tag.');
    }
  }

  /* --- exposed listener with no TLS / reverse-proxy posture anywhere --- */
  if(bindAllLines.length && !hasTLS){
    add('CRITICAL', bindAllLines[0], 'exposed-no-tls', null, null,
      'A listener is exposed on all interfaces and nothing in this config provides TLS or a reverse proxy — no https address, no TLS setting, no proxy service. The exposed listener is unencrypted.',
      'Put the hub behind an https reverse proxy (or enable TLS) before exposing any port beyond localhost.');
  }

  findings.sort(function(a,b){ return a.line - b.line; });

  var counts = {CRITICAL:0, HIGH:0, WARNING:0, INFO:0};
  findings.forEach(function(f){ counts[f.severity]++; });

  var verdict;
  if(signals < 2 && findings.length === 0){
    verdict = 'NOT ENOUGH TO GRADE';
    findings.push({severity:'INFO', line:0, rule:'not-enough-content', key:null, valueLength:null,
      message:'No recognizable Beszel hub or agent configuration was found in the pasted text, so there is nothing to grade.',
      fix:'Paste the hub or agent environment, flags, or docker-compose service definition and audit again.'});
    counts.INFO++;
  } else if(counts.CRITICAL > 0){
    verdict = 'DO NOT DEPLOY';
  } else if(counts.HIGH > 0 || counts.WARNING > 0){
    verdict = 'DEPLOY WITH FIXES';
  } else {
    verdict = 'SAFE TO DEPLOY';
  }
  return {verdict:verdict, findings:findings, counts:counts, linesChecked:lines.length, signals:signals};
}

function buildReport(result){
  var out = [];
  out.push('J-Dawgs Beszel Server Config Safety Auditor — text report');
  out.push('Verdict: ' + result.verdict);
  out.push('Lines checked: ' + result.linesChecked);
  out.push('Findings: ' + result.findings.length + ' (Critical ' + result.counts.CRITICAL + ', High ' + result.counts.HIGH + ', Warning ' + result.counts.WARNING + ', Info ' + result.counts.INFO + ')');
  out.push('Secrets are reported by key name, line, and length only. No secret values and no config text are included.');
  out.push('---');
  if(result.findings.length === 0){
    out.push('No findings.');
  }
  result.findings.forEach(function(f){
    var loc = f.line > 0 ? ('Line ' + f.line) : 'Whole input';
    var keyPart = f.key ? (' [' + f.key + (typeof f.valueLength === 'number' ? ', length ' + f.valueLength : '') + ']') : '';
    out.push('[' + f.severity + '] ' + loc + keyPart + ' (' + f.rule + ') ' + f.message);
    out.push('  Fix: ' + f.fix);
  });
  return out.join('\n');
}
function buildJSON(result){
  return JSON.stringify({
    tool:'J-Dawgs Beszel Server Config Safety Auditor',
    verdict:result.verdict,
    linesChecked:result.linesChecked,
    counts:result.counts,
    findings:result.findings.map(function(f){
      return {severity:f.severity, line:f.line, rule:f.rule, key:f.key, valueLength:f.valueLength, message:f.message, fix:f.fix};
    })
  }, null, 2);
}
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_WORDS": (typeof EXAMPLE_WORDS !== 'undefined' ? EXAMPLE_WORDS : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-beszel-server-config-safety-auditortm',
  name: 'J-Dawgs Beszel Server Config Safety Auditor',
  description: 'Host tools only tell you the server started; ours grades a pasted Beszel hub/agent config offline into one deploy verdict — secrets by key name/line/length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_WORDS": __core["EXAMPLE_WORDS"] }
};
