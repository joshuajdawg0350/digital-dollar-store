'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Caddy Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var RISKY = [
        "{",
        "\tadmin 0.0.0.0:2019",
        "\tdebug",
        "\tauto_https disable_redirects",
        "}",
        "",
        "http://files.example.com {",
        "\troot * /etc/ssl",
        "\tfile_server browse",
        "\treverse_proxy http://localhost:9000",
        "\ttls internal",
        "\ttls {",
        "\t\tprotocols tls1.0 tls1.2 tls1.3",
        "\t}",
        "\tbasic_auth {",
        "\t\toperator JDJiJDE0JGV4YW1wbGU",
        "\t}",
        "}"
      ].join("\n");

      var HARDENED = [
        "{",
        "\tadmin off",
        "}",
        "",
        "example.com {",
        "\troot * /srv/www",
        "\tfile_server",
        "\treverse_proxy localhost:9000",
        "\ttls {",
        "\t\tprotocols tls1.2 tls1.3",
        "\t}",
        "}"
      ].join("\n");

      var PITCHES = {
        "pitch-store": "J-Dawgs AI Tool Store — working tools built for AI agents and the humans who send them: https://muse.ai/s/ai-tool-store-xng6xkxwjkxl2xab/UoF72OkKI7j33Q2ITxmrZyIr4nv40QtYfj2AgESh_k8",
        "pitch-exchange": "J-Dawgs Agent Exchange — where AI agents pick up real work and get it done: https://muse.ai/s/j-dawgs-agent-exchange-ih6xlnihzxdhxc/ZbleqxFHRE0NcswaBkyN13y9lLp5rPAgHTb6t8ii-PY",
        "pitch-stack": "Seal It, Serve It, Reckon It Stack — three J-Dawgs safety auditors in one bundle: the Vault Server Config Safety Auditor, the Caddy Server Config Safety Auditor, and the Estimate vs Actual Variance Auditor."
      };

      function escapeHtml(s) {
        return String(s).replace(/[&<>"']/g, function (c) {
          return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
        });
      }

      function hostOf(value) {
        // admin value forms: off | localhost:2019 | 0.0.0.0:2019 | unix//path | [::1]:2019
        if (value.indexOf("unix") === 0) return "unix";
        if (value.charAt(0) === "[") {
          var end = value.indexOf("]");
          return end > 0 ? value.slice(1, end) : value;
        }
        var idx = value.lastIndexOf(":");
        if (idx > -1 && value.indexOf(":") === idx) return value.slice(0, idx);
        if (idx > -1 && value.split(":").length > 2) return value; // bare IPv6
        return value;
      }

      function isLocalHost(host) {
        var h = String(host).toLowerCase();
        return h === "localhost" || h === "127.0.0.1" || h === "::1" || h === "unix" ||
               h.indexOf("127.") === 0;
      }

      function audit(text) {
        var findings = [];
        var passes = [];
        var lines = String(text).split(/\r?\n/);
        var adminOff = false, adminOffLine = null, adminLine = null;
        var stack = [];

        function add(sev, line, title, detail, fix) {
          findings.push({ sev: sev, line: line, title: title, detail: detail, fix: fix });
        }

        lines.forEach(function (raw, i) {
          var n = i + 1;
          var hashIdx = raw.indexOf("#");
          var line = hashIdx >= 0 ? raw.slice(0, hashIdx) : raw;
          var t = line.trim();

          if (t) {
            var tokens = t.split(/\s+/);
            var head = tokens[0];

            // --- admin directive ---
            if (head === "admin" && tokens.length > 1) {
              var val = tokens[1];
              if (val === "off") {
                adminOff = true; adminOffLine = n;
              } else {
                if (adminLine === null) adminLine = n;
                var host = hostOf(val);
                if (!isLocalHost(host)) {
                  add("blocker", n, "Admin endpoint exposed to the network",
                    "The admin directive binds Caddy's admin API to " + val + ", which is not a localhost address. Anyone who can reach that port can read and rewrite the live server configuration — no password stands in the way.",
                    "Bind admin to localhost only (admin localhost:2019), or switch it off entirely with admin off in the global options block.");
                }
              }
            }

            // --- debug mode ---
            if (head === "debug" && tokens.length === 1) {
              add("warning", n, "Debug mode is on",
                "The global debug option turns on verbose debug logging. In production it bloats logs and can leak request details you would rather keep quiet.",
                "Remove the debug line from the global options block before deploying.");
            }

            // --- auto_https ---
            if (head === "auto_https") {
              var args = tokens.slice(1);
              if (args.indexOf("off") >= 0 || args.indexOf("disable_certs") >= 0) {
                add("blocker", n, "Automatic HTTPS is disabled",
                  "auto_https is set to " + args.join(" ") + ", which turns off automatic certificate issuing. Sites in this file will be left without working HTTPS unless certificates are managed some other way.",
                  "Remove the auto_https override and let Caddy issue and renew certificates automatically.");
              } else if (args.indexOf("disable_redirects") >= 0) {
                add("warning", n, "HTTP-to-HTTPS redirects are disabled",
                  "auto_https disable_redirects means visitors who arrive on plain http are not sent on to the secure site — they stay on the unencrypted version.",
                  "Drop disable_redirects so Caddy redirects http traffic to https automatically.");
              }
            }

            // --- plaintext site block ---
            if (/^http:\/\//i.test(t) || /^:80(?=\s|\{|$)/.test(t)) {
              add("blocker", n, "Plaintext HTTP site block",
                "This site address is served over plain http. Everything sent to and from it — logins, forms, files — travels the network unencrypted and can be read or altered in transit.",
                "Serve the site over HTTPS instead: use the bare domain name or an https:// address and let Caddy issue a certificate.");
            }

            // --- tls internal ---
            if (head === "tls" && tokens[1] === "internal") {
              add("warning", n, "Certificates from the internal CA",
                "tls internal issues certificates from Caddy's local certificate authority. Browsers do not trust that CA, so visitors get a certificate warning; it is meant for local development, not public sites.",
                "Remove tls internal for public sites so Caddy uses a publicly trusted certificate.");
            }

            // --- TLS protocols ---
            if (head === "protocols") {
              var vers = tokens.slice(1).map(function (v) { return v.toLowerCase(); });
              var weak = vers.filter(function (v) {
                return v === "tls1.0" || v === "tls1.1" || v === "tlsv1.0" || v === "tlsv1.1";
              });
              var modern = vers.filter(function (v) { return v === "tls1.2" || v === "tls1.3"; });
              if (weak.length) {
                add("blocker", n, "Weak TLS versions switched on",
                  "This protocols line enables " + weak.join(" and ") + ". TLS 1.0 and 1.1 are obsolete and broken — modern browsers reject them, and the connections they allow are not properly secure.",
                  "Limit protocols to tls1.2 and tls1.3 only.");
              } else if (modern.length) {
                passes.push({ line: n, title: "Modern TLS protocols only",
                  detail: "Protocols are limited to " + vers.join(" ") + " — no weak TLS versions are offered." });
              }
            }

            // --- file_server browse ---
            if (head === "file_server" && tokens.indexOf("browse") >= 0) {
              add("warning", n, "Directory browsing is enabled",
                "file_server browse shows a public listing of every file in the served folder. Anything left in that folder by accident — backups, exports, stray configs — becomes visible to the whole internet.",
                "Remove browse from file_server, or restrict the listing to a folder that holds nothing sensitive.");
            } else if (t === "browse" && stack.indexOf("file_server") >= 0) {
              add("warning", n, "Directory browsing is enabled",
                "The browse option inside this file_server block shows a public listing of every file in the served folder. Anything left in that folder by accident becomes visible to the whole internet.",
                "Remove the browse line from the file_server block, or restrict the listing to a folder that holds nothing sensitive.");
            }

            // --- wildcard bind ---
            if (head === "bind") {
              var bindVals = tokens.slice(1);
              var wildcard = bindVals.some(function (v) {
                var h = hostOf(v);
                return h === "0.0.0.0" || h === "*" || h === "::";
              });
              if (wildcard) {
                add("warning", n, "Wildcard bind address",
                  "This bind directive makes the site answer on every network interface, including ones you may not intend to expose it on.",
                  "Bind to the specific interface or address the site should answer on, if it does not need to be reachable everywhere.");
              }
            }

            // --- plaintext upstream ---
            if (head === "reverse_proxy") {
              var ups = tokens.slice(1).filter(function (x) { return /^http:\/\//i.test(x); });
              if (ups.length) {
                var shown = ups[0].replace(/^(https?:\/\/)[^/@]*@/, "$1");
                add("warning", n, "Plaintext upstream behind reverse_proxy",
                  "The proxy sends traffic on to " + shown + " over plain http, so the hop from Caddy to the backend is unencrypted. Fine on a trusted private link; a real exposure anywhere else.",
                  "Use an https:// upstream, or confirm this plaintext hop never leaves a network you control.");
              }
            }

            // --- sensitive document root ---
            if (head === "root") {
              var p = tokens[tokens.length - 1];
              var sensitive = p === "/" ||
                /^\/(etc|root|home|sys|proc|boot|private)(\/|$)/.test(p) ||
                p.indexOf("/.ssh") >= 0;
              if (sensitive) {
                add("warning", n, "Document root in a sensitive directory",
                  "The site root points at " + p + ", a system directory. Serving from there risks exposing files that were never meant to be public.",
                  "Point root at a dedicated web folder that contains only the files the site should serve.");
              }
            }

            // --- secret-bearing directives: name and line only, never the value ---
            if (head === "basic_auth") {
              add("note", n, "Secret-bearing directive present: basic_auth",
                "This directive carries a credential. It is flagged by directive name and line number only — the value is deliberately not shown here or in the copied report.",
                "Keep the Caddyfile itself somewhere private, prefer environment-variable placeholders for credentials, and rotate the credential if this file has been shared.");
            }
          }

          // block-stack tracking for the file_server/browse check
          var opens = (line.match(/\{/g) || []).length;
          var closes = (line.match(/\}/g) || []).length;
          var firstTok = t ? t.split(/\s+/)[0] : "";
          for (var a = 0; a < opens; a++) stack.push(firstTok);
          for (var b = 0; b < closes; b++) stack.pop();
        });

        // --- admin off: pass or note ---
        if (adminOff) {
          passes.push({ line: adminOffLine, title: "Admin endpoint switched off",
            detail: "admin off is set, so Caddy's admin API does not listen at all." });
        } else {
          add("note", adminLine, "Admin endpoint not switched off",
            "No admin off was found in this file, so Caddy's admin API stays enabled. By default it binds localhost only, which is contained — but if nothing manages this server through the admin API, it is attack surface that does not need to exist.",
            "Add admin off to the global options block, unless you deliberately manage Caddy through its admin API.");
        }

        var rank = { blocker: 0, warning: 1, note: 2 };
        findings.sort(function (x, y) {
          if (rank[x.sev] !== rank[y.sev]) return rank[x.sev] - rank[y.sev];
          var lx = x.line === null ? 99999 : x.line, ly = y.line === null ? 99999 : y.line;
          return lx - ly;
        });
        passes.sort(function (x, y) { return (x.line || 0) - (y.line || 0); });

        var blockers = findings.filter(function (f) { return f.sev === "blocker"; }).length;
        var warnings = findings.filter(function (f) { return f.sev === "warning"; }).length;
        var notes = findings.filter(function (f) { return f.sev === "note"; }).length;
        var verdict = blockers > 0 ? "DO NOT DEPLOY" : (warnings > 0 ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY");

        return { verdict: verdict, blockers: blockers, warnings: warnings, notes: notes,
                 findings: findings, passes: passes };
      }

      function buildReport(r) {
        var out = [];
        out.push("J-DAWGS CADDY SERVER CONFIG SAFETY AUDITOR — REPORT");
        out.push("Verdict: " + r.verdict);
        out.push("Blockers: " + r.blockers + " · Warnings: " + r.warnings + " · Notes: " + r.notes + " · Passed checks: " + r.passes.length);
        out.push("");
        var groups = [["BLOCKERS", "blocker"], ["WARNINGS", "warning"], ["NOTES", "note"]];
        groups.forEach(function (g) {
          var items = r.findings.filter(function (f) { return f.sev === g[1]; });
          if (!items.length) return;
          out.push(g[0]);
          items.forEach(function (f, idx) {
            out.push("[" + (idx + 1) + "] " + (f.line !== null ? "Line " + f.line + " — " : "Whole file — ") + f.title);
            out.push("    " + f.detail);
            out.push("    Fix: " + f.fix);
          });
          out.push("");
        });
        if (r.passes.length) {
          out.push("PASSED CHECKS");
          r.passes.forEach(function (p) {
            out.push("- Line " + p.line + " — " + p.title + ": " + p.detail);
          });
          out.push("");
        }
        out.push("Audited locally in the browser. Nothing was uploaded or saved. Secret values are never included in this report.");
        return out.join("\n");
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-caddy-server-config-safety-auditor',
  name: 'J-Dawgs Caddy Server Config Safety Auditor',
  description: 'Paste a Caddyfile, get one deploy verdict: a non-localhost admin endpoint, file_server browse, plaintext sites and upstreams, and TLS posture graded offline — credentials are never rendered.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
