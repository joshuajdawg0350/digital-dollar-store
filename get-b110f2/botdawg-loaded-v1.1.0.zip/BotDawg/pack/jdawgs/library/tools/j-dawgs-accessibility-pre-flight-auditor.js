'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Accessibility Pre-Flight Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var EXAMPLE_A = [
          '<section class="signup">',
          '  <h1>Join the newsletter</h1>',
          '  <h3>Why join?</h3>',
          '  <img src="team.jpg">',
          '  <span id="hint">We never share your email.</span>',
          '  <input type="email" id="email" placeholder="you@example.com">',
          '  <p id="hint">Duplicate note text.</p>',
          '  <a href="/signup">click here</a>',
          '  <button type="submit"></button>',
          '  <div tabindex="3">Jump target</div>',
          '</section>'
        ].join("\n");

        var EXAMPLE_B = [
          '<section class="signup">',
          '  <h1>Join the newsletter</h1>',
          '  <h2>Why join?</h2>',
          '  <img src="team.jpg" alt="The J-Dawgs crew packing orders at the workbench">',
          '  <label for="email">Email address</label>',
          '  <input type="email" id="email" placeholder="you@example.com">',
          '  <a href="/signup">Sign up for the newsletter</a>',
          '  <button type="submit">Subscribe</button>',
          '</section>'
        ].join("\n");

        var KNOWN_ROLES = {};
        ("alert alertdialog application article banner button cell checkbox columnheader combobox complementary contentinfo definition dialog directory document feed figure form grid gridcell group heading img link list listbox listitem log main marquee math menu menubar menuitem menuitemcheckbox menuitemradio navigation none note option presentation progressbar radio radiogroup region row rowgroup rowheader scrollbar search searchbox separator slider spinbutton status switch tab table tablist tabpanel term textbox timer toolbar tooltip tree treegrid treeitem generic caption code deletion emphasis insertion paragraph strong subscript superscript time blockquote listitem").split(" ").forEach(function (r) { KNOWN_ROLES[r] = true; });

        var VOID = { area: 1, base: 1, br: 1, col: 1, embed: 1, hr: 1, img: 1, input: 1, link: 1, meta: 1, param: 1, source: 1, track: 1, wbr: 1 };
        var RAW_TEXT = { script: 1, style: 1, textarea: 1, title: 1 };
        var BAD_LINK_TEXT = { "click here": 1, "here": 1, "read more": 1, "more": 1, "learn more": 1, "link": 1, "this": 1, "this link": 1, "go": 1, "continue": 1, "click": 1 };

        /* ---------- tiny HTML parser that keeps line numbers ---------- */
        function parseHTML(src) {
          var root = { tag: "#root", attrs: {}, children: [], text: "", line: 0, raw: "", parent: null };
          var stack = [root];
          var i = 0, line = 1, n = src.length;
          function top() { return stack[stack.length - 1]; }
          function advanceTo(j) { while (i < j) { if (src.charCodeAt(i) === 10) line++; i++; } }
          function addText(t) { top().text += t; }

          while (i < n) {
            var lt = src.indexOf("<", i);
            if (lt === -1) { addText(src.slice(i)); advanceTo(n); break; }
            if (lt > i) { addText(src.slice(i, lt)); advanceTo(lt); }
            var startLine = line;

            if (src.substr(i, 4) === "<!--") {
              var cEnd = src.indexOf("-->", i + 4);
              advanceTo(cEnd === -1 ? n : cEnd + 3);
              continue;
            }
            if (src.substr(i, 2) === "<!" || src.substr(i, 2) === "<?") {
              var dEnd = src.indexOf(">", i + 2);
              advanceTo(dEnd === -1 ? n : dEnd + 1);
              continue;
            }
            if (src.substr(i, 2) === "</") {
              var cm = /^<\/\s*([a-zA-Z][a-zA-Z0-9-]*)\s*>/.exec(src.slice(i, i + 80));
              if (cm) {
                var cname = cm[1].toLowerCase();
                for (var s = stack.length - 1; s > 0; s--) {
                  if (stack[s].tag === cname) { stack.length = s; break; }
                }
                advanceTo(i + cm[0].length);
              } else {
                addText("<"); advanceTo(i + 1);
              }
              continue;
            }
            var om = /^<([a-zA-Z][a-zA-Z0-9-]*)/.exec(src.slice(i, i + 80));
            if (!om) { addText("<"); advanceTo(i + 1); continue; }
            var tag = om[1].toLowerCase();
            var j = i + om[0].length;
            var attrs = {};
            var selfClose = false;
            while (j < n) {
              var ch = src[j];
              if (ch === ">") { j++; break; }
              if (ch === "/" && src[j + 1] === ">") { selfClose = true; j += 2; break; }
              if (/\s/.test(ch) || ch === "/") { j++; continue; }
              var am = /^([^\s=\/>]+)/.exec(src.slice(j));
              if (!am) { j++; continue; }
              var aname = am[1].toLowerCase();
              j += am[0].length;
              while (j < n && /\s/.test(src[j])) j++;
              var aval = "";
              if (src[j] === "=") {
                j++;
                while (j < n && /\s/.test(src[j])) j++;
                var q = src[j];
                if (q === '"' || q === "'") {
                  var qEnd = src.indexOf(q, j + 1);
                  if (qEnd === -1) qEnd = n;
                  aval = src.slice(j + 1, qEnd);
                  j = qEnd + 1;
                } else {
                  var vm = /^[^\s>]*/.exec(src.slice(j));
                  aval = vm[0]; j += vm[0].length;
                }
              }
              if (!(aname in attrs)) attrs[aname] = aval;
            }
            var node = { tag: tag, attrs: attrs, children: [], text: "", line: startLine, raw: src.slice(i, j), parent: top() };
            top().children.push(node);
            advanceTo(j);
            if (!selfClose && !VOID[tag]) {
              stack.push(node);
              if (RAW_TEXT[tag]) {
                var closeIdx = src.toLowerCase().indexOf("</" + tag, i);
                if (closeIdx === -1) { addText(src.slice(i)); advanceTo(n); }
                else { addText(src.slice(i, closeIdx)); advanceTo(closeIdx); }
              }
            }
          }
          return root;
        }

        function walk(node, out) {
          for (var k = 0; k < node.children.length; k++) {
            out.push(node.children[k]);
            walk(node.children[k], out);
          }
          return out;
        }
        function innerText(node) {
          var t = node.text;
          for (var k = 0; k < node.children.length; k++) t += " " + innerText(node.children[k]);
          return t.replace(/\s+/g, " ").trim();
        }
        function descendantImgAlt(node) {
          for (var k = 0; k < node.children.length; k++) {
            var c = node.children[k];
            if (c.tag === "img" && c.attrs.alt && c.attrs.alt.trim()) return c.attrs.alt.trim();
            var r = descendantImgAlt(c);
            if (r) return r;
          }
          return "";
        }
        function hasAncestor(node, tag) {
          var p = node.parent;
          while (p) { if (p.tag === tag) return true; p = p.parent; }
          return false;
        }
        function hasDescendant(node, pred) {
          for (var k = 0; k < node.children.length; k++) {
            if (pred(node.children[k]) || hasDescendant(node.children[k], pred)) return true;
          }
          return false;
        }
        function isFocusable(node) {
          if (node.tag === "a" && ("href" in node.attrs)) return true;
          if (node.tag === "button" || node.tag === "select" || node.tag === "textarea") return true;
          if (node.tag === "input" && (node.attrs.type || "text").toLowerCase() !== "hidden") return true;
          if ((node.tag === "audio" || node.tag === "video") && ("controls" in node.attrs)) return true;
          if ("tabindex" in node.attrs) { var tv = parseInt(node.attrs.tabindex, 10); if (!isNaN(tv) && tv >= 0) return true; }
          return false;
        }
        function snippet(node) {
          var s = node.raw.replace(/\s+/g, " ").trim();
          return s.length > 110 ? s.slice(0, 107) + "..." : s;
        }

        /* ---------- the audit ---------- */
        function audit(src) {
          var findings = [];
          function add(sev, line, title, node, fix) {
            findings.push({ sev: sev, line: line, title: title, code: node ? snippet(node) : "", fix: fix });
          }
          var root = parseHTML(src);
          var all = walk(root, []);
          var i, node;

          var byTag = {};
          all.forEach(function (el) { (byTag[el.tag] = byTag[el.tag] || []).push(el); });

          /* ids */
          var idMap = {};
          all.forEach(function (el) { if (el.attrs.id) (idMap[el.attrs.id] = idMap[el.attrs.id] || []).push(el); });
          Object.keys(idMap).forEach(function (id) {
            if (idMap[id].length > 1) {
              var lines = idMap[id].map(function (e) { return e.line; }).join(", ");
              add("BLOCKER", idMap[id][1].line, 'Duplicate id "' + id + '" (appears on lines ' + lines + ")", idMap[id][1],
                'Make every id unique. Labels and ARIA references point at the first match only, so duplicates silently break them.');
            }
          });
          function idExists(id) { return !!idMap[id]; }

          /* (6) html lang */
          var htmlEls = byTag.html || [];
          if (htmlEls.length) {
            var h = htmlEls[0];
            if (!h.attrs.lang || !h.attrs.lang.trim()) {
              add("BLOCKER", h.line, "Full document pasted but <html> has no lang attribute", h,
                'Add a language, e.g. <html lang="en">, so screen readers use the right pronunciation rules.');
            }
          }

          /* (1) images */
          (byTag.img || []).forEach(function (img) {
            if (!("alt" in img.attrs)) {
              add("BLOCKER", img.line, "Image missing alt attribute", img,
                'Add alt text describing the image\'s content or purpose — or alt="" if it is purely decorative.');
            } else if (img.attrs.alt.trim() === "") {
              add("INFO", img.line, 'Image has alt="" — marked decorative, OK', img,
                "No fix needed if the image is purely decorative. If it carries information, give it real alt text instead.");
            }
          });

          /* (2) form labels */
          var labelFor = {};
          (byTag.label || []).forEach(function (l) { if (l.attrs["for"]) labelFor[l.attrs["for"]] = true; });
          function labelledBy(el) {
            if (el.attrs["aria-label"] && el.attrs["aria-label"].trim()) return "aria-label";
            if (el.attrs["aria-labelledby"] && el.attrs["aria-labelledby"].trim()) {
              var refs = el.attrs["aria-labelledby"].trim().split(/\s+/);
              for (var r = 0; r < refs.length; r++) if (idExists(refs[r])) return "aria-labelledby";
              return "broken-labelledby";
            }
            if (el.attrs.id && labelFor[el.attrs.id]) return "label for=";
            if (hasAncestor(el, "label")) return "wrapping label";
            return "";
          }
          function checkControl(el, what) {
            var how = labelledBy(el);
            if (how === "broken-labelledby") {
              add("BLOCKER", el.line, what + " points aria-labelledby at an id that does not exist", el,
                "Fix the aria-labelledby reference to an existing element id, or use a real <label>.");
            } else if (!how) {
              var ph = el.attrs.placeholder && el.attrs.placeholder.trim();
              add("BLOCKER", el.line, what + " has no associated label" + (ph ? " (placeholder alone does not count)" : ""), el,
                'Add a <label for="' + (el.attrs.id || "field-id") + '">, wrap the field in a <label>, or add aria-label. A placeholder disappears while typing and is not a label.');
            }
          }
          all.forEach(function (el) {
            if (el.tag === "select" || el.tag === "textarea") checkControl(el, el.tag === "select" ? "Select" : "Textarea");
            else if (el.tag === "input") {
              var type = (el.attrs.type || "text").toLowerCase();
              if (type === "hidden") return;
              if (type === "submit" || type === "reset") return; /* browser supplies a name */
              if (type === "button") {
                if (!(el.attrs.value && el.attrs.value.trim()) && !(el.attrs["aria-label"] && el.attrs["aria-label"].trim())) {
                  add("BLOCKER", el.line, "Input button has no accessible name (no value, no aria-label)", el,
                    'Give it a value such as value="Apply filters", or an aria-label.');
                }
                return;
              }
              if (type === "image") {
                if (!(el.attrs.alt && el.attrs.alt.trim()) && !(el.attrs["aria-label"] && el.attrs["aria-label"].trim())) {
                  add("BLOCKER", el.line, "Image input has no accessible name (no alt, no aria-label)", el,
                    "Add alt text naming the action, e.g. alt=\"Search\".");
                }
                return;
              }
              checkControl(el, "Input");
            }
          });

          /* (3) headings */
          var headings = all.filter(function (el) { return /^h[1-6]$/.test(el.tag); });
          var h1s = byTag.h1 || [];
          if (headings.length && h1s.length === 0) {
            add("WARNING", headings[0].line, "Headings present but no h1", headings[0],
              "Add one h1 that names the page or section; start the outline there.");
          }
          if (h1s.length > 1) {
            add("WARNING", h1s[1].line, "Multiple h1 elements (" + h1s.length + " found, first on line " + h1s[0].line + ")", h1s[1],
              "Keep one h1 per page and demote the rest to h2 in outline order.");
          }
          for (i = 1; i < headings.length; i++) {
            var prev = parseInt(headings[i - 1].tag.charAt(1), 10);
            var cur = parseInt(headings[i].tag.charAt(1), 10);
            if (cur > prev + 1) {
              add("WARNING", headings[i].line, "Heading level skips from h" + prev + " to h" + cur, headings[i],
                "Do not skip levels: use h" + (prev + 1) + " here, or promote this heading. Screen-reader users navigate by the outline.");
            }
          }

          /* (4) links */
          (byTag.a || []).forEach(function (a) {
            if (!("href" in a.attrs)) return;
            var name = (a.attrs["aria-label"] && a.attrs["aria-label"].trim()) || innerText(a) || descendantImgAlt(a);
            if (!name) {
              add("BLOCKER", a.line, "Link has no text at all", a,
                "Give the link text that names the destination, or an aria-label — an image-only link needs alt text on the image.");
            } else {
              var norm = name.toLowerCase().replace(/[.!…]+$/, "").trim();
              if (BAD_LINK_TEXT[norm] || /^https?:\/\//i.test(norm) || /^www\./i.test(norm)) {
                add("WARNING", a.line, 'Non-descriptive link text: "' + (name.length > 40 ? name.slice(0, 37) + "..." : name) + '"', a,
                  "Rewrite the link text to name the destination out of context, e.g. \"Sign up for the newsletter\" instead of \"click here\".");
              }
            }
          });

          /* (5) buttons */
          (byTag.button || []).forEach(function (b) {
            var name = (b.attrs["aria-label"] && b.attrs["aria-label"].trim()) || innerText(b) || descendantImgAlt(b);
            if (!name) {
              if (b.attrs["aria-labelledby"] && b.attrs["aria-labelledby"].trim()) {
                var refs = b.attrs["aria-labelledby"].trim().split(/\s+/);
                var ok = false;
                refs.forEach(function (r) { if (idExists(r)) ok = true; });
                if (ok) return;
              }
              add("BLOCKER", b.line, "Button has no accessible name (no text, no aria-label)", b,
                "Put text inside the button, or add aria-label for an icon-only button.");
            }
          });

          /* (7) positive tabindex */
          all.forEach(function (el) {
            if ("tabindex" in el.attrs) {
              var tv = parseInt(el.attrs.tabindex, 10);
              if (!isNaN(tv) && tv > 0) {
                add("WARNING", el.line, "Positive tabindex (" + tv + ") reorders keyboard focus", el,
                  "Remove the positive tabindex and let DOM order set the tab order; use tabindex=\"0\" or \"-1\" only where needed.");
              }
            }
          });

          /* (8) ARIA subset */
          all.forEach(function (el) {
            if (el.attrs["aria-hidden"] && el.attrs["aria-hidden"].trim().toLowerCase() === "true") {
              if (isFocusable(el) || hasDescendant(el, isFocusable)) {
                add("BLOCKER", el.line, 'aria-hidden="true" on an element containing focusable content', el,
                  "Keyboard and screen-reader users can tab to content that is hidden from them. Remove aria-hidden, or remove the focusable elements from the tab order and the accessibility tree together.");
              }
            }
            if (el.attrs.role && el.attrs.role.trim()) {
              el.attrs.role.trim().split(/\s+/).forEach(function (r) {
                var rl = r.toLowerCase();
                if (!KNOWN_ROLES[rl]) {
                  add("INFO", el.line, 'NOT EVALUATED: role "' + r + '" is outside the known-role list', el,
                    "This audit does not guess at unknown roles. Check the value against the ARIA role list yourself; a typo here silently removes the intended semantics.");
                }
              });
            }
          });

          /* (10) tables */
          (byTag.table || []).forEach(function (t) {
            var hasTh = hasDescendant(t, function (c) { return c.tag === "th"; });
            var hasCaption = hasDescendant(t, function (c) { return c.tag === "caption"; });
            if (!hasTh || !hasCaption) {
              var missing = [];
              if (!hasTh) missing.push("no <th> header cells");
              if (!hasCaption) missing.push("no <caption>");
              add("WARNING", t.line, "Table ambiguity: " + missing.join(" and "), t,
                "If this is a data table, add <th> headers and a <caption> naming it. If it is layout-only, prefer CSS layout so assistive tech does not announce a phantom table.");
            }
          });

          findings.sort(function (a, b) {
            if (a.line !== b.line) return a.line - b.line;
            var order = { BLOCKER: 0, WARNING: 1, INFO: 2 };
            return order[a.sev] - order[b.sev];
          });

          var counts = { BLOCKER: 0, WARNING: 0, INFO: 0 };
          findings.forEach(function (f) { counts[f.sev]++; });
          var verdict;
          if (counts.BLOCKER > 0) verdict = "DO NOT SHIP — ACCESS BARRIERS PRESENT";
          else if (counts.WARNING > 0) verdict = "SHIP WITH FIXES";
          else verdict = "ACCESSIBLE ENOUGH TO SHIP";
          return { findings: findings, counts: counts, verdict: verdict };
        }

        function buildReport(result, src) {
          var lines = [];
          var lineCount = src.replace(/\s+$/, "").split("\n").length;
          lines.push("J-DAWGS ACCESSIBILITY PRE-FLIGHT AUDIT");
          lines.push("Verdict: " + result.verdict);
          lines.push("Counts: " + result.counts.BLOCKER + " BLOCKER · " + result.counts.WARNING + " WARNING · " + result.counts.INFO + " INFO");
          lines.push("Source: " + lineCount + " line" + (lineCount === 1 ? "" : "s") + " of pasted HTML audited offline in the browser.");
          lines.push("");
          if (!result.findings.length) {
            lines.push("No findings. Nothing in the checked rules fired on this markup.");
          }
          result.findings.forEach(function (f) {
            lines.push("[" + f.sev + "] Line " + f.line + " — " + f.title);
            if (f.code) lines.push("  Code: " + f.code);
            lines.push("  Fix: " + f.fix);
            lines.push("");
          });
          lines.push("Limits: static text audit only — no color-contrast judgement, no keyboard-flow or screen-reader testing, no WCAG certification claim.");
          return lines.join("\n");
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_A": (typeof EXAMPLE_A !== 'undefined' ? EXAMPLE_A : undefined), "EXAMPLE_B": (typeof EXAMPLE_B !== 'undefined' ? EXAMPLE_B : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-accessibility-pre-flight-auditor',
  name: 'J-Dawgs Accessibility Pre-Flight Auditor',
  description: 'Live scanners grade a page that already shipped; ours pre-flights a pasted HTML fragment before publish — alt text, labels, heading order, link names, ARIA traps — and returns one ship verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_A": __core["EXAMPLE_A"], "EXAMPLE_B": __core["EXAMPLE_B"] }
};
