'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Deck & Patio Proposal, Work Record & Final Invoice Consistency Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";
/* ---------- helpers ---------- */
function $(id){return document.getElementById(id);}
function num(s){ if(s==null) return null; var v=parseFloat(String(s).replace(/,/g,"")); return isNaN(v)?null:v; }
function money(v){ if(v==null||isNaN(v)) return "—"; return "$"+Number(v).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g,","); }
function linesOf(t){ return String(t||"").split(/\r?\n/); }
function lastMoney(line){ var m=String(line).match(/\$\s*([\d,]+\.?\d*)/g); if(!m) return null; return num(m[m.length-1].replace(/\$/,"")); }
function firstMoney(line){ var m=String(line).match(/\$\s*([\d,]+\.?\d*)/); return m?num(m[1]):null; }
function esc(s){ return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"); }

var DECK_WORDS=["deck","patio","sq","labor","material","permit","invoice","proposal","footing","railing","disposal","composite","deposit","lumber","concrete"];
function isUsable(text){
  var t=String(text||"").trim();
  if(t.length<60) return false;
  var words=t.split(/\s+/).filter(Boolean);
  if(words.length<8) return false;
  var low=t.toLowerCase();
  var hits=0; DECK_WORDS.forEach(function(w){ if(low.indexOf(w)>=0) hits++; });
  if(hits<2) return false;
  if(!/\d/.test(t)) return false;
  /* gibberish guard: most words should contain a vowel or be numeric */
  var vowelish=words.filter(function(w){ return /[aeiou]/i.test(w)||/\d/.test(w); }).length;
  if(words.length>0 && vowelish/words.length<0.5) return false;
  return true;
}

/* ---------- extractors ---------- */
function sqftNear(text, labelRes){
  var ls=linesOf(text);
  for(var i=0;i<ls.length;i++){
    for(var j=0;j<labelRes.length;j++){
      if(labelRes[j].test(ls[i])){
        var m=ls[i].match(/([\d,]+(?:\.\d+)?)\s*(?:sq\.?\s*ft|square\s*feet)/i);
        if(m) return num(m[1]);
        var m2=ls[i].match(/[:\-]\s*([\d,]+(?:\.\d+)?)/);
        if(m2 && /sq|feet|area|deck/i.test(ls[i])) return num(m2[1]);
      }
    }
  }
  return null;
}
function anySqft(text){
  var m=String(text).match(/([\d,]+(?:\.\d+)?)\s*(?:sq\.?\s*ft|square\s*feet)/i);
  return m?num(m[1]):null;
}
function getWaste(text){
  var m=String(text).match(/waste[^%\n]{0,40}?([\d.]+)\s*%/i);
  return m?num(m[1]):null;
}
function getRatePerSqft(text){
  var m=String(text).match(/\$\s*([\d,]+\.?\d*)\s*(?:per|\/)\s*(?:sq\.?\s*ft|square\s*foot)/i);
  if(m) return num(m[1]);
  m=String(text).match(/decking\s*rate[^$\n]*\$\s*([\d,]+\.?\d*)/i);
  return m?num(m[1]):null;
}
function getLaborRate(text){
  var m=String(text).match(/labor\s*rate[^$\n]*\$\s*([\d,]+\.?\d*)/i);
  if(m) return num(m[1]);
  m=String(text).match(/\$\s*([\d,]+\.?\d*)\s*(?:per\s*hour|\/\s*hr|per\s*hr)/i);
  return m?num(m[1]):null;
}
function getHours(text, kind){
  var ls=linesOf(text), res;
  if(kind==="recorded") res=[/hours?\s*recorded/i,/labor\s*hours/i,/hours?\s*worked/i,/recorded[^:\n]*hours/i];
  else if(kind==="billed") res=[/hours?\s*billed/i,/labor\s*hours/i,/billed[^:\n]*hours/i];
  else res=[/labor\s*hours/i,/estimated\s*labor/i,/hours/i];
  for(var i=0;i<ls.length;i++){
    for(var j=0;j<res.length;j++){
      if(res[j].test(ls[i])){
        var m=ls[i].match(/([\d,]+(?:\.\d+)?)\s*(?:hours?|hrs?)\b/i);
        if(m) return num(m[1]);
        var m2=ls[i].match(/[:\-]\s*([\d,]+(?:\.\d+)?)/);
        if(m2) return num(m2[1]);
      }
    }
  }
  /* fall back: any "N hours" on a labor line */
  for(var k=0;k<ls.length;k++){
    if(/labor/i.test(ls[k])){ var m3=ls[k].match(/([\d,]+(?:\.\d+)?)\s*(?:hours?|hrs?)\b/i); if(m3) return num(m3[1]); }
  }
  return null;
}
function getLaborCharge(text){
  var ls=linesOf(text), best=null;
  for(var i=0;i<ls.length;i++){
    if(/labor/i.test(ls[i]) && /\$/.test(ls[i])){
      if(/rate/i.test(ls[i]) && !/[:\-]\s*\$[\d,]+\.\d{2}\s*$/.test(ls[i].trim()) && (ls[i].match(/\$/g)||[]).length===1) continue;
      var v=lastMoney(ls[i]); if(v!=null) best=v;
    }
  }
  return best;
}
function getDeposit(text, mode){
  var ls=linesOf(text), best=null;
  for(var i=0;i<ls.length;i++){
    if(!/deposit/i.test(ls[i])) continue;
    if(mode==="credit" && !/credit|less|applied|deduct/i.test(ls[i])) continue;
    if(mode==="paid" && /credit/i.test(ls[i])) continue;
    var v=lastMoney(ls[i]); if(v!=null) best=v;
  }
  return best;
}
function feeLines(text, name){
  var out=[];
  linesOf(text).forEach(function(l){ if(new RegExp(name,"i").test(l) && /\$/.test(l) && !/total/i.test(l)){ var v=lastMoney(l); if(v!=null) out.push({line:l.trim(), amount:v}); } });
  return out;
}
function feeAmount(text, name){
  var f=feeLines(text,name); return f.length?f[0].amount:null;
}
function materialIn(text){
  var low=String(text).toLowerCase();
  /* prefer explicit material / decking / installed lines */
  var ls=linesOf(text);
  var scoped=ls.filter(function(l){ return /material|decking|installed|billed|proposed/i.test(l); }).join(" ").toLowerCase();
  var hay=scoped.length?scoped:low;
  if(/pressure[\s-]*treated/.test(hay)) return "Pressure-treated";
  if(/composite/.test(hay)) return "Composite";
  if(/cedar/.test(hay)) return "Cedar";
  if(/\bpvc\b/.test(hay)) return "PVC";
  if(/trex/.test(hay)) return "Composite (Trex)";
  return null;
}
function featureIn(text, kind){
  var ls=linesOf(text).filter(function(l){ return new RegExp(kind,"i").test(l); });
  var hay=ls.join(" ").toLowerCase();
  if(!hay) return null;
  if(/aluminum|aluminium/.test(hay)) return "Aluminum";
  if(/cable/.test(hay)) return "Cable";
  if(/composite/.test(hay)) return "Composite";
  if(/vinyl/.test(hay)) return "Vinyl";
  if(/wood/.test(hay)) return "Wood";
  if(/helical/.test(hay)) return "Helical pier";
  if(/concrete/.test(hay)) return "Concrete";
  if(/sonotube/.test(hay)) return "Sonotube concrete";
  return null;
}
function invoiceLines(text){
  var out=[];
  linesOf(text).forEach(function(l){
    if(!/\$/.test(l)) return;
    if(/total|subtotal|balance\s*due|amount\s*due/i.test(l)) return;
    var v=lastMoney(l); if(v==null) return;
    var isCredit=/credit|less\s+deposit|deposit\s+applied|deduct/i.test(l);
    out.push({label:l.trim(), amount:isCredit?-Math.abs(v):v, credit:isCredit});
  });
  return out;
}
function statedTotal(text){
  var ls=linesOf(text), best=null;
  for(var i=0;i<ls.length;i++){
    if(/total\s*due|invoice\s*total|balance\s*due|grand\s*total|^\s*total\b/i.test(ls[i])){ var v=lastMoney(ls[i]); if(v!=null) best=v; }
  }
  return best;
}

/* ---------- audit ---------- */
function audit(pText,wText,iText){
  var docs=[
    {key:"proposal", name:"Approved proposal", text:pText, usable:isUsable(pText)},
    {key:"work", name:"Builder's work record", text:wText, usable:isUsable(wText)},
    {key:"invoice", name:"Final invoice", text:iText, usable:isUsable(iText)}
  ];
  var usableCount=docs.filter(function(d){return d.usable;}).length;
  var missing=docs.filter(function(d){return !d.usable;});
  var findings=[], figures={};
  function add(sev,title,detail,math,amount){ findings.push({severity:sev,title:title,detail:detail,math:math||"",amount:(amount==null?null:amount)}); }

  if(usableCount<2){
    add("info","Not enough to compare","Fewer than two usable documents were pasted. A cross-check needs at least two of the three documents — and a real verdict needs all three. Gibberish, blank, and very short pastes do not count as documents.","Usable documents found: "+usableCount+" of 3.",null);
    return finish("NOT ENOUGH TO COMPARE","Paste at least two usable documents — all three for a full verdict.",findings,figures,0,docs);
  }

  var partial = usableCount===2;
  if(partial){
    add("warning","Missing document: "+missing.map(function(d){return d.name;}).join(", "),
      "Only two usable documents were pasted, so this verdict is capped at PAY WITH FIXES. Paste the "+missing.map(function(d){return d.name.toLowerCase();}).join(", ")+" and re-run for a full cross-check.",
      "Documents present: "+docs.filter(function(d){return d.usable;}).map(function(d){return d.name;}).join(" + ")+". Missing: "+missing.map(function(d){return d.name;}).join(", ")+".",null);
  }

  var hasP=docs[0].usable, hasW=docs[1].usable, hasI=docs[2].usable;

  /* extracted figures */
  var builtSqft = hasW ? (sqftNear(wText,[/built/i,/completed/i,/actual/i,/installed/i]) || anySqft(wText)) : null;
  var billedSqft = hasI ? (sqftNear(iText,[/billed/i]) || null) : null;
  if(billedSqft==null && hasI){
    /* decking line: "360 sq ft at $30" */
    var dm=iText.match(/([\d,]+(?:\.\d+)?)\s*(?:sq\.?\s*ft|square\s*feet)[^\n]*\$\s*[\d,]/i);
    if(dm) billedSqft=num(dm[1]);
  }
  var proposalSqft = hasP ? anySqft(pText) : null;
  var waste = hasP ? getWaste(pText) : null;
  if(waste==null && hasI) waste=getWaste(iText);
  if(waste==null) waste=0;
  var rateSqft = (hasI?getRatePerSqft(iText):null) || (hasP?getRatePerSqft(pText):null);
  /* derive rate from decking line total / billed sqft */
  var invLines = hasI ? invoiceLines(iText) : [];
  if(rateSqft==null && billedSqft){
    for(var di=0;di<invLines.length;di++){ if(/deck/i.test(invLines[di].label) && invLines[di].amount>0){ rateSqft=invLines[di].amount/billedSqft; break; } }
  }
  var workHours = hasW ? getHours(wText,"recorded") : null;
  var billHours = hasI ? getHours(iText,"billed") : null;
  var laborRate = (hasP?getLaborRate(pText):null) || (hasI?getLaborRate(iText):null) || (hasW?getLaborRate(wText):null);
  var laborCharge = hasI ? getLaborCharge(iText) : null;
  var depositPaid = (hasP?getDeposit(pText,"paid"):null);
  if(depositPaid==null && hasW) depositPaid=getDeposit(wText,"paid");
  if(depositPaid==null && hasW) depositPaid=getDeposit(wText,"any");
  var depositCredit = hasI ? getDeposit(iText,"credit") : null;
  var total = hasI ? statedTotal(iText) : null;
  var lineSum = invLines.reduce(function(s,l){return s+l.amount;},0);

  figures={builtSqft:builtSqft,billedSqft:billedSqft,proposalSqft:proposalSqft,wastePct:waste,ratePerSqft:rateSqft,workHours:workHours,billedHours:billHours,laborRate:laborRate,laborCharge:laborCharge,depositPaid:depositPaid,depositCredit:depositCredit,invoiceLineSum:hasI?lineSum:null,statedTotal:total};

  var overcharge=0, hasCritical=false;

  /* 1 — square feet */
  if(hasW && hasI && builtSqft!=null && billedSqft!=null){
    var allowed=builtSqft*(1+waste/100);
    figures.allowedSqft=Math.round(allowed*100)/100;
    if(billedSqft>allowed+0.5){
      var overSq=billedSqft-allowed;
      var amt=rateSqft!=null?overSq*rateSqft:null;
      if(amt!=null) overcharge+=amt;
      hasCritical=true;
      add("critical","Deck area billed above what was built (beyond the waste allowance)",
        "The invoice bills "+billedSqft+" sq ft, but the work record says "+builtSqft+" sq ft was built. Even after the agreed "+waste+"% waste allowance, only "+(Math.round(allowed*100)/100)+" sq ft is billable. The extra "+(Math.round(overSq*100)/100)+" sq ft should not be paid at the decking rate.",
        "Allowed = "+builtSqft+" × (1 + "+waste+"/100) = "+(Math.round(allowed*100)/100)+" sq ft\nOver = "+billedSqft+" − "+(Math.round(allowed*100)/100)+" = "+(Math.round(overSq*100)/100)+" sq ft"+(rateSqft!=null?"\nOvercharge = "+(Math.round(overSq*100)/100)+" × "+money(rateSqft)+" = "+money(amt):"\n(No per-sq-ft rate found, so no dollar figure is claimed for this one.)"),amt);
    } else {
      add("ok","Deck area checks out","Billed "+billedSqft+" sq ft is within the built "+builtSqft+" sq ft plus the "+waste+"% waste allowance ("+(Math.round(allowed*100)/100)+" sq ft).",
        "Allowed = "+builtSqft+" × (1 + "+waste+"/100) = "+(Math.round(allowed*100)/100)+" sq ft. Billed = "+billedSqft+" sq ft.",null);
    }
  } else if(hasI && hasP && billedSqft!=null && proposalSqft!=null && !hasW){
    add("info","Area compared to proposal only (no work record)","Billed "+billedSqft+" sq ft vs. proposed "+proposalSqft+" sq ft. Without the work record there is no built figure to check against, so no overbilling verdict is given on area.","",null);
  }

  /* 2 — materials / railing / footings */
  var matP=hasP?materialIn(pText):null, matW=hasW?materialIn(wText):null, matI=hasI?materialIn(iText):null;
  figures.materials={proposal:matP,workRecord:matW,invoice:matI};
  if(matW && ((matP && matP!==matW)||(matI && matI!==matW))){
    hasCritical=true;
    add("critical","Material swap: what was billed / proposed is not what the work record says went in",
      "Proposal says "+(matP||"—")+", invoice bills "+(matI||"—")+", but the work record says "+matW+" was installed. A downgrade swap like this changes the value of the job — do not pay the higher-material price for the lower material until the builder prices the difference in writing.",
      "Proposal material: "+(matP||"not stated")+"\nInvoice material: "+(matI||"not stated")+"\nWork-record material: "+matW,null);
  } else if(matP||matW||matI){
    add("ok","Decking material is consistent","Material reads the same across the documents supplied: "+(matW||matI||matP)+".","Proposal: "+(matP||"—")+" · Work record: "+(matW||"—")+" · Invoice: "+(matI||"—"),null);
  }
  [["railing","Railing"],["footing","Footing"]].forEach(function(pair){
    var a=hasP?featureIn(pText,pair[0]):null, b=hasW?featureIn(wText,pair[0]):null, c=hasI?featureIn(iText,pair[0]):null;
    if(b && ((a && a!==b)||(c && c!==b))){
      hasCritical=true;
      add("critical",pair[1]+" change: documents disagree",
        pair[1]+" — proposal: "+(a||"—")+", invoice: "+(c||"—")+", work record: "+b+". The documents do not describe the same "+pair[1].toLowerCase()+", so the invoice price for it cannot be trusted until the builder explains the change.",
        "Proposal: "+(a||"not stated")+" · Work record: "+b+" · Invoice: "+(c||"not stated"),null);
    } else if(a||b||c){
      add("ok",pair[1]+" is consistent",pair[1]+" reads consistently: "+(b||c||a)+".","Proposal: "+(a||"—")+" · Work record: "+(b||"—")+" · Invoice: "+(c||"—"),null);
    }
  });

  /* 3 — labor */
  if(hasW && hasI && workHours!=null && laborRate!=null && laborCharge!=null){
    var expected=workHours*laborRate;
    figures.laborExpected=expected;
    if(laborCharge>expected+1){
      var lOver=laborCharge-expected; overcharge+=lOver; hasCritical=true;
      add("critical","Labor charged above recorded hours × rate",
        "The work record shows "+workHours+" hours. At the agreed "+money(laborRate)+" per hour that is "+money(expected)+", but the invoice charges "+money(laborCharge)+" for labor"+(billHours!=null?" ("+billHours+" hours billed)":"")+".",
        "Expected = "+workHours+" hrs × "+money(laborRate)+" = "+money(expected)+"\nCharged = "+money(laborCharge)+"\nOvercharge = "+money(laborCharge)+" − "+money(expected)+" = "+money(lOver),lOver);
    } else {
      add("ok","Labor checks out","Recorded "+workHours+" hrs × "+money(laborRate)+" = "+money(expected)+", and the invoice labor charge is "+money(laborCharge)+".",
        "Expected = "+workHours+" × "+money(laborRate)+" = "+money(expected)+". Charged = "+money(laborCharge)+".",null);
    }
  } else if(hasI && billHours!=null && workHours!=null && billHours>workHours){
    add("warning","Billed hours exceed recorded hours","Invoice bills "+billHours+" hours; the work record records "+workHours+" hours. No rate was found to price the difference, so ask for the rate and the timesheets before paying the difference.","Billed − recorded = "+(billHours-workHours)+" hours.",null);
  }

  /* 4 — deposit */
  if(depositPaid!=null && depositPaid>0 && hasI){
    var credit=depositCredit||0;
    if(credit<depositPaid-0.5){
      var missingAmt=depositPaid-credit; overcharge+=missingAmt; hasCritical=true;
      add("critical","Deposit paid but not fully credited on the invoice",
        "A deposit of "+money(depositPaid)+" was paid, but the invoice credits only "+money(credit)+". The missing "+money(missingAmt)+" is money already paid being charged again if the invoice total is paid in full.",
        "Deposit paid = "+money(depositPaid)+"\nDeposit credited on invoice = "+money(credit)+"\nMissing credit = "+money(depositPaid)+" − "+money(credit)+" = "+money(missingAmt),missingAmt);
    } else {
      add("ok","Deposit is credited","Deposit paid "+money(depositPaid)+" and credited "+money(credit)+" on the invoice.","Paid "+money(depositPaid)+" − credited "+money(credit)+" = $0.00 missing.",null);
    }
  }

  /* 5 — double fees */
  ["permit","disposal"].forEach(function(fee){
    if(!hasI) return;
    var fl=feeLines(iText,fee);
    if(fl.length>1){
      var extra=fl.slice(1).reduce(function(s,x){return s+x.amount;},0);
      overcharge+=extra; hasCritical=true;
      add("critical",fee.charAt(0).toUpperCase()+fee.slice(1)+" fee charged "+fl.length+" times on the invoice",
        "The "+fee+" fee appears "+fl.length+" times as a charge on the one invoice. One job needs one "+fee+" fee — the extra charge(s) total "+money(extra)+".",
        fl.map(function(x,i){return "Charge "+(i+1)+": "+money(x.amount)+" — "+x.line;}).join("\n")+"\nExtra (all charges after the first) = "+money(extra),extra);
    } else if(fl.length===1){
      var propFee=hasP?feeAmount(pText,fee):null;
      if(propFee!=null && Math.abs(propFee-fl[0].amount)>0.5){
        add("warning",fee.charAt(0).toUpperCase()+fee.slice(1)+" fee differs from the proposal",
          "Proposal lists the "+fee+" fee at "+money(propFee)+"; the invoice charges "+money(fl[0].amount)+". Ask which figure is the actual receipted cost before paying the difference.",
          "Invoice "+money(fl[0].amount)+" − proposal "+money(propFee)+" = "+money(fl[0].amount-propFee),null);
      } else {
        add("ok",fee.charAt(0).toUpperCase()+fee.slice(1)+" fee charged once","The "+fee+" fee appears once on the invoice at "+money(fl[0].amount)+(propFee!=null?", matching the proposal.":"."),"Charges found on invoice: 1 × "+money(fl[0].amount)+".",null);
      }
    }
  });

  /* 6 — invoice-only charges */
  if(hasI && (hasP||hasW)){
    var others=((hasP?pText:"")+" "+(hasW?wText:"")).toLowerCase();
    var stop=["the","and","fee","charge","total","deck","labor","hours","hour","per","for","sq","ft","with","line","item","work","job","services","service","material","materials","includes","included","each","flat","rate","cost","price","paid","due"];
    invLines.forEach(function(l){
      if(l.credit||l.amount<=0) return;
      if(/permit|disposal|labor|decking|deposit/i.test(l.label)) return; /* covered by dedicated checks */
      var words=l.label.toLowerCase().replace(/[^a-z\s]/g," ").split(/\s+/).filter(function(w){return w.length>3 && stop.indexOf(w)<0;});
      var found=words.some(function(w){return others.indexOf(w)>=0;});
      if(words.length && !found){
        overcharge+=l.amount; hasCritical=true;
        add("critical","Invoice-only charge: appears in neither the proposal nor the work record",
          "\""+l.label+"\" is charged at "+money(l.amount)+" on the invoice, but nothing matching it appears in the approved proposal or the work record. Unapproved extras are the classic padding line — require written approval for this charge before paying it.",
          "Charge = "+money(l.amount)+"\nMentioned in proposal: no\nMentioned in work record: no",l.amount);
      }
    });
  }

  /* 7 — line sum vs stated total */
  if(hasI && total!=null && invLines.length){
    var diff=total-lineSum;
    figures.lineSumDiff=diff;
    if(Math.abs(diff)>0.99){
      if(diff>0){ overcharge+=diff; hasCritical=true; }
      add(diff>0?"critical":"warning","Invoice lines do not add up to the stated total",
        "Adding every invoice line (with any deposit credit subtracted) gives "+money(lineSum)+", but the invoice states a total of "+money(total)+". That is a "+money(Math.abs(diff))+" difference "+(diff>0?"in the builder's favor":"in your favor — still get a corrected invoice so the paperwork matches")+".",
        "Sum of lines = "+invLines.map(function(l){return money(l.amount);}).join(" + ").replace(/\+ -/g,"− ")+"\nStated total = "+money(total)+"\nDifference = "+money(total)+" − "+money(lineSum)+" = "+money(diff),diff>0?diff:null);
    } else {
      add("ok","Invoice arithmetic checks out","The invoice lines sum to "+money(lineSum)+" and the stated total is "+money(total)+".","Sum of lines = "+money(lineSum)+". Stated total = "+money(total)+". Difference = "+money(diff)+".",null);
    }
  }

  if(!findings.some(function(f){return f.severity==="critical"||f.severity==="warning";}) && !partial){
    /* all ok/info */
  }

  var verdict, sub;
  if(partial){
    verdict="PAY WITH FIXES";
    sub="Capped at PAY WITH FIXES because the "+missing.map(function(d){return d.name.toLowerCase();}).join(", ")+" is missing. Paste it and re-run for a full verdict.";
  } else if(hasCritical || overcharge>=100){
    verdict="DO NOT PAY YET";
    sub="The three documents disagree in ways that cost money. Fix the critical findings below — or get them explained in writing — before paying.";
  } else if(findings.some(function(f){return f.severity==="warning";}) || overcharge>0){
    verdict="PAY WITH FIXES";
    sub="No deal-breakers, but fix the items below (or get them corrected on the invoice) as part of paying.";
  } else {
    verdict="SAFE TO PAY";
    sub="On the text supplied, the proposal, work record, and invoice agree: area, materials, labor, deposit, fees, and arithmetic all cross-check. This verifies the paperwork only — not the work itself.";
  }
  return finish(verdict,sub,findings,figures,overcharge,docs);
}
function finish(verdict,sub,findings,figures,overcharge,docs){
  return {verdict:verdict,sub:sub,findings:findings,figures:figures,documentedOvercharge:Math.round(overcharge*100)/100,
    documents:docs.map(function(d){return {name:d.name,usable:d.usable,characters:(d.text||"").trim().length};}),
    generatedNote:"Text cross-check only — verifies no work performed. Not trade or legal advice."};
}

/* ---------- rendering ---------- */
var lastResult=null;
function sevBadge(s){ return s==="critical"?'<span class="badge b-crit">Critical</span>':s==="warning"?'<span class="badge b-warn">Fix</span>':s==="ok"?'<span class="badge b-ok">Checks out</span>':'<span class="badge b-info">Note</span>'; }
function render(r){
  lastResult=r;
  var box=$("verdictBox"), vt=$("verdictText");
  vt.textContent=r.verdict;
  box.className="verdict "+(r.verdict==="SAFE TO PAY"?"v-safe":r.verdict==="PAY WITH FIXES"?"v-fixes":r.verdict==="DO NOT PAY YET"?"v-dont":"v-not");
  $("verdictSub").textContent=r.sub;
  $("overchargeLine").innerHTML = r.verdict==="NOT ENOUGH TO COMPARE" ? "" :
    "Documented overcharge total: <strong>"+money(r.documentedOvercharge)+"</strong> — the sum of every dollar-quantified finding below. Material downgrades are flagged but not priced.";
  var f=r.figures, rows=[];
  function row(k,v){ if(v!=null&&v!=="") rows.push("<tr><td>"+esc(k)+"</td><td class='num'>"+esc(v)+"</td></tr>"); }
  row("Built area (work record)", f.builtSqft!=null?f.builtSqft+" sq ft":null);
  row("Billed area (invoice)", f.billedSqft!=null?f.billedSqft+" sq ft":null);
  row("Waste allowance", f.wastePct!=null?f.wastePct+"%":null);
  row("Billable area allowed", f.allowedSqft!=null?f.allowedSqft+" sq ft":null);
  row("Decking rate", f.ratePerSqft!=null?money(f.ratePerSqft)+" / sq ft":null);
  row("Labor hours recorded", f.workHours!=null?f.workHours+" hrs":null);
  row("Labor hours billed", f.billedHours!=null?f.billedHours+" hrs":null);
  row("Labor rate", f.laborRate!=null?money(f.laborRate)+" / hr":null);
  row("Labor expected (recorded × rate)", f.laborExpected!=null?money(f.laborExpected):null);
  row("Labor charged", f.laborCharge!=null?money(f.laborCharge):null);
  row("Deposit paid", f.depositPaid!=null?money(f.depositPaid):null);
  row("Deposit credited", f.depositCredit!=null?money(f.depositCredit):(f.depositPaid!=null?"$0.00":null));
  row("Sum of invoice lines", f.invoiceLineSum!=null?money(f.invoiceLineSum):null);
  row("Stated invoice total", f.statedTotal!=null?money(f.statedTotal):null);
  $("figuresWrap").innerHTML = rows.length? "<h3>Figures pulled from your three documents</h3><div style='overflow-x:auto;margin-top:12px'><table><thead><tr><th>Figure</th><th>Value</th></tr></thead><tbody>"+rows.join("")+"</tbody></table></div>":"";
  $("findings").innerHTML = r.findings.map(function(x){
    return "<div class='finding'>"+sevBadge(x.severity)+" <h3 style='display:inline'>"+esc(x.title)+"</h3><p style='margin:8px 0 0'>"+esc(x.detail)+"</p>"+(x.math?"<div class='math'>"+esc(x.math)+"</div>":"")+(x.amount!=null?"<p class='num' style='margin:8px 0 0'>Counts toward documented overcharge: "+money(x.amount)+"</p>":"")+"</div>";
  }).join("");
  /* text report */
  var L=[];
  L.push("J-Dawgs Deck & Patio Proposal, Work Record & Final Invoice Consistency Auditor\u2122");
  L.push("VERDICT: "+r.verdict);
  L.push(r.sub);
  L.push("Documented overcharge total: "+money(r.documentedOvercharge));
  L.push("");
  L.push("Documents: "+r.documents.map(function(d){return d.name+" — "+(d.usable?"usable ("+d.characters+" chars)":"missing / not usable");}).join("; "));
  L.push("");
  L.push("FINDINGS:");
  r.findings.forEach(function(x,i){
    L.push((i+1)+". ["+x.severity.toUpperCase()+"] "+x.title);
    L.push("   "+x.detail);
    if(x.math) x.math.split("\n").forEach(function(m){ L.push("   "+m); });
    if(x.amount!=null) L.push("   Counts toward documented overcharge: "+money(x.amount));
  });
  L.push("");
  L.push("Text cross-check only — verifies no work performed. Not trade or legal advice.");
  $("textReport").textContent=L.join("\n");
  $("jsonReport").textContent=JSON.stringify(r,null,2);
}
function runAudit(){ render(audit($("docProposal").value,$("docWork").value,$("docInvoice").value)); }

/* ---------- examples ---------- */
var GOOD={
proposal:[
"APPROVED PROPOSAL — Dawson Residence Deck",
"Deck area: 320 sq ft",
"Waste allowance: 10%",
"Decking material: Composite",
"Decking rate: $28.00 per sq ft",
"Railing: Aluminum railing",
"Footings: Concrete footings",
"Labor rate: $65.00 per hour",
"Estimated labor: 40 hours",
"Permit fee: $250.00",
"Disposal fee: $300.00",
"Deposit paid: $2,000.00"
].join("\n"),
work:[
"WORK RECORD — Dawson Residence Deck",
"Built deck area: 320 sq ft",
"Material installed: Composite decking",
"Railing installed: Aluminum railing",
"Footings installed: Concrete footings",
"Labor hours recorded: 40 hours",
"Labor rate: $65.00 per hour",
"Permit fee: $250.00",
"Disposal fee: $300.00",
"Deposit received: $2,000.00"
].join("\n"),
invoice:[
"FINAL INVOICE — Dawson Residence Deck",
"Billed deck area: 320 sq ft",
"Decking material billed: Composite",
"Decking — 320 sq ft at $28.00 per sq ft: $8,960.00",
"Labor — 40 hours at $65.00 per hour: $2,600.00",
"Labor hours billed: 40 hours",
"Permit fee: $250.00",
"Disposal fee: $300.00",
"Deposit credit: -$2,000.00",
"Total due: $10,110.00"
].join("\n")};
var BAD={
proposal:[
"APPROVED PROPOSAL — Miller Residence Deck",
"Deck area: 300 sq ft",
"Waste allowance: 10%",
"Decking material: Composite",
"Decking rate: $30.00 per sq ft",
"Railing: Aluminum railing",
"Footings: Concrete footings",
"Labor rate: $60.00 per hour",
"Estimated labor: 32 hours",
"Permit fee: $250.00",
"Disposal fee: $350.00",
"Deposit paid: $2,500.00"
].join("\n"),
work:[
"WORK RECORD — Miller Residence Deck",
"Built deck area: 300 sq ft",
"Material installed: Pressure-treated lumber decking",
"Railing installed: Wood railing",
"Footings installed: Concrete footings",
"Labor hours recorded: 32 hours",
"Labor rate: $60.00 per hour",
"Permit fee: $250.00",
"Disposal fee: $350.00",
"Deposit received: $2,500.00"
].join("\n"),
invoice:[
"FINAL INVOICE — Miller Residence Deck",
"Billed deck area: 360 sq ft",
"Decking material billed: Composite",
"Decking — 360 sq ft at $30.00 per sq ft: $10,800.00",
"Labor — 48 hours at $60.00 per hour: $2,880.00",
"Labor hours billed: 48 hours",
"Permit fee: $250.00",
"Permit fee — duplicate filing: $250.00",
"Disposal fee: $350.00",
"Hot tub reinforcement: $750.00",
"Total due: $15,780.00"
].join("\n")};
function loadSet(s){ $("docProposal").value=s.proposal; $("docWork").value=s.work; $("docInvoice").value=s.invoice; updateMeta(); }
function updateMeta(){
  $("metaProposal").textContent=$("docProposal").value.length+" characters";
  $("metaWork").textContent=$("docWork").value.length+" characters";
  $("metaInvoice").textContent=$("docInvoice").value.length+" characters";
}
["docProposal","docWork","docInvoice"].forEach(function(id){ $(id).addEventListener("input",updateMeta); });
$("runBtn").addEventListener("click",runAudit);
$("loadBadBtn").addEventListener("click",function(){ loadSet(BAD); });
$("loadGoodBtn").addEventListener("click",function(){ loadSet(GOOD); });
$("loadBadBtn2").addEventListener("click",function(){ loadSet(BAD); runAudit(); window.scrollTo({top:0,behavior:"smooth"}); });
$("loadGoodBtn2").addEventListener("click",function(){ loadSet(GOOD); runAudit(); window.scrollTo({top:0,behavior:"smooth"}); });
$("clearBtn").addEventListener("click",function(){ loadSet({proposal:"",work:"",invoice:""}); });
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-deck-patio-proposal-work-record-final-invoice-consistency-auditortm',
  name: 'J-Dawgs Deck & Patio Proposal, Work Record & Final Invoice Consistency Auditor',
  description: 'Cross-checks a deck & patio proposal against its work record and final invoice into one pay verdict, with arithmetic shown across all pastes.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
