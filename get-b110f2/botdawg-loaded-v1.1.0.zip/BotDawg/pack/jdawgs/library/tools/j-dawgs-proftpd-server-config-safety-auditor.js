'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs ProFTPD Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var DANGEROUS = [
        '# Dangerous example - shared test config (do not deploy)',
        'ServerName "J-Dawgs Test FTP Server"',
        'ServerType standalone',
        'Port 21',
        'ServerIdent on "ProFTPD 1.3.6 Server (Debian) ready"',
        'RootLogin on',
        'TLSEngine off',
        'RequireValidShell off',
        'Umask 000',
        '<Anonymous /srv/ftp>',
        '  User ftp',
        '  Group ftp',
        '  UserAlias anonymous ftp',
        '  <Limit WRITE>',
        '    AllowAll',
        '  </Limit>',
        '</Anonymous>'
      ].join("\n") + "\n";

      var CLEAN = [
        '# Hardened example',
        'ServerName "J-Dawgs FTP Server"',
        'ServerType standalone',
        'Port 21',
        'ServerIdent off',
        'RootLogin off',
        'RequireValidShell on',
        'Umask 022',
        'MaxInstances 30',
        'MaxLoginAttempts 3',
        'TimeoutIdle 600',
        'DenyFilter \\*.*/',
        'DefaultAddress 192.0.2.10',
        'TLSEngine on',
        'TLSRequired on',
        'TLSProtocol TLSv1.2 TLSv1.3',
        'TLSCACertificateFile /etc/ssl/certs/ca-certificates.crt',
        'TLSCertificateFile /etc/ssl/certs/proftpd.pem',
        'WtmpLog on',
        'TransferLog /var/log/proftpd/transfer.log',
        '<Anonymous /srv/ftp/pub>',
        '  User ftp',
        '  Group ftp',
        '  <Limit WRITE>',
        '    DenyAll',
        '  </Limit>',
        '</Anonymous>'
      ].join("\n") + "\n";

      var KNOWN = {};
      ("ServerName ServerType ServerIdent Port DefaultAddress DefaultServer RootLogin " +
       "RequireValidShell Umask User Group MaxInstances MaxLoginAttempts MaxClients MaxClientsPerHost " +
       "MaxClientsPerUser MaxHostsPerUser TimeoutIdle TimeoutLogin TimeoutNoTransfer TimeoutStalled " +
       "DenyFilter AllowFilter WtmpLog TransferLog SystemLog ExtendedLog DebugLevel ScoreboardFile PidFile " +
       "AuthPAM AuthPAMConfig AuthOrder AuthUserFile AuthGroupFile DefaultRoot AllowChroot " +
       "TLSEngine TLSRequired TLSProtocol TLSOptions TLSVerifyClient TLSLog TLSRenegotiate " +
       "TLSCACertificateFile TLSCertificateFile TLSCertificateKeyFile TLSRSACertificateFile TLSRSACertificateKeyFile TLSDHParamFile " +
       "PassivePorts MasqueradeAddress AllowOverwrite AllowStoreRestart AllowRetrieveRestart HiddenStores " +
       "DeleteAbortedStores DisplayLogin DisplayQuit DisplayChdir DirFakeUser DirFakeGroup DirFakeMode " +
       "ListOptions UseReverseDNS IdentLookups TimesGMT Include LoadModule ModulePath " +
       "AllowAll DenyAll Allow Deny AllowUser DenyUser AllowGroup DenyGroup Order Satisfy " +
       "UserAlias AnonRequirePassword RequirePartialAuth CDPath IgnoreHidden ShowSymlinks " +
       "PersistentPasswd MultilineRFC2228 DeferWelcome AccessDenyMsg AccessGrantMsg " +
       "CommandBufferSize CreateHome DefaultTransferMode DisplayConnect DisplayGoAway " +
       "FSCachePolicy FSOptions HiddenFile HideFiles HideGroup HideNoAccess HideUser " +
       "LogFormat MaxCommandRate MaxConnectionRate MaxConnectionsPerHost " +
       "PathAllowFilter PathDenyFilter RatioFile Ratios " +
       "ServerAdmin ServerAlias SetEnv TCPAccessFiles TCPAccessSyslogFiles TCPBackLog TCPGroupAccess TCPUserAccess " +
       "UseFtpUsers UseGlobbing TLSServerNameIndication AuthUsingAlias DefaultDisplay " +
       "SQLAuthTypes SQLBackend SQLEngine SQLConnectInfo SQLUserInfo SQLGroupInfo SQLAuthenticate " +
       "LDAPServer LDAPBindDN LDAPUsers LDAPGroups LDAPDoAuth LDAPDefaultAuthScheme " +
       "RadiusEngine RadiusAcctServer RadiusAuthServer RadiusUserInfo " +
       "Classes Class AddonModule AllowForeignAddress CapabilitiesEngine CapabilitiesSet " +
       "DelayEngine DelayOnEvent DelayTable SFTPHostKey SFTPEngine SSHHostKey " +
       "BanEngine BanLog BanTable ControlsEngine ControlsACLs ControlsLog ControlsMaxClients " +
       "FactsAdvertise FactsOptions FileRatioMsg GroupRatioMsg HostRatioMsg UserRatioMsg " +
       "TransferRate AllowSymlinks RescanStor DirFakeGroupMode").split(" ").forEach(function (n) {
        KNOWN[n.toLowerCase()] = true;
      });

      var WRITE_CMDS = { WRITE: 1, ALL: 1, STOR: 1, STOU: 1, MKD: 1, XMKD: 1, RMD: 1, XRMD: 1, DELE: 1, RNFR: 1, APPE: 1 };
      var SCALARS = { port: 1, servername: 1, rootlogin: 1, tlsengine: 1, tlsrequired: 1, requirevalidshell: 1,
                      maxinstances: 1, defaultaddress: 1, umask: 1, timeoutidle: 1, maxloginattempts: 1,
                      servertype: 1, masqueradeaddress: 1, wtmplog: 1, serverident: 1 };

      function isSecretName(name) { return /passwd|password|keyfile/i.test(name); }

      function stripComment(line) {
        var inQ = false;
        for (var i = 0; i < line.length; i++) {
          var c = line.charAt(i);
          if (c === '"') inQ = !inQ;
          if (c === '#' && !inQ && (i === 0 || /\s/.test(line.charAt(i - 1)))) return line.slice(0, i);
        }
        return line;
      }

      function tokenize(rest) {
        var out = [], cur = "", inQ = false;
        for (var i = 0; i < rest.length; i++) {
          var c = rest.charAt(i);
          if (c === '"') { inQ = !inQ; continue; }
          if (!inQ && /\s/.test(c)) { if (cur) { out.push(cur); cur = ""; } continue; }
          cur += c;
        }
        if (cur) out.push(cur);
        return out;
      }

      function parse(text) {
        var lines = text.split(/\r?\n/);
        var directives = [], blocks = [], errors = [], stack = [];
        function innermost(type) {
          for (var i = stack.length - 1; i >= 0; i--) if (stack[i].type === type) return stack[i];
          return null;
        }
        for (var idx = 0; idx < lines.length; idx++) {
          var ln = idx + 1;
          var t = stripComment(lines[idx]).replace(/^\s+|\s+$/g, "");
          if (!t) continue;
          var closeM = t.match(/^<\/\s*([A-Za-z][A-Za-z0-9]*)\s*>$/);
          if (closeM) {
            var cname = closeM[1].toLowerCase();
            if (stack.length && stack[stack.length - 1].type === cname) { stack.pop().endLine = ln; }
            else {
              var found = -1;
              for (var j = stack.length - 1; j >= 0; j--) if (stack[j].type === cname) { found = j; break; }
              if (found >= 0) {
                errors.push({ line: ln, name: "</" + closeM[1] + ">",
                  msg: "Closing tag </" + closeM[1] + "> on line " + ln + " does not match the block opened on line " + stack[stack.length - 1].line + "." });
                stack.length = found;
              } else {
                errors.push({ line: ln, name: "</" + closeM[1] + ">",
                  msg: "Closing tag </" + closeM[1] + "> on line " + ln + " has no matching opening block." });
              }
            }
            continue;
          }
          var openM = t.match(/^<\s*([A-Za-z][A-Za-z0-9]*)\s*([^>]*)>$/);
          if (openM) {
            var b = { type: openM[1].toLowerCase(), typeName: openM[1], args: tokenize(openM[2] || ""),
                      line: ln, endLine: null, allowAll: false, denyAll: false,
                      parentAnon: innermost("anonymous") };
            blocks.push(b); stack.push(b);
            continue;
          }
          var dirM = t.match(/^([A-Za-z][A-Za-z0-9]*)\s*(.*)$/);
          if (!dirM) {
            errors.push({ line: ln, name: "Unparseable line", msg: "Line " + ln + " could not be read as a directive or block tag." });
            continue;
          }
          var rec = { name: dirM[1], key: dirM[1].toLowerCase(), args: dirM[2] || "",
                      tokens: tokenize(dirM[2] || ""), line: ln,
                      anon: innermost("anonymous"), limit: innermost("limit"),
                      ifmodule: innermost("ifmodule"), topLevel: stack.length === 0,
                      inGlobal: !!innermost("global") };
          directives.push(rec);
          if (rec.limit) {
            if (rec.key === "allowall") rec.limit.allowAll = true;
            if (rec.key === "denyall") rec.limit.denyAll = true;
          }
        }
        stack.forEach(function (b) {
          errors.push({ line: b.line, name: "<" + b.typeName + ">",
            msg: "Block <" + b.typeName + "> opened on line " + b.line + " is never closed." });
        });
        return { lines: lines.length, directives: directives, blocks: blocks, errors: errors };
      }

      function audit(text) {
        var p = parse(text);
        var F = [];
        function add(sev, line, name, msg, fix) { F.push({ sev: sev, line: line, name: name, msg: msg, fix: fix || "" }); }
        function find(key) { var r = []; p.directives.forEach(function (d) { if (d.key === key) r.push(d); }); return r; }
        function first(key) { var r = find(key); return r.length ? r[0] : null; }
        function val(d) { return (d.tokens[0] || "").toLowerCase(); }

        p.errors.forEach(function (e) {
          add("BLOCKER", e.line, e.name, "NOT PARSED — " + e.msg,
              "Close every <Anonymous>, <Limit>, <Global>, and <IfModule> block in order, then audit again.");
        });

        // Secrets — name and line only, value never copied into any output.
        p.directives.forEach(function (d) {
          if (isSecretName(d.name) && d.args.replace(/\s/g, "") !== "") {
            add("WARNING", d.line, d.name,
              "Secret-bearing directive " + d.name + " carries an inline value on line " + d.line + ". The value is not shown in this report.",
              "Move secrets out of the shared config where possible, restrict the file's permissions (owner read-only), and rotate the value if this file was shared.");
          }
        });

        // RootLogin
        var rl = first("rootlogin");
        if (rl) {
          if (val(rl) === "on") add("BLOCKER", rl.line, "RootLogin", "RootLogin is on — the root account can log in over FTP.",
            "Set RootLogin off. Root should only ever authenticate through a local console or SSH with key auth.");
          else add("INFO", rl.line, "RootLogin", "RootLogin is off — root FTP logins are refused.", "");
        } else add("INFO", null, "RootLogin", "RootLogin is not set; ProFTPD's default is off, but stating it makes the posture explicit.", "Add RootLogin off so the setting is deliberate, not inherited.");

        // Anonymous blocks
        var anonBlocks = p.blocks.filter(function (b) { return b.type === "anonymous"; });
        var limitBlocks = p.blocks.filter(function (b) { return b.type === "limit"; });
        anonBlocks.forEach(function (ab) {
          var inner = limitBlocks.filter(function (lb) { return lb.parentAnon === ab; });
          var allowWrite = null, denyWrite = null;
          inner.forEach(function (lb) {
            var cmds = lb.args.map(function (a) { return a.toUpperCase(); });
            var touchesWrite = cmds.some(function (c) { return WRITE_CMDS[c]; });
            if (!touchesWrite) return;
            if (lb.allowAll) allowWrite = lb;
            if (lb.denyAll) denyWrite = lb;
          });
          if (allowWrite) {
            add("BLOCKER", ab.line, "<Anonymous>",
              "Anonymous block opened on line " + ab.line + " allows writes: the <Limit> on line " + allowWrite.line + " allows write commands (STORE / STOU / MKD / RMD / DELE / RNFR) for unauthenticated users.",
              "Make anonymous access read-only: put <Limit WRITE> with DenyAll inside the <Anonymous> block, or remove the anonymous block entirely.");
          } else if (!denyWrite) {
            add("BLOCKER", ab.line, "<Anonymous>",
              "Anonymous block opened on line " + ab.line + " has no <Limit> denying write commands, so anonymous write access depends on inherited defaults.",
              "Add an explicit deny inside the block: <Limit WRITE> DenyAll </Limit> — anonymous access should be read-only by construction, not by default.");
          } else {
            add("INFO", ab.line, "<Anonymous>",
              "Anonymous block opened on line " + ab.line + " explicitly denies writes (line " + denyWrite.line + ") — anonymous access is read-only.", "");
          }
        });
        p.directives.forEach(function (d) {
          if (d.key === "useralias" && d.tokens.some(function (t) { return t.toLowerCase() === "anonymous"; })) {
            add("WARNING", d.line, "UserAlias",
              "UserAlias maps the name \"anonymous\" to a real account on line " + d.line + " — anonymous FTP is enabled here. Confirm the target account is locked down and read-only.",
              "Keep the alias only if anonymous access is intended, and pair it with a deny-write <Limit> in the <Anonymous> block.");
          }
        });

        // TLS
        var tls = first("tlsengine");
        var tlsModBlock = p.blocks.some(function (b) {
          return b.type === "ifmodule" && b.args.join(" ").toLowerCase().indexOf("mod_tls") >= 0;
        });
        var tlsOn = false;
        if (tls) {
          if (val(tls) === "off") add("WARNING", tls.line, "TLSEngine",
            "TLSEngine is off — logins and file transfers travel in clear text.",
            "Set TLSEngine on, configure certificate files, and set TLSRequired on.");
          else if (val(tls) === "on") { tlsOn = true; add("INFO", tls.line, "TLSEngine", "TLSEngine is on.", ""); }
        } else if (!tlsModBlock) {
          add("WARNING", null, "TLSEngine",
            "TLSEngine is not set and there is no <IfModule mod_tls.c> section — TLS state is off or unclear, so credentials can cross the network in clear text.",
            "Load mod_tls, set TLSEngine on, configure certificate files, and set TLSRequired on.");
        } else {
          add("INFO", null, "TLSEngine", "TLSEngine is not set at top level, but a <IfModule mod_tls.c> section is present — check that TLSEngine on appears inside it.", "");
        }
        if (tlsOn) {
          var tr = first("tlsrequired");
          if (!tr) add("WARNING", null, "TLSRequired",
            "TLS is on but TLSRequired is not set — clients can still fall back to clear-text sessions.",
            "Set TLSRequired on so every session must be encrypted.");
          else if (val(tr) === "off") add("WARNING", tr.line, "TLSRequired",
            "TLSRequired is off — TLS is available but not enforced, so clients can still log in unencrypted.",
            "Set TLSRequired on.");
          else add("INFO", tr.line, "TLSRequired", "TLSRequired is on — unencrypted sessions are refused.", "");
        }
        var tp = first("tlsprotocol");
        if (tp) {
          var weak = tp.tokens.filter(function (t) {
            var u = t.toUpperCase().replace("+", "").replace("-", "");
            return u === "SSLV3" || u === "SSLV2" || u === "TLSV1.0" || u === "TLSV1.1" || u === "TLSV1";
          });
          if (weak.length) add("WARNING", tp.line, "TLSProtocol",
            "TLSProtocol still allows weak protocol versions: " + weak.join(", ") + ".",
            "Restrict TLSProtocol to TLSv1.2 and TLSv1.3.");
          else add("INFO", tp.line, "TLSProtocol", "TLSProtocol does not allow SSLv3, TLSv1.0, or TLSv1.1.", "");
        }
        p.directives.forEach(function (d) {
          if (/certificatefile/i.test(d.name)) {
            add("INFO", d.line, d.name, d.name + " is configured (value not shown).", "");
          }
        });

        // Auth
        var ao = first("authorder");
        if (ao && ao.tokens.length === 1 && ao.tokens[0].toLowerCase() === "mod_auth_pam.c") {
          add("INFO", ao.line, "AuthOrder",
            "AuthOrder names only mod_auth_pam.c — authentication depends entirely on PAM and the host's system accounts.",
            "");
        }
        var ap = first("authpam");
        if (ap && val(ap) === "off" && !first("authuserfile")) {
          add("WARNING", ap.line, "AuthPAM",
            "AuthPAM is off and no AuthUserFile is configured — the authentication source is unclear.",
            "Either leave AuthPAM on or configure AuthUserFile/AuthGroupFile so it is obvious where accounts come from.");
        }
        var rvs = first("requirevalidshell");
        if (rvs) {
          if (val(rvs) === "off") add("WARNING", rvs.line, "RequireValidShell",
            "RequireValidShell is off — accounts with invalid shells (including service accounts) can log in over FTP.",
            "Set RequireValidShell on, or list only intended FTP accounts in a dedicated AuthUserFile.");
          else add("INFO", rvs.line, "RequireValidShell", "RequireValidShell is on.", "");
        } else add("INFO", null, "RequireValidShell", "RequireValidShell is not set; ProFTPD's default is on.", "");

        // Exposure
        var port = first("port");
        if (port) add("INFO", port.line, "Port", "Port is set to " + (port.tokens[0] || "?") + (String(port.tokens[0]) === "21" ? " — the standard FTP port, expected to be reachable and scanned." : "."), "");
        else add("INFO", null, "Port", "Port is not set; ProFTPD defaults to 21.", "");
        var si = first("serverident");
        if (si) {
          if (val(si) === "on" && si.tokens.length > 1) add("WARNING", si.line, "ServerIdent",
            "ServerIdent is on with extra banner text — the greeting discloses server/version information to anyone who connects.",
            "Set ServerIdent off, or on with a bare generic greeting that carries no version detail.");
          else if (val(si) === "on") add("INFO", si.line, "ServerIdent", "ServerIdent is on with a minimal greeting.", "");
          else add("INFO", si.line, "ServerIdent", "ServerIdent is off — no banner information is disclosed.", "");
        } else add("INFO", null, "ServerIdent", "ServerIdent is not set; ProFTPD's default greeting can disclose version detail.", "Set ServerIdent off, or on with a bare generic greeting.");
        var pp = first("passiveports");
        if (pp && !first("masqueradeaddress")) {
          add("INFO", pp.line, "PassivePorts",
            "PassivePorts is configured but MasqueradeAddress is not set — passive transfers can fail or expose an internal address behind NAT.", "");
        }
        var da = first("defaultaddress");
        add("INFO", da ? da.line : null, "DefaultAddress",
          da ? "DefaultAddress is set — the server binds the address named there (value not shown)."
             : "DefaultAddress is not set — the server listens on all interfaces by default. Binding one address narrows exposure.", "");

        // Global write Limit
        limitBlocks.forEach(function (lb) {
          if (lb.parentAnon || !lb.allowAll) return;
          var insideDirOrAnonCtx = false;
          var cmds = lb.args.map(function (a) { return a.toUpperCase(); });
          if (!(cmds.indexOf("WRITE") >= 0 || cmds.indexOf("ALL") >= 0)) return;
          add("WARNING", lb.line, "<Limit>",
            "A <Limit " + lb.args.join(" ") + "> outside any <Anonymous> block allows access at a broad scope on line " + lb.line + " — write commands may be open to every authenticated user.",
            "Scope write permission to the directories and users that need it instead of allowing it globally.");
        });

        // Umask
        var um = first("umask");
        if (um) {
          var m = (um.tokens[0] || "").match(/^[0-7]{3,4}$/);
          if (m) {
            var u = parseInt(um.tokens[0], 8);
            if ((u & 2) === 0) add("WARNING", um.line, "Umask",
              "Umask " + um.tokens[0] + " leaves uploaded files world-writable.",
              "Use Umask 022 (or stricter, such as 027) so uploads are not writable by every local account.");
            else add("INFO", um.line, "Umask", "Umask " + um.tokens[0] + " does not leave uploads world-writable.", "");
          }
        }

        // Limits & logging presence
        [["maxinstances", "MaxInstances", "no cap on child processes — a connection flood can fork without limit. Set MaxInstances to a sane ceiling."],
         ["maxloginattempts", "MaxLoginAttempts", "no cap on password guesses per connection. Set MaxLoginAttempts (3 is typical) to slow credential guessing."],
         ["timeoutidle", "TimeoutIdle", "idle sessions are not timed out by an explicit setting. Set TimeoutIdle so abandoned sessions do not linger."],
         ["denyfilter", "DenyFilter", "a filter rejecting dangerous command arguments is a cheap extra layer. Consider DenyFilter \\*.*/"]]
        .forEach(function (row) {
          var d = first(row[0]);
          if (d) add("INFO", d.line, row[1], row[1] + " is set.", "");
          else add("INFO", null, row[1], row[1] + " is not set — " + row[2], "");
        });
        var wl = first("wtmplog");
        add("INFO", wl ? wl.line : null, "WtmpLog", wl ? "WtmpLog is configured." : "WtmpLog is not configured — login history logging is left to defaults.", "");
        var tl = first("transferlog");
        add("INFO", tl ? tl.line : null, "TransferLog", tl ? "TransferLog is configured (path not shown)." : "TransferLog is not configured — without a transfer log there is no record of what was uploaded or downloaded.", "");

        // Duplicates at global scope
        var seen = {};
        p.directives.forEach(function (d) {
          if (!d.topLevel || !SCALARS[d.key]) return;
          (seen[d.key] = seen[d.key] || []).push(d);
        });
        Object.keys(seen).forEach(function (k) {
          var arr = seen[k];
          if (arr.length < 2) return;
          var last = arr[arr.length - 1];
          var linesList = arr.map(function (d) { return d.line; }).join(" and ");
          var valNote = isSecretName(last.name) ? " (value not shown)" :
            " — the last value wins: " + (last.tokens.join(" ").slice(0, 40) || "(empty)");
          add("WARNING", arr[0].line, last.name,
            last.name + " is defined " + arr.length + " times at global scope, on lines " + linesList + valNote + ".",
            "Keep exactly one " + last.name + " at global scope so the effective setting is never in doubt.");
        });

        // Unknown directives
        var unknown = p.directives.filter(function (d) { return !KNOWN[d.key]; });
        if (unknown.length) {
          var listing = unknown.map(function (d) { return d.name + " (line " + d.line + ")"; }).join(", ");
          add("INFO", unknown[0].line, "Unrecognized directives",
            unknown.length + " directive(s) not graded by this tool: " + listing + ". They may belong to modules this auditor does not cover; review them by hand.", "");
        }

        var rank = { BLOCKER: 0, WARNING: 1, INFO: 2 };
        F.sort(function (a, b) {
          if (rank[a.sev] !== rank[b.sev]) return rank[a.sev] - rank[b.sev];
          var la = a.line === null ? 99999 : a.line, lb = b.line === null ? 99999 : b.line;
          return la - lb;
        });
        var counts = { BLOCKER: 0, WARNING: 0, INFO: 0 };
        F.forEach(function (f) { counts[f.sev]++; });
        var verdict;
        if (p.errors.length) verdict = "NOT PARSED";
        else if (counts.BLOCKER > 0) verdict = "DO NOT DEPLOY";
        else if (counts.WARNING > 0) verdict = "DEPLOY WITH FIXES";
        else verdict = "SAFE TO DEPLOY";
        return { verdict: verdict, findings: F, counts: counts, lines: p.lines, parseErrors: p.errors.length };
      }

      function buildReport(r) {
        var out = [];
        out.push("J-Dawgs ProFTPD Server Config Safety Auditor - Report");
        out.push("Verdict: " + r.verdict);
        out.push("Counts: " + r.counts.BLOCKER + " BLOCKER, " + r.counts.WARNING + " WARNING, " + r.counts.INFO + " INFO across " + r.lines + " lines read.");
        out.push("Note: secret values are never shown; findings name the directive and line only.");
        out.push("");
        if (!r.findings.length) out.push("No findings.");
        r.findings.forEach(function (f) {
          out.push("[" + f.sev + "] Line " + (f.line === null ? "-" : f.line) + " - " + f.name + ": " + f.msg);
          if (f.fix) out.push("    Fix: " + f.fix);
        });
        return out.join("\n") + "\n";
      }

      function esc(s) {
        return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-proftpd-server-config-safety-auditor',
  name: 'J-Dawgs ProFTPD Server Config Safety Auditor',
  description: 'ProFTPD\'s own validation needs a running install and stops at load validity; ours grades a pasted proftpd.conf offline — anonymous-login posture, DefaultRoot chroot, passive-port range and TLS posture, secrets flagged by key name only — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
