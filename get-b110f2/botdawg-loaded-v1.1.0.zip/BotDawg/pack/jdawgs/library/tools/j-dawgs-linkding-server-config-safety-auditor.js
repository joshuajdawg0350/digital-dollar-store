'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Linkding Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var KNOWN = {
          "LD_HOST":1,"HOST":1,"LD_SERVER_HOST":1,"SERVER_HOST":1,
          "LD_SERVER_PORT":1,"LD_PORT":1,"PORT":1,
          "LD_CSRF_TRUSTED_ORIGINS":1,"CSRF_TRUSTED_ORIGINS":1,
          "LD_DISABLE_URL_VALIDATION":1,
          "LD_ENABLE_AUTH_PROXY":1,"LD_AUTH_PROXY_USERNAME_HEADER":1,"LD_AUTH_PROXY_LOGOUT_URL":1,
          "LD_SUPERUSER_NAME":1,"LD_SUPERUSER_PASSWORD":1,
          "LD_DB_ENGINE":1,"DATABASE_URL":1,"LD_DATABASE_URL":1,
          "LD_DB_HOST":1,"LD_DB_PORT":1,"LD_DB_NAME":1,"LD_DB_USER":1,"LD_DB_PASSWORD":1,"DB_PASSWORD":1,
          "LD_OPTIONS":1,"LD_REQUEST_TIMEOUT":1,
          "LD_DISABLE_BACKGROUND_TASKS":1,"LD_BACKGROUND_TASKS":1,
          "LD_DEBUG":1,"DEBUG":1
        };
        var WEAK_WORDS = ["password","changeme","change-me","letmein","admin","secret","example","linkding","qwerty","123456","12345678","welcome","default","test123","passw0rd"];
        var DEFAULT_USERS = {"admin":1,"root":1,"linkding":1,"user":1,"administrator":1,"superuser":1};
        var SEV_ORDER = {"CRITICAL":0,"HIGH":1,"MEDIUM":2,"LOW":3,"NOT PARSED":4,"INFO":5};

        function $(id){ return document.getElementById(id); }
        function isTrue(v){ return /^(true|1|yes|on)$/i.test(String(v).trim()); }
        function isFalse(v){ return /^(false|0|no|off)$/i.test(String(v).trim()); }
        function isSecretKey(key){ return /(PASSWORD|PASSWD|SECRET|TOKEN|API_?KEY|PRIVATE|CREDENTIAL)/i.test(key); }
        function unquote(v){
          v = String(v).trim();
          if (v.length >= 2 && ((v.charAt(0)==='"' && v.charAt(v.length-1)==='"') || (v.charAt(0)==="'" && v.charAt(v.length-1)==="'"))) {
            return v.slice(1,-1);
          }
          return v;
        }
        function esc(s){
          return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
        }

        function parseConfig(text){
          var rawLines = String(text).split(/\r?\n/);
          var entries = [];   // {line, key, value}
          var byKey = {};     // key -> entry (last wins)
          var malformed = []; // line numbers
          var totalNonBlank = 0;
          for (var i=0;i<rawLines.length;i++){
            var lineNo = i+1;
            var raw = rawLines[i];
            var t = raw.trim();
            if (t === "" || t.charAt(0) === "#") continue;
            totalNonBlank++;
            var m = t.match(/^(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/);
            if (!m){ malformed.push(lineNo); continue; }
            var entry = { line: lineNo, key: m[1], value: unquote(m[2]) };
            entries.push(entry);
            byKey[entry.key] = entry;
          }
          return { entries: entries, byKey: byKey, malformed: malformed, totalLines: rawLines.length, totalNonBlank: totalNonBlank };
        }

        function audit(text){
          var parsed = parseConfig(text);
          var findings = [];
          function add(sev, line, key, msg, fix){
            findings.push({ severity: sev, line: line, key: key, message: msg, fix: fix || "" });
          }
          var byKey = parsed.byKey;

          var recognized = 0;
          parsed.entries.forEach(function(e){ if (KNOWN[e.key]) recognized++; });

          // Host binding
          var hostEntry = byKey["LD_HOST"] || byKey["LD_SERVER_HOST"] || byKey["HOST"] || byKey["SERVER_HOST"] || null;
          var hostAll = false, hostLine = null;
          if (hostEntry){
            hostLine = hostEntry.line;
            var hv = hostEntry.value.trim();
            if (hv === "0.0.0.0" || hv === "::" || hv === "[::]" || hv === "*"){
              hostAll = true;
              add("CRITICAL", hostEntry.line, hostEntry.key,
                "Server is bound to all network interfaces (" + hv + "). Anyone who can reach this machine — LAN, VPN, or the open internet if the port is forwarded — can reach the Linkding login and every other check below gets worse.",
                "Bind to loopback (127.0.0.1) and reach it through a reverse proxy or SSH tunnel, or bind only to the one private interface it should serve.");
            }
          } else if (recognized > 0){
            add("MEDIUM", null, "LD_HOST",
              "No host binding is set in the pasted config. Depending on how the server is launched, the default bind may listen on all interfaces.",
              "Set LD_HOST=127.0.0.1 (or one specific private address) explicitly so the bind never depends on a default.");
          }

          // Port
          var portEntry = byKey["LD_SERVER_PORT"] || byKey["LD_PORT"] || byKey["PORT"] || null;
          if (portEntry){
            var pv = portEntry.value.trim();
            if (!/^\d+$/.test(pv) || +pv < 1 || +pv > 65535){
              add("MEDIUM", portEntry.line, portEntry.key,
                "Port value is not a valid port number (1–65535). The server may fail to start or fall back to a default port you did not choose.",
                "Set LD_SERVER_PORT to a valid number, e.g. 9090.");
            }
          }

          // Superuser name
          var suName = byKey["LD_SUPERUSER_NAME"];
          if (suName && DEFAULT_USERS[suName.value.trim().toLowerCase()]){
            add("HIGH", suName.line, "LD_SUPERUSER_NAME",
              "Superuser name is the default/guessable value \"" + suName.value.trim() + "\". Attackers try the obvious admin names first, so the password carries the whole defense.",
              "Use a non-obvious superuser name that you do not use anywhere else.");
          }

          // Superuser password — value is NEVER rendered; length and pattern class only.
          var suPw = byKey["LD_SUPERUSER_PASSWORD"];
          if (suPw){
            var pwLen = suPw.value.length;
            var lower = suPw.value.toLowerCase();
            var weak = false;
            for (var w=0; w<WEAK_WORDS.length; w++){ if (lower.indexOf(WEAK_WORDS[w]) !== -1){ weak = true; break; } }
            if (pwLen < 12 || weak){
              var reasons = [];
              if (pwLen < 12) reasons.push("only " + pwLen + " characters long");
              if (weak) reasons.push("matches a known example/weak pattern");
              add("CRITICAL", suPw.line, "LD_SUPERUSER_PASSWORD",
                "Superuser password is " + reasons.join(" and ") + ". This is the master account for the whole bookmark archive. (Value never shown — key, line, and length only: length " + pwLen + ".)",
                "Use a unique password of at least 16 characters from a password manager, and never reuse an example value.");
            } else if (pwLen < 16){
              add("HIGH", suPw.line, "LD_SUPERUSER_PASSWORD",
                "Superuser password is " + pwLen + " characters — above the bare minimum but below the 16-character floor this auditor recommends for a master account. (Value never shown.)",
                "Lengthen it to 16+ characters.");
            }
          }

          // CSRF trusted origins
          var csrf = byKey["LD_CSRF_TRUSTED_ORIGINS"] || byKey["CSRF_TRUSTED_ORIGINS"];
          if (csrf){
            var cv = csrf.value;
            var tokens = cv.split(/[\s,]+/).filter(function(x){ return x.length; });
            var wildcard = tokens.some(function(x){ return x === "*" || x.indexOf("*") !== -1; });
            if (wildcard){
              add("CRITICAL", csrf.line, csrf.key,
                "CSRF trusted origins are set to a wildcard. The browser same-origin defense is effectively switched off: any website a logged-in user visits can be trusted to submit forms as them.",
                "List the exact origins only, e.g. https://bookmarks.example.com — one per real address, no wildcards.");
            } else {
              var plainHttp = tokens.filter(function(x){ return /^http:\/\//i.test(x) && !/^http:\/\/(localhost|127\.0\.0\.1|\[::1\])(:\d+)?$/i.test(x); });
              if (plainHttp.length){
                add("HIGH", csrf.line, csrf.key,
                  "CSRF trusted origins include plain http:// address(es). On an unencrypted origin, session traffic can be read or altered in transit.",
                  "Serve Linkding over HTTPS and trust only the https:// origin.");
              }
            }
          }

          // URL validation
          var duv = byKey["LD_DISABLE_URL_VALIDATION"];
          if (duv && isTrue(duv.value)){
            add("CRITICAL", duv.line, "LD_DISABLE_URL_VALIDATION",
              "URL validation is disabled. Linkding will accept bookmark URLs without checking them, so malformed, deceptive, or hostile URLs (including ones aimed at internal services) go straight into the archive.",
              "Set LD_DISABLE_URL_VALIDATION=False and leave validation on unless you are debugging one specific import.");
          }

          // Auth proxy
          var eap = byKey["LD_ENABLE_AUTH_PROXY"];
          if (eap && isTrue(eap.value)){
            if (hostAll){
              add("CRITICAL", eap.line, "LD_ENABLE_AUTH_PROXY",
                "Auth-proxy mode is ON while the server is bound to all interfaces (line " + hostLine + "). Linkding trusts the identity header from its proxy — but with a direct network path to the port, anyone can send that header themselves and sign in as any user, including the superuser.",
                "Turn LD_ENABLE_AUTH_PROXY off, or bind the app to loopback so only the real proxy can reach it, and have the proxy strip the header from incoming requests before setting it.");
            } else {
              add("HIGH", eap.line, "LD_ENABLE_AUTH_PROXY",
                "Auth-proxy mode is ON: Linkding trusts the identity header (see LD_AUTH_PROXY_USERNAME_HEADER) from whatever fronts it. That is only safe if the app port is unreachable except through a proxy that strips and re-sets that header.",
                "Confirm the app cannot be reached directly, and that the proxy overwrites the header on every request.");
            }
            if (!byKey["LD_AUTH_PROXY_USERNAME_HEADER"]){
              add("MEDIUM", eap.line, "LD_AUTH_PROXY_USERNAME_HEADER",
                "Auth-proxy mode is on but no LD_AUTH_PROXY_USERNAME_HEADER is set in the pasted config, so it is unclear which header identity is being trusted from.",
                "Set LD_AUTH_PROXY_USERNAME_HEADER explicitly to the header your proxy sets, and document it next to the config.");
            }
          }

          // Database: DATABASE_URL embedded password — value NEVER rendered; password length only.
          ["DATABASE_URL","LD_DATABASE_URL"].forEach(function(k){
            var e = byKey[k];
            if (!e) return;
            var m = e.value.match(/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\/[^:\/@\s]+:([^@\s]+)@/);
            if (m){
              var dbPwLen = m[1].length;
              add("HIGH", e.line, k,
                k + " embeds a plaintext database password (password length " + dbPwLen + "; the URL and password are never shown here). Anyone who can read this file — a backup, a screenshot, a leaked repo — owns the database.",
                "Move the credential into a secret store or a root-only env file, rotate the database password, and keep the URL out of shared config.");
            }
          });
          // Standalone DB password keys
          ["LD_DB_PASSWORD","DB_PASSWORD"].forEach(function(k){
            var e = byKey[k];
            if (!e) return;
            add("HIGH", e.line, k,
              "A plaintext database password sits in the config under " + k + " (length " + e.value.length + "; value never shown). Plaintext in a pasted/shared file is the most common way database credentials leak.",
              "Load it from a secret store or root-only file instead, and rotate it if this file was ever shared.");
          });
          // Generic secret-shaped keys (excluding ones already handled)
          parsed.entries.forEach(function(e){
            if (!isSecretKey(e.key)) return;
            if (e.key === "LD_SUPERUSER_PASSWORD" || e.key === "LD_DB_PASSWORD" || e.key === "DB_PASSWORD") return;
            if (e.value.length > 0 && e.value.length < 12){
              add("HIGH", e.line, e.key,
                "Secret under " + e.key + " is only " + e.value.length + " characters long. (Value never shown.) Short secrets are guessable secrets.",
                "Replace it with a generated secret of 16+ characters.");
            } else if (e.value.length >= 12){
              add("INFO", e.line, e.key,
                "Secret present under " + e.key + " (length " + e.value.length + "; value never shown). Length looks adequate — the remaining risk is where this file is stored and who can read it.",
                "Keep this file out of repos, screenshots, and shared folders.");
            }
          });

          // Debug
          var dbg = byKey["LD_DEBUG"] || byKey["DEBUG"];
          if (dbg && isTrue(dbg.value)){
            add("HIGH", dbg.line, dbg.key,
              "Debug mode is on. Debug output leaks paths, settings, and stack traces to anyone who can trigger an error page.",
              "Set debug off for any deployment other people can reach.");
          }

          // Request timeout
          var rt = byKey["LD_REQUEST_TIMEOUT"];
          if (rt){
            var rv = rt.value.trim();
            if (!/^\d+(\.\d+)?$/.test(rv)){
              add("MEDIUM", rt.line, "LD_REQUEST_TIMEOUT",
                "LD_REQUEST_TIMEOUT is not a number, so the effective timeout is whatever the default happens to be.",
                "Set a plain number of seconds, e.g. 30.");
            } else if (+rv < 10){
              add("MEDIUM", rt.line, "LD_REQUEST_TIMEOUT",
                "LD_REQUEST_TIMEOUT is " + rv + "s — very short. Imports, metadata fetches, and link previews to slow sites will time out and fail in ways that look like random breakage.",
                "Raise it to around 30s unless you have a measured reason to keep it low.");
            } else if (+rv > 300){
              add("LOW", rt.line, "LD_REQUEST_TIMEOUT",
                "LD_REQUEST_TIMEOUT is " + rv + "s — very long. A hung upstream can tie up workers for minutes at a time.",
                "Bring it back toward 30–60s.");
            }
          }

          // Background tasks disabled
          var dbt = byKey["LD_DISABLE_BACKGROUND_TASKS"];
          if (dbt && isTrue(dbt.value)){
            add("MEDIUM", dbt.line, "LD_DISABLE_BACKGROUND_TASKS",
              "Background tasks are disabled. Imports, link previews, and scheduled checks will silently stall or never run.",
              "Leave background tasks enabled unless a separate worker process is intentionally handling them.");
          }
          var opts = byKey["LD_OPTIONS"];
          if (opts && /background/i.test(opts.value) && /(disable|\"false\"|\bfalse\b)/i.test(opts.value)){
            add("MEDIUM", opts.line, "LD_OPTIONS",
              "LD_OPTIONS appears to switch background work off. That silently stalls imports, previews, and scheduled checks.",
              "Check the LD_OPTIONS blob and keep background tasks on.");
          }

          // Unknown keys -> INFO
          parsed.entries.forEach(function(e){
            if (!KNOWN[e.key]){
              add("INFO", e.line, e.key,
                "Unrecognized setting " + e.key + " — not a Linkding option this auditor knows, so it was counted but not graded. A typo'd key is silently ignored by the server, which is how a fix you think you applied never takes effect.",
                "Check the spelling against the Linkding options list.");
            }
          });

          // Malformed lines -> NOT PARSED (content never rendered)
          parsed.malformed.forEach(function(ln){
            add("NOT PARSED", ln, "—",
              "Line " + ln + " is not a KEY=VALUE setting and was skipped. Nothing on this line was graded — if it was meant to be a setting, the server will ignore it too.",
              "Rewrite it as KEY=VALUE, or delete it if it is a stray note.");
          });

          findings.sort(function(a,b){
            var d = SEV_ORDER[a.severity] - SEV_ORDER[b.severity];
            if (d !== 0) return d;
            return (a.line || 0) - (b.line || 0);
          });

          var counts = { CRITICAL:0, HIGH:0, MEDIUM:0, LOW:0, "NOT PARSED":0, INFO:0 };
          findings.forEach(function(f){ counts[f.severity]++; });

          var verdict, verdictClass, verdictSub;
          if (recognized === 0){
            verdict = "NOT ENOUGH TO GRADE";
            verdictClass = "none";
            verdictSub = parsed.totalNonBlank === 0
              ? "The paste was empty. Paste a Linkding config with recognizable settings and audit again."
              : "No recognizable Linkding settings were found in the pasted text, so no honest grade exists. Paste the environment config itself — not a screenshot description, log, or prose about the server.";
          } else if (counts.CRITICAL > 0){
            verdict = "DO NOT DEPLOY";
            verdictClass = "crit";
            verdictSub = counts.CRITICAL + " critical finding(s) would expose this server the moment it starts. Fix every critical item, then re-audit.";
          } else if (counts.HIGH > 0 || counts.MEDIUM > 0 || parsed.malformed.length > 0){
            verdict = "DEPLOY WITH FIXES";
            verdictClass = "warn";
            var bits = [];
            if (counts.HIGH) bits.push(counts.HIGH + " high");
            if (counts.MEDIUM) bits.push(counts.MEDIUM + " medium");
            if (parsed.malformed.length) bits.push(parsed.malformed.length + " unparsed line(s)");
            verdictSub = "No critical findings, but " + bits.join(", ") + " to fix before this faces anyone else. Re-audit after fixing.";
          } else {
            verdict = "SAFE TO DEPLOY";
            verdictClass = "ok";
            verdictSub = "No blocking findings in the pasted settings. This grades the pasted text only — your firewall, proxy, and file permissions still have to hold up their end.";
          }

          return {
            verdict: verdict, verdictClass: verdictClass, verdictSub: verdictSub,
            findings: findings, counts: counts,
            stats: {
              totalLines: parsed.totalLines,
              settingsParsed: parsed.entries.length,
              recognized: recognized,
              malformed: parsed.malformed.length
            }
          };
        }

        function buildReport(r){
          var out = [];
          out.push("J-Dawgs Linkding Server Config Safety Auditor — Audit Report");
          out.push("Verdict: " + r.verdict);
          out.push("Settings parsed: " + r.stats.settingsParsed + " | Recognized Linkding settings: " + r.stats.recognized + " | Lines not parsed: " + r.stats.malformed);
          out.push("Findings: " + r.counts.CRITICAL + " critical, " + r.counts.HIGH + " high, " + r.counts.MEDIUM + " medium, " + r.counts.LOW + " low, " + r.counts["NOT PARSED"] + " not parsed, " + r.counts.INFO + " info");
          out.push("");
          if (!r.findings.length){
            out.push("No findings. Nothing in the pasted settings tripped a check.");
          } else {
            r.findings.forEach(function(f, i){
              var where = (f.line ? "Line " + f.line : "No line (setting absent)");
              out.push((i+1) + ". [" + f.severity + "] " + where + " — " + f.key + ": " + f.message);
              if (f.fix) out.push("   Fix: " + f.fix);
            });
          }
          out.push("");
          out.push("Notes: Heuristic text audit of the pasted config only. No server was contacted. Secrets are reported by key name, line, and length only — secret values never appear in this report.");
          return out.join("\n");
        }

        function buildJson(r){
          return JSON.stringify({
            tool: "J-Dawgs Linkding Server Config Safety Auditor",
            verdict: r.verdict,
            stats: r.stats,
            counts: r.counts,
            findings: r.findings.map(function(f){
              return { severity: f.severity, line: f.line, key: f.key, message: f.message, fix: f.fix };
            }),
            secretsNote: "Secrets are reported by key name, line, and length only. Secret values are never included."
          }, null, 2);
        }

        var lastReport = "", lastJson = "";

        function runAudit(){
          var text = $("configInput").value;
          var r = audit(text);
          $("result").classList.remove("hidden");
          $("emptyHint").classList.add("hidden");
          var box = $("verdictBox");
          box.className = "verdict " + r.verdictClass;
          $("verdictText").textContent = r.verdict;
          $("verdictSub").textContent = r.verdictSub;
          $("statsRow").innerHTML =
            '<span class="stat">Settings parsed: <b>' + r.stats.settingsParsed + "</b></span>" +
            '<span class="stat">Recognized: <b>' + r.stats.recognized + "</b></span>" +
            '<span class="stat">Not parsed: <b>' + r.stats.malformed + "</b></span>" +
            '<span class="stat">Critical: <b>' + r.counts.CRITICAL + "</b></span>" +
            '<span class="stat">High: <b>' + r.counts.HIGH + "</b></span>" +
            '<span class="stat">Medium: <b>' + r.counts.MEDIUM + "</b></span>" +
            '<span class="stat">Low: <b>' + r.counts.LOW + "</b></span>" +
            '<span class="stat">Info: <b>' + r.counts.INFO + "</b></span>";
          var list = $("findingsList");
          if (!r.findings.length){
            list.innerHTML = '<p class="small">No findings — nothing in the pasted settings tripped a check.</p>';
          } else {
            list.innerHTML = r.findings.map(function(f){
              var sevClass = f.severity.replace(" ", "");
              var head = (f.line ? "Line " + f.line : "Setting absent") + (f.key && f.key !== "—" ? ' · <code>' + esc(f.key) + "</code>" : "");
              return '<div class="finding"><span class="sev ' + sevClass + '">' + esc(f.severity) + '</span>' +
                '<div class="fbody"><div class="fhead">' + head + '</div>' +
                '<div class="fmsg">' + esc(f.message) + "</div>" +
                (f.fix ? '<div class="ffix"><b>Fix:</b> ' + esc(f.fix) + "</div>" : "") +
                "</div></div>";
            }).join("");
          }
          lastReport = buildReport(r);
          lastJson = buildJson(r);
          $("reportPre").textContent = lastReport;
          $("jsonPre").textContent = lastJson;
        }

        function loadFromPre(id){
          $("configInput").value = $(id).textContent.replace(/^\n+|\n+$/g, "");
          $("configInput").focus();
          window.scrollTo({ top: $("configInput").getBoundingClientRect().top + window.scrollY - 24, behavior: "smooth" });
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-linkding-server-config-safety-auditor',
  name: 'J-Dawgs Linkding Server Config Safety Auditor',
  description: 'Host tools only tell you the server started; ours grades a pasted Linkding server config offline into one deploy verdict — secrets by key name/line/length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
