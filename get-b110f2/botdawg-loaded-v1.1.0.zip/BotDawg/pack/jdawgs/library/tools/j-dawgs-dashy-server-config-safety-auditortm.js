'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Dashy Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Sample configs (single source of truth: display + audit + tests) ---------- */
      var RISKY = [
        "pageInfo:",
        "  title: Home Dashboard",
        "appConfig:",
        "  theme: colorful",
        "  auth:",
        "    enableGuestAccess: true",
        "    users:",
        "      - user: admin",
        "        hash: password123",
        "sections:",
        "- name: Media",
        "  items:",
        "    - title: Plex",
        "      url: http://192.168.1.20:32400",
        "      statusCheck: true",
        "      statusCheckUrl: http://192.168.1.20:32400/identity",
        "    - title: Weather",
        "      widget: weather",
        "      options:",
        "        apiKey: 9f8e7d6c5b4a"
      ].join("\n");

      var HARDENED = [
        "pageInfo:",
        "  title: Home Dashboard",
        "appConfig:",
        "  theme: nord",
        "  auth:",
        "    enableGuestAccess: false",
        "    users:",
        "      - user: joshua",
        "        hash: $2b$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy",
        "sections:",
        "- name: Media",
        "  items:",
        "    - title: Plex",
        "      url: https://plex.example.com",
        "      statusCheck: true",
        "      statusCheckUrl: https://plex.example.com/identity",
        "    - title: Weather",
        "      widget: weather",
        "      options:",
        "        apiKey: ${OPENWEATHER_API_KEY}"
      ].join("\n");

      /* ---------- Auditor ----------
         A finding NEVER carries a secret value: only key name, line, and length. */
      var SECRET_KEY = /(password|passwd|pwd|secret|token|api[-_]?key|access[-_]?key|private[-_]?key|(^|_)hash$)/i;
      var DEFAULT_WORDS = ["password","password123","123456","12345678","12345","admin","changeme","letmein","dashy","example","test","secret","default","passw0rd","qwerty","root","user","demo","welcome1"];
      var SEV_RANK = { CRITICAL:0, HIGH:1, MEDIUM:2, LOW:3 };

      function cleanValue(raw){
        var v = String(raw == null ? "" : raw);
        var hashIdx = v.indexOf(" #");
        if (hashIdx > -1) v = v.slice(0, hashIdx);
        v = v.trim();
        if (v.length >= 2 && ((v.charAt(0) === '"' && v.charAt(v.length-1) === '"') || (v.charAt(0) === "'" && v.charAt(v.length-1) === "'"))) {
          v = v.slice(1, -1);
        }
        return v.trim();
      }
      function isEnvRef(v){ return /^\$\{?[A-Za-z_][A-Za-z0-9_]*\}?$/.test(v) || v.indexOf("${") === 0; }
      function isHashed(v){
        return /^\$2[aby]\$\d{2}\$/.test(v) || /^sha(256|512)[:$]/i.test(v) || /^[a-f0-9]{64}$/i.test(v) || /^[a-f0-9]{128}$/i.test(v);
      }
      function isDefaultish(v){
        var lv = v.toLowerCase();
        if (DEFAULT_WORDS.indexOf(lv) > -1) return true;
        return lv.indexOf("password") > -1 || lv.indexOf("changeme") > -1 || lv.indexOf("example") > -1;
      }
      function hostOf(url){
        var m = url.match(/^https?:\/\/([^\/:?#\s]+)/i);
        return m ? m[1].toLowerCase() : "";
      }
      function isInternalHost(h){
        if (!h) return false;
        if (h === "localhost" || h === "::1" || h === "127.0.0.1") return true;
        if (/^192\.168\./.test(h) || /^10\./.test(h)) return true;
        var m = h.match(/^172\.(\d{1,3})\./);
        if (m && +m[1] >= 16 && +m[1] <= 31) return true;
        if (/^127\./.test(h)) return true;
        if (/\.local$/.test(h)) return true;
        if (h.indexOf(".") === -1) return true; /* single-label host: an internal service name */
        return false;
      }
      function isLocalHost(h){ return h === "localhost" || h === "127.0.0.1" || h === "::1"; }

      function audit(text){
        var raw = String(text == null ? "" : text);
        var lines = raw.split(/\r?\n/);
        var findings = [];
        function add(line, severity, check, key, length, detail){
          findings.push({ line: line, severity: severity, check: check, key: key || null, length: (typeof length === "number" ? length : null), detail: detail });
        }

        /* Gradeability: need at least 3 non-empty lines and a recognizable config marker. */
        var nonEmpty = lines.filter(function(l){ return l.trim().length > 0; });
        var envLines = lines.filter(function(l){ return /^\s*-?\s*[A-Za-z_][A-Za-z0-9_]*\s*=/.test(l); }).length;
        var kvLines = lines.filter(function(l){ return /^\s*-?\s*[A-Za-z0-9_'\"-]+\s*:/.test(l); }).length;
        var hasMarker = /(appConfig|pageInfo|sections\s*:|services\s*:|auth\s*:|environment\s*:|image\s*:|widget|enableGuestAccess)/.test(raw) || envLines >= 2;
        if (nonEmpty.length < 3 || (!hasMarker && kvLines < 3)) {
          return { verdict: "NOT ENOUGH TO GRADE", gradeable: false, findings: [],
                   counts: { CRITICAL:0, HIGH:0, MEDIUM:0, LOW:0 },
                   reason: "The pasted text does not look like a Dashy conf.yml, .env, or docker-compose file yet — too little recognizable config structure to grade honestly." };
        }

        var isDashyConf = /(appConfig|pageInfo|sections\s*:|enableGuestAccess)/.test(raw);
        var authLine = 0, hasUsers = false, guestLine = 0;
        var i, line, m;

        for (i = 0; i < lines.length; i++){
          line = lines[i];
          var ln = i + 1;
          if (/^\s*auth\s*:/.test(line) && !authLine) authLine = ln;
          if (/users\s*:/.test(line) || /-\s*user\s*:/.test(line)) hasUsers = true;
          if (/enableGuestAccess\s*:\s*true/i.test(line)) guestLine = ln;
        }

        /* --- Authentication checks --- */
        if (guestLine) {
          add(guestLine, "CRITICAL", "Guest access enabled",
              "enableGuestAccess", null,
              "appConfig.auth.enableGuestAccess is true, so anyone who can reach the dashboard can open it without signing in. Set it to false.");
        }
        if (isDashyConf && !authLine) {
          add(1, "CRITICAL", "Authentication missing", "auth", null,
              "This Dashy config has no auth block at all, so the dashboard has no sign-in protection. Add appConfig.auth with at least one user.");
        } else if (isDashyConf && authLine && !hasUsers) {
          add(authLine, "CRITICAL", "No auth users defined", "auth.users", null,
              "An auth block exists but defines no users, so there is nobody who can sign in — and nothing stopping anyone else. Add at least one user with a hashed credential.");
        }

        /* --- Per-line checks --- */
        for (i = 0; i < lines.length; i++){
          line = lines[i];
          var n = i + 1;
          var trimmed = line.replace(/^\s*(-\s*)?/, "");

          /* key/value extraction: YAML "key: value" or env "KEY=value" */
          var key = null, value = null;
          var ym = trimmed.match(/^([A-Za-z0-9_'\"-]{1,80})\s*:\s*(.*)$/);
          var em = trimmed.match(/^([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/);
          if (ym) { key = ym[1].replace(/['"]/g, ""); value = cleanValue(ym[2]); }
          else if (em) { key = em[1]; value = cleanValue(em[2]); }

          /* Secret-bearing keys */
          if (key && SECRET_KEY.test(key) && value !== null && value !== "") {
            if (!isEnvRef(value) && !isHashed(value)) {
              var isCred = /(password|passwd|pwd|hash)/i.test(key);
              if (isDefaultish(value)) {
                add(n, "CRITICAL", isCred ? "Default or example password" : "Default or example secret", key, value.length,
                    "Key \"" + key + "\" holds a default or example value (length " + value.length + ") that anyone can guess. Replace it with a long random value stored outside the config.");
              }
              if (isCred) {
                add(n, "HIGH", "Plaintext password in config", key, value.length,
                    "Key \"" + key + "\" stores a credential as readable plaintext (length " + value.length + ") instead of a bcrypt/SHA hash. Anyone who sees this file owns the account.");
              } else {
                add(n, "HIGH", /api[-_]?key/i.test(key) ? "API key in plaintext (widget/service)" : "Secret in plaintext", key, value.length,
                    "Key \"" + key + "\" holds a plaintext value of length " + value.length + " right in the config. Move it to an environment variable and reference it as ${...} instead.");
              }
              if (value.length < 12) {
                add(n, "MEDIUM", "Short secret", key, value.length,
                    "Key \"" + key + "\" is only " + value.length + " characters long. Secrets under 12 characters fall to guessing fast — use a long random value.");
              }
            }
          }

          /* URLs */
          var urls = line.match(/https?:\/\/[^\s'"\])]+/g) || [];
          var onStatusLine = /(statusCheck|statusCheckUrl|health)/i.test(line);
          for (var u = 0; u < urls.length; u++){
            var url = urls[u], host = hostOf(url), internal = isInternalHost(host);
            if (/^http:\/\//i.test(url)) {
              add(n, isLocalHost(host) ? "LOW" : "MEDIUM", "Plain HTTP URL", key, null,
                  "Line " + n + " uses an http:// address, so traffic to it (and anything typed into it) travels unencrypted. Switch it to https://.");
            }
            if (internal) {
              if (onStatusLine) {
                add(n, "HIGH", "Status-check / health endpoint exposes internal URL", key, null,
                    "Line " + n + " points a status-check or health endpoint at an internal (private-network) service address. Dashy serves this config to every visitor's browser, so the internal address leaks. Keep internal checks behind the server, not in the shipped config.");
              } else {
                add(n, "MEDIUM", "Internal service URL in config", key, null,
                    "Line " + n + " names an internal (private-network) service address. The config is delivered to visitors' browsers, so internal addresses should not be listed here.");
              }
            }
          }
        }

        findings.sort(function(a, b){ return (a.line - b.line) || (SEV_RANK[a.severity] - SEV_RANK[b.severity]); });
        var counts = { CRITICAL:0, HIGH:0, MEDIUM:0, LOW:0 };
        findings.forEach(function(f){ counts[f.severity]++; });

        var verdict, reason;
        if (counts.CRITICAL > 0) {
          verdict = "DO NOT DEPLOY";
          reason = counts.CRITICAL + " critical problem(s) would leave this dashboard open or guessable the moment it goes live. Fix those first — nothing else matters until then.";
        } else if (findings.length > 0) {
          verdict = "DEPLOY WITH FIXES";
          reason = "Nothing here is an open door, but " + findings.length + " finding(s) should be fixed before this faces the internet.";
        } else {
          verdict = "SAFE TO DEPLOY";
          reason = "Authentication is on with real users, credentials are hashed or pulled from the environment, and no plaintext keys or internal addresses were found in the pasted config.";
        }
        return { verdict: verdict, gradeable: true, findings: findings, counts: counts, reason: reason };
      }

      function reportText(r){
        var out = [];
        out.push("J-Dawgs Dashy Server Config Safety Auditor\u2122 — audit report");
        out.push("Verdict: " + r.verdict);
        out.push(r.reason);
        out.push("Findings: " + r.findings.length + " (Critical " + r.counts.CRITICAL + ", High " + r.counts.HIGH + ", Medium " + r.counts.MEDIUM + ", Low " + r.counts.LOW + ")");
        out.push("Secrets are listed by key name, line, and length only — values are never shown.");
        r.findings.forEach(function(f){
          var s = "- Line " + f.line + " [" + f.severity + "] " + f.check + ": " + f.detail;
          if (f.key) s += " (key: " + f.key + (typeof f.length === "number" ? ", length: " + f.length : "") + ")";
          out.push(s);
        });
        return out.join("\n");
      }
      function reportJson(r){
        return JSON.stringify({
          tool: "J-Dawgs Dashy Server Config Safety Auditor\u2122",
          verdict: r.verdict,
          gradeable: r.gradeable,
          reason: r.reason,
          counts: r.counts,
          findings: r.findings.map(function(f){
            return { line: f.line, severity: f.severity, check: f.check, key: f.key, length: f.length, detail: f.detail };
          }),
          note: "Secrets are reported by key name, line, and length only. Secret values never appear in this export."
        }, null, 2);
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-dashy-server-config-safety-auditortm',
  name: 'J-Dawgs Dashy Server Config Safety Auditor',
  description: 'Host tools only tell you the server started; ours grades a pasted Dashy config (conf.yml/.env/compose text) offline into one deploy verdict — secrets by key name/line/length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
