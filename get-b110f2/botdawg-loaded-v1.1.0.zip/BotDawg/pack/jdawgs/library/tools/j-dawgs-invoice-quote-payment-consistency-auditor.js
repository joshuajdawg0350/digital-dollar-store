'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Invoice, Quote & Payment Confirmation Consistency Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";
/* ---------- examples ---------- */
var WORKED = {
quote:
"QUOTE / ESTIMATE\n" +
"From: Acme Builders LLC\n" +
"Quote No: Q-2081\n" +
"Quote Date: November 1, 2026\n" +
"Bill To: J. Miller\n" +
"\n" +
"Line items:\n" +
"Concrete pour — 1 × $657.41 = $657.41\n" +
"Framing labor — 1 × $500.00 = $500.00\n" +
"\n" +
"Subtotal: $1,157.41\n" +
"Tax (8%): $92.59\n" +
"Total: $1,250.00\n",
invoice:
"INVOICE\n" +
"From: Acme Builders LLC\n" +
"Invoice No: INV-2081\n" +
"Invoice Date: November 3, 2026\n" +
"Due Date: November 20, 2026\n" +
"Bill To: J. Miller\n" +
"\n" +
"Line items:\n" +
"Concrete pour — 1 × $657.41 = $657.41\n" +
"Framing labor — 1 × $500.00 = $500.00\n" +
"Permit and inspection fee — 1 × $92.59 = $92.59\n" +
"\n" +
"Subtotal: $1,250.00\n" +
"Tax (10%): $125.00\n" +
"Total: $1,375.00\n",
payment:
"PAYMENT CONFIRMATION / RECEIPT\n" +
"Payee: Acme Builders LLC\n" +
"Invoice No: INV-2081\n" +
"Payment Date: November 5, 2026\n" +
"Amount Paid: $1,375.00\n" +
"Method: Card\n" +
"Payment received in full for Invoice No: INV-2081.\n"
};
var CLEAN = {
quote:
"QUOTE / ESTIMATE\n" +
"From: Acme Builders LLC\n" +
"Quote No: Q-3100\n" +
"Quote Date: October 10, 2026\n" +
"Bill To: J. Miller\n" +
"\n" +
"Line items:\n" +
"Garden wall build — 1 × $600.00 = $600.00\n" +
"Stone materials — 2 × $200.00 = $400.00\n" +
"\n" +
"Subtotal: $1,000.00\n" +
"Tax (8%): $80.00\n" +
"Total: $1,080.00\n",
invoice:
"INVOICE\n" +
"From: Acme Builders LLC\n" +
"Invoice No: INV-3100\n" +
"Invoice Date: October 12, 2026\n" +
"Due Date: October 26, 2026\n" +
"Bill To: J. Miller\n" +
"\n" +
"Line items:\n" +
"Garden wall build — 1 × $600.00 = $600.00\n" +
"Stone materials — 2 × $200.00 = $400.00\n" +
"\n" +
"Subtotal: $1,000.00\n" +
"Tax (8%): $80.00\n" +
"Total: $1,080.00\n",
payment:
"PAYMENT CONFIRMATION / RECEIPT\n" +
"Payee: Acme Builders LLC\n" +
"Invoice No: INV-3100\n" +
"Payment Date: October 14, 2026\n" +
"Amount Paid: $1,080.00\n" +
"Method: Card\n" +
"Payment received in full for Invoice No: INV-3100.\n"
};

/* ---------- helpers ---------- */
function toCents(numStr){
  var v = parseFloat(String(numStr).replace(/,/g,""));
  if (isNaN(v)) return null;
  return Math.round(v * 100);
}
function fmt(cents, sym){
  if (cents === null || cents === undefined) return "NOT PARSED";
  var s = sym || "$";
  var neg = cents < 0; var a = Math.abs(cents);
  var dollars = Math.floor(a / 100), c = a % 100;
  var dstr = String(dollars).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return (neg ? "-" : "") + s + dstr + "." + (c < 10 ? "0" : "") + c;
}
function fmtSigned(cents, sym){
  if (cents === null || cents === undefined) return "NOT PARSED";
  return (cents > 0 ? "+" : "") + fmt(cents, sym);
}
function moneyIn(text){
  var s = String(text);
  var m = s.match(/([$€£])\s?(\d{1,3}(?:,\d{3})*(?:\.\d{1,2})?|\d+(?:\.\d{1,2})?)/);
  if (m) return { cents: toCents(m[2]), symbol: m[1], code: null, raw: m[0] };
  var cm = s.match(/\b(USD|EUR|GBP|CAD|AUD)\s?(\d{1,3}(?:,\d{3})*(?:\.\d{1,2})?|\d+(?:\.\d{1,2})?)/);
  if (cm) return { cents: toCents(cm[2]), symbol: null, code: cm[1], raw: cm[0] };
  var dm = s.match(/\b(\d{1,3}(?:,\d{3})+\.\d{2}|\d+\.\d{2})\b/);
  if (dm) return { cents: toCents(dm[1]), symbol: null, code: null, raw: dm[0] };
  return null;
}
function currencyOf(text){
  var mi = moneyIn(text);
  if (mi){
    if (mi.code) return mi.code;
    if (mi.symbol === "$") return "USD ($)";
    if (mi.symbol === "€") return "EUR (€)";
    if (mi.symbol === "£") return "GBP (£)";
  }
  var cm = String(text).match(/\b(USD|EUR|GBP|CAD|AUD)\b/);
  if (cm) return cm[1];
  if (/\$/.test(text)) return "USD ($)";
  if (/€/.test(text)) return "EUR (€)";
  if (/£/.test(text)) return "GBP (£)";
  return null;
}
var MONTHS = {january:0,february:1,march:2,april:3,may:4,june:5,july:6,august:7,september:8,october:9,november:10,december:11,
  jan:0,feb:1,mar:2,apr:3,jun:5,jul:6,aug:7,sep:8,sept:8,oct:9,nov:10,dec:11};
function parseDateStr(s){
  var m = s.match(/\b(January|February|March|April|May|June|July|August|September|October|November|December|Jan\.?|Feb\.?|Mar\.?|Apr\.?|Jun\.?|Jul\.?|Aug\.?|Sep\.?|Sept\.?|Oct\.?|Nov\.?|Dec\.?)\s+(\d{1,2}),?\s+(\d{4})\b/i);
  if (m){
    var mon = MONTHS[m[1].toLowerCase().replace(/\./g,"")];
    if (mon !== undefined) return { ms: Date.UTC(+m[3], mon, +m[2]), raw: m[0] };
  }
  m = s.match(/\b(\d{4})-(\d{2})-(\d{2})\b/);
  if (m) return { ms: Date.UTC(+m[1], +m[2]-1, +m[3]), raw: m[0] };
  m = s.match(/\b(\d{1,2})\/(\d{1,2})\/(\d{4})\b/);
  if (m) return { ms: Date.UTC(+m[3], +m[1]-1, +m[2]), raw: m[0] };
  return null;
}
function dateLabel(ms){
  if (ms === null || ms === undefined) return "NOT PARSED";
  var d = new Date(ms);
  var names = ["January","February","March","April","May","June","July","August","September","October","November","December"];
  return names[d.getUTCMonth()] + " " + d.getUTCDate() + ", " + d.getUTCFullYear();
}
function normName(s){
  return String(s).toLowerCase().replace(/[^a-z0-9 ]+/g," ").replace(/\s+/g," ").trim();
}
function esc(s){
  return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
}

/* ---------- extraction ---------- */
var SKIP_LINE = /subtotal|grand total|total due|amount due|balance due|amount paid|total paid|^total\b|tax\b|date|from:|payee:|seller:|vendor:|bill to|billed to|invoice no|invoice number|quote no|quote number|method:|payment received|thank you|line items/i;

function extractItems(lines){
  var items = [];
  var reA = /^(.+?)\s*[—–-]?\s*(\d+(?:\.\d+)?)\s*[×xX]\s*\$?([\d,]+(?:\.\d{1,2})?)\s*=\s*\$?([\d,]+\.\d{1,2})\s*$/;
  var reB = /^(.+?)\s*[—–-]\s*\$([\d,]+\.\d{1,2})\s*$/;
  var reC = /^(.+?)\s{2,}\$?([\d,]+\.\d{1,2})\s*$/;
  lines.forEach(function(line){
    var t = line.trim();
    if (!t || SKIP_LINE.test(t) || /%/.test(t)) return;
    var m = t.match(reA);
    if (m){
      items.push({ name: m[1].replace(/^[•\-*\d.)\s]+/, "").trim(), qty: parseFloat(m[2]), unitCents: toCents(m[3]), amountCents: toCents(m[4]) });
      return;
    }
    m = t.match(reB);
    if (m && m[1].trim().length > 1){ items.push({ name: m[1].trim(), qty: null, unitCents: null, amountCents: toCents(m[2]) }); return; }
    m = t.match(reC);
    if (m && m[1].trim().length > 1 && !/:/.test(m[1])){ items.push({ name: m[1].trim(), qty: null, unitCents: null, amountCents: toCents(m[2]) }); }
  });
  return items;
}

function extract(text, kind){
  var d = { kind: kind, present: !!(text && text.trim()), totalCents: null, totalLine: null, currency: null,
    subtotalCents: null, taxCents: null, taxRate: null, items: [], seller: null, invoiceNo: null,
    invoiceDate: null, dueDate: null, paymentDate: null, docDate: null };
  if (!d.present) return d;
  var lines = text.split(/\r?\n/);
  lines.forEach(function(line){
    var low = line.toLowerCase();
    if (/subtotal/.test(low)){ var mi = moneyIn(line); if (mi) d.subtotalCents = mi.cents; }
    if (/tax/.test(low)){
      var mi2 = moneyIn(line); if (mi2 && d.taxCents === null) d.taxCents = mi2.cents;
      var rm = line.match(/(\d+(?:\.\d+)?)\s*%/); if (rm && d.taxRate === null) d.taxRate = parseFloat(rm[1]);
    }
    if (/(invoice\s*(?:no\.?|number|#))/.test(low) && !d.invoiceNo){
      var im = line.match(/invoice\s*(?:no\.?|number|#)\s*[:#]?\s*([A-Za-z0-9][A-Za-z0-9\-\/]*)/i);
      if (im) d.invoiceNo = im[1];
    }
    var sm = line.match(/^\s*(?:from|seller|payee|vendor|billed by|issued by)\s*:\s*(.+)$/i);
    if (sm && !d.seller) d.seller = sm[1].trim();
    if (/due/.test(low) && d.dueDate === null){ var dd = parseDateStr(line); if (dd) d.dueDate = dd; }
    if (/(payment date|paid on|date paid)/.test(low) && d.paymentDate === null){ var pd = parseDateStr(line); if (pd) d.paymentDate = pd; }
    if (/invoice date/.test(low) && d.invoiceDate === null){ var idd = parseDateStr(line); if (idd) d.invoiceDate = idd; }
  });
  /* total: priority grand total > total due > amount due > balance due > amount paid > total */
  var labels = [/grand\s*total/i, /total\s*due/i, /amount\s*due/i, /balance\s*due/i, /amount\s*paid/i, /total\s*paid/i, /\btotal\b/i];
  for (var li = 0; li < labels.length && d.totalCents === null; li++){
    for (var i = 0; i < lines.length; i++){
      if (/subtotal/i.test(lines[i])) continue;
      if (labels[li].test(lines[i])){
        var tm = moneyIn(lines[i]);
        if (tm){ d.totalCents = tm.cents; d.totalLine = lines[i].trim(); break; }
      }
    }
  }
  if (d.taxRate === null){
    var anyRate = text.match(/(\d+(?:\.\d+)?)\s*%/);
    if (anyRate && /tax|vat|gst/i.test(text)) d.taxRate = parseFloat(anyRate[1]);
  }
  if (d.docDate === null){ var fd = parseDateStr(text); if (fd) d.docDate = fd; }
  if (kind === "invoice" && d.invoiceDate === null) d.invoiceDate = d.docDate;
  if (kind === "payment" && d.paymentDate === null) d.paymentDate = d.docDate;
  d.currency = currencyOf(d.totalLine || text);
  d.items = extractItems(lines);
  return d;
}

/* ---------- audit ---------- */
var DOCNAMES = { quote: "Quote", invoice: "Invoice", payment: "Payment confirmation" };

function audit(qText, iText, pText){
  var docs = { quote: extract(qText, "quote"), invoice: extract(iText, "invoice"), payment: extract(pText, "payment") };
  var keys = ["quote","invoice","payment"];
  var provided = keys.filter(function(k){ return docs[k].present; });
  var findings = [];
  function add(sev, check, msg, arith){ findings.push({ severity: sev, check: check, message: msg, arithmetic: arith || null }); }

  /* single-document arithmetic */
  keys.forEach(function(k){
    var d = docs[k]; if (!d.present) return;
    var nm = DOCNAMES[k];
    if (d.items.length){
      var sum = d.items.reduce(function(a,it){ return a + it.amountCents; }, 0);
      var parts = d.items.map(function(it){ return fmt(it.amountCents); }).join(" + ");
      if (d.subtotalCents !== null && sum !== d.subtotalCents){
        add("major", "Line items vs subtotal (" + nm + ")",
          nm + " line items do not add up to its stated subtotal.",
          parts + " = " + fmt(sum) + "  ·  stated subtotal " + fmt(d.subtotalCents) + "  ·  difference " + fmtSigned(sum - d.subtotalCents));
      }
      if (d.totalCents !== null && d.subtotalCents === null && d.taxCents === null && sum !== d.totalCents){
        add("major", "Line items vs total (" + nm + ")",
          nm + " line items do not add up to its stated total.",
          parts + " = " + fmt(sum) + "  ·  stated total " + fmt(d.totalCents) + "  ·  difference " + fmtSigned(sum - d.totalCents));
      }
      d.items.forEach(function(it){
        if (it.qty !== null && it.unitCents !== null){
          var expect = Math.round(it.qty * it.unitCents);
          if (expect !== it.amountCents){
            add("major", "Quantity × unit price (" + nm + ")",
              "“" + it.name + "” in the " + nm.toLowerCase() + ": quantity × unit price does not equal the line amount.",
              it.qty + " × " + fmt(it.unitCents) + " = " + fmt(expect) + "  ·  line shows " + fmt(it.amountCents) + "  ·  difference " + fmtSigned(it.amountCents - expect));
          }
        }
      });
    }
    if (d.subtotalCents !== null && d.taxCents !== null && d.totalCents !== null){
      var st = d.subtotalCents + d.taxCents;
      if (st !== d.totalCents){
        add("major", "Subtotal + tax vs total (" + nm + ")",
          nm + " subtotal plus its tax does not equal its stated total.",
          fmt(d.subtotalCents) + " + " + fmt(d.taxCents) + " = " + fmt(st) + "  ·  stated total " + fmt(d.totalCents) + "  ·  difference " + fmtSigned(d.totalCents - st));
      } else {
        add("ok", "Subtotal + tax (" + nm + ")",
          nm + " subtotal + tax equals its stated total.",
          fmt(d.subtotalCents) + " + " + fmt(d.taxCents) + " = " + fmt(d.totalCents));
      }
    }
    if (d.subtotalCents !== null && d.taxCents !== null && d.taxRate !== null){
      var expTax = Math.round(d.subtotalCents * d.taxRate / 100);
      if (Math.abs(expTax - d.taxCents) > 1){
        add("major", "Tax rate × subtotal (" + nm + ")",
          nm + " tax amount does not match its own stated rate applied to its subtotal.",
          d.taxRate + "% × " + fmt(d.subtotalCents) + " = " + fmt(expTax) + "  ·  tax shown " + fmt(d.taxCents) + "  ·  difference " + fmtSigned(d.taxCents - expTax));
      }
    }
  });

  var verdict, verdictClass, why;
  if (provided.length === 0){
    return { docs: docs, provided: provided, findings: findings, verdict: "NO DOCUMENTS PASTED", verdictClass: "", why: "Paste at least one document — the quote, the invoice, or the payment confirmation — then run the audit." };
  }
  if (provided.length === 1){
    keys.forEach(function(k){
      var d = docs[k]; if (!d.present) return;
      if (d.totalCents === null) add("info", "Not parsed", DOCNAMES[k] + " grand total: NOT PARSED — no labeled total was found in the paste, and none was guessed.");
    });
    verdict = "NO COMPARISON POSSIBLE";
    verdictClass = "";
    why = "Only one document was pasted, so there is nothing to compare it against. Only that document's own arithmetic (above) was checked. Paste a second or third copy of the same agreement to get a consistency verdict — agreement is never claimed for documents that were not pasted.";
    return { docs: docs, provided: provided, findings: findings, verdict: verdict, verdictClass: verdictClass, why: why };
  }

  /* ---- cross-document checks (2 or 3 pastes) ---- */
  /* Totals */
  var totals = provided.filter(function(k){ return docs[k].totalCents !== null; });
  provided.forEach(function(k){
    if (docs[k].totalCents === null) add("info", "Not parsed", DOCNAMES[k] + " grand total: NOT PARSED — no labeled total found in that paste, so its total could not be compared.");
  });
  if (totals.length >= 2){
    var first = totals[0];
    var allEqual = totals.every(function(k){ return docs[k].totalCents === docs[first].totalCents; });
    if (allEqual){
      add("ok", "Grand totals", "Grand totals agree to the cent across every paste that states one: " + totals.map(function(k){ return DOCNAMES[k] + " " + fmt(docs[k].totalCents); }).join(" · ") + ".");
    } else {
      var lines = totals.map(function(k){ return DOCNAMES[k] + " total: " + fmt(docs[k].totalCents); }).join("\n");
      var diffs = [];
      for (var ti = 1; ti < totals.length; ti++){
        var dd2 = docs[totals[ti]].totalCents - docs[first].totalCents;
        if (dd2 !== 0) diffs.push(DOCNAMES[totals[ti]] + " − " + DOCNAMES[first] + " = " + fmtSigned(dd2) + " (difference " + fmt(Math.abs(dd2)) + ")");
      }
      add("blocker", "Grand totals disagree",
        "The pastes do not agree on the grand total. Do not send or pay until the amount itself is settled.",
        lines + "\n" + diffs.join("\n"));
    }
  }
  /* Currency */
  var curs = provided.filter(function(k){ return docs[k].currency !== null; });
  var distinctCur = [];
  curs.forEach(function(k){ if (distinctCur.indexOf(docs[k].currency) === -1) distinctCur.push(docs[k].currency); });
  if (distinctCur.length > 1){
    add("blocker", "Currency mismatch",
      "The pastes state totals in different currencies for the same agreement: " + curs.map(function(k){ return DOCNAMES[k] + " " + docs[k].currency; }).join(" · ") + ". A $ total and a € total are not the same money.");
  } else if (curs.length >= 2){
    add("ok", "Currency", "Currency agrees across pastes: " + distinctCur[0] + ".");
  }
  /* Tax rate */
  var rates = provided.filter(function(k){ return docs[k].taxRate !== null; });
  provided.forEach(function(k){
    if (docs[k].present && docs[k].taxRate === null && (k !== "payment")) add("info", "Not parsed", DOCNAMES[k] + " tax rate: NOT PARSED — no percentage was found in that paste.");
  });
  if (rates.length >= 2){
    var r0 = docs[rates[0]].taxRate;
    if (rates.every(function(k){ return docs[k].taxRate === r0; })){
      add("ok", "Tax rate", "Tax rate agrees across pastes: " + r0 + "%.");
    } else {
      add("blocker", "Tax rate changed",
        "Tax rate differs between pastes: " + rates.map(function(k){ return DOCNAMES[k] + " " + docs[k].taxRate + "%"; }).join(" · ") + ". A rate change between the quote and the invoice changes the money owed — blocker.");
    }
  }
  /* Tax amount */
  var taxAmts = provided.filter(function(k){ return docs[k].taxCents !== null; });
  if (taxAmts.length >= 2){
    var t0 = docs[taxAmts[0]].taxCents;
    if (taxAmts.every(function(k){ return docs[k].taxCents === t0; })){
      add("ok", "Tax amount", "Tax amount agrees across pastes: " + fmt(t0) + ".");
    } else {
      add("major", "Tax amount differs",
        "Tax amount differs between pastes: " + taxAmts.map(function(k){ return DOCNAMES[k] + " " + fmt(docs[k].taxCents); }).join(" · ") + ".",
        taxAmts.slice(1).map(function(k){ return DOCNAMES[k] + " − " + DOCNAMES[taxAmts[0]] + " = " + fmtSigned(docs[k].taxCents - t0); }).join("\n"));
    }
  }
  /* Line items quote vs invoice */
  var q = docs.quote, iv = docs.invoice;
  if (q.present && iv.present){
    if (q.items.length && iv.items.length){
      var ivNames = iv.items.map(function(it){ return normName(it.name); });
      var qNames = q.items.map(function(it){ return normName(it.name); });
      q.items.forEach(function(it){
        if (ivNames.indexOf(normName(it.name)) === -1)
          add("major", "Line item missing from invoice", "“" + it.name + "” is on the quote (" + fmt(it.amountCents) + ") but does not appear on the invoice.");
      });
      iv.items.forEach(function(it){
        if (qNames.indexOf(normName(it.name)) === -1)
          add("major", "Line item added on invoice", "“" + it.name + "” is on the invoice (" + fmt(it.amountCents) + ") but does not appear on the quote — it was added after the quote.");
      });
      q.items.forEach(function(qit){
        var idx = ivNames.indexOf(normName(qit.name));
        if (idx !== -1){
          var iit = iv.items[idx];
          if (qit.amountCents !== iit.amountCents)
            add("major", "Line item amount changed", "“" + qit.name + "”: quote " + fmt(qit.amountCents) + " vs invoice " + fmt(iit.amountCents) + ".",
              "Invoice − Quote = " + fmtSigned(iit.amountCents - qit.amountCents));
          else if (qit.qty !== null && iit.qty !== null && (qit.qty !== iit.qty || qit.unitCents !== iit.unitCents))
            add("major", "Line item terms changed", "“" + qit.name + "” totals the same but quantity or unit price changed: quote " + qit.qty + " × " + fmt(qit.unitCents) + " vs invoice " + iit.qty + " × " + fmt(iit.unitCents) + ".");
        }
      });
      var anyItemFinding = findings.some(function(f){ return /Line item/.test(f.check); });
      if (!anyItemFinding) add("ok", "Line items", "Every line item on the quote appears on the invoice at the same amount, and nothing was added.");
    } else {
      add("info", "Line items not compared", "Line items could not be compared: " + (q.items.length ? "" : "quote items NOT PARSED. ") + (iv.items.length ? "" : "invoice items NOT PARSED. ") + "Items are never assumed to match.");
    }
  }
  /* Dates */
  var dueDocs = provided.filter(function(k){ return docs[k].dueDate !== null; });
  if (dueDocs.length >= 2){
    var d0 = docs[dueDocs[0]].dueDate.ms;
    if (!dueDocs.every(function(k){ return docs[k].dueDate.ms === d0; }))
      add("major", "Due date differs", "Due date differs between pastes: " + dueDocs.map(function(k){ return DOCNAMES[k] + " " + dateLabel(docs[k].dueDate.ms); }).join(" · ") + ".");
    else add("ok", "Due date", "Due date agrees across pastes: " + dateLabel(d0) + ".");
  }
  if (iv.present && iv.invoiceDate && iv.dueDate && iv.dueDate.ms < iv.invoiceDate.ms)
    add("major", "Date ordering (invoice)", "Invoice due date " + dateLabel(iv.dueDate.ms) + " is before the invoice date " + dateLabel(iv.invoiceDate.ms) + ".");
  var pay = docs.payment;
  if (pay.present && pay.paymentDate && iv.present && iv.invoiceDate){
    if (pay.paymentDate.ms < iv.invoiceDate.ms){
      var days = Math.round((iv.invoiceDate.ms - pay.paymentDate.ms) / 86400000);
      add("major", "Payment before invoice date", "Payment is dated " + dateLabel(pay.paymentDate.ms) + ", which is " + days + " day" + (days === 1 ? "" : "s") + " before the invoice date " + dateLabel(iv.invoiceDate.ms) + ". A payment cannot predate the invoice it pays.");
    } else {
      add("ok", "Date ordering", "Payment date " + dateLabel(pay.paymentDate.ms) + " is on or after the invoice date " + dateLabel(iv.invoiceDate.ms) + ".");
    }
  }
  /* Seller / payee */
  var sellers = provided.filter(function(k){ return docs[k].seller !== null; });
  if (sellers.length >= 2){
    var s0 = docs[sellers[0]].seller;
    if (sellers.every(function(k){ return docs[k].seller === s0; })){
      add("ok", "Seller / payee name", "Seller / payee name is spelled identically in every paste: “" + s0 + "”.");
    } else if (sellers.every(function(k){ return normName(docs[k].seller) === normName(s0); })){
      add("info", "Seller / payee name", "Seller / payee name matches except for case or punctuation: " + sellers.map(function(k){ return DOCNAMES[k] + " “" + docs[k].seller + "”"; }).join(" · ") + ".");
    } else {
      add("major", "Seller / payee name differs", "Seller / payee name is spelled differently between pastes: " + sellers.map(function(k){ return DOCNAMES[k] + " “" + docs[k].seller + "”"; }).join(" · ") + ". Paying a differently-named payee is how money goes to the wrong party.");
    }
  } else {
    provided.forEach(function(k){ if (docs[k].seller === null) add("info", "Not parsed", DOCNAMES[k] + " seller / payee name: NOT PARSED."); });
  }
  /* Invoice number */
  if (iv.present && pay.present){
    if (iv.invoiceNo && pay.invoiceNo){
      if (iv.invoiceNo === pay.invoiceNo) add("ok", "Invoice number", "Payment confirmation references the same invoice number as the invoice: " + iv.invoiceNo + ".");
      else add("major", "Invoice number mismatch", "Invoice number differs: invoice says " + iv.invoiceNo + " but the payment confirmation references " + pay.invoiceNo + ". The payment may belong to a different invoice.");
    } else {
      add("info", "Invoice number not compared", "Invoice number could not be compared: " + (!iv.invoiceNo ? "invoice number NOT PARSED on the invoice. " : "") + (!pay.invoiceNo ? "invoice number NOT PARSED on the payment confirmation." : ""));
    }
  }

  /* verdict */
  var hasBlocker = findings.some(function(f){ return f.severity === "blocker"; });
  var hasFix = findings.some(function(f){ return f.severity === "major"; });
  if (hasBlocker){
    verdict = "DO NOT SEND OR PAY"; verdictClass = "bad";
    why = "At least one blocker was found — a disagreement on the money itself (totals, tax rate, or currency). Settle the blocker findings below before this invoice goes out or this payment is made.";
  } else if (hasFix){
    verdict = "FIX BEFORE SENDING"; verdictClass = "fix";
    why = "No blockers, but the findings below disagree across the pastes. Fix them so all copies of the agreement say the same thing before sending or paying.";
  } else {
    verdict = "CONSISTENT"; verdictClass = "ok";
    why = provided.length === 3
      ? "Everything compared across all three pastes agrees — totals to the cent, tax, line items, dates, names, invoice number, and currency."
      : "Everything compared across the 2 pasted documents agrees. Under the paste-count rule this earns CONSISTENT only because every compared fact agrees; the third copy was not pasted and was not checked.";
  }
  return { docs: docs, provided: provided, findings: findings, verdict: verdict, verdictClass: verdictClass, why: why };
}

/* ---------- rendering ---------- */
function factCell(k, docs, fn){
  var d = docs[k];
  if (!d.present) return "—";
  var v = fn(d);
  return (v === null || v === undefined || v === "") ? "NOT PARSED" : v;
}
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-invoice-quote-payment-consistency-auditor',
  name: 'J-Dawgs Invoice, Quote & Payment Confirmation Consistency Auditor',
  description: 'holding a quote, an invoice, and a payment confirmation that must agree',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
