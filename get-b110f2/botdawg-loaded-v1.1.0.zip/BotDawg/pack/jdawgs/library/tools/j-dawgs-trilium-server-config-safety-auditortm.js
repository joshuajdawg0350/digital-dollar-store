'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Trilium Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";
        var RISKY = document.getElementById('riskyText').textContent.replace(/\n$/,'');
        var HARDENED = document.getElementById('hardenedText').textContent.replace(/\n$/,'');
        var input = document.getElementById('configInput');
        var lastResult = null;

        function truthy(v){ return ['true','1','yes','on'].indexOf(String(v).trim().toLowerCase()) !== -1; }
        function falsy(v){ return ['false','0','no','off'].indexOf(String(v).trim().toLowerCase()) !== -1; }

        function isEnvRef(v){ return /^\$\{[^}]+\}$/.test(v) || /^\$\{?[A-Z][A-Z0-9_]*\}?$/.test(v) || /^env:/i.test(v) || /^vault:/i.test(v); }
        function isHash(v){ return /^\$2[aby]\$/.test(v) || /^\$argon2/i.test(v) || /^\{(bcrypt|argon2|sha256|sha512)\}/i.test(v); }

        var SECRET_HINTS = ['password','passwd','secret','token','apikey','api_key','api-key','passphrase','privatekey','credential'];
        var WEAK_WORDS = ['example','changeme','change-me','change_me','password','letmein','admin','test','demo','default','trilium','1234','qwerty','secret','sample','placeholder'];

        function audit(text){
          var lines = text.split(/\r?\n/);
          var entries = [];
          var notParsed = [];
          var section = '';
          for (var i=0;i<lines.length;i++){
            var lineNo = i+1;
            var t = lines[i].trim();
            if (t === '') continue;
            if (t.charAt(0) === ';' || t.charAt(0) === '#') continue;
            var sec = t.match(/^\[([^\]]+)\]$/);
            if (sec){ section = sec[1].trim(); continue; }
            var m = t.match(/^([A-Za-z][A-Za-z0-9_.\-]*)\s*[:=]\s*(.*)$/);
            if (m){
              entries.push({line:lineNo, section:section, key:m[1], keyLower:m[1].toLowerCase(), value:m[2].trim()});
            } else {
              notParsed.push(lineNo);
            }
          }
          function byKey(name){ for (var j=entries.length-1;j>=0;j--){ if (entries[j].keyLower===name) return entries[j]; } return null; }
          function anyKey(pred){ for (var j=0;j<entries.length;j++){ if (pred(entries[j])) return entries[j]; } return null; }

          var findings = [];
          function add(severity, code, line, key, detail, fix){
            findings.push({severity:severity, code:code, line:line, key:key, detail:detail, fix:fix});
          }

          // Per-setting checks
          entries.forEach(function(e){
            var k = e.keyLower, v = e.value, vl = v.toLowerCase();
            if ((k==='noauthentication'||k==='noauth'||k==='disableauthentication'||k==='authdisabled') && truthy(v)){
              add('CRITICAL','AUTH_DISABLED',e.line,e.key,'Authentication is disabled in the pasted config. Anyone who can reach the server can open the notes without signing in.','Set '+e.key+'=false (or remove the key) and configure a password before the server is reachable by anyone else.');
            }
            if ((k==='authentication'||k==='auth'||k==='authenabled') && (falsy(v)||vl==='disabled'||vl==='none')){
              add('CRITICAL','AUTH_DISABLED',e.line,e.key,'Authentication is set to off/disabled in the pasted config.','Turn authentication on and configure a password before deploying.');
            }
            if ((k==='debug'||k==='debugmode') && truthy(v)){
              add('MAJOR','DEBUG_ENABLED',e.line,e.key,'Debug mode is on. Debug output can expose internal paths, queries, and config details.','Set '+e.key+'=false on a deployed server.');
            }
            if ((k==='devmode'||k==='developmentmode'||k==='dev') && truthy(v)){
              add('MAJOR','DEV_MODE_ENABLED',e.line,e.key,'Development mode is on. Dev modes commonly relax checks and expose extra tooling.','Set '+e.key+'=false and run the production mode on a deployed server.');
            }
            if ((k==='environment'||k==='mode'||k==='nodeenv'||k==='appenv') && (vl==='development'||vl==='dev'||vl==='debug')){
              add('MAJOR','DEV_ENVIRONMENT',e.line,e.key,'The environment is set to a development/debug value.','Set the environment to production for deployment.');
            }
            if (k==='loglevel' && (vl==='debug'||vl==='trace')){
              add('MAJOR','DEBUG_LOG_LEVEL',e.line,e.key,'The log level is set to a debug-level value, which can write sensitive detail to logs.','Use info or warn level logging on a deployed server.');
            }
            // Secrets — report key, line, and length only. The value is never copied into a finding.
            var isSecretKey = SECRET_HINTS.some(function(h){ return k.indexOf(h) !== -1; });
            if (isSecretKey){
              if (v === ''){
                add('MAJOR','EMPTY_SECRET',e.line,e.key,'Key "'+e.key+'" (line '+e.line+', value length 0) is present but empty, so the protection it names is not actually set.','Set a real value, a password hash, or an environment-variable reference for this key.');
              } else if (!isEnvRef(v) && !isHash(v) && k.indexOf('hash') === -1){
                var issues = ['stored as plaintext in the config file'];
                if (v.length < 12) issues.push('shorter than 12 characters');
                var weak = WEAK_WORDS.some(function(w){ return vl.indexOf(w) !== -1; });
                if (weak) issues.push('matches a common example, placeholder, or guessable pattern');
                var sev = (weak || v.length < 8) ? 'CRITICAL' : (v.length < 16 ? 'MAJOR' : 'MINOR');
                add(sev,'WEAK_OR_PLAINTEXT_SECRET',e.line,e.key,'Key "'+e.key+'" (line '+e.line+', value length '+v.length+') is '+issues.join('; ')+'. The value itself is never shown in this report.','Replace it with a long, unique value stored as a hash or pulled from an environment variable, and rotate it if it was ever shared.');
              } else if ((isHash(v) || k.indexOf('hash') !== -1) && v.length < 20 && !isEnvRef(v)){
                add('MAJOR','SHORT_HASH',e.line,e.key,'Key "'+e.key+'" (line '+e.line+', value length '+v.length+') looks like a hash but is unusually short for one.','Store a full-length password hash produced by the server, not a truncated or hand-typed value.');
              }
            }
          });

          // Host / TLS / port posture
          var hostE = byKey('host') || byKey('hostname') || byKey('bind') || byKey('bindaddress') || byKey('listenaddress');
          var httpsE = byKey('https');
          var tlsE = byKey('tls') || byKey('ssl');
          var certE = anyKey(function(e){ return ['certpath','certificatepath','tlscertpath','certfile'].indexOf(e.keyLower) !== -1 && e.value !== ''; });
          var tlsOn = (httpsE && truthy(httpsE.value)) || (tlsE && truthy(tlsE.value)) || !!certE;
          var allInterfaces = false;
          if (hostE){
            var hv = hostE.value.toLowerCase();
            allInterfaces = (hv==='0.0.0.0' || hv==='::' || hv==='[::]' || hv==='*');
            if (allInterfaces && !tlsOn){
              add('CRITICAL','HOST_ALL_INTERFACES_NO_TLS',hostE.line,hostE.key,'The host is bound to all network interfaces (0.0.0.0-style binding) while HTTPS/TLS is off, so sign-in and note traffic cross the network as plain HTTP.','Bind to 127.0.0.1, or enable HTTPS with a certificate before binding to all interfaces.');
            } else if (allInterfaces && tlsOn){
              add('MAJOR','HOST_ALL_INTERFACES',hostE.line,hostE.key,'The host is bound to all network interfaces. TLS is on, but the server is still reachable from every network it sits on.','Bind to 127.0.0.1 behind a reverse proxy, or confirm a firewall limits who can reach the port.');
            }
          }
          if (httpsE && falsy(httpsE.value)){
            add('MAJOR','HTTPS_DISABLED',httpsE.line,httpsE.key,'HTTPS is explicitly switched off in the pasted config.','Set https=true with certificate and key paths, or bind to 127.0.0.1 and terminate TLS in a reverse proxy.');
          }
          var portE = byKey('port');
          if (portE){
            if (allInterfaces){
              add('MAJOR','PORT_EXPOSED_ALL_INTERFACES',portE.line,portE.key,'This port is exposed on all interfaces because the host binding covers every network interface.','Restrict the host binding or firewall the port so only intended networks can reach it.');
            } else if (!hostE){
              add('MINOR','PORT_WITHOUT_HOST_RESTRICTION',portE.line,portE.key,'A port is set but no host binding is named in the pasted text, so how widely the port is exposed depends on server defaults you cannot see here.','Name an explicit host binding (127.0.0.1 for local-only) in the config.');
            }
            var pv = parseInt(portE.value,10);
            if (isNaN(pv) || pv < 1 || pv > 65535){
              add('MINOR','INVALID_PORT',portE.line,portE.key,'The port value is not a valid port number (1–65535).','Set a valid numeric port.');
            }
          }

          // NOT PARSED lines
          notParsed.forEach(function(ln){
            add('MINOR','NOT_PARSED',ln,null,'Line '+ln+' could not be parsed: it is not blank, a comment, a [section] header, or a key=value setting. A misspelled security setting on such a line may be silently ignored by the server.','Fix the line into key=value form, make it a comment, or remove it — then re-audit.');
          });

          // Missing instance / session protections (file-level)
          var instE = byKey('instancename') || byKey('instanceid');
          if (!instE){
            add('MINOR','MISSING_INSTANCE_NAME',null,null,'No instanceName is named in the pasted text, so this instance carries no identifying name in its config.','Set instanceName to a recognizable name for this server.');
          } else if (instE.value === ''){
            add('MINOR','MISSING_INSTANCE_NAME',instE.line,instE.key,'instanceName is present but empty, so the instance protection it names is not actually set.','Give instanceName a real value.');
          }
          var sessSecretE = anyKey(function(e){ return e.keyLower.indexOf('session') !== -1 && (e.keyLower.indexOf('secret') !== -1 || e.keyLower.indexOf('key') !== -1 || e.keyLower.indexOf('token') !== -1); });
          if (!sessSecretE){
            add('MAJOR','MISSING_SESSION_SECRET',null,null,'No session secret is named in the pasted text, so session protection depends on defaults or generated values you cannot verify here.','Set a session secret as a long unique value or an environment-variable reference.');
          }
          var sessTimeoutE = anyKey(function(e){ return ['sessiontimeout','sessionmaxage','sessionexpiry','sessionexpires','sessionttl','sessionlifetime'].indexOf(e.keyLower) !== -1; });
          if (!sessTimeoutE){
            add('MINOR','MISSING_SESSION_TIMEOUT',null,null,'No session timeout setting is named in the pasted text, so signed-in sessions may live longer than you intend.','Set a session timeout (for example sessionTimeout) appropriate for this server.');
          }
          var authConfigE = byKey('noauthentication') || anyKey(function(e){ return e.keyLower.indexOf('password') !== -1 || e.keyLower==='authentication' || e.keyLower==='auth'; });
          if (!authConfigE){
            add('MAJOR','MISSING_AUTH_CONFIGURATION',null,null,'The pasted text names no authentication setting and no password at all, so it is not possible to confirm sign-in protection from this config.','Name the authentication setting explicitly (for example noAuthentication=false) and configure a password or password hash.');
          }

          var rank = {CRITICAL:0, MAJOR:1, MINOR:2};
          findings.sort(function(a,b){
            var la = a.line === null ? 100000 : a.line, lb = b.line === null ? 100000 : b.line;
            if (la !== lb) return la - lb;
            return rank[a.severity] - rank[b.severity];
          });
          var crit = findings.filter(function(f){return f.severity==='CRITICAL';}).length;
          var maj = findings.filter(function(f){return f.severity==='MAJOR';}).length;
          var min = findings.filter(function(f){return f.severity==='MINOR';}).length;
          var verdict = crit > 0 ? 'DO NOT DEPLOY' : (findings.length > 0 ? 'DEPLOY WITH FIXES' : 'SAFE TO DEPLOY');
          return {verdict:verdict, findings:findings, linesChecked:lines.length, settingsParsed:entries.length, notParsedCount:notParsed.length, counts:{critical:crit, major:maj, minor:min, total:findings.length}};
        }

        function esc(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-trilium-server-config-safety-auditortm',
  name: 'J-Dawgs Trilium Server Config Safety Auditor',
  description: 'Host tools only tell you the server started; ours grades a pasted Trilium Notes server config.ini offline into one deploy verdict — secrets by key/line/length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
