'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs LibreChat Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Examples ---------- */
      var RISKY = [
        "# Risky LibreChat config (worked example)",
        "CREDS_KEY=abc123short",
        "CREDS_IV=xyz789",
        "JWT_SECRET=mysecret",
        "JWT_REFRESH_SECRET=mysecret",
        "MONGO_URI=mongodb://admin:MongoPlainPass99@db.example.com:27017/librechat",
        "ALLOW_REGISTRATION=true",
        "DEBUG_LOGS=true",
        "DEBUG_CONSOLE=true",
        "DOMAIN_CLIENT=http://chat.example.com",
        "DOMAIN_SERVER=http://api.example.com",
        "ALLOW_SOCIAL_LOGIN=true",
        "OPENAI_API_KEY=sk-short99"
      ].join("\n");

      var HARDENED = [
        "# Hardened LibreChat config (worked example)",
        "CREDS_KEY=fae5c00dcd1b7dc78058865e9ab2c561b15d3a0bdf7ad8dfc2b10d3d3b915448",
        "CREDS_IV=c5bb9f99e77ed1086d9f9603cbdd1f2b",
        "JWT_SECRET=OhbVrpoiVgRV5IfLBcbfnoGMbJmTPSIAoCLrZ3aWZkSBvrjn",
        "JWT_REFRESH_SECRET=9Wvgfygw2wMqZcUDIh7yfJs1ON43xKmTecQoXsf2o3gyrDO1",
        "MONGO_URI=mongodb://librechat:${MONGO_PASSWORD}@db.internal:27017/librechat",
        "ALLOW_REGISTRATION=false",
        "ALLOW_SOCIAL_LOGIN=false",
        "DEBUG_LOGS=false",
        "DEBUG_CONSOLE=false",
        "DOMAIN_CLIENT=https://chat.example.com",
        "DOMAIN_SERVER=https://api.example.com",
        "OPENAI_API_KEY=${OPENAI_API_KEY}"
      ].join("\n");

      var PROSE = [
        "Deployment notes for the team",
        "We are thinking about self hosting a chat server next week.",
        "Someone should double check the database settings before launch!",
        "Bring snacks for the Friday review."
      ].join("\n");

      /* ---------- Parsing ---------- */
      var KNOWN_KEYS = {
        CREDS_KEY:1, CREDS_IV:1, JWT_SECRET:1, JWT_REFRESH_SECRET:1,
        MONGO_URI:1, MONGO_URL:1, ALLOW_REGISTRATION:1, ALLOW_SOCIAL_LOGIN:1,
        DEBUG_LOGS:1, DEBUG_CONSOLE:1, DOMAIN_CLIENT:1, DOMAIN_SERVER:1,
        HOST:1, PORT:1, SESSION_EXPIRY:1, REFRESH_TOKEN_EXPIRY:1,
        OPENAI_API_KEY:1, ANTHROPIC_API_KEY:1, GOOGLE_KEY:1, BINGAI_TOKEN:1,
        CHATGPT_TOKEN:1, TITLE_CONVO:1, ENDPOINTS:1, CONSOLE_JSON:1,
        REGISTRATION_ALLOWED_DOMAINS:1, ALLOWED_DOMAINS:1
      };

      function stripQuotes(v){
        if (v.length >= 2){
          var a = v.charAt(0), b = v.charAt(v.length-1);
          if ((a === '"' && b === '"') || (a === "'" && b === "'")) return v.slice(1,-1);
        }
        return v;
      }

      function parseConfig(text){
        var lines = String(text == null ? "" : text).split(/\r?\n/);
        var entries = [], notParsed = [];
        for (var i = 0; i < lines.length; i++){
          var lineNo = i + 1;
          var t = lines[i].trim();
          if (t === "") continue;
          if (t.charAt(0) === "#") continue;
          var m = t.match(/^(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/);
          if (!m) m = t.match(/^(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*:\s+(.*)$/);
          if (!m) m = t.match(/^(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*:\s*(.*)$/);
          if (!m){ notParsed.push(lineNo); continue; }
          entries.push({ key: m[1].toUpperCase(), value: stripQuotes(m[2].trim()), line: lineNo });
        }
        return { entries: entries, notParsed: notParsed };
      }

      /* ---------- Helpers ---------- */
      function isPlaceholder(v){ return /^\$\{[^}]*\}$/.test(v) || /^\$\{[A-Za-z0-9_]+\}/.test(v) && v.indexOf("${") === 0 && /\}$/.test(v); }
      function isTruthy(v){ var s = v.trim().toLowerCase(); return s === "true" || s === "1" || s === "on" || s === "yes" || s === "debug"; }
      var EXAMPLE_WORDS = ["example","changeme","change_me","change-me","change me","placeholder","your-","your_","your ","letmein","123456","qwerty","foobar","librechat","default","todo"];
      function isExampleValue(v){
        var s = v.toLowerCase();
        if (s === "") return false;
        for (var i = 0; i < EXAMPLE_WORDS.length; i++){ if (s.indexOf(EXAMPLE_WORDS[i]) !== -1) return true; }
        if (/^(.)\1+$/.test(s)) return true;
        if (s === "secret" || s === "mysecret" || s === "password" || s === "test" || s === "demo" || s === "sample") return true;
        if (s.indexOf("mysecret") !== -1 || s.indexOf("supersecret") !== -1) return true;
        return false;
      }
      function isHexOf(v, n){ return v.length === n && /^[0-9a-fA-F]+$/.test(v); }

      /* ---------- Audit ---------- */
      function auditConfig(text){
        var parsed = parseConfig(text);
        var entries = parsed.entries, notParsed = parsed.notParsed;
        var map = {};
        entries.forEach(function(e){ map[e.key] = e; });
        var findings = [];
        function add(sev, key, line, len, issue, fix){
          findings.push({ severity: sev, key: key, line: line, length: len, issue: issue, fix: fix });
        }

        var knownCount = 0, seen = {};
        entries.forEach(function(e){ if (KNOWN_KEYS[e.key] && !seen[e.key]){ seen[e.key] = 1; knownCount++; } });

        /* CREDS_KEY */
        var ck = map["CREDS_KEY"];
        if (!ck) add("BLOCKER","CREDS_KEY",null,null,"CREDS_KEY is missing. LibreChat cannot encrypt stored credentials without it.","Generate a 64-character hex key (e.g. with openssl rand -hex 32) and set CREDS_KEY to it.");
        else if (!isPlaceholder(ck.value) && !isHexOf(ck.value, 64))
          add("BLOCKER","CREDS_KEY",ck.line,ck.value.length,"CREDS_KEY is " + ck.value.length + " characters and is not a 64-character hex value. Credential encryption is weak or will fail.","Replace it with a freshly generated 64-character hex key (openssl rand -hex 32). Do not reuse an example or short value.");

        /* CREDS_IV */
        var ci = map["CREDS_IV"];
        if (!ci) add("BLOCKER","CREDS_IV",null,null,"CREDS_IV is missing. LibreChat needs the IV paired with CREDS_KEY.","Generate a 32-character hex IV (openssl rand -hex 16) and set CREDS_IV to it.");
        else if (!isPlaceholder(ci.value) && !isHexOf(ci.value, 32))
          add("BLOCKER","CREDS_IV",ci.line,ci.value.length,"CREDS_IV is " + ci.value.length + " characters and is not a 32-character hex value.","Replace it with a freshly generated 32-character hex IV (openssl rand -hex 16), unique to this deployment.");

        /* JWT secrets */
        ["JWT_SECRET","JWT_REFRESH_SECRET"].forEach(function(k){
          var e = map[k];
          if (!e) add("BLOCKER",k,null,null,k + " is missing. Session tokens cannot be signed safely.","Generate a random secret of at least 32 characters and set " + k + " to it.");
          else if (isPlaceholder(e.value)) { /* safe reference */ }
          else if (isExampleValue(e.value))
            add("BLOCKER",k,e.line,e.value.length,k + " (" + e.value.length + " chars) looks like an example or placeholder value. Anyone who has seen the sample config can forge sessions.","Replace it with a unique random secret of at least 32 characters that appears in no example or repository.");
          else if (e.value.length < 32)
            add("HIGH",k,e.line,e.value.length,k + " is only " + e.value.length + " characters — shorter than the 32-character minimum for a token-signing secret.","Regenerate " + k + " as a random value of at least 32 characters.");
        });
        var js = map["JWT_SECRET"], jr = map["JWT_REFRESH_SECRET"];
        if (js && jr && !isPlaceholder(js.value) && js.value !== "" && js.value === jr.value)
          add("HIGH","JWT_REFRESH_SECRET",jr.line,jr.value.length,"JWT_SECRET and JWT_REFRESH_SECRET are identical (" + jr.value.length + " chars each). One leaked value compromises both access and refresh tokens.","Generate two different random secrets and use a separate value for each key.");

        /* MONGO_URI plaintext password */
        ["MONGO_URI","MONGO_URL"].forEach(function(k){
          var e = map[k];
          if (!e || isPlaceholder(e.value)) return;
          var m = e.value.match(/^mongodb(?:\+srv)?:\/\/([^\/:?#@]+):([^@]+)@/i);
          if (m){
            var pw = m[2];
            if (!isPlaceholder(pw) && !/^\*+$/.test(pw) && !/^x+$/i.test(pw))
              add("HIGH",k,e.line,e.value.length,k + " (value length " + e.value.length + ") embeds a plaintext password in the connection string. Anyone who reads this file owns the database.","Remove the password from the URI: reference it from your secret store instead, e.g. mongodb://user:${MONGO_PASSWORD}@host:27017/db, and rotate the exposed password.");
          }
        });

        /* Open registration */
        var ar = map["ALLOW_REGISTRATION"];
        if (ar && isTruthy(ar.value)){
          var restricted = false;
          Object.keys(map).forEach(function(k){
            if (/ALLOWED.*DOMAIN|DOMAIN.*ALLOW|REGISTRATION.*DOMAIN|ALLOWED_EMAIL/.test(k) && map[k].value.trim() !== "") restricted = true;
          });
          if (!restricted)
            add("WARNING","ALLOW_REGISTRATION",ar.line,ar.value.length,"ALLOW_REGISTRATION is on with no allowed-domain restriction anywhere in the config. Anyone on the internet can create an account.","Set ALLOW_REGISTRATION=false, or add an allowed-domain restriction (e.g. REGISTRATION_ALLOWED_DOMAINS) limited to your own domains.");
        }

        /* Social login */
        var sl = map["ALLOW_SOCIAL_LOGIN"];
        if (sl && isTruthy(sl.value))
          add("WARNING","ALLOW_SOCIAL_LOGIN",sl.line,sl.value.length,"ALLOW_SOCIAL_LOGIN is on. Social sign-in widens the account-creation surface and is easy to leave on by accident.","Turn ALLOW_SOCIAL_LOGIN off unless social sign-in is deliberate and its providers are locked down.");

        /* Debug logging */
        ["DEBUG_LOGS","DEBUG_CONSOLE"].forEach(function(k){
          var e = map[k];
          if (e && isTruthy(e.value))
            add("WARNING",k,e.line,e.value.length,k + " is on. Debug output can leak prompts, tokens, and request data into logs.","Set " + k + "=false for production; enable it only briefly while troubleshooting.");
        });

        /* http domains */
        ["DOMAIN_CLIENT","DOMAIN_SERVER"].forEach(function(k){
          var e = map[k];
          if (e && !isPlaceholder(e.value) && e.value.toLowerCase().indexOf("http://") === 0)
            add("HIGH",k,e.line,e.value.length,k + " uses plain http:// (value length " + e.value.length + "). Traffic, logins, and tokens cross the network unencrypted.","Put the service behind HTTPS and set " + k + " to the https:// address.");
        });

        /* Generic secret-like keys */
        var handled = { CREDS_KEY:1, CREDS_IV:1, JWT_SECRET:1, JWT_REFRESH_SECRET:1, MONGO_URI:1, MONGO_URL:1 };
        entries.forEach(function(e){
          if (handled[e.key]) return;
          if (!/(SECRET|TOKEN|PASSWORD|PASSWD|KEY)/.test(e.key)) return;
          if (isPlaceholder(e.value)) return;
          if (e.value === "")
            add("HIGH",e.key,e.line,0,e.key + " is set but empty.","Give " + e.key + " a real value from your secret store, or remove the key.");
          else if (isExampleValue(e.value))
            add("HIGH",e.key,e.line,e.value.length,e.key + " (" + e.value.length + " chars) looks like an example or placeholder value.","Replace " + e.key + " with the real, unique secret from your secret store.");
          else if (e.value.length < 16)
            add("HIGH",e.key,e.line,e.value.length,e.key + " is only " + e.value.length + " characters — too short for a secret.","Replace " + e.key + " with a random value of at least 32 characters.");
          else if (e.value.length < 32)
            add("WARNING",e.key,e.line,e.value.length,e.key + " is " + e.value.length + " characters — below the 32-character bar for secrets.","Lengthen " + e.key + " to at least 32 random characters when you next rotate it.");
        });

        /* Verdict */
        var blockers = findings.filter(function(f){ return f.severity === "BLOCKER"; }).length;
        var highs = findings.filter(function(f){ return f.severity === "HIGH"; }).length;
        var warns = findings.filter(function(f){ return f.severity === "WARNING"; }).length;
        var verdict;
        if (knownCount < 3) verdict = "NOT ENOUGH TO GRADE";
        else if (blockers > 0) verdict = "DO NOT DEPLOY";
        else if (findings.length > 0) verdict = "DEPLOY WITH FIXES";
        else verdict = "SAFE TO DEPLOY";

        return {
          verdict: verdict, findings: findings, notParsed: notParsed,
          parsedCount: entries.length, knownCount: knownCount,
          counts: { blocker: blockers, high: highs, warning: warns },
          keys: entries.map(function(e){ return e.key; })
        };
      }

      /* ---------- Report / JSON (never include secret values) ---------- */
      function buildTextReport(r){
        var out = [];
        out.push("J-Dawgs LibreChat Server Config Safety Auditor — text report");
        out.push("Verdict: " + r.verdict);
        out.push("Parsed keys: " + r.parsedCount + " | Recognizable LibreChat keys: " + r.knownCount);
        out.push("Findings: " + r.findings.length + " (BLOCKER " + r.counts.blocker + ", HIGH " + r.counts.high + ", WARNING " + r.counts.warning + ")");
        out.push("");
        if (r.findings.length === 0) out.push("No findings.");
        r.findings.forEach(function(f, i){
          out.push((i+1) + ". [" + f.severity + "] " + f.key + " — line " + (f.line == null ? "missing" : f.line) + (f.length == null ? "" : " — value length " + f.length));
          out.push("   Issue: " + f.issue);
          out.push("   Fix: " + f.fix);
        });
        if (r.notParsed.length){
          out.push("");
          out.push("NOT PARSED (excluded from grading): line" + (r.notParsed.length > 1 ? "s" : "") + " " + r.notParsed.join(", "));
        }
        out.push("");
        out.push("Note: secret values are never included in this report — key name, line, and length only.");
        return out.join("\n");
      }
      function buildJson(r){
        return JSON.stringify({
          tool: "J-Dawgs LibreChat Server Config Safety Auditor",
          verdict: r.verdict,
          parsedKeys: r.parsedCount,
          recognizableLibreChatKeys: r.knownCount,
          counts: r.counts,
          findings: r.findings.map(function(f){
            return { severity: f.severity, key: f.key, line: f.line, valueLength: f.length, issue: f.issue, fix: f.fix };
          }),
          notParsedLines: r.notParsed,
          keysSeen: r.keys
        }, null, 2);
      }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_WORDS": (typeof EXAMPLE_WORDS !== 'undefined' ? EXAMPLE_WORDS : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-librechat-server-config-safety-auditortm',
  name: 'J-Dawgs LibreChat Server Config Safety Auditor',
  description: 'Grades a pasted LibreChat config offline into one deploy verdict — CREDS_KEY/CREDS_IV shape, JWT secret strength and reuse, plaintext MONGO_URI password, open registration, and http domains graded, secrets by key name/line/length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_WORDS": __core["EXAMPLE_WORDS"] }
};
