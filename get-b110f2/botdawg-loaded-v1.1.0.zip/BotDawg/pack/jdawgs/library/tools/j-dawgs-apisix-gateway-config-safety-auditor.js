'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs APISIX Gateway Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Built-in examples (line numbers are load-bearing) ---------- */
      var RISKY_LINES = [
        "# Risky example - an APISIX config that starts fine and deploys dangerous.",
        "apisix:",
        "  node_listen: 9080",
        "  enable_admin: true",
        "  admin_key: edd1c9f034335f136f87ad84b625c8f1",
        "  allow_admin:",
        "    - 0.0.0.0/0",
        "  admin_listen:",
        "    ip: 0.0.0.0",
        "    port: 9180",
        "  enable_control: true",
        "  control:",
        "    ip: 0.0.0.0",
        "    port: 9090",
        "  enable_dev_mode: true",
        "  ssl:",
        "    enable: true",
        "    listen_port: 9443",
        "    ssl_protocols: \"TLSv1 TLSv1.1 TLSv1.2\"",
        "plugins:",
        "  - prometheus",
        "plugin_attr:",
        "  prometheus:",
        "    export_uri: /apisix/prometheus/metrics",
        "deployment:",
        "  etcd:",
        "    host:",
        "      - \"http://127.0.0.1:2379\"",
        "    user: root",
        "    password: TrailingPlantSecret-4815-xq",
        "nginx_config:",
        "  http:",
        "    server_tokens: \"on\""
      ];
      var RISKY_TEXT = RISKY_LINES.join("\n");

      var HARDENED_LINES = [
        "# Hardened example - the same gateway with the holes closed.",
        "apisix:",
        "  node_listen:",
        "    - ip: 127.0.0.1",
        "      port: 9080",
        "  enable_admin: true",
        "  admin_key: ${{APISIX_ADMIN_KEY}}",
        "  allow_admin:",
        "    - 127.0.0.0/8",
        "  admin_listen:",
        "    ip: 127.0.0.1",
        "    port: 9180",
        "  enable_control: false",
        "  ssl:",
        "    enable: true",
        "    listen_port: 9443",
        "    ssl_protocols: \"TLSv1.2 TLSv1.3\"",
        "plugins:",
        "  - prometheus",
        "  - key-auth",
        "plugin_attr:",
        "  prometheus:",
        "    export_uri: /internal/metrics",
        "deployment:",
        "  etcd:",
        "    host:",
        "      - \"https://127.0.0.1:2379\"",
        "    user: ${{ETCD_USER}}",
        "    password: ${{ETCD_PASSWORD}}",
        "nginx_config:",
        "  http:",
        "    server_tokens: \"off\""
      ];
      var HARDENED_TEXT = HARDENED_LINES.join("\n");

      var PITCHES = {
        pitch1: "Grade your APISIX gateway config before it grades you — the J-Dawgs APISIX Gateway Config Safety Auditor reads a pasted config.yaml offline and returns one deploy verdict: SAFE TO DEPLOY, DEPLOY WITH FIXES, or DO NOT DEPLOY.",
        pitch2: "AI Tool Store — https://muse.ai/s/ai-tool-store-xng6xkxwjkxl2xab/UoF72OkKI7j33Q2ITxmrZyIr4nv40QtYfj2AgESh_k8",
        pitch3: "J-Dawgs Agent Exchange — https://muse.ai/s/j-dawgs-agent-exchange-ih6xlnihzxdhxc/ZbleqxFHRE0NcswaBkyN13y9lLp5rPAgHTb6t8ii-PY",
        pitch4: "Route It, Vault It, Build It Right Stack — APISIX Gateway Config Safety Auditor + OpenBao Server Config Safety Auditor + Masonry Proposal, Work Record & Final Invoice Consistency Auditor: grade the gateway, grade the secrets vault, cross-check the masonry paperwork — $2.75 full pass."
      };

      /* ---------- Heuristic line parser ---------- */
      var RECOGNIZABLE = {
        apisix: 1, deployment: 1, node_listen: 1, admin_key: 1, admin_keys: 1,
        allow_admin: 1, admin_listen: 1, enable_admin: 1, enable_control: 1,
        control: 1, ssl: 1, plugins: 1, plugin_attr: 1, etcd: 1,
        nginx_config: 1, prometheus: 1, config_provider: 1, discovery: 1,
        stream_plugins: 1, enable_admin_cors: 1, port_admin: 1, https_admin: 1
      };
      var KNOWN_ADMIN_KEYS = [
        "edd1c9f034335f136f87ad84b625c8f1",
        "4054f7cf07e344346cd3f287985e76a2",
        "admin", "apisix", "password", "changeme", "123456"
      ];
      /* Credential keys are matched by whole name segment, never substring,
         so status keys like server_tokens are not mistaken for credentials. */
      function isSecretKey(key) {
        var segs = String(key).toLowerCase().split(/[_-]+/).filter(Boolean);
        for (var i = 0; i < segs.length; i++) {
          var s = segs[i];
          if (s === "password" || s === "passwd" || s === "secret" || s === "token" || s === "apikey") return true;
          if (i + 1 < segs.length) {
            var pair = s + "_" + segs[i + 1];
            if (pair === "api_key" || pair === "access_key" || pair === "private_key") return true;
          }
        }
        return false;
      }

      function unquote(v) {
        v = (v == null ? "" : String(v)).trim();
        if (v.length >= 2) {
          var a = v.charAt(0), b = v.charAt(v.length - 1);
          if ((a === '"' && b === '"') || (a === "'" && b === "'")) return v.slice(1, -1);
        }
        var ci = v.indexOf(" #");
        if (ci > -1) v = v.slice(0, ci).trim();
        return v;
      }
      function isEnvRef(v) {
        return v.indexOf("${") === 0 || v.indexOf("${{") > -1 || /\$\{ENV:/.test(v);
      }
      function isTruthy(v) {
        var s = unquote(v).toLowerCase();
        return s === "true" || s === "yes" || s === "on";
      }
      function hasParent(e, name) { return e.parents.indexOf(name) > -1; }

      function parseConfig(text) {
        var lines = String(text == null ? "" : text).split(/\r?\n/);
        var entries = [];
        var notParsed = [];
        var stack = []; // {indent, key}
        function parentsFor(indent, isItem) {
          if (isItem) {
            while (stack.length && stack[stack.length - 1].indent > indent) stack.pop();
          } else {
            while (stack.length && stack[stack.length - 1].indent >= indent) stack.pop();
          }
          return stack.map(function (s) { return s.key; });
        }
        lines.forEach(function (raw, idx) {
          var lineNo = idx + 1;
          var trimmed = raw.trim();
          if (trimmed === "" || trimmed.charAt(0) === "#") return;
          var indent = raw.length - raw.replace(/^\s+/, "").length;
          var m;
          if ((m = trimmed.match(/^-\s+(.*)$/))) {
            var rest = m[1];
            var itemParents = parentsFor(indent, true);
            var km = rest.match(/^([A-Za-z0-9_.\-]+)\s*:\s*(.*)$/);
            if (km && rest.charAt(0) !== '"' && rest.charAt(0) !== "'") {
              entries.push({ line: lineNo, type: "key", key: km[1], value: km[2], parents: itemParents });
            } else {
              entries.push({ line: lineNo, type: "item", key: null, value: rest, parents: itemParents });
            }
            return;
          }
          if ((m = trimmed.match(/^([A-Za-z_][A-Za-z0-9_]*)=(.*)$/)) && indent === 0) {
            entries.push({ line: lineNo, type: "env", key: m[1], value: m[2], parents: [] });
            return;
          }
          if ((m = trimmed.match(/^([A-Za-z0-9_.\-]+)\s*:\s*(.*)$/))) {
            var parents = parentsFor(indent, false);
            entries.push({ line: lineNo, type: "key", key: m[1], value: m[2], parents: parents });
            stack.push({ indent: indent, key: m[1] });
            return;
          }
          notParsed.push(lineNo);
        });
        return { entries: entries, notParsed: notParsed, totalLines: lines.length };
      }

      /* ---------- Audit ---------- */
      var SEV_RANK = { BLOCKER: 0, HIGH: 1, WARNING: 2, INFO: 3 };

      function audit(text) {
        var parsed = parseConfig(text);
        var entries = parsed.entries;
        var findings = [];
        function add(sev, line, key, title, detail, fix) {
          findings.push({ severity: sev, line: line, key: key, title: title, detail: detail, fix: fix });
        }
        function byKey(name) {
          return entries.filter(function (e) { return e.key === name; });
        }

        var recognizable = entries.some(function (e) {
          return (e.key && RECOGNIZABLE[e.key]) || e.parents.some(function (p) { return RECOGNIZABLE[p]; });
        });

        /* allow_admin */
        var allowAdminKeys = byKey("allow_admin");
        var allowAdminItems = entries.filter(function (e) { return e.type === "item" && hasParent(e, "allow_admin"); });
        allowAdminItems.forEach(function (e) {
          var v = unquote(e.value);
          if (v === "0.0.0.0/0" || v === "::/0") {
            add("BLOCKER", e.line, "allow_admin",
              "Admin API open to the entire internet",
              "allow_admin includes " + v + ", so anyone on any network can reach the Admin API and only the admin key stands between them and full gateway control.",
              "Replace " + v + " in allow_admin with only the CIDRs that administer this gateway (for example your VPN range, or 127.0.0.0/8 for local-only admin).");
          }
        });
        allowAdminKeys.forEach(function (e) {
          var v = unquote(e.value);
          if (v.indexOf("0.0.0.0/0") > -1 || v.indexOf("::/0") > -1) {
            add("BLOCKER", e.line, "allow_admin",
              "Admin API open to the entire internet",
              "allow_admin is set inline to a world-open CIDR (0.0.0.0/0 or ::/0), so the Admin API accepts connections from any network.",
              "Restrict allow_admin to the specific CIDRs that administer this gateway (for example your VPN range, or 127.0.0.0/8 for local-only admin).");
          }
        });

        /* admin key strength */
        var adminKeyTargets = [];
        byKey("admin_key").forEach(function (e) { if (unquote(e.value) !== "") adminKeyTargets.push(e); });
        entries.forEach(function (e) {
          if (e.key === "key" && hasParent(e, "admin_key") && unquote(e.value) !== "") adminKeyTargets.push(e);
        });
        adminKeyTargets.forEach(function (e) {
          var v = unquote(e.value);
          if (isEnvRef(v)) return;
          if (KNOWN_ADMIN_KEYS.indexOf(v) > -1) {
            add("BLOCKER", e.line, e.key,
              "Admin key is a well-known example/default value",
              "The admin key in key '" + e.key + "' (line " + e.line + ", " + v.length + " characters) matches a documented example/default admin key that ships in public APISIX examples. Anyone who has read the docs knows it. The value itself is never printed here.",
              "Generate a fresh random admin key of at least 32 characters, keep it out of the file via an env reference such as ${{APISIX_ADMIN_KEY}}, and treat any gateway that ever ran with the example key as exposed.");
          } else if (v.length < 16) {
            add("BLOCKER", e.line, e.key,
              "Admin key is too short",
              "The admin key in key '" + e.key + "' (line " + e.line + ") is only " + v.length + " characters — under the 16-character floor, and short enough to brute-force against an exposed Admin API. The value itself is never printed here.",
              "Replace it with a random admin key of at least 32 characters, supplied through an env reference such as ${{APISIX_ADMIN_KEY}} rather than typed into the config.");
          }
        });

        /* admin enabled with no allow_admin */
        var enableAdmin = byKey("enable_admin").filter(function (e) { return isTruthy(e.value); });
        var adminListenKeys = byKey("admin_listen");
        var adminPresentLine = null;
        if (enableAdmin.length) adminPresentLine = enableAdmin[0].line;
        else if (adminKeyTargets.length) adminPresentLine = adminKeyTargets[0].line;
        else if (adminListenKeys.length) adminPresentLine = adminListenKeys[0].line;
        if (adminPresentLine !== null && allowAdminKeys.length === 0 && allowAdminItems.length === 0) {
          add("HIGH", adminPresentLine, "allow_admin",
            "Admin API enabled with no allow_admin restriction",
            "The Admin API appears enabled, but no allow_admin list appears anywhere in the config, so source-IP restriction is left to defaults or to whatever fronts the gateway.",
            "Add an allow_admin list containing only the CIDRs that should reach the Admin API (for example 127.0.0.0/8 plus your admin VPN range).");
        }

        /* admin listener bound to all interfaces */
        entries.forEach(function (e) {
          if (e.key === "ip" && hasParent(e, "admin_listen")) {
            var v = unquote(e.value);
            if (v === "0.0.0.0" || v === "::") {
              add("HIGH", e.line, "admin_listen.ip",
                "Admin listener bound to all interfaces",
                "admin_listen binds the Admin API to " + v + " (every interface on the host), so it is reachable on every network the machine touches.",
                "Bind admin_listen ip to 127.0.0.1 and reach it over SSH or a VPN, or firewall the admin port (9180 by default) down to admin networks only.");
            }
          }
        });
        adminListenKeys.forEach(function (e) {
          if (unquote(e.value).indexOf("0.0.0.0") > -1) {
            add("HIGH", e.line, "admin_listen",
              "Admin listener bound to all interfaces",
              "admin_listen is set to 0.0.0.0, binding the Admin API to every interface on the host.",
              "Bind admin_listen to 127.0.0.1 and reach it over SSH or a VPN, or firewall the admin port down to admin networks only.");
          }
        });

        /* control API */
        entries.forEach(function (e) {
          if (e.key === "ip" && hasParent(e, "control")) {
            var v = unquote(e.value);
            if (v !== "127.0.0.1" && v !== "::1" && v.toLowerCase() !== "localhost") {
              add("HIGH", e.line, "control.ip",
                "Control API bound beyond localhost",
                "The control API is bound to " + v + ". The control API exposes internal gateway state and plugin control, and is meant to stay on the local host.",
                "Bind the control API ip to 127.0.0.1, or set enable_control: false if nothing local consumes it.");
            }
          }
        });

        /* listeners & TLS */
        var nodeListen = byKey("node_listen");
        var sslListen = entries.some(function (e) {
          return (e.key === "listen_port" && hasParent(e, "ssl")) ||
                 (e.key === "port" && hasParent(e, "ssl") && hasParent(e, "listen"));
        });
        if (nodeListen.length && !sslListen) {
          add("WARNING", nodeListen[0].line, "node_listen",
            "Plain-HTTP listeners only — no TLS listener",
            "A node_listen data-plane listener is configured, but no ssl listen_port appears in the config, so gateway traffic is served over plain HTTP unless something in front terminates TLS.",
            "Add an ssl block with listen_port (9443 by convention) and a certificate, or document the TLS terminator in front of the gateway and restrict the HTTP listener to it.");
        }
        byKey("ssl_protocols").forEach(function (e) {
          var v = unquote(e.value);
          var tokens = v.split(/[^A-Za-z0-9.]+/).filter(Boolean);
          var bad = tokens.filter(function (t) { return t === "TLSv1" || t === "TLSv1.1"; });
          if (bad.length) {
            add("HIGH", e.line, "ssl_protocols",
              "TLS listener still allows obsolete protocol versions",
              "ssl_protocols includes " + bad.join(" and ") + ", which are deprecated and vulnerable (BEAST / POODLE-class attacks) and fail modern compliance scans.",
              "Set ssl_protocols to \"TLSv1.2 TLSv1.3\" and remove TLSv1 and TLSv1.1.");
          }
        });

        /* prometheus metrics */
        var exportUri = byKey("export_uri");
        var promEntry = exportUri.length ? exportUri[0] :
          (entries.filter(function (e) { return unquote(e.value) === "prometheus" || e.key === "prometheus"; })[0] || null);
        var authPosture = entries.some(function (e) {
          var hay = ((e.key || "") + " " + unquote(e.value)).toLowerCase();
          return /key-auth|basic-auth|jwt-auth|ip-restriction|ldap-auth|authz-/.test(hay);
        });
        if (promEntry && !authPosture) {
          add("WARNING", promEntry.line, "prometheus",
            "Prometheus metrics endpoint exposed with no auth posture",
            "The Prometheus plugin / export_uri is configured, but no auth or IP-restriction plugin (key-auth, basic-auth, jwt-auth, ip-restriction) appears anywhere in the config, so operational metrics are readable by anyone who can reach the path.",
            "Put an auth or ip-restriction plugin in front of the metrics path, move export_uri to an internal-only location, or scrape it over a listener that is not publicly reachable.");
        }

        /* debug posture */
        byKey("enable_dev_mode").forEach(function (e) {
          if (isTruthy(e.value)) {
            add("WARNING", e.line, "enable_dev_mode",
              "Dev mode is on",
              "enable_dev_mode: true relaxes checks and enables development behavior that is not meant for a production gateway.",
              "Set enable_dev_mode: false in the production config.");
          }
        });
        byKey("debug").forEach(function (e) {
          if (isTruthy(e.value)) {
            add("WARNING", e.line, "debug",
              "Debug mode is on",
              "debug: true increases log detail and can surface request and credential material in logs on a production gateway.",
              "Set debug: false in the production config and raise log levels selectively when troubleshooting.");
          }
        });

        /* credentials — values NEVER recorded, only key/line/length */
        entries.forEach(function (e) {
          if (!e.key) return;
          var key = e.key;
          var v = unquote(e.value);
          var isEtcdUser = key === "user" && hasParent(e, "etcd");
          if (!isSecretKey(key) && !isEtcdUser) return;
          if (/_FILE$/i.test(key)) return;
          if (v === "" || v === "null" || v === "~") return;
          if (isEnvRef(v)) return;
          add("HIGH", e.line, key,
            isEtcdUser ? "etcd username stored in plaintext" : "Plaintext credential in config",
            "Key '" + key + "' (line " + e.line + ") holds a plaintext value of " + v.length + " characters. Anyone who can read this file — a repo, a backup, a screenshot — holds the credential. The value itself is never printed here.",
            "Move the value out of the config into an env reference such as ${{VAR}} or a *_FILE secret file, and rotate the credential — it has been sitting in plaintext.");
        });

        /* nginx INFO notes */
        byKey("server_tokens").forEach(function (e) {
          var v = unquote(e.value).toLowerCase();
          if (v === "on" || v === "true") {
            add("INFO", e.line, "server_tokens",
              "nginx server_tokens is on",
              "server_tokens on advertises the server version in response headers and error pages, which fingerprints the stack for attackers.",
              "Set server_tokens: \"off\" under nginx_config http.");
          } else if (v === "off" || v === "false") {
            add("INFO", e.line, "server_tokens",
              "nginx server_tokens is off",
              "The server version banner is suppressed — good posture, noted for the record.",
              "None needed.");
          }
        });
        entries.forEach(function (e) {
          if (e.key === "real_ip_header" || e.key === "real_ip_from") {
            add("INFO", e.line, e.key,
              "Real-IP handling is configured",
              "Key '" + e.key + "' is set, so client-IP decisions (logging, allow_admin, rate limits) depend on forwarded headers. That is only safe when the gateway sits behind a proxy you control.",
              "Confirm real_ip_from lists only your own proxies; if clients can reach the gateway directly, forwarded-header trust can be spoofed.");
          }
        });

        findings.sort(function (a, b) {
          return (SEV_RANK[a.severity] - SEV_RANK[b.severity]) || (a.line - b.line);
        });

        var counts = { BLOCKER: 0, HIGH: 0, WARNING: 0, INFO: 0 };
        findings.forEach(function (f) { counts[f.severity]++; });

        var verdict;
        if (!recognizable) verdict = "NOT ENOUGH TO GRADE";
        else if (counts.BLOCKER > 0) verdict = "DO NOT DEPLOY";
        else if (counts.HIGH > 0 || counts.WARNING > 0) verdict = "DEPLOY WITH FIXES";
        else verdict = "SAFE TO DEPLOY";

        return {
          verdict: verdict,
          counts: counts,
          findings: verdict === "NOT ENOUGH TO GRADE" ? [] : findings,
          notParsed: parsed.notParsed,
          totalLines: parsed.totalLines,
          parsedKeys: entries.length,
          recognizable: recognizable
        };
      }

      /* ---------- Report + JSON (secrecy: built only from finding fields) ---------- */
      function buildReport(r, sourceLabel) {
        var out = [];
        out.push("J-Dawgs APISIX Gateway Config Safety Auditor - audit report");
        out.push("Source: " + sourceLabel + " (pasted text, audited in-browser; nothing uploaded)");
        out.push("Verdict: " + r.verdict);
        out.push("Counts: BLOCKER " + r.counts.BLOCKER + " | HIGH " + r.counts.HIGH + " | WARNING " + r.counts.WARNING + " | INFO " + r.counts.INFO);
        out.push("Lines scanned: " + r.totalLines + " | Settings read: " + r.parsedKeys);
        if (r.notParsed.length) {
          out.push("NOT PARSED lines (content withheld): " + r.notParsed.join(", "));
        }
        out.push("");
        if (r.verdict === "NOT ENOUGH TO GRADE") {
          out.push("No recognizable APISIX settings were found in the pasted text, so there is nothing to grade.");
        } else if (!r.findings.length) {
          out.push("No findings. Nothing in the pasted config tripped a check.");
        } else {
          out.push("Findings:");
          r.findings.forEach(function (f, i) {
            out.push((i + 1) + ". [" + f.severity + "] Line " + f.line + " - key '" + f.key + "': " + f.title);
            out.push("   " + f.detail);
            out.push("   Fix: " + f.fix);
          });
          out.push("");
          out.push("Fix list:");
          r.findings.forEach(function (f, i) {
            out.push((i + 1) + ". (Line " + f.line + ", " + f.severity + ") " + f.fix);
          });
        }
        out.push("");
        out.push("Note: secret values never appear in this report - key name, line, and character length only.");
        return out.join("\n");
      }

      function buildJson(r, sourceLabel) {
        return JSON.stringify({
          tool: "J-Dawgs APISIX Gateway Config Safety Auditor",
          source: sourceLabel,
          verdict: r.verdict,
          counts: { blocker: r.counts.BLOCKER, high: r.counts.HIGH, warning: r.counts.WARNING, info: r.counts.INFO },
          linesScanned: r.totalLines,
          settingsRead: r.parsedKeys,
          notParsedLines: r.notParsed,
          findings: r.findings.map(function (f) {
            return { severity: f.severity, line: f.line, key: f.key, finding: f.title, detail: f.detail, fix: f.fix };
          })
        }, null, 2);
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-apisix-gateway-config-safety-auditor',
  name: 'J-Dawgs APISIX Gateway Config Safety Auditor',
  description: 'Grades a pasted Apache APISIX config.yaml fully offline into one deploy verdict — default or example admin key, allow_admin open to 0.0.0.0/0, exposed control and metrics endpoints, and TLS posture — with secrets reported by key name, line, and length only, never by value. APISIX only exercises a co',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
