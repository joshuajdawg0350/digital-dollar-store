'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Coolify Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

/* ---------- Examples (exact planted content) ---------- */
var RISKY = [
  "APP_KEY=123456789012",
  "APP_ENV=production",
  "APP_DEBUG=true",
  "APP_URL=http://coolify.example.com",
  "DB_PASSWORD=abcd1234",
  "ROOT_USER_PASSWORD=password",
  "REGISTRATION_ENABLED=true"
].join("\n");

var HARDENED = [
  "APP_KEY=aB3dF5gH7jK9mN2pQ4rS6tV8wX0yZ1bC3dE5fG7hJ9kL2mN4",
  "APP_ENV=production",
  "APP_DEBUG=false",
  "APP_URL=https://coolify.example.com",
  "DB_PASSWORD=${DB_PASSWORD}",
  "REDIS_PASSWORD=${REDIS_PASSWORD}",
  "REGISTRATION_ENABLED=false"
].join("\n");

/* ---------- Helpers ---------- */
var KNOWN_KEYS = {
  APP_KEY:1, APP_ENV:1, APP_DEBUG:1, APP_URL:1,
  DB_PASSWORD:1, DB_USERNAME:1, DB_HOST:1, DB_DATABASE:1, DB_PORT:1, DB_CONNECTION:1,
  REDIS_PASSWORD:1, REDIS_HOST:1, REDIS_PORT:1,
  PUSHER_APP_ID:1, PUSHER_APP_KEY:1, PUSHER_APP_SECRET:1,
  ROOT_USERNAME:1, ROOT_USER_EMAIL:1, ROOT_USER_PASSWORD:1,
  REGISTRATION_ENABLED:1, ALLOW_REGISTRATION:1,
  SSL:1, FORCE_HTTPS:1, SSL_ENABLED:1, FORCE_SSL:1, HTTPS:1,
  DOCKER_HOST:1
};
var SECRET_NAME = /(SECRET|TOKEN|PASSWORD|KEY|CREDENTIAL)/;
var EXAMPLE_WORDS = ["example","changeme","test","123456","coolify"];
var EXAMPLE_WORDS_GENERIC = ["example","changeme","test","123456","coolify","password","admin","secret","letmein","default","qwerty"];

function isRecognized(key){
  return !!KNOWN_KEYS[key] || SECRET_NAME.test(key);
}
function isEnvRef(v){
  return /^\$\{[^}]*\}$/.test(v) || /^\$[A-Za-z_][A-Za-z0-9_]*$/.test(v);
}
function containsAny(v, words){
  var low = v.toLowerCase();
  for (var i=0;i<words.length;i++){ if (low.indexOf(words[i]) !== -1) return words[i]; }
  return null;
}
function hasRepeated(v){
  if (/(.)\1{3,}/.test(v)) return true;
  if (v.length >= 4){
    var allSame = true;
    for (var i=1;i<v.length;i++){ if (v[i] !== v[0]){ allSame = false; break; } }
    if (allSame) return true;
  }
  return false;
}
function truthy(v){
  var low = v.toLowerCase();
  return low === "true" || low === "on" || low === "1" || low === "yes";
}
function stripQuotes(v){
  v = v.trim();
  if (v.length >= 2 && ((v.charAt(0)==='"' && v.charAt(v.length-1)==='"') || (v.charAt(0)==="'" && v.charAt(v.length-1)==="'"))){
    return v.slice(1,-1);
  }
  return v;
}

/* ---------- Parsing ---------- */
function parseConfig(text){
  var entries = [];   // {key, value, line}
  var notParsed = []; // {line, }
  var trimmed = text.replace(/\r\n/g,"\n");
  var t = trimmed.trim();

  if (t.charAt(0) === "{"){
    try {
      var obj = JSON.parse(t);
      if (obj && typeof obj === "object" && !Array.isArray(obj)){
        var rawLines = trimmed.split("\n");
        var keys = Object.keys(obj);
        for (var k=0;k<keys.length;k++){
          var key = String(keys[k]).toUpperCase();
          var lineNo = 1;
          for (var li=0; li<rawLines.length; li++){
            if (rawLines[li].indexOf(keys[k]) !== -1){ lineNo = li+1; break; }
          }
          entries.push({key:key, value:String(obj[keys[k]]), line:lineNo});
        }
        return {entries:entries, notParsed:notParsed};
      }
    } catch(e){ /* fall through to line parsing */ }
  }

  var lines = trimmed.split("\n");
  for (var i=0;i<lines.length;i++){
    var raw = lines[i];
    var s = raw.trim();
    var lineNo = i+1;
    if (s === "") continue;
    if (s.charAt(0) === "#" ) continue;
    if (s.charAt(0) === "{" || s.charAt(0) === "}" || s.charAt(0) === "[") { notParsed.push({line:lineNo}); continue; }
    var m = s.match(/^"?([A-Za-z_][A-Za-z0-9_.\-]*)"?\s*=\s*(.*)$/) || s.match(/^"?([A-Za-z_][A-Za-z0-9_.\-]*)"?\s*:\s+(.*)$/);
    if (m){
      var key2 = m[1].toUpperCase();
      var val = stripQuotes(m[2].trim());
      /* strip trailing inline comment for .env style values without spaces in value */
      entries.push({key:key2, value:val, line:lineNo});
    } else {
      notParsed.push({line:lineNo});
    }
  }
  return {entries:entries, notParsed:notParsed};
}

/* ---------- Audit ---------- */
function audit(text){
  var parsed = parseConfig(text);
  var entries = parsed.entries;
  var findings = [];
  function add(sev, line, key, issue, fix){
    findings.push({severity:sev, line:line, key:key, issue:issue, fix:fix});
  }
  parsed.notParsed.forEach(function(np){
    add("NOT PARSED", np.line, "—", "This line could not be parsed as a key/value setting, so it was not graded.", "Rewrite the line as KEY=value (or KEY: value), or remove it if it is not a setting.");
  });

  var byKey = {};
  entries.forEach(function(e){ (byKey[e.key] = byKey[e.key] || []).push(e); });
  function first(key){ return byKey[key] ? byKey[key][0] : null; }

  var recognizedCount = entries.filter(function(e){ return isRecognized(e.key); }).length;
  var envEntry = first("APP_ENV");
  var isProd = envEntry ? (envEntry.value.trim().toLowerCase() === "production") : false;

  /* APP_KEY */
  var appKey = first("APP_KEY");
  if (!appKey){
    if (recognizedCount > 0){
      add("BLOCKER", 0, "APP_KEY", "APP_KEY is missing. Coolify cannot encrypt sessions and stored credentials without an application key.", "Generate a long random application key (at least 32 characters) and set APP_KEY before deploying.");
    }
  } else if (!isEnvRef(appKey.value)){
    var akEx = containsAny(appKey.value, EXAMPLE_WORDS);
    if (appKey.value.length < 32){
      add("BLOCKER", appKey.line, "APP_KEY", "APP_KEY is only " + appKey.value.length + " characters long (value not shown). Keys under 32 characters are too weak for a platform that stores deploy credentials.", "Generate a fresh random application key of at least 32 characters and set APP_KEY to it.");
    } else if (akEx || hasRepeated(appKey.value)){
      add("BLOCKER", appKey.line, "APP_KEY", "APP_KEY looks like an example or placeholder value (value not shown). Placeholder keys are publicly known and effectively no key at all.", "Generate a fresh random application key of at least 32 characters and set APP_KEY to it.");
    }
  }

  /* APP_DEBUG */
  var dbg = first("APP_DEBUG");
  if (dbg && truthy(dbg.value)){
    add("HIGH", dbg.line, "APP_DEBUG", "Debug mode is turned on. Debug output can expose configuration details, credentials, and stack traces to anyone who can reach the app.", "Set APP_DEBUG=false for any deployed instance.");
  }

  /* APP_ENV */
  if (envEntry && envEntry.value.trim().toLowerCase() !== "production"){
    add("HIGH", envEntry.line, "APP_ENV", "The environment is not set to production, so development behavior (verbose errors, relaxed checks) may be active on a live instance.", "Set APP_ENV=production for a deployed instance.");
  }

  /* APP_URL */
  var url = first("APP_URL");
  if (url && url.value.trim().toLowerCase().indexOf("http://") === 0){
    add("HIGH", url.line, "APP_URL", "APP_URL uses plain http://. That is plaintext transport for a platform that holds deploy credentials — logins and sessions can be read in transit.", "Serve Coolify over HTTPS and set APP_URL to the https:// address.");
  }

  /* DB_PASSWORD / REDIS_PASSWORD */
  ["DB_PASSWORD","REDIS_PASSWORD"].forEach(function(k){
    var e = first(k);
    if (!e || e.value === "") return;
    if (isEnvRef(e.value)) return;
    if (e.value.length < 12){
      add("BLOCKER", e.line, k, k + " is set to a plaintext value only " + e.value.length + " characters long (value not shown). A short, literal credential in the config file is easily guessed and easily leaked.", "Move this credential into a secret store or environment reference (for example ${...}) and use a generated value of at least 12 characters.");
    } else {
      add("HIGH", e.line, k, k + " is set to a literal plaintext value " + e.value.length + " characters long (value not shown) rather than an environment reference. Anyone who can read this config file has the credential.", "Replace the literal value with an environment reference (for example ${...}) supplied from a secret store at deploy time.");
    }
  });

  /* PUSHER_APP_SECRET */
  var pusher = first("PUSHER_APP_SECRET");
  if (pusher && pusher.value !== "" && !isEnvRef(pusher.value)){
    var pEx = containsAny(pusher.value, EXAMPLE_WORDS_GENERIC);
    if (pusher.value.length < 16 || pEx){
      add("HIGH", pusher.line, "PUSHER_APP_SECRET", "PUSHER_APP_SECRET is a plaintext value " + pusher.value.length + " characters long (value not shown) that is short or looks like an example value, so it is guessable.", "Generate a fresh random secret of at least 16 characters and supply it through an environment reference.");
    }
  }

  /* ROOT_USER_PASSWORD */
  var rootPw = first("ROOT_USER_PASSWORD");
  if (rootPw && rootPw.value !== "" && !isEnvRef(rootPw.value)){
    var rEx = containsAny(rootPw.value, EXAMPLE_WORDS_GENERIC);
    if (rootPw.value.length < 12 || rEx){
      add("BLOCKER", rootPw.line, "ROOT_USER_PASSWORD", "The root account credential is only " + rootPw.value.length + " characters long (value not shown) and/or matches a well-known example value. The root account controls the whole platform.", "Set a unique generated root credential of at least 12 characters, and supply it through an environment reference rather than a literal value.");
    }
  }

  /* Registration */
  ["REGISTRATION_ENABLED","ALLOW_REGISTRATION"].forEach(function(k){
    var e = first(k);
    if (e && truthy(e.value) && isProd){
      add("HIGH", e.line, k, "Open registration is enabled on a production instance. Anyone who can reach this admin platform can create an account on it.", "Disable registration (set it to false) once the needed accounts exist.");
    }
  });

  /* FORCE_HTTPS / SSL off on production */
  ["FORCE_HTTPS","SSL_ENABLED","FORCE_SSL"].forEach(function(k){
    var e = first(k);
    if (e && isProd && (e.value.trim().toLowerCase() === "false" || e.value.trim().toLowerCase() === "0" || e.value.trim().toLowerCase() === "off")){
      add("WARNING", e.line, k, "HTTPS enforcement is switched off on a production instance, so traffic may fall back to plaintext.", "Turn HTTPS enforcement on for production and serve the platform over HTTPS.");
    }
  });

  /* Generic secret-named keys */
  var handled = {APP_KEY:1, DB_PASSWORD:1, REDIS_PASSWORD:1, PUSHER_APP_SECRET:1, ROOT_USER_PASSWORD:1};
  entries.forEach(function(e){
    if (handled[e.key]) return;
    if (!SECRET_NAME.test(e.key)) return;
    if (e.value === "" || isEnvRef(e.value)) return;
    var gEx = containsAny(e.value, EXAMPLE_WORDS_GENERIC);
    if (e.value.length < 16 || gEx){
      add("HIGH", e.line, e.key, "This secret-named setting holds a plaintext value " + e.value.length + " characters long (value not shown) that is short or looks like an example value.", "Generate a fresh random value of at least 16 characters and supply it through an environment reference.");
    } else {
      add("INFO", e.line, e.key, "This secret-named setting holds a plaintext value " + e.value.length + " characters long (value not shown). It is long enough, but a literal value in a config file can leak with the file.", "Consider supplying this value through an environment reference from a secret store.");
    }
  });

  /* Verdict */
  var counts = {BLOCKER:0, HIGH:0, WARNING:0, INFO:0, "NOT PARSED":0};
  findings.forEach(function(f){ if (counts.hasOwnProperty(f.severity)) counts[f.severity]++; });
  var verdict;
  if (recognizedCount === 0){
    verdict = "NOT ENOUGH TO GRADE";
  } else if (counts.BLOCKER > 0){
    verdict = "DO NOT DEPLOY";
  } else if (counts.HIGH > 0){
    verdict = "DEPLOY WITH FIXES";
  } else {
    verdict = "SAFE TO DEPLOY";
  }
  findings.sort(function(a,b){
    var order = {BLOCKER:0, HIGH:1, WARNING:2, INFO:3, "NOT PARSED":4};
    if (order[a.severity] !== order[b.severity]) return order[a.severity]-order[b.severity];
    return a.line - b.line;
  });
  return {
    tool: "J-Dawgs Coolify Server Config Safety Auditor™",
    verdict: verdict,
    counts: counts,
    recognizedKeys: recognizedCount,
    parsedSettings: entries.length,
    findings: findings
  };
}

/* ---------- Rendering ---------- */
function esc(s){
  return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
}
function buildTextReport(r){
  var out = [];
  out.push("J-Dawgs Coolify Server Config Safety Auditor\u2122 \u2014 Report");
  out.push("Verdict: " + r.verdict);
  out.push("Counts: BLOCKER " + r.counts.BLOCKER + " | HIGH " + r.counts.HIGH + " | WARNING " + r.counts.WARNING + " | INFO " + r.counts.INFO + " | NOT PARSED " + r.counts["NOT PARSED"]);
  out.push("Recognized Coolify keys: " + r.recognizedKeys + " | Parsed settings: " + r.parsedSettings);
  out.push("Secret values are never included in this report; secrets are identified by key name, line, and value length only.");
  out.push("");
  if (r.findings.length === 0){
    out.push("Findings: none.");
  } else {
    out.push("Findings:");
    r.findings.forEach(function(f,i){
      out.push((i+1) + ". [" + f.severity + "] Line " + (f.line === 0 ? "\u2014 (missing)" : f.line) + " \u00b7 " + f.key);
      out.push("   Issue: " + f.issue);
      out.push("   Fix: " + f.fix);
    });
  }
  out.push("");
  out.push("Note: this audit ran entirely in the browser. It does not connect to any server, does not start Coolify, and does not verify the config will load.");
  return out.join("\n");
}

var lastReport = null;
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_WORDS": (typeof EXAMPLE_WORDS !== 'undefined' ? EXAMPLE_WORDS : undefined), "EXAMPLE_WORDS_GENERIC": (typeof EXAMPLE_WORDS_GENERIC !== 'undefined' ? EXAMPLE_WORDS_GENERIC : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-coolify-server-config-safety-auditortm',
  name: 'J-Dawgs Coolify Server Config Safety Auditor',
  description: 'Grades a pasted Coolify server config offline into one deploy verdict, secrets by key name/line/length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_WORDS": __core["EXAMPLE_WORDS"], "EXAMPLE_WORDS_GENERIC": __core["EXAMPLE_WORDS_GENERIC"] }
};
