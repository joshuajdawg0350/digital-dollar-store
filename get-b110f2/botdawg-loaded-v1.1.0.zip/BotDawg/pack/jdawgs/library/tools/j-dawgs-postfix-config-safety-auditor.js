'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Postfix Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

var RISKY = [
"# Risky example - do not deploy this",
"myhostname = mail.example.com",
"mydomain = example.com",
"myorigin = $mydomain",
"inet_interfaces = all",
"mynetworks = 0.0.0.0/0, 127.0.0.0/8",
"mydestination = $myhostname, localhost.$mydomain, localhost",
"relay_domains = *",
"smtpd_relay_restrictions = permit_mynetworks, permit_sasl_authenticated",
"smtpd_recipient_restrictions = permit_mynetworks, permit_sasl_authenticated",
"smtpd_tls_security_level = encrypt",
"smtpd_tls_security_level = none",
"smtpd_sasl_auth_enable = yes",
"smtp_tls_security_level = may",
"message_size_limit = 0",
""
].join("\n");

var HARDENED = [
"# Hardened example",
"myhostname = mail.example.com",
"mydomain = example.com",
"myorigin = $mydomain",
"inet_interfaces = all",
"mynetworks = 127.0.0.0/8, 203.0.113.10/32",
"mydestination = $myhostname, localhost.$mydomain, localhost, $mydomain",
"relay_domains = example.com",
"smtpd_relay_restrictions = permit_mynetworks, permit_sasl_authenticated, reject_unauth_destination",
"smtpd_recipient_restrictions = permit_mynetworks, permit_sasl_authenticated, reject_unauth_destination",
"smtpd_tls_security_level = encrypt",
"smtp_tls_security_level = encrypt",
"smtpd_tls_cert_file = /etc/postfix/fullchain.pem",
"smtpd_tls_key_file = /etc/postfix/privkey.pem",
"smtpd_tls_protocols = !SSLv2, !SSLv3, !TLSv1, !TLSv1.1",
"smtp_tls_protocols = !SSLv2, !SSLv3, !TLSv1, !TLSv1.1",
"smtpd_tls_auth_only = yes",
"smtpd_sasl_auth_enable = yes",
"smtpd_sasl_type = dovecot",
"smtpd_sasl_path = private/auth",
"smtpd_helo_required = yes",
"message_size_limit = 26214400",
""
].join("\n");

var KNOWN_KEYS = {};
("myhostname mydomain myorigin mydestination mynetworks mynetworks_style inet_interfaces inet_protocols proxy_interfaces " +
"relay_domains relayhost relay_transport default_transport transport_maps sender_dependent_relayhost_maps " +
"smtpd_relay_restrictions smtpd_recipient_restrictions smtpd_sender_restrictions smtpd_helo_restrictions smtpd_client_restrictions smtpd_data_restrictions smtpd_end_of_data_restrictions smtpd_etrn_restrictions " +
"smtpd_tls_security_level smtp_tls_security_level smtpd_use_tls smtp_use_tls smtpd_tls_cert_file smtpd_tls_key_file smtp_tls_cert_file smtp_tls_key_file smtpd_tls_CAfile smtp_tls_CAfile " +
"smtpd_tls_protocols smtp_tls_protocols smtpd_tls_mandatory_protocols smtp_tls_mandatory_protocols smtpd_tls_exclude_ciphers smtp_tls_exclude_ciphers smtpd_tls_ciphers smtp_tls_ciphers tls_preempt_cipherlist smtpd_tls_dh1024_param_file smtpd_tls_eecdh_grade smtpd_tls_loglevel smtp_tls_loglevel smtpd_tls_received_header smtpd_tls_ask_ccert smtpd_tls_req_ccert smtpd_tls_session_cache_database smtpd_tls_session_cache_timeout smtp_tls_session_cache_enabled smtp_tls_session_cache_database " +
"smtpd_tls_auth_only smtpd_sasl_auth_enable smtpd_sasl_type smtpd_sasl_path smtpd_sasl_security_options smtpd_sasl_local_domain smtpd_sasl_authenticated_header smtp_sasl_auth_enable smtp_sasl_security_options smtp_sasl_password_maps smtp_sasl_mechanism_filter smtp_sasl_tls_security_options smtp_tls_note_starttls_offer " +
"smtpd_helo_required message_size_limit mailbox_size_limit virtual_mailbox_limit smtpd_banner biff append_dot_mydomain append_at_myorigin masquerade_domains masquerade_classes masquerade_exceptions always_add_missing_headers local_header_rewrite_clients " +
"local_recipient_maps unknown_local_recipient_reject_code alias_maps alias_database virtual_alias_maps virtual_alias_domains virtual_mailbox_domains virtual_mailbox_maps virtual_mailbox_base virtual_uid_maps virtual_gid_maps virtual_minimum_uid virtual_transport " +
"header_checks mime_header_checks body_checks nested_header_checks content_filter smtpd_milters non_smtpd_milters milter_default_action milter_protocol milter_connect_macros milter_end_of_data_macros " +
"queue_directory command_directory daemon_directory data_directory mail_owner setgid_group sendmail_path mailq_path newaliases_path manpage_directory sample_directory readme_directory html_directory mail_spool_directory shlib_directory meta_directory compatibility_level " +
"debugger_command soft_bounce recipient_delimiter home_mailbox mailbox_command mailbox_transport fallback_transport luser_relay local_transport error_notice_recipient notify_classes address_verify_map canonical_maps sender_canonical_maps recipient_canonical_maps sender_canonical_classes recipient_canonical_classes " +
"smtpd_delay_reject smtpd_error_sleep_time smtpd_soft_error_limit smtpd_hard_error_limit smtpd_client_connection_rate_limit smtpd_client_connection_count_limit anvil_rate_time_unit smtpd_peername_lookup disable_vrfy_command strict_rfc821_envelopes smtpd_reject_unlisted_recipient smtpd_reject_unlisted_sender " +
"tls_daemon_random_bytes tls_random_source tlsmgr_ask_ccache tlsmgr_use_ccache postlog_file postlog_path syslog_facility syslog_name import_environment exported_attribute owner_request_special parent_domain_matches_subdomains smtpd_forbidden_commands smtpd_discard_ehlo_keywords smtpd_etrn_restrictions permit_mx_backup_networks fallback_relay smtp_helo_name smtp_host_lookup postscreen_dnsbl_sites postscreen_access_list postscreen_greet_action postscreen_dnsbl_action postscreen_blacklist_action postscreen_whitelist_action " +
"check_policy_service defer_if_permit defer_if_reject authorized_submit_users authorized_mailq_users authorized_flush_users lmtp_host_port smtp_generic_maps smtp_connection_cache_destinations smtp_connection_cache_on_demand smtp_dns_support_level dnsblog_reply_delay").split(/\s+/).forEach(function(k){ if(k) KNOWN_KEYS[k]=true; });

var SECURITY_KEYS = {};
("mynetworks inet_interfaces relay_domains smtpd_relay_restrictions smtpd_recipient_restrictions smtpd_tls_security_level smtp_tls_security_level smtpd_tls_cert_file smtpd_tls_key_file smtpd_tls_protocols smtp_tls_protocols smtpd_tls_mandatory_protocols smtp_tls_mandatory_protocols smtpd_tls_auth_only smtpd_sasl_auth_enable smtpd_sasl_type smtpd_sasl_path smtpd_helo_required message_size_limit smtpd_milters content_filter").split(/\s+/).forEach(function(k){ if(k) SECURITY_KEYS[k]=true; });

var SECRET_KEY_RE = /(pass(word)?|passwd|pwd|secret|credential|api[-_]?key|auth[-_]?token|access[-_]?token|private[-_]?key[-_]?pass)/i;

var secrets = [];
function collectSecrets(entries){
  secrets = [];
  entries.forEach(function(e){
    if (SECRET_KEY_RE.test(e.key) && !/_maps$/.test(e.key)) {
      var v = e.value;
      if (v && !/^\//.test(v) && !/^(hash|btree|regexp|pcre|proxy|lmdb|mysql|pgsql|ldap|sqlite):/i.test(v)) {
        if (v.length >= 4) secrets.push(v);
        v.split(/[\s,:;]+/).forEach(function(tok){ if (tok.length >= 4) secrets.push(tok); });
      }
    }
  });
}
function scrub(text){
  var out = String(text);
  secrets.forEach(function(s){ if (s) out = out.split(s).join("[REDACTED]"); });
  return out;
}

function parseConfig(text){
  var physical = String(text).replace(/\r\n?/g, "\n").split("\n");
  var logical = [];
  var current = null;
  for (var i = 0; i < physical.length; i++) {
    var raw = physical[i];
    var lineNo = i + 1;
    if (/^\s/.test(raw) && raw.trim() !== "" && current !== null) {
      current.text += " " + raw.trim();
      continue;
    }
    if (raw.trim() === "") { current = null; continue; }
    if (raw.trim().charAt(0) === "#") { current = null; continue; }
    current = { line: lineNo, text: raw.trim() };
    logical.push(current);
  }
  var entries = [], unparsable = [];
  logical.forEach(function(l){
    var m = l.text.match(/^([A-Za-z0-9_]+)\s*=\s*(.*)$/);
    if (m) entries.push({ key: m[1], value: m[2].trim(), line: l.line });
    else unparsable.push({ line: l.line, text: l.text });
  });
  return { entries: entries, unparsable: unparsable };
}

function audit(text, expectedDomainsRaw){
  var parsed = parseConfig(text);
  var entries = parsed.entries;
  collectSecrets(entries);
  var findings = [];
  function add(line, setting, severity, meaning, fix){
    findings.push({ line: (line === null || line === undefined) ? null : line, setting: setting, severity: severity, meaning: scrub(meaning), fix: scrub(fix) });
  }

  var byKey = {};
  entries.forEach(function(e){ (byKey[e.key] = byKey[e.key] || []).push(e); });
  function eff(key){ var l = byKey[key]; return l ? l[l.length - 1] : null; }
  function val(key){ var e = eff(key); return e ? e.value : null; }
  function valLC(key){ var v = val(key); return v === null ? null : v.toLowerCase().trim(); }
  function tokens(v){ return v ? v.split(/[,\s]+/).filter(Boolean) : []; }

  var saslOn = valLC("smtpd_sasl_auth_enable") === "yes";

  /* Unparsable lines */
  parsed.unparsable.forEach(function(u){
    add(u.line, "(line " + u.line + ")", "WARNING",
      "This line could not be parsed as a key = value setting, so it was excluded from the audit. Postfix would warn about it or ignore it; either way it is doing nothing you can rely on.",
      "Fix the line so it reads key = value, or delete it. Never leave a line in main.cf that the audit had to skip.");
  });

  /* Inline secrets - key name only, value never shown */
  entries.forEach(function(e){
    if (SECRET_KEY_RE.test(e.key) && !/_maps$/.test(e.key)) {
      var v = e.value;
      var looksLikeFile = /^\//.test(v) || /^(hash|btree|regexp|pcre|proxy|lmdb|mysql|pgsql|ldap|sqlite):/i.test(v);
      if (!looksLikeFile && v !== "") {
        add(e.line, e.key, "WARNING",
          "A secret appears to be stored inline under this key name. The value is redacted here and never appears in any output from this tool.",
          "Move the secret into a protected lookup file (for example a hashed sasl_passwd map) with owner-only file permissions, and reference the file from main.cf instead of pasting the secret itself.");
      }
    }
  });

  /* Duplicate keys - Postfix uses the LAST value */
  Object.keys(byKey).forEach(function(key){
    var list = byKey[key];
    if (list.length < 2) return;
    var first = list[0], last = list[list.length - 1];
    var disagree = list.some(function(e){ return e.value !== last.value; });
    var sev = (disagree && SECURITY_KEYS[key]) ? "WARNING" : "INFO";
    var lines = list.map(function(e){ return e.line; }).join(" and ");
    add(last.line, key, sev,
      "This key is set " + list.length + " times, on lines " + lines + ". Postfix uses the LAST value (line " + last.line + "), so the earlier setting" + (list.length > 2 ? "s are" : " is") + " dead text. Every other check in this audit graded the effective value from line " + last.line + "." + (disagree ? " The values disagree, and this is a security-relevant setting, so the config does not say what its author probably meant." : " The values agree, so the behavior is unambiguous, but the dead line is still a trap for the next edit."),
      "Delete every occurrence except the one on line " + last.line + ", and make sure that remaining value is the one you intend.");
  });

  /* 1. OPEN RELAY */
  var mn = eff("mynetworks");
  if (mn) {
    var mnToks = tokens(mn.value);
    var wild = mnToks.filter(function(t){ return t === "0.0.0.0/0" || t === "::/0" || t === "[::]/0" || t === "0.0.0.0/00"; });
    if (wild.length) {
      add(mn.line, "mynetworks", "BLOCKER",
        "mynetworks trusts " + wild.join(", ") + " - every network on the internet. Combined with permit_mynetworks anywhere in the relay restrictions, any stranger can relay mail through this server: an open relay, which gets the server blocklisted and abused for spam within days.",
        "Restrict mynetworks to the networks that are actually yours, for example 127.0.0.0/8 plus specific /32 host addresses. Never use a /0 network here.");
    }
  }

  function restrictionProblem(key){
    var e = eff(key);
    if (!e) return null;
    var toks = tokens(e.value.toLowerCase());
    if (toks.indexOf("permit") !== -1) return { e: e, why: "bare-permit" };
    var pi = toks.indexOf("permit_mynetworks");
    var ri = toks.indexOf("reject_unauth_destination");
    if (pi !== -1 && (ri === -1 || ri < pi)) return { e: e, why: "no-reject-after-permit" };
    return null;
  }
  ["smtpd_relay_restrictions", "smtpd_recipient_restrictions"].forEach(function(key){
    var p = restrictionProblem(key);
    if (p) {
      add(p.e.line, key, "BLOCKER",
        p.why === "bare-permit"
          ? "This restriction list contains a bare permit, which allows the message unconditionally at that point - including relaying to outside destinations. That is an open relay."
          : "This restriction list contains permit_mynetworks with no reject_unauth_destination after it, so clients in mynetworks can relay to any destination on the internet without limit. If mynetworks is broad - or ever becomes broad - this server is an open relay.",
        "End the relay path with reject_unauth_destination, for example: permit_mynetworks, permit_sasl_authenticated, reject_unauth_destination.");
    }
  });

  var ii = eff("inet_interfaces");
  if (ii && ii.value.toLowerCase().trim() === "all") {
    var eitherMissing = !eff("smtpd_relay_restrictions") && !eff("smtpd_recipient_restrictions");
    var permissive = eitherMissing || !!restrictionProblem("smtpd_relay_restrictions") || !!restrictionProblem("smtpd_recipient_restrictions");
    if (permissive) {
      add(ii.line, "inet_interfaces", "BLOCKER",
        "inet_interfaces = all listens on every network interface while the relay restrictions are permissive (or unset). The server is reachable from the whole internet and will relay for it - the classic open-relay combination.",
        "Either narrow inet_interfaces to the interfaces that should accept mail, or close the relay restrictions with reject_unauth_destination and a tight mynetworks. Do not ship the combination.");
    }
  }

  var rd = eff("relay_domains");
  var expected = (expectedDomainsRaw || "").split(",").map(function(s){ return s.trim().toLowerCase(); }).filter(Boolean);
  if (rd && rd.value.trim() !== "") {
    var rdToks = tokens(rd.value);
    if (rdToks.indexOf("*") !== -1 || rdToks.indexOf("$relay_domains") !== -1 && false) {
      add(rd.line, "relay_domains", "BLOCKER",
        "relay_domains is set to a wildcard, so this server accepts relay responsibility for mail addressed to any domain anywhere.",
        "List exactly the domains this server relays for, and nothing else.");
    } else if (expected.length) {
      rdToks.forEach(function(t){
        if (t.charAt(0) === "$") return;
        var tl = t.toLowerCase();
        var broader = expected.some(function(x){ return x !== tl && x.slice(-(tl.length + 1)) === "." + tl; });
        if (expected.indexOf(tl) === -1) {
          add(rd.line, "relay_domains", "WARNING",
            "relay_domains includes " + t + ", which is not in the list of domains you said this server should relay for (" + expected.join(", ") + ")." + (broader ? " It is also a parent of a listed domain, which makes the relay scope broader than intended." : ""),
            "Remove " + t + " from relay_domains, or add it to the expected-domains list if relaying for it is deliberate.");
        } else if (broader) {
          add(rd.line, "relay_domains", "WARNING",
            "relay_domains includes the parent domain " + t + ", which also covers every subdomain - broader than the exact domains you listed.",
            "Relay for the exact domains only, or confirm in writing that every subdomain is in scope before deploying.");
        }
      });
    }
  }

  /* 2. TLS */
  var tlsLevel = eff("smtpd_tls_security_level");
  var tlsLvl = tlsLevel ? tlsLevel.value.toLowerCase().trim() : null;
  if (!tlsLevel || tlsLvl === "" || tlsLvl === "none") {
    add(tlsLevel ? tlsLevel.line : null, "smtpd_tls_security_level", saslOn ? "BLOCKER" : "WARNING",
      !tlsLevel
        ? "smtpd_tls_security_level is not set in this file. Postfix then defaults to no enforced inbound TLS, so connections fall back to plaintext." + (saslOn ? " SASL authentication is enabled, so login credentials can cross the network in plaintext - that combination is a blocker." : "")
        : "smtpd_tls_security_level = none turns inbound TLS off: mail and, with SASL enabled, login credentials cross the network in plaintext." + (saslOn ? " Because smtpd_sasl_auth_enable = yes, this is graded as a blocker." : ""),
      "Set smtpd_tls_security_level = encrypt (or dane / fingerprint where you manage the other side), and set smtpd_tls_cert_file and smtpd_tls_key_file to real certificate paths.");
  } else if (["encrypt", "dane", "fingerprint", "secure", "verify"].indexOf(tlsLvl) !== -1) {
    var meanings = {
      encrypt: "Inbound TLS is mandatory (encrypt): clients must use STARTTLS before mail is accepted. Good posture.",
      dane: "Inbound TLS uses DANE (dane): certificate trust is anchored in DNSSEC-published TLSA records. Strong, provided the TLSA records are maintained.",
      fingerprint: "Inbound TLS uses certificate fingerprint matching (fingerprint): only certificates with the configured fingerprints are trusted. Strong for a closed set of peers, brittle if certificates rotate.",
      secure: "Inbound TLS requires a verified certificate matching the destination (secure). Strong posture.",
      verify: "Inbound TLS requires a verified certificate (verify). Strong posture."
    };
    add(tlsLevel.line, "smtpd_tls_security_level", "INFO", meanings[tlsLvl], "No change needed for this setting.");
  } else if (tlsLvl === "may") {
    add(tlsLevel.line, "smtpd_tls_security_level", "INFO",
      "Inbound TLS is opportunistic (may): STARTTLS is offered, but plaintext connections are still accepted, so a network attacker can strip the upgrade.",
      "Consider smtpd_tls_security_level = encrypt if your senders can be required to use TLS.");
  }

  var outLevel = eff("smtp_tls_security_level");
  if (!outLevel) {
    add(null, "smtp_tls_security_level", "WARNING",
      "smtp_tls_security_level is not set, so outbound TLS is opportunistic at best and mail to other servers can leave in plaintext without anyone noticing.",
      "Set smtp_tls_security_level = encrypt, or dane if your DNS is DNSSEC-signed and you publish TLSA records.");
  } else {
    var ol = outLevel.value.toLowerCase().trim();
    if (ol === "none") {
      add(outLevel.line, "smtp_tls_security_level", "WARNING",
        "smtp_tls_security_level = none sends outbound mail in plaintext.",
        "Set smtp_tls_security_level = encrypt or dane.");
    } else if (["encrypt", "dane", "fingerprint", "secure", "verify"].indexOf(ol) !== -1) {
      add(outLevel.line, "smtp_tls_security_level", "INFO",
        "Outbound TLS level is " + ol + ": delivery to other servers is protected by TLS at this level.",
        "No change needed for this setting.");
    } else if (ol === "may") {
      add(outLevel.line, "smtp_tls_security_level", "INFO",
        "Outbound TLS is opportunistic (may): TLS is used when the receiving server offers it, plaintext otherwise.",
        "Consider encrypt or dane for destinations you control.");
    }
  }

  if (tlsLvl && ["may", "encrypt", "dane", "fingerprint", "secure", "verify"].indexOf(tlsLvl) !== -1) {
    var cert = eff("smtpd_tls_cert_file"), keyf = eff("smtpd_tls_key_file");
    var certMissing = !cert || cert.value.trim() === "";
    var keyMissing = !keyf || keyf.value.trim() === "";
    if (certMissing || keyMissing) {
      var missingNames = [];
      if (certMissing) missingNames.push("smtpd_tls_cert_file");
      if (keyMissing) missingNames.push("smtpd_tls_key_file");
      add(tlsLevel.line, missingNames.join(" / "), "WARNING",
        "TLS is set to " + tlsLvl + " but " + missingNames.join(" and ") + " " + (missingNames.length > 1 ? "are" : "is") + " not set: certificate paths not set in this file - NOT VERIFIED whether the files exist. Without a certificate and key, STARTTLS cannot actually be offered.",
        "Set smtpd_tls_cert_file and smtpd_tls_key_file to the real certificate and private-key paths on the server, then confirm the files exist and the key is readable only by root.");
    }
  }

  ["smtpd_tls_protocols", "smtp_tls_protocols", "smtpd_tls_mandatory_protocols", "smtp_tls_mandatory_protocols"].forEach(function(key){
    var e = eff(key);
    if (!e) return;
    var kept = tokens(e.value).filter(function(t){ return t.charAt(0) !== "!" && t.charAt(0) !== "-"; }).join(" ");
    var bad = [];
    if (/SSLv2/i.test(kept)) bad.push("SSLv2");
    if (/SSLv3/i.test(kept)) bad.push("SSLv3");
    if (/TLSv1\.0/i.test(kept) || /TLSv1(?![\d.])/i.test(kept)) bad.push("TLSv1.0");
    if (bad.length) {
      add(e.line, key, "WARNING",
        "This protocol list still allows " + bad.join(", ") + ". Those protocol versions are broken or deprecated and expose sessions to known downgrade and decryption attacks.",
        "Set " + key + " = !SSLv2, !SSLv3, !TLSv1, !TLSv1.1 so only TLS 1.2 and newer are used.");
    }
  });

  /* 3. AUTH */
  if (saslOn) {
    var authOnly = valLC("smtpd_tls_auth_only") === "yes";
    if (!authOnly) {
      add(eff("smtpd_sasl_auth_enable").line, "smtpd_sasl_auth_enable", "WARNING",
        "SASL authentication is enabled but smtpd_tls_auth_only is not yes, so clients may authenticate over a plaintext connection and send reusable credentials in the clear.",
        "Set smtpd_tls_auth_only = yes so logins are only accepted after STARTTLS is established.");
    }
    var st = eff("smtpd_sasl_type"), sp = eff("smtpd_sasl_path");
    if (!st || !sp || st.value.trim() === "" || sp.value.trim() === "") {
      var miss = [];
      if (!st || st.value.trim() === "") miss.push("smtpd_sasl_type");
      if (!sp || sp.value.trim() === "") miss.push("smtpd_sasl_path");
      add(eff("smtpd_sasl_auth_enable").line, miss.join(" / "), "INFO",
        "Authentication is enabled but " + miss.join(" and ") + " " + (miss.length > 1 ? "are" : "is") + " missing from this file, so the SASL backend this server talks to is NOT CHECKED here - it may be set elsewhere or may not exist at all.",
        "Set smtpd_sasl_type (for example dovecot or cyrus) and smtpd_sasl_path to the authentication socket, and verify the backend service is running.");
    }
  }

  /* 5. Hygiene */
  var msl = eff("message_size_limit");
  if (msl && msl.value.trim() === "0") {
    add(msl.line, "message_size_limit", "WARNING",
      "message_size_limit = 0 means unlimited message size: a single sender can fill the queue disk with enormous messages.",
      "Set a real limit, for example message_size_limit = 26214400 (25 MB), matched to what your users actually send.");
  }
  if (!eff("smtpd_helo_required")) {
    add(null, "smtpd_helo_required", "INFO",
      "smtpd_helo_required is not set, so clients are not required to greet with HELO/EHLO before sending. Postfix defaults to no here; requiring it rejects a class of sloppy spam senders for free.",
      "Set smtpd_helo_required = yes.");
  } else if (valLC("smtpd_helo_required") === "no") {
    add(eff("smtpd_helo_required").line, "smtpd_helo_required", "INFO",
      "smtpd_helo_required = no explicitly allows clients to skip the HELO/EHLO greeting.",
      "Set smtpd_helo_required = yes unless a known broken client forces the exception.");
  }

  /* Unknown / possibly misspelled keys - named, never interpreted */
  var unknownSeen = {};
  entries.forEach(function(e){
    if (!KNOWN_KEYS[e.key] && !unknownSeen[e.key]) {
      unknownSeen[e.key] = e;
    }
  });
  Object.keys(unknownSeen).forEach(function(key){
    add(unknownSeen[key].line, key, "INFO",
      "NOT AUDITED: this auditor does not recognize a setting named " + key + ", so its effect was not audited. It may be a newer Postfix parameter, a plugin setting, or a misspelling of a common key - a misspelled security setting silently does nothing.",
      "Check the spelling against the postconf(5) manual. If the name is correct and current, treat this as a gap in this audit, not as a pass.");
  });

  var rank = { BLOCKER: 0, WARNING: 1, INFO: 2 };
  findings.sort(function(a, b){
    if (rank[a.severity] !== rank[b.severity]) return rank[a.severity] - rank[b.severity];
    var la = a.line === null ? 1e9 : a.line, lb = b.line === null ? 1e9 : b.line;
    if (la !== lb) return la - lb;
    return a.setting < b.setting ? -1 : (a.setting > b.setting ? 1 : 0);
  });

  var counts = { BLOCKER: 0, WARNING: 0, INFO: 0 };
  findings.forEach(function(f){ counts[f.severity]++; });
  var verdict = counts.BLOCKER > 0 ? "DO NOT DEPLOY" : (counts.WARNING > 0 ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY");

  var notChecked = [
    "Certificate files themselves - whether the files named by smtpd_tls_cert_file / smtpd_tls_key_file exist, are in date, match the key, and cover the hostname. NOT CHECKED.",
    "DNS - MX records, SPF, DKIM, DMARC, and PTR / reverse DNS for this server. None of it is in the pasted file. NOT CHECKED.",
    "Firewall rules, NAT, and which networks can actually reach ports 25 / 465 / 587 on the live machine. NOT CHECKED.",
    "master.cf - only main.cf text was pasted and audited; submission and other service definitions in master.cf can change everything above. NOT CHECKED.",
    "Lookup tables and map files referenced from main.cf (transport maps, SASL password maps, header checks and similar) - their contents were not pasted. NOT CHECKED.",
    "The SASL backend service itself (Dovecot or Cyrus configuration, account database, password strength). NOT CHECKED.",
    "Whether a running server actually loads this exact file, and live open-relay behavior - this audit never connects to any server. NOT CHECKED."
  ];
  var unknownNames = Object.keys(unknownSeen);
  if (unknownNames.length) {
    notChecked.push("Unrecognized settings, NOT AUDITED by name: " + unknownNames.join(", ") + ".");
  }

  return { verdict: verdict, counts: counts, findings: findings, notChecked: notChecked, entriesCount: entries.length };
}
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-postfix-config-safety-auditor',
  name: 'J-Dawgs Postfix Config Safety Auditor',
  description: 'Validation on an installed server stops at syntax; this grades a pasted main.cf anywhere — open-relay exposure, TLS and plaintext-auth posture, duplicate keys graded last-value-wins, secrets flagged by key name only — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
