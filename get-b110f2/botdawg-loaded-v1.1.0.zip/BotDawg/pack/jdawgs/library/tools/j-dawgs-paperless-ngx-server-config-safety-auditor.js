'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Paperless-ngx Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var RISKY = [
        "# Paperless-ngx - copied from a tutorial, never hardened",
        "PAPERLESS_SECRET_KEY=changeme",
        "PAPERLESS_ADMIN_USER=paperless",
        "PAPERLESS_ADMIN_PASSWORD=paperless123",
        "PAPERLESS_URL=http://docs.example-company.com",
        "PAPERLESS_ALLOWED_HOSTS=*",
        "PAPERLESS_CORS_ALLOWED_HOSTS=*",
        "PAPERLESS_DEBUG=true",
        "PAPERLESS_DBHOST=db.internal.example-company.com",
        "PAPERLESS_DBNAME=paperless",
        "PAPERLESS_DBUSER=paperless",
        "PAPERLESS_DBPASS=dbpass123",
        "PAPERLESS_MEDIA_ROOT=/usr/src/paperless/media",
        "PAPERLESS_CONSUMPTION_DIR=/usr/src/paperless/media/documents",
        "PAPERLESS_OCR_LANGUAGE=eng"
      ].join("\n");

      var HARDENED = [
        "# Paperless-ngx - hardened deployment",
        "PAPERLESS_SECRET_KEY=k9$Xv2!mQp7#LzR4&nT8*wY3^sDf6GhJ1@bN5%cV0xEaUoPqSrTzMhWjKlYd",
        "PAPERLESS_ADMIN_USER=jdawgs-admin",
        "PAPERLESS_ADMIN_PASSWORD=Tr7!falcon-QUIET-river-92",
        "PAPERLESS_URL=https://docs.example-company.com",
        "PAPERLESS_ALLOWED_HOSTS=docs.example-company.com",
        "PAPERLESS_CORS_ALLOWED_HOSTS=https://docs.example-company.com",
        "PAPERLESS_TRUSTED_PROXIES=10.0.0.5/32",
        "PAPERLESS_DEBUG=false",
        "PAPERLESS_DBHOST=db.internal.example-company.com",
        "PAPERLESS_DBNAME=paperless",
        "PAPERLESS_DBUSER=paperless",
        "PAPERLESS_DBPASS=Vx8!harbor-LANTERN-meadow-47",
        "PAPERLESS_DBSSLMODE=verify-full",
        "PAPERLESS_REDIS=redis://127.0.0.1:6379",
        "PAPERLESS_DATA_DIR=/usr/src/paperless/data",
        "PAPERLESS_MEDIA_ROOT=/usr/src/paperless/media",
        "PAPERLESS_CONSUMPTION_DIR=/consume",
        "PAPERLESS_OCR_LANGUAGE=eng",
        "PAPERLESS_TIME_ZONE=America/Chicago"
      ].join("\n");

      var AGENT_INPUT = [
        "PAPERLESS_URL=https://files.example.org",
        "PAPERLESS_ALLOWED_HOSTS=files.example.org",
        "PAPERLESS_DEBUG=false",
        "PAPERLESS_ADMIN_PASSWORD=short1"
      ].join("\n");

      var AGENT_BLOCK = [
        "TASK: Audit this Paperless-ngx configuration with the J-Dawgs Paperless-ngx",
        "Server Config Safety Auditor. Paste the input below into the auditor and",
        "report back the single verdict plus every BLOCKER and FIX finding.",
        "",
        "RULE: Never repeat a secret value back. Report passwords and keys by key",
        "name, line number, and length only - exactly as the auditor does.",
        "",
        "INPUT:",
        AGENT_INPUT,
        "",
        "EXPECTED VERDICT: DO NOT DEPLOY",
        "Why: PAPERLESS_SECRET_KEY is missing entirely (BLOCKER), and",
        "PAPERLESS_ADMIN_PASSWORD on line 4 is only 6 characters long (BLOCKER).",
        "The https URL, explicit allowed hosts, and DEBUG=false lines pass."
      ].join("\n");

      var SECRET_RE = /(SECRET|PASS|TOKEN|PRIVATE|APIKEY|API_KEY)/;
      var COMMON_SECRETS = ["admin","password","paperless","changeme","change-me","123456","12345678","postgres","redis","letmein","root","test","secret","paperless123","dbpass123"];
      var EXAMPLE_MARKERS = ["changeme","change-me","change_me","example","django-insecure","your-secret","your_secret","insecure","placeholder","replace-me","replace_me","xxxxxxxx"];

      function isSecretKey(key){
        return SECRET_RE.test(key) || key === "DATABASE_URL";
      }
      function truthy(v){
        var s = String(v).trim().toLowerCase();
        return s === "true" || s === "1" || s === "yes" || s === "on";
      }
      function falsy(v){
        var s = String(v).trim().toLowerCase();
        return s === "false" || s === "0" || s === "no" || s === "off" || s === "";
      }
      function stripQuotes(v){
        v = String(v).trim();
        if (v.length >= 2 && ((v.charAt(0) === '"' && v.charAt(v.length-1) === '"') || (v.charAt(0) === "'" && v.charAt(v.length-1) === "'"))) {
          return v.slice(1, -1);
        }
        return v;
      }
      function hostOf(url){
        var m = String(url).match(/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\/([^\/:?#]+)/);
        if (m) return m[1].toLowerCase();
        var m2 = String(url).match(/^([^\/:?#]+)/);
        return m2 ? m2[1].toLowerCase() : "";
      }
      function schemeOf(url){
        var m = String(url).match(/^([a-zA-Z][a-zA-Z0-9+.-]*):\/\//);
        return m ? m[1].toLowerCase() : "";
      }
      function isPrivateHost(h){
        if (!h) return false;
        if (h === "localhost" || h === "::1") return true;
        if (/\.(local|lan|internal|home\.arpa)$/.test(h)) return true;
        if (/^127\./.test(h) || /^10\./.test(h) || /^192\.168\./.test(h)) return true;
        var m = h.match(/^172\.(\d+)\./);
        if (m && +m[1] >= 16 && +m[1] <= 31) return true;
        if (!/\./.test(h)) return true; /* single-label name: LAN / container network */
        return false;
      }
      function splitList(v){
        return String(v).split(/[\s,]+/).filter(function(x){ return x.length > 0; });
      }

      function parseConfig(text){
        var lines = String(text == null ? "" : text).split(/\r?\n/);
        var entries = {};   /* key -> {key, value, line} (last one wins, like a server) */
        var order = [];
        var notParsed = [];
        for (var i = 0; i < lines.length; i++){
          var lineNo = i + 1;
          var raw = lines[i];
          var t = raw.trim();
          if (t === "" || t.charAt(0) === "#") continue;
          var work = t.replace(/^-\s+/, "").replace(/^export\s+/, "");
          var m = work.match(/^([A-Za-z_][A-Za-z0-9_]*)\s*[:=]\s*(.*)$/);
          if (m) {
            var key = m[1].toUpperCase();
            var value = stripQuotes(m[2].replace(/\s+#.*$/, "").trim());
            if (!entries[key]) order.push(key);
            entries[key] = { key: key, value: value, line: lineNo };
          } else if (/^[A-Za-z0-9_.-]+:$/.test(work)) {
            /* structural YAML line such as "environment:" - not a setting, not an error */
            continue;
          } else {
            notParsed.push(lineNo);
          }
        }
        return { entries: entries, order: order, notParsed: notParsed, lineCount: lines.length };
      }

      function auditConfig(text){
        var parsed = parseConfig(text);
        var e = parsed.entries;
        var findings = [];
        function add(sev, key, line, title, detail){
          findings.push({ severity: sev, key: key || null, line: (line == null ? null : line), title: title, detail: detail });
        }
        function get(k){ return e[k] || null; }

        var paperlessCount = parsed.order.filter(function(k){ return k.indexOf("PAPERLESS_") === 0; }).length;

        if (parsed.order.length === 0 || paperlessCount < 3) {
          add("note", null, null, "This paste does not look like a Paperless-ngx configuration",
            "Only " + paperlessCount + " PAPERLESS_ setting(s) were recognized. A gradeable paste needs at least 3 PAPERLESS_ key=value lines (environment variables, docker-compose environment lines, or paperless.conf lines).");
          return finish("NOT ENOUGH TO GRADE", findings, parsed, paperlessCount);
        }

        /* ---- Secret key ---- */
        var sk = get("PAPERLESS_SECRET_KEY");
        if (!sk) {
          add("blocker", "PAPERLESS_SECRET_KEY", null, "Secret key is missing",
            "No PAPERLESS_SECRET_KEY appears in this paste. Paperless signs sessions and tokens with this key; a deployment running on a default or improvised key can be impersonated. Set a unique random value of 50+ characters and keep it out of version control.");
        } else {
          var skLow = sk.value.toLowerCase();
          var isExample = EXAMPLE_MARKERS.some(function(x){ return skLow.indexOf(x) !== -1; }) || COMMON_SECRETS.indexOf(skLow) !== -1;
          if (isExample) {
            add("blocker", "PAPERLESS_SECRET_KEY", sk.line, "Secret key is an example or placeholder value",
              "Line " + sk.line + ", length " + sk.value.length + ". The value matches a known example/placeholder pattern (the value itself is never shown here). Anyone who has seen the tutorial it came from knows your key. Generate a fresh random key.");
          } else if (sk.value.length < 32) {
            add("blocker", "PAPERLESS_SECRET_KEY", sk.line, "Secret key is too short",
              "Line " + sk.line + ", length " + sk.value.length + ". Short keys can be brute-forced offline. Use 50+ random characters.");
          } else if (sk.value.length < 50) {
            add("fix", "PAPERLESS_SECRET_KEY", sk.line, "Secret key is shorter than recommended",
              "Line " + sk.line + ", length " + sk.value.length + ". It clears the minimum, but 50+ random characters is the recommended length for PAPERLESS_SECRET_KEY.");
          } else {
            add("ok", "PAPERLESS_SECRET_KEY", sk.line, "Secret key present and long enough",
              "Line " + sk.line + ", length " + sk.value.length + ". Length and pattern checked only - this tool cannot verify the key is unique to your deployment or kept private.");
          }
        }

        /* ---- Passwords (values never rendered) ---- */
        var pwKeys = ["PAPERLESS_ADMIN_PASSWORD", "PAPERLESS_DBPASS", "POSTGRES_PASSWORD", "PAPERLESS_DB_PASSWORD", "DATABASE_URL"];
        pwKeys.forEach(function(k){
          var ent = get(k);
          if (!ent) return;
          var v = ent.value, low = v.toLowerCase();
          var guessable = COMMON_SECRETS.indexOf(low) !== -1 || low.indexOf("paperless") !== -1 || low.indexOf("postgres") !== -1 || low === "admin123";
          if (guessable) {
            add("blocker", k, ent.line, "Password is a common or guessable value",
              "Line " + ent.line + ", length " + v.length + " (value never shown). It matches a commonly used password pattern. Replace it with a unique random password of 16+ characters, ideally supplied through a secrets file rather than plaintext in the config.");
          } else if (v.length < 8) {
            add("blocker", k, ent.line, "Password is too short",
              "Line " + ent.line + ", length " + v.length + " (value never shown). Under 8 characters falls to guessing almost immediately. Use 16+ characters.");
          } else if (v.length < 12) {
            add("fix", k, ent.line, "Password is short",
              "Line " + ent.line + ", length " + v.length + " (value never shown). 12 characters is the floor; 16+ random characters is the target, ideally supplied through a secrets file rather than plaintext in the config.");
          } else {
            add("ok", k, ent.line, "Password present with adequate length",
              "Line " + ent.line + ", length " + v.length + " (value never shown). Only length and common-value patterns are checked - correctness and secrecy cannot be verified from a paste. Prefer a secrets file over plaintext where your setup supports it.");
          }
        });
        if (!get("PAPERLESS_ADMIN_PASSWORD")) {
          add("note", "PAPERLESS_ADMIN_PASSWORD", null, "No admin password in this paste",
            "That is fine if the admin account is created interactively or through a secrets file - it just cannot be graded from this paste.");
        }

        /* ---- DEBUG ---- */
        ["PAPERLESS_DEBUG", "DEBUG"].forEach(function(k){
          var ent = get(k);
          if (!ent) return;
          if (truthy(ent.value)) {
            add("blocker", k, ent.line, "DEBUG is enabled",
              "Line " + ent.line + ". DEBUG mode leaks stack traces, settings, and paths in error pages. Set it to false in anything reachable by other people.");
          } else if (falsy(ent.value)) {
            add("ok", k, ent.line, "DEBUG is off", "Line " + ent.line + ".");
          } else {
            add("fix", k, ent.line, "DEBUG value is unclear",
              "Line " + ent.line + ". The value is not a recognizable true/false. Set it explicitly to false for a deployment.");
          }
        });
        if (!get("PAPERLESS_DEBUG") && !get("DEBUG")) {
          add("note", "PAPERLESS_DEBUG", null, "DEBUG not set in this paste", "Paperless defaults to off, so this is only a problem if something outside this paste turns it on.");
        }

        /* ---- URL scheme ---- */
        var urlEnt = get("PAPERLESS_URL");
        var urlHost = "";
        if (!urlEnt || urlEnt.value === "") {
          add("fix", "PAPERLESS_URL", urlEnt ? urlEnt.line : null, "PAPERLESS_URL is not set",
            "Paperless needs its exact public address to build correct links, redirects, and security cookies - especially behind a reverse proxy. Set it, with https://, before deploying.");
        } else {
          var scheme = schemeOf(urlEnt.value);
          urlHost = hostOf(urlEnt.value);
          if (scheme === "https") {
            add("ok", "PAPERLESS_URL", urlEnt.line, "URL uses https", "Line " + urlEnt.line + ", host " + (urlHost || "(unparsed)") + ".");
          } else if (scheme === "http") {
            if (isPrivateHost(urlHost)) {
              add("note", "PAPERLESS_URL", urlEnt.line, "URL uses http on a local or private host",
                "Line " + urlEnt.line + ", host " + urlHost + ". Acceptable only while the server is never reachable from outside that private network. The moment it is exposed, logins and documents travel unencrypted.");
            } else {
              add("blocker", "PAPERLESS_URL", urlEnt.line, "URL uses http on a public host",
                "Line " + urlEnt.line + ", host " + (urlHost || "(unparsed)") + ". On a public address, http sends login credentials and document content in clear text. Serve it over https (usually at your reverse proxy) and set PAPERLESS_URL to the https address.");
            }
          } else {
            add("fix", "PAPERLESS_URL", urlEnt.line, "URL scheme is missing or unrecognized",
              "Line " + urlEnt.line + ". Set PAPERLESS_URL to the full address including https://.");
          }
        }

        /* ---- Allowed hosts ---- */
        var ah = get("PAPERLESS_ALLOWED_HOSTS");
        if (!ah || ah.value === "") {
          add("fix", "PAPERLESS_ALLOWED_HOSTS", ah ? ah.line : null, "Allowed hosts not set in this paste",
            "If the deployment relies on a permissive default, any Host header is accepted, which enables host-header attacks against password-reset links and caches. Set PAPERLESS_ALLOWED_HOSTS to your exact hostname(s).");
        } else {
          var hosts = splitList(ah.value);
          if (hosts.indexOf("*") !== -1) {
            add("blocker", "PAPERLESS_ALLOWED_HOSTS", ah.line, "Allowed hosts is a wildcard (*)",
              "Line " + ah.line + ". A wildcard disables Host-header protection entirely: any domain can be used to reach this server. List the exact hostname(s) instead.");
          } else {
            add("ok", "PAPERLESS_ALLOWED_HOSTS", ah.line, "Allowed hosts are explicit", "Line " + ah.line + ": " + hosts.join(", ") + ".");
            if (urlHost && hosts.indexOf(urlHost) === -1 && !isPrivateHost(urlHost)) {
              add("fix", "PAPERLESS_ALLOWED_HOSTS", ah.line, "URL host is not in the allowed hosts list",
                "PAPERLESS_URL points at " + urlHost + " but that host is not listed in PAPERLESS_ALLOWED_HOSTS, so the server will reject requests at its own public address. Add it or fix the URL.");
            }
          }
        }

        /* ---- CORS ---- */
        var cors = get("PAPERLESS_CORS_ALLOWED_HOSTS");
        if (!cors || cors.value === "") {
          add("note", "PAPERLESS_CORS_ALLOWED_HOSTS", null, "CORS hosts not set in this paste",
            "No cross-origin allowance is declared here, which is the restrictive default and fine for normal same-origin use.");
        } else if (splitList(cors.value).indexOf("*") !== -1) {
          add("fix", "PAPERLESS_CORS_ALLOWED_HOSTS", cors.line, "CORS allows every origin (*)",
            "Line " + cors.line + ". A wildcard lets any website make cross-origin requests to your Paperless API from a visitor's browser. Restrict it to the exact origin(s) that need API access - or remove it if none do.");
        } else {
          add("ok", "PAPERLESS_CORS_ALLOWED_HOSTS", cors.line, "CORS hosts are explicit", "Line " + cors.line + ".");
        }

        /* ---- Trusted proxies ---- */
        var tp = get("PAPERLESS_TRUSTED_PROXIES");
        if (!tp || tp.value === "") {
          if (urlEnt && urlEnt.value) {
            add("fix", "PAPERLESS_TRUSTED_PROXIES", null, "Trusted proxies not set while a public URL is",
              "Behind a reverse proxy, Paperless needs to know which proxy's forwarded headers (real IP, scheme, host) to trust, or client IPs and https detection go wrong. Set PAPERLESS_TRUSTED_PROXIES to your proxy's IP or narrow CIDR.");
          } else {
            add("note", "PAPERLESS_TRUSTED_PROXIES", null, "Trusted proxies not set in this paste",
              "Only a problem if the server sits behind a reverse proxy - then set it to that proxy's IP or narrow CIDR.");
          }
        } else {
          var tpList = splitList(tp.value);
          var wide = tpList.some(function(x){ return x === "*" || x === "0.0.0.0/0" || x === "::/0" || x === "0.0.0.0"; });
          if (wide) {
            add("blocker", "PAPERLESS_TRUSTED_PROXIES", tp.line, "Trusted proxies trusts everyone",
              "Line " + tp.line + ". Trusting forwarded headers from any source lets any client spoof its IP address and host. Restrict it to the exact proxy IP or a narrow CIDR.");
          } else {
            add("ok", "PAPERLESS_TRUSTED_PROXIES", tp.line, "Trusted proxies are specific", "Line " + tp.line + ": " + tpList.join(", ") + ".");
          }
        }

        /* ---- Header-based auth / auto-login ---- */
        var remoteUser = get("PAPERLESS_ENABLE_HTTP_REMOTE_USER");
        if (remoteUser && truthy(remoteUser.value)) {
          add("fix", "PAPERLESS_ENABLE_HTTP_REMOTE_USER", remoteUser.line, "HTTP remote-user authentication is enabled",
            "Line " + remoteUser.line + ". Paperless will trust a login header, so this is only safe when a proxy you control sets that header and strips it from outside requests - and PAPERLESS_TRUSTED_PROXIES is set narrowly.");
        }
        var autoLogin = get("PAPERLESS_AUTO_LOGIN_USERNAME");
        if (autoLogin && autoLogin.value !== "") {
          add("fix", "PAPERLESS_AUTO_LOGIN_USERNAME", autoLogin.line, "Auto-login username is configured",
            "Line " + autoLogin.line + ". Anyone who can open the web page is signed in as that user with no password. Only acceptable on a network nobody untrusted can reach.");
        }

        /* ---- Database SSL posture ---- */
        var dbHost = get("PAPERLESS_DBHOST");
        if (!dbHost || dbHost.value === "") {
          add("note", "PAPERLESS_DBHOST", null, "No database host in this paste",
            "The database may be SQLite, a linked container, or configured elsewhere - its SSL posture cannot be graded from this paste.");
        } else if (isPrivateHost(hostOf(dbHost.value)) || !/\./.test(dbHost.value)) {
          add("note", "PAPERLESS_DBHOST", dbHost.line, "Database host is local or on the container/private network",
            "Line " + dbHost.line + ". Database SSL matters most when traffic crosses a network you do not control; on a private container network it is a lesser concern, though still worth enabling where supported.");
        } else {
          var ssl = get("PAPERLESS_DBSSLMODE");
          if (!ssl || ssl.value === "") {
            add("fix", "PAPERLESS_DBSSLMODE", null, "No database SSL mode set for a remote database host",
              "PAPERLESS_DBHOST (line " + dbHost.line + ") points at a remote host but PAPERLESS_DBSSLMODE is not in this paste, so the connection may run unencrypted depending on the database default. Set PAPERLESS_DBSSLMODE=require at minimum, verify-full where certificates allow.");
          } else {
            var mode = ssl.value.toLowerCase();
            if (mode === "verify-full" || mode === "verify-ca" || mode === "require") {
              add("ok", "PAPERLESS_DBSSLMODE", ssl.line, "Database SSL mode is set", "Line " + ssl.line + ": " + mode + ".");
            } else {
              add("fix", "PAPERLESS_DBSSLMODE", ssl.line, "Database SSL mode is weak",
                "Line " + ssl.line + ": " + mode + ". For a remote database host use require, verify-ca, or verify-full so document metadata is not sent in clear text.");
            }
          }
        }

        /* ---- Consume folder exposure ---- */
        var consume = get("PAPERLESS_CONSUMPTION_DIR");
        var media = get("PAPERLESS_MEDIA_ROOT");
        var dataDir = get("PAPERLESS_DATA_DIR");
        if (!consume || consume.value === "") {
          add("note", "PAPERLESS_CONSUMPTION_DIR", null, "Consume directory not set in this paste",
            "Wherever it is set, keep the consume folder off any web-served path, give it restrictive permissions, and remember anything dropped into it is imported automatically.");
        } else {
          var cPath = consume.value.replace(/\/+$/, "");
          var overlaps = [media, dataDir].some(function(ent){
            if (!ent || !ent.value) return false;
            var p = ent.value.replace(/\/+$/, "");
            return cPath === p || cPath.indexOf(p + "/") === 0;
          });
          if (cPath === "/" || overlaps) {
            add("blocker", "PAPERLESS_CONSUMPTION_DIR", consume.line, "Consume folder overlaps a served or data folder",
              "Line " + consume.line + ". The consume directory sits inside (or equals) the media/data tree. Files waiting to be imported - often your most sensitive scans - should never live under a folder the application serves or stores processed documents in. Point consumption at its own dedicated directory.");
          } else if (/(^|\/)media(\/|$)/.test(cPath)) {
            add("fix", "PAPERLESS_CONSUMPTION_DIR", consume.line, "Consume folder sits under a media path",
              "Line " + consume.line + ". Double-check this path is not reachable through the web server or a shared media mount; the consume folder should be private and separate from served media.");
          } else {
            add("ok", "PAPERLESS_CONSUMPTION_DIR", consume.line, "Consume folder is separate from media/data",
              "Line " + consume.line + ". Keep its permissions restrictive - anything placed there is imported automatically.");
          }
        }

        /* ---- Redis ---- */
        var redis = get("PAPERLESS_REDIS");
        if (redis && redis.value) {
          var rv = redis.value;
          var hasCreds = /:\/\/[^\/@]+@/.test(rv);
          var rHost = hostOf(rv.replace(/^redis:\/\//, "http://"));
          if (hasCreds) {
            add("note", "PAPERLESS_REDIS", redis.line, "Redis address embeds credentials",
              "Line " + redis.line + ", length " + rv.length + " (value never shown). Embedded credentials in a config line tend to get copied into tickets and chats; prefer a secrets mechanism where your setup supports one.");
          } else if (rHost && !isPrivateHost(rHost)) {
            add("fix", "PAPERLESS_REDIS", redis.line, "Redis is remote with no credentials in this paste",
              "Line " + redis.line + ", host " + rHost + ". A network-reachable Redis without a password can be read or flushed by anyone who can reach it. Bind it privately or set a password.");
          } else {
            add("ok", "PAPERLESS_REDIS", redis.line, "Redis address is local or private", "Line " + redis.line + ".");
          }
        }

        /* ---- Admin username / OCR notes ---- */
        var adminUser = get("PAPERLESS_ADMIN_USER");
        if (adminUser && adminUser.value.toLowerCase() === "paperless" && get("PAPERLESS_ADMIN_PASSWORD")) {
          add("note", "PAPERLESS_ADMIN_USER", adminUser.line, "Admin account uses the default username",
            "Line " + adminUser.line + ". A known username plus password login invites credential guessing. A unique admin name costs nothing.");
        }
        if (!get("PAPERLESS_OCR_LANGUAGE")) {
          add("note", "PAPERLESS_OCR_LANGUAGE", null, "OCR language not set in this paste",
            "Not a safety issue: Paperless falls back to its default OCR language. Set PAPERLESS_OCR_LANGUAGE if your documents are not in the default language, or recognition quality will suffer silently.");
        }

        var blockers = findings.filter(function(f){ return f.severity === "blocker"; }).length;
        var fixes = findings.filter(function(f){ return f.severity === "fix"; }).length;
        var verdict = blockers > 0 ? "DO NOT DEPLOY" : (fixes > 0 ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY");
        return finish(verdict, findings, parsed, paperlessCount);
      }

      function finish(verdict, findings, parsed, paperlessCount){
        var counts = { blocker: 0, fix: 0, note: 0, ok: 0 };
        findings.forEach(function(f){ counts[f.severity] = (counts[f.severity] || 0) + 1; });
        var safeEntries = parsed.order.map(function(k){
          var ent = parsed.entries[k];
          var secret = isSecretKey(k) || (k === "PAPERLESS_REDIS" && /:\/\/[^\/@]+@/.test(ent.value));
          var rec = { key: k, line: ent.line, secret: secret };
          if (secret) { rec.length = ent.value.length; } else { rec.value = ent.value; }
          return rec;
        });
        return {
          verdict: verdict,
          findings: findings,
          counts: counts,
          parsedKeyCount: parsed.order.length,
          paperlessKeyCount: paperlessCount,
          notParsedLines: parsed.notParsed,
          entries: safeEntries
        };
      }

      var VERDICT_BLURB = {
        "SAFE TO DEPLOY": "Nothing in this paste tripped a known-bad pattern. This is a heuristic text audit, not a guarantee - it does not start the server or verify any secret is correct.",
        "DEPLOY WITH FIXES": "No deployment blockers, but the FIX items below should be corrected before this configuration faces other people.",
        "DO NOT DEPLOY": "One or more BLOCKER items below would expose the server, its credentials, or your documents. Fix them and audit again.",
        "NOT ENOUGH TO GRADE": "This paste could not be recognized as a Paperless-ngx configuration, so no safety grade is given. Paste environment variables, docker-compose environment lines, or paperless.conf key=value lines."
      };

      function buildReport(r){
        var out = [];
        out.push("J-Dawgs Paperless-ngx Server Config Safety Auditor - Text Report");
        out.push("Verdict: " + r.verdict);
        out.push("Settings parsed: " + r.parsedKeyCount + " (" + r.paperlessKeyCount + " PAPERLESS_*)");
        out.push("Findings: " + r.counts.blocker + " blocker(s), " + r.counts.fix + " fix(es), " + r.counts.note + " note(s), " + r.counts.ok + " ok");
        out.push("Secret values are never included in this report - secrets are reported by key name, line, and length only.");
        out.push("");
        r.findings.forEach(function(f, i){
          var head = (i + 1) + ". [" + f.severity.toUpperCase() + "] " + f.title;
          if (f.key) head += " - " + f.key + (f.line ? " (line " + f.line + ")" : " (not in paste)");
          out.push(head);
          out.push("   " + f.detail);
        });
        if (r.notParsedLines.length) {
          out.push("");
          out.push("NOT PARSED line numbers (content not reproduced): " + r.notParsedLines.join(", "));
        }
        out.push("");
        out.push("Scope: heuristic text audit only. No server was started and no secret was verified as correct.");
        return out.join("\n");
      }

      function buildJson(r){
        return JSON.stringify({
          tool: "J-Dawgs Paperless-ngx Server Config Safety Auditor",
          verdict: r.verdict,
          summary: {
            parsedSettings: r.parsedKeyCount,
            paperlessSettings: r.paperlessKeyCount,
            blockers: r.counts.blocker, fixes: r.counts.fix, notes: r.counts.note, ok: r.counts.ok
          },
          findings: r.findings,
          settings: r.entries,
          notParsedLines: r.notParsedLines,
          secretHandling: "Secret values are never exported. Secret settings appear as key name, line number, and length only."
        }, null, 2);
      }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_MARKERS": (typeof EXAMPLE_MARKERS !== 'undefined' ? EXAMPLE_MARKERS : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-paperless-ngx-server-config-safety-auditor',
  name: 'J-Dawgs Paperless-ngx Server Config Safety Auditor',
  description: 'Host tools only tell you the container started; ours grades a pasted Paperless-ngx .env/config offline into one deploy verdict — admin credentials and secret keys by key name/line/length only, and consume-directory, database, and port-exposure posture.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_MARKERS": __core["EXAMPLE_MARKERS"] }
};
