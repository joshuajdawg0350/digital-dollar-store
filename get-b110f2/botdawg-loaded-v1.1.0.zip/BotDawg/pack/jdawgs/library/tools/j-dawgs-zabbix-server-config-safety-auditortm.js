'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Zabbix Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        // Keys this auditor knows how to grade (server + agent + proxy, clean-room
        // from the public Zabbix parameter documentation). Anything else is
        // reported as NOT PARSED by line.
        var KNOWN_KEYS = {};
        ("PidFile LogType LogFile LogFileSize DebugLevel SourceIP " +
          "DBHost DBName DBSchema DBUser DBPassword DBSocket DBPort " +
          "VaultDBPath VaultToken VaultURL VaultTLSCAFile VaultTLSCertFile VaultTLSKeyFile " +
          "StartPollers StartPollersUnreachable StartPreprocessors StartTrappers StartPingers " +
          "StartDiscoverers StartHTTPPollers StartTimers StartEscalators StartAlerters " +
          "StartLLDProcessors StartJavaPollers StartSNMPTrapper StartProxyPollers StartODBCPollers " +
          "StartBrowserPollers StartReportWriters StartVMwareCollectors " +
          "ListenIP ListenPort JavaGateway JavaGatewayPort AlertScriptsPath ExternalScripts " +
          "FpingLocation Fping6Location SSHKeyLocation HousekeepingFrequency SenderFrequency " +
          "CacheSize HistoryIndexCacheSize TrendCacheSize TrendFunctionCacheSize ValueCacheSize " +
          "Timeout TrapperTimeout UnreachablePeriod UnreachableDelay UnavailableDelay LogSlowQueries " +
          "ProxyConfigFrequency ProxyDataFrequency VMwareFrequency VMwarePerfFrequency VMwareCacheSize " +
          "VMwareTimeout SNMPTrapperFile StatsAllowedIP EnableRemoteCommands LogRemoteCommands " +
          "TLSCAFile TLSCRLFile TLSCertFile TLSKeyFile TLSServerCertIssuer TLSServerCertSubject " +
          "TLSCipherCert13 TLSCipherCert TLSCipherPSK13 TLSCipherPSK TLSCipherAll13 TLSCipherAll " +
          "FrontendPort AllowUnsupportedDBVersions EnableGlobalScripts NodeAddress " +
          "HistoryStorageURL HistoryStorageTypes HistoryStorageDateIndex ExportDir ExportFileSize " +
          "User SocketDir WebServiceURL LoadModulePath LoadModule " +
          "Server StartAgents ServerActive Hostname HostnameItem RefreshActiveChecks BufferSend " +
          "BufferSize MaxLinesPerSecond Alias AllowRoot Include UnsafeUserParameters UserParameter " +
          "DenyKey AllowKey TLSConnect TLSAccept TLSPSKIdentity TLSPSKFile HostMetadata HostMetadataItem " +
          "PersistentBufferPeriod PersistentBufferFileSize PersistentBufferLocation ControlSocket PluginSocket"
        ).split(" ").forEach(function (k) { KNOWN_KEYS[k] = true; });

        function isKnownKey(key) {
          if (KNOWN_KEYS[key]) return true;
          if (key.indexOf("Plugins.") === 0) return true; // agent2 plugin parameters
          return false;
        }

        // Values of these keys are never rendered anywhere in the output.
        var SENSITIVE_KEYS = { DBPassword: true, DBUser: true, TLSPSKFile: true, TLSPSKIdentity: true, VaultToken: true };

        var RISKY_EXAMPLE = [
          "# zabbix_server.conf - pulled from a production host",
          "PidFile=/run/zabbix/zabbix_server.pid",
          "LogFile=/var/log/zabbix/zabbix_server.log",
          "LogFileSize=0",
          "LogFileSize=10",
          "DBHost=localhost",
          "DBName=zabbix",
          "DBUser=root",
          "DBPassword=Tr0pic@lStorm99",
          "ListenIP=0.0.0.0",
          "ListenPort=10051",
          "StartTrappers=10",
          "EnableRemoteCommands=1",
          "LogRemoteCommands=0",
          "TLSAccept=unencrypted,psk",
          "TLSConnect=unencrypted",
          "DebugLevel=5",
          "FrobnicateMode=on",
          "this line never made it into the file properly"
        ].join("\n");

        var HARDENED_EXAMPLE = [
          "# zabbix_server.conf - hardened",
          "PidFile=/run/zabbix/zabbix_server.pid",
          "LogFile=/var/log/zabbix/zabbix_server.log",
          "LogFileSize=50",
          "DBHost=localhost",
          "DBName=zabbix",
          "DBUser=zabbix",
          "VaultDBPath=/zabbix/db/password",
          "VaultURL=https://vault.example.lan:8200",
          "ListenIP=127.0.0.1",
          "ListenPort=10051",
          "StartTrappers=5",
          "EnableRemoteCommands=0",
          "LogRemoteCommands=1",
          "TLSCAFile=/etc/zabbix/tls/ca.crt",
          "TLSCertFile=/etc/zabbix/tls/server.crt",
          "TLSKeyFile=/etc/zabbix/tls/server.key",
          "DebugLevel=3"
        ].join("\n");

        function parseConfig(text) {
          var lines = text.split(/\r?\n/);
          var entries = {};   // key -> { value, line, firstLine, count }
          var order = [];
          var findings = [];
          for (var i = 0; i < lines.length; i++) {
            var lineNo = i + 1;
            var raw = lines[i];
            var line = raw.replace(/^\s+|\s+$/g, "");
            if (line === "") continue;
            if (line.charAt(0) === "#") continue;
            var eq = line.indexOf("=");
            if (eq === -1) {
              findings.push({
                severity: "WARNING", line: lineNo, key: null,
                title: "Line not parsed",
                detail: "This line is not a key=value pair, so the auditor skipped it. (Line contents are never reproduced here.)",
                fix: "Rewrite it as Key=Value, comment it out with #, or delete it — as written, the daemon will reject or ignore it."
              });
              continue;
            }
            var key = line.slice(0, eq).replace(/\s+$/g, "");
            var value = line.slice(eq + 1).replace(/^\s+|\s+$/g, "");
            if (!isKnownKey(key)) {
              findings.push({
                severity: "INFO", line: lineNo, key: key,
                title: "Unknown key — not parsed",
                detail: "Key \"" + key + "\" is not in the zabbix_server.conf / zabbix_agentd.conf parameter set this auditor grades, so its value was not audited.",
                fix: "Check the spelling against the Zabbix documentation for your version. A misspelled key is silently ignored by the daemon, which means the setting you think is on may not be."
              });
              continue;
            }
            if (entries[key]) {
              entries[key].count += 1;
              entries[key].value = value;
              entries[key].line = lineNo;
              findings.push({
                severity: "WARNING", line: lineNo, key: key,
                title: "Duplicate key",
                detail: "Key \"" + key + "\" is set again here; it was first set on line " + entries[key].firstLine + ". Zabbix uses the last value it reads, so the earlier line is silently dead.",
                fix: "Delete one of the two \"" + key + "\" lines so the file says what the daemon will actually do."
              });
            } else {
              entries[key] = { value: value, line: lineNo, firstLine: lineNo, count: 1 };
              order.push(key);
            }
          }
          return { entries: entries, order: order, findings: findings, lineCount: lines.length };
        }

        function isWildcardListen(entries) {
          var e = entries["ListenIP"];
          if (!e) return { wildcard: true, implicit: true };
          var parts = e.value.split(",");
          for (var i = 0; i < parts.length; i++) {
            var p = parts[i].replace(/\s+/g, "");
            if (p === "0.0.0.0" || p === "::" || p === "*" || p === "[::]" || p === "") {
              return { wildcard: true, implicit: false };
            }
          }
          return { wildcard: false, implicit: false };
        }

        function isOn(v) { return v === "1" || /^on$/i.test(v) || /^yes$/i.test(v) || /^true$/i.test(v); }
        function isOff(v) { return v === "0" || /^off$/i.test(v) || /^no$/i.test(v) || /^false$/i.test(v); }
        function tlsTokens(v) {
          return v.split(",").map(function (t) { return t.replace(/\s+/g, "").toLowerCase(); }).filter(Boolean);
        }

        function audit(text) {
          var parsed = parseConfig(text);
          var entries = parsed.entries;
          var findings = parsed.findings.slice();

          function add(severity, line, key, title, detail, fix) {
            findings.push({ severity: severity, line: line, key: key, title: title, detail: detail, fix: fix });
          }
          function has(key) { return !!entries[key]; }
          function val(key) { return entries[key] ? entries[key].value : null; }
          function lineOf(key) { return entries[key] ? entries[key].line : null; }

          // Detect config flavour.
          var isServer = has("DBName") || has("DBHost") || has("StartTrappers") || has("DBPassword") || has("VaultDBPath");
          var isAgent = !isServer && (has("Server") || has("ServerActive") || has("Hostname") || has("AllowRoot") || has("TLSAccept"));
          var configType = isServer ? "zabbix_server.conf style (server / proxy)"
            : isAgent ? "zabbix_agentd.conf style (agent)"
            : "generic Zabbix key=value config";

          var listen = isWildcardListen(entries);

          // ---- Database credentials (name + line only; values never rendered) ----
          if (has("DBPassword")) {
            if (val("DBPassword") === "") {
              add("WARNING", lineOf("DBPassword"), "DBPassword",
                "DBPassword key present but empty",
                "A DBPassword line exists on line " + lineOf("DBPassword") + " with no value after the equals sign. The value itself is never shown by this auditor.",
                "Either remove the line and load the password from a vault (VaultDBPath), or set the password deliberately — an empty one usually means a templating step failed.");
            } else {
              add("BLOCKER", lineOf("DBPassword"), "DBPassword",
                "Plaintext database password in the config file",
                "A DBPassword value is stored in plaintext on line " + lineOf("DBPassword") + ". The value is never shown by this auditor — only the key name and line. Anyone who can read this file (backups, config management, a stray paste) owns the Zabbix database.",
                "Move the password into a secrets vault and point VaultDBPath / VaultURL at it, lock this file to owner-read-only (chmod 600, owned by the zabbix user) in the meantime, and rotate the password — treat the old one as exposed.");
            }
          }
          if (has("DBUser")) {
            var u = val("DBUser").toLowerCase();
            if (u === "root" || u === "admin" || u === "postgres" || u === "sa" || u === "sysdba") {
              add("WARNING", lineOf("DBUser"), "DBUser",
                "Database user is a superuser-grade account",
                "The DBUser on line " + lineOf("DBUser") + " names a database superuser rather than a dedicated Zabbix account. (The account name itself is not reproduced in the exports.) A compromised Zabbix daemon then holds the keys to every database on that server.",
                "Create a dedicated database user that owns only the Zabbix database, grant it nothing else, and point DBUser at it.");
            }
          }
          if (isServer && !has("DBPassword") && !has("VaultDBPath")) {
            add("INFO", null, "DBPassword",
              "No DBPassword and no VaultDBPath",
              "This server-style config carries neither a DBPassword nor a VaultDBPath, so database authentication must be coming from somewhere else (socket peer authentication, a vault default, or an include file).",
              "Confirm the mechanism on purpose. If it is an Include file, audit that file with the same care — this tool only sees what was pasted.");
          }

          // ---- Listen exposure ----
          if (has("ListenIP")) {
            if (listen.wildcard && !listen.implicit) {
              add("WARNING", lineOf("ListenIP"), "ListenIP",
                "Listening on every interface",
                "ListenIP on line " + lineOf("ListenIP") + " binds the daemon to all network interfaces (wildcard address). Anything that can route to this host can reach the Zabbix port" + (has("ListenPort") ? " (" + val("ListenPort") + ")" : "") + ".",
                "Bind ListenIP to the specific address your agents, proxies, and server actually use — or to localhost if everything is local — and back it with firewall rules.");
            }
          } else if (has("ListenPort") || has("StartTrappers") || isAgent || isServer) {
            add("INFO", null, "ListenIP",
              "ListenIP is not set — the daemon binds every interface by default",
              "With no ListenIP line, Zabbix listens on all interfaces (0.0.0.0 / ::). That default is easy to forget because no line in the file says it.",
              "Set ListenIP explicitly to the address the daemon should answer on, so the exposure is written down in the file where a reviewer can see it.");
          }

          // ---- Remote commands ----
          var ercOn = has("EnableRemoteCommands") && isOn(val("EnableRemoteCommands"));
          if (ercOn) {
            add("BLOCKER", lineOf("EnableRemoteCommands"), "EnableRemoteCommands",
              "Remote commands are enabled",
              "EnableRemoteCommands is on (line " + lineOf("EnableRemoteCommands") + "). Anyone who can drive the Zabbix API or a compromised server can execute arbitrary shell commands on this host as the daemon's user.",
              "Set EnableRemoteCommands=0 unless a documented, reviewed workflow truly needs it. If it must stay on, restrict who can trigger scripts and treat this host as code-execution exposed.");
            if (!has("LogRemoteCommands") || isOff(val("LogRemoteCommands"))) {
              add("WARNING", has("LogRemoteCommands") ? lineOf("LogRemoteCommands") : lineOf("EnableRemoteCommands"), "LogRemoteCommands",
                "Remote commands run unlogged",
                "Remote commands are enabled but LogRemoteCommands is off or unset, so executed commands leave no trace in the daemon log.",
                "Set LogRemoteCommands=1 for as long as remote commands stay enabled — unaudited command execution is the worst of both settings.");
            }
          }

          // ---- Privilege ----
          if (has("AllowRoot") && isOn(val("AllowRoot"))) {
            add("BLOCKER", lineOf("AllowRoot"), "AllowRoot",
              "Agent is allowed to run as root",
              "AllowRoot=1 (line " + lineOf("AllowRoot") + ") lets the agent run with full root privileges. Paired with user parameters or remote commands, that is unauthenticated-feeling root on the host.",
              "Set AllowRoot=0 and run the agent as the dedicated zabbix user. Grant narrow sudo rules only for the specific checks that need them.");
          }
          if (has("User") && val("User").toLowerCase() === "root") {
            add("WARNING", lineOf("User"), "User",
              "Daemon is configured to run as root",
              "The User parameter on line " + lineOf("User") + " runs the daemon as root instead of a service account.",
              "Set User=zabbix (or your dedicated service account) so a daemon compromise does not start at full privilege.");
          }

          // ---- Trappers ----
          if (has("StartTrappers")) {
            var stRaw = val("StartTrappers");
            var st = parseInt(stRaw, 10);
            if (isNaN(st)) {
              add("WARNING", lineOf("StartTrappers"), "StartTrappers",
                "StartTrappers value could not be read as a number",
                "StartTrappers on line " + lineOf("StartTrappers") + " is not a plain integer, so the trapper count cannot be graded.",
                "Set StartTrappers to a plain number (for example 5) so both the daemon and this audit can read it.");
            } else if (st > 0 && listen.wildcard) {
              add("WARNING", lineOf("StartTrappers"), "StartTrappers",
                st + " trapper threads accepting data on a wildcard listen",
                "StartTrappers=" + st + " (line " + lineOf("StartTrappers") + ") opens trapper listeners while the server binds every interface" + (listen.implicit ? " (ListenIP unset — the default)" : "") + ". Any host that can reach the port can push trapper data in; the trapper protocol itself carries no authentication beyond the sender being able to connect.",
                "Bind ListenIP to the addresses your senders use, firewall the trapper port to known senders, and keep the trapper count sized to real load.");
            } else if (st === 0) {
              add("INFO", lineOf("StartTrappers"), "StartTrappers",
                "Trapper listener is off",
                "StartTrappers=0 means sender-command and trapper data will not be received by this server.",
                "Fine if nothing sends trapper data here. If zabbix_sender or active items feed this server, raise StartTrappers above zero.");
            }
          }

          // ---- TLS / PSK posture ----
          var pskConfigured = has("TLSPSKFile") && has("TLSPSKIdentity");
          if (has("TLSAccept")) {
            var accTokens = tlsTokens(val("TLSAccept"));
            if (accTokens.indexOf("unencrypted") !== -1) {
              if (listen.wildcard) {
                add("BLOCKER", lineOf("TLSAccept"), "TLSAccept",
                  "Unencrypted connections accepted on a wildcard listen",
                  "TLSAccept on line " + lineOf("TLSAccept") + " accepts unencrypted connections while the daemon listens on every interface" + (listen.implicit ? " (ListenIP unset — the default)" : "") + ". Checks, inventory data, and any remote-command traffic cross the network in the clear to anyone positioned to read it.",
                  "Remove \"unencrypted\" from TLSAccept (keep psk and/or cert), and bind ListenIP to the addresses that should reach this host.");
              } else {
                add("WARNING", lineOf("TLSAccept"), "TLSAccept",
                  "Unencrypted connections accepted",
                  "TLSAccept on line " + lineOf("TLSAccept") + " includes \"unencrypted\", so passive checks can arrive with no encryption and no peer authentication.",
                  "Remove \"unencrypted\" from TLSAccept once every connecting server/proxy supports PSK or certificate TLS.");
              }
            }
            if (accTokens.indexOf("psk") !== -1 && !has("TLSPSKFile")) {
              add("WARNING", lineOf("TLSAccept"), "TLSAccept",
                "PSK accepted but no PSK key file is configured",
                "TLSAccept includes \"psk\" but there is no TLSPSKFile line, so PSK connections have no key to authenticate with and will fail or fall back. (Key file values are never shown by this auditor — presence by name only.)",
                "Set TLSPSKIdentity and TLSPSKFile, generate the key with a proper random source, and protect the file as a secret.");
            }
            if (accTokens.indexOf("cert") !== -1 && !has("TLSCertFile")) {
              add("WARNING", lineOf("TLSAccept"), "TLSAccept",
                "Certificate TLS accepted but no certificate file is configured",
                "TLSAccept includes \"cert\" but there is no TLSCertFile line, so certificate connections cannot be presented by this host.",
                "Set TLSCAFile, TLSCertFile, and TLSKeyFile to the issued certificate chain, or remove \"cert\" from TLSAccept.");
            }
          } else if (isAgent) {
            add("WARNING", null, "TLSAccept",
              "TLSAccept is not set — unencrypted is the agent default",
              "With no TLSAccept line, the agent accepts unencrypted passive connections. Nothing in the file says so; it is simply the default.",
              "Set TLSAccept=psk (with TLSPSKIdentity / TLSPSKFile) or TLSAccept=cert once the server side supports it.");
          }
          if (has("TLSConnect")) {
            var conTokens = tlsTokens(val("TLSConnect"));
            if (conTokens.indexOf("unencrypted") !== -1) {
              add("WARNING", lineOf("TLSConnect"), "TLSConnect",
                "Active connections go out unencrypted",
                "TLSConnect on line " + lineOf("TLSConnect") + " includes \"unencrypted\", so this host's active checks to the server cross the network in the clear and unauthenticated.",
                "Set TLSConnect=psk or TLSConnect=cert and configure the matching PSK or certificate material.");
            }
            if (conTokens.indexOf("psk") !== -1 && !has("TLSPSKFile")) {
              add("WARNING", lineOf("TLSConnect"), "TLSConnect",
                "PSK required for active checks but no PSK key file is configured",
                "TLSConnect includes \"psk\" but there is no TLSPSKFile line. (Key file values are never shown — presence by name only.)",
                "Set TLSPSKIdentity and TLSPSKFile so active checks can authenticate.");
            }
          }
          if (has("TLSPSKFile") && !has("TLSPSKIdentity")) {
            add("WARNING", lineOf("TLSPSKFile"), "TLSPSKFile",
              "PSK key file set without a PSK identity",
              "A TLSPSKFile is configured (line " + lineOf("TLSPSKFile") + ", name only — the path and key are never rendered) but no TLSPSKIdentity line exists, so peers cannot select this key.",
              "Add the TLSPSKIdentity line that matches the identity configured on the server for this host.");
          }
          if (has("TLSPSKIdentity") && !has("TLSPSKFile")) {
            add("WARNING", lineOf("TLSPSKIdentity"), "TLSPSKIdentity",
              "PSK identity set without a PSK key file",
              "A TLSPSKIdentity is configured (line " + lineOf("TLSPSKIdentity") + ", name only) but no TLSPSKFile line exists, so there is no key behind the identity.",
              "Add TLSPSKFile pointing at the protected key file for this host.");
          }
          if (isServer && !has("TLSCertFile") && !has("TLSKeyFile") && !has("TLSAccept") && !has("TLSConnect")) {
            add("WARNING", null, "TLSCertFile",
              "No TLS certificate material configured for the server",
              "This server-style config sets no TLSCertFile / TLSKeyFile, so agent and proxy connections that want certificate TLS have nothing to verify, and unencrypted or PSK-less traffic is the path of least resistance.",
              "Issue a certificate for the server and set TLSCAFile, TLSCertFile, and TLSKeyFile — or deliberately standardise on PSK everywhere and document that choice.");
          }

          // ---- Debug level ----
          if (has("DebugLevel")) {
            var dl = parseInt(val("DebugLevel"), 10);
            if (!isNaN(dl) && dl >= 4) {
              add("WARNING", lineOf("DebugLevel"), "DebugLevel",
                "DebugLevel " + dl + " left at debug verbosity",
                "DebugLevel on line " + lineOf("DebugLevel") + " is " + dl + ". Debug logs are voluminous, slow the daemon, and can capture connection details and item values you would not want sitting in a log file.",
                "Drop DebugLevel back to 3 for production. Raise it only while actively debugging, and set a calendar reminder to turn it back down.");
            } else if (!isNaN(dl) && dl > 5) {
              add("WARNING", lineOf("DebugLevel"), "DebugLevel",
                "DebugLevel is out of range",
                "DebugLevel on line " + lineOf("DebugLevel") + " is above the documented 0–5 range.",
                "Set DebugLevel between 0 and 5 (3 is the normal production setting).");
            }
          }

          // Sort: BLOCKER, WARNING, INFO; then by line (file-level last within tier by title).
          var sevRank = { BLOCKER: 0, WARNING: 1, INFO: 2 };
          findings.sort(function (a, b) {
            if (sevRank[a.severity] !== sevRank[b.severity]) return sevRank[a.severity] - sevRank[b.severity];
            var la = a.line === null ? 9999 : a.line;
            var lb = b.line === null ? 9999 : b.line;
            return la - lb;
          });

          var counts = { BLOCKER: 0, WARNING: 0, INFO: 0 };
          findings.forEach(function (f) { counts[f.severity] += 1; });

          var verdict = counts.BLOCKER > 0 ? "DO NOT DEPLOY"
            : counts.WARNING > 0 ? "DEPLOY WITH FIXES"
            : "SAFE TO DEPLOY";

          return { verdict: verdict, counts: counts, findings: findings, configType: configType };
        }

        function buildReport(r) {
          var out = [];
          out.push("J-Dawgs Zabbix Server Config Safety Auditor\u2122 - Audit Report");
          out.push("Config type detected: " + r.configType);
          out.push("Verdict: " + r.verdict);
          out.push("Blockers: " + r.counts.BLOCKER + " | Warnings: " + r.counts.WARNING + " | Info: " + r.counts.INFO);
          out.push("");
          if (r.findings.length === 0) {
            out.push("No findings. Nothing in the pasted config tripped a rule.");
          } else {
            r.findings.forEach(function (f) {
              out.push("[" + f.severity + "] " + (f.line ? "Line " + f.line : "Whole file") + (f.key ? " - " + f.key : "") + ": " + f.title);
              out.push("  " + f.detail);
              out.push("  Fix: " + f.fix);
              out.push("");
            });
          }
          out.push("Credential values are never reproduced in this report - findings name keys and lines only.");
          out.push("Heuristic text audit performed offline in the browser. This tool does not connect to any server and does not verify the database.");
          return out.join("\n");
        }

        function buildJson(r) {
          var obj = {
            tool: "J-Dawgs Zabbix Server Config Safety Auditor\u2122",
            configType: r.configType,
            verdict: r.verdict,
            counts: { blocker: r.counts.BLOCKER, warning: r.counts.WARNING, info: r.counts.INFO },
            findings: r.findings.map(function (f) {
              return { severity: f.severity, line: f.line, key: f.key, title: f.title, detail: f.detail, fix: f.fix };
            }),
            note: "Credential values are never included. Findings reference keys by name and line only."
          };
          return JSON.stringify(obj, null, 2);
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-zabbix-server-config-safety-auditortm',
  name: 'J-Dawgs Zabbix Server Config Safety Auditor',
  description: 'Grades a pasted zabbix_server.conf or zabbix_agentd.conf offline — remote commands, DB credentials by key name/line only, TLS/PSK posture — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
