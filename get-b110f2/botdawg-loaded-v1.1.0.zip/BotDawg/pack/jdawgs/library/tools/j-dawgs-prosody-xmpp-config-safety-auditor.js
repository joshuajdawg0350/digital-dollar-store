'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Prosody XMPP Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

var RISKY = [
'-- RISKY EXAMPLE - for audit demo only. Do not deploy.',
'VirtualHost "chat.example.com"',
'  authentication = "anonymous"',
'  allow_registration = true',
'  modules_enabled = { "register"; "mam"; "carbons"; "bosh"; "websocket"; }',
'  admins = { "admin@chat.example.com" }',
'  interfaces = { "*" }',
'  require_encryption = false',
'  s2s_secure_auth = false',
'  ssl = { key = "certs/chat.key"; certificate = "certs/chat.crt"; }',
'  component_secret = "JdRisky-SECRET-7391"',
'  admin_password = "JdAdmin-SECRET-4820"',
'  bosh_ports = { 5280 }',
'  websocket_url = "ws://chat.example.com:5280/xmpp-websocket"',
'  Component "conference.chat.example.com" "muc"',
'  this is not a valid config line %%%'
].join("\n");

var HARDENED = [
'-- HARDENED EXAMPLE',
'VirtualHost "chat.example.com"',
'  authentication = "internal_hashed"',
'  allow_registration = false',
'  modules_enabled = { "mam"; "carbons"; "tls"; "saslauth"; }',
'  admins = { "owner@chat.example.com" }',
'  interfaces = { "127.0.0.1"; "::1"; }',
'  require_encryption = true',
'  s2s_secure_auth = true',
'  c2s_require_encryption = true',
'  s2s_require_encryption = true',
'  ssl = { key = "certs/chat.key"; certificate = "certs/chat.crt"; }',
'  restrict_room_creation = true',
'  https_ports = { 5281 }',
'  Component "conference.chat.example.com" "muc"'
].join("\n");

var SECRET_KEY = /(password|passwd|secret|token|api[_-]?key|apikey|credential)/i;

function stripComment(line){
  // Remove a trailing -- comment only when it is not inside quotes (simple heuristic).
  var inQ = false, q = "";
  for (var i = 0; i < line.length - 1; i++){
    var c = line.charAt(i);
    if (inQ){ if (c === q) inQ = false; }
    else if (c === '"' || c === "'"){ inQ = true; q = c; }
    else if (c === "-" && line.charAt(i+1) === "-"){ return line.slice(0, i); }
  }
  return line;
}

function quotedValue(raw){
  var m = raw.match(/"([^"]*)"|'([^']*)'/);
  if (!m) return null;
  return (m[1] !== undefined ? m[1] : m[2]);
}

function audit(text){
  var findings = [];
  function add(line, severity, check, message){
    findings.push({line: line, severity: severity, check: check, message: message});
  }

  var raw = (text === null || text === undefined) ? "" : String(text);
  var trimmed = raw.replace(/\s+/g, "");
  if (trimmed.length < 12){
    return {verdict: "NOT ENOUGH TO GRADE", findings: [], enough: false,
      message: "NOT ENOUGH TO GRADE — paste the text of a prosody.cfg.lua config (at least a few key = value lines) and run the audit again."};
  }

  var lines = raw.split(/\r?\n/);
  var state = {
    anonymous: false, anonymousLine: 0,
    allowReg: false, allowRegLine: 0,
    registerModule: false, registerModuleLine: 0,
    requireEncSeen: false,
    s2sSecureSeen: false,
    adminsSeen: false,
    certSeen: false,
    exposureLine: 0,
    restrictRoomSeen: false,
    mucLines: [],
    parsedCount: 0
  };

  for (var i = 0; i < lines.length; i++){
    var n = i + 1;
    var original = lines[i];
    var code = stripComment(original).trim();
    if (code === "") continue;

    var isVirtual = /^VirtualHost\s+"/.test(code);
    var isComponent = /^Component\s+"/.test(code);
    var isInclude = /^Include\s+"/.test(code);
    var kv = code.match(/^([A-Za-z_][\w.-]*)\s*=\s*(.+)$/);
    var isBraceOnly = /^[{},\s;]+$/.test(code);

    if (!isVirtual && !isComponent && !isInclude && !kv && !isBraceOnly){
      var secretish = SECRET_KEY.test(code) || /"[^"]{8,}"/.test(code);
      add(n, "NOT PARSED", "Unparsable line",
        secretish
          ? "Line could not be parsed by this heuristic audit. Content withheld because it looks secret-bearing — review it manually in the original file."
          : "Line could not be parsed by this heuristic audit: \u201C" + code.slice(0, 80) + "\u201D Review it manually; it may be valid Lua this text audit does not model.");
      continue;
    }
    state.parsedCount++;

    if (isComponent && /"muc"/.test(code)){ state.mucLines.push(n); }
    if (isComponent){ continue; }
    if (!kv) continue;

    var key = kv[1];
    var val = kv[2].trim();
    var low = val.toLowerCase();
    var qv = quotedValue(val);

    // Plaintext secret values — key, line, length ONLY. Never the value.
    if (SECRET_KEY.test(key) && qv !== null && qv.length > 0){
      add(n, "HIGH", "Plaintext secret in config",
        "Key \u201C" + key + "\u201D holds a plaintext value (" + qv.length + " characters; value never shown). Move secrets out of the config file into a protected secrets store or environment-provided file with strict permissions, and rotate this value — it has been handled as plaintext.");
    }

    if (key === "authentication" && qv !== null && qv.toLowerCase() === "anonymous"){
      state.anonymous = true; state.anonymousLine = n;
      add(n, "BLOCKER", "Anonymous authentication",
        "authentication = \"anonymous\" lets anyone connect without credentials. Set authentication to a real backend (for example \"internal_hashed\") and create accounts deliberately.");
    }
    if (key === "allow_registration" && low === "true"){
      state.allowReg = true; state.allowRegLine = n;
    }
    if (key === "modules_enabled" && /"register"/.test(val)){
      state.registerModule = true; state.registerModuleLine = n;
    }
    if (key === "require_encryption"){
      state.requireEncSeen = true;
      if (low === "false"){
        add(n, "HIGH", "Encryption not required",
          "require_encryption = false allows plaintext client and server connections. Set require_encryption = true and configure a valid TLS certificate.");
      }
    }
    if ((key === "c2s_require_encryption" || key === "s2s_require_encryption") && low === "false"){
      add(n, "HIGH", "Encryption not required",
        key + " = false allows plaintext connections on that path. Set it to true.");
    }
    if (key === "s2s_secure_auth"){
      state.s2sSecureSeen = true;
      if (low === "false"){
        add(n, "HIGH", "Unauthenticated server-to-server dialback",
          "s2s_secure_auth = false accepts server-to-server connections without strong authentication, enabling spoofing. Set s2s_secure_auth = true.");
      }
    }
    if (key === "admins"){
      state.adminsSeen = true;
      if (/\{\s*\}/.test(val)){
        add(n, "MEDIUM", "Empty admin list",
          "admins = { } leaves the host with no named administrators. Name at least one real admin JID, on an account protected by a strong, non-shared password.");
      }
    }
    if (key === "interfaces" && (val.indexOf('"*"') !== -1 || val.indexOf("0.0.0.0") !== -1)){
      if (!state.exposureLine) state.exposureLine = n;
      add(n, "MEDIUM", "Listening on all interfaces",
        "interfaces includes all interfaces (\"*\" / 0.0.0.0). Bind only the interfaces the server must serve, and make sure TLS is configured before exposing the host to a network.");
    }
    if ((key === "ports" || key === "c2s_ports" || key === "s2s_ports" || key === "bosh_ports" || key === "http_ports") && !state.exposureLine){
      state.exposureLine = n;
    }
    if (key === "bosh_ports" && /5280/.test(val)){
      add(n, "MEDIUM", "BOSH served over plain HTTP",
        "bosh_ports includes 5280, the plain-HTTP BOSH port. Serve BOSH over HTTPS (5281 with a valid certificate) or behind a TLS-terminating proxy.");
    }
    if (key === "http_ports"){
      add(n, "MEDIUM", "HTTP services on a plaintext port",
        "http_ports exposes Prosody HTTP services (BOSH / WebSocket / file sharing) without TLS. Prefer https_ports with a valid certificate.");
    }
    if ((key === "websocket_url" || key === "bosh_url" || key === "http_external_url") && qv !== null && /^ws:\/\//i.test(qv)){
      add(n, "MEDIUM", "WebSocket endpoint on ws://",
        key + " uses ws:// (plaintext). Use wss:// so browser clients connect over TLS.");
    }
    if (key === "ssl" || key === "https_ssl" || key === "certificate" || key === "key"){
      if (!state.certSeen){
        state.certSeen = true;
        add(n, "NOT VERIFIED", "Certificate path",
          "A certificate / key path is referenced here. This offline audit cannot open files on your host, so the path, file existence, expiry, and key match are NOT VERIFIED. Check them on the server before deploying.");
      }
    }
    if (key === "restrict_room_creation"){ state.restrictRoomSeen = true; }
  }

  // Cross-line checks (escalations and absences).
  if (state.allowReg){
    if (state.anonymous){
      add(state.allowRegLine, "BLOCKER", "Open registration with anonymous auth",
        "allow_registration = true combined with authentication = \"anonymous\" (line " + state.anonymousLine + ") means anyone on the network can obtain an account on a server that already accepts anonymous logins. Close registration (allow_registration = false) and provision accounts deliberately.");
    } else {
      add(state.allowRegLine, "HIGH", "Open registration",
        "allow_registration = true lets anyone who can reach the server create an account — a standing spam and abuse vector. Set allow_registration = false unless open signup is a deliberate, monitored policy.");
    }
  }
  if (state.registerModule){
    add(state.registerModuleLine, "HIGH", "Registration module enabled",
      "modules_enabled includes \"register\", the in-band registration module. With registration open this is unrestricted account creation. Remove \"register\" from modules_enabled, or pair it with registration limits and throttling you have actually configured.");
  }
  if (!state.requireEncSeen && state.exposureLine){
    add(state.exposureLine, "MEDIUM", "TLS posture not stated",
      "No require_encryption setting was found, while the config exposes network listeners (this line). A starting server with no stated TLS posture can accept plaintext connections. Set require_encryption = true and configure a certificate; the certificate itself is NOT VERIFIED by this audit.");
  }
  if (!state.s2sSecureSeen){
    // Only flag when the config looks like a real host definition.
    if (state.parsedCount >= 3){
      add(1, "MEDIUM", "s2s_secure_auth not stated",
        "No s2s_secure_auth setting was found. If this server federates, set s2s_secure_auth = true so remote servers authenticate strongly; if it never federates, disable s2s instead.");
    }
  }
  if (!state.adminsSeen && state.parsedCount >= 3){
    add(1, "MEDIUM", "No admin list found",
      "No admins = { ... } setting was found in the pasted text. Name the admin JIDs explicitly so operator access is deliberate and auditable.");
  }
  if (!state.certSeen && state.exposureLine){
    add(state.exposureLine, "MEDIUM", "No certificate configured",
      "Network listeners are configured but no ssl / certificate setting was found in the pasted text. Configure a TLS certificate before exposing this host; without one, encryption cannot be offered. (Any certificate you add later is NOT VERIFIED by this audit.)");
  }
  if (!state.restrictRoomSeen){
    for (var m = 0; m < state.mucLines.length; m++){
      add(state.mucLines[m], "MEDIUM", "MUC component posture",
        "A MUC (multi-user chat) component is declared, and no restrict_room_creation setting is visible in the pasted text. Set restrict_room_creation to limit who can create rooms, or confirm the restriction is set in the component section.");
    }
  }

  findings.sort(function(a, b){
    var rank = {"BLOCKER":0,"HIGH":1,"MEDIUM":2,"NOT VERIFIED":3,"NOT PARSED":4};
    if (rank[a.severity] !== rank[b.severity]) return rank[a.severity] - rank[b.severity];
    return a.line - b.line;
  });

  var blockers = findings.filter(function(f){return f.severity==="BLOCKER";}).length;
  var highs = findings.filter(function(f){return f.severity==="HIGH";}).length;
  var mediums = findings.filter(function(f){return f.severity==="MEDIUM";}).length;

  var verdict;
  if (blockers > 0) verdict = "DO NOT DEPLOY";
  else if (highs > 0 || mediums > 0) verdict = "DEPLOY WITH FIXES";
  else verdict = "SAFE TO DEPLOY";

  return {verdict: verdict, findings: findings, enough: true,
    counts: {blocker: blockers, high: highs, medium: mediums,
      notVerified: findings.filter(function(f){return f.severity==="NOT VERIFIED";}).length,
      notParsed: findings.filter(function(f){return f.severity==="NOT PARSED";}).length}};
}

function buildReport(result){
  var out = [];
  out.push("J-Dawgs Prosody XMPP Config Safety Auditor - heuristic text audit (not a Lua parser; Prosody was not run)");
  out.push("Verdict: " + result.verdict);
  if (!result.enough){
    out.push(result.message);
    return out.join("\n");
  }
  var c = result.counts;
  out.push("Counts: BLOCKER " + c.blocker + " | HIGH " + c.high + " | MEDIUM " + c.medium + " | NOT VERIFIED " + c.notVerified + " | NOT PARSED " + c.notParsed);
  out.push("Secret values are never printed: secret findings name key, line, and value length only.");
  out.push("---");
  if (result.findings.length === 0){
    out.push("No findings.");
  } else {
    result.findings.forEach(function(f){
      out.push("Line " + f.line + " [" + f.severity + "] " + f.check + ": " + f.message);
    });
  }
  out.push("---");
  out.push("Limits: no server was contacted; certificates are NOT VERIFIED by this offline audit.");
  return out.join("\n");
}

function buildJson(result){
  var obj = {
    tool: "J-Dawgs Prosody XMPP Config Safety Auditor",
    auditType: "heuristic-text-audit",
    verdict: result.verdict,
    enough: result.enough
  };
  if (!result.enough){
    obj.message = result.message;
  } else {
    obj.counts = result.counts;
    obj.findings = result.findings.map(function(f){
      return {line: f.line, severity: f.severity, check: f.check, message: f.message};
    });
    obj.notes = [
      "Secret values are never included; secret findings name key, line, and value length only.",
      "Certificates are NOT VERIFIED by this offline audit.",
      "Heuristic text audit only; Prosody was not run and no server was contacted."
    ];
  }
  return JSON.stringify(obj, null, 2);
}
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-prosody-xmpp-config-safety-auditor',
  name: 'J-Dawgs Prosody XMPP Config Safety Auditor',
  description: 'Grades a pasted prosody.cfg.lua offline into one deploy verdict — anonymous auth and open registration as BLOCKERs, TLS/s2s posture, secrets by key name/line/length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
