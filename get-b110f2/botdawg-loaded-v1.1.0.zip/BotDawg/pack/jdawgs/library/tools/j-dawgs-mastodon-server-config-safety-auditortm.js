'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Mastodon Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var RECOGNIZED = {};
      [
        "LOCAL_DOMAIN","WEB_DOMAIN","SECRET_KEY_BASE","OTP_SECRET",
        "VAPID_PRIVATE_KEY","VAPID_PUBLIC_KEY",
        "DB_HOST","DB_PORT","DB_NAME","DB_USER","DB_PASS","DB_SSLMODE",
        "REDIS_HOST","REDIS_PORT","REDIS_PASSWORD","REDIS_URL",
        "SMTP_SERVER","SMTP_PORT","SMTP_LOGIN","SMTP_PASSWORD","SMTP_FROM_ADDRESS","SMTP_DOMAIN","SMTP_AUTH_METHOD","SMTP_OPENSSL_VERIFY_MODE","SMTP_ENABLE_STARTTLS",
        "S3_ENABLED","S3_BUCKET","S3_REGION","S3_HOSTNAME","S3_ENDPOINT","S3_ACCESS_KEY_ID","S3_SECRET_ACCESS_KEY","S3_PROTOCOL",
        "ES_ENABLED","ES_HOST","ES_PORT","ES_USER","ES_PASS",
        "SINGLE_USER_MODE","OPEN_REGISTRATIONS","AUTHORIZED_FETCH","LIMITED_FEDERATION_MODE",
        "DISALLOW_UNAUTHENTICATED_API_ACCESS","STREAMING_API_BASE_URL",
        "BIND","PORT","STREAMING_PORT","STREAMING_BIND","TRUSTED_PROXY_IP",
        "RAILS_ENV","NODE_ENV","RAILS_SERVE_STATIC_FILES","FORCE_SSL",
        "DEFAULT_LOCALE","ALLOWED_PRIVATE_ADDRESSES","IP_RETENTION_PERIOD","SESSION_RETENTION_PERIOD",
        "PREPARED_STATEMENTS","DB_POOL","SIDEKIQ_CONCURRENCY","MAX_THREADS",
        "ALTERNATE_DOMAINS","CDN_HOST","S3_ALIAS_HOST","AWS_ACCESS_KEY_ID","AWS_SECRET_ACCESS_KEY",
        "OTP_SECRET_FILE","SECRET_KEY_BASE_FILE","DB_PASS_FILE","REDIS_PASSWORD_FILE","SMTP_PASSWORD_FILE","ES_PASS_FILE",
        "VAPID_PRIVATE_KEY_FILE","VAPID_PUBLIC_KEY_FILE","S3_SECRET_ACCESS_KEY_FILE"
      ].forEach(function(k){ RECOGNIZED[k] = true; });

      var CORE_SECRETS = ["SECRET_KEY_BASE","OTP_SECRET","VAPID_PRIVATE_KEY"];
      var PLAINTEXT_KEYS = {
        "DB_PASS":true,"REDIS_PASSWORD":true,"SMTP_PASSWORD":true,
        "S3_SECRET_ACCESS_KEY":true,"ES_PASS":true,"AWS_SECRET_ACCESS_KEY":true
      };

      function isSecretKey(key){
        return CORE_SECRETS.indexOf(key) !== -1 ||
          PLAINTEXT_KEYS[key] === true ||
          /(_PASS|_PASSWORD|_SECRET|_PRIVATE_KEY|_ACCESS_KEY)$/.test(key) ||
          key === "SECRET_KEY_BASE";
      }
      function isReference(key, value){
        if (/_FILE$/.test(key)) return true;
        if (!value) return false;
        if (value.indexOf("${") === 0) return true;
        if (value.indexOf("env:") === 0) return true;
        if (value.indexOf("file:") === 0) return true;
        if (value.indexOf("$") === 0) return true;
        return false;
      }
      function isPlaceholder(value){
        var v = value.toLowerCase();
        if (v.indexOf("example") !== -1) return true;
        if (v.indexOf("changeme") !== -1 || v.indexOf("change-me") !== -1 || v.indexOf("change_me") !== -1) return true;
        if (v === "secret") return true;
        if (v.indexOf("placeholder") !== -1) return true;
        if (v.indexOf("your-") === 0 || v.indexOf("your_") === 0) return true;
        if (value.length > 0){
          var allSame = true;
          for (var i = 1; i < value.length; i++){ if (value.charAt(i) !== value.charAt(0)){ allSame = false; break; } }
          if (allSame) return true;
        }
        return false;
      }
      function stripQuotes(v){
        if (v.length >= 2){
          var a = v.charAt(0), b = v.charAt(v.length - 1);
          if ((a === '"' && b === '"') || (a === "'" && b === "'")) return v.slice(1, -1);
        }
        return v;
      }
      function hostOf(url){
        var m = /^[a-z][a-z0-9+.-]*:\/\/([^\/:?#]+)/i.exec(url);
        return m ? m[1].toLowerCase() : "";
      }
      function isLocalHost(h){
        return h === "localhost" || h === "127.0.0.1" || h === "::1" || h === "[::1]" || /\.local$/.test(h);
      }

      function audit(raw){
        var findings = [];
        function add(severity, category, key, line, valueLength, message, fix){
          findings.push({
            severity: severity, category: category, key: key || null,
            line: (line === undefined ? null : line),
            valueLength: (valueLength === undefined ? null : valueLength),
            message: message, fix: fix || ""
          });
        }

        var lines = String(raw || "").split(/\r?\n/);
        var entries = {};   // key -> [{line, value}]
        var order = [];
        var recognizedPresent = {};

        lines.forEach(function(rawLine, idx){
          var lineNo = idx + 1;
          var trimmed = rawLine.replace(/^\s+|\s+$/g, "");
          if (trimmed === "") return;
          if (trimmed.charAt(0) === "#"){
            var cm = /^#\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=/.exec(trimmed);
            if (cm){
              add("INFO","COMMENTED",cm[1],lineNo,null,
                "Line " + lineNo + " sets " + cm[1] + " only inside a comment. It is COMMENTED / NOT ACTIVE and was not graded as set.",
                "If this setting is meant to be live, uncomment it and give it a real value; if not, leave it commented.");
            } else {
              add("INFO","COMMENTED",null,lineNo,null,
                "Line " + lineNo + " is a comment. It is COMMENTED / NOT ACTIVE and was not graded.",
                "No action needed.");
            }
            return;
          }
          var m = /^(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/.exec(trimmed);
          if (!m){
            add("WARNING","NOT PARSED",null,lineNo,null,
              "Line " + lineNo + " is not in KEY=value form and is not a comment or blank line, so it was NOT PARSED. Nothing about it was guessed.",
              "Rewrite the line as KEY=value, comment it out with a leading #, or remove it.");
            return;
          }
          var key = m[1];
          var value = stripQuotes(m[2].replace(/\s+$/,""));
          if (!entries[key]){ entries[key] = []; order.push(key); }
          entries[key].push({ line: lineNo, value: value });
          if (RECOGNIZED[key]) recognizedPresent[key] = true;
        });

        var recognizedCount = Object.keys(recognizedPresent).length;

        // Duplicates (last value wins)
        order.forEach(function(key){
          var list = entries[key];
          if (list.length > 1){
            var lineList = list.map(function(e){ return e.line; }).join(" and ");
            add("WARNING","DUPLICATE",key,list[list.length-1].line, isSecretKey(key) ? list[list.length-1].value.length : null,
              key + " is set more than once, on lines " + lineList + ". Duplicate keys: the last value wins, so line " + list[list.length-1].line + " is the value graded here.",
              "Delete all but one " + key + " line and keep the value you actually intend.");
          }
        });

        function lastEntry(key){ var l = entries[key]; return l ? l[l.length-1] : null; }

        if (recognizedCount < 3){
          add("INFO","NOT ENOUGH TO GRADE",null,null,null,
            "Only " + recognizedCount + " recognized Mastodon key" + (recognizedCount === 1 ? "" : "s") + " found in the paste. A gradeable config needs at least 3 recognized Mastodon keys (for example LOCAL_DOMAIN, SECRET_KEY_BASE, and DB_HOST). Empty pastes and ordinary prose land here too — there is not enough Mastodon config to grade.",
            "Paste the server's env-style config (its .env.production or equivalent) and audit again.");
          return finish(findings, "NOT ENOUGH TO GRADE", recognizedCount,
            "Fewer than 3 recognized Mastodon keys were found, so no honest grade is possible.");
        }

        // ---- Core secrets ----
        CORE_SECRETS.forEach(function(key){
          var e = lastEntry(key);
          if (!e){
            var fileEntry = lastEntry(key + "_FILE");
            if (fileEntry && fileEntry.value !== ""){
              add("PASS","SECRET",key,fileEntry.line,null,
                key + " is supplied through " + key + "_FILE (line " + fileEntry.line + "), a pointer to a secrets file, so the secret itself stays out of the config file.",
                "No action needed. Keep the referenced secrets file readable only by the server account.");
              return;
            }
            add("BLOCKER","SECRET",key,null,0,
              key + " is missing. Mastodon cannot run safely without it, and there is nothing to grade in its place.",
              "Generate a long random value (for example with `rails secret` or `openssl rand -hex 64`) and set " + key + ", or point to it with a reference such as ${" + key + "} or a " + key + "_FILE entry.");
            return;
          }
          if (isReference(key, e.value)){
            add("PASS","SECRET",key,e.line,null,
              key + " (line " + e.line + ") is supplied as a reference rather than a literal value, so the secret itself stays out of the config file.",
              "No action needed. Keep the referenced secret store protected.");
            return;
          }
          if (isPlaceholder(e.value)){
            add("BLOCKER","SECRET",key,e.line,e.value.length,
              key + " (line " + e.line + ", value length " + e.value.length + ") holds a known example or placeholder value. Anyone who has seen the public examples knows this secret.",
              "Replace it with a freshly generated long random value and keep the real value out of examples and repos.");
            return;
          }
          if (e.value.length < 32){
            add("BLOCKER","SECRET",key,e.line,e.value.length,
              key + " (line " + e.line + ", value length " + e.value.length + ") is too short — under 32 characters. Short secrets can be guessed or brute-forced.",
              "Replace it with a generated value of at least 64 characters (for example `openssl rand -hex 64`).");
            return;
          }
          add("PASS","SECRET",key,e.line,e.value.length,
            key + " (line " + e.line + ", value length " + e.value.length + ") is present and long enough. Its correctness is not verified — only its presence, length, and form were graded.",
            "No action needed.");
        });

        // VAPID public key (informational completeness)
        (function(){
          var e = lastEntry("VAPID_PUBLIC_KEY");
          if (!e){
            add("INFO","SECRET","VAPID_PUBLIC_KEY",null,0,
              "VAPID_PUBLIC_KEY is not present. Web push notifications need the VAPID key pair; the private half was graded above.",
              "If you use web push, generate the VAPID pair (`rake mastodon:webpush:generate_vapid_key`) and set both keys.");
          }
        })();

        // ---- Plaintext password / secret keys ----
        order.forEach(function(key){
          if (CORE_SECRETS.indexOf(key) !== -1) return;
          if (/_FILE$/.test(key)){
            var baseKey = key.slice(0, key.length - 5);
            if (CORE_SECRETS.indexOf(baseKey) !== -1) return; // already graded in the core-secret pass
            var fe = lastEntry(key);
            if (fe && fe.value !== "" && (PLAINTEXT_KEYS[baseKey] === true || /(_PASS|_PASSWORD|_SECRET)$/.test(baseKey))){
              add("PASS","PASSWORD STORAGE",key,fe.line,null,
                key + " (line " + fe.line + ") points to a secrets file rather than holding a literal value, so no plaintext password sits in this config.",
                "No action needed. Keep the referenced secrets file readable only by the server account.");
            }
            return;
          }
          var isPlainKey = PLAINTEXT_KEYS[key] === true || /(_PASS|_PASSWORD|_SECRET)$/.test(key);
          if (!isPlainKey) return;
          var e = lastEntry(key);
          if (!e) return;
          if (isReference(key, e.value) || /_FILE$/.test(key)){
            add("PASS","PASSWORD STORAGE",key,e.line,null,
              key + " (line " + e.line + ") is supplied as a reference or file pointer rather than a literal value, so no plaintext password sits in this config.",
              "No action needed.");
            return;
          }
          if (e.value === ""){
            add("WARNING","PASSWORD STORAGE",key,e.line,0,
              key + " (line " + e.line + ") is set but empty. The service it unlocks will fail to connect, or worse, may fall back to no authentication.",
              "Set a real value, or supply it as a reference such as ${" + key + "} or a " + key + "_FILE entry.");
            return;
          }
          add("HIGH","PASSWORD STORAGE",key,e.line,e.value.length,
            key + " (line " + e.line + ", value length " + e.value.length + ") is written into the config as a literal plaintext value. Anyone who reads this file — a leaked backup, a pasted log, a repo commit — has the password.",
            "Move it out of the file: use a reference such as ${" + key + "}, an env: lookup, or a " + key + "_FILE path to a protected secrets file, and rotate the password since it has sat in plaintext.");
        });

        // ---- Federation identity ----
        var ld = lastEntry("LOCAL_DOMAIN");
        if (!ld){
          add("BLOCKER","FEDERATION","LOCAL_DOMAIN",null,0,
            "LOCAL_DOMAIN is missing. It is the server's federation identity — the domain in every @user@domain handle — and it cannot be graded, or safely changed later, without it.",
            "Set LOCAL_DOMAIN to the server's permanent public domain (host only, no scheme, no port, no path) before first deploy.");
        } else {
          if (/:\/\//.test(ld.value) || /\//.test(ld.value) || /:\d+/.test(ld.value)){
            add("WARNING","FEDERATION","LOCAL_DOMAIN",ld.line,null,
              "LOCAL_DOMAIN (line " + ld.line + ") contains a scheme, port, or path. LOCAL_DOMAIN must be a bare host — those extras break federation identity and account addresses.",
              "Set LOCAL_DOMAIN to the bare host only, for example `social.example.org`.");
          } else {
            add("PASS","FEDERATION","LOCAL_DOMAIN",ld.line,null,
              "LOCAL_DOMAIN (line " + ld.line + ") is present as a bare host, which is the form federation identity needs.",
              "No action needed. Treat this value as permanent once the server has federated.");
          }
          var wd = lastEntry("WEB_DOMAIN");
          if (wd){
            if (/:\/\//.test(wd.value) || /\//.test(wd.value) || /:\d+/.test(wd.value)){
              add("WARNING","FEDERATION","WEB_DOMAIN",wd.line,null,
                "WEB_DOMAIN (line " + wd.line + ") contains a scheme, port, or path. WEB_DOMAIN must be a bare host.",
                "Set WEB_DOMAIN to the bare host only.");
            }
            if (wd.value !== ld.value){
              add("INFO","FEDERATION","WEB_DOMAIN",wd.line,null,
                "WEB_DOMAIN (line " + wd.line + ") differs from LOCAL_DOMAIN. That is a legitimate split — accounts keep the LOCAL_DOMAIN identity while the web UI is served from WEB_DOMAIN — but it must be intentional, with DNS and certificates in place for both.",
                "If the split is deliberate, no action is needed. If it is a typo, make WEB_DOMAIN match LOCAL_DOMAIN.");
            }
          }
        }

        // ---- Registration posture ----
        var or = lastEntry("OPEN_REGISTRATIONS");
        if (or && /^true$/i.test(or.value)){
          add("WARNING","REGISTRATION","OPEN_REGISTRATIONS",or.line,null,
            "OPEN_REGISTRATIONS is true (line " + or.line + "): anyone on the internet can create an account immediately. That is a real spam and abuse surface — new servers are found by spammers within days.",
            "If open sign-up is not deliberate, set OPEN_REGISTRATIONS=false and approve accounts manually, or require an invite or a sign-up reason.");
        }
        if (!or){
          // wording-based check: any active line mentioning registrations open
          var wordingLine = null;
          lines.forEach(function(rawLine, idx){
            var t = rawLine.replace(/^\s+/,"");
            if (t.charAt(0) === "#") return;
            if (/registrations?\s+(are\s+)?open/i.test(t)) wordingLine = idx + 1;
          });
          if (wordingLine !== null){
            add("WARNING","REGISTRATION",null,wordingLine,null,
              "Line " + wordingLine + " says registrations are open. Open registration is a spam and abuse surface for a public server.",
              "If open sign-up is not deliberate, close registrations or require manual approval.");
          }
        }
        var sum = lastEntry("SINGLE_USER_MODE");
        if (sum && /^true$/i.test(sum.value)){
          add("INFO","REGISTRATION","SINGLE_USER_MODE",sum.line,null,
            "SINGLE_USER_MODE is true (line " + sum.line + "): the server is set up as a one-person instance, with the root redirecting to the owner's profile and registration effectively closed.",
            "No action needed if this is a personal instance.");
        }

        // ---- Federation posture defaults ----
        if (!lastEntry("AUTHORIZED_FETCH")){
          add("INFO","FEDERATION","AUTHORIZED_FETCH",null,null,
            "AUTHORIZED_FETCH is not set, so the default federation posture is unstated. With it off, other servers can fetch your public content without signing requests, which makes blocking abusive instances less effective.",
            "Consider AUTHORIZED_FETCH=true if you want signed fetches and stronger block enforcement; leave unset only as a deliberate choice.");
        } else {
          add("PASS","FEDERATION","AUTHORIZED_FETCH",lastEntry("AUTHORIZED_FETCH").line,null,
            "AUTHORIZED_FETCH (line " + lastEntry("AUTHORIZED_FETCH").line + ") is set explicitly, so the federation fetch posture is a stated choice rather than a silent default.",
            "No action needed.");
        }
        if (!lastEntry("LIMITED_FEDERATION_MODE")){
          add("INFO","FEDERATION","LIMITED_FEDERATION_MODE",null,null,
            "LIMITED_FEDERATION_MODE is not set, so the default federation posture is unstated. The server will federate openly with instances it has not explicitly allowlisted.",
            "Consider LIMITED_FEDERATION_MODE=true (allowlist federation) for a small or private server; leave unset only as a deliberate choice.");
        } else {
          add("PASS","FEDERATION","LIMITED_FEDERATION_MODE",lastEntry("LIMITED_FEDERATION_MODE").line,null,
            "LIMITED_FEDERATION_MODE (line " + lastEntry("LIMITED_FEDERATION_MODE").line + ") is set explicitly, so the federation reach posture is a stated choice.",
            "No action needed.");
        }
        var dua = lastEntry("DISALLOW_UNAUTHENTICATED_API_ACCESS");
        if (dua && /^true$/i.test(dua.value)){
          add("PASS","FEDERATION","DISALLOW_UNAUTHENTICATED_API_ACCESS",dua.line,null,
            "DISALLOW_UNAUTHENTICATED_API_ACCESS is true (line " + dua.line + "): unauthenticated API access is restricted, which reduces scraping surface.",
            "No action needed.");
        }

        // ---- Bind posture ----
        order.forEach(function(key){
          if (!/BIND/.test(key)) return;
          var e = lastEntry(key);
          if (!e) return;
          if (e.value === "0.0.0.0" || e.value === "::"){
            add("WARNING","BIND",key,e.line,null,
              key + " (line " + e.line + ") binds on all network interfaces (0.0.0.0). The app port answers on every interface the machine has. That is usually fine only because a reverse proxy sits in front and the firewall blocks direct access — if neither is true, the app is exposed directly.",
              "Bind to 127.0.0.1 when a reverse proxy on the same machine fronts the app, or confirm the firewall blocks the app port from the public internet.");
          } else if (isLocalHost(e.value)){
            add("PASS","BIND",key,e.line,null,
              key + " (line " + e.line + ") binds to a local interface only, so the app is reachable through the reverse proxy rather than directly.",
              "No action needed.");
          }
        });

        // ---- URL transport ----
        order.forEach(function(key){
          var e = lastEntry(key);
          if (!e) return;
          if (key === "LOCAL_DOMAIN" || key === "WEB_DOMAIN") return;
          if (/^http:\/\//i.test(e.value)){
            var host = hostOf(e.value);
            if (isLocalHost(host)){
              add("INFO","TRANSPORT",key,e.line,null,
                key + " (line " + e.line + ") uses http:// on a local host (" + host + "). Plain http inside the machine is a normal local-development and internal-wiring choice.",
                "No action needed for local hosts. Use https:// for anything public.");
            } else {
              add("HIGH","TRANSPORT",key,e.line,null,
                key + " (line " + e.line + ") uses http:// on a public host (" + host + "). Traffic to it — including API and streaming traffic — crosses the network unencrypted and can be read or altered in transit.",
                "Switch " + key + " to the https:// address for " + host + " and make sure the host serves a valid certificate.");
            }
          } else if (/^https:\/\//i.test(e.value) && /URL|HOST|ENDPOINT|DOMAIN/.test(key)){
            add("PASS","TRANSPORT",key,e.line,null,
              key + " (line " + e.line + ") uses https://, so traffic to it is encrypted in transit.",
              "No action needed.");
          }
        });

        // ---- Verdict ----
        var hasBlocker = findings.some(function(f){ return f.severity === "BLOCKER"; });
        var hasHighOrWarn = findings.some(function(f){ return f.severity === "HIGH" || f.severity === "WARNING"; });
        var verdict, sub;
        if (hasBlocker){
          verdict = "DO NOT DEPLOY";
          sub = "At least one BLOCKER finding must be fixed before this config goes anywhere near a server.";
        } else if (hasHighOrWarn){
          verdict = "DEPLOY WITH FIXES";
          sub = "No blockers, but HIGH or WARNING findings remain. Fix them first — each one names its fix.";
        } else {
          verdict = "SAFE TO DEPLOY";
          sub = "No BLOCKER, HIGH, or WARNING findings. INFO and PASS notes are recorded below for the record.";
        }
        return finish(findings, verdict, recognizedCount, sub);
      }

      var SEV_ORDER = { BLOCKER:0, HIGH:1, WARNING:2, INFO:3, PASS:4 };
      function finish(findings, verdict, recognizedCount, sub){
        var counts = { BLOCKER:0, HIGH:0, WARNING:0, INFO:0, PASS:0, "NOT PARSED":0, COMMENTED:0 };
        findings.forEach(function(f){
          if (f.category === "NOT PARSED") counts["NOT PARSED"]++;
          else if (f.category === "COMMENTED") counts["COMMENTED"]++;
          else if (counts.hasOwnProperty(f.severity)) counts[f.severity]++;
        });
        var sorted = findings.slice().sort(function(a,b){
          var ca = a.category === "NOT PARSED" ? 2 : (a.category === "COMMENTED" ? 3.5 : SEV_ORDER[a.severity]);
          var cb = b.category === "NOT PARSED" ? 2 : (b.category === "COMMENTED" ? 3.5 : SEV_ORDER[b.severity]);
          if (ca !== cb) return ca - cb;
          var la = a.line === null ? 9999 : a.line, lb = b.line === null ? 9999 : b.line;
          return la - lb;
        });
        return { verdict: verdict, sub: sub, counts: counts, findings: sorted, recognizedCount: recognizedCount };
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-mastodon-server-config-safety-auditortm',
  name: 'J-Dawgs Mastodon Server Config Safety Auditor',
  description: 'Grades a pasted Mastodon env config fully offline into one deploy verdict — SAFE TO DEPLOY / DEPLOY WITH FIXES / DO NOT DEPLOY / NOT ENOUGH TO GRADE — short or example core secrets, plaintext passwords, and federation and bind posture, with secrets shown by key name, line, and length only, never by ',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
