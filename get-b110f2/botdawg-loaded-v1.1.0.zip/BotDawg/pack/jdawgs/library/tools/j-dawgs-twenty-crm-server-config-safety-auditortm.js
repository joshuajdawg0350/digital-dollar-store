'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Twenty CRM Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        /* ---------- Built-in examples ---------- */

        var RISKY_EXAMPLE = [
          "# Twenty CRM — production attempt (risky example)",
          "APP_SECRET=short-example-secret",
          "PG_DATABASE_URL=postgres://twenty:shortpw@db.example.com:5432/twenty",
          "SERVER_URL=http://crm.example.com",
          "FRONT_BASE_URL=http://crm.example.com",
          "SIGN_UP_DISABLED=false",
          "NODE_ENV=development",
          "DEBUG_MODE=true",
          "STORAGE_TYPE=local",
          "EMAIL_SMTP_PASSWORD=hunter2plaintext"
        ].join("\n");

        var HARDENED_EXAMPLE = [
          "# Twenty CRM — production (hardened example)",
          "APP_SECRET=${env:APP_SECRET}",
          "SIGNING_SECRET=${env:SIGNING_SECRET}",
          "ENCRYPTION_KEY=${env:ENCRYPTION_KEY}",
          "PG_DATABASE_URL=${env:PG_DATABASE_URL}",
          "SERVER_URL=https://crm.example.com",
          "FRONT_BASE_URL=https://crm.example.com",
          "SIGN_UP_DISABLED=true",
          "NODE_ENV=production",
          "DEBUG_MODE=false",
          "STORAGE_TYPE=S3",
          "STORAGE_S3_KEY_ID=${env:STORAGE_S3_KEY_ID}",
          "STORAGE_S3_SECRET_ACCESS_KEY=${env:STORAGE_S3_SECRET_ACCESS_KEY}",
          "EMAIL_SMTP_PASSWORD=${env:EMAIL_SMTP_PASSWORD}"
        ].join("\n");

        /* Secret values planted in the risky example. The self-test proves
           these strings appear 0 times in findings, report, and JSON. */
        var PLANTED_SECRETS = ["short-example-secret", "shortpw", "hunter2plaintext"];

        /* ---------- Recognition ---------- */

        var KNOWN_KEYS = {
          APP_SECRET: 1, SIGNING_SECRET: 1, ENCRYPTION_KEY: 1,
          PG_DATABASE_URL: 1, DATABASE_URL: 1, REDIS_URL: 1,
          SERVER_URL: 1, FRONT_BASE_URL: 1, PORT: 1,
          SIGN_UP_DISABLED: 1, IS_SIGN_UP_DISABLED: 1, SIGN_UP_ENABLED: 1,
          DEBUG_MODE: 1, NODE_ENV: 1,
          STORAGE_TYPE: 1, STORAGE_S3_KEY_ID: 1, STORAGE_S3_SECRET_ACCESS_KEY: 1,
          STORAGE_S3_REGION: 1, STORAGE_S3_BUCKET_NAME: 1,
          AWS_ACCESS_KEY_ID: 1, AWS_SECRET_ACCESS_KEY: 1,
          EMAIL_SMTP_HOST: 1, EMAIL_SMTP_PORT: 1, EMAIL_SMTP_USER: 1,
          EMAIL_SMTP_PASSWORD: 1, EMAIL_FROM_ADDRESS: 1, EMAIL_FROM_NAME: 1,
          SMTP_HOST: 1, SMTP_PORT: 1, SMTP_USER: 1, SMTP_PASSWORD: 1,
          ACCESS_TOKEN_SECRET: 1, REFRESH_TOKEN_SECRET: 1, LOGIN_TOKEN_SECRET: 1,
          AUTH_GOOGLE_ENABLED: 1, AUTH_MICROSOFT_ENABLED: 1,
          WORKSPACE_API_KEY: 1, CAPTCHA_SITE_KEY: 1
        };

        function isRecognized(key) {
          if (KNOWN_KEYS[key]) return true;
          if (/_FILE$/.test(key) && KNOWN_KEYS[key.replace(/_FILE$/, "")]) return true;
          if (/(SECRET|ENCRYPTION_KEY|SIGNING|PASSWORD|PASSWD)/.test(key)) return true;
          if (/^(STORAGE_S3_|AWS_|EMAIL_|SMTP_|PG_|SERVER_URL|FRONT_BASE_URL)/.test(key)) return true;
          return false;
        }

        /* ---------- Helpers ---------- */

        function isRef(value) {
          return /\$\{[^}]+\}/.test(value);
        }
        function isTruthy(v) {
          return /^(true|1|yes|on)$/i.test(String(v).trim());
        }
        function isFalsy(v) {
          return /^(false|0|no|off)$/i.test(String(v).trim());
        }
        function hostOf(value) {
          var m = String(value).match(/^[a-z][a-z0-9+.-]*:\/\/([^\/:?#]+)/i);
          return m ? m[1].toLowerCase() : "";
        }
        function isLocalHost(host) {
          return host === "localhost" || host === "127.0.0.1" || host === "::1" || /\.local$/.test(host);
        }

        var WEAK_WORDS = ["example", "changeme", "change-me", "change_me", "default", "secret123", "placeholder"];
        function weakWordIn(value) {
          var v = value.toLowerCase();
          for (var i = 0; i < WEAK_WORDS.length; i++) {
            if (v.indexOf(WEAK_WORDS[i]) !== -1) return WEAK_WORDS[i];
          }
          if (/(^|[^a-z])test([^a-z]|$)/.test(v)) return "test";
          return null;
        }

        /* ---------- Parser ---------- */

        function parseConfig(text) {
          var lines = String(text).split(/\r?\n/);
          var entries = [];        /* {key, value, line} in order */
          var malformed = [];      /* line numbers */
          for (var i = 0; i < lines.length; i++) {
            var lineNo = i + 1;
            var raw = lines[i];
            var line = raw.trim();
            if (line === "") continue;
            if (line.charAt(0) === "#") continue;
            if (line.indexOf("- ") === 0) line = line.slice(2).trim();       /* compose list item */
            if (/^export\s+/i.test(line)) line = line.replace(/^export\s+/i, "");
            var m = line.match(/^([A-Za-z_][A-Za-z0-9_.]*)\s*[:=]\s*(.*)$/);
            if (!m) { malformed.push(lineNo); continue; }
            var key = m[1].toUpperCase();
            var value = m[2].trim();
            if (value === "" && /:$/.test(line)) continue;                    /* YAML section header */
            if (value.length >= 2) {
              var q = value.charAt(0);
              if ((q === '"' || q === "'") && value.charAt(value.length - 1) === q) {
                value = value.slice(1, -1);
              }
            }
            if (value.charAt(0) !== '"' && value.charAt(0) !== "'") {
              var hashIdx = value.indexOf(" #");
              if (hashIdx !== -1) value = value.slice(0, hashIdx).trim();
            }
            entries.push({ key: key, value: value, line: lineNo });
          }
          return { entries: entries, malformed: malformed, totalLines: lines.length };
        }

        /* ---------- Auditor ---------- */

        var SEV_ORDER = { BLOCKER: 0, HIGH: 1, WARNING: 2, INFO: 3 };

        function audit(text) {
          var parsed = parseConfig(text);
          var findings = [];
          function add(severity, line, key, message, fix) {
            findings.push({ severity: severity, line: line, key: key, message: message, fix: fix });
          }

          /* Malformed lines: reported, excluded from grading. */
          parsed.malformed.forEach(function (lineNo) {
            add("INFO", lineNo, "(unparsed line)", "NOT PARSED — this line is not a recognizable key=value setting, so it was left out of the grade.",
              "Rewrite the line as KEY=value (or KEY: value in YAML), or delete it if it is not a setting.");
          });

          /* Last-wins map + duplicate reporting. */
          var byKey = {};
          var order = [];
          parsed.entries.forEach(function (e) {
            if (byKey[e.key]) {
              add("WARNING", e.line, e.key,
                "Duplicate key — first set on line " + byKey[e.key].firstLine + ", set again on line " + e.line + ". The last value wins, so line " + e.line + " is the one graded.",
                "Delete the copy you do not mean to use so the file says one thing in one place.");
              byKey[e.key].value = e.value;
              byKey[e.key].line = e.line;
            } else {
              byKey[e.key] = { value: e.value, line: e.line, firstLine: e.line };
              order.push(e.key);
            }
          });

          var recognized = order.filter(isRecognized);
          var result = {
            verdict: "NOT ENOUGH TO GRADE",
            recognizedCount: recognized.length,
            recognizedKeys: recognized.slice(),
            findings: findings,
            counts: { BLOCKER: 0, HIGH: 0, WARNING: 0, INFO: 0 }
          };

          if (recognized.length < 3) {
            finish();
            return result;
          }

          function get(key) { return byKey[key] || null; }
          function present(key) { return !!byKey[key]; }
          function isFileKey(key) { return /_FILE$/.test(key); }

          /* Cross-config signals. */
          var hasPublicURL = false;
          var hasHttpsURL = false;
          order.forEach(function (k) {
            var v = byKey[k].value;
            var host = hostOf(v);
            if (host && !isLocalHost(host)) hasPublicURL = true;
            if (/^https:\/\//i.test(v)) hasHttpsURL = true;
          });
          var nodeEnv = get("NODE_ENV");
          var productionSignals = hasPublicURL || hasHttpsURL ||
            (nodeEnv && /^production$/i.test(nodeEnv.value));

          /* --- Core secret keys: APP_SECRET and friends --- */
          var secretStyle = order.filter(function (k) {
            if (isFileKey(k)) return false;
            if (/S3/.test(k)) return false;                 /* handled under storage */
            if (/PASSWORD|PASSWD/.test(k)) return false;    /* handled under email/db */
            return /(^|_)(APP_SECRET|SIGNING_SECRET|ENCRYPTION_KEY)$/.test(k) ||
                   /SECRET/.test(k) || /ENCRYPTION_KEY/.test(k) || /SIGNING/.test(k);
          });

          if (!present("APP_SECRET") && !present("APP_SECRET_FILE")) {
            add("BLOCKER", null, "APP_SECRET",
              "APP_SECRET is missing entirely. Twenty signs sessions and tokens with this secret; without it the server is running on an absent or fallback signing key.",
              "Set APP_SECRET to a random value of at least 32 characters, handed in as a ${...} reference or a secret file — never typed into a file that gets committed.");
          }

          secretStyle.forEach(function (k) {
            var e = get(k);
            var v = e.value;
            if (isRef(v)) return;                            /* reference = safe */
            if (v === "") {
              add("BLOCKER", e.line, k, k + " is set but empty (0 characters).",
                "Give " + k + " a random value of at least 32 characters, handed in as a ${...} reference or a secret file.");
              return;
            }
            var weak = weakWordIn(v);
            if (weak) {
              add("BLOCKER", e.line, k,
                k + " contains a placeholder word (the value is " + v.length + " characters). Placeholder secrets are the first thing an attacker tries.",
                "Replace " + k + " with a freshly generated random value of at least 32 characters and hand it in as a ${...} reference or a secret file.");
              return;
            }
            if (v.length < 32) {
              add("BLOCKER", e.line, k,
                k + " is only " + v.length + " characters long. Core signing and encryption secrets under 32 characters can be brute-forced.",
                "Regenerate " + k + " at 32 characters or longer and hand it in as a ${...} reference or a secret file.");
            }
          });

          /* --- Database URLs --- */
          ["PG_DATABASE_URL", "DATABASE_URL"].forEach(function (k) {
            var e = get(k);
            if (!e || isFileKey(k)) return;
            var v = e.value;
            if (isRef(v)) return;
            var m = v.match(/:\/\/([^:\/@]+):([^@]+)@/);
            if (!m) return;
            var pw = m[2];
            if (isRef(pw)) return;
            add("HIGH", e.line, k,
              k + " carries a plaintext database password typed right into the URL (password is " + pw.length + " characters). Anyone who can read this file owns the database.",
              "Move the database password into your secret store and hand the whole URL in as a ${...} reference, or use a *_FILE secret.");
            if (pw.length < 12) {
              add("BLOCKER", e.line, k,
                "Same line: the database password inside " + k + " is only " + pw.length + " characters — under the 12-character floor for a database password.",
                "Set a database password of at least 12 characters (16 or more is better) and store it as a secret, not in the URL.");
            }
          });

          /* --- Public URLs --- */
          ["SERVER_URL", "FRONT_BASE_URL"].forEach(function (k) {
            var e = get(k);
            if (!e) return;
            var v = e.value;
            var host = hostOf(v);
            if (/^http:\/\//i.test(v) && host && !isLocalHost(host)) {
              add("HIGH", e.line, k,
                k + " starts with http:// on a public host, so logins and session cookies travel unencrypted.",
                "Put the server behind https:// (a reverse proxy or certificate) and set " + k + " to the https:// address.");
            } else if (host && isLocalHost(host) && productionSignals) {
              add("WARNING", e.line, k,
                k + " points at localhost, but the rest of this config looks like production. Links, emails, and redirects built from this URL will break for real users.",
                "Set " + k + " to the real public https:// address of the deployment.");
            }
          });

          /* --- Signup posture --- */
          var sud = get("SIGN_UP_DISABLED");
          var isud = get("IS_SIGN_UP_DISABLED");
          var sue = get("SIGN_UP_ENABLED");
          var signupFlagged = false;
          if (sud && !isRef(sud.value) && isFalsy(sud.value)) {
            add("WARNING", sud.line, "SIGN_UP_DISABLED",
              "SIGN_UP_DISABLED is false, so anyone on the internet can create an account on this CRM the moment it goes live.",
              "Set SIGN_UP_DISABLED=true once your own accounts exist, or restrict signup to your domain in Twenty's settings.");
            signupFlagged = true;
          }
          if (isud && !isRef(isud.value) && isFalsy(isud.value)) {
            add("WARNING", isud.line, "IS_SIGN_UP_DISABLED",
              "IS_SIGN_UP_DISABLED is false, so public signup is enabled on this CRM.",
              "Set IS_SIGN_UP_DISABLED=true once your own accounts exist.");
            signupFlagged = true;
          }
          if (sue && !isRef(sue.value) && isTruthy(sue.value)) {
            add("WARNING", sue.line, "SIGN_UP_ENABLED",
              "SIGN_UP_ENABLED is true, so public signup is explicitly switched on.",
              "Turn signup off once your own accounts exist, unless this CRM is deliberately public.");
            signupFlagged = true;
          }
          if (!sud && !isud && !sue && productionSignals) {
            add("WARNING", null, "SIGN_UP_DISABLED",
              "No signup setting appears anywhere, and this config looks like production — Twenty's default leaves signup open, so strangers can register accounts.",
              "Add SIGN_UP_DISABLED=true (after creating your own admin account) so the door closes behind you.");
          }

          /* --- Debug / environment --- */
          var dbg = get("DEBUG_MODE");
          if (dbg && isTruthy(dbg.value)) {
            if (hasPublicURL) {
              add("HIGH", dbg.line, "DEBUG_MODE",
                "DEBUG_MODE is on and this config carries a public URL. Debug output leaks stack traces, settings, and sometimes secrets to anyone who triggers an error.",
                "Set DEBUG_MODE=false for anything reachable from the internet.");
            } else {
              add("WARNING", dbg.line, "DEBUG_MODE",
                "DEBUG_MODE is on. Fine on a local bench, a leak if this config ever goes public.",
                "Set DEBUG_MODE=false before this config leaves your machine.");
            }
          }
          if (nodeEnv && /^development$/i.test(nodeEnv.value)) {
            if (hasPublicURL) {
              add("HIGH", nodeEnv.line, "NODE_ENV",
                "NODE_ENV=development on a config with a public URL. Development mode relaxes security checks and prints verbose errors in production.",
                "Set NODE_ENV=production for the live deployment.");
            } else {
              add("WARNING", nodeEnv.line, "NODE_ENV",
                "NODE_ENV=development. Right for local work; wrong for anything public.",
                "Set NODE_ENV=production for the live deployment.");
            }
          }

          /* --- Storage --- */
          var st = get("STORAGE_TYPE");
          var hasS3Keys = order.some(function (k) { return /^STORAGE_S3_/.test(k) || /^AWS_/.test(k); });
          if (st && /^local$/i.test(st.value) && !hasS3Keys) {
            add("INFO", st.line, "STORAGE_TYPE",
              "STORAGE_TYPE is local and no S3 keys are present. Uploaded files live on this one server's disk — they vanish if the container or disk does.",
              "For a lasting deployment, switch STORAGE_TYPE to S3 (or your provider's equivalent) and hand the keys in as secrets.");
          }
          ["STORAGE_S3_SECRET_ACCESS_KEY", "AWS_SECRET_ACCESS_KEY"].forEach(function (k) {
            var e = get(k);
            if (!e || isFileKey(k)) return;
            if (isRef(e.value) || e.value === "") return;
            add("HIGH", e.line, k,
              k + " is written as a plaintext value (" + e.value.length + " characters). A leaked S3 secret key hands an attacker your file storage.",
              "Move " + k + " into your secret store and reference it as ${...}, or use a *_FILE secret.");
          });

          /* --- Email / SMTP passwords --- */
          order.forEach(function (k) {
            if (!/(PASSWORD|PASSWD)/.test(k)) return;
            if (!/(SMTP|EMAIL|MAIL)/.test(k)) return;
            if (isFileKey(k)) return;
            var e = get(k);
            if (isRef(e.value) || e.value === "") return;
            add("HIGH", e.line, k,
              k + " is a plaintext email/SMTP password (" + e.value.length + " characters) sitting in the config file. Anyone with the file can send mail as you and reset accounts tied to that mailbox.",
              "Move " + k + " into your secret store and reference it as ${...}, or use a *_FILE secret.");
          });

          finish();

          function finish() {
            findings.sort(function (a, b) {
              var d = SEV_ORDER[a.severity] - SEV_ORDER[b.severity];
              if (d !== 0) return d;
              return (a.line || 0) - (b.line || 0);
            });
            result.counts = { BLOCKER: 0, HIGH: 0, WARNING: 0, INFO: 0 };
            findings.forEach(function (f) { result.counts[f.severity]++; });
            if (result.recognizedCount < 3) {
              result.verdict = "NOT ENOUGH TO GRADE";
            } else if (result.counts.BLOCKER > 0) {
              result.verdict = "DO NOT DEPLOY";
            } else if (result.counts.HIGH > 0 || result.counts.WARNING > 0) {
              result.verdict = "DEPLOY WITH FIXES";
            } else {
              result.verdict = "SAFE TO DEPLOY";
            }
          }

          return result;
        }

        /* ---------- Rendering ---------- */

        function esc(s) {
          return String(s).replace(/[&<>"']/g, function (c) {
            return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
          });
        }

        function findingsText(result) {
          if (!result.findings.length) return "No findings. Nothing in the checks fired.";
          return result.findings.map(function (f) {
            return "[" + f.severity + "] " + (f.line ? "Line " + f.line : "Missing key") + " · " + f.key + " — " + f.message + " Fix: " + f.fix;
          }).join("\n");
        }

        function buildReport(result) {
          var lines = [];
          lines.push("J-Dawgs Twenty CRM Server Config Safety Auditor™ — audit report");
          lines.push("Verdict: " + result.verdict);
          lines.push("Recognizable Twenty keys found: " + result.recognizedCount +
            (result.recognizedKeys.length ? " (" + result.recognizedKeys.join(", ") + ")" : ""));
          lines.push("Findings: " + result.findings.length +
            " — BLOCKER " + result.counts.BLOCKER +
            ", HIGH " + result.counts.HIGH +
            ", WARNING " + result.counts.WARNING +
            ", INFO " + result.counts.INFO);
          lines.push("");
          lines.push(findingsText(result));
          lines.push("");
          lines.push("Secret values are never shown in this report: findings name the key, the line, and the value's character length only. This audit ran entirely in the browser on pasted text; it did not connect to any server and did not verify that any secret is real.");
          return lines.join("\n");
        }

        function buildJSON(result) {
          return JSON.stringify({
            tool: "J-Dawgs Twenty CRM Server Config Safety Auditor™",
            verdict: result.verdict,
            recognizedKeyCount: result.recognizedCount,
            recognizedKeys: result.recognizedKeys,
            counts: result.counts,
            findings: result.findings.map(function (f) {
              return { severity: f.severity, line: f.line, key: f.key, message: f.message, fix: f.fix };
            }),
            note: "Secret values are never included. Findings report key name, line number, and character length only."
          }, null, 2);
        }

        var lastResult = null;
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-twenty-crm-server-config-safety-auditortm',
  name: 'J-Dawgs Twenty CRM Server Config Safety Auditor',
  description: 'Grades a pasted Twenty CRM server config offline into one deploy verdict, secrets by key name/line/length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
