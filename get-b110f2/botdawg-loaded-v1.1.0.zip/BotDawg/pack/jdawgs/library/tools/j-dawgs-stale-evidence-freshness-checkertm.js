'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Stale Evidence & Freshness Checker".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the analyze function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var TYPES = ["price", "status", "schedule", "inventory", "news", "general"];
        var STOPWORDS = {
          the:1, a:1, an:1, and:1, or:1, of:1, to:1, in:1, on:1, at:1, for:1, is:1, are:1,
          was:1, were:1, be:1, been:1, it:1, its:1, this:1, that:1, with:1, from:1, by:1,
          as:1, now:1, today:1, currently:1, you:1, your:1, we:1, our:1, they:1, their:1,
          has:1, have:1, will:1, can:1, not:1, but:1, all:1, any:1, per:1, via:1
        };
        var CURRENCY_PATTERNS = [
          { re: /\bcurrently\b/i, word: "currently" },
          { re: /\bright now\b/i, word: "right now" },
          { re: /\bnow\b/i, word: "now" },
          { re: /\btoday\b/i, word: "today" },
          { re: /\bin stock\b/i, word: "in stock" },
          { re: /\bcosts?\b/i, word: "costs" },
          { re: /\$\s?\d/, word: "$ amount" },
          { re: /\bis open\b/i, word: "is open" },
          { re: /\bopen now\b/i, word: "open now" },
          { re: /\bis scheduled\b/i, word: "is scheduled" },
          { re: /\bscheduled to\b/i, word: "scheduled to" }
        ];
        var MONTHS = "january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sep|sept|oct|nov|dec";

        function $(id) { return document.getElementById(id); }
        function esc(s) {
          return String(s).replace(/[&<>"']/g, function (c) {
            return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
          });
        }
        function pad(n) { return (n < 10 ? "0" : "") + n; }
        function fmtISO(d) { return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate()); }
        function fmtLong(iso) {
          var p = parseISODate(iso);
          if (!p) return iso;
          var names = ["January","February","March","April","May","June","July","August","September","October","November","December"];
          return names[p.m - 1] + " " + p.d + ", " + p.y;
        }
        // Strict ISO date / datetime -> {y,m,d} or null
        function parseISODate(str) {
          if (!str) return null;
          var m = String(str).trim().match(/^(\d{4})-(\d{2})-(\d{2})(?:[T ](\d{2}):(\d{2})(?::(\d{2})(?:\.\d+)?)?(?:Z|[+-]\d{2}:?\d{2})?)?$/);
          if (!m) return null;
          var y = +m[1], mo = +m[2], d = +m[3];
          if (mo < 1 || mo > 12 || d < 1 || d > 31) return null;
          var dt = new Date(Date.UTC(y, mo - 1, d));
          if (dt.getUTCFullYear() !== y || dt.getUTCMonth() !== mo - 1 || dt.getUTCDate() !== d) return null;
          return { y: y, m: mo, d: d };
        }
        function dayNum(p) { return Date.UTC(p.y, p.m - 1, p.d) / 86400000; }
        function tokens(text) {
          var out = {}, raw = String(text).toLowerCase().match(/[a-z0-9]+/g) || [];
          for (var i = 0; i < raw.length; i++) {
            var t = raw[i];
            if ((t.length >= 3 || /^\d+$/.test(t)) && !STOPWORDS[t]) out[t] = 1;
          }
          return out;
        }
        function sharedCount(a, b) {
          var n = 0, shared = [];
          for (var k in a) if (b[k]) { n++; shared.push(k); }
          return { n: n, shared: shared };
        }

        /* ---------------- Evidence parsing ---------------- */
        function parseEvidence(text) {
          var sources = [], bad = [];
          var lines = String(text).split(/\r?\n/);
          for (var i = 0; i < lines.length; i++) {
            var raw = lines[i], lineNo = i + 1;
            if (!raw.trim()) continue;
            var fail = function (reason) { bad.push({ line: lineNo, text: raw.trim(), reason: reason }); };
            var head = raw.match(/^\s*SOURCE:\s*(.*)$/i);
            if (!head) { fail("does not start with “SOURCE:”"); continue; }
            var parts = head[1].split("|").map(function (s) { return s.trim(); });
            var label = parts[0];
            if (!label) { fail("missing source label"); continue; }
            var src = {
              line: lineNo, label: label, retrieved: null, retParts: null,
              type: "general", typeGiven: false, cached: null, age: null, flags: []
            };
            var lineBad = null;
            for (var j = 1; j < parts.length; j++) {
              if (!parts[j]) continue;
              var kv = parts[j].match(/^([A-Za-z]+)\s*:\s*(.*)$/);
              if (!kv) continue; // unrecognized fragment: ignored, key fields still parsed
              var key = kv[1].toUpperCase(), val = kv[2].trim();
              if (key === "RETRIEVED") {
                var p = parseISODate(val);
                if (!p) { lineBad = "RETRIEVED value “" + val + "” is not a valid ISO date"; break; }
                src.retrieved = val.slice(0, 10); src.retParts = p;
              } else if (key === "TYPE") {
                var t = val.toLowerCase();
                if (TYPES.indexOf(t) === -1) { lineBad = "TYPE value “" + val + "” is not one of price|status|schedule|inventory|news|general"; break; }
                src.type = t; src.typeGiven = true;
              } else if (key === "CACHED") {
                var c = val.toLowerCase();
                if (c !== "yes" && c !== "no") { lineBad = "CACHED value “" + val + "” is not yes/no"; break; }
                src.cached = (c === "yes");
              }
            }
            if (lineBad) { fail(lineBad); continue; }
            src.keywords = tokens(label + " " + src.type);
            sources.push(src);
          }
          return { sources: sources, bad: bad };
        }

        /* ---------------- Draft scanning ---------------- */
        function splitSentences(text) {
          var out = [], re = /[^.!?\n]+(?:[.!?]+["'”’)\]]*)?/g, m;
          while ((m = re.exec(text)) !== null) {
            if (m[0].trim()) out.push({ text: m[0], start: m.index, end: m.index + m[0].length });
            if (m[0].length === 0) re.lastIndex++;
          }
          return out;
        }
        function currencyHits(sentence) {
          var hits = [];
          for (var i = 0; i < CURRENCY_PATTERNS.length; i++) {
            if (CURRENCY_PATTERNS[i].re.test(sentence)) hits.push(CURRENCY_PATTERNS[i].word);
          }
          return hits;
        }
        function hasAsOfDate(draft) {
          var re = new RegExp("as of\\s+(?:\\d{4}-\\d{2}-\\d{2}|\\d{1,2}/\\d{1,2}/\\d{2,4}|(?:" + MONTHS + ")\\s+\\d{1,2}(?:st|nd|rd|th)?,?\\s+\\d{4}|\\d{1,2}\\s+(?:" + MONTHS + ")\\s+\\d{4})", "i");
          return re.test(draft);
        }

        function getThresholds() {
          var th = {};
          TYPES.forEach(function (t) {
            var v = parseInt($("th-" + t).value, 10);
            th[t] = isNaN(v) || v < 0 ? 0 : v;
          });
          return th;
        }
        function getNow() {
          var v = $("nowDate").value;
          var p = parseISODate(v);
          if (p) return { iso: v, parts: p };
          var t = new Date();
          return { iso: fmtISO(t), parts: { y: t.getFullYear(), m: t.getMonth() + 1, d: t.getDate() } };
        }

        /* ---------------- Analysis ---------------- */
        function analyze() {
          var draft = $("draft").value;
          var evidenceText = $("evidence").value;
          var results = $("results");

          if (!draft.trim() && !evidenceText.trim()) {
            results.innerHTML = '<div class="empty-msg"><strong>Nothing to check.</strong><br/>Both the draft answer and the evidence list are empty. Paste your text above — or load the stale or fresh sample — then press <strong>Check freshness</strong>.</div>';
            return null;
          }

          var now = getNow();
          var th = getThresholds();
          var parsed = parseEvidence(evidenceText);
          var sources = parsed.sources;

          // Ages + date flags
          sources.forEach(function (s) {
            if (!s.retParts) {
              s.flags.push("UNDATED");
            } else {
              s.age = dayNum(now.parts) - dayNum(s.retParts);
              if (s.age > th[s.type]) s.flags.push("STALE");
              if (s.age < 0) s.flags.push("FUTURE-DATED");
            }
          });

          // Claims
          var sentences = splitSentences(draft);
          var claims = [];
          sentences.forEach(function (sent) {
            var hits = currencyHits(sent.text);
            if (!hits.length) return;
            var claim = { sentence: sent, hits: hits, matches: [], label: "NO SOURCE MATCH", staleSource: null };
            var ct = tokens(sent.text);
            var best = 0;
            sources.forEach(function (s) {
              var sc = sharedCount(ct, s.keywords);
              if (sc.n > 0) {
                claim.matches.push({ source: s, score: sc.n, shared: sc.shared });
                if (sc.n > best) best = sc.n;
              }
            });
            // Only the strongest keyword matches count as the evidence a claim
            // "appears to rely on" — a single shared brand word is not backing.
            if (claim.matches.length) {
              claim.matches = claim.matches.filter(function (mm) { return mm.score === best; });
            }
            if (claim.matches.length) {
              var anyStale = null, anyDatedFresh = null;
              claim.matches.forEach(function (mm) {
                if (mm.source.flags.indexOf("STALE") !== -1) {
                  if (!anyStale || mm.score > anyStale.score ||
                      (mm.score === anyStale.score && mm.source.age > anyStale.source.age)) anyStale = mm;
                } else if (mm.source.retParts) {
                  anyDatedFresh = mm;
                }
              });
              if (anyStale) { claim.label = "STALE-BACKED"; claim.staleSource = anyStale.source; }
              else if (anyDatedFresh) { claim.label = "FRESH"; }
              else { claim.label = "UNDATED-BACKED"; }
              // CACHED_AS_LIVE: cached source relied on by a present-tense claim
              claim.matches.forEach(function (mm) {
                if (mm.source.cached && mm.source.flags.indexOf("CACHED_AS_LIVE") === -1) {
                  mm.source.flags.push("CACHED_AS_LIVE");
                }
              });
            }
            claims.push(claim);
          });

          var missingAsOf = claims.length > 0 && !hasAsOfDate(draft);

          // Verdict
          var anyCachedLive = sources.some(function (s) { return s.flags.indexOf("CACHED_AS_LIVE") !== -1; });
          var anyUndatedBacked = claims.some(function (c) { return c.label === "UNDATED-BACKED"; });
          var anyNoSource = claims.some(function (c) { return c.label === "NO SOURCE MATCH"; });
          var anyStaleBacked = claims.some(function (c) { return c.label === "STALE-BACKED"; });
          var verdict, vClass, vWhy;
          if (anyCachedLive || anyUndatedBacked || anyNoSource) {
            verdict = "DO NOT PRESENT AS CURRENT"; vClass = "dont";
            var reasons = [];
            if (anyCachedLive) reasons.push("cached evidence is being presented as live");
            if (anyUndatedBacked) reasons.push("a current-sounding claim rests on an undated source");
            if (anyNoSource) reasons.push("a current-sounding claim matches no source at all");
            vWhy = "Why: " + reasons.join("; ") + ".";
          } else if (anyStaleBacked || missingAsOf) {
            verdict = "SEND WITH AS-OF DATES"; vClass = "asof";
            var r2 = [];
            if (anyStaleBacked) r2.push("some claims are backed by stale evidence — date them with the fixed draft below");
            if (missingAsOf) r2.push("the draft makes current-sounding claims but carries no “as of” date");
            vWhy = "Why: " + r2.join("; ") + ".";
          } else {
            verdict = "SAFE TO SEND AS CURRENT"; vClass = "safe";
            vWhy = claims.length
              ? "Every current-sounding claim is backed by dated evidence inside its freshness threshold."
              : "No current-sounding claims were found in the draft, and no blocking evidence problems were detected.";
          }

          // Fixed draft: insert " (as of <date>)" into stale-backed claim sentences
          var fixedDraft = draft, changed = [];
          var edits = [];
          claims.forEach(function (c) {
            if (c.label === "STALE-BACKED" && c.staleSource) {
              edits.push({ start: c.sentence.start, end: c.sentence.end, text: c.sentence.text, date: c.staleSource.retrieved });
            }
          });
          edits.sort(function (a, b) { return b.start - a.start; });
          edits.forEach(function (e) {
            var m = e.text.match(/^([\s\S]*?)([.!?]+["'”’)\]]*)?(\s*)$/);
            var body = m[1], punct = m[2] || "", trail = m[3] || "";
            var trimmedBody = body.replace(/\s+$/, "");
            var newText = trimmedBody + " (as of " + e.date + ")" + punct + trail;
            fixedDraft = fixedDraft.slice(0, e.start) + newText + fixedDraft.slice(e.end);
            changed.push(e.date);
          });

          var result = {
            now: now, th: th, sources: sources, bad: parsed.bad, claims: claims,
            missingAsOf: missingAsOf, verdict: verdict, vClass: vClass, vWhy: vWhy,
            fixedDraft: fixedDraft, fixedChanged: changed.length > 0, draft: draft
          };
          render(result);
          return result;
        }

        /* ---------------- Rendering ---------------- */
        function flagChip(f) {
          var cls = "neutral";
          if (f === "STALE" || f === "CACHED_AS_LIVE" || f === "UNDATED") cls = f === "STALE" ? "stale" : (f === "CACHED_AS_LIVE" ? "cached" : "undated");
          if (f === "MISSING_AS_OF") cls = "missing";
          if (f === "FRESH" || f === "OK") cls = "ok";
          return '<span class="flag ' + cls + '">' + esc(f) + "</span>";
        }
        function claimClass(label) {
          return label === "FRESH" ? "fresh" : label.toLowerCase().replace(/ /g, "-");
        }
        function sourceMeta(s, th) {
          var bits = [];
          bits.push("type: " + s.type + (s.typeGiven ? "" : " (default)"));
          if (s.retParts) {
            bits.push("retrieved " + s.retrieved);
            bits.push("age " + s.age + (s.age === 1 ? " day" : " days"));
            bits.push("threshold " + th[s.type] + (th[s.type] === 1 ? " day" : " days"));
          } else {
            bits.push("no retrieval date — cannot be called current");
          }
          bits.push("cached: " + (s.cached === null ? "not stated" : (s.cached ? "yes" : "no")));
          bits.push("evidence line " + s.line);
          return bits.join(" · ");
        }

        function buildReport(r) {
          var L = [];
          L.push("J-DAWGS STALE EVIDENCE & FRESHNESS CHECKER — REPORT");
          L.push("Now (as entered): " + r.now.iso);
          L.push("Thresholds (days): " + TYPES.map(function (t) { return t + " " + r.th[t]; }).join(" · "));
          L.push("");
          L.push("VERDICT: " + r.verdict);
          L.push(r.vWhy.replace(/^Why: /, "Reason: "));
          L.push("");
          L.push("SOURCES (" + r.sources.length + ")");
          if (!r.sources.length) L.push("  (none parsed)");
          r.sources.forEach(function (s, i) {
            var fl = s.flags.length ? "[" + s.flags.join("] [") + "] " : "[OK] ";
            L.push((i + 1) + ". " + fl + s.label);
            L.push("   " + sourceMeta(s, r.th));
          });
          if (r.bad.length) {
            L.push("");
            L.push("UNPARSABLE LINES (reported and excluded)");
            r.bad.forEach(function (b) {
              L.push("  Line " + b.line + ": " + b.reason + " — “" + b.text + "”");
            });
          }
          L.push("");
          L.push("DRAFT-LEVEL FLAGS");
          L.push(r.missingAsOf
            ? "  [MISSING_AS_OF] The draft makes current-sounding claims but contains no “as of” date anywhere."
            : "  None.");
          L.push("");
          L.push("CURRENCY CLAIMS (" + r.claims.length + ")");
          if (!r.claims.length) L.push("  No current-sounding claims found in the draft.");
          r.claims.forEach(function (c, i) {
            L.push((i + 1) + ". " + c.label + " — “" + c.sentence.text.trim() + "”");
            L.push("   Currency words: " + c.hits.join(", "));
            if (c.matches.length) {
              c.matches.forEach(function (mm) {
                var s = mm.source;
                L.push("   Matched source: “" + s.label + "”" +
                  (s.retParts ? " (retrieved " + s.retrieved + ", age " + s.age + " days)" : " (undated)") +
                  " — shared keywords: " + mm.shared.join(", "));
              });
            } else {
              L.push("   Matched source: none — no shared keywords with any parsed source.");
            }
          });
          L.push("");
          L.push("FIXED DRAFT" + (r.fixedChanged
            ? " (“as of” qualifiers added to stale-backed claims; no numbers or facts changed)"
            : " (unchanged — no stale-backed claims to qualify)"));
          L.push(r.fixedDraft.trim() ? r.fixedDraft : "(draft was empty)");
          return L.join("\n");
        }

        function render(r) {
          var html = "";
          html += '<div class="verdict ' + r.vClass + '"><div class="v-label">Verdict</div>' +
            '<div class="v-text">' + esc(r.verdict) + '</div>' +
            '<div class="v-why">' + esc(r.vWhy) + "</div></div>";

          html += '<div class="panel"><h2>Sources</h2>';
          if (!r.sources.length) {
            html += '<p class="subtle">No sources were parsed from the evidence list.</p>';
          }
          r.sources.forEach(function (s) {
            var chips = s.flags.length ? s.flags.map(flagChip).join("") : flagChip("OK");
            html += '<div class="item"><div class="title">' + esc(s.label) + "</div>" +
              "<div>" + chips + "</div>" +
              '<div class="meta">' + esc(sourceMeta(s, r.th)) + "</div></div>";
          });
          if (r.bad.length) {
            html += "<h3>Unparsable lines — reported &amp; excluded</h3>";
            r.bad.forEach(function (b) {
              html += '<div class="item"><div class="title">Line ' + b.line + ": " + esc(b.reason) + "</div>" +
                '<div class="meta mono">' + esc(b.text) + "</div></div>";
            });
          }
          html += "</div>";

          html += '<div class="panel"><h2>Draft check</h2>';
          if (r.missingAsOf) {
            html += '<div class="item"><div>' + flagChip("MISSING_AS_OF") + "</div>" +
              '<div class="meta">The draft makes current-sounding claims but contains no “as of” date anywhere. A reader cannot tell when the facts were true.</div></div>';
          }
          if (!r.claims.length) {
            html += '<p class="subtle">No current-sounding claims found in the draft (no sentences using words like currently, now, today, in stock, costs, is open, or is scheduled).</p>';
          }
          r.claims.forEach(function (c, i) {
            html += '<div class="item"><div class="claim-label ' + claimClass(c.label) + '">' + (i + 1) + ". " + esc(c.label) + "</div>" +
              '<div class="quote">“' + esc(c.sentence.text.trim()) + '”</div>' +
              '<div class="meta">Currency words: ' + esc(c.hits.join(", ")) + "</div>";
            if (c.matches.length) {
              c.matches.forEach(function (mm) {
                var s = mm.source;
                html += '<div class="meta">↳ backed by “' + esc(s.label) + '”' +
                  (s.retParts ? " — retrieved " + esc(s.retrieved) + ", " + s.age + (s.age === 1 ? " day" : " days") + " old" : " — undated") +
                  " (shared: " + esc(mm.shared.join(", ")) + ")</div>";
              });
            } else {
              html += '<div class="meta">↳ no source shares keywords with this claim.</div>';
            }
            html += "</div>";
          });
          html += "</div>";

          html += '<div class="panel"><div class="row-head"><h2 style="margin:0;">Fixed draft suggestion</h2>' +
            '<button type="button" class="small" id="btnCopyFixed">Copy fixed draft</button></div>' +
            '<p class="sr-note">' + (r.fixedChanged
              ? "“As of” qualifiers were inserted into stale-backed claim sentences using each backing source's retrieval date. No numbers or facts were changed. Undated-backed and unmatched claims cannot be qualified this way — they need fresh evidence."
              : "No stale-backed claims needed an “as of” qualifier, so the draft is unchanged.") + "</p>" +
            '<textarea id="fixedDraft" class="mono" readonly style="min-height:120px;">' + esc(r.fixedDraft) + "</textarea></div>";

          var report = buildReport(r);
          html += '<div class="panel"><div class="row-head"><h2 style="margin:0;">Plain-text report</h2>' +
            '<button type="button" class="small" id="btnCopyReport">Copy report</button></div>' +
            '<div style="height:8px"></div>' +
            '<textarea id="reportText" class="mono" readonly style="min-height:260px;">' + esc(report) + "</textarea></div>";

          $("results").innerHTML = html;

          $("btnCopyFixed").addEventListener("click", function () { copyFrom($("fixedDraft"), this); });
          $("btnCopyReport").addEventListener("click", function () { copyFrom($("reportText"), this); });
        }

        /* ---------------- Copy helpers ---------------- */
        function flashCopied(btn) {
          var old = btn.textContent;
          btn.textContent = "Copied ✓";
          setTimeout(function () { btn.textContent = old; }, 1600);
        }
  return { "analyze": (typeof analyze !== 'undefined' ? analyze : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["analyze"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-stale-evidence-freshness-checkertm',
  name: 'J-Dawgs Stale Evidence & Freshness Checker',
  description: 'Checks a draft against its sources\' retrieval dates and cache status, flags stale or undated evidence presented as current, and inserts honest "as of" qualifiers',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["analyze"]) return { ok: false, output: null, summary: 'Extracted core has no analyze function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
