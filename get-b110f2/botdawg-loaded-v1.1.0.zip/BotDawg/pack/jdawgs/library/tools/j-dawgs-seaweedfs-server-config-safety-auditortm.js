'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs SeaweedFS Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

var RISKY = [
'# SeaweedFS risky example - do not deploy',
'[master]',
'ip.bind = "0.0.0.0"',
'port = 9333',
'[volume]',
'ip.bind = "0.0.0.0"',
'port = 8080',
'[filer]',
'ip.bind = "0.0.0.0"',
's3.enabled = true',
's3.allowAnonymous = true',
's3.accessKey = "AKIAEXAMPLE123"',
's3.secretKey = "plantedsecretvalue123456"',
'jwt.signing.key = "changeme"',
'jwt.signing.read.key = "short"',
'grpc.tls.enabled = false',
'mtls.enabled = false',
'admin.password = "hunter2planted"',
'this line is not valid toml at all !!!',
'# tls.cert.file = "/etc/seaweedfs/tls.crt"'
].join('\n');

var HARDENED = [
'# SeaweedFS hardened example',
'[master]',
'ip.bind = "127.0.0.1"',
'port = 9333',
'[volume]',
'ip.bind = "127.0.0.1"',
'port = 8080',
'[filer]',
'ip.bind = "127.0.0.1"',
's3.enabled = true',
's3.allowAnonymous = false',
's3.accessKey = "${S3_ACCESS_KEY}"',
's3.secretKey = "${S3_SECRET_KEY}"',
'jwt.signing.key = "${JWT_SIGNING_KEY}"',
'jwt.signing.read.key = "${JWT_SIGNING_READ_KEY}"',
'grpc.tls.enabled = true',
'mtls.enabled = true',
'tls.cert.file = "/etc/seaweedfs/certs/server.crt"',
'tls.key.file = "/etc/seaweedfs/certs/server.key"',
'auth.enabled = true'
].join('\n');

var EXAMPLE_WORDS = ['changeme','change-me','change_me','example','your-','your_','placeholder','todo','xxx','secret123','password','default','test','sample','replace','insecure','demo','letmein','admin123'];
var FALSE_WORDS = ['false','disabled','disable','off','no','0'];
var TRUE_WORDS = ['true','enabled','enable','on','yes','1'];

function cleanVal(v){
  v = String(v).trim();
  if (v.length >= 2 && ((v.charAt(0)==='"' && v.charAt(v.length-1)==='"') || (v.charAt(0)==="'" && v.charAt(v.length-1)==="'"))) v = v.slice(1,-1);
  return v.trim();
}
function isExternal(v){
  return /^\$\{[^}]+\}$/.test(v) || /^\$[A-Z_][A-Z0-9_]*$/.test(v) || /^env:/i.test(v) || /^file:/i.test(v) || /^vault:/i.test(v) || /^secret:\/\//i.test(v) || /^kms:/i.test(v);
}
function isExample(v){
  var l = v.toLowerCase();
  for (var i=0;i<EXAMPLE_WORDS.length;i++){ if (l.indexOf(EXAMPLE_WORDS[i]) !== -1) return true; }
  return false;
}
function isPathVal(v){
  return v.indexOf('/') !== -1 && !/\s/.test(v);
}
function isFalse(v){ return FALSE_WORDS.indexOf(v.toLowerCase()) !== -1; }
function isTrue(v){ return TRUE_WORDS.indexOf(v.toLowerCase()) !== -1; }
function isSecretKey(k){ return /(secret|password|passwd|pwd|key|token)/.test(k); }

function parseFlags(text, lineNo, entries){
  var tokens = text.match(/"[^"]*"|'[^']*'|\S+/g) || [];
  var count = 0;
  for (var i=0;i<tokens.length;i++){
    var t = tokens[i];
    if (t.charAt(0) !== '-') continue;
    var body = t.replace(/^-+/, '');
    if (!body) continue;
    var eq = body.indexOf('=');
    if (eq > 0){
      var k = body.slice(0,eq).trim().toLowerCase();
      var v = cleanVal(body.slice(eq+1));
      entries.push({key:k, keyDisplay:body.slice(0,eq).trim(), value:v, line:lineNo});
      count++;
    } else if (/^[A-Za-z0-9_.\-]+$/.test(body)){
      entries.push({key:body.toLowerCase(), keyDisplay:body, value:'true', line:lineNo});
      count++;
    }
  }
  return count;
}

function parseConfig(text){
  var lines = String(text).split(/\r?\n/);
  var entries = [], commented = [], notParsed = [], sections = [];
  var section = '';
  for (var i=0;i<lines.length;i++){
    var lineNo = i+1;
    var raw = lines[i];
    var trimmed = raw.trim();
    if (!trimmed) continue;
    if (trimmed.charAt(0) === '#' || trimmed.indexOf('//') === 0){
      var body = trimmed.replace(/^#+\s?/, '').replace(/^\/\/\s?/, '');
      var guess = '';
      var eq = body.indexOf('=');
      if (eq > 0){ var gk = body.slice(0,eq).trim(); if (/^[A-Za-z0-9_.\-]+$/.test(gk)) guess = gk.toLowerCase(); }
      else if (/^\[[^\]]+\]$/.test(body)) guess = body;
      commented.push({line:lineNo, key:guess, status:'COMMENTED / NOT ACTIVE'});
      continue;
    }
    var secMatch = trimmed.match(/^\[([^\]]+)\]$/);
    if (secMatch){ section = secMatch[1].trim().toLowerCase(); sections.push({name:section, line:lineNo}); continue; }
    if (/^weed\b/i.test(trimmed) && trimmed.indexOf('-') !== -1){
      if (parseFlags(trimmed, lineNo, entries) > 0) continue;
    }
    if (trimmed.charAt(0) === '-' && trimmed.indexOf('=') !== -1){
      if (parseFlags(trimmed, lineNo, entries) > 0) continue;
    }
    var eqIdx = trimmed.indexOf('=');
    if (eqIdx > 0){
      var key = trimmed.slice(0,eqIdx).trim();
      var val = cleanVal(trimmed.slice(eqIdx+1));
      if (/^[A-Za-z0-9_.\-\*]+$/.test(key) && key.length <= 80){
        var fullKey = key.toLowerCase();
        entries.push({key:fullKey, keyDisplay:key, value:val, line:lineNo, section:section});
        continue;
      }
    }
    var colonMatch = trimmed.match(/^([A-Za-z0-9_.\-]+)\s*:\s*(.+)$/);
    if (colonMatch){
      entries.push({key:colonMatch[1].toLowerCase(), keyDisplay:colonMatch[1], value:cleanVal(colonMatch[2]), line:lineNo, section:section});
      continue;
    }
    notParsed.push({line:lineNo, length:trimmed.length, status:'NOT PARSED'});
  }
  return {entries:entries, commented:commented, notParsed:notParsed, sections:sections, totalLines:lines.length};
}

function audit(text){
  var parsed = parseConfig(text);
  var entries = parsed.entries;
  var findings = [];
  function add(sev, line, key, message, valueLength){
    var f = {severity:sev, line:(line==null?null:line), key:key||'', message:message};
    if (typeof valueLength === 'number') f.valueLength = valueLength;
    findings.push(f);
  }
  var relevant = entries.filter(function(e){
    return /(jwt|tls|grpc|mtls|master|volume|filer|s3|ip|bind|port|auth|security|cert|dir|password|secret)/.test(e.key);
  });
  var relevantSections = parsed.sections.filter(function(s){ return /(master|volume|filer|security|s3|jwt)/.test(s.name); });
  if (entries.length === 0 || (relevant.length === 0 && relevantSections.length === 0)){
    return {verdict:'NOT ENOUGH TO GRADE', reason:'No recognisable SeaweedFS settings were found in the pasted text. Paste a security.toml / master.toml / filer.toml style config, key=value lines, or a weed server command line.', findings:[], commented:parsed.commented, notParsed:parsed.notParsed, activeCount:entries.length};
  }

  function findKey(name){ for (var i=0;i<entries.length;i++){ if (entries[i].key === name) return entries[i]; } return null; }
  function keysContaining(s){ return entries.filter(function(e){ return e.key.indexOf(s) !== -1; }); }

  var tlsEnabledEntry = entries.filter(function(e){ return (e.key.indexOf('tls')!==-1 || e.key.indexOf('mtls')!==-1) && isTrue(e.value); })[0] || null;
  var authEnabled = entries.some(function(e){ return e.key.indexOf('auth')!==-1 && isTrue(e.value); });

  /* JWT */
  var signKey = findKey('jwt.signing.key') || entries.filter(function(e){ return e.key.indexOf('jwt.signing.key')!==-1; })[0] || null;
  var readKey = findKey('jwt.signing.read.key') || entries.filter(function(e){ return e.key.indexOf('jwt.signing.read.key')!==-1; })[0] || null;
  var jwtUsable = false;
  if (!signKey){
    add('CRITICAL', null, 'jwt.signing.key', 'jwt.signing.key is missing. Without a signing key, SeaweedFS JWT authentication cannot be trusted — set a long, random, privately held signing key (ideally supplied from an environment variable or secret store).');
  } else if (!isExternal(signKey.value)){
    if (isExample(signKey.value)){
      add('CRITICAL', signKey.line, 'jwt.signing.key', 'jwt.signing.key holds an example / placeholder value. Anyone can guess it — replace it with a long random key from a secret store. Value not shown; length recorded only.', signKey.value.length);
    } else if (signKey.value.length < 16){
      add('CRITICAL', signKey.line, 'jwt.signing.key', 'jwt.signing.key is too short to be safe (under 16 characters). Use a long random key from a secret store. Value not shown; length recorded only.', signKey.value.length);
    } else if (signKey.value.length < 32){
      add('HIGH', signKey.line, 'jwt.signing.key', 'jwt.signing.key is short (under 32 characters). Use a longer random key from a secret store. Value not shown; length recorded only.', signKey.value.length);
    } else {
      add('MEDIUM', signKey.line, 'jwt.signing.key', 'jwt.signing.key is stored as plaintext in the config. Move it to an environment variable or secret store reference (for example ${JWT_SIGNING_KEY}). Value not shown; length recorded only.', signKey.value.length);
    }
  }
  if (signKey && (isExternal(signKey.value) || (!isExample(signKey.value) && signKey.value.length >= 16))) jwtUsable = true;

  if (!readKey){
    add('HIGH', null, 'jwt.signing.read.key', 'jwt.signing.read.key is missing. Read-only JWT access cannot be separated from full access — set a distinct long random read key (ideally from an environment variable or secret store).');
  } else if (!isExternal(readKey.value)){
    if (isExample(readKey.value)){
      add('HIGH', readKey.line, 'jwt.signing.read.key', 'jwt.signing.read.key holds an example / placeholder value — replace it with a long random key from a secret store. Value not shown; length recorded only.', readKey.value.length);
    } else if (readKey.value.length < 32){
      add('HIGH', readKey.line, 'jwt.signing.read.key', 'jwt.signing.read.key is too short (under 32 characters). Use a long random key from a secret store. Value not shown; length recorded only.', readKey.value.length);
    } else {
      add('MEDIUM', readKey.line, 'jwt.signing.read.key', 'jwt.signing.read.key is stored as plaintext in the config. Move it to an environment variable or secret store reference. Value not shown; length recorded only.', readKey.value.length);
    }
  }

  /* mTLS / gRPC TLS */
  var tlsEntries = entries.filter(function(e){ return e.key.indexOf('tls')!==-1 || e.key.indexOf('mtls')!==-1 || e.key.indexOf('grpc')!==-1; });
  var tlsDisabled = tlsEntries.filter(function(e){ return isFalse(e.value); });
  tlsDisabled.forEach(function(e){
    add('CRITICAL', e.line, (e.keyDisplay || e.key), 'TLS is switched off here (' + (e.keyDisplay || e.key) + ' is set to a disabled value). Master, volume, and filer traffic — including credentials — can cross the network unencrypted. Turn TLS / mTLS on and supply certificates.');
  });
  if (tlsEntries.length === 0){
    add('HIGH', null, '(no TLS setting found)', 'No mTLS or gRPC TLS setting appears in the active config. Nothing in the pasted text shows encrypted, certificate-checked traffic between SeaweedFS components — add TLS / mTLS settings and certificates.');
  } else if (!tlsEnabledEntry && tlsDisabled.length === 0){
    add('HIGH', null, '(TLS settings)', 'TLS-related settings are present but none clearly switches TLS / mTLS on. Confirm gRPC TLS and mTLS are enabled, not just mentioned.');
  }
  if (tlsEnabledEntry && !entries.some(function(e){ return e.key.indexOf('cert')!==-1; })){
    add('MEDIUM', tlsEnabledEntry.line, tlsEnabledEntry.key, 'TLS is enabled but no certificate file setting appears in the pasted text. Make sure the certificate and key file paths are configured on every component.');
  }

  var authEvidence = jwtUsable || authEnabled || !!tlsEnabledEntry;

  /* Bind to all interfaces */
  entries.forEach(function(e){
    var isBind = e.key === 'ip' || e.key === 'ip.bind' || e.key === 'bind' || e.key.slice(-3) === '.ip' || e.key.slice(-8) === '.ip.bind' || e.key.indexOf('ip.bind') !== -1;
    if (!isBind) return;
    var v = e.value.toLowerCase();
    if (v === '0.0.0.0' || v === '::' || v === '[::]' || v === '*'){
      if (!authEvidence){
        add('CRITICAL', e.line, (e.keyDisplay || e.key), 'This component is bound to all network interfaces (0.0.0.0 / ::) and the config shows no working authentication or TLS to protect it. Anyone who can reach the port can reach the service. Bind to a private address or loopback, or put authenticated, TLS-protected access in front of it.');
      } else {
        add('MEDIUM', e.line, (e.keyDisplay || e.key), 'This component is bound to all network interfaces (0.0.0.0 / ::). Authentication or TLS is present elsewhere in the config, but a private bind address is still safer where the service does not need to be public.');
      }
    }
  });

  /* Filer S3 */
  var s3Entries = keysContaining('s3');
  var s3Enabled = s3Entries.some(function(e){ return (e.key.indexOf('enabled')!==-1 || e.key === 's3' || e.key === 'filer.s3') && isTrue(e.value); }) ||
                    entries.some(function(e){ return e.key.indexOf('s3.')!==-1; }) && s3Entries.some(function(e){ return e.key.indexOf('enabled')!==-1 && isTrue(e.value); });
  s3Entries.forEach(function(e){
    if (e.key.indexOf('anonymous') !== -1 && isTrue(e.value)){
      add('CRITICAL', e.line, (e.keyDisplay || e.key), 'Filer S3 anonymous access is allowed. Anyone who can reach the S3 endpoint can use it without credentials. Turn anonymous access off and require signed requests.');
    }
    if ((e.key.indexOf('access') !== -1 || e.key.indexOf('secret') !== -1) && e.value && !isExternal(e.value) && !isPathVal(e.value)){
      add('HIGH', e.line, (e.keyDisplay || e.key), 'A filer S3 credential is stored as plaintext in the config. Move it to an environment variable or secret store reference. Value not shown; length recorded only.', e.value.length);
    }
  });
  if (s3Enabled && !s3Entries.some(function(e){ return e.key.indexOf('access')!==-1 || e.key.indexOf('secret')!==-1; })){
    add('MEDIUM', null, 's3 (filer)', 'Filer S3 is enabled but no S3 credential settings appear in the pasted text. Confirm how S3 requests are authenticated before deploying.');
  }

  /* Generic plaintext secrets (jwt.* and s3.* already covered above) */
  entries.forEach(function(e){
    if (e.key.indexOf('jwt.') === 0 || e.key.indexOf('s3') !== -1) return;
    if (!isSecretKey(e.key)) return;
    if (!e.value) return;
    if (isExternal(e.value)) return;
    if (isPathVal(e.value)) return;
    if (isTrue(e.value) || isFalse(e.value)) return;
    var sev = (isExample(e.value) || e.value.length < 12) ? 'HIGH' : 'MEDIUM';
    add(sev, e.line, (e.keyDisplay || e.key), 'Plaintext secret in ' + (e.keyDisplay || e.key) + '. Anyone who can read this config can use it. Move it to an environment variable or secret store reference. Value not shown; length recorded only.', e.value.length);
  });

  var verdict, reason;
  var hasCrit = findings.some(function(f){ return f.severity==='CRITICAL'; });
  if (hasCrit){ verdict = 'DO NOT DEPLOY'; reason = 'Critical problems were found. Fix every critical finding before this config goes anywhere near a live cluster.'; }
  else if (findings.length > 0){ verdict = 'DEPLOY WITH FIXES'; reason = 'No critical problems, but fixes are needed before this config is deployment-ready. Work through the findings below.'; }
  else { verdict = 'SAFE TO DEPLOY'; reason = 'No problems from the graded checks were found in the active (non-commented) settings of the pasted text.'; }
  return {verdict:verdict, reason:reason, findings:findings, commented:parsed.commented, notParsed:parsed.notParsed, activeCount:entries.length};
}

var lastResult = null;

function esc(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_WORDS": (typeof EXAMPLE_WORDS !== 'undefined' ? EXAMPLE_WORDS : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-seaweedfs-server-config-safety-auditortm',
  name: 'J-Dawgs SeaweedFS Server Config Safety Auditor',
  description: '',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_WORDS": __core["EXAMPLE_WORDS"] }
};
