'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs dnscrypt-proxy Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ============================================================
         Worked examples
         ============================================================ */
      var RISKY_EXAMPLE = [
        "# dnscrypt-proxy.toml - example workstation config (risky)",
        "listen_addresses = ['0.0.0.0:53']",
        "server_names = []",
        "require_dnssec = false",
        "require_nolog = false",
        "require_nofilter = false",
        "cache = false",
        "fallback_resolver = '9.9.9.9:53'",
        "provider_secret_key = 'PLANTED-SECRET-DO-NOT-LEAK-9f3k'",
        "",
        "[sources]",
        "  [sources.public-resolvers]",
        "  urls = ['https://download.dnscrypt.info/resolvers-list/v3/public-resolvers.md']",
        "  cache_file = 'public-resolvers.md'",
        "  minisign_key = 'SHORTKEY123'"
      ].join("\n");

      var HARDENED_EXAMPLE = [
        "# dnscrypt-proxy.toml - hardened local resolver",
        "listen_addresses = ['127.0.0.1:53', '[::1]:53']",
        "server_names = ['cloudflare', 'quad9-dnscrypt']",
        "require_dnssec = true",
        "require_nolog = true",
        "require_nofilter = true",
        "dnscrypt_servers = true",
        "doh_servers = true",
        "ipv6_servers = true",
        "block_ipv6 = false",
        "cache = true",
        "cache_size = 4096",
        "cache_min_ttl = 2400",
        "cache_max_ttl = 86400",
        "lb_strategy = 'p2'",
        "timeout = 5000",
        "log_level = 2",
        "bootstrap_resolvers = ['9.9.9.9:853', '8.8.8.8:853']",
        "",
        "[sources.public-resolvers]",
        "urls = ['https://download.dnscrypt.info/resolvers-list/v3/public-resolvers.md']",
        "cache_file = 'public-resolvers.md'",
        "minisign_key = 'RWQf6LRCGA9i53mlYecO4IzT51TGPpvWucNSCh1CBM0QTaLn73Y7GFO3a7Kd92Qz'",
        "",
        "[anonymized_dns]",
        "routes = [",
        "  { server_name = 'quad9-dnscrypt', via = ['anon-quad9'] }",
        "]"
      ].join("\n");

      /* ============================================================
         TOML-ish line parser (offline, text only)
         ============================================================ */
      function splitComment(line) {
        var inS = false, inD = false;
        for (var i = 0; i < line.length; i++) {
          var c = line.charAt(i);
          if (inD) { if (c === '"') inD = false; }
          else if (inS) { if (c === "'") inS = false; }
          else if (c === '"') inD = true;
          else if (c === "'") inS = true;
          else if (c === "#") return { code: line.slice(0, i), comment: line.slice(i + 1) };
        }
        return { code: line, comment: "" };
      }

      function parseConfig(text) {
        var lines = String(text == null ? "" : text).split(/\r?\n/);
        var entries = [];   // {key, raw, line, section}
        var sections = [];  // {name, line}
        var comments = [];
        var section = "";
        for (var i = 0; i < lines.length; i++) {
          var parts = splitComment(lines[i]);
          if (parts.comment) comments.push(parts.comment);
          var code = parts.code.replace(/^\s+|\s+$/g, "");
          if (!code) continue;
          var sm = code.match(/^\[([^\]]+)\]\s*$/);
          if (sm) {
            section = sm[1].replace(/^\s+|\s+$/g, "");
            sections.push({ name: section, line: i + 1 });
            continue;
          }
          var km = code.match(/^([A-Za-z0-9_.\-]+)\s*=\s*(.*)$/);
          if (km) {
            var val = km[2].replace(/\s+$/g, "");
            var startLine = i + 1;
            var guard = 0;
            while (val.charAt(0) === "[" && val.indexOf("]") === -1 && i + 1 < lines.length && guard < 60) {
              i++; guard++;
              val += " " + splitComment(lines[i]).code.replace(/^\s+|\s+$/g, "");
            }
            entries.push({ key: km[1], raw: val, line: startLine, section: section });
          }
        }
        return { entries: entries, sections: sections, comments: comments.join("\n"), lineCount: lines.length };
      }

      function asString(raw) {
        var m = String(raw).match(/^'([^']*)'/) || String(raw).match(/^"([^"]*)"/);
        return m ? m[1] : null;
      }
      function asBool(raw) {
        var t = String(raw).replace(/\s+/g, "");
        if (t === "true") return true;
        if (t === "false") return false;
        return null;
      }
      function asNum(raw) {
        var n = parseInt(String(raw), 10);
        return isNaN(n) ? null : n;
      }
      function asArray(raw) {
        var out = [], re = /'([^']*)'|"([^"]*)"/g, m;
        var s = String(raw);
        while ((m = re.exec(s)) !== null) out.push(m[1] !== undefined ? m[1] : m[2]);
        return out;
      }
      function isEmptyArray(raw) { return /^\[\s*\]$/.test(String(raw).replace(/\s+/g, " ").replace(/^\s+|\s+$/g, "")) || /^\[\s*\]$/.test(String(raw).trim()); }
      function hostOf(addr) {
        var a = String(addr).replace(/^\s+|\s+$/g, "");
        if (a.charAt(0) === "[") {
          var end = a.indexOf("]");
          return end > 0 ? a.slice(1, end) : a;
        }
        var parts = a.split(":");
        if (parts.length === 2) return parts[0];
        return a;
      }
      function portOf(addr) {
        var a = String(addr).replace(/^\s+|\s+$/g, "");
        var bi = a.indexOf("]");
        if (bi >= 0) {
          var rest = a.slice(bi + 1);
          var bm = rest.match(/:(\d+)$/);
          return bm ? parseInt(bm[1], 10) : null;
        }
        var m = a.match(/:(\d+)$/);
        if (m && a.indexOf(":") === a.lastIndexOf(":")) return parseInt(m[1], 10);
        return null;
      }
      function valueLength(entry) {
        var s = asString(entry.raw);
        if (s !== null) return s.length;
        return String(entry.raw).replace(/^\s+|\s+$/g, "").length;
      }

      var RECOGNIZED_KEYS = {
        listen_addresses: 1, server_names: 1, disabled_server_names: 1,
        require_dnssec: 1, require_nolog: 1, require_nofilter: 1,
        dnscrypt_servers: 1, doh_servers: 1, odoh_servers: 1,
        ipv6_servers: 1, block_ipv6: 1, block_unqualified: 1, block_undelegated: 1,
        cache: 1, cache_size: 1, cache_min_ttl: 1, cache_max_ttl: 1,
        cache_neg_min_ttl: 1, cache_neg_max_ttl: 1,
        lb_strategy: 1, lb_estimator: 1, timeout: 1, netprobe_timeout: 1,
        log_level: 1, log_file: 1, log_files_max_size: 1,
        bootstrap_resolvers: 1, fallback_resolver: 1, ignore_system_dns: 1,
        netprobe_address: 1, minisign_key: 1, urls: 1, cache_file: 1,
        routes: 1, server_name: 1, via: 1, offline_mode: 1, force_tcp: 1,
        http_proxy: 1, proxy: 1, query_log: 1, cert_refresh_delay: 1,
        tls_cipher_suite: 1, reject_cipher_suites: 1, best_rtt_only: 1,
        edns_client_subnet_block: 1, forwarding_rules: 1, cloaking_rules: 1,
        blocked_query_response: 1, local_doh: 1, dns64: 1, prefix: 1,
        format: 1, file: 1, refresh_delay: 1
      };
      var RECOGNIZED_SECTIONS = { sources: 1, anonymized_dns: 1, static: 1, query_log: 1, nx_log: 1, schedules: 1, dns64: 1, local_doh: 1 };

      /* ============================================================
         The audit
         ============================================================ */
      function auditConfig(text) {
        var parsed = parseConfig(text);
        var entries = parsed.entries;
        var findings = [];
        function add(severity, line, check, message, fix) {
          findings.push({ severity: severity, line: (typeof line === "number" ? line : null), check: check, message: message, fix: fix });
        }
        function first(key) {
          for (var i = 0; i < entries.length; i++) if (entries[i].key === key) return entries[i];
          return null;
        }
        function all(key) {
          var out = [];
          for (var i = 0; i < entries.length; i++) if (entries[i].key === key) out.push(entries[i]);
          return out;
        }
        function sectionLine(prefix) {
          for (var i = 0; i < parsed.sections.length; i++) {
            if (parsed.sections[i].name === prefix || parsed.sections[i].name.indexOf(prefix + ".") === 0) return parsed.sections[i].line;
          }
          return null;
        }

        /* --- Recognizability gate --- */
        var recognizedSet = {};
        var i, e;
        for (i = 0; i < entries.length; i++) if (RECOGNIZED_KEYS[entries[i].key]) recognizedSet[entries[i].key] = 1;
        for (i = 0; i < parsed.sections.length; i++) {
          var root = parsed.sections[i].name.split(".")[0];
          if (RECOGNIZED_SECTIONS[root]) recognizedSet["[" + root + "]"] = 1;
        }
        var recognizedCount = Object.keys(recognizedSet).length;

        if (recognizedCount < 3) {
          add("INFO", null, "Not a recognizable dnscrypt-proxy config",
            "Only " + recognizedCount + " recognizable dnscrypt-proxy key(s) were found in the pasted text, so there is not enough here to grade. This verdict also covers empty pastes and unrelated text.",
            "Paste the full contents of a dnscrypt-proxy.toml file (it should contain keys such as listen_addresses, server_names, and require_dnssec), then audit again.");
          return finish("NOT ENOUGH TO GRADE", findings, recognizedCount);
        }

        /* --- Check 1: listen_addresses --- */
        var la = first("listen_addresses");
        if (!la) {
          add("INFO", null, "listen_addresses not set",
            "No listen_addresses key was found. dnscrypt-proxy's built-in default binds localhost only, but an explicit bind is easier to audit and cannot drift.",
            "Set listen_addresses = ['127.0.0.1:53', '[::1]:53'] explicitly.");
        } else {
          var addrs = asArray(la.raw);
          var wild = [], loop = 0, other = 0;
          for (i = 0; i < addrs.length; i++) {
            var h = hostOf(addrs[i]);
            if (h === "0.0.0.0" || h === "::" || h === "") wild.push(addrs[i]);
            else if (h === "127.0.0.1" || h === "::1" || h === "localhost") loop++;
            else other++;
          }
          if (wild.length) {
            add("BLOCKER", la.line, "listen_addresses binds all interfaces",
              "listen_addresses includes a wildcard bind (" + wild.length + " of " + addrs.length + " entries), so the proxy answers DNS queries from every network interface — the whole LAN, and the internet if this host is exposed. Anyone who can reach it can use it as an open resolver.",
              "Bind loopback only: listen_addresses = ['127.0.0.1:53', '[::1]:53']. If other machines genuinely must use this resolver, bind the specific LAN address instead of a wildcard and firewall port 53.");
          } else if (other > 0) {
            add("WARNING", la.line, "listen_addresses binds a non-loopback address",
              "listen_addresses binds at least one specific non-loopback address. That can be right for a deliberate LAN resolver, but it is a serving decision, not a default.",
              "Confirm the exposure is intended and firewall port 53 to the LAN. For a local-only resolver, use ['127.0.0.1:53', '[::1]:53'].");
          } else if (addrs.length) {
            add("INFO", la.line, "listen_addresses is loopback-only",
              "All listen addresses are loopback (127.0.0.1 / ::1), so the proxy only serves this machine.",
              "No change needed.");
          } else {
            add("WARNING", la.line, "listen_addresses is an empty list",
              "listen_addresses is present but empty, so the bind posture depends on build defaults rather than your stated intent.",
              "Set listen_addresses = ['127.0.0.1:53', '[::1]:53'].");
          }
        }

        /* --- Check 2: require_dnssec --- */
        var rd = first("require_dnssec");
        if (!rd) {
          add("HIGH", null, "require_dnssec is absent",
            "require_dnssec does not appear in the config, so the default posture is unverified: the proxy may happily serve resolvers that do not validate DNSSEC, and forged answers would pass through.",
            "Add require_dnssec = true so only DNSSEC-validating resolvers are used.");
        } else if (asBool(rd.raw) === false) {
          add("HIGH", rd.line, "require_dnssec = false",
            "DNSSEC validation is explicitly not required. The proxy can pick resolvers that never check cryptographic signatures on DNS answers, so spoofed records are accepted as-is.",
            "Set require_dnssec = true.");
        } else if (asBool(rd.raw) === true) {
          add("INFO", rd.line, "require_dnssec = true",
            "Only resolvers that validate DNSSEC are accepted.",
            "No change needed.");
        }

        /* --- Check 3: require_nolog / require_nofilter --- */
        function requireFlag(key, label, why) {
          var ent = first(key);
          if (!ent) {
            add("WARNING", null, key + " is absent",
              key + " does not appear in the config, so " + label + " is not enforced — the proxy may select servers that do not meet it.",
              "Add " + key + " = true. " + why);
          } else if (asBool(ent.raw) === false) {
            add("HIGH", ent.line, key + " = false",
              key + " is explicitly off, so the proxy may select servers that ignore " + label + ".",
              "Set " + key + " = true. " + why);
          } else if (asBool(ent.raw) === true) {
            add("INFO", ent.line, key + " = true", label.charAt(0).toUpperCase() + label.slice(1) + " is required of every selected server.", "No change needed.");
          }
        }
        requireFlag("require_nolog", "a no-logging policy", "This keeps query logs out of your resolver choice.");
        requireFlag("require_nofilter", "content filtering being off (uncensored answers)", "This keeps the proxy from silently using censoring resolvers.");

        /* --- Check 4: encrypted protocol posture --- */
        var protoKeys = ["dnscrypt_servers", "doh_servers", "odoh_servers"];
        var anyProtoOn = false, protoLine = null;
        for (i = 0; i < protoKeys.length; i++) {
          e = first(protoKeys[i]);
          if (e) { if (protoLine === null) protoLine = e.line; if (asBool(e.raw) === true) anyProtoOn = true; }
        }
        if (!anyProtoOn) {
          add("WARNING", protoLine, "No encrypted protocol is explicitly enabled",
            "dnscrypt_servers, doh_servers, and odoh_servers are all false or absent, so no encrypted transport (DNSCrypt / DoH / ODoH) is explicitly switched on in the config text.",
            "Enable at least one encrypted protocol, e.g. dnscrypt_servers = true and doh_servers = true.");
        }

        /* --- Check 5: cache --- */
        var cacheEnt = first("cache");
        var cacheSizeEnt = first("cache_size");
        var cacheVal = cacheEnt ? asBool(cacheEnt.raw) : null;
        if (cacheVal === false) {
          add("HIGH", cacheEnt.line, "cache = false",
            "The resolver cache is disabled. Every query goes upstream, which leaks more query traffic to resolvers, adds latency, and makes query patterns easier to observe.",
            "Set cache = true and a bounded cache_size such as 4096.");
        } else {
          if (!cacheSizeEnt) {
            add("WARNING", cacheEnt ? cacheEnt.line : null, "cache_size is absent",
              "cache_size does not appear in the config, so the cache bound is whatever the build default is rather than a size you chose and audited.",
              "Set an explicit, bounded cache_size such as 4096.");
          } else {
            var cs = asNum(cacheSizeEnt.raw);
            if (cs === null || cs === 0 || cs > 100000) {
              add("WARNING", cacheSizeEnt.line, "cache_size is disabled or unbounded",
                "cache_size is " + (cs === null ? "not a readable number" : String(cs)) + ". A size of 0 disables caching; a very large size lets the cache grow without a practical bound and can serve stale answers longer.",
                "Set cache_size to a bounded value such as 4096.");
            }
          }
        }

        /* --- Check 6: anonymized DNS --- */
        var routesEnt = null;
        for (i = 0; i < entries.length; i++) {
          if (entries[i].key === "routes" && entries[i].section === "anonymized_dns") { routesEnt = entries[i]; break; }
        }
        var routesPresent = !!(routesEnt && /server_name/.test(routesEnt.raw));
        var anonLine = sectionLine("anonymized_dns");
        var claimText = (parsed.comments + "\n" + String(text)).toLowerCase();
        var privacyClaim = /\bprivacy\b|\bprivate\b/.test(parsed.comments.toLowerCase()) || /\banonymized\b/.test(parsed.comments.toLowerCase());
        if (routesPresent) {
          add("INFO", routesEnt.line, "Anonymized DNS routes are configured",
            "The [anonymized_dns] section defines at least one route, so queries can be relayed instead of going direct from this host.",
            "No change needed. Keep the relay list maintained — a dead relay silently slows or breaks resolution.");
        } else if (anonLine !== null) {
          add(privacyClaim ? "HIGH" : "WARNING", anonLine, "Anonymized DNS section has no usable routes",
            "An [anonymized_dns] section exists but defines no routes with a server_name, so no query is actually relayed — the privacy the section implies is not happening.",
            "Add at least one route, e.g. routes = [ { server_name = 'quad9-dnscrypt', via = ['anon-quad9'] } ], or remove the section and the privacy claim.");
        } else if (privacyClaim) {
          add("WARNING", null, "Privacy is claimed but anonymized DNS is missing",
            "The config text talks about privacy, but there is no [anonymized_dns] section with routes, so queries leave this host directly and the resolver sees the client address.",
            "Add an [anonymized_dns] section with at least one route, or drop the privacy claim from the config comments.");
        } else {
          add("INFO", null, "No anonymized DNS routes",
            "No [anonymized_dns] routes are configured and the config makes no privacy claim about relaying, so queries go directly to the chosen resolvers.",
            "Optional: add [anonymized_dns] routes if relayed, address-hiding resolution is wanted.");
        }

        /* --- Check 7: bootstrap / fallback resolvers --- */
        var boot = first("bootstrap_resolvers");
        if (boot) {
          var baddrs = asArray(boot.raw);
          var plain = 0;
          for (i = 0; i < baddrs.length; i++) { if (portOf(baddrs[i]) !== 853) plain++; }
          if (plain > 0) {
            add("WARNING", boot.line, "bootstrap_resolvers include plaintext endpoints",
              plain + " of " + baddrs.length + " bootstrap resolvers do not use port 853. Bootstrap lookups over plain DNS can be observed or redirected before the encrypted channel exists.",
              "Prefer bootstrap_resolvers on port 853 (DNS-over-TLS), e.g. ['9.9.9.9:853', '8.8.8.8:853'], and keep the list short.");
          }
        }
        var fb = first("fallback_resolver");
        if (fb) {
          var fbStr = asString(fb.raw);
          var fbPort = fbStr !== null ? portOf(fbStr) : null;
          if (fbPort !== 853) {
            add("HIGH", fb.line, "fallback_resolver is a plaintext resolver",
              "A fallback resolver is configured that does not use port 853. Whenever the primary path fails, queries silently drop to plaintext DNS — exactly when an attacker would force a failure.",
              "Remove fallback_resolver, or point it at an encrypted endpoint on port 853.");
          }
        }

        /* --- Check 8: IPv6 posture --- */
        var v6s = first("ipv6_servers"), v6b = first("block_ipv6");
        var v6sVal = v6s ? asBool(v6s.raw) : null;
        var v6bVal = v6b ? asBool(v6b.raw) : null;
        if (v6sVal === false && v6bVal === false) {
          add("WARNING", v6s.line, "IPv6 posture is inconsistent",
            "ipv6_servers = false says IPv6 resolvers are unwanted, but block_ipv6 = false lets IPv6 queries leak out anyway — the two settings contradict each other.",
            "Make them agree: either ipv6_servers = true with block_ipv6 = false, or block_ipv6 = true if IPv6 must not be used.");
        } else if (!v6s && !v6b) {
          add("INFO", null, "IPv6 posture is unstated",
            "Neither ipv6_servers nor block_ipv6 appears in the config, so IPv6 behavior follows build defaults rather than a stated choice.",
            "State it explicitly, e.g. ipv6_servers = true and block_ipv6 = false, or block_ipv6 = true on IPv4-only networks.");
        }

        /* --- Check 9: logging --- */
        var ll = first("log_level");
        if (!ll) {
          add("INFO", null, "log_level is absent",
            "No log_level is set, so logging verbosity follows the build default.",
            "Set log_level = 2 (or higher) to keep logs terse in production.");
        } else {
          var llv = asNum(ll.raw);
          if (llv !== null && llv <= 1) {
            add("WARNING", ll.line, "log_level is very verbose",
              "log_level " + llv + " is debug-grade verbosity. Verbose proxy logs can record query history — a privacy liability on disk.",
              "Raise log_level to 2 or higher for serving, and rotate or delete old logs.");
          }
        }
        var lf = first("log_file");
        if (lf && valueLength(lf) > 0) {
          add("WARNING", lf.line, "log_file is set",
            "Output is being written to a log file. Combined with verbose logging, that file becomes a record of DNS activity for whoever can read the disk.",
            "Keep log_level at 2 or higher, restrict the log file's permissions, and confirm no [query_log] section is recording lookups.");
        }
        if (sectionLine("query_log") !== null) {
          add("WARNING", sectionLine("query_log"), "Query logging section present",
            "A [query_log] section records individual DNS lookups — the most privacy-sensitive log dnscrypt-proxy can keep.",
            "Remove the [query_log] section unless query records are genuinely required, and protect the file if they are.");
        }

        /* --- Check 10: minisign_key (public key — value never shown) --- */
        var mkAll = all("minisign_key");
        if (!mkAll.length) {
          add("HIGH", sectionLine("sources"), "minisign_key is missing",
            "No minisign_key was found for the resolver sources, so the config text carries no public key for verifying that downloaded resolver lists are genuine.",
            "Add the source's published minisign_key under its [sources.*] section — copy it from the dnscrypt-proxy project, never invent or shorten it.");
        } else {
          for (i = 0; i < mkAll.length; i++) {
            var mkVal = asString(mkAll[i].raw);
            var mkLen = mkVal !== null ? mkVal.length : valueLength(mkAll[i]);
            var mkLower = (mkVal || "").toLowerCase();
            var placeholder = mkLower.indexOf("example") >= 0 || mkLower.indexOf("xxxx") >= 0 || mkLower.indexOf("placeholder") >= 0 || mkLower.indexOf("your") >= 0;
            if (mkLen === 0) {
              add("BLOCKER", mkAll[i].line, "minisign_key is empty",
                "The minisign_key at this line is empty, so resolver-list signatures cannot be verified at all. (The key is a public key; its value is never printed in this report.)",
                "Paste the source's full published minisign_key (a long base64 string) at this line.");
            } else if (mkLen < 40 || placeholder) {
              add("BLOCKER", mkAll[i].line, "minisign_key is too short or a placeholder",
                "The minisign_key at this line is only " + mkLen + " characters" + (placeholder ? " and looks like placeholder text" : "") + ". A real minisign public key is a long base64 string; a short or placeholder key means resolver lists cannot be properly verified and may fail or be spoofed. (Value not shown.)",
                "Replace it with the source's full published minisign_key (60+ characters, no placeholder text).");
            } else {
              add("INFO", mkAll[i].line, "minisign_key present (public key)",
                "A plausible minisign public key is configured (length " + mkLen + "). It is a public key, so its presence is a pass — and its value is still never printed in this report.",
                "No change needed.");
            }
          }
        }

        /* --- Check 11: server_names --- */
        var sn = first("server_names");
        if (!sn) {
          add("WARNING", null, "server_names is absent",
            "Without an explicit server_names list, the proxy auto-picks from the whole public resolver list — you do not control which operators see your queries.",
            "Pin an explicit list, e.g. server_names = ['cloudflare', 'quad9-dnscrypt'].");
        } else if (isEmptyArray(sn.raw) || asArray(sn.raw).length === 0) {
          add("WARNING", sn.line, "server_names is an empty list",
            "server_names = [] means the proxy picks any resolver that meets the require_* flags. That is auto-pick risk: operators you never chose can enter the rotation.",
            "Name the resolvers you trust, e.g. server_names = ['cloudflare', 'quad9-dnscrypt'].");
        }

        /* --- Check 12: lb_strategy --- */
        var lb = first("lb_strategy");
        if (!lb) {
          add("INFO", null, "lb_strategy is absent",
            "No load-balancing strategy is stated, so the proxy uses its default (p2) behavior.",
            "Optional: set lb_strategy = 'p2' explicitly so the choice is auditable.");
        } else {
          var lbVal = (asString(lb.raw) || "").toLowerCase();
          if (lbVal === "first") {
            add("WARNING", lb.line, "lb_strategy = 'first'",
              "The 'first' strategy always uses the first available server — no load balancing and a single point of failure (and of observation).",
              "Use lb_strategy = 'p2', 'ph', or 'random' so queries spread across the configured servers.");
          }
        }

        /* --- Check 13: timeout --- */
        var to = first("timeout");
        if (!to) {
          add("INFO", null, "timeout is absent",
            "No query timeout is stated, so the build default applies.",
            "Optional: set timeout = 5000 (milliseconds) explicitly.");
        } else {
          var tov = asNum(to.raw);
          if (tov !== null && (tov > 10000 || tov < 1000)) {
            add("WARNING", to.line, "timeout is out of a sane range",
              "timeout is " + tov + " ms. Above 10000 ms, dead resolvers stall every lookup; below 1000 ms, healthy resolvers get cut off and queries retry or fall back.",
              "Set timeout between 1000 and 10000 ms — 5000 is a solid default.");
          }
        }

        /* --- Check 14: secrets — name, line, length ONLY --- */
        var secretRe = /secret|token|password|private/i;
        var keyRe = /key/i;
        for (i = 0; i < entries.length; i++) {
          e = entries[i];
          if (e.key === "minisign_key") continue; /* public key, handled by check 10 */
          if (secretRe.test(e.key) || keyRe.test(e.key)) {
            var len = valueLength(e);
            if (len > 0) {
              add("INFO", e.line, "Secret present: " + e.key,
                "A secret-bearing key '" + e.key + "' is present at line " + e.line + " with a value of length " + len + ". The value is never shown in these findings, the plain-text report, or the JSON export.",
                "Keep real secrets out of shared copies of this config; rotate the value if this file has been pasted anywhere public.");
            }
          }
        }

        return finish(null, findings, recognizedCount);
      }

      function finish(forcedVerdict, findings, recognizedCount) {
        var order = { BLOCKER: 0, HIGH: 1, WARNING: 2, INFO: 3 };
        findings.sort(function (a, b) {
          var d = order[a.severity] - order[b.severity];
          if (d !== 0) return d;
          var la = a.line === null ? 100000 : a.line, lb2 = b.line === null ? 100000 : b.line;
          return la - lb2;
        });
        var counts = { BLOCKER: 0, HIGH: 0, WARNING: 0, INFO: 0 };
        for (var i = 0; i < findings.length; i++) counts[findings[i].severity]++;
        var verdict = forcedVerdict;
        if (!verdict) {
          if (counts.BLOCKER >= 1 || counts.HIGH >= 2) verdict = "DO NOT SERVE";
          else if (counts.HIGH === 1 || counts.WARNING >= 1) verdict = "SERVE WITH FIXES";
          else verdict = "SAFE TO SERVE";
        }
        return { verdict: verdict, counts: counts, findings: findings, recognizedKeys: recognizedCount };
      }

      /* ============================================================
         Report builders (secret values never enter these)
         ============================================================ */
      var TOOL_NAME = "J-Dawgs dnscrypt-proxy Server Config Safety Auditor\u2122";

      function buildReport(r) {
        var out = [];
        out.push(TOOL_NAME);
        out.push("Offline audit of pasted dnscrypt-proxy.toml text. Nothing was uploaded, saved, or sent to any network.");
        out.push("");
        out.push("Verdict: " + r.verdict);
        out.push("Severity counts: BLOCKER " + r.counts.BLOCKER + " | HIGH " + r.counts.HIGH + " | WARNING " + r.counts.WARNING + " | INFO " + r.counts.INFO);
        out.push("Recognizable dnscrypt-proxy keys found: " + r.recognizedKeys);
        out.push("Secret values are never printed: secret-bearing keys are reported by name, line, and value length only.");
        out.push("");
        out.push("FINDINGS");
        if (!r.findings.length) out.push("(none)");
        for (var i = 0; i < r.findings.length; i++) {
          var f = r.findings[i];
          out.push("");
          out.push((i + 1) + ". [" + f.severity + "] " + (f.line === null ? "(config-wide)" : "Line " + f.line) + " - " + f.check);
          out.push("   What: " + f.message);
          out.push("   Fix: " + f.fix);
        }
        return out.join("\n");
      }

      function buildJson(r) {
        return JSON.stringify({
          tool: TOOL_NAME,
          verdict: r.verdict,
          severity_counts: { BLOCKER: r.counts.BLOCKER, HIGH: r.counts.HIGH, WARNING: r.counts.WARNING, INFO: r.counts.INFO },
          recognized_keys: r.recognizedKeys,
          secrets_policy: "Secret values are never included. Secret-bearing keys appear by name, line, and value length only.",
          findings: r.findings.map(function (f) {
            return { severity: f.severity, line: f.line, check: f.check, message: f.message, fix: f.fix };
          })
        }, null, 2);
      }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-dnscrypt-proxy-server-config-safety-auditortm',
  name: 'J-Dawgs dnscrypt-proxy Server Config Safety Auditor',
  description: 'Host tools only tell you the proxy started; ours grades a pasted dnscrypt-proxy config offline into one serve verdict — all-interface binds, DNSSEC/logging/filter requirements off, cache and anonymized-DNS posture, and secrets by key name/line/length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
