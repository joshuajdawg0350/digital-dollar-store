'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs vsftpd Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var RISKY = [
          "# A real-world style vsftpd.conf with real problems planted in it",
          "listen=YES",
          "listen_ipv6=YES",
          "anonymous_enable=YES",
          "anon_upload_enable=YES",
          "anon_mkdir_write_enable=YES",
          "local_enable=YES",
          "write_enable=YES",
          "chroot_local_user=YES",
          "ssl_enable=NO",
          "pasv_min_port=60100",
          "pasv_max_port=60000",
          "guest_enable=YES",
          "guest_password=Tr0pic@lStorm99",
          "this line is not a setting at all",
          "frobnicate_mode=YES"
        ].join("\n");

        var HARDENED = [
          "# The same server, locked down",
          "listen=YES",
          "listen_ipv6=NO",
          "listen_address=192.0.2.10",
          "anonymous_enable=NO",
          "anon_upload_enable=NO",
          "anon_mkdir_write_enable=NO",
          "local_enable=YES",
          "write_enable=YES",
          "chroot_local_user=YES",
          "allow_writeable_chroot=YES",
          "ssl_enable=YES",
          "force_local_logins_ssl=YES",
          "force_local_data_ssl=YES",
          "rsa_cert_file=/etc/ssl/certs/vsftpd.pem",
          "pasv_enable=YES",
          "pasv_min_port=60000",
          "pasv_max_port=60100",
          "userlist_enable=YES",
          "userlist_deny=YES",
          "userlist_file=/etc/vsftpd.userlist",
          "guest_enable=NO",
          "idle_session_timeout=600",
          "data_connection_timeout=120",
          "xferlog_enable=YES"
        ].join("\n");

        var BOOL_KEYS = {};
        ["listen","listen_ipv6","anonymous_enable","anon_upload_enable","anon_mkdir_write_enable",
         "anon_other_write_enable","anon_world_readable_only","local_enable","write_enable",
         "chroot_local_user","chroot_list_enable","allow_writeable_chroot","ssl_enable",
         "force_local_logins_ssl","force_local_data_ssl","force_anon_logins_ssl","force_anon_data_ssl",
         "pasv_enable","pasv_addr_resolve","userlist_enable","userlist_deny","guest_enable",
         "xferlog_enable","xferlog_std_format","log_ftp_protocol","dual_log_enable","dirmessage_enable",
         "tcp_wrappers","check_shell","port_enable","port_promiscuous","pasv_promiscuous",
         "download_enable","dirlist_enable","text_userdb_names","ls_recurse_enable","hide_ids",
         "one_process_model","background","syslog_enable","use_localtime","use_sendfile",
         "ascii_download_enable","ascii_upload_enable","chown_uploads","delete_failed_uploads",
         "connect_from_port_20","ssl_tlsv1","ssl_sslv2","ssl_sslv3","implicit_ssl",
         "require_ssl_reuse","debug_ssl","session_support","setproctitle_enable","force_dot_files",
         "passwd_chroot_enable","no_anon_password","hide_file","deny_email_enable","virtual_use_local_privs"
        ].forEach(function (k) { BOOL_KEYS[k] = true; });

        var NUM_KEYS = {};
        ["pasv_min_port","pasv_max_port","idle_session_timeout","data_connection_timeout",
         "connect_timeout","accept_timeout","local_max_rate","anon_max_rate","max_clients",
         "max_per_ip","listen_port","ftp_data_port","trans_chunk_size","local_umask","anon_umask","file_open_mode"
        ].forEach(function (k) { NUM_KEYS[k] = true; });

        var STR_KEYS = {};
        ["listen_address","listen_address6","anon_root","chroot_list_file","rsa_cert_file",
         "rsa_private_key_file","userlist_file","guest_username","xferlog_file","vsftpd_log_file",
         "ftpd_banner","banner_file","banned_email_file","pam_service_name","secure_chroot_dir",
         "ftp_username","nopriv_user","local_root","user_config_dir","user_sub_token","message_file",
         "cmds_allowed","cmds_denied","deny_file","ssl_ciphers","chown_username","email_password_file"
        ].forEach(function (k) { STR_KEYS[k] = true; });

        function isKnown(key) { return !!(BOOL_KEYS[key] || NUM_KEYS[key] || STR_KEYS[key]); }
        function isSecretKey(key) { return /pass|passwd|secret|token|credential/i.test(key); }

        function audit(text) {
          var findings = [];
          var settings = {};   // key -> {value, line} last occurrence wins, like vsftpd
          var seen = {};
          var lines = text.split(/\r?\n/);

          function add(sev, line, title, body, fix) {
            findings.push({ sev: sev, line: line, title: title, body: body, fix: fix || null });
          }

          lines.forEach(function (raw, idx) {
            var lineNo = idx + 1;
            var line = raw.trim();
            if (line === "" || line.charAt(0) === "#") return;
            var m = line.match(/^([A-Za-z0-9_]+)\s*=\s*(.*)$/);
            if (!m) {
              add("NOT PARSED", lineNo, "Line could not be parsed",
                "This line is not in key=value form, so the auditor skipped it rather than guess at its meaning. Line content is not reproduced here.",
                "Rewrite it as key=value using a real vsftpd directive, or delete the line.");
              return;
            }
            var key = m[1];
            var value = m[2].trim();
            if (!isKnown(key)) {
              add("NOT PARSED", lineNo, "Unrecognized directive: " + key,
                isSecretKey(key)
                  ? "This key is not a directive this auditor recognizes, and because its name looks password-like, its value is deliberately not shown anywhere in these results or the report."
                  : "This key is not a directive this auditor recognizes, so it was skipped rather than guessed at. Its value is not reproduced here.",
                "Check the spelling against the vsftpd.conf man page; if it is a real directive this auditor does not know, audit that line by hand.");
              return;
            }
            if (BOOL_KEYS[key]) {
              var up = value.toUpperCase();
              if (up !== "YES" && up !== "NO") {
                add("NOT PARSED", lineNo, "Unparsable value for " + key,
                  key + " is a YES/NO setting, but line " + lineNo + " does not give it a YES or NO value, so the line was skipped rather than guessed at.",
                  "Set " + key + "=YES or " + key + "=NO.");
                return;
              }
              value = up;
            } else if (NUM_KEYS[key]) {
              if (!/^\d+$/.test(value)) {
                add("NOT PARSED", lineNo, "Unparsable value for " + key,
                  key + " is a numeric setting, but line " + lineNo + " does not give it a whole number, so the line was skipped rather than guessed at.",
                  "Set " + key + " to a whole number.");
                return;
              }
            }
            if (seen[key]) {
              add("INFO", lineNo, "Duplicate setting: " + key,
                key + " also appears at line " + seen[key] + ". vsftpd uses the last value it reads, so line " + lineNo + " is the one in effect.",
                "Remove the earlier " + key + " line so the file says what it means in one place.");
            }
            seen[key] = lineNo;
            settings[key] = { value: value, line: lineNo };
          });

          function get(key) { return settings[key] || null; }
          function isYes(key) { var s = get(key); return !!s && s.value === "YES"; }

          /* ---- Anonymous access ---- */
          var anon = get("anonymous_enable");
          var anonUp = get("anon_upload_enable");
          var anonMk = get("anon_mkdir_write_enable");
          if (!anon) {
            add("BLOCKER", null, "anonymous_enable is not set — and vsftpd's default is YES",
              "This file never mentions anonymous_enable. When the setting is missing, vsftpd's built-in default turns anonymous FTP logins ON, so anyone who can reach the server can log in as the anonymous user without a password.",
              "Add anonymous_enable=NO unless this server is deliberately a public anonymous archive.");
          } else if (anon.value === "YES") {
            var extras = [];
            if (anonUp && anonUp.value === "YES") extras.push("anon_upload_enable=YES (line " + anonUp.line + ")");
            if (anonMk && anonMk.value === "YES") extras.push("anon_mkdir_write_enable=YES (line " + anonMk.line + ")");
            if (extras.length) {
              add("BLOCKER", anon.line, "Anonymous access is ON — and anonymous visitors can write (ESCALATED)",
                "anonymous_enable=YES lets anyone log in with no password. It gets worse: " + extras.join(" and ") + " also set, so those same unauthenticated visitors can put files on your server and create folders — the classic recipe for a server that ends up hosting strangers' files.",
                "Set anonymous_enable=NO. If anonymous read access is truly required, at minimum set anon_upload_enable=NO and anon_mkdir_write_enable=NO.");
            } else {
              add("BLOCKER", anon.line, "Anonymous access is ON",
                "anonymous_enable=YES lets anyone who can reach this server log in as the anonymous user with no password and read whatever the FTP account can read.",
                "Set anonymous_enable=NO unless this server is deliberately a public anonymous archive.");
            }
          } else {
            if (anonUp && anonUp.value === "YES") {
              add("INFO", anonUp.line, "anon_upload_enable=YES has no effect while anonymous access is off",
                "Anonymous logins are disabled (anonymous_enable=NO, line " + anon.line + "), so this upload permission currently does nothing — but it becomes dangerous the day someone turns anonymous access back on.",
                "Set anon_upload_enable=NO so the file stays safe if anonymous access is ever re-enabled.");
            }
            if (anonMk && anonMk.value === "YES") {
              add("INFO", anonMk.line, "anon_mkdir_write_enable=YES has no effect while anonymous access is off",
                "Anonymous logins are disabled (anonymous_enable=NO, line " + anon.line + "), so this folder-creation permission currently does nothing — but it becomes dangerous the day someone turns anonymous access back on.",
                "Set anon_mkdir_write_enable=NO so the file stays safe if anonymous access is ever re-enabled.");
            }
          }

          /* ---- Local logins & TLS posture ---- */
          var local = get("local_enable");
          var ssl = get("ssl_enable");
          var fLogins = get("force_local_logins_ssl");
          var fData = get("force_local_data_ssl");
          var listenAddr = get("listen_address");
          var allInterfaces = !listenAddr;
          if (local && local.value === "YES") {
            if (!ssl || ssl.value === "NO") {
              if (fLogins && fLogins.value === "YES") {
                add("WARNING", fLogins.line, "force_local_logins_ssl=YES but ssl_enable is off — local logins will be refused",
                  "This file demands encrypted logins (force_local_logins_ssl=YES) while TLS itself is " + (ssl ? "switched off (ssl_enable=NO, line " + ssl.line + ")" : "never switched on") + ". vsftpd resolves that contradiction by refusing local logins altogether.",
                  "Set ssl_enable=YES and provide a certificate (rsa_cert_file), or set force_local_logins_ssl=NO if you accept plaintext logins.");
              } else {
                add("WARNING", ssl ? ssl.line : local.line, "Local logins are unencrypted — passwords cross the network in plaintext" + (allInterfaces ? " (escalated: listening on all interfaces)" : ""),
                  "local_enable=YES lets real user accounts log in, but ssl_enable is " + (ssl ? "NO" : "not set, which means NO") + ", so usernames and passwords travel across the network readable by anyone in a position to watch the traffic." + (allInterfaces ? " No listen_address is set either, so the server listens on every network interface it has — those plaintext credentials are exposed on all of them." : ""),
                  "Set ssl_enable=YES, point rsa_cert_file at a certificate, and set force_local_logins_ssl=YES so unencrypted logins are refused.");
              }
            } else {
              if (!fLogins || fLogins.value !== "YES") {
                add("WARNING", local.line, "TLS is available but not required — logins can still fall back to plaintext",
                  "ssl_enable=YES (line " + ssl.line + ") means the server can encrypt, but force_local_logins_ssl is " + (fLogins ? "NO" : "not set") + ", so any client that doesn't ask for TLS still logs in with its password in the clear.",
                  "Set force_local_logins_ssl=YES so every local login must be encrypted.");
              } else if (!fData || fData.value !== "YES") {
                add("INFO", fLogins.line, "Logins are forced to TLS, but file transfers are not",
                  "force_local_logins_ssl=YES protects passwords, while force_local_data_ssl is " + (fData ? "NO" : "not set") + " — the files themselves can still move across the network unencrypted.",
                  "Set force_local_data_ssl=YES if the contents of transfers need the same protection as the passwords.");
              }
            }
          } else if (local) {
            add("INFO", local.line, "Local logins are disabled",
              "local_enable=NO means real user accounts cannot log in over FTP at all; only anonymous or guest access (if enabled) would work.",
              null);
          } else {
            add("INFO", null, "local_enable is not set — vsftpd's default is NO",
              "With no local_enable line, real user accounts cannot log in over FTP; the default is NO.",
              null);
          }

          /* ---- Writable chroot ---- */
          var chroot = get("chroot_local_user");
          var awc = get("allow_writeable_chroot");
          var write = get("write_enable");
          if (chroot && chroot.value === "YES") {
            if (!awc || awc.value !== "YES") {
              add("WARNING", chroot.line, "Writable chroot risk: users are jailed in home folders vsftpd may refuse to enter",
                "In plain words: chroot_local_user=YES locks each user inside their own home folder. But vsftpd refuses to log a user in when that home folder is writable by the user — a writable jail root weakens the jail — unless allow_writeable_chroot=YES says you accept that. Here allow_writeable_chroot is " + (awc ? "NO (line " + awc.line + ")" : "not set, which means NO") + (write && write.value === "YES" ? ", and write_enable=YES (line " + write.line + ") means users are expected to write files" : "") + ". So the likely outcomes are users who suddenly cannot log in, or a rushed \"fix\" that loosens the wrong permission and quietly weakens the jail.",
                "Decide deliberately: make home folders non-writable by their owners (the safer route), or set allow_writeable_chroot=YES knowingly and keep everything below the home folder writable instead.");
            } else {
              add("INFO", chroot.line, "Writable chroot is explicitly allowed",
                "chroot_local_user=YES with allow_writeable_chroot=YES (line " + awc.line + ") means vsftpd will log users into home folders they can write to. That works, but the jail is only as strong as the permissions underneath it.",
                "Confirm each home folder holds nothing a logged-in user should not reach, and that no writable path inside it points outside the folder.");
            }
          }

          /* ---- Listener posture ---- */
          var lis = get("listen");
          var lis6 = get("listen_ipv6");
          if (lis && lis6 && lis.value === "YES" && lis6.value === "YES") {
            add("WARNING", lis6.line, "listen and listen_ipv6 are both YES — vsftpd generally refuses to run both from one config",
              "A single vsftpd instance listens either as an IPv4 standalone server (listen=YES) or an IPv6 one (listen_ipv6=YES). With both switched on, startup commonly fails or one listener silently wins.",
              "Keep the one you actually serve on and set the other to NO; run a second config instance if you truly need both families.");
          } else if (lis && lis6 && lis.value === "NO" && lis6.value === "NO") {
            add("WARNING", lis6.line, "No standalone listener is enabled",
              "listen=NO and listen_ipv6=NO means this config only works if something else (like xinetd) starts vsftpd per-connection. As a standalone daemon it would accept nothing.",
              "Set listen=YES (IPv4) or listen_ipv6=YES (IPv6) for a standalone server.");
          } else if (!lis && !lis6) {
            add("INFO", null, "Neither listen nor listen_ipv6 is set",
              "vsftpd's defaults apply: a standalone IPv4 listener (listen defaults to YES, listen_ipv6 to NO).",
              null);
          }
          var standalone = (lis && lis.value === "YES") || (lis6 && lis6.value === "YES") || (!lis && !lis6);
          if (standalone) {
            if (listenAddr) {
              add("INFO", listenAddr.line, "Listener is pinned to one address",
                "listen_address is set, so the standalone listener binds that address only instead of every interface.",
                null);
            } else {
              add("INFO", null, "No listen_address set — the listener binds every interface",
                "Without listen_address, the standalone listener accepts connections on all of the machine's network interfaces.",
                "Set listen_address to the one address the server should answer on, if it has interfaces that should not serve FTP.");
            }
          }

          /* ---- Passive port range arithmetic ---- */
          var pMin = get("pasv_min_port");
          var pMax = get("pasv_max_port");
          var pasv = get("pasv_enable");
          if (pMin && pMax) {
            var lo = parseInt(pMin.value, 10);
            var hi = parseInt(pMax.value, 10);
            if (lo > hi) {
              add("WARNING", pMax.line, "Passive port range is upside down: min is higher than max",
                "pasv_min_port=" + lo + " (line " + pMin.line + ") is greater than pasv_max_port=" + hi + ". There is no valid port in that range — " + hi + " − " + lo + " + 1 is negative — so passive-mode data connections have nowhere to land and transfers will fail.",
                "Swap them or set a sane range, e.g. pasv_min_port=60000 and pasv_max_port=60100, and open that same range in the firewall.");
            } else if (hi > 65535) {
              add("WARNING", pMax.line, "pasv_max_port is above the highest valid port",
                "Ports stop at 65535, but pasv_max_port=" + hi + ". The usable range is really " + lo + "–65535 (" + (65535 - lo + 1) + " ports).",
                "Set pasv_max_port to 65535 or lower.");
            } else {
              var span = hi - lo + 1;
              add("INFO", pMin.line, "Passive port range: " + lo + "–" + hi + " = " + span + " ports",
                "The arithmetic: " + hi + " − " + lo + " + 1 = " + span + " ports available for passive data connections" + (pasv && pasv.value === "NO" ? ". Note pasv_enable=NO (line " + pasv.line + "), so this range is currently unused." : "") + (span < 10 ? " That is a small pool — a handful of simultaneous transfers can exhaust it." : ""),
                "Make sure the firewall opens exactly this range (" + lo + "–" + hi + ") to the server, no more and no less.");
            }
          } else if (pMin || pMax) {
            var only = pMin || pMax;
            add("WARNING", only.line, "Only one end of the passive port range is set",
              (pMin ? "pasv_min_port" : "pasv_max_port") + " is set at line " + only.line + " but its partner is missing, so the effective range depends on a built-in default you have not chosen.",
              "Set both pasv_min_port and pasv_max_port, or remove both and let vsftpd pick ephemeral ports.");
          }

          /* ---- Userlist & guest posture ---- */
          var ul = get("userlist_enable");
          var ulDeny = get("userlist_deny");
          if (ul && ul.value === "YES") {
            if (ulDeny && ulDeny.value === "NO") {
              add("INFO", ul.line, "Userlist is in allow-list mode — the strictest posture",
                "userlist_enable=YES with userlist_deny=NO means ONLY the users named in the userlist file may log in; everyone else is refused before their password is even checked.",
                "Keep the userlist file owner-writable only, and review it whenever accounts change.");
            } else {
              add("INFO", ul.line, "Userlist is in deny-list mode",
                "userlist_enable=YES with userlist_deny " + (ulDeny ? "set to YES (line " + ulDeny.line + ")" : "unset, which defaults to YES") + " means users named in the userlist file are refused, and everyone else with a valid account may log in.",
                null);
            }
          } else {
            add("INFO", ul ? ul.line : null, "No userlist gate",
              "userlist_enable is " + (ul ? "NO" : "not set, which means NO") + ", so there is no list-based allow/deny gate in front of password checks; any local account may attempt an FTP login.",
              "Consider userlist_enable=YES with userlist_deny=NO and a short allow-list of the accounts that should have FTP access.");
          }
          var guest = get("guest_enable");
          var guestUser = get("guest_username");
          if (guest && guest.value === "YES") {
            add("WARNING", guest.line, "Guest logins are enabled",
              "guest_enable=YES treats authenticated non-local (guest) logins as real logins mapped onto " + (guestUser ? "the guest_username account set at line " + guestUser.line : "the guest account (default: ftp)") + ". Every guest shares that one account's view of the filesystem, so one weak guest password exposes the whole shared area.",
              "Set guest_enable=NO unless you deliberately run a guest-access service, and keep the guest account's permissions minimal.");
          } else if (guestUser) {
            add("INFO", guestUser.line, "guest_username is set but guest logins are off",
              "guest_enable is not YES, so the guest_username at line " + guestUser.line + " currently has no effect.",
              null);
          }

          /* ---- Timeouts ---- */
          var idle = get("idle_session_timeout");
          var dct = get("data_connection_timeout");
          if (!idle) {
            add("INFO", null, "idle_session_timeout is not set — vsftpd's default of 300 seconds applies",
              "Idle control connections are dropped after 300 seconds by default. That is a reasonable default; setting it explicitly makes the intent visible to the next person who reads this file.",
              "Add idle_session_timeout=600 (or your chosen value) to state the policy in the file.");
          }
          if (!dct) {
            add("INFO", null, "data_connection_timeout is not set — vsftpd's default of 300 seconds applies",
              "Stalled data connections time out after 300 seconds by default. Without an explicit line, a stalled transfer's behaviour depends on a default nobody chose for this server.",
              "Add data_connection_timeout=120 (or your chosen value) to state the policy in the file.");
          }

          var rank = { "BLOCKER": 0, "WARNING": 1, "INFO": 2, "NOT PARSED": 3 };
          findings.sort(function (a, b) {
            if (rank[a.sev] !== rank[b.sev]) return rank[a.sev] - rank[b.sev];
            return (a.line || 0) - (b.line || 0);
          });

          var counts = { "BLOCKER": 0, "WARNING": 0, "INFO": 0, "NOT PARSED": 0 };
          findings.forEach(function (f) { counts[f.sev]++; });

          var verdict = counts.BLOCKER > 0 ? "DO NOT DEPLOY"
            : (counts.WARNING > 0 || counts["NOT PARSED"] > 0) ? "DEPLOY WITH FIXES"
            : "SAFE TO DEPLOY";

          return { findings: findings, counts: counts, verdict: verdict };
        }

        function buildReport(result) {
          var out = [];
          out.push("J-Dawgs vsftpd Config Safety Auditor — audit report");
          out.push("Verdict: " + result.verdict);
          out.push("Counts: BLOCKER " + result.counts.BLOCKER + " · WARNING " + result.counts.WARNING + " · INFO " + result.counts.INFO + " · NOT PARSED " + result.counts["NOT PARSED"]);
          out.push("Heuristic text audit only — no server was contacted and no logins were tested.");
          out.push("Password-like values are never included in this report.");
          out.push("");
          if (!result.findings.length) {
            out.push("No findings.");
          }
          result.findings.forEach(function (f, i) {
            out.push((i + 1) + ". [" + f.sev + "]" + (f.line ? " Line " + f.line + " — " : " — ") + f.title);
            out.push("   " + f.body);
            if (f.fix) out.push("   Fix: " + f.fix);
          });
          return out.join("\n");
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-vsftpd-config-safety-auditor',
  name: 'J-Dawgs vsftpd Config Safety Auditor',
  description: 'Grades a pasted vsftpd.conf offline — anonymous access, writable chroot, plaintext-login/TLS posture, passive-port arithmetic — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
