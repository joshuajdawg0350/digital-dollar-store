'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Moving Service Estimate, Work Record & Final Invoice Consistency Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";
var $ = function(id){ return document.getElementById(id); };

var EXAMPLE_BAD_ESTIMATE = [
"ESTIMATE #E-881 — Johnson Move",
"Crew: 2 movers",
"Truck: 20 ft truck",
"Hourly rate: $120 per hour",
"Estimated hours: 4 hours",
"Estimated miles: 30 miles",
"Packing materials: 10 boxes at $4.00 each",
"Deposit paid: $200.00",
"No travel, stair, or elevator fees in this estimate."
].join("\n");

var EXAMPLE_BAD_WORK = [
"WORK RECORD / BILL OF LADING NOTES — Job #881",
"Crew on site: 2 movers",
"Truck used: 20 ft truck",
"Hours worked: 4 hours (9:00 AM - 1:00 PM)",
"Miles driven: 28 miles",
"Materials used: 10 boxes used",
"Deposit noted: $200 paid",
"Notes: Ground floor to elevator building, no stairs carried. No travel delay."
].join("\n");

var EXAMPLE_BAD_INVOICE = [
"FINAL INVOICE #I-881",
"Crew billed: 3 movers",
"Truck billed: 26 ft truck",
"Labor: 6 hours @ $120.00/hour = $720.00",
"Mileage: 85 miles @ $1.50/mile = $127.50",
"Packing materials: 25 boxes @ $4.00 = $100.00",
"Travel time fee: $95.00",
"Stair fee: $75.00",
"Subtotal: $1,117.50",
"Deposit credit: $0.00",
"Total due: $1,250.00"
].join("\n");

var EXAMPLE_CLEAN_ESTIMATE = [
"ESTIMATE #E-2041 — Alvarez Move",
"Crew: 2 movers",
"Truck: 20 ft truck",
"Hourly rate: $120 per hour",
"Estimated hours: 4 hours",
"Estimated miles: 30 miles",
"Packing materials: 10 boxes at $4.00 each",
"Deposit paid: $150.00"
].join("\n");

var EXAMPLE_CLEAN_WORK = [
"WORK RECORD — Job #2041",
"Crew on site: 2 movers",
"Truck used: 20 ft truck",
"Hours worked: 4 hours",
"Miles driven: 30 miles",
"Materials used: 10 boxes used",
"Deposit noted: $150 paid"
].join("\n");

var EXAMPLE_CLEAN_INVOICE = [
"FINAL INVOICE #I-2041",
"Crew billed: 2 movers",
"Truck billed: 20 ft truck",
"Labor: 4 hours @ $120.00/hour = $480.00",
"Mileage: 30 miles @ $1.50/mile = $45.00",
"Packing materials: 10 boxes @ $4.00 = $40.00",
"Subtotal: $565.00",
"Deposit credit: -$150.00",
"Total due: $415.00"
].join("\n");

function fmt(n){ return "$" + Math.abs(n).toLocaleString("en-US",{minimumFractionDigits:2, maximumFractionDigits:2}); }
function linesOf(text){ return (text || "").split(/\r?\n/); }
function moneyAll(line){
  var out = [], re = /-?\s*\$\s*([\d,]+\.?\d*)/g, m;
  while((m = re.exec(line)) !== null){
    var raw = m[0], neg = raw.indexOf("-") !== -1;
    var v = parseFloat(m[1].replace(/,/g,""));
    if(!isNaN(v)) out.push(neg ? -v : v);
  }
  return out;
}
function lastMoney(line){ var a = moneyAll(line); return a.length ? a[a.length-1] : null; }
function firstNumBefore(line, unitRe){
  var m = line.match(new RegExp("([\\d]+(?:\\.\\d+)?)\\s*" + unitRe, "i"));
  return m ? parseFloat(m[1]) : null;
}
function findLine(lines, test){
  for(var i=0;i<lines.length;i++){ if(test(lines[i].toLowerCase(), lines[i])) return {value:null, idx:i, text:lines[i]}; }
  return null;
}
function ref(docName, hit){ return hit ? {doc:docName, line:hit.idx+1, text:hit.text.trim()} : null; }

function extractCrew(lines){
  var hit = findLine(lines, function(l){ return l.indexOf("mover") !== -1 || l.indexOf("crew") !== -1; });
  if(!hit) return null;
  var v = firstNumBefore(hit.text, "movers?");
  if(v === null){ var m = hit.text.match(/(\d+)/); v = m ? parseInt(m[1],10) : null; }
  hit.value = v; return hit;
}
function extractTruck(lines){
  var hit = findLine(lines, function(l){ return l.indexOf("truck") !== -1 && l.indexOf("ft") !== -1; });
  if(!hit) return null;
  hit.value = firstNumBefore(hit.text, "ft");
  return hit;
}
function extractRate(allLineSets){
  for(var s=0;s<allLineSets.length;s++){
    var lines = allLineSets[s];
    for(var i=0;i<lines.length;i++){
      var l = lines[i].toLowerCase();
      if(l.indexOf("per hour") !== -1 || l.indexOf("/hour") !== -1 || l.indexOf("hourly rate") !== -1){
        var mon = moneyAll(lines[i]);
        if(mon.length) return {value:mon[0], idx:i, text:lines[i], set:s};
        var m = lines[i].match(/([\d.]+)/); if(m) return {value:parseFloat(m[1]), idx:i, text:lines[i], set:s};
      }
    }
  }
  return null;
}
function extractHoursWorked(lines){
  var hit = findLine(lines, function(l){ return l.indexOf("hours worked") !== -1 || l.indexOf("actual hours") !== -1 || l.indexOf("hours recorded") !== -1; });
  if(!hit) hit = findLine(lines, function(l){ return l.indexOf("hour") !== -1; });
  if(!hit) return null;
  hit.value = firstNumBefore(hit.text, "hours?");
  return hit;
}
function extractLaborBilled(lines){
  var hit = findLine(lines, function(l){ return l.indexOf("labor") !== -1 || l.indexOf("hours billed") !== -1 || l.indexOf("billed hours") !== -1; });
  if(!hit) return null;
  var hours = firstNumBefore(hit.text, "hours?");
  var mon = moneyAll(hit.text);
  var rate = null;
  var rm = hit.text.match(/\$\s*([\d.]+)\s*\/\s*hour/i) || hit.text.match(/@\s*\$\s*([\d.]+)/i);
  if(rm) rate = parseFloat(rm[1]);
  hit.value = hours; hit.amount = mon.length ? mon[mon.length-1] : null; hit.rate = rate;
  return hit;
}
function extractMilesRecorded(lines){
  var hit = findLine(lines, function(l){ return l.indexOf("miles driven") !== -1 || l.indexOf("miles recorded") !== -1 || l.indexOf("miles traveled") !== -1 || l.indexOf("actual miles") !== -1; });
  if(!hit) hit = findLine(lines, function(l){ return l.indexOf("miles") !== -1 && l.indexOf("estimated") === -1; });
  if(!hit) return null;
  hit.value = firstNumBefore(hit.text, "miles?");
  return hit;
}
function extractMileageBilled(lines){
  var hit = findLine(lines, function(l){ return l.indexOf("mileage") !== -1 || (l.indexOf("miles") !== -1 && l.indexOf("$") !== -1 && l.indexOf("estimated") === -1); });
  if(!hit) return null;
  var miles = firstNumBefore(hit.text, "miles?");
  var mon = moneyAll(hit.text);
  var rate = null;
  var rm = hit.text.match(/\$\s*([\d.]+)\s*\/\s*mile/i);
  if(rm) rate = parseFloat(rm[1]);
  hit.value = miles; hit.amount = mon.length ? mon[mon.length-1] : null; hit.rate = rate;
  return hit;
}
function extractBoxes(lines, usedSide){
  var hit = null;
  if(usedSide){
    hit = findLine(lines, function(l){ return l.indexOf("box") !== -1 && (l.indexOf("used") !== -1 || l.indexOf("materials used") !== -1); });
    if(!hit) hit = findLine(lines, function(l){ return l.indexOf("box") !== -1; });
  } else {
    hit = findLine(lines, function(l){ return l.indexOf("box") !== -1; });
  }
  if(!hit) return null;
  var n = firstNumBefore(hit.text, "boxes");
  if(n === null) n = firstNumBefore(hit.text, "box");
  var mon = moneyAll(hit.text);
  var unit = null;
  var um = hit.text.match(/@\s*\$\s*([\d.]+)/i) || hit.text.match(/\$\s*([\d.]+)\s*each/i);
  if(um) unit = parseFloat(um[1]);
  hit.value = n; hit.amount = mon.length ? mon[mon.length-1] : null; hit.unit = unit;
  return hit;
}
function extractDepositPaid(estLines, workLines){
  var sets = [["Estimate", estLines], ["Work Record", workLines]];
  for(var s=0;s<sets.length;s++){
    var lines = sets[s][1];
    for(var i=0;i<lines.length;i++){
      if(lines[i].toLowerCase().indexOf("deposit") !== -1){
        var mon = moneyAll(lines[i]);
        if(mon.length) return {value:Math.abs(mon[0]), idx:i, text:lines[i], doc:sets[s][0]};
      }
    }
  }
  return null;
}
function extractDepositCredit(invLines){
  for(var i=0;i<invLines.length;i++){
    if(invLines[i].toLowerCase().indexOf("deposit") !== -1){
      var mon = moneyAll(invLines[i]);
      return {value: mon.length ? Math.abs(mon[0]) : 0, idx:i, text:invLines[i], found:true};
    }
  }
  return {value:0, idx:-1, text:"", found:false};
}

function audit(estText, workText, invText){
  var estLines = linesOf(estText), workLines = linesOf(workText), invLines = linesOf(invText);
  var findings = [];
  var compare = [];

  var crewE = extractCrew(estLines), crewW = extractCrew(workLines), crewI = extractCrew(invLines);
  var truckE = extractTruck(estLines), truckW = extractTruck(workLines), truckI = extractTruck(invLines);
  var rateHit = extractRate([estLines, invLines, workLines]);
  var rate = rateHit ? rateHit.value : null;
  var hoursW = extractHoursWorked(workLines);
  var laborI = extractLaborBilled(invLines);
  var milesW = extractMilesRecorded(workLines);
  var milesI = extractMileageBilled(invLines);
  var boxesW = extractBoxes(workLines, true);
  var boxesI = extractBoxes(invLines, false);
  var boxesE = extractBoxes(estLines, false);
  var depPaid = extractDepositPaid(estLines, workLines);
  var depCredit = extractDepositCredit(invLines);

  function pushCompare(item, e, w, i, agree){
    compare.push({item:item, estimate:e, work:w, invoice:i, agree:agree});
  }
  function disp(hit, suffix){ return (hit && hit.value !== null && hit.value !== undefined) ? (hit.value + (suffix||"")) : "—"; }

  /* 1 — Crew */
  var crewAgree = "—";
  if(crewW && crewI && crewW.value !== null && crewI.value !== null){
    if(crewI.value !== crewW.value){
      crewAgree = "NO";
      findings.push({id:"crew-size", severity:"high", title:"Crew size billed does not match crew recorded",
        detail:"The invoice bills a larger crew than the work record shows on site.",
        arithmetic:"Work record crew: " + crewW.value + " movers\nInvoice crew billed: " + crewI.value + " movers\nDifference: " + (crewI.value - crewW.value) + " extra mover(s) billed with no record of them on the job.",
        refs:[ref("Work Record", crewW), ref("Invoice", crewI), crewE ? ref("Estimate", crewE) : null].filter(Boolean), overcharge:0});
    } else crewAgree = "Yes";
  }
  pushCompare("Crew size", disp(crewE," movers"), disp(crewW," movers"), disp(crewI," movers"), crewAgree);

  /* 2 — Truck */
  var truckAgree = "—";
  if(truckW && truckI && truckW.value !== null && truckI.value !== null){
    if(truckI.value !== truckW.value){
      truckAgree = "NO";
      findings.push({id:"truck-size", severity:"high", title:"Truck size billed does not match truck recorded",
        detail:"The invoice bills a different (larger) truck than the work record shows was used.",
        arithmetic:"Work record truck: " + truckW.value + " ft\nInvoice truck billed: " + truckI.value + " ft\nDifference: " + (truckI.value - truckW.value) + " ft larger truck billed than recorded.",
        refs:[ref("Work Record", truckW), ref("Invoice", truckI), truckE ? ref("Estimate", truckE) : null].filter(Boolean), overcharge:0});
    } else truckAgree = "Yes";
  }
  pushCompare("Truck size", disp(truckE," ft"), disp(truckW," ft"), disp(truckI," ft"), truckAgree);

  /* 3 — Hours × rate */
  var hoursAgree = "—";
  if(hoursW && laborI && hoursW.value !== null && laborI.value !== null){
    var effRate = (laborI.rate !== null && laborI.rate !== undefined) ? laborI.rate : rate;
    if(laborI.value > hoursW.value){
      hoursAgree = "NO";
      var extraH = laborI.value - hoursW.value;
      var overH = effRate ? extraH * effRate : null;
      var arithH = "Hours recorded (work record): " + hoursW.value + "\nHours billed (invoice): " + laborI.value + "\nExtra hours: " + laborI.value + " − " + hoursW.value + " = " + extraH;
      if(effRate) arithH += "\nHourly rate: " + fmt(effRate) + "\nOvercharge: " + extraH + " × " + fmt(effRate) + " = " + fmt(overH) + "\nCorrect labor: " + hoursW.value + " × " + fmt(effRate) + " = " + fmt(hoursW.value * effRate) + (laborI.amount !== null ? " (invoice charges " + fmt(laborI.amount) + ")" : "");
      findings.push({id:"hours-over", severity:"high", title:"Hours billed above hours recorded",
        detail:"The invoice bills more labor hours than the work record shows were worked.",
        arithmetic:arithH, refs:[ref("Work Record", hoursW), ref("Invoice", laborI)].filter(Boolean), overcharge: overH || 0});
    } else if(laborI.value === hoursW.value){ hoursAgree = "Yes"; }
    else { hoursAgree = "Billed less"; }
  }
  pushCompare("Labor hours", "—", disp(hoursW," hrs"), disp(laborI," hrs"), hoursAgree);

  /* 4 — Mileage */
  var milesAgree = "—";
  if(milesW && milesI && milesW.value !== null && milesI.value !== null){
    if(milesI.value > milesW.value){
      milesAgree = "NO";
      var extraM = milesI.value - milesW.value;
      var mRate = milesI.rate;
      var overM = mRate ? extraM * mRate : null;
      var arithM = "Miles recorded (work record): " + milesW.value + "\nMiles billed (invoice): " + milesI.value + "\nExtra miles: " + milesI.value + " − " + milesW.value + " = " + extraM;
      if(mRate) arithM += "\nPer-mile rate: " + fmt(mRate) + "\nOvercharge: " + extraM + " × " + fmt(mRate) + " = " + fmt(overM) + "\nCorrect mileage: " + milesW.value + " × " + fmt(mRate) + " = " + fmt(milesW.value * mRate) + (milesI.amount !== null ? " (invoice charges " + fmt(milesI.amount) + ")" : "");
      findings.push({id:"mileage-over", severity:"high", title:"Mileage billed above miles recorded",
        detail:"The invoice bills more miles than the work record shows were driven.",
        arithmetic:arithM, refs:[ref("Work Record", milesW), ref("Invoice", milesI)].filter(Boolean), overcharge: overM || 0});
    } else if(milesI.value === milesW.value){ milesAgree = "Yes"; }
    else { milesAgree = "Billed less"; }
  }
  pushCompare("Miles", "—", disp(milesW," mi"), disp(milesI," mi"), milesAgree);

  /* 5 — Materials */
  var boxesAgree = "—";
  if(boxesW && boxesI && boxesW.value !== null && boxesI.value !== null){
    if(boxesI.value > boxesW.value){
      boxesAgree = "NO";
      var extraB = boxesI.value - boxesW.value;
      var unit = boxesI.unit || (boxesE && boxesE.unit) || null;
      var overB = unit ? extraB * unit : null;
      var arithB = "Boxes recorded as used (work record): " + boxesW.value + "\nBoxes billed (invoice): " + boxesI.value + "\nExtra boxes: " + boxesI.value + " − " + boxesW.value + " = " + extraB;
      if(unit) arithB += "\nPrice per box: " + fmt(unit) + "\nOvercharge: " + extraB + " × " + fmt(unit) + " = " + fmt(overB) + "\nCorrect materials: " + boxesW.value + " × " + fmt(unit) + " = " + fmt(boxesW.value * unit) + (boxesI.amount !== null ? " (invoice charges " + fmt(boxesI.amount) + ")" : "");
      findings.push({id:"materials-over", severity:"high", title:"Packing materials billed but not recorded as used",
        detail:"The invoice bills more packing boxes than the work record shows were used.",
        arithmetic:arithB, refs:[ref("Work Record", boxesW), ref("Invoice", boxesI)].filter(Boolean), overcharge: overB || 0});
    } else if(boxesI.value === boxesW.value){ boxesAgree = "Yes"; }
    else { boxesAgree = "Billed less"; }
  }
  pushCompare("Boxes", disp(boxesE,""), disp(boxesW,""), disp(boxesI,""), boxesAgree);

  /* 6 — Deposit */
  var depAgree = "—";
  if(depPaid && depPaid.value > 0){
    if(!depCredit.found || depCredit.value < depPaid.value){
      depAgree = "NO";
      var missing = depPaid.value - (depCredit.found ? depCredit.value : 0);
      var refsD = [{doc:depPaid.doc, line:depPaid.idx+1, text:depPaid.text.trim()}];
      if(depCredit.found) refsD.push({doc:"Invoice", line:depCredit.idx+1, text:depCredit.text.trim()});
      findings.push({id:"deposit-not-credited", severity:"high", title:"Deposit paid but not credited on the invoice",
        detail: depCredit.found ? "The invoice credits less deposit than was paid." : "The invoice contains no deposit credit line at all, even though a deposit was paid.",
        arithmetic:"Deposit paid: " + fmt(depPaid.value) + "\nDeposit credited on invoice: " + fmt(depCredit.found ? depCredit.value : 0) + "\nMissing credit: " + fmt(depPaid.value) + " − " + fmt(depCredit.found ? depCredit.value : 0) + " = " + fmt(missing),
        refs:refsD, overcharge:missing});
    } else depAgree = "Yes";
  }
  pushCompare("Deposit", depPaid ? fmt(depPaid.value) : "—", "—", depCredit.found ? fmt(depCredit.value) + " credited" : "No credit line", depAgree);

  /* 7 — Invoice-only fees */
  var feeDefs = [
    {key:"travel", label:"Travel time fee", test:function(l){ return l.indexOf("travel") !== -1; }},
    {key:"stair", label:"Stair fee", test:function(l){ return l.indexOf("stair") !== -1; }},
    {key:"elevator", label:"Elevator fee", test:function(l){ return l.indexOf("elevator") !== -1 && l.indexOf("fee") !== -1; }},
    {key:"fuel", label:"Fuel surcharge", test:function(l){ return l.indexOf("fuel") !== -1; }},
    {key:"long carry", label:"Long carry fee", test:function(l){ return l.indexOf("long carry") !== -1; }}
  ];
  var feeAgree = "Yes";
  feeDefs.forEach(function(fd){
    var invHit = null;
    for(var i=0;i<invLines.length;i++){ if(fd.test(invLines[i].toLowerCase()) && moneyAll(invLines[i]).length){ invHit = {idx:i, text:invLines[i]}; break; } }
    if(!invHit) return;
    var inEst = false;
    for(var j=0;j<estLines.length;j++){ if(fd.test(estLines[j].toLowerCase()) && moneyAll(estLines[j]).length){ inEst = true; break; } }
    if(inEst) return;
    feeAgree = "NO";
    var amt = lastMoney(invHit.text);
    findings.push({id:"invoice-only-fee-" + fd.key, severity:"medium", title:fd.label + " appears only on the invoice",
      detail:"This fee is charged on the final invoice but appears nowhere in the estimate — no priced " + fd.label.toLowerCase() + " was quoted.",
      arithmetic:"Charged on invoice: " + (amt !== null ? fmt(amt) : "amount not readable") + "\nCharged in estimate: $0.00 (no priced line found)\nUnquoted fee to dispute: " + (amt !== null ? fmt(amt) : "—"),
      refs:[{doc:"Invoice", line:invHit.idx+1, text:invHit.text.trim()}], overcharge: amt || 0});
  });
  pushCompare("Invoice-only fees", "—", "—", feeAgree === "NO" ? "Present" : "None", feeAgree);

  /* 8 — Totals */
  var totalAgree = "—";
  var chargeSum = 0, chargeRefs = [], subtotalHit = null, totalHit = null;
  for(var t=0;t<invLines.length;t++){
    var lt = invLines[t].toLowerCase();
    var monT = moneyAll(invLines[t]);
    if(!monT.length) continue;
    if(lt.indexOf("subtotal") !== -1){ subtotalHit = {idx:t, text:invLines[t], value:lastMoney(invLines[t])}; continue; }
    if(lt.indexOf("deposit") !== -1){ continue; }
    if(lt.indexOf("total due") !== -1 || lt.indexOf("balance due") !== -1 || (lt.indexOf("total") !== -1 && lt.indexOf("subtotal") === -1)){ totalHit = {idx:t, text:invLines[t], value:lastMoney(invLines[t])}; continue; }
    if(lt.indexOf("rate") !== -1 && lt.indexOf("=") === -1){ continue; }
    chargeSum += monT[monT.length-1];
    chargeRefs.push({doc:"Invoice", line:t+1, text:invLines[t].trim()});
  }
  var baseForTotal = subtotalHit ? subtotalHit.value : (chargeRefs.length ? chargeSum : null);
  if(subtotalHit && chargeRefs.length && Math.abs(chargeSum - subtotalHit.value) > 0.51){
    totalAgree = "NO";
    var dSub = subtotalHit.value - chargeSum;
    findings.push({id:"subtotal-mismatch", severity:"high", title:"Invoice line items do not add up to the subtotal",
      detail:"Re-adding the invoice's own charge lines gives a different subtotal than the one printed.",
      arithmetic:"Sum of invoice charge lines: " + fmt(chargeSum) + "\nPrinted subtotal: " + fmt(subtotalHit.value) + "\nDifference: " + fmt(subtotalHit.value) + " − " + fmt(chargeSum) + " = " + fmt(dSub),
      refs:chargeRefs.concat([{doc:"Invoice", line:subtotalHit.idx+1, text:subtotalHit.text.trim()}]), overcharge: dSub > 0 ? dSub : 0});
  }
  if(totalHit && baseForTotal !== null){
    var expectedTotal = baseForTotal - (depCredit.found ? depCredit.value : 0);
    if(Math.abs(totalHit.value - expectedTotal) > 0.51){
      totalAgree = "NO";
      var dTot = totalHit.value - expectedTotal;
      findings.push({id:"total-mismatch", severity:"high", title:"Invoice total does not add up",
        detail:"The printed total due does not equal the subtotal minus the deposit credit shown on the same invoice.",
        arithmetic:"Subtotal: " + fmt(baseForTotal) + "\nMinus deposit credit: − " + fmt(depCredit.found ? depCredit.value : 0) + "\nExpected total due: " + fmt(baseForTotal) + " − " + fmt(depCredit.found ? depCredit.value : 0) + " = " + fmt(expectedTotal) + "\nPrinted total due: " + fmt(totalHit.value) + "\nDifference: " + fmt(totalHit.value) + " − " + fmt(expectedTotal) + " = " + fmt(dTot),
        refs:[{doc:"Invoice", line:totalHit.idx+1, text:totalHit.text.trim()}].concat(subtotalHit ? [{doc:"Invoice", line:subtotalHit.idx+1, text:subtotalHit.text.trim()}] : []), overcharge: dTot > 0 ? dTot : 0});
    } else if(totalAgree === "—") totalAgree = "Yes";
  }
  if(totalAgree === "—" && chargeRefs.length) totalAgree = "Yes";
  pushCompare("Invoice totals", "—", "—", totalHit ? fmt(totalHit.value) + " due" : "—", totalAgree);

  var totalOver = findings.reduce(function(s,f){ return s + (f.overcharge || 0); }, 0);
  var verdict, verdictClass, why;
  if(findings.length === 0){
    verdict = "SAFE TO PAY"; verdictClass = "safe";
    why = "All eight cross-checks agree across the estimate, the work record, and the final invoice. No overcharge was found in the pasted text.";
  } else if(findings.length >= 4 || totalOver >= 150 || findings.some(function(f){ return f.id === "deposit-not-credited"; })){
    verdict = "DO NOT PAY YET"; verdictClass = "donot";
    why = findings.length + " mismatch" + (findings.length === 1 ? "" : "es") + " found, with " + fmt(totalOver) + " in documented overcharges and unquoted fees. Send the report below to the mover and get a corrected invoice before paying.";
  } else {
    verdict = "PAY WITH FIXES"; verdictClass = "fixes";
    why = findings.length + " mismatch" + (findings.length === 1 ? "" : "es") + " found (" + fmt(totalOver) + " documented). Ask for those specific lines to be corrected, then pay the corrected total.";
  }

  return {findings:findings, compare:compare, verdict:verdict, verdictClass:verdictClass, why:why,
    totalOver:totalOver, lineCounts:{estimate:estLines.length, work:workLines.length, invoice:invLines.length},
    totalLines: estLines.length + workLines.length + invLines.length, checksRun:8};
}

function buildReport(r){
  var L = [];
  L.push("MOVING SERVICE CONSISTENCY AUDIT — REPORT");
  L.push("Tool: J-Dawgs Moving Service Estimate, Work Record & Final Invoice Consistency Auditor\u2122");
  L.push("Method: Text cross-check of three pasted documents only. This report does not verify weights, distances, or a live booking.");
  L.push("");
  L.push("VERDICT: " + r.verdict);
  L.push(r.why);
  L.push("Findings: " + r.findings.length + " | Documented overcharge found: " + fmt(r.totalOver) + " | Lines compared: " + r.totalLines + " (Estimate " + r.lineCounts.estimate + ", Work Record " + r.lineCounts.work + ", Invoice " + r.lineCounts.invoice + ")");
  L.push("");
  if(!r.findings.length){
    L.push("No mismatches found. Crew, truck, hours, miles, materials, deposit, fees, and totals agree across all three documents.");
  } else {
    r.findings.forEach(function(f, i){
      L.push("FINDING " + (i+1) + " — " + f.title + (f.overcharge ? " (" + fmt(f.overcharge) + ")" : ""));
      L.push(f.detail);
      L.push("Arithmetic:");
      f.arithmetic.split("\n").forEach(function(a){ L.push("  " + a); });
      L.push("Source lines:");
      f.refs.forEach(function(rf){ L.push("  [" + rf.doc + " L" + rf.line + "] " + rf.text); });
      L.push("");
    });
  }
  L.push("SIDE-BY-SIDE SUMMARY");
  r.compare.forEach(function(c){ L.push("- " + c.item + ": Estimate " + c.estimate + " | Work Record " + c.work + " | Invoice " + c.invoice + " | Agrees: " + c.agree); });
  return L.join("\n");
}

var lastResult = null, lastJson = "";
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_BAD_ESTIMATE": (typeof EXAMPLE_BAD_ESTIMATE !== 'undefined' ? EXAMPLE_BAD_ESTIMATE : undefined), "EXAMPLE_BAD_WORK": (typeof EXAMPLE_BAD_WORK !== 'undefined' ? EXAMPLE_BAD_WORK : undefined), "EXAMPLE_BAD_INVOICE": (typeof EXAMPLE_BAD_INVOICE !== 'undefined' ? EXAMPLE_BAD_INVOICE : undefined), "EXAMPLE_CLEAN_ESTIMATE": (typeof EXAMPLE_CLEAN_ESTIMATE !== 'undefined' ? EXAMPLE_CLEAN_ESTIMATE : undefined), "EXAMPLE_CLEAN_WORK": (typeof EXAMPLE_CLEAN_WORK !== 'undefined' ? EXAMPLE_CLEAN_WORK : undefined), "EXAMPLE_CLEAN_INVOICE": (typeof EXAMPLE_CLEAN_INVOICE !== 'undefined' ? EXAMPLE_CLEAN_INVOICE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-moving-service-estimate-work-record-final-invoice-consistency-auditortm',
  name: 'J-Dawgs Moving Service Estimate, Work Record & Final Invoice Consistency Auditor',
  description: 'Cross-checks a moving service estimate against the work record and the final invoice, with arithmetic shown across all pastes — into one pay verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_BAD_ESTIMATE": __core["EXAMPLE_BAD_ESTIMATE"], "EXAMPLE_BAD_WORK": __core["EXAMPLE_BAD_WORK"], "EXAMPLE_BAD_INVOICE": __core["EXAMPLE_BAD_INVOICE"], "EXAMPLE_CLEAN_ESTIMATE": __core["EXAMPLE_CLEAN_ESTIMATE"], "EXAMPLE_CLEAN_WORK": __core["EXAMPLE_CLEAN_WORK"], "EXAMPLE_CLEAN_INVOICE": __core["EXAMPLE_CLEAN_INVOICE"] }
};
