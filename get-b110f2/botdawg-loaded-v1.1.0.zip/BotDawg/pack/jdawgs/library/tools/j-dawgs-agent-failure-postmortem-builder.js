'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Agent Failure Postmortem Builder".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the analyze function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

  "use strict";

  var $ = function (id) { return document.getElementById(id); };
  var transcriptEl = $("transcript"), intendedEl = $("intended"), actualEl = $("actual");
  var outputEl = $("output"), actionsEl = $("outputActions"), plainEl = $("plainText");
  var formMsg = $("formMsg"), copyStatus = $("copyStatus");
  var currentPlain = "";

  /* ================= samples ================= */

  var FAILED_SAMPLE = [
    "[00:00] TASK START: Post invoice #4471 to the billing API, then verify the charge, then report back.",
    "[00:01] CALL billing.post_invoice { invoice_id: 4471, amount: 129.00 }",
    "[00:02] RESULT: 403 Forbidden \u2014 API key lacks billing:write scope",
    "[00:03] RETRY CALL billing.post_invoice { invoice_id: 4471, amount: 129.00 }",
    "[00:04] RESULT: 403 Forbidden \u2014 API key lacks billing:write scope",
    "[00:05] RETRY CALL billing.post_invoice { invoice_id: 4471, amount: 129.00 }",
    "[00:06] RESULT: 403 Forbidden \u2014 API key lacks billing:write scope",
    "[00:07] RETRY CALL billing.post_invoice { invoice_id: 4471, amount: 129.00 }",
    "[00:08] RESULT: 403 Forbidden \u2014 API key lacks billing:write scope",
    "[00:09] NOTE: Error noted. Continuing with the remaining steps.",
    "[00:10] CALL notify.send { channel: \"ops\", message: \"Invoice posted\" }",
    "[00:11] RESULT: delivered",
    "[00:12] FINAL: Task completed successfully. Invoice #4471 posted and reported."
  ].join("\n");

  var CLEAN_SAMPLE = [
    "[00:00] TASK START: Summarize the weekly metrics file and post the summary to the team channel.",
    "[00:01] CALL files.read { path: \"metrics-week42.csv\" }",
    "[00:02] RESULT: 84 rows loaded",
    "[00:03] CALL summarize.run { rows: 84 }",
    "[00:04] RESULT: summary generated (5 bullet points)",
    "[00:05] CALL chat.post { channel: \"team\", message: \"Weekly metrics summary\" }",
    "[00:06] RESULT: posted, message id 9917",
    "[00:07] FINAL: Task completed successfully. Summary posted to the team channel."
  ].join("\n");

  $("loadFailed").addEventListener("click", function () {
    transcriptEl.value = FAILED_SAMPLE;
    intendedEl.value = "Post invoice #4471 to the billing API, verify the charge, then report back.";
    actualEl.value = "The invoice was never posted \u2014 every attempt got a 403 \u2014 but the run reported success anyway, and the verification step never ran.";
    formMsg.textContent = "";
    build();
  });
  $("loadClean").addEventListener("click", function () {
    transcriptEl.value = CLEAN_SAMPLE;
    intendedEl.value = "Summarize the weekly metrics file and post the summary to the team channel.";
    actualEl.value = "The summary was generated and posted; the run completed as intended.";
    formMsg.textContent = "";
    build();
  });
  $("clearAll").addEventListener("click", function () {
    transcriptEl.value = ""; intendedEl.value = ""; actualEl.value = "";
    formMsg.textContent = ""; copyStatus.textContent = ""; currentPlain = "";
    actionsEl.hidden = true;
    outputEl.innerHTML = '<div class="empty"><p style="margin:0;"><strong>Cleared.</strong> Paste a transcript and press <strong>Build postmortem</strong>.</p></div>';
  });

  /* ================= analysis helpers ================= */

  var ERROR_RE = /(\berror\b|\bexception\b|traceback|\bfailed\b|\bfailure\b|\bfatal\b|denied|forbidden|unauthorized|\b[45]\d\d\b|timed?\s?out|crash(ed)?\b|aborted|rejected)/i;
  var SUCCESS_RE = /(completed successfully|task complete|completed\.|done\.|success(fully)?\b|all steps (complete|done)|finished)/i;
  var HALT_RE = /(halt|stopping|stopped|abort|giving up|gave up|cannot continue|unable to continue|run (failed|terminated)|exiting)/i;
  var CALL_RE = /(^\s*(call|tool|action|step|invoke|request)\b|\bCALL\b|\btool_call\b|->)/i;

  function splitLines(text) {
    return text.split(/\r?\n/).map(function (l, i) {
      return { n: i + 1, raw: l, text: l.trim() };
    }).filter(function (l) { return l.text.length > 0; });
  }

  // Normalize a line for repeat detection: strip timestamps / line prefixes,
  // lowercase, collapse whitespace, strip trailing punctuation noise.
  function normalize(line) {
    var s = line.text.toLowerCase();
    s = s.replace(/^\[?[\d:. -]+\]?\s*[:\-]?\s*/, "");       // [00:03] style prefixes
    s = s.replace(/^(line|step)\s+\d+\s*[:.)-]?\s*/, "");
    s = s.replace(/retry\s+/g, "");
    s = s.replace(/\s+/g, " ").trim();
    return s;
  }
  // Looser signature: also blank out digits/ids so near-identical lines group.
  function signature(line) {
    return normalize(line).replace(/\d+/g, "#").replace(/#+/g, "#");
  }

  function findRepeats(lines) {
    function group(keyFn, minLen) {
      var map = {}, order = [];
      lines.forEach(function (l) {
        var k = keyFn(l);
        if (k.length < minLen) return;
        if (!map[k]) { map[k] = { key: k, lines: [] }; order.push(map[k]); }
        map[k].lines.push(l);
      });
      return order.filter(function (g) { return g.lines.length >= 2; })
                  .sort(function (a, b) { return b.lines.length - a.lines.length; });
    }
    var exact = group(normalize, 12);
    var near = group(signature, 12);
    // Merge: a near group that fully contains an exact group of same size is the same run.
    var usedNear = {};
    exact.forEach(function (g) { g.kind = "exact"; });
    near.forEach(function (g, i) {
      var dup = exact.some(function (e) {
        return e.lines.length === g.lines.length && e.lines[0].n === g.lines[0].n;
      });
      if (!dup) { g.kind = "near"; usedNear[i] = g; }
    });
    var out = exact.slice();
    Object.keys(usedNear).forEach(function (i) { out.push(usedNear[i]); });
    return out.sort(function (a, b) { return b.lines.length - a.lines.length; });
  }

  function quote(l) { return { n: l.n, text: l.text }; }

  /* ================= category detectors =================
     Each returns null or { id, name, confidence, why, evidence:[quotes] } */

  function detectRetryLoop(lines, repeats) {
    var best = null;
    repeats.forEach(function (g) {
      var isCall = g.lines.some(function (l) { return CALL_RE.test(l.text) || /\{.*\}/.test(l.text); });
      if (!isCall) return;
      if (!best || g.lines.length > best.lines.length) best = g;
    });
    if (!best) return null;
    var count = best.lines.length;
    return {
      id: "retry-loop", name: "Retry loop",
      confidence: count >= 3 ? "STRONG" : "POSSIBLE",
      why: "The same step appears " + count + " times" +
           (best.kind === "exact" ? " with identical text (unchanged inputs)." : " in near-identical form (same shape, minor value changes only).") +
           " Repeating a failing call without changing anything between attempts is the classic loop signature.",
      evidence: [quote(best.lines[0]), quote(best.lines[best.lines.length - 1])],
      group: best
    };
  }

  function detectIgnoredError(lines, errorIdx) {
    if (!errorIdx.length) return null;
    var firstErr = lines[errorIdx[0]];
    var lastErr = lines[errorIdx[errorIdx.length - 1]];

    // (1) Explicit "continuing anyway" language after the LAST error: the run
    //     acknowledged failure was final and moved on regardless.
    for (var j = errorIdx[errorIdx.length - 1] + 1; j < lines.length; j++) {
      if (/(continu|proceed|moving on|carry on|regardless)/i.test(lines[j].text) && !HALT_RE.test(lines[j].text)) {
        return {
          id: "ignored-error", name: "Ignored tool error",
          confidence: "STRONG",
          why: "After the final error at line " + lastErr.n + ", the run states it is continuing anyway \u2014 the failed step is never resolved, yet the run proceeds as though it had succeeded.",
          evidence: [quote(lastErr), quote(lines[j])]
        };
      }
    }
    // (2) An error immediately followed by further steps, with no halt between.
    for (var k = 0; k < errorIdx.length; k++) {
      var i = errorIdx[k];
      var after = lines.slice(i + 1, i + 5);
      if (after.some(function (l) { return HALT_RE.test(l.text); })) continue;
      var nextCall = after.find(function (l) { return CALL_RE.test(l.text); });
      if (nextCall) {
        return {
          id: "ignored-error", name: "Ignored tool error",
          confidence: "POSSIBLE",
          why: "An error appears at line " + lines[i].n + ", and instead of halting, the run carries on with later steps as though the failed step had succeeded.",
          evidence: [quote(lines[i]), quote(nextCall)]
        };
      }
    }
    // (3) Error present and the run still ends in a success claim.
    var last = lines[lines.length - 1];
    if (last && SUCCESS_RE.test(last.text)) {
      return {
        id: "ignored-error", name: "Ignored tool error",
        confidence: "POSSIBLE",
        why: "The transcript contains an error at line " + firstErr.n + " yet the run still closes with a success claim, with no halt or recovery step in between.",
        evidence: [quote(firstErr), quote(last)]
      };
    }
    return null;
  }

  function detectSilentPartial(lines, errorIdx) {
    var successLines = lines.filter(function (l) { return SUCCESS_RE.test(l.text); });
    if (!successLines.length) return null;
    var success = successLines[successLines.length - 1];

    // (a) A step named in the opening plan never appears again as executed.
    var planLine = lines.find(function (l) { return /(task start|plan|goal|steps?:)/i.test(l.text); });
    var missing = null;
    if (planLine) {
      var verbs = ["verif", "confirm", "check", "validat", "upload", "send", "post", "save", "notify", "report", "pay", "deploy"];
      for (var v = 0; v < verbs.length; v++) {
        var word = verbs[v];
        if (planLine.text.toLowerCase().indexOf(word) === -1) continue;
        var later = lines.slice(1).filter(function (l) {
          return l.text.toLowerCase().indexOf(word) !== -1 && l.n !== success.n;
        });
        var executed = later.some(function (l) { return CALL_RE.test(l.text) || /result|done|delivered|posted|saved|sent|verified|confirmed/i.test(l.text); });
        if (!executed && errorIdx.length) { missing = { word: word, plan: planLine }; break; }
      }
    }
    if (missing) {
      return {
        id: "silent-partial", name: "Silent partial success",
        confidence: "STRONG",
        why: "The run reports success, but a step named in its own plan \u2014 the one involving \u201C" + missing.word + "\u2026\u201D \u2014 never appears as executed anywhere after the plan line, and the transcript contains errors the success claim does not mention.",
        evidence: [quote(missing.plan), quote(success)]
      };
    }
    // (b) Explicit "never ran / skipped" phrasing.
    var skipLine = lines.find(function (l) {
      return /(never (ran|executed|completed)|not (run|executed|completed)|was skipped|skipped step|did not (run|complete|verify))/i.test(l.text);
    });
    if (skipLine) {
      return {
        id: "silent-partial", name: "Silent partial success",
        confidence: "STRONG",
        why: "The transcript itself notes a step that never completed, yet the run still reports overall success.",
        evidence: [quote(skipLine), quote(success)]
      };
    }
    // (c) Success claim coexisting with errors.
    if (errorIdx.length) {
      return {
        id: "silent-partial", name: "Silent partial success",
        confidence: "POSSIBLE",
        why: "The run claims success while the transcript also contains " + errorIdx.length + " error line" + (errorIdx.length === 1 ? "" : "s") + ". A success claim that does not account for those errors may be papering over an incomplete run.",
        evidence: [quote(lines[errorIdx[0]]), quote(success)]
      };
    }
    return null;
  }

  function detectSchemaDrift(lines) {
    var hits = lines.filter(function (l) {
      return /(schema|validation (error|failed)|parse (error|failed)|failed to parse|unexpected (field|property|key)|unknown (field|property)|missing (field|property|required)|required field|field .{0,40}(renamed|removed|missing|expected)|type (error|mismatch)|invalid (json|payload|response|format)|malformed|does not match|no such (field|column|key))/i.test(l.text);
    });
    if (!hits.length) return null;
    var explicit = hits.some(function (l) { return /(missing|renamed|unknown field|unexpected field|required field)/i.test(l.text); });
    return {
      id: "schema-drift", name: "Schema drift",
      confidence: explicit ? "STRONG" : "POSSIBLE",
      why: "The log names validation or parse problems \u2014 the shape of the data changed (a field renamed, dropped, or re-typed) between what the agent sent and what the tool now expects.",
      evidence: hits.slice(0, 3).map(quote)
    };
  }

  function detectInstructionConflict(lines) {
    var hits = lines.filter(function (l) {
      return /(ignore (all )?(previous|prior|above|earlier) (instructions|prompts|directions)|disregard (your|the) (instructions|rules)|override (the )?(instructions|system|rules)|new instructions:|forget your instructions|instead,? (do|run|execute)|you must now|system (prompt|message) says|developer (note|message|instruction)|user (now )?(demands|insists)|conflicting instruction)/i.test(l.text);
    });
    if (!hits.length) return null;
    var injected = hits.some(function (l) { return /(ignore|disregard|forget your|override)/i.test(l.text); });
    return {
      id: "instruction-conflict", name: "Instruction conflict",
      confidence: injected ? "STRONG" : "POSSIBLE",
      why: "The transcript contains override-style phrasing \u2014 language that tells the agent to drop earlier instructions and follow new ones. That can be a legitimate operator redirect, a conflict between instruction sources, or injected text inside tool output; the transcript alone cannot tell which.",
      evidence: hits.slice(0, 3).map(quote)
    };
  }

  function detectMeasurementBreak(lines, errorIdx) {
    var hits = lines.filter(function (l) {
      return /(grader|scorer|scoring|evaluat(ion|or)|harness|assertion|assert\b|expected .{0,60} (got|but)|test (failed|failure)|benchmark|judge (model|returned)|output parser|parser (failed|error)|metric (dropped|is zero)|score (of )?0\b)/i.test(l.text);
    });
    if (!hits.length) return null;
    var failContext = hits.some(function (l) { return ERROR_RE.test(l.text) || /fail|error|mismatch|expected/i.test(l.text); });
    if (!failContext && !errorIdx.length) return null;
    return {
      id: "measurement-break", name: "Measurement break",
      confidence: failContext ? "STRONG" : "POSSIBLE",
      why: "The failure signals sit in the grading / scoring / output-parsing layer rather than in the agent's own tool work. When the measuring instrument breaks, a healthy run scores as a failure \u2014 and a real regression can hide behind a broken score.",
      evidence: hits.slice(0, 3).map(quote)
    };
  }

  function detectContextOverflow(lines) {
    var hits = lines.filter(function (l) {
      return /(context (length|window|limit)|too many tokens|token limit|max(imum)? (context|tokens)|input too long|prompt\s+(?:is\s+)?too long|truncat(ed|ion)|exceeds? the (context|limit)|context_length_exceeded|request too large)/i.test(l.text);
    });
    if (!hits.length) return null;
    var explicit = hits.some(function (l) { return /(exceeded|too long|too many|limit)/i.test(l.text); });
    return {
      id: "context-overflow", name: "Context overflow",
      confidence: explicit ? "STRONG" : "POSSIBLE",
      why: "The log complains about length \u2014 tokens, context window, or truncation. Once the window overflows, earlier instructions and results silently fall out of the run, and later steps act on a partial picture.",
      evidence: hits.slice(0, 3).map(quote)
    };
  }

  /* ================= fixes & rules per category ================= */

  var FIXES = {
    "retry-loop": [
      "Cap identical retries: after 2 failures of the same call with unchanged inputs, stop and change something \u2014 the input, the tool, or the approach \u2014 before trying again.",
      "Log the exact error text of the first failure and require the retry plan to name what is different this time.",
      "Add a run-level budget: a hard maximum on total calls per task, so a loop burns budget loudly instead of silently."
    ],
    "ignored-error": [
      "Halt on error: any tool result containing an error status stops the run until the error is resolved or a human approves continuing.",
      "Make the final report conditional: the run may only claim success for steps whose results it has actually seen succeed.",
      "Carry failures forward explicitly \u2014 every later step should receive the list of steps that already failed."
    ],
    "silent-partial": [
      "Build a completion checklist from the task's own steps and verify each one against an actual tool result before reporting success.",
      "Require evidence per step in the final report (result id, status line, or output), not just a summary sentence.",
      "Treat \u201Cstep never appears in the log\u201D as a failed step, not a completed one."
    ],
    "schema-drift": [
      "Pin the expected schema version and validate outgoing payloads against it before the call.",
      "Diff the tool's current field list against the fields the agent was written for; update the renamed/missing fields the log names.",
      "Fail fast on validation errors with the offending field printed \u2014 do not let a parse error surface three steps later."
    ],
    "instruction-conflict": [
      "Fix the instruction hierarchy in writing: which source wins when the task, tool output, and operator messages disagree.",
      "Treat directive language inside tool results and fetched content as data, never as instructions, unless the operator sent it directly.",
      "When a genuine conflict is detected, stop and surface both instructions to the operator instead of silently picking one."
    ],
    "measurement-break": [
      "Re-run the grader/scorer on a known-good output: if it still fails, the instrument is broken, not the agent.",
      "Check the five usual measurement breaks: parser rejects valid output, scorer reads the wrong field, stale expected answers, harness timeout counted as failure, and score aggregation dropping runs.",
      "Version the grader alongside the agent and record which grader version produced every score."
    ],
    "context-overflow": [
      "Budget tokens per step and summarize completed steps into a compact state block instead of carrying full transcripts forward.",
      "Split oversized inputs before the run starts; never let a single tool result consume the remaining window.",
      "On any truncation or length warning, stop and checkpoint \u2014 the run no longer has the full picture."
    ],
    "generic": [
      "Reproduce the failure once with full logging before changing anything, so the fix is aimed at evidence, not memory.",
      "Write down the first error line and work forward from it; later errors are usually consequences, not causes.",
      "Add the failing pattern to the run's pre-flight checks so the next run catches it in the first step."
    ]
  };

  var RULES = {
    "retry-loop": ["Never issue the same call with the same inputs more than twice.", "A retry must change something and say what changed."],
    "ignored-error": ["An error result halts the run \u2014 no silent continuation.", "Never report a step as done if its result was an error."],
    "silent-partial": ["Success requires a seen result for every planned step.", "If a step is missing from the log, the run is not complete."],
    "schema-drift": ["Validate payload shape before every call; fail on the first mismatch.", "Name the exact field when reporting a schema problem."],
    "instruction-conflict": ["Tool output is data, not instructions.", "Conflicting instructions go to the operator, not to a coin flip."],
    "measurement-break": ["Verify the grader on a known-good output before trusting a failing score.", "Record the grader version with every result."],
    "context-overflow": ["Watch for truncation and length warnings; stop at the first one.", "Summarize state forward instead of dragging the full transcript."],
    "generic": ["Read the first error first; do not diagnose from the final message alone.", "Report only what the log proves; label the rest unverified."]
  };

  /* ================= build ================= */

  function esc(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  function analyze() {
    var lines = splitLines(transcriptEl.value);
    var errorIdx = [];
    lines.forEach(function (l, i) {
      if (!ERROR_RE.test(l.text)) return;
      // "Error noted / noted the error" is commentary about an error, not an
      // error event itself — unless the line also carries a status code.
      if (/\bnoted\b/i.test(l.text) && !/[45]\d\d/.test(l.text)) return;
      errorIdx.push(i);
    });
    var repeats = findRepeats(lines);

    var cats = [];
    var rl = detectRetryLoop(lines, repeats); if (rl) cats.push(rl);
    var ie = detectIgnoredError(lines, errorIdx); if (ie) cats.push(ie);
    var sp = detectSilentPartial(lines, errorIdx); if (sp) cats.push(sp);
    var sd = detectSchemaDrift(lines); if (sd) cats.push(sd);
    var ic = detectInstructionConflict(lines); if (ic) cats.push(ic);
    var mb = detectMeasurementBreak(lines, errorIdx); if (mb) cats.push(mb);
    var co = detectContextOverflow(lines); if (co) cats.push(co);

    // Rank: STRONG first, then evidence weight.
    var rank = { STRONG: 0, POSSIBLE: 1 };
    cats.sort(function (a, b) {
      return (rank[a.confidence] - rank[b.confidence]) || (b.evidence.length - a.evidence.length);
    });

    return { lines: lines, errorIdx: errorIdx, repeats: repeats, cats: cats };
  }

  function build() {
    copyStatus.textContent = "";
    if (!transcriptEl.value.trim()) {
      formMsg.textContent = "Paste a run transcript first \u2014 or load one of the samples.";
      return;
    }
    formMsg.textContent = "";
    var intended = intendedEl.value.trim();
    var actual = actualEl.value.trim();
    var a = analyze();
    var lines = a.lines, errorIdx = a.errorIdx, repeats = a.repeats, cats = a.cats;
    var firstError = errorIdx.length ? lines[errorIdx[0]] : null;
    var lastLine = lines[lines.length - 1];
    var hasSuccess = lines.some(function (l) { return SUCCESS_RE.test(l.text); });

    /* ----- clean run: no errors, no categories ----- */
    if (!errorIdx.length && !cats.length) {
      var note =
        "NO FAILURE FOUND \u2014 J-Dawgs Agent Failure Postmortem Builder\u2122\n" +
        "============================================================\n\n" +
        "The transcript (" + lines.length + " non-empty lines) contains no error lines and matches none of the\n" +
        "failure patterns this tool checks for (retry loop, ignored tool error, silent partial\n" +
        "success, schema drift, instruction conflict, measurement break, context overflow).\n\n" +
        (hasSuccess
          ? "The run closes with a success line:\n  [line " + lastLine.n + "] " + lastLine.text + "\n\n"
          : "Note: the transcript also contains no explicit success/completion line, so a clean\nfinish is inferred from the absence of errors, not proven by the log.\n\n") +
        "No postmortem was generated: inventing one for a clean run would be fabrication.\n" +
        "Unverified: this tool only pattern-matches pasted text. A failure that leaves no\n" +
        "error text in the transcript (wrong content, wrong recipient, wrong amount) is\n" +
        "invisible to it.\n";
      currentPlain = note;
      plainEl.textContent = note;
      outputEl.innerHTML =
        '<div class="clean-note">' +
        "<h2>No failure found in this transcript</h2>" +
        "<p>The run\u2019s " + lines.length + " lines contain <strong>no error lines</strong> and match none of the seven failure patterns this builder checks for." +
        (hasSuccess ? " It closes with a success line (line " + lastLine.n + ")." : "") + "</p>" +
        "<p>No postmortem was generated \u2014 writing one for a clean run would mean inventing a failure. One honest caveat: this tool pattern-matches text, so a failure that leaves no error text in the log (right steps, wrong content) is invisible to it and stays unverified.</p>" +
        "</div>";
      actionsEl.hidden = false;
      return;
    }

    /* ----- counts for impact ----- */
    var wasted = 0;
    repeats.forEach(function (g) { wasted += g.lines.length - 1; });
    var stepCount = lines.filter(function (l) { return CALL_RE.test(l.text); }).length;

    /* ----- fix checklist: top category first, then others, deduped ----- */
    var fixes = [], seenFix = {};
    function addFixes(list) { list.forEach(function (f) { if (!seenFix[f]) { seenFix[f] = 1; fixes.push(f); } }); }
    cats.forEach(function (c, i) { if (i === 0) addFixes(FIXES[c.id]); });
    cats.forEach(function (c, i) { if (i > 0) addFixes((FIXES[c.id] || []).slice(0, 2)); });
    if (!cats.length) addFixes(FIXES.generic);
    fixes = fixes.slice(0, 7);

    var rules = [], seenRule = {};
    cats.forEach(function (c) { (RULES[c.id] || []).forEach(function (r) { if (!seenRule[r]) { seenRule[r] = 1; rules.push(r); } }); });
    (RULES.generic).forEach(function (r) { if (!seenRule[r]) { seenRule[r] = 1; rules.push(r); } });
    rules = rules.slice(0, 6);

    /* ----- unverified items ----- */
    var unverified = [
      "The true root cause. Categories above are pattern matches over pasted text; the operator must confirm the cause before acting.",
      "Any cost in money, time, or downstream effects (messages sent, records changed, people affected) that the transcript does not explicitly state."
    ];
    if (!intended) unverified.push("The intended outcome \u2014 the field was left blank, so the summary cannot compare plan against result.");
    if (!actual) unverified.push("The actual outcome in the operator\u2019s own words \u2014 the field was left blank; only the transcript\u2019s final lines speak to what happened.");
    if (cats.some(function (c) { return c.id === "instruction-conflict"; }))
      unverified.push("Whether the override-style phrasing was a legitimate operator redirect or injected text \u2014 the transcript shows the words, not their source of authority.");
    if (cats.some(function (c) { return c.id === "measurement-break"; }))
      unverified.push("Whether the agent\u2019s underlying work was actually correct \u2014 a broken grader can hide a real failure as easily as it can fake one.");
    if (cats.some(function (c) { return c.id === "silent-partial"; }))
      unverified.push("Whether the missing step was completed outside this transcript (another run, a manual action) \u2014 it is absent here, which is all this tool can say.");
    unverified.push("Anything that happened before the first pasted line or after the last one.");

    /* ----- plain-text postmortem ----- */
    var T = [];
    T.push("AGENT FAILURE POSTMORTEM \u2014 built by J-Dawgs Agent Failure Postmortem Builder\u2122");
    T.push("============================================================");
    T.push("Heuristic pattern-match over the pasted transcript only. Not a proven root cause.");
    T.push("");
    T.push("SUMMARY");
    T.push("-------");
    T.push(summaryText(intended, actual, cats, errorIdx));
    T.push("");
    T.push("TIMELINE");
    T.push("--------");
    if (firstError) T.push("First error (line " + firstError.n + "): " + firstError.text);
    else T.push("First error: none found in the transcript.");
    repeats.slice(0, 3).forEach(function (g) {
      T.push("Repeated step x" + g.lines.length + (g.kind === "near" ? " (near-identical)" : " (identical)") +
             ", lines " + g.lines[0].n + "\u2013" + g.lines[g.lines.length - 1].n + ": " + g.lines[0].text);
    });
    if (!repeats.length) T.push("Repeated steps: none detected.");
    T.push("Final line (line " + lastLine.n + "): " + lastLine.text);
    T.push("");
    T.push("SUSPECTED CAUSE CATEGORIES");
    T.push("--------------------------");
    if (!cats.length) {
      T.push("No category matched, but the transcript contains " + errorIdx.length + " error line(s) \u2014 read them directly; the failure may be a pattern this tool does not cover.");
    }
    cats.forEach(function (c) {
      T.push("");
      T.push("* " + c.name + " [" + c.confidence + "]");
      T.push("  " + c.why);
      c.evidence.forEach(function (e) { T.push("  Evidence (line " + e.n + "): " + e.text); });
    });
    T.push("");
    T.push("IMPACT");
    T.push("------");
    impactLines(errorIdx, wasted, stepCount, lines).forEach(function (s) { T.push("- " + s); });
    T.push("");
    T.push("FIX CHECKLIST");
    T.push("-------------");
    fixes.forEach(function (f) { T.push("[ ] " + f); });
    T.push("");
    T.push("DO-NOT-REPEAT CHECKLIST");
    T.push("-----------------------");
    rules.forEach(function (r) { T.push("[ ] " + r); });
    T.push("");
    T.push("UNVERIFIED ITEMS");
    T.push("----------------");
    unverified.forEach(function (u) { T.push("- " + u); });
    T.push("");
    T.push("\u2014 End of postmortem. Confirm the cause before acting on the fix checklist.");

    currentPlain = T.join("\n");
    plainEl.textContent = currentPlain;

    /* ----- HTML rendering ----- */
    var h = "";
    h += '<div class="report">';
    h += '<h2 class="rp-title">Postmortem</h2>';
    h += '<p class="rp-meta">' + lines.length + " transcript lines \u00b7 " + errorIdx.length + " error lines \u00b7 " +
         cats.length + " suspected categor" + (cats.length === 1 ? "y" : "ies") + " \u00b7 heuristic match, not a proven cause</p>";

    h += "<section><h3>Summary</h3><p>" + esc(summaryText(intended, actual, cats, errorIdx)) + "</p></section>";

    h += "<section><h3>Timeline</h3>";
    if (firstError) {
      h += "<p style='margin-bottom:2px;'><strong>First error</strong></p>" + evBlock(firstError);
    } else {
      h += "<p class='muted'>No error line found in the transcript.</p>";
    }
    repeats.slice(0, 3).forEach(function (g) {
      h += "<p style='margin-bottom:2px;'><strong>Repeated step \u00d7" + g.lines.length + "</strong> " +
           "<span class='muted'>(" + (g.kind === "near" ? "near-identical" : "identical") + ", lines " + g.lines[0].n + "\u2013" + g.lines[g.lines.length - 1].n + ")</span></p>" + evBlock(g.lines[0]);
    });
    if (!repeats.length) h += "<p class='muted'>No repeated steps detected.</p>";
    h += "<p style='margin-bottom:2px;'><strong>Final step</strong></p>" + evBlock(lastLine);
    h += "</section>";

    h += "<section><h3>Suspected cause categories</h3>";
    if (!cats.length) {
      h += "<p>No category matched, but the transcript contains error lines \u2014 read them directly in the timeline above. The failure may follow a pattern this tool does not cover.</p>";
    }
    cats.forEach(function (c) {
      h += '<div class="cause"><div class="cause-head"><span class="cause-name">' + esc(c.name) + '</span>' +
           '<span class="badge ' + (c.confidence === "STRONG" ? "strong" : "possible") + '">' + c.confidence + "</span></div>" +
           '<p class="cause-why">' + esc(c.why) + "</p>";
      c.evidence.forEach(function (e) { h += evBlock(e); });
      h += "</div>";
    });
    h += "</section>";

    h += "<section><h3>Impact</h3><ul>";
    impactLines(errorIdx, wasted, stepCount, lines).forEach(function (s) { h += "<li>" + esc(s) + "</li>"; });
    h += "</ul></section>";

    h += "<section><h3>Fix checklist</h3><ul class='checklist'>";
    fixes.forEach(function (f) { h += "<li>" + esc(f) + "</li>"; });
    h += "</ul></section>";

    h += "<section><h3>Do-not-repeat checklist</h3><ul class='checklist no'>";
    rules.forEach(function (r) { h += "<li>" + esc(r) + "</li>"; });
    h += "</ul></section>";

    h += "<section><h3>Unverified items</h3><ul>";
    unverified.forEach(function (u) { h += "<li>" + esc(u) + "</li>"; });
    h += "</ul></section>";

    h += "</div>";
    outputEl.innerHTML = h;
    actionsEl.hidden = false;
  }

  function evBlock(l) {
    return '<blockquote class="ev"><span class="ln">line ' + l.n + "</span>" + esc(l.text) + "</blockquote>";
  }

  function summaryText(intended, actual, cats, errorIdx) {
    var parts = [];
    parts.push(intended ? "The run was supposed to: " + intended.replace(/\.*$/, "") + "."
                        : "The intended outcome was not stated by the operator.");
    parts.push(actual ? "In fact: " + actual.replace(/\.*$/, "") + "."
                      : "What actually happened, per the transcript: the run hit " + errorIdx.length +
                        " error line(s) and ended with: \u201C" + lastLineText() + "\u201D");
    if (cats.length) {
      parts.push("Strongest pattern match: " + cats[0].name + " (" + cats[0].confidence + ")" +
                 (cats.length > 1 ? ", with " + (cats.length - 1) + " further suspected categor" + (cats.length === 2 ? "y" : "ies") + " listed below" : "") + ".");
    } else {
      parts.push("No known failure pattern matched, despite the error lines present.");
    }
    return parts.join(" ");
  }
  var _lastLineCache = "";
  function lastLineText() { return _lastLineCache; }

  function impactLines(errorIdx, wasted, stepCount, lines) {
    var out = [];
    out.push("Error lines in transcript: " + errorIdx.length + ".");
    if (wasted > 0) out.push("Wasted steps: " + wasted + " repeated call(s) beyond the first attempt \u2014 work the transcript shows being spent re-issuing steps that had already run.");
    else out.push("Wasted steps from repeats: none detected.");
    out.push("Total steps logged: " + lines.length + " lines, " + stepCount + " of them tool calls/actions.");
    out.push("Cost in money, wall-clock time, or downstream side effects: not stated in transcript.");
    return out;
  }

  // Keep summary helper honest: track last line text during build.
  var origBuild = build;
  return { "analyze": (typeof analyze !== 'undefined' ? analyze : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "FAILED_SAMPLE": (typeof FAILED_SAMPLE !== 'undefined' ? FAILED_SAMPLE : undefined), "CLEAN_SAMPLE": (typeof CLEAN_SAMPLE !== 'undefined' ? CLEAN_SAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["analyze"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-agent-failure-postmortem-builder',
  name: 'J-Dawgs Agent Failure Postmortem Builder',
  description: 'Turn a failed run into a structured postmortem with causes and fixes',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["analyze"]) return { ok: false, output: null, summary: 'Extracted core has no analyze function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "FAILED_SAMPLE": __core["FAILED_SAMPLE"], "CLEAN_SAMPLE": __core["CLEAN_SAMPLE"] }
};
