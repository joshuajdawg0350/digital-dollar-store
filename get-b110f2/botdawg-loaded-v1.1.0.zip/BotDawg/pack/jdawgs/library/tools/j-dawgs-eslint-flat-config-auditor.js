'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs ESLint Flat Config Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- worked examples ---------- */

      var EXAMPLE_BAD_CONFIG = [
        "// eslint.config.js — carried over from an old .eslintrc setup",
        "export default [",
        "  {",
        "    files: [\"src/**/*.{js,mjs}\"],",
        "    env: {",
        "      browser: true,",
        "      es2021: true",
        "    },",
        "    languageOptions: {",
        "      ecmaVersion: 2021,",
        "      sourceType: \"module\"",
        "    },",
        "    rules: {",
        "      \"no-unused-vars\": \"warn\",",
        "      eqeqeq: \"error\"",
        "    }",
        "  }",
        "];",
        ""
      ].join("\n");

      var EXAMPLE_BAD_FILES = [
        "src/app.js",
        "src/lib/format.js",
        "dist/bundle.js",
        ""
      ].join("\n");

      var EXAMPLE_GOOD_CONFIG = [
        "// eslint.config.js",
        "import globals from \"globals\";",
        "",
        "export default [",
        "  {",
        "    ignores: [\"dist/**\", \"node_modules/**\", \"coverage/**\"]",
        "  },",
        "  {",
        "    files: [\"src/**/*.{js,mjs,cjs}\", \"eslint.config.js\"],",
        "    languageOptions: {",
        "      ecmaVersion: \"latest\",",
        "      sourceType: \"module\",",
        "      globals: { ...globals.browser }",
        "    },",
        "    rules: {",
        "      \"no-undef\": \"error\",",
        "      \"no-unused-vars\": \"warn\",",
        "      eqeqeq: [\"error\", \"always\"]",
        "    }",
        "  },",
        "  {",
        "    files: [\"src/**/*.cjs\"],",
        "    languageOptions: { sourceType: \"commonjs\" }",
        "  }",
        "];",
        ""
      ].join("\n");

      var EXAMPLE_GOOD_FILES = [
        "src/app.js",
        "src/lib/format.js",
        "src/legacy/tool.cjs",
        "eslint.config.js",
        "dist/bundle.js",
        "node_modules/some-dep/index.js",
        ""
      ].join("\n");

      /* ---------- text helpers ---------- */

      // Replace comments with spaces (same length, newlines kept) so offsets
      // and line numbers still match the pasted text. Strings are preserved.
      function stripComments(src) {
        var out = [], i = 0, n = src.length, state = null;
        while (i < n) {
          var c = src[i], d = i + 1 < n ? src[i + 1] : "";
          if (state) {
            out.push(c);
            if (c === "\\" && i + 1 < n) { out.push(src[i + 1]); i += 2; continue; }
            if (c === state) state = null;
            i++; continue;
          }
          if (c === '"' || c === "'" || c === "`") { state = c; out.push(c); i++; continue; }
          if (c === "/" && d === "/") {
            while (i < n && src[i] !== "\n") { out.push(" "); i++; }
            continue;
          }
          if (c === "/" && d === "*") {
            out.push(" ", " "); i += 2;
            while (i < n && !(src[i] === "*" && src[i + 1] === "/")) {
              out.push(src[i] === "\n" ? "\n" : " "); i++;
            }
            if (i < n) { out.push(" ", " "); i += 2; }
            continue;
          }
          out.push(c); i++;
        }
        return out.join("");
      }

      function lineOf(text, idx) {
        var line = 1;
        for (var i = 0; i < idx && i < text.length; i++) if (text[i] === "\n") line++;
        return line;
      }

      // Index of the delimiter that closes the one at text[start], or -1.
      function matchDelim(text, start, open, close) {
        var depth = 0, state = null, i = start;
        while (i < text.length) {
          var c = text[i];
          if (state) {
            if (c === "\\") { i += 2; continue; }
            if (c === state) state = null;
            i++; continue;
          }
          if (c === '"' || c === "'" || c === "`") { state = c; i++; continue; }
          if (c === open) depth++;
          else if (c === close) { depth--; if (depth === 0) return i; }
          i++;
        }
        return -1;
      }

      // Split a comma list at nesting depth 0. Returns [{text, start}].
      function splitTopLevel(content, baseOffset) {
        var parts = [], depth = 0, state = null, start = 0, i = 0;
        while (i < content.length) {
          var c = content[i];
          if (state) {
            if (c === "\\") { i += 2; continue; }
            if (c === state) state = null;
            i++; continue;
          }
          if (c === '"' || c === "'" || c === "`") { state = c; i++; continue; }
          if (c === "{" || c === "[" || c === "(") depth++;
          else if (c === "}" || c === "]" || c === ")") depth--;
          else if (c === "," && depth === 0) {
            parts.push({ text: content.slice(start, i), start: baseOffset + start });
            start = i + 1;
          }
          i++;
        }
        var tail = content.slice(start);
        if (tail.trim() !== "") parts.push({ text: tail, start: baseOffset + start });
        return parts;
      }

      function extractQuoted(str) {
        var out = [], re = /"([^"\n]*)"|'([^'\n]*)'|`([^`]*)`/g, m;
        while ((m = re.exec(str)) !== null) {
          var v = m[1] !== undefined ? m[1] : (m[2] !== undefined ? m[2] : m[3]);
          if (v.indexOf("${") === -1) out.push(v);
        }
        return out;
      }

      // Skip a value expression starting at i (inside an object literal chunk
      // whose own braces sit at relative depth 0). Returns index just past it.
      function skipValue(text, i) {
        var depth = 0, state = null;
        while (i < text.length) {
          var c = text[i];
          if (state) {
            if (c === "\\") { i += 2; continue; }
            if (c === state) state = null;
            i++; continue;
          }
          if (c === '"' || c === "'" || c === "`") { state = c; i++; continue; }
          if (c === "{" || c === "[" || c === "(") depth++;
          else if (c === "}" || c === "]" || c === ")") {
            if (depth === 0) return i;
            depth--;
          } else if (c === "," && depth === 0) return i;
          i++;
        }
        return i;
      }

      function readKey(text, i) {
        var c = text[i];
        if (c === '"' || c === "'" || c === "`") {
          var j = i + 1, val = "";
          while (j < text.length && text[j] !== c) {
            if (text[j] === "\\" && j + 1 < text.length) { val += text[j + 1]; j += 2; continue; }
            val += text[j]; j++;
          }
          return { key: val, end: j + 1 };
        }
        var m = /^[A-Za-z_$][A-Za-z0-9_$]*/.exec(text.slice(i));
        if (m) return { key: m[0], end: i + m[0].length };
        return null;
      }

      // Parse the top-level entries of an object literal chunk (chunk includes
      // its outer braces). Returns [{key, keyIdx, valueText, spread}].
      function parseObjectEntries(chunk, chunkStart) {
        var entries = [];
        var i = 1; // past '{'
        while (i < chunk.length) {
          var c = chunk[i];
          if (c === "}" ) break;
          if (c === "," || /\s/.test(c)) { i++; continue; }
          if (chunk.slice(i, i + 3) === "...") {
            var send = skipValue(chunk, i + 3);
            entries.push({ key: null, spread: true, keyIdx: chunkStart + i, valueText: chunk.slice(i, send) });
            i = send; continue;
          }
          var rk = readKey(chunk, i);
          if (!rk) { i++; continue; }
          var keyIdx = chunkStart + i;
          i = rk.end;
          while (i < chunk.length && /\s/.test(chunk[i])) i++;
          var valueText = "";
          if (chunk[i] === ":") {
            i++;
            while (i < chunk.length && /\s/.test(chunk[i])) i++;
            var vend = skipValue(chunk, i);
            valueText = chunk.slice(i, vend);
            i = vend;
          }
          entries.push({ key: rk.key, spread: false, keyIdx: keyIdx, valueText: valueText });
        }
        return entries;
      }

      function getEntry(entries, key) {
        for (var i = 0; i < entries.length; i++) if (entries[i].key === key) return entries[i];
        return null;
      }

      /* ---------- globs ---------- */

      function escapeRe(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); }

      function globToRegExp(glob) {
        var g = glob.replace(/^\.\//, "");
        var re = "", i = 0;
        while (i < g.length) {
          var c = g[i];
          if (c === "*") {
            if (g[i + 1] === "*") {
              if (g[i + 2] === "/") { re += "(?:.*/)?"; i += 3; }
              else { re += ".*"; i += 2; }
            } else { re += "[^/]*"; i++; }
          } else if (c === "?") { re += "[^/]"; i++; }
          else if (c === "{") {
            var j = g.indexOf("}", i);
            if (j < 0) { re += "\\{"; i++; }
            else {
              var parts = g.slice(i + 1, j).split(",");
              for (var k = 0; k < parts.length; k++) parts[k] = escapeRe(parts[k].trim());
              re += "(?:" + parts.join("|") + ")"; i = j + 1;
            }
          } else if (".+^$()|[]\\".indexOf(c) >= 0) { re += "\\" + c; i++; }
          else { re += c; i++; }
        }
        return new RegExp("^" + re + "$");
      }

      function matchesGlob(pattern, path) {
        var p = pattern.replace(/^\.\//, "").replace(/\/+$/, "");
        var f = path.replace(/^\.\//, "");
        if (p === "") return false;
        if (globToRegExp(p).test(f)) return true;
        var hasMagic = /[*?{]/.test(p);
        if (!hasMagic && f.indexOf(p + "/") === 0) return true; // bare folder name covers its contents
        if (p.indexOf("/") === -1) {
          var base = f.split("/").pop();
          if (globToRegExp(p).test(base)) return true;
        }
        return false;
      }

      function matchesAny(patterns, path) {
        for (var i = 0; i < patterns.length; i++) if (matchesGlob(patterns[i], path)) return true;
        return false;
      }

      /* ---------- audit ---------- */

      var CORE_SAFETY_RULES = [
        "no-undef", "no-unused-vars", "no-redeclare", "no-dupe-keys",
        "no-dupe-args", "no-unreachable", "no-const-assign", "no-func-assign",
        "no-import-assign", "no-obj-calls", "no-setter-return",
        "use-isnan", "valid-typeof", "no-duplicate-case", "no-fallthrough"
      ];

      function scalarText(v) {
        v = v.trim();
        var m = /^"([^"]*)"|^'([^']*)'/.exec(v);
        if (m) return { stated: true, text: m[1] !== undefined ? m[1] : m[2], raw: v };
        if (/^-?\d+$/.test(v)) return { stated: true, text: v, raw: v };
        var id = /^[A-Za-z_$][A-Za-z0-9_$.]*/.exec(v);
        if (id && !/\.\.\./.test(v)) return { stated: true, text: id[0], raw: v };
        return { stated: false, text: "", raw: v };
      }

      function severityOf(valueText) {
        var v = valueText.trim();
        if (v.charAt(0) === "[") {
          var inner = v.slice(1);
          var depth = 0, state = null, end = inner.length;
          for (var i = 0; i < inner.length; i++) {
            var c = inner[i];
            if (state) { if (c === "\\") i++; else if (c === state) state = null; continue; }
            if (c === '"' || c === "'" || c === "`") { state = c; continue; }
            if (c === "{" || c === "[" || c === "(") depth++;
            else if (c === "}" || c === "]" || c === ")") depth--;
            else if (c === "," && depth === 0) { end = i; break; }
          }
          v = inner.slice(0, end).trim();
        }
        var m = /^"([^"]*)"|^'([^']*)'/.exec(v);
        if (m) return { kind: "string", val: m[1] !== undefined ? m[1] : m[2] };
        if (/^-?\d+$/.test(v)) return { kind: "number", val: parseInt(v, 10) };
        return { kind: "expr", val: null };
      }

      function audit(configRaw, filesRaw) {
        var findings = [];   // {sev: 'blocker'|'warning', title, where, fix}
        var notes = [];      // stated facts
        var notChecked = []; // strings
        var text = stripComments(configRaw);
        var files = [];
        var fileLines = filesRaw.split(/\r?\n/);
        for (var fi = 0; fi < fileLines.length; fi++) {
          var p = fileLines[fi].trim();
          if (p !== "" && p.charAt(0) !== "#") files.push({ path: p, line: fi + 1 });
        }

        function addBlocker(title, where, fix) { findings.push({ sev: "blocker", title: title, where: where, fix: fix }); }
        function addWarning(title, where, fix) { findings.push({ sev: "warning", title: title, where: where, fix: fix }); }

        /* locate the exported array */
        var exportMatch = /export\s+default/.exec(text) ||
                          /module\s*\.\s*exports\s*=/.exec(text) ||
                          /export\s*=/.exec(text) ||
                          /defineConfig\s*\(/.exec(text);
        var arrayInner = null, arrayInnerStart = 0;
        if (exportMatch) {
          var bracket = text.indexOf("[", exportMatch.index);
          if (bracket >= 0) {
            var close = matchDelim(text, bracket, "[", "]");
            if (close > bracket) { arrayInner = text.slice(bracket + 1, close); arrayInnerStart = bracket + 1; }
          }
        }

        var entries = []; // per-entry analysis
        var allFilesGlobs = [];   // {glob, entryNo, line}
        var allIgnoreGlobs = [];  // pattern strings
        var standaloneIgnores = false;
        var anyIgnores = false;
        var globalLang = { ecmaVersion: null, sourceType: null }; // from entries without files
        var langStated = [];      // display lines
        var importedEntries = 0;
        var cjsOverrides = {};    // nothing fancy; per-entry sourceType entries list
        var sourceTypeEntries = []; // {globs, sourceType}

        if (!arrayInner) {
          addBlocker(
            "No exported array found — this does not read as a flat config",
            "whole config",
            "A flat config exports an array of config objects: export default [ { files: [...], rules: {...} } ]; (or module.exports = [ ... ]). Nothing else in the file can be trusted as a lint gate until that shape is there."
          );
          // Still scan raw text for legacy keys so they are named.
          var legacyScan = [
            { key: "env", re: /(^|[\s{,])env\s*:/, fix: "Flat config has no env key. Move globals into languageOptions.globals on the entry that needs them (for example the globals package's browser/node sets, or list each global by name)." },
            { key: "extends", re: /(^|[\s{,])extends\s*:\s*["'\[]/, fix: "Flat config does not load string presets. Import the shareable config and spread it into the exported array instead of naming it in extends." },
            { key: "parserOptions", re: /parserOptions\s*:/, fix: "Move parser options inside languageOptions on the entry that needs them — parserOptions does not stand alone in flat config." }
          ];
          for (var ls = 0; ls < legacyScan.length; ls++) {
            var lm = legacyScan[ls].re.exec(text);
            if (lm) addBlocker("LEGACY LEAK: \"" + legacyScan[ls].key + "\"", "config line " + lineOf(text, lm.index), legacyScan[ls].fix);
          }
        } else {
          var chunks = splitTopLevel(arrayInner, arrayInnerStart);
          for (var ci = 0; ci < chunks.length; ci++) {
            var chunk = chunks[ci];
            var trimmed = chunk.text.trim();
            var entryNo = ci + 1;
            if (trimmed === "") continue;
            if (trimmed.charAt(0) !== "{") {
              importedEntries++;
              entries.push({ no: entryNo, imported: true });
              continue;
            }
            var objStart = chunk.start + chunk.text.indexOf("{");
            var kv = parseObjectEntries(trimmed.slice(trimmed.indexOf("{")), objStart);
            var info = { no: entryNo, imported: false, filesGlobs: [], ignoresGlobs: [], hasFiles: false, sourceType: null };
            var filesEnt = getEntry(kv, "files");
            var ignoresEnt = getEntry(kv, "ignores");
            if (filesEnt) {
              info.hasFiles = true;
              info.filesGlobs = extractQuoted(filesEnt.valueText);
              for (var g = 0; g < info.filesGlobs.length; g++) {
                allFilesGlobs.push({ glob: info.filesGlobs[g], entryNo: entryNo, line: lineOf(text, filesEnt.keyIdx) });
              }
              if (info.filesGlobs.length === 0 && filesEnt.valueText.trim() !== "") {
                notChecked.push("The files patterns in entry " + entryNo + " are written as expressions, not quoted strings — a text audit cannot read them.");
              }
            }
            if (ignoresEnt) {
              info.ignoresGlobs = extractQuoted(ignoresEnt.valueText);
              anyIgnores = true;
              for (var ig = 0; ig < info.ignoresGlobs.length; ig++) allIgnoreGlobs.push(info.ignoresGlobs[ig]);
              if (!filesEnt && kv.length === 1) standaloneIgnores = true;
            }

            /* legacy keys at this entry's top level */
            var LEGACY = {
              env: "Flat config has no env key. Move these globals into languageOptions.globals on this entry (for example the globals package's browser/node sets, or list each global by name).",
              parserOptions: "parserOptions does not stand alone in flat config. Move it inside languageOptions on this entry."
            };
            var envEnt = getEntry(kv, "env");
            if (envEnt) {
              addBlocker("LEGACY LEAK: \"env\" key", "entry " + entryNo + ", config line " + lineOf(text, envEnt.keyIdx), LEGACY.env);
            }
            var poEnt = getEntry(kv, "parserOptions");
            if (poEnt) {
              addBlocker("LEGACY LEAK: \"parserOptions\" at the top level of an entry", "entry " + entryNo + ", config line " + lineOf(text, poEnt.keyIdx), LEGACY.parserOptions);
            }
            var extEnt = getEntry(kv, "extends");
            if (extEnt) {
              var extVal = extEnt.valueText.trim();
              if (/^["'`]/.test(extVal) || (extVal.charAt(0) === "[" && extractQuoted(extVal).length > 0)) {
                addBlocker("LEGACY LEAK: \"extends\" naming string presets", "entry " + entryNo + ", config line " + lineOf(text, extEnt.keyIdx),
                  "Flat config does not load presets by name. Import each shareable config and spread it into the exported array (or pass it to defineConfig) instead of listing it in extends.");
              }
            }

            /* languageOptions */
            var langEnt = getEntry(kv, "languageOptions");
            var entryEcma = null, entrySource = null;
            if (langEnt && langEnt.valueText.trim().charAt(0) === "{") {
              var langKv = parseObjectEntries(langEnt.valueText.trim(), langEnt.keyIdx);
              var ecmaEnt = getEntry(langKv, "ecmaVersion");
              var srcEnt = getEntry(langKv, "sourceType");
              if (ecmaEnt) { var es = scalarText(ecmaEnt.valueText); if (es.stated) entryEcma = es.text; }
              if (srcEnt) { var ss = scalarText(srcEnt.valueText); if (ss.stated) entrySource = ss.text; }
            }
            if (entryEcma !== null || entrySource !== null) {
              var scope = info.hasFiles ? "entry " + entryNo + " (" + (info.filesGlobs.join(", ") || "files as written") + ")" : "entry " + entryNo + " (no files list — applies globally)";
              langStated.push({ scope: scope, ecmaVersion: entryEcma, sourceType: entrySource });
            }
            if (!info.hasFiles) {
              if (entryEcma !== null && globalLang.ecmaVersion === null) globalLang.ecmaVersion = entryEcma;
              if (entrySource !== null && globalLang.sourceType === null) globalLang.sourceType = entrySource;
            }
            if (entrySource !== null) {
              info.sourceType = entrySource;
              sourceTypeEntries.push({ globs: info.filesGlobs, sourceType: entrySource });
            }

            /* rules posture */
            var rulesEnt = getEntry(kv, "rules");
            if (rulesEnt && rulesEnt.valueText.trim().charAt(0) === "{") {
              var ruleKv = parseObjectEntries(rulesEnt.valueText.trim(), rulesEnt.keyIdx);
              for (var ri = 0; ri < ruleKv.length; ri++) {
                var rule = ruleKv[ri];
                if (!rule.key) continue;
                var sev = severityOf(rule.valueText);
                var where = "entry " + entryNo + ", config line " + lineOf(text, rule.keyIdx);
                if (sev.kind === "string" && ["off", "warn", "error"].indexOf(sev.val) === -1) {
                  addWarning("Invalid severity for rule \"" + rule.key + "\": \"" + sev.val + "\"", where,
                    "Severities are only \"off\", \"warn\", \"error\" (or 0, 1, 2). ESLint will refuse to run with \"" + sev.val + "\" — set a real severity.");
                } else if (sev.kind === "number" && [0, 1, 2].indexOf(sev.val) === -1) {
                  addWarning("Invalid severity for rule \"" + rule.key + "\": " + sev.val, where,
                    "Severities are only 0, 1, 2 (or \"off\", \"warn\", \"error\"). ESLint will refuse to run with " + sev.val + " — set a real severity.");
                } else if ((sev.kind === "string" && sev.val === "off") || (sev.kind === "number" && sev.val === 0)) {
                  if (CORE_SAFETY_RULES.indexOf(rule.key) !== -1) {
                    addWarning("Core safety rule \"" + rule.key + "\" is set to \"off\"", where,
                      "This gate will not catch what \"" + rule.key + "\" exists to catch. If the off is deliberate, it should be scoped to the files that need it — not set where everything inherits it.");
                  }
                }
              }
            }
            entries.push(info);
          }
        }

        /* global ignores posture */
        if (arrayInner) {
          if (!anyIgnores) {
            addWarning("No ignores anywhere in the config",
              "whole config",
              "Add a standalone global-ignores entry — an object with only an ignores list, e.g. { ignores: [\"dist/**\", \"node_modules/**\"] } — so build output and dependencies are never linted.");
          } else if (!standaloneIgnores) {
            addWarning("Ignores exist, but no standalone global-ignores entry",
              "whole config",
              "Ignores written inside an entry that also has files only apply to that entry. Put shared ignores in their own entry — an object with only an ignores list — so they apply to the whole project.");
          }
        }

        /* per-file coverage */
        var coveredCount = 0, ignoredCount = 0;
        if (files.length === 0) {
          notChecked.push("Per-file coverage — no file list was pasted, so no path could be matched against the config.");
        } else if (arrayInner) {
          for (var fi2 = 0; fi2 < files.length; fi2++) {
            var f = files[fi2];
            var norm = f.path.replace(/^\.\//, "");
            var segs = norm.split("/");
            var inBuild = segs.indexOf("dist") !== -1 || segs.indexOf("node_modules") !== -1 ||
                          norm.indexOf("dist/") === 0 || norm.indexOf("node_modules/") === 0;
            if (matchesAny(allIgnoreGlobs, f.path)) { ignoredCount++; continue; }
            if (inBuild) {
              addBlocker("COVERAGE GAP: " + f.path + " is build output / a dependency and no ignores pattern covers it",
                "file list line " + f.line,
                "ESLint will lint this file (or fail trying) because nothing ignores it. Add it to a global ignores entry — \"dist/**\" and \"node_modules/**\" cover the usual cases.");
              continue;
            }
            if (matchesAny(allFilesGlobs.map(function (x) { return x.glob; }), f.path)) { coveredCount++; continue; }
            var underSrc = norm.indexOf("src/") === 0 || segs.indexOf("src") !== -1;
            if (underSrc) {
              addBlocker("UNCOVERED: " + f.path + " is matched by no entry's files list",
                "file list line " + f.line,
                "This source file gets no rules at all — the gate silently skips it. Add a files glob that covers it (for example \"src/**/*.js\") to an entry with your rules.");
            } else {
              addWarning("UNCOVERED: " + f.path + " is matched by no entry's files list",
                "file list line " + f.line,
                "No entry claims this file, so it is linted with defaults only — or skipped. Add a files glob for it, or ignore it explicitly if it should stay out of the gate.");
            }
          }
          /* stale globs */
          for (var sg = 0; sg < allFilesGlobs.length; sg++) {
            var gobj = allFilesGlobs[sg];
            var hit = false;
            for (var hf = 0; hf < files.length; hf++) if (matchesGlob(gobj.glob, files[hf].path)) { hit = true; break; }
            if (!hit) {
              addWarning("STALE: files glob \"" + gobj.glob + "\" matches nothing in the pasted file list",
                "entry " + gobj.entryNo + ", config line " + gobj.line,
                "Either the glob is misspelled, the files moved, or the list you pasted is incomplete. Fix the glob or remove it — a stale glob hides the files it was meant to cover.");
            }
          }
        }

        /* .cjs vs global sourceType "module" */
        if (globalLang.sourceType === "module" && files.length > 0) {
          var mismatched = [];
          for (var cf = 0; cf < files.length; cf++) {
            var cp = files[cf].path;
            if (!/\.cjs$/i.test(cp)) continue;
            if (matchesAny(allIgnoreGlobs, cp)) continue;
            var hasOverride = false;
            for (var oe = 0; oe < sourceTypeEntries.length; oe++) {
              if (sourceTypeEntries[oe].globs.length > 0 && matchesAny(sourceTypeEntries[oe].globs, cp)) { hasOverride = true; break; }
            }
            if (!hasOverride) mismatched.push(cp);
          }
          if (mismatched.length > 0) {
            addWarning("MISMATCH: sourceType \"module\" is stated globally, but " + mismatched.join(", ") + " is a .cjs (CommonJS) file with no per-file override",
              "whole config",
              "Add an entry for the .cjs files with languageOptions: { sourceType: \"commonjs\" } — parsing CommonJS as a module breaks on require/module.exports.");
          }
        }

        /* stated language options summary */
        if (langStated.length === 0) {
          notes.push("ecmaVersion: NOT STATED anywhere in the pasted config.");
          notes.push("sourceType: NOT STATED anywhere in the pasted config.");
        } else {
          for (var ln = 0; ln < langStated.length; ln++) {
            var L = langStated[ln];
            notes.push(L.scope + " — ecmaVersion: " + (L.ecmaVersion !== null ? "\"" + L.ecmaVersion + "\"" : "not stated in this entry") +
                       "; sourceType: " + (L.sourceType !== null ? "\"" + L.sourceType + "\"" : "not stated in this entry") + ".");
          }
          var anyEcma = langStated.some(function (x) { return x.ecmaVersion !== null; });
          var anySrc = langStated.some(function (x) { return x.sourceType !== null; });
          if (!anyEcma) notes.push("ecmaVersion: NOT STATED anywhere — the audit does not assume a default.");
          if (!anySrc) notes.push("sourceType: NOT STATED anywhere — the audit does not assume a default.");
        }

        /* not checked */
        notChecked.push("Whether this config actually loads and runs in ESLint — the config is never executed here.");
        notChecked.push("Imports, plugins, and shareable configs — they are never resolved or loaded, and any rules they set are invisible to a text audit.");
        if (importedEntries > 0) {
          notChecked.push("The contents of " + importedEntries + " imported or spread entr" + (importedEntries === 1 ? "y" : "ies") + " in the exported array — not visible in pasted text.");
        }
        notChecked.push("Rule semantics and rule options beyond the severity values and the named core-safety off-checks above.");

        var blockers = findings.filter(function (x) { return x.sev === "blocker"; }).length;
        var warnings = findings.length - blockers;
        var verdict, vclass, why;
        if (!arrayInner || blockers > 0) {
          verdict = "DO NOT TRUST THIS GATE"; vclass = "bad";
          why = blockers + " blocker" + (blockers === 1 ? "" : "s") + " found. Until the blockers are fixed, this config either will not run as a flat config or silently skips files it should be checking — a green run would mean nothing.";
          if (!arrayInner) why = "No exported array was found, so this does not read as a working flat config at all. Fix the shape first; a gate that cannot load cannot be trusted.";
        } else if (warnings > 0) {
          verdict = "LINT WITH FIXES"; vclass = "warn";
          why = "The shape is a real flat config and nothing blocks outright, but " + warnings + " warning" + (warnings === 1 ? "" : "s") + " should be fixed before this gate is relied on.";
        } else {
          verdict = "READY TO LINT"; vclass = "ok";
          why = "Exported array present, no legacy leaks, ignores and files coverage line up with the pasted file list, and rule posture is clean on every check this audit runs.";
        }

        return {
          verdict: verdict, vclass: vclass, why: why,
          findings: findings, notes: notes, notChecked: notChecked,
          blockers: blockers, warnings: warnings,
          coveredCount: coveredCount, ignoredCount: ignoredCount, fileCount: files.length
        };
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_BAD_CONFIG": (typeof EXAMPLE_BAD_CONFIG !== 'undefined' ? EXAMPLE_BAD_CONFIG : undefined), "EXAMPLE_BAD_FILES": (typeof EXAMPLE_BAD_FILES !== 'undefined' ? EXAMPLE_BAD_FILES : undefined), "EXAMPLE_GOOD_CONFIG": (typeof EXAMPLE_GOOD_CONFIG !== 'undefined' ? EXAMPLE_GOOD_CONFIG : undefined), "EXAMPLE_GOOD_FILES": (typeof EXAMPLE_GOOD_FILES !== 'undefined' ? EXAMPLE_GOOD_FILES : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-eslint-flat-config-auditor',
  name: 'J-Dawgs ESLint Flat Config Auditor',
  description: 'Audits a pasted ESLint flat config against a pasted file list without executing it — legacy .eslintrc leaks, global-ignores posture, and per-file glob coverage — into one verdict: READY TO LINT, LINT WITH FIXES, or DO NOT TRUST THIS GATE.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_BAD_CONFIG": __core["EXAMPLE_BAD_CONFIG"], "EXAMPLE_BAD_FILES": __core["EXAMPLE_BAD_FILES"], "EXAMPLE_GOOD_CONFIG": __core["EXAMPLE_GOOD_CONFIG"], "EXAMPLE_GOOD_FILES": __core["EXAMPLE_GOOD_FILES"] }
};
