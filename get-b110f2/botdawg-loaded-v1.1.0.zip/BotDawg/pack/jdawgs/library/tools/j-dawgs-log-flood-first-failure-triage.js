'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Log Flood & First-Failure Triage Bench".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the analyze function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var logInput = document.getElementById("logInput");
        var inputMeta = document.getElementById("inputMeta");
        var emptyMsg = document.getElementById("emptyMsg");
        var results = document.getElementById("results");
        var includeStack = true;
        var lastAnalysis = null;

        function estTokens(chars) { return Math.round(chars / 4); }
        function fmt(n) { return n.toLocaleString("en-US"); }
        function truncate(s, n) { return s.length > n ? s.slice(0, n - 1) + "…" : s; }

        /* ---------- classification ---------- */
        var RE_STACK = [
          /^\s+at\s+\S/,
          /^\s*File\s+"[^"]+",\s+line\s+\d+/,
          /^Traceback \(most recent call last\):/,
          /^\s*#\d+\s+\S/,
          /^\s+at\s+[\w.$]+\(/
        ];
        var RE_ERROR = /\b(FATAL|CRITICAL|SEVERE|ERROR|Error|Exception|FAIL(?:ED|URE)?|panic|AssertionError|Traceback)\b/;
        var RE_WARN = /\b(WARN(?:ING)?|Deprecated|DeprecationWarning|deprecat)/i;
        var RE_PASS = /(\bPASS(?:ED)?\b|\bOK\b|✓|✔|\bpassed\b|\bsuccess(?:ful)?\b|\bDone\b|\bcompleted\b)/i;

        function classify(line) {
          var i;
          for (i = 0; i < RE_STACK.length; i++) { if (RE_STACK[i].test(line)) return "stack"; }
          if (RE_ERROR.test(line)) return "error";
          if (RE_WARN.test(line)) return "warning";
          if (RE_PASS.test(line)) return "pass";
          return "other";
        }

        /* ---------- normalization for clustering ---------- */
        function normalize(line) {
          var s = line;
          s = s.replace(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/gi, "<uuid>");
          s = s.replace(/\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(\.\d+)?(Z|[+-]\d{2}:?\d{2})?/g, "<ts>");
          s = s.replace(/\b\d{1,2}:\d{2}:\d{2}(\.\d+)?\b/g, "<ts>");
          s = s.replace(/"[^"]*"/g, '"<v>"');
          s = s.replace(/'[^']*'/g, "'<v>'");
          s = s.replace(/\b0x[0-9a-fA-F]+\b/g, "<hex>");
          s = s.replace(/\b[0-9a-fA-F]{12,}\b/g, "<hex>");
          s = s.replace(/\b\d[\d,]*(\.\d+)?\b/g, "<n>");
          s = s.replace(/\s+/g, " ").trim();
          return s;
        }

        function clusterLines(items) {
          // items: [{lineNo, text}] -> clusters sorted by first appearance
          var map = {}, order = [], i, it, key, c;
          for (i = 0; i < items.length; i++) {
            it = items[i];
            key = normalize(it.text);
            if (!map[key]) {
              map[key] = { key: key, count: 0, first: it.lineNo, last: it.lineNo, example: it.text };
              order.push(map[key]);
            }
            c = map[key];
            c.count++;
            c.last = it.lineNo;
          }
          order.sort(function (a, b) { return a.first - b.first; });
          return order;
        }

        /* ---------- analysis ---------- */
        function analyze(raw) {
          var lines = raw.split(/\r?\n/);
          if (lines.length && lines[lines.length - 1] === "") lines.pop();
          var counts = { error: 0, warning: 0, stack: 0, pass: 0, other: 0 };
          var errors = [], warnings = [], i, cls;
          var normAll = {}, dupExtra = 0, longestRep = null;
          for (i = 0; i < lines.length; i++) {
            cls = classify(lines[i]);
            counts[cls]++;
            if (cls === "error") errors.push({ lineNo: i + 1, text: lines[i] });
            if (cls === "warning") warnings.push({ lineNo: i + 1, text: lines[i] });
            if (lines[i].trim() !== "") {
              var k = normalize(lines[i]);
              if (!normAll[k]) normAll[k] = { count: 0, example: lines[i] };
              normAll[k].count++;
            }
          }
          Object.keys(normAll).forEach(function (k) {
            var g = normAll[k];
            if (g.count >= 2) {
              dupExtra += g.count - 1;
              if (!longestRep || g.example.length > longestRep.example.length) longestRep = g;
            }
          });
          var nonEmpty = lines.filter(function (l) { return l.trim() !== ""; }).length;
          var dupPct = nonEmpty ? Math.round((dupExtra / nonEmpty) * 1000) / 10 : 0;

          var errorClusters = clusterLines(errors);
          var warningClusters = clusterLines(warnings);
          warningClusters.sort(function (a, b) { return b.count - a.count || a.first - b.first; });

          var firstFailure = null;
          if (errors.length) {
            var ff = errors[0];
            var context = [], j = ff.lineNo; // lineNo is 1-based; next line index = lineNo
            while (j < lines.length && context.length < 12) {
              if (classify(lines[j]) === "stack") { context.push(lines[j]); j++; }
              else break;
            }
            firstFailure = { lineNo: ff.lineNo, text: ff.text, context: context };
          }
          return {
            totalLines: lines.length,
            chars: raw.length,
            counts: counts,
            errorClusters: errorClusters,
            warningClusters: warningClusters,
            firstFailure: firstFailure,
            dupPct: dupPct,
            dupExtra: dupExtra,
            longestRep: longestRep
          };
        }

        /* ---------- summary text ---------- */
        function buildSummary(a) {
          var out = [];
          out.push("LOG TRIAGE — J-Dawgs Log Flood & First-Failure Triage Bench");
          out.push("Lines: " + fmt(a.totalLines) +
            " | raw log ≈" + fmt(estTokens(a.chars)) + " tokens (chars/4 est)" +
            " | errors: " + a.counts.error + " lines in " + a.errorClusters.length + " clusters" +
            " | warnings: " + a.counts.warning +
            " | duplicate lines: " + a.dupPct + "%");
          out.push("");
          if (a.firstFailure) {
            out.push("FIRST FAILURE (line " + a.firstFailure.lineNo + "):");
            out.push(truncate(a.firstFailure.text.trim(), 220));
            if (includeStack && a.firstFailure.context.length) {
              a.firstFailure.context.forEach(function (f) { out.push("  " + truncate(f.trim(), 200)); });
            }
            out.push('("First" = earliest error, a triage heuristic — not proof of root cause.)');
          } else {
            out.push("NO ERRORS FOUND");
          }
          if (a.errorClusters.length) {
            out.push("");
            out.push("ERROR CLUSTERS (by first appearance):");
            a.errorClusters.slice(0, 10).forEach(function (c, idx) {
              var tag = idx === 0 && a.firstFailure ? "FIRST FAILURE" : "LIKELY FALLOUT";
              if (!a.firstFailure) tag = "";
              out.push((idx + 1) + ". ×" + c.count + " (lines " + c.first + "–" + c.last + ")" +
                (tag ? " [" + tag + "]" : "") + " " + truncate(c.example.trim(), 180));
            });
            if (a.errorClusters.length > 10) out.push("…and " + (a.errorClusters.length - 10) + " more error clusters (see on-page list).");
          }
          out.push("");
          out.push("NOISE:");
          if (a.warningClusters.length) {
            var w = a.warningClusters[0];
            out.push("- Top warning cluster: ×" + w.count + " (lines " + w.first + "–" + w.last + ") " + truncate(w.example.trim(), 140));
            out.push("- Distinct warning clusters: " + a.warningClusters.length);
          } else {
            out.push("- No warnings.");
          }
          if (a.longestRep) {
            out.push("- Longest repeated line: ×" + a.longestRep.count + ", " + a.longestRep.example.length + " chars — " + truncate(a.longestRep.example.trim(), 140));
          }
          out.push("- Duplicates: " + fmt(a.dupExtra) + " repeated lines = " + a.dupPct + "% of the log (exact/near-dup after normalization).");
          var body = out.join("\n");
          var ratio = estTokens(body) > 0 ? Math.max(1, Math.round(estTokens(a.chars) / estTokens(body))) : 0;
          body += "\n\nSIZE: raw ≈" + fmt(estTokens(a.chars)) + " tokens → summary ≈" + fmt(estTokens(body)) + " tokens (about " + ratio + "× smaller). Token counts are chars/4 estimates.";
          return body;
        }
  return { "analyze": (typeof analyze !== 'undefined' ? analyze : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["analyze"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-log-flood-first-failure-triage',
  name: 'J-Dawgs Log Flood & First-Failure Triage Bench',
  description: '',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["analyze"]) return { ok: false, output: null, summary: 'Extracted core has no analyze function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
