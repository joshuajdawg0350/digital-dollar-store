'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs BIND DNS Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

/* ---------- Worked examples ---------- */
var RISKY = [
'// Risky example — review before deploying',
'options {',
'    directory "/var/cache/bind";',
'    recursion yes;',
'    allow-query { any; };',
'    dnssec-validation no;',
'};',
'',
'zone "example.com" {',
'    type master;',
'    file "/etc/bind/db.example.com";',
'    allow-update { any; };',
'};'
].join('\n');

var HARDENED = [
'// Hardened example',
'options {',
'    directory "/var/cache/bind";',
'    recursion no;',
'    allow-query { localhost; };',
'    allow-transfer { 192.0.2.53; key "transfer-key"; };',
'    version "Not currently available";',
'    dnssec-validation auto;',
'    blackhole { 10.0.0.0/8; };',
'    notify explicit;',
'    also-notify { 192.0.2.53; };',
'};',
'',
'zone "example.com" {',
'    type master;',
'    file "/etc/bind/db.example.com";',
'    allow-update { key "update-key"; };',
'};'
].join('\n');

/* ---------- Auditor ---------- */
var KNOWN = {};
("options view zone acl key controls logging server include " +
 "recursion allow-query allow-query-on allow-recursion allow-recursion-on allow-transfer " +
 "allow-update allow-update-forwarding update-policy version dnssec-validation dnssec-enable " +
 "dnssec-lookaside dnssec-must-be-secure allow-new-zones empty-zones-enable empty-contact " +
 "empty-server blackhole notify also-notify notify-explicit notify-source notify-source-v6 " +
 "directory listen-on listen-on-v6 listen-on-port pid-file session-keyfile statistics-file " +
 "dump-file memstatistics-file type file masters forwarders forward allow-notify " +
 "match-clients match-destinations sortlist rrset-order dialup heartbeat-interval " +
 "transfer-format many-answers one-answer use-ixfr provide-ixfr request-ixfr " +
 "max-transfer-time-in max-transfer-time-out max-transfer-idle-in max-transfer-idle-out " +
 "transfer-source transfer-source-v6 query-source query-source-v6 port hostname " +
 "server-id auth-nxdomain minimal-responses minimal-any recursion-on-additional " +
 "allow-query-cache allow-query-cache-on additional-from-auth additional-from-cache " +
 "clients-per-query max-clients-per-query lame-ttl max-ncache-ttl max-cache-ttl " +
 "max-cache-size max-udp-size edns-udp-size tcp-clients resolver-query-timeout " +
 "secret algorithm channel severity print-time print-category print-severity " +
 "file versions size null output facility dynamic log file " +
 "trusted-keys managed-keys bindkeys-file sig-validity-interval " +
 "check-names check-mx check-wildcard check-integrity check-dup-records " +
 "zero-no-soa-ttl max-zone-ttl serial-update-method serial-query-rate " +
 "avoid-v4-udp-ports avoid-v6-udp-ports listen-on-v6-none " +
 "response-padding response-policy qname-minimization resolver-nonbackoff " +
 "stale-answer-enable stale-cache-enable prefetch root-delegation-only " +
 "disable-algorithms disable-ds-digests dnssec-accept-expired validate-except " +
 "auto-dnssec ixfr-from-differences journal max-journal-size " +
 "also-control also-source key-directory managed-keys-directory " +
 "new-zones-directory working-directory named-checkconf named-checkzone " +
 "base deny-answer-addresses deny-answer-aliases exclude excluderange " +
 "localhost localnets none any element category default_debug default_syslog " +
 "master slave hint forward-only forward-first delegation-only stub " +
 "static-stub redirect in-view dnskey-sig-validity nta-lifetime nta-recheck " +
 "catalog-zones allow-recursion-on-additional fetch-glue no-case-compress " +
 "acache-enable acache-cleaning-interval cleaning-interval interface-interval " +
 "statistics-interval zone-statistics coresize datasize stacksize files " +
 "tcp-listen-queue transfers-in transfers-out transfers-per-ns " +
 "transfer-message-size preferred-glue querylog max-retry-time min-retry-time " +
 "max-refresh-time min-refresh-time multi-master ixfr-tmp-file request-nsid " +
 "require-server-cookie server-cookie send-cookie cookie-option " +
 "answer-cookie nocookie-udp-size keep-response-order sortlist-v6 " +
 "top-level-only use-v4-udp-ports use-v6-udp-ports v6-bias glue-cache " +
 "synth-from-dnssec dnsrps-enable dnsrps-options plugin query acl-name " +
 "masters-port masters-dscp dscp in-order-response root-key-sentinel " +
 "check-mx-cname check-spf check-sibling check-in-memory " +
 "disable-empty-zone enable-empty-zone disable-algorithms-zone " +
 "fstrm-set-buffer-hint fstrm-set-flush-timeout fstrm-set-input-queue-size " +
 "fstrm-set-output-notify-threshold fstrm-set-reopen-interval " +
 "dnstap dnscap tap log-queries nta lifetime recheck ipv4only dns64 " +
 "break-dnssec dns64-contact dns64-server lookup parent trust-anchor-file " +
 "initial-key initial-ds trust-anchor negative-trust-anchor static-key static-ds " +
 "response-padding-block-size pad pad-server pad-client").split(/\s+/).forEach(function(w){ if(w) KNOWN[w]=true; });

function stripComments(text){
  var out=[], i=0, inStr=false, inBlock=false, line=text.split('\n');
  // line-based with block-comment state and string awareness
  var res=[];
  var block=false;
  for(var li=0; li<line.length; li++){
    var s=line[li], o='', str=false;
    for(var c=0;c<s.length;c++){
      var ch=s[c], nx=s[c+1]||'';
      if(block){ if(ch==='*'&&nx==='/'){block=false;c++;} continue; }
      if(str){ o+=ch; if(ch==='"') str=false; continue; }
      if(ch==='"'){str=true;o+=ch;continue;}
      if(ch==='/'&&nx==='*'){block=true;c++;continue;}
      if(ch==='/'&&nx==='/'){break;}
      if(ch==='#'){break;}
      o+=ch;
    }
    res.push(o);
  }
  return res; // array of comment-stripped lines
}

function braceDelta(s){
  var d=0, str=false;
  for(var i=0;i<s.length;i++){ var ch=s[i];
    if(str){ if(ch==='"') str=false; continue; }
    if(ch==='"'){str=true;continue;}
    if(ch==='{')d++; if(ch==='}')d--;
  }
  return d;
}
function braceTotals(lines){
  var open=0, close=0;
  lines.forEach(function(s){ var str=false;
    for(var i=0;i<s.length;i++){var ch=s[i];
      if(str){if(ch==='"')str=false;continue;}
      if(ch==='"'){str=true;continue;}
      if(ch==='{')open++; if(ch==='}')close++;
    }});
  return {open:open, close:close};
}

function audit(text){
  var findings=[];
  var rawLines=text.split('\n');
  var lines=stripComments(text);

  /* Collect secret values first so they can be scrubbed from ALL output. */
  var secretValues=[];
  var svRe=/secret\s+"([^"]+)"/g, m;
  while((m=svRe.exec(text))!==null){ if(m[1]) secretValues.push(m[1]); }
  var svRe2=/secret\s+([A-Za-z0-9+/=_-]{8,})\s*;/g;
  while((m=svRe2.exec(text))!==null){ if(m[1]) secretValues.push(m[1]); }

  function scrub(s){
    if(s==null) return s;
    var out=String(s);
    for(var i=0;i<secretValues.length;i++){
      if(secretValues[i]) out=out.split(secretValues[i]).join('[MASKED]');
    }
    out=out.replace(/secret\s+"[^"]*"/gi,'secret "[MASKED]"');
    out=out.replace(/secret\s+"?[A-Za-z0-9+/=_-]{12,}"?/gi,'secret [MASKED]');
    return out;
  }
  function add(sev,line,directive,title,fix,block){
    findings.push({sev:sev,line:line,directive:scrub(directive||''),title:scrub(title),fix:scrub(fix),block:block||''});
  }

  if(!text.trim()){
    return {verdict:'EMPTY', findings:[], notParsed:false, scrub:scrub};
  }

  /* Structure: brace balance */
  var totals=braceTotals(lines);
  var notParsed=false;
  if(totals.open!==totals.close){
    notParsed=true;
    add('BLOCKER', rawLines.length, '',
      'NOT PARSED — unbalanced braces: '+totals.open+' opening "{" vs '+totals.close+' closing "}". The audit cannot trust block boundaries in this file.',
      'Balance every "{" with a matching "}" in each options / view / zone / acl / key block, then re-audit.');
  }
  /* Structure: unterminated statements (chunk ending at } or EOF without ;) */
  (function(){
    var chunk='', chunkLine=1, curLine=1, str=false;
    var full=lines.join('\n');
    function flush(termLine, term){
      var t=chunk.trim();
      if(t && /^[A-Za-z]/.test(t)){
        notParsed=true;
        add('BLOCKER', chunkLine, t.split('\n')[0],
          'NOT PARSED — unterminated statement ending at '+(term==='}'?'a closing brace':'end of file')+' with no ";" (statement began on line '+chunkLine+').',
          'End the statement with a semicolon: named.conf statements are terminated by ";".');
      }
      chunk='';
    }
    for(var i=0;i<full.length;i++){
      var ch=full[i];
      if(ch==='\n'){curLine++; if(chunk) chunk+='\n'; continue;}
      if(str){ chunk+=ch; if(ch==='"') str=false; continue; }
      if(ch==='"'){str=true; chunk+=ch; continue;}
      if(ch===';'){ chunk=''; continue; }
      if(ch==='{'){ chunk=''; continue; }
      if(ch==='}'){ flush(curLine,'}'); chunkLine=curLine; continue; }
      if(!chunk.trim() && /\S/.test(ch)) chunkLine=curLine;
      chunk+=ch;
    }
    flush(curLine,'EOF');
  })();

  /* Context tracking (line-based) */
  var contexts=[]; // {label,startLine,kind,dirs:{}}
  var root={label:'top level',startLine:1,kind:'top',dirs:{}};
  contexts.push(root);
  var stack=[root];
  var depth=0;
  var includes=[], secretsFound=[], unknown={};
  var keyNameNear={}; // line -> enclosing key block name tracked via stack labels

  function currentCtx(){ return stack[stack.length-1]; }
  function record(ctx,name,line,value,raw){
    if(!ctx.dirs[name]) ctx.dirs[name]=[];
    ctx.dirs[name].push({line:line,value:value,raw:raw});
  }
  function braceContent(s){
    var a=s.indexOf('{'), b=s.lastIndexOf('}');
    if(a>=0 && b>a) return s.substring(a+1,b).trim();
    return null;
  }
  function isAny(content){
    if(content==null) return false;
    return /(^|[;\s])any\s*(;|$)/.test(content+' ') || content.trim()==='any' || content.trim()==='any;';
  }
  function hasKeyRef(content){
    return content!=null && /\bkey\s+"/.test(content);
  }

  var blockOpenRe=/^\s*(options|view|zone|acl|key|controls|logging|server)\b\s*("[^"]*")?\s*\{/;
  var dirRe=/^\s*([A-Za-z][A-Za-z0-9-]*)\b/;

  for(var li=0; li<lines.length; li++){
    var lineNo=li+1;
    var s=lines[li];
    var trimmed=s.trim();
    var openMatch=s.match(blockOpenRe);
    var ctx=currentCtx();

    /* include statements */
    var inc=trimmed.match(/^include\s+"([^"]+)"/);
    if(inc){
      includes.push({line:lineNo,file:inc[1]});
      add('INFO',lineNo,rawLines[li].trim(),
        'NOT CHECKED — include file "'+inc[1]+'" is not visible to this audit; its contents were not graded.',
        'Audit the included file separately, or paste its contents in place of the include line and re-audit.');
      record(ctx,'include',lineNo,inc[1],trimmed);
      depth+=braceDelta(s);
      continue;
    }

    /* secrets: flag by key name + line only */
    if(/\bsecret\b/.test(s)){
      var keyName='(unnamed key)';
      for(var si=stack.length-1; si>=0; si--){
        if(stack[si].kind==='key'){ keyName=stack[si].keyName||keyName; break; }
      }
      secretsFound.push({line:lineNo,key:keyName});
      add('INFO',lineNo,'secret "[MASKED]";',
        'Secret present for key "'+keyName+'" on this line — value masked and never shown in this audit or its report.',
        'Keep the secret out of tickets, chats, and repos; rotate it if it has ever been pasted somewhere untrusted.');
    }

    if(openMatch){
      var kind=openMatch[1];
      var label=kind+(openMatch[2]?' '+openMatch[2]:'');
      var nctx={label:label,startLine:lineNo,kind:kind,dirs:{},keyName:openMatch[2]?openMatch[2].replace(/"/g,''):null};
      contexts.push(nctx);
      stack.push(nctx);
      ctx=nctx;
    }

    /* directive recording for known single-line directives */
    var dm=trimmed.match(dirRe);
    if(dm && trimmed[0]!=='}'){
      var dname=dm[1].toLowerCase();
      var val='';
      var bc=braceContent(s);
      if(bc!=null) val=bc;
      else { var vm=trimmed.match(/^[A-Za-z][A-Za-z0-9-]*\s+([^;]+);?\s*$/); if(vm) val=vm[1].trim(); }
      if(KNOWN[dname]) record(ctx,dname,lineNo,val,trimmed);
      else if(!/^(zone|view)$/.test(dname) && trimmed.indexOf('{')!==0){
        // statement-start word we don't know — but skip pure ACL address entries etc.
        if(!unknown[dname]) unknown[dname]={line:lineNo,raw:trimmed};
      }
    }

    depth+=braceDelta(s);
    while(stack.length>1){
      // pop contexts whose block has closed: track via stored depth
      var top=stack[stack.length-1];
      if(top._openDepth==null) top._openDepth=depth; // depth after opening line
      if(depth < top._openDepth){ stack.pop(); } else break;
    }
  }

  /* Unknown directives -> NOT AUDITED */
  Object.keys(unknown).forEach(function(name){
    // Avoid flagging block keywords & comment remnants
    if(KNOWN[name]) return;
    add('INFO', unknown[name].line, unknown[name].raw,
      'NOT AUDITED — directive "'+name+'" is not in this auditor\'s rule set, so it was not graded. No behavior is assumed for it.',
      'Check "'+name+'" against the BIND 9 Administrator Reference Manual for your version before deploying.');
  });

  /* Duplicates: same option twice in one block, last value wins */
  contexts.forEach(function(ctx){
    Object.keys(ctx.dirs).forEach(function(name){
      var occ=ctx.dirs[name];
      if(occ.length>1 && ['recursion','version','dnssec-validation','dnssec-enable','allow-query','allow-recursion','allow-transfer','allow-update','notify','allow-new-zones','empty-zones-enable'].indexOf(name)>=0){
        add('WARNING', occ[occ.length-1].line, occ[occ.length-1].raw,
          'Duplicate "'+name+'" in '+ctx.label+' (lines '+occ.map(function(o){return o.line;}).join(' and ')+'). BIND semantics: the last value wins — line '+occ[occ.length-1].line+' is the one that takes effect.',
          'Delete the losing "'+name+'" statement so the config says what it does in one place.');
      }
    });
  });
  function eff(ctx,name){ var o=ctx.dirs[name]; return o&&o.length?o[o.length-1]:null; }
  function anyDir(name){
    var found=[];
    contexts.forEach(function(c){ (c.dirs[name]||[]).forEach(function(o){found.push({ctx:c,occ:o});}); });
    return found;
  }

  var optionsCtxs=contexts.filter(function(c){return c.kind==='options'||c.kind==='view'||c.kind==='top';});
  var zoneCtxs=contexts.filter(function(c){return c.kind==='zone';});
  var serverLike=optionsCtxs.length?optionsCtxs:[root];

  /* ---- Recursion posture ---- */
  var recFound=anyDir('recursion');
  var authoritativeOnly=false;
  serverLike.forEach(function(c){ var r=eff(c,'recursion'); if(r && /^no\b/.test(r.value)) authoritativeOnly=true; });
  if(!recFound.length){
    add('WARNING',1,'',
      'Recursion is not set anywhere. BIND\'s built-in default applies, and a reader cannot tell the intended posture from this file.',
      'Set "recursion" explicitly — "recursion no;" on authoritative servers, or "recursion yes;" with a restricted allow-recursion list on resolvers.');
  }
  contexts.forEach(function(c){
    var r=eff(c,'recursion'); if(!r) return;
    var aq=eff(c,'allow-query'), ar=eff(c,'allow-recursion');
    if(/^yes\b/.test(r.value)){
      var openList=(aq&&isAny(aq.value))||(ar&&isAny(ar.value));
      var absent=!aq&&!ar;
      if(openList||absent){
        add('BLOCKER', r.line, rawLines[r.line-1].trim(),
          'Open recursive resolver in '+c.label+': "recursion yes" with '+(absent?'no allow-query / allow-recursion restriction at all':'an allow list of { any; }')+'. Anyone on the internet can use this server for DNS amplification abuse.',
          'Restrict recursion to your own networks, e.g. allow-recursion { localhost; localnets; }; — or set "recursion no;" if this server is authoritative-only.');
      } else {
        add('INFO', r.line, rawLines[r.line-1].trim(),
          'Recursion is on in '+c.label+' but restricted by '+(ar?'allow-recursion':'allow-query')+' (named ACLs / explicit networks, not "any"). That is the safer resolver posture.',
          'No change needed. Re-check the ACL contents whenever your networks change.');
      }
    } else if(/^no\b/.test(r.value)){
      add('INFO', r.line, rawLines[r.line-1].trim(),
        'Recursion is off in '+c.label+' — authoritative-only posture. This server will not answer recursive queries for strangers.',
        'No change needed, as long as clients are not pointed at this server as their resolver.');
    }
  });

  /* ---- allow-query { any; } in authoritative-only context ---- */
  contexts.forEach(function(c){
    var aq=eff(c,'allow-query'); if(!aq) return;
    var r=eff(c,'recursion');
    if(isAny(aq.value) && r && /^no\b/.test(r.value)){
      add('WARNING', aq.line, rawLines[aq.line-1].trim(),
        'allow-query { any; } on an authoritative-only server ('+c.label+'). The zones are world-queryable, which is normal for public authoritative service but worth a deliberate decision, and it exposes zone existence to anyone.',
        'If these zones are public, this can stay — note it as a decision. If any zone is internal, restrict allow-query to your networks.');
    }
  });

  /* ---- Zone transfer ---- */
  var atFound=anyDir('allow-transfer');
  if(!atFound.length){
    var anchor=(contexts.filter(function(c){return c.kind==='options';})[0]||root);
    add('BLOCKER', anchor.startLine, '',
      'allow-transfer is not set anywhere. BIND\'s default for allow-transfer is "any" — zone transfers (AXFR) are open to anyone who asks, handing out your full zone contents.',
      'Set allow-transfer to your secondaries only, e.g. allow-transfer { 192.0.2.53; key "transfer-key"; }; — or { none; } if there are no secondaries.');
  } else {
    atFound.forEach(function(f){
      if(isAny(f.occ.value)){
        add('BLOCKER', f.occ.line, rawLines[f.occ.line-1].trim(),
          'allow-transfer { any; } in '+f.ctx.label+' — anyone can pull a full copy of your zones (AXFR).',
          'Restrict allow-transfer to secondary server addresses and/or TSIG keys.');
      }
    });
    var anyBad=atFound.some(function(f){return isAny(f.occ.value);});
    if(!anyBad){
      var f0=atFound[0];
      add('INFO', f0.occ.line, rawLines[f0.occ.line-1].trim(),
        'allow-transfer is restricted in '+f0.ctx.label+' (explicit addresses and/or TSIG keys, not "any"). Zone contents are not handed to strangers.',
        'No change needed. Keep the list in step with your actual secondaries.');
    }
  }

  /* ---- Dynamic updates ---- */
  contexts.forEach(function(c){
    var au=eff(c,'allow-update');
    if(au){
      if(isAny(au.value)){
        add('BLOCKER', au.line, rawLines[au.line-1].trim(),
          'allow-update { any; } in '+c.label+' — unauthenticated dynamic updates: anyone can add, change, or delete records in this zone.',
          'Require a TSIG key, e.g. allow-update { key "update-key"; }; — or use update-policy, or remove allow-update entirely if updates are not needed.');
      } else if(hasKeyRef(au.value)){
        add('INFO', au.line, rawLines[au.line-1].trim(),
          'Dynamic updates in '+c.label+' are key-only (allow-update names a TSIG key). Updates require authentication.',
          'No change needed. Protect the key and rotate it if it is ever exposed.');
      } else if(/^\s*none\s*;?\s*$/.test(au.value)){
        add('INFO', au.line, rawLines[au.line-1].trim(),
          'allow-update { none; } in '+c.label+' — dynamic updates are refused outright.',
          'No change needed.');
      } else {
        add('WARNING', au.line, rawLines[au.line-1].trim(),
          'allow-update in '+c.label+' is restricted by address/ACL rather than by TSIG key. Address-based update permission is weaker than key-based authentication (heuristic: this auditor cannot resolve the ACL named here).',
          'Prefer allow-update { key "update-key"; }; or an update-policy with keys.');
      }
    }
    var up=eff(c,'update-policy');
    if(up){
      add('INFO', up.line, rawLines[up.line-1].trim(),
        'update-policy is present in '+c.label+' — fine-grained, key-based update rules are the controlled way to accept dynamic updates.',
        'No change needed, as long as every rule names a key and the narrowest name/type scope that works.');
    }
  });
  zoneCtxs.forEach(function(c){
    if(!eff(c,'allow-update') && !eff(c,'update-policy')){
      add('INFO', c.startLine, '',
        'Zone '+c.label+' sets no allow-update and no update-policy — BIND\'s default refuses dynamic updates for this zone.',
        'No change needed unless this zone is supposed to accept dynamic updates.');
    }
  });

  /* ---- Notify explicitness ---- */
  var notifyFound=anyDir('notify'), alsoFound=anyDir('also-notify');
  if(!notifyFound.length){
    add('INFO',1,'',
      'notify is not set explicitly. BIND will use its default NOTIFY behavior toward the zone\'s NS records.',
      'Optional: set "notify explicit;" together with also-notify so secondaries learn about changes exactly where you intend.');
  } else {
    var nf=notifyFound[0];
    add('INFO', nf.occ.line, rawLines[nf.occ.line-1].trim(),
      'notify is set explicitly in '+nf.ctx.label+' (value: '+ (nf.occ.value||'yes') +').',
      'No change needed.');
  }
  alsoFound.forEach(function(f){
    add('INFO', f.occ.line, rawLines[f.occ.line-1].trim(),
      'also-notify is set in '+f.ctx.label+' — extra NOTIFY targets are named deliberately.',
      'No change needed. Keep the list in step with your actual secondaries.');
  });

  /* ---- blackhole (INFO only) ---- */
  if(!anyDir('blackhole').length){
    add('INFO',1,'',
      'No blackhole list is set. blackhole is an optional hygiene control: it makes the server silently ignore queries from known-bad source networks.',
      'Optional: add a blackhole ACL for bogon/abuse source ranges if this server faces the internet.');
  }

  /* ---- Version disclosure ---- */
  var versionFound=anyDir('version');
  if(!versionFound.length){
    var vopt=(contexts.filter(function(c){return c.kind==='options';})[0]||root);
    add('WARNING', vopt.startLine, '',
      'version is not set. BIND answers CHAOS-class version.bind queries with its real version string, advertising exactly which build — and which known vulnerabilities — this server runs.',
      'Set version "Not currently available"; (or version none;) in options.');
  } else {
    versionFound.forEach(function(f){
      var v=(f.occ.value||'').trim();
      if(/^none\b/.test(v) || /not currently available/i.test(v) || /^"/.test(v)){
        add('INFO', f.occ.line, rawLines[f.occ.line-1].trim(),
          'Version disclosure is controlled in '+f.ctx.label+' — CHAOS version.bind queries get a hidden/fixed string instead of the real BIND version.',
          'No change needed.');
      }
    });
  }

  /* ---- DNSSEC posture ---- */
  var dvFound=anyDir('dnssec-validation');
  if(!dvFound.length){
    add('INFO',1,'',
      'dnssec-validation is not set. BIND\'s compiled default applies (auto on current BIND 9 builds), but the posture is not stated in the file.',
      'Optional but clearer: set dnssec-validation auto; explicitly.');
  } else {
    dvFound.forEach(function(f){
      var v=(f.occ.value||'').trim().toLowerCase();
      if(/^no\b/.test(v)){
        add('WARNING', f.occ.line, rawLines[f.occ.line-1].trim(),
          'dnssec-validation is "no" in '+f.ctx.label+' — this resolver will not validate DNSSEC signatures, so spoofed signed data is accepted on trust.',
          'Set dnssec-validation auto; (with a managed trust anchor) or dnssec-validation yes;.');
      } else {
        add('INFO', f.occ.line, rawLines[f.occ.line-1].trim(),
          'dnssec-validation is "'+v+'" in '+f.ctx.label+' — DNSSEC validation is enabled.',
          'No change needed.');
      }
    });
  }
  anyDir('dnssec-enable').forEach(function(f){
    add('INFO', f.occ.line, rawLines[f.occ.line-1].trim(),
      'Legacy directive dnssec-enable appears in '+f.ctx.label+'. It is a pre-9.10-era switch and is ignored/removed on current BIND — heuristic note, verify against your BIND version.',
      'Drop dnssec-enable and control the behavior with dnssec-validation instead.');
  });

  /* ---- Dangerous conveniences (heuristic) ---- */
  anyDir('allow-new-zones').forEach(function(f){
    if(/^yes\b/i.test((f.occ.value||'').trim())){
      add('WARNING', f.occ.line, rawLines[f.occ.line-1].trim(),
        'allow-new-zones yes in '+f.ctx.label+' (heuristic): rndc addzone is enabled, so anyone holding the rndc key can create zones on this server at runtime.',
        'Set allow-new-zones no; unless runtime zone creation is an operational requirement, and protect the rndc key accordingly.');
    } else {
      add('INFO', f.occ.line, rawLines[f.occ.line-1].trim(),
        'allow-new-zones is off in '+f.ctx.label+' — zones cannot be created at runtime via rndc.',
        'No change needed.');
    }
  });
  anyDir('empty-zones-enable').forEach(function(f){
    if(/^no\b/i.test((f.occ.value||'').trim())){
      add('WARNING', f.occ.line, rawLines[f.occ.line-1].trim(),
        'empty-zones-enable no in '+f.ctx.label+' (heuristic): automatic empty zones are disabled, so queries for private/undelegated ranges (RFC 1918 reverse space, etc.) may leak upstream instead of being answered locally.',
        'Leave empty-zones-enable at its default (yes) unless you deliberately serve those ranges another way.');
    } else {
      add('INFO', f.occ.line, rawLines[f.occ.line-1].trim(),
        'empty-zones-enable is on in '+f.ctx.label+' — automatic empty zones stay enabled, keeping private-range queries from leaking upstream.',
        'No change needed.');
    }
  });

  /* sort: BLOCKER, WARNING, INFO; then line */
  var order={BLOCKER:0,WARNING:1,INFO:2};
  findings.sort(function(a,b){ return order[a.sev]-order[b.sev] || a.line-b.line; });

  var hasBlocker=findings.some(function(f){return f.sev==='BLOCKER';});
  var hasWarn=findings.some(function(f){return f.sev==='WARNING';});
  var verdict= hasBlocker ? 'DO_NOT_DEPLOY' : (hasWarn ? 'DEPLOY_WITH_FIXES' : 'SAFE_TO_DEPLOY');
  return {verdict:verdict, findings:findings, notParsed:notParsed, scrub:scrub,
          counts:{b:findings.filter(function(f){return f.sev==='BLOCKER';}).length,
                  w:findings.filter(function(f){return f.sev==='WARNING';}).length,
                  i:findings.filter(function(f){return f.sev==='INFO';}).length}};
}
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-bind-dns-server-config-safety-auditortm',
  name: 'J-Dawgs BIND DNS Server Config Safety Auditor',
  description: 'Paste a BIND named.conf, get one deploy verdict: open recursion, zone-transfer defaults, unauthenticated updates, version disclosure and DNSSEC graded line by line — named-checkconf only tells you the file loads.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
