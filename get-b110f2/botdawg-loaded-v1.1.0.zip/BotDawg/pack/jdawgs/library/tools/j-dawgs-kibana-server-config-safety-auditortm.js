'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Kibana Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var RISKY_EXAMPLE = [
          "# Kibana \u2014 production (risky example)",
          "server.port: 5601",
          'server.host: "0.0.0.0"',
          'server.name: "kibana-prod-01"',
          "server.ssl.enabled: false",
          'server.publicBaseUrl: "http://kibana.example.internal:5601"',
          'elasticsearch.hosts: ["http://es-node-01.internal:9200", "http://es-node-02.internal:9200"]',
          'elasticsearch.username: "kibana_system"',
          'elasticsearch.password: "Tr7!falcon-ridge-92"',
          "elasticsearch.ssl.verificationMode: none",
          "xpack.security.enabled: false",
          'xpack.encryptedSavedObjects.encryptionKey: "shortkey123"',
          'xpack.reporting.encryptionKey: "changeme"',
          "logging.root.level: debug",
          "xpack.monitoring.collection.enabled: true"
        ].join("\n");

        var HARDENED_EXAMPLE = [
          "# Kibana \u2014 production (hardened example)",
          "server.port: 5601",
          'server.host: "localhost"',
          'server.name: "kibana-prod-01"',
          "server.ssl.enabled: true",
          'server.ssl.certificate: "/etc/kibana/certs/kibana.crt"',
          'server.ssl.key: "/etc/kibana/certs/kibana.key"',
          'server.publicBaseUrl: "https://kibana.example.com"',
          'elasticsearch.hosts: ["https://es-node-01.internal:9200", "https://es-node-02.internal:9200"]',
          "elasticsearch.ssl.verificationMode: full",
          'elasticsearch.ssl.certificateAuthorities: ["/etc/kibana/certs/es-ca.crt"]',
          "xpack.security.enabled: true",
          'xpack.encryptedSavedObjects.encryptionKey: "g9K2xQ7pL4mN8vR1sT6wY3zA5bC0dEfH"',
          'xpack.reporting.encryptionKey: "h8J3kM6nP9qR2sT5vW8xY1zA4bC7dEgF"',
          "logging.root.level: info"
        ].join("\n");

        var RECOGNIZED_TOP = {
          server: 1, elasticsearch: 1, xpack: 1, logging: 1, kibana: 1,
          telemetry: 1, monitoring: 1, apm: 1, canvas: 1, csp: 1, data: 1,
          i18n: 1, ops: 1, path: 1, pid: 1, uisettings: 1, newsfeed: 1,
          management: 1, savedobjects: 1, features: 1, vis: 1, timelion: 1,
          dev: 1, embeddable: 1, node: 1, migrations: 1
        };
        var LOCAL_HOSTS = { localhost: 1, "127.0.0.1": 1, "::1": 1, "[::1]": 1 };
        var ALL_INTERFACES = { "0.0.0.0": 1, "::": 1, "[::]": 1, "*": 1 };
        var PLACEHOLDER_HINTS = ["changeme", "change_me", "change-me", "placeholder", "your_", "your-", "yourkey", "example", "todo", "replace", "xxxx", "000000", "password", "letmein", "defaultkey"];
        var SEV_RANK = { BLOCKER: 0, HIGH: 1, WARNING: 2, INFO: 3 };

        function parseScalar(raw) {
          var s = (raw || "").trim();
          if (!s) return "";
          var q = s.charAt(0);
          if (q === '"' || q === "'") {
            var end = s.indexOf(q, 1);
            if (end > 0) return s.slice(1, end);
            return s.slice(1);
          }
          var hash = s.indexOf(" #");
          if (hash >= 0) s = s.slice(0, hash);
          return s.trim();
        }

        function parseConfig(text) {
          var entries = [];
          var lines = String(text || "").split(/\r?\n/);
          var currentKey = null;
          for (var i = 0; i < lines.length; i++) {
            var raw = lines[i];
            var lineNo = i + 1;
            var trimmed = raw.trim();
            if (!trimmed || trimmed.charAt(0) === "#") continue;
            var listMatch = raw.match(/^\s*-\s+(.+)$/);
            if (listMatch && currentKey) {
              entries.push({ key: currentKey, baseKey: currentKey, value: parseScalar(listMatch[1]), raw: listMatch[1].trim(), line: lineNo, listItem: true });
              continue;
            }
            var m = raw.match(/^\s*([A-Za-z0-9_.\-]+)\s*:\s*(.*)$/);
            if (m) {
              var key = m[1].toLowerCase();
              currentKey = key;
              entries.push({ key: key, baseKey: key, value: parseScalar(m[2]), raw: (m[2] || "").trim(), line: lineNo, listItem: false });
            }
          }
          return { entries: entries, lineCount: lines.length };
        }

        function isRecognized(key) {
          var top = key.split(".")[0];
          return !!RECOGNIZED_TOP[top];
        }

        function firstEntry(entries, key) {
          for (var i = 0; i < entries.length; i++) {
            if (entries[i].key === key && !entries[i].listItem) return entries[i];
          }
          return null;
        }

        function hostOfUrl(url) {
          var m = String(url).match(/^[a-z][a-z0-9+.-]*:\/\/([^/:?#]+)/i);
          return m ? m[1].toLowerCase() : "";
        }

        function isPlaceholder(value) {
          var v = String(value || "").toLowerCase();
          if (!v) return false;
          for (var i = 0; i < PLACEHOLDER_HINTS.length; i++) {
            if (v.indexOf(PLACEHOLDER_HINTS[i]) >= 0) return true;
          }
          if (/^(.)\1+$/.test(v)) return true;
          return false;
        }

        function collectEsHosts(entries) {
          var hosts = [];
          for (var i = 0; i < entries.length; i++) {
            var e = entries[i];
            if (e.baseKey !== "elasticsearch.hosts") continue;
            var text = e.listItem ? e.value : e.raw;
            var urls = String(text).match(/https?:\/\/[^\s"',\]]+/gi) || [];
            for (var j = 0; j < urls.length; j++) hosts.push({ url: urls[j], line: e.line });
            if (e.listItem && !urls.length && e.value) hosts.push({ url: e.value, line: e.line });
          }
          return hosts;
        }

        function auditConfig(text) {
          var parsed = parseConfig(text);
          var entries = parsed.entries;
          var recognizedCount = 0;
          var i, e;
          for (i = 0; i < entries.length; i++) if (isRecognized(entries[i].baseKey)) recognizedCount++;

          var result = {
            verdict: "NOT ENOUGH TO GRADE",
            counts: { BLOCKER: 0, HIGH: 0, WARNING: 0, INFO: 0 },
            findings: [],
            lineCount: parsed.lineCount,
            keyCount: recognizedCount,
            recognized: recognizedCount > 0
          };
          if (!result.recognized) return result;

          var findings = [];
          function add(sev, line, key, title, detail, fix) {
            findings.push({ severity: sev, line: line, key: key, title: title, detail: detail, fix: fix });
          }

          var hostEntry = firstEntry(entries, "server.host");
          var hostVal = hostEntry ? hostEntry.value.trim() : "";
          var hostLower = hostVal.toLowerCase();
          var allInterfaces = !!ALL_INTERFACES[hostLower];
          var boundBeyondLocal = !!hostEntry && !LOCAL_HOSTS[hostLower];

          var sslEntry = firstEntry(entries, "server.ssl.enabled");
          var tlsEnabled = !!sslEntry && sslEntry.value.trim().toLowerCase() === "true";
          var tlsOffOrAbsent = !tlsEnabled;

          var secEntry = firstEntry(entries, "xpack.security.enabled");
          var securityDisabled = !!secEntry && secEntry.value.trim().toLowerCase() === "false";

          // --- server.host exposure ---
          if (hostEntry && allInterfaces) {
            if (tlsOffOrAbsent || securityDisabled) {
              var reasons = [];
              if (tlsOffOrAbsent) reasons.push("TLS is disabled or not configured");
              if (securityDisabled) reasons.push("the security plugin is disabled");
              add("BLOCKER", hostEntry.line, "server.host",
                "Kibana is bound to all network interfaces with no safety net",
                "server.host is \"" + hostVal + "\", so Kibana listens on every interface \u2014 and " + reasons.join(" and ") + ". Anyone who can reach this port reaches the login-less, unencrypted UI.",
                "Bind Kibana to a specific interface (or localhost behind a reverse proxy), enable server.ssl, and keep xpack.security enabled before this host touches a network.");
            } else {
              add("HIGH", hostEntry.line, "server.host",
                "Kibana is bound to all network interfaces",
                "server.host is \"" + hostVal + "\", so Kibana listens on every interface, not just localhost. That is only safe if the network in front of it is fully trusted and firewalled.",
                "Prefer a specific interface or localhost behind a reverse proxy; if all-interfaces binding is required, confirm firewall rules restrict port access to intended clients.");
            }
          }

          // --- server TLS ---
          if (boundBeyondLocal && tlsOffOrAbsent) {
            add("HIGH", sslEntry ? sslEntry.line : hostEntry.line, "server.ssl.enabled",
              sslEntry ? "Kibana TLS is disabled while bound beyond localhost" : "Kibana TLS is not configured while bound beyond localhost",
              "Kibana is reachable beyond this machine, but server.ssl.enabled is " + (sslEntry ? "set to false" : "absent") + ", so browser traffic \u2014 including sessions and any credentials typed into it \u2014 travels in plain http.",
              "Set server.ssl.enabled: true with server.ssl.certificate and server.ssl.key, or bind Kibana to localhost and terminate TLS at a reverse proxy in front of it.");
          }
          if (tlsEnabled) {
            var certEntry = firstEntry(entries, "server.ssl.certificate");
            var keyEntry = firstEntry(entries, "server.ssl.key");
            if (!certEntry || !keyEntry) {
              add("WARNING", sslEntry.line, "server.ssl.certificate",
                "TLS is enabled but no certificate/key pair is configured in the file",
                "server.ssl.enabled is true, but " + (!certEntry && !keyEntry ? "neither server.ssl.certificate nor server.ssl.key is set" : (!certEntry ? "server.ssl.certificate is not set" : "server.ssl.key is not set")) + " in the pasted config. The pair may live in the keystore or another included file \u2014 this audit can only grade what was pasted.",
                "Set server.ssl.certificate and server.ssl.key to the Kibana certificate and private key, or confirm the pair is supplied by your keystore or config includes.");
            }
          }

          // --- security plugin ---
          if (securityDisabled) {
            add("BLOCKER", secEntry.line, "xpack.security.enabled",
              "The security plugin is disabled \u2014 authentication is off",
              "xpack.security.enabled is false, so Kibana serves dashboards and data with no login, no roles, and no audit trail. Combined with any network exposure this is an open door, not a setting.",
              "Set xpack.security.enabled: true (or remove the line \u2014 current Kibana enables security by default) and configure users/roles before deploying.");
          }

          // --- public base URL ---
          var pbuEntry = firstEntry(entries, "server.publicbaseurl");
          if (!pbuEntry) {
            add("WARNING", null, "server.publicBaseUrl",
              "server.publicBaseUrl is not set",
              "Without server.publicBaseUrl, Kibana guesses its public address. Behind a proxy or on a non-default port, generated links, alerts, and share URLs can point at the wrong host or scheme.",
              "Set server.publicBaseUrl to the exact https:// address users and agents use to reach this Kibana.");
          } else if (/^http:\/\//i.test(pbuEntry.value.trim())) {
            add("HIGH", pbuEntry.line, "server.publicBaseUrl",
              "server.publicBaseUrl uses plain http://",
              "The public address Kibana advertises is \"" + pbuEntry.value.trim() + "\" \u2014 plain http. Links, redirects, and embedded URLs inherit the unencrypted scheme even if a proxy upgrades some traffic.",
              "Serve Kibana over https and set server.publicBaseUrl to the https:// address.");
          }

          // --- elasticsearch hosts transport ---
          var esHosts = collectEsHosts(entries);
          var hostsEntry = firstEntry(entries, "elasticsearch.hosts");
          var httpHosts = [];
          var httpLine = null;
          var seenHttpHosts = {};
          for (i = 0; i < esHosts.length; i++) {
            var h = esHosts[i];
            if (/^http:\/\//i.test(h.url) && !LOCAL_HOSTS[hostOfUrl(h.url)] && !seenHttpHosts[h.url]) {
              seenHttpHosts[h.url] = 1;
              httpHosts.push(h.url);
              if (httpLine === null) httpLine = h.line;
            }
          }
          if (httpHosts.length) {
            add("HIGH", httpLine, "elasticsearch.hosts",
              "Elasticsearch is reached over plain http://",
              "elasticsearch.hosts points at non-localhost host" + (httpHosts.length === 1 ? "" : "s") + " over plain http: " + httpHosts.join(", ") + ". Kibana-to-Elasticsearch traffic \u2014 queries, results, and the service credentials \u2014 crosses the network unencrypted.",
              "Enable TLS on the Elasticsearch HTTP layer and point elasticsearch.hosts at the https:// addresses, with elasticsearch.ssl.certificateAuthorities set.");
          }

          // --- elasticsearch ssl verification ---
          var vmEntry = firstEntry(entries, "elasticsearch.ssl.verificationmode");
          if (vmEntry) {
            var vm = vmEntry.value.trim().toLowerCase();
            if (vm === "none") {
              add("BLOCKER", vmEntry.line, "elasticsearch.ssl.verificationMode",
                "Elasticsearch certificate verification is turned off",
                "elasticsearch.ssl.verificationMode is \"none\", so Kibana accepts any certificate from anything claiming to be Elasticsearch. TLS without verification stops casual snooping and nothing else.",
                "Set elasticsearch.ssl.verificationMode to \"full\" (or \"certificate\" only as a deliberate, documented exception) and configure elasticsearch.ssl.certificateAuthorities.");
            } else if (vm === "certificate") {
              add("WARNING", vmEntry.line, "elasticsearch.ssl.verificationMode",
                "Elasticsearch hostname verification is skipped",
                "verificationMode \"certificate\" checks the certificate chain but not that the certificate matches the host Kibana dialed. That is weaker than \"full\" and should be a deliberate choice, not a leftover.",
                "Use verificationMode \"full\" with certificates that carry the correct hostnames, and keep \"certificate\" only where a documented constraint requires it.");
            }
          }
          var caEntry = firstEntry(entries, "elasticsearch.ssl.certificateauthorities");
          var hasHttpsHost = false;
          for (i = 0; i < esHosts.length; i++) if (/^https:\/\//i.test(esHosts[i].url)) hasHttpsHost = true;
          if (hasHttpsHost && !caEntry) {
            add("WARNING", hostsEntry ? hostsEntry.line : null, "elasticsearch.ssl.certificateAuthorities",
              "https Elasticsearch hosts but no certificate authority configured",
              "elasticsearch.hosts uses https://, but elasticsearch.ssl.certificateAuthorities is not set in the pasted config. Against a private-CA cluster this fails verification; against a public CA it relies on the system trust store, which may not be what you intended.",
              "Set elasticsearch.ssl.certificateAuthorities to the Elasticsearch CA certificate (or the keystore equivalent) so the trust decision is explicit.");
          }

          // --- plaintext elasticsearch credentials (values never rendered) ---
          var credKeys = ["elasticsearch.username", "elasticsearch.password"];
          for (i = 0; i < credKeys.length; i++) {
            var ce = firstEntry(entries, credKeys[i]);
            if (ce && ce.value && ce.value.indexOf("${") !== 0) {
              add("HIGH", ce.line, credKeys[i],
                "Plaintext Elasticsearch credential sits in the config file",
                credKeys[i] + " is set directly in kibana.yml (value length: " + ce.value.length + " characters \u2014 the value is never shown by this tool). Anyone or any agent that can read this file, a backup of it, or a paste of it has working Elasticsearch credentials.",
                "Move the credential into the Kibana keystore (kibana-keystore add " + credKeys[i] + ") or your secrets manager, remove it from the file, and rotate it \u2014 it has already lived in plaintext.");
            }
          }

          // --- encryption keys (values never rendered) ---
          var encKeys = [
            { key: "xpack.encryptedsavedobjects.encryptionkey", label: "xpack.encryptedSavedObjects.encryptionKey", shortSev: "BLOCKER", purpose: "saved objects" },
            { key: "xpack.reporting.encryptionkey", label: "xpack.reporting.encryptionKey", shortSev: "HIGH", purpose: "reporting" }
          ];
          for (i = 0; i < encKeys.length; i++) {
            var spec = encKeys[i];
            var ke = firstEntry(entries, spec.key);
            if (!ke || !ke.value) {
              add("WARNING", ke ? ke.line : null, spec.label,
                spec.label + " is not set",
                "With no " + spec.purpose + " encryption key in the file, Kibana generates one at startup. Encrypted " + spec.purpose + " data then cannot be read after a restart or by another node with a different generated key, and the failure surfaces later, at read time.",
                "Set " + spec.label + " to a random value of at least 32 characters, the same on every node, stored with your other secrets \u2014 not invented per machine.");
            } else if (isPlaceholder(ke.value)) {
              add("BLOCKER", ke.line, spec.label,
                spec.label + " is a placeholder value",
                spec.label + " is set to a placeholder-style value (length: " + ke.value.length + " characters \u2014 value not shown). A guessed key is no key: anyone who has seen a tutorial has seen this one, and " + spec.purpose + " encryption under it is decoration.",
                "Replace it with a genuinely random value of at least 32 characters, unique to this deployment, and store it in your secrets manager.");
            } else if (ke.value.length < 32) {
              add(spec.shortSev, ke.line, spec.label,
                spec.label + " is too short",
                spec.label + " is only " + ke.value.length + " characters (value not shown); Kibana expects at least 32. Short keys are brute-forceable and signal the value was typed, not generated.",
                "Generate a random value of at least 32 characters for " + spec.label + ", identical on every node, and store it with your secrets.");
            }
          }

          // --- logging posture ---
          for (i = 0; i < entries.length; i++) {
            e = entries[i];
            if (e.listItem) continue;
            var lv = e.value.trim().toLowerCase();
            if ((e.key === "logging.root.level" || e.key === "logging.level" || /logging\..*\.level$/.test(e.key)) && (lv === "debug" || lv === "verbose" || lv === "all" || lv === "trace")) {
              add("WARNING", e.line, e.key,
                "Debug-level logging is on",
                e.key + " is set to \"" + lv + "\". Debug and verbose logs can record request details, headers, and query content \u2014 useful on a bench, a liability in production storage.",
                "Run production at info level (logging.root.level: info) and raise verbosity temporarily, per-logger, while debugging.");
            }
            if (e.key === "logging.verbose" && lv === "true") {
              add("WARNING", e.line, e.key,
                "Verbose logging is on",
                "logging.verbose is true (the legacy switch). Verbose logs can record request detail that has no business in production log storage.",
                "Set logging.verbose to false for production and use targeted logger levels while debugging.");
            }
          }

          // --- legacy families (INFO, once per family) ---
          var legacy = [
            { prefix: "xpack.monitoring", name: "xpack.monitoring", note: "Legacy monitoring settings are present. Current Kibana versions collect monitoring data through Elastic Agent / Metricbeat rather than these keys, so they may be silently ignored while looking authoritative.", fix: "Confirm how this cluster is monitored today and remove or update the stale xpack.monitoring keys so the file describes reality." },
            { prefix: "xpack.apm", name: "xpack.apm", note: "Legacy APM settings are present. APM configuration for current Kibana lives with the APM integration and Fleet policies, not these keys, so they may not do what the file suggests.", fix: "Move APM configuration to the current integration settings and drop the legacy xpack.apm keys." },
            { prefix: "xpack.canvas", name: "xpack.canvas", note: "Canvas settings are present. Canvas is a legacy feature in current Kibana releases; settings for it deserve a second look before they ride into a new deployment.", fix: "Confirm Canvas is still used on this deployment; if it is not, remove the xpack.canvas keys." }
          ];
          for (var f = 0; f < legacy.length; f++) {
            for (i = 0; i < entries.length; i++) {
              if (entries[i].baseKey.indexOf(legacy[f].prefix) === 0) {
                add("INFO", entries[i].line, legacy[f].name, legacy[f].name + " settings noted", legacy[f].note, legacy[f].fix);
                break;
              }
            }
          }

          findings.sort(function (a, b) {
            var r = SEV_RANK[a.severity] - SEV_RANK[b.severity];
            if (r !== 0) return r;
            var la = a.line === null ? 99999 : a.line;
            var lb = b.line === null ? 99999 : b.line;
            return la - lb;
          });

          result.findings = findings;
          for (i = 0; i < findings.length; i++) result.counts[findings[i].severity]++;

          if (result.counts.BLOCKER > 0) result.verdict = "DO NOT DEPLOY";
          else if (result.counts.HIGH > 0 || result.counts.WARNING > 0) result.verdict = "DEPLOY WITH FIXES";
          else result.verdict = "SAFE TO DEPLOY";
          return result;
        }

        function verdictClass(v) {
          if (v === "SAFE TO DEPLOY") return "verdict safe";
          if (v === "DEPLOY WITH FIXES") return "verdict fixes";
          if (v === "DO NOT DEPLOY") return "verdict danger";
          return "verdict neutral";
        }

        function verdictWhy(r) {
          if (r.verdict === "NOT ENOUGH TO GRADE") {
            return "No recognizable Kibana settings were found in the paste, so there is nothing honest to grade. Paste the contents of a kibana.yml \u2014 lines like server.host, elasticsearch.hosts, or xpack.security.enabled \u2014 and run the audit again.";
          }
          if (r.verdict === "DO NOT DEPLOY") {
            return "Blocking problems are present \u2014 at least one finding would leave this Kibana exposed, unauthenticated, or trusting an unverified connection. Fix every BLOCKER before this config ships.";
          }
          if (r.verdict === "DEPLOY WITH FIXES") {
            return "Nothing here is an open door by itself, but the findings below are real weaknesses or footguns. Fix the HIGH and WARNING items, then re-audit.";
          }
          return "No blocking, high, or warning findings in the pasted config. This grades the pasted text only \u2014 it is not a promise that Kibana will start, or that controls outside the file (keystore, proxy, firewall) are set the way you think they are.";
        }

        function buildReport(r) {
          var out = [];
          out.push("J-Dawgs Kibana Server Config Safety Auditor\u2122 \u2014 audit report");
          out.push("Verdict: " + r.verdict);
          out.push("Counts: BLOCKER " + r.counts.BLOCKER + " \u00b7 HIGH " + r.counts.HIGH + " \u00b7 WARNING " + r.counts.WARNING + " \u00b7 INFO " + r.counts.INFO);
          out.push("Scanned: " + r.lineCount + " lines, " + r.keyCount + " recognized Kibana settings.");
          out.push("Note: heuristic text audit of pasted text only. It does not connect to any server and does not verify the config loads. Secret values are reported by key name, line, and length only.");
          out.push("");
          if (!r.findings.length) {
            out.push(r.verdict === "NOT ENOUGH TO GRADE" ? "No findings \u2014 nothing recognizable to grade." : "No findings.");
          } else {
            out.push("Findings:");
            for (var i = 0; i < r.findings.length; i++) {
              var f = r.findings[i];
              out.push("");
              out.push((i + 1) + ". [" + f.severity + "] " + (f.line === null ? "Setting absent" : "Line " + f.line) + " \u2014 " + f.key + ": " + f.title);
              out.push("   " + f.detail);
              out.push("   Fix: " + f.fix);
            }
          }
          return out.join("\n");
        }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-kibana-server-config-safety-auditortm',
  name: 'J-Dawgs Kibana Server Config Safety Auditor',
  description: 'Grades a pasted kibana.yml offline into one deploy verdict. Kibana startup only answers will-it-start; ours also grades all-interface binding, TLS, xpack.security, and plaintext Elasticsearch credentials — by key name, line, and length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
