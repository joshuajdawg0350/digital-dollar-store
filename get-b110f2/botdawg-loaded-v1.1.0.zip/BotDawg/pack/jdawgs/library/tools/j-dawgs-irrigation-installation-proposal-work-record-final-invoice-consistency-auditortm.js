'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Irrigation Installation Proposal, Work Record & Final Invoice Consistency Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- helpers ---------- */
      function $(id){ return document.getElementById(id); }
      function round2(n){ return Math.round(n*100)/100; }
      function fmt(n){
        var neg = n < 0; n = Math.abs(round2(n));
        var s = n.toFixed(2), parts = s.split(".");
        parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        return (neg ? "-$" : "$") + parts[0] + "." + parts[1];
      }
      function esc(s){
        return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
      }
      function qtyFmt(n){ return (Math.round(n*100)/100).toString(); }

      /* ---------- text extraction ---------- */
      // All money amounts on a line: [{value, raw}]
      function amountsIn(line){
        var out = [], re = /(-)?\s*\$\s*(-)?([\d,]+(?:\.\d{1,2})?)/g, m;
        while((m = re.exec(line)) !== null){
          var v = parseFloat(m[3].replace(/,/g,""));
          if(m[1] || m[2]) v = -v;
          if(/\(\s*$/.test(line.slice(0, m.index))) v = -Math.abs(v);
          out.push({ value: round2(v), raw: m[0] });
        }
        return out;
      }
      // "8 zones × $120.00" / "18 hours x $85.00"
      function qtyPriceIn(line){
        var m = line.match(/(\d+(?:\.\d+)?)\s*(?:zones?|heads?|rotors?|ft|feet|foot|hours?|hrs?|units?|ea)?\s*[x×]\s*\$?\s*([\d,]+(?:\.\d{1,2})?)/i);
        if(!m) return null;
        return { qty: parseFloat(m[1]), price: parseFloat(m[2].replace(/,/g,"")) };
      }
      function categoryOf(lower){
        if(/deposit/.test(lower)) return "deposit";
        if(/labou?r/.test(lower)) return "labor";
        if(/zone/.test(lower)) return "zones";
        if(/rotor/.test(lower)) return "rotors";
        if(/drip/.test(lower)) return "drip";
        if(/head/.test(lower)) return "heads";
        if(/controller/.test(lower)) return "controller";
        return "other";
      }
      function qtyInLine(line, cat){
        var m = null, lower = line.toLowerCase();
        if(cat === "zones") m = lower.match(/(\d+(?:\.\d+)?)\s*zones?/);
        else if(cat === "heads") m = lower.match(/(\d+(?:\.\d+)?)\s*(?:spray\s+)?heads?/);
        else if(cat === "rotors") m = lower.match(/(\d+(?:\.\d+)?)\s*rotors?/);
        else if(cat === "drip") m = lower.match(/(\d+(?:\.\d+)?)\s*(?:ft|feet|foot)\b/);
        else if(cat === "labor") m = lower.match(/(\d+(?:\.\d+)?)\s*(?:hours?|hrs?)\b/);
        if(m) return parseFloat(m[1]);
        var qp = qtyPriceIn(line);
        return qp ? qp.qty : null;
      }
      // First quantity for a category found anywhere in a document.
      function docQuantity(text, cat){
        var lines = text.split(/\r?\n/);
        for(var i = 0; i < lines.length; i++){
          var lower = lines[i].toLowerCase();
          var hit = (cat === "zones" && /zone/.test(lower)) || (cat === "heads" && /head/.test(lower)) ||
                    (cat === "rotors" && /rotor/.test(lower)) || (cat === "drip" && /drip/.test(lower)) ||
                    (cat === "labor" && /(hour|hr\b|labou?r)/.test(lower));
          if(!hit) continue;
          var q = qtyInLine(lines[i], cat);
          if(q !== null) return { qty: q, line: i + 1, raw: lines[i].trim() };
        }
        return null;
      }
      function docDeposit(text){
        var lines = text.split(/\r?\n/);
        for(var i = 0; i < lines.length; i++){
          if(/deposit/i.test(lines[i])){
            var a = amountsIn(lines[i]);
            if(a.length) return { amount: Math.abs(a[0].value), line: i + 1, raw: lines[i].trim() };
          }
        }
        return null;
      }
      function laborRate(text){
        var lines = text.split(/\r?\n/);
        for(var i = 0; i < lines.length; i++){
          var lower = lines[i].toLowerCase();
          if(/per\s*hour|\/\s*(hr|hour)|hourly|rate/.test(lower) && /labou?r|hour|rate/.test(lower)){
            var a = amountsIn(lines[i]);
            if(a.length) return { rate: Math.abs(a[0].value), line: i + 1 };
          }
        }
        return null;
      }
      function controllerModel(text){
        var lines = text.split(/\r?\n/);
        for(var i = 0; i < lines.length; i++){
          if(!/controller/i.test(lines[i]) || /fee/i.test(lines[i])) continue;
          var s = lines[i].replace(/^\s*[-•*]\s*/, "");
          s = s.replace(/\$\s*-?[\d,]+(?:\.\d{1,2})?/g, " ");
          s = s.replace(/controller/gi, " ");
          s = s.replace(/\b(installed|proposed|includes?|with|new|the)\b/gi, " ");
          s = s.replace(/[():]/g, " ").replace(/[—–]/g, " ").replace(/=/g, " ");
          s = s.replace(/\s+/g, " ").trim().replace(/^-+\s*/, "").replace(/\s*-+$/, "").trim();
          if(s) return { model: s, line: i + 1 };
        }
        return null;
      }
      function normalizeLabel(line){
        var s = line.replace(/^\s*[-•*]\s*/, "");
        s = s.replace(/-?\s*\$\s*-?[\d,]+(?:\.\d{1,2})?/g, " ");
        s = s.replace(/\d+(?:\.\d+)?\s*[x×]\s*/g, " ");
        s = s.replace(/=.*$/, " ");
        s = s.toLowerCase().replace(/[^a-z]+/g, " ").replace(/\s+/g, " ").trim();
        return s;
      }
      function significantWords(line){
        var stop = {each:true,with:true,fee:true,fees:true,charge:true,charges:true,surcharge:true,
          total:true,line:true,item:true,items:true,service:true,services:true,installed:true,
          zone:true,zones:true,head:true,heads:true,rotor:true,rotors:true,drip:true,
          controller:true,labor:true,labour:true,hours:true,hour:true};
        var words = normalizeLabel(line).split(" "), out = [];
        for(var i = 0; i < words.length; i++){
          if(words[i].length >= 4 && !stop[words[i]]) out.push(words[i]);
        }
        return out;
      }

      /* ---------- invoice parsing ---------- */
      function parseInvoice(text){
        var lines = text.split(/\r?\n/), items = [], totalLine = null, subtotalLine = null;
        lines.forEach(function(raw, i){
          var line = raw.trim();
          if(!line) return;
          var amounts = amountsIn(line);
          if(!amounts.length) return;
          var lower = line.toLowerCase();
          var isSubtotal = /subtotal/.test(lower);
          var isTotal = !isSubtotal && /(grand\s+total|total\s+due|total|balance\s+due|amount\s+due)/.test(lower);
          var entry = { line: i + 1, raw: line, amounts: amounts, category: categoryOf(lower) };
          if(isSubtotal){ entry.amount = amounts[amounts.length - 1].value; subtotalLine = entry; return; }
          if(isTotal){ entry.amount = amounts[amounts.length - 1].value; totalLine = entry; return; }
          var qp = qtyPriceIn(line);
          entry.qtyPrice = qp;
          var total;
          var eq = line.lastIndexOf("=");
          if(eq >= 0){
            var after = amountsIn(line.slice(eq));
            if(after.length) total = after[after.length - 1].value;
          }
          if(total === undefined){
            if(qp && amounts.length === 1) total = round2(qp.qty * qp.price);
            else total = amounts[amounts.length - 1].value;
          }
          entry.amount = round2(total);
          entry.label = normalizeLabel(line);
          items.push(entry);
        });
        return { items: items, totalLine: totalLine, subtotalLine: subtotalLine };
      }

      /* ---------- the audit ---------- */
      var CATNAMES = { zones: "Zones", heads: "Sprinkler heads", rotors: "Rotors", drip: "Drip line (ft)" };
      var CATUNITS = { zones: "zone", heads: "head", rotors: "rotor", drip: "ft" };

      function audit(proposal, work, invoice){
        proposal = proposal || ""; work = work || ""; invoice = invoice || "";
        if(!proposal.trim() && !work.trim() && !invoice.trim()){
          return { empty: true, verdict: "NO DOCUMENTS", totalOvercharge: 0, findings: [] };
        }
        var findings = [];
        function add(sev, title, detail, amount, refs){
          findings.push({ severity: sev, title: title, detail: detail,
            amount: round2(amount || 0), refs: refs || [] });
        }
        if(!proposal.trim()) add("minor", "Proposal is empty", "No proposal was pasted, so proposed quantities, the controller model, the labor rate, and the deposit terms could not be checked.", 0, []);
        if(!work.trim()) add("minor", "Work record is empty", "No work record was pasted, so installed quantities and recorded hours could not be verified against the invoice.", 0, []);
        if(!invoice.trim()) add("minor", "Invoice is empty", "No invoice was pasted, so there is nothing billed to check.", 0, []);

        var inv = parseInvoice(invoice);
        var corpus = (proposal + "\n" + work).toLowerCase();

        /* quantity checks: zones / heads / rotors / drip */
        ["zones", "heads", "rotors", "drip"].forEach(function(cat){
          var billedLine = null;
          for(var i = 0; i < inv.items.length; i++){
            if(inv.items[i].category === cat){ billedLine = inv.items[i]; break; }
          }
          if(!billedLine) return;
          var billedQty = qtyInLine(billedLine.raw, cat);
          if(billedQty === null && billedLine.qtyPrice) billedQty = billedLine.qtyPrice.qty;
          if(billedQty === null) return;
          var rec = docQuantity(work, cat), recSrc = "Work record";
          if(!rec){ rec = docQuantity(proposal, cat); recSrc = "Proposal"; }
          if(!rec) return;
          if(billedQty > rec.qty){
            var unit = billedLine.qtyPrice ? billedLine.qtyPrice.price : null;
            if(unit === null && billedQty > 0 && billedLine.amount > 0) unit = round2(billedLine.amount / billedQty);
            var extra = round2(billedQty - rec.qty);
            if(unit !== null){
              var amt = round2(extra * unit);
              add("critical", CATNAMES[cat] + " billed above " + (recSrc === "Work record" ? "installed" : "proposed") + " quantity",
                "Invoice bills " + qtyFmt(billedQty) + " " + CATUNITS[cat] + "s but the " + recSrc.toLowerCase() +
                " shows " + qtyFmt(rec.qty) + ". Extra: " + qtyFmt(billedQty) + " − " + qtyFmt(rec.qty) + " = " +
                qtyFmt(extra) + " " + CATUNITS[cat] + "s × " + fmt(unit) + " per " + CATUNITS[cat] + " = " + fmt(amt) + ".",
                amt, ["Invoice line " + billedLine.line, recSrc + " line " + rec.line]);
            } else {
              add("minor", CATNAMES[cat] + " billed above recorded quantity — price not shown",
                "Invoice bills " + qtyFmt(billedQty) + " but the " + recSrc.toLowerCase() + " shows " + qtyFmt(rec.qty) +
                ", and no unit price was found on the invoice line, so the dollar amount needs a manual check.",
                0, ["Invoice line " + billedLine.line, recSrc + " line " + rec.line]);
            }
          }
        });

        /* controller model swap */
        var propCtl = controllerModel(proposal), workCtl = controllerModel(work);
        if(propCtl && workCtl && propCtl.model.toLowerCase() !== workCtl.model.toLowerCase()){
          add("critical", "Controller model swap",
            "Proposal specifies controller \"" + propCtl.model + "\"; the work record shows installed controller \"" +
            workCtl.model + "\". A different model was installed than proposed — confirm the swap was approved before paying.",
            0, ["Proposal line " + propCtl.line, "Work record line " + workCtl.line]);
        }

        /* labor check */
        var laborLines = inv.items.filter(function(it){ return it.category === "labor"; });
        var recHours = docQuantity(work, "labor");
        var rateInfo = laborRate(proposal);
        if(laborLines.length && recHours){
          var billedLabor = round2(laborLines.reduce(function(s, it){ return s + it.amount; }, 0));
          var rate = rateInfo ? rateInfo.rate : (laborLines[0].qtyPrice ? laborLines[0].qtyPrice.price : null);
          var billedHours = laborLines[0].qtyPrice ? laborLines[0].qtyPrice.qty : qtyInLine(laborLines[0].raw, "labor");
          if(rate !== null && billedLabor > round2(recHours.qty * rate) + 0.005){
            var allowed = round2(recHours.qty * rate), over = round2(billedLabor - allowed);
            add("critical", "Labor billed above recorded hours × proposal rate",
              "Invoice bills labor at " + fmt(billedLabor) + (billedHours !== null ? " (" + qtyFmt(billedHours) + " hrs × " + fmt(rate) + "/hr)" : "") +
              ". The work record shows " + qtyFmt(recHours.qty) + " hrs; " + qtyFmt(recHours.qty) + " × " + fmt(rate) + " = " +
              fmt(allowed) + " is supported. Overcharge: " + fmt(billedLabor) + " − " + fmt(allowed) + " = " + fmt(over) + ".",
              over, ["Invoice line " + laborLines[0].line, "Work record line " + recHours.line].concat(rateInfo ? ["Proposal line " + rateInfo.line] : []));
          }
        }

        /* deposit credit */
        var depPaid = docDeposit(work) || docDeposit(proposal);
        var depPaidSrc = docDeposit(work) ? "Work record" : "Proposal";
        var depCredit = 0, depCreditLine = null;
        inv.items.forEach(function(it){
          if(it.category === "deposit"){ depCredit += Math.abs(it.amount); depCreditLine = it; }
        });
        if(depPaid && depPaid.amount > depCredit + 0.005){
          var short = round2(depPaid.amount - depCredit);
          add("critical", "Deposit paid but not fully credited on the invoice",
            "Deposit paid per the " + depPaidSrc.toLowerCase() + ": " + fmt(depPaid.amount) + ". Credit shown on the invoice: " +
            fmt(depCredit) + ". Uncredited deposit: " + fmt(depPaid.amount) + " − " + fmt(depCredit) + " = " + fmt(short) + ".",
            short, [depPaidSrc + " line " + depPaid.line].concat(depCreditLine ? ["Invoice line " + depCreditLine.line] : []));
        }

        /* duplicate charges */
        var seen = {};
        inv.items.forEach(function(it){
          if(it.category === "deposit" || !it.label) return;
          if(seen[it.label]){
            var first = seen[it.label];
            if(it.amount > 0){
              add("critical", "Duplicate charge",
                "\"" + it.raw.replace(/^\s*[-•*]\s*/, "").replace(/:?\s*\$.*$/, "") + "\" appears twice on the invoice (lines " +
                first.line + " and " + it.line + "). The second charge of " + fmt(it.amount) + " is a duplicate.",
                it.amount, ["Invoice line " + first.line, "Invoice line " + it.line]);
            }
            it.isDuplicate = true;
          } else seen[it.label] = it;
        });

        /* invoice-only fees / lines with no basis */
        inv.items.forEach(function(it){
          if(it.category === "deposit" || it.isDuplicate) return;
          var isFee = /fee|charge|surcharge/.test(it.raw.toLowerCase());
          var words = significantWords(it.raw);
          var hasBasis;
          if(isFee){
            hasBasis = words.some(function(w){ return corpus.indexOf(w) >= 0; });
          } else if(it.category !== "other"){
            hasBasis = true;
          } else {
            hasBasis = words.length === 0 || words.some(function(w){ return corpus.indexOf(w) >= 0; });
          }
          if(!hasBasis && it.amount > 0){
            add("minor", isFee ? "Invoice-only fee — no basis in proposal or work record" : "Invoice-only line — no basis in proposal or work record",
              "\"" + it.raw.replace(/^\s*[-•*]\s*/, "").replace(/:?\s*\$.*$/, "") + "\" (" + fmt(it.amount) +
              ") appears only on the invoice. No matching item or fee appears in the proposal or the work record, so there is no documented basis for the charge.",
              it.amount, ["Invoice line " + it.line]);
          }
        });

        /* invoice total arithmetic */
        var stated = inv.totalLine || inv.subtotalLine;
        if(stated && inv.items.length){
          var sum = round2(inv.items.reduce(function(s, it){ return s + it.amount; }, 0));
          var diff = round2(stated.amount - sum);
          if(Math.abs(diff) > 0.01){
            add(diff >= 10 ? "critical" : "minor", "Invoice total does not match its own line items",
              "The invoice line items add to " + fmt(sum) + " but the stated " + (inv.totalLine ? "total" : "subtotal") +
              " is " + fmt(stated.amount) + ". Difference: " + fmt(stated.amount) + " − " + fmt(sum) + " = " + fmt(diff) +
              (diff > 0 ? " billed above the sum of its own lines." : " (in the customer's favor, but the invoice still needs correcting)."),
              diff > 0 ? diff : 0, ["Invoice line " + stated.line]);
          }
        }

        var total = round2(findings.reduce(function(s, f){ return s + f.amount; }, 0));
        var hasCrit = findings.some(function(f){ return f.severity === "critical"; });
        var verdict = hasCrit ? "DO NOT PAY YET" : (findings.length ? "PAY WITH FIXES" : "SAFE TO PAY");
        return { empty: false, verdict: verdict, totalOvercharge: total, findings: findings };
      }

      /* ---------- built-in examples ---------- */
      var EXAMPLE_BAD = {
        proposal: [
          "IRRIGATION INSTALLATION PROPOSAL",
          "Property: Greenfield Residence",
          "Prepared by: AquaFlow Irrigation LLC",
          "",
          "Scope of work:",
          "- Zones: 6 zones",
          "- Sprinkler heads: 24 spray heads at $18.00 each",
          "- Rotors: 8 rotors at $42.00 each",
          "- Drip line: 200 ft of drip line at $1.50 per ft",
          "- Controller: Rain Bird ESP-TM2 controller — $289.00",
          "- Labor rate: $85.00 per hour",
          "- Deposit required: $500.00 due at signing"
        ].join("\n"),
        work: [
          "WORK RECORD",
          "Property: Greenfield Residence",
          "Crew: J. Alvarez and M. Chen",
          "Dates: May 12-14, 2026",
          "",
          "Installed and completed:",
          "- Zones installed: 6 zones",
          "- Spray heads installed: 22 heads",
          "- Rotors installed: 8 rotors",
          "- Drip line installed: 180 ft of drip line",
          "- Controller installed: Hunter Pro-C controller",
          "- Labor: 14 hours on site",
          "- Deposit received: $500.00"
        ].join("\n"),
        invoice: [
          "FINAL INVOICE #1042",
          "Property: Greenfield Residence",
          "From: AquaFlow Irrigation LLC",
          "",
          "Line items:",
          "- Zones: 8 zones × $120.00 = $960.00",
          "- Spray heads: 26 heads × $18.00 = $468.00",
          "- Rotors: 8 rotors × $42.00 = $336.00",
          "- Drip line: 250 ft × $1.50 = $375.00",
          "- Controller (Hunter Pro-C): $289.00",
          "- Labor: 18 hours × $85.00 = $1,530.00",
          "- Controller programming fee: $75.00",
          "- Controller programming fee: $75.00",
          "- Materials handling fee: $60.00",
          "",
          "Subtotal: $4,168.00",
          "Total due: $4,218.00"
        ].join("\n")
      };
      var EXAMPLE_CLEAN = {
        proposal: [
          "IRRIGATION INSTALLATION PROPOSAL",
          "Property: Maple Street Residence",
          "Prepared by: AquaFlow Irrigation LLC",
          "",
          "Scope of work:",
          "- Zones: 4 zones",
          "- Sprinkler heads: 16 spray heads at $18.00 each",
          "- Rotors: 4 rotors at $42.00 each",
          "- Drip line: 100 ft of drip line at $1.50 per ft",
          "- Controller: Hunter Pro-C controller — $249.00",
          "- Labor rate: $80.00 per hour",
          "- Permit fee: $45.00",
          "- Deposit required: $300.00 due at signing"
        ].join("\n"),
        work: [
          "WORK RECORD",
          "Property: Maple Street Residence",
          "Crew: J. Alvarez and M. Chen",
          "",
          "Installed and completed:",
          "- Zones installed: 4 zones",
          "- Spray heads installed: 16 heads",
          "- Rotors installed: 4 rotors",
          "- Drip line installed: 100 ft of drip line",
          "- Controller installed: Hunter Pro-C controller",
          "- Labor: 10 hours on site",
          "- Deposit received: $300.00"
        ].join("\n"),
        invoice: [
          "FINAL INVOICE #1043",
          "Property: Maple Street Residence",
          "From: AquaFlow Irrigation LLC",
          "",
          "Line items:",
          "- Zones: 4 zones × $120.00 = $480.00",
          "- Spray heads: 16 heads × $18.00 = $288.00",
          "- Rotors: 4 rotors × $42.00 = $168.00",
          "- Drip line: 100 ft × $1.50 = $150.00",
          "- Controller (Hunter Pro-C): $249.00",
          "- Labor: 10 hours × $80.00 = $800.00",
          "- Permit fee: $45.00",
          "- Deposit credit: -$300.00",
          "",
          "Subtotal: $1,880.00",
          "Total due: $1,880.00"
        ].join("\n")
      };

      /* ---------- reporting ---------- */
      var lastResult = null, lastInputs = null;
      function buildReport(r){
        if(!r) return "No report yet. Run the cross-check and the report appears here, ready to copy.";
        if(r.empty) return "IRRIGATION CONSISTENCY AUDIT\n\nNo documents were pasted. Paste a proposal, a work record, and a final invoice, then run the cross-check.";
        var out = [];
        out.push("IRRIGATION INSTALLATION CONSISTENCY AUDIT");
        out.push("Verdict: " + r.verdict);
        out.push("Documented overcharge total: " + fmt(r.totalOvercharge));
        out.push("");
        if(!r.findings.length){
          out.push("No findings. The proposal, work record, and invoice agree on quantities, controller model, labor, deposit credit, and totals.");
        } else {
          r.findings.forEach(function(f, i){
            out.push((i + 1) + ". [" + f.severity.toUpperCase() + "] " + f.title + (f.amount ? " — " + fmt(f.amount) : ""));
            out.push("   " + f.detail);
            if(f.refs.length) out.push("   Source: " + f.refs.join(" · "));
          });
        }
        out.push("");
        out.push("Scope: this audit cross-checks only the three pasted documents. It does not verify field work, market prices, or payment status.");
        return out.join("\n");
      }
      function buildJSON(r){
        if(!r) return "{}";
        return JSON.stringify({
          tool: "J-Dawgs Irrigation Installation Proposal, Work Record & Final Invoice Consistency Auditor",
          verdict: r.verdict,
          documentedOverchargeTotal: r.totalOvercharge,
          findings: r.findings.map(function(f){
            return { severity: f.severity, title: f.title, detail: f.detail, amount: f.amount, sources: f.refs };
          }),
          scope: "Cross-checks only the three pasted documents; does not verify field work, market prices, or payment status."
        }, null, 2);
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_BAD": (typeof EXAMPLE_BAD !== 'undefined' ? EXAMPLE_BAD : undefined), "EXAMPLE_CLEAN": (typeof EXAMPLE_CLEAN !== 'undefined' ? EXAMPLE_CLEAN : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-irrigation-installation-proposal-work-record-final-invoice-consistency-auditortm',
  name: 'J-Dawgs Irrigation Installation Proposal, Work Record & Final Invoice Consistency Auditor',
  description: 'Cross-checks an irrigation installation proposal against its work record and final invoice (zones, sprinkler heads, and drip lines billed above what was recorded, controller swaps, labor above hours × rate, uncredited deposit, duplicate and invoice-only fees, arithmetic shown) into one pay verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_BAD": __core["EXAMPLE_BAD"], "EXAMPLE_CLEAN": __core["EXAMPLE_CLEAN"] }
};
