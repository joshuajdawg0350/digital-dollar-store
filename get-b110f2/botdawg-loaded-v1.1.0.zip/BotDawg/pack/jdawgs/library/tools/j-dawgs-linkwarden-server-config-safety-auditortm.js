'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Linkwarden Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Example configurations ---------- */

      var RISKY_EXAMPLE = [
        "# Linkwarden — production draft (do not ship this)",
        "NEXTAUTH_SECRET=supersecret123",
        "NEXTAUTH_URL=http://bookmarks.example.org",
        "DATABASE_URL=postgres://linkwarden:dbpass987@db:5432/linkwarden",
        "POSTGRES_PASSWORD=dbpass987",
        "MEILI_MASTER_KEY=shortkey",
        "NEXT_PUBLIC_DISABLE_REGISTRATION=false",
        "STORAGE_ACCESS_KEY_ID=AKIAEXAMPLE12345",
        "STORAGE_SECRET_ACCESS_KEY=wJalrXUtnFEMIK7MDENGbPxRfiCYEXAMPLEKEY"
      ].join("\n");

      var HARDENED_EXAMPLE = [
        "# Linkwarden — production, secrets supplied by reference",
        "NEXTAUTH_SECRET=${NEXTAUTH_SECRET}",
        "NEXTAUTH_URL=https://bookmarks.example.org",
        "DATABASE_URL=${DATABASE_URL}",
        "POSTGRES_PASSWORD_FILE=/run/secrets/postgres_password",
        "MEILI_MASTER_KEY=${MEILI_MASTER_KEY}",
        "NEXT_PUBLIC_DISABLE_REGISTRATION=true",
        "STORAGE_ACCESS_KEY_ID=${STORAGE_ACCESS_KEY_ID}",
        "STORAGE_SECRET_ACCESS_KEY=${STORAGE_SECRET_ACCESS_KEY}"
      ].join("\n");

      /* ---------- Auditor ---------- */

      var EXAMPLE_WORDS = [
        "secret", "supersecret", "super-secret", "mysecret", "my-secret", "some-secret",
        "password", "password123", "passw0rd", "123456", "12345678", "123456789",
        "letmein", "linkwarden", "meili", "meilisearch", "masterkey", "master-key",
        "test", "testing", "dev", "development", "random", "topsecret", "secretkey",
        "secret123", "changeit", "admin", "default"
      ];
      var EXAMPLE_SUBSTRINGS = [
        "changeme", "change-me", "change_me", "example", "placeholder", "supersecret",
        "your-secret", "your_secret", "your-key", "your_key", "insert-", "todo", "xxxx"
      ];

      function isExampleValue(v) {
        var low = v.toLowerCase();
        if (EXAMPLE_WORDS.indexOf(low) !== -1) return true;
        for (var i = 0; i < EXAMPLE_SUBSTRINGS.length; i++) {
          if (low.indexOf(EXAMPLE_SUBSTRINGS[i]) !== -1) return true;
        }
        return false;
      }

      function stripQuotes(v) {
        v = v.trim();
        if (v.length >= 2) {
          var a = v.charAt(0), b = v.charAt(v.length - 1);
          if ((a === '"' && b === '"') || (a === "'" && b === "'")) return v.slice(1, -1);
        }
        return v;
      }

      function isVarRef(v) { return v.indexOf("${") !== -1; }
      function isWholeVarRef(v) { return /^\$\{[A-Za-z_][A-Za-z0-9_]*\}$/.test(v); }

      var RECOGNIZED = /^(NEXTAUTH_|NEXT_PUBLIC_|DATABASE_URL$|POSTGRES_|MEILI|MEILISEARCH|STORAGE_|S3_|AWS_|SPACES_|MINIO_)/;

      function parseConfig(text) {
        var entries = [];
        var lines = String(text == null ? "" : text).split(/\r?\n/);
        for (var i = 0; i < lines.length; i++) {
          var raw = lines[i];
          var trimmed = raw.trim();
          if (!trimmed || trimmed.charAt(0) === "#") continue;
          var m = trimmed.match(/^([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/);
          if (!m) continue;
          entries.push({ key: m[1], value: stripQuotes(m[2]), line: i + 1 });
        }
        return entries;
      }

      function audit(text) {
        var entries = parseConfig(text);
        var findings = [];
        function add(line, severity, key, issue, fix) {
          findings.push({ line: line, severity: severity, key: key, issue: issue, fix: fix });
        }

        var recognized = entries.filter(function (e) { return RECOGNIZED.test(e.key); });
        if (entries.length === 0 || recognized.length === 0) {
          return {
            verdict: "NOT ENOUGH TO GRADE",
            reason: entries.length === 0
              ? "No KEY=value lines were found in the pasted text. Paste the env-style lines from a Linkwarden .env or compose file."
              : "The pasted text has lines, but none of the keys a Linkwarden server configuration uses. There is nothing here to grade.",
            findings: [],
            counts: { BLOCKER: 0, HIGH: 0, WARNING: 0, INFO: 0 }
          };
        }

        var byKey = {};
        entries.forEach(function (e) { if (!byKey[e.key]) byKey[e.key] = e; });
        var handled = {};

        function secretState(e) {
          // returns "file" | "ref" | "empty" | "plain"
          if (/_FILE$/.test(e.key)) return "file";
          if (e.value === "") return "empty";
          if (isWholeVarRef(e.value)) return "ref";
          return "plain";
        }

        function noteSafeReference(e) {
          var st = secretState(e);
          if (st === "file") {
            add(e.line, "INFO", e.key, "Secret is supplied from a file reference, not written in the configuration.",
              "No fix needed — keep the referenced file outside the repo and readable only by the server.");
            return true;
          }
          if (st === "ref") {
            add(e.line, "INFO", e.key, "Secret is supplied by a ${...} variable reference, not written in the configuration.",
              "No fix needed — make sure the variable is set in the host environment or secret store at deploy time.");
            return true;
          }
          return false;
        }

        /* NEXTAUTH_SECRET */
        var nas = byKey["NEXTAUTH_SECRET"];
        if (!nas) {
          add(null, "BLOCKER", "NEXTAUTH_SECRET", "NEXTAUTH_SECRET is missing entirely.",
            "Set NEXTAUTH_SECRET to a random value of at least 32 characters (for example, the output of: openssl rand -base64 32) and supply it by reference, not in plaintext.");
        } else {
          handled["NEXTAUTH_SECRET"] = true;
          if (!noteSafeReference(nas)) {
            if (nas.value === "") {
              add(nas.line, "BLOCKER", "NEXTAUTH_SECRET", "NEXTAUTH_SECRET is present but empty.",
                "Set it to a random value of at least 32 characters and supply it by reference, not in plaintext.");
            } else if (isExampleValue(nas.value)) {
              add(nas.line, "BLOCKER", "NEXTAUTH_SECRET",
                "NEXTAUTH_SECRET is a known example value (reported by length only: " + nas.value.length + " characters). Anyone can guess it, so session tokens can be forged.",
                "Replace it with a fresh random value of at least 32 characters, known to nobody, and supply it by reference.");
            } else if (nas.value.length < 32) {
              add(nas.line, "HIGH", "NEXTAUTH_SECRET",
                "NEXTAUTH_SECRET is only " + nas.value.length + " characters long — under the 32-character floor. Short session secrets are guessable.",
                "Generate a random value of at least 32 characters (for example: openssl rand -base64 32) and supply it by reference.");
            } else {
              add(nas.line, "WARNING", "NEXTAUTH_SECRET",
                "NEXTAUTH_SECRET is written in plaintext in the configuration (" + nas.value.length + " characters; value never shown). If this file leaks, sessions can be forged.",
                "Move it into your secret store or host environment and reference it here as ${NEXTAUTH_SECRET}.");
            }
          }
        }

        /* NEXTAUTH_URL */
        var nau = byKey["NEXTAUTH_URL"];
        if (!nau) {
          add(null, "WARNING", "NEXTAUTH_URL", "NEXTAUTH_URL is not set. Auth callbacks and shared links can point at the wrong address.",
            "Set NEXTAUTH_URL to the exact public https address users reach the server at.");
        } else {
          handled["NEXTAUTH_URL"] = true;
          var urlVal = nau.value;
          if (!isVarRef(urlVal) && /^http:\/\//i.test(urlVal)) {
            var local = /localhost|127\.0\.0\.1/.test(urlVal);
            add(nau.line, local ? "WARNING" : "HIGH", "NEXTAUTH_URL",
              local
                ? "NEXTAUTH_URL uses http:// on a local address. Fine on a developer machine, wrong anywhere users reach it over a network."
                : "NEXTAUTH_URL uses http://. Logins and session cookies travel unencrypted, and auth providers may reject the callbacks.",
              "Serve the server over https (a reverse proxy is fine) and set NEXTAUTH_URL to the https address.");
          }
        }

        /* DATABASE_URL */
        var dbu = byKey["DATABASE_URL"];
        if (dbu) {
          handled["DATABASE_URL"] = true;
          if (!noteSafeReference(dbu) && dbu.value !== "") {
            var um = dbu.value.match(/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\/[^:@/]+:([^@]*)@/);
            if (um && um[1] !== "" && um[1].indexOf("${") === -1) {
              add(dbu.line, "HIGH", "DATABASE_URL",
                "DATABASE_URL carries a plaintext database password (" + um[1].length + " characters; value never shown). Anyone who reads this file owns the database.",
                "Move the connection string into your secret store and reference it as ${DATABASE_URL}, or use a password file / secret mount.");
            } else if (!um) {
              add(dbu.line, "INFO", "DATABASE_URL",
                "DATABASE_URL is set without an embedded password in the string.",
                "No fix needed for the password check — keep any password in a secret store, not in this file.");
            }
          }
        }

        /* POSTGRES_PASSWORD */
        var pgp = byKey["POSTGRES_PASSWORD"];
        if (pgp) {
          handled["POSTGRES_PASSWORD"] = true;
          if (!noteSafeReference(pgp)) {
            if (pgp.value === "") {
              add(pgp.line, "WARNING", "POSTGRES_PASSWORD", "POSTGRES_PASSWORD is present but empty — the database may start with no password at all.",
                "Set a long random password and supply it from a secret file (POSTGRES_PASSWORD_FILE) or by reference.");
            } else {
              add(pgp.line, "HIGH", "POSTGRES_PASSWORD",
                "POSTGRES_PASSWORD is a plaintext password written in the configuration (" + pgp.value.length + " characters; value never shown).",
                "Supply it from a secret file (POSTGRES_PASSWORD_FILE=/run/secrets/...) or as a ${...} reference instead of plaintext.");
            }
          }
        }
        if (byKey["POSTGRES_PASSWORD_FILE"]) {
          handled["POSTGRES_PASSWORD_FILE"] = true;
          noteSafeReference(byKey["POSTGRES_PASSWORD_FILE"]);
        }

        /* Search master key (Meilisearch) */
        Object.keys(byKey).forEach(function (k) {
          if (!/MASTER_KEY$/.test(k) && k !== "MEILI_MASTER_KEY") return;
          var e = byKey[k];
          handled[k] = true;
          if (noteSafeReference(e)) return;
          if (e.value === "") {
            add(e.line, "HIGH", k, "The search master key is present but empty — the search index can run unprotected.",
              "Set a long random master key and supply it by reference.");
          } else if (isExampleValue(e.value)) {
            add(e.line, "BLOCKER", k,
              "The search master key is a known example value (reported by length only: " + e.value.length + " characters). It can mint its own API keys, so a guessed master key hands over the whole index.",
              "Replace it with a fresh random value of at least 32 characters and supply it by reference.");
          } else if (e.value.length < 20) {
            add(e.line, "HIGH", k,
              "The search master key is only " + e.value.length + " characters long. A master key can mint API keys, so a short one is a short way in.",
              "Use a random value of at least 32 characters and supply it by reference.");
          } else {
            add(e.line, "WARNING", k,
              "The search master key is written in plaintext in the configuration (" + e.value.length + " characters; value never shown).",
              "Move it into your secret store and reference it as ${" + k + "}.");
          }
        });

        /* Public registration */
        var reg = byKey["NEXT_PUBLIC_DISABLE_REGISTRATION"];
        if (!reg) {
          add(null, "WARNING", "NEXT_PUBLIC_DISABLE_REGISTRATION",
            "NEXT_PUBLIC_DISABLE_REGISTRATION is not set in this configuration, so public registration may be open — anyone who finds the server can create an account.",
            "Set NEXT_PUBLIC_DISABLE_REGISTRATION=true once your own accounts exist, unless this server is deliberately public.");
        } else {
          handled["NEXT_PUBLIC_DISABLE_REGISTRATION"] = true;
          var rv = reg.value.toLowerCase();
          if (rv === "false" || rv === "0" || rv === "no" || rv === "") {
            add(reg.line, "HIGH", "NEXT_PUBLIC_DISABLE_REGISTRATION",
              "Public registration is open (NEXT_PUBLIC_DISABLE_REGISTRATION is off). Anyone who finds the server can sign up and use your storage and bandwidth.",
              "Create the accounts you need, then set NEXT_PUBLIC_DISABLE_REGISTRATION=true.");
          } else {
            add(reg.line, "INFO", "NEXT_PUBLIC_DISABLE_REGISTRATION",
              "Public registration is disabled in this configuration.",
              "No fix needed — reopen it only briefly, on purpose, when you need to add an account.");
          }
        }

        /* Storage / S3 credentials */
        Object.keys(byKey).forEach(function (k) {
          if (handled[k]) return;
          var storageKey = /(STORAGE_|^S3_|AWS_|SPACES_|MINIO_)/.test(k);
          if (!storageKey) return;
          var e = byKey[k];
          var isSecretPart = /(SECRET|PRIVATE)/.test(k);
          var isAccessPart = /(ACCESS_KEY|ACCESSKEY)/.test(k);
          if (!isSecretPart && !isAccessPart) return;
          handled[k] = true;
          if (noteSafeReference(e)) return;
          if (e.value === "") {
            add(e.line, "WARNING", k, "This storage credential is present but empty — uploads will fail or fall back to an unintended account.",
              "Set the credential in your secret store and reference it here, or remove the key if this storage backend is unused.");
          } else if (isSecretPart) {
            add(e.line, "HIGH", k,
              "A storage secret credential is written in plaintext in the configuration (" + e.value.length + " characters; value never shown). It is the keys to the file bucket.",
              "Move it into your secret store and reference it as ${" + k + "}; rotate it if this file was ever shared.");
          } else {
            add(e.line, "WARNING", k,
              "A storage access key ID is written in plaintext in the configuration (" + e.value.length + " characters; value never shown). Paired with a leaked secret key, it identifies exactly which account to attack.",
              "Supply it by reference as ${" + k + "} alongside the secret key, and keep this file out of public repos.");
          }
        });

        /* Generic sweep: any other secret-shaped key */
        Object.keys(byKey).forEach(function (k) {
          if (handled[k]) return;
          if (!/(SECRET|PASSWORD|TOKEN|PRIVATE_KEY|API_KEY|APIKEY)/.test(k)) return;
          var e = byKey[k];
          handled[k] = true;
          if (noteSafeReference(e)) return;
          if (e.value === "") {
            add(e.line, "WARNING", k, "This secret is present but empty.", "Set it in your secret store and reference it here, or remove the key if it is unused.");
          } else if (isExampleValue(e.value)) {
            add(e.line, "HIGH", k,
              "This secret is a known example value (reported by length only: " + e.value.length + " characters).",
              "Replace it with a fresh random value and supply it by reference.");
          } else if (e.value.length < 16) {
            add(e.line, "WARNING", k,
              "This secret is short (" + e.value.length + " characters; value never shown). Short secrets are guessable.",
              "Use a random value of at least 32 characters and supply it by reference.");
          } else {
            add(e.line, "WARNING", k,
              "This secret is written in plaintext in the configuration (" + e.value.length + " characters; value never shown).",
              "Move it into your secret store and reference it as ${" + k + "}.");
          }
        });

        var counts = { BLOCKER: 0, HIGH: 0, WARNING: 0, INFO: 0 };
        findings.forEach(function (f) { counts[f.severity]++; });
        var sevRank = { BLOCKER: 0, HIGH: 1, WARNING: 2, INFO: 3 };
        findings.sort(function (a, b) {
          if (sevRank[a.severity] !== sevRank[b.severity]) return sevRank[a.severity] - sevRank[b.severity];
          return (a.line || 0) - (b.line || 0);
        });

        var verdict, reason;
        if (counts.BLOCKER > 0) {
          verdict = "DO NOT DEPLOY";
          reason = counts.BLOCKER + " blocker" + (counts.BLOCKER === 1 ? "" : "s") + " must be fixed before this configuration goes anywhere near a server.";
        } else if (counts.HIGH > 0 || counts.WARNING > 0) {
          verdict = "DEPLOY WITH FIXES";
          reason = "Nothing here is an automatic stop, but the findings above are real exposure. Fix them first — none of them take long.";
        } else {
          verdict = "SAFE TO DEPLOY";
          reason = "No blockers, no high or warning findings. Secrets arrive by reference, the URL is https, and registration is closed.";
        }
        return { verdict: verdict, reason: reason, findings: findings, counts: counts };
      }

      /* ---------- Report builders (secret values never included) ---------- */

      function buildReport(result) {
        var out = [];
        out.push("J-Dawgs Linkwarden Server Config Safety Auditor™ — audit report");
        out.push("Verdict: " + result.verdict);
        out.push(result.reason);
        out.push("Findings: " + result.findings.length +
          " (BLOCKER " + result.counts.BLOCKER + ", HIGH " + result.counts.HIGH +
          ", WARNING " + result.counts.WARNING + ", INFO " + result.counts.INFO + ")");
        out.push("Secret values are never included in this report — keys, lines, and lengths only.");
        result.findings.forEach(function (f, i) {
          out.push("");
          out.push((i + 1) + ". [" + f.severity + "] " + f.key + " — " + (f.line ? "line " + f.line : "not present in the configuration"));
          out.push("   Issue: " + f.issue);
          out.push("   Fix: " + f.fix);
        });
        return out.join("\n");
      }

      function buildJSON(result) {
        return JSON.stringify({
          tool: "J-Dawgs Linkwarden Server Config Safety Auditor™",
          verdict: result.verdict,
          reason: result.reason,
          counts: result.counts,
          findings: result.findings.map(function (f) {
            return { line: f.line, severity: f.severity, key: f.key, issue: f.issue, fix: f.fix };
          }),
          note: "Secret values are never included — keys, lines, and lengths only."
        }, null, 2);
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined), "EXAMPLE_WORDS": (typeof EXAMPLE_WORDS !== 'undefined' ? EXAMPLE_WORDS : undefined), "EXAMPLE_SUBSTRINGS": (typeof EXAMPLE_SUBSTRINGS !== 'undefined' ? EXAMPLE_SUBSTRINGS : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-linkwarden-server-config-safety-auditortm',
  name: 'J-Dawgs Linkwarden Server Config Safety Auditor',
  description: 'Grades a pasted Linkwarden env config offline into one deploy verdict: short or example NEXTAUTH_SECRET and database password values, an http NEXTAUTH_URL, and open signups all graded, with secrets reported by key name, line, and length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"], "EXAMPLE_WORDS": __core["EXAMPLE_WORDS"], "EXAMPLE_SUBSTRINGS": __core["EXAMPLE_SUBSTRINGS"] }
};
