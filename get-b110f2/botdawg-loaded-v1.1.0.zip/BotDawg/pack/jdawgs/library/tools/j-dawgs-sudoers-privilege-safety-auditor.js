'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Sudoers Privilege Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

  "use strict";

  var EXAMPLE_A = "Defaults timestamp_timeout=60\ndeploy ALL=(ALL) NOPASSWD: ALL\nbackup ALL=(ALL) /usr/bin/vim\nops ALL=(ALL) /usr/bin/systemctl restart httpd";
  var EXAMPLE_B = "Defaults timestamp_timeout=0\nops ALL=(root) /usr/bin/systemctl restart httpd\nbackup ALL=(root) /usr/bin/rsync --server --sender -vlogDtpre.iLsfx . /var/backups";

  var ESCAPES = {
    "vim": "vim can run :shell or :!command and can edit any file as root — a full shell escape.",
    "vi": "vi can run :shell or :!command and can edit any file as root — a full shell escape.",
    "nvim": "nvim can run :shell or :!command and can edit any file as root — a full shell escape.",
    "nano": "nano can read and overwrite any file as root and can spawn commands from its menus — an editor escape.",
    "emacs": "emacs can spawn a shell and edit any file as root — a full shell escape.",
    "less": "less can run !command from its pager prompt — a direct shell escape.",
    "more": "more can invoke an editor or shell from the pager on many builds — a shell escape risk.",
    "man": "man pages through less, which can run !command — an indirect shell escape.",
    "find": "find -exec runs any command as root — a direct shell escape.",
    "awk": "awk can run system() and getline pipes — a shell escape.",
    "gawk": "gawk can run system() and getline pipes — a shell escape.",
    "mawk": "mawk can run system() and getline pipes — a shell escape.",
    "python": "python runs arbitrary code as root — a complete shell escape.",
    "python3": "python3 runs arbitrary code as root — a complete shell escape.",
    "perl": "perl runs arbitrary code and system() calls as root — a complete shell escape.",
    "ruby": "ruby runs arbitrary code and system() calls as root — a complete shell escape.",
    "node": "node runs arbitrary code as root — a complete shell escape.",
    "docker": "docker can mount the host filesystem into a container and return a root shell — a complete escape.",
    "tar": "tar can overwrite arbitrary files as root and its checkpoint actions can run commands — a file and shell escape.",
    "cp": "cp can overwrite protected files such as /etc/shadow or an authorized_keys file as root — a file escape.",
    "mv": "mv can replace protected files such as /etc/shadow or an authorized_keys file as root — a file escape.",
    "tee": "tee can append to or overwrite protected files as root — a file escape.",
    "dd": "dd can overwrite any file or device as root — a file escape.",
    "env": "env can launch any other program as root — a direct shell escape.",
    "bash": "bash is a shell — granting it is granting root itself.",
    "sh": "sh is a shell — granting it is granting root itself.",
    "zsh": "zsh is a shell — granting it is granting root itself."
  };

  var SECRET_RE = /(password|passwd|pwd|secret|api[\s_-]?key|access[\s_-]?token|auth[\s_-]?token)\s*[:=]\s*\S+/i;
  var TAG_RE = /^(NOPASSWD|PASSWD|NOEXEC|EXEC|SETENV|NOSETENV|MAIL|NOMAIL|FOLLOW|NOFOLLOW|INTERCEPT|NOINTERCEPT|LOG_INPUT|NOLOG_INPUT|LOG_OUTPUT|NOLOG_OUTPUT|TTY|NO_TTY)\s*:\s*/i;
  var ALIAS_NAME_RE = /^[A-Z][A-Z0-9_]*$/;
  var PRINCIPAL_RE = /^[%+#@]?[\w.\-+]+(:[%+#]?[\w.\-+]+)?$/;

  function basename(p){ var parts = p.split("/"); return parts[parts.length-1].toLowerCase(); }

  function audit(text){
    var findings = [];
    var principals = {};   // name -> {name, rules:[], order}
    var principalOrder = [];
    var seenLines = {};    // normalized -> first line no
    var lines = text.split("\n");
    var nonEmpty = 0;

    function add(sev, line, code, message, fix){
      findings.push({severity:sev, line:line, code:code, message:message, fix:fix});
    }
    function getPrincipal(name){
      if(!principals[name]){
        principals[name] = {name:name, rules:[]};
        principalOrder.push(name);
      }
      return principals[name];
    }

    for(var i=0;i<lines.length;i++){
      var n = i+1;
      var raw = lines[i];
      var t = raw.replace(/\s+$/,"").replace(/^\s+/,"");
      if(t === ""){ continue; }
      nonEmpty++;

      // Include directives (sudoers writes them with # or @).
      if(/^(#|@)include(dir)?\b/i.test(t)){
        var isDir = /includedir/i.test(t);
        add("INFO", n, "INCLUDE-NOT-CHECKED",
          "Line " + n + " is an include directive (" + (isDir ? "#includedir" : "#include") + "). The files it pulls in were not pasted, so their content is NOT CHECKED by this grade.",
          "Paste each included file or fragment into this tool separately and grade it before installing anything.");
        continue;
      }

      // Full-line comments.
      if(t.charAt(0) === "#"){
        if(SECRET_RE.test(t)){
          add("WARNING", n, "SECRET-IN-COMMENT",
            "Line " + n + " appears to contain a password-shaped value in a comment. The value is deliberately not shown here or in the reports.",
            "Remove the secret from the comment — sudoers files are often world-readable in backups and repos — and rotate the credential if it was real.");
        }
        continue;
      }

      // Defaults lines.
      if(/^Defaults\b/.test(t)){
        var normD = t.replace(/\s+/g," ");
        if(seenLines[normD] !== undefined){
          add("INFO", n, "DUPLICATE",
            "Line " + n + " duplicates line " + seenLines[normD] + " exactly.",
            "Delete the duplicate at line " + n + " so the file states each setting once.");
        } else { seenLines[normD] = n; }

        if(/!authenticate\b/.test(t)){
          add("WARNING", n, "DEFAULTS-NOAUTH",
            "Line " + n + " sets Defaults !authenticate — sudo stops asking for a password entirely for the scope of this line.",
            "Remove !authenticate from line " + n + " so every sudo use requires the user's password.");
        }
        var mTs = t.match(/timestamp_timeout\s*=\s*(-?\d+)/);
        if(mTs){
          var ts = parseInt(mTs[1],10);
          if(ts === 0){
            add("INFO", n, "TIMESTAMP-ZERO",
              "Line " + n + " sets timestamp_timeout=0 — sudo always asks for a password. That is the strict, good setting.",
              "No fix needed. Keep timestamp_timeout=0 if the strictest prompting is what you want.");
          } else if(ts < 0){
            add("WARNING", n, "TIMESTAMP-NEVER",
              "Line " + n + " sets timestamp_timeout to a negative value — a entered password never expires for that session, so one unlock lasts indefinitely.",
              "Set timestamp_timeout to a value from 0 to 15 on line " + n + " so password caching always expires.");
          } else if(ts > 15){
            add("WARNING", n, "TIMESTAMP-LONG",
              "Line " + n + " sets timestamp_timeout=" + ts + " — a password stays cached for " + ts + " minutes, well past the 15-minute ceiling. Anyone at the unlocked terminal inherits root for that whole window.",
              "Lower timestamp_timeout on line " + n + " to 15 or less — or 0 to always ask.");
          }
        }
        continue;
      }

      // Alias definitions: valid sudoers, no privilege granted by themselves.
      if(/^(User_Alias|Runas_Alias|Host_Alias|Cmnd_Alias)\b/.test(t)){
        var normA = t.replace(/\s+/g," ");
        if(seenLines[normA] !== undefined){
          add("INFO", n, "DUPLICATE",
            "Line " + n + " duplicates line " + seenLines[normA] + " exactly.",
            "Delete the duplicate at line " + n + ".");
        } else { seenLines[normA] = n; }
        continue;
      }

      // Everything else should be a user specification: principal hosts = (runas) tags: commands
      var eq = t.indexOf("=");
      if(eq < 0){
        add("WARNING", n, "UNPARSABLE",
          "Line " + n + " could not be parsed as a sudoers rule, a Defaults line, an alias, or a comment, so it was excluded from grading. Its content is not reproduced here.",
          "Check line " + n + " against sudoers syntax, fix or remove it, and confirm the whole file with visudo -c on the host.");
        continue;
      }
      var left = t.slice(0,eq).replace(/\s+$/,"");
      var right = t.slice(eq+1).replace(/^\s+/,"");
      var leftTokens = left.split(/\s+/);
      var principal = leftTokens[0];
      if(!principal || (!PRINCIPAL_RE.test(principal) && !ALIAS_NAME_RE.test(principal)) || right === ""){
        add("WARNING", n, "UNPARSABLE",
          "Line " + n + " could not be parsed as a sudoers rule, so it was excluded from grading. Its content is not reproduced here.",
          "Check line " + n + " against sudoers syntax, fix or remove it, and confirm the whole file with visudo -c on the host.");
        continue;
      }

      // Duplicate identical rule lines.
      var norm = t.replace(/\s+/g," ");
      var isDup = seenLines[norm] !== undefined;
      if(isDup){
        add("INFO", n, "DUPLICATE",
          "Line " + n + " duplicates line " + seenLines[norm] + " exactly — the same grant stated twice for principal " + principal + ".",
          "Delete the duplicate at line " + n + "; one statement of the grant is enough.");
      } else { seenLines[norm] = n; }

      // Runas spec.
      var runas = "root";
      var rest = right;
      if(rest.charAt(0) === "("){
        var close = rest.indexOf(")");
        if(close > 0){ runas = rest.slice(1,close).replace(/\s+/g,""); rest = rest.slice(close+1).replace(/^\s+/,""); }
      }
      var runasAll = /(^|:|,)ALL(,|:|$)/.test(runas);

      // Command list: split on commas, stripping per-command tags.
      var segments = rest.split(",");
      var commands = [];
      var lineNopasswd = /NOPASSWD\s*:/i.test(right);
      for(var s=0;s<segments.length;s++){
        var seg = segments[s].replace(/^\s+/,"").replace(/\s+$/,"");
        var guard = 0;
        while(TAG_RE.test(seg) && guard < 8){ seg = seg.replace(TAG_RE,""); guard++; }
        if(seg === ""){ continue; }
        var sp = seg.search(/\s/);
        var cpath = sp < 0 ? seg : seg.slice(0,sp);
        var cargs = sp < 0 ? "" : seg.slice(sp+1).replace(/^\s+/,"");
        commands.push({path:cpath, args:cargs, raw:seg});
      }
      if(commands.length === 0){
        add("WARNING", n, "UNPARSABLE",
          "Line " + n + " names principal " + principal + " but lists no command that could be parsed, so it was excluded from grading.",
          "Give line " + n + " an explicit command list, or remove the line, then confirm with visudo -c on the host.");
        continue;
      }

      var hasAll = false;
      var ruleScore = 0;
      for(var c=0;c<commands.length;c++){
        var cmd = commands[c];
        var cmdScore = 12;

        if(cmd.path === "ALL"){
          hasAll = true;
          cmdScore = 60;
          if(lineNopasswd){
            add("BLOCKER", n, "NOPASSWD-ALL",
              "Principal " + principal + " on line " + n + " has NOPASSWD: ALL — any command at all, run as " + (runasAll ? "any user" : runas) + ", with no password asked. Anyone (or any script or malware) running as " + principal + " gets full root instantly, with no checkpoint.",
              "Remove this grant. Replace ALL with the specific absolute command paths " + principal + " actually needs, and drop NOPASSWD so a password is always required.");
          } else {
            add("WARNING", n, "FULL-ACCESS",
              "Principal " + principal + " on line " + n + " can run ALL commands as " + (runasAll ? "any user" : runas) + " (ALL=(ALL) ALL-style full access). A password is still asked, but once given there is no limit on what can be run.",
              "Replace ALL on line " + n + " with the specific absolute command paths " + principal + " actually needs; reserve full ALL access for named human admins only.");
          }
        } else if(ALIAS_NAME_RE.test(cmd.path) && cmd.path.indexOf("/") < 0){
          cmdScore = 20; // command alias reference — contents defined elsewhere
        } else {
          // Relative path.
          if(cmd.path.charAt(0) !== "/"){
            add("WARNING", n, "RELATIVE-PATH",
              "Principal " + principal + " on line " + n + " is granted the relative command path \"" + cmd.path + "\" (no leading /). A relative or bare name can resolve to a different, attacker-planted binary.",
              "Rewrite the command on line " + n + " as a full absolute path (for example /usr/bin/" + cmd.path + ") so sudo runs exactly one known binary.");
            cmdScore = Math.max(cmdScore, 22);
          }
          // Shell escapes.
          var base = basename(cmd.path);
          if(base === "systemctl" && /\bedit\b/.test(cmd.args)){
            add("WARNING", n, "SHELL-ESCAPE",
              "Principal " + principal + " on line " + n + " is granted \"systemctl edit\": it opens a text editor as root to modify unit files, and that editor can shell out or save over other files — an editor escape to root.",
              "Remove systemctl edit from line " + n + ". Grant only the specific actions needed (for example /usr/bin/systemctl restart <unit>) and edit unit files through your normal admin path.");
            cmdScore = Math.max(cmdScore, 35);
          } else if(ESCAPES[base]){
            add("WARNING", n, "SHELL-ESCAPE",
              "Principal " + principal + " on line " + n + " is granted " + cmd.path + " — " + ESCAPES[base],
              "Remove " + cmd.path + " from line " + n + ", or wrap the exact allowed operation in a small root-owned script with fixed arguments and grant only that script.");
            cmdScore = Math.max(cmdScore, 35);
          }
          // Wildcards.
          if(cmd.raw.indexOf("*") >= 0){
            add("WARNING", n, "WILDCARD",
              "Principal " + principal + " on line " + n + " is granted a command containing a wildcard: " + cmd.path + (cmd.args ? " " + cmd.args : "") + ". A * can match files or arguments beyond the one case you had in mind — a wildcard in an argument can be steered to protected files, quietly widening the grant.",
              "Spell the command and its arguments out in full on line " + n + " with no *, listing each allowed variation as its own entry.");
            cmdScore = Math.max(cmdScore, 40);
          }
          if(cmd.args){ cmdScore = Math.max(cmdScore, 18); }
        }
        ruleScore = Math.max(ruleScore, cmdScore);
      }

      if(lineNopasswd && !hasAll){
        add("INFO", n, "NOPASSWD-SPECIFIC",
          "Principal " + principal + " on line " + n + " runs the listed command(s) with NOPASSWD — no password prompt. The grant itself is narrow, but anything running as " + principal + " can invoke it unattended.",
          "Keep NOPASSWD on line " + n + " only if this is an unattended service account that truly needs it; otherwise remove NOPASSWD so a password is asked.");
      }

      if(lineNopasswd){ ruleScore += 8; }
      if(runasAll){ ruleScore += 6; }
      if(commands.length > 1){ ruleScore += 4; }

      // Describe the grant for the summary / last-match checks.
      var desc;
      if(hasAll){
        desc = "ALL commands (unrestricted)";
      } else {
        var names = [];
        for(var d=0;d<commands.length && d<3;d++){
          names.push(commands[d].args ? commands[d].path + " " + commands[d].args : commands[d].path);
        }
        desc = names.join("; ") + (commands.length > 3 ? "; … (+" + (commands.length-3) + " more)" : "");
      }
      desc += " — as " + (runasAll ? "ALL users" : runas);
      if(lineNopasswd){ desc += ", passwordless (NOPASSWD)"; }

      var p = getPrincipal(principal);
      // LAST-MATCH-WINS: later rule broader than the broadest earlier rule it beats.
      var beaten = null;
      for(var r=0;r<p.rules.length;r++){
        if(p.rules[r].score < ruleScore && (!beaten || p.rules[r].score > beaten.score)){ beaten = p.rules[r]; }
      }
      if(beaten){
        add("WARNING", n, "LAST-MATCH-WINS",
          "Line " + n + " gives principal " + principal + " a broader grant than line " + beaten.line + " did. sudo applies the LAST matching rule, so line " + n + " is the one that actually takes effect — the narrower line " + beaten.line + " gives a false sense of restriction.",
          "Reorder or merge the rules for " + principal + ": keep the broadest intended grant only, and delete the narrower line " + beaten.line + " (or the broader line " + n + ") so the file says one thing.");
      }
      p.rules.push({line:n, score:ruleScore, desc:desc, nopasswd:lineNopasswd, runas:runas, runasAll:runasAll, hasAll:hasAll});
    }

    // Sort findings: BLOCKER, WARNING, INFO; then by line.
    var rank = {BLOCKER:0, WARNING:1, INFO:2};
    findings.sort(function(a,b){
      if(rank[a.severity] !== rank[b.severity]){ return rank[a.severity]-rank[b.severity]; }
      return a.line - b.line;
    });

    var counts = {BLOCKER:0, WARNING:0, INFO:0};
    for(var f=0;f<findings.length;f++){ counts[findings[f].severity]++; }

    var verdict;
    if(nonEmpty === 0){ verdict = null; }
    else if(counts.BLOCKER > 0){ verdict = "DO NOT INSTALL"; }
    else if(counts.WARNING > 0){ verdict = "INSTALL WITH FIXES"; }
    else { verdict = "SAFE TO INSTALL"; }

    var summary = [];
    for(var pi=0; pi<principalOrder.length; pi++){
      var pr = principals[principalOrder[pi]];
      var best = pr.rules[0];
      for(var q=1;q<pr.rules.length;q++){ if(pr.rules[q].score > best.score){ best = pr.rules[q]; } }
      summary.push({principal:pr.name, broadest:best.desc, line:best.line, nopasswd:best.nopasswd, runas:best.runas, ruleCount:pr.rules.length});
    }

    return {verdict:verdict, counts:counts, total:findings.length, findings:findings, principals:summary, nonEmpty:nonEmpty};
  }

  function buildTextReport(res){
    var out = [];
    out.push("J-Dawgs Sudoers Privilege Safety Auditor — Report");
    out.push("==================================================");
    if(res.verdict === null){
      out.push("Verdict: (no input — paste a sudoers file or fragment to grade it)");
    } else {
      out.push("Verdict: " + res.verdict);
    }
    out.push("Counts: BLOCKER " + res.counts.BLOCKER + " / WARNING " + res.counts.WARNING + " / INFO " + res.counts.INFO + " — total findings: " + res.total);
    out.push("");
    out.push("Findings:");
    if(res.findings.length === 0){
      out.push(res.verdict === null ? "  (none — nothing pasted yet)" : "  (none — no problems found in the pasted text)");
    }
    for(var i=0;i<res.findings.length;i++){
      var f = res.findings[i];
      out.push("  [" + f.severity + "] Line " + f.line + " — " + f.code + ": " + f.message);
      out.push("      Fix: " + f.fix);
    }
    out.push("");
    out.push("Per-principal summary (broadest grant):");
    if(res.principals.length === 0){ out.push("  (no user or group rules found in the pasted text)"); }
    for(var j=0;j<res.principals.length;j++){
      var p = res.principals[j];
      out.push("  " + p.principal + ": " + p.broadest + " (line " + p.line + ")");
    }
    out.push("");
    out.push("Notes: This grade covers only the pasted text. Included files (#includedir / #include) were not pasted and are NOT CHECKED. This tool does not certify sudoers syntax — visudo -c on the target host remains the final on-host syntax check.");
    return out.join("\n");
  }

  function buildJsonReport(res){
    return JSON.stringify({
      tool: "J-Dawgs Sudoers Privilege Safety Auditor",
      verdict: res.verdict,
      counts: {blocker: res.counts.BLOCKER, warning: res.counts.WARNING, info: res.counts.INFO, total: res.total},
      findings: res.findings.map(function(f){
        return {severity:f.severity, line:f.line, code:f.code, message:f.message, fix:f.fix};
      }),
      principals: res.principals.map(function(p){
        return {principal:p.principal, broadestGrant:p.broadest, line:p.line, nopasswd:p.nopasswd, runas:p.runas, ruleCount:p.ruleCount};
      }),
      notes: [
        "Grade covers only the pasted text; included files were not pasted and are not checked.",
        "This tool does not certify sudoers syntax; visudo -c on the target host remains the final on-host syntax check."
      ]
    }, null, 2);
  }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_A": (typeof EXAMPLE_A !== 'undefined' ? EXAMPLE_A : undefined), "EXAMPLE_B": (typeof EXAMPLE_B !== 'undefined' ? EXAMPLE_B : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-sudoers-privilege-safety-auditor',
  name: 'J-Dawgs Sudoers Privilege Safety Auditor',
  description: 'visudo checks syntax and stops; this grades a pasted sudoers file anywhere — NOPASSWD: ALL, shell-escape commands, wildcard commands, last-match-wins conflicts — into one install verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_A": __core["EXAMPLE_A"], "EXAMPLE_B": __core["EXAMPLE_B"] }
};
