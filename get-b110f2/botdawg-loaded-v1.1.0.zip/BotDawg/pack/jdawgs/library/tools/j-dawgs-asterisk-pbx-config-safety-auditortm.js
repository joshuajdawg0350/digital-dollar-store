'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Asterisk PBX Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

/* ================= samples ================= */

var RISKY = [
"; Risky sample - a small-office PBX config with common mistakes planted in it.",
"[general]",
"allowguest=yes",
"bindaddr=0.0.0.0",
"context=from-public",
"register => 5550134:trunkpass@sip.provider.example",
"",
"[1001]",
"type=friend",
"host=dynamic",
"secret=1234",
"context=from-public",
"insecure=invite",
"permit=0.0.0.0/0.0.0.0",
"",
"[1002]",
"type=friend",
"host=dynamic",
"secret=password",
"context=from-public"
].join("\n");

var HARDENED = [
"; Hardened sample - internal phones only, TLS signaling, SRTP media, restricted ACL.",
"[transport-tls]",
"type=transport",
"protocol=tls",
"bind=192.0.2.10",
"cert_file=/etc/asterisk/keys/pbx.crt",
"priv_key_file=/etc/asterisk/keys/pbx.key",
"",
"[office-acl]",
"type=acl",
"deny=0.0.0.0/0.0.0.0",
"permit=192.0.2.0/255.255.255.0",
"",
"[1001]",
"type=endpoint",
"transport=transport-tls",
"context=internal-phones",
"disallow=all",
"allow=ulaw",
"media_encryption=sdes",
"acl=office-acl",
"auth=auth1001",
"aors=1001",
"",
"[auth1001]",
"type=auth",
"auth_type=userpass",
"username=1001",
"password=Tr7!kQ9wz2Lp#eX4vB8nR3",
"",
"[1001]",
"type=aor",
"max_contacts=1"
].join("\n");

var SHARE_TEXT = [
"Serve It, Pipe It, List It Honest Stack \u2014 J-Dawgs Asterisk PBX Config Safety Auditor\u2122 + J-Dawgs Fluent Bit Config Safety Auditor\u2122 + J-Dawgs Real Estate Listing & Disclosure Consistency Auditor\u2122: check the phone system, check the log pipeline, cross-check the listing before anyone signs.",
"",
"J-Dawgs Asterisk PBX Config Safety Auditor\u2122 \u2014 paste a sip.conf or pjsip.conf and get one deploy verdict (SAFE TO DEPLOY / DEPLOY WITH FIXES / DO NOT DEPLOY) with line-numbered security findings and fixes; secret values are never shown.",
"J-Dawgs Fluent Bit Config Safety Auditor\u2122 \u2014 grades a Fluent Bit pipeline config for unsafe inputs, parsers, and outputs before the pipeline ships.",
"J-Dawgs Real Estate Listing & Disclosure Consistency Auditor\u2122 \u2014 cross-checks a listing against its disclosures so the numbers and claims agree before anyone signs.",
"",
"AI Tool Store: https://muse.ai/s/ai-tool-store",
"J-Dawgs Agent Exchange: https://muse.ai/s/j-dawgs-agent-exchange-ih6xlnihzxdhxc/ZbleqxFHRE0NcswaBkyN13y9lLp5rPAgHTb6t8ii-PY"
].join("\n");

/* ================= helpers ================= */

function esc(s){
  return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
}
function trim(s){ return s.replace(/^\s+|\s+$/g,""); }
function truthy(v){
  v = trim(String(v)).toLowerCase();
  return v==="yes"||v==="true"||v==="on"||v==="1";
}
function stripPort(v){
  v = trim(String(v));
  var m = v.match(/^\[?([0-9a-fA-F:.\/]+)\]?(?::\d+)?$/);
  return m ? m[1] : v;
}
function isOpenBind(v){
  var ip = stripPort(v);
  return ip==="0.0.0.0" || ip==="::" || ip==="0.0.0.0/0";
}

/* ================= parser =================
   Produces sections with entries, plus a NOT PARSED list.
   Nothing about an unparsed line is guessed, and its content is
   never carried into any output (it could hold a credential). */

function parseConfig(text){
  var rawLines = text.split(/\r?\n/);
  var sections = [];
  var notParsed = [];
  var current = null;
  var i, raw, line, lineNo;

  function ensureSection(){
    if(!current){
      current = { name:"(before any section)", type:null, line:0, template:false, entries:[] };
      sections.push(current);
    }
    return current;
  }

  for(i=0;i<rawLines.length;i++){
    raw = rawLines[i];
    lineNo = i+1;
    line = trim(raw);
    if(line==="") continue;
    if(line.charAt(0)===";") continue;                       /* comment */
    if(line.indexOf("#include")===0) continue;               /* include directive */
    if(line.charAt(0)==="#" && line.indexOf("=")===-1) continue; /* comment */

    if(line.charAt(0)==="["){
      var close = line.indexOf("]");
      if(close===-1){
        notParsed.push({ line:lineNo, reason:"Section header is missing its closing bracket, so the section was not opened." });
        current = null;
        continue;
      }
      var inside = line.substring(1, close);
      var name = trim(inside.split("(")[0]);
      if(name===""){
        notParsed.push({ line:lineNo, reason:"Section header has no name, so the section was not opened." });
        current = null;
        continue;
      }
      current = { name:name, type:null, line:lineNo, template:/\(\s*!/.test(inside), entries:[] };
      sections.push(current);
      continue;
    }

    var eq = line.indexOf("=");
    if(eq===-1){
      notParsed.push({ line:lineNo, reason:"Line is not a section header and has no key = value form." });
      continue;
    }
    var key = trim(line.substring(0, eq)).replace(/>$/,"");
    key = trim(key).toLowerCase();
    var value = trim(line.substring(eq+1));
    if(value.charAt(0)===">") value = trim(value.substring(1));
    var sc = value.search(/\s;/);
    if(sc>=0) value = trim(value.substring(0, sc));
    if(key===""){
      notParsed.push({ line:lineNo, reason:"Line has an equals sign but no key name before it." });
      continue;
    }
    var sec = ensureSection();
    sec.entries.push({ key:key, value:value, line:lineNo });
    if(key==="type") sec.type = trim(value).toLowerCase();
  }
  return { sections:sections, notParsed:notParsed, totalLines:rawLines.length };
}

/* ================= audit ================= */

var PLACEHOLDERS = ["1234","12345","123456","1234567","12345678","123456789","0000","1111","123","password","password1","changeme","secret","admin","asterisk","default","letmein","test"];
var PUBLIC_CONTEXTS = ["from-public","from-trunk","from-pstn","from-external","from-did","public","external","from-internet"];

function audit(text){
  var parsed = parseConfig(text);
  var sections = parsed.sections;
  var findings = [];
  var coverage = [];

  function add(sev, line, title, detail, fix){
    findings.push({ sev:sev, line:line, title:title, detail:detail, fix:fix });
  }
  function entriesWhere(key){
    var out = [];
    sections.forEach(function(s){
      s.entries.forEach(function(e){ if(e.key===key) out.push({ section:s, entry:e }); });
    });
    return out;
  }
  function sectionHas(sec, key){
    for(var i=0;i<sec.entries.length;i++) if(sec.entries[i].key===key) return sec.entries[i];
    return null;
  }
  function isEndpointSection(s){
    if(!s.type) return true; /* sip.conf style: untyped sections are peers/endpoints */
    return ["endpoint","friend","peer","user","aor"].indexOf(s.type)>=0 && s.type!=="aor" ? true : (s.type==="endpoint");
  }

  /* ---- gather global facts ---- */
  var guestEntries = entriesWhere("allowguest");
  var guestOn = guestEntries.some(function(r){ return truthy(r.entry.value); });
  var contextEntries = entriesWhere("context");
  var anyContext = contextEntries.length>0;

  var bindKeys = ["bindaddr","bind","udpbindaddr","tcpbindaddr","tlsbindaddr"];
  var bindEntries = [];
  bindKeys.forEach(function(k){ entriesWhere(k).forEach(function(r){ bindEntries.push(r); }); });
  var openBinds = bindEntries.filter(function(r){ return isOpenBind(r.entry.value); });

  var secretEntries = [];
  ["secret","password"].forEach(function(k){ entriesWhere(k).forEach(function(r){ secretEntries.push(r); }); });
  var weakSecretExists = secretEntries.some(function(r){
    var v = r.entry.value;
    return PLACEHOLDERS.indexOf(v.toLowerCase())>=0 || v.length<8;
  });

  var permitEntries = entriesWhere("permit");
  var openPermitExists = permitEntries.some(function(r){ return stripPort(r.entry.value).indexOf("0.0.0.0")===0; });

  /* TLS / transport facts */
  var tlsPresent = false, tlsLine = null, plaintextTransports = [];
  sections.forEach(function(s){
    if(s.type==="transport"){
      var proto = sectionHas(s,"protocol");
      if(proto){
        var p = trim(proto.value).toLowerCase();
        if(p==="tls"){ tlsPresent = true; tlsLine = proto.line; }
        else if(p==="udp"||p==="tcp"){ plaintextTransports.push({ line:proto.line, proto:p, section:s.name }); }
      }
    }
  });
  entriesWhere("tlsbindaddr").forEach(function(r){ tlsPresent = true; tlsLine = r.entry.line; });
  entriesWhere("tlsenable").forEach(function(r){ if(truthy(r.entry.value)){ tlsPresent = true; tlsLine = r.entry.line; } });
  entriesWhere("transport").forEach(function(r){
    if(/tls/i.test(r.entry.value)){ tlsPresent = true; if(tlsLine===null) tlsLine = r.entry.line; }
  });
  var sipStyle = sections.some(function(s){
    return s.name.toLowerCase()==="general" || (s.type && ["friend","peer","user"].indexOf(s.type)>=0);
  }) || bindEntries.length>0;

  /* SRTP facts */
  var srtpPresent = false, srtpLine = null;
  entriesWhere("media_encryption").forEach(function(r){
    var v = trim(r.entry.value).toLowerCase();
    if(v==="sdes"||v==="srtp"||v==="dtls"){ srtpPresent = true; srtpLine = r.entry.line; }
  });
  entriesWhere("encryption").forEach(function(r){ if(truthy(r.entry.value)){ srtpPresent = true; srtpLine = r.entry.line; } });
  entriesWhere("dtls_enable").forEach(function(r){ if(truthy(r.entry.value)){ srtpPresent = true; srtpLine = r.entry.line; } });

  /* dialplan contexts with external/DID wildcard patterns (if dialplan text was pasted too) */
  var dialplanExternal = {}; /* context name -> line of wildcard exten */
  sections.forEach(function(s){
    s.entries.forEach(function(e){
      if(e.key==="exten"){
        var pat = trim(e.value.split(",")[0]);
        if(pat.indexOf(".")>=0 || /X{4,}/.test(pat) || /^_?\d{4,}$/.test(pat)){
          if(!(s.name.toLowerCase() in dialplanExternal)) dialplanExternal[s.name.toLowerCase()] = e.line;
        }
      }
    });
  });

  /* ================= CHECK 1: guest access ================= */
  guestEntries.forEach(function(r){
    if(truthy(r.entry.value)){
      var reachable = anyContext || openBinds.length>0;
      add(reachable ? "BLOCKER" : "WARNING", r.entry.line,
        "Guest access is enabled (allowguest)",
        "Unauthenticated callers are accepted and landed in a dialplan context" + (anyContext ? " \u2014 this file sets context= entries that guest calls can reach" : "") + ". Anyone who can reach this PBX can place calls as a guest, which is the classic route into toll fraud.",
        "Set allowguest=no in [general], and require every endpoint to authenticate.");
    } else {
      add("INFO", r.entry.line,
        "Guest access is explicitly off (allowguest)",
        "allowguest is present in the file and set to a disabled value. Unauthenticated callers are not accepted by this setting.",
        "No change needed for this key \u2014 keep it off.");
    }
  });
  if(guestEntries.length===0){
    coverage.push({ check:"allowguest (guest access)", set:false, where:"\u2014",
      note:"NOT SET IN FILE. The auditor does not assume the running default; set allowguest explicitly so the posture is reviewed, not inherited." });
  } else {
    coverage.push({ check:"allowguest (guest access)", set:true, where:"Line "+guestEntries[0].entry.line,
      note: guestOn ? "Set, and enabled \u2014 see findings." : "Set, and disabled." });
  }

  /* ================= CHECK 2: insecure= ================= */
  entriesWhere("insecure").forEach(function(r){
    var v = trim(r.entry.value).toLowerCase();
    if(v==="no"||v==="") return;
    var tokens = v.split(/[,\s]+/);
    var hasInvite = tokens.indexOf("invite")>=0;
    var hasPort = tokens.indexOf("port")>=0;
    if(v==="very" || (hasInvite && hasPort)){
      add("BLOCKER", r.entry.line,
        "insecure= disables both port and invite authentication checks",
        "This section matches callers loosely and does not require authentication on incoming INVITEs. Combined, anyone who can reach the port can place calls through this endpoint without knowing its secret.",
        "Remove insecure= entirely, or set insecure=no, and let endpoints authenticate normally.");
    } else if(hasInvite || v==="yes"){
      add("WARNING", r.entry.line,
        "insecure=invite skips authentication on incoming calls",
        "INVITEs arriving for this endpoint are not challenged for the endpoint secret. The endpoint can be used to place calls by anyone who can reach it and guess or learn its name.",
        "Remove insecure=invite (or set insecure=no) unless a trunk provider formally requires it \u2014 and then restrict the section with permit/deny ACLs.");
    } else if(hasPort){
      add("WARNING", r.entry.line,
        "insecure=port loosens caller matching",
        "The source port is ignored when matching this endpoint, which weakens the address checks Asterisk applies to it. Lower risk than the invite form, but still a deliberate loosening.",
        "Remove insecure=port unless a provider requires it; prefer exact host= or ACL-restricted matching.");
    } else {
      add("WARNING", r.entry.line,
        "insecure= is set to a non-default value",
        "An insecure mode is requested for this section. Any insecure mode relaxes how Asterisk authenticates or matches this endpoint.",
        "Set insecure=no, or remove the key, unless the mode is formally required by a provider.");
    }
  });

  /* ================= CHECK 3: endpoint secrets (values never rendered) ================= */
  secretEntries.forEach(function(r){
    var v = r.entry.value;
    var keyName = r.entry.key;
    if(PLACEHOLDERS.indexOf(v.toLowerCase())>=0){
      add("BLOCKER", r.entry.line,
        "Placeholder-pattern secret on the `" + keyName + "` key",
        "The value on this key matches a known placeholder pattern \u2014 a common default that appears in tutorials and example files. It is graded by pattern and length only; the value itself is never shown here. Anyone scanning this PBX will try it early.",
        "Replace it with a unique random secret of at least 16 characters, stored in a credential vault, and different from every other endpoint.");
    } else if(v.length<8){
      add("BLOCKER", r.entry.line,
        "Critically short secret on the `" + keyName + "` key (" + v.length + " characters)",
        "Graded by length only \u2014 the value is never shown. At under 8 characters, this secret can be brute-forced quickly against a reachable PBX.",
        "Replace it with a unique random secret of at least 16 characters.");
    } else if(v.length<12){
      add("WARNING", r.entry.line,
        "Short secret on the `" + keyName + "` key (" + v.length + " characters)",
        "Graded by length only \u2014 the value is never shown. Secrets under 12 characters fall fast to offline guessing if any hash or response is captured.",
        "Lengthen it to at least 16 random characters.");
    } else {
      add("INFO", r.entry.line,
        "Secret on the `" + keyName + "` key passes the length check (" + v.length + " characters)",
        "Length only: this tool does not test the value against any database or dictionary, and never displays it. Length is necessary, not sufficient \u2014 uniqueness still matters.",
        "No change required by this check. Keep the secret unique to this endpoint.");
    }
  });
  entriesWhere("md5secret").forEach(function(r){
    add("INFO", r.entry.line,
      "md5secret present (hashed secret form)",
      "A hashed secret is configured on this line. Presence is reported by key name and line only; the hash is never shown. Note the MD5 form is a legacy hash \u2014 it resists casual reading of the file, not a determined offline attack.",
      "Prefer a long, unique plaintext secret in a protected config file, or keep md5secret only where the deployment requires it.");
  });

  /* ================= CHECK 4: register strings (values never rendered) ================= */
  entriesWhere("register").forEach(function(r){
    var v = r.entry.value;
    var at = v.indexOf("@"), colon = v.indexOf(":");
    var embedded = at>0 && colon>0 && colon<at;
    if(embedded){
      add("WARNING", r.entry.line,
        "Outbound register string carries an embedded credential",
        "This register line embeds a provider credential in plain text. It is reported by key name and line only \u2014 the credential is never shown. Anyone who reads this file owns the trunk registration.",
        "Restrict the config file's permissions (owner-read only), rotate the provider credential if this file has been shared, and never paste this file into tickets or chats.");
    } else {
      add("INFO", r.entry.line,
        "Outbound register string present",
        "A registration to an outside provider is configured. Reported by key name and line only; no credential appears in this line's parsed form.",
        "No change required by this check. Keep the file's permissions tight.");
    }
  });

  /* ================= CHECK 5: bind exposure + escalation ================= */
  openBinds.forEach(function(r){
    var factors = [];
    if(guestOn) factors.push("guest access is enabled");
    if(weakSecretExists) factors.push("at least one endpoint secret is weak or a placeholder");
    if(openPermitExists) factors.push("a permit ACL opens the endpoint to every address");
    if(factors.length>0){
      add("BLOCKER", r.entry.line,
        "PBX listens on every interface (" + r.entry.key + " is a wildcard bind), paired with live weaknesses",
        "This bind exposes the PBX on all network interfaces while " + factors.join(", and ".replace(", and", " and")) + ". Exposure plus any one of those turns a configuration mistake into an internet-reachable one.",
        "Bind to the specific interface address the PBX should serve, put the PBX behind a firewall that only admits known peers, and clear the paired weaknesses listed in this report.");
    } else {
      add("WARNING", r.entry.line,
        "PBX listens on every interface (" + r.entry.key + " is a wildcard bind)",
        "The PBX accepts signaling on all interfaces. No guest access, weak secret, or open ACL was found in this file to pair with it, but the exposure leaves no network-layer margin if a weak endpoint is added later.",
        "Bind to the specific interface address, or firewall the PBX to known peer addresses.");
    }
  });

  /* ================= CHECK 6: plaintext transports / TLS ================= */
  if(plaintextTransports.length>0 && !tlsPresent){
    var pt = plaintextTransports[0];
    add("WARNING", pt.line,
      "Plaintext transports only \u2014 no TLS transport in the file",
      "A " + pt.proto.toUpperCase() + " transport is configured and no TLS transport exists anywhere in the file. Signaling \u2014 including authentication exchanges and dialed numbers \u2014 crosses the network readable by anyone on the path.",
      "Add a TLS transport (protocol=tls with a certificate) and move endpoints to it; keep plaintext transports only on trusted local networks, if at all.");
  } else if(sipStyle && !tlsPresent && bindEntries.length>0){
    add("WARNING", bindEntries[0].entry.line,
      "No TLS signaling configured \u2014 chan_sip defaults to plaintext",
      "Nothing in this file enables TLS (no tlsenable, no tlsbindaddr, no TLS transport), so signaling runs over plaintext UDP/TCP. Authentication exchanges and dialed numbers cross the network readable by anyone on the path.",
      "Enable TLS (tlsenable=yes with a certificate and tlsbindaddr) or migrate endpoints to a PJSIP TLS transport.");
  }
  if(tlsPresent){
    coverage.push({ check:"TLS transport (encrypted signaling)", set:true, where:"Line "+tlsLine, note:"A TLS transport or TLS bind is configured." });
  } else {
    coverage.push({ check:"TLS transport (encrypted signaling)", set:false, where:"\u2014",
      note:"NOT SET IN FILE. No TLS transport, tlsbindaddr, or tlsenable appears in the file." });
  }

  /* ================= CHECK 7: SRTP / media encryption ================= */
  if(!srtpPresent){
    var epLine = null;
    sections.forEach(function(s){ if(epLine===null && isEndpointSection(s) && s.line>0) epLine = s.line; });
    add("WARNING", epLine,
      "Media encryption (SRTP) is not required anywhere",
      "No endpoint in this file requires encrypted media (no media_encryption=sdes/srtp/dtls, no encryption=yes). Call audio can travel in the clear even where signaling is protected.",
      "Require SRTP on endpoints (media_encryption=sdes or dtls for PJSIP; encryption=yes for chan_sip) and confirm the far end supports it.");
    coverage.push({ check:"SRTP / media encryption required", set:false, where:"\u2014",
      note:"NOT SET IN FILE. No media_encryption, encryption, or dtls_enable key requires encrypted media." });
  } else {
    coverage.push({ check:"SRTP / media encryption required", set:true, where:"Line "+srtpLine, note:"At least one endpoint requires encrypted media." });
  }

  /* ================= CHECK 8: context hygiene ================= */
  contextEntries.forEach(function(r){
    var ctx = trim(r.entry.value);
    var ctxLow = ctx.toLowerCase();
    var sec = r.section;
    var secInsecure = sectionHas(sec, "insecure");
    var insecureActive = secInsecure && trim(secInsecure.value).toLowerCase()!=="no";
    if(ctxLow in dialplanExternal){
      add("BLOCKER", r.entry.line,
        "Section [" + sec.name + "] lands in context `" + ctx + "`, which carries external/DID wildcard patterns",
        "Dialplan text in this file shows the `" + ctx + "` context matching wildcard/DID patterns (line " + dialplanExternal[ctxLow] + "). Endpoints \u2014 and guests, if enabled \u2014 that land here can reach outbound-style patterns directly.",
        "Point this section at an internal-only context that contains no external or wildcard patterns, and keep public/DID contexts separate with their own restricted endpoints.");
    } else if(PUBLIC_CONTEXTS.indexOf(ctxLow)>=0){
      if(insecureActive){
        add("BLOCKER", r.entry.line,
          "Public-facing context `" + ctx + "` combined with insecure= in section [" + sec.name + "]",
          "This section sends calls into a public-style context and also relaxes authentication with insecure=. Unauthenticated or loosely matched callers landing in a public context is the textbook toll-fraud setup.",
          "Remove insecure= from this section and point it at an internal-only context; give public/DID traffic its own locked-down endpoint.");
      } else {
        add("WARNING", r.entry.line,
          "Section [" + sec.name + "] uses the public-facing context `" + ctx + "`",
          "Endpoints or defaults that land in a from-public style context inherit whatever that context can dial \u2014 typically outbound routes. That is the right place for a provider trunk, and the wrong default for phones or guests.",
          "Point internal endpoints at an internal-only context; reserve public contexts for the trunk sections that need them.");
      }
    } else if(ctxLow==="default"){
      add("WARNING", r.entry.line,
        "Section [" + sec.name + "] uses the `default` context",
        "The default context is where unauthenticated and unmatched calls collect in many sample dialplans. Endpoints pointed at it inherit whatever accumulated there.",
        "Create a named internal context for this section and point context= at it.");
    }
  });
  var endpointsMissingContext = [];
  sections.forEach(function(s){
    if(s.template) return;
    var endpointish = s.type ? (s.type==="endpoint"||s.type==="friend"||s.type==="peer"||s.type==="user") : (s.name.toLowerCase()!=="general" && s.line>0);
    if(!endpointish) return;
    if(s.name==="(before any section)") return;
    if(!sectionHas(s,"context")) endpointsMissingContext.push(s);
  });
  endpointsMissingContext.forEach(function(s){
    add("INFO", s.line,
      "No context set on section [" + s.name + "] \u2014 NOT SET IN FILE for this section",
      "With no context= of its own, this endpoint's calls fall back to the default context. The auditor does not assume what that context can dial.",
      "Set context= explicitly on this section to a named internal context.");
  });
  coverage.push({ check:"Endpoint contexts", set: endpointsMissingContext.length===0, where: anyContext ? "context= present" : "\u2014",
    note: endpointsMissingContext.length===0 ? "Every endpoint-style section sets its own context." :
      endpointsMissingContext.length + " endpoint-style section(s) set no context \u2014 NOT SET IN FILE for those sections; they fall back to the default context." });

  /* ================= CHECK 9: permit/deny ACLs ================= */
  var anyAcl = permitEntries.length>0 || entriesWhere("deny").length>0;
  permitEntries.forEach(function(r){
    if(stripPort(r.entry.value).indexOf("0.0.0.0")===0){
      var hasDeny = !!sectionHas(r.section, "deny");
      if(!hasDeny){
        add("WARNING", r.entry.line,
          "permit opens section [" + r.section.name + "] to every address, with no deny restriction",
          "permit=0.0.0.0/0.0.0.0 and no deny= in the same section means this endpoint accepts connections from any source address on the network. The endpoint's secret is the only thing left guarding it.",
          "Add deny=0.0.0.0/0.0.0.0 first, then permit only the exact subnets that should reach this endpoint \u2014 or narrow the permit to those subnets.");
      }
    }
  });
  entriesWhere("acl").forEach(function(){ /* a named ACL reference counts as ACL use */ anyAcl = true; });
  if(!anyAcl){
    add("INFO", null,
      "No permit/deny ACLs anywhere in this file \u2014 NOT SET IN FILE",
      "Nothing in the file restricts which source addresses may reach these endpoints. That is stated plainly, not judged: on a PBX reachable only from a trusted LAN it may be a deliberate choice, but it is a choice this file does not record.",
      "Add deny=0.0.0.0/0.0.0.0 plus permit lines for the subnets that should reach each endpoint, or an equivalent named ACL.");
    coverage.push({ check:"permit/deny ACLs", set:false, where:"\u2014",
      note:"NOT SET IN FILE. No permit, deny, or acl key appears anywhere in the file." });
  } else {
    coverage.push({ check:"permit/deny ACLs", set:true, where:"Line "+(permitEntries.length?permitEntries[0].entry.line:entriesWhere("deny")[0].entry.line),
      note: openPermitExists ? "ACLs exist, but at least one permit opens an endpoint to every address \u2014 see findings." : "ACLs are present and no permit opens an endpoint to every address." });
  }

  /* ================= CHECK 10: duplicates ================= */
  var seen = {};
  sections.forEach(function(s){
    if(s.line===0) return;
    var k = s.name.toLowerCase() + "|" + (s.type||"");
    if(seen[k] !== undefined){
      add("WARNING", s.line,
        "Duplicate section [" + s.name + "]" + (s.type ? " (type=" + s.type + ")" : ""),
        "This section name" + (s.type ? " and type" : "") + " was already defined at line " + seen[k] + ". Asterisk merges or overrides duplicated sections in ways that are easy to misread \u2014 the setting you think is live may not be.",
        "Merge the two definitions into one section, or rename one of them.");
    } else {
      seen[k] = s.line;
    }
  });

  /* ================= CHECK 11: not parsed ================= */
  parsed.notParsed.forEach(function(np){
    add("NOT PARSED", np.line,
      "Line could not be parsed \u2014 reported, not guessed",
      np.reason + " The line's content is withheld from this report in case it contains a credential. Asterisk may reject or silently skip such a line, so what you think is configured may not be.",
      "Rewrite the line as key = value inside a [section], or comment it out with a leading semicolon if it is a note.");
  });

  /* ---- sort: severity rank, then line ---- */
  var rank = { "BLOCKER":0, "WARNING":1, "NOT PARSED":2, "INFO":3 };
  findings.sort(function(a,b){
    if(rank[a.sev]!==rank[b.sev]) return rank[a.sev]-rank[b.sev];
    var la = a.line===null?99999:a.line, lb = b.line===null?99999:b.line;
    return la-lb;
  });

  var counts = { blockers:0, warnings:0, info:0, notParsed:0 };
  findings.forEach(function(f){
    if(f.sev==="BLOCKER") counts.blockers++;
    else if(f.sev==="WARNING") counts.warnings++;
    else if(f.sev==="INFO") counts.info++;
    else if(f.sev==="NOT PARSED") counts.notParsed++;
  });

  var verdict;
  if(counts.blockers>0) verdict = "DO NOT DEPLOY";
  else if(counts.warnings>0 || counts.notParsed>0) verdict = "DEPLOY WITH FIXES";
  else verdict = "SAFE TO DEPLOY";

  return { findings:findings, coverage:coverage, counts:counts, verdict:verdict, totalLines:parsed.totalLines };
}
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-asterisk-pbx-config-safety-auditortm',
  name: 'J-Dawgs Asterisk PBX Config Safety Auditor',
  description: 'Grades a pasted Asterisk sip.conf/pjsip.conf offline — guest access, insecure=, weak secrets by length only, TLS/SRTP posture, wildcard-bind escalation — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
