'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Ryot Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------------- Built-in examples (all secrets below are fake) ---------------- */
      var RISKY = [
        "# Ryot server config - RISKY example (built in; every secret below is fake)",
        "DATABASE_URL=postgres://ryot:PlantedPw!4821@db.remote-host.net:5432/ryot",
        "JWT_SECRET=tinykey7",
        "ADMIN_PASSWORD=changeme-planted-99",
        "SERVER_HOST=0.0.0.0",
        "SERVER_PORT=8000",
        "NODE_ENV=development",
        "DEBUG=true",
        "MEDIA_WEBHOOK_URL=http://hooks.remote-relay.net/ryot-events"
      ].join("\n");

      var HARDENED = [
        "# Ryot server config - HARDENED example (built in; every value below is fake)",
        "DATABASE_URL=postgres://ryot_app@db.internal.lan:5432/ryot",
        "JWT_SECRET=vR8kQ2mZ9pL4xN7wT3sY6bH1cF5jD0aGeK2nP8qW4",
        "API_TOKEN=Zx7Qw9Er2Ty5Ui8Op1As3Df6Gh0Jk4Lz9Xc2Vb5Nm7",
        "SERVER_HOST=127.0.0.1",
        "SERVER_PORT=8000",
        "NODE_ENV=production",
        "DEBUG=false",
        "MEDIA_WEBHOOK_URL=https://hooks.internal.lan/ryot-events"
      ].join("\n");

      var PLANTED = ["PlantedPw!4821", "tinykey7", "changeme-planted-99"];

      /* ---------------- Parsing ---------------- */
      var SECRET_RE = /(SECRET|JWT|TOKEN|PASSWORD|PASSWD|PASSPHRASE|API_?KEY|PRIVATE_?KEY|ACCESS_?KEY|CREDENTIAL)/;
      var RECOGNIZED_RE = /(DATABASE|DB_|SECRET|JWT|TOKEN|PASSWORD|PASSWD|API|HOST|BIND|PORT|NODE_?ENV|DEBUG|URL|URI|UNSAFE|INSECURE|CORS|ORIGIN|ENV|MODE|LISTEN|ADDRESS)/;
      var PLACEHOLDERS = ["changeme","change-me","change_me","example","password","passwd","secret","your-","your_","xxx","12345","letmein","default","replace-me","replace_me","todo","placeholder"];

      function normalizeKey(raw){
        return raw.trim().toUpperCase().replace(/[\s.\-]+/g,"_").replace(/_+/g,"_");
      }
      function stripQuotes(v){
        v = v.trim();
        if (v.length >= 2 && ((v.charAt(0)==='"' && v.charAt(v.length-1)==='"') || (v.charAt(0)==="'" && v.charAt(v.length-1)==="'"))){
          return v.slice(1,-1);
        }
        var hashIdx = v.indexOf(" #");
        if (hashIdx > 0) v = v.slice(0, hashIdx).trim();
        return v;
      }

      function parseConfig(text){
        var rawLines = String(text == null ? "" : text).split(/\r\n|\r|\n/);
        var entries = [];
        var meaningful = 0;
        var stack = []; // {indent, seg}
        for (var i = 0; i < rawLines.length; i++){
          var lineNo = i + 1;
          var raw = rawLines[i];
          var trimmed = raw.trim();
          if (trimmed === "") continue;
          if (trimmed.charAt(0) === "#" || trimmed.indexOf("//") === 0) continue;
          meaningful++;
          var indent = raw.length - raw.replace(/^\s+/, "").length;
          var key = null, value = null, matched = false;
          var m = trimmed.match(/^([A-Za-z0-9_.\-]+)\s*=\s*(.*)$/);
          if (m){ key = m[1]; value = m[2]; matched = true; }
          else {
            var m2 = trimmed.match(/^([A-Za-z0-9_.\-]+)\s*:\s+(.*)$/);
            if (m2){ key = m2[1]; value = m2[2]; matched = true; }
            else {
              var m3 = trimmed.match(/^([A-Za-z0-9_.\-]+)\s*:\s*$/);
              if (m3){ key = m3[1]; value = ""; matched = true; }
            }
          }
          if (!matched) continue;
          while (stack.length && stack[stack.length-1].indent >= indent) stack.pop();
          var segs = stack.map(function(s){ return s.seg; });
          segs.push(key);
          var fullKey = normalizeKey(segs.join("_"));
          var leafKey = normalizeKey(key);
          var val = stripQuotes(value == null ? "" : value);
          var entry = { line: lineNo, key: fullKey, leaf: leafKey, value: val, indent: indent, isParent: false };
          entries.push(entry);
          if (val === "") stack.push({ indent: indent, seg: key });
        }
        // A key with an empty value that has deeper-indented children is a YAML parent, not an empty setting.
        for (var j = 0; j < entries.length; j++){
          if (entries[j].value !== "") continue;
          for (var k = j + 1; k < entries.length; k++){
            if (entries[k].indent > entries[j].indent){ entries[j].isParent = true; break; }
            if (entries[k].indent <= entries[j].indent) break;
          }
        }
        return { entries: entries, meaningful: meaningful, totalLines: rawLines.length };
      }

      function isDbUrlKey(key){ return key === "DATABASE_URL" || key === "DB_URL" || /DATABASE.*URL/.test(key); }
      function isTruthy(v){
        var s = String(v).toLowerCase();
        return s === "true" || s === "1" || s === "yes" || s === "on";
      }

      /* ---------------- Audit ---------------- */
      function audit(text){
        var parsed = parseConfig(text);
        var entries = parsed.entries;
        var findings = [];
        var recognized = 0, hasDb = false, hasSecret = false;

        function add(sev, line, key, issue, fix, lenLabel, lenVal){
          var f = { severity: sev, line: line, key: key, issue: issue, fix: fix };
          if (lenLabel){ f[lenLabel] = lenVal; }
          findings.push(f);
        }

        entries.forEach(function(e){
          if (RECOGNIZED_RE.test(e.key)) recognized++;
          if (e.isParent) return;
          var key = e.key, val = e.value, low = val.toLowerCase();

          if (isDbUrlKey(key) && val !== "") hasDb = true;
          var secretLike = SECRET_RE.test(key);
          if (secretLike && val !== "") hasSecret = true;
          if (secretLike && val === "" && !isDbUrlKey(key)) hasSecret = hasSecret || false;

          // 1) URL with an embedded plaintext password (any key, DATABASE_URL first among them)
          var cred = val.match(/^[a-zA-Z][a-zA-Z0-9+.\-]*:\/\/[^:\/?#\s]+:([^@\/?#\s]+)@/);
          if (cred){
            add("critical", e.line, key,
              (isDbUrlKey(key) ? "Database URL" : "URL in this setting") + " embeds a plaintext password in the connection string.",
              "Move the password out of the URL: pass it through a secret manager or a separate password variable, and rotate the exposed password now — treat it as compromised.",
              "passwordLength", cred[1].length);
            return; // one finding per line is enough for this entry
          }

          // 2) Secret-like keys: empty, placeholder, or too short
          if (secretLike){
            if (val === ""){
              add("critical", e.line, key,
                "Secret key is present but empty.",
                "Set a real, randomly generated value of at least 32 characters before deploying.",
                "valueLength", 0);
              return;
            }
            var ph = null;
            for (var p = 0; p < PLACEHOLDERS.length; p++){ if (low.indexOf(PLACEHOLDERS[p]) !== -1){ ph = PLACEHOLDERS[p]; break; } }
            if (ph){
              add("critical", e.line, key,
                "Secret value matches a known example/placeholder pattern — it is not a real secret.",
                "Replace it with a randomly generated secret of at least 32 characters (for example: openssl rand -hex 32) and store it in a secret manager, not in the repo.",
                "valueLength", val.length);
              return;
            }
            if (val.length < 16){
              add("critical", e.line, key,
                "Secret is very short (" + val.length + " characters) — trivially guessable or brute-forceable.",
                "Generate a random secret of at least 32 characters (for example: openssl rand -hex 32).",
                "valueLength", val.length);
              return;
            }
            if (val.length < 32){
              add("warning", e.line, key,
                "Secret is short (" + val.length + " characters); 32 or more is the safe floor.",
                "Lengthen it to at least 32 randomly generated characters and rotate it on a schedule.",
                "valueLength", val.length);
              return;
            }
          }

          // 3) All-interface bind
          if (/(HOST|BIND|LISTEN|ADDRESS)/.test(key) && (val === "0.0.0.0" || val === "::" || val === "[::]")){
            add("warning", e.line, key,
              "Server binds to all network interfaces (" + (val === "::" ? "IPv6 any" : "0.0.0.0") + "), exposing it to the whole network.",
              "Bind to 127.0.0.1 or a private interface and put a reverse proxy or firewall in front, unless this service is intentionally public.",
              null, null);
            return;
          }

          // 4) Debug / development mode / unsafe flags
          if (/DEBUG/.test(key) && isTruthy(val)){
            add("warning", e.line, key,
              "Debug mode is switched on.",
              "Set debug to false for deployment — debug output leaks internals and stack traces.",
              null, null);
            return;
          }
          if (/(NODE_?ENV|^ENV$|ENVIRONMENT|MODE)/.test(key) && (low === "development" || low === "dev" || low === "debug" || low === "local")){
            add("warning", e.line, key,
              "Environment is set to a development mode.",
              "Set the environment to production for deployment so dev-only behavior, verbose errors, and relaxed checks stay off.",
              null, null);
            return;
          }
          if (/(UNSAFE|INSECURE|SKIP_?VERIFY|DISABLE_?AUTH|ALLOW_?ALL|PERMISSIVE)/.test(key) && isTruthy(val)){
            add("warning", e.line, key,
              "An unsafe/permissive flag is switched on.",
              "Turn this flag off for deployment; if it was enabled to work around an error, fix the underlying error instead.",
              null, null);
            return;
          }
          if (/(CORS|ORIGIN)/.test(key) && val === "*"){
            add("warning", e.line, key,
              "CORS origin is a wildcard — any website can call this server as your users.",
              "Restrict allowed origins to your real domains instead of *.",
              null, null);
            return;
          }

          // 5) Plain http:// for an external service
          if (low.indexOf("http://") === 0){
            var host = val.slice(7).split(/[\/?#:]/)[0].toLowerCase();
            var local = (host === "localhost" || host === "127.0.0.1" || host === "::1" || host === "[::1]" || host === "");
            if (!local){
              add("warning", e.line, key,
                "External service endpoint uses plain http:// — traffic, tokens, and data cross the network in clear text.",
                "Switch the endpoint to https:// and confirm the service supports TLS before deploying.",
                null, null);
              return;
            }
          }
        });

        // Empty secret keys still count as "a secret key exists" for coverage purposes.
        entries.forEach(function(e){ if (!e.isParent && SECRET_RE.test(e.key)) hasSecret = true; });

        var notEnough = parsed.meaningful < 3 || recognized === 0 || (!hasDb && !hasSecret);
        var verdict;
        if (notEnough){
          verdict = "NOT ENOUGH TO GRADE";
        } else {
          if (!hasDb){
            add("warning", null, "DATABASE_URL",
              "No database URL setting was found in the pasted config.",
              "Add the DATABASE_URL entry (without an embedded plaintext password) so database safety can be graded.",
              null, null);
          }
          if (!hasSecret){
            add("warning", null, "(none found)",
              "No secret/JWT/token key was found in the pasted config.",
              "Add the server's secret keys so they can be graded — a config with no secrets usually means they are hardcoded or missing.",
              null, null);
          }
          findings.sort(function(a,b){
            var sa = a.severity === "critical" ? 0 : 1, sb = b.severity === "critical" ? 0 : 1;
            if (sa !== sb) return sa - sb;
            return (a.line || 0) - (b.line || 0);
          });
          var crits = findings.filter(function(f){ return f.severity === "critical"; }).length;
          var warns = findings.length - crits;
          if (crits > 0) verdict = "DO NOT DEPLOY";
          else if (warns > 0) verdict = "DEPLOY WITH FIXES";
          else verdict = "SAFE TO DEPLOY";
        }

        return {
          verdict: verdict,
          linesScanned: parsed.totalLines,
          meaningfulLines: parsed.meaningful,
          keysRecognized: recognized,
          criticalCount: findings.filter(function(f){ return f.severity === "critical"; }).length,
          warningCount: findings.filter(function(f){ return f.severity === "warning"; }).length,
          findings: findings
        };
      }

      /* ---------------- Report + JSON (never contains secret values) ---------------- */
      function buildReport(r){
        var out = [];
        out.push("J-Dawgs Ryot Server Config Safety Auditor\u2122 - Audit Report");
        out.push("Verdict: " + r.verdict);
        out.push("Lines scanned: " + r.linesScanned + " | Meaningful lines: " + r.meaningfulLines + " | Keys recognized: " + r.keysRecognized);
        out.push("Critical findings: " + r.criticalCount + " | Warnings: " + r.warningCount);
        out.push("");
        if (r.findings.length === 0){
          out.push(r.verdict === "NOT ENOUGH TO GRADE"
            ? "No findings: there was not enough recognizable config to grade."
            : "No findings: nothing flagged. This is a config check only - it does not prove the server runs or the database accepts the connection.");
        } else {
          out.push("Findings:");
          r.findings.forEach(function(f, i){
            var lineStr = f.line ? ("Line " + f.line) : "Line -";
            var lenStr = "";
            if (typeof f.passwordLength === "number") lenStr = " (password length: " + f.passwordLength + ")";
            else if (typeof f.valueLength === "number") lenStr = " (value length: " + f.valueLength + ")";
            out.push((i+1) + ". [" + f.severity.toUpperCase() + "] " + lineStr + " | " + f.key + " - " + f.issue + lenStr);
            out.push("   Fix: " + f.fix);
          });
        }
        out.push("");
        out.push("Secret values are never shown: findings list key name, line, and length only.");
        out.push("Offline check only - nothing was uploaded, saved, or sent.");
        return out.join("\n");
      }
      function buildJson(r){
        return JSON.stringify({
          tool: "J-Dawgs Ryot Server Config Safety Auditor",
          verdict: r.verdict,
          linesScanned: r.linesScanned,
          meaningfulLines: r.meaningfulLines,
          keysRecognized: r.keysRecognized,
          criticalCount: r.criticalCount,
          warningCount: r.warningCount,
          findings: r.findings,
          note: "Secret values are never included - key name, line, and length only."
        }, null, 2);
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-ryot-server-config-safety-auditortm',
  name: 'J-Dawgs Ryot Server Config Safety Auditor',
  description: '',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
