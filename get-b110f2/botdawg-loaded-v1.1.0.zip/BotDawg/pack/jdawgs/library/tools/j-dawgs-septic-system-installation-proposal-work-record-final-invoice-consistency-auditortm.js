'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Septic System Installation Proposal, Work Record & Final Invoice Consistency Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- helpers ---------- */
      function $(id){ return document.getElementById(id); }
      function round2(n){ return Math.round(n*100)/100; }
      function fmt(n){
        var neg = n < 0; n = Math.abs(round2(n));
        var s = n.toFixed(2), parts = s.split(".");
        parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        return (neg ? "-$" : "$") + parts[0] + "." + parts[1];
      }
      function esc(s){
        return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
      }
      function qtyFmt(n){ return (Math.round(n*100)/100).toString(); }

      /* ---------- text extraction ---------- */
      // All money amounts on a line: [{value, raw}]
      function amountsIn(line){
        var out = [], re = /(-)?\s*\$\s*(-)?([\d,]+(?:\.\d{1,2})?)/g, m;
        while((m = re.exec(line)) !== null){
          var v = parseFloat(m[3].replace(/,/g,""));
          if(m[1] || m[2]) v = -v;
          if(/\(\s*$/.test(line.slice(0, m.index))) v = -Math.abs(v);
          out.push({ value: round2(v), raw: m[0] });
        }
        return out;
      }
      // "300 linear ft × $18.00" / "28 hrs x $85.00" — quantity, some unit words, ×, unit price
      function qtyPriceIn(line){
        var m = line.match(/(\d+(?:\.\d+)?)\s*(?:[a-z]+\s+){0,3}?[x×]\s*\$?\s*([\d,]+(?:\.\d{1,2})?)/i);
        if(!m) return null;
        return { qty: parseFloat(m[1]), price: parseFloat(m[2].replace(/,/g,"")) };
      }
      function categoryOf(lower){
        if(/deposit/.test(lower)) return "deposit";
        if(/labou?r/.test(lower)) return "labor";
        if(/tank/.test(lower)) return "tank";
        if(/drain|leach/.test(lower)) return "drainfield";
        if(/permit/.test(lower)) return "permit";
        return "other";
      }
      function gallonsIn(line){
        var m = line.match(/(\d[\d,]*)\s*(?:gal|gallons?)\b/i);
        return m ? parseFloat(m[1].replace(/,/g,"")) : null;
      }
      function feetIn(line){
        var m = line.toLowerCase().match(/(\d+(?:\.\d+)?)\s*(?:linear\s+)?(?:ft|feet|foot)\b/);
        if(m) return parseFloat(m[1]);
        var qp = qtyPriceIn(line);
        return qp ? qp.qty : null;
      }
      function hoursIn(line){
        var m = line.toLowerCase().match(/(\d+(?:\.\d+)?)\s*(?:hours?|hrs?)\b/);
        if(m) return parseFloat(m[1]);
        var qp = qtyPriceIn(line);
        return qp ? qp.qty : null;
      }
      // First line in a document matching `test` that yields a value from `extract`.
      function docFind(text, test, extract){
        var lines = text.split(/\r?\n/);
        for(var i = 0; i < lines.length; i++){
          if(!test(lines[i].toLowerCase())) continue;
          var v = extract(lines[i]);
          if(v !== null && v !== undefined) return { value: v, line: i + 1, raw: lines[i].trim() };
        }
        return null;
      }
      function docGallons(text){
        return docFind(text, function(l){ return /tank/.test(l); }, gallonsIn);
      }
      function docTankValue(text){
        return docFind(text, function(l){ return /tank/.test(l); }, function(line){
          var a = amountsIn(line);
          return a.length ? Math.abs(a[a.length - 1].value) : null;
        });
      }
      function docDrain(text){
        return docFind(text, function(l){ return /drain|leach/.test(l); }, function(line){
          var q = feetIn(line);
          if(q === null) return null;
          var qp = qtyPriceIn(line);
          return { qty: q, price: qp ? qp.price : null };
        });
      }
      function docLaborHours(text){
        return docFind(text, function(l){ return /labou?r|hours?|hrs?\b/.test(l); }, hoursIn);
      }
      function docPermit(text){
        return docFind(text, function(l){ return /permit/.test(l); }, function(line){
          var a = amountsIn(line);
          return a.length ? Math.abs(a[a.length - 1].value) : null;
        });
      }
      function docDeposit(text){
        return docFind(text, function(l){ return /deposit/.test(l); }, function(line){
          var a = amountsIn(line);
          return a.length ? Math.abs(a[0].value) : null;
        });
      }
      function laborRate(text){
        var lines = text.split(/\r?\n/);
        for(var i = 0; i < lines.length; i++){
          if(!/labou?r/.test(lines[i].toLowerCase())) continue;
          var qp = qtyPriceIn(lines[i]);
          if(qp) return { rate: qp.price, line: i + 1 };
        }
        for(var j = 0; j < lines.length; j++){
          var lower = lines[j].toLowerCase();
          if(/per\s*hour|\/\s*(hr|hour)|hourly|rate/.test(lower) && /labou?r|hour|rate/.test(lower)){
            var a = amountsIn(lines[j]);
            if(a.length) return { rate: Math.abs(a[0].value), line: j + 1 };
          }
        }
        return null;
      }
      function normalizeLabel(line){
        var s = line.replace(/^\s*[-•*]\s*/, "");
        s = s.replace(/-?\s*\$\s*-?[\d,]+(?:\.\d{1,2})?/g, " ");
        s = s.replace(/\d+(?:\.\d+)?\s*[x×]\s*/g, " ");
        s = s.replace(/=.*$/, " ");
        s = s.toLowerCase().replace(/[^a-z]+/g, " ").replace(/\s+/g, " ").trim();
        return s;
      }
      function significantWords(line){
        var stop = {each:true,with:true,fee:true,fees:true,charge:true,charges:true,surcharge:true,
          total:true,line:true,item:true,items:true,service:true,services:true,installed:true,
          septic:true,tank:true,drain:true,field:true,leach:true,labor:true,labour:true,
          hours:true,hour:true,permit:true,gallon:true,gallons:true,linear:true,feet:true,foot:true,
          paid:true,credit:true,received:true,recorded:true,actual:true,billed:true};
        var words = normalizeLabel(line).split(" "), out = [];
        for(var i = 0; i < words.length; i++){
          if(words[i].length >= 4 && !stop[words[i]]) out.push(words[i]);
        }
        return out;
      }

      /* ---------- invoice parsing ---------- */
      function parseInvoice(text){
        var lines = text.split(/\r?\n/), items = [], totalLine = null, subtotalLine = null;
        lines.forEach(function(raw, i){
          var line = raw.trim();
          if(!line) return;
          var amounts = amountsIn(line);
          if(!amounts.length) return;
          var lower = line.toLowerCase();
          var isSubtotal = /subtotal/.test(lower);
          var isTotal = !isSubtotal && /(grand\s+total|total\s+due|total|balance\s+due|amount\s+due)/.test(lower);
          var entry = { line: i + 1, raw: line, amounts: amounts, category: categoryOf(lower) };
          if(isSubtotal){ entry.amount = amounts[amounts.length - 1].value; subtotalLine = entry; return; }
          if(isTotal){ entry.amount = amounts[amounts.length - 1].value; totalLine = entry; return; }
          var qp = qtyPriceIn(line);
          entry.qtyPrice = qp;
          var total;
          var eq = line.lastIndexOf("=");
          if(eq >= 0){
            var after = amountsIn(line.slice(eq));
            if(after.length) total = after[after.length - 1].value;
          }
          if(total === undefined){
            if(qp && amounts.length === 1) total = round2(qp.qty * qp.price);
            else total = amounts[amounts.length - 1].value;
          }
          entry.amount = round2(total);
          entry.label = normalizeLabel(line);
          entry.corrected = entry.amount;
          items.push(entry);
        });
        return { items: items, totalLine: totalLine, subtotalLine: subtotalLine };
      }

      /* ---------- the audit ---------- */
      function audit(proposal, work, invoice){
        proposal = proposal || ""; work = work || ""; invoice = invoice || "";
        if(!proposal.trim() && !work.trim() && !invoice.trim()){
          return { empty: true, verdict: "NO DOCUMENTS", totalOvercharge: 0, findings: [],
                   correctedGross: null, correctedDue: null, statedDue: null };
        }
        var findings = [];
        function add(sev, title, detail, amount, refs){
          findings.push({ severity: sev, title: title, detail: detail,
            amount: round2(amount || 0), refs: refs || [] });
        }
        if(!proposal.trim()) add("minor", "Proposal is empty", "No proposal was pasted, so proposed quantities, the labor rate, and the deposit terms could not be checked.", 0, []);
        if(!work.trim()) add("minor", "Work record is empty", "No work record was pasted, so the tank size installed, drain-field feet installed, recorded hours, and the recorded permit fee could not be verified against the invoice.", 0, []);
        if(!invoice.trim()) add("minor", "Invoice is empty", "No invoice was pasted, so there is nothing billed to check.", 0, []);

        var inv = parseInvoice(invoice);
        var corpus = (proposal + "\n" + work).toLowerCase();

        /* facts from the work record (falling back to the proposal) */
        var wrGal = docGallons(work), propGal = docGallons(proposal);
        var instGal = wrGal || propGal, instGalSrc = wrGal ? "Work record" : "Proposal";
        var wrTankVal = docTankValue(work), propTankVal = docTankValue(proposal);
        var instTankVal = wrTankVal || propTankVal, instTankValSrc = wrTankVal ? "Work record" : "Proposal";
        var wrDrain = docDrain(work), propDrain = docDrain(proposal);
        var instDrain = wrDrain || propDrain, instDrainSrc = wrDrain ? "Work record" : "Proposal";
        var recHours = docLaborHours(work);
        var wrPermit = docPermit(work), propPermit = docPermit(proposal);
        var recPermit = wrPermit || propPermit, recPermitSrc = wrPermit ? "Work record" : "Proposal";
        var wrDep = docDeposit(work), propDep = docDeposit(proposal);
        var depPaid = wrDep || propDep, depPaidSrc = wrDep ? "Work record" : "Proposal";
        var rateInfo = laborRate(proposal) || laborRate(work);

        /* (1) tank size billed above installed */
        var tankItems = inv.items.filter(function(it){ return it.category === "tank"; });
        if(tankItems.length){
          var t = tankItems[0];
          var billedGal = gallonsIn(t.raw);
          if(billedGal !== null && instGal && billedGal > instGal.value){
            if(instTankVal && t.amount > instTankVal.value + 0.005){
              var tOver = round2(t.amount - instTankVal.value);
              add("critical", "Tank billed above installed size",
                "Invoice bills a " + qtyFmt(billedGal) + " gal tank at " + fmt(t.amount) + ", but the " +
                instGalSrc.toLowerCase() + " shows a " + qtyFmt(instGal.value) + " gal tank installed, valued at " +
                fmt(instTankVal.value) + ". Overcharge: " + fmt(t.amount) + " − " + fmt(instTankVal.value) + " = " + fmt(tOver) + ".",
                tOver, ["Invoice line " + t.line, instGalSrc + " line " + instGal.line, instTankValSrc + " line " + instTankVal.line]);
              t.corrected = instTankVal.value;
            } else {
              add("critical", "Tank billed above installed size — price basis not shown",
                "Invoice bills a " + qtyFmt(billedGal) + " gal tank, but the " + instGalSrc.toLowerCase() +
                " shows a " + qtyFmt(instGal.value) + " gal tank installed, and no installed-tank value was found to price the difference. Confirm the tank size before paying.",
                0, ["Invoice line " + t.line, instGalSrc + " line " + instGal.line]);
            }
          } else if(instTankVal && t.amount > instTankVal.value + 0.005 && billedGal !== null && instGal && billedGal >= instGal.value){
            var tpOver = round2(t.amount - instTankVal.value);
            add("critical", "Tank billed above recorded price",
              "Invoice bills the tank at " + fmt(t.amount) + "; the " + instTankValSrc.toLowerCase() +
              " values the installed tank at " + fmt(instTankVal.value) + ". Overcharge: " + fmt(t.amount) +
              " − " + fmt(instTankVal.value) + " = " + fmt(tpOver) + ".",
              tpOver, ["Invoice line " + t.line, instTankValSrc + " line " + instTankVal.line]);
            t.corrected = instTankVal.value;
          }
        }

        /* (2) drain-field feet billed above installed */
        var drainItems = inv.items.filter(function(it){ return it.category === "drainfield"; });
        if(drainItems.length && instDrain){
          var d = drainItems[0];
          var billedFt = feetIn(d.raw);
          if(billedFt !== null && billedFt > instDrain.value.qty){
            var unit = d.qtyPrice ? d.qtyPrice.price : instDrain.value.price;
            if(unit === null && billedFt > 0 && d.amount > 0) unit = round2(d.amount / billedFt);
            var extraFt = round2(billedFt - instDrain.value.qty);
            if(unit !== null){
              var dOver = round2(extraFt * unit);
              var instVal = round2(instDrain.value.qty * unit);
              add("critical", "Drain field billed above installed length",
                "Invoice bills " + qtyFmt(billedFt) + " linear ft of drain field at " + fmt(unit) + "/ft = " + fmt(d.amount) +
                ". The " + instDrainSrc.toLowerCase() + " shows " + qtyFmt(instDrain.value.qty) + " ft installed (" +
                qtyFmt(instDrain.value.qty) + " × " + fmt(unit) + " = " + fmt(instVal) + "). Overcharge: " +
                qtyFmt(extraFt) + " ft not installed × " + fmt(unit) + " = " + fmt(dOver) + ".",
                dOver, ["Invoice line " + d.line, instDrainSrc + " line " + instDrain.line]);
              d.corrected = instVal;
            } else {
              add("minor", "Drain field billed above installed length — price not shown",
                "Invoice bills " + qtyFmt(billedFt) + " ft but the " + instDrainSrc.toLowerCase() + " shows " +
                qtyFmt(instDrain.value.qty) + " ft installed, and no per-foot price was found, so the dollar amount needs a manual check.",
                0, ["Invoice line " + d.line, instDrainSrc + " line " + instDrain.line]);
            }
          }
        }

        /* (3) labor billed above recorded hours × rate */
        var laborItems = inv.items.filter(function(it){ return it.category === "labor"; });
        if(laborItems.length && recHours){
          var billedLabor = round2(laborItems.reduce(function(s, it){ return s + it.amount; }, 0));
          var rate = rateInfo ? rateInfo.rate : (laborItems[0].qtyPrice ? laborItems[0].qtyPrice.price : null);
          var billedHours = laborItems[0].qtyPrice ? laborItems[0].qtyPrice.qty : hoursIn(laborItems[0].raw);
          if(rate !== null && billedLabor > round2(recHours.value * rate) + 0.005){
            var allowed = round2(recHours.value * rate), lOver = round2(billedLabor - allowed);
            var extraHrs = billedHours !== null ? round2(billedHours - recHours.value) : null;
            add("critical", "Labor billed above recorded hours × rate",
              "Invoice bills labor at " + fmt(billedLabor) + (billedHours !== null ? " (" + qtyFmt(billedHours) + " hrs × " + fmt(rate) + "/hr)" : "") +
              ". The work record shows " + qtyFmt(recHours.value) + " hrs; " + qtyFmt(recHours.value) + " × " + fmt(rate) + " = " +
              fmt(allowed) + " is supported" + (extraHrs !== null && extraHrs > 0 ? " — " + qtyFmt(extraHrs) + " hrs billed above actual × " + fmt(rate) + " = " + fmt(lOver) : "") +
              ". Overcharge: " + fmt(billedLabor) + " − " + fmt(allowed) + " = " + fmt(lOver) + ".",
              lOver, ["Invoice line " + laborItems[0].line, "Work record line " + recHours.line].concat(rateInfo ? [(rateInfo === laborRate(proposal) ? "Proposal" : "Work record") + " (rate)"] : []));
            laborItems.forEach(function(it, idx){ it.corrected = idx === 0 ? allowed : 0; });
          }
        }

        /* (4) permit fee billed above recorded / duplicate permit fee */
        var permitItems = inv.items.filter(function(it){ return it.category === "permit"; });
        if(permitItems.length && recPermit){
          var billedPermit = round2(permitItems.reduce(function(s, it){ return s + it.amount; }, 0));
          if(billedPermit > recPermit.value + 0.005){
            var pOver = round2(billedPermit - recPermit.value);
            add("critical", "Permit fee billed above recorded permit fee",
              "Invoice bills permit fee" + (permitItems.length > 1 ? "s" : "") + " totaling " + fmt(billedPermit) +
              (permitItems.length > 1 ? " across " + permitItems.length + " lines" : "") +
              ". The recorded permit fee is " + fmt(recPermit.value) + ". Overcharge: " + fmt(billedPermit) +
              " − " + fmt(recPermit.value) + " = " + fmt(pOver) + " — the permit was billed above the recorded fee, or billed twice.",
              pOver, ["Invoice line " + permitItems[0].line, recPermitSrc + " line " + recPermit.line]);
            permitItems.forEach(function(it, idx){ it.corrected = idx === 0 ? recPermit.value : 0; });
          }
        }

        /* (5) uncredited deposit */
        var depCredit = 0, depCreditLine = null;
        inv.items.forEach(function(it){
          if(it.category === "deposit"){ depCredit += Math.abs(it.amount); depCreditLine = it; }
        });
        depCredit = round2(depCredit);
        if(depPaid && depPaid.value > depCredit + 0.005){
          var short = round2(depPaid.value - depCredit);
          add("critical", "Deposit paid but not fully credited on the invoice",
            "Deposit paid per the " + depPaidSrc.toLowerCase() + ": " + fmt(depPaid.value) + ". Credit shown on the invoice: " +
            fmt(depCredit) + ". Uncredited deposit: " + fmt(depPaid.value) + " − " + fmt(depCredit) + " = " + fmt(short) + ".",
            short, [depPaidSrc + " line " + depPaid.line].concat(depCreditLine ? ["Invoice line " + depCreditLine.line] : []));
        }

        /* (6) duplicate fees */
        var seen = {};
        inv.items.forEach(function(it){
          if(it.category !== "other" || !it.label) return;
          if(seen[it.label]){
            var first = seen[it.label];
            if(it.amount > 0){
              add("critical", "Duplicate fee",
                "\"" + it.raw.replace(/^\s*[-•*]\s*/, "").replace(/:?\s*\$.*$/, "") + "\" appears twice on the invoice (lines " +
                first.line + " and " + it.line + "). The second charge of " + fmt(it.amount) + " is a duplicate.",
                it.amount, ["Invoice line " + first.line, "Invoice line " + it.line]);
              it.corrected = 0;
            }
            it.isDuplicate = true;
          } else seen[it.label] = it;
        });

        /* (7) invoice-only charges */
        inv.items.forEach(function(it){
          if(it.category !== "other" || it.isDuplicate) return;
          var words = significantWords(it.raw);
          var hasBasis = words.length === 0 || words.some(function(w){ return corpus.indexOf(w) >= 0; });
          if(!hasBasis && it.amount > 0){
            add("minor", "Invoice-only charge — no basis in proposal or work record",
              "\"" + it.raw.replace(/^\s*[-•*]\s*/, "").replace(/:?\s*\$.*$/, "") + "\" (" + fmt(it.amount) +
              ") appears only on the invoice. No matching item or fee appears in the proposal or the work record, so there is no documented basis for the charge.",
              it.amount, ["Invoice line " + it.line]);
            it.corrected = 0;
          }
        });

        /* (8) invoice total arithmetic */
        var stated = inv.totalLine || inv.subtotalLine;
        if(stated && inv.items.length){
          var sum = round2(inv.items.reduce(function(s, it){ return s + it.amount; }, 0));
          var diff = round2(stated.amount - sum);
          if(Math.abs(diff) > 0.01){
            add(diff >= 10 ? "critical" : "minor", "Invoice total does not match its own line items",
              "The invoice line items add to " + fmt(sum) + " but the stated " + (inv.totalLine ? "total" : "subtotal") +
              " is " + fmt(stated.amount) + ". Difference: " + fmt(stated.amount) + " − " + fmt(sum) + " = " + fmt(diff) +
              (diff > 0 ? " billed above the sum of its own lines." : " (in the customer's favor, but the invoice still needs correcting)."),
              diff > 0 ? diff : 0, ["Invoice line " + stated.line]);
          }
        }

        /* corrected totals */
        var correctedGross = null, correctedDue = null;
        if(inv.items.length){
          correctedGross = round2(inv.items.reduce(function(s, it){
            return it.category === "deposit" ? s : s + it.corrected;
          }, 0));
          var depForDue = depPaid ? depPaid.value : depCredit;
          correctedDue = round2(correctedGross - depForDue);
        }

        var total = round2(findings.reduce(function(s, f){ return s + f.amount; }, 0));
        var verdict = findings.length ? "DO NOT PAY YET" : "SAFE TO PAY";
        return { empty: false, verdict: verdict, totalOvercharge: total, findings: findings,
                 correctedGross: correctedGross, correctedDue: correctedDue,
                 statedDue: stated ? stated.amount : null };
      }

      /* ---------- built-in examples ---------- */
      var EXAMPLE_BAD = {
        proposal: [
          "SEPTIC SYSTEM INSTALLATION PROPOSAL",
          "Property: Greenfield Residence",
          "Prepared by: OnSite Septic LLC",
          "",
          "Scope of work:",
          "- Septic tank: 1000 gal tank × $3,200.00 = $3,200.00",
          "- Drain field: 300 linear ft × $18.00 = $5,400.00",
          "- Labor: 24 hrs × $85.00 = $2,040.00",
          "- Permit fee: $350.00",
          "- Deposit paid: $2,000.00"
        ].join("\n"),
        work: [
          "WORK RECORD",
          "Property: Greenfield Residence",
          "Crew: D. Ruiz and T. Bell",
          "Dates: June 8-10, 2026",
          "",
          "Installed and completed:",
          "- Septic tank installed: 1000 gal tank at $3,200.00",
          "- Drain field installed: 240 linear ft × $18.00",
          "- Labor: 20 hrs × $85.00",
          "- Permit recorded: $350.00",
          "- Deposit received: $2,000.00"
        ].join("\n"),
        invoice: [
          "FINAL INVOICE #2041",
          "Property: Greenfield Residence",
          "From: OnSite Septic LLC",
          "",
          "Line items:",
          "- Septic tank: 1500 gal tank × $4,100.00 = $4,100.00",
          "- Drain field: 300 linear ft × $18.00 = $5,400.00",
          "- Labor: 28 hrs × $85.00 = $2,380.00",
          "- Permit fee: $700.00",
          "- Inspection fee: $250.00",
          "",
          "Total due: $13,030.00"
        ].join("\n")
      };
      var EXAMPLE_CLEAN = {
        proposal: [
          "SEPTIC SYSTEM INSTALLATION PROPOSAL",
          "Property: Maple Street Residence",
          "Prepared by: OnSite Septic LLC",
          "",
          "Scope of work:",
          "- Septic tank: 1000 gal tank × $3,200.00 = $3,200.00",
          "- Drain field: 240 linear ft × $18.00 = $4,320.00",
          "- Labor: 20 hrs × $85.00 = $1,700.00",
          "- Permit fee: $350.00",
          "- Deposit paid: $2,000.00"
        ].join("\n"),
        work: [
          "WORK RECORD",
          "Property: Maple Street Residence",
          "Crew: D. Ruiz and T. Bell",
          "",
          "Installed and completed:",
          "- Septic tank installed: 1000 gal tank at $3,200.00",
          "- Drain field installed: 240 linear ft × $18.00",
          "- Labor: 20 hrs × $85.00",
          "- Permit recorded: $350.00",
          "- Deposit received: $2,000.00"
        ].join("\n"),
        invoice: [
          "FINAL INVOICE #2042",
          "Property: Maple Street Residence",
          "From: OnSite Septic LLC",
          "",
          "Line items:",
          "- Septic tank: 1000 gal tank × $3,200.00 = $3,200.00",
          "- Drain field: 240 linear ft × $18.00 = $4,320.00",
          "- Labor: 20 hrs × $85.00 = $1,700.00",
          "- Permit fee: $350.00",
          "- Deposit credit: -$2,000.00",
          "",
          "Total due: $7,570.00"
        ].join("\n")
      };

      /* ---------- reporting ---------- */
      var lastResult = null, lastInputs = null;
      function buildReport(r){
        if(!r) return "No report yet. Run the cross-check and the report appears here, ready to copy.";
        if(r.empty) return "SEPTIC SYSTEM CONSISTENCY AUDIT\n\nNo documents were pasted. Paste a proposal, a work record, and a final invoice, then run the cross-check.";
        var out = [];
        out.push("SEPTIC SYSTEM INSTALLATION CONSISTENCY AUDIT");
        out.push("Verdict: " + r.verdict);
        out.push("Documented overcharge total: " + fmt(r.totalOvercharge));
        if(r.statedDue !== null && r.statedDue !== undefined) out.push("Stated total due on invoice: " + fmt(r.statedDue));
        if(r.correctedGross !== null) out.push("Corrected gross (what the documents support): " + fmt(r.correctedGross));
        if(r.correctedDue !== null) out.push("Corrected amount due: " + fmt(r.correctedDue));
        out.push("");
        if(!r.findings.length){
          out.push("No findings. The proposal, work record, and invoice agree on tank size and price, drain-field feet, labor, permit fee, deposit credit, and totals.");
        } else {
          r.findings.forEach(function(f, i){
            out.push((i + 1) + ". [" + f.severity.toUpperCase() + "] " + f.title + (f.amount ? " — " + fmt(f.amount) : ""));
            out.push("   " + f.detail);
            if(f.refs.length) out.push("   Source: " + f.refs.join(" · "));
          });
        }
        out.push("");
        out.push("Scope: this audit cross-checks only the three pasted documents. It does not verify field work, market prices, or payment status.");
        return out.join("\n");
      }
      function buildJSON(r){
        if(!r) return "{}";
        return JSON.stringify({
          tool: "J-Dawgs Septic System Installation Proposal, Work Record & Final Invoice Consistency Auditor",
          verdict: r.verdict,
          documentedOverchargeTotal: r.totalOvercharge,
          statedTotalDue: r.statedDue,
          correctedGross: r.correctedGross,
          correctedAmountDue: r.correctedDue,
          findings: r.findings.map(function(f){
            return { severity: f.severity, title: f.title, detail: f.detail, amount: f.amount, sources: f.refs };
          }),
          scope: "Cross-checks only the three pasted documents; does not verify field work, market prices, or payment status."
        }, null, 2);
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_BAD": (typeof EXAMPLE_BAD !== 'undefined' ? EXAMPLE_BAD : undefined), "EXAMPLE_CLEAN": (typeof EXAMPLE_CLEAN !== 'undefined' ? EXAMPLE_CLEAN : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-septic-system-installation-proposal-work-record-final-invoice-consistency-auditortm',
  name: 'J-Dawgs Septic System Installation Proposal, Work Record & Final Invoice Consistency Auditor',
  description: '',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_BAD": __core["EXAMPLE_BAD"], "EXAMPLE_CLEAN": __core["EXAMPLE_CLEAN"] }
};
