'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Quote & Estimate Consistency Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var CLEAN_EXAMPLE = [
          "Framing labor — 10 x $75.00 = $750.00",
          "Tile installation | 4 | $120.00 | $480.00",
          "Paint and finish — 2 x $90.00 = $180.00",
          "Subtotal: $1,410.00",
          "Tax (8%): $112.80",
          "Total: $1,522.80",
          "Valid for 30 days",
          "Deposit (25%): $380.70"
        ].join("\n");

        var BROKEN_EXAMPLE = [
          "Framing labor — 10 x $75.00 = $750.00",
          "Tile installation — 4 x $120.00 = $500.00",
          "Paint and finish — 2 x $90.00 = $180.00",
          "Subtotal: $1,450.00",
          "Tax (8%): $116.00",
          "Total: $1,600.00",
          "Valid until 2025-06-30",
          "Deposit (25%): $400.00"
        ].join("\n");

        var MONTHS = {
          january: 0, february: 1, march: 2, april: 3, may: 4, june: 5,
          july: 6, august: 7, september: 8, october: 9, november: 10, december: 11
        };

        var SYM = "$";

        function todayStart() {
          var d = new Date();
          return new Date(d.getFullYear(), d.getMonth(), d.getDate());
        }
        function fmtDateLong(d) {
          return d.toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" });
        }
        function isoOf(d) {
          function p(n) { return (n < 10 ? "0" : "") + n; }
          return d.getFullYear() + "-" + p(d.getMonth() + 1) + "-" + p(d.getDate());
        }
        function toCents(n) { return Math.round(n * 100); }
        function fmtMoney(centsVal) {
          var neg = centsVal < 0;
          var v = Math.abs(centsVal) / 100;
          return (neg ? "-" : "") + SYM + v.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        }
        function trimLine(s) { return s.length > 90 ? s.slice(0, 87) + "…" : s; }

        // Extract an amount (in cents) from a summary line: prefer a
        // currency-marked figure, else the last number on the line.
        // Percent figures are removed first so a rate is never read as money.
        function extractAmountCents(line) {
          var s = line.replace(/(\d+(?:\.\d+)?)\s*%/g, " ");
          var m = s.match(/[$€£]\s*(-?[\d,]+(?:\.\d{1,2})?)/);
          if (m) return toCents(parseFloat(m[1].replace(/,/g, "")));
          var nums = s.match(/-?[\d,]+(?:\.\d{1,2})?/g);
          if (nums && nums.length) return toCents(parseFloat(nums[nums.length - 1].replace(/,/g, "")));
          return null;
        }
        function extractPercent(line) {
          var m = line.match(/(\d+(?:\.\d+)?)\s*%/);
          return m ? parseFloat(m[1]) : null;
        }
        function moneyTokenCents(tok) {
          if (tok == null) return null;
          var m = String(tok).match(/-?[\d,]+(?:\.\d{1,2})?/);
          return m ? toCents(parseFloat(m[0].replace(/,/g, ""))) : null;
        }

        var ITEM_RE = /^(.+?)\s*(?:—|–|-)?\s*(\d+(?:\.\d+)?)\s*(?:x|×|\*)\s*[$€£]?\s*([\d,]+(?:\.\d{1,2})?)\s*=\s*[$€£]?\s*(-?[\d,]+(?:\.\d{1,2})?)\s*$/i;

        function parseValidityDate(line) {
          var m = line.match(/(\d{4})-(\d{2})-(\d{2})/);
          if (m) return new Date(+m[1], +m[2] - 1, +m[3]);
          m = line.match(/(\d{1,2})\/(\d{1,2})\/(\d{4})/);
          if (m) return new Date(+m[3], +m[1] - 1, +m[2]);
          m = line.match(/(january|february|march|april|may|june|july|august|september|october|november|december)\s+(\d{1,2})(?:st|nd|rd|th)?,?\s+(\d{4})/i);
          if (m) return new Date(+m[3], MONTHS[m[1].toLowerCase()], +m[2]);
          return null;
        }

        function audit(text) {
          var findings = [];
          function add(sev, lineNo, title, detail) {
            findings.push({ sev: sev, line: lineNo, title: title, detail: detail });
          }

          var hasDollar = text.indexOf("$") !== -1;
          var hasEuro = text.indexOf("€") !== -1;
          SYM = (hasEuro && !hasDollar) ? "€" : "$";

          var lines = text.split(/\r?\n/);
          var items = [];          // {line, desc, qty, unitCents, statedCents, computedCents}
          var notParsed = [];      // {line, text}
          var subtotalStated = null, subtotalLine = null;
          var taxAmt = null, taxRate = null, taxLine = null;
          var discountAmt = null, discountPct = null, discountLine = null;
          var totalStated = null, totalLine = null;
          var validity = null;     // {kind:'until', date, line} | {kind:'for', text, line} | {kind:'vague', line}
          var depositAmt = null, depositPct = null, depositLine = null;

          for (var i = 0; i < lines.length; i++) {
            var ln = i + 1;
            var raw = lines[i];
            var t = raw.trim();
            if (!t) continue;

            if (/\bvalid/i.test(t) || /\bexpir/i.test(t)) {
              if (!validity) {
                var d = parseValidityDate(t);
                var forM = t.match(/(\d+)\s*(days|day|weeks|week|months|month)/i);
                if (d) validity = { kind: "until", date: d, line: ln, raw: t };
                else if (forM) validity = { kind: "for", text: forM[0], line: ln, raw: t };
                else validity = { kind: "vague", line: ln, raw: t };
              }
              continue;
            }
            if (/^subtotal\b/i.test(t)) {
              if (subtotalStated === null) { subtotalStated = extractAmountCents(t); subtotalLine = ln; }
              continue;
            }
            if (/^(grand\s+)?total\b/i.test(t)) {
              if (totalStated === null) { totalStated = extractAmountCents(t); totalLine = ln; }
              continue;
            }
            if (/^(sales\s+)?tax\b/i.test(t)) {
              if (taxAmt === null) { taxAmt = extractAmountCents(t); taxRate = extractPercent(t); taxLine = ln; }
              continue;
            }
            if (/^discount\b/i.test(t)) {
              if (discountAmt === null && discountPct === null) {
                discountAmt = extractAmountCents(t); discountPct = extractPercent(t); discountLine = ln;
              }
              continue;
            }
            if (/\bdeposit\b/i.test(t)) {
              if (depositAmt === null && depositPct === null) {
                depositAmt = extractAmountCents(t); depositPct = extractPercent(t); depositLine = ln;
              }
              continue;
            }
            if (t.indexOf("|") !== -1) {
              var parts = t.split("|");
              if (parts.length >= 4) {
                var qtyP = parseFloat(parts[parts.length - 3].replace(/,/g, ""));
                var unitP = moneyTokenCents(parts[parts.length - 2]);
                var totP = moneyTokenCents(parts[parts.length - 1]);
                var descP = parts.slice(0, parts.length - 3).join("|").trim();
                if (!isNaN(qtyP) && unitP !== null && totP !== null && descP) {
                  items.push({ line: ln, desc: descP, qty: qtyP, unitCents: unitP, statedCents: totP, computedCents: Math.round(qtyP * unitP) });
                  continue;
                }
              }
              notParsed.push({ line: ln, text: t });
              continue;
            }
            var im = t.match(ITEM_RE);
            if (im) {
              var desc = im[1].replace(/[—–-]\s*$/, "").trim();
              var qty = parseFloat(im[2]);
              var unitC = toCents(parseFloat(im[3].replace(/,/g, "")));
              var totC = toCents(parseFloat(im[4].replace(/,/g, "")));
              if (desc) {
                items.push({ line: ln, desc: desc, qty: qty, unitCents: unitC, statedCents: totC, computedCents: Math.round(qty * unitC) });
                continue;
              }
            }
            notParsed.push({ line: ln, text: t });
          }

          // (8) NOT PARSED lines
          for (var np = 0; np < notParsed.length; np++) {
            add("INFO", notParsed[np].line, "Line " + notParsed[np].line + " — NOT PARSED",
              "“" + trimLine(notParsed[np].text) + "” does not match a line-item or summary format, so it is excluded from every sum. All sums in this audit cover parsed lines only.");
          }

          // (1) line item arithmetic
          var sumComputed = 0;
          for (var k = 0; k < items.length; k++) {
            var it = items[k];
            sumComputed += it.computedCents;
            var arith = String(it.qty) + " × " + fmtMoney(it.unitCents) + " = " + fmtMoney(it.computedCents);
            if (it.computedCents !== it.statedCents) {
              add("BLOCKER", it.line, "Line " + it.line + " — line total does not match qty × unit price (“" + trimLine(it.desc) + "”)",
                "Stated line total: " + fmtMoney(it.statedCents) + ". Computed: " + arith + ". Difference: " + fmtMoney(Math.abs(it.computedCents - it.statedCents)) + ".");
            } else {
              add("OK", it.line, "Line " + it.line + " — line total checks out (“" + trimLine(it.desc) + "”)",
                arith + " — matches the stated line total of " + fmtMoney(it.statedCents) + ".");
            }
          }

          if (items.length === 0) {
            add("BLOCKER", null, "No parseable line items found",
              "Nothing in this quote could be cross-checked. Line items must look like “Description — qty x $unit = $line-total” or “Description | qty | unit price | line total”.");
          }

          // (7) duplicate description, different unit price
          var byDesc = {};
          for (var q = 0; q < items.length; q++) {
            var key = items[q].desc.toLowerCase().replace(/\s+/g, " ");
            if (!byDesc[key]) byDesc[key] = [];
            byDesc[key].push(items[q]);
          }
          for (var key2 in byDesc) {
            if (!Object.prototype.hasOwnProperty.call(byDesc, key2)) continue;
            var group = byDesc[key2];
            for (var a = 0; a < group.length; a++) {
              for (var b = a + 1; b < group.length; b++) {
                if (group[a].unitCents !== group[b].unitCents) {
                  add("WARNING", group[b].line, "DUPLICATE ITEM, DIFFERENT PRICE — “" + trimLine(group[a].desc) + "”",
                    "Line " + group[a].line + " prices it at " + fmtMoney(group[a].unitCents) + " per unit; line " + group[b].line + " prices it at " + fmtMoney(group[b].unitCents) + " per unit. Same description, two different unit prices.");
                }
              }
            }
          }

          // (2) subtotal
          var sumExpr = items.map(function (x) { return fmtMoney(x.computedCents); }).join(" + ");
          if (subtotalStated !== null) {
            if (items.length > 0) {
              if (sumComputed !== subtotalStated) {
                add("BLOCKER", subtotalLine, "Line " + subtotalLine + " — subtotal does not match the line items",
                  "Stated subtotal: " + fmtMoney(subtotalStated) + ". Computed from parsed lines only: " + sumExpr + " = " + fmtMoney(sumComputed) + ". Difference: " + fmtMoney(Math.abs(sumComputed - subtotalStated)) + ".");
              } else {
                add("OK", subtotalLine, "Line " + subtotalLine + " — subtotal checks out",
                  "Sum of computed line totals (parsed lines only): " + sumExpr + " = " + fmtMoney(sumComputed) + " — matches the stated subtotal.");
              }
            }
          } else if (items.length > 0) {
            add("INFO", null, "No subtotal line found",
              "The computed sum of the parsed line totals is " + fmtMoney(sumComputed) + " (" + sumExpr + "), but the quote states no subtotal to check it against.");
          }
          var subtotalBase = (subtotalStated !== null) ? subtotalStated : sumComputed;
          var subtotalBaseLabel = (subtotalStated !== null) ? "stated subtotal" : "computed sum of parsed lines";

          // discount resolution (percent-only discount is taken off the subtotal base)
          var discountCents = 0;
          var discountNote = "";
          if (discountAmt !== null) { discountCents = Math.abs(discountAmt); }
          else if (discountPct !== null) {
            discountCents = Math.round(subtotalBase * discountPct / 100);
            discountNote = " (" + discountPct + "% of the " + subtotalBaseLabel + ": " + fmtMoney(subtotalBase) + " × " + discountPct + "% = " + fmtMoney(discountCents) + ")";
          }

          // (3) tax
          var taxCents = (taxAmt !== null) ? taxAmt : 0;
          if (taxAmt !== null) {
            if (taxRate !== null) {
              var taxExpected = Math.round(subtotalBase * taxRate / 100);
              var taxArith = taxRate + "% × " + fmtMoney(subtotalBase) + " (" + subtotalBaseLabel + ") = " + fmtMoney(taxExpected);
              if (Math.abs(taxExpected - taxAmt) > 1) {
                add("WARNING", taxLine, "Line " + taxLine + " — tax amount does not match the stated rate",
                  "Stated tax: " + fmtMoney(taxAmt) + ". Computed: " + taxArith + ". Difference: " + fmtMoney(Math.abs(taxExpected - taxAmt)) + ".");
              } else {
                add("OK", taxLine, "Line " + taxLine + " — tax checks out",
                  taxArith + " — matches the stated tax of " + fmtMoney(taxAmt) + " (within one cent).");
              }
            } else {
              add("INFO", taxLine, "Line " + taxLine + " — tax rate not stated, amount not verifiable",
                "A tax amount of " + fmtMoney(taxAmt) + " is stated with no rate, so it cannot be recomputed. The amount is taken as given in the total check below.");
            }
          }

          // (4) total
          var totalComputed = subtotalBase - discountCents + taxCents;
          var totalArith = fmtMoney(subtotalBase) + " (" + subtotalBaseLabel + ") − " + fmtMoney(discountCents) + " discount + " + fmtMoney(taxCents) + " tax = " + fmtMoney(totalComputed);
          if (totalStated !== null) {
            if (totalComputed !== totalStated) {
              add("BLOCKER", totalLine, "Line " + totalLine + " — total does not match subtotal − discount + tax",
                "Stated total: " + fmtMoney(totalStated) + ". Computed: " + totalArith + ". Difference: " + fmtMoney(Math.abs(totalComputed - totalStated)) + ".");
            } else {
              add("OK", totalLine, "Line " + totalLine + " — total checks out",
                totalArith + " — matches the stated total.");
            }
          } else {
            add("INFO", null, "No total line found",
              "Subtotal − discount + tax computes to " + totalArith + ", but the quote states no total to check it against.");
          }
          var totalBase = (totalStated !== null) ? totalStated : totalComputed;

          // (5) validity
          var today = todayStart();
          if (!validity) {
            add("WARNING", null, "No validity line — this quote never expires on paper",
              "No “Valid for …” or “Valid until …” line was found. As written, the quote never expires on paper; add a validity period or an expiry date.");
          } else if (validity.kind === "until") {
            if (validity.date < today) {
              add("BLOCKER", validity.line, "Line " + validity.line + " — quote already expired",
                "“Valid until " + isoOf(validity.date) + "” is in the past — today is " + isoOf(today) + ". This quote is already expired.");
            } else {
              add("OK", validity.line, "Line " + validity.line + " — validity date is in force",
                "Valid until " + isoOf(validity.date) + "; today is " + isoOf(today) + ", so the date has not passed.");
            }
          } else if (validity.kind === "for") {
            add("OK", validity.line, "Line " + validity.line + " — validity period stated",
              "The quote states it is valid for " + validity.text + ", so it does carry an expiry term.");
          } else {
            add("INFO", validity.line, "Line " + validity.line + " — validity mentioned, but no period or date could be read",
              "“" + trimLine(validity.raw) + "” mentions validity without a readable period or date, so expiry cannot be checked.");
          }

          // (6) deposit
          if (depositAmt !== null || depositPct !== null) {
            var effDeposit = depositAmt;
            if (effDeposit === null && depositPct !== null) effDeposit = Math.round(totalBase * depositPct / 100);
            if (effDeposit !== null && effDeposit > totalBase) {
              add("BLOCKER", depositLine, "Line " + depositLine + " — deposit is greater than the total",
                "Deposit: " + fmtMoney(effDeposit) + (depositAmt === null ? " (" + depositPct + "% of the total)" : "") + ". Quote total: " + fmtMoney(totalBase) + ". A deposit cannot exceed the amount owed.");
            } else if (depositAmt !== null && depositPct !== null) {
              var depExpected = Math.round(totalBase * depositPct / 100);
              if (Math.abs(depExpected - depositAmt) > 1) {
                add("WARNING", depositLine, "Line " + depositLine + " — deposit percentage and amount disagree",
                  "Stated deposit: " + fmtMoney(depositAmt) + " at " + depositPct + "%. Computed: " + depositPct + "% × " + fmtMoney(totalBase) + " (total) = " + fmtMoney(depExpected) + ". Difference: " + fmtMoney(Math.abs(depExpected - depositAmt)) + ".");
              } else {
                add("OK", depositLine, "Line " + depositLine + " — deposit checks out",
                  depositPct + "% × " + fmtMoney(totalBase) + " (total) = " + fmtMoney(depExpected) + " — matches the stated deposit of " + fmtMoney(depositAmt) + ", and the deposit does not exceed the total.");
              }
            } else if (depositAmt !== null) {
              var implied = totalBase > 0 ? Math.round(depositAmt / totalBase * 1000) / 10 : 0;
              add("INFO", depositLine, "Line " + depositLine + " — deposit amount stated, no percentage to check against",
                "Deposit of " + fmtMoney(depositAmt) + " is " + implied + "% of the total " + fmtMoney(totalBase) + ", and does not exceed it. No percentage was stated, so there is nothing further to cross-check.");
            } else {
              add("INFO", depositLine, "Line " + depositLine + " — deposit percentage stated, no amount to check against",
                depositPct + "% of the total " + fmtMoney(totalBase) + " = " + fmtMoney(effDeposit) + ". No deposit amount was stated, so there is nothing further to cross-check.");
            }
          }

          // (9) mixed currency
          if (hasDollar && hasEuro) {
            add("WARNING", null, "Mixed currency symbols — both $ and € appear in this quote",
              "The quote uses $ (dollar) in some figures and € (euro) in others. Pick one currency and restate the figures in the other.");
          }

          // verdict + counts
          var counts = { BLOCKER: 0, WARNING: 0, INFO: 0, OK: 0 };
          for (var f = 0; f < findings.length; f++) counts[findings[f].sev]++;

          var verdict, verdictClass;
          if (counts.BLOCKER > 0) { verdict = "DO NOT SEND"; verdictClass = "verdict-stop"; }
          else if (counts.WARNING > 0) { verdict = "SEND WITH FIXES"; verdictClass = "verdict-fixes"; }
          else { verdict = "SAFE TO SEND"; verdictClass = "verdict-safe"; }

          return {
            findings: findings, counts: counts, verdict: verdict, verdictClass: verdictClass,
            items: items, notParsedCount: notParsed.length,
            sumComputed: sumComputed, sumExpr: sumExpr,
            subtotalStated: subtotalStated, taxAmt: taxAmt, taxRate: taxRate,
            discountCents: discountCents, discountNote: discountNote,
            totalStated: totalStated, totalComputed: totalComputed, totalArith: totalArith
          };
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "CLEAN_EXAMPLE": (typeof CLEAN_EXAMPLE !== 'undefined' ? CLEAN_EXAMPLE : undefined), "BROKEN_EXAMPLE": (typeof BROKEN_EXAMPLE !== 'undefined' ? BROKEN_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-quote-estimate-consistency-auditor',
  name: 'J-Dawgs Quote & Estimate Consistency Auditor',
  description: 'Cross-checks a pasted sales quote against itself — line math, subtotal, tax, total, expiry, deposit — with all arithmetic shown, into one send verdict before it goes out.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "CLEAN_EXAMPLE": __core["CLEAN_EXAMPLE"], "BROKEN_EXAMPLE": __core["BROKEN_EXAMPLE"] }
};
