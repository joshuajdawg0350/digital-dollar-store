'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Employee Offboarding Access Revocation Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var TYPES = ["account", "token", "shared-key", "group", "physical"];

        var EXAMPLES = {
          ex1: {
            departure: "2026-11-06T17:00",
            access:
              "ACCESS: Email | account | j.doe@example.com\n" +
              "ACCESS: VPN | token | vpn-token-jdoe\n" +
              "ACCESS: AWS | shared-key | deploy-key-prod\n" +
              "ACCESS: Building | physical | badge-4471",
            evidence:
              "REVOKED: Email | j.doe@example.com | 2026-11-06 16:30\n" +
              "REVOKED: VPN | vpn-token-jdoe | 2026-11-07 09:00\n" +
              "REVOKED: AWS | deploy-key-prod | 2026-11-06 15:00"
          },
          ex2: {
            departure: "2026-11-06T17:00",
            access:
              "ACCESS: Email | account | j.doe@example.com\n" +
              "ACCESS: VPN | token | vpn-token-jdoe\n" +
              "ACCESS: AWS | shared-key | deploy-key-prod\n" +
              "ACCESS: Building | physical | badge-4471\n" +
              "ACCESS: Slack | group | #eng-oncall",
            evidence:
              "REVOKED: Email | j.doe@example.com | 2026-11-06 16:30\n" +
              "REVOKED: VPN | vpn-token-jdoe | 2026-11-06 16:45\n" +
              "ROTATED: AWS | deploy-key-prod | 2026-11-06 15:30\n" +
              "RETURNED: Building | badge-4471 | 2026-11-06 12:00\n" +
              "REVOKED: Slack | #eng-oncall | 2026-11-06 16:00\n" +
              "REVIEWED-NONE: Payroll"
          }
        };

        var PASS_TEXT =
          "J-Dawgs AI Tool Store — the tool store where the AI is the customer. Free and per-use tools your AI can reach for today, every one tested and approved before it lists.\n" +
          "https://muse.ai/s/ai-tool-store-xng6xkxwjkxl2xab/UoF72OkKI7j33Q2ITxmrZyIr4nv40QtYfj2AgESh_k8\n\n" +
          "J-Dawgs Agent Exchange — the exchange where AI agents hire verified humans for the real-world tasks software cannot do itself.\n" +
          "https://muse.ai/s/j-dawgs-agent-exchange-ih6xlnihzxdhxc/ZbleqxFHRE0NcswaBkyN13y9lLp5rPAgHTb6t8ii-PY\n\n" +
          "Stream It, Search It, Revoke It Right Stack — Kafka Config Safety Auditor + Elasticsearch Config Safety Auditor + Employee Offboarding Access Revocation Auditor: grade the broker, grade the search cluster, prove every access is revoked";

        var DISCLAIMER =
          "This auditor never connects to any system and never verifies that evidence is genuine. " +
          "It cross-checks only the text pasted into it. Confirm critical revocations in the source systems themselves.";

        function $(id) { return document.getElementById(id); }

        function pad2(n) { return (n < 10 ? "0" : "") + n; }

        // Strictly parse "YYYY-MM-DD HH:MM" (space or T separator, optional seconds).
        // Returns a local Date, or null if the shape or the calendar date is invalid.
        function parseDT(s) {
          var m = /^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})(?::(\d{2}))?$/.exec(String(s).trim());
          if (!m) return null;
          var y = +m[1], mo = +m[2], d = +m[3], h = +m[4], mi = +m[5], se = m[6] ? +m[6] : 0;
          if (mo < 1 || mo > 12 || h > 23 || mi > 59 || se > 59) return null;
          var dt = new Date(y, mo - 1, d, h, mi, se);
          if (dt.getFullYear() !== y || dt.getMonth() !== mo - 1 || dt.getDate() !== d ||
              dt.getHours() !== h || dt.getMinutes() !== mi) return null;
          return dt;
        }

        function fmtDT(dt) {
          return dt.getFullYear() + "-" + pad2(dt.getMonth() + 1) + "-" + pad2(dt.getDate()) +
                 " " + pad2(dt.getHours()) + ":" + pad2(dt.getMinutes());
        }

        // Gap between two moments, in hours and minutes (days broken out when >= 24h).
        function fmtGap(ms) {
          var mins = Math.round(Math.abs(ms) / 60000);
          var d = Math.floor(mins / 1440);
          var h = Math.floor((mins % 1440) / 60);
          var m = mins % 60;
          var out = "";
          if (d > 0) out += d + "d ";
          return out + h + "h " + pad2(m) + "m";
        }

        function keyOf(system, identifier) {
          return system.trim().toLowerCase() + "" + identifier.trim().toLowerCase();
        }

        function splitFields(body) {
          return body.split("|").map(function (p) { return p.trim(); });
        }

        function parseAccess(text) {
          var items = [], problems = [];
          var lines = String(text).split(/\r?\n/);
          lines.forEach(function (raw, i) {
            var lineNo = i + 1, line = raw.trim();
            if (!line) return;
            var m = /^ACCESS:\s*(.+)$/i.exec(line);
            if (!m) {
              problems.push({ block: "ACCESS", line: lineNo, text: raw.trim(), reason: "does not start with \"ACCESS:\"" });
              return;
            }
            var parts = splitFields(m[1]);
            if (parts.length !== 3) {
              problems.push({ block: "ACCESS", line: lineNo, text: raw.trim(), reason: "expected 3 fields separated by | — system | type | identifier" });
              return;
            }
            var type = parts[1].toLowerCase();
            if (TYPES.indexOf(type) === -1) {
              problems.push({ block: "ACCESS", line: lineNo, text: raw.trim(), reason: "unknown type \"" + parts[1] + "\" — must be account, token, shared-key, group, or physical" });
              return;
            }
            if (!parts[0] || !parts[2]) {
              problems.push({ block: "ACCESS", line: lineNo, text: raw.trim(), reason: "system and identifier must not be empty" });
              return;
            }
            items.push({ system: parts[0], type: type, identifier: parts[2], line: lineNo });
          });
          return { items: items, problems: problems };
        }

        function parseEvidence(text) {
          var items = [], problems = [], reviewedNone = [];
          var lines = String(text).split(/\r?\n/);
          lines.forEach(function (raw, i) {
            var lineNo = i + 1, line = raw.trim();
            if (!line) return;
            var rn = /^REVIEWED-NONE:\s*(.+)$/i.exec(line);
            if (rn) {
              var sys = rn[1].trim();
              if (!sys || sys.indexOf("|") !== -1) {
                problems.push({ block: "EVIDENCE", line: lineNo, text: raw.trim(), reason: "REVIEWED-NONE takes exactly one field — the system name" });
              } else {
                reviewedNone.push({ system: sys, line: lineNo });
              }
              return;
            }
            var m = /^(REVOKED|ROTATED|RETURNED):\s*(.+)$/i.exec(line);
            if (!m) {
              problems.push({ block: "EVIDENCE", line: lineNo, text: raw.trim(), reason: "unrecognized evidence line — must start with REVOKED:, ROTATED:, RETURNED:, or REVIEWED-NONE:" });
              return;
            }
            var verb = m[1].toUpperCase();
            var parts = splitFields(m[2]);
            if (parts.length !== 3) {
              problems.push({ block: "EVIDENCE", line: lineNo, text: raw.trim(), reason: "expected 3 fields separated by | — system | identifier | YYYY-MM-DD HH:MM" });
              return;
            }
            if (!parts[0] || !parts[1]) {
              problems.push({ block: "EVIDENCE", line: lineNo, text: raw.trim(), reason: "system and identifier must not be empty" });
              return;
            }
            var dt = parseDT(parts[2]);
            if (!dt) {
              problems.push({ block: "EVIDENCE", line: lineNo, text: raw.trim(), reason: "bad datetime \"" + parts[2] + "\" — must be a real date and time as YYYY-MM-DD HH:MM" });
              return;
            }
            items.push({ verb: verb, system: parts[0], identifier: parts[1], dt: dt, line: lineNo, raw: raw.trim() });
          });
          return { items: items, problems: problems, reviewedNone: reviewedNone };
        }

        function earliest(list) {
          var best = null;
          list.forEach(function (e) { if (!best || e.dt < best.dt) best = e; });
          return best;
        }

        function gradeAccess(acc, evList, departure) {
          var byVerb = { REVOKED: [], ROTATED: [], RETURNED: [] };
          evList.forEach(function (e) { byVerb[e.verb].push(e); });
          var type = acc.type;

          function timing(dt, verbLabel, okStatus) {
            var diff = dt - departure;
            if (diff <= 0) {
              return { status: okStatus, cls: "ok", category: "ontime",
                       detail: verbLabel + " " + fmtDT(dt) + " — " + fmtGap(diff) + " before the " + fmtDT(departure) + " departure." };
            }
            return { status: okStatus === "ROTATED" ? "ROTATED — LATE" : verbLabel.toUpperCase() + " LATE", cls: "warn", category: "late",
                     detail: verbLabel + " " + fmtDT(dt) + " — departure " + fmtDT(departure) + " = " + fmtGap(diff) + " late." };
          }

          function stillActive(foundNote) {
            return { status: foundNote ? "STILL ACTIVE — WRONG EVIDENCE TYPE (BLOCKER)" : "STILL ACTIVE — NO EVIDENCE (BLOCKER)",
                     cls: "bad", category: "active",
                     detail: foundNote || "No evidence line matches this access. Until acceptable evidence is produced, this access must be treated as still active." };
          }

          if (type === "shared-key") {
            if (byVerb.ROTATED.length) {
              var r = timing(earliest(byVerb.ROTATED).dt, "Rotated", "ROTATED");
              r.detail += " Rotation is the correct proof for a shared key — deleting one holder's copy proves nothing while other holders may still know the old key.";
              return r;
            }
            if (byVerb.REVOKED.length) {
              var rv = earliest(byVerb.REVOKED);
              return { status: "PARTIAL — REVOKED, NOT ROTATED", cls: "warn", category: "partial",
                       detail: "Only a REVOKED line was provided (" + fmtDT(rv.dt) + "). A shared key is satisfied only by ROTATED evidence: revoking one holder's access does not change the key itself, so every other holder may still know it." };
            }
            if (byVerb.RETURNED.length) {
              return stillActive("Only RETURNED evidence was found (" + fmtDT(earliest(byVerb.RETURNED).dt) + "). Returning an item does not change a shared key. A ROTATED line is required.");
            }
            return stillActive(null);
          }

          if (type === "physical") {
            var good = byVerb.REVOKED.concat(byVerb.RETURNED);
            if (good.length) {
              var g = earliest(good);
              var label = g.verb === "RETURNED" ? "Returned" : "Revoked";
              var okStatus = g.verb === "RETURNED" ? "RETURNED ON TIME" : "REVOKED ON TIME";
              var t = timing(g.dt, label, okStatus);
              if (t.category === "late") t.status = label.toUpperCase() + " LATE";
              return t;
            }
            if (byVerb.ROTATED.length) {
              return stillActive("Only ROTATED evidence was found (" + fmtDT(earliest(byVerb.ROTATED).dt) + "). Rotation does not apply to a physical item. A REVOKED or RETURNED line is required.");
            }
            return stillActive(null);
          }

          // account / token / group
          if (byVerb.REVOKED.length) {
            return timing(earliest(byVerb.REVOKED).dt, "Revoked", "REVOKED ON TIME");
          }
          var typeWord = type === "group" ? "group membership" : type;
          if (byVerb.ROTATED.length) {
            return stillActive("Only ROTATED evidence was found (" + fmtDT(earliest(byVerb.ROTATED).dt) + "). Rotation changes a credential; it does not close a " + typeWord + ". A REVOKED line is required.");
          }
          if (byVerb.RETURNED.length) {
            return stillActive("Only RETURNED evidence was found (" + fmtDT(earliest(byVerb.RETURNED).dt) + "). RETURNED applies to physical items. A REVOKED line is required for a " + typeWord + ".");
          }
          return stillActive(null);
        }

        function audit(departure, accessText, evidenceText) {
          var ap = parseAccess(accessText);
          var ep = parseEvidence(evidenceText);

          // Duplicate ACCESS detection on normalized system+identifier.
          var seen = {}, duplicates = [];
          ap.items.forEach(function (a) {
            var k = keyOf(a.system, a.identifier);
            if (seen[k]) {
              a.duplicateOf = seen[k].line;
              duplicates.push({ first: seen[k], dup: a });
            } else {
              seen[k] = a;
            }
          });

          // Evidence index by key.
          var evByKey = {};
          ep.items.forEach(function (e) {
            var k = keyOf(e.system, e.identifier);
            if (!evByKey[k]) evByKey[k] = [];
            evByKey[k].push(e);
          });

          // Orphan evidence: names a system+identifier with no ACCESS line at all.
          var orphans = ep.items.filter(function (e) { return !seen[keyOf(e.system, e.identifier)]; });

          // REVIEWED-NONE conflicts: claims a system is empty while ACCESS lines name it.
          var accessSystems = {};
          ap.items.forEach(function (a) { accessSystems[a.system.toLowerCase()] = true; });
          var rnConflicts = ep.reviewedNone.filter(function (r) { return accessSystems[r.system.toLowerCase()]; });

          var rows = ap.items.map(function (a) {
            if (a.duplicateOf) {
              return { access: a, status: "DUPLICATE", cls: "warn", category: "duplicate",
                       detail: "Same system + identifier as ACCESS line " + a.duplicateOf + " (lines " + a.duplicateOf + " and " + a.line + "). Counted once — remove the duplicate line." };
            }
            var g = gradeAccess(a, evByKey[keyOf(a.system, a.identifier)] || [], departure);
            g.access = a;
            return g;
          });

          var counts = { ontime: 0, late: 0, partial: 0, active: 0, duplicate: 0 };
          rows.forEach(function (r) { counts[r.category] = (counts[r.category] || 0) + 1; });

          var verdict, verdictCls;
          if (counts.active > 0) { verdict = "NOT REVOKED"; verdictCls = "bad"; }
          else if (counts.late > 0 || counts.partial > 0 || counts.duplicate > 0) { verdict = "REVOKED WITH GAPS"; verdictCls = "warn"; }
          else { verdict = "FULLY REVOKED"; verdictCls = "ok"; }

          return {
            departure: departure, rows: rows, counts: counts, verdict: verdict, verdictCls: verdictCls,
            duplicates: duplicates, orphans: orphans, rnConflicts: rnConflicts,
            reviewedNone: ep.reviewedNone,
            problems: ap.problems.concat(ep.problems),
            accessCount: ap.items.length
          };
        }

        function verdictWhy(r) {
          if (r.verdict === "FULLY REVOKED") {
            return "Every one of the " + r.accessCount + " accesses is closed by the correct kind of evidence at or before the departure moment.";
          }
          if (r.verdict === "NOT REVOKED") {
            return r.counts.active + " access" + (r.counts.active === 1 ? " is" : "es are") +
                   " still active — no acceptable evidence. One still-active access makes the whole audit NOT REVOKED.";
          }
          var bits = [];
          if (r.counts.late) bits.push(r.counts.late + " closed late");
          if (r.counts.partial) bits.push(r.counts.partial + " partial (shared key not rotated)");
          if (r.counts.duplicate) bits.push(r.counts.duplicate + " duplicate line" + (r.counts.duplicate === 1 ? "" : "s"));
          return "Nothing is left evidence-less, but the record has gaps: " + bits.join(", ") + ".";
        }

        function buildReport(r) {
          var L = [];
          L.push("J-DAWGS EMPLOYEE OFFBOARDING ACCESS REVOCATION AUDITOR — REPORT");
          L.push("Departure moment: " + fmtDT(r.departure));
          L.push("VERDICT: " + r.verdict);
          L.push("");
          L.push("PER-ACCESS RESULTS (" + r.rows.length + ")");
          r.rows.forEach(function (row, i) {
            var a = row.access;
            L.push((i + 1) + ". [" + row.status + "] " + a.system + " | " + a.type + " | " + a.identifier + " (ACCESS line " + a.line + ")");
            L.push("   " + row.detail);
          });
          L.push("");
          L.push("ISSUES");
          var any = false;
          r.duplicates.forEach(function (d) {
            any = true;
            L.push("- DUPLICATE ACCESS: lines " + d.first.line + " and " + d.dup.line + " — " + d.dup.system + " | " + d.dup.identifier + ".");
          });
          r.orphans.forEach(function (e) {
            any = true;
            L.push("- ORPHAN EVIDENCE: EVIDENCE line " + e.line + " — \"" + e.raw + "\" matches no ACCESS line.");
          });
          r.rnConflicts.forEach(function (c) {
            any = true;
            L.push("- CONFLICT: EVIDENCE line " + c.line + " — REVIEWED-NONE claims no access in " + c.system + ", but ACCESS lines name that system.");
          });
          r.problems.forEach(function (p) {
            any = true;
            L.push("- MALFORMED (" + p.block + " block, line " + p.line + ", excluded): \"" + p.text + "\" — " + p.reason + ".");
          });
          if (r.reviewedNone.length) {
            r.reviewedNone.forEach(function (c) {
              if (r.rnConflicts.indexOf(c) === -1) L.push("- Attested REVIEWED-NONE: " + c.system + " (EVIDENCE line " + c.line + ").");
            });
          }
          if (!any && !r.reviewedNone.length) L.push("- None.");
          L.push("");
          L.push("COUNTS: on time " + r.counts.ontime + " · late " + r.counts.late + " · partial " + r.counts.partial +
                 " · still active " + r.counts.active + " · duplicates " + r.counts.duplicate +
                 " · orphan evidence " + r.orphans.length + " · malformed lines " + r.problems.length);
          L.push("");
          L.push("IMPORTANT: " + DISCLAIMER);
          return L.join("\n");
        }

        function buildSummary(r) {
          var L = [];
          L.push("OFFBOARDING ACCESS SUMMARY — systems and statuses only (no identifiers)");
          L.push("Departure moment: " + fmtDT(r.departure));
          L.push("VERDICT: " + r.verdict);
          L.push("");
          // Aggregate per system + status, preserving first-seen order.
          var order = [], agg = {};
          r.rows.forEach(function (row) {
            var sys = row.access.system;
            var k = sys.toLowerCase() + "" + row.status;
            if (!agg[k]) { agg[k] = { system: sys, status: row.status, n: 0 }; order.push(k); }
            agg[k].n++;
          });
          order.forEach(function (k) {
            var a = agg[k];
            L.push(a.system + " — " + a.status + (a.n > 1 ? " (" + a.n + " accesses)" : ""));
          });
          L.push("");
          L.push("Note: prepared from pasted records. " + DISCLAIMER);
          return L.join("\n");
        }

        function esc(s) {
          return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
        }

        function render(r) {
          $("resultsCard").classList.remove("hidden");
          var box = $("verdictBox");
          box.className = "verdict " + r.verdictCls;
          $("verdictWord").textContent = r.verdict;
          $("verdictWhy").textContent = verdictWhy(r);

          var chips = [
            ["Accesses", r.accessCount],
            ["On time", r.counts.ontime],
            ["Late", r.counts.late],
            ["Partial", r.counts.partial],
            ["Still active", r.counts.active],
            ["Duplicates", r.counts.duplicate],
            ["Orphan evidence", r.orphans.length],
            ["Malformed lines", r.problems.length]
          ];
          $("chips").innerHTML = chips.map(function (c) {
            return "<span class=\"chip\">" + c[0] + ": " + c[1] + "</span>";
          }).join("");

          $("rows").innerHTML = r.rows.map(function (row) {
            var a = row.access;
            return "<div class=\"arow\">" +
              "<div><div class=\"who\">" + esc(a.system) + " · <span class=\"id mono\">" + esc(a.identifier) + "</span></div>" +
              "<div class=\"meta\">type: " + esc(a.type) + " · ACCESS line " + a.line + "</div></div>" +
              "<div><span class=\"pill " + row.cls + "\">" + esc(row.status) + "</span></div>" +
              "<div class=\"detail\">" + esc(row.detail) + "</div>" +
              "</div>";
          }).join("");

          var issuesHtml = "";
          function list(title, items) {
            if (!items.length) return;
            issuesHtml += "<h4 style=\"margin:12px 0 4px\">" + title + "</h4><ul class=\"issue-list\">" +
              items.map(function (t) { return "<li>" + t + "</li>"; }).join("") + "</ul>";
          }
          list("Duplicate ACCESS lines", r.duplicates.map(function (d) {
            return "ACCESS lines " + d.first.line + " and " + d.dup.line + " — <span class=\"mono\">" + esc(d.dup.system) + " | " + esc(d.dup.identifier) + "</span> appears twice.";
          }));
          list("Orphan evidence (matches no ACCESS line)", r.orphans.map(function (e) {
            return "EVIDENCE line " + e.line + " — <span class=\"mono\">" + esc(e.raw) + "</span>";
          }));
          list("REVIEWED-NONE conflicts", r.rnConflicts.map(function (c) {
            return "EVIDENCE line " + c.line + " — REVIEWED-NONE claims no access in <strong>" + esc(c.system) + "</strong>, but ACCESS lines name that system.";
          }));
          list("Malformed lines (excluded, never guessed)", r.problems.map(function (p) {
            return p.block + " block, line " + p.line + " — <span class=\"mono\">" + esc(p.text) + "</span> · " + esc(p.reason);
          }));
          if (r.reviewedNone.length) {
            list("Attested clear", r.reviewedNone.filter(function (c) { return r.rnConflicts.indexOf(c) === -1; }).map(function (c) {
              return "REVIEWED-NONE: " + esc(c.system) + " (EVIDENCE line " + c.line + ") — system checked, person held nothing there.";
            }));
          }
          $("issues").innerHTML = issuesHtml || "<p class=\"none\">None — no duplicates, no orphan evidence, no malformed lines.</p>";

          $("reportText").textContent = buildReport(r);
          $("summaryText").textContent = buildSummary(r);
          $("resultsCard").scrollIntoView({ behavior: "smooth", block: "start" });
        }

        function showErr(msg) {
          var e = $("formErr");
          e.textContent = msg;
          e.classList.add("show");
        }
        function hideErr() { $("formErr").classList.remove("show"); }

        function run() {
          hideErr();
          var depVal = $("departure").value;
          var departure = depVal ? parseDT(depVal) : null;
          if (!departure) {
            showErr("Enter the departure date & time first — every closure is graded against that moment.");
            return;
          }
          var accessText = $("accessText").value;
          if (!accessText.trim()) {
            showErr("Paste at least one ACCESS line — there is nothing to audit yet.");
            return;
          }
          var r = audit(departure, accessText, $("evidenceText").value);
          if (r.accessCount === 0) {
            showErr("No valid ACCESS lines found. Check the malformed-line format: ACCESS: <system> | <type> | <identifier>.");
            return;
          }
          render(r);
        }

        function exampleText(ex) {
          return "Departure: " + ex.departure.replace("T", " ") + "\n\nACCESS LIST\n" + ex.access + "\n\nEVIDENCE\n" + ex.evidence;
        }

        function loadExample(key) {
          var ex = EXAMPLES[key];
          $("departure").value = ex.departure;
          $("accessText").value = ex.access;
          $("evidenceText").value = ex.evidence;
          run();
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLES": (typeof EXAMPLES !== 'undefined' ? EXAMPLES : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-employee-offboarding-access-revocation-auditor',
  name: 'J-Dawgs Employee Offboarding Access Revocation Auditor',
  description: 'Cross-checks a departing person\'s pasted ACCESS list against revocation evidence and the departure time: on-time/late arithmetic, shared keys need ROTATED proof, still-active blockers — into one revocation verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLES": __core["EXAMPLES"] }
};
