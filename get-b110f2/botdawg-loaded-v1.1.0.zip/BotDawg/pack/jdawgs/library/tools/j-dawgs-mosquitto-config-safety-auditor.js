'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Mosquitto MQTT Broker Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Worked examples ---------- */
      var RISKY = [
        "# Example broker config - internet-facing sensor gateway",
        "listener 1883",
        "allow_anonymous true",
        "log_type all",
        "persistence true",
        "persistence_location /tmp/mosquitto/",
        ""
      ].join("\n");

      var HARDENED = [
        "# Hardened broker - TLS only, authenticated, ACL-restricted",
        "allow_anonymous false",
        "password_file /etc/mosquitto/passwd",
        "acl_file /etc/mosquitto/acl",
        "persistence true",
        "persistence_location /var/lib/mosquitto/",
        "log_type error",
        "log_type warning",
        "log_type notice",
        "max_connections 512",
        "max_queued_messages 1000",
        "",
        "listener 8883",
        "cafile /etc/mosquitto/ca.crt",
        "certfile /etc/mosquitto/server.crt",
        "keyfile /etc/mosquitto/server.key",
        ""
      ].join("\n");

      var OVERRIDE = [
        "# Safe globals, one dangerous listener override",
        "allow_anonymous false",
        "password_file /etc/mosquitto/passwd",
        "acl_file /etc/mosquitto/acl",
        "",
        "listener 8883",
        "cafile /etc/mosquitto/ca.crt",
        "certfile /etc/mosquitto/server.crt",
        "keyfile /etc/mosquitto/server.key",
        "",
        "listener 1883",
        "allow_anonymous true",
        ""
      ].join("\n");

      /* ---------- Parser ---------- */
      var KNOWN = {};
      ("listener port bind_address protocol allow_anonymous allow_zero_length_clientid " +
       "password_file acl_file psk_file auth_plugin cafile capath certfile keyfile tls_version " +
       "ciphers dhparam_file require_certificate use_identity_as_username persistence " +
       "persistence_location persistence_file autosave_interval autosave_on_changes log_dest " +
       "log_type log_timestamp log_timestamp_format log_facility connection_messages " +
       "max_connections max_queued_messages max_inflight_messages max_inflight_bytes " +
       "max_packet_size max_queued_bytes message_size_limit memory_limit queue_qos0_messages " +
       "retain_available set_tcp_nodelay socket_domain sys_interval upgrade_outgoing_qos user " +
       "pid_file include_dir per_listener_settings clientid_prefixes max_keepalive " +
       "connection address topic remote_username remote_password remote_clientid local_clientid " +
       "notifications notification_topic cleansession start_type attempt_unsubscribe " +
       "bridge_max_packet_size bridge_reconnect_timeout bridge_tls_version bridge_cafile " +
       "bridge_capath bridge_certfile bridge_keyfile bridge_insecure bridge_alpn idle_timeout " +
       "keepalive_interval local_password local_username restart_timeout round_robin " +
       "threshold try_private global_max_connections enable_control_api mount_point " +
       "websockets_headers http_dir http_username http_password max_topic_alias").split(" ")
       .forEach(function(k){ KNOWN[k]=true; });

      var BOOL_KEYS = {};
      ("allow_anonymous allow_zero_length_clientid persistence autosave_on_changes " +
       "per_listener_settings retain_available connection_messages queue_qos0_messages " +
       "set_tcp_nodelay upgrade_outgoing_qos use_identity_as_username require_certificate " +
       "log_timestamp try_private cleansession round_robin notifications bridge_insecure").split(" ")
       .forEach(function(k){ BOOL_KEYS[k]=true; });

      function safeToken(tok){
        return /^[a-z][a-z0-9_]{0,23}$/i.test(tok) ? tok : "[unrecognized content]";
      }

      function parse(text){
        var globals = { dirs:{} };
        var listeners = [];
        var notParsed = [];
        var current = null;
        var rawLines = text.split(/\r?\n/);
        for (var i=0;i<rawLines.length;i++){
          var lineNo = i+1;
          var t = rawLines[i].trim();
          if (!t) continue;
          if (t.charAt(0) === "#") continue;
          var sp = t.search(/\s/);
          var key = sp === -1 ? t : t.slice(0, sp);
          var value = sp === -1 ? "" : t.slice(sp).trim();
          var lk = key.toLowerCase();
          var known = KNOWN[lk] || lk.indexOf("auth_opt_") === 0 || lk.indexOf("plugin_opt_") === 0 || lk.indexOf("bridge_") === 0;
          if (!/^[a-z][a-z0-9_]*$/i.test(key) || !known){
            notParsed.push({ line:lineNo, reason:"Unrecognized directive \u201C"+safeToken(key)+"\u201D" });
            continue;
          }
          if (lk === "listener"){
            var parts = value.split(/\s+/).filter(Boolean);
            var portOk = parts.length >= 1 && /^\d+$/.test(parts[0]) && +parts[0] >= 1 && +parts[0] <= 65535;
            if (!portOk){
              notParsed.push({ line:lineNo, reason:"listener port is missing or not a number from 1\u201365535" });
              current = null;
              continue;
            }
            current = { line:lineNo, port:+parts[0], bindArg:(parts[1] || null), dirs:{}, implicit:false };
            listeners.push(current);
            continue;
          }
          if (BOOL_KEYS[lk] && !/^(true|false)$/i.test(value)){
            notParsed.push({ line:lineNo, reason:"\u201C"+lk+"\u201D expects true or false" });
            continue;
          }
          if ((lk === "port") && !(/^\d+$/.test(value) && +value >= 1 && +value <= 65535)){
            notParsed.push({ line:lineNo, reason:"\u201Cport\u201D is not a number from 1\u201365535" });
            continue;
          }
          if ((lk === "max_connections" || lk === "max_queued_messages" || lk === "max_inflight_messages") && !/^-?\d+$/.test(value)){
            notParsed.push({ line:lineNo, reason:"\u201C"+lk+"\u201D expects a whole number" });
            continue;
          }
          var scope = current || globals;
          if (!scope.dirs[lk]) scope.dirs[lk] = [];
          scope.dirs[lk].push({ value:value, line:lineNo });
        }
        return { globals:globals, listeners:listeners, notParsed:notParsed };
      }

      function last(scope, key){
        var a = scope.dirs[key];
        return (a && a.length) ? a[a.length-1] : null;
      }
      function eff(listener, globals, key){ /* per-listener wins, else global */
        return last(listener, key) || last(globals, key);
      }
      function effSource(listener, globals, key){
        if (last(listener, key)) return "listener";
        if (last(globals, key)) return "global";
        return "default";
      }

      function bindClass(bind){
        if (!bind) return "all";
        var b = bind.toLowerCase();
        if (b === "0.0.0.0" || b === "::" || b === "*") return "all";
        if (b === "127.0.0.1" || b === "::1" || b === "localhost") return "loopback";
        return "specific";
      }

      /* ---------- Audit ---------- */
      function audit(text){
        var parsed = parse(text);
        var globals = parsed.globals;
        var listeners = parsed.listeners.slice();
        var implicit = false;
        if (!listeners.length){
          var gp = last(globals, "port");
          var gb = last(globals, "bind_address");
          listeners.push({
            line: gp ? gp.line : null, port: gp ? +gp.value : 1883,
            bindArg: gb ? gb.value : null, dirs:{}, implicit:true
          });
          implicit = true;
        }

        var findings = [];
        function add(sev, line, scope, title, detail, fix){
          findings.push({ severity:sev, line:line, scope:scope, title:title, detail:detail, fix:fix || "" });
        }

        var anyTlsListener = false;
        var listenerRows = [];

        listeners.forEach(function(L){
          var scopeName = L.implicit ? "Default listener (no listener directive found)" : "Listener on port " + L.port + " (line " + L.line + ")";
          var protoE = eff(L, globals, "protocol");
          var proto = protoE ? protoE.value.toLowerCase() : "mqtt";
          if (proto !== "mqtt" && proto !== "websockets") proto = "mqtt";
          var bindE = last(L, "bind_address");
          var bind = L.bindArg || (bindE ? bindE.value : null);
          var bc = bindClass(bind);
          var exposed = bc !== "loopback";

          var certE = eff(L, globals, "certfile");
          var keyE  = eff(L, globals, "keyfile");
          var caE   = eff(L, globals, "cafile") || eff(L, globals, "capath");
          var tlsDeclared = !!(certE || keyE || caE) || L.port === 8883;
          var tlsComplete = !!(certE && keyE && caE);
          var tlsOn = tlsComplete || !!(certE && keyE);
          if (tlsOn) anyTlsListener = true;

          /* TLS completeness */
          if (tlsDeclared){
            if (!certE || !keyE){
              var missing = [];
              if (!certE) missing.push("certfile");
              if (!keyE) missing.push("keyfile");
              add("BLOCKER", L.line, scopeName,
                "Broken TLS configuration on port " + L.port,
                "This listener is set up for TLS (port " + L.port + (L.port === 8883 ? ", the standard MQTT-over-TLS port" : "") + ") but " + missing.join(" and ") + (missing.length > 1 ? " are" : " is") + " not set. The broker will refuse to start this listener, and no encrypted service exists on this port until it is fixed.",
                "Set " + missing.join(" and ") + " for this listener to real certificate/key files, or remove the TLS setup and the 8883 listener if TLS is not intended.");
            } else if (!caE){
              add("WARNING", L.line, scopeName,
                "TLS on port " + L.port + " has no CA file",
                "certfile (line " + certE.line + ") and keyfile (line " + keyE.line + ") are set, so TLS is on, but neither cafile nor capath is set: the broker has no CA bundle for verifying client certificates.",
                "Add cafile pointing at the CA certificate that signs client certificates (or capath for a directory of CA files).");
            } else {
              add("POSITIVE", certE.line, scopeName,
                "TLS fully configured on port " + L.port,
                "cafile/capath, certfile (line " + certE.line + "), and keyfile (line " + keyE.line + ") are all set for this listener, so MQTT traffic on port " + L.port + " is encrypted. File paths are noted by key name and line only.",
                "");
            }
          }

          /* Anonymous access, effective per listener */
          var anonE = eff(L, globals, "allow_anonymous");
          var anonSrc = effSource(L, globals, "allow_anonymous");
          var anon = anonE ? /^true$/i.test(anonE.value) : true; /* Mosquitto default: allow_anonymous true when unset */
          var pwE = eff(L, globals, "password_file");
          var aclE = eff(L, globals, "acl_file");
          var authPluginE = eff(L, globals, "auth_plugin");

          if (anon){
            var gAnonE = last(globals, "allow_anonymous");
            var overridesSafeGlobal = anonSrc === "listener" && gAnonE && !/^true$/i.test(gAnonE.value);
            var where = anonSrc === "listener"
              ? (overridesSafeGlobal
                  ? "set by a per-listener allow_anonymous override at line " + anonE.line + ", overriding the global allow_anonymous false at line " + gAnonE.line
                  : "set per-listener at line " + anonE.line)
              : (anonSrc === "global"
                  ? "set globally at line " + anonE.line
                  : "on by Mosquitto default \u2014 allow_anonymous is never set to false anywhere in this config");
            if (exposed){
              add("BLOCKER", anonE ? anonE.line : L.line, scopeName,
                "Anonymous access open to the network on port " + L.port,
                "allow_anonymous is " + where + ", and this listener " + (bc === "all" ? "binds all interfaces (no bind restriction)" : "binds " + bind + ", a network-reachable address") + ". Anyone who can reach port " + L.port + " can connect, publish, and subscribe with no credentials at all." + (overridesSafeGlobal ? " The safe global setting does not save this listener: the per-listener override wins." : ""),
                "Set allow_anonymous false for this listener and configure password_file (and acl_file), or bind the listener to 127.0.0.1 if it is only for local use.");
            } else {
              add("WARNING", anonE ? anonE.line : L.line, scopeName,
                "Anonymous access on loopback-only port " + L.port,
                "allow_anonymous is " + where + ", but this listener binds " + bind + " (loopback), so exposure is limited to the same machine. Any local process or forwarded tunnel can still connect without credentials.",
                "Set allow_anonymous false and add password_file, or keep it only if every local consumer of this broker is trusted.");
            }
          } else {
            if (!pwE && !authPluginE){
              add("WARNING", anonE.line, scopeName,
                "Anonymous access off but no password_file on port " + L.port,
                "allow_anonymous is false (line " + anonE.line + ") but no password_file is set for this listener and no auth_plugin is configured. As written, no client can authenticate \u2014 every connection will be refused, which usually means the first real deployment quietly flips anonymous access back on.",
                "Create a password file with mosquitto_passwd, set password_file for this listener, or configure an auth_plugin for external authentication.");
            } else if (pwE){
              add("POSITIVE", pwE.line, scopeName,
                "Authentication required on port " + L.port,
                "allow_anonymous is false (line " + anonE.line + ") and password_file is set (line " + pwE.line + "), so clients must authenticate. The password file path is noted by key name and line only; its contents are never read or shown.",
                "");
            }
          }

          /* Plaintext exposure */
          if (!tlsOn && exposed){
            if (anon){
              add("BLOCKER", L.line, scopeName,
                "Plaintext port " + L.port + " exposed with anonymous access",
                "This listener serves unencrypted MQTT on port " + L.port + " on " + (bc === "all" ? "all interfaces" : bind) + " and allows anonymous connections. Credentials (once any exist), topics, and payloads all cross the network in clear text, and anyone can join in.",
                "Move network clients to a TLS listener on 8883 with allow_anonymous false; keep a plaintext listener only on 127.0.0.1 for local tooling.");
            } else {
              add("WARNING", L.line, scopeName,
                "Plaintext port " + L.port + " exposed on the network",
                "This listener serves unencrypted MQTT on port " + L.port + " on " + (bc === "all" ? "all interfaces" : bind) + ". Authentication is required, but usernames, passwords, and message payloads cross the network in clear text where they can be captured.",
                "Add a TLS listener on 8883 and migrate clients to it, or restrict this listener with bind_address to a trusted interface.");
            }
          }

          /* ACL coverage, per listener (reported once per listener that authenticates or is exposed) */
          if (!aclE && (anon || pwE)){
            add("WARNING", anonE ? anonE.line : L.line, scopeName,
              "No acl_file \u2014 no topic restrictions on port " + L.port,
              "No acl_file is set for this listener, so there are no per-user topic restrictions: " + (anon ? "any anonymous client" : "any authenticated user") + " can publish and subscribe to every topic on this listener, including system topics it can reach.",
              "Add acl_file with per-user topic rules (read/write/readwrite patterns) for this listener.");
          } else if (aclE && !anon){
            add("POSITIVE", aclE.line, scopeName,
              "Topic ACLs configured on port " + L.port,
              "acl_file is set (line " + aclE.line + "), so per-user topic restrictions apply on this listener. The file path is noted by key name and line only.",
              "");
          }

          listenerRows.push({
            label: L.implicit ? "default" : ("line " + L.line),
            protocol: proto, port: L.port,
            bind: bind || "all interfaces",
            tls: tlsOn ? "on" : "off",
            anonymous: anon ? "true" : "false"
          });
        });

        /* No TLS listener anywhere */
        if (!anyTlsListener && listeners.some(function(L){
          var bindE = last(L, "bind_address");
          return bindClass(L.bindArg || (bindE ? bindE.value : null)) !== "loopback";
        })){
          add("WARNING", null, "Whole config",
            "No TLS listener anywhere in this config",
            "Every listener in this config serves plaintext MQTT and at least one is reachable from the network. There is no encrypted listener for clients to migrate to.",
            "Add a listener 8883 block with cafile, certfile, and keyfile set, and point network clients at it.");
        }
        if (implicit){
          add("INFO", null, "Whole config",
            "No listener directive \u2014 Mosquitto default listener applies",
            "With no listener lines, the broker uses a single default listener on port " + listeners[0].port + (listeners[0].bindArg ? " bound by bind_address" : " on all interfaces") + ". The findings above grade that default listener.",
            "Declare listeners explicitly so the exposure of each one is a deliberate choice.");
        }

        /* Persistence */
        var persE = last(globals, "persistence");
        listeners.forEach(function(L){ var e = last(L, "persistence"); if (e) persE = e; });
        var persLocE = last(globals, "persistence_location");
        listeners.forEach(function(L){ var e = last(L, "persistence_location"); if (e) persLocE = e; });
        if (persE && /^true$/i.test(persE.value) && persLocE){
          var p = persLocE.value;
          if (/^(\/tmp|\/var\/tmp|\/dev\/shm)(\/|$)/.test(p) || /^(\.\/|\.\.\/)/.test(p)){
            add("INFO", persLocE.line, "Whole config",
              "Persistence stored in a world-writable-style location",
              "persistence is true (line " + persE.line + ") and persistence_location (line " + persLocE.line + ") points under " + p.split("/").slice(0,3).join("/") + ", a shared/world-writable-style path. Retained messages and queued data written there can be read or tampered with by other local users, and the directory is typically wiped on reboot.",
              "Move persistence_location to a broker-owned directory such as /var/lib/mosquitto/ with restrictive permissions.");
          } else {
            add("INFO", persLocE.line, "Whole config",
              "Persistence on, location set",
              "persistence is true (line " + persE.line + ") with persistence_location set (line " + persLocE.line + "), so retained messages and subscriptions survive restarts. Confirm that directory is owned by the broker user and not group/world-writable.",
              "");
          }
        } else if (persE && /^true$/i.test(persE.value)){
          add("INFO", persE.line, "Whole config",
            "Persistence on, default location",
            "persistence is true (line " + persE.line + ") but persistence_location is not set, so the broker uses its compile-time default directory. Fine if deliberate; a surprise if the data lands somewhere unmanaged.",
            "Set persistence_location explicitly so the stored data has a known home.");
        }

        /* Logging verbosity */
        var logTypes = globals.dirs["log_type"] || [];
        listeners.forEach(function(L){ (L.dirs["log_type"] || []).forEach(function(e){ logTypes.push(e); }); });
        logTypes.forEach(function(e){
          var v = e.value.toLowerCase();
          if (v === "debug"){
            add("WARNING", e.line, "Whole config",
              "log_type debug \u2014 verbose logging on",
              "log_type debug (line " + e.line + ") logs connection detail, topics, and protocol chatter at full verbosity. In production that fills disks and can record sensitive topic names and client behavior.",
              "Drop log_type debug in production; keep error, warning, and notice.");
          } else if (v === "all"){
            add("INFO", e.line, "Whole config",
              "log_type all \u2014 every log class enabled",
              "log_type all (line " + e.line + ") enables all log classes including debug-level detail. Harmless while testing; noisy and revealing as a permanent production setting.",
              "Replace log_type all with the specific classes you need (error, warning, notice) once the broker is live.");
          }
        });

        /* Connection / queue limits */
        var mcE = last(globals, "max_connections");
        if (!mcE){
          add("INFO", null, "Whole config",
            "max_connections not set \u2014 unbounded by default",
            "max_connections never appears in this config, so Mosquitto's default applies: no limit (-1) on simultaneous connections. A misbehaving client fleet or a scan can grow connection count without a ceiling.",
            "Set max_connections to a number your host can actually serve.");
        } else if (+mcE.value === -1){
          add("INFO", mcE.line, "Whole config",
            "max_connections is -1 \u2014 explicitly unbounded",
            "max_connections is set to -1 at line " + mcE.line + ", which Mosquitto treats as no limit on simultaneous connections.",
            "Set max_connections to a finite number sized to the host.");
        }
        var mqE = last(globals, "max_queued_messages");
        if (!mqE){
          add("INFO", null, "Whole config",
            "max_queued_messages not set \u2014 broker default applies",
            "max_queued_messages never appears in this config, so Mosquitto's built-in default (1000 per client) applies. That ceiling exists, but it was chosen by default, not by you.",
            "Set max_queued_messages explicitly if offline clients queue large backlogs.");
        } else if (+mqE.value === 0){
          add("INFO", mqE.line, "Whole config",
            "max_queued_messages is 0 \u2014 unbounded queue",
            "max_queued_messages is set to 0 at line " + mqE.line + ", which Mosquitto treats as no limit: a disconnected client with a durable session can accumulate an unbounded in-memory queue.",
            "Set max_queued_messages to a finite number sized to available memory.");
        }

        /* NOT PARSED lines */
        parsed.notParsed.forEach(function(np){
          add("NOT PARSED", np.line, "Line " + np.line,
            "Line " + np.line + " was not parsed",
            np.reason + ". The line was ignored rather than guessed at, so nothing in this audit relies on it. Mosquitto itself would reject or misread a line like this at startup.",
            "Fix or remove line " + np.line + " so the directive you intended is the one the broker actually reads.");
        });

        /* Verdict */
        var order = { "BLOCKER":0, "WARNING":1, "NOT PARSED":2, "INFO":3, "POSITIVE":4 };
        findings.sort(function(a,b){
          if (order[a.severity] !== order[b.severity]) return order[a.severity] - order[b.severity];
          var la = a.line == null ? 9999 : a.line, lb = b.line == null ? 9999 : b.line;
          return la - lb;
        });
        var counts = { "BLOCKER":0, "WARNING":0, "NOT PARSED":0, "INFO":0, "POSITIVE":0 };
        findings.forEach(function(f){ counts[f.severity]++; });
        var verdict;
        if (counts["BLOCKER"] > 0) verdict = "DO NOT DEPLOY";
        else if (counts["WARNING"] > 0 || counts["NOT PARSED"] > 0) verdict = "DEPLOY WITH FIXES";
        else verdict = "SAFE TO DEPLOY";

        return { verdict:verdict, counts:counts, listeners:listenerRows, findings:findings,
                 notParsed: parsed.notParsed.map(function(n){ return { line:n.line, reason:n.reason }; }) };
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-mosquitto-config-safety-auditor',
  name: 'J-Dawgs Mosquitto MQTT Broker Config Safety Auditor',
  description: 'pasting a Mosquitto mosquitto.conf',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
