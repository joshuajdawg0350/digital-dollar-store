'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Memcached Server Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

  "use strict";

  var RISKY = [
    "# Risky worked example - staged options, not production-ready",
    "OPTIONS=\"-l 0.0.0.0 -p 11211 -U 11211 -m 65536\"",
    "sasl_admin_password = Tr0ub4dor-value-that-must-never-render",
    "--turbo-mode",
    "this line is not memcached options at all"
  ].join("\n");

  var CLEAN = [
    "# Clean worked example - local-only development cache",
    "OPTIONS=\"-l 127.0.0.1 -p 11211 -U 0 -m 512 -c 1024\""
  ].join("\n");

  var input = document.getElementById("optionsInput");
  var verdictBox = document.getElementById("verdictBox");
  var verdictWord = document.getElementById("verdictWord");
  var verdictWhy = document.getElementById("verdictWhy");
  var countsRow = document.getElementById("countsRow");
  var findingsWrap = document.getElementById("findingsWrap");
  var findingsList = document.getElementById("findingsList");
  var reportBox = document.getElementById("reportBox");
  var summaryBox = document.getElementById("summaryBox");
  var auditStatus = document.getElementById("auditStatus");
  var reportStatus = document.getElementById("reportStatus");
  var summaryStatus = document.getElementById("summaryStatus");
  var pitchStatus = document.getElementById("pitchStatus");

  var SEV_RANK = { "BLOCKER":0, "HIGH":1, "WARN":2, "REVIEW":3, "INFO":4 };
  var SEV_LABELS = ["BLOCKER","HIGH","WARN","REVIEW","INFO"];

  // Known memcached flags: [canonical, short, long, takesValue]
  var FLAG_DEFS = [
    ["listen","l","listen",true],
    ["port","p","port",true],
    ["udp","U","udp-port",true],
    ["socket","s","unix-socket",true],
    ["unixmask","a","unix-mask",true],
    ["memory","m","memory-limit",true],
    ["conns","c","conn-limit",true],
    ["user","u","user",true],
    ["pidfile","P","pidfile",true],
    ["growth","f","growth-factor",true],
    ["minitem","n","min-item-size",true],
    ["threads","t","threads",true],
    ["delim","D","delim",true],
    ["backlog","b","listen-backlog",true],
    ["protocol","B","protocol",true],
    ["maxitem","I","max-item-size",true],
    ["options","o","options",true],
    ["daemon","d","daemon",false],
    ["coredumps","r","enable-coredumps",false],
    ["lockmem","k","lock-memory",false],
    ["verbose","v",null,false],
    ["help","h","help",false],
    ["license","i","license",false],
    ["version","V","version",false],
    ["sasl","S","enable-sasl",false],
    ["ssl","Z","enable-ssl",false],
    ["disableflush","F","disable-flush-all",false],
    ["disablecas","C","disable-cas",false],
    ["largepages","L","enable-largepages",false],
    ["erronevict","M",null,false]
  ];
  var SHORT = {}, LONG = {};
  for (var d = 0; d < FLAG_DEFS.length; d++){
    var def = { canon: FLAG_DEFS[d][0], takesValue: FLAG_DEFS[d][3] };
    if (FLAG_DEFS[d][1]) SHORT[FLAG_DEFS[d][1]] = def;
    if (FLAG_DEFS[d][2]) LONG[FLAG_DEFS[d][2]] = def;
  }

  var SECRET_RE = /pass(word|wd)?|secret|token|api[-_]?key|credential|private[-_]?key/i;

  function tokenize(str){
    var out = [], cur = "", q = null, has = false, i, ch;
    for (i = 0; i < str.length; i++){
      ch = str.charAt(i);
      if (q){
        if (ch === q) q = null; else cur += ch;
        has = true;
      } else if (ch === '"' || ch === "'"){
        q = ch; has = true;
      } else if (/\s/.test(ch)){
        if (has || cur !== ""){ out.push(cur); cur = ""; has = false; }
      } else {
        cur += ch; has = true;
      }
    }
    if (has || cur !== "") out.push(cur);
    return out;
  }

  function commas(num){
    return String(num).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  }

  function isNum(v){ return typeof v === "string" && /^\d+$/.test(v); }

  function classifyAddr(raw){
    var a = raw.replace(/^\s+|\s+$/g, "");
    if (a.charAt(0) === "["){
      var close = a.indexOf("]");
      if (close > 0) a = a.slice(1, close);
    } else {
      var first = a.indexOf(":"), last = a.lastIndexOf(":");
      if (first > 0 && first === last) a = a.slice(0, first); // host:port
    }
    if (a === "" || a === "*" || a === "0.0.0.0" || a === "::") return "all";
    if (a === "::1" || a.toLowerCase() === "localhost" || /^127\./.test(a)) return "loopback";
    return "specific";
  }

  function audit(text){
    var findings = [];
    var occs = [];
    var flagNum = 0;
    var secretCount = 0, unknownCount = 0, unparsableCount = 0, dupCount = 0;
    var lines = text.split(/\r?\n/);

    function F(sev, line, occ, title, detail, fix){
      findings.push({
        sev: sev, line: line,
        flagNum: occ ? occ.num : 0,
        flagDisp: occ ? occ.display : "",
        title: title, detail: detail, fix: fix
      });
    }
    function wholeF(sev, title, detail, fix){
      findings.push({ sev: sev, line: 0, flagNum: 0, flagDisp: "", title: title, detail: detail, fix: fix });
    }
    function secretFinding(line, occNum, occDisp, name){
      secretCount++;
      findings.push({
        sev: "HIGH", line: line, flagNum: occNum, flagDisp: occDisp,
        title: "Secret-named option flagged by name only: " + name,
        detail: "The name " + name + " suggests a credential. Its value is never shown in this audit, the report, or the share-safe summary, and the option was excluded from every other check.",
        fix: "Move the credential out of the options text into your secret store or the service environment, and rotate it — it has been written down in a config file."
      });
    }

    // Parse one line's flag tokens. Returns {parsed, strays}.
    function parseTokens(toks, lineNo){
      var parsed = 0, strays = 0, i, tok;
      function nextValue(idx){
        if (idx + 1 < toks.length){
          var nx = toks[idx + 1];
          if (nx.charAt(0) !== "-" || /^-\d/.test(nx)) return nx;
        }
        return null;
      }
      for (i = 0; i < toks.length; i++){
        tok = toks[i];
        if (tok.charAt(0) === "#") break; // inline comment: the rest is ignored
        if (tok.slice(0, 2) === "--"){
          parsed++;
          var body = tok.slice(2);
          var eq = body.indexOf("=");
          var name = eq >= 0 ? body.slice(0, eq) : body;
          var attached = eq >= 0 ? body.slice(eq + 1) : null;
          flagNum++;
          var thisNum = flagNum, thisDisp = "--" + name;
          if (SECRET_RE.test(name)){
            if (attached === null && nextValue(i) !== null) i++;
            secretFinding(lineNo, thisNum, thisDisp, thisDisp);
            continue;
          }
          var ldef = LONG[name];
          if (!ldef && name.indexOf("ssl-") === 0) ldef = { canon: "ssl", takesValue: true };
          if (!ldef){
            unknownCount++;
            findings.push({
              sev: "REVIEW", line: lineNo, flagNum: thisNum, flagDisp: thisDisp,
              title: "Unknown flag " + thisDisp + " — NOT AUDITED",
              detail: "This auditor does not recognize " + thisDisp + ", so nothing about it was checked and nothing was guessed. If it carried a value, that value is not shown here.",
              fix: "Check " + thisDisp + " against `memcached -h` for your exact version before you deploy."
            });
            continue;
          }
          if (ldef.takesValue){
            var val = attached;
            if (val === null){ val = nextValue(i); if (val !== null) i++; }
            if (val === null || val === ""){
              findings.push({
                sev: "REVIEW", line: lineNo, flagNum: thisNum, flagDisp: thisDisp,
                title: "Flag " + thisDisp + " has no value",
                detail: thisDisp + " needs a value; with none given, memcached would refuse to start. The flag was excluded from resolution.",
                fix: "Give " + thisDisp + " a value, or remove it."
              });
              occs.push({ canon: ldef.canon, display: thisDisp, value: null, line: lineNo, num: thisNum, novalue: true });
            } else {
              occs.push({ canon: ldef.canon, display: thisDisp, value: val, line: lineNo, num: thisNum });
            }
          } else {
            occs.push({ canon: ldef.canon, display: thisDisp, value: null, line: lineNo, num: thisNum });
          }
        } else if (tok.charAt(0) === "-" && tok.length > 1){
          parsed++;
          var bodyS = tok.slice(1), j = 0;
          while (j < bodyS.length){
            var c = bodyS.charAt(j);
            var sdef = SHORT[c];
            flagNum++;
            var sNum = flagNum, sDisp = "-" + c;
            if (!sdef){
              unknownCount++;
              findings.push({
                sev: "REVIEW", line: lineNo, flagNum: sNum, flagDisp: sDisp,
                title: "Unknown flag " + sDisp + " — NOT AUDITED",
                detail: "This auditor does not recognize " + sDisp + ", so nothing about it was checked and nothing was guessed.",
                fix: "Check " + sDisp + " against `memcached -h` for your exact version before you deploy."
              });
              j++;
              continue;
            }
            if (sdef.takesValue){
              var rest = bodyS.slice(j + 1);
              if (rest.charAt(0) === "=") rest = rest.slice(1);
              var v2 = rest;
              if (v2 === ""){ v2 = nextValue(i); if (v2 !== null) i++; }
              if (v2 === null || v2 === ""){
                findings.push({
                  sev: "REVIEW", line: lineNo, flagNum: sNum, flagDisp: sDisp,
                  title: "Flag " + sDisp + " has no value",
                  detail: sDisp + " needs a value; with none given, memcached would refuse to start. The flag was excluded from resolution.",
                  fix: "Give " + sDisp + " a value, or remove it."
                });
                occs.push({ canon: sdef.canon, display: sDisp, value: null, line: lineNo, num: sNum, novalue: true });
              } else {
                occs.push({ canon: sdef.canon, display: sDisp, value: v2, line: lineNo, num: sNum });
              }
              j = bodyS.length;
            } else {
              var disp = sDisp;
              while (j + 1 < bodyS.length && bodyS.charAt(j + 1) === c){ disp += c; j++; }
              occs.push({ canon: sdef.canon, display: disp, value: null, line: lineNo, num: sNum });
              j++;
            }
          }
        } else {
          strays++;
        }
      }
      return { parsed: parsed, strays: strays };
    }

    for (var li = 0; li < lines.length; li++){
      var n = li + 1;
      var trimmed = lines[li].replace(/^\s+|\s+$/g, "");
      if (trimmed === "") continue;
      if (trimmed.charAt(0) === "#" || trimmed.charAt(0) === ";") continue;

      var mAssign = trimmed.match(/^(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/);
      if (mAssign){
        var varName = mAssign[1];
        if (SECRET_RE.test(varName)){
          secretFinding(n, 0, "", varName);
          continue;
        }
        if (/OPTIONS/i.test(varName) || /^ExecStart$/i.test(varName)){
          var rhs = mAssign[2].replace(/^\s+|\s+$/g, "");
          if (rhs.length >= 2 &&
              ((rhs.charAt(0) === '"' && rhs.charAt(rhs.length - 1) === '"') ||
               (rhs.charAt(0) === "'" && rhs.charAt(rhs.length - 1) === "'"))){
            rhs = rhs.slice(1, -1);
          }
          var toksA = tokenize(rhs);
          if (/^ExecStart$/i.test(varName) && toksA.length &&
              (toksA[0].indexOf("/") >= 0 || toksA[0] === "memcached")) toksA.shift();
          var resA = parseTokens(toksA, n);
          if (resA.parsed === 0){
            unparsableCount++;
            F("REVIEW", n, null, "Line " + n + " held no recognizable Memcached flags",
              "The " + varName + " value on this line produced no flags this auditor recognizes, so it contributed nothing to the audit. Its contents are not reproduced here.",
              "Check the line against `memcached -h` for your version, or remove it.");
          } else if (resA.strays > 0){
            F("REVIEW", n, null, "Line " + n + ": " + resA.strays + " token(s) did not belong to any flag",
              "Those tokens were excluded from the audit; their contents are not reproduced here.",
              "Remove the stray text, or fold it into a flag this auditor (and memcached) recognizes.");
          }
          continue;
        }
        unparsableCount++;
        F("REVIEW", n, null, "Line " + n + " is not Memcached options — excluded",
          "This line is an assignment this auditor does not treat as Memcached options, so it was excluded from the audit. Its contents are not reproduced here.",
          "If the line matters to the deployment, check it by hand; the audit graded only the options text.");
        continue;
      }

      var mSec = trimmed.match(/^([A-Za-z_][A-Za-z0-9_.-]*)\s*[:=\s]\s*\S/);
      if (mSec && trimmed.charAt(0) !== "-" && SECRET_RE.test(mSec[1])){
        secretFinding(n, 0, "", mSec[1]);
        continue;
      }

      var toks = tokenize(trimmed);
      if (toks.length && (toks[0] === "memcached" || /\/memcached$/.test(toks[0]))) toks.shift();
      var res = parseTokens(toks, n);
      if (res.parsed === 0){
        unparsableCount++;
        F("REVIEW", n, null, "Line " + n + " could not be parsed as Memcached options — excluded",
          "Nothing on this line parsed as a Memcached flag, so it contributed nothing to the audit. Its contents are not reproduced here.",
          "Fix the line into flag form (for example -l 127.0.0.1), comment it out with #, or remove it.");
      } else if (res.strays > 0){
        F("REVIEW", n, null, "Line " + n + ": " + res.strays + " token(s) did not belong to any flag",
          "Those tokens were excluded from the audit; their contents are not reproduced here.",
          "Remove the stray text, or fold it into a flag this auditor (and memcached) recognizes.");
      }
    }

    // --- Resolution: last value wins ---
    var byCanon = {};
    var oi;
    for (oi = 0; oi < occs.length; oi++){
      if (!byCanon[occs[oi].canon]) byCanon[occs[oi].canon] = [];
      byCanon[occs[oi].canon].push(occs[oi]);
    }
    function eff(canon){
      var a = byCanon[canon];
      return a && a.length ? a[a.length - 1] : null;
    }
    for (var canon in byCanon){
      var list = byCanon[canon];
      if (list.length > 1){
        dupCount++;
        var parts = [];
        for (var pi = 0; pi < list.length; pi++){
          parts.push("flag #" + list[pi].num + " (" + list[pi].display + ", line " + list[pi].line +
            (list[pi].value !== null ? ", value " + list[pi].value : "") + ")");
        }
        var lastOcc = list[list.length - 1];
        F("REVIEW", list[0].line, list[0],
          "Duplicate flag " + list[0].display + " — last value wins",
          list[0].display + " appears " + list.length + " times: " + parts.join(" and ") +
            ". Memcached resolves duplicate flags last-value-wins, so the effective setting is " +
            (lastOcc.value !== null ? lastOcc.display + " " + lastOcc.value : lastOcc.display + " (set)") +
            " from flag #" + lastOcc.num + ".",
          "Remove the earlier " + list[0].display + " so the options say one thing in one place.");
      }
    }

    var saslOcc = eff("sasl");
    var saslOn = !!saslOcc;

    // --- Bind exposure ---
    var listenOcc = eff("listen");
    var bindClass, bindHow;
    if (!listenOcc || listenOcc.value === null){
      bindClass = "all";
      bindHow = "default";
    } else {
      bindHow = "explicit";
      var addrs = listenOcc.value.split(",");
      var sawSpecific = false;
      bindClass = "loopback";
      for (var ai = 0; ai < addrs.length; ai++){
        var cls = classifyAddr(addrs[ai]);
        if (cls === "all"){ bindClass = "all"; break; }
        if (cls === "specific") sawSpecific = true;
      }
      if (bindClass !== "all" && sawSpecific) bindClass = "specific";
    }

    if (bindClass === "all"){
      if (!saslOn){
        if (bindHow === "default"){
          wholeF("BLOCKER",
            "World-reachable cache with no authentication (no -l flag — memcached binds all interfaces by default)",
            "No -l / --listen flag appears in the pasted options, and memcached listens on every network interface by default. With SASL (-S / --enable-sasl) off, anyone who can reach the port can read, write, and flush the cache.",
            "Add -l 127.0.0.1 (or a private interface address) and/or enable SASL with -S, with credentials kept outside the options text.");
        } else {
          F("BLOCKER", listenOcc.line, listenOcc,
            "World-reachable cache with no authentication (" + listenOcc.display + " covers all interfaces)",
            listenOcc.display + " " + listenOcc.value + " binds every network interface, and SASL (-S / --enable-sasl) is not enabled, so anyone who can reach the port can read, write, and flush the cache.",
            "Bind loopback or a private interface instead (for example -l 127.0.0.1) and/or enable SASL with -S, with credentials kept outside the options text.");
        }
      } else {
        if (bindHow === "default"){
          wholeF("WARN",
            "Bound on all interfaces by default (no -l flag); SASL is on",
            "No -l / --listen flag appears, so memcached will listen on every interface. SASL authentication is enabled, which is the only thing standing between the cache and the network.",
            "Set -l explicitly to the interfaces you intend — a default this wide should never be an accident.");
        } else {
          F("WARN", listenOcc.line, listenOcc,
            "Bound on all interfaces (" + listenOcc.display + " " + listenOcc.value + "); SASL is on",
            "The cache listens on every network interface. SASL authentication is enabled, which is the only thing standing between the cache and the network.",
            "Narrow -l to loopback or a private interface unless the cache truly must serve the whole network.");
        }
      }
    } else if (bindClass === "specific"){
      if (!saslOn){
        F("BLOCKER", listenOcc.line, listenOcc,
          "Cache bound to a non-loopback address with no authentication",
          listenOcc.display + " binds a specific non-loopback address (the address itself is not reproduced in shareable output), and SASL (-S / --enable-sasl) is not enabled. Anything that can route to that address can use the cache.",
          "Enable SASL with -S, restrict the address to a private network, or bind loopback and proxy access.");
      } else {
        F("INFO", listenOcc.line, listenOcc,
          "Non-loopback bind with SASL enabled",
          listenOcc.display + " binds a specific non-loopback address, and SASL authentication is enabled for clients that reach it.",
          "No change needed for this check — keep the SASL credentials rotated and the network ACL tight.");
      }
    } else {
      F("INFO", listenOcc.line, listenOcc,
        "Loopback-only bind — safe posture",
        listenOcc.display + " " + listenOcc.value + " listens on loopback only, so the cache is reachable only from this host.",
        "No change needed. If the bind ever widens beyond loopback, enable SASL (-S) first.");
    }

    // --- SASL posture notes ---
    if (saslOn){
      F("INFO", saslOcc.line, saslOcc,
        "SASL authentication enabled (" + saslOcc.display + ")",
        "Clients must authenticate before they can use the cache. No credential value appears in the pasted options, and none would ever be printed here.",
        "No change needed. Keep the SASL credential store outside the options text.");
    } else if (bindClass === "loopback"){
      wholeF("INFO",
        "SASL not enabled — acceptable only because the bind is loopback-only",
        "No -S / --enable-sasl flag appears. On a loopback-only bind that is a reasonable posture; the moment the bind widens, the cache is open to the network.",
        "Leave SASL off only while -l stays on loopback; enable -S before any wider bind.");
    }

    // --- UDP ---
    var udpOcc = eff("udp");
    var portOcc = eff("port");
    var tcpPort = portOcc && isNum(portOcc.value) ? parseInt(portOcc.value, 10) : 11211;
    var udpEnabled, udpPort, udpExplicit;
    if (udpOcc && udpOcc.value !== null){
      if (isNum(udpOcc.value)){
        udpPort = parseInt(udpOcc.value, 10);
        udpEnabled = udpPort !== 0;
        udpExplicit = true;
      } else {
        udpEnabled = false; udpExplicit = true;
        F("REVIEW", udpOcc.line, udpOcc,
          "Flag " + udpOcc.display + " value is not a plain port number",
          "The value given for " + udpOcc.display + " is not a plain number, so this auditor did not grade the UDP posture from it. The value is not reproduced here.",
          "Give " + udpOcc.display + " a numeric port, or 0 to disable UDP.");
      }
    } else if (udpOcc){
      udpEnabled = false; udpExplicit = true; // novalue occurrence already reported
    } else {
      udpEnabled = true; udpExplicit = false; udpPort = tcpPort;
    }
    if (udpOcc && udpOcc.value !== null && isNum(udpOcc.value) && !udpEnabled){
      F("INFO", udpOcc.line, udpOcc,
        "UDP disabled (" + udpOcc.display + " 0)",
        "UDP is explicitly off, so the cache cannot be used as a UDP reflection/amplification source.",
        "No change needed.");
    } else if (udpEnabled){
      var udpSev = bindClass === "loopback" ? "WARN" : "BLOCKER";
      var udpTitle = udpExplicit
        ? "UDP enabled (" + (udpOcc ? udpOcc.display : "-U") + " " + udpPort + ") — amplification and abuse risk"
        : "UDP on by default (no -U flag) — amplification and abuse risk";
      var udpDetail = udpExplicit
        ? "UDP is enabled on port " + udpPort + ". Memcached's UDP service has a long history of abuse as a reflection/amplification source for denial-of-service attacks" + (bindClass === "loopback" ? "; on this loopback-only bind the exposure is local, but it turns serious the moment the bind widens." : ", and this bind is reachable beyond the local host.")
        : "No -U flag appears, and memcached serves UDP on the TCP port (" + tcpPort + ") by default. That UDP service has a long history of abuse as a reflection/amplification source for denial-of-service attacks" + (bindClass === "loopback" ? "; on this loopback-only bind the exposure is local, but it turns serious the moment the bind widens." : ", and this bind is reachable beyond the local host.");
      if (udpExplicit && udpOcc){
        F(udpSev, udpOcc.line, udpOcc, udpTitle, udpDetail, "Set -U 0 to disable UDP unless you have a measured need for it.");
      } else {
        wholeF(udpSev, udpTitle, udpDetail, "Add -U 0 to disable UDP unless you have a measured need for it.");
      }
    }

    // --- Memory ---
    var memOcc = eff("memory");
    if (!memOcc){
      wholeF("INFO",
        "No -m / --memory-limit flag — the memcached default applies",
        "No memory limit appears in the pasted options, so the memcached default of 64 MB applies. That figure is the program's default, named here as a default — it was not read from your text.",
        "Set -m explicitly so the cache size is a decision, not a default you discover later.");
    } else if (memOcc.value !== null){
      if (isNum(memOcc.value)){
        var mb = parseInt(memOcc.value, 10);
        if (mb >= 16384){
          F("WARN", memOcc.line, memOcc,
            "Very large memory limit (" + memOcc.display + " " + commas(mb) + ")",
            memOcc.display + " " + commas(mb) + " lets the cache grow to " + commas(mb) + " MB of RAM. On a shared host that can starve everything else on the box.",
            "Confirm the host actually has this much RAM to spare, or lower -m to the working set the cache really needs.");
        }
      } else {
        F("REVIEW", memOcc.line, memOcc,
          "Flag " + memOcc.display + " value is not a plain number of megabytes",
          "The value given for " + memOcc.display + " is not a plain number, so this auditor did not grade the memory limit from it. The value is not reproduced here.",
          "Give " + memOcc.display + " a plain number of megabytes (for example -m 512).");
      }
    }

    // --- Connections ---
    var connOcc = eff("conns");
    if (!connOcc){
      wholeF("INFO",
        "No -c flag — the memcached default applies",
        "No connection limit appears in the pasted options, so the memcached default of 1,024 maximum connections applies. That figure is the program's default, named here as a default — it was not read from your text.",
        "Set -c explicitly if your client count needs more (or fewer) connections than the default.");
    } else if (connOcc.value !== null && !isNum(connOcc.value)){
      F("REVIEW", connOcc.line, connOcc,
        "Flag " + connOcc.display + " value is not a plain number",
        "The value given for " + connOcc.display + " is not a plain number, so this auditor did not grade the connection limit from it. The value is not reproduced here.",
        "Give " + connOcc.display + " a plain number (for example -c 1024).");
    }

    // --- TLS posture ---
    var sslOcc = eff("ssl");
    var tlsHow = null;
    if (sslOcc) tlsHow = sslOcc.display + " (flag #" + sslOcc.num + ", line " + sslOcc.line + ")";
    var optOcc = eff("options");
    var optKeysOther = [];
    if (optOcc && optOcc.value){
      var pairs = optOcc.value.split(",");
      for (var ki = 0; ki < pairs.length; ki++){
        var key = pairs[ki].split("=")[0].replace(/^\s+|\s+$/g, "");
        if (key === "") continue;
        if (key.indexOf("ssl_") === 0){
          if (!tlsHow) tlsHow = "-o " + key + " (flag #" + optOcc.num + ", line " + optOcc.line + ")";
        } else {
          optKeysOther.push(key);
        }
      }
    }
    if (optKeysOther.length){
      F("REVIEW", optOcc.line, optOcc,
        "Sub-options inside " + optOcc.display + " not individually audited",
        "The -o string names these sub-options: " + optKeysOther.join(", ") + ". This auditor reports their names only — their values are not shown, and their effects were not graded.",
        "Check each named sub-option against the memcached documentation for your version.");
    }
    if (tlsHow){
      findings.push({
        sev: "INFO", line: sslOcc ? sslOcc.line : optOcc.line,
        flagNum: sslOcc ? sslOcc.num : optOcc.num, flagDisp: sslOcc ? sslOcc.display : optOcc.display,
        title: "TLS enabled via " + tlsHow,
        detail: "TLS is switched on, so cache traffic can be encrypted in transit.",
        fix: "No change needed. Keep the certificate and key paths outside the options text's audience."
      });
    } else if (bindClass !== "loopback"){
      wholeF("WARN",
        "No TLS on a network-reachable bind",
        "No --enable-ssl / -Z flag and no ssl_* option appears, while the bind reaches beyond loopback — so cache traffic, including everything clients store and fetch, crosses the network in plaintext.",
        "Enable TLS (--enable-ssl, with the certificate and key set through -o ssl_chain_cert / ssl_key), or keep the bind on loopback or a trusted private network only.");
    }

    // --- Unix socket note ---
    var sockOcc = eff("socket");
    if (sockOcc){
      F("INFO", sockOcc.line, sockOcc,
        "Unix socket configured (" + sockOcc.display + ")",
        "A Unix socket is configured; access to it is governed by filesystem permissions. Note that a socket does not by itself switch off the TCP listener graded above.",
        "No change needed for the socket itself — make sure its file permissions are part of the deployment checklist.");
    }

    findings.sort(function(a, b){
      if (SEV_RANK[a.sev] !== SEV_RANK[b.sev]) return SEV_RANK[a.sev] - SEV_RANK[b.sev];
      var la = a.line === 0 ? 1000000 : a.line;
      var lb = b.line === 0 ? 1000000 : b.line;
      if (la !== lb) return la - lb;
      return a.flagNum - b.flagNum;
    });

    var counts = { BLOCKER: 0, HIGH: 0, WARN: 0, REVIEW: 0, INFO: 0 };
    for (var ci = 0; ci < findings.length; ci++) counts[findings[ci].sev]++;

    var verdict, cls, why;
    if (counts.BLOCKER > 0){
      verdict = "DO NOT DEPLOY"; cls = "bad";
      why = counts.BLOCKER + (counts.BLOCKER === 1 ? " blocker" : " blockers") + " found. Fix every blocker before these options go near a live server.";
    } else if (counts.HIGH + counts.WARN + counts.REVIEW > 0){
      verdict = "DEPLOY WITH FIXES"; cls = "warn";
      why = "No blockers, but " + (counts.HIGH + counts.WARN + counts.REVIEW) + " finding(s) need a fix or a deliberate review before deployment.";
    } else {
      verdict = "SAFE TO DEPLOY"; cls = "good";
      why = "No blocker, high, warning, or review finding fired on the pasted text — only INFO notes. This is a text audit, not a proof: the live server still deserves a smoke test.";
    }

    var state = {
      bindClass: bindClass,
      saslOn: saslOn,
      udpEnabled: udpEnabled,
      udpExplicit: udpExplicit,
      tlsOn: !!tlsHow,
      memSet: !!memOcc,
      connSet: !!connOcc,
      secretCount: secretCount,
      unknownCount: unknownCount,
      unparsableCount: unparsableCount,
      dupCount: dupCount
    };

    return { findings: findings, counts: counts, verdict: verdict, cls: cls, why: why, lineCount: lines.length, state: state };
  }

  function locText(f){
    return f.line === 0 ? "Whole input" : "Line " + f.line;
  }

  function buildReport(result){
    var out = [];
    out.push("J-Dawgs Memcached Server Safety Auditor - audit report");
    out.push("Verdict: " + result.verdict);
    out.push("Lines scanned: " + result.lineCount);
    out.push("Counts: BLOCKER " + result.counts.BLOCKER + " | HIGH " + result.counts.HIGH + " | WARN " + result.counts.WARN + " | REVIEW " + result.counts.REVIEW + " | INFO " + result.counts.INFO);
    out.push("Note: offline text audit only. Nothing was uploaded; no server was contacted, memcached was not run, and no live stats were seen. Secret values are never printed by design.");
    out.push("");
    if (!result.findings.length){
      out.push("Findings: none.");
    } else {
      out.push("Findings:");
      for (var i = 0; i < result.findings.length; i++){
        var f = result.findings[i];
        out.push("");
        out.push((i + 1) + ". " + locText(f) + (f.flagNum ? " - Flag #" + f.flagNum + " (" + f.flagDisp + ")" : "") + " [" + f.sev + "] " + f.title);
        out.push("   " + f.detail);
        out.push("   Fix: " + f.fix);
      }
    }
    return out.join("\n");
  }

  function buildSummary(result){
    var s = result.state;
    var bindWord = s.bindClass === "loopback" ? "loopback only" : (s.bindClass === "all" ? "all interfaces" : "a non-loopback address");
    var out = [];
    out.push("J-Dawgs Memcached Server Safety Auditor - share-safe summary");
    out.push("Verdict: " + result.verdict);
    out.push("Counts: BLOCKER " + result.counts.BLOCKER + " | HIGH " + result.counts.HIGH + " | WARN " + result.counts.WARN + " | REVIEW " + result.counts.REVIEW + " | INFO " + result.counts.INFO);
    out.push("Posture: bind = " + bindWord + " | SASL = " + (s.saslOn ? "on" : "off") + " | UDP = " + (s.udpEnabled ? "enabled" : "disabled") + " | TLS = " + (s.tlsOn ? "on" : "off") + " | memory limit = " + (s.memSet ? "set" : "default") + " | connection limit = " + (s.connSet ? "set" : "default"));
    out.push("Secret-named options flagged by name only: " + s.secretCount + " (names withheld in this summary)");
    out.push("Unknown flags (NOT AUDITED): " + s.unknownCount + " | Unparsable lines excluded: " + s.unparsableCount + " | Duplicate flags: " + s.dupCount);
    out.push("Generated locally in the browser from pasted text. No addresses, values, or secret names are included.");
    return out.join("\n");
  }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-memcached-server-safety-auditor',
  name: 'J-Dawgs Memcached Server Safety Auditor',
  description: 'Grades pasted Memcached options pre-deploy — all-interfaces bind with no SASL, UDP amplification, duplicate flags last-value-wins — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
