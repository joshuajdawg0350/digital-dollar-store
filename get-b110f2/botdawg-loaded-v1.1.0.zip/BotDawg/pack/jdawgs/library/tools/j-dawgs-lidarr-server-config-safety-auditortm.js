'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Lidarr Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

var RISKY = [
"<Config>",
"  <Port>8686</Port>",
"  <UrlBase></UrlBase>",
"  <BindAddress>*</BindAddress>",
"  <SslPort>6860</SslPort>",
"  <EnableSsl>False</EnableSsl>",
"  <LaunchBrowser>True</LaunchBrowser>",
"  <ApiKey>abc123examplekey</ApiKey>",
"  <AuthenticationMethod>None</AuthenticationMethod>",
"  <Branch>master</Branch>",
"  <LogLevel>debug</LogLevel>",
"  <SslCertPath></SslCertPath>",
"  <SslCertPassword>certpass123</SslCertPassword>",
"  <InstanceName>Lidarr</InstanceName>",
"  <AnalyticsEnabled>True</AnalyticsEnabled>",
"  <IndexerName>ExampleIndexer</IndexerName>",
"  <IndexerPassword>hunter2pass</IndexerPassword>",
"  <DownloadClientPassword>dl-secret-9876</DownloadClientPassword>",
"</Config>"
].join("\n");

var HARDENED = [
"<Config>",
"  <Port>8686</Port>",
"  <UrlBase>/lidarr</UrlBase>",
"  <BindAddress>127.0.0.1</BindAddress>",
"  <SslPort>6860</SslPort>",
"  <EnableSsl>True</EnableSsl>",
"  <LaunchBrowser>False</LaunchBrowser>",
"  <ApiKey>9f2c7a41d8e64b05a3f19c72e5d8064b</ApiKey>",
"  <AuthenticationMethod>Forms</AuthenticationMethod>",
"  <AuthenticationRequired>Enabled</AuthenticationRequired>",
"  <Branch>master</Branch>",
"  <LogLevel>info</LogLevel>",
"  <SslCertPath>/config/certs/lidarr.pfx</SslCertPath>",
"  <SslCertPassword></SslCertPassword>",
"  <InstanceName>Lidarr</InstanceName>",
"  <AnalyticsEnabled>False</AnalyticsEnabled>",
"</Config>"
].join("\n");

var SECRET_RE = /(password|passwd|pwd|apikey|api_key|token|secret|passkey|privatekey)/i;
var PLACEHOLDER_RE = /(example|changeme|change-me|your[-_ ]?api|yourkey|placeholder|xxxx|123456|abcdef|000000|111111|testkey|demo|sample|default)/i;

function isSecretKey(k){ return SECRET_RE.test(k); }
function isTrue(v){ return /^(true|yes|1|enabled|on)$/i.test((v||"").trim()); }
function isFalse(v){ return /^(false|no|0|disabled|off|none)$/i.test((v||"").trim()); }

function parseConfig(text){
  var lines = text.split(/\r?\n/);
  var entries = []; // {key, value, line}
  var byKey = {};
  lines.forEach(function(raw, idx){
    var lineNo = idx + 1;
    var m = raw.match(/<([A-Za-z][A-Za-z0-9_]*)>\s*([^<]*?)\s*<\/\1>/);
    if(m){ add(m[1], m[2], lineNo); return; }
    var kv = raw.match(/^\s*"?([A-Za-z][A-Za-z0-9_.-]*)"?\s*[:=]\s*"?([^"\n]*?)"?\s*,?\s*$/);
    if(kv && !/^<\/?/.test(raw.trim()) && raw.trim().length){ add(kv[1], kv[2], lineNo); }
  });
  function add(k, v, ln){
    var e = { key:k, value:(v||"").trim(), line:ln };
    entries.push(e);
    var lk = k.toLowerCase();
    if(!byKey[lk]) byKey[lk] = e;
  }
  return { lines: lines, entries: entries, byKey: byKey };
}
function get(parsed, name){
  return parsed.byKey[name.toLowerCase()] || null;
}

function audit(text){
  var findings = [];
  function push(sev, line, key, title, detail, fix){
    findings.push({ severity:sev, line:(line==null?null:line), key:key, title:title, detail:detail, fix:fix });
  }
  if(!text || !text.trim()){
    push("CRITICAL", null, "(empty input)", "No config was provided",
      "The input is empty, so nothing can be verified — an unexamined config must be treated as unsafe.",
      "Paste the full contents of config.xml and run the audit again.");
    return finish(text, {lines:[],entries:[],byKey:{}}, findings);
  }
  var p = parseConfig(text);

  /* --- API key --- */
  var api = get(p, "ApiKey");
  if(!api){
    push("CRITICAL", null, "ApiKey", "API key is missing",
      "No ApiKey entry was found. Without it, Lidarr generates or accepts access unpredictably on first run, and integrations cannot authenticate reliably.",
      "Let Lidarr generate a key, confirm a 32-character ApiKey entry exists in config.xml, and treat it like a password.");
  } else if(api.value === ""){
    push("CRITICAL", api.line, "ApiKey", "API key is empty",
      "The ApiKey entry on line " + api.line + " has length 0. An empty key offers no protection.",
      "Generate a new 32-character API key in Settings \u2192 General and restart, or set one before first launch.");
  } else {
    if(api.value.length < 32){
      push("CRITICAL", api.line, "ApiKey", "API key is too short (" + api.value.length + " characters)",
        "The ApiKey on line " + api.line + " is only " + api.value.length + " characters long. Lidarr keys are 32 characters; a short key is brute-forceable. Value is not shown.",
        "Regenerate the API key in Settings \u2192 General so it is a full 32-character random value, and update every integration that uses it.");
    }
    if(PLACEHOLDER_RE.test(api.value)){
      push("CRITICAL", api.line, "ApiKey", "API key looks like an example or placeholder",
        "The ApiKey on line " + api.line + " (length " + api.value.length + ") matches a known example / placeholder pattern. Example keys are public knowledge. Value is not shown.",
        "Replace it with a freshly generated, unique 32-character key that has never appeared in documentation or a repo.");
    }
    if(api.value.length >= 32 && !PLACEHOLDER_RE.test(api.value)){
      push("OK", api.line, "ApiKey", "API key length looks right",
        "The ApiKey on line " + api.line + " is " + api.value.length + " characters and does not match known placeholder patterns. Its actual validity and secrecy cannot be verified offline.",
        "No change needed. Rotate it if it has ever been shared, committed, or screenshotted.");
    }
  }

  /* --- Authentication --- */
  var auth = get(p, "AuthenticationMethod");
  var authOff = false;
  if(!auth || auth.value === "" || /^(none|disabled|off)$/i.test(auth.value)){
    authOff = true;
    push("CRITICAL", auth ? auth.line : null, "AuthenticationMethod", "Authentication is disabled",
      auth ? ("AuthenticationMethod on line " + auth.line + " is set to \u201C" + auth.value + "\u201D, so anyone who can reach the port gets full control — add / delete media, change settings, read the API key.")
           : "No AuthenticationMethod entry was found, so this config does not prove a login is required.",
      "Set AuthenticationMethod to Forms (browser login) or Basic, set a strong username and password, and restart Lidarr.");
  } else {
    push("OK", auth.line, "AuthenticationMethod", "Authentication is enabled",
      "AuthenticationMethod on line " + auth.line + " requires a login before the UI and API can be used.",
      "No change needed. Use a unique, strong password and keep AuthenticationRequired on for non-local access.");
  }

  /* --- Bind address --- */
  var bind = get(p, "BindAddress");
  var bindAll = false;
  if(bind && /^\*$/.test(bind.value) || bind && /^(0\.0\.0\.0|::)$/.test(bind.value)){
    bindAll = true;
    push("HIGH", bind.line, "BindAddress", "Listening on all interfaces",
      "BindAddress on line " + bind.line + " is \u201C" + bind.value + "\u201D, so Lidarr answers on every network interface — LAN, and the internet too if the port is forwarded or the host is public.",
      "If only local apps need it, bind to 127.0.0.1. If remote access is required, keep the bind but enforce authentication + HTTPS, or put Lidarr behind a VPN or authenticated reverse proxy.");
  } else if(bind && /^(127\.0\.0\.1|localhost)$/i.test(bind.value)){
    push("OK", bind.line, "BindAddress", "Bound to localhost only",
      "BindAddress on line " + bind.line + " limits Lidarr to this machine. Remote access would need a proxy or VPN, which is the safer default.",
      "No change needed unless you intentionally publish it — then re-run this audit with the new bind.");
  } else if(!bind){
    push("MEDIUM", null, "BindAddress", "Bind address not specified",
      "No BindAddress entry was found. Lidarr's default behaviour then decides which interfaces it listens on, and that default is not visible in this config.",
      "Set BindAddress explicitly — 127.0.0.1 for local-only, or a specific LAN address — so the exposure is a decision, not a default.");
  }

  /* --- SSL --- */
  var ssl = get(p, "EnableSsl");
  var sslOff = false;
  if(ssl && isFalse(ssl.value)){ sslOff = true; }
  if(!ssl){ sslOff = true; }
  if(sslOff){
    push(bindAll ? "HIGH" : "MEDIUM", ssl ? ssl.line : null, "EnableSsl", "SSL / HTTPS is disabled",
      (ssl ? "EnableSsl on line " + ssl.line + " is off" : "No EnableSsl entry was found") +
      ", so logins, the API key, and credentials travel as plain HTTP" + (bindAll ? " while the instance listens on all interfaces — anyone on the network path can read them." : "."),
      "Enable SSL with a valid certificate (or terminate HTTPS at a trusted reverse proxy) before exposing Lidarr beyond localhost.");
  } else {
    push("OK", ssl.line, "EnableSsl", "SSL / HTTPS is enabled",
      "EnableSsl on line " + ssl.line + " is on, so traffic to the UI and API is encrypted.",
      "No change needed. Keep the certificate current and confirm the cert password is not sitting in plaintext (checked separately).");
  }

  /* --- Combination escalation --- */
  if(authOff && bindAll && sslOff){
    push("CRITICAL", null, "Combination", "Worst-case combination: no login + all interfaces + plain HTTP",
      "Authentication is off, the bind covers every interface, and SSL is off at the same time. Together these mean anyone who can reach the port owns the instance and can read credentials in transit.",
      "Fix all three before deploying: enable Forms authentication, bind to localhost or protect with a proxy/VPN, and turn on HTTPS.");
  }

  /* --- SSL cert password --- */
  var certPw = get(p, "SslCertPassword");
  if(certPw && certPw.value !== ""){
    push("HIGH", certPw.line, "SslCertPassword", "SSL certificate password stored in plaintext",
      "SslCertPassword on line " + certPw.line + " holds a readable value of length " + certPw.value.length + ". Anyone who reads config.xml owns the certificate's private key. Value is not shown." + (sslOff ? " SSL is also disabled, so this secret is exposed while buying no protection at all." : ""),
      "Restrict config.xml file permissions to the Lidarr service account, prefer a certificate store / proxy-managed cert, and rotate the cert password if this file was ever shared or backed up in plaintext.");
  }

  /* --- Analytics --- */
  var analytics = get(p, "AnalyticsEnabled");
  if(analytics && isTrue(analytics.value)){
    push("MEDIUM", analytics.line, "AnalyticsEnabled", "Analytics / telemetry is enabled",
      "AnalyticsEnabled on line " + analytics.line + " is on, so the instance sends usage analytics to the Servarr telemetry endpoint.",
      "Set AnalyticsEnabled to False if you do not want the instance reporting usage data, then restart Lidarr.");
  } else if(analytics){
    push("OK", analytics.line, "AnalyticsEnabled", "Analytics is disabled",
      "AnalyticsEnabled on line " + analytics.line + " is off; the instance does not send usage analytics.",
      "No change needed.");
  }

  /* --- Generic plaintext secrets (indexers, download clients, misc) --- */
  p.entries.forEach(function(e){
    var lk = e.key.toLowerCase();
    if(lk === "apikey" || lk === "sslcertpassword") return;
    if(isSecretKey(e.key) && e.value !== ""){
      push("MEDIUM", e.line, e.key, "Plaintext credential: " + e.key,
        e.key + " on line " + e.line + " holds a readable credential of length " + e.value.length + ". Lidarr-family configs store indexer and download-client secrets as readable text, so config.xml must be treated as a secret itself. Value is not shown.",
        "Lock config.xml down to the service account only, never commit or share it, exclude it from world-readable backups, and rotate this credential if the file has circulated.");
    }
  });

  /* --- Log level --- */
  var log = get(p, "LogLevel");
  if(log && /^(debug|trace)$/i.test(log.value)){
    push("LOW", log.line, "LogLevel", "Verbose logging can capture secrets",
      "LogLevel on line " + log.line + " is \u201C" + log.value + "\u201D. Debug and trace logs can record URLs containing API keys and credential-bearing requests.",
      "Return LogLevel to info for normal running; raise it only briefly while troubleshooting, and treat log files as sensitive.");
  }

  /* --- Launch browser --- */
  var lb = get(p, "LaunchBrowser");
  if(lb && isTrue(lb.value)){
    push("LOW", lb.line, "LaunchBrowser", "Browser auto-launch is on",
      "LaunchBrowser on line " + lb.line + " opens a browser on start — harmless on a desktop, noisy and pointless on a headless server.",
      "Set LaunchBrowser to False on servers and containers.");
  }

  /* --- Missing core keys summary --- */
  ["Port","InstanceName"].forEach(function(k){
    if(!get(p, k)){
      push("LOW", null, k, k + " entry not found",
        "No " + k + " entry was present in the pasted text. This may just mean a partial config was pasted.",
        "Paste the complete config.xml for a full grade, or confirm the running instance has this set as intended.");
    }
  });

  return finish(text, p, findings);
}

function finish(text, parsed, findings){
  var counts = { CRITICAL:0, HIGH:0, MEDIUM:0, LOW:0, OK:0 };
  findings.forEach(function(f){ counts[f.severity] = (counts[f.severity]||0)+1; });
  var verdict, cls;
  if(counts.CRITICAL > 0){ verdict = "DO NOT DEPLOY"; cls = "danger"; }
  else if(counts.HIGH > 0 || counts.MEDIUM > 0){ verdict = "DEPLOY WITH FIXES"; cls = "fixes"; }
  else { verdict = "SAFE TO DEPLOY"; cls = "safe"; }
  var secretCount = parsed.entries.filter(function(e){ return isSecretKey(e.key) && e.value !== ""; }).length;
  return {
    verdict: verdict, cls: cls, counts: counts, findings: findings,
    lineCount: text ? text.split(/\r?\n/).length : 0,
    keyCount: parsed.entries.length, secretCount: secretCount,
    generatedAt: new Date().toISOString()
  };
}

function lineLabel(f){ return f.line == null ? "Not found in config" : "Line " + f.line; }

function buildReport(r){
  var out = [];
  out.push("J-Dawgs Lidarr Server Config Safety Auditor\u2122 — Audit Report");
  out.push("Generated: " + r.generatedAt);
  out.push("VERDICT: " + r.verdict);
  out.push("Findings: " + r.counts.CRITICAL + " critical, " + r.counts.HIGH + " high, " + r.counts.MEDIUM + " medium, " + r.counts.LOW + " low, " + r.counts.OK + " ok");
  out.push("Scope: " + r.lineCount + " lines, " + r.keyCount + " keys. Secrets are reported by key name, line, and length only — values are never included.");
  out.push("");
  r.findings.forEach(function(f, i){
    out.push((i+1) + ". [" + f.severity + "] " + f.title + " (" + f.key + ", " + lineLabel(f) + ")");
    out.push("   " + f.detail);
    out.push("   Fix: " + f.fix);
  });
  out.push("");
  out.push("Limits: offline structural grade only. No live server was contacted and no key, password, or certificate was verified.");
  return out.join("\n");
}
function buildJson(r){
  return JSON.stringify({
    tool: "J-Dawgs Lidarr Server Config Safety Auditor\u2122",
    generatedAt: r.generatedAt,
    verdict: r.verdict,
    counts: r.counts,
    scope: { lines: r.lineCount, keys: r.keyCount, secretsDetectedRedacted: r.secretCount },
    secretsPolicy: "Secret values are never included; secrets appear as key name, line, and length only.",
    findings: r.findings.map(function(f){
      return { severity:f.severity, line:f.line, key:f.key, title:f.title, detail:f.detail, fix:f.fix };
    })
  }, null, 2);
}
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-lidarr-server-config-safety-auditortm',
  name: 'J-Dawgs Lidarr Server Config Safety Auditor',
  description: 'Lidarr\'s own checks only answer whether the service starts on the host; ours grades a pasted Lidarr config.xml or env fully offline — authentication disabled, a short or example ApiKey, wildcard bind, SSL off, plaintext download-client and indexer passwords — into one deploy verdict, with secrets sh',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
