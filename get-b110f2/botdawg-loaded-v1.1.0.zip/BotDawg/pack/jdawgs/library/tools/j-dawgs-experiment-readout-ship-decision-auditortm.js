'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Experiment Readout & Ship-Decision Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var input = document.getElementById("readoutInput");
        var resultsEl = document.getElementById("results");
        var vbVerdict = document.getElementById("vbVerdict");
        var vbChips = document.getElementById("vbChips");
        var copyNote = document.getElementById("copyNote");
        var lastReport = "";

        function esc(s) {
          return String(s)
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;");
        }
        function fmtInt(n) {
          return Math.round(n).toLocaleString("en-US");
        }
        function fmtNum(n, dp) {
          return n.toLocaleString("en-US", { minimumFractionDigits: dp, maximumFractionDigits: dp });
        }
        function parseNum(s) {
          if (s === null || s === undefined) return null;
          var v = parseFloat(String(s).replace(/,/g, ""));
          return isNaN(v) ? null : v;
        }
        function parseDate(s) {
          var m = String(s).match(/(\d{4})-(\d{1,2})-(\d{1,2})/);
          if (m) return Date.UTC(+m[1], +m[2] - 1, +m[3]);
          var m2 = String(s).match(/(\d{1,2})\/(\d{1,2})\/(\d{4})/);
          if (m2) return Date.UTC(+m2[3], +m2[1] - 1, +m2[2]);
          return null;
        }
        function dateStr(ms) {
          var d = new Date(ms);
          function p(x) { return (x < 10 ? "0" : "") + x; }
          return d.getUTCFullYear() + "-" + p(d.getUTCMonth() + 1) + "-" + p(d.getUTCDate());
        }

        /* ---------- Parsing ---------- */
        function parseReadout(text) {
          var r = {
            name: null, splitParts: null, startMs: null, decisionMs: null,
            mde: null, variants: [], guardrails: [], missing: [], invalid: []
          };
          var lines = String(text).split(/\r?\n/);
          for (var i = 0; i < lines.length; i++) {
            var line = lines[i].trim();
            if (!line) continue;
            var low = line.toLowerCase();
            var m;
            if (/^experiment\s*:/.test(low)) {
              r.name = line.slice(line.indexOf(":") + 1).trim() || null;
            } else if (/^planned split\s*:/.test(low)) {
              var rest = line.slice(line.indexOf(":") + 1);
              var parts = rest.split(/[\/:,]/).map(function (x) { return parseNum(x.trim()); }).filter(function (x) { return x !== null; });
              if (parts.length >= 2) r.splitParts = parts;
            } else if (/^start date\s*:/.test(low)) {
              r.startMs = parseDate(line.slice(line.indexOf(":") + 1));
            } else if (/^decision date\s*:/.test(low)) {
              r.decisionMs = parseDate(line.slice(line.indexOf(":") + 1));
            } else if (/^mde\s*:/.test(low)) {
              r.mde = parseNum(line.slice(line.indexOf(":") + 1));
            } else if (/^variant\s/.test(low) || /^variant:/.test(low)) {
              var labelM = line.match(/^variant\s+([^:]+?)\s*:/i);
              var label = labelM ? labelM[1].trim() : "Variant " + (r.variants.length + 1);
              var visM = line.match(/([\d,]+(?:\.\d+)?)\s*visitors?/i);
              var convM = line.match(/([\d,]+(?:\.\d+)?)\s*conversions?/i);
              r.variants.push({
                label: label,
                visitors: visM ? parseNum(visM[1]) : null,
                conversions: convM ? parseNum(convM[1]) : null
              });
            } else if (/^guardrail\s*:/.test(low)) {
              var gline = line.slice(line.indexOf(":") + 1).trim();
              var gm = gline.match(/^(.+?)\s*(<=|>=|<|>|=)\s*([\d,]+(?:\.\d+)?)\s*(%?)\s*(?:[|;,]\s*)?(?:observed\s*[:=]?\s*([\d,]+(?:\.\d+)?)\s*(%)?)?\s*$/i);
              if (gm) {
                r.guardrails.push({
                  name: gm[1].trim(), op: gm[2], limit: parseNum(gm[3]),
                  observed: (gm[5] !== undefined && gm[5] !== "") ? parseNum(gm[5]) : null,
                  readable: true
                });
              } else {
                r.guardrails.push({ name: gline, op: null, limit: null, observed: null, readable: false });
              }
            }
          }

          /* Missing / invalid fields — named exactly, never guessed. */
          if (!r.name) r.missing.push("experiment name");
          if (!r.splitParts) r.missing.push("planned split");
          if (r.startMs === null) r.missing.push("start date");
          if (r.decisionMs === null) r.missing.push("decision date");
          if (r.mde === null) r.missing.push("MDE (minimum effect that would matter, in percentage points)");
          else if (r.mde <= 0) r.invalid.push("MDE is stated as " + r.mde + " — an effect of zero cannot be the bar");
          if (r.variants.length < 2) {
            r.missing.push("two variant lines (visitors and conversions for a control and a treatment variant)");
          }
          r.variants.forEach(function (v, idx) {
            if (v.visitors === null) r.missing.push("Variant " + v.label + " visitors");
            if (v.conversions === null) r.missing.push("Variant " + v.label + " conversions");
            if (v.visitors !== null && v.visitors <= 0) r.invalid.push("Variant " + v.label + " visitors is " + fmtInt(v.visitors) + " — a rate cannot be computed on zero or fewer visitors");
            if (v.visitors !== null && v.conversions !== null && v.conversions > v.visitors) r.invalid.push("Variant " + v.label + " conversions (" + fmtInt(v.conversions) + ") exceed its visitors (" + fmtInt(v.visitors) + ") — that cannot be a real count");
            void idx;
          });
          if (r.splitParts && r.variants.length >= 2 && r.splitParts.length !== r.variants.length) {
            r.invalid.push("planned split lists " + r.splitParts.length + " shares but " + r.variants.length + " variant lines were given");
          }
          if (r.startMs !== null && r.decisionMs !== null && r.decisionMs < r.startMs) {
            r.invalid.push("decision date (" + dateStr(r.decisionMs) + ") is before the start date (" + dateStr(r.startMs) + ")");
          }
          return r;
        }

        /* ---------- Audit ---------- */
        function audit(text) {
          var r = parseReadout(text);
          var out = {
            parsed: r, verdict: null, blockers: [], warnings: [], passes: [],
            checksHtml: "", report: [], chips: []
          };
          var R = out.report;
          R.push("J-Dawgs Experiment Readout & Ship-Decision Auditor™ — audit report");
          R.push("Experiment: " + (r.name || "(not stated)"));
          R.push("");

          var settled = r.missing.length === 0 && r.invalid.length === 0;

          /* Check 0 — fields */
          var fieldsHtml = "<div class='check'><h3>Fields <span class='grade " + (settled ? "ok" : "bad") + "'>" + (settled ? "Complete" : "Not settled") + "</span></h3>";
          if (settled) {
            fieldsHtml += "<p>Every required field is present and usable: experiment name, planned split, start and decision dates, MDE, and visitors + conversions for " + r.variants.length + " variants.</p>";
            out.passes.push("All required fields are present and usable.");
            R.push("FIELDS: complete.");
          } else {
            fieldsHtml += "<p><strong>Missing — named exactly, never guessed:</strong></p><ul>";
            r.missing.forEach(function (x) { fieldsHtml += "<li>" + esc(x) + "</li>"; R.push("MISSING: " + x); });
            fieldsHtml += "</ul>";
            if (r.invalid.length) {
              fieldsHtml += "<p><strong>Present but unusable:</strong></p><ul>";
              r.invalid.forEach(function (x) { fieldsHtml += "<li>" + esc(x) + "</li>"; R.push("UNUSABLE: " + x); });
              fieldsHtml += "</ul>";
            }
            fieldsHtml += "<p>Checks that depend on the missing fields are skipped rather than estimated.</p>";
          }
          fieldsHtml += "</div>";
          out.checksHtml += fieldsHtml;

          var canSplit = r.splitParts && r.variants.length >= 2 && r.splitParts.length === r.variants.length && r.variants.every(function (v) { return v.visitors !== null && v.visitors > 0; });
          var canRates = r.variants.length >= 2 && r.variants.every(function (v) { return v.visitors !== null && v.visitors > 0 && v.conversions !== null; });

          /* Check 1 — sample-ratio mismatch */
          var srmScore = null, srmGrade = null;
          if (canSplit) {
            var total = r.variants.reduce(function (a, v) { return a + v.visitors; }, 0);
            var splitTotal = r.splitParts.reduce(function (a, x) { return a + x; }, 0);
            var rows = "", arith = "", chi = 0;
            r.variants.forEach(function (v, i) {
              var share = r.splitParts[i] / splitTotal;
              var expected = total * share;
              var obsShare = v.visitors / total * 100;
              var term = Math.pow(v.visitors - expected, 2) / expected;
              chi += term;
              rows += "<tr><td>" + esc(v.label) + "</td><td>" + fmtInt(v.visitors) + "</td><td>" + fmtNum(obsShare, 2) + "%</td><td>" + fmtNum(share * 100, 2) + "%</td><td>" + fmtNum(expected, 1) + "</td><td>" + fmtNum(term, 3) + "</td></tr>";
              arith += "Variant " + v.label + ": expected = " + fmtInt(total) + " × " + fmtNum(share * 100, 2) + "% = " + fmtNum(expected, 1) + ";  (" + fmtInt(v.visitors) + " − " + fmtNum(expected, 1) + ")² ÷ " + fmtNum(expected, 1) + " = " + fmtNum(term, 3) + "\n";
            });
            arith += "Deviation score = sum of the per-variant terms = " + fmtNum(chi, 3);
            srmScore = chi;
            var sev, sevGrade;
            if (chi < 4) { sev = "In line with the plan — the observed split looks like the split that was planned."; sevGrade = "ok"; srmGrade = "ok"; }
            else if (chi <= 10) { sev = "Noticeably off — the split drifted from the plan. Find out why before trusting this readout."; sevGrade = "warn"; srmGrade = "warn"; out.warnings.push("Sample-ratio mismatch: deviation score " + fmtNum(chi, 2) + " — the observed split drifted noticeably from the planned split."); }
            else { sev = "Badly off — the observed split is nowhere near the plan. Something in the assignment or the logging is broken, and every downstream number inherits the break."; sevGrade = "bad"; srmGrade = "bad"; out.blockers.push("Sample-ratio mismatch: deviation score " + fmtNum(chi, 2) + " — the observed split is badly off the planned split."); }
            out.checksHtml += "<div class='check'><h3>1 · Sample-ratio check <span class='grade " + sevGrade + "'>" + (chi < 4 ? "Matches plan" : (chi <= 10 ? "Noticeably off" : "Badly off")) + "</span></h3>"
              + "<div class='table-scroll'><table><thead><tr><th>Variant</th><th>Visitors (observed)</th><th>Observed share</th><th>Planned share</th><th>Expected visitors</th><th>(obs − exp)² ÷ exp</th></tr></thead><tbody>" + rows + "</tbody></table></div>"
              + "<div class='arith'>" + esc(arith) + "</div>"
              + "<p><strong>Severity call:</strong> " + esc(sev) + "</p>"
              + "<p class='fine'>Bands on the score are a plain rule of thumb: under 4 in line, 4–10 noticeably off, over 10 badly off. This is a deviation score, not a p-value.</p></div>";
            R.push("SAMPLE-RATIO CHECK: score " + fmtNum(chi, 3) + " — " + sev);
            R.push(arith);
            out.chips.push({ t: "Split score " + fmtNum(chi, 2), c: sevGrade });
          }

          /* Check 2 — conversion rates and lift */
          var absLift = null, relLift = null;
          if (canRates) {
            var lines = "", rows2 = "";
            var rates = r.variants.map(function (v) {
              var rate = v.conversions / v.visitors;
              rows2 += "<tr><td>" + esc(v.label) + "</td><td>" + fmtInt(v.conversions) + " ÷ " + fmtInt(v.visitors) + "</td><td>" + fmtNum(rate * 100, 2) + "%</td></tr>";
              lines += "Variant " + v.label + ": " + fmtInt(v.conversions) + " ÷ " + fmtInt(v.visitors) + " = " + fmtNum(rate, 4) + " → " + fmtNum(rate * 100, 2) + "%\n";
              return rate;
            });
            var a = rates[0], b = rates[1];
            absLift = (b - a) * 100;
            relLift = a > 0 ? (b - a) / a * 100 : null;
            lines += "Absolute lift = " + fmtNum(b * 100, 2) + "% − " + fmtNum(a * 100, 2) + "% = " + (absLift >= 0 ? "+" : "") + fmtNum(absLift, 2) + " percentage points\n";
            lines += relLift !== null
              ? "Relative lift = " + fmtNum(absLift, 2) + " ÷ " + fmtNum(a * 100, 2) + " × 100 = " + (relLift >= 0 ? "+" : "") + fmtNum(relLift, 2) + "%"
              : "Relative lift cannot be computed — the control rate is 0%.";
            var liftGrade = absLift > 0 ? "ok" : "warn";
            out.checksHtml += "<div class='check'><h3>2 · Conversion rates &amp; lift <span class='grade " + liftGrade + "'>" + (absLift > 0 ? "Positive lift" : "No positive lift") + "</span></h3>"
              + "<div class='table-scroll'><table><thead><tr><th>Variant</th><th>Conversions ÷ visitors</th><th>Conversion rate</th></tr></thead><tbody>" + rows2 + "</tbody></table></div>"
              + "<div class='arith'>" + esc(lines) + "</div>"
              + "<p>Variant " + esc(r.variants[1].label) + " vs control Variant " + esc(r.variants[0].label) + ": <strong>" + (absLift >= 0 ? "+" : "") + fmtNum(absLift, 2) + " percentage points</strong>" + (relLift !== null ? " (<strong>" + (relLift >= 0 ? "+" : "") + fmtNum(relLift, 2) + "%</strong> relative)" : "") + ". No p-values or confidence intervals are computed — these are the readout's own numbers, divided out.</p></div>";
            R.push("CONVERSION RATES & LIFT:");
            R.push(lines);
            out.chips.push({ t: "Lift " + (absLift >= 0 ? "+" : "") + fmtNum(absLift, 2) + " pts", c: absLift > 0 ? "ok" : "warn" });
          }

          /* Check 3 — rough power sanity check */
          var powerOk = null;
          if (canRates && r.mde !== null && r.mde > 0) {
            var p = r.variants[0].conversions / r.variants[0].visitors;
            var d = r.mde / 100;
            if (p > 0 && p < 1) {
              var required = Math.ceil(16 * p * (1 - p) / (d * d));
              var plines = "p (control rate) = " + fmtNum(p, 4) + ";  d (MDE as a decimal) = " + fmtNum(d, 4) + "\n"
                + "Required per variant ≈ 16 × " + fmtNum(p, 4) + " × " + fmtNum(1 - p, 4) + " ÷ " + fmtNum(d, 4) + "² = " + fmtNum(16 * p * (1 - p) / (d * d), 1) + " → " + fmtInt(required) + " visitors\n";
              powerOk = true;
              r.variants.forEach(function (v) {
                var ok = v.visitors >= required;
                if (!ok) powerOk = false;
                plines += "Variant " + v.label + ": " + fmtInt(v.visitors) + " visitors " + (ok ? "≥" : "<") + " " + fmtInt(required) + " required → " + (ok ? "large enough" : "TOO SMALL") + "\n";
              });
              if (!powerOk) out.blockers.push("Sample too small for the stated MDE: at least one variant is below the roughly " + fmtInt(required) + " visitors per variant needed for an effect of " + fmtNum(r.mde, 2) + " points to have been detectable.");
              else out.passes.push("Both samples clear the rough size needed for the stated MDE (" + fmtInt(required) + " per variant).");
              out.checksHtml += "<div class='check'><h3>3 · Rough power sanity check <span class='grade " + (powerOk ? "ok" : "bad") + "'>" + (powerOk ? "Large enough" : "Too small") + "</span></h3>"
                + "<div class='arith'>" + esc(plines) + "</div>"
                + "<p>" + (powerOk
                  ? "Each variant's sample is at or above the rough requirement, so an effect of the stated MDE size (" + fmtNum(r.mde, 2) + " points) could plausibly have shown up in this readout."
                  : "At least one variant falls below the rough requirement. An effect of the stated MDE size (" + fmtNum(r.mde, 2) + " points) could easily have been missed at this sample size — the readout cannot settle the question it was run to answer.") + "</p>"
                + "<p class='fine'>This is a rough back-of-envelope sanity check using the stated shortcut formula — it is not an exact power calculation.</p></div>";
              R.push("ROUGH POWER SANITY CHECK (not an exact power calculation):");
              R.push(plines);
              out.chips.push({ t: "Sample vs MDE: " + (powerOk ? "enough" : "too small"), c: powerOk ? "ok" : "bad" });
            }
          }

          /* Check 4 — duration */
          var days = null;
          if (r.startMs !== null && r.decisionMs !== null && r.decisionMs >= r.startMs) {
            days = Math.round((r.decisionMs - r.startMs) / 86400000);
            var fullWeeks = Math.floor(days / 7), extra = days % 7;
            var dGrade, dMsg;
            if (days < 7) {
              dGrade = "bad";
              dMsg = "Under 7 days and short of one full weekly cycle. Weekday and weekend traffic behave differently; a partial week can fake an effect or hide a real one.";
              out.blockers.push("Duration is " + days + " days — under 7 days and short of a full weekly cycle.");
            } else {
              dGrade = "ok";
              dMsg = "Covers " + fullWeeks + " full weekly cycle" + (fullWeeks === 1 ? "" : "s") + (extra ? ", plus " + extra + " extra day" + (extra === 1 ? "" : "s") + " into the next cycle" : "") + " — every day of the week is represented.";
              out.passes.push("Duration is " + days + " days — at least one full weekly cycle.");
            }
            out.checksHtml += "<div class='check'><h3>4 · Duration <span class='grade " + dGrade + "'>" + days + " days</span></h3>"
              + "<div class='arith'>" + esc("Decision date " + dateStr(r.decisionMs) + " − start date " + dateStr(r.startMs) + " = " + days + " days") + "</div>"
              + "<p>" + esc(dMsg) + "</p></div>";
            R.push("DURATION: " + days + " days (" + dateStr(r.startMs) + " → " + dateStr(r.decisionMs) + "). " + dMsg);
            out.chips.push({ t: days + " days", c: dGrade });
          }

          /* Check 5 — guardrails */
          var gHtml = "<div class='check'><h3>5 · Guardrails</h3>";
          if (r.guardrails.length === 0) {
            gHtml += "<p class='empty-note'>No guardrail lines in this readout — nothing was graded. If the experiment has guardrails, they belong in the readout; an unstated guardrail is one nobody checked.</p>";
            R.push("GUARDRAILS: none stated in the readout.");
          } else {
            var grows = "";
            r.guardrails.forEach(function (g) {
              var grade, gClass;
              if (!g.readable || g.observed === null || g.limit === null) {
                grade = "NO EVIDENCE"; gClass = "neutral";
                out.warnings.push("Guardrail '" + g.name + "' is graded NO EVIDENCE — " + (!g.readable ? "the line could not be read." : "it states a limit but no observed value."));
              } else {
                var holds;
                if (g.op === "<=") holds = g.observed <= g.limit;
                else if (g.op === ">=") holds = g.observed >= g.limit;
                else if (g.op === "<") holds = g.observed < g.limit;
                else if (g.op === ">") holds = g.observed > g.limit;
                else holds = g.observed === g.limit;
                if (holds) { grade = "WITHIN LIMIT"; gClass = "ok"; }
                else { grade = "BREACHED"; gClass = "bad"; out.blockers.push("Guardrail breached: '" + g.name + "' observed " + fmtNum(g.observed, 2) + " against a limit of " + g.op + " " + fmtNum(g.limit, 2) + "."); }
              }
              grows += "<tr><td>" + esc(g.name) + "</td><td>" + (g.op ? esc(g.op) + " " + fmtNum(g.limit, 2) : "—") + "</td><td>" + (g.observed !== null ? fmtNum(g.observed, 2) : "not stated") + "</td><td><span class='grade " + gClass + "'>" + grade + "</span></td></tr>";
              R.push("GUARDRAIL: " + g.name + " | limit " + (g.op || "?") + " " + (g.limit !== null ? fmtNum(g.limit, 2) : "?") + " | observed " + (g.observed !== null ? fmtNum(g.observed, 2) : "not stated") + " → " + grade);
            });
            gHtml += "<div class='table-scroll'><table><thead><tr><th>Guardrail</th><th>Stated limit</th><th>Observed</th><th>Grade</th></tr></thead><tbody>" + grows + "</tbody></table></div>"
              + "<p class='fine'>Graded only against the limits written in the readout. This tool knows no team's real thresholds.</p>";
          }
          gHtml += "</div>";
          out.checksHtml += gHtml;

          /* ---------- Verdict ---------- */
          if (!settled) {
            out.verdict = "NOT SETTLED";
          } else if (out.blockers.length) {
            out.verdict = "DO NOT SHIP ON THIS READOUT";
          } else if (out.warnings.length) {
            out.verdict = "KEEP RUNNING";
          } else if (absLift !== null && r.mde !== null && absLift < r.mde) {
            out.verdict = "KEEP RUNNING";
            out.warnings.push("Observed lift is " + fmtNum(absLift, 2) + " points — smaller than the " + fmtNum(r.mde, 2) + "-point effect the team said would matter. More data, or accept that the effect, if real, is below the bar that was set.");
          } else if (absLift !== null && absLift <= 0) {
            out.verdict = "KEEP RUNNING";
            out.warnings.push("Observed lift is " + fmtNum(absLift, 2) + " points — the treatment is not ahead of the control on this readout.");
          } else {
            out.verdict = "SHIP IT";
          }

          R.push("");
          R.push("VERDICT: " + out.verdict);
          out.blockers.forEach(function (x) { R.push("BLOCKER: " + x); });
          out.warnings.forEach(function (x) { R.push("WARNING: " + x); });
          out.passes.forEach(function (x) { R.push("PASS: " + x); });
          R.push("");
          R.push("This audit checks the readout as pasted against itself. It verifies no raw event data and computes no p-values or confidence intervals. The decision stays with the team.");
          out.reportText = R.join("\n");
          return out;
        }

        /* ---------- Rendering ---------- */
        function verdictClass(v) {
          if (v === "SHIP IT") return "v-ship";
          if (v === "KEEP RUNNING") return "v-keep";
          if (v === "DO NOT SHIP ON THIS READOUT") return "v-dont";
          return "v-unsettled";
        }
        function verdictHeadClass(v) {
          if (v === "SHIP IT") return "ship";
          if (v === "KEEP RUNNING") return "keep";
          if (v === "DO NOT SHIP ON THIS READOUT") return "dont";
          return "";
        }
        var verdictWhy = {
          "SHIP IT": "Every check the readout can be held to, it passes: split on plan, full weekly cycles, samples large enough for the stated MDE, lift at or above the MDE, guardrails within limits.",
          "KEEP RUNNING": "The readout is usable but not conclusive. Settle the warnings below — or gather more data — before this readout carries a ship decision.",
          "DO NOT SHIP ON THIS READOUT": "The readout itself is broken in at least one way listed below. Fix the run or the logging and re-read; do not ship on these numbers.",
          "NOT SETTLED": "Required fields are missing or unusable, and this tool never guesses. Supply exactly what is named below and re-run the audit."
        };
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-experiment-readout-ship-decision-auditortm',
  name: 'J-Dawgs Experiment Readout & Ship-Decision Auditor',
  description: 'Cross-checks a pasted A/B readout: sample-ratio mismatch with deviation arithmetic, sample-vs-MDE sanity, duration / full-week check, guardrails — into one ship verdict. Computes no p-values.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
