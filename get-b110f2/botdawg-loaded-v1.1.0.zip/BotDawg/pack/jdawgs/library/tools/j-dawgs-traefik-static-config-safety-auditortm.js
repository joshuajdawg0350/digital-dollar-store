'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Traefik Static Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var RISKY = [
          "# Traefik static config — risky example",
          "global:",
          "  checkNewVersion: true",
          "  sendAnonymousUsage: true",
          "api:",
          "  insecure: true",
          "  dashboard: true",
          "entryPoints:",
          "  web:",
          "    address: \":80\"",
          "  traefik:",
          "    address: \":8080\"",
          "providers:",
          "  docker:",
          "    endpoint: \"unix:///var/run/docker.sock\"",
          "    exposedByDefault: true",
          "tls:",
          "  options:",
          "    default:",
          "      minVersion: VersionTLS10",
          "log:",
          "  level: DEBUG"
        ].join("\n");

        var HARDENED = [
          "# Traefik static config — hardened example",
          "api:",
          "  dashboard: true",
          "entryPoints:",
          "  web:",
          "    address: \":80\"",
          "    http:",
          "      redirections:",
          "        entryPoint:",
          "          to: websecure",
          "          scheme: https",
          "  websecure:",
          "    address: \":443\"",
          "  traefik:",
          "    address: \"127.0.0.1:8080\"",
          "providers:",
          "  docker:",
          "    exposedByDefault: false",
          "tls:",
          "  options:",
          "    default:",
          "      minVersion: VersionTLS12",
          "log:",
          "  level: INFO"
        ].join("\n");

        var GRADED = {
          api: true, entrypoints: true, providers: true, tls: true,
          certificatesresolvers: true, global: true, log: true, ping: true
        };
        var SECRET_RE = /(token|password|passwd|secret|credential|api[-_]?key|private[-_]?key|access[-_]?key)/i;

        var input = document.getElementById("config-input");
        var resultsEl = document.getElementById("results");
        var noInputNote = document.getElementById("no-input-note");
        var currentReport = "";

        function normalizeValue(raw) {
          var v = raw.replace(/^\s+/, "");
          if (v.charAt(0) === '"' || v.charAt(0) === "'") {
            var q = v.charAt(0);
            var end = v.indexOf(q, 1);
            return end === -1 ? v.slice(1) : v.slice(1, end);
          }
          var hash = v.indexOf(" #");
          if (hash !== -1) v = v.slice(0, hash);
          if (v.charAt(0) === "#") v = "";
          return v.replace(/\s+$/, "");
        }

        function isSecretEntry(e) {
          var last = e.path[e.path.length - 1] || "";
          if (SECRET_RE.test(last)) return true;
          var joined = e.path.join(".").toLowerCase();
          if (last.toLowerCase() === "storage" && joined.indexOf("acme") !== -1) return true;
          return false;
        }

        function parseConfig(text) {
          var rawLines = text.split(/\r?\n/);
          var entries = [];
          var notParsed = [];
          var sections = []; // {name (lowercased top-level), display, line}
          var seenSections = {};
          var stack = []; // YAML indent stack {indent, key}
          var inToml = false;
          var tomlPath = [];

          function noteSection(topDisplay, lineNo) {
            var k = topDisplay.toLowerCase();
            if (!seenSections[k]) {
              seenSections[k] = true;
              sections.push({ name: k, display: topDisplay, line: lineNo });
            }
          }

          for (var i = 0; i < rawLines.length; i++) {
            var lineNo = i + 1;
            var line = rawLines[i].replace(/\t/g, "  ");
            var trimmed = line.replace(/^\s+|\s+$/g, "");
            if (trimmed === "") continue;
            if (trimmed.charAt(0) === "#") continue;

            var secMatch = trimmed.match(/^\[\[?\s*([^\]]+?)\s*\]\]?$/);
            if (secMatch) {
              inToml = true;
              tomlPath = secMatch[1].split(".").map(function (s) {
                return s.replace(/^\s+|\s+$/g, "").replace(/^["']|["']$/g, "");
              }).filter(Boolean);
              stack = [];
              if (tomlPath.length) noteSection(tomlPath[0], lineNo);
              continue;
            }

            if (trimmed.charAt(0) === "-" && (trimmed.length === 1 || trimmed.charAt(1) === " ")) {
              continue; // YAML list item — belongs to the key above it
            }

            var kv = trimmed.match(/^([^:=]+?)[:=]([\s\S]*)$/);
            if (!kv) { notParsed.push(lineNo); continue; }
            var keyRaw = kv[1].replace(/^\s+|\s+$/g, "");
            if (/\s/.test(keyRaw) && keyRaw.charAt(0) !== '"' && keyRaw.charAt(0) !== "'") {
              notParsed.push(lineNo);
              continue;
            }
            var segs = keyRaw.split(".").map(function (s) {
              return s.replace(/^\s+|\s+$/g, "").replace(/^["']|["']$/g, "");
            }).filter(Boolean);
            if (!segs.length) { notParsed.push(lineNo); continue; }
            var value = normalizeValue(kv[2]);
            if (!inToml && (value.charAt(0) === "{" || value.charAt(0) === "[")) {
              notParsed.push(lineNo); // flow-style collections are not graded line-by-line
              continue;
            }

            var path;
            if (inToml) {
              path = tomlPath.concat(segs);
            } else {
              var indent = line.length - line.replace(/^\s+/, "").length;
              while (stack.length && stack[stack.length - 1].indent >= indent) stack.pop();
              path = stack.map(function (s) { return s.key; }).concat(segs);
              if (value === "") stack.push({ indent: indent, key: segs[segs.length - 1] });
            }
            if (path.length) noteSection(path[0], lineNo);
            entries.push({ path: path, key: segs[segs.length - 1], value: value, line: lineNo });
          }
          return { entries: entries, notParsed: notParsed, sections: sections };
        }

        function pathKey(e) { return e.path.map(function (s) { return s.toLowerCase(); }).join("."); }
        function isTrue(v) { return typeof v === "string" && v.replace(/["']/g, "").toLowerCase() === "true"; }

        function isPublicAddress(addr) {
          var a = (addr || "").replace(/["']/g, "").replace(/\s+/g, "");
          if (!a) return false;
          if (a.charAt(0) === ":") return true;
          var host = a.split(":")[0].replace(/^\[|\]$/g, "");
          return host === "" || host === "0.0.0.0" || host === "::";
        }
        function portOf(addr) {
          var a = (addr || "").replace(/["']/g, "");
          var parts = a.split(":");
          var p = parseInt(parts[parts.length - 1], 10);
          return isNaN(p) ? null : p;
        }

        function audit(text) {
          var parsed = parseConfig(text);
          var entries = parsed.entries;
          var findings = [];

          function add(sev, lines, rule, fix) {
            findings.push({ sev: sev, lines: lines, rule: rule, fix: fix });
          }
          function findExact(pk) {
            return entries.filter(function (e) { return pathKey(e) === pk; });
          }

          // Entrypoint map: name -> {address, line}
          var eps = {};
          entries.forEach(function (e) {
            var pk = pathKey(e).split(".");
            if (pk.length === 3 && pk[0] === "entrypoints" && pk[2] === "address") {
              eps[pk[1]] = { address: e.value, line: e.line, name: e.path[1] };
            }
          });

          // --- api.insecure ---
          findExact("api.insecure").forEach(function (e) {
            if (isTrue(e.value)) {
              add("BLOCKER", [e.line],
                "api.insecure is true — the Traefik dashboard and API are served with no authentication at all. Anyone who can reach the dashboard entrypoint can read the full configuration and the routes it exposes.",
                "Set api.insecure to false (or remove it) and put the dashboard behind an authenticated entrypoint with a middleware such as basicAuth.");
            }
          });

          // --- api.dashboard on a public entrypoint ---
          var dashOn = findExact("api.dashboard").some(function (e) { return isTrue(e.value); });
          var insecureOn = findExact("api.insecure").some(function (e) { return isTrue(e.value); });
          if (dashOn || insecureOn) {
            var dashLine = null;
            findExact("api.dashboard").forEach(function (e) { if (isTrue(e.value)) dashLine = e.line; });
            if (dashLine === null) findExact("api.insecure").forEach(function (e) { if (isTrue(e.value)) dashLine = e.line; });
            var dashEp = eps["traefik"] || null;
            if (dashEp && isPublicAddress(dashEp.address)) {
              add("WARNING", [dashLine, dashEp.line],
                "The dashboard is enabled and it rides the entrypoint \"" + dashEp.name + "\" (line " + dashEp.line + "), whose address " + dashEp.address + " binds every network interface — the dashboard is reachable from the network, not just this host.",
                "Bind the dashboard entrypoint to 127.0.0.1 (for example 127.0.0.1:8080) or put authentication in front of it, so it is not publicly reachable.");
            }
          }

          // --- Docker provider ---
          findExact("providers.docker.exposedbydefault").forEach(function (e) {
            if (isTrue(e.value)) {
              add("WARNING", [e.line],
                "providers.docker.exposedByDefault is true — every container on the host is published through Traefik unless it is explicitly labeled otherwise. One forgotten label exposes a service.",
                "Set exposedByDefault to false and opt containers in on purpose with the traefik.enable=true label.");
            }
          });
          entries.forEach(function (e) {
            var pk = pathKey(e);
            if (/^providers\.docker.*\.endpoint$/.test(pk) || pk === "providers.docker.endpoint") {
              if (e.value.indexOf("docker.sock") !== -1) {
                add("WARNING", [e.line],
                  "The Docker provider points at the Docker socket (" + e.value + "). Whoever controls Traefik's configuration effectively controls that socket, and the socket is root-level control of the host — treat this as a host-control trust decision, not a routine setting.",
                  "Keep it only if Traefik itself is locked down: run it with least privilege, never expose its API/dashboard publicly, and prefer a read-only socket proxy where one fits.");
              }
            }
          });

          // --- Plain HTTP entrypoints without redirect ---
          Object.keys(eps).forEach(function (name) {
            var ep = eps[name];
            if (portOf(ep.address) === 80) {
              var hasRedirect = entries.some(function (e) {
                var pk = pathKey(e);
                return pk.indexOf("entrypoints." + name + ".http.redirections.") === 0 && /\.to$/.test(pk) && e.value !== "";
              });
              if (!hasRedirect) {
                add("WARNING", [ep.line],
                  "Entrypoint \"" + ep.name + "\" listens on plain HTTP (port 80) and this file defines no redirect to HTTPS — traffic to it travels unencrypted and nothing pushes clients to the secure entrypoint.",
                  "Add an HTTP-to-HTTPS redirection on this entrypoint (http.redirections.entryPoint.to pointing at your HTTPS entrypoint, scheme https).");
              }
            }
          });

          // --- TLS minVersion ---
          entries.forEach(function (e) {
            var pk = pathKey(e);
            if (/(^|\.)minversion$/.test(pk) && pk.indexOf("tls.") === 0) {
              var v = e.value.replace(/["']/g, "");
              if (/^(VersionSSL30|VersionTLS10|VersionTLS11)$/i.test(v)) {
                add("BLOCKER", [e.line],
                  "TLS minVersion is " + v + " — an obsolete protocol floor. SSL 3.0 and TLS 1.0/1.1 are broken or deprecated and are refused by modern clients; allowing them downgrades every connection this proxy serves.",
                  "Set minVersion to VersionTLS12 (the acceptable floor) or VersionTLS13.");
              } else if (/^VersionTLS12$/i.test(v)) {
                add("INFO", [e.line],
                  "TLS minVersion is VersionTLS12 — the acceptable floor. Modern clients are fine with it; VersionTLS13 is the stricter option.",
                  "No change required. Consider VersionTLS13 if every client you serve supports it.");
              } else if (/^VersionTLS13$/i.test(v)) {
                add("INFO", [e.line],
                  "TLS minVersion is VersionTLS13 — the strictest floor Traefik offers.",
                  "No change required.");
              }
            }
          });

          // --- ACME httpChallenge ---
          entries.forEach(function (e) {
            var pk = pathKey(e);
            if (pk.indexOf("certificatesresolvers.") === 0 && pk.indexOf(".acme.httpchallenge.") !== -1) {
              add("WARNING", [e.line],
                "This ACME resolver uses the httpChallenge, which answers certificate challenges over a plain-HTTP entrypoint. Let's Encrypt's tlsChallenge proves control over the TLS port instead and is the preferred default.",
                "Switch the resolver to tlsChallenge (or dnsChallenge for wildcard certificates) unless you have a specific reason to keep httpChallenge.");
            }
          });

          // --- Phone-home settings (INFO only) ---
          findExact("global.checknewversion").forEach(function (e) {
            if (isTrue(e.value)) {
              add("INFO", [e.line],
                "global.checkNewVersion is true — Traefik periodically checks for a newer version over the network. Informational only; not a safety defect.",
                "No fix needed. Set it to false if you want the proxy to make no version-check calls.");
            }
          });
          findExact("global.sendanonymoususage").forEach(function (e) {
            if (isTrue(e.value)) {
              add("INFO", [e.line],
                "global.sendAnonymousUsage is true — Traefik sends anonymous usage statistics to its makers. Informational only; not a safety defect.",
                "No fix needed. Set it to false to stop the usage reporting.");
            }
          });

          // --- Log level DEBUG ---
          findExact("log.level").forEach(function (e) {
            if (e.value.replace(/["']/g, "").toUpperCase() === "DEBUG") {
              add("WARNING", [e.line],
                "log.level is DEBUG — debug logging is verbose and can record sensitive detail (headers, routing internals, request data) into log files that are often kept longer and shared more widely than the config itself.",
                "Run at INFO in production; raise to DEBUG only while actively troubleshooting, then set it back.");
            }
          });

          // --- Ping / health endpoint on a public entrypoint ---
          var pingSection = parsed.sections.filter(function (s) { return s.name === "ping"; })[0];
          if (pingSection) {
            var pingEpEntry = entries.filter(function (e) {
              var pk = pathKey(e);
              return pk === "ping.entrypoint";
            })[0];
            var pingEpName = pingEpEntry ? pingEpEntry.value.replace(/["']/g, "").toLowerCase() : "traefik";
            var pingEp = eps[pingEpName];
            if (pingEp && isPublicAddress(pingEp.address)) {
              add("WARNING", [pingEpEntry ? pingEpEntry.line : pingSection.line],
                "The ping health endpoint is exposed on entrypoint \"" + pingEp.name + "\" (line " + pingEp.line + "), which binds every network interface — anyone on the network can probe the proxy's health endpoint.",
                "Serve ping on an internal or localhost-bound entrypoint, or restrict it at the firewall.");
            } else {
              add("INFO", [pingSection.line],
                "A ping health endpoint is enabled on entrypoint \"" + pingEpName + "\", which is not publicly bound in this file.",
                "No change required.");
            }
          }

          // --- Secret-bearing keys: name and line only, never the value ---
          entries.forEach(function (e) {
            if (isSecretEntry(e) && e.value !== "") {
              add("WARNING", [e.line],
                "Key \"" + e.path.join(".") + "\" looks secret-bearing. Its value is deliberately not shown here or in the report — a pasted config must never become a place secrets leak back out of.",
                "Move the value out of the static config into an environment variable or a secret store, and rotate it if this file has been shared.");
            }
          });

          // --- Duplicate keys ---
          var byPath = {};
          entries.forEach(function (e) {
            if (e.value === "") return;
            var pk = pathKey(e);
            if (!byPath[pk]) byPath[pk] = [];
            byPath[pk].push(e);
          });
          Object.keys(byPath).forEach(function (pk) {
            var list = byPath[pk];
            if (list.length > 1) {
              var lines = list.map(function (e) { return e.line; });
              add("WARNING", lines,
                "Key \"" + list[0].path.join(".") + "\" is set " + list.length + " times (lines " + lines.join(" and ") + "). When a key is duplicated, the last value wins and the earlier setting is silently ignored — the config you read is not the config that runs.",
                "Delete the duplicate(s) and keep exactly one setting for this key.");
            }
          });

          // --- Not parsed / not audited ---
          parsed.notParsed.forEach(function (ln) {
            add("NOT PARSED", [ln],
              "Line " + ln + " could not be understood by this tool's parser, so nothing on it was graded. Its content is not reproduced here.",
              "Check the line by hand against Traefik's static config reference — do not assume it is safe or unsafe from this report.");
          });
          parsed.sections.forEach(function (s) {
            if (!GRADED[s.name]) {
              add("NOT AUDITED", [s.line],
                "Section \"" + s.display + "\" is not graded by this tool, so nothing in it was checked. It is listed so the gap is visible, not silent.",
                "Review this section by hand against Traefik's documentation before deploying.");
            }
          });

          var order = { "BLOCKER": 0, "WARNING": 1, "INFO": 2, "NOT PARSED": 3, "NOT AUDITED": 4 };
          findings.sort(function (a, b) {
            if (order[a.sev] !== order[b.sev]) return order[a.sev] - order[b.sev];
            return a.lines[0] - b.lines[0];
          });

          var counts = { "BLOCKER": 0, "WARNING": 0, "INFO": 0, "NOT PARSED": 0, "NOT AUDITED": 0 };
          findings.forEach(function (f) { counts[f.sev]++; });

          var verdict, vclass;
          if (counts["BLOCKER"] > 0) { verdict = "DO NOT DEPLOY"; vclass = "danger"; }
          else if (counts["WARNING"] > 0 || counts["NOT PARSED"] > 0) { verdict = "DEPLOY WITH FIXES"; vclass = "fixes"; }
          else { verdict = "SAFE TO DEPLOY"; vclass = "safe"; }

          return { findings: findings, counts: counts, verdict: verdict, vclass: vclass };
        }

        function lineLabel(lines) {
          if (lines.length === 1) return "Line " + lines[0];
          return "Lines " + lines.join(" & ");
        }

        function buildReport(r) {
          var out = [];
          out.push("J-Dawgs Traefik Static Config Safety Auditor — audit report");
          out.push("Verdict: " + r.verdict);
          out.push("Counts: " + r.counts["BLOCKER"] + " blocker(s), " + r.counts["WARNING"] + " warning(s), " +
            r.counts["INFO"] + " info, " + r.counts["NOT PARSED"] + " not parsed, " + r.counts["NOT AUDITED"] + " section(s) not audited");
          out.push("");
          if (!r.findings.length) {
            out.push("Findings: none. No graded rule fired on the pasted static config.");
          } else {
            out.push("Findings:");
            r.findings.forEach(function (f) {
              out.push("[" + f.sev + "] " + lineLabel(f.lines) + " — " + f.rule);
              out.push("  Fix: " + f.fix);
            });
          }
          out.push("");
          out.push("Secret-bearing keys are reported by key name and line only; no secret value appears in this report.");
          out.push("Heuristic text audit of the pasted static config only. Traefik was not started and no dynamic configuration was read.");
          return out.join("\n");
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-traefik-static-config-safety-auditortm',
  name: 'J-Dawgs Traefik Static Config Safety Auditor',
  description: 'Grades a pasted Traefik static config offline: api.insecure dashboard exposure, Docker exposedByDefault + socket, obsolete TLS floors, missing HTTPS redirect — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
