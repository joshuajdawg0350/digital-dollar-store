'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Window Installation Proposal, Work Record & Final Invoice Consistency Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";
var $ = function(id){ return document.getElementById(id); };
function money(n){ return "$" + Number(n).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ","); }
function parseAmt(s){ if(s===null||s===undefined) return null; var v = parseFloat(String(s).replace(/[$,]/g,"")); return isNaN(v)?null:v; }
function linesOf(t){ return t.split(/\r?\n/); }
function moneyOnLine(line){ var m = line.match(/\$\s*[\d,]+(?:\.\d{1,2})?/g); if(!m) return null; return parseAmt(m[m.length-1]); }
function findLineMoney(text, re){ var ls = linesOf(text), i, m; for(i=0;i<ls.length;i++){ if(re.test(ls[i])){ m = moneyOnLine(ls[i]); if(m!==null) return m; } } return null; }

function extractUnits(text){
  var m = text.match(/(\d+)\s*windows?\b/i);
  if(m) return parseInt(m[1],10);
  m = text.match(/windows?[^\d]{0,24}(\d+)\b/i);
  return m ? parseInt(m[1],10) : null;
}
function extractSeries(text){
  var m = text.match(/series\s*[:#\-]?\s*([A-Za-z]*\d[\w\-]*)/i) || text.match(/series\s+([A-Za-z0-9\-]+)/i);
  return m ? m[1].toLowerCase() : null;
}
var GLASS = ["low-e","lowe","low e","argon","tempered","impact"];
function glassTerms(text){
  var low = text.toLowerCase(), out = [], i, t;
  var hasLowE = /low[\s\-]?e/.test(low);
  if(hasLowE) out.push("Low-E");
  if(/argon/.test(low)) out.push("argon");
  if(/tempered/.test(low)) out.push("tempered");
  if(/impact/.test(low)) out.push("impact");
  return out;
}
function extractPerUnit(text){
  var m = text.match(/\$\s*([\d,]+(?:\.\d{1,2})?)\s*(?:per|\/)\s*(?:window|unit)/i);
  if(m) return parseAmt(m[1]);
  m = text.match(/per[-\s]?(?:window|unit)[^$\n]*\$\s*([\d,]+(?:\.\d{1,2})?)/i);
  return m ? parseAmt(m[1]) : null;
}
function extractHours(text){
  var ls = linesOf(text), i, m;
  for(i=0;i<ls.length;i++){ if(/hour|hrs?\b|labor/i.test(ls[i])){ m = ls[i].match(/(\d+(?:\.\d+)?)\s*(?:hours?|hrs?)\b/i); if(m) return parseFloat(m[1]); } }
  m = text.match(/(\d+(?:\.\d+)?)\s*(?:hours?|hrs?)\b/i);
  return m ? parseFloat(m[1]) : null;
}
function extractRate(text){
  var m = text.match(/\$\s*([\d,]+(?:\.\d{1,2})?)\s*(?:per|\/)\s*hour/i);
  if(m) return parseAmt(m[1]);
  var ls = linesOf(text), i;
  for(i=0;i<ls.length;i++){ if(/rate/i.test(ls[i]) && /hour|labor/i.test(ls[i])){ var v = moneyOnLine(ls[i]); if(v!==null) return v; } }
  return null;
}
function extractTotal(text){
  var ls = linesOf(text), i, v, found = null;
  for(i=0;i<ls.length;i++){ if(/\btotal\b/i.test(ls[i]) && !/subtotal/i.test(ls[i])){ v = moneyOnLine(ls[i]); if(v!==null) found = v; } }
  return found;
}
function extractLaborCharge(text){
  var ls = linesOf(text), i, v, found = null;
  for(i=0;i<ls.length;i++){ if(/labor|labour/i.test(ls[i])){ v = moneyOnLine(ls[i]); if(v!==null && v > 20) found = v; } }
  return found;
}
function invoiceChargeLines(text){
  var ls = linesOf(text), out = [], i, line, amt, label;
  for(i=0;i<ls.length;i++){
    line = ls[i].trim(); if(!line) continue;
    if(!/\$/.test(line)) continue;
    if(/total|deposit|per[-\s]?(unit|window|hour)|\/\s*(unit|window|hour)|rate|balance|amount due/i.test(line)) continue;
    amt = moneyOnLine(line); if(amt===null) continue;
    label = line.replace(/\$\s*[\d,]+(?:\.\d{1,2})?/g,"").replace(/[:\-=×x]\s*$/,"").trim();
    if(!label) label = "Unlabeled charge";
    out.push({label: label, amount: amt});
  }
  return out;
}
function docCounts(text){
  if(!text || text.trim().length < 15) return false;
  return /\d/.test(text) || /window|series|labor|deposit|total|invoice|proposal/i.test(text);
}

function audit(){
  var pText = $("docProposal").value, wText = $("docWork").value, iText = $("docInvoice").value;
  var hasP = docCounts(pText), hasW = docCounts(wText), hasI = docCounts(iText);
  var docs = [];
  if(hasP) docs.push("proposal"); if(hasW) docs.push("work record"); if(hasI) docs.push("invoice");
  var missing = [];
  if(!hasP) missing.push("PROPOSAL"); if(!hasW) missing.push("WORK RECORD"); if(!hasI) missing.push("FINAL INVOICE");
  var findings = [];
  function add(sev, name, detail, math){ findings.push({severity:sev, check:name, detail:detail, arithmetic:math||""}); }

  var P = hasP ? { units: extractUnits(pText), series: extractSeries(pText), glass: glassTerms(pText), perUnit: extractPerUnit(pText), hours: extractHours(pText), rate: extractRate(pText), labor: extractLaborCharge(pText), deposit: findLineMoney(pText, /deposit/i), total: extractTotal(pText) } : null;
  var W = hasW ? { units: extractUnits(wText), series: extractSeries(wText), glass: glassTerms(wText), hours: extractHours(wText), deposit: findLineMoney(wText, /deposit/i) } : null;
  var I = hasI ? { units: extractUnits(iText), series: extractSeries(iText), perUnit: extractPerUnit(iText), labor: extractLaborCharge(iText), depositCredited: findLineMoney(iText, /deposit\s*credited/i), total: extractTotal(iText), lines: invoiceChargeLines(iText) } : null;
  if(I && I.depositCredited===null) I.depositCredited = findLineMoney(iText, /deposit/i);

  var perUnit = (I && I.perUnit) || (P && P.perUnit) || null;
  var invoiceOnly = [], invoiceOnlySum = 0, reAdd = null;

  if(docs.length <= 1){
    add("info","Documents present","Only " + docs.length + " usable document(s) pasted (" + (docs.join(", ") || "none") + "). A cross-check needs at least two, and a full verdict needs all three.","Missing: " + missing.join(", "));
  } else {
    if(missing.length){
      add("flag","Missing document","Missing: " + missing.join(", ") + ". Without the " + missing.join(", ") + ", every check that needs it is skipped, and checks that compare the documents you did paste cannot be confirmed from the other direction. The verdict is capped at PAY WITH FIXES.","Documents pasted: " + docs.join(", ") + " · Missing: " + missing.join(", "));
    }
    /* Units billed vs recorded */
    if(W && I && W.units!==null && I.units!==null){
      if(I.units > W.units){
        var over = I.units - W.units, amt = perUnit!==null ? over*perUnit : null;
        add("blocker","Units billed vs units recorded installed","Invoice bills " + I.units + " windows but the work record shows only " + W.units + " installed — " + over + " window(s) billed above recorded." + (amt!==null ? " At the per-unit price that is " + money(amt) + " billed for windows the record does not show installed." : ""),"(" + I.units + " billed − " + W.units + " recorded) = " + over + " windows" + (amt!==null ? "\n" + over + " × " + money(perUnit) + " per unit = " + money(amt) : "\nPer-unit price not found, dollar value not computed"));
      } else if(I.units < W.units){
        add("flag","Units billed vs units recorded installed","Invoice bills " + I.units + " windows; the work record shows " + W.units + " installed. Fewer billed than recorded — confirm the unbilled work is intentional.", W.units + " recorded − " + I.units + " billed = " + (W.units - I.units) + " windows unbilled");
      } else {
        add("ok","Units billed vs units recorded installed","Billed count matches recorded installed count.","" + I.units + " billed = " + W.units + " recorded");
      }
    }
    /* Series identity */
    var seriesList = [];
    if(P && P.series) seriesList.push(["proposal", P.series]);
    if(W && W.series) seriesList.push(["work record", W.series]);
    if(I && I.series) seriesList.push(["invoice", I.series]);
    if(seriesList.length >= 2){
      var first = seriesList[0][1], mismatch = seriesList.some(function(s){ return s[1] !== first; });
      var desc = seriesList.map(function(s){ return s[0] + ": Series " + s[1]; }).join(" · ");
      if(mismatch) add("blocker","Series / model identity — product swap","The window series does not match across documents. That is a product swap or downgrade until proven otherwise.", desc);
      else add("ok","Series / model identity","Series matches across every document that names it.", desc);
    } else if(seriesList.length === 1){
      add("info","Series / model identity","Only one document names a window series, so identity cannot be cross-checked.", seriesList[0][0] + ": Series " + seriesList[0][1]);
    }
    /* Glass package */
    if(P && W && P.glass.length){
      var missingGlass = P.glass.filter(function(g){ return W.glass.indexOf(g) === -1; });
      if(missingGlass.length){
        add("flag","Glass package","The proposal promises " + P.glass.join(", ") + ", but the work record does not note " + missingGlass.join(", ") + ". The promised glass package is missing from the record — a downgrade passes silently unless this is confirmed.","Proposal glass: " + P.glass.join(", ") + "\nWork record glass: " + (W.glass.length ? W.glass.join(", ") : "none noted") + "\nMissing from record: " + missingGlass.join(", "));
      } else {
        add("ok","Glass package","Every glass feature promised in the proposal is noted in the work record.","Proposal glass: " + P.glass.join(", ") + " = Work record glass: " + W.glass.join(", "));
      }
    }
    /* Labor */
    var hours = (W && W.hours!==null) ? W.hours : (P ? P.hours : null);
    var rate = P ? P.rate : null;
    if(I && I.labor!==null && hours!==null && rate!==null){
      var expected = hours * rate;
      if(I.labor > expected + 0.005){
        add("flag","Labor charge vs recorded hours × proposal rate","Invoice labor is " + money(I.labor) + " but recorded hours at the proposal rate come to " + money(expected) + " — " + money(I.labor - expected) + " over.", hours + " hours × " + money(rate) + "/hour = " + money(expected) + " expected\n" + money(I.labor) + " charged − " + money(expected) + " expected = " + money(I.labor - expected) + " over");
      } else if(I.labor < expected - 0.005){
        add("ok","Labor charge vs recorded hours × proposal rate","Invoice labor is below recorded hours × proposal rate.","" + hours + " × " + money(rate) + " = " + money(expected) + " expected vs " + money(I.labor) + " charged");
      } else {
        add("ok","Labor charge vs recorded hours × proposal rate","Invoice labor matches recorded hours × proposal rate exactly.","" + hours + " hours × " + money(rate) + "/hour = " + money(expected) + " = " + money(I.labor) + " charged");
      }
    }
    /* Deposit */
    var paid = (P && P.deposit!==null) ? P.deposit : (W ? W.deposit : null);
    if(I && paid!==null && paid > 0){
      var credited = I.depositCredited;
      if(credited===null || credited === 0){
        add("blocker","Deposit credited","A deposit of " + money(paid) + " was paid, but the invoice credits " + (credited===null ? "no deposit at all" : money(0)) + ". The full " + money(paid) + " deposit is uncredited — do not pay it twice.", money(paid) + " paid − " + money(credited||0) + " credited = " + money(paid - (credited||0)) + " uncredited");
      } else if(credited < paid){
        add("flag","Deposit credited","Deposit paid was " + money(paid) + " but only " + money(credited) + " is credited on the invoice — " + money(paid - credited) + " uncredited.", money(paid) + " paid − " + money(credited) + " credited = " + money(paid - credited) + " uncredited");
      } else {
        add("ok","Deposit credited","The full deposit paid is credited on the invoice.", money(paid) + " paid = " + money(credited) + " credited");
      }
    }
    /* Invoice-only charges */
    if(P && I && I.lines.length){
      var pLow = pText.toLowerCase();
      I.lines.forEach(function(l){
        var words = l.label.toLowerCase().replace(/[^a-z\s]/g," ").split(/\s+/).filter(function(w){ return w.length > 3 && ["charge","windows","window","labor","labour"].indexOf(w)===-1; });
        var found = words.some(function(w){ return pLow.indexOf(w) !== -1; });
        if(words.length && !found){ invoiceOnly.push(l); invoiceOnlySum += l.amount; }
      });
      if(invoiceOnly.length){
        invoiceOnly.forEach(function(l){
          add("flag","Invoice-only charge","“" + l.label + "” appears on the invoice at " + money(l.amount) + " with no counterpart anywhere in the proposal.", l.label + ": " + money(l.amount) + " on invoice · $0.00 in proposal");
        });
      } else {
        add("ok","Invoice-only charges","Every invoice charge line has a counterpart in the proposal.","Invoice-only total: $0.00");
      }
    }
    /* Totals: re-add */
    if(I && I.lines.length && I.total!==null){
      reAdd = I.lines.reduce(function(s,l){ return s + l.amount; }, 0);
      var parts = I.lines.map(function(l){ return money(l.amount); }).join(" + ");
      if(Math.abs(reAdd - I.total) > 0.005){
        add("flag","Invoice totals re-add","The invoice charge lines re-add to " + money(reAdd) + " but the stated invoice total is " + money(I.total) + " — a " + money(Math.abs(reAdd - I.total)) + " gap.", parts + " = " + money(reAdd) + " re-added\nStated total: " + money(I.total) + "\nGap: " + money(Math.abs(reAdd - I.total)));
      } else {
        add("ok","Invoice totals re-add","Invoice charge lines re-add exactly to the stated total.", parts + " = " + money(reAdd) + " = stated total " + money(I.total));
      }
    }
    /* Proposal vs invoice delta */
    if(P && I && P.total!==null && I.total!==null){
      var delta = I.total - P.total;
      var unitDelta = (P.units!==null && I.units!==null && perUnit!==null) ? (I.units - P.units) * perUnit : 0;
      var laborDelta = (P.labor!==null && I.labor!==null) ? I.labor - P.labor : 0;
      var explained = unitDelta + laborDelta + invoiceOnlySum;
      var mathStr = "Invoice total " + money(I.total) + " − proposal total " + money(P.total) + " = " + money(delta) + " delta\nExplained by: unit-count change " + money(unitDelta) + " + labor change " + money(laborDelta) + " + invoice-only charges " + money(invoiceOnlySum) + " = " + money(explained);
      if(Math.abs(delta) < 0.005){
        add("ok","Proposal total vs invoice total","Invoice total equals the proposal total — no delta to explain.", mathStr);
      } else if(Math.abs(explained - delta) <= 0.005){
        add("info","Proposal total vs invoice total","The " + money(delta) + " delta between the proposal total and the invoice total is fully explained by the findings above — explained is not the same as justified; each item still has to be resolved.", mathStr + "\nUnexplained: $0.00");
      } else {
        add("flag","Proposal total vs invoice total","The " + money(delta) + " delta between the proposal total and the invoice total is not fully explained: " + money(Math.abs(delta - explained)) + " is unaccounted for.", mathStr + "\nUnexplained: " + money(delta - explained));
      }
    }
  }

  var hasBlocker = findings.some(function(f){ return f.severity === "blocker"; });
  var hasFlag = findings.some(function(f){ return f.severity === "flag"; });
  var verdict, vclass, why;
  if(docs.length <= 1){
    verdict = "NOT ENOUGH TO COMPARE"; vclass = "notenough";
    why = "Paste at least two of the three documents — proposal, work record, and final invoice — to run a cross-check. Missing: " + missing.join(", ") + ".";
  } else if(hasBlocker){
    verdict = "DO NOT PAY YET"; vclass = "donot";
    why = "One or more blockers were found (see BLOCKER findings below). Resolve them with the installer before paying." + (missing.length ? " Also missing: " + missing.join(", ") + "." : "");
  } else if(missing.length || hasFlag){
    verdict = "PAY WITH FIXES"; vclass = "fixes";
    why = (missing.length ? "Only two documents were pasted, so the verdict is capped at PAY WITH FIXES. Missing: " + missing.join(", ") + ". " : "") + (hasFlag ? "Fix each flagged item below before paying the affected amount." : "No discrepancies found in the documents pasted.");
  } else {
    verdict = "SAFE TO PAY"; vclass = "safe";
    why = "All three documents agree: counts, series, glass package, labor, deposit, and totals all cross-check with the arithmetic shown below. This is a text cross-check only — it verifies no work was performed.";
  }

  var result = {
    tool: "J-Dawgs Window Installation Proposal, Work Record & Final Invoice Consistency Auditor™",
    verdict: verdict,
    documents_pasted: docs,
    documents_missing: missing,
    extracted: {
      proposal: P, work_record: W, invoice: I ? { units: I.units, series: I.series, perUnit: I.perUnit, labor: I.labor, depositCredited: I.depositCredited, total: I.total, charge_lines: I.lines, lines_readded: reAdd } : null,
      invoice_only_charges: invoiceOnly, invoice_only_total: invoiceOnlySum
    },
    findings: findings,
    disclaimer: "Text cross-check only. Verifies no work was performed. Not trade or legal advice."
  };

  $("resultsCard").hidden = false;
  var vb = $("verdictBox"); vb.className = "verdict " + vclass;
  $("verdictLabel").textContent = verdict;
  $("verdictWhy").textContent = why;
  var fh = "";
  findings.forEach(function(f){
    fh += '<div class="finding ' + f.severity + '"><span class="sev">' + f.severity + '</span> · <span class="fname">' + f.check.replace(/</g,"&lt;") + '</span><div>' + f.detail.replace(/</g,"&lt;") + '</div>' + (f.arithmetic ? '<div class="math">' + f.arithmetic.replace(/</g,"&lt;") + '</div>' : '') + '</div>';
  });
  $("findings").innerHTML = fh || '<p class="note">No findings.</p>';

  var txt = "J-DAWGS WINDOW INSTALLATION CONSISTENCY AUDIT\nVerdict: " + verdict + "\nDocuments pasted: " + (docs.join(", ") || "none") + "\nDocuments missing: " + (missing.join(", ") || "none") + "\n\nFINDINGS\n";
  findings.forEach(function(f, idx){
    txt += (idx+1) + ". [" + f.severity.toUpperCase() + "] " + f.check + "\n   " + f.detail + (f.arithmetic ? "\n   Arithmetic: " + f.arithmetic.replace(/\n/g, " | ") : "") + "\n";
  });
  txt += "\nNote: text cross-check only; verifies no work was performed; not trade or legal advice.";
  $("textReport").textContent = txt;
  $("jsonReport").textContent = JSON.stringify(result, null, 2);
  $("resultsCard").scrollIntoView({behavior:"smooth", block:"start"});
  return result;
}
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-window-installation-proposal-work-record-final-invoice-consistency-auditortm',
  name: 'J-Dawgs Window Installation Proposal, Work Record & Final Invoice Consistency Auditor',
  description: '',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
