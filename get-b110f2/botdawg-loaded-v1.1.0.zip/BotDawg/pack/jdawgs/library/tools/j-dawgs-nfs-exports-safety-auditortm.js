'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs NFS Exports Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var RISKY_TEXT = "/srv/share *(rw,async,no_root_squash,insecure)";
      var HARDENED_TEXT = "/srv/projects 192.168.1.0/24(ro,sync,root_squash,secure)\n/srv/backups backuphost(ro,sync,root_squash)";

      var SEV_RANK = { "BLOCKER": 0, "NOT PARSED": 1, "WARNING": 2, "GOOD": 3, "INFO": 4 };

      function splitOpts(s) {
        if (!s) return [];
        return s.split(",").map(function (o) { return o.trim(); }).filter(function (o) { return o.length > 0; });
      }
      function optNames(opts) {
        return opts.map(function (o) { return o.split("=")[0].toLowerCase(); });
      }
      function lastWins(opts, a, b, dflt) {
        var names = optNames(opts), val = dflt;
        for (var i = 0; i < names.length; i++) {
          if (names[i] === a) val = a;
          else if (names[i] === b) val = b;
        }
        return val;
      }
      function hasOpt(opts, name) { return optNames(opts).indexOf(name) !== -1; }
      function optValue(opts, name) {
        for (var i = 0; i < opts.length; i++) {
          var parts = opts[i].split("=");
          if (parts[0].toLowerCase() === name) return parts.length > 1 ? parts[1] : "";
        }
        return null;
      }
      function normalizePath(p) {
        if (p.length > 1 && p.charAt(p.length - 1) === "/") return p.slice(0, p.length - 1);
        return p;
      }
      function isWorldHost(host) {
        return host === null || host === "*" || host === "0.0.0.0/0" || host === "::/0";
      }
      function sensitivePath(path) {
        if (path === "/") return "the entire filesystem root";
        if (path === "/etc") return "the system configuration directory, which holds service settings and can expose credentials";
        if (path === "/root") return "the root user's home directory";
        if (path === "/home") return "the parent directory of every user's home directory";
        if (/^\/home\/[^\/]+$/.test(path)) return "a user's home directory root";
        return null;
      }

      function audit(text) {
        var findings = [];
        var entries = [];      // one per (line, host) pair
        var linePaths = {};    // line number -> { path, sigParts: [] }
        var rawLines = text.split(/\r?\n/);
        var anyFsid = false, anyFsid0 = false, fsidLine = 0;

        function add(line, sev, text) { findings.push({ line: line, sev: sev, text: text }); }

        rawLines.forEach(function (raw, idx) {
          var n = idx + 1;
          var hash = raw.indexOf("#");
          var body = (hash === -1 ? raw : raw.slice(0, hash)).trim();
          if (!body) return;

          var tokens = body.split(/\s+/);
          var pathTok = tokens[0];
          if (pathTok.charAt(0) !== "/" || /[()]/.test(pathTok)) {
            add(n, "NOT PARSED", "Line " + n + " does not start with an absolute path, so it does not match the exports format and nothing about it was guessed: \u201C" + raw.trim() + "\u201D");
            return;
          }
          var path = normalizePath(pathTok);
          var hosts = [];
          var bad = false;
          for (var t = 1; t < tokens.length; t++) {
            var tok = tokens[t], m;
            if ((m = tok.match(/^([^\s()]+)\(([^()]*)\)$/))) {
              hosts.push({ host: m[1], options: splitOpts(m[2]) });
            } else if ((m = tok.match(/^\(([^()]*)\)$/))) {
              hosts.push({ host: null, options: splitOpts(m[1]) });
            } else if (/^[^\s()]+$/.test(tok)) {
              hosts.push({ host: tok, options: [] });
            } else { bad = true; break; }
          }
          if (!bad) {
            for (var h = 0; h < hosts.length && !bad; h++) {
              for (var o = 0; o < hosts[h].options.length; o++) {
                if (!/^[A-Za-z0-9_.\-]+(=[^,]+)?$/.test(hosts[h].options[o])) bad = true;
              }
            }
          }
          if (bad) {
            add(n, "NOT PARSED", "Line " + n + " could not be parsed as an export (malformed host or option list), so it was not audited and nothing about it was guessed: \u201C" + raw.trim() + "\u201D");
            return;
          }
          if (hosts.length === 0) hosts.push({ host: null, options: [], implicit: true });

          if (!linePaths[n]) linePaths[n] = { path: path, sigParts: [] };

          hosts.forEach(function (hst) {
            var opts = hst.options;
            var access = lastWins(opts, "rw", "ro", "ro");
            var syncMode = lastWins(opts, "sync", "async", "sync");
            var squash = lastWins(opts, "root_squash", "no_root_squash", "root_squash");
            var secureMode = lastWins(opts, "secure", "insecure", "secure");
            var world = isWorldHost(hst.host);
            var hostLabel = hst.host === null ? "(no host named)" : hst.host;
            var entry = {
              line: n, path: path, host: hst.host, hostLabel: hostLabel, opts: opts,
              access: access, syncMode: syncMode, squash: squash, secureMode: secureMode, world: world
            };
            entries.push(entry);
            linePaths[n].sigParts.push(access + "|" + squash + "|" + syncMode + "|" + secureMode + "|" + (world ? "world" : hostLabel));

            var fsid = optValue(opts, "fsid");
            if (fsid !== null) { anyFsid = true; if (!fsidLine) fsidLine = n; if (fsid === "0") anyFsid0 = true; }

            // (3) access mode, stated per export
            add(n, "INFO", "Line " + n + ": " + path + " \u2192 " + hostLabel + " is " +
              (access === "rw" ? "read-write (rw) — clients that can mount it can change files, not just read them."
                                : "read-only (ro) — clients can read, but not write."));

            // (1) world exposure
            if (world) {
              var why = hst.implicit
                ? "has no host list at all — in exports semantics an empty host list means the whole world"
                : (hst.host === null
                    ? "is shared with no host named on the line — that means the whole world in exports semantics"
                    : "is exported to the whole world (host pattern \u201C" + hst.host + "\u201D)");
              if (access === "rw") {
                add(n, "BLOCKER", "Line " + n + ": " + path + " " + why + ", with read-write access. Any machine that can reach this server can mount it and write to it.");
              } else {
                add(n, "WARNING", "Line " + n + ": " + path + " " + why + ", with read-only access. Any machine that can reach this server can mount it and read everything in it.");
              }
            }

            // (2) privilege
            if (squash === "no_root_squash") {
              if (access === "rw") {
                add(n, "BLOCKER", "Line " + n + ": no_root_squash on the read-write export of " + path + " \u2192 " + hostLabel + ". A root user on any client that can mount this share keeps full root privileges over the shared files.");
              } else {
                add(n, "WARNING", "Line " + n + ": no_root_squash on " + path + " \u2192 " + hostLabel + ". Remote root keeps its root identity; the export is read-only, which limits the damage, but root-owned files can still be read as root.");
              }
            } else {
              add(n, "GOOD", "Line " + n + ": root_squash is in effect for " + path + " \u2192 " + hostLabel +
                (hasOpt(opts, "root_squash") ? " (set on the line)" : " (the default when neither squash option is named)") +
                " — remote root is mapped down to an anonymous user.");
            }

            // (3) sync / async, secure / insecure
            if (syncMode === "async") {
              add(n, "WARNING", "Line " + n + ": async is in effect for " + path + " \u2192 " + hostLabel + ". The server can confirm a write before it reaches disk, so a server crash can silently lose data the client believes was saved.");
            } else {
              add(n, "GOOD", "Line " + n + ": sync is in effect for " + path + " \u2192 " + hostLabel +
                (hasOpt(opts, "sync") ? " (set on the line)" : " (the default)") +
                " — writes are committed to disk before the server confirms them.");
            }
            if (secureMode === "insecure") {
              add(n, "WARNING", "Line " + n + ": insecure is set for " + path + " \u2192 " + hostLabel + ". Clients may connect from ports above 1024, which any user on a client machine — not just root — can open, so the reserved-port trust check no longer means anything.");
            }

            // (5) sensitive paths
            var sens = sensitivePath(path);
            if (sens) {
              var sev = access === "rw" ? "BLOCKER" : "WARNING";
              add(n, sev, "Line " + n + ": this exports " + path + " — " + sens + ". Sharing it over NFS (" + (access === "rw" ? "read-write" : "read-only") + ", to " + hostLabel + ") puts far more than a data folder on the network.");
            }
          });
        });

        // (4) shadowing / overlap — same path twice
        var byPath = {};
        Object.keys(linePaths).forEach(function (ln) {
          var rec = linePaths[ln];
          if (!byPath[rec.path]) byPath[rec.path] = [];
          byPath[rec.path].push({ line: Number(ln), sig: rec.sigParts.slice().sort().join(";") });
        });
        Object.keys(byPath).forEach(function (p) {
          var group = byPath[p];
          for (var i = 0; i < group.length; i++) {
            for (var j = i + 1; j < group.length; j++) {
              if (group[i].sig !== group[j].sig) {
                add(group[j].line, "WARNING", "Lines " + group[i].line + " and " + group[j].line + " both export " + p + " with different options, so the file disagrees with itself about how " + p + " is shared. Which line takes effect can depend on the server and its version — does the later line replace the earlier one on your server, or does the first match stand? Keep one line for " + p + " so its posture is unambiguous.");
              } else {
                add(group[j].line, "INFO", "Lines " + group[i].line + " and " + group[j].line + " export " + p + " with identical posture. The duplicate is harmless, but one line is easier to audit than two.");
              }
            }
          }
        });
        // (4) parent / child overlap with conflicting posture
        var lineNums = Object.keys(linePaths).map(Number).sort(function (a, b) { return a - b; });
        function posture(ln) {
          var es = entries.filter(function (e) { return e.line === ln; });
          return {
            accesses: es.map(function (e) { return e.access; }).filter(function (v, i, a) { return a.indexOf(v) === i; }).sort().join(","),
            squash: es.map(function (e) { return e.squash; }).filter(function (v, i, a) { return a.indexOf(v) === i; }).sort().join(","),
            world: es.some(function (e) { return e.world; })
          };
        }
        for (var a = 0; a < lineNums.length; a++) {
          for (var b = 0; b < lineNums.length; b++) {
            if (a === b) continue;
            var pa = linePaths[lineNums[a]].path, pb = linePaths[lineNums[b]].path;
            if (pb.length > pa.length && pb.indexOf(pa === "/" ? "/" : pa + "/") === 0) {
              var postA = posture(lineNums[a]), postB = posture(lineNums[b]);
              if (postA.accesses !== postB.accesses || postA.squash !== postB.squash || postA.world !== postB.world) {
                add(lineNums[b], "WARNING", "Lines " + lineNums[a] + " and " + lineNums[b] + ": " + pa + " (line " + lineNums[a] + ") and its child path " + pb + " (line " + lineNums[b] + ") are exported with conflicting posture — " +
                  "line " + lineNums[a] + " is " + postA.accesses + (postA.world ? ", open to the world" : ", named hosts only") + ", " + postA.squash + "; line " + lineNums[b] + " is " + postB.accesses + (postB.world ? ", open to the world" : ", named hosts only") + ", " + postB.squash + ". " +
                  "When a client reaches the child path, which export governs it can depend on the server version and how the mount is made — is the more specific (child) export the one that takes effect on your server? Make the two postures agree, or confirm the behavior for your server before sharing.");
              }
            }
          }
        }

        // (6) NFSv4 root posture
        if (anyFsid && !anyFsid0) {
          add(fsidLine, "INFO", "Line " + fsidLine + ": NFSv4-style exports are in use here (an fsid= option appears), but no export in the file carries fsid=0, so no NFSv4 root export is defined. NFSv4 clients expect one fsid=0 root that the other exports hang under; without it, v4 mounts may fail to traverse the tree even though NFSv3 works.");
        } else if (anyFsid && anyFsid0) {
          add(fsidLine, "GOOD", "An export in this file carries fsid=0, so the NFSv4 root posture is defined for v4 clients.");
        }

        findings.sort(function (x, y) {
          if (x.line !== y.line) return x.line - y.line;
          return SEV_RANK[x.sev] - SEV_RANK[y.sev];
        });

        var counts = { BLOCKER: 0, WARNING: 0, GOOD: 0, INFO: 0, "NOT PARSED": 0 };
        findings.forEach(function (f) { counts[f.sev]++; });

        var verdict, verdictClass, why;
        if (entries.length === 0 && counts["NOT PARSED"] === 0) {
          verdict = null;
        } else if (counts.BLOCKER > 0) {
          verdict = "DO NOT SHARE"; verdictClass = "danger";
          why = counts.BLOCKER + (counts.BLOCKER === 1 ? " blocker" : " blockers") + " found. Fix every blocker before this file goes on a server — each one is a hole a client can walk through, not a style nit.";
        } else if (counts.WARNING > 0 || counts["NOT PARSED"] > 0) {
          verdict = "SHARE WITH FIXES"; verdictClass = "fixes";
          why = "No blockers, but " +
            (counts.WARNING > 0 ? counts.WARNING + (counts.WARNING === 1 ? " warning" : " warnings") + " to fix" : "") +
            (counts.WARNING > 0 && counts["NOT PARSED"] > 0 ? " and " : "") +
            (counts["NOT PARSED"] > 0 ? counts["NOT PARSED"] + (counts["NOT PARSED"] === 1 ? " line" : " lines") + " that could not be parsed — the auditor will not call a file safe when part of it could not be read" : "") +
            ". Work through the findings, then run the audit again.";
        } else {
          verdict = "SAFE TO SHARE"; verdictClass = "safe";
          why = "No blockers and no warnings. Every export in the pasted file is named-host, root-squashed, and free of the exposure patterns this auditor checks for.";
        }

        return { findings: findings, counts: counts, entries: entries.length, verdict: verdict, verdictClass: verdictClass, why: why };
      }

      function buildReport(result) {
        var out = [];
        out.push("J-Dawgs NFS Exports Safety Auditor\u2122 — Audit Report");
        out.push("Verdict: " + (result.verdict || "NOTHING TO AUDIT"));
        out.push("Exports audited: " + result.entries +
          " · Blockers: " + result.counts.BLOCKER +
          " · Warnings: " + result.counts.WARNING +
          " · Good: " + result.counts.GOOD +
          " · Info: " + result.counts.INFO +
          " · Not parsed: " + result.counts["NOT PARSED"]);
        out.push("");
        if (result.findings.length === 0) {
          out.push("No findings — no export lines were found in the pasted text.");
        } else {
          out.push("Findings:");
          result.findings.forEach(function (f) { out.push("[" + f.sev + "] " + f.text); });
        }
        out.push("");
        out.push("Heuristic text audit of the pasted file only. No NFS server was contacted, nothing was mounted, and nothing was uploaded or saved.");
        out.push("\u00A9 2026 Joshua Dawson");
        return out.join("\n");
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-nfs-exports-safety-auditortm',
  name: 'J-Dawgs NFS Exports Safety Auditor',
  description: 'exportfs/showmount need a live server and only list what is shared; ours grades a pasted /etc/exports offline — world exposure, root-squash posture, shadowing — into one share verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
