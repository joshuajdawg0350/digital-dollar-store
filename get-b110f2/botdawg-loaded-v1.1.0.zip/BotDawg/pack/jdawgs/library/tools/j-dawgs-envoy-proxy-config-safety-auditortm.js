'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Envoy Proxy Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var RISKY = [
          "# Risky example — do not ship a config like this",
          "admin:",
          "  address:",
          "    socket_address:",
          "      address: 0.0.0.0",
          "      port_value: 9901",
          "static_resources:",
          "  listeners:",
          "  - name: listener_http",
          "    address:",
          "      socket_address:",
          "        address: 0.0.0.0",
          "        port_value: 8080",
          "    filter_chains:",
          "    - filters:",
          "      - name: envoy.filters.network.http_connection_manager",
          "        typed_config:",
          '          "@type": type.googleapis.com/envoy.extensions.filters.network.http_connection_manager.v3.HttpConnectionManager',
          "          stat_prefix: ingress_http",
          "          route_config:",
          "            name: local_route",
          "            virtual_hosts:",
          "            - name: backend",
          '              domains: ["*"]',
          "              cors:",
          "                allow_origin_string_match:",
          '                - prefix: "*"',
          "                allow_credentials: true",
          "              routes:",
          "              - match:",
          '                  prefix: "/"',
          "                route:",
          "                  cluster: backend_cluster",
          "          http_filters:",
          "          - name: envoy.filters.http.ext_authz",
          "            typed_config:",
          '              "@type": type.googleapis.com/envoy.extensions.filters.http.ext_authz.v3.ExtAuthz',
          "              http_service:",
          "                server_uri:",
          "                  uri: http://auth.internal.example.com:9000",
          "                  cluster: backend_cluster",
          "                  timeout: 2s",
          "          - name: envoy.filters.http.router",
          "  - name: listener_https_unverified",
          "    address:",
          "      socket_address:",
          "        address: 0.0.0.0",
          "        port_value: 8443",
          "    filter_chains:",
          "    - transport_socket:",
          "        name: envoy.transport_sockets.tls",
          "        typed_config:",
          '          "@type": type.googleapis.com/envoy.extensions.transport_sockets.tls.v3.DownstreamTlsContext',
          "          common_tls_context:",
          "            validation_context:",
          "              trust_chain_verification: ACCEPT_UNTRUSTED",
          "              validate_certificate: false",
          "      filters:",
          "      - name: envoy.filters.network.http_connection_manager",
          "        typed_config:",
          '          "@type": type.googleapis.com/envoy.extensions.filters.network.http_connection_manager.v3.HttpConnectionManager',
          "          stat_prefix: ingress_https",
          "          route_config:",
          "            name: local_route_tls",
          "            virtual_hosts:",
          "            - name: backend_tls",
          '              domains: ["*"]',
          "              routes:",
          "              - match:",
          '                  prefix: "/"',
          "                route:",
          "                  cluster: backend_cluster",
          "  clusters:",
          "  - name: backend_cluster",
          "    connect_timeout: 5s",
          "    type: LOGICAL_DNS",
          "    dns_lookup_family: V4_ONLY",
          "    metadata:",
          "      filter_metadata:",
          "        backend:",
          '          api_key: "FAKE-EXAMPLE-KEY-0000-not-a-real-secret"',
          "    load_assignment:",
          "      cluster_name: backend_cluster",
          "      endpoints:",
          "      - lb_endpoints:",
          "        - endpoint:",
          "            address:",
          "              socket_address:",
          "                address: backend.internal.example.com",
          "                port_value: 8080"
        ].join("\n");

        var HARDENED = [
          "# Hardened example — the same shape, done right",
          "admin:",
          "  address:",
          "    socket_address:",
          "      address: 127.0.0.1",
          "      port_value: 9901",
          "stats_config:",
          "  use_all_default_tags: true",
          "static_resources:",
          "  listeners:",
          "  - name: listener_https",
          "    address:",
          "      socket_address:",
          "        address: 127.0.0.1",
          "        port_value: 8443",
          "    filter_chains:",
          "    - transport_socket:",
          "        name: envoy.transport_sockets.tls",
          "        typed_config:",
          '          "@type": type.googleapis.com/envoy.extensions.transport_sockets.tls.v3.DownstreamTlsContext',
          "          common_tls_context:",
          "            tls_params:",
          "              tls_minimum_protocol_version: TLSv1_2",
          "              tls_maximum_protocol_version: TLSv1_3",
          "            validation_context:",
          "              trust_chain_verification: VERIFY_TRUST_CHAIN",
          "              validate_certificate: true",
          "      filters:",
          "      - name: envoy.filters.network.http_connection_manager",
          "        typed_config:",
          '          "@type": type.googleapis.com/envoy.extensions.filters.network.http_connection_manager.v3.HttpConnectionManager',
          "          stat_prefix: ingress_https",
          "          request_timeout: 15s",
          "          route_config:",
          "            name: local_route",
          "            virtual_hosts:",
          "            - name: backend",
          '              domains: ["api.example.com"]',
          "              routes:",
          "              - match:",
          '                  prefix: "/"',
          "                route:",
          "                  cluster: backend_cluster",
          "                  timeout: 10s",
          "  clusters:",
          "  - name: backend_cluster",
          "    connect_timeout: 5s",
          "    type: STRICT_DNS",
          "    dns_lookup_family: V4_ONLY",
          "    load_assignment:",
          "      cluster_name: backend_cluster",
          "      endpoints:",
          "      - lb_endpoints:",
          "        - endpoint:",
          "            address:",
          "              socket_address:",
          "                address: backend.example.com",
          "                port_value: 443",
          "    transport_socket:",
          "      name: envoy.transport_sockets.tls",
          "      typed_config:",
          '        "@type": type.googleapis.com/envoy.extensions.transport_sockets.tls.v3.UpstreamTlsContext',
          "        sni: backend.example.com",
          "        common_tls_context:",
          "          validation_context:",
          "            trust_chain_verification: VERIFY_TRUST_CHAIN",
          "            validate_certificate: true",
          "    health_checks:",
          "    - timeout: 2s",
          "      healthy_threshold: 1",
          "      unhealthy_threshold: 2",
          "      http_health_check:",
          "        path: /healthz",
          "        host: backend.example.com"
        ].join("\n");

        var input = document.getElementById("configInput");
        var verdictBox = document.getElementById("verdictBox");
        var verdictWord = document.getElementById("verdictWord");
        var verdictSub = document.getElementById("verdictSub");
        var countsRow = document.getElementById("countsRow");
        var findingsHead = document.getElementById("findingsHead");
        var findingsList = document.getElementById("findingsList");
        var emptyNote = document.getElementById("emptyNote");
        var copyRow = document.getElementById("copyRow");
        var copyStatus = document.getElementById("copyStatus");
        var lastReport = "";

        function indentOf(line){
          var m = line.match(/^\s*/);
          return m ? m[0].length : 0;
        }
        function isWildcardAddressLine(line){
          return /"?address"?\s*:\s*"?(0\.0\.0\.0|::)"?\s*(,|$|\})/.test(line) ||
                 /"?address"?\s*:\s*"?(0\.0\.0\.0|::)"?\s*$/.test(line);
        }
        function isValueAddressLine(line){
          return /"?address"?\s*:\s*"?[0-9A-Fa-f\.\:]/.test(line);
        }

        function auditConfig(raw){
          var findings = [];
          var seen = {};
          function add(sev, line, title, expl){
            var key = sev + "|" + line + "|" + title;
            if (seen[key]) return;
            seen[key] = true;
            findings.push({sev: sev, line: line, title: title, expl: expl});
          }

          var text = (raw || "").replace(/\r\n?/g, "\n");
          var trimmed = text.trim();
          var lines = text.split("\n");

          if (!trimmed){
            return {verdict: "NOT PARSED", findings: [], lineCount: 0,
              sub: "The input box is empty, so there was nothing to audit. Paste an Envoy config (YAML or JSON) and run the audit again — we never guess at missing input."};
          }

          var jsonOk = false;
          if (trimmed.charAt(0) === "{" || trimmed.charAt(0) === "["){
            try { JSON.parse(trimmed); jsonOk = true; } catch (e) { jsonOk = false; }
          }
          var keyRe = /(admin|listeners|clusters|static_resources|socket_address|filter_chains|transport_socket|typed_config|stats_config|health_check|envoy)/i;
          if (!jsonOk && !keyRe.test(text)){
            return {verdict: "NOT PARSED", findings: [], lineCount: lines.length,
              sub: "This input (" + lines.length + (lines.length === 1 ? " line" : " lines") + ") contains no recognizable Envoy keys — no admin, listeners, clusters, static_resources, or other Envoy sections — and it is not valid JSON either. We never guessed: no findings were invented for input we could not recognize."};
          }

          var i, j;

          /* ---- locate the admin block ---- */
          var adminStart = -1, adminIndent = 0, adminEnd = lines.length;
          for (i = 0; i < lines.length; i++){
            if (/^\s*"?admin"?\s*:/.test(lines[i])){ adminStart = i; adminIndent = indentOf(lines[i]); break; }
          }
          if (adminStart >= 0){
            for (j = adminStart + 1; j < lines.length; j++){
              if (lines[j].trim() === "") continue;
              if (indentOf(lines[j]) <= adminIndent){ adminEnd = j; break; }
            }
          }
          function inAdmin(idx){ return adminStart >= 0 && idx >= adminStart && idx < adminEnd; }

          /* ---- 1. Admin bound to 0.0.0.0 -> BLOCKER ---- */
          var adminBlockerDone = {};
          if (adminStart >= 0){
            for (i = adminStart; i < adminEnd; i++){
              if (isWildcardAddressLine(lines[i])){
                add("BLOCKER", i + 1, "Admin interface bound to 0.0.0.0",
                  "The Envoy admin address sits inside the admin block and is bound to 0.0.0.0, so the admin interface (config dump, stats, log control, drain) answers on every network interface. Bind admin to 127.0.0.1 and reach it through a local shell or tunnel instead.");
                adminBlockerDone[i] = true;
              }
            }
          }
          for (i = 0; i < lines.length; i++){
            if (/admin/i.test(lines[i]) && /0\.0\.0\.0/.test(lines[i]) && !adminBlockerDone[i]){
              add("BLOCKER", i + 1, "Admin interface bound to 0.0.0.0",
                "This line puts the admin interface on 0.0.0.0 — reachable from every network the host touches. Bind admin to 127.0.0.1 instead.");
              adminBlockerDone[i] = true;
            }
          }
          /* Admin port 9901 with a wildcard address nearby */
          for (i = 0; i < lines.length; i++){
            if (/9901/.test(lines[i])){
              for (j = Math.max(0, i - 4); j <= Math.min(lines.length - 1, i + 4); j++){
                if (isWildcardAddressLine(lines[j]) && !adminBlockerDone[j]){
                  var windowHasAdmin = inAdmin(j);
                  if (!windowHasAdmin){
                    for (var k = Math.max(0, i - 4); k <= Math.min(lines.length - 1, i + 4); k++){
                      if (/admin/i.test(lines[k])) { windowHasAdmin = true; break; }
                    }
                  }
                  if (windowHasAdmin){
                    add("BLOCKER", j + 1, "Admin interface bound to 0.0.0.0 (port 9901)",
                      "Port 9901 is Envoy's admin port, and the address beside it is 0.0.0.0. The admin interface must listen on 127.0.0.1 only.");
                    adminBlockerDone[j] = true;
                  }
                }
              }
            }
          }

          /* ---- 4. Wildcard binds outside admin -> HIGH ---- */
          for (i = 0; i < lines.length; i++){
            if (isWildcardAddressLine(lines[i]) && !adminBlockerDone[i] && !inAdmin(i)){
              add("HIGH", i + 1, "Wildcard bind (0.0.0.0 / ::)",
                "This socket_address binds every interface on the host. If this proxy sits on a shared or public network, the port is exposed far beyond its intended audience. Bind a specific interface address, or 127.0.0.1 for local-only services.");
            }
          }

          /* ---- 2. TLS validation disabled -> BLOCKER / old TLS -> HIGH ---- */
          var tlsBad = [
            {re: /validate_certificate"?\s*:\s*"?false/i,
             t: "Certificate validation turned off (validate_certificate: false)",
             e: "With certificate validation off, the proxy accepts certificates it cannot verify — including forged ones — so TLS stops proving who is on the other end. Set validate_certificate to true and configure a trusted CA."},
            {re: /require_certificate_validation"?\s*:\s*"?false/i,
             t: "Certificate validation turned off (require_certificate_validation: false)",
             e: "This setting tells the proxy not to require certificate validation. Turn it back on and provide a trust chain; unverified TLS is encryption without authentication."},
            {re: /trust_chain_verification"?\s*:\s*"?ACCEPT_UNTRUSTED/i,
             t: "Trust chain verification set to ACCEPT_UNTRUSTED",
             e: "ACCEPT_UNTRUSTED means Envoy accepts certificates signed by anyone, or no one. Use VERIFY_TRUST_CHAIN with a real validation context so upstream and client certificates are actually checked."},
            {re: /verification_mode"?\s*:\s*"?insecure/i,
             t: "TLS verification mode set to insecure",
             e: "An insecure verification mode disables the checks that make TLS trustworthy. Remove it and let the proxy verify certificates against a configured trust store."},
            {re: /insecure_skip_verify"?\s*:\s*"?true/i,
             t: "TLS verification skipped (insecure_skip_verify: true)",
             e: "Skipping verification accepts any certificate presented. Turn this off outside a throwaway local test, and never in a deployed config."},
            {re: /\binsecure"?\s*:\s*"?true/i,
             t: "Insecure TLS flag enabled (insecure: true)",
             e: "An explicit insecure flag disables TLS safety checks. Remove it and configure proper certificate validation instead."}
          ];
          for (i = 0; i < lines.length; i++){
            for (j = 0; j < tlsBad.length; j++){
              if (tlsBad[j].re.test(lines[i])){
                add("BLOCKER", i + 1, tlsBad[j].t, tlsBad[j].e);
              }
            }
            if (/(tlsv1_[01]\b|tls\s*v?1\.[01]\b|tlsv1\.[01]\b|\bsslv[23]\b)/i.test(lines[i])){
              add("HIGH", i + 1, "Outdated TLS version (1.0 / 1.1 or SSL)",
                "TLS 1.0 and 1.1 (and all SSL versions) are deprecated and broken in ways that matter. Set the minimum protocol version to TLSv1_2 or higher.");
            }
          }

          /* ---- 3. Plaintext listeners -> HIGH ---- */
          var lsStart = -1, lsIndent = 0, lsEnd = lines.length;
          for (i = 0; i < lines.length; i++){
            if (/^\s*"?listeners"?\s*:/.test(lines[i])){ lsStart = i; lsIndent = indentOf(lines[i]); break; }
          }
          var httpsListener = false;
          if (lsStart >= 0){
            for (j = lsStart + 1; j < lines.length; j++){
              if (lines[j].trim() === "") continue;
              if (lines[j].trim().charAt(0) !== "-" && indentOf(lines[j]) <= lsIndent){ lsEnd = j; break; }
            }
            /* split the listeners section into per-listener chunks */
            var itemIndent = -1;
            for (j = lsStart + 1; j < lsEnd; j++){
              if (lines[j].trim().charAt(0) === "-"){
                var ind = indentOf(lines[j]);
                if (itemIndent < 0 || ind < itemIndent) itemIndent = ind;
              }
            }
            var chunks = [];
            if (itemIndent >= 0){
              var cur = -1;
              for (j = lsStart + 1; j < lsEnd; j++){
                if (lines[j].trim().charAt(0) === "-" && indentOf(lines[j]) === itemIndent){
                  chunks.push({start: j, end: lsEnd});
                  if (cur >= 0) chunks[cur].end = j;
                  cur = chunks.length - 1;
                }
              }
            }
            if (chunks.length === 0) chunks.push({start: lsStart, end: lsEnd});
            for (var c = 0; c < chunks.length; c++){
              var chunkText = lines.slice(chunks[c].start, chunks[c].end).join("\n");
              var hasTls = /transport_socket|DownstreamTlsContext|tls_context/i.test(chunkText);
              if (hasTls) httpsListener = true;
              var addrLine = chunks[c].start;
              for (j = chunks[c].start; j < chunks[c].end; j++){
                if (isValueAddressLine(lines[j])){ addrLine = j; break; }
              }
              if (!hasTls){
                add("HIGH", addrLine + 1, "Plaintext listener (no TLS)",
                  "This listener has no TLS transport socket or tls_context, so it serves traffic in the clear — credentials, headers, and bodies cross the network readable by anyone in the path. Add a DownstreamTlsContext transport socket, or bind the listener to 127.0.0.1 if it is strictly local.");
              }
            }
          }

          /* ---- Wildcard CORS ---- */
          for (i = 0; i < lines.length; i++){
            var corsHit = /allow_origin/i.test(lines[i]) && /\*/.test(lines[i]);
            var prefixHit = /"?prefix"?\s*:\s*"\*"/.test(lines[i]) &&
              (function(){ for (var w = Math.max(0, i - 4); w <= Math.min(lines.length - 1, i + 2); w++){ if (/cors|allow_origin/i.test(lines[w])) return true; } return false; })();
            if (corsHit || prefixHit){
              var creds = false;
              for (j = Math.max(0, i - 8); j <= Math.min(lines.length - 1, i + 8); j++){
                if (/allow_credentials"?\s*:\s*"?true/i.test(lines[j])) creds = true;
              }
              if (creds){
                add("HIGH", i + 1, "Wildcard CORS origin with credentials allowed",
                  "A wildcard allow-origin combined with allow_credentials: true lets any website make credentialed requests through a visitor's browser. Name the specific origins that need access instead.");
              } else {
                add("WARNING", i + 1, "Wildcard CORS origin (*)",
                  "A wildcard CORS origin lets any website call this listener from a browser. If the API is not deliberately public, list the exact origins instead.");
              }
            }
          }

          /* ---- 5. Secrets in plain text -> WARNING (key name + line only) ---- */
          var secretKeyRe = /^\s*-?\s*"?([A-Za-z0-9_\-]*(?:password|passwd|secret|token|api[_-]?key|private[_-]?key|credential)[A-Za-z0-9_\-]*)"?\s*:/i;
          var benignKeys = {"allow_credentials": true};
          for (i = 0; i < lines.length; i++){
            var m = lines[i].match(secretKeyRe);
            if (m && !benignKeys[m[1].toLowerCase()]){
              add("WARNING", i + 1, 'Secret written in the config: "' + m[1] + '"',
                "A key named \"" + m[1] + "\" appears directly in the config text. Only the key name and line are shown here — the value is redacted and is never displayed or copied. Move secrets out of the config into SDS or a secret store, and rotate this one if it was ever real.");
            }
          }

          /* ---- 7. Plain-HTTP URLs (cluster endpoints / service URIs) ---- */
          for (i = 0; i < lines.length; i++){
            if (/http:\/\//i.test(lines[i])){
              add("WARNING", i + 1, "Plain HTTP (non-TLS) endpoint or service URL",
                "This line points at an http:// address, so traffic to that upstream or service crosses the network unencrypted. Use the https:// endpoint and configure the matching upstream TLS context.");
            }
          }

          /* ---- 6. Missing stats / health posture -> WARNING ---- */
          if (!/stats_config|stats_sink/i.test(text) && !/"stats"\s*:/.test(text)){
            add("WARNING", 1, "No stats configuration found",
              "Across all " + lines.length + " lines there is no stats_config or stats sink. Without stats you cannot see connection errors, TLS failures, or upstream health in production. Add a stats_config (even the defaults) so the proxy is observable.");
          }
          if (!/health_check/i.test(text)){
            add("WARNING", 1, "No health checks found",
              "No health_check or health_checks section appears anywhere in this config. Envoy will keep sending traffic to dead upstreams until connections fail. Add active health checks to each cluster.");
          }

          /* ---- Other posture notes ---- */
          if (!/timeout/i.test(text)){
            add("INFO", 1, "No timeouts found",
              "No timeout setting appears anywhere in this config. Explicit connect and request timeouts stop a slow upstream from quietly piling up connections.");
          }
          if (adminStart < 0 && !/admin/i.test(text)){
            add("INFO", 1, "No admin block found",
              "No admin section was found, so the admin interface posture could not be confirmed. Envoy needs an admin address to serve stats and readiness — make sure it is bound to 127.0.0.1.");
          }

          /* ---- Hardened signals + verdict ---- */
          var adminLoopback = false;
          if (adminStart >= 0){
            for (i = adminStart; i < adminEnd; i++){
              if (/127\.0\.0\.1/.test(lines[i])) adminLoopback = true;
            }
          }
          if (!adminLoopback && /admin/i.test(text) && /127\.0\.0\.1/.test(text)) adminLoopback = true;
          var tlsValidationOn = /VERIFY_TRUST_CHAIN/.test(text) || /validate_certificate"?\s*:\s*"?true/i.test(text);
          var signals = (adminLoopback ? 1 : 0) + (tlsValidationOn ? 1 : 0) + (httpsListener ? 1 : 0);

          var counts = {BLOCKER: 0, HIGH: 0, WARNING: 0, INFO: 0};
          findings.forEach(function(f){ counts[f.sev]++; });

          if (counts.BLOCKER === 0 && counts.HIGH === 0 && counts.WARNING === 0 && signals < 2){
            add("WARNING", 1, "Hardened posture could not be confirmed",
              "Nothing dangerous was found, but the config does not show the hardened signals a safe deploy should show — admin on 127.0.0.1, certificate validation on (VERIFY_TRUST_CHAIN), and TLS listeners. Confirm those by hand before treating this as safe.");
            counts.WARNING++;
          }

          var order = {BLOCKER: 0, HIGH: 1, WARNING: 2, INFO: 3};
          findings.sort(function(a, b){
            if (order[a.sev] !== order[b.sev]) return order[a.sev] - order[b.sev];
            return a.line - b.line;
          });

          var verdict, sub;
          if (counts.BLOCKER > 0){
            verdict = "DO NOT DEPLOY";
            sub = counts.BLOCKER + (counts.BLOCKER === 1 ? " blocker" : " blockers") + " found — starting with the admin interface exposure. Fix every blocker, then audit again before this config goes anywhere near production.";
          } else if (counts.HIGH > 0 || counts.WARNING > 0){
            verdict = "DEPLOY WITH FIXES";
            sub = "No blockers, but " + (counts.HIGH + counts.WARNING) + (counts.HIGH + counts.WARNING === 1 ? " finding needs" : " findings need") + " attention first. Work down the list, then re-run the audit to confirm a clean pass.";
          } else {
            verdict = "SAFE TO DEPLOY";
            sub = "No blockers, high findings, or warnings. The hardened signals are present: admin on loopback, certificate validation on, and TLS on the listeners. Still run envoy --mode validate before a real deploy — this audit checks safety posture, not full schema validity.";
          }
          return {verdict: verdict, findings: findings, counts: counts, sub: sub, lineCount: lines.length};
        }

        function esc(s){
          return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
        }

        function render(result){
          copyStatus.textContent = "";
          verdictBox.className = "verdict show " +
            (result.verdict === "DO NOT DEPLOY" ? "v-blocker" :
             result.verdict === "DEPLOY WITH FIXES" ? "v-fixes" :
             result.verdict === "SAFE TO DEPLOY" ? "v-safe" : "v-notparsed");
          verdictWord.textContent = "Verdict: " + result.verdict;
          verdictSub.textContent = result.sub;

          if (result.verdict === "NOT PARSED"){
            countsRow.className = "counts";
            countsRow.innerHTML = "";
            findingsHead.className = "findings-head";
            findingsList.className = "findings";
            findingsList.innerHTML = "";
            emptyNote.className = "empty-note show";
            emptyNote.textContent = "No findings — nothing was invented for input we could not recognize. Paste a real Envoy config, or load one of the examples, and audit again.";
            copyRow.className = "copy-row show";
            lastReport = "J-Dawgs Envoy Proxy Config Safety Auditor\u2122\nVerdict: NOT PARSED\n" + result.sub;
            return;
          }

          var c = result.counts;
          countsRow.className = "counts show";
          countsRow.innerHTML =
            '<span class="count-chip c-blocker">Blockers <b>' + c.BLOCKER + "</b></span>" +
            '<span class="count-chip c-high">High <b>' + c.HIGH + "</b></span>" +
            '<span class="count-chip c-warn">Warnings <b>' + c.WARNING + "</b></span>" +
            '<span class="count-chip c-info">Info <b>' + c.INFO + "</b></span>";

          findingsHead.className = "findings-head show";
          findingsList.className = "findings show";
          if (result.findings.length === 0){
            findingsList.innerHTML = "";
            emptyNote.className = "empty-note show";
            emptyNote.textContent = "No findings at all — the audit came back completely clean.";
          } else {
            emptyNote.className = "empty-note";
            findingsList.innerHTML = result.findings.map(function(f){
              return '<li class="sev-' + f.sev + '">' +
                '<div class="f-top"><span class="f-sev">' + f.sev + '</span>' +
                '<span class="f-line">Line ' + f.line + '</span>' +
                '<span class="f-title">' + esc(f.title) + "</span></div>" +
                '<p class="f-expl">' + esc(f.expl) + "</p></li>";
            }).join("");
          }
          copyRow.className = "copy-row show";

          var out = [];
          out.push("J-Dawgs Envoy Proxy Config Safety Auditor\u2122");
          out.push("Verdict: " + result.verdict);
          out.push("Blockers: " + c.BLOCKER + " | High: " + c.HIGH + " | Warnings: " + c.WARNING + " | Info: " + c.INFO);
          out.push("");
          if (result.findings.length === 0){
            out.push("No findings.");
          } else {
            result.findings.forEach(function(f){
              out.push("Line " + f.line + " — [" + f.sev + "] " + f.title);
              out.push("  " + f.expl);
            });
          }
          out.push("");
          out.push("Note: secret values are never included in these results — findings name the key and line only.");
          lastReport = out.join("\n");
        }

        function runAudit(){
          render(auditConfig(input.value));
        }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-envoy-proxy-config-safety-auditortm',
  name: 'J-Dawgs Envoy Proxy Config Safety Auditor',
  description: 'Envoy\'s own validation needs a running install and stops at load validity; ours grades a pasted Envoy config offline — admin exposure, TLS posture, listener/cluster risk — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
