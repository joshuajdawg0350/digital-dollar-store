'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Grafana Dashboard JSON Consistency Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------------- Built-ins (listed explicitly) ---------------- */
      var BUILTIN_VARS = {
        "__interval": 1, "__interval_ms": 1, "__range": 1, "__range_s": 1, "__range_ms": 1,
        "__from": 1, "__to": 1, "__timeFilter": 1, "__timeFrom": 1, "__timeTo": 1,
        "__unixEpochFrom": 1, "__unixEpochTo": 1, "__unixEpochFilter": 1, "__timezone": 1,
        "__dashboard": 1, "__org": 1, "__user": 1, "__all_variables": 1, "__value": 1, "__name": 1
      };
      /* Grafana's own datasource identifiers — not instance-specific UIDs. */
      var BUILTIN_DS = {
        "grafana": 1, "-- Grafana --": 1, "-- Mixed --": 1, "-- Dashboard --": 1,
        "mixed": 1, "dashboard": 1
      };
      var EXEMPT_TYPES = { "text": 1, "row": 1 };

      /* ---------------- Small helpers ---------------- */
      function isObj(v) { return v !== null && typeof v === "object" && !Array.isArray(v); }
      function isArr(v) { return Object.prototype.toString.call(v) === "[object Array]"; }
      function esc(s) {
        return String(s).replace(/[&<>"']/g, function (c) {
          return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
        });
      }
      function extractVarNames(str, out) {
        if (typeof str !== "string") return out;
        var re = /\$\{([A-Za-z_][A-Za-z0-9_]*)(?::[^}]*)?\}|\$([A-Za-z_][A-Za-z0-9_]*)/g, m;
        while ((m = re.exec(str)) !== null) out.push(m[1] || m[2]);
        return out;
      }
      function collectStrings(node, out) {
        if (typeof node === "string") { out.push(node); return out; }
        if (isArr(node)) { for (var i = 0; i < node.length; i++) collectStrings(node[i], out); return out; }
        if (isObj(node)) { for (var k in node) if (Object.prototype.hasOwnProperty.call(node, k)) collectStrings(node[k], out); return out; }
        return out;
      }
      function varNameFromRef(raw) {
        if (typeof raw !== "string") return null;
        var m = /^\s*\$\{?([A-Za-z_][A-Za-z0-9_]*)\}?\s*$/.exec(raw);
        return m ? m[1] : null;
      }
      /* Normalize any Grafana datasource reference form. */
      function parseDsRef(ds) {
        if (ds === null || ds === undefined || ds === "") return null;
        if (typeof ds === "string") {
          var vn = varNameFromRef(ds);
          if (vn) return { kind: "var", name: vn };
          if (ds.charAt(0) === "$") return { kind: "raw", raw: ds };
          return { kind: "uid", uid: ds, type: null };
        }
        if (isObj(ds)) {
          if (typeof ds.uid === "string" && ds.uid !== "") {
            var vn2 = varNameFromRef(ds.uid);
            if (vn2) return { kind: "var", name: vn2 };
            return { kind: "uid", uid: ds.uid, type: ds.type || null };
          }
          if (typeof ds.type === "string" && ds.type !== "") return { kind: "type", type: ds.type };
        }
        return null;
      }
      function panelLabel(p) {
        var t = (typeof p.title === "string" && p.title.trim() !== "") ? p.title : "(untitled panel)";
        var id = (p.id === null || p.id === undefined) ? "no id" : "id " + p.id;
        return "Panel \u201C" + t + "\u201D (" + id + ")";
      }

      /* ---------------- The audit ---------------- */
      function audit(dash) {
        var findings = [];
        function add(sev, loc, msg, fix) {
          findings.push({ sev: sev, loc: loc, msg: msg, fix: fix || null });
        }

        /* --- Defined variables --- */
        var defined = {};           // name -> variable object
        var varList = [];
        if (isObj(dash.templating) && isArr(dash.templating.list)) varList = dash.templating.list;
        varList.forEach(function (v) {
          if (isObj(v) && typeof v.name === "string" && v.name !== "") defined[v.name] = v;
        });

        /* --- Variable usage map: name -> {loc: true} --- */
        var usage = {};
        function noteUse(name, loc) {
          if (!usage[name]) usage[name] = {};
          usage[name][loc] = true;
        }
        function scanString(str, loc, skipName) {
          var names = extractVarNames(str, []);
          names.forEach(function (n) { if (n !== skipName) noteUse(n, loc); });
        }
        function scanDeep(node, loc, skipName) {
          var strs = collectStrings(node, []);
          strs.forEach(function (s) { scanString(s, loc, skipName); });
        }

        /* --- Flatten panels (rows expanded honestly) --- */
        var allPanels = [];        // {panel, gridChecked}
        var notGridChecked = [];   // labels of panels inside collapsed rows
        function walkPanels(list, insideCollapsedRow) {
          (list || []).forEach(function (p) {
            if (!isObj(p)) return;
            if (p.type === "row" && isArr(p.panels)) {
              allPanels.push({ panel: p, gridChecked: !insideCollapsedRow });
              var collapsed = p.collapsed === true;
              p.panels.forEach(function (sp) {
                if (!isObj(sp)) return;
                allPanels.push({ panel: sp, gridChecked: !collapsed && !insideCollapsedRow });
                if (collapsed || insideCollapsedRow) notGridChecked.push(panelLabel(sp) + " — inside collapsed row \u201C" + (p.title || "row") + "\u201D");
              });
            } else {
              allPanels.push({ panel: p, gridChecked: !insideCollapsedRow });
              if (insideCollapsedRow) notGridChecked.push(panelLabel(p));
            }
          });
        }
        walkPanels(isArr(dash.panels) ? dash.panels : [], false);

        /* --- Datasource reference collection --- */
        var uidRefs = {};          // uid -> [loc,...]  (panels, targets, annotations)
        var panelUids = {};        // uid -> true (panels + targets only)
        var dsTypes = {};          // type -> true
        function recordDsRef(ref, loc, isPanelSide) {
          if (!ref) return;
          if (ref.kind === "var") { noteUse(ref.name, loc); return; }
          if (ref.kind === "uid") {
            if (!uidRefs[ref.uid]) uidRefs[ref.uid] = [];
            uidRefs[ref.uid].push(loc);
            if (isPanelSide) panelUids[ref.uid] = true;
            if (ref.type) dsTypes[ref.type] = true;
            return;
          }
          if (ref.kind === "type") { dsTypes[ref.type] = true; }
        }

        var hasDsVariable = false;
        Object.keys(defined).forEach(function (n) { if (defined[n].type === "datasource") hasDsVariable = true; });
        var hasDefaultDs = (dash.datasource !== null && dash.datasource !== undefined && dash.datasource !== "") || hasDsVariable;

        /* --- Scan variables' own definitions --- */
        var varDsUid = {}; // varName -> uid (hardcoded datasource on a query variable)
        varList.forEach(function (v) {
          if (!isObj(v) || typeof v.name !== "string") return;
          var loc = "Variable $" + v.name;
          if (v.query !== undefined) scanDeep(v.query, loc + " — query", v.name);
          if (v.definition !== undefined) scanDeep(v.definition, loc + " — definition", v.name);
          var ref = parseDsRef(v.datasource);
          if (ref) {
            if (ref.kind === "var") noteUse(ref.name, loc + " — datasource");
            else if (ref.kind === "uid") { varDsUid[v.name] = ref.uid; if (ref.type) dsTypes[ref.type] = true; }
            else if (ref.kind === "type") dsTypes[ref.type] = true;
          }
          if (v.type === "datasource" && typeof v.query === "string" && v.query !== "" && v.query.charAt(0) !== "$") {
            dsTypes[v.query] = true; // datasource variable's query names the plugin type
          }
        });

        /* --- Scan panels --- */
        var idMap = {}; // id -> [labels]
        allPanels.forEach(function (entry) {
          var p = entry.panel;
          var label = panelLabel(p);
          var exempt = !!EXEMPT_TYPES[p.type];

          if (p.id === null || p.id === undefined) {
            add("warning", label, "This panel has no id. Panel ids must be unique across the dashboard; Grafana will assign one when the dashboard is saved, which can surprise anything that links to panels by id.",
              "Give the panel a unique numeric id in the JSON, or let Grafana assign one on first save and re-export.");
          } else {
            if (!idMap[p.id]) idMap[p.id] = [];
            idMap[p.id].push(label);
          }

          if (typeof p.title === "string") scanString(p.title, label + " — title");
          if (typeof p.description === "string") scanString(p.description, label + " — description");
          if (typeof p.repeat === "string" && p.repeat !== "") noteUse(p.repeat.replace(/^\$\{?|\}?$/g, ""), label + " — repeat");
          if (isArr(p.links)) p.links.forEach(function (lk, i) {
            if (isObj(lk) && typeof lk.url === "string") scanString(lk.url, label + " — panel link " + (i + 1));
          });

          if (exempt) {
            add("info", label, "This is a " + p.type + " panel — exempt from target and datasource checks by design" + (p.type === "text" ? "; it renders content, it does not query." : "; it groups other panels, it does not query."));
            return;
          }

          /* targets: variable scan + per-target datasources + presence */
          var targets = isArr(p.targets) ? p.targets : [];
          var anyTargetDs = false;
          targets.forEach(function (t, i) {
            if (!isObj(t)) return;
            scanDeep(t, label + " — target " + (t.refId || String.fromCharCode(65 + i)) + " query");
            var tref = parseDsRef(t.datasource);
            if (tref) { anyTargetDs = true; recordDsRef(tref, label + " — target " + (t.refId || String.fromCharCode(65 + i)) + " datasource", true); }
          });
          if (targets.length === 0) {
            add("warning", label, "Panel queries nothing: it has no targets. On import it renders as an empty panel showing \u201CNo data\u201D.",
              "Add at least one query target, or change the panel type if it is meant to be display-only.");
          }

          /* panel-level datasource */
          var pref = parseDsRef(p.datasource);
          if (pref) {
            recordDsRef(pref, label + " — datasource", true);
          } else if (!anyTargetDs && !hasDefaultDs) {
            add("warning", label, "This panel declares no datasource, none of its targets declare one, and the dashboard defines no default (no dashboard-level datasource and no datasource template variable). Grafana will leave the panel unbound.",
              "Set a datasource on the panel (a UID or a $variable), or add a datasource template variable to act as the dashboard default.");
          }
        });

        /* --- Duplicate ids --- */
        Object.keys(idMap).forEach(function (id) {
          if (idMap[id].length > 1) {
            add("blocker", "Dashboard — panel ids",
              "Duplicate panel id " + id + ": used by " + idMap[id].join(" and ") + ". Grafana panel ids must be unique; duplicates corrupt panel links, repeats, and alert associations.",
              "Renumber one of these panels so every panel id in the dashboard is unique.");
          }
        });

        /* --- Annotations: variable scan + datasource refs --- */
        var annList = (isObj(dash.annotations) && isArr(dash.annotations.list)) ? dash.annotations.list : [];
        annList.forEach(function (a, i) {
          if (!isObj(a)) return;
          var loc = "Annotation \u201C" + (a.name || ("#" + (i + 1))) + "\u201D";
          if (a.query !== undefined) scanDeep(a.query, loc);
          if (a.expr !== undefined) scanDeep(a.expr, loc);
          recordDsRef(parseDsRef(a.datasource), loc + " — datasource", false);
        });

        /* --- Dashboard links (check 5: undefined vars in link URLs) --- */
        if (isArr(dash.links)) {
          dash.links.forEach(function (lk, i) {
            if (!isObj(lk)) return;
            var loc = "Dashboard link \u201C" + (lk.title || ("#" + (i + 1))) + "\u201D";
            if (typeof lk.url === "string") scanString(lk.url, loc);
            if (typeof lk.title === "string") scanString(lk.title, loc);
          });
        }

        /* --- Check 1a: undefined variables (one BLOCKER per variable, all locations) --- */
        Object.keys(usage).forEach(function (name) {
          if (defined[name] || BUILTIN_VARS[name]) return;
          var locs = Object.keys(usage[name]);
          add("blocker", locs.join("; "),
            "Undefined variable $" + name + " is referenced but never defined in templating.list. Grafana leaves the reference literal, so every panel using it queries for the text \u201C$" + name + "\u201D and shows \u201CNo data\u201D.",
            "Define $" + name + " under templating.list (Dashboard settings \u2192 Variables), or replace every reference listed here with a defined variable or a literal value.");
        });

        /* --- Check 1b: dead variables --- */
        Object.keys(defined).forEach(function (name) {
          if (!usage[name] || Object.keys(usage[name]).length === 0) {
            add("info", "Variable $" + name,
              "Defined variable $" + name + " is used nowhere — no panel title, target, repeat, link, annotation, or other variable references it. Dead variable: it adds a dead dropdown to the dashboard header.",
              "Remove $" + name + " from templating.list, or wire it into a panel so it earns its place.");
          }
        });

        /* --- Check 1c: variable datasource UID not used by any panel --- */
        Object.keys(varDsUid).forEach(function (name) {
          var uid = varDsUid[name];
          if (BUILTIN_DS[uid]) return;
          if (!panelUids[uid]) {
            add("warning", "Variable $" + name,
              "Variable $" + name + " runs its query against hardcoded datasource UID \u201C" + uid + "\u201D, which no panel in this dashboard declares or uses. If the variable resolves values from a different datasource than the panels query, the dashboard can look wired up while filtering on the wrong source.",
              "Point $" + name + " at the same datasource the panels use (ideally the same $datasource variable), so variable values and panel queries come from one source.");
          }
        });

        /* --- Check 2a: one-off hardcoded UID = portability risk --- */
        Object.keys(uidRefs).forEach(function (uid) {
          if (BUILTIN_DS[uid]) return;
          if (uidRefs[uid].length === 1) {
            add("warning", uidRefs[uid][0],
              "Hardcoded datasource UID \u201C" + uid + "\u201D appears only here and is not routed through a variable. Instance-specific UID — it will break on a different Grafana instance unless that exact UID exists there. (This auditor cannot see the target instance, so this is a portability risk, not proof the UID is missing.)",
              "Route the reference through a datasource template variable (e.g. $ds) so the dashboard can be re-pointed at import, or confirm the target instance carries this exact UID.");
          }
        });

        /* --- Check 2b: mixed datasource types --- */
        var typeNames = Object.keys(dsTypes);
        if (typeNames.length > 1) {
          add("info", "Dashboard — datasources",
            "Mixed datasource types in one dashboard: " + typeNames.sort().join(", ") + ". That can be deliberate (logs next to metrics), but every panel must point at the type its query language expects.",
            null);
        }

        /* --- Check 3: grid --- */
        var rects = [];
        allPanels.forEach(function (entry) {
          if (!entry.gridChecked) return;
          var p = entry.panel;
          var g = p.gridPos;
          if (!isObj(g)) return;
          if (typeof g.x !== "number" || typeof g.y !== "number" || typeof g.w !== "number" || typeof g.h !== "number") return;
          var label = panelLabel(p);
          if (g.w > 24 || g.x + g.w > 24) {
            add("blocker", label,
              "Invalid grid position: gridPos x=" + g.x + ", w=" + g.w + " puts the panel outside Grafana's 24-column grid (x + w must be \u2264 24; this panel reaches column " + (g.x + g.w) + "). Grafana will clamp or mangle the layout on import.",
              "Shrink or move the panel so x + w \u2264 24.");
          }
          rects.push({ label: label, x: g.x, y: g.y, w: g.w, h: g.h });
        });
        for (var i = 0; i < rects.length; i++) {
          for (var j = i + 1; j < rects.length; j++) {
            var a = rects[i], b = rects[j];
            if (a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h) {
              add("warning", a.label + " \u2194 " + b.label,
                "Panels overlap on the grid: " + a.label + " occupies x" + a.x + "\u2013" + (a.x + a.w) + ", y" + a.y + "\u2013" + (a.y + a.h) + " and " + b.label + " occupies x" + b.x + "\u2013" + (b.x + b.w) + ", y" + b.y + "\u2013" + (b.y + b.h) + ". Grafana resolves overlaps by pushing panels down, so the imported layout will not match this JSON.",
                "Move or resize one of the two panels so their grid rectangles no longer intersect.");
            }
          }
        }
        if (notGridChecked.length > 0) {
          add("info", "Dashboard — grid",
            "NOT GRID-CHECKED: " + notGridChecked.join("; ") + ". Panels inside collapsed rows carry no reliable grid coordinates until the row is expanded, so overlaps and grid bounds were not verified for them.",
            null);
        }

        /* --- Check 4: health basics --- */
        if (typeof dash.title !== "string" || dash.title.trim() === "") {
          add("warning", "Dashboard", "Dashboard title is empty or missing. It imports as an untitled dashboard and is hard to find in search.",
            "Set a dashboard title in the JSON (or in Dashboard settings) before importing.");
        }
        if (dash.uid === null || dash.uid === undefined || dash.uid === "") {
          add("info", "Dashboard", "No dashboard uid. Grafana will assign one on import — fine, unless something already links to this dashboard by uid.",
            null);
        }
        if (dash.schemaVersion === null || dash.schemaVersion === undefined) {
          add("info", "Dashboard", "No schemaVersion. Grafana will migrate the dashboard from a guessed schema on import, which can silently change panel defaults.",
            null);
        }
        if (!isObj(dash.time)) {
          add("info", "Dashboard", "No time range (dashboard \u201Ctime\u201D is absent). Grafana falls back to its default range on import.",
            null);
        }

        /* --- Verdict --- */
        var counts = { blocker: 0, warning: 0, info: 0 };
        findings.forEach(function (f) { counts[f.sev]++; });
        var rank = { blocker: 0, warning: 1, info: 2 };
        findings.sort(function (x, y) { return rank[x.sev] - rank[y.sev]; });
        var verdict = counts.blocker > 0 ? "DO NOT IMPORT YET" : (counts.warning > 0 ? "IMPORT WITH FIXES" : "READY TO IMPORT");
        return {
          verdict: verdict, counts: counts, findings: findings,
          panelCount: allPanels.length, gridCheckedCount: allPanels.length - notGridChecked.length
        };
      }

      /* ---------------- Report text ---------------- */
      function buildReport(res, meta) {
        var lines = [];
        lines.push("J-Dawgs Grafana Dashboard JSON Consistency Auditor\u2122 — audit report");
        lines.push("Dashboard: " + (meta.title || "(untitled)") + (meta.uid ? " (uid: " + meta.uid + ")" : " (no uid)"));
        if (meta.unwrapped) lines.push("Input form: export wrapper — top-level \u201Cdashboard\u201D key was unwrapped before auditing.");
        lines.push("Verdict: " + res.verdict);
        lines.push("Counts: " + res.counts.blocker + " blocker(s), " + res.counts.warning + " warning(s), " + res.counts.info + " info — " +
          res.panelCount + " panel(s) audited, " + res.gridCheckedCount + " grid-checked.");
        lines.push("");
        if (res.findings.length === 0) {
          lines.push("FINDINGS: none. The dashboard JSON is internally consistent on every check this tool runs.");
        } else {
          lines.push("FINDINGS");
          res.findings.forEach(function (f, i) {
            lines.push((i + 1) + ". [" + f.sev.toUpperCase() + "] " + f.loc + " — " + f.msg);
            if (f.fix) lines.push("    Fix: " + f.fix);
          });
        }
        var fixes = res.findings.filter(function (f) { return f.fix && f.sev !== "info"; });
        if (fixes.length > 0) {
          lines.push("");
          lines.push("FIX LIST (in order)");
          fixes.forEach(function (f, i) { lines.push((i + 1) + ". " + f.fix); });
        }
        lines.push("");
        lines.push("Limits: internal consistency only. This audit cannot see the target Grafana instance, cannot know whether a datasource UID exists there, does not run queries, and does not render panels.");
        return lines.join("\n");
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-grafana-dashboard-json-consistency-auditor',
  name: 'J-Dawgs Grafana Dashboard JSON Consistency Auditor',
  description: 'Paste an exported Grafana dashboard JSON and get one import verdict — undefined template variables, duplicate panel ids, invalid/overlapping grid positions, and one-off datasource UID portability risks cross-checked against the dashboard itself. Grafana imports a broken dashboard silently; this pre-',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
