'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Navidrome Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

var RISKY = [
'# Risky example — do not deploy a config like this',
'Address = "0.0.0.0"',
'Port = 4533',
'BaseURL = "http://music.example.com"',
'TLSCert = ""',
'TLSKey = ""',
'PrometheusEnabled = true',
'DevDebug = true',
'LogLevel = "debug"',
'ND_ADMINPASSWORD = "x7k9"',
'# EnablePrometheus = true'
].join('\n');

var HARDENED = [
'# Hardened example',
'Address = "127.0.0.1"',
'Port = 4533',
'BaseURL = "https://music.example.com"',
'TLSCert = "/etc/navidrome/certs/fullchain.pem"',
'TLSKey = "/etc/navidrome/certs/privkey.pem"',
'PrometheusEnabled = false',
'DevDebug = false',
'LogLevel = "info"',
'LoginThrottleMaxAttempts = 5',
'LoginThrottleWindow = "15m"',
'ND_SESSIONSECRET = "k9f2m8x4p7q1w5e3r6t0y2u4i6o8a1s3d5f7g9h2j4"'
].join('\n');

var lastReport = null;

function stripQuotes(v){
  v = (v||'').trim();
  if(v.length>=2 && ((v.charAt(0)==='"' && v.charAt(v.length-1)==='"') || (v.charAt(0)==="'" && v.charAt(v.length-1)==="'"))){ v = v.slice(1,-1); }
  return v.trim();
}
function isTruthy(v){ var s=(v||'').toLowerCase(); return s==='true'||s==='1'||s==='yes'||s==='on'||s==='enabled'; }
function isSecretKey(k){ var s=k.toLowerCase(); return s.indexOf('password')!==-1||s.indexOf('secret')!==-1||s.indexOf('token')!==-1||s.indexOf('apikey')!==-1||s.indexOf('api_key')!==-1||s.indexOf('privatekey')!==-1||s.indexOf('encryptionkey')!==-1||s.indexOf('credential')!==-1; }
function normKey(k){ return k.toUpperCase().replace(/[^A-Z0-9]/g,''); }

function audit(text){
  var lines = (text||'').split('\n');
  var entries = [];
  lines.forEach(function(raw, idx){
    var trimmed = raw.trim();
    if(!trimmed) return;
    var commented = trimmed.charAt(0)==='#';
    var content = commented ? trimmed.slice(1).trim() : trimmed;
    var m = content.match(/^([A-Za-z0-9_.\-]+)\s*=\s*(.*)$/);
    if(!m) return;
    var key = m[1];
    var value = stripQuotes(m[2].replace(/\s+#.*$/,''));
    entries.push({line: idx+1, key:key, norm:normKey(key), value:value, commented:commented, secret:isSecretKey(key)});
  });

  var findings = [];
  function add(line, severity, status, key, title, detail, fix){
    findings.push({line:line, severity:severity, status:status, key:key, title:title, detail:detail, fix:fix});
  }

  if(entries.length===0){
    return {tool:'J-Dawgs Navidrome Server Config Safety Auditor', verdict:'NOT ENOUGH TO GRADE', counts:{CRITICAL:0,HIGH:0,MEDIUM:0,LOW:0,commented:0}, parsedLines:0, findings:[], note:'No config lines (Key = value or ND_* lines) were found. Nothing was graded and no findings were invented.'};
  }

  // TLS state from ACTIVE entries
  var tlsCert=null, tlsKey=null;
  entries.forEach(function(e){
    if(e.commented) return;
    if(e.norm==='TLSCERT'||e.norm==='NDTLSCERT'||e.norm==='NDTLSCERTFILE'||e.norm==='NDTLSCERTIFICATEFILE') tlsCert=e;
    if(e.norm==='TLSKEY'||e.norm==='NDTLSKEY'||e.norm==='NDTLSKEYFILE') tlsKey=e;
  });
  var tlsOn = !!(tlsCert && tlsCert.value) && !!(tlsKey && tlsKey.value);

  var hasThrottle=false;
  entries.forEach(function(e){
    if(e.commented) return;
    var n=e.norm;
    if(n.indexOf('THROTTLE')!==-1||n.indexOf('RATELIMIT')!==-1||n.indexOf('MAXLOGIN')!==-1||n.indexOf('LOGINATTEMPT')!==-1||n.indexOf('FAILEDLOGIN')!==-1) hasThrottle=true;
  });

  entries.forEach(function(e){
    var status = e.commented ? 'COMMENTED / NOT ACTIVE' : 'ACTIVE';
    var n = e.norm;
    var v = e.value;
    var vl = v.toLowerCase();

    // Secret handling first — value NEVER used in output
    if(e.secret){
      if(v && v.charAt(0)!=='$' && v.indexOf('vault:')!==0){
        if(v.length < 12) add(e.line,'CRITICAL',status,e.key,'Very short plaintext secret','Key "'+e.key+'" at line '+e.line+' holds a plaintext secret of only '+v.length+' characters. Length only is reported — the value is never shown.','Move the secret to a proper secrets store or environment injection and use at least 32 random characters.');
        else if(v.length < 20) add(e.line,'HIGH',status,e.key,'Short plaintext secret','Key "'+e.key+'" at line '+e.line+' holds a plaintext secret of '+v.length+' characters. Length only is reported — the value is never shown.','Use at least 32 random characters and keep it out of committed config files.');
        else if(v.length < 32) add(e.line,'MEDIUM',status,e.key,'Plaintext secret under 32 characters','Key "'+e.key+'" at line '+e.line+' holds a plaintext secret of '+v.length+' characters. Length only is reported — the value is never shown.','Use at least 32 random characters.');
      }
      return; // do not run other checks on secret keys
    }

    // Address binding
    if(n==='ADDRESS'||n==='NDADDRESS'){
      if(v==='0.0.0.0'||v==='::'||v==='[::]'||v==='*'||v===''){
        if(!tlsOn) add(e.line,'CRITICAL',status,e.key,'Bound to all interfaces with no TLS','Address at line '+e.line+' listens on every network interface, and no active TLSCert/TLSKey pair is set — logins and streams cross the network unencrypted.','Bind to 127.0.0.1 behind a TLS reverse proxy, or set real TLSCert and TLSKey paths.');
        else add(e.line,'HIGH',status,e.key,'Bound to all interfaces','Address at line '+e.line+' listens on every network interface. TLS is configured, but confirm this exposure is intended and firewalled.','Restrict the bind address or firewall the port if public exposure is not intended.');
      }
      return;
    }
    // TLS empty
    if(n==='TLSCERT'||n==='TLSKEY'||n==='NDTLSCERT'||n==='NDTLSKEY'||n==='NDTLSCERTFILE'||n==='NDTLSKEYFILE'){
      if(!v) add(e.line,'MEDIUM',status,e.key,'TLS setting present but empty','Key "'+e.key+'" at line '+e.line+' is set to an empty value, so TLS is not actually configured on this line.','Set a real certificate/key file path, or remove the line and terminate TLS at a reverse proxy.');
      return;
    }
    // BaseURL
    if(n==='BASEURL'||n==='NDBASEURL'){
      if(vl.indexOf('http://')===0) add(e.line,'HIGH',status,e.key,'BaseURL uses plain HTTP','BaseURL at line '+e.line+' starts with http:// — session cookies and credentials can travel unencrypted.','Use an https:// BaseURL and redirect HTTP to HTTPS.');
      return;
    }
    // Prometheus / metrics
    if(n.indexOf('PROMETHEUS')!==-1 || n.indexOf('ENABLEMETRICS')!==-1 || n==='METRICSENABLED'){
      if(isTruthy(v)) add(e.line,'HIGH',status,e.key,'Prometheus metrics exposed','Metrics are enabled at line '+e.line+'. An exposed metrics endpoint leaks usage, library, and system detail.','Disable metrics, or bind the metrics endpoint to localhost / a private network only.');
      return;
    }
    // Dev / debug
    if(n.indexOf('DEV')!==-1 || n.indexOf('DEBUG')!==-1){
      if(isTruthy(v)) add(e.line,'HIGH',status,e.key,'Dev/debug flag left on','Key "'+e.key+'" at line '+e.line+' is enabled. Debug modes can expose internals and extra endpoints in production.','Set this flag to false for any deployed server.');
      return;
    }
    if(n==='LOGLEVEL'||n==='NDLOGLEVEL'){
      if(vl==='debug'||vl==='trace') add(e.line,'MEDIUM',status,e.key,'Verbose log level','LogLevel at line '+e.line+' is "'+vl+'" — verbose logs can capture sensitive paths and tokens and grow fast.','Use info level in production.');
      return;
    }
  });

  if(!hasThrottle){
    add(null,'MEDIUM','ACTIVE','(missing)','No login-attempt throttling configured','No active key for login throttling / rate limiting / max login attempts was found anywhere in the paste, so credential guessing is unthrottled as far as this config shows.','Add login throttling (for example a max-attempts key) or enforce rate limiting at your reverse proxy.');
  }

  var counts={CRITICAL:0,HIGH:0,MEDIUM:0,LOW:0,commented:0};
  findings.forEach(function(f){
    if(f.status.indexOf('COMMENTED')===0){ counts.commented++; }
    else counts[f.severity]++;
  });

  var verdict;
  if(counts.CRITICAL>0 || counts.HIGH>=2) verdict='DO NOT DEPLOY';
  else if(counts.HIGH>0 || counts.MEDIUM>0 || counts.LOW>0) verdict='DEPLOY WITH FIXES';
  else verdict='SAFE TO DEPLOY';

  var order={CRITICAL:0,HIGH:1,MEDIUM:2,LOW:3};
  findings.sort(function(a,b){
    var ca=a.status.indexOf('COMMENTED')===0?1:0, cb=b.status.indexOf('COMMENTED')===0?1:0;
    if(ca!==cb) return ca-cb;
    if(order[a.severity]!==order[b.severity]) return order[a.severity]-order[b.severity];
    return (a.line||9999)-(b.line||9999);
  });

  return {tool:'J-Dawgs Navidrome Server Config Safety Auditor', verdict:verdict, counts:counts, parsedLines:entries.length, findings:findings, note:'Secrets are reported by key name, line, and length only. No secret value is included anywhere in this report.'};
}

function esc(s){ return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }

function reportText(r){
  var out=[];
  out.push('J-Dawgs Navidrome Server Config Safety Auditor — Report');
  out.push('Verdict: '+r.verdict);
  out.push('Parsed config lines: '+r.parsedLines);
  out.push('Active counts — CRITICAL: '+r.counts.CRITICAL+', HIGH: '+r.counts.HIGH+', MEDIUM: '+r.counts.MEDIUM+', LOW: '+r.counts.LOW+'; Commented (not active): '+r.counts.commented);
  out.push('');
  if(r.findings.length===0){ out.push('Findings: none.'); }
  else{
    out.push('Findings:');
    r.findings.forEach(function(f){
      out.push('- ['+f.severity+'] '+(f.line?('Line '+f.line):'Missing (no line)')+' · '+f.status+' · '+f.key+' — '+f.title);
      out.push('  '+f.detail);
      out.push('  Fix: '+f.fix);
    });
  }
  out.push('');
  out.push(r.note);
  return out.join('\n');
}
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-navidrome-server-config-safety-auditortm',
  name: 'J-Dawgs Navidrome Server Config Safety Auditor',
  description: 'Host tools only tell you the server started; ours grades a pasted Navidrome toml/ND_* env config offline into one deploy verdict — all-interface bind without TLS, http BaseURL, exposed metrics, dev flags, login throttling, and short secrets.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
