'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Tomcat Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var RISKY = [
          '<?xml version="1.0" encoding="UTF-8"?>',
          '<!-- Risky worked example: several findings are deliberate. -->',
          '<Server port="8005" shutdown="SHUTDOWN">',
          '  <Service name="Catalina">',
          '    <Connector port="8080" protocol="HTTP/1.1"',
          '               connectionTimeout="20000" />',
          '    <Connector port="8443" protocol="org.apache.coyote.http11.Http11NioProtocol"',
          '               SSLEnabled="true" scheme="https" secure="true">',
          '      <SSLHostConfig protocols="TLSv1,TLSv1.1,TLSv1.2">',
          '        <Certificate certificateKeystoreFile="conf/localhost-rsa.jks"',
          '                     certificateKeystorePassword="changeit" />',
          '      </SSLHostConfig>',
          '    </Connector>',
          '    <Connector port="8009" protocol="AJP/1.3" redirectPort="8443" />',
          '    <Engine name="Catalina" defaultHost="localhost">',
          '      <Host name="localhost" appBase="webapps"',
          '            unpackWARs="true" autoDeploy="true">',
          '        <Context path="/manager" docBase="manager" />',
          '      </Host>',
          '    </Engine>',
          '  </Service>',
          '</Server>'
        ].join("\n");

        var HARDENED = [
          '<?xml version="1.0" encoding="UTF-8"?>',
          '<!-- Hardened worked example: expected verdict SAFE TO DEPLOY. -->',
          '<Server port="-1">',
          '  <Service name="Catalina">',
          '    <Connector port="8080" protocol="HTTP/1.1"',
          '               connectionTimeout="20000" redirectPort="8443" />',
          '    <Connector port="8443" protocol="org.apache.coyote.http11.Http11NioProtocol"',
          '               SSLEnabled="true" scheme="https" secure="true">',
          '      <SSLHostConfig protocols="TLSv1.2,TLSv1.3">',
          '        <Certificate certificateKeystoreFile="conf/keystore.p12"',
          '                     type="PKCS12" />',
          '      </SSLHostConfig>',
          '    </Connector>',
          '    <!-- AJP connector intentionally not configured. -->',
          '    <Engine name="Catalina" defaultHost="localhost">',
          '      <Host name="localhost" appBase="webapps"',
          '            unpackWARs="true" autoDeploy="false" deployOnStartup="true">',
          '        <Context path="/manager" docBase="manager">',
          '          <Valve className="org.apache.catalina.valves.RemoteAddrValve"',
          '                 allow="127\\.0\\.0\\.1" />',
          '        </Context>',
          '        <Valve className="org.apache.catalina.valves.AccessLogValve"',
          '               directory="logs" prefix="localhost_access_log" suffix=".txt"',
          '               pattern="%h %l %u %t %r %s %b" />',
          '      </Host>',
          '    </Engine>',
          '  </Service>',
          '</Server>'
        ].join("\n");

        var DEFAULT_SECRET_VALUES = {
          "": true, "changeit": true, "tomcat": true, "admin": true,
          "password": true, "passwd": true, "secret": true, "s3cret": true,
          "letmein": true, "123456": true, "12345": true, "changeme": true,
          "change-me": true, "default": true, "keystore": true,
          "catalina": true, "manager": true, "root": true, "qwerty": true,
          "passw0rd": true, "yourpassword": true, "your-password": true,
          "insert-password": true, "todo": true, "xxx": true, "*****": true
        };
        var SECRET_NAME_RE = /(password|passwd|pwd|secret|passphrase)/i;
        var WEAK_PROTOCOLS = { "sslv3": "SSLv3", "tlsv1": "TLSv1", "tlsv1.1": "TLSv1.1" };

        function lineAt(text, idx) {
          var n = 1, i;
          for (i = 0; i < idx && i < text.length; i++) { if (text.charCodeAt(i) === 10) n++; }
          return n;
        }

        function maskMarkup(text) {
          function blank(m) { return m.replace(/[^\n]/g, " "); }
          var t = text.replace(/<!--[\s\S]*?-->/g, blank);
          t = t.replace(/<!\[CDATA\[[\s\S]*?\]\]>/g, blank);
          t = t.replace(/<\?[\s\S]*?\?>/g, blank);
          t = t.replace(/<![A-Za-z][^>]*>/g, blank);
          return t;
        }

        function parseAttrs(attrText) {
          var attrs = {}, order = [];
          var re = /([A-Za-z_][\w.:-]*)\s*=\s*(?:"([^"]*)"|'([^']*)')/g, m;
          while ((m = re.exec(attrText)) !== null) {
            var name = m[1];
            attrs[name] = (m[2] !== undefined) ? m[2] : m[3];
            order.push({ name: name, index: m.index });
          }
          return { map: attrs, order: order };
        }

        function attrCI(attrs, name) {
          var want = name.toLowerCase();
          for (var k in attrs) { if (k.toLowerCase() === want) return attrs[k]; }
          return undefined;
        }
        function hasAttrCI(attrs, name) { return attrCI(attrs, name) !== undefined; }

        function weakProtocolsIn(value) {
          if (!value) return [];
          var parts = String(value).split(/[+,\s]+/), found = [], seen = {};
          for (var i = 0; i < parts.length; i++) {
            var p = parts[i].replace(/^[+-]+/, "").trim().toLowerCase();
            if (WEAK_PROTOCOLS[p] && !seen[p]) { seen[p] = true; found.push(WEAK_PROTOCOLS[p]); }
          }
          return found;
        }

        function looksDefaultSecret(value) {
          if (value === undefined || value === null) return false;
          var v = String(value).trim().toLowerCase();
          if (DEFAULT_SECRET_VALUES[v]) return true;
          if (/^(change|your|insert|replace|enter)[-_ ]/.test(v)) return true;
          if (/^<[^>]*>$/.test(v)) return true;
          return false;
        }

        function audit(raw) {
          var findings = [];
          function add(sev, line, title, detail, fix) {
            findings.push({ sev: sev, line: line, title: title, detail: detail, fix: fix });
          }

          var text = maskMarkup(raw);
          var totalLines = raw.split("\n").length;

          var tagRe = /<(\/?)([A-Za-z][\w.:-]*)((?:[^<>"']|"[^"]*"|'[^']*')*?)(\/?)>/g;
          var stack = [];
          var elements = [];
          var parseError = null;
          var m;

          function finalize(el) {
            if (el.name === "sslhostconfig" && !el.hasCert) {
              add("WARNING", el.line,
                "SSLHostConfig has no Certificate configured",
                "An SSLHostConfig element opens at this line but contains no <Certificate> element, so Tomcat has no key/certificate to present for TLS on this host config.",
                "Add a <Certificate> element inside the SSLHostConfig pointing at your keystore or PEM key and certificate files.");
            }
            if (el.isManagerCtx && !el.hasAddrValve) {
              add("WARNING", el.line,
                "Manager-style context has no access restriction",
                "A Manager-style context is configured with no RemoteAddrValve or RemoteHostValve inside it, so the manager app is reachable from any address that can reach the connector.",
                "Add a RemoteAddrValve inside the context with an allow list limited to admin addresses (for example localhost or a management network).");
            }
          }

          while ((m = tagRe.exec(text)) !== null) {
            var closing = m[1] === "/";
            var rawName = m[2];
            var name = rawName.toLowerCase();
            var attrText = m[3] || "";
            var selfClosing = m[4] === "/" || /\/\s*$/.test(attrText);
            var line = lineAt(text, m.index);
            var parsed = parseAttrs(attrText);
            var i, j;

            if (closing) {
              if (!stack.length || stack[stack.length - 1].name !== name) {
                parseError = { line: line, msg: "Closing tag </" + rawName + "> at line " + line + " does not match the element that is open (" + (stack.length ? "<" + stack[stack.length - 1].rawName + "> opened at line " + stack[stack.length - 1].line : "nothing is open") + ")." };
                break;
              }
              finalize(stack.pop());
              continue;
            }

            var el = {
              name: name, rawName: rawName, attrs: parsed.map, attrOrder: parsed.order,
              tagText: m[0], line: line, hasCert: false, hasAddrValve: false,
              isManagerCtx: false
            };
            elements.push(el);

            if (name === "certificate") {
              for (i = 0; i < stack.length; i++) { if (stack[i].name === "sslhostconfig") stack[i].hasCert = true; }
            }
            if (name === "valve") {
              var cn = attrCI(el.attrs, "className") || "";
              if (/RemoteAddrValve|RemoteHostValve/i.test(cn)) {
                for (i = 0; i < stack.length; i++) { if (stack[i].name === "context") stack[i].hasAddrValve = true; }
              }
            }
            if (name === "context") {
              var path = attrCI(el.attrs, "path") || "";
              var docBase = attrCI(el.attrs, "docBase") || "";
              if (/manager/i.test(path) || /manager/i.test(docBase)) el.isManagerCtx = true;
            }

            // Generic secret scan: flag by attribute NAME and LINE only.
            for (j = 0; j < el.attrOrder.length; j++) {
              var an = el.attrOrder[j].name;
              if (an.toLowerCase() === "secretrequired") continue;
              if (!SECRET_NAME_RE.test(an)) continue;
              var av = el.attrs[an];
              if (looksDefaultSecret(av)) {
                var attrLine = line + (el.tagText.slice(0, el.tagText.indexOf(an)).split("\n").length - 1);
                add("HIGH", attrLine,
                  "Default or unchanged-looking secret value",
                  "The attribute '" + an + "' on <" + rawName + "> appears to hold a default or unchanged placeholder value. The value is never shown in this audit.",
                  "Replace the value held by '" + an + "' with a strong, unique secret, ideally injected from the environment or a secrets vault rather than stored in the file.");
              }
            }

            if (selfClosing) { finalize(el); }
            else { stack.push(el); }
          }

          if (!parseError && stack.length) {
            var top = stack[stack.length - 1];
            parseError = { line: top.line, msg: "Element <" + top.rawName + "> opened at line " + top.line + " is never closed." };
          }

          var hasServer = false, hasAccessLog = false, hasRemoteAddrAnywhere = false;
          var hasHttps = false, i2;
          var confidentialDeclared = /CONFIDENTIAL/i.test(text);
          var managerMentioned = /manager/i.test(raw);
          var managerCtxSeen = false;

          for (i2 = 0; i2 < elements.length; i2++) {
            var e = elements[i2];
            if (e.name === "server") hasServer = true;
            if (e.name === "valve") {
              var c2 = attrCI(e.attrs, "className") || "";
              if (/AccessLogValve/i.test(c2)) hasAccessLog = true;
              if (/RemoteAddrValve|RemoteHostValve/i.test(c2)) hasRemoteAddrAnywhere = true;
            }
            if (e.isManagerCtx) managerCtxSeen = true;
            if (e.name === "connector") {
              var proto0 = attrCI(e.attrs, "protocol") || "";
              var ssl0 = (attrCI(e.attrs, "SSLEnabled") || "").toLowerCase() === "true";
              var scheme0 = (attrCI(e.attrs, "scheme") || "").toLowerCase();
              if (!/ajp/i.test(proto0) && (ssl0 || scheme0 === "https")) hasHttps = true;
            }
          }

          if (!parseError && !hasServer) {
            parseError = { line: 1, msg: "No <Server> root element was found, so this does not look like a Tomcat server.xml. The auditor will not guess at it." };
          }

          if (parseError) {
            return {
              verdict: "NOT PARSED", totalLines: totalLines,
              findings: [{ sev: "BLOCKER", line: parseError.line, title: "Malformed or unbalanced XML",
                detail: parseError.msg + " Fix the XML structure first, then re-run the audit — no other checks were run against a config that does not parse.",
                fix: "Correct the tag structure at the line shown and re-paste the config." }]
            };
          }

          var httpsConnectorNeedsSslNote = {};

          for (i2 = 0; i2 < elements.length; i2++) {
            var el2 = elements[i2];
            var at = el2.attrs;

            if (el2.name === "server") {
              var port = attrCI(at, "port");
              var shutdownAttr = attrCI(at, "shutdown");
              if (port !== undefined && String(port).trim() !== "-1") {
                if (shutdownAttr === undefined || String(shutdownAttr).trim().toUpperCase() === "SHUTDOWN") {
                  add("HIGH", el2.line,
                    "Shutdown port enabled with the default shutdown command",
                    "The <Server> element listens on shutdown port " + String(port).trim() + " and its 'shutdown' attribute still holds Tomcat's well-known default command word (the value is never printed here). Anyone who can reach that port can stop Tomcat with one plain-text message.",
                    "Set port=\"-1\" on <Server> to disable the shutdown port entirely, or set the 'shutdown' attribute to a long, non-default value and restrict the port at the firewall.");
                } else {
                  add("INFO", el2.line,
                    "Shutdown port is enabled",
                    "The <Server> element listens on a shutdown port with a non-default command word (value not shown). Make sure the port is not reachable from untrusted networks.",
                    "Prefer port=\"-1\" to disable the shutdown port unless local shutdown scripts depend on it.");
                }
              }
            }

            if (el2.name === "connector") {
              var proto = attrCI(at, "protocol") || "HTTP/1.1";
              var cport = attrCI(at, "port") || "(unspecified)";
              var isAjp = /ajp/i.test(proto);
              var sslOn = (attrCI(at, "SSLEnabled") || "").toLowerCase() === "true";
              var scheme = (attrCI(at, "scheme") || "").toLowerCase();
              var isHttps = !isAjp && (sslOn || scheme === "https");

              if (isAjp) {
                var sr = attrCI(at, "secretRequired");
                var secret = attrCI(at, "requiredSecret");
                var hasSecret = secret !== undefined && String(secret).trim() !== "";
                var srTrue = sr !== undefined && String(sr).trim().toLowerCase() === "true";
                if (!hasSecret) {
                  add("BLOCKER", el2.line,
                    "AJP connector enabled without a required secret (Ghostcat-class risk)",
                    "The AJP connector on port " + cport + " sets no requiredSecret. Anyone who can reach the AJP port can read web-application files and, in some setups, reach remote code execution — the CVE-2020-1938 (Ghostcat) pattern.",
                    "Set secretRequired=\"true\" and a long, random requiredSecret on the AJP connector and bind it to a trusted address — or remove / comment out the AJP connector if AJP is not used.");
                } else if (!srTrue) {
                  add("BLOCKER", el2.line,
                    "AJP connector does not require its secret (Ghostcat-class risk)",
                    "The AJP connector on port " + cport + " has a requiredSecret set, but secretRequired is not \"true\", so the secret is not enforced on connections — the Ghostcat-class exposure stays open.",
                    "Set secretRequired=\"true\" on the AJP connector so every AJP connection must present the secret.");
                } else if (!hasAttrCI(at, "address")) {
                  add("WARNING", el2.line,
                    "AJP connector is not bound to a specific address",
                    "The AJP connector on port " + cport + " requires a secret, but sets no address attribute, so it listens on all interfaces.",
                    "Add an address attribute binding AJP to localhost or the specific front-end server address that should use it.");
                }
              } else if (isHttps) {
                var weakC = weakProtocolsIn(attrCI(at, "sslProtocol") || attrCI(at, "protocols"));
                if (weakC.length) {
                  add("HIGH", el2.line,
                    "Weak TLS protocols enabled on the HTTPS connector",
                    "This HTTPS connector enables weak protocol versions: " + weakC.join(", ") + ". TLSv1 and TLSv1.1 are deprecated and SSLv3 is broken (POODLE).",
                    "Restrict the connector / SSLHostConfig protocols to TLSv1.2 and TLSv1.3 only.");
                }
                httpsConnectorNeedsSslNote[el2.line] = el2;
              } else {
                // Plaintext HTTP connector
                var redirectPort = attrCI(at, "redirectPort");
                if (confidentialDeclared && !redirectPort) {
                  add("HIGH", el2.line,
                    "Plaintext HTTP connector under a CONFIDENTIAL transport guarantee",
                    "The pasted config declares a CONFIDENTIAL transport guarantee (HTTPS-only traffic), but the HTTP connector on port " + cport + " has no redirectPort, so plaintext requests are not forced onto HTTPS.",
                    "Add redirectPort set to your HTTPS connector port (for example 8443) on this HTTP connector, or remove the HTTP connector.");
                } else if (hasHttps && !redirectPort) {
                  add("HIGH", el2.line,
                    "Plaintext HTTP connector does not redirect to HTTPS",
                    "An HTTPS connector is configured, but the HTTP connector on port " + cport + " has no redirectPort, so clients can keep talking plaintext HTTP and are never pushed onto TLS.",
                    "Add redirectPort set to your HTTPS connector port (for example 8443) on this HTTP connector, or remove the HTTP connector if HTTP is not needed.");
                } else if (!hasHttps) {
                  add("HIGH", el2.line,
                    "Application is served over plaintext HTTP only",
                    "This config has an HTTP connector on port " + cport + " and no HTTPS connector at all, so application traffic — logins, session cookies, data — crosses the network unencrypted.",
                    "Add an HTTPS connector with a valid certificate and redirect HTTP to it via redirectPort.");
                }
              }
            }

            if (el2.name === "sslhostconfig") {
              var weakS = weakProtocolsIn(attrCI(at, "protocols"));
              if (weakS.length) {
                add("HIGH", el2.line,
                  "Weak TLS protocols enabled in SSLHostConfig",
                  "This SSLHostConfig enables weak protocol versions: " + weakS.join(", ") + ". TLSv1 and TLSv1.1 are deprecated and SSLv3 is broken (POODLE).",
                  "Set protocols=\"TLSv1.2,TLSv1.3\" on the SSLHostConfig and remove the weak versions.");
              }
            }

            if (el2.name === "host") {
              var ad = attrCI(at, "autoDeploy");
              if (ad !== undefined && String(ad).trim().toLowerCase() === "true") {
                add("WARNING", el2.line,
                  "autoDeploy is on for this Host",
                  "With autoDeploy=\"true\", any WAR or directory dropped into the appBase is deployed automatically — convenient in development, risky in production if the directory is writable by anything else.",
                  "Set autoDeploy=\"false\" on the Host for production and deploy through your controlled release process.");
              }
              var ds = attrCI(at, "deployOnStartup");
              if (ds !== undefined && String(ds).trim().toLowerCase() === "false") {
                add("INFO", el2.line,
                  "deployOnStartup is off for this Host",
                  "Applications under this Host will not deploy when Tomcat starts; they deploy only when triggered. That is a valid posture — just confirm your start scripts and runbooks expect it.",
                  "No change needed if on-demand deployment is intentional; otherwise set deployOnStartup=\"true\".");
              }
              var uw = attrCI(at, "unpackWARs");
              if (uw !== undefined) {
                if (String(uw).trim().toLowerCase() === "true") {
                  add("INFO", el2.line,
                    "unpackWARs posture: WARs are unpacked on deploy",
                    "unpackWARs=\"true\" is the common default: WARs are expanded into directories under the appBase. It is fine in most setups — just keep the appBase directory permissions tight, because the unpacked files are what actually runs.",
                    "No change required for most deployments; keep OS permissions on the appBase restrictive.");
                } else {
                  add("INFO", el2.line,
                    "unpackWARs posture: WARs run packed",
                    "unpackWARs=\"false\" runs applications directly from the WAR file. That can slow first access and breaks apps that expect a real directory on disk.",
                    "No change required if the apps are known to run packed; otherwise set unpackWARs=\"true\".");
                }
              }
            }
          }

          // HTTPS connector with no SSLHostConfig anywhere near it.
          var anySslHostConfig = false, anyCertAnywhere = false, i3;
          for (i3 = 0; i3 < elements.length; i3++) {
            if (elements[i3].name === "sslhostconfig") anySslHostConfig = true;
            if (elements[i3].name === "certificate") anyCertAnywhere = true;
          }
          if (hasHttps && !anySslHostConfig && !anyCertAnywhere) {
            for (var ln in httpsConnectorNeedsSslNote) {
              add("WARNING", parseInt(ln, 10),
                "HTTPS connector has no certificate configuration",
                "This connector is marked as HTTPS, but the pasted config contains no SSLHostConfig and no Certificate element, so there is no certificate for Tomcat to serve.",
                "Add an SSLHostConfig with a Certificate element (keystore or PEM files) inside the HTTPS connector.");
            }
          }

          if (managerMentioned && !managerCtxSeen && !hasRemoteAddrAnywhere) {
            add("INFO", 0,
              "Manager app mentioned, no access restriction found",
              "The pasted text mentions a Manager-style app, but no RemoteAddrValve or RemoteHostValve appears anywhere in it, and no Manager context element was found to check directly.",
              "If the Manager app is deployed, restrict it with a RemoteAddrValve allow list and strong, non-default credentials.");
          }

          if (!hasAccessLog) {
            add("INFO", 0,
              "No AccessLogValve configured",
              "No AccessLogValve appears in the pasted config, so Tomcat will not write an HTTP access log for this setup — the first thing you want when investigating an incident.",
              "Add an AccessLogValve to the Host (className org.apache.catalina.valves.AccessLogValve) with your preferred directory and pattern.");
          }

          var rank = { BLOCKER: 0, HIGH: 1, WARNING: 2, INFO: 3 };
          findings.sort(function (a, b) {
            if (rank[a.sev] !== rank[b.sev]) return rank[a.sev] - rank[b.sev];
            return (a.line || 0) - (b.line || 0);
          });

          var counts = { BLOCKER: 0, HIGH: 0, WARNING: 0, INFO: 0 };
          for (i3 = 0; i3 < findings.length; i3++) counts[findings[i3].sev]++;

          var verdict;
          if (counts.BLOCKER > 0) verdict = "DO NOT DEPLOY";
          else if (counts.HIGH > 0 || counts.WARNING > 0) verdict = "DEPLOY WITH FIXES";
          else verdict = "SAFE TO DEPLOY";

          return { verdict: verdict, totalLines: totalLines, findings: findings, counts: counts };
        }

        function buildReport(result) {
          var lines = [];
          lines.push("J-Dawgs Tomcat Server Config Safety Auditor — Audit Report");
          lines.push("Verdict: " + result.verdict);
          lines.push("Lines scanned: " + result.totalLines);
          if (result.counts) {
            lines.push("Counts: Blockers " + result.counts.BLOCKER + " · High " + result.counts.HIGH + " · Warnings " + result.counts.WARNING + " · Info " + result.counts.INFO);
          }
          lines.push("");
          if (!result.findings.length) {
            lines.push("Findings: none. No issues matched the audit checks in the pasted config.");
          } else {
            lines.push("Findings:");
            for (var i = 0; i < result.findings.length; i++) {
              var f = result.findings[i];
              lines.push("");
              lines.push((i + 1) + ". [" + f.sev + "] " + (f.line ? "Line " + f.line : "File-wide") + " — " + f.title);
              lines.push("   " + f.detail);
              lines.push("   Fix: " + f.fix);
            }
          }
          lines.push("");
          lines.push("Notes: heuristic text audit of pasted XML — not a real XML/DTD validator. Secret values are never shown; findings name the attribute and line only. Nothing was uploaded or saved; the audit ran entirely in the browser.");
          return lines.join("\n");
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-tomcat-server-config-safety-auditor',
  name: 'J-Dawgs Tomcat Server Config Safety Auditor',
  description: 'Tomcat will happily start on a dangerous server.xml and tell you nothing; ours audits a pasted Tomcat server.xml offline — an AJP connector without a secret graded BLOCKER, plaintext connectors, shutdown-port exposure — into one deploy verdict, secrets flagged by key name only and never rendered.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
