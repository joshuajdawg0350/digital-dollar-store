'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs MongoDB Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

    /*CORE-START*/
    var EXAMPLE_RISKY = [
      "# Risky mongod.conf — the worked example. Do not deploy as-is.",
      "systemLog:",
      "  destination: file",
      "  path: /var/log/mongodb/mongod.log",
      "storage:",
      "  dbPath: /var/lib/mongo",
      "net:",
      "  port: 27017",
      "  bindIp: 0.0.0.0",
      "  tls:",
      "    mode: disabled",
      "security:",
      "  authorization: disabled",
      "  # transitionToAuth: true",
      "operationProfiling:",
      "  mode: all"
    ].join("\n");

    var EXAMPLE_HARDENED = [
      "# Hardened mongod.conf — the worked example.",
      "systemLog:",
      "  destination: file",
      "  path: /var/log/mongodb/mongod.log",
      "  logAppend: true",
      "  verbosity: 0",
      "storage:",
      "  dbPath: /var/lib/mongo",
      "  wiredTiger:",
      "    engineConfig:",
      "      cacheSizeGB: 4",
      "net:",
      "  port: 27017",
      "  bindIp: 127.0.0.1,10.0.0.15",
      "  tls:",
      "    mode: requireTLS",
      "    certificateKeyFile: /etc/mongodb/mongod.pem",
      "security:",
      "  authorization: enabled",
      "  transitionToAuth: false",
      "operationProfiling:",
      "  mode: slowOp",
      "  slowOpThresholdMs: 100",
      "setParameter:",
      "  authenticationMechanisms: SCRAM-SHA-256",
      "replication:",
      "  replSetName: rs0"
    ].join("\n");

    var KNOWN_TOP = {
      "systemLog": 1, "storage": 1, "processManagement": 1, "net": 1, "security": 1,
      "setParameter": 1, "operationProfiling": 1, "replication": 1, "sharding": 1,
      "auditLog": 1, "snmp": 1, "cloud": 1
    };
    var WATCHED_COMMENT_KEYS = {
      "authorization": 1, "bindip": 1, "bindipall": 1, "transitiontoauth": 1, "keyfile": 1,
      "replsetname": 1, "verbosity": 1, "mode": 1, "tls": 1, "ssl": 1, "cachesizegb": 1,
      "authenticationmechanisms": 1, "port": 1, "destination": 1, "certificatekeyfile": 1,
      "clusterpassword": 1, "password": 1
    };

    function isSecretKey(leaf) {
      return /password|passwd|pwd|secret|token|apikey|api_key|privatekey/i.test(leaf);
    }
    function leafOf(path) {
      var i = path.lastIndexOf(".");
      return i < 0 ? path : path.slice(i + 1);
    }
    function stripQuotes(v) {
      v = v.replace(/^\s+|\s+$/g, "");
      if (v.length >= 2 && ((v.charAt(0) === '"' && v.charAt(v.length - 1) === '"') || (v.charAt(0) === "'" && v.charAt(v.length - 1) === "'"))) {
        return v.slice(1, -1);
      }
      return v;
    }
    function cleanValue(v) {
      v = v.replace(/^\s+/, "");
      if (v.charAt(0) === '"' || v.charAt(0) === "'") {
        var q = v.charAt(0);
        var end = v.indexOf(q, 1);
        if (end > 0) return stripQuotes(v.slice(0, end + 1));
        return stripQuotes(v);
      }
      var hash = v.indexOf(" #");
      if (hash >= 0) v = v.slice(0, hash);
      return stripQuotes(v.replace(/\s+$/, ""));
    }

    function parseConfig(text) {
      var rawLines = String(text == null ? "" : text).split(/\r?\n/);
      var entries = [];
      var byPath = {};
      var dupSeen = {};
      var duplicates = [];
      var comments = [];
      var topLevel = [];
      var stack = [];
      var blockIndent = -1;
      for (var i = 0; i < rawLines.length; i++) {
        var lineNo = i + 1;
        var raw = rawLines[i].replace(/\t/g, "  ");
        var noLead = raw.replace(/^\s+/, "");
        var indent = raw.length - noLead.length;
        if (noLead === "") { continue; }
        if (noLead.charAt(0) === "#") {
          var cm = noLead.match(/^#\s*([A-Za-z][\w-]*)\s*:/);
          if (cm && WATCHED_COMMENT_KEYS[cm[1].toLowerCase()]) {
            comments.push({ line: lineNo, key: cm[1] });
          }
          continue;
        }
        if (blockIndent >= 0) {
          if (indent > blockIndent) { continue; }
          blockIndent = -1;
        }
        if (noLead.indexOf("- ") === 0 || noLead === "-") { continue; }
        var m = noLead.match(/^([^:]+?):(?:\s+(.*))?$/);
        if (!m) { continue; }
        var key = stripQuotes(m[1].replace(/\s+$/, ""));
        var rawVal = (m[2] == null ? "" : m[2]);
        var value = rawVal === "" ? "" : cleanValue(rawVal);
        while (stack.length && stack[stack.length - 1].indent >= indent) { stack.pop(); }
        var parentPath = stack.length ? stack[stack.length - 1].path : "";
        var fullPath = parentPath ? parentPath + "." + key : key;
        if (indent === 0) { topLevel.push({ key: key, line: lineNo }); }
        var dupKey = parentPath + "|" + key;
        if (dupSeen[dupKey] != null) {
          duplicates.push({ path: fullPath, firstLine: dupSeen[dupKey], line: lineNo });
        } else {
          dupSeen[dupKey] = lineNo;
        }
        if (value === "|" || value === ">" || value === "|-" || value === ">-" || value === "|+" || value === ">+") {
          blockIndent = indent;
          stack.push({ indent: indent, key: key, path: fullPath });
          continue;
        }
        if (value === "") {
          stack.push({ indent: indent, key: key, path: fullPath });
          continue;
        }
        var entry = { path: fullPath, key: key, value: value, line: lineNo };
        entries.push(entry);
        byPath[fullPath] = entry;
      }
      return { entries: entries, byPath: byPath, duplicates: duplicates, comments: comments, topLevel: topLevel };
    }

    function isLoopback(v) {
      return v === "localhost" || v === "::1" || v === "[::1]" || v.indexOf("127.") === 0;
    }

    function auditConfig(text) {
      var parsed = parseConfig(text);
      var byPath = parsed.byPath;
      var findings = [];
      function add(sev, line, key, msg) {
        findings.push({ severity: sev, line: (line == null ? null : line), key: key || "", message: msg });
      }
      function get(p) { return byPath[p] || null; }
      function val(p) { var e = get(p); return e ? e.value : null; }
      function low(p) { var v = val(p); return v == null ? null : v.toLowerCase(); }

      /* Bind analysis */
      var bindE = get("net.bindIp");
      var bindAllE = get("net.bindIpAll");
      var bindAll = bindAllE && low("net.bindIpAll") === "true";
      var bindList = [];
      if (bindE) { bindList = bindE.value.split(",").map(function (s) { return s.replace(/^\s+|\s+$/g, ""); }).filter(function (s) { return s !== ""; }); }
      var wildcard = !!bindAll || bindList.some(function (v) { return v === "0.0.0.0" || v === "::" || v === "[::]" || v === "*"; });
      var hasNonLoop = bindList.some(function (v) { return !isLoopback(v); });
      var externalBind = wildcard || hasNonLoop;

      /* Authorization */
      var authE = get("security.authorization");
      var authLow = low("security.authorization");
      var authEnabled = authLow === "enabled";
      var secLine = authE ? authE.line : (get("security") ? null : null);

      if (bindE || bindAll) {
        if (wildcard && !authEnabled) {
          add("BLOCKER", bindAll ? bindAllE.line : bindE.line, bindAll ? "net.bindIpAll" : "net.bindIp",
            "mongod binds every interface (" + (bindAll ? "bindIpAll: true" : bindE.value) + ") while security.authorization is " + (authE ? "disabled" : "not set") + ". Anyone who can reach this host gets a MongoDB listener with no login required.");
        } else if (wildcard && authEnabled) {
          add("WARNING", bindE ? bindE.line : bindAllE.line, "net.bindIp",
            "mongod binds every interface (0.0.0.0 / ::). Authorization is enabled, but every network that can route to this host can attempt logins — prefer listing the specific interfaces the deployment actually needs.");
        } else if (hasNonLoop && authEnabled) {
          add("INFO", bindE.line, "net.bindIp",
            "Binds loopback plus the listed non-loopback address(es) (" + bindE.value + "). Reachable beyond this host, so authorization and TLS carry the weight — both are checked below.");
        } else if (hasNonLoop && !authEnabled) {
          add("BLOCKER", bindE.line, "net.bindIp",
            "Binds a non-loopback address (" + bindE.value + ") while security.authorization is " + (authE ? "disabled" : "not set") + " — the database is reachable from other machines with no login required.");
        } else {
          add("INFO", bindE.line, "net.bindIp", "Binds loopback only (" + bindE.value + ") — not reachable from other machines at the MongoDB layer.");
        }
      } else {
        add("INFO", null, "net.bindIp", "net.bindIp is not set. Since MongoDB 3.6, mongod binds localhost only by default — set bindIp explicitly so the intent survives upgrades and audits.");
      }

      if (!authEnabled) {
        if (externalBind) {
          add("BLOCKER", authE ? authE.line : secLine, "security.authorization",
            "security.authorization is " + (authE ? "disabled" : "missing") + " while mongod binds beyond localhost. With authorization off, any connection is effectively a superuser — enable authorization and create an admin user before this config goes anywhere near a network.");
        } else {
          add("WARNING", authE ? authE.line : secLine, "security.authorization",
            "security.authorization is " + (authE ? "disabled" : "missing") + ". The bind is localhost-only, so exposure is limited to this host — but any local process or user can still read and write every database without credentials.");
        }
      } else {
        add("INFO", authE.line, "security.authorization", "Authorization is enabled — clients must authenticate and are confined to their roles (role contents themselves are not in this file; see Honest limits).");
      }

      var ttaE = get("security.transitionToAuth");
      if (ttaE) {
        if (low("security.transitionToAuth") === "true") {
          add("WARNING", ttaE.line, "security.transitionToAuth", "transitionToAuth is on: during the transition the deployment accepts connections both with and without credentials, so unauthenticated access still works. Finish the rollout and turn it off.");
        } else {
          add("INFO", ttaE.line, "security.transitionToAuth", "transitionToAuth is off — no mixed authenticated/unauthenticated transition posture.");
        }
      }

      var keyFileE = get("security.keyFile");
      if (keyFileE) {
        add("INFO", keyFileE.line, "security.keyFile", "A keyFile is configured for replica-set internal authentication (path reference only — its contents are not in this file and were not inspected).");
      }

      /* TLS */
      var tlsModeE = get("net.tls.mode") || get("net.ssl.mode");
      var tlsPrefix = get("net.tls.mode") ? "net.tls" : "net.ssl";
      var tlsMode = tlsModeE ? tlsModeE.value.toLowerCase() : null;
      if (get("net.ssl.mode") && !get("net.tls.mode")) {
        add("INFO", tlsModeE.line, "net.ssl.mode", "Legacy net.ssl naming in use — current MongoDB versions call this net.tls. It still parses, but rename it when the server version is confirmed.");
      }
      if (!tlsModeE || tlsMode === "disabled") {
        if (externalBind) {
          add("BLOCKER", tlsModeE ? tlsModeE.line : null, "net.tls.mode",
            "TLS is " + (tlsModeE ? "disabled" : "not configured") + " while mongod binds beyond localhost. Credentials and data cross the network in plaintext — set net.tls.mode to requireTLS with a certificate before deploying.");
        } else {
          add("WARNING", tlsModeE ? tlsModeE.line : null, "net.tls.mode",
            "TLS is " + (tlsModeE ? "disabled" : "not configured") + ". Tolerable only for isolated localhost development — the moment this bind widens, plaintext credentials and data are on the wire.");
        }
      } else if (tlsMode === "allowtls") {
        add("WARNING", tlsModeE.line, tlsPrefix + ".mode", "allowTLS accepts TLS connections but also accepts plaintext ones — a client (or a downgrade) can still connect unencrypted. requireTLS is the strict posture.");
      } else if (tlsMode === "prefertls") {
        add("INFO", tlsModeE.line, tlsPrefix + ".mode", "preferTLS: TLS is used when the peer offers it, but plaintext connections are still possible. Fine for a migration step; requireTLS is the end state.");
      } else if (tlsMode === "requiretls") {
        add("INFO", tlsModeE.line, tlsPrefix + ".mode", "requireTLS: every connection must be encrypted. This is the posture the rest of the grade assumes.");
        var certE = get("net.tls.certificateKeyFile") || get("net.ssl.PEMKeyFile") || get("net.tls.certificateSelector");
        if (!certE) {
          add("WARNING", tlsModeE.line, tlsPrefix + ".certificateKeyFile", "requireTLS is set but no certificateKeyFile / certificateSelector is configured — mongod has no certificate to present and will refuse to start or serve TLS.");
        }
      } else {
        add("WARNING", tlsModeE.line, tlsPrefix + ".mode", "Unrecognized TLS mode value — expected one of disabled, allowTLS, preferTLS, requireTLS. mongod will reject a mode it does not know at startup.");
      }

      /* Port */
      var portE = get("net.port");
      if (portE) {
        if (portE.value !== "27017") {
          add("INFO", portE.line, "net.port", "Non-default port " + portE.value + " (default is 27017). Harmless as obscurity, worthless as a control — make sure firewall rules and client connection strings match it.");
        }
      }

      /* systemLog */
      var verbE = get("systemLog.verbosity");
      if (verbE) {
        var verb = parseInt(verbE.value, 10);
        if (!isNaN(verb) && verb >= 2) {
          add("WARNING", verbE.line, "systemLog.verbosity", "systemLog verbosity is " + verbE.value + " — at this level the log can record detailed operation content, grows fast, and costs performance. Keep production at 0 or 1 unless actively debugging.");
        } else if (!isNaN(verb) && verb === 1) {
          add("INFO", verbE.line, "systemLog.verbosity", "systemLog verbosity 1 — mildly more detail than default; watch log growth and content on a production host.");
        }
      }
      var destE = get("systemLog.destination");
      if (destE) {
        var dest = destE.value.toLowerCase();
        if (dest === "file") {
          var pathE = get("systemLog.path");
          if (!pathE) {
            add("WARNING", destE.line, "systemLog.path", "systemLog.destination is file but no systemLog.path is set — mongod needs an explicit log path for file logging.");
          } else {
            add("INFO", destE.line, "systemLog.destination", "Logs go to a file (" + pathE.value + "). Make sure rotation is configured and the file is access-controlled — logs can contain operation details.");
          }
        } else if (dest === "syslog") {
          add("INFO", destE.line, "systemLog.destination", "Logs go to syslog. Confirm the syslog sink is access-controlled and retained — query details may land there, and local log review no longer applies.");
        }
      } else {
        add("INFO", null, "systemLog.destination", "No systemLog.destination set — mongod logs to stdout. Fine under a supervisor that captures it; a surprise under anything else.");
      }

      /* operationProfiling */
      var profE = get("operationProfiling.mode");
      if (profE) {
        var prof = profE.value.toLowerCase();
        if (prof === "all") {
          add("WARNING", profE.line, "operationProfiling.mode", "operationProfiling.mode is all: the profiler records every operation, including the full content of writes and queries — sensitive data lands in system.profile and every operation pays profiling overhead. Use slowOp with a threshold instead.");
        } else if (prof === "slowop") {
          add("INFO", profE.line, "operationProfiling.mode", "Profiler records slow operations only — the sane production posture.");
        }
      }

      /* authenticationMechanisms */
      var mechE = get("setParameter.authenticationMechanisms");
      if (!mechE) {
        add("INFO", null, "setParameter.authenticationMechanisms", "authenticationMechanisms is not set — mongod uses its built-in defaults for the server version (SCRAM-based on current releases). Pinning it makes the posture explicit and auditable.");
      } else {
        var mechUp = mechE.value.toUpperCase();
        if (mechUp.indexOf("PLAIN") >= 0) {
          add("WARNING", mechE.line, "setParameter.authenticationMechanisms", "PLAIN is among the offered authentication mechanisms — it exposes credentials to anything that can observe or terminate the connection unless it is strictly confined to TLS with an external directory. Remove it unless that exact setup is intended.");
        } else if (mechUp.indexOf("SCRAM-SHA-1") >= 0 && mechUp.indexOf("SCRAM-SHA-256") < 0) {
          add("WARNING", mechE.line, "setParameter.authenticationMechanisms", "Only SCRAM-SHA-1 is offered. SCRAM-SHA-256 is the stronger mechanism and is supported by current drivers — offer it (existing users may need their credentials re-set to gain SHA-256 credentials).");
        } else if (mechUp.indexOf("SCRAM-SHA-256") >= 0) {
          add("INFO", mechE.line, "setParameter.authenticationMechanisms", "SCRAM-SHA-256 is offered — the current strong default mechanism.");
        }
      }

      /* WiredTiger cache */
      var cacheE = get("storage.wiredTiger.engineConfig.cacheSizeGB");
      if (cacheE) {
        var cache = parseFloat(cacheE.value);
        if (!isNaN(cache) && cache < 0.25) {
          add("WARNING", cacheE.line, "storage.wiredTiger.engineConfig.cacheSizeGB", "cacheSizeGB is " + cacheE.value + " — far below MongoDB's own floor for a working set cache; expect heavy disk re-reads. The default (roughly 50% of RAM, minus 1 GB) exists for a reason.");
        } else {
          add("INFO", cacheE.line, "storage.wiredTiger.engineConfig.cacheSizeGB", "cacheSizeGB is pinned at " + cacheE.value + ". Sanity check it against host RAM (default is ~50% of RAM minus 1 GB, and the OS and mongod itself also need memory) — this file cannot see the host, so the number itself is taken on trust.");
        }
      }

      /* Replica set — honest not-verified */
      var rsE = get("replication.replSetName");
      if (rsE) {
        add("NOT_VERIFIED", rsE.line, "replication.replSetName", "replSetName is set ('" + rsE.value + "') in this file — but a single mongod.conf cannot prove replica set topology: member count, which node is primary, or whether a majority can elect one. Topology is NOT VERIFIED by this audit.");
      }

      /* Duplicates */
      parsed.duplicates.forEach(function (d) {
        add("WARNING", d.line, d.path, "Duplicate key '" + leafOf(d.path) + "' at the same level: first set on line " + d.firstLine + ", repeated on line " + d.line + ". Most YAML parsers silently take the last value, so one of these lines is dead config — remove one.");
      });

      /* Unknown top-level sections */
      parsed.topLevel.forEach(function (t) {
        if (!KNOWN_TOP[t.key]) {
          add("NOT_AUDITED", t.line, t.key, "Top-level section '" + t.key + "' is not a section this auditor knows — everything under it is NOT AUDITED. Check the spelling against the MongoDB configuration reference; a misspelled section name is silently ignored by no one and misread by everyone.");
        }
      });

      /* Commented-out settings */
      parsed.comments.forEach(function (c) {
        add("INFO", c.line, c.key, "Line " + c.line + " sets '" + c.key + "' inside a comment. Commented-out settings are treated as unset — comments do not configure mongod, so the audit graded this config as if the line were absent.");
      });

      /* Secrets — key name and line only, never the value */
      parsed.entries.forEach(function (e) {
        var leaf = leafOf(e.path);
        if (isSecretKey(leaf)) {
          add("WARNING", e.line, e.path, "Secret-looking value sits in the config at key '" + leaf + "' (line " + e.line + "). The value is deliberately not shown here, in the report, or in the JSON export. Prefer a file reference or a secret store over an inline secret in a config file.");
        } else if (leaf === "keyFile" && e.value.length > 80 && e.value.indexOf("/") < 0 && e.value.indexOf(".") < 0) {
          add("WARNING", e.line, e.path, "The keyFile value on line " + e.line + " looks like inline key material rather than a file path. The value is deliberately not shown. keyFile should name a path to a file with strict permissions, not carry the key itself.");
        } else if (/BEGIN [A-Z ]*PRIVATE KEY/.test(e.value)) {
          add("WARNING", e.line, e.path, "The value at key '" + leaf + "' (line " + e.line + ") contains PEM private-key material inline. The value is deliberately not shown. Move key material into a protected file and reference its path.");
        }
      });

      var rank = { "BLOCKER": 0, "WARNING": 1, "NOT_VERIFIED": 2, "NOT_AUDITED": 3, "INFO": 4 };
      findings.sort(function (a, b) {
        var r = rank[a.severity] - rank[b.severity];
        if (r !== 0) return r;
        var la = a.line == null ? 99999 : a.line;
        var lb = b.line == null ? 99999 : b.line;
        return la - lb;
      });

      var counts = { BLOCKER: 0, WARNING: 0, INFO: 0, NOT_VERIFIED: 0, NOT_AUDITED: 0 };
      findings.forEach(function (f) { counts[f.severity]++; });
      var verdict = counts.BLOCKER > 0 ? "DO NOT DEPLOY" : (counts.WARNING > 0 ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY");
      return { verdict: verdict, counts: counts, findings: findings, parsed: parsed };
    }

    function diffConfigs(textA, textB) {
      var pa = parseConfig(textA);
      var pb = parseConfig(textB);
      var out = [];
      var seen = {};
      Object.keys(pa.byPath).forEach(function (p) {
        seen[p] = 1;
        var a = pa.byPath[p];
        var b = pb.byPath[p];
        if (!b) {
          out.push({ path: p, kind: "only-a", a: maskVal(p, a.value), b: null, lineA: a.line, lineB: null });
        } else if (a.value !== b.value) {
          out.push({ path: p, kind: "changed", a: maskVal(p, a.value), b: maskVal(p, b.value), lineA: a.line, lineB: b.line });
        }
      });
      Object.keys(pb.byPath).forEach(function (p) {
        if (seen[p]) return;
        var b = pb.byPath[p];
        out.push({ path: p, kind: "only-b", a: null, b: maskVal(p, b.value), lineA: null, lineB: b.line });
      });
      out.sort(function (x, y) { return x.path < y.path ? -1 : (x.path > y.path ? 1 : 0); });
      return out;
    }
    function maskVal(path, v) {
      return isSecretKey(leafOf(path)) ? "•••••• (masked)" : v;
    }

    function buildReport(result, drift) {
      var lines = [];
      lines.push("J-Dawgs MongoDB Server Config Safety Auditor™ — audit report");
      lines.push("Verdict: " + result.verdict);
      lines.push("Blockers: " + result.counts.BLOCKER + " · Warnings: " + result.counts.WARNING + " · Info: " + result.counts.INFO + " · Not verified: " + result.counts.NOT_VERIFIED + " · Not audited: " + result.counts.NOT_AUDITED);
      lines.push("---");
      result.findings.forEach(function (f) {
        lines.push("[" + f.severity.replace("_", " ") + "] " + (f.line == null ? "not set" : "line " + f.line) + (f.key ? " · " + f.key : "") + " — " + f.message);
      });
      if (drift) {
        lines.push("---");
        lines.push("Drift — Config 1 vs Config 2 (" + drift.length + " difference" + (drift.length === 1 ? "" : "s") + "):");
        if (!drift.length) { lines.push("No differences in leaf settings."); }
        drift.forEach(function (d) {
          if (d.kind === "changed") { lines.push("- " + d.path + ": '" + d.a + "' (Config 1, line " + d.lineA + ") → '" + d.b + "' (Config 2, line " + d.lineB + ")"); }
          else if (d.kind === "only-a") { lines.push("- " + d.path + ": only in Config 1 — '" + d.a + "' (line " + d.lineA + ")"); }
          else { lines.push("- " + d.path + ": only in Config 2 — '" + d.b + "' (line " + d.lineB + ")"); }
        });
      }
      lines.push("---");
      lines.push("Generated in your browser by a heuristic text audit — not a full YAML parser, not mongod. Nothing was uploaded. Secret values are never printed.");
      return lines.join("\n");
    }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_RISKY": (typeof EXAMPLE_RISKY !== 'undefined' ? EXAMPLE_RISKY : undefined), "EXAMPLE_HARDENED": (typeof EXAMPLE_HARDENED !== 'undefined' ? EXAMPLE_HARDENED : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-mongodb-server-config-safety-auditortm',
  name: 'J-Dawgs MongoDB Server Config Safety Auditor',
  description: 'Grades a pasted mongod.conf offline — bindIp paired with authorization, TLS mode, profiling, and duplicate settings, with secrets never printed — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_RISKY": __core["EXAMPLE_RISKY"], "EXAMPLE_HARDENED": __core["EXAMPLE_HARDENED"] }
};
