'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Saleor Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Built-in worked examples (inputs only — never rendered into output) ---------- */
      var RISKY_EXAMPLE = [
        "# Risky worked example — for testing only, do not deploy",
        "SECRET_KEY=short123",
        "DEBUG=True",
        "ALLOWED_HOSTS=*",
        "DATABASE_URL=postgres://saleor:plaintextpass123@db.example.com:5432/saleor",
        "CELERY_BROKER_URL=redis://:brokerpass456@redis.example.com:6379/0",
        "ALLOWED_CLIENT_HOSTS=http://shop.example.com",
        "PUBLIC_URL=http://shop.example.com/",
        "SECURE_SSL_REDIRECT=False",
        "SESSION_COOKIE_SECURE=False",
        "EMAIL_HOST_PASSWORD=smtp-pass-789",
        "JWT_SECRET=tinyjwt"
      ].join("\n");

      var HARDENED_EXAMPLE = [
        "# Hardened worked example",
        "SECRET_KEY=Kx9$mQ2vLp7#zR4w!d8NnB3sTf6yHj1uVc5eAa0oPq9wEr2tYu7i",
        "DEBUG=False",
        "ALLOWED_HOSTS=shop.example.com,api.example.com",
        "DATABASE_URL=postgres://saleor@db.internal:5432/saleor",
        "CELERY_BROKER_URL=redis://cache.internal:6379/0",
        "ALLOWED_CLIENT_HOSTS=https://shop.example.com",
        "PUBLIC_URL=https://shop.example.com/",
        "SECURE_SSL_REDIRECT=True",
        "SESSION_COOKIE_SECURE=True",
        "CSRF_COOKIE_SECURE=True",
        "JWT_SECRET=Zp3!wQ8x$mN5vK2#rT9yLd4&sF7hJb1uVc6eAa0oPq3wEr8t"
      ].join("\n");

      var AGENT_INPUT = ["SECRET_KEY=abc", "DEBUG=True", "ALLOWED_HOSTS=*"].join("\n");

      /* ---------- Parsing ---------- */
      function stripQuotes(v) {
        if (v.length >= 2) {
          var a = v.charAt(0), b = v.charAt(v.length - 1);
          if ((a === '"' && b === '"') || (a === "'" && b === "'")) return v.slice(1, -1);
        }
        return v;
      }

      function parseConfig(text) {
        var entries = [], malformed = 0;
        var lines = String(text == null ? "" : text).split(/\r?\n/);
        for (var i = 0; i < lines.length; i++) {
          var raw = lines[i], t = raw.trim();
          if (t === "" || t.charAt(0) === "#") continue;
          var m = t.match(/^([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/);
          if (!m) { malformed++; continue; }
          entries.push({ key: m[1].toUpperCase(), value: stripQuotes(m[2].trim()), line: i + 1 });
        }
        return { entries: entries, malformed: malformed, totalLines: lines.length };
      }

      function isTruthy(v) { var s = v.trim().toLowerCase(); return s === "true" || s === "1" || s === "yes" || s === "on"; }
      function isFalsy(v) { var s = v.trim().toLowerCase(); return s === "false" || s === "0" || s === "no" || s === "off" || s === ""; }
      function isPlaceholder(v) {
        var s = v.trim();
        return s === "" || s.indexOf("${") === 0 || s.charAt(0) === "$" || s.indexOf("***") !== -1 ||
               s.charAt(0) === "<" || s.toLowerCase() === "none" || s.toLowerCase() === "null";
      }
      var EXAMPLE_WORDS = ["changeme", "change-me", "change_me", "example", "insecure", "placeholder",
        "your-secret", "your_secret", "yoursecret", "secret123", "test-secret", "test_secret",
        "dev-secret", "dev_secret", "default-secret", "todo", "letmein", "django-insecure"];
      function looksExample(v) {
        var s = v.toLowerCase();
        for (var i = 0; i < EXAMPLE_WORDS.length; i++) if (s.indexOf(EXAMPLE_WORDS[i]) !== -1) return true;
        return false;
      }
      function isLocalHostValue(v) {
        var s = v.toLowerCase();
        return s.indexOf("localhost") !== -1 || s.indexOf("127.0.0.1") !== -1 || s.indexOf("[::1]") !== -1 || s.indexOf("::1") !== -1;
      }
      /* Returns embedded password length, or -1 when there is no plaintext password. Never returns the password. */
      function embeddedPasswordLength(urlValue) {
        var m2 = String(urlValue).match(/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\/([^@/?#]*)@/);
        var userinfo = m2 ? m2[1] : null;
        if (!userinfo) return -1;
        var colon = userinfo.indexOf(":");
        if (colon === -1) return -1;
        var pass = userinfo.slice(colon + 1);
        try { pass = decodeURIComponent(pass); } catch (e) { /* keep raw length */ }
        if (isPlaceholder(pass)) return -1;
        return pass.length;
      }

      var URL_KEYS = ["ALLOWED_CLIENT_HOSTS", "PUBLIC_URL", "SITE_URL", "BASE_URL", "APP_URL",
        "DASHBOARD_URL", "FRONTEND_URL", "STOREFRONT_URL", "GRAPHQL_URL", "API_URL", "MEDIA_URL", "STATIC_URL"];
      var SSL_KEYS = ["SECURE_SSL_REDIRECT", "SESSION_COOKIE_SECURE", "CSRF_COOKIE_SECURE"];
      var SMTP_KEYS = ["EMAIL_HOST_PASSWORD", "SMTP_PASSWORD", "SMTP_PASS", "EMAIL_PASSWORD", "MAIL_PASSWORD", "SENDGRID_API_KEY"];
      function isUrlTypeKey(key) {
        if (URL_KEYS.indexOf(key) !== -1) return true;
        if (key.indexOf("PUBLIC") !== -1 && key.slice(-4) === "_URL") return true;
        return false;
      }
      function isJwtKey(key) {
        return key.indexOf("JWT") !== -1 || key === "TOKEN_SECRET" || key === "API_TOKEN_SECRET" || key === "AUTH_TOKEN_SECRET";
      }
      function isSmtpKey(key) { return SMTP_KEYS.indexOf(key) !== -1; }

      /* ---------- The audit ---------- */
      function auditConfig(text) {
        var parsed = parseConfig(text);
        var entries = parsed.entries;
        var findings = [];
        function add(line, key, severity, check, detail) {
          findings.push({ line: line, key: key, severity: severity, check: check, detail: detail });
        }

        if (entries.length < 3) {
          return {
            verdict: "NOT ENOUGH TO GRADE",
            findings: [],
            stats: { validLines: entries.length, malformedLines: parsed.malformed, totalLines: parsed.totalLines,
                     critical: 0, high: 0, medium: 0, low: 0 },
            reason: entries.length === 0
              ? "No readable KEY=value lines were found. Paste an env-style Saleor configuration (at least 3 settings) and audit again."
              : "Only " + entries.length + " readable KEY=value line(s) found — at least 3 settings are needed to grade a configuration."
          };
        }

        var seenSecretKey = false;

        for (var i = 0; i < entries.length; i++) {
          var e = entries[i], key = e.key, val = e.value;

          /* SECRET_KEY and any *_SECRET_KEY */
          if (key === "SECRET_KEY" || key.slice(-11) === "_SECRET_KEY" && key.indexOf("JWT") === -1) {
            if (key === "SECRET_KEY") seenSecretKey = true;
            if (isPlaceholder(val)) {
              add(e.line, key, "CRITICAL", "secret-key-empty", key + " is empty or a placeholder reference with no value on this line. Set a long random value through your secret store.");
            } else if (looksExample(val)) {
              add(e.line, key, "CRITICAL", "secret-key-example", key + " looks like an example or placeholder value (length " + val.length + "). Replace it with a long random secret that has never been published.");
            } else if (val.length < 32) {
              add(e.line, key, "CRITICAL", "secret-key-short", key + " value is only " + val.length + " characters long (50+ recommended). Short secrets can be guessed or brute-forced.");
            } else if (val.length < 50) {
              add(e.line, key, "MEDIUM", "secret-key-medium", key + " value is " + val.length + " characters long. It passes the minimum, but 50+ characters is the recommended length for a production signing secret.");
            }
            continue;
          }

          if (key === "DEBUG") {
            if (isTruthy(val)) add(e.line, key, "CRITICAL", "debug-on", "DEBUG is on. Debug output leaks stack traces, settings, and queries in production. Set DEBUG=False.");
            continue;
          }

          if (key === "ALLOWED_HOSTS") {
            var hosts = val.split(/[\s,]+/);
            var wild = false;
            for (var h = 0; h < hosts.length; h++) if (hosts[h] === "*") wild = true;
            if (wild) add(e.line, key, "CRITICAL", "allowed-hosts-wildcard", "ALLOWED_HOSTS contains the wildcard *, which accepts any Host header. List the real hostnames instead.");
            continue;
          }

          if (key === "DATABASE_URL" || key === "CELERY_BROKER_URL" || key === "CELERY_BROKER" || key === "REDIS_URL") {
            var plen = embeddedPasswordLength(val);
            if (plen >= 0) add(e.line, key, "CRITICAL", "url-plaintext-password", key + " embeds a plaintext password (password length " + plen + "). Anyone who reads this file owns the service — inject the password from a secret store instead of writing it into the URL.");
            continue;
          }

          if (isSmtpKey(key)) {
            if (!isPlaceholder(val)) add(e.line, key, "HIGH", "smtp-plaintext-credential", key + " holds a plaintext mail credential in the config (value length " + val.length + "). Move it to a secret store and reference it at deploy time.");
            continue;
          }

          if (isJwtKey(key)) {
            if (isPlaceholder(val)) {
              add(e.line, key, "HIGH", "jwt-secret-empty", key + " is empty or a placeholder. Token signing needs a real, long secret.");
            } else if (looksExample(val)) {
              add(e.line, key, "CRITICAL", "jwt-secret-example", key + " looks like an example or placeholder value (length " + val.length + "). Replace it with a long random secret.");
            } else if (val.length < 16) {
              add(e.line, key, "CRITICAL", "jwt-secret-short", key + " value is only " + val.length + " characters long. Token secrets under 16 characters can be brute-forced; use 32+ random characters.");
            } else if (val.length < 32) {
              add(e.line, key, "HIGH", "jwt-secret-short", key + " value is " + val.length + " characters long. Use 32+ random characters for token signing secrets.");
            }
            continue;
          }

          if (SSL_KEYS.indexOf(key) !== -1) {
            if (isFalsy(val)) add(e.line, key, "HIGH", "ssl-posture-off", key + " is off. Turning it on keeps sessions and traffic on HTTPS; leave it off only behind a proxy that already enforces it — and document that.");
            continue;
          }

          if (isUrlTypeKey(key)) {
            if (val.toLowerCase().indexOf("http://") !== -1 && !isLocalHostValue(val)) {
              add(e.line, key, "HIGH", "insecure-http-url", key + " uses plain http:// for a non-localhost address. Browsers and payment flows will distrust it — switch to https://.");
            }
            continue;
          }
        }

        if (!seenSecretKey) {
          add(null, "SECRET_KEY", "CRITICAL", "secret-key-missing", "SECRET_KEY is missing from this configuration. Saleor cannot sign sessions or tokens safely without one — set a long random value (50+ characters) through your secret store.");
        }

        findings.sort(function (a, b) {
          var la = a.line == null ? 0 : a.line, lb = b.line == null ? 0 : b.line;
          return la - lb;
        });

        var counts = { critical: 0, high: 0, medium: 0, low: 0 };
        for (var j = 0; j < findings.length; j++) {
          var s = findings[j].severity.toLowerCase();
          if (counts.hasOwnProperty(s)) counts[s]++;
        }
        var verdict;
        if (counts.critical > 0) verdict = "DO NOT DEPLOY";
        else if (counts.high > 0 || counts.medium > 0) verdict = "DEPLOY WITH FIXES";
        else verdict = "SAFE TO DEPLOY";

        return {
          verdict: verdict, findings: findings, reason: null,
          stats: { validLines: entries.length, malformedLines: parsed.malformed, totalLines: parsed.totalLines,
                   critical: counts.critical, high: counts.high, medium: counts.medium, low: counts.low }
        };
      }

      /* ---------- Output builders (findings only — raw config never included) ---------- */
      function lineLabel(f) { return f.line == null ? "— (missing)" : String(f.line); }

      function buildReport(result) {
        var out = [];
        out.push("J-Dawgs Saleor Server Config Safety Auditor — Audit Report");
        out.push("Verdict: " + result.verdict);
        out.push("Settings read: " + result.stats.validLines + " KEY=value line(s)" +
          (result.stats.malformedLines ? "; " + result.stats.malformedLines + " line(s) could not be parsed and were skipped" : ""));
        out.push("Findings: " + result.findings.length + " total — " +
          result.stats.critical + " critical, " + result.stats.high + " high, " +
          result.stats.medium + " medium, " + result.stats.low + " low");
        out.push("");
        if (result.reason) out.push(result.reason);
        if (result.findings.length === 0 && !result.reason) out.push("No findings. None of the checks fired on this configuration.");
        for (var i = 0; i < result.findings.length; i++) {
          var f = result.findings[i];
          out.push("Line " + lineLabel(f) + " · " + f.severity + " · " + f.key + " — " + f.detail);
        }
        out.push("");
        out.push("Note: heuristic text audit only. Secret values are never shown — findings name the key, its line, and its length only.");
        return out.join("\n");
      }

      function buildJSON(result) {
        var obj = {
          tool: "J-Dawgs Saleor Server Config Safety Auditor",
          verdict: result.verdict,
          summary: {
            settingsRead: result.stats.validLines,
            malformedLinesSkipped: result.stats.malformedLines,
            findingsTotal: result.findings.length,
            critical: result.stats.critical, high: result.stats.high,
            medium: result.stats.medium, low: result.stats.low
          },
          reason: result.reason,
          findings: result.findings.map(function (f) {
            return { line: f.line, key: f.key, severity: f.severity, check: f.check, detail: f.detail };
          }),
          note: "Heuristic text audit of a pasted config. Secret values are never included; findings report key name, line, and length only."
        };
        return JSON.stringify(obj, null, 2);
      }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined), "EXAMPLE_WORDS": (typeof EXAMPLE_WORDS !== 'undefined' ? EXAMPLE_WORDS : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-saleor-server-config-safety-auditortm',
  name: 'J-Dawgs Saleor Server Config Safety Auditor',
  description: 'Grades a pasted Saleor server config offline into one deploy verdict (SAFE TO DEPLOY / DEPLOY WITH FIXES / DO NOT DEPLOY / NOT ENOUGH TO GRADE) — short or example SECRET_KEY, DEBUG=True, wildcard ALLOWED_HOSTS, and plaintext database and broker passwords flagged; secrets reported by key name, line, ',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"], "EXAMPLE_WORDS": __core["EXAMPLE_WORDS"] }
};
