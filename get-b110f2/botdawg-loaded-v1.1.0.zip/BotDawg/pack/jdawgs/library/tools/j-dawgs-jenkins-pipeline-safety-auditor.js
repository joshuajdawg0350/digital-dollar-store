'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Jenkins Pipeline Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var RISKY_EXAMPLE = [
          "pipeline {",
          "    agent any",
          "    environment {",
          "        API_TOKEN = 'sk-fake-1234567890'",
          "        APP_NAME = 'demo-service'",
          "    }",
          "    stages {",
          "        stage('Install') {",
          "            steps {",
          "                sh 'curl -fsSL https://example.com/install.sh | sh'",
          "            }",
          "        }",
          "        stage('Deploy') {",
          "            steps {",
          "                sh 'echo deploying to production'",
          "            }",
          "        }",
          "    }",
          "}"
        ].join("\n");

        var CLEAN_EXAMPLE = [
          "pipeline {",
          "    agent {",
          "        docker {",
          "            image 'node:20.11.1-alpine'",
          "            args '-u root'",
          "        }",
          "    }",
          "    options {",
          "        timeout(time: 30, unit: 'MINUTES')",
          "        disableConcurrentBuilds()",
          "    }",
          "    stages {",
          "        stage('Build') {",
          "            steps {",
          "                withCredentials([string(credentialsId: 'api-token', variable: 'API_TOKEN')]) {",
          "                    sh 'npm ci && npm test'",
          "                }",
          "            }",
          "        }",
          "        stage('Approve') {",
          "            steps {",
          "                input message: 'Deploy to production?'",
          "            }",
          "        }",
          "        stage('Deploy') {",
          "            steps {",
          "                sh 'echo deploying to production'",
          "            }",
          "        }",
          "    }",
          "    post {",
          "        always {",
          "            cleanWs()",
          "        }",
          "    }",
          "}"
        ].join("\n");

        var input = document.getElementById("jenkins-input");
        var emptyMsg = document.getElementById("empty-msg");
        var results = document.getElementById("results");
        var banner = document.getElementById("verdict-banner");
        var countsEl = document.getElementById("counts");
        var findingsEl = document.getElementById("findings");
        var reportEl = document.getElementById("report-output");

        input.value = RISKY_EXAMPLE;

        function escapeHtml(s) {
          return s.replace(/[&<>"']/g, function (c) {
            return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
          });
        }

        function lineStarts(text) {
          var starts = [0];
          for (var i = 0; i < text.length; i++) {
            if (text.charAt(i) === "\n") starts.push(i + 1);
          }
          return starts;
        }

        function lineOf(starts, idx) {
          var lo = 0, hi = starts.length - 1, ans = 0;
          while (lo <= hi) {
            var mid = (lo + hi) >> 1;
            if (starts[mid] <= idx) { ans = mid; lo = mid + 1; } else { hi = mid - 1; }
          }
          return ans + 1;
        }

        // Find the index just past the closing brace that matches the "{" at openIdx.
        function matchBrace(text, openIdx) {
          var depth = 0;
          for (var i = openIdx; i < text.length; i++) {
            var c = text.charAt(i);
            if (c === "{") depth++;
            else if (c === "}") { depth--; if (depth === 0) return i; }
          }
          return -1;
        }

        function bracesBalanced(text) {
          var depth = 0;
          for (var i = 0; i < text.length; i++) {
            var c = text.charAt(i);
            if (c === "{") depth++;
            else if (c === "}") { depth--; if (depth < 0) return false; }
          }
          return depth === 0;
        }

        function maskValue(v) {
          var head = v.length >= 2 ? v.slice(0, 2) : v.slice(0, 1);
          return head + "•••• (" + v.length + " chars)";
        }

        function audit(text) {
          var findings = [];
          var starts = lineStarts(text);
          var lines = text.split("\n");

          function add(sev, line, title, detail, fix) {
            findings.push({ sev: sev, line: line, title: title, detail: detail, fix: fix });
          }

          var hasPipelineBlock = /^\s*pipeline\s*\{/m.test(text) || /\bpipeline\s*\{/.test(text);
          var scripted = !hasPipelineBlock;
          var pipelineLine = 1;
          var pm = /\bpipeline\s*\{/.exec(text);
          if (pm) pipelineLine = lineOf(starts, pm.index);

          if (scripted) {
            add("note", 1, "Scripted pipeline — NOT FULLY EVALUATED",
              "No \"pipeline {\" block was found, so this reads as a scripted pipeline. Declarative pipelines are this auditor's target; the line checks below still ran as text heuristics, but the file as a whole is NOT FULLY EVALUATED.",
              "Convert the pipeline to declarative syntax (a top-level pipeline { } block), or validate it on a Jenkins controller, before treating any verdict as complete.");
          }

          // (1) agent any
          var agentRe = /\bagent\s+any\b/g, am;
          while ((am = agentRe.exec(text)) !== null) {
            add("warning", lineOf(starts, am.index), "\"agent any\" — pipeline can run anywhere",
              "Guidance: \"agent any\" lets Jenkins run this pipeline on any available agent, which in some setups includes the controller itself. Controller workspaces are a sensitive place to run untrusted build steps.",
              "Pin the pipeline to a labeled agent or a specific docker image, e.g. agent { label 'linux' } or agent { docker { image '…' } }.");
          }

          // (2) plaintext credentials in environment block
          var envRe = /\benvironment\s*\{/g, em;
          var credKey = /^(.*?(password|passwd|token|secret|api[_-]?key).*)$/i;
          while ((em = envRe.exec(text)) !== null) {
            var openIdx = text.indexOf("{", em.index);
            var closeIdx = matchBrace(text, openIdx);
            if (closeIdx === -1) closeIdx = text.length;
            var blockStartLine = lineOf(starts, openIdx);
            var blockEndLine = lineOf(starts, closeIdx);
            for (var ln = blockStartLine; ln <= blockEndLine && ln <= lines.length; ln++) {
              var lineText = lines[ln - 1];
              var assign = /^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(['"])(.*?)\2\s*$/.exec(lineText) ||
                           /^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(['"])(.*?)\2/.exec(lineText);
              if (assign && credKey.test(assign[1])) {
                var val = assign[3];
                if (val.indexOf("${") === -1) {
                  add("blocker", ln, "Plaintext credential in environment block: " + assign[1],
                    "The variable " + assign[1] + " is assigned a literal value (" + assign[1] + " = " + maskValue(val) + ") directly in the Jenkinsfile. Anyone who can read this file — or its build logs — gets the credential. The full value is never shown by this auditor.",
                    "Remove the literal value. Store the credential in Jenkins Credentials and bind it with credentials('…') in the environment block or withCredentials in the step that needs it, then rotate the exposed credential.");
                }
              }
            }
          }

          // (3) curl / wget piped to sh / bash
          var pipeRe = /\b(curl|wget)\b[^|]{0,300}\|\s*(sudo\s+)?(bash|sh)\b/g, qm;
          var pipeLines = {};
          while ((qm = pipeRe.exec(text)) !== null) {
            var pl = lineOf(starts, qm.index);
            if (!pipeLines[pl]) {
              pipeLines[pl] = true;
              add("blocker", pl, "Download piped straight into a shell (" + qm[1] + " | " + (qm[3]) + ")",
                "This step downloads a remote script and executes it in the same breath. Whatever that URL serves at run time runs with the build's credentials — there is no review, pinning, or checksum in between.",
                "Download the script as its own step, pin it to a version, verify a published checksum, and only then execute the local file — or install the tool from a package manager instead.");
            }
          }

          // (4) sh steps interpolating params.* / env.*
          var shRe = /\bsh\s*("""|'''|"|')/g, sm;
          while ((sm = shRe.exec(text)) !== null) {
            var delim = sm[1];
            var bodyStart = sm.index + sm[0].length;
            var bodyEnd = text.indexOf(delim, bodyStart);
            if (bodyEnd === -1) continue;
            if (delim === '"' || delim === '"""') {
              var body = text.slice(bodyStart, bodyEnd);
              var interp = /\$\{[^}]*\b(params|env)\.|\$(params|env)\./.exec(body);
              if (interp) {
                add("warning", lineOf(starts, sm.index), "Shell injection risk: " + interp[1] + ".* interpolated into an sh string (heuristic)",
                  "Injection-risk heuristic: a double-quoted sh string interpolates " + interp[0].replace(/\s+/g, "") + "… directly into the shell command. If that value contains shell metacharacters (spaces, ;, $(), backticks), the shell will act on them — a parameter value can become extra commands.",
                  "Pass the value through an environment variable instead: assign it in the step's environment or use withEnv, then reference it in a single-quoted sh string as a quoted shell variable (\"$VAR\"), so the shell treats it as data, not code.");
              }
            }
            shRe.lastIndex = bodyEnd + delim.length;
          }

          // (5) deploy stage with no input step before it
          var stageRe = /\bstage\s*\(\s*(['"])(.*?)\1\s*\)/g, gm;
          var inputIdx = text.search(/\binput\s*[({]/);
          if (inputIdx === -1) inputIdx = text.search(/\binput\s+message/);
          while ((gm = stageRe.exec(text)) !== null) {
            if (/deploy/i.test(gm[2])) {
              if (inputIdx === -1 || inputIdx > gm.index) {
                add("warning", lineOf(starts, gm.index), "Deploy stage \"" + gm[2] + "\" has no approval step before it",
                  "No \"input\" approval step appears anywhere before this stage, so the pipeline can deploy with no human checkpoint in the run.",
                  "Add an input step (its own \"Approve\" stage works well) before the deploy stage, so a person confirms the deployment.");
              }
            }
          }

          // (6) options: timeout + disableConcurrentBuilds
          if (!/\btimeout\s*\(/.test(text)) {
            add("warning", pipelineLine, "No timeout in options",
              "No timeout(…) appears anywhere in the file. A hung step can occupy an executor indefinitely.",
              "Add an options block with a timeout, e.g. options { timeout(time: 30, unit: 'MINUTES') }.");
          }
          if (!/\bdisableConcurrentBuilds\s*\(/.test(text)) {
            add("info", pipelineLine, "No disableConcurrentBuilds in options",
              "Nothing in the file disables concurrent builds of the same job, so overlapping runs of this pipeline can interleave — a real hazard if a stage deploys or writes shared state.",
              "If overlapping runs would collide, add disableConcurrentBuilds() to the options block.");
          }

          // (7) docker agent image :latest or untagged
          var imgRe = /\bimage\s+(['"])([^'"]+)\1/g, im;
          while ((im = imgRe.exec(text)) !== null) {
            var ref = im[2];
            var lastSlash = ref.lastIndexOf("/");
            var lastColon = ref.lastIndexOf(":");
            var hasTag = lastColon > lastSlash;
            if (!hasTag) {
              add("warning", lineOf(starts, im.index), "Docker agent image \"" + ref + "\" has no tag",
                "An untagged image reference resolves to :latest at run time, so the build environment can change under you without any edit to this file.",
                "Pin the image to a specific version tag, e.g. '" + ref + ":20.11.1-alpine'.");
            } else if (ref.slice(lastColon + 1) === "latest") {
              add("warning", lineOf(starts, im.index), "Docker agent image \"" + ref + "\" uses the :latest tag",
                "The :latest tag is a moving target: the same Jenkinsfile can build in a different environment next week, and a bad upstream push becomes your broken (or compromised) build.",
                "Pin the image to a specific version tag instead of :latest.");
            }
          }

          // (8) withCredentials — safer pattern
          var wc = /\bwithCredentials\s*\(/.exec(text);
          if (wc) {
            add("info", lineOf(starts, wc.index), "withCredentials in use — the safer pattern",
              "Credentials are bound from the Jenkins credential store for the scope of a block instead of being written into the file. This is the pattern the plaintext-credential check above wants to see.",
              "No fix needed. Keep secrets in the credential store and bind them this way (or with credentials('…') in the environment block).");
          }

          // (9) post { always } cleanup
          if (!/\b(deleteDir|cleanWs)\s*\(/.test(text)) {
            add("info", pipelineLine, "No workspace cleanup found (post { always })",
              "No deleteDir() or cleanWs() call appears in the file, so workspaces are left on the agent after each run — stale files can leak into later builds and disks fill up.",
              "Add a post { always { cleanWs() } } block (or deleteDir() where cleanWs is unavailable) so every run cleans up after itself.");
          }

          // NOT EVALUATED constructs
          if (/@Library/.test(text)) {
            var lib = /@Library/.exec(text);
            add("note", lineOf(starts, lib.index), "NOT EVALUATED: shared library (@Library)",
              "This pipeline loads a Jenkins shared library. That code lives outside this file and was not evaluated — its steps run with the same trust as the pipeline itself.",
              "Review the shared library's source and pin it to a specific version or commit in the @Library annotation.");
          }
          if (/\bkubernetes\s*\{/.test(text)) {
            var kb = /\bkubernetes\s*\{/.exec(text);
            add("note", lineOf(starts, kb.index), "NOT EVALUATED: kubernetes agent block",
              "The kubernetes agent's pod template (containers, volumes, secrets mounts) is not evaluated by these text checks.",
              "Review the pod template separately — especially secret mounts and privileged containers — before running.");
          }
          if (/\bdockerfile\s*(\{|true)/.test(text)) {
            var df = /\bdockerfile/.exec(text);
            add("note", lineOf(starts, df.index), "NOT EVALUATED: dockerfile agent",
              "This pipeline builds its agent from a Dockerfile. The Dockerfile's contents are outside this file and were not evaluated.",
              "Review the Dockerfile separately and pin its base image to a specific tag.");
          }
          if (/\bnode\s*\(/.test(text)) {
            var nd = /\bnode\s*\(/.exec(text);
            add("note", lineOf(starts, nd.index), "NOT EVALUATED: node() block (scripted construct)",
              "A node() block is scripted-pipeline syntax. Its steps are outside the declarative checks this auditor performs.",
              "Prefer declarative structure where possible; otherwise review the node() block manually before running.");
          }
          if (!bracesBalanced(text)) {
            add("note", 1, "NOT EVALUATED: brace balance could not be traced",
              "The file's braces do not balance, so block boundaries (including the environment block) could not be traced reliably. Some checks may have incomplete scope.",
              "Fix the brace balance — a Jenkins controller or an editor with Groovy syntax checking can pinpoint it — then re-run this audit.");
          }

          var counts = { blocker: 0, warning: 0, info: 0, note: 0 };
          findings.forEach(function (f) { counts[f.sev]++; });

          var verdict, verdictClass, verdictWhy;
          if (scripted) {
            verdict = "NOT FULLY EVALUATED";
            verdictClass = "unevaluated";
            verdictWhy = "No pipeline { } block was found, so this reads as a scripted pipeline. The findings below are text heuristics only — this file was not fully evaluated.";
          } else if (counts.blocker > 0) {
            verdict = "DO NOT RUN";
            verdictClass = "danger";
            verdictWhy = counts.blocker + (counts.blocker === 1 ? " blocker" : " blockers") + " found. Fix every blocker before this pipeline runs.";
          } else if (counts.warning > 0) {
            verdict = "RUN WITH FIXES";
            verdictClass = "fixes";
            verdictWhy = "No blockers, but " + counts.warning + (counts.warning === 1 ? " warning needs" : " warnings need") + " attention before this runs unattended.";
          } else {
            verdict = "SAFE TO RUN";
            verdictClass = "safe";
            verdictWhy = "No blockers or warnings found by these heuristic text checks. (Info notes below are still worth a read.)";
          }

          var sevRank = { blocker: 0, warning: 1, note: 2, info: 3 };
          findings.sort(function (a, b) {
            if (sevRank[a.sev] !== sevRank[b.sev]) return sevRank[a.sev] - sevRank[b.sev];
            return a.line - b.line;
          });

          return { verdict: verdict, verdictClass: verdictClass, verdictWhy: verdictWhy, counts: counts, findings: findings, scripted: scripted };
        }

        function buildReport(r) {
          var out = [];
          out.push("J-Dawgs Jenkins Pipeline Safety Auditor™ — Audit Report");
          out.push("Heuristic text audit only: the file was never executed and no Jenkins controller was contacted. Secret values are masked, never shown in full.");
          out.push("");
          out.push("VERDICT: " + r.verdict);
          out.push("Counts: " + r.counts.blocker + " blocker(s), " + r.counts.warning + " warning(s), " + r.counts.info + " info, " + r.counts.note + " not evaluated");
          out.push("");
          out.push("FINDINGS:");
          if (r.findings.length === 0) {
            out.push("(none)");
          }
          r.findings.forEach(function (f, i) {
            var sevLabel = f.sev === "note" ? "NOT EVALUATED" : f.sev.toUpperCase();
            out.push((i + 1) + ". [" + sevLabel + "] Line " + f.line + " — " + f.title);
            out.push("   " + f.detail);
          });
          out.push("");
          out.push("FIX LIST:");
          var fixes = r.findings.filter(function (f) { return f.sev === "blocker" || f.sev === "warning" || f.sev === "note"; });
          if (fixes.length === 0) out.push("(nothing to fix)");
          fixes.forEach(function (f, i) {
            out.push((i + 1) + ". (Line " + f.line + ") " + f.fix);
          });
          return out.join("\n");
        }

        function render(r) {
          banner.className = "verdict " + r.verdictClass;
          banner.innerHTML = '<div class="verdict-label">' + escapeHtml(r.verdict) + "</div><p>" + escapeHtml(r.verdictWhy) + "</p>";

          countsEl.innerHTML =
            '<span class="count-chip">Blockers: ' + r.counts.blocker + "</span>" +
            '<span class="count-chip">Warnings: ' + r.counts.warning + "</span>" +
            '<span class="count-chip">Info: ' + r.counts.info + "</span>" +
            '<span class="count-chip">Not evaluated: ' + r.counts.note + "</span>";

          if (r.findings.length === 0) {
            findingsEl.innerHTML = '<p class="muted">No findings.</p>';
          } else {
            findingsEl.innerHTML = r.findings.map(function (f) {
              var sevLabel = f.sev === "note" ? "NOT EVALUATED" : f.sev.toUpperCase();
              return '<div class="finding ' + f.sev + '">' +
                '<div class="finding-head"><span class="sev ' + f.sev + '">' + sevLabel + "</span>" +
                '<span class="line-no">Line ' + f.line + "</span>" +
                '<span class="finding-title">' + escapeHtml(f.title) + "</span></div>" +
                "<p>" + escapeHtml(f.detail) + "</p>" +
                '<p class="fix"><strong>Fix:</strong> ' + escapeHtml(f.fix) + "</p>" +
                "</div>";
            }).join("");
          }

          reportEl.value = buildReport(r);
          results.classList.remove("hidden");
        }

        function runAudit() {
          var text = input.value;
          if (!text || text.trim() === "") {
            results.classList.add("hidden");
            emptyMsg.classList.remove("hidden");
            emptyMsg.scrollIntoView({ block: "nearest", behavior: "smooth" });
            return;
          }
          emptyMsg.classList.add("hidden");
          render(audit(text));
          results.scrollIntoView({ block: "start", behavior: "smooth" });
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "CLEAN_EXAMPLE": (typeof CLEAN_EXAMPLE !== 'undefined' ? CLEAN_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-jenkins-pipeline-safety-auditor',
  name: 'J-Dawgs Jenkins Pipeline Safety Auditor',
  description: 'Jenkins\' own linter needs a running controller; this grades a pasted Jenkinsfile anywhere for run-safety — plaintext credentials masked by key name, curl|sh, shell interpolation, unapproved deploys — into one run verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "CLEAN_EXAMPLE": __core["CLEAN_EXAMPLE"] }
};
