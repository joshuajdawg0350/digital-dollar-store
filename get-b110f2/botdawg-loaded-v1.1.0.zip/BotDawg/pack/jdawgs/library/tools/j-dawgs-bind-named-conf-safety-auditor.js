'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs BIND named.conf Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

  "use strict";

  var HARDENED = [
    'options {',
    '    directory "/var/cache/bind";',
    '    recursion yes;',
    '    allow-query { localnets; localhost; };',
    '    allow-recursion { localnets; localhost; };',
    '    allow-transfer { none; };',
    '    version "none";',
    '    dnssec-validation auto;',
    '    rate-limit { responses-per-second 10; };',
    '    listen-on { 127.0.0.1; };',
    '};',
    'zone "example.com" {',
    '    type master;',
    '    file "/etc/bind/db.example.com";',
    '    allow-transfer { none; };',
    '};'
  ].join("\n");

  /* ---------------- Tokenizer ----------------
     Handles quoted strings, // and # line comments, and block comments.
     Comment text produces no tokens, so commented directives never fire. */
  function tokenize(text) {
    var toks = [], errors = [], line = 1, i = 0, n = text.length, depth = 0;
    while (i < n) {
      var c = text[i];
      if (c === "\n") { line++; i++; continue; }
      if (c === " " || c === "\t" || c === "\r" || c === "\f" || c === "\v") { i++; continue; }
      if (c === "/" && text[i + 1] === "/") { while (i < n && text[i] !== "\n") i++; continue; }
      if (c === "#") { while (i < n && text[i] !== "\n") i++; continue; }
      if (c === "/" && text[i + 1] === "*") {
        var csl = line; i += 2; var cclosed = false;
        while (i < n) {
          if (text[i] === "*" && text[i + 1] === "/") { i += 2; cclosed = true; break; }
          if (text[i] === "\n") line++;
          i++;
        }
        if (!cclosed) errors.push({ line: csl, msg: "Unterminated block comment" });
        continue;
      }
      if (c === '"') {
        var qsl = line; i++; var s = "", ok = false;
        while (i < n) {
          var ch = text[i];
          if (ch === "\\" && i + 1 < n) { s += text[i + 1]; i += 2; continue; }
          if (ch === '"') { i++; ok = true; break; }
          if (ch === "\n") break;
          s += ch; i++;
        }
        if (!ok) errors.push({ line: qsl, msg: "Unterminated quoted string" });
        toks.push({ t: "str", v: s, line: qsl });
        continue;
      }
      if (c === "{" || c === "}" || c === ";") {
        toks.push({ t: c, v: c, line: line });
        if (c === "{") depth++;
        if (c === "}") depth--;
        i++; continue;
      }
      var wsl = line, w = "";
      while (i < n) {
        var ch2 = text[i];
        if (ch2 === " " || ch2 === "\t" || ch2 === "\r" || ch2 === "\n" ||
            ch2 === "{" || ch2 === "}" || ch2 === ";" || ch2 === '"' || ch2 === "#") break;
        if (ch2 === "/" && (text[i + 1] === "/" || text[i + 1] === "*")) break;
        w += ch2; i++;
      }
      if (w.length === 0) { i++; continue; }
      toks.push({ t: "word", v: w, line: wsl });
    }
    return { toks: toks, errors: errors, balance: depth };
  }

  /* ---------------- Parser ----------------
     A statement = ordered parts: value tokens and { ... } blocks,
     terminated by ';'. Interleaved clauses (controls inet ... allow {}
     keys {}) are preserved so blockAfter() can find them. */
  function parseTokens(toks) {
    var pos = 0, errors = [];
    function parseList(inBlock) {
      var stmts = [];
      while (pos < toks.length) {
        var tk = toks[pos];
        if (tk.t === "}") {
          pos++;
          if (inBlock) return { stmts: stmts, closed: true };
          errors.push({ line: tk.line, msg: "Unmatched closing brace" });
          continue;
        }
        if (tk.t === ";") { pos++; continue; }
        var stmt = { line: tk.line, parts: [], toks: [], blocks: [], name: "" };
        var terminated = false, hitClose = false;
        while (pos < toks.length) {
          var t2 = toks[pos];
          if (t2.t === ";") { pos++; terminated = true; break; }
          if (t2.t === "}") { hitClose = true; break; }
          if (t2.t === "{") {
            pos++;
            var inner = parseList(true);
            stmt.parts.push({ k: "block", stmts: inner.stmts });
            stmt.blocks.push(inner.stmts);
            if (!inner.closed) { /* EOF reached inside the block */ }
            continue;
          }
          stmt.parts.push({ k: "tok", v: t2.v, quoted: (t2.t === "str"), line: t2.line });
          stmt.toks.push(t2);
          pos++;
        }
        if (stmt.toks.length) stmt.name = stmt.toks[0].v.toLowerCase();
        if (stmt.toks.length > 0 || stmt.blocks.length > 0) {
          stmts.push(stmt);
          if (!terminated) {
            if (hitClose) errors.push({ line: stmt.line, msg: "Statement is missing its closing ; before }" });
            else if (stmt.blocks.length > 0) errors.push({ line: stmt.line, msg: "Block opened here is not closed before end of file" });
            else errors.push({ line: stmt.line, msg: "Statement runs to end of file without a closing ;" });
          }
        }
        if (hitClose) {
          pos++;
          if (inBlock) return { stmts: stmts, closed: true };
          errors.push({ line: tk.line, msg: "Unmatched closing brace" });
        }
      }
      return { stmts: stmts, closed: !inBlock };
    }
    var top = parseList(false);
    return { stmts: top.stmts, errors: errors };
  }

  /* ---------------- Statement helpers ---------------- */
  function firstBlock(stmt) { return stmt && stmt.blocks.length ? stmt.blocks[0] : null; }
  function blockAfter(stmt, kw) {
    var seen = false;
    for (var i = 0; i < stmt.parts.length; i++) {
      var p = stmt.parts[i];
      if (p.k === "tok" && p.v.toLowerCase() === kw) { seen = true; continue; }
      if (p.k === "block" && seen) return p.stmts;
    }
    return null;
  }
  function findAll(stmts, name) {
    var out = [];
    (stmts || []).forEach(function (s) { if (s.name === name) out.push(s); });
    return out;
  }
  function findFirst(stmts, name) { var r = findAll(stmts, name); return r.length ? r[0] : null; }
  function walk(stmts, ancestors, fn) {
    (stmts || []).forEach(function (s) {
      fn(s, ancestors);
      s.blocks.forEach(function (b) { walk(b, ancestors.concat([s.name]), fn); });
    });
  }
  function isIPorPrefix(s) {
    if (/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})(\/\d{1,2})?$/.test(s)) return true;
    if (s.indexOf(":") !== -1 && /^[0-9a-fA-F:]+(\/\d{1,3})?$/.test(s)) return true;
    return false;
  }
  function isLoopback(ip) {
    var a = ip.split("/")[0];
    return a === "::1" || a.indexOf("127.") === 0;
  }
  function isPrivateOrLocal(ip) {
    var a = ip.split("/")[0];
    if (isLoopback(a)) return true;
    if (a.indexOf("10.") === 0 || a.indexOf("192.168.") === 0) return true;
    var m = /^172\.(\d{1,3})\./.exec(a);
    if (m) { var o = parseInt(m[1], 10); if (o >= 16 && o <= 31) return true; }
    if (a.toLowerCase().indexOf("fe80:") === 0) return true;
    if (a.indexOf("::") === 0) return true;
    return false;
  }

  /* Classify the elements of an address-match list { ... }; */
  function classifyElements(elemStmts) {
    var info = { hasAny: false, hasNone: false, hasLocalhost: false, hasLocalnets: false,
                 keys: [], names: [], ips: [], elems: 0, allKey: false };
    function visit(list) {
      (list || []).forEach(function (s) {
        var nm = s.name, neg = false;
        if (nm.charAt(0) === "!") { neg = true; nm = nm.substring(1); }
        if (s.blocks.length && nm === "") { visit(s.blocks[0]); return; }
        if (!nm) return;
        info.elems++;
        if (nm === "key") { info.keys.push(s.toks.length > 1 ? s.toks[1].v : ""); return; }
        if (neg) return;
        if (nm === "any") info.hasAny = true;
        else if (nm === "none") info.hasNone = true;
        else if (nm === "localhost") info.hasLocalhost = true;
        else if (nm === "localnets") info.hasLocalnets = true;
        else if (isIPorPrefix(nm)) info.ips.push(nm);
        else info.names.push(nm);
      });
    }
    visit(elemStmts);
    info.allKey = info.elems > 0 && info.keys.length === info.elems;
    return info;
  }
  function openness(info) {
    if (!info) return -1;
    if (info.hasAny) return 3;
    if (info.elems > 0 && info.hasNone && info.keys.length === 0 && info.names.length === 0 &&
        info.ips.length === 0 && !info.hasLocalhost && !info.hasLocalnets) return 0;
    return 2;
  }
  function audienceNonLocal(info, aclMap, depth) {
    if (!info) return false;
    if (info.hasAny) return true;
    for (var i = 0; i < info.ips.length; i++) if (!isPrivateOrLocal(info.ips[i])) return true;
    if (depth < 3) {
      for (var j = 0; j < info.names.length; j++) {
        var def = aclMap[info.names[j].toLowerCase()];
        if (def && audienceNonLocal(def, aclMap, depth + 1)) return true;
      }
    }
    return false;
  }
  function secretShaped(v) {
    return v.length >= 24 && /^[A-Za-z0-9+/]+={0,2}$/.test(v) &&
           /[0-9]/.test(v) && /[a-z]/.test(v) && /[A-Z]/.test(v);
  }

  /* ---------------- Audit engine ---------------- */
  function audit(text) {
    var tk = tokenize(text);
    var parsed = parseTokens(tk.toks);
    var findings = [], notChecked = [], zonesOut = [];
    var openResolver = false;
    function F(sev, line, title, detail, fix) {
      findings.push({ sev: sev, line: line, title: title, detail: detail, fix: fix });
    }

    tk.errors.forEach(function (e) {
      F("WARNING", e.line, "NOT PARSED — " + e.msg,
        "The tokenizer could not read this construct, so anything inside it was not audited.",
        "Fix the quoting or comment syntax on this line, then re-run the audit.");
    });
    parsed.errors.forEach(function (e) {
      F("WARNING", e.line, "NOT PARSED — " + e.msg,
        "This statement could not be assembled into a complete statement, so it was not graded.",
        "Complete the statement (every statement ends with ; and every { has a matching }), then re-run the audit.");
    });
    if (tk.balance !== 0) {
      F("BLOCKER", null, "Unbalanced braces — brace balance at end of file: " + (tk.balance > 0 ? "+" : "") + tk.balance,
        "The file ends with " + (tk.balance > 0 ? tk.balance + " unclosed { brace(s)" : Math.abs(tk.balance) + " extra } brace(s)") +
        ". Statements after the imbalance may have been read in the wrong block, so this audit cannot be trusted until the braces balance.",
        "Match every { with a } so the brace balance at end of file is 0, then re-run the audit.");
    }

    var top = parsed.stmts;

    /* Named ACLs, for resolving references like allow-query { trusted; }; */
    var aclMap = {};
    findAll(top, "acl").forEach(function (s) {
      if (s.toks.length > 1) aclMap[s.toks[1].v.toLowerCase()] = classifyElements(firstBlock(s));
    });

    /* Includes, key blocks, and secret material — values are never read into output. */
    var sawKeyBlock = false, sawUpdatePolicy = false;
    walk(top, [], function (s, ancestors) {
      if (s.name === "include" && s.toks.length > 1) {
        notChecked.push('Included file "' + s.toks[1].v + '" (line ' + s.line + ") — its contents are not read by this audit.");
      }
      if (s.name === "update-policy") sawUpdatePolicy = true;
      if (s.name === "key") {
        sawKeyBlock = true;
        var kn = s.toks.length > 1 ? s.toks[1].v : "(unnamed)";
        F("INFO", s.line, 'Key declared: "' + kn + '"',
          "Key material is present in the pasted text. It is reported by directive name and line only — the secret value is never shown in any output.",
          "No fix needed for this finding. Keep real key values out of shared copies of this file.");
      }
      if (s.name === "secret" && ancestors.indexOf("key") === -1) {
        F("INFO", s.line, "Secret material present (directive: secret)",
          "A secret statement appears here. It is reported by directive name and line only — the value is never shown in any output.",
          "No fix needed for this finding. Keep real secret values out of shared copies of this file.");
      }
      /* Secret-shaped values anywhere else: name and line only. */
      if (["directory", "file", "include", "version", "key", "secret"].indexOf(s.name) === -1) {
        for (var ti = 1; ti < s.toks.length; ti++) {
          if (secretShaped(s.toks[ti].v)) {
            F("INFO", s.toks[ti].line, 'Secret-shaped value in "' + s.name + '" statement',
              "A value here looks like key material. It is reported by directive name and line only — the value itself is never shown in any output.",
              "If this is a real secret, move it to a protected key file and reference it by name instead.");
            break;
          }
        }
      }
    });

    /* Options block */
    var optStmt = findFirst(top, "options");
    var opts = optStmt ? (firstBlock(optStmt) || []) : [];
    function opt(name) { return findFirst(opts, name); }
    function optVal(name) { var s = opt(name); return s && s.toks.length > 1 ? s.toks[1].v.toLowerCase() : null; }

    function pathCheck(value, line, directive) {
      if (/^\/tmp(\/|$)/.test(value) || /^\/var\/tmp(\/|$)/.test(value) || /^\/dev\/shm(\/|$)/.test(value)) {
        F("WARNING", line, 'Path in a world-writable location (' + directive + ': "' + value + '")',
          "This path sits in a shared temporary directory that other local users can write to. Zone or working files there can be tampered with by any local account.",
          "Move it under a directory owned by the named user, such as /var/cache/bind or /etc/bind.");
      } else if (/^\/home\//.test(value) || /^\/Users\//.test(value) || value.indexOf("~") === 0) {
        F("WARNING", line, 'Home-directory path (' + directive + ': "' + value + '")',
          "BIND working and zone files inside a home directory inherit that account's exposure and often break under named's own permissions or chroot.",
          "Move it to a service-owned path such as /var/cache/bind or /etc/bind.");
      }
    }

    var dirStmt = opt("directory");
    if (dirStmt && dirStmt.toks.length > 1) pathCheck(dirStmt.toks[1].v, dirStmt.line, "directory");

    /* Duplicate scalar options inside options */
    var scalarSeen = {};
    opts.forEach(function (s) {
      if (s.blocks.length > 0 || s.toks.length < 2) return;
      if (!scalarSeen[s.name]) scalarSeen[s.name] = [];
      scalarSeen[s.name].push(s.line);
    });
    Object.keys(scalarSeen).forEach(function (name) {
      var lines = scalarSeen[name];
      if (lines.length > 1) {
        F("WARNING", lines[1], 'Duplicate option: "' + name + '" is set ' + lines.length + " times in options (lines " + lines.join(", ") + ")",
          "Which of the duplicate statements takes effect is version- and option-dependent in BIND — NOT SETTLED, so this audit does not claim a winner. The ambiguity itself is the risk.",
          'Remove the duplicate "' + name + '" statements so exactly one remains.');
      }
    });

    /* Recursion / open resolver */
    var recStmt = opt("recursion");
    var recVal = recStmt && recStmt.toks.length > 1 ? recStmt.toks[1].v.toLowerCase() : null;
    var aqStmt = opt("allow-query");
    var aqInfo = aqStmt ? classifyElements(firstBlock(aqStmt)) : null;
    var arStmt = opt("allow-recursion");
    var arInfo = arStmt ? classifyElements(firstBlock(arStmt)) : null;

    if (recVal === null) {
      F("WARNING", optStmt ? optStmt.line : null, "recursion is not stated",
        "Recursion posture is not stated: posture depends on BIND version defaults, which differ across releases. A config whose safety depends on a default is a config that can change behavior on upgrade.",
        'State it explicitly, e.g. recursion yes; with a restricted allow-query, or recursion no; on authoritative-only servers.');
    }
    if (arInfo && arInfo.hasAny) {
      openResolver = true;
      F("BLOCKER", arStmt.line, "allow-recursion { any; } — recursive service offered to the entire internet",
        "Any host on the internet can ask this server to resolve names for it. That is an open resolver: usable for DNS amplification attacks and cache poisoning of third parties.",
        "Restrict it: allow-recursion { localnets; localhost; }; — or set recursion no; if this server is authoritative-only.");
    }
    if (recVal !== "no") {
      if (!aqInfo) {
        openResolver = true;
        F("BLOCKER", recStmt ? recStmt.line : (optStmt ? optStmt.line : null), "Open resolver — recursion is on (or unstated) with no allow-query restriction",
          "With recursion enabled and no allow-query limit in the file, whether strangers can use this server as their resolver rests entirely on version defaults — and combined with an unrestricted listener that is the classic open-resolver posture.",
          "Add allow-query { localnets; localhost; }; (and the same for allow-recursion), or set recursion no; if this server should not resolve for clients at all.");
      } else if (aqInfo.hasAny) {
        openResolver = true;
        F("BLOCKER", aqStmt.line, "Open resolver — recursion yes with allow-query { any; }",
          "This server will recursively resolve queries from any host on the internet. Open resolvers are conscripted into DNS amplification DDoS attacks and are a standing abuse liability for the operator.",
          "Restrict queries to your own clients: allow-query { localnets; localhost; }; and allow-recursion { localnets; localhost; }; — or set recursion no; on authoritative-only servers.");
      } else if (recVal === "yes") {
        F("INFO", aqStmt.line, "Recursion is on, restricted to trusted clients",
          "allow-query is limited to localhost, localnets, specific addresses, or named ACLs rather than any — recursive service is not offered to the open internet.",
          "No fix needed. Keep the allow-query and allow-recursion lists in step when networks change.");
      }
    } else {
      F("INFO", recStmt.line, "Recursion is disabled (recursion no)",
        "This server answers only for zones it is authoritative for and offers no recursive service.",
        "No fix needed for an authoritative-only server.");
    }

    /* Zone transfer — global */
    var atStmt = opt("allow-transfer");
    var atInfo = atStmt ? classifyElements(firstBlock(atStmt)) : null;
    var globalOpen = openness(atInfo);
    if (atInfo && atInfo.hasAny) {
      F("BLOCKER", atStmt.line, "allow-transfer { any; } — full zone transfers (AXFR) to anyone",
        "Any host can download complete copies of every zone this server holds, exposing all hostnames and records — a ready-made map of the network for an attacker.",
        "Restrict transfers to your real secondary servers, or deny them: allow-transfer { none; };");
    } else if (!atInfo) {
      F("WARNING", optStmt ? optStmt.line : null, "allow-transfer is not stated",
        "Zone transfers follow defaults when allow-transfer is absent — restrict explicitly so the posture is known and survives upgrades.",
        "Add allow-transfer { none; }; or list only your secondary servers' addresses.");
    } else if (globalOpen === 0) {
      F("INFO", atStmt.line, "Zone transfers denied (allow-transfer { none; })",
        "No host may pull a full zone transfer from this server.",
        "No fix needed — unless real secondaries exist, in which case list their addresses instead of none.");
    } else {
      F("INFO", atStmt.line, "Zone transfers restricted to a listed set",
        "allow-transfer names specific hosts, addresses, or keys rather than any.",
        "No fix needed. Review the list when secondaries are decommissioned.");
    }
    ["also-notify", "allow-notify"].forEach(function (nm) {
      var s = opt(nm);
      if (s) F("INFO", s.line, nm + " is set",
        "Notification posture is stated explicitly in options rather than left to defaults.",
        "No fix needed. Make sure the listed hosts are the intended secondaries.");
    });

    /* Dynamic updates — checker used for options and for each zone */
    function updateCheck(scopeStmts, scopeLabel, scopeLine) {
      var uStmt = findFirst(scopeStmts, "allow-update");
      if (!uStmt) return;
      var uInfo = classifyElements(firstBlock(uStmt));
      if (uInfo.hasAny) {
        F("BLOCKER", uStmt.line, "allow-update { any; } — anyone can change zone data (" + scopeLabel + ")",
          "Dynamic updates from any host mean any stranger can rewrite DNS records this server serves.",
          "Deny updates, or accept them only from named keys: allow-update { key \"update-key\"; };");
      } else if (uInfo.allKey) {
        F("INFO", uStmt.line, "Dynamic updates accept keys only (" + scopeLabel + ")",
          "allow-update is limited to TSIG key holders — the safe way to run dynamic DNS.",
          "No fix needed. Protect the key file and rotate keys on staff changes.");
      } else if (uInfo.elems > 0) {
        F("WARNING", uStmt.line, "Dynamic updates trusted from non-key clients (" + scopeLabel + ")",
          "allow-update trusts source addresses rather than cryptographic keys. Source addresses can be spoofed or reassigned.",
          'Switch to key-only updates: allow-update { key "update-key"; };');
      }
    }
    updateCheck(opts, "options", optStmt ? optStmt.line : null);
    var upStmt = opt("update-policy");
    if (upStmt) {
      F("INFO", upStmt.line, "update-policy is present",
        "Dynamic updates are governed by an update-policy in options. Its presence is noted; the individual rules are listed under NOT CHECKED.",
        "No fix needed. Review the policy rules by hand — this audit does not grade them rule by rule.");
    }

    /* Version disclosure */
    var vStmt = opt("version");
    if (!vStmt) {
      F("WARNING", optStmt ? optStmt.line : null, "version directive is absent — server version disclosed by default",
        "Without a version directive, BIND answers version.bind queries with its real version string, handing attackers a precise target for version-specific exploits.",
        'Add version "none"; (or any non-version string) to the options block.');
    } else {
      var vVal = vStmt.toks.length > 1 ? vStmt.toks[1].v : "";
      if (vVal.toLowerCase() === "none") {
        F("INFO", vStmt.line, 'version "none" — version disclosure turned off',
          "Good practice: version.bind queries get nothing useful.",
          "No fix needed.");
      } else if (/^\d/.test(vVal) || /bind/i.test(vVal)) {
        F("WARNING", vStmt.line, "version directive discloses a real-looking version string",
          "The version statement answers version.bind queries with what reads as the actual BIND version, which targets version-specific attacks.",
          'Change it to version "none"; or a harmless non-version string.');
      } else {
        F("INFO", vStmt.line, "version directive set to a non-version string",
          "Good practice: the version statement does not disclose the real BIND version.",
          "No fix needed.");
      }
    }

    /* Listening exposure */
    ["listen-on", "listen-on-v6"].forEach(function (nm) {
      var s = opt(nm);
      if (!s) return;
      var lInfo = classifyElements(firstBlock(s));
      if (!lInfo || lInfo.elems === 0) return;
      var allLoop = lInfo.ips.length > 0 && !lInfo.hasAny && !lInfo.hasLocalnets && !lInfo.hasLocalhost &&
                    lInfo.names.length === 0 && lInfo.keys.length === 0 &&
                    lInfo.ips.every(isLoopback);
      if (lInfo.hasAny) {
        if (recVal !== "no") {
          F("WARNING", s.line, nm + " { any; } — listening on every interface while recursion is on (or unstated)",
            "The server accepts DNS traffic on all interfaces. Combined with the recursion posture above, every reachable interface is a door into the resolver.",
            "Bind only the addresses you serve on, e.g. " + nm + " { 127.0.0.1; }; for a local resolver, and firewall UDP/TCP 53 to your client networks.");
        } else {
          F("INFO", s.line, nm + " { any; } — listening on every interface, recursion off",
            "The server listens on all interfaces but offers no recursion, which is the normal posture for a public authoritative server.",
            "No fix needed for a public authoritative server. Still confirm every interface is intended to serve DNS.");
        }
      } else if (allLoop || (lInfo.hasLocalhost && lInfo.ips.every(isLoopback) && lInfo.names.length === 0 && !lInfo.hasLocalnets)) {
        F("INFO", s.line, nm + " restricted to localhost",
          "DNS service is bound to loopback only" + (recVal === "yes" ? ", so the enabled recursion is reachable only from this host itself." : "."),
          "No fix needed for a host-local resolver or a server fronted by something else.");
      } else {
        F("INFO", s.line, nm + " bound to a restricted address list",
          "Listening is limited to the stated addresses rather than any.",
          "No fix needed. Confirm the list still matches the host's real interfaces.");
      }
    });

    /* DNSSEC validation */
    var dStmt = opt("dnssec-validation");
    var dVal = dStmt && dStmt.toks.length > 1 ? dStmt.toks[1].v.toLowerCase() : null;
    if (dVal === "no") {
      F("WARNING", dStmt.line, "dnssec-validation no — DNSSEC validation is off",
        "Recursive answers are returned without DNSSEC validation, so forged responses that DNSSEC would have caught are passed to clients as genuine.",
        "Set dnssec-validation auto; (validates using the built-in root trust anchor) or yes with a managed trust anchor.");
    } else if (dVal === "yes" || dVal === "auto") {
      F("INFO", dStmt.line, "dnssec-validation " + dVal + " — validation on",
        "Recursive answers are DNSSEC-validated.",
        "No fix needed.");
    }

    /* Response rate limiting */
    var rlStmt = opt("rate-limit");
    var audienceInfo = arInfo || aqInfo;
    var nonLocalAudience = openResolver || audienceNonLocal(audienceInfo, aclMap, 0);
    if (rlStmt) {
      F("INFO", rlStmt.line, "Response rate limiting (rate-limit) is configured",
        "Rate limiting blunts this server's usefulness in DNS amplification attacks.",
        "No fix needed. Tune responses-per-second to real client load.");
    } else if (recVal !== "no" && nonLocalAudience) {
      F("WARNING", optStmt ? optStmt.line : null, "No rate-limit block while recursion is offered beyond this host",
        "Without response rate limiting, a recursive server reachable by non-local clients can be used for DNS amplification: small spoofed queries, large reflected answers.",
        "Add a rate-limit { responses-per-second 10; }; block to options, sized to your client load.");
    }

    /* Forwarders */
    var fwdStmt = opt("forwarders");
    if (fwdStmt) {
      var fElems = firstBlock(fwdStmt) || [];
      var badFwd = 0;
      fElems.forEach(function (e) {
        if (!e.toks.length) return;
        var a = e.toks[0].v;
        if (a === "0.0.0.0" || a === "::") {
          badFwd++;
          F("WARNING", e.line, 'Forwarder entry "' + a + '" is not a usable upstream resolver',
            "This entry names the unspecified address, which cannot answer queries — forwarding through it fails or falls back unpredictably.",
            "Replace it with the real upstream resolver address, or remove the entry.");
        } else if (!isIPorPrefix(a)) {
          badFwd++;
          F("WARNING", e.line, "Forwarder entry does not parse as an IP address",
            "This forwarders entry is not a recognizable IPv4 or IPv6 address, so BIND cannot forward to it as written. (The entry text is not reproduced here.)",
            "Correct the entry to the upstream resolver's IP address.");
        }
      });
      if (fElems.length > 0 && badFwd === 0) {
        var fMode = optVal("forward");
        F("INFO", fwdStmt.line, "Forwarders configured: " + fElems.length + " upstream resolver(s)",
          "Queries this server cannot answer are forwarded upstream. Forward mode: " +
          (fMode ? '"' + fMode + '"' : "not stated (BIND default is first)") + ".",
          "No fix needed. Public resolvers as forwarders are a normal choice — just confirm they are the ones you intended to trust.");
      }
    }

    /* Controls / rndc */
    findAll(top, "controls").forEach(function (cStmt) {
      (firstBlock(cStmt) || []).forEach(function (inner) {
        if (inner.name === "inet") {
          var addr = inner.toks.length > 1 ? inner.toks[1].v : "";
          var allowBlk = blockAfter(inner, "allow");
          var keysBlk = blockAfter(inner, "keys");
          var cInfo = allowBlk ? classifyElements(allowBlk) : null;
          var nonLocalAllow = !!cInfo && (cInfo.hasAny || cInfo.names.length > 0 ||
            cInfo.ips.some(function (ip) { return !isLoopback(ip); }));
          if (keysBlk) {
            F("INFO", inner.line, "Controls channel requires key authentication (inet " + addr + ")",
              "This controls listener is protected by a keys clause, so rndc commands require key material. Key values are never shown in this audit.",
              "No fix needed. Keep the rndc key file readable only by its owner.");
          } else if (nonLocalAllow) {
            F("BLOCKER", inner.line, "Controls channel open to non-local hosts without a keys clause (inet " + addr + ")",
              "The named control channel accepts connections from non-local addresses with no key authentication — anyone who can reach it can reload, reconfigure, or stop the server.",
              'Add a keys clause (keys { "rndc-key"; };) and restrict allow to localhost, or remove the controls block.');
          } else {
            F("WARNING", inner.line, "Controls channel on localhost without a keys clause (inet " + addr + ")",
              "The control channel is limited to this host but unauthenticated — any local process or account could issue rndc commands to named.",
              'Add a keys clause (keys { "rndc-key"; };) so only the key holder can control the server.');
          }
        } else if (inner.name === "unix") {
          F("INFO", inner.line, "Controls unix socket noted",
            "A unix-socket control channel is guarded by filesystem permissions rather than the network.",
            "No fix needed. Confirm the socket path permissions are as intended.");
        }
      });
    });

    /* Zones — top level and inside view blocks */
    var zoneStmts = [];
    top.forEach(function (s) {
      if (s.name === "zone") zoneStmts.push(s);
      if (s.name === "view") (firstBlock(s) || []).forEach(function (z) { if (z.name === "zone") zoneStmts.push(z); });
    });
    var zoneNameLines = {};
    zoneStmts.forEach(function (z) {
      var zName = z.toks.length > 1 ? z.toks[1].v : "(unnamed)";
      var zInner = firstBlock(z) || [];
      var typeStmt = findFirst(zInner, "type");
      var zType = typeStmt && typeStmt.toks.length > 1 ? typeStmt.toks[1].v.toLowerCase() : null;
      var fileStmt = findFirst(zInner, "file");
      var zFile = fileStmt && fileStmt.toks.length > 1 ? fileStmt.toks[1].v : null;
      zonesOut.push({ name: zName, type: zType, line: z.line });
      if (!zoneNameLines[zName]) zoneNameLines[zName] = [];
      zoneNameLines[zName].push(z.line);

      F("INFO", z.line, 'Zone "' + zName + '"' + (zType ? " — type " + zType : " — type not stated"),
        "Zone declared at line " + z.line + (zFile ? ' with file "' + zFile + '"' : ", with no file clause") + ".",
        "No fix needed for this listing entry.");
      if ((zType === "master" || zType === "primary") && !fileStmt) {
        F("WARNING", z.line, 'Zone "' + zName + '" is type ' + zType + " with no file clause",
          "A primary zone with no file clause has no stated source of zone data in this file, so what it serves depends on defaults and dynamic updates.",
          'Add a file clause, e.g. file "/etc/bind/db.' + zName + '";, or change the zone type if it is not a primary.');
      }
      if (zFile) {
        pathCheck(zFile, fileStmt.line, "file");
        notChecked.push('Zone file "' + zFile + '" for zone "' + zName + '" — contents are not read; validate them with named-checkzone.');
      }
      var zatStmt = findFirst(zInner, "allow-transfer");
      if (zatStmt) {
        var zatInfo = classifyElements(firstBlock(zatStmt));
        if (zatInfo.hasAny) {
          F("BLOCKER", zatStmt.line, 'Zone "' + zName + '" allows transfers to anyone (allow-transfer { any; })',
            "This zone can be downloaded in full by any host, regardless of the global allow-transfer setting.",
            "Restrict this zone's allow-transfer to its real secondaries, or set it to { none; }.");
        } else if (atInfo && openness(zatInfo) > globalOpen && openness(zatInfo) < 3) {
          F("WARNING", zatStmt.line, 'Zone "' + zName + '" widens the global allow-transfer setting',
            "This zone's allow-transfer is more permissive than the global one in options, so the zone is more exposed than the global posture suggests.",
            "Tighten this zone's allow-transfer to match the global setting, or confirm the exception is deliberate.");
        }
      }
      updateCheck(zInner, 'zone "' + zName + '"', z.line);
      ["also-notify", "allow-notify"].forEach(function (nm) {
        var s = findFirst(zInner, nm);
        if (s) F("INFO", s.line, nm + ' is set for zone "' + zName + '"',
          "Notification posture for this zone is stated explicitly.",
          "No fix needed.");
      });
    });
    Object.keys(zoneNameLines).forEach(function (nm) {
      var lines = zoneNameLines[nm];
      if (lines.length > 1) {
        F("BLOCKER", lines[1], 'Duplicate zone "' + nm + '" (declared at lines ' + lines.join(", ") + ")",
          "The same zone name is declared more than once. BIND cannot serve two conflicting definitions of one zone; one of them is wrong.",
          "Remove or rename one of the duplicate zone blocks so each zone name is declared exactly once.");
      }
    });

    /* NOT CHECKED — always stated, in the page and in every report */
    if (sawUpdatePolicy || zoneStmts.some(function (z) { return !!findFirst(firstBlock(z) || [], "update-policy"); })) {
      notChecked.push("update-policy rule contents — presence is noted, but individual rules are not graded.");
    }
    if (sawKeyBlock) {
      notChecked.push("Key files on disk (such as rndc.key) — only key directives pasted into this file are noted, by name and line.");
    }
    notChecked.push("The running server — this audit never sends a DNS query and never tests a live named.");
    notChecked.push("Statement semantics outside the checks above (for example logging, statistics-channels, and response-policy zone contents) are not evaluated.");
    notChecked.push("Whether the addresses and ACLs named here match your real networks — the audit grades the text, not the network.");

    /* Sort: BLOCKER, WARNING, INFO; by line within each */
    var rank = { BLOCKER: 0, WARNING: 1, INFO: 2 };
    findings.sort(function (a, b) {
      if (rank[a.sev] !== rank[b.sev]) return rank[a.sev] - rank[b.sev];
      var la = a.line === null ? 99999 : a.line, lb = b.line === null ? 99999 : b.line;
      return la - lb;
    });
    var counts = { BLOCKER: 0, WARNING: 0, INFO: 0 };
    findings.forEach(function (f) { counts[f.sev]++; });

    var verdict, verdictClass;
    if (counts.BLOCKER > 0) { verdict = "DO NOT DEPLOY" + (openResolver ? " — OPEN RESOLVER" : ""); verdictClass = "bad"; }
    else if (counts.WARNING > 0) { verdict = "DEPLOY WITH FIXES"; verdictClass = "warn"; }
    else { verdict = "SAFE TO DEPLOY"; verdictClass = "ok"; }

    /* Plain-text report */
    var L = [];
    L.push("J-DAWGS BIND NAMED.CONF SAFETY AUDITOR — REPORT");
    L.push("Verdict: " + verdict);
    L.push("Counts: BLOCKER " + counts.BLOCKER + " · WARNING " + counts.WARNING + " · INFO " + counts.INFO);
    L.push("Brace balance at end of file: " + (tk.balance > 0 ? "+" : "") + tk.balance + (tk.balance === 0 ? " (balanced)" : " (UNBALANCED)"));
    L.push("");
    L.push("FINDINGS");
    if (!findings.length) L.push("(none)");
    findings.forEach(function (f) {
      L.push("[" + f.sev + "]" + (f.line ? " Line " + f.line + " — " : " ") + f.title);
      L.push("  " + f.detail);
      L.push("  Fix: " + f.fix);
    });
    L.push("");
    L.push("ZONES SEEN");
    if (!zonesOut.length) L.push("(no zone blocks found)");
    zonesOut.forEach(function (z) { L.push('- "' + z.name + '" — type ' + (z.type || "not stated") + " (line " + z.line + ")"); });
    L.push("");
    L.push("NOT CHECKED");
    notChecked.forEach(function (n) { L.push("- " + n); });
    L.push("");
    L.push("LIMITS");
    L.push("Heuristic text audit of the pasted file only — not a BIND parser and not a replacement for named-checkconf / named-checkzone.");
    L.push("Included files, zone files, and key files are not read. The running server is not tested.");
    L.push("A SAFE verdict means no risk in the checks above was found in the text.");
    L.push("Secrets: key material is reported by directive name and line only. No secret value appears in this report.");

    return { verdict: verdict, verdictClass: verdictClass, counts: counts, findings: findings,
             zones: zonesOut, notChecked: notChecked, report: L.join("\n"), balance: tk.balance };
  }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-bind-named-conf-safety-auditor',
  name: 'J-Dawgs BIND named.conf Safety Auditor',
  description: 'Grades a pasted named.conf offline — open-resolver and zone-transfer blockers, version disclosure, DNSSEC and rate-limit posture, secrets by name only — into one deploy verdict. named-checkconf runs only where BIND is installed and answers only whether the file parses.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
