'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs NiFi Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

var RISKY = [
"# RISKY EXAMPLE - training config, do not deploy",
"nifi.web.https.host=0.0.0.0",
"nifi.web.https.port=8443",
"nifi.web.http.host=0.0.0.0",
"nifi.web.http.port=8080",
"nifi.security.keystore=",
"nifi.security.keystorePasswd=changeme",
"nifi.security.truststore=",
"nifi.security.needClientAuth=false",
"nifi.security.user.authorizer=",
"nifi.security.truststorePasswd=tiny",
"nifi.cluster.is.node=true",
"nifi.zookeeper.connect.string=",
"nifi.state.management.embedded.zookeeper.start=true",
"nifi.content.repository.archive.enabled=false",
"nifi.remote.input.socket.port=10000",
"nifi.remote.input.secure=false",
"this line has no equals sign and cannot be parsed"
].join("\n");

var HARDENED = [
"# HARDENED EXAMPLE - single-node, TLS on, secrets protected",
"nifi.web.https.host=nifi.internal.example",
"nifi.web.https.port=8443",
"nifi.web.http.host=",
"nifi.web.http.port=",
"nifi.security.keystore=/opt/nifi/conf/keystore.p12",
"nifi.security.keystoreType=PKCS12",
"nifi.security.keystorePasswd=ENC{hardenedExampleProtectedValue0001}",
"nifi.security.truststore=/opt/nifi/conf/truststore.p12",
"nifi.security.truststoreType=PKCS12",
"nifi.security.truststorePasswd=${env:NIFI_TRUSTSTORE_PASSWORD}",
"nifi.security.needClientAuth=true",
"nifi.security.user.authorizer=managed-authorizer",
"nifi.security.user.login.identity.provider=ldap-provider",
"nifi.sensitive.props.key=${env:NIFI_SENSITIVE_PROPS_KEY}",
"nifi.cluster.is.node=false",
"nifi.zookeeper.connect.string=zk1.internal.example:2181,zk2.internal.example:2181,zk3.internal.example:2181",
"nifi.state.management.embedded.zookeeper.start=false",
"nifi.content.repository.archive.enabled=true",
"nifi.content.repository.archive.max.retention.period=7 days",
"nifi.provenance.repository.implementation=org.apache.nifi.provenance.PersistentProvenanceRepository",
"nifi.remote.input.host=nifi.internal.example",
"nifi.remote.input.socket.port=10443",
"nifi.remote.input.secure=true",
"nifi.flow.configuration.archive.enabled=true"
].join("\n");

var SENSITIVE_RE = /(password|passwd|secret|keystorepass|truststorepass|token)/i;
var PLACEHOLDERS = ["changeme","password","example","letmein","admin","default","secret","password123"];

function isProtected(v){
  var t = v.replace(/^\s+|\s+$/g,"");
  if(/^ENC\{[\s\S]*\}$/.test(t)) return true;
  if(t.indexOf("${") !== -1) return true;
  return false;
}
function isPlaceholder(v){
  var lower = v.toLowerCase();
  if(PLACEHOLDERS.indexOf(lower) !== -1) return true;
  if(lower.indexOf("changeme") !== -1) return true;
  return false;
}
function trim(s){ return s.replace(/^\s+|\s+$/g,""); }
function lowerEq(v, target){ return trim(v).toLowerCase() === target; }

function audit(text){
  var lines = text.split(/\r?\n/);
  var props = {};       // key -> {value, line}
  var order = [];       // entries in file order
  var unparsed = [];    // {line, }
  var i, raw, t, eq, key, val;

  for(i=0;i<lines.length;i++){
    raw = lines[i];
    t = trim(raw);
    if(t === "") continue;
    if(t.charAt(0) === "#" || t.charAt(0) === "!") continue;
    eq = raw.indexOf("=");
    if(eq === -1){ unparsed.push({line:i+1}); continue; }
    key = trim(raw.slice(0,eq));
    val = trim(raw.slice(eq+1));
    if(key === ""){ unparsed.push({line:i+1}); continue; }
    props[key] = {value:val, line:i+1};
    order.push({key:key, value:val, line:i+1});
  }

  var recognizable = 0;
  for(var k in props){ if(k.indexOf("nifi.") === 0) recognizable++; }

  var findings = [];
  function add(sev, line, keyName, title, detail, fix){
    findings.push({severity:sev, line:(line==null?null:line), key:keyName||null, title:title, detail:detail, fix:fix});
  }
  function get(keyName){ return props.hasOwnProperty(keyName) ? props[keyName] : null; }
  function hasVal(e){ return e && trim(e.value) !== ""; }

  var httpsHost = get("nifi.web.https.host");
  var httpsPort = get("nifi.web.https.port");
  var httpHost  = get("nifi.web.http.host");
  var httpPort  = get("nifi.web.http.port");
  var httpEnabled = hasVal(httpHost) || hasVal(httpPort);
  var httpLine = hasVal(httpHost) ? httpHost.line : (httpPort ? httpPort.line : null);

  // --- Web listeners ---
  if(httpsHost){
    var hv = trim(httpsHost.value);
    var allIface = (hv === "" || hv === "0.0.0.0" || hv === "::" || hv === "[::]");
    if(allIface){
      if(httpEnabled){
        add("BLOCKER", httpsHost.line, "nifi.web.https.host",
          "HTTPS bound to all interfaces while plaintext HTTP is also enabled",
          "nifi.web.https.host is " + (hv==="" ? "empty (all interfaces)" : hv) + " and the plaintext HTTP listener is on, so the UI/API is reachable on every interface over both schemes.",
          "Bind nifi.web.https.host to one specific interface or hostname and disable the HTTP listener.");
      } else {
        add("HIGH", httpsHost.line, "nifi.web.https.host",
          "HTTPS host exposes the UI/API on all interfaces",
          "nifi.web.https.host is " + (hv==="" ? "empty, which binds all interfaces" : hv + ", which binds all interfaces") + ".",
          "Set nifi.web.https.host to a specific interface or internal hostname.");
      }
    }
    if(!hasVal(httpsPort)){
      add("WARNING", httpsHost.line, "nifi.web.https.port",
        "HTTPS host is set but no HTTPS port is configured",
        "nifi.web.https.host is set, but nifi.web.https.port is " + (httpsPort ? "empty" : "missing") + ".",
        "Set nifi.web.https.port (for example 8443) so the HTTPS listener has an explicit port.");
    }
    // TLS stores while HTTPS is on
    var ks = get("nifi.security.keystore");
    if(!hasVal(ks)){
      add("HIGH", ks ? ks.line : httpsHost.line, "nifi.security.keystore",
        "Keystore is not set while HTTPS is enabled",
        "nifi.security.keystore is " + (ks ? "empty" : "missing") + " but an HTTPS host is configured, so the server has no certificate to present.",
        "Point nifi.security.keystore at a valid keystore file.");
    }
    var ts = get("nifi.security.truststore");
    if(!hasVal(ts)){
      add("HIGH", ts ? ts.line : httpsHost.line, "nifi.security.truststore",
        "Truststore is not set while HTTPS is enabled",
        "nifi.security.truststore is " + (ts ? "empty" : "missing") + " but an HTTPS host is configured.",
        "Point nifi.security.truststore at a valid truststore file.");
    }
  }
  if(httpEnabled){
    add("HIGH", httpLine, hasVal(httpHost) ? "nifi.web.http.host" : "nifi.web.http.port",
      "Plaintext HTTP UI/API is enabled",
      "A nifi.web.http host or port is set, which serves the NiFi UI and API over unencrypted HTTP.",
      "Clear nifi.web.http.host and nifi.web.http.port and serve the UI/API over HTTPS only.");
  }

  // --- Security posture ---
  var nca = get("nifi.security.needClientAuth");
  if(nca && lowerEq(nca.value,"false")){
    add("WARNING", nca.line, "nifi.security.needClientAuth",
      "Client certificate authentication is disabled",
      "nifi.security.needClientAuth is false, so clients are not required to present a certificate for mutual TLS.",
      "Set nifi.security.needClientAuth to true where client certificates are part of the access model, or document why it is off.");
  }
  var authz = get("nifi.security.user.authorizer");
  var authzVal = authz ? trim(authz.value).toLowerCase() : "";
  if(!hasVal(authz)){
    add("HIGH", authz ? authz.line : null, "nifi.security.user.authorizer",
      "No authorizer configured — anonymous posture",
      "nifi.security.user.authorizer is " + (authz ? "empty" : "missing") + ", so there is no configured authorization layer deciding who may do what.",
      "Set nifi.security.user.authorizer to a managed authorizer (for example managed-authorizer) and configure its user group provider.");
  } else if(authzVal === "single-user-authorizer"){
    add("WARNING", authz.line, "nifi.security.user.authorizer",
      "Single-user authorizer in use",
      "The single-user authorizer fits a one-operator install only; it provides no multi-user authorization.",
      "Move to a managed authorizer before more than one operator needs access.");
  }
  var lip = get("nifi.security.user.login.identity.provider");
  if(hasVal(lip)){
    var lipVal = trim(lip.value).toLowerCase();
    if(lipVal.indexOf("single-user") !== -1 || authzVal === "single-user-authorizer"){
      add("WARNING", lip.line, "nifi.security.user.login.identity.provider",
        "Login identity provider set alongside a single-user posture",
        "A login identity provider is configured together with a single-user generator/authorizer posture, which mixes two identity models.",
        "Pick one identity model: the single-user generator for a solo install, or the login identity provider with a managed authorizer.");
    }
  }

  // --- Sensitive properties (value NEVER reported; key, line, length only) ---
  for(i=0;i<order.length;i++){
    var e = order[i];
    if(!SENSITIVE_RE.test(e.key)) continue;
    var v = e.value;
    if(trim(v) === ""){
      add("WARNING", e.line, e.key,
        "Sensitive property is empty",
        "Key " + e.key + " is present with an empty value (length 0).",
        "Set a protected value, or remove the key if it is not used.");
      continue;
    }
    if(isProtected(v)) continue;
    var len = v.length;
    if(isPlaceholder(v)){
      add("BLOCKER", e.line, e.key,
        "Placeholder or example secret stored in plaintext",
        "Key " + e.key + " holds a well-known placeholder-style value in plaintext (value length " + len + "; value not shown).",
        "Replace it with a real secret stored as an ENC{...} value or an environment reference, and rotate anything that ever used the placeholder.");
    } else if(len < 12){
      add("HIGH", e.line, e.key,
        "Short plaintext secret",
        "Key " + e.key + " holds a plaintext value of only " + len + " characters (value not shown). Short plaintext secrets are both exposed and weak.",
        "Use a longer secret stored as an ENC{...} value or an environment reference such as ${env:...}.");
    } else {
      add("WARNING", e.line, e.key,
        "Plaintext sensitive value",
        "Key " + e.key + " holds a plaintext value (value length " + len + "; value not shown).",
        "Move the value into an ENC{...} encrypted value or an environment reference such as ${env:...}.");
    }
  }

  // --- Cluster / ZooKeeper ---
  var isNode = get("nifi.cluster.is.node");
  var isNodeTrue = isNode && lowerEq(isNode.value,"true");
  var zk = get("nifi.zookeeper.connect.string");
  if(isNodeTrue){
    if(!hasVal(zk)){
      add("HIGH", zk ? zk.line : isNode.line, "nifi.zookeeper.connect.string",
        "Cluster node with an empty ZooKeeper ensemble",
        "nifi.cluster.is.node is true but nifi.zookeeper.connect.string is " + (zk ? "empty" : "missing") + ", so the node has no ensemble to coordinate with.",
        "Set nifi.zookeeper.connect.string to the ZooKeeper ensemble (host:port list) or set nifi.cluster.is.node to false.");
    } else {
      var zkv = zk.value;
      var credLike = false;
      if(zkv.indexOf("@") !== -1 && zkv.split("@")[0].indexOf(":") !== -1) credLike = true;
      if(/password/i.test(zkv)) credLike = true;
      if(credLike){
        add("HIGH", zk.line, "nifi.zookeeper.connect.string",
          "ZooKeeper connect string appears to carry plaintext credentials",
          "The connect string matches a credentials pattern (value not shown). Credentials in a connect string sit in plaintext in the config file.",
          "Remove credentials from the connect string and supply ZooKeeper authentication through protected properties instead.");
      }
    }
    var emb = get("nifi.state.management.embedded.zookeeper.start");
    if(emb && lowerEq(emb.value,"true")){
      add("WARNING", emb.line, "nifi.state.management.embedded.zookeeper.start",
        "Embedded ZooKeeper started in a clustered posture",
        "nifi.cluster.is.node is true and the embedded ZooKeeper is set to start, which suits a single-node test setup more than a real cluster.",
        "Run an external ZooKeeper ensemble for a multi-node cluster and set the embedded start flag to false.");
    }
  }

  // --- Content repository / provenance ---
  var arch = get("nifi.content.repository.archive.enabled");
  if(arch && lowerEq(arch.value,"false")){
    add("WARNING", arch.line, "nifi.content.repository.archive.enabled",
      "Content repository archive is disabled",
      "With archiving off, content that flows through is not retained for replay or audit once processed.",
      "Set nifi.content.repository.archive.enabled to true unless there is a documented reason to discard content immediately.");
  }
  if(!get("nifi.content.repository.archive.max.retention.period")){
    add("INFO", null, "nifi.content.repository.archive.max.retention.period",
      "No content retention period configured",
      "No nifi.content.repository.archive.max.retention.period key was found, so content retention is left to defaults (key absent from file).",
      "Set an explicit retention period that matches your disk and audit needs.");
  }
  var flowArch = get("nifi.flow.configuration.archive.enabled");
  if(flowArch && lowerEq(flowArch.value,"false")){
    add("INFO", flowArch.line, "nifi.flow.configuration.archive.enabled",
      "Flow configuration archive is disabled",
      "Archived flow configurations are the rollback history for flow changes.",
      "Set nifi.flow.configuration.archive.enabled to true to keep flow change history.");
  }

  // --- Site-to-site / remote input ---
  var rip = get("nifi.remote.input.socket.port");
  var ris = get("nifi.remote.input.secure");
  if(hasVal(rip)){
    if(ris && lowerEq(ris.value,"false")){
      add("HIGH", ris.line, "nifi.remote.input.secure",
        "Site-to-site input socket is not secure",
        "nifi.remote.input.socket.port is set while nifi.remote.input.secure is false, so site-to-site traffic can arrive unencrypted and unauthenticated by certificate.",
        "Set nifi.remote.input.secure to true and configure the keystore/truststore, or clear the socket port if site-to-site is unused.");
    } else if(!ris){
      add("WARNING", rip.line, "nifi.remote.input.secure",
        "Site-to-site security flag not set",
        "A remote input socket port is set but nifi.remote.input.secure is missing, so the secure posture is left implicit.",
        "Set nifi.remote.input.secure explicitly to true.");
    }
  }

  // --- Unparsed lines ---
  for(i=0;i<unparsed.length;i++){
    add("WARNING", unparsed[i].line, null,
      "NOT PARSED — line could not be read as key=value",
      "Line " + unparsed[i].line + " is not blank, not a comment, and contains no = sign, so it was not interpreted as a property (line content not reproduced in this finding beyond its number).",
      "Fix the line into key=value form, comment it out with #, or delete it.");
  }

  // --- Verdict ---
  var counts = {BLOCKER:0, HIGH:0, WARNING:0, INFO:0};
  for(i=0;i<findings.length;i++) counts[findings[i].severity]++;

  var verdict, verdictClass, summary;
  if(recognizable < 3){
    verdict = "NOT ENOUGH TO GRADE";
    verdictClass = "nog";
    summary = "Only " + recognizable + " recognizable nifi.* key" + (recognizable===1?" was":"s were") + " found. This does not look like a NiFi configuration, so no deploy grade was given — paste a nifi.properties-style config with at least 3 nifi.* keys.";
  } else if(counts.BLOCKER > 0){
    verdict = "DO NOT DEPLOY"; verdictClass = "dont";
    summary = counts.BLOCKER + " BLOCKER finding" + (counts.BLOCKER===1?"":"s") + " must be fixed before this configuration is deployed.";
  } else if(counts.HIGH > 0 || counts.WARNING > 0){
    verdict = "DEPLOY WITH FIXES"; verdictClass = "fixes";
    summary = "No BLOCKERs, but " + (counts.HIGH + counts.WARNING) + " HIGH/WARNING finding" + ((counts.HIGH+counts.WARNING)===1?"":"s") + " should be fixed before or alongside deployment.";
  } else {
    verdict = "SAFE TO DEPLOY"; verdictClass = "safe";
    summary = "No BLOCKER, HIGH, or WARNING findings." + (counts.INFO>0 ? " " + counts.INFO + " INFO note" + (counts.INFO===1?"":"s") + " listed for awareness." : " No INFO notes either.");
  }

  var sevRank = {BLOCKER:0, HIGH:1, WARNING:2, INFO:3};
  findings.sort(function(a,b){
    if(sevRank[a.severity] !== sevRank[b.severity]) return sevRank[a.severity]-sevRank[b.severity];
    var la = a.line==null?99999:a.line, lb = b.line==null?99999:b.line;
    return la-lb;
  });

  return {verdict:verdict, verdictClass:verdictClass, summary:summary, counts:counts,
          findings:findings, recognizable:recognizable, totalLines:lines.length};
}

function lineLabel(f){ return f.line==null ? "missing key" : "line " + f.line; }

function buildTextReport(r){
  var out = [];
  out.push("J-Dawgs NiFi Server Config Safety Auditor - Audit Report");
  out.push("Verdict: " + r.verdict);
  out.push("Recognizable nifi.* keys: " + r.recognizable);
  out.push("Counts: BLOCKER " + r.counts.BLOCKER + " | HIGH " + r.counts.HIGH + " | WARNING " + r.counts.WARNING + " | INFO " + r.counts.INFO);
  out.push("Summary: " + r.summary);
  out.push("");
  out.push("Findings (" + r.findings.length + "):");
  if(r.findings.length===0) out.push("  (none)");
  for(var i=0;i<r.findings.length;i++){
    var f = r.findings[i];
    out.push("  [" + f.severity + "] " + lineLabel(f) + (f.key ? " - " + f.key : "") + " - " + f.title);
    out.push("      " + f.detail);
    out.push("      Fix: " + f.fix);
  }
  out.push("");
  out.push("Note: sensitive values are never reproduced in this report; secret findings name the key, line, and value length only. Heuristic text audit of pasted text only - not NiFi itself, no certificates verified, no live server contacted.");
  return out.join("\n");
}
function buildJsonReport(r){
  var obj = {
    tool: "J-Dawgs NiFi Server Config Safety Auditor",
    verdict: r.verdict,
    summary: r.summary,
    recognizable_nifi_keys: r.recognizable,
    counts: {BLOCKER:r.counts.BLOCKER, HIGH:r.counts.HIGH, WARNING:r.counts.WARNING, INFO:r.counts.INFO},
    findings: r.findings.map(function(f){
      return {severity:f.severity, line:f.line, key:f.key, title:f.title, detail:f.detail, fix:f.fix};
    }),
    note: "Sensitive values are never included; secret findings name the key, line, and value length only."
  };
  return JSON.stringify(obj, null, 2);
}
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-nifi-server-config-safety-auditortm',
  name: 'J-Dawgs NiFi Server Config Safety Auditor',
  description: 'Grades a pasted nifi.properties offline — all-interface listeners, plaintext HTTP, plaintext or placeholder sensitive keys by name/line/length only, site-to-site secure off — into one deploy verdict. NiFi only exercises the config by starting the server; this grades it before anything starts.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
