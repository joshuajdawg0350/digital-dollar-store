'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs BookStack Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";
/* ---------- Worked examples (dummy placeholder values only) ---------- */
var RISKY = [
"# RISKY EXAMPLE - training only, every value below is a dummy placeholder",
"APP_NAME=BookStack",
"APP_URL=http://wiki.example.internal",
"APP_DEBUG=true",
"APP_KEY=base64:shortkey",
"DB_HOST=localhost",
"DB_DATABASE=bookstackapp",
"DB_USERNAME=bookstackapp",
"DB_PASSWORD=secret",
"MAIL_DRIVER=smtp",
"MAIL_HOST=mail.example.internal",
"MAIL_USERNAME=wiki@example.internal",
"MAIL_PASSWORD=password",
"AUTH_METHOD=ldap",
"LDAP_SERVER=ldap://ldap.example.internal:389",
"LDAP_BIND_PASSWORD=changeme",
"ALLOW_UNAUTHENTICATED=true",
"ALLOW_REGISTRATION=true",
"SESSION_SECURE_COOKIE=false",
"SESSION_LIFETIME=120",
"STORAGE_TYPE=public",
"STORAGE_IMAGE_TYPE=public",
"THIS LINE HAS NO EQUALS SIGN AND CANNOT BE PARSED",
"DEFAULT_ADMIN_EMAIL=admin@example.internal",
"DEFAULT_ADMIN_PASSWORD=admin"
].join("\n");

var HARDENED = [
"# HARDENED EXAMPLE - training only, every value below is a dummy placeholder",
"APP_NAME=BookStack",
"APP_URL=https://wiki.example.com",
"APP_DEBUG=false",
"APP_KEY=base64:kX9vQ2mNpL8rT4wYzA1bC6dE7fG8hJ0kL2mN4pQ6rS8tU0=",
"DB_HOST=db.example.internal",
"DB_DATABASE=bookstackapp",
"DB_USERNAME=bookstackapp",
"DB_PASSWORD=X7qP9vR2mL8nK4wZ6tY3",
"MAIL_DRIVER=smtp",
"MAIL_HOST=mail.example.com",
"MAIL_USERNAME=wiki@example.com",
"MAIL_PASSWORD=M4nB8vC2xZ6qW9eR5tY7",
"AUTH_METHOD=standard",
"ALLOW_UNAUTHENTICATED=false",
"ALLOW_REGISTRATION=false",
"SESSION_SECURE_COOKIE=true",
"SESSION_COOKIE_SECURE=true",
"SESSION_LIFETIME=120",
"STORAGE_TYPE=local_secure",
"STORAGE_IMAGE_TYPE=local_secure"
].join("\n");

var GIBBERISH = [
"the quick brown fox jumps over the lazy dog",
"12345 !!! not a config file",
"just some random notes with no keys at all"
].join("\n");

var PLANTED = [
 {line:3,  planted:"APP_URL uses http://", report:"CRITICAL — APP_URL is served over plain http."},
 {line:4,  planted:"APP_DEBUG=true", report:"CRITICAL — debug mode is switched on."},
 {line:5,  planted:"APP_KEY is a short dummy value (length 15)", report:"CRITICAL — APP_KEY too short / example value, by name, line, and length only."},
 {line:9,  planted:"DB_PASSWORD is a short example word (length 6)", report:"CRITICAL — secret too short / example value, by name, line, and length only."},
 {line:13, planted:"MAIL_PASSWORD is a short example word (length 8)", report:"CRITICAL — secret too short / example value, by name, line, and length only."},
 {line:15, planted:"LDAP_SERVER uses ldap:// (not ldaps://)", report:"HIGH — directory traffic over a non-TLS LDAP URL."},
 {line:16, planted:"LDAP_BIND_PASSWORD is a short example word (length 8)", report:"CRITICAL — secret too short / example value, by name, line, and length only."},
 {line:17, planted:"ALLOW_UNAUTHENTICATED=true", report:"CRITICAL — unauthenticated access is allowed."},
 {line:18, planted:"ALLOW_REGISTRATION=true", report:"HIGH — public self-registration is switched on."},
 {line:19, planted:"SESSION_SECURE_COOKIE=false", report:"HIGH — secure session cookie flag is off."},
 {line:21, planted:"STORAGE_TYPE=public", report:"HIGH — storage type exposes files publicly."},
 {line:22, planted:"STORAGE_IMAGE_TYPE=public", report:"HIGH — image storage type exposes files publicly."},
 {line:23, planted:"A line with no KEY=VALUE shape", report:"LOW — NOT PARSED, reported with its line number."},
 {line:24, planted:"DEFAULT_ADMIN_EMAIL left in the config", report:"HIGH — default admin posture present in config."},
 {line:25, planted:"DEFAULT_ADMIN_PASSWORD is a short example word (length 5)", report:"CRITICAL — secret too short / example value, by name, line, and length only."}
];

/* ---------- Audit engine (original code; public documentation concepts only) ---------- */
var RECOGNISED_PREFIXES = ["APP_","DB_","MAIL_","SESSION_","COOKIE_","STORAGE_","AUTH_","LDAP_","OIDC_","SAML_","ALLOW_","FILE_","UPLOAD_","DEFAULT_","QUEUE_","CACHE_","REDIS_","LOG_","AWS_","MEMCACHED_"];
var EXAMPLE_WORDS = ["example","changeme","change-me","change_me","placeholder","your-","your_","dummy","sample","test123","letmein","default"];
var EXAMPLE_EXACT = ["","secret","password","passwd","passw0rd","admin","root","123456","12345678","qwerty","bookstack","wiki","changeme","password1","secret123"];

function isTrue(v){ v=String(v).toLowerCase(); return v==="true"||v==="1"||v==="yes"||v==="on"; }
function isFalse(v){ v=String(v).toLowerCase(); return v==="false"||v==="0"||v==="no"||v==="off"; }
function looksExample(v){
  var lv=String(v).toLowerCase();
  if(EXAMPLE_EXACT.indexOf(lv)>=0) return true;
  for(var i=0;i<EXAMPLE_WORDS.length;i++){ if(lv.indexOf(EXAMPLE_WORDS[i])>=0) return true; }
  return false;
}
function isSecretKey(key){
  return /(PASSWORD|PASSWD|SECRET|TOKEN|BIND|PRIVATE_KEY|API_KEY)/.test(key);
}
function isRecognised(key){
  for(var i=0;i<RECOGNISED_PREFIXES.length;i++){ if(key.indexOf(RECOGNISED_PREFIXES[i])===0) return true; }
  return false;
}
function stripQuotes(v){
  v=String(v).trim();
  if(v.length>=2 && ((v.charAt(0)==='"' && v.charAt(v.length-1)==='"') || (v.charAt(0)==="'" && v.charAt(v.length-1)==="'"))){
    return v.slice(1,-1);
  }
  return v;
}

function auditConfig(text){
  var findings=[], passes=[], entries={}, order=[], notParsed=[];
  var lines = String(text==null?"":text).split(/\r?\n/);
  var parsedCount=0, recognisedCount=0;
  for(var i=0;i<lines.length;i++){
    var lineNo=i+1, raw=lines[i], trimmed=raw.trim();
    if(trimmed==="" || trimmed.charAt(0)==="#"){ continue; }
    var m = trimmed.match(/^(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/);
    if(!m){
      notParsed.push(lineNo);
      findings.push({severity:"LOW",code:"NOT_PARSED",key:null,line:lineNo,length:null,
        message:"Line "+lineNo+" is NOT PARSED — it is not in KEY=VALUE shape, so the auditor skipped its content. Fix or remove the line so nothing hides in it."});
      continue;
    }
    var key=m[1].toUpperCase(), value=stripQuotes(m[2]);
    parsedCount++;
    if(isRecognised(key)) recognisedCount++;
    if(!entries[key]){ order.push(key); }
    entries[key]={key:key,line:lineNo,value:value,length:value.length};
  }

  var gradeable = recognisedCount>=3;

  function add(sev,code,e,msg){ findings.push({severity:sev,code:code,key:e?e.key:null,line:e?e.line:null,length:(e&&isSecretKey(e.key))||code==="APP_KEY_SHORT"||code==="APP_KEY_EXAMPLE"? (e?e.length:null):null,message:msg}); }
  /* Simpler: attach length for any secret-bearing finding explicitly below. */

  if(gradeable){
    /* APP_URL */
    var eUrl=entries["APP_URL"];
    if(eUrl){
      if(/^http:\/\//i.test(eUrl.value)){
        findings.push({severity:"CRITICAL",code:"APP_URL_HTTP",key:eUrl.key,line:eUrl.line,length:null,
          message:"APP_URL on line "+eUrl.line+" uses http:// instead of https://. Logins, pages, and session cookies would travel unencrypted. Set APP_URL to the https:// address."});
      } else if(/^https:\/\//i.test(eUrl.value)){
        passes.push("APP_URL uses https:// (line "+eUrl.line+").");
      } else {
        findings.push({severity:"MEDIUM",code:"APP_URL_ODD",key:eUrl.key,line:eUrl.line,length:null,
          message:"APP_URL on line "+eUrl.line+" does not start with https://. Set it to the full https:// address of the instance."});
      }
    } else {
      findings.push({severity:"MEDIUM",code:"APP_URL_MISSING",key:"APP_URL",line:null,length:null,
        message:"APP_URL is not present. BookStack builds links and redirects from it — set it to the full https:// address before deploying."});
    }
    /* APP_DEBUG */
    var eDbg=entries["APP_DEBUG"];
    if(eDbg && isTrue(eDbg.value)){
      findings.push({severity:"CRITICAL",code:"APP_DEBUG_ON",key:eDbg.key,line:eDbg.line,length:null,
        message:"APP_DEBUG on line "+eDbg.line+" is true. Debug mode can expose stack traces, file paths, and configuration details to visitors. Set APP_DEBUG=false for production."});
    } else if(eDbg){
      passes.push("APP_DEBUG is off (line "+eDbg.line+").");
    }
    /* APP_KEY */
    var eKey=entries["APP_KEY"];
    if(!eKey){
      findings.push({severity:"HIGH",code:"APP_KEY_MISSING",key:"APP_KEY",line:null,length:null,
        message:"APP_KEY is not present. BookStack needs a generated application key; generate one with the vendor's documented key generation command rather than typing a value."});
    } else if(eKey.length<40 || looksExample(eKey.value)){
      findings.push({severity:"CRITICAL",code:"APP_KEY_WEAK",key:eKey.key,line:eKey.line,length:eKey.length,
        message:"APP_KEY on line "+eKey.line+" is only "+eKey.length+" characters long and/or reads as an example value. A real generated key is much longer. Reported by name, line, and length only — the value is never shown. Regenerate it with the documented command."});
    } else {
      passes.push("APP_KEY is present with a plausible generated length ("+eKey.length+" characters, line "+eKey.line+"). Length only — the value was not inspected beyond that.");
    }
    /* Secrets: DB / MAIL / LDAP / OIDC / SAML and any password/secret/token key */
    for(var j=0;j<order.length;j++){
      var k=order[j], e=entries[k];
      if(k==="APP_KEY") continue;
      if(!isSecretKey(k)) continue;
      if(e.length===0){
        findings.push({severity:"CRITICAL",code:"SECRET_EMPTY",key:k,line:e.line,length:0,
          message:k+" on line "+e.line+" is present but empty (length 0). An empty secret usually means the service falls back to no authentication. Reported by name, line, and length only."});
      } else if(e.length<12 || looksExample(e.value)){
        findings.push({severity:"CRITICAL",code:"SECRET_WEAK",key:k,line:e.line,length:e.length,
          message:k+" on line "+e.line+" is only "+e.length+" characters long and/or reads as an example value. Use a long, unique, generated secret. Reported by name, line, and length only — the value is never shown."});
      } else {
        passes.push(k+" has a plausible length ("+e.length+" characters, line "+e.line+"). Length only — correctness was not verified.");
      }
    }
    /* Open access posture */
    var eUnauth=entries["ALLOW_UNAUTHENTICATED"];
    if(eUnauth && isTrue(eUnauth.value)){
      findings.push({severity:"CRITICAL",code:"ALLOW_UNAUTHENTICATED_ON",key:eUnauth.key,line:eUnauth.line,length:null,
        message:"ALLOW_UNAUTHENTICATED on line "+eUnauth.line+" is true — visitors may reach content without logging in. Set it to false unless the instance is deliberately public and reviewed."});
    } else if(eUnauth){
      passes.push("ALLOW_UNAUTHENTICATED is off (line "+eUnauth.line+").");
    }
    for(var r=0;r<order.length;r++){
      var rk=order[r], re=entries[rk];
      if(/REGISTRATION|REGISTER/.test(rk) && isTrue(re.value)){
        findings.push({severity:"HIGH",code:"PUBLIC_REGISTRATION_ON",key:rk,line:re.line,length:null,
          message:rk+" on line "+re.line+" is true — anyone on the internet can self-register an account. Switch public registration off and invite users instead, unless open sign-up is deliberate and reviewed."});
      }
    }
    var adminSeen=false;
    for(var a=0;a<order.length;a++){
      var ak=order[a];
      if(ak.indexOf("DEFAULT_ADMIN")===0 && !adminSeen){
        adminSeen=true; var ae=entries[ak];
        findings.push({severity:"HIGH",code:"DEFAULT_ADMIN_PRESENT",key:ak,line:ae.line,length:null,
          message:"A default admin setting ("+ak+") is present on line "+ae.line+". Default or seeded admin accounts are a first target — remove the default admin settings from the deployed config and confirm the real admin account uses a unique, strong password."});
      }
    }
    /* Session / cookie secure flags (where present) */
    for(var s=0;s<order.length;s++){
      var sk=order[s], se=entries[sk];
      if(sk.indexOf("SECURE")>=0 && (sk.indexOf("SESSION")>=0 || sk.indexOf("COOKIE")>=0) && isFalse(se.value)){
        findings.push({severity:"HIGH",code:"SECURE_COOKIE_OFF",key:sk,line:se.line,length:null,
          message:sk+" on line "+se.line+" is false — the session cookie is not restricted to https, so it can leak over plain http. Set it to true on an https deployment."});
      } else if(sk.indexOf("SECURE")>=0 && (sk.indexOf("SESSION")>=0 || sk.indexOf("COOKIE")>=0) && isTrue(se.value)){
        passes.push(sk+" is on (line "+se.line+").");
      }
    }
    /* Storage / upload exposure (where present) */
    for(var t=0;t<order.length;t++){
      var tk=order[t], te=entries[tk];
      if((tk.indexOf("STORAGE")>=0 || tk.indexOf("UPLOAD")>=0 || tk.indexOf("FILESYSTEM")>=0 || tk.indexOf("DISK")>=0) &&
         /^public/i.test(te.value)){
        findings.push({severity:"HIGH",code:"STORAGE_PUBLIC",key:tk,line:te.line,length:null,
          message:tk+" on line "+te.line+" is set to a public storage type — uploaded files may be reachable by direct URL without a login. Use a private/secure storage type for a private wiki."});
      }
    }
    /* Insecure auth endpoints: LDAP / OIDC / SAML over plain http or ldap */
    for(var u=0;u<order.length;u++){
      var uk=order[u], ue=entries[uk];
      if((uk.indexOf("LDAP_")===0 || uk.indexOf("OIDC_")===0 || uk.indexOf("SAML_")===0) && /^http:\/\//i.test(ue.value)){
        findings.push({severity:"HIGH",code:"AUTH_ENDPOINT_HTTP",key:uk,line:ue.line,length:null,
          message:uk+" on line "+ue.line+" points at an http:// endpoint — identity traffic would travel unencrypted. Use the https:// (or ldaps://) endpoint."});
      }
      if(uk==="LDAP_SERVER" && /^ldap:\/\//i.test(ue.value)){
        findings.push({severity:"HIGH",code:"LDAP_PLAIN",key:uk,line:ue.line,length:null,
          message:"LDAP_SERVER on line "+ue.line+" uses ldap:// without TLS — directory binds, including credentials, can travel unencrypted. Use ldaps:// or StartTLS per the vendor documentation."});
      }
    }
  }

  var verdict;
  if(!gradeable){ verdict="NOT ENOUGH TO GRADE"; }
  else if(findings.some(function(f){return f.severity==="CRITICAL";})){ verdict="DO NOT DEPLOY"; }
  else if(findings.length>0){ verdict="DEPLOY WITH FIXES"; }
  else { verdict="SAFE TO DEPLOY"; }

  var sevRank={CRITICAL:0,HIGH:1,MEDIUM:2,LOW:3};
  findings.sort(function(x,y){
    var lx=(x.line==null?9999:x.line), ly=(y.line==null?9999:y.line);
    if(sevRank[x.severity]!==sevRank[y.severity]) return sevRank[x.severity]-sevRank[y.severity];
    return lx-ly;
  });

  return {verdict:verdict, findings:findings, passes:passes, notParsed:notParsed,
    stats:{totalLines:lines.length, parsedKeys:parsedCount, recognisedKeys:recognisedCount,
      critical:findings.filter(function(f){return f.severity==="CRITICAL";}).length,
      high:findings.filter(function(f){return f.severity==="HIGH";}).length,
      medium:findings.filter(function(f){return f.severity==="MEDIUM";}).length,
      low:findings.filter(function(f){return f.severity==="LOW";}).length}};
}

function buildTextReport(result){
  var out=[];
  out.push("J-Dawgs BookStack Server Config Safety Auditor\u2122 — audit report");
  out.push("Heuristic text audit of pasted config only. No server was contacted and no secret was verified.");
  out.push("Secrets are reported by key name, line, and length only. Secret values are never included.");
  out.push("");
  out.push("VERDICT: "+result.verdict);
  out.push("Parsed keys: "+result.stats.parsedKeys+" | Recognised BookStack keys: "+result.stats.recognisedKeys+
    " | Findings: "+result.findings.length+" (CRITICAL "+result.stats.critical+", HIGH "+result.stats.high+
    ", MEDIUM "+result.stats.medium+", LOW "+result.stats.low+")");
  out.push("");
  if(result.findings.length===0){
    out.push("Findings: none.");
  } else {
    out.push("Findings:");
    result.findings.forEach(function(f){
      var loc = f.line==null ? "config-wide" : "Line "+f.line;
      var key = f.key ? " · "+f.key : "";
      var len = (f.length==null) ? "" : " · length "+f.length;
      out.push("- ["+f.severity+"] "+loc+key+len+" — "+f.message);
    });
  }
  if(result.notParsed.length){
    out.push("");
    out.push("NOT PARSED lines: "+result.notParsed.join(", "));
  }
  if(result.passes.length){
    out.push("");
    out.push("Checks that passed:");
    result.passes.forEach(function(p){ out.push("- "+p); });
  }
  out.push("");
  out.push("Reminder: this is a heuristic text audit, not a replacement for the official BookStack documentation or your own security review.");
  return out.join("\n");
}
function buildJson(result){
  return JSON.stringify({
    tool:"J-Dawgs BookStack Server Config Safety Auditor\u2122",
    reportType:"heuristic-text-audit",
    notes:"No server was contacted. No secret was verified. Secrets appear by key name, line, and length only; secret values are never included.",
    verdict:result.verdict,
    stats:result.stats,
    notParsedLines:result.notParsed,
    findings:result.findings.map(function(f){
      return {severity:f.severity, code:f.code, key:f.key, line:f.line, valueLength:f.length, message:f.message};
    }),
    passedChecks:result.passes
  }, null, 2);
}
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_WORDS": (typeof EXAMPLE_WORDS !== 'undefined' ? EXAMPLE_WORDS : undefined), "EXAMPLE_EXACT": (typeof EXAMPLE_EXACT !== 'undefined' ? EXAMPLE_EXACT : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-bookstack-server-config-safety-auditor',
  name: 'J-Dawgs BookStack Server Config Safety Auditor',
  description: 'Host tools only tell you the server started; ours grades a pasted BookStack .env/config offline into one deploy verdict — secrets by key name/line/length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_WORDS": __core["EXAMPLE_WORDS"], "EXAMPLE_EXACT": __core["EXAMPLE_EXACT"] }
};
