'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Valkey Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

var RISKY = [
"# RISKY EXAMPLE - for audit practice only, do not deploy",
"bind 0.0.0.0",
"protected-mode no",
"port 6379",
"daemonize yes",
"user appuser on >Plant3d-Secret-Value-7734 allcommands allkeys",
"maxmemory 0",
"maxmemory-policy noeviction",
'save ""',
"appendonly no",
"replicaof 10.0.0.9 6379",
"replica-read-only no",
"this is plain prose not a directive",
"frobnicate enable please"
].join("\n");

var HARDENED = [
"# HARDENED EXAMPLE",
"bind 127.0.0.1 -::1",
"protected-mode yes",
"port 0",
"tls-port 6379",
"tls-cert-file /etc/valkey/tls/valkey.crt",
"tls-key-file /etc/valkey/tls/valkey.key",
"tls-ca-cert-file /etc/valkey/tls/ca.crt",
"requirepass Harden3d-Long-Str0ng-Passphrase-2026!x",
"user appuser on #9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08 allcommands ~app:*",
"rename-command FLUSHALL \"\"",
"rename-command FLUSHDB \"\"",
"rename-command CONFIG \"\"",
"rename-command DEBUG \"\"",
"rename-command SHUTDOWN \"\"",
"rename-command KEYS \"\"",
"maxmemory 2gb",
"maxmemory-policy allkeys-lru",
"save 900 1",
"save 300 10",
"appendonly yes",
"appendfsync everysec"
].join("\n");

var KNOWN = {};
["bind","protected-mode","port","tls-port","tls-cert-file","tls-key-file","tls-ca-cert-file","tls-ca-cert-dir","tls-auth-clients","tls-protocols","tls-ciphers","requirepass","masterauth","user","aclfile","rename-command","maxmemory","maxmemory-policy","maxclients","save","appendonly","appendfsync","appendfilename","dir","dbfilename","replicaof","slaveof","replica-read-only","slave-read-only","replica-serve-stale-data","daemonize","supervised","pidfile","logfile","loglevel","syslog-enabled","databases","timeout","tcp-backlog","tcp-keepalive","unixsocket","unixsocketperm","io-threads","io-threads-do-reads","hz","dynamic-hz","aof-rewrite-incremental-fsync","rdbchecksum","activerehashing","stop-writes-on-bgsave-error","daemonize","notify-keyspace-events","hash-max-listpack-entries","list-max-listpack-size","set-max-intset-entries","zset-max-listpack-entries","slowlog-log-slower-than","slowlog-max-len","latency-monitor-threshold","min-replicas-to-write","min-slaves-to-write","cluster-enabled","cluster-config-file","cluster-node-timeout","appenddirname","aof-timestamp-enabled","sanitize-dump-payload","enable-debug-command","enable-module-command","protected-mode","dual-channel-replication-enabled","replicationid","activedefrag"].forEach(function(k){KNOWN[k]=true;});

var NEEDS_ARG = {"bind":1,"port":1,"tls-port":1,"protected-mode":1,"requirepass":1,"user":1,"rename-command":1,"maxmemory":1,"maxmemory-policy":1,"save":1,"appendonly":1,"replicaof":1,"slaveof":1,"replica-read-only":1,"slave-read-only":1,"dir":1,"dbfilename":1,"logfile":1,"loglevel":1,"aclfile":1,"tls-cert-file":1,"tls-key-file":1,"tls-ca-cert-file":1};

var DANGEROUS = ["FLUSHALL","CONFIG","DEBUG","SHUTDOWN","KEYS"];

function tokenize(line){
  var out=[], m, re=/"([^"]*)"|'([^']*)'|(\S+)/g;
  while((m=re.exec(line))!==null){
    if(m[1]!==undefined) out.push(m[1]);
    else if(m[2]!==undefined) out.push(m[2]);
    else out.push(m[3]);
  }
  return out;
}

function audit(text){
  var findings=[], secrets=[], notParsed=[];
  function add(sev,check,line,detail){ findings.push({severity:sev,check:check,line:line,detail:detail}); }
  function lineRef(n){ return n?("Line "+n):"Not set"; }

  var rawLines = String(text||"").split(/\r?\n/);
  var cfg = {}; // directive -> array of {line, tokens}
  var parsedCount = 0;

  rawLines.forEach(function(raw, idx){
    var n = idx+1;
    var t = raw.trim();
    if(t==="" || t.charAt(0)==="#") return;
    var tokens = tokenize(t);
    if(!tokens.length){ notParsed.push({line:n, word:"(blank token)"}); return; }
    var dir = tokens[0].toLowerCase();
    if(!/^[a-z][a-z0-9-]*$/.test(dir) || !KNOWN[dir]){
      notParsed.push({line:n, word:tokens[0]});
      return;
    }
    if(NEEDS_ARG[dir] && tokens.length<2){
      notParsed.push({line:n, word:tokens[0]});
      return;
    }
    if(dir==="rename-command" && tokens.length<3){
      notParsed.push({line:n, word:tokens[0]});
      return;
    }
    if(dir==="user" && tokens.length<3){
      notParsed.push({line:n, word:tokens[0]});
      return;
    }
    parsedCount++;
    (cfg[dir]=cfg[dir]||[]).push({line:n, tokens:tokens});
  });

  function first(dir){ return cfg[dir] ? cfg[dir][0] : null; }
  function val(dir){ var e=first(dir); return e ? e.tokens[1] : null; }

  // NOT ENOUGH TO GRADE gate
  if(parsedCount < 3){
    return {
      verdict:"NOT ENOUGH TO GRADE",
      why: parsedCount===0
        ? "No recognizable Valkey directives were found. Empty input and plain prose cannot be graded."
        : "Only "+parsedCount+" recognizable Valkey directive(s) found — too little config to grade. Paste a fuller valkey.conf.",
      parsed:parsedCount, notParsed:notParsed, findings:[], secrets:[]
    };
  }

  // --- Bind / protected-mode ---
  var bindE = first("bind");
  var bindTokens = bindE ? bindE.tokens.slice(1) : [];
  var bindStr = bindTokens.join(" ");
  var isPublic = bindTokens.some(function(x){return x==="0.0.0.0"||x==="::"||x==="*";});
  var isLocal = bindTokens.length>0 && bindTokens.every(function(x){return x==="127.0.0.1"||x==="::1"||x==="-::1"||x==="localhost";});
  var pmE = first("protected-mode");
  var pm = pmE ? pmE.tokens[1].toLowerCase() : "yes"; // server default
  if(bindE && isPublic && pm==="no"){
    add("CRITICAL","Bind / protected-mode", lineRef(bindE.line)+" + "+lineRef(pmE.line),
      "bind "+bindStr+" exposes every interface and protected-mode is no. Anyone who can reach the port can try the server with no protected-mode safety net. Bind a specific interface and set protected-mode yes.");
  } else if(bindE && isPublic){
    add("WARNING","Bind / protected-mode", lineRef(bindE.line),
      "bind "+bindStr+" listens on all interfaces. Protected-mode alone is not a firewall — restrict the bind or put a firewall in front of the port.");
  } else if(bindE && isLocal){
    add("PASS","Bind / protected-mode", lineRef(bindE.line),
      "Bind is limited to loopback ("+bindStr+"). Remote clients cannot reach this server directly.");
  } else if(bindE){
    add("INFO","Bind / protected-mode", lineRef(bindE.line),
      "Bind is set to \""+bindStr+"\". Confirm every listed interface is intended to serve Valkey traffic.");
  } else {
    add("INFO","Bind / protected-mode","Not set",
      "No bind directive pasted. Valkey's built-in default binds loopback only, but an explicit bind line makes the intent reviewable.");
  }
  if(pmE && pm==="no" && !(bindE && isPublic)){
    add("WARNING","Bind / protected-mode", lineRef(pmE.line),
      "protected-mode is explicitly no. That safety net should stay on (yes) unless another control replaces it.");
  }

  // --- requirepass ---
  var rpE = first("requirepass");
  var hasAuth = false;
  if(!rpE){
    add("CRITICAL","requirepass","Not set",
      "No requirepass directive. The default user has no password, so authentication depends entirely on network reachability.");
  } else {
    hasAuth = true;
    var rpLen = rpE.tokens[1].length;
    secrets.push({key:"requirepass", line:rpE.line, length:rpLen});
    if(rpLen < 8){
      add("CRITICAL","requirepass", lineRef(rpE.line),
        "requirepass is set but very short (length "+rpLen+" only; value never shown). Short passwords fall to guessing fast — use a long random passphrase.");
    } else if(rpLen < 16){
      add("WARNING","requirepass", lineRef(rpE.line),
        "requirepass is set but modest length ("+rpLen+" characters; value never shown). 16+ random characters is the safer floor.");
    } else {
      add("PASS","requirepass", lineRef(rpE.line),
        "requirepass is set with length "+rpLen+" (value never shown). Length is the only property this text audit judges.");
    }
  }

  // --- ACL users ---
  var userEntries = cfg["user"]||[];
  if(!userEntries.length){
    add("INFO","ACL users","Not set",
      "No ACL user directives pasted. Access rests on the default user and requirepass alone; named ACL users with least-privilege key patterns are the stronger posture.");
  }
  userEntries.forEach(function(e){
    var name = e.tokens[1];
    var rest = e.tokens.slice(2);
    var plain=null, hashed=false, nopass=false;
    rest.forEach(function(tok){
      if(tok.charAt(0)===">" && tok.length>1) plain=tok.slice(1);
      else if(tok.charAt(0)==="#" && tok.length>1) hashed=true;
      else if(tok.toLowerCase()==="nopass") nopass=true;
    });
    if(nopass){
      add("CRITICAL","ACL users", lineRef(e.line),
        "ACL user \""+name+"\" is set to nopass — that account needs no password at all. Remove nopass or disable the user.");
    } else if(plain!==null){
      secrets.push({key:"user "+name+" password (plaintext >)", line:e.line, length:plain.length});
      add("WARNING","ACL users", lineRef(e.line),
        "ACL user \""+name+"\" carries a plaintext password in the config (key: user "+name+", line "+e.line+", length "+plain.length+"; value never shown). Prefer a hashed password (# + SHA-256 hex) so the config file itself is not a credential list.");
    } else if(hashed){
      add("PASS","ACL users", lineRef(e.line),
        "ACL user \""+name+"\" uses a hashed password (# form). The hash itself is not reproduced here.");
    } else {
      add("INFO","ACL users", lineRef(e.line),
        "ACL user \""+name+"\" has no password token this audit can see (no >, #, or nopass). Confirm how that account authenticates.");
    }
  });
  if(first("aclfile")){
    add("INFO","ACL users", lineRef(first("aclfile").line),
      "An external aclfile is configured. Its contents are not in the pasted text, so ACL users defined there are not graded here.");
  }

  // --- TLS / port pairing ---
  var portE = first("port");
  var portV = portE ? parseInt(portE.tokens[1],10) : 6379; // server default when absent
  var tlsE = first("tls-port");
  var tlsV = tlsE ? parseInt(tlsE.tokens[1],10) : 0;
  if(isNaN(portV)) portV = 6379;
  if(isNaN(tlsV)) tlsV = 0;
  if(portV>0 && tlsV>0){
    add("WARNING","TLS / port pairing", lineRef(portE.line)+" + "+lineRef(tlsE.line),
      "Both port "+portV+" (plaintext) and tls-port "+tlsV+" are open. The plaintext door still accepts unencrypted traffic — set port 0 if TLS is meant to be the only way in.");
  } else if(portV>0 && tlsV===0){
    if(isPublic || pm==="no"){
      add("CRITICAL","TLS / port pairing", lineRef(portE.line),
        "port "+portV+" serves plaintext with no tls-port configured, on an exposed bind. Credentials and data cross the network unencrypted. Enable TLS (tls-port + cert/key/CA) or confine the server to a trusted private network.");
    } else {
      add("WARNING","TLS / port pairing", lineRef(portE.line),
        "port "+portV+" serves plaintext and no tls-port is configured. Fine on a sealed loopback/private setup; a network-facing server should speak TLS.");
    }
  } else if(portV===0 && tlsV>0){
    add("PASS","TLS / port pairing", lineRef(tlsE.line),
      "Plaintext port is disabled (port 0) and tls-port "+tlsV+" is the listener. Traffic is TLS-only.");
  } else {
    add("WARNING","TLS / port pairing","Not set",
      "Both port and tls-port resolve to 0/absent in the pasted text — no listener this audit can confirm. Check the effective listener settings before deploying.");
  }

  // --- Dangerous commands ---
  var disabled={}, renamed={};
  (cfg["rename-command"]||[]).forEach(function(e){
    var cmd=e.tokens[1].toUpperCase();
    if(e.tokens[2]==="") disabled[cmd]=e.line; else renamed[cmd]=e.line;
  });
  var stillOn = DANGEROUS.filter(function(c){return !disabled[c] && !renamed[c];});
  var renamedList = DANGEROUS.filter(function(c){return renamed[c];});
  var disabledList = DANGEROUS.filter(function(c){return disabled[c];});
  if(stillOn.length===DANGEROUS.length){
    add((isPublic||!hasAuth)?"CRITICAL":"WARNING","Dangerous commands","No rename-command lines",
      "FLUSHALL, CONFIG, DEBUG, SHUTDOWN, and KEYS all remain available under their real names — no rename-command disables or renames any of them. Any authenticated (or unauthenticated, if auth is missing) client can flush data, rewrite config, or stop the server.");
  } else if(stillOn.length>0){
    add("WARNING","Dangerous commands","Partial rename-command coverage",
      "Still enabled under their real names: "+stillOn.join(", ")+". Disabled: "+(disabledList.join(", ")||"none")+". Renamed: "+(renamedList.join(", ")||"none")+". Disable or rename the rest.");
  } else {
    add("PASS","Dangerous commands", lineRef((cfg["rename-command"]||[])[0].line),
      "Every checked dangerous command (FLUSHALL, CONFIG, DEBUG, SHUTDOWN, KEYS) is disabled or renamed via rename-command."+(renamedList.length?(" Renamed rather than disabled: "+renamedList.join(", ")+"."):""));
  }

  // --- maxmemory / policy ---
  var mmE = first("maxmemory");
  var polE = first("maxmemory-policy");
  var pol = polE ? polE.tokens[1].toLowerCase() : null;
  var mmZero = !mmE || /^0(b|kb|mb|gb)?$/i.test(mmE.tokens[1]);
  if(mmZero){
    add("WARNING","Memory posture", mmE?lineRef(mmE.line):"Not set",
      "maxmemory is "+(mmE?("set to "+mmE.tokens[1]):"not set")+" — the dataset is unbounded and can grow until the host runs out of RAM. Set maxmemory to a deliberate ceiling.");
  }
  if(pol==="noeviction"){
    add("WARNING","Memory posture", lineRef(polE.line),
      "maxmemory-policy is noeviction: at the memory ceiling, writes start erroring instead of evicting. Right for some cache designs, a surprise outage for others — pick an eviction policy (e.g. allkeys-lru) unless noeviction is deliberate.");
  }
  if(!mmZero && pol && pol!=="noeviction"){
    add("PASS","Memory posture", lineRef(mmE.line),
      "maxmemory is set ("+mmE.tokens[1]+") with maxmemory-policy "+pol+". Memory has both a ceiling and an eviction behavior.");
  } else if(!mmZero && !pol){
    add("INFO","Memory posture", lineRef(mmE.line),
      "maxmemory is set ("+mmE.tokens[1]+") but no maxmemory-policy is pasted — the server default (noeviction) applies. Name the policy explicitly so the behavior is a decision, not a default.");
  }

  // --- Persistence ---
  var saveEntries = cfg["save"]||[];
  var saveDisabled = saveEntries.length>0 && saveEntries.every(function(e){return e.tokens.length===2 && e.tokens[1]==="";});
  var savePoints = saveEntries.some(function(e){return e.tokens.length>=3;});
  var aoE = first("appendonly");
  var ao = aoE ? aoE.tokens[1].toLowerCase() : "no"; // server default
  if(ao==="yes"){
    add("PASS","Persistence", lineRef(aoE.line),
      "appendonly is yes — the AOF logs writes for recovery."+(savePoints?" RDB save points are also configured.":""));
  } else if(saveDisabled && ao!=="yes"){
    add("CRITICAL","Persistence", lineRef(saveEntries[0].line)+" + "+(aoE?lineRef(aoE.line):"appendonly not set"),
      "Persistence is fully off: save \"\" disables RDB snapshots and appendonly is not yes. A restart or crash loses the whole dataset. Enable appendonly yes and/or real save points.");
  } else if(savePoints && ao!=="yes"){
    add("WARNING","Persistence", lineRef(saveEntries[0].line),
      "RDB snapshots only (save points set, appendonly not yes). A crash can lose everything written since the last snapshot. appendonly yes narrows that window.");
  } else if(!saveEntries.length && ao!=="yes"){
    add("INFO","Persistence","Not set",
      "No save or appendonly directives pasted. Server defaults apply (RDB save points on, AOF off) — state the persistence posture explicitly in the config.");
  }

  // --- Replica notes ---
  var repE = first("replicaof") || first("slaveof");
  var roE = first("replica-read-only") || first("slave-read-only");
  if(repE){
    if(roE && roE.tokens[1].toLowerCase()==="no"){
      add("WARNING","Replica posture", lineRef(roE.line),
        "This server is a replica (replicaof, "+lineRef(repE.line)+") but replica-read-only is no — clients can write to the replica and it will diverge from its primary. Set replica-read-only yes unless this is a deliberate promotion.");
    } else {
      add("INFO","Replica posture", lineRef(repE.line),
        "This server is configured as a replica (replicaof). replica-read-only is "+(roE?roE.tokens[1]:"at its default (yes)")+" — replicas stay read-only, as expected. (Replica host values are not reproduced in this report.)");
    }
  } else {
    add("INFO","Replica posture","Not set",
      "No replicaof directive — this config describes a primary / standalone server. No replica read-only posture to grade.");
  }

  var crit = findings.filter(function(f){return f.severity==="CRITICAL";}).length;
  var warn = findings.filter(function(f){return f.severity==="WARNING";}).length;
  var verdict, why;
  if(crit>0){ verdict="DO NOT DEPLOY"; why=crit+" critical finding(s) must be fixed before this config faces any network."; }
  else if(warn>0){ verdict="DEPLOY WITH FIXES"; why=warn+" warning(s) to fix — no criticals, but the fixes are the difference between a config and a safe config."; }
  else { verdict="SAFE TO DEPLOY"; why="No criticals and no warnings in the pasted text. This grades the text only — it verifies no live server."; }

  return {verdict:verdict, why:why, parsed:parsedCount, notParsed:notParsed, findings:findings, secrets:secrets};
}

function buildReport(r, whenStr){
  var lines=[];
  lines.push("J-Dawgs Valkey Server Config Safety Auditor(TM) - text audit report");
  lines.push("Run (this browser, offline): "+whenStr);
  lines.push("Scope: text audit only. Verifies no live server. Not a replacement for running Valkey.");
  lines.push("");
  lines.push("VERDICT: "+r.verdict);
  lines.push(r.why);
  lines.push("");
  var crit=r.findings.filter(function(f){return f.severity==="CRITICAL";}).length;
  var warn=r.findings.filter(function(f){return f.severity==="WARNING";}).length;
  var pass=r.findings.filter(function(f){return f.severity==="PASS";}).length;
  var info=r.findings.filter(function(f){return f.severity==="INFO";}).length;
  lines.push("COUNTS: directives parsed "+r.parsed+" | NOT PARSED "+r.notParsed.length+" | critical "+crit+" | warnings "+warn+" | passes "+pass+" | notes "+info);
  lines.push("");
  lines.push("FINDINGS:");
  if(!r.findings.length) lines.push("- (none - not enough recognizable config to grade)");
  r.findings.forEach(function(f){
    lines.push("- ["+f.severity+"] "+f.check+" ("+f.line+"): "+f.detail);
  });
  lines.push("");
  lines.push("SECRETS SEEN (key / line / length only - values never rendered):");
  if(!r.secrets.length) lines.push("- (no secret-bearing keys found in parsed directives)");
  r.secrets.forEach(function(s){
    lines.push("- key \""+s.key+"\", line "+s.line+", length "+s.length);
  });
  lines.push("");
  lines.push("LINES NOT PARSED:");
  if(!r.notParsed.length) lines.push("- (none)");
  r.notParsed.forEach(function(np){
    lines.push("- Line "+np.line+": NOT PARSED (first word: "+np.word+")");
  });
  return lines.join("\n");
}

function buildJson(r, whenStr){
  var crit=r.findings.filter(function(f){return f.severity==="CRITICAL";}).length;
  var warn=r.findings.filter(function(f){return f.severity==="WARNING";}).length;
  var pass=r.findings.filter(function(f){return f.severity==="PASS";}).length;
  var info=r.findings.filter(function(f){return f.severity==="INFO";}).length;
  return {
    tool:"J-Dawgs Valkey Server Config Safety Auditor\u2122",
    scope:"text audit only - verifies no live server - not a replacement for running Valkey",
    run_at_local: whenStr,
    verdict:r.verdict,
    verdict_reason:r.why,
    counts:{directives_parsed:r.parsed, lines_not_parsed:r.notParsed.length, critical:crit, warnings:warn, passes:pass, notes:info},
    findings:r.findings,
    secrets_seen_key_line_length_only:r.secrets,
    not_parsed:r.notParsed.map(function(np){return {line:np.line, status:"NOT PARSED", first_word:np.word};})
  };
}

var lastReport="", lastJson="";
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-valkey-server-config-safety-auditortm',
  name: 'J-Dawgs Valkey Server Config Safety Auditor',
  description: 'Grades a pasted valkey.conf fully offline into one deploy verdict — bind and protected-mode, requirepass, ACL users, TLS, and dangerous commands — with secrets shown by key name, line, and length only, never by value.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
