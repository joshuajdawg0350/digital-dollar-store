'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Wallabag Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Built-in examples ---------- */

      var RISKY_EXAMPLE = [
        "# RISKY SAMPLE — planted problems only. Never deploy a config like this.",
        "parameters:",
        "    secret: this-is-a-secret",
        "    database_url: mysql://wallabag:dbpass123@127.0.0.1:3306/wallabag",
        "    domain_name: http://reading.example.net",
        "    mailer_transport: smtp",
        "    mailer_host: smtp.example.net",
        "    mailer_port: 25",
        "    mailer_user: wallabag@example.net",
        "    mailer_password: smtp-pass-123",
        "    fosuser_registration: true",
        "    app_env: dev",
        "    debug: true",
        "    two_factor: false"
      ].join("\n");

      var HARDENED_EXAMPLE = [
        "# HARDENED SAMPLE — secrets are pulled from the environment at runtime.",
        "parameters:",
        "    secret: '%env(APP_SECRET)%'",
        "    database_url: 'mysql://wallabag:%env(DB_PASS)%@127.0.0.1:3306/wallabag'",
        "    domain_name: https://reading.example.net",
        "    mailer_transport: smtp",
        "    mailer_encryption: tls",
        "    mailer_host: smtp.example.net",
        "    mailer_port: 587",
        "    mailer_user: '%env(MAILER_USER)%'",
        "    mailer_password: '%env(MAILER_PASSWORD)%'",
        "    fosuser_registration: false",
        "    app_env: prod",
        "    debug: false",
        "    two_factor: true"
      ].join("\n");

      /* Every planted problem in the risky example: [check id, exact line]. */
      var RISKY_EXPECTED = [
        ["secret-weak", 3],
        ["database-url-password", 4],
        ["domain-http", 5],
        ["mailer-transport-plaintext", 6],
        ["mailer-host-plaintext", 7],
        ["mailer-port-25", 8],
        ["smtp-user-plaintext", 9],
        ["smtp-password-plaintext", 10],
        ["registration-open", 11],
        ["env-dev", 12],
        ["debug-on", 13],
        ["two-factor-off", 14]
      ];

      /* ---------- Parsing ---------- */

      function cleanValue(v) {
        v = v.replace(/^\s+/, "").replace(/\s+$/, "");
        if (v.length && v.charAt(0) !== '"' && v.charAt(0) !== "'") {
          var hashIdx = v.indexOf(" #");
          if (hashIdx >= 0) v = v.slice(0, hashIdx).replace(/\s+$/, "");
        }
        if (v.length >= 2) {
          var first = v.charAt(0), last = v.charAt(v.length - 1);
          if ((first === '"' && last === '"') || (first === "'" && last === "'")) {
            v = v.slice(1, -1);
          }
        }
        return v.replace(/^\s+/, "").replace(/\s+$/, "");
      }

      function parseConfig(text) {
        var lines = String(text).split(/\r?\n/);
        var entries = [];
        var stack = [];
        for (var i = 0; i < lines.length; i++) {
          var raw = lines[i];
          var trimmed = raw.replace(/^\s+/, "").replace(/\s+$/, "");
          if (!trimmed || trimmed.charAt(0) === "#" || trimmed === "---") continue;
          var indent = raw.length - raw.replace(/^\s+/, "").length;
          var m = trimmed.match(/^([A-Za-z0-9_.\-]+)\s*[:=]\s*(.*)$/);
          if (!m) continue;
          var keyNorm = m[1].toLowerCase().replace(/[.\-]/g, "_");
          while (stack.length && stack[stack.length - 1].indent >= indent) stack.pop();
          var path = [];
          for (var s = 0; s < stack.length; s++) path.push(stack[s].key);
          path.push(keyNorm);
          var value = cleanValue(m[2]);
          entries.push({
            line: i + 1,
            key: keyNorm,
            keyDisplay: m[1],
            value: value,
            path: path
          });
          if (value === "") stack.push({ indent: indent, key: keyNorm });
        }
        return { entries: entries, totalLines: lines.length };
      }

      /* ---------- Helpers ---------- */

      function isEnvRef(v) {
        return /^\$\{[^}]*\}$/.test(v) || /^%env\([^)]*\)%$/.test(v) || /^env\([^)]*\)$/i.test(v);
      }
      function truthy(v) {
        v = String(v).toLowerCase();
        return v === "true" || v === "yes" || v === "on" || v === "1";
      }
      function falsy(v) {
        v = String(v).toLowerCase();
        return v === "false" || v === "no" || v === "off" || v === "0" || v === "disabled";
      }
      /* Password embedded in a URL's userinfo, or null. Never returned to the UI — only its length is. */
      function urlPassword(v) {
        var m = String(v).match(/^[a-zA-Z][a-zA-Z0-9+.\-]*:\/\/([^/?#]*)/);
        if (!m) return null;
        var authority = m[1];
        var at = authority.lastIndexOf("@");
        if (at < 0) return null;
        var userinfo = authority.slice(0, at);
        var colon = userinfo.indexOf(":");
        if (colon < 0) return null;
        var pw = userinfo.slice(colon + 1);
        return pw === "" ? null : pw;
      }
      function urlScheme(v) {
        var m = String(v).match(/^([a-zA-Z][a-zA-Z0-9+.\-]*):\/\//);
        return m ? m[1].toLowerCase() : null;
      }
      function urlPort(v) {
        var m = String(v).match(/^[a-zA-Z][a-zA-Z0-9+.\-]*:\/\/([^/?#]*)/);
        if (!m) return null;
        var authority = m[1];
        var at = authority.lastIndexOf("@");
        var hostport = at >= 0 ? authority.slice(at + 1) : authority;
        var pm = hostport.match(/:(\d+)$/);
        return pm ? pm[1] : null;
      }
      function pathHas(e, name) { return e.path.indexOf(name) >= 0; }

      var SEV_RANK = { critical: 0, high: 1, medium: 2, low: 3 };

      /* ---------- The audit ---------- */

      function auditConfig(text) {
        var parsed = parseConfig(text);
        var entries = parsed.entries;
        var findings = [];
        var recognized = [];

        function recognize(e) {
          if (recognized.indexOf(e.keyDisplay) === -1) recognized.push(e.keyDisplay);
        }
        function add(severity, check, e, valueLength, issue, fix) {
          findings.push({
            severity: severity,
            check: check,
            key: e.keyDisplay,
            line: e.line,
            valueLength: valueLength,
            issue: issue,
            fix: fix
          });
        }

        /* Mailer TLS posture is a cross-line fact: gather it first. */
        var tlsDeclared = false;
        var i, e;
        for (i = 0; i < entries.length; i++) {
          e = entries[i];
          if (e.key === "mailer_encryption") {
            var enc = e.value.toLowerCase();
            if (enc === "tls" || enc === "ssl") tlsDeclared = true;
          }
          if ((e.key === "mailer_url" || e.key === "mailer_dsn")) {
            if (urlScheme(e.value) === "smtps" || /[?&]encryption=(tls|ssl)/i.test(e.value)) tlsDeclared = true;
          }
        }

        for (i = 0; i < entries.length; i++) {
          e = entries[i];
          var key = e.key, val = e.value, lower = val.toLowerCase();

          /* SECRET */
          if (key === "secret" || /_secret$/.test(key)) {
            recognize(e);
            if (val === "") {
              add("critical", "secret-weak", e, 0,
                "SECRET is present but empty — sessions and tokens would be signed with no real secret.",
                "Set SECRET to a random value of at least 32 characters, ideally supplied through an environment variable.");
            } else if (!isEnvRef(val)) {
              var placeholder = /(example|change|default|placeholder|todo|your|xxx|secret)/i.test(val);
              if (val.length < 32 || placeholder) {
                add("critical", "secret-weak", e, val.length,
                  "SECRET is " + (val.length < 32 ? "only " + val.length + " characters long" : "long enough") +
                  (placeholder ? " and reads like a shipped example/placeholder value" : "") +
                  ". A short or example SECRET lets anyone forge sessions and tokens.",
                  "Generate a fresh random SECRET of at least 32 characters (64 is better) and supply it via an environment variable, never committed in the file.");
              }
            }
            continue;
          }

          /* DATABASE_URL */
          if (key === "database_url" || key === "database_dsn") {
            recognize(e);
            var dbPw = urlPassword(val);
            if (dbPw !== null && !isEnvRef(dbPw)) {
              add("critical", "database-url-password", e, dbPw.length,
                "DATABASE_URL embeds a plaintext database password (" + dbPw.length + " characters) in the connection string. Anyone who can read this file owns the database.",
                "Move the password out of the file: reference it from an environment variable (for example %env(DB_PASS)% inside the URL) or use a secrets manager / socket authentication.");
            }
            continue;
          }
          if (key === "database_password") {
            recognize(e);
            if (val !== "" && !isEnvRef(val)) {
              add("high", "database-password-plaintext", e, val.length,
                "A plaintext database password (" + val.length + " characters) sits directly in the config file.",
                "Supply the database password through an environment variable or secrets manager and rotate the exposed one.");
            }
            continue;
          }
          if (key.indexOf("database_") === 0) { recognize(e); continue; }

          /* DOMAIN_NAME */
          if (key === "domain_name" || key === "domain") {
            recognize(e);
            if (lower.indexOf("http://") === 0) {
              add("high", "domain-http", e, val.length,
                "DOMAIN_NAME uses plain http://. Login pages, session cookies, and saved-article links would travel unencrypted, and generated URLs point at the insecure scheme.",
                "Put the site behind HTTPS (a reverse proxy with a valid certificate is fine) and set DOMAIN_NAME to the https:// address.");
            } else if (val !== "" && lower.indexOf("https://") !== 0 && !isEnvRef(val)) {
              add("medium", "domain-no-scheme", e, val.length,
                "DOMAIN_NAME has no https:// scheme, so generated links and redirects may fall back to plain http.",
                "Set DOMAIN_NAME to the full https:// address of the site.");
            }
            continue;
          }

          /* Open registration — flat key */
          if (key === "fosuser_registration" || key === "fos_user_registration") {
            recognize(e);
            if (truthy(val)) {
              add("high", "registration-open", e, val.length,
                "Public registration is switched on. On a self-hosted reading archive, anyone on the internet can create an account and consume the instance.",
                "Set registration to false once your accounts exist, or put registration behind an invite/approval step.");
            }
            continue;
          }
          /* Open registration — nested fos_user: registration: enabled: */
          if (key === "enabled" && (pathHas(e, "fos_user") || pathHas(e, "fosuser")) && pathHas(e, "registration")) {
            recognize(e);
            if (truthy(val)) {
              add("high", "registration-open", e, val.length,
                "fos_user registration is enabled (nested registration.enabled). Anyone can sign up for an account on this instance.",
                "Set fos_user.registration.enabled to false after creating your accounts, or gate signups behind approval.");
            }
            continue;
          }

          /* Two-factor posture — nested two_factor: enabled: */
          if (key === "enabled" && pathHas(e, "two_factor")) {
            recognize(e);
            if (falsy(val)) {
              add("medium", "two-factor-off", e, val.length,
                "Two-factor authentication is disabled in the two_factor block, leaving passwords as the only login barrier.",
                "Enable two-factor authentication, at least for admin accounts.");
            }
            continue;
          }
          if (key === "two_factor" || key.indexOf("two_factor") === 0) {
            recognize(e);
            if (falsy(val)) {
              add("medium", "two-factor-off", e, val.length,
                "Two-factor authentication is switched off, leaving passwords as the only login barrier.",
                "Turn two_factor on and enroll admin accounts before exposing the instance.");
            }
            continue;
          }

          /* Mailer transport / host / port / encryption */
          if (key === "mailer_transport") {
            recognize(e);
            if (lower === "smtp" && !tlsDeclared) {
              add("high", "mailer-transport-plaintext", e, val.length,
                "Mailer transport is smtp with no TLS encryption configured anywhere in the file. Password-reset and notification mail — and the SMTP login itself — cross the network in the clear.",
                "Set mailer_encryption to tls (with port 587) or ssl (with port 465), or use an smtps:// MAILER_URL.");
            }
            continue;
          }
          if (key === "mailer_host") {
            recognize(e);
            if (/smtp/i.test(val) && !tlsDeclared) {
              add("high", "mailer-host-plaintext", e, val.length,
                "mailer_host points at an SMTP server but nothing in the file enables tls/ssl for the connection, so mail is sent unencrypted.",
                "Enable mailer_encryption (tls or ssl) to match the mail provider's secure endpoint.");
            }
            continue;
          }
          if (key === "mailer_port") {
            recognize(e);
            if (val === "25" && !tlsDeclared) {
              add("medium", "mailer-port-25", e, val.length,
                "Mailer port is 25 with no TLS configured — the classic plaintext submission port.",
                "Use port 587 with tls or port 465 with ssl, as your mail provider directs.");
            }
            continue;
          }
          if (key === "mailer_encryption") {
            recognize(e);
            if (lower === "null" || lower === "none" || val === "") {
              add("high", "mailer-encryption-off", e, val.length,
                "mailer_encryption is explicitly off, so SMTP traffic is unencrypted even if the server offers TLS.",
                "Set mailer_encryption to tls or ssl.");
            }
            continue;
          }

          /* SMTP credentials in the clear */
          if (key === "mailer_password" || key === "mailer_pass") {
            recognize(e);
            if (val !== "" && !isEnvRef(val)) {
              add("high", "smtp-password-plaintext", e, val.length,
                "The SMTP password (" + val.length + " characters) is stored in plaintext in the config. A leaked file hands over the mail account.",
                "Supply it via an environment variable (for example '%env(MAILER_PASSWORD)%') and rotate the exposed password.");
            }
            continue;
          }
          if (key === "mailer_user" || key === "mailer_username") {
            recognize(e);
            if (val !== "" && !isEnvRef(val)) {
              add("medium", "smtp-user-plaintext", e, val.length,
                "The SMTP username (" + val.length + " characters) is written in plaintext alongside the mail settings, completing the credential pair for anyone who reads the file.",
                "Supply the mail username through an environment variable as well, and keep it out of version control.");
            }
            continue;
          }

          /* MAILER_URL / MAILER_DSN (env style) */
          if (key === "mailer_url" || key === "mailer_dsn") {
            recognize(e);
            var scheme = urlScheme(val);
            var mPw = urlPassword(val);
            if (mPw !== null && !isEnvRef(mPw)) {
              add("high", "smtp-password-plaintext", e, mPw.length,
                "The mailer URL embeds a plaintext SMTP password (" + mPw.length + " characters).",
                "Reference the password from an environment variable instead of embedding it in the URL, and rotate the exposed one.");
            }
            if (scheme === "smtp" && !tlsDeclared) {
              add("high", "mailer-transport-plaintext", e, val.length,
                "The mailer URL uses the plaintext smtp:// scheme with no encryption parameter, so mail and credentials cross the network unencrypted.",
                "Use smtps:// or add ?encryption=tls with the provider's secure port.");
            } else if (scheme === "smtp" && urlPort(val) === "25" && !/[?&]encryption=/i.test(val)) {
              add("medium", "mailer-port-25", e, val.length,
                "The mailer URL targets port 25 without an explicit encryption parameter.",
                "Use the provider's submission port (587 with tls, or 465 with ssl).");
            }
            continue;
          }
          if (key.indexOf("mailer") === 0) { recognize(e); continue; }

          /* App environment / debug */
          if (key === "app_env" || key === "symfony_env") {
            recognize(e);
            if (lower === "dev") {
              add("high", "env-dev", e, val.length,
                "The application environment is set to dev. Dev mode exposes stack traces, profiler data, and verbose errors to visitors.",
                "Set the environment to prod for deployment and clear the cache after changing it.");
            }
            continue;
          }
          if (key === "debug" || key === "app_debug" || key === "kernel_debug") {
            recognize(e);
            if (truthy(val)) {
              add("medium", "debug-on", e, val.length,
                "Debug mode is on. Debug output leaks file paths, configuration values, and stack traces.",
                "Set debug to false for any deployment reachable by other people.");
            }
            continue;
          }

          /* fos_user block headers and other fos keys still count as recognized */
          if (key === "fos_user" || key === "fosuser" || pathHas(e, "fos_user") || pathHas(e, "fosuser")) {
            recognize(e);
            continue;
          }
        }

        findings.sort(function (a, b) {
          if (SEV_RANK[a.severity] !== SEV_RANK[b.severity]) return SEV_RANK[a.severity] - SEV_RANK[b.severity];
          return a.line - b.line;
        });

        var counts = { critical: 0, high: 0, medium: 0, low: 0 };
        for (i = 0; i < findings.length; i++) counts[findings[i].severity]++;

        var verdict;
        if (entries.length === 0 || recognized.length === 0) verdict = "NOT ENOUGH TO GRADE";
        else if (counts.critical > 0) verdict = "DO NOT DEPLOY";
        else if (findings.length > 0) verdict = "DEPLOY WITH FIXES";
        else verdict = "SAFE TO DEPLOY";

        return {
          verdict: verdict,
          findings: findings,
          counts: counts,
          recognized: recognized,
          totalLines: parsed.totalLines,
          entryCount: entries.length
        };
      }

      /* ---------- Report builders (secret values never enter either) ---------- */

      function buildTextReport(result) {
        var out = [];
        out.push("J-Dawgs Wallabag Server Config Safety Auditor — Report");
        out.push("Verdict: " + result.verdict);
        out.push("Lines scanned: " + result.totalLines +
          " · Recognized keys: " + result.recognized.length +
          " · Critical: " + result.counts.critical +
          " · High: " + result.counts.high +
          " · Medium: " + result.counts.medium +
          " · Low: " + result.counts.low);
        out.push("Findings list key name, line number, and value length only. Secret values are never printed.");
        out.push("");
        if (result.verdict === "NOT ENOUGH TO GRADE") {
          out.push("No recognizable Wallabag configuration keys were found in the input, so there is nothing to grade.");
        } else if (result.findings.length === 0) {
          out.push("No problems found. Every recognized setting passed its check.");
        } else {
          for (var i = 0; i < result.findings.length; i++) {
            var f = result.findings[i];
            out.push("[" + f.severity.toUpperCase() + "] " + f.key + " — line " + f.line + " — value length " + f.valueLength);
            out.push("  Issue: " + f.issue);
            out.push("  Fix: " + f.fix);
            out.push("");
          }
        }
        return out.join("\n");
      }

      function buildJson(result) {
        return JSON.stringify({
          tool: "J-Dawgs Wallabag Server Config Safety Auditor",
          verdict: result.verdict,
          lines_scanned: result.totalLines,
          recognized_keys: result.recognized,
          counts: result.counts,
          findings: result.findings.map(function (f) {
            return {
              severity: f.severity,
              check: f.check,
              key: f.key,
              line: f.line,
              value_length: f.valueLength,
              issue: f.issue,
              fix: f.fix
            };
          }),
          note: "Secret values are never included. Findings carry key name, line number, and value length only."
        }, null, 2);
      }

      /* ---------- UI wiring ---------- */

      var lastResult = null;
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-wallabag-server-config-safety-auditortm',
  name: 'J-Dawgs Wallabag Server Config Safety Auditor',
  description: 'Host tools only tell you the server started; ours grades a pasted Wallabag parameters/env config offline into one deploy verdict — secrets by key name/line/length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
