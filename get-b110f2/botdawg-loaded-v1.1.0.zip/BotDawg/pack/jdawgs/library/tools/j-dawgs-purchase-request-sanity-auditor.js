'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Purchase Request Sanity Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var SUB_WORDS = ["subscription", "per month", "/mo", "trial", "renews", "auto-renew"];

        var WORKED_BAD =
          "budget: $100\n" +
          "USB cable | 2 | $9.99\n" +
          "USB cable | 1 | $9.99\n" +
          "Widget Pro subscription | 1 | $79.99";

        var WORKED_GOOD =
          "budget: $200\n" +
          "deliver to: Dock 2, 1180 Industrial Pkwy, Springfield MO\n" +
          "needed by: 2026-12-15\n" +
          "HDMI cable | 2 | $12.50\n" +
          "Notebook | 5 | $3.99\n" +
          "Desk lamp | 1 | $24.99";

        var $ = function (id) { return document.getElementById(id); };
        var reqEl = $("req"), refEl = $("refDate");

        function todayISO() {
          var d = new Date();
          var m = String(d.getMonth() + 1).padStart(2, "0");
          var day = String(d.getDate()).padStart(2, "0");
          return d.getFullYear() + "-" + m + "-" + day;
        }
        refEl.value = todayISO();

        function money(cents) {
          var neg = cents < 0;
          var abs = Math.abs(Math.round(cents));
          var dollars = Math.floor(abs / 100);
          var c = abs % 100;
          var ds = String(dollars).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
          return (neg ? "-$" : "$") + ds + "." + String(c).padStart(2, "0");
        }

        function parseMoneyToCents(text) {
          if (text == null) return null;
          var t = String(text).replace(/[$,\s]/g, "");
          if (!/^-?\d+(\.\d{1,2})?$/.test(t)) return null;
          var v = parseFloat(t);
          if (!isFinite(v)) return null;
          return Math.round(v * 100);
        }

        function parseDate(text) {
          if (!text) return null;
          var t = String(text).trim();
          var m = t.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
          if (!m) m = t.match(/^(\d{1,2})[\/](\d{1,2})[\/](\d{4})/) && (function (mm) {
            return [mm[0], mm[3], mm[1], mm[2]];
          })(t.match(/^(\d{1,2})[\/](\d{1,2})[\/](\d{4})/));
          if (!m) {
            var d = new Date(t);
            if (!isNaN(d.getTime())) return new Date(d.getFullYear(), d.getMonth(), d.getDate());
            return null;
          }
          return new Date(parseInt(m[1], 10), parseInt(m[2], 10) - 1, parseInt(m[3], 10));
        }

        function fmtDate(d) {
          return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
        }

        function audit(text, refDateStr) {
          var findings = []; // {sev: blocker|warning|flag, msg}
          var lines = [];
          var budgetCents = null, deliverTo = null, neededByRaw = null, neededByDate = null;
          var rawLines = String(text).split(/\r?\n/);

          rawLines.forEach(function (raw, idx) {
            var lineNo = idx + 1;
            var t = raw.trim();
            if (!t) return;
            var low = t.toLowerCase();
            var hm;
            if ((hm = low.match(/^budget\s*:\s*(.*)$/))) {
              var b = parseMoneyToCents(hm[1]);
              if (b == null) findings.push({ sev: "warning", msg: "Line " + lineNo + ": budget header is present but “" + hm[1].trim() + "” is not a parseable amount, so no budget check was run." });
              else budgetCents = b;
              return;
            }
            if ((hm = low.match(/^deliver\s+to\s*:\s*(.*)$/))) { deliverTo = t.slice(t.indexOf(":") + 1).trim(); return; }
            if ((hm = low.match(/^needed\s+by\s*:\s*(.*)$/))) {
              neededByRaw = hm[1].trim();
              neededByDate = parseDate(neededByRaw);
              return;
            }
            // item line
            var parts = t.split("|").map(function (s) { return s.trim(); });
            var entry = { lineNo: lineNo, name: parts[0] || t, qty: null, unitCents: null, lineCents: null, unpriced: false, malformed: false, traps: [], dupOf: null };
            if (parts.length < 3) {
              entry.malformed = true; entry.unpriced = true;
              findings.push({ sev: "warning", msg: "Line " + lineNo + " (“" + entry.name + "”): not in “item | quantity | unit price” form — UNPRICED, excluded from the total." });
            } else {
              var q = parseFloat(parts[1].replace(/,/g, ""));
              if (isFinite(q)) entry.qty = q;
              else findings.push({ sev: "warning", msg: "Line " + lineNo + " (“" + entry.name + "”): quantity “" + parts[1] + "” is not a number — line excluded from the total." });
              entry.unitCents = parseMoneyToCents(parts[2]);
              if (entry.unitCents == null) {
                entry.unpriced = true;
                findings.push({ sev: "warning", msg: "Line " + lineNo + " (“" + entry.name + "”): no parseable unit price — UNPRICED, excluded from the total." });
              }
              if (entry.qty != null && entry.unitCents != null) entry.lineCents = Math.round(entry.qty * entry.unitCents);
            }
            // subscription trap words
            var nameLow = entry.name.toLowerCase();
            SUB_WORDS.forEach(function (w) { if (nameLow.indexOf(w) !== -1) entry.traps.push(w); });
            if (entry.traps.length) {
              findings.push({ sev: "flag", msg: "Line " + lineNo + " (“" + entry.name + "”): SUBSCRIPTION TRAP — the item name contains “" + entry.traps.join("”, “") + "”. A one-time buy request must not silently become a recurring charge. Confirm this is really a one-time purchase before buying." });
            }
            // quantity sanity
            if (entry.qty != null && entry.qty > 20) {
              findings.push({ sev: "warning", msg: "Line " + lineNo + " (“" + entry.name + "”): QUANTITY SANITY — quantity " + entry.qty + " is over 20 on a single line. That is never silently accepted: confirm the count is intended, not a typo." });
            }
            lines.push(entry);
          });

          // duplicates: exact name match ignoring case/whitespace
          var seen = {};
          lines.forEach(function (e) {
            var key = e.name.toLowerCase().replace(/\s+/g, " ").trim();
            if (seen[key]) {
              e.dupOf = seen[key].lineNo;
              findings.push({ sev: "warning", msg: "Lines " + seen[key].lineNo + " and " + e.lineNo + ": DUPLICATE ITEM — “" + seen[key].name + "” appears on both lines. Merge them or confirm both are really wanted." });
            } else seen[key] = e;
          });

          var totalCents = 0, anyPriced = false, anyUnpriced = false;
          lines.forEach(function (e) {
            if (e.lineCents != null) { totalCents += e.lineCents; anyPriced = true; }
            if (e.unpriced || e.lineCents == null) anyUnpriced = true;
          });
          var partial = anyUnpriced && lines.length > 0;

          // budget blocker
          var overBy = null;
          if (budgetCents != null && anyPriced && totalCents > budgetCents) {
            overBy = totalCents - budgetCents;
            findings.push({ sev: "blocker", msg: "OVER BUDGET — the computed total " + money(totalCents) + (partial ? " (PARTIAL)" : "") + " exceeds the budget of " + money(budgetCents) + " by " + money(overBy) + ". Do not buy until the request or the budget changes." });
          }

          // delivery warning
          if (!deliverTo) {
            findings.push({ sev: "warning", msg: "MISSING DELIVERY — no “deliver to:” header. Add where this order goes before buying; an order with no destination is a return waiting to happen." });
          }

          // needed-by blocker
          var refDate = parseDate(refDateStr) || new Date();
          refDate = new Date(refDate.getFullYear(), refDate.getMonth(), refDate.getDate());
          var neededPast = false;
          if (neededByRaw != null) {
            if (!neededByDate) {
              findings.push({ sev: "warning", msg: "“needed by: " + neededByRaw + "” could not be read as a date, so the deadline was not checked." });
            } else if (neededByDate < refDate) {
              neededPast = true;
              findings.push({ sev: "blocker", msg: "DEADLINE PASSED — “needed by” date " + fmtDate(neededByDate) + " is in the past against the reference date " + fmtDate(refDate) + ". The request as written cannot be met; fix the date or drop the deadline." });
            }
          }

          var blockers = findings.filter(function (f) { return f.sev === "blocker"; }).length;
          var others = findings.length - blockers;
          var verdict, cls;
          if (!lines.length) { verdict = "NOTHING TO AUDIT"; cls = "warn"; }
          else if (blockers) { verdict = "DO NOT BUY YET"; cls = "bad"; }
          else if (others) { verdict = "BUY WITH FIXES"; cls = "warn"; }
          else { verdict = "SAFE TO BUY"; cls = "ok"; }

          return {
            findings: findings, lines: lines, totalCents: totalCents, budgetCents: budgetCents,
            deliverTo: deliverTo, neededByRaw: neededByRaw, neededByDate: neededByDate,
            neededPast: neededPast, partial: partial, anyPriced: anyPriced,
            verdict: verdict, cls: cls, blockers: blockers, others: others, refDate: refDate
          };
        }

        function esc(s) {
          return String(s).replace(/[&<>"']/g, function (c) {
            return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
          });
        }

        function render(r) {
          var box = $("results");
          box.classList.add("show");
          var vb = $("verdictBox");
          vb.className = "verdict " + r.cls;
          $("verdictWord").textContent = r.verdict;
          $("verdictTotal").textContent = r.lines.length
            ? "Total: " + money(r.totalCents) + (r.partial ? " (PARTIAL)" : "")
            : "";
          var sub;
          if (!r.lines.length) sub = "No item lines were found. Paste lines in “item | quantity | unit price” form.";
          else if (r.cls === "bad") sub = r.blockers + " blocker" + (r.blockers === 1 ? "" : "s") + " must be resolved before any money moves." + (r.others ? " " + r.others + " more finding" + (r.others === 1 ? "" : "s") + " below." : "");
          else if (r.cls === "warn") sub = "No blockers, but " + r.others + " finding" + (r.others === 1 ? "" : "s") + " need a fix or a conscious sign-off first.";
          else sub = "Arithmetic checks out, the request is internally consistent, and every required header is present.";
          $("verdictSub").textContent = sub;

          var stats = "";
          stats += '<div class="stat"><div class="k">Computed total</div><div class="v">' + money(r.totalCents) + (r.partial ? " *" : "") + '</div><div class="n">' + (r.partial ? "*PARTIAL — unpriced lines excluded" : "All lines priced") + "</div></div>";
          if (r.budgetCents != null) {
            var over = r.totalCents > r.budgetCents;
            stats += '<div class="stat' + (over ? " over" : "") + '"><div class="k">Budget</div><div class="v">' + money(r.budgetCents) + '</div><div class="n">' + (over ? "Over by " + money(r.totalCents - r.budgetCents) : money(r.budgetCents - r.totalCents) + " of headroom") + "</div></div>";
          } else {
            stats += '<div class="stat"><div class="k">Budget</div><div class="v">—</div><div class="n">No budget header given</div></div>';
          }
          stats += '<div class="stat"><div class="k">Deliver to</div><div class="v" style="font-family:inherit;font-size:15px;">' + (r.deliverTo ? esc(r.deliverTo) : "Missing") + '</div><div class="n">' + (r.neededByRaw ? "Needed by " + esc(r.neededByRaw) : "No deadline given") + "</div></div>";
          $("totalsRow").innerHTML = stats;

          var fl = $("findingsList");
          if (!r.findings.length && r.lines.length) {
            fl.innerHTML = '<li class="finding clean"><span class="tag">Clean</span>No findings. Every line is priced, quantities are sane, no duplicates, no recurring-charge wording, delivery and dates are in order.</li>';
          } else {
            fl.innerHTML = r.findings.map(function (f) {
              var tag = f.sev === "blocker" ? "Blocker" : (f.sev === "flag" ? "Subscription trap" : "Warning");
              return '<li class="finding ' + f.sev + '"><span class="tag">' + tag + "</span>" + esc(f.msg) + "</li>";
            }).join("");
          }

          var tb = $("lineBody");
          tb.innerHTML = r.lines.map(function (e) {
            var badges = "";
            if (e.unpriced) badges += '<span class="badge unpriced">Unpriced</span>';
            if (e.traps.length) badges += '<span class="badge trap">Subscription wording</span>';
            if (e.dupOf) badges += '<span class="badge dup">Dup of line ' + e.dupOf + "</span>";
            return "<tr><td>" + e.lineNo + "</td><td>" + esc(e.name) + badges + "</td>" +
              '<td class="num" data-k="Qty">' + (e.qty == null ? "—" : e.qty) + "</td>" +
              '<td class="num" data-k="Unit">' + (e.unitCents == null ? "—" : money(e.unitCents)) + "</td>" +
              '<td class="num" data-k="Line total">' + (e.lineCents == null ? "—" : money(e.lineCents)) + "</td></tr>";
          }).join("");
          $("lineFoot").innerHTML = "<tr><td></td><td>Grand total" + (r.partial ? " (PARTIAL — unpriced lines excluded)" : "") + '</td><td></td><td></td><td class="num">' + money(r.totalCents) + "</td></tr>";

          $("checklistBox").textContent = buildChecklist(r);
        }

        function buildChecklist(r) {
          var out = [];
          out.push("PRE-BUY CHECKLIST — J-Dawgs Purchase Request Sanity Auditor™");
          out.push("Verdict: " + r.verdict);
          out.push("");
          function line(ok, text) { out.push((ok ? "[x] " : "[ ] ") + text); }
          if (r.budgetCents != null) {
            line(r.totalCents <= r.budgetCents, "Total " + money(r.totalCents) + (r.partial ? " (PARTIAL)" : "") + " is within the budget of " + money(r.budgetCents) + (r.totalCents > r.budgetCents ? " — OVER by " + money(r.totalCents - r.budgetCents) : ""));
          } else {
            line(false, "Budget stated in the request (none given — add a “budget:” line)");
          }
          var dups = r.lines.filter(function (e) { return e.dupOf; });
          line(!dups.length, "No duplicate items" + (dups.length ? " — duplicates: " + dups.map(function (e) { return "“" + e.name + "” (lines " + e.dupOf + " & " + e.lineNo + ")"; }).join(", ") : ""));
          var traps = r.lines.filter(function (e) { return e.traps.length; });
          line(!traps.length, "No subscription / trial-that-converts wording" + (traps.length ? " — flagged: " + traps.map(function (e) { return "line " + e.lineNo + " “" + e.name + "”"; }).join(", ") : ""));
          var unp = r.lines.filter(function (e) { return e.unpriced || e.lineCents == null; });
          line(!unp.length, "Every line has a price" + (unp.length ? " — unpriced: " + unp.map(function (e) { return "line " + e.lineNo + " “" + e.name + "”"; }).join(", ") + " (excluded from the total)" : ""));
          var big = r.lines.filter(function (e) { return e.qty != null && e.qty > 20; });
          line(!big.length, "All quantities are 20 or under, or confirmed intentional" + (big.length ? " — over 20: " + big.map(function (e) { return "line " + e.lineNo + " “" + e.name + "” × " + e.qty; }).join(", ") : ""));
          line(!!r.deliverTo, "Delivery destination stated" + (r.deliverTo ? ": " + r.deliverTo : " — MISSING (“deliver to:” header)"));
          if (r.neededByRaw) line(!r.neededPast && !!r.neededByDate, "“Needed by” date (" + r.neededByRaw + ") is not in the past" + (r.neededPast ? " — it is past as of " + fmtDate(r.refDate) : ""));
          out.push("[ ] Live price, stock, and seller legitimacy confirmed with the seller (this audit checks arithmetic and consistency only — it cannot verify those).");
          return out.join("\n");
        }

        function run() {
          render(audit(reqEl.value, refEl.value || todayISO()));
        }

        function toast(msg) {
          var t = $("toast");
          t.textContent = msg;
          t.classList.add("show");
          setTimeout(function () { t.classList.remove("show"); }, 2200);
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-purchase-request-sanity-auditor',
  name: 'J-Dawgs Purchase Request Sanity Auditor',
  description: 'Sanity-checks a pasted purchase request — duplicates, quantity slips, totals vs budget, subscription traps, missing delivery — and returns one verdict (SAFE TO BUY / BUY WITH FIXES / DO NOT BUY YET) before any money moves.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
