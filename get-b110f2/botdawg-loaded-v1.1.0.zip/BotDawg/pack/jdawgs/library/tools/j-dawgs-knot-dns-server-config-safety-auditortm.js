'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Knot DNS Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

var RISKY = [
"server:",
"  listen: 0.0.0.0@53",
"  listen: ::@53",
"",
"control:",
"  listen: 0.0.0.0@953",
"  password: \"hunter2\"",
"",
"key:",
"  - id: transfer-key",
"    algorithm: hmac-sha256",
"    secret: \"abc123\"",
"",
"acl:",
"  - id: open-transfer",
"    address: 0.0.0.0/0",
"    action: transfer",
"",
"zone:",
"  - domain: example.com",
"    dnssec-signing: off",
"    file: example.com.zone",
"",
"template:",
"  - id: default",
"    rrl: off",
"    statistics: on",
"    version: \"Knot DNS 3.3.5\""
].join("\n");

var HARDENED = [
"server:",
"  listen: 127.0.0.1@53",
"  listen: 192.0.2.53@53",
"",
"control:",
"  listen: 127.0.0.1@953",
"",
"key:",
"  - id: transfer-key",
"    algorithm: hmac-sha256",
"    secret: \"k9fJ2mQx7LpR4vN8sT1wY6zA3bC5dE0fG2hJ4kL6mN8pQ0rS2tU4vW6xY8zA0bC2dE4f\"",
"",
"acl:",
"  - id: trusted-transfer",
"    address: 192.0.2.10/32",
"    action: transfer",
"    key: transfer-key",
"",
"zone:",
"  - domain: example.com",
"    dnssec-signing: on",
"    acl: trusted-transfer",
"",
"template:",
"  - id: default",
"    rrl: on",
"    statistics: off"
].join("\n");

var KNOWN_KEYS = {
  "server":1,"listen":1,"control":1,"acl":1,"key":1,"zone":1,"template":1,"remote":1,
  "address":1,"action":1,"secret":1,"algorithm":1,"id":1,"domain":1,"file":1,
  "dnssec-signing":1,"dnssec":1,"statistics":1,"rrl":1,"version":1,"notify":1,
  "master":1,"allow-transfer":1,"password":1,"api-key":1,"token":1,"storage":1,
  "journal":1,"zonefile-sync":1,"semantic-checks":1,"serial-policy":1,"kasp-db":1,
  "manual":1,"nsec3":1,"cds-cdnskey-publish":1,"rate-limit":1,"chaos":1,"user":1,"group":1
};
var TOP_SECTIONS = {"server":1,"control":1,"acl":1,"key":1,"zone":1,"template":1,"remote":1,"log":1,"statistics":1,"policy":1,"submission":1,"mod-rrl":1};

function stripQuotes(v){
  v = v.trim();
  if ((v.charAt(0)==='"' && v.charAt(v.length-1)==='"') || (v.charAt(0)==="'" && v.charAt(v.length-1)==="'")){
    return v.slice(1,-1);
  }
  return v;
}
function isTruthy(v){ v=stripQuotes(v).toLowerCase(); return v==="on"||v==="true"||v==="yes"||v==="1"; }
function isFalsy(v){ v=stripQuotes(v).toLowerCase(); return v==="off"||v==="false"||v==="no"||v==="0"; }
function isLoopback(addr){
  addr = addr.trim().toLowerCase();
  return addr==="127.0.0.1"||addr==="::1"||addr==="[::1]"||addr==="localhost"||addr.indexOf("127.")===0;
}
function isWildcardAddr(addr){
  addr = addr.trim().toLowerCase();
  return addr==="0.0.0.0"||addr==="::"||addr==="[::]"||addr==="*"||addr==="any";
}
function isWildcardNet(v){
  v = stripQuotes(v).trim().toLowerCase();
  return v==="0.0.0.0/0"||v==="::/0"||v==="[::]/0"||v==="any"||v==="0.0.0.0"||v==="::";
}

function audit(text){
  var findings = [];
  var notParsed = [];
  function add(sev, line, key, message, fix){
    findings.push({severity:sev, line:line, key:key, message:message, fix:fix});
  }

  if (!text || !text.trim()){
    return {verdict:"NOT ENOUGH TO GRADE", reason:"The paste is empty. Paste a knot.conf-style configuration to grade it.", counts:emptyCounts(), findings:[], notParsed:[]};
  }

  var rawLines = text.split(/\r?\n/);

  // Pre-scan: recognizable keys + ACL posture
  var recognizable = 0;
  var hasRestrictedAcl = false;
  var scanSection = "";
  rawLines.forEach(function(raw){
    var t = raw.trim();
    if (!t || t.charAt(0)==="#") return;
    var m = t.match(/^([A-Za-z0-9_\-\.]+)\s*:/);
    var keyName = null;
    if (m) keyName = m[1].toLowerCase();
    else {
      var lm = t.match(/^-\s+([A-Za-z0-9_\-\.]+)\s*:/);
      if (lm) keyName = lm[1].toLowerCase();
    }
    if (raw.charAt(0)!==" " && raw.charAt(0)!=="\t" && m && TOP_SECTIONS[m[1].toLowerCase()]) scanSection = m[1].toLowerCase();
    if (keyName && KNOWN_KEYS[keyName]) recognizable++;
    if (scanSection==="acl" && keyName==="address"){
      var val = t.slice(t.indexOf(":")+1);
      if (!isWildcardNet(val)) hasRestrictedAcl = true;
    }
  });

  if (recognizable===0){
    // Still collect NOT PARSED lines for transparency
    rawLines.forEach(function(raw, idx){
      var t = raw.trim();
      if (!t || t.charAt(0)==="#") return;
      notParsed.push({line: idx+1, key:"(unrecognized)"});
    });
    return {verdict:"NOT ENOUGH TO GRADE", reason:"No recognizable Knot keys (server:, listen:, control:, acl:, key:, zone:, template:) were found in this paste. It may be prose or a different server's config.", counts:countsFrom(findings, notParsed), findings:[], notParsed:notParsed};
  }

  var section = "";
  var lastZoneDomain = "";
  var inZoneItemDomain = "";

  rawLines.forEach(function(raw, idx){
    var lineNo = idx+1;
    var t = raw.trim();
    if (!t || t.charAt(0)==="#") return;

    // Parseability: list item, key: value, or key:
    var isList = /^-\s+/.test(t);
    var kv = t.match(/^(?:-\s+)?([A-Za-z0-9_\-\.\/\[\]]+)\s*:\s*(.*)$/);
    if (!kv && !isList){
      notParsed.push({line:lineNo, key:"(unparsed line)"});
      return;
    }
    if (isList && !kv){
      // A bare list value like "- 192.0.2.10@53" — parseable as a value, check context below via raw text
      var bareVal = t.replace(/^-\s+/,"");
      if (section==="server" && /@53\b/.test(bareVal) && (bareVal.indexOf("0.0.0.0")===0 || bareVal.indexOf("::")===0)){
        if (!hasRestrictedAcl) add("BLOCKER", lineNo, "listen", "Listen address is bound to all interfaces on port 53 with no access control restricting who can query.", "Bind listen to specific addresses, or add an acl that restricts queries to trusted networks only.");
        else add("HIGH", lineNo, "listen", "Listen address is bound to all interfaces on port 53.", "Confirm the acl genuinely restricts queries; prefer binding listen to specific addresses.");
      }
      return;
    }

    var key = kv[1].toLowerCase();
    var value = (kv[2]||"").trim();
    var indent = raw.length - raw.replace(/^\s+/,"").length;

    if (indent===0 && TOP_SECTIONS[key]) section = key;
    if (indent===0 && !TOP_SECTIONS[key] && value==="") { /* unknown top-level: keep section */ }

    // ---- Secrets first: never echo the value anywhere ----
    if (key==="secret"){
      var secretVal = stripQuotes(value);
      var len = secretVal.length;
      var lower = secretVal.toLowerCase();
      var exampleLike = lower==="abc123"||lower.indexOf("example")>-1||lower.indexOf("changeme")>-1||lower==="secret"||lower==="password"||lower.indexOf("test")===0;
      if (len < 32 || exampleLike){
        add("HIGH", lineNo, "secret", "TSIG secret is weak: its value is only " + len + " characters long" + (exampleLike ? " and matches an example-style pattern" : "") + ". (Value not shown.)", "Generate a long random secret (for example with keymgr or a password generator — 32+ characters, ideally a full base64 key) and distribute it only over a trusted channel.");
      } else {
        add("INFO", lineNo, "secret", "TSIG secret present, value length " + len + " characters. (Value not shown.)", "No action needed on length. Rotate it if it has ever been shared in plain text.");
      }
      return;
    }
    if (key==="password" || key==="api-key" || key==="api_key" || key==="token" || key==="credentials"){
      var credLen = stripQuotes(value).length;
      if (credLen > 0){
        add("HIGH", lineNo, key, "Plaintext credential stored in the config: key \"" + key + "\" holds a value " + credLen + " characters long, in clear text. (Value not shown.)", "Move the credential out of the pasted/shared config into a root-only file or secret store, restrict the config file's permissions, and rotate the credential if this paste was ever shared.");
      }
      return;
    }

    // ---- Server listen ----
    if (section==="server" && key==="listen"){
      var addrPart = value.split("@")[0].replace(/[\[\]"']/g,"").trim();
      var portPart = value.indexOf("@")>-1 ? value.split("@")[1] : "";
      if (isWildcardAddr(addrPart)){
        if (!hasRestrictedAcl){
          add("BLOCKER", lineNo, "listen", "Server listens on all interfaces (" + addrPart + (portPart ? "@"+portPart.replace(/[^0-9]/g,"") : "") + ") with no access control restricting who can query it. Anyone on the network can use this server.", "Bind listen to the specific addresses that should serve, and/or add an acl section that restricts queries to trusted networks.");
        } else {
          add("HIGH", lineNo, "listen", "Server listens on all interfaces (" + addrPart + "). An acl exists, but a wildcard bind still exposes the service on every interface.", "Prefer binding listen to specific addresses even when an acl is present — defense in depth.");
        }
      } else if (addrPart){
        add("INFO", lineNo, "listen", "Server listen is bound to a specific address (" + addrPart + "), not all interfaces.", "No action needed.");
      }
      return;
    }

    // ---- Control listen ----
    if (section==="control" && key==="listen"){
      var cAddr = value.split("@")[0].replace(/[\[\]"']/g,"").trim();
      // Unix socket paths contain "/" — treat as local
      if (value.indexOf("/")===0 || cAddr.indexOf("/")>-1){
        add("INFO", lineNo, "listen (control)", "Control interface uses a local socket path, not a network address.", "No action needed. Keep the socket directory root-only.");
      } else if (isLoopback(cAddr)){
        add("INFO", lineNo, "listen (control)", "Control interface is bound to loopback only.", "No action needed.");
      } else {
        add("BLOCKER", lineNo, "listen (control)", "Remote control interface is exposed beyond localhost (bound to " + (isWildcardAddr(cAddr) ? "all interfaces" : "a non-loopback address") + "). Knot's control channel can reload zones, reconfigure, and stop the server — anyone who can reach it owns the daemon.", "Bind control listen to 127.0.0.1 (or ::1) or a Unix socket, and firewall the control port from every other network.");
      }
      return;
    }

    // ---- ACL entries ----
    if (section==="acl" && key==="address"){
      if (isWildcardNet(value)){
        add("BLOCKER", lineNo, "address (acl)", "ACL entry matches any address (" + stripQuotes(value) + "). Combined with a transfer or notify action, this hands the zone to the whole network.", "Restrict this ACL to the exact secondary / notifier addresses (for example a single /32) and require the TSIG key for transfers.");
      }
      return;
    }
    if (key==="allow-transfer" || key==="allow-notify"){
      if (isWildcardNet(value) || /any/i.test(value)){
        add("BLOCKER", lineNo, key, "Zone transfer / notify setting is open to any address.", "Restrict it to named secondaries by address and TSIG key.");
      }
      return;
    }

    // ---- Zone context + DNSSEC ----
    if (section==="zone" && key==="domain"){ inZoneItemDomain = stripQuotes(value); lastZoneDomain = inZoneItemDomain; return; }
    if (key==="dnssec-signing"){
      var dom = inZoneItemDomain || lastZoneDomain || "this zone";
      var internal = /\.(local|internal|lan|home|corp)$/i.test(dom);
      if (isFalsy(value)){
        if (internal){
          add("LOW", lineNo, "dnssec-signing", "DNSSEC signing is off for " + dom + ", which looks like an internal zone.", "Fine for a purely internal zone. If this zone is ever published, turn dnssec-signing on first.");
        } else {
          add("HIGH", lineNo, "dnssec-signing", "DNSSEC signing is off for " + dom + ", a zone served publicly. Resolvers cannot validate its answers, so spoofed answers are indistinguishable from real ones.", "Set dnssec-signing: on for this zone (with a signing policy / KASP), publish the DS record at the parent, and monitor re-signing.");
        }
      } else if (isTruthy(value)){
        add("INFO", lineNo, "dnssec-signing", "DNSSEC signing is on for " + dom + ".", "No action needed. Keep the DS record at the parent in sync after any key rollover.");
      }
      return;
    }

    // ---- RRL ----
    if (key==="rrl" || key==="rate-limit"){
      if (isFalsy(value)){
        add("MEDIUM", lineNo, key, "Response rate limiting is off. An authoritative server without RRL can be used to amplify reflected traffic toward third parties.", "Turn rrl on (template or mod-rrl) with conservative slip settings, then watch logs for legitimate resolvers being limited.");
      } else if (isTruthy(value)){
        add("INFO", lineNo, key, "Response rate limiting is on.", "No action needed.");
      }
      return;
    }

    // ---- Statistics / version / CHAOS ----
    if (key==="statistics"){
      if (isTruthy(value)){
        add("MEDIUM", lineNo, "statistics", "Statistics collection / exposure is switched on. Query statistics can leak what clients ask for and confirm the server is a live Knot instance.", "Turn statistics off unless you actively use them, and never expose a statistics endpoint beyond localhost.");
      }
      return;
    }
    if (key==="version"){
      var vv = stripQuotes(value);
      if (vv && !isFalsy(vv) && vv.toLowerCase()!=="hidden" && vv.toLowerCase()!=="none"){
        add("MEDIUM", lineNo, "version", "A version string is stated in the config, which fingerprints the exact Knot release for anyone who can elicit it (for example via CHAOS-class queries).", "Hide or genericize the version answer where Knot / your fronting setup allows it, and keep CHAOS-class responses restricted.");
      }
      return;
    }
    if (key==="chaos"){
      if (isTruthy(value)){
        add("MEDIUM", lineNo, "chaos", "CHAOS-class handling is explicitly enabled, which commonly exposes version.bind / hostname.bind answers.", "Restrict CHAOS-class queries to trusted management addresses or disable them.");
      }
      return;
    }
  });

  var counts = countsFrom(findings, notParsed);
  var verdict, reason;
  if (counts.BLOCKER > 0){
    verdict = "DO NOT SERVE";
    reason = counts.BLOCKER + " blocker finding(s) must be fixed before this config serves publicly.";
  } else if (counts.HIGH > 0 || counts.MEDIUM > 0){
    verdict = "SERVE WITH FIXES";
    reason = "No blockers, but " + (counts.HIGH + counts.MEDIUM) + " high/medium finding(s) should be fixed before or alongside serving.";
  } else {
    verdict = "SAFE TO SERVE";
    reason = "No blocker, high, or medium findings in the recognized settings of this paste.";
  }
  // NOT PARSED lines are reported but never change the verdict.
  return {verdict:verdict, reason:reason, counts:counts, findings:findings, notParsed:notParsed};
}
function emptyCounts(){ return {BLOCKER:0,HIGH:0,MEDIUM:0,LOW:0,INFO:0,NOT_PARSED:0}; }
function countsFrom(findings, notParsed){
  var c = emptyCounts();
  findings.forEach(function(f){ if (c[f.severity]!==undefined) c[f.severity]++; });
  c.NOT_PARSED = notParsed.length;
  return c;
}

function buildReport(result, lineCount){
  var out = [];
  out.push("J-Dawgs Knot DNS Server Config Safety Auditor\u2122 — audit report");
  out.push("Verdict: " + result.verdict);
  out.push("Why: " + result.reason);
  out.push("Lines pasted: " + lineCount);
  out.push("Counts: BLOCKER " + result.counts.BLOCKER + " | HIGH " + result.counts.HIGH + " | MEDIUM " + result.counts.MEDIUM + " | LOW " + result.counts.LOW + " | INFO " + result.counts.INFO + " | NOT PARSED " + result.counts.NOT_PARSED);
  out.push("");
  if (result.findings.length===0 && result.notParsed.length===0){
    out.push("Findings: none.");
  } else {
    out.push("Findings:");
    result.findings.forEach(function(f){
      out.push("- [" + f.severity + "] Line " + f.line + " — key \"" + f.key + "\": " + f.message + " Fix: " + f.fix);
    });
    result.notParsed.forEach(function(n){
      out.push("- [NOT PARSED] Line " + n.line + " — this line could not be parsed as a Knot setting and was excluded from grading.");
    });
  }
  out.push("");
  out.push("Note: secrets are reported by key name, line number, and value length only — secret values never appear in this report.");
  out.push("Limits: heuristic text audit of the pasted config only. It does not start Knot, does not run knot-checkconf, does not connect to any server, and is not a replacement for the daemon's own validation.");
  return out.join("\n");
}

function buildJson(result){
  return {
    tool: "J-Dawgs Knot DNS Server Config Safety Auditor",
    verdict: result.verdict,
    reason: result.reason,
    counts: {BLOCKER:result.counts.BLOCKER, HIGH:result.counts.HIGH, MEDIUM:result.counts.MEDIUM, LOW:result.counts.LOW, INFO:result.counts.INFO, NOT_PARSED:result.counts.NOT_PARSED},
    findings: result.findings.map(function(f){ return {severity:f.severity, line:f.line, key:f.key, message:f.message, fix:f.fix}; }),
    notParsed: result.notParsed.map(function(n){ return {line:n.line, note:"Line could not be parsed as a Knot setting; excluded from grading."}; }),
    limits: "Heuristic text audit of the pasted config only. Does not start Knot, does not run knot-checkconf, does not connect to any server, and is not a replacement for the daemon's own validation. Secret values are never included; secrets appear by key name, line, and value length only."
  };
}
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-knot-dns-server-config-safety-auditortm',
  name: 'J-Dawgs Knot DNS Server Config Safety Auditor',
  description: 'Grades a pasted knot.conf fully offline into one serve verdict — SAFE TO SERVE / SERVE WITH FIXES / DO NOT SERVE / NOT ENOUGH TO GRADE — wildcard listens, an exposed control interface, open zone transfers, TSIG strength, and DNSSEC posture.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
