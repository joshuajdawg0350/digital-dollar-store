'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Gotify Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

    "use strict";

    /* ---------- Worked examples (line numbers are part of the test) ---------- */

    var RISKY_LINES = [
      '# Gotify server configuration - production (copied from the example file)',
      'server:',
      '  listenaddr: "0.0.0.0"',
      '  port: 80',
      '  ssl:',
      '    enabled: false',
      '  cors:',
      '    alloworigins:',
      '      - "*"',
      '  stream:',
      '    allowedorigins:',
      '      - "*"',
      'database:',
      '  dialect: "sqlite3"',
      '  connection: "data/gotify.db"',
      'defaultuser:',
      '  name: "admin"',
      '  pass: "admin123"',
      'passstrength: 6',
      'registration: true',
      'externalurl: "http://notify.example.com"',
      'pluginsdir: "data/plugins"'
    ];
    var RISKY = RISKY_LINES.join('\n');

    var HARDENED_LINES = [
      '# Gotify server configuration - production, hardened',
      '# TLS is terminated by the Caddy reverse proxy on this host; Gotify itself stays on loopback.',
      'server:',
      '  listenaddr: "127.0.0.1"',
      '  port: 8080',
      '  ssl:',
      '    enabled: false',
      '  cors:',
      '    alloworigins:',
      '      - "https://notify.example.com"',
      '  stream:',
      '    allowedorigins:',
      '      - "https://notify.example.com"',
      'database:',
      '  dialect: "sqlite3"',
      '  connection: "/var/lib/gotify/gotify.db"',
      'externalurl: "https://notify.example.com"',
      'passstrength: 12',
      'pluginsdir: "/var/lib/gotify/plugins"',
      'uploadedimagesdir: "/var/lib/gotify/images"'
    ];
    var HARDENED = HARDENED_LINES.join('\n');

    var NON_GOTIFY = [
      'worker_processes 1;',
      '',
      'events {',
      '    worker_connections 1024;',
      '}',
      '',
      'http {',
      '    server {',
      '        listen 80;',
      '    }',
      '}'
    ].join('\n');

    var ENV_SAMPLE = [
      'GOTIFY_SERVER_LISTENADDR=0.0.0.0',
      'GOTIFY_SERVER_PORT=8080',
      'GOTIFY_DATABASE_DIALECT=sqlite3',
      'GOTIFY_DEFAULTUSER_PASS=supersecretvalue99'
    ].join('\n');

    /* ---------- Parser: YAML-ish lines + GOTIFY_* env lines ---------- */

    function cleanScalar(raw) {
      var v = (raw || '').trim();
      if (!v) return '';
      var q = v.charAt(0);
      if (q === '"' || q === "'") {
        var end = v.indexOf(q, 1);
        if (end > 0) return v.slice(1, end);
        return v.slice(1);
      }
      var hash = v.indexOf(' #');
      if (hash >= 0) v = v.slice(0, hash);
      return v.trim();
    }

    function parseConfig(text) {
      var rawLines = String(text || '').split(/\r?\n/);
      var entries = [];
      var comments = [];
      var stack = [];
      rawLines.forEach(function (rawLine, idx) {
        var lineNo = idx + 1;
        var trimmed = rawLine.trim();
        if (trimmed.charAt(0) === '#') { comments.push({ line: lineNo, text: trimmed }); return; }
        if (trimmed === '') return;

        var envM = rawLine.match(/^\s*(?:export\s+)?([A-Za-z][A-Za-z0-9_]*)\s*=\s*(.*)$/);
        if (envM && (envM[1].indexOf('_') >= 0 || /^[A-Z0-9_]+$/.test(envM[1]))) {
          var segs = envM[1].replace(/^GOTIFY_/i, '').toLowerCase().split('_').filter(Boolean);
          if (segs.length) {
            entries.push({
              path: segs.join('.'), key: segs[segs.length - 1],
              value: cleanScalar(envM[2]), line: lineNo, envKey: envM[1], listItem: false
            });
          }
          return;
        }

        var indent = rawLine.match(/^\s*/)[0].replace(/\t/g, '  ').length;
        var listM = trimmed.match(/^-\s+(.*)$/);
        if (listM) {
          var parent = null;
          for (var i = stack.length - 1; i >= 0; i--) {
            if (stack[i].indent < indent) { parent = stack[i]; break; }
          }
          if (parent) {
            entries.push({ path: parent.path, key: parent.key, value: cleanScalar(listM[1]), line: lineNo, listItem: true });
          }
          return;
        }

        var kvM = trimmed.match(/^([A-Za-z0-9_."'-]+)\s*:\s*(.*)$/);
        if (kvM) {
          var key = kvM[1].replace(/^["']|["']$/g, '').toLowerCase();
          while (stack.length && stack[stack.length - 1].indent >= indent) stack.pop();
          var parentPath = stack.length ? stack[stack.length - 1].path : '';
          var path = parentPath ? parentPath + '.' + key : key;
          entries.push({ path: path, key: key, value: cleanScalar(kvM[2]), line: lineNo, listItem: false });
          stack.push({ indent: indent, key: key, path: path });
        }
      });
      return { entries: entries, comments: comments, lineCount: rawLines.length };
    }

    function isTruthy(v) { return /^(true|yes|on|1)$/i.test(String(v || '').trim()); }
    function isFalsy(v) { return /^(false|no|off|0)$/i.test(String(v || '').trim()); }

    /* ---------- Audit engine ---------- */

    var SEV_RANK = { BLOCKER: 0, HIGH: 1, WARNING: 2, INFO: 3 };
    var WEAK_PASSWORDS = ['admin', 'admin123', 'password', 'password1', 'changeme', 'change-me',
      'gotify', 'letmein', '123456', '12345678', 'default', 'secret', 'qwerty'];
    var GUESSED_NAMES = ['admin', 'gotify', 'user', 'root', 'administrator'];

    function auditConfig(text) {
      var parsed = parseConfig(text);
      var entries = parsed.entries;
      var findings = [];
      function add(sev, line, key, title, detail, fix) {
        findings.push({ severity: sev, line: line || 0, key: key || '', title: title, detail: detail, fix: fix || '' });
      }
      function first(path) {
        for (var i = 0; i < entries.length; i++) if (entries[i].path === path) return entries[i];
        return null;
      }

      var noteText = parsed.comments.map(function (c) { return c.text; }).join('\n');
      var proxyNote = /reverse proxy|proxy|tls|ssl|https|nginx|caddy|traefik|letsencrypt|let's encrypt/i.test(noteText);

      var markerSet = {};
      entries.forEach(function (e) {
        var top = e.path.split('.')[0];
        if (['server', 'database', 'defaultuser', 'passstrength', 'pluginsdir', 'uploadedimagesdir'].indexOf(top) >= 0) markerSet[top] = true;
        if (e.envKey && /^GOTIFY_/i.test(e.envKey)) markerSet['gotify-env'] = true;
      });
      var markerCount = Object.keys(markerSet).length;
      var gradeable = markerCount >= 2 || !!markerSet['defaultuser'] || !!markerSet['passstrength'];

      if (!gradeable) {
        add('INFO', 0, '', 'Not recognizably a Gotify configuration',
          'This paste does not carry enough Gotify configuration markers (looked for: a server block, a database block, defaultuser, passstrength, pluginsdir, uploadedimagesdir, or GOTIFY_* environment lines). There is nothing here this auditor can honestly grade.',
          'Paste the Gotify server config.yml / config.yaml, or its GOTIFY_* environment lines, and run the audit again.');
        return finish('NOT ENOUGH TO GRADE', findings, parsed, false);
      }

      /* TLS posture */
      var sslEntry = first('server.ssl.enabled');
      var leEntry = first('server.ssl.letsencrypt.enabled');
      var certEntry = first('server.ssl.certfile');
      var sslEnabled = false;
      if (sslEntry && isTruthy(sslEntry.value)) sslEnabled = true;
      if (leEntry && isTruthy(leEntry.value)) sslEnabled = true;
      if (certEntry && certEntry.value) sslEnabled = true;

      /* Listen address */
      var listenEntry = first('server.listenaddr');
      var portEntry = first('server.port');
      var listenVal = listenEntry ? listenEntry.value.trim() : '';
      var allIfaces = !listenEntry || listenVal === '' || ['0.0.0.0', '::', '[::]', '*'].indexOf(listenVal) >= 0;
      var loopback = ['127.0.0.1', '::1', '[::1]', 'localhost'].indexOf(listenVal) >= 0;
      var listenLine = listenEntry ? listenEntry.line : (portEntry ? portEntry.line : 0);

      if (allIfaces) {
        if (sslEnabled) {
          add('WARNING', listenLine, 'server.listenaddr', 'Listening on all network interfaces',
            'server.listenaddr reaches every interface on the host (' + (listenVal || 'unset — Gotify defaults to all interfaces') + '). TLS is configured, so traffic is encrypted, but the service is still directly reachable from any network the host touches.',
            'Bind server.listenaddr to 127.0.0.1 and let your reverse proxy be the only public door, unless the service must be directly reachable.');
        } else if (proxyNote) {
          add('HIGH', listenLine, 'server.listenaddr', 'Listening on all interfaces over plain HTTP',
            'server.listenaddr is ' + (listenVal || 'unset — Gotify defaults to all interfaces') + ' and SSL is not enabled in Gotify. A note in the file says TLS is handled elsewhere, but the service itself still answers plain HTTP on every interface, bypassing that protection for anyone who can reach the port directly.',
            'Bind server.listenaddr to 127.0.0.1 so only the TLS-terminating reverse proxy can reach Gotify.');
        } else {
          add('BLOCKER', listenLine, 'server.listenaddr', 'Listening on all interfaces with no TLS',
            'server.listenaddr is ' + (listenVal || 'unset — Gotify defaults to all interfaces') + ' and SSL is not enabled. Every login and every notification crosses the network in plain HTTP, readable and alterable by anyone on the path.',
            'Bind server.listenaddr to 127.0.0.1 behind a TLS reverse proxy, or enable server.ssl with a real certificate.');
        }
      } else if (loopback) {
        add('INFO', listenLine, 'server.listenaddr', 'Bound to loopback only',
          'server.listenaddr is ' + listenVal + ', so Gotify answers only on this host. Public access has to come through something in front of it (a reverse proxy), which is the right shape.', '');
      }

      /* HTTP port */
      if (portEntry) {
        var portNum = parseInt(portEntry.value, 10);
        if (!sslEnabled) {
          if (proxyNote) {
            add('INFO', portEntry.line, 'server.port', 'Plain-HTTP port, with a reverse-proxy / TLS note on file',
              'server.port is ' + portEntry.value + ' and SSL is off in Gotify, but the file notes that TLS is terminated by a reverse proxy, and the bind posture above decides how exposed this port really is.', '');
          } else if (portNum === 80) {
            add('HIGH', portEntry.line, 'server.port', 'Standard HTTP port 80 with no TLS or reverse-proxy note',
              'server.port is 80 and nothing in the file — no SSL settings, no comment — says a reverse proxy or TLS terminates in front of it. As written, this is a plain-HTTP service on the standard web port.',
              'Move Gotify behind a TLS reverse proxy (or enable server.ssl) and serve it on https; keep port 80 only as a redirect to https.');
          } else if (allIfaces) {
            /* Exposure already graded by the listen-address finding. */
          } else if (loopback) {
            add('INFO', portEntry.line, 'server.port', 'Plain HTTP on a loopback-only bind',
              'server.port is ' + portEntry.value + ' with SSL off, but the bind is loopback-only, so this port is not reachable from the network.', '');
          } else {
            add('WARNING', portEntry.line, 'server.port', 'Plain-HTTP port with no TLS or reverse-proxy note',
              'server.port is ' + portEntry.value + ' and nothing in the file says TLS or a reverse proxy terminates in front of it.',
              'Put a TLS reverse proxy in front of Gotify or enable server.ssl.');
          }
        } else if (portNum === 80) {
          add('WARNING', portEntry.line, 'server.port', 'Port 80 with SSL enabled',
            'SSL is enabled but the HTTP port is 80. Confirm server.ssl.redirecttohttps is on so plain-HTTP hits are redirected, not served.',
            'Set server.ssl.redirecttohttps to true, or move the plain port off 80.');
        }
      }

      /* SSL explicitly off */
      if (sslEntry && isFalsy(sslEntry.value)) {
        if (allIfaces && !proxyNote) {
          add('HIGH', sslEntry.line, 'server.ssl.enabled', 'SSL is explicitly switched off',
            'server.ssl.enabled is false while the server binds all interfaces. There is no encrypted path to this service at all.',
            'Enable server.ssl with a certificate, or bind to loopback behind a TLS reverse proxy.');
        } else if (proxyNote) {
          add('INFO', sslEntry.line, 'server.ssl.enabled', 'SSL off in Gotify; TLS handled by the reverse proxy',
            'server.ssl.enabled is false, and the note in the file says TLS is terminated by a reverse proxy. That is a sound pattern as long as the bind stays loopback and the proxy is the only public door.', '');
        } else if (loopback) {
          add('INFO', sslEntry.line, 'server.ssl.enabled', 'SSL off, but the bind is loopback-only',
            'server.ssl.enabled is false. Because Gotify only answers on this host, encryption depends on whatever fronts it locally.', '');
        } else {
          add('WARNING', sslEntry.line, 'server.ssl.enabled', 'SSL is switched off',
            'server.ssl.enabled is false and the file carries no reverse-proxy or TLS note.',
            'Enable server.ssl, or record in the file that a reverse proxy terminates TLS.');
        }
      }
      if (sslEnabled) {
        add('INFO', sslEntry ? sslEntry.line : (leEntry ? leEntry.line : 0), 'server.ssl', 'TLS is enabled in the config',
          'The configuration turns TLS on for the Gotify server itself.', '');
      }

      /* CORS + stream origins */
      var corsEntries = entries.filter(function (e) { return e.path.indexOf('cors') >= 0 && e.key === 'alloworigins'; });
      corsEntries.forEach(function (e) {
        if (e.value.indexOf('*') >= 0) {
          add('HIGH', e.line, e.path, 'CORS allows any origin (*)',
            'The CORS allow-list contains a wildcard, so a page on any website can make credentialed browser requests to this Gotify server.',
            'Replace the wildcard with the exact origin(s) of your own web client, e.g. https://your-host.');
        }
      });
      var corsValued = corsEntries.filter(function (e) { return e.value; });
      if (corsValued.length && !corsValued.some(function (e) { return e.value.indexOf('*') >= 0; })) {
        add('INFO', corsValued[0].line, corsValued[0].path, 'CORS origins are restricted to named origins',
          'The CORS allow-list names specific origins instead of a wildcard.', '');
      }
      entries.forEach(function (e) {
        if (e.key === 'allowedorigins' && e.path.indexOf('stream') >= 0 && e.value.indexOf('*') >= 0) {
          add('WARNING', e.line, e.path, 'WebSocket stream allows any origin (*)',
            'The message-stream allow-list contains a wildcard, so any website can open a stream connection attempt against this server.',
            'Restrict the stream allow-list to your own origin(s).');
        }
        if ((e.key === 'alloworigins' || e.key === 'allowedorigins') && e.value.indexOf('*') >= 0 &&
            e.path.indexOf('cors') < 0 && e.path.indexOf('stream') < 0) {
          add('WARNING', e.line, e.path, 'Wildcard origin allowed',
            'An origin allow-list contains a wildcard (*), which lets any website act as an allowed origin.',
            'Replace the wildcard with the exact origin(s) you control.');
        }
      });

      /* Database posture */
      var dbDialect = first('database.dialect');
      var dbConn = first('database.connection');
      if (markerSet['database'] && !dbDialect) {
        add('WARNING', dbConn ? dbConn.line : 0, 'database.dialect', 'Database dialect is not set',
          'A database block is present but names no dialect, so the deployment falls back to whatever the binary defaults to.',
          'Set database.dialect explicitly (sqlite3, mysql, or postgres).');
      }
      if (dbDialect) {
        var d = dbDialect.value.toLowerCase();
        if (d === 'sqlite3') {
          if (dbConn) {
            var c = dbConn.value;
            var isAbs = c.charAt(0) === '/' || c.charAt(0) === '~' || c === ':memory:';
            if (!isAbs) {
              add('WARNING', dbConn.line, 'database.connection', 'SQLite database uses a relative path',
                'database.connection is "' + c + '", which resolves relative to wherever the process happens to start. A different working directory means a different (empty) database — and the file can land somewhere unprotected.',
                'Use an absolute path in a directory only the Gotify user can read, e.g. /var/lib/gotify/gotify.db.');
            } else {
              add('INFO', dbConn.line, 'database.connection', 'SQLite database at an absolute path',
                'database.connection points at a fixed absolute location, so the database file is the same no matter how the process is started.', '');
            }
          }
        } else if (d === 'mysql' || d === 'postgres' || d === 'postgresql') {
          if (dbConn && /pass(word)?\s*=|:[^:@/]+@/.test(dbConn.value)) {
            add('WARNING', dbConn.line, 'database.connection', 'Database credentials are embedded in the connection string',
              'Reported by key name only: key "database.connection", line ' + dbConn.line + ', value length ' + dbConn.value.length + '. Anyone who can read this config holds the database password.',
              'Move the database credential into an environment variable or secret store and out of the config file.');
          } else {
            add('INFO', dbDialect.line, 'database.dialect', 'External database dialect (' + d + ')',
              'The config uses an external database. Grade its own access controls separately — this auditor only reads the config text.', '');
          }
        } else if (d) {
          add('WARNING', dbDialect.line, 'database.dialect', 'Unrecognized database dialect',
            'database.dialect is set to a value this auditor does not recognize as a standard Gotify dialect (sqlite3, mysql, postgres).',
            'Set database.dialect to sqlite3, mysql, or postgres.');
        }
      }

      /* Default user posture */
      var duName = first('defaultuser.name');
      var duPass = first('defaultuser.pass');
      if (duName && GUESSED_NAMES.indexOf(duName.value.toLowerCase()) >= 0) {
        add('WARNING', duName.line, 'defaultuser.name', 'Default admin username is a commonly guessed name',
          'The default user name is set (key "defaultuser.name", line ' + duName.line + ') to one of the first names an attacker tries. Combined with any weak password, the admin account is an open target.',
          'Rename the default admin user to something that is not on the standard guess list.');
      }
      if (duPass) {
        var pv = duPass.value;
        var weak = pv.length <= 10 || WEAK_PASSWORDS.indexOf(pv.toLowerCase()) >= 0 ||
          (duName && pv.toLowerCase() === duName.value.toLowerCase());
        if (weak) {
          add('BLOCKER', duPass.line, 'defaultuser.pass', 'Default admin password is a shipped example or guessable value',
            'Reported by key name only: key "defaultuser.pass", line ' + duPass.line + ', value length ' + pv.length + '. It matches a commonly shipped example value or is too short to resist guessing — anyone who knows the example file knows this password.',
            'Set a long, unique admin password (16+ characters, generated, stored in a password manager) and change it on first login.');
        } else {
          add('WARNING', duPass.line, 'defaultuser.pass', 'Admin password sits in plain text in the config file',
            'Reported by key name only: key "defaultuser.pass", line ' + duPass.line + ', value length ' + pv.length + '. The value itself is not weak on its face, but a plain-text password in a config file is one careless copy away from exposure.',
            'Move the admin password to an environment variable or secret store, and rotate it if this file was ever shared.');
        }
      }
      if (!duName && !duPass) {
        add('INFO', 0, 'defaultuser', 'No defaultuser block in this file',
          'The initial admin account is not defined in this file. Make sure its password was set somewhere safe and was changed from any first-run or example value.', '');
      }

      /* Password strength floor */
      var ps = first('passstrength');
      if (ps) {
        var psn = parseInt(ps.value, 10);
        if (!isNaN(psn) && psn < 10) {
          add('WARNING', ps.line, 'passstrength', 'Password strength requirement is set low',
            'passstrength is ' + psn + ', below the usual floor of 10, so the server accepts weaker user passwords than it should.',
            'Raise passstrength to 10 or higher.');
        }
      }

      /* Registration / open sign-up */
      entries.forEach(function (e) {
        if (/regist|signup|sign-up|openjoin/i.test(e.key)) {
          if (isTruthy(e.value)) {
            add('HIGH', e.line, e.path, 'Open registration / sign-up is switched on',
              'This setting lets anyone who can reach the server create their own account. On a notification server, a stranger\'s account means a stranger pushing and reading messages.',
              'Turn registration off and create accounts deliberately, one named user at a time.');
          } else if (isFalsy(e.value)) {
            add('INFO', e.line, e.path, 'Registration is switched off',
              'Self-service sign-up is disabled; accounts are created deliberately.', '');
          }
        }
      });

      /* URL / base settings on http:// */
      entries.forEach(function (e) {
        if (/^http:\/\//i.test(e.value) && /url|base|host|endpoint|address/i.test(e.key) &&
            e.key !== 'alloworigins' && e.key !== 'allowedorigins') {
          add('WARNING', e.line, e.path, 'Base/URL setting uses plain http://',
            'Key "' + e.path + '" points at an http:// address (' + e.value + '). Links, redirects, and callbacks built on it travel unencrypted and can be rewritten in transit.',
            'Point this setting at the https:// address the server is actually served on.');
        }
      });

      /* Secret inventory — key name, line, length only. Values never surface. */
      var covered = {};
      findings.forEach(function (f) { if (f.line) covered[f.line] = true; });
      entries.forEach(function (e) {
        if (e.key !== 'passstrength' && e.value &&
            /pass(word)?|secret|token|api[-_]?key|apikey|credential|privatekey/i.test(e.key) && !covered[e.line]) {
          add('INFO', e.line, e.path, 'Secret present in the file (value never shown)',
            'Key "' + e.path + '", line ' + e.line + ', value length ' + e.value.length + '. This auditor reports secrets by key name, line number, and length only — the value appears nowhere in these results.',
            '');
        }
      });

      var counts = { BLOCKER: 0, HIGH: 0, WARNING: 0, INFO: 0 };
      findings.forEach(function (f) { counts[f.severity]++; });
      var verdict = counts.BLOCKER > 0 ? 'DO NOT DEPLOY'
        : (counts.HIGH > 0 || counts.WARNING > 0) ? 'DEPLOY WITH FIXES' : 'SAFE TO DEPLOY';
      return finish(verdict, findings, parsed, true);
    }

    function finish(verdict, findings, parsed, gradeable) {
      findings.sort(function (a, b) {
        var r = SEV_RANK[a.severity] - SEV_RANK[b.severity];
        return r !== 0 ? r : a.line - b.line;
      });
      var counts = { BLOCKER: 0, HIGH: 0, WARNING: 0, INFO: 0 };
      findings.forEach(function (f) { counts[f.severity]++; });
      var fixes = findings
        .filter(function (f) { return f.fix && f.severity !== 'INFO'; })
        .map(function (f) { return (f.line ? 'Line ' + f.line + ' — ' : '') + f.fix; });
      return {
        verdict: verdict, gradeable: gradeable, counts: counts,
        findings: findings, fixes: fixes, lineCount: parsed.lineCount
      };
    }

    function buildReport(result) {
      var out = [];
      out.push('J-Dawgs Gotify Server Config Safety Auditor(TM) - audit report');
      out.push('================================================================');
      out.push('Verdict: ' + result.verdict);
      out.push('Lines audited: ' + result.lineCount);
      out.push('Findings: ' + result.counts.BLOCKER + ' BLOCKER, ' + result.counts.HIGH + ' HIGH, ' +
        result.counts.WARNING + ' WARNING, ' + result.counts.INFO + ' INFO');
      out.push('');
      out.push('FINDINGS');
      out.push('--------');
      if (!result.findings.length) out.push('(none)');
      result.findings.forEach(function (f) {
        out.push('[' + f.severity + '] ' + (f.line ? 'Line ' + f.line : 'File') + ' - ' + f.title);
        out.push('    ' + f.detail);
        if (f.fix) out.push('    Fix: ' + f.fix);
      });
      out.push('');
      out.push('FIX LIST');
      out.push('--------');
      if (!result.fixes.length) out.push('(nothing to fix)');
      result.fixes.forEach(function (fx, i) { out.push((i + 1) + '. ' + fx); });
      out.push('');
      out.push('NOTES');
      out.push('-----');
      out.push('Secret values are never shown: secrets and passwords are reported by key name,');
      out.push('line number, and value length only.');
      out.push('This audit ran entirely in the browser. Nothing was uploaded, saved, or sent anywhere.');
      return out.join('\n');
    }

    function buildExport(result) {
      return {
        tool: 'J-Dawgs Gotify Server Config Safety Auditor',
        verdict: result.verdict,
        gradeable: result.gradeable,
        linesAudited: result.lineCount,
        counts: result.counts,
        findings: result.findings.map(function (f) {
          return { severity: f.severity, line: f.line, key: f.key, title: f.title, detail: f.detail, fix: f.fix };
        }),
        fixes: result.fixes
      };
    }

    /* ---------- UI ---------- */

    function esc(s) {
      return String(s == null ? '' : s)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
    }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "ENV_SAMPLE": (typeof ENV_SAMPLE !== 'undefined' ? ENV_SAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-gotify-server-config-safety-auditortm',
  name: 'J-Dawgs Gotify Server Config Safety Auditor',
  description: 'Host tools only tell you the server started; ours grades a pasted Gotify push-notification server config offline into one deploy verdict — secrets by key name/line/length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "ENV_SAMPLE": __core["ENV_SAMPLE"] }
};
