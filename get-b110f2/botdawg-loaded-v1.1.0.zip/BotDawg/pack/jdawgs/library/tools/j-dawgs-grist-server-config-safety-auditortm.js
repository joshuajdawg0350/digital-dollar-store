'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Grist Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var RISKY_LINES = [
        "# RISKY worked example - a config that must not ship",
        "APP_HOME_URL=http://grist.example-company.com",
        "APP_DOC_URL=http://grist.example-company.com/docs",
        "GRIST_SESSION_SECRET=example-secret-123",
        "GRIST_SANDBOX_FLAVOR=unsandboxed",
        "GRIST_ANON_PLAY=true",
        "GRIST_FORCE_LOGIN=false",
        "TYPEORM_TYPE=postgres",
        "TYPEORM_DATABASE=grist_prod",
        "TYPEORM_PASSWORD=dbpass123plaintext",
        "GRIST_TELEMETRY_LEVEL=full",
        "PORT=8484"
      ];
      var HARDENED_LINES = [
        "# HARDENED worked example - session secret shown masked (stand-in, 48 chars)",
        "APP_HOME_URL=https://grist.example-company.com",
        "APP_DOC_URL=https://grist.example-company.com/docs",
        "GRIST_SESSION_SECRET=9f27c41a8b6e4d02f5a1c8e7b390d6f2a4c81e5b7d9036f2",
        "GRIST_SANDBOX_FLAVOR=gvisor",
        "GRIST_ANON_PLAY=false",
        "GRIST_FORCE_LOGIN=true",
        "TYPEORM_TYPE=postgres",
        "TYPEORM_DATABASE=grist_prod",
        "TYPEORM_PASSWORD=${TYPEORM_PASSWORD_FROM_VAULT}",
        "GRIST_TELEMETRY_LEVEL=off",
        "GRIST_SERVE_SAME_ORIGIN=true",
        "PORT=8484"
      ];
      var RISKY = RISKY_LINES.join("\n");
      var HARDENED = HARDENED_LINES.join("\n");

      var RECOGNIZED = {
        APP_HOME_URL:1, APP_DOC_URL:1, APP_DOC_ID:1,
        GRIST_SESSION_SECRET:1, GRIST_SANDBOX_FLAVOR:1, GRIST_ANON_PLAY:1,
        GRIST_FORCE_LOGIN:1, GRIST_TELEMETRY_LEVEL:1, GRIST_SERVE_SAME_ORIGIN:1,
        GRIST_OIDC_IDP_CLIENT_SECRET:1, GRIST_OIDC_IDP_CLIENT_ID:1, GRIST_OIDC_SP_HOST:1,
        GRIST_HOST:1, GRIST_PORT:1, GRIST_DATA_DIR:1, GRIST_ORG:1, GRIST_PERSONAL:1,
        TYPEORM_TYPE:1, TYPEORM_DATABASE:1, TYPEORM_USERNAME:1, TYPEORM_PASSWORD:1,
        TYPEORM_HOST:1, TYPEORM_PORT:1, REDIS_URL:1, PORT:1, HOST:1
      };
      var PLACEHOLDER_RE = /example|change[-_ ]?me|placeholder|your[-_ ]|secret123|password123|default|sample|demo[-_ ]?secret|replace|insert[-_ ]|todo|xxx|test123|letmein|123456|masked|stand[-_ ]?in/i;

      function isRecognized(key){
        return !!RECOGNIZED[key] || key.indexOf("GRIST_")===0 || key.indexOf("TYPEORM_")===0 || key.indexOf("APP_")===0;
      }
      function stripQuotes(v){
        if(v.length>=2){
          var a=v.charAt(0), b=v.charAt(v.length-1);
          if((a==='"'&&b==='"')||(a==="'"&&b==="'")) return v.slice(1,-1);
        }
        return v;
      }
      function isReference(v){
        return /^\$\{[^}]+\}$/.test(v) || /^\$[A-Za-z_][A-Za-z0-9_]*$/.test(v) ||
               v.indexOf("vault:")===0 || v.indexOf("secret:")===0 || v.indexOf("arn:")===0;
      }
      function truthy(v){
        var s=v.trim().toLowerCase();
        return s==="true"||s==="1"||s==="yes"||s==="on"||s==="enabled";
      }
      function falsy(v){
        var s=v.trim().toLowerCase();
        return s==="false"||s==="0"||s==="no"||s==="off"||s==="disabled"||s==="";
      }
      function urlHost(u){
        var m = /^[a-z][a-z0-9+.-]*:\/\/([^/?#]+)/i.exec(u);
        if(!m) return null;
        var auth = m[1];
        var at = auth.lastIndexOf("@");
        if(at>=0) auth = auth.slice(at+1);
        if(auth.charAt(0)==="["){ var end=auth.indexOf("]"); return auth.slice(0,end+1).toLowerCase(); }
        return auth.split(":")[0].toLowerCase();
      }
      function isLocalHost(h){
        return h==="localhost"||h==="127.0.0.1"||h==="[::1]"||h==="::1"||/\.local$/.test(h)||/\.internal$/.test(h);
      }

      function audit(text){
        var findings = [];
        function add(sev, key, line, msg, secretLength){
          var f = {severity:sev, key:key||null, line:(line==null?null:line), message:msg};
          if(typeof secretLength==="number") f.secretLength = secretLength;
          findings.push(f);
        }
        var lines = String(text==null?"":text).split(/\r?\n/);
        var entries = [];       // {key, value, line}
        var byKey = {};         // key -> [entries]
        var notParsed = [];
        lines.forEach(function(raw, i){
          var lineNo = i+1;
          var t = raw.trim();
          if(t==="" || t.charAt(0)==="#") return;
          var m = /^(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/.exec(t);
          if(!m){ notParsed.push(lineNo); return; }
          var entry = {key:m[1], value:stripQuotes(m[2].trim()), line:lineNo};
          entries.push(entry);
          if(!byKey[entry.key]) byKey[entry.key] = [];
          byKey[entry.key].push(entry);
        });
        function last(key){ var a=byKey[key]; return a?a[a.length-1]:null; }

        var recognizedCount = entries.filter(function(e){return isRecognized(e.key);}).length;

        // NOT PARSED lines
        notParsed.forEach(function(ln){
          add("NOT PARSED", null, ln, "Line is not blank, not a comment, and not KEY=value. It was not parsed and nothing about it was guessed.");
        });

        // Duplicates
        Object.keys(byKey).forEach(function(key){
          var a = byKey[key];
          if(a.length>1){
            var nums = a.map(function(e){return e.line;}).join(" and ");
            add("WARNING", key, a[a.length-1].line, key+" appears more than once (lines "+nums+"). Last value wins, as in a real environment file.");
          }
        });

        // Public http URL? (needed for anon escalation)
        var publicHttp = false;
        ["APP_HOME_URL","APP_DOC_URL"].forEach(function(key){
          var e = last(key);
          if(e && /^http:\/\//i.test(e.value)){
            var h = urlHost(e.value);
            if(h && !isLocalHost(h)) publicHttp = true;
          }
        });

        // URL transport checks
        ["APP_HOME_URL","APP_DOC_URL"].forEach(function(key){
          var e = last(key);
          if(!e) return;
          if(/^http:\/\//i.test(e.value)){
            var h = urlHost(e.value);
            if(h && !isLocalHost(h)){
              add("HIGH", key, e.line, key+" uses http:// on a non-localhost host ("+h+"). Session cookies and document traffic cross the network unencrypted. Use https://.");
            } else {
              add("INFO", key, e.line, key+" uses http:// but the host is local ("+(h||"unparsed")+"), so this is a local-only setup.");
            }
          } else if(/^https:\/\//i.test(e.value)){
            add("PASS", key, e.line, key+" uses https://.");
          } else {
            add("INFO", key, e.line, key+" is set but is not an http(s) URL; transport could not be graded from the pasted text.");
          }
        });

        // Session secret — value NEVER rendered
        var ss = last("GRIST_SESSION_SECRET");
        if(!ss){
          if(recognizedCount>0){
            add("BLOCKER", "GRIST_SESSION_SECRET", null, "GRIST_SESSION_SECRET is missing. Grist needs a long random session secret; without one, sessions are not properly protected.");
          }
        } else {
          var v = ss.value;
          var reasons = [];
          if(v.length < 32) reasons.push("it is "+v.length+" characters long, shorter than the 32-character minimum");
          if(PLACEHOLDER_RE.test(v) || /^(.)\1+$/.test(v)) reasons.push("it matches an example / placeholder pattern");
          if(reasons.length){
            add("BLOCKER", "GRIST_SESSION_SECRET", ss.line, "GRIST_SESSION_SECRET is not safe: "+reasons.join(" and ")+". The value itself is never shown.", v.length);
          } else if(isReference(v)){
            add("PASS", "GRIST_SESSION_SECRET", ss.line, "GRIST_SESSION_SECRET is supplied by reference rather than pasted in plaintext. Its length and strength cannot be graded from the pasted text.", v.length);
          } else {
            add("PASS", "GRIST_SESSION_SECRET", ss.line, "GRIST_SESSION_SECRET is present at "+v.length+" characters with no placeholder pattern detected. The value itself is never shown.", v.length);
          }
        }

        // Sandbox flavor
        var sf = last("GRIST_SANDBOX_FLAVOR");
        if(sf){
          var fl = sf.value.trim().toLowerCase();
          if(fl==="unsandboxed"){
            add("HIGH", "GRIST_SANDBOX_FLAVOR", sf.line, "GRIST_SANDBOX_FLAVOR is \"unsandboxed\": document formulas and data-engine code run unsandboxed, with the server process's own access.");
          } else if(fl==="gvisor"){
            add("PASS", "GRIST_SANDBOX_FLAVOR", sf.line, "GRIST_SANDBOX_FLAVOR is \"gvisor\": documents run inside the gVisor sandbox.");
          } else {
            add("INFO", "GRIST_SANDBOX_FLAVOR", sf.line, "GRIST_SANDBOX_FLAVOR is \""+sf.value+"\"; only \"unsandboxed\" (HIGH) and \"gvisor\" (pass) are graded specifically.");
          }
        }

        // Anonymous play
        var ap = last("GRIST_ANON_PLAY");
        if(ap){
          if(truthy(ap.value)){
            if(publicHttp){
              add("HIGH", "GRIST_ANON_PLAY", ap.line, "GRIST_ANON_PLAY is enabled (anonymous access on) and a public http:// URL is also present: anonymous visitors reach the server over an unencrypted public address.");
            } else {
              add("WARNING", "GRIST_ANON_PLAY", ap.line, "GRIST_ANON_PLAY is enabled: anonymous access is on, so anyone who can reach the server can open publicly shared documents without an account.");
            }
          } else if(falsy(ap.value)){
            add("PASS", "GRIST_ANON_PLAY", ap.line, "GRIST_ANON_PLAY is off: anonymous access is disabled.");
          } else {
            add("INFO", "GRIST_ANON_PLAY", ap.line, "GRIST_ANON_PLAY value \""+ap.value+"\" is not a recognized on/off value; anonymous-access state could not be graded.");
          }
        }

        // Force login
        var flg = last("GRIST_FORCE_LOGIN");
        if(flg){
          if(truthy(flg.value)) add("PASS", "GRIST_FORCE_LOGIN", flg.line, "GRIST_FORCE_LOGIN is on: visitors must log in.");
          else if(falsy(flg.value)) add("WARNING", "GRIST_FORCE_LOGIN", flg.line, "GRIST_FORCE_LOGIN is off: login is not forced for visitors.");
        }

        // Plaintext credential checks — values NEVER rendered
        [["TYPEORM_PASSWORD","database password"],["GRIST_OIDC_IDP_CLIENT_SECRET","OIDC client secret"]].forEach(function(pair){
          var e = last(pair[0]);
          if(!e || e.value==="") return;
          if(isReference(e.value)){
            add("PASS", pair[0], e.line, pair[0]+" ("+pair[1]+") is supplied by reference rather than pasted in plaintext.", e.value.length);
          } else {
            add("HIGH", pair[0], e.line, pair[0]+" holds a plaintext "+pair[1]+" in the pasted config ("+e.value.length+" characters). Anyone who can read this file has the credential. The value itself is never shown.", e.value.length);
          }
        });
        var ru = last("REDIS_URL");
        if(ru && ru.value){
          var rm = /^[a-z][a-z0-9+.-]*:\/\/([^/?#@]*)@/i.exec(ru.value);
          if(rm){
            var cred = rm[1];
            var pw = cred.indexOf(":")>=0 ? cred.slice(cred.indexOf(":")+1) : "";
            if(pw){
              add("HIGH", "REDIS_URL", ru.line, "REDIS_URL embeds a plaintext Redis password ("+pw.length+" characters) in the URL. The password itself is never shown.", pw.length);
            }
          }
        }

        // Telemetry
        var tm = last("GRIST_TELEMETRY_LEVEL");
        if(tm){
          var tl = tm.value.trim().toLowerCase();
          if(tl==="off") add("PASS", "GRIST_TELEMETRY_LEVEL", tm.line, "GRIST_TELEMETRY_LEVEL is off: no telemetry is sent.");
          else if(tl==="on"||tl==="full") add("INFO", "GRIST_TELEMETRY_LEVEL", tm.line, "GRIST_TELEMETRY_LEVEL is \""+tm.value+"\": telemetry is sent to Grist's team. Not a deploy blocker; noted so it is a deliberate choice.");
          else add("INFO", "GRIST_TELEMETRY_LEVEL", tm.line, "GRIST_TELEMETRY_LEVEL is \""+tm.value+"\"; only off / on / full are graded specifically.");
        }

        // Same-origin serving
        var so = last("GRIST_SERVE_SAME_ORIGIN");
        if(so){
          if(truthy(so.value)) add("PASS", "GRIST_SERVE_SAME_ORIGIN", so.line, "GRIST_SERVE_SAME_ORIGIN is on: the app and documents are served from the same origin.");
          else if(falsy(so.value)) add("INFO", "GRIST_SERVE_SAME_ORIGIN", so.line, "GRIST_SERVE_SAME_ORIGIN is off: documents are served from a separate origin. A legitimate setup, noted for the record.");
        }

        // Bind address
        ["HOST","GRIST_HOST"].forEach(function(key){
          var e = last(key);
          if(e && (e.value==="0.0.0.0"||e.value==="::")){
            add("INFO", key, e.line, key+" binds all network interfaces ("+e.value+"). Normal behind a reverse proxy or firewall; exposed directly, everything above matters more.");
          }
        });

        var counts = {BLOCKER:0, HIGH:0, WARNING:0, INFO:0, PASS:0, "NOT PARSED":0};
        findings.forEach(function(f){ counts[f.severity]++; });

        var rank = {BLOCKER:0, HIGH:1, WARNING:2, INFO:3, PASS:4, "NOT PARSED":5};
        findings.sort(function(a,b){
          if(rank[a.severity]!==rank[b.severity]) return rank[a.severity]-rank[b.severity];
          return (a.line||0)-(b.line||0);
        });

        var verdict;
        if(!String(text||"").trim() || recognizedCount===0){
          verdict = "NOT ENOUGH TO GRADE";
        } else if(counts.BLOCKER>0 || counts.HIGH>=2){
          verdict = "DO NOT DEPLOY";
        } else if(counts.HIGH>0 || counts.WARNING>0 || counts["NOT PARSED"]>0){
          verdict = "DEPLOY WITH FIXES";
        } else {
          verdict = "SAFE TO DEPLOY";
        }

        return {
          verdict: verdict,
          counts: counts,
          findings: findings,
          linesScanned: lines.length,
          keysParsed: entries.length,
          recognizedKeys: recognizedCount,
          notParsedLines: notParsed.slice()
        };
      }

      function reportText(r){
        var out = [];
        out.push("J-Dawgs Grist Server Config Safety Auditor - Audit Report");
        out.push("Verdict: "+r.verdict);
        out.push("Lines scanned: "+r.linesScanned+" | Keys parsed: "+r.keysParsed+" | Recognized Grist keys: "+r.recognizedKeys);
        out.push("Counts: BLOCKER "+r.counts.BLOCKER+" | HIGH "+r.counts.HIGH+" | WARNING "+r.counts.WARNING+" | INFO "+r.counts.INFO+" | PASS "+r.counts.PASS+" | NOT PARSED "+r.counts["NOT PARSED"]);
        out.push("");
        if(r.findings.length===0) out.push("No findings.");
        r.findings.forEach(function(f){
          var loc = f.line==null ? "no line (key absent)" : "Line "+f.line;
          var line = "["+f.severity+"] "+loc+(f.key?" - "+f.key:"")+": "+f.message;
          if(typeof f.secretLength==="number") line += " (secret length: "+f.secretLength+" characters; value never shown)";
          out.push(line);
        });
        out.push("");
        out.push("Secret values never appear in this report - only key name, line number, and character length.");
        return out.join("\n");
      }
      function jsonText(r){
        return JSON.stringify({
          tool: "J-Dawgs Grist Server Config Safety Auditor",
          verdict: r.verdict,
          counts: r.counts,
          linesScanned: r.linesScanned,
          keysParsed: r.keysParsed,
          recognizedKeys: r.recognizedKeys,
          findings: r.findings,
          note: "Secret values are never included - key name, line number, and character length only."
        }, null, 2);
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-grist-server-config-safety-auditortm',
  name: 'J-Dawgs Grist Server Config Safety Auditor',
  description: 'Grades a pasted Grist server env config offline into one deploy verdict (SAFE TO DEPLOY / DEPLOY WITH FIXES / DO NOT DEPLOY / NOT ENOUGH TO GRADE) — sandbox flavor, anonymous access, and credential posture graded too; secrets reported by key name, line, and length only, never the secret value.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
