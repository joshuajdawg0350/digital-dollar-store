'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs HTML Escaping & Entity Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------------- Example fragments ---------------- */

      var BROKEN_EXAMPLE = [
        "<p>Tom &amp; Jerry: 5 < 6, always.</p>",
        "<p>To show a bracket in code, write &amp;lt; and readers see the bracket.</p>",
        "<p title=\"He said \"hello\" loudly\">A quoted greeting</p>",
        "<a href=\"javascript:runTracker()\">Do not click</a>",
        "<a href=\"https://example.com/find?q=cats&page=2\">More results</a>"
      ].join("\n");

      var CLEAN_EXAMPLE = [
        "<p>Tom &amp; Jerry: 5 &lt; 6, always.</p>",
        "<p>Brackets as text: &lt; and &gt;. Quotes as text: &quot;hello&quot;.</p>",
        "<a href=\"https://example.com/find?q=cats&amp;page=2\" title=\"Search results\">More results</a>",
        "<!-- A tidy comment - with single hyphens only -->",
        "<p>&copy; 2026 J-Dawgs Trading Post. Prices in USD &amp; tax where it applies.</p>"
      ].join("\n");

      /* ---------------- Entity tables ---------------- */

      var KNOWN = {};
      ("amp lt gt quot apos nbsp iexcl cent pound curren yen brvbar sect uml copy ordf laquo not shy reg macr deg plusmn sup2 sup3 acute micro para middot cedil sup1 ordm raquo frac14 frac12 frac34 iquest " +
       "Agrave Aacute Acirc Atilde Auml Aring AElig Ccedil Egrave Eacute Ecirc Euml Igrave Iacute Icirc Iuml ETH Ntilde Ograve Oacute Ocirc Otilde Ouml times Oslash Ugrave Uacute Ucirc Uuml Yacute THORN szlig " +
       "agrave aacute acirc atilde auml aring aelig ccedil egrave eacute ecirc euml igrave iacute icirc iuml eth ntilde ograve oacute ocirc otilde ouml divide oslash ugrave uacute ucirc uuml yacute thorn yuml " +
       "OElig oelig Scaron scaron Yuml fnof circ tilde ensp emsp thinsp zwnj zwj lrm rlm ndash mdash lsquo rsquo sbquo ldquo rdquo bdquo dagger Dagger bull hellip permil prime Prime lsaquo rsaquo frasl weierp image real trade alefsym " +
       "Alpha Beta Gamma Delta Epsilon Zeta Eta Theta Iota Kappa Lambda Mu Nu Xi Omicron Pi Rho Sigma Tau Upsilon Phi Chi Psi Omega alpha beta gamma delta epsilon zeta eta theta iota kappa lambda mu nu xi omicron pi rho sigmaf sigma tau upsilon phi chi psi omega thetasym upsih piv " +
       "larr uarr rarr darr harr crarr lArr uArr rArr dArr hArr forall exist empty nabla isin notin ni prod sum minus lowast radic prop infin ang and or cap cup int there4 sim cong asymp ne equiv le ge sub sup nsub sube supe oplus otimes perp sdot lceil rceil lfloor rfloor lang rang loz spades clubs hearts diams " +
       "AMP LT GT QUOT COPY REG TRADE").split(" ").forEach(function (n) { if (n) KNOWN[n] = true; });

      var CHAR_TO_ENTITY = {
        "©": "copy", "®": "reg", "™": "trade", "—": "mdash", "–": "ndash",
        "…": "hellip", " ": "nbsp", "«": "laquo", "»": "raquo", "×": "times",
        "÷": "divide", "°": "deg", "±": "plusmn", "£": "pound", "€": "euro",
        "¥": "yen", "¢": "cent", "§": "sect", "¶": "para", "•": "bull",
        "‘": "lsquo", "’": "rsquo", "“": "ldquo", "”": "rdquo",
        "é": "eacute", "è": "egrave", "à": "agrave", "á": "aacute",
        "í": "iacute", "ó": "oacute", "ú": "uacute", "ñ": "ntilde",
        "ü": "uuml", "ö": "ouml", "ä": "auml", "ß": "szlig", "ç": "ccedil",
        "¼": "frac14", "½": "frac12", "¾": "frac34", "†": "dagger",
        "‰": "permil", "′": "prime", "″": "Prime", "‹": "lsaquo", "›": "rsaquo"
      };
      var ENTITY_TO_CHAR = {};
      Object.keys(CHAR_TO_ENTITY).forEach(function (ch) { ENTITY_TO_CHAR[CHAR_TO_ENTITY[ch]] = ch; });

      var BOOLEAN_ATTRS = {};
      ("disabled checked selected readonly required multiple hidden autofocus autoplay controls loop muted open async defer novalidate formnovalidate inert playsinline default reversed ismap itemscope allowfullscreen").split(" ").forEach(function (n) { BOOLEAN_ATTRS[n] = true; });

      /* ---------------- The audit ---------------- */

      function makeLineIndex(src) {
        var starts = [0];
        for (var i = 0; i < src.length; i++) { if (src[i] === "\n") starts.push(i + 1); }
        return function (idx) {
          var lo = 0, hi = starts.length - 1, ans = 0;
          while (lo <= hi) {
            var mid = (lo + hi) >> 1;
            if (starts[mid] <= idx) { ans = mid; lo = mid + 1; } else { hi = mid - 1; }
          }
          return ans + 1;
        };
      }

      function audit(src) {
        var lineOf = makeLineIndex(src);
        var findings = [], edits = [], notFixed = [];
        var rawChars = {}, entChars = {};
        var n = src.length;

        function addFinding(sev, idx, check, msg) {
          findings.push({ sev: sev, line: lineOf(idx), check: check, msg: msg });
        }
        function noteRawChar(ch, idx) {
          if (ch.codePointAt(0) > 127 && !(ch in rawChars)) rawChars[ch] = lineOf(idx);
        }
        function noteEntChar(ch, idx, form) {
          if (ch && ch.codePointAt(0) > 127 && !(ch in entChars)) entChars[ch] = { line: lineOf(idx), form: form };
        }
        function context(idx) {
          var s = src.slice(Math.max(0, idx - 14), Math.min(n, idx + 15)).replace(/\s+/g, " ");
          return "…" + s + "…";
        }

        /* Handles a "&" at pos. Returns the index just past what was consumed. */
        function handleAmp(pos, inUrlAttr) {
          var rest = src.slice(pos);
          var m, fixed;
          m = rest.match(/^&amp;(lt|gt|amp|quot|apos);/);
          if (m) {
            fixed = "&" + m[1] + ";";
            addFinding("warning", pos, "Double-escaped entity",
              "“" + m[0] + "” is escaped twice — readers will literally see “" + fixed + "” on the page instead of the character. The corrected copy collapses exactly one level, to " + fixed + ".");
            edits.push({ start: pos, end: pos + m[0].length, replacement: fixed, line: lineOf(pos),
              desc: "collapsed one level of double-escaping: " + m[0] + " → " + fixed });
            return pos + m[0].length;
          }
          m = rest.match(/^&amp;#(\d+);/) || rest.match(/^&amp;#x([0-9a-fA-F]+);/);
          if (m) {
            fixed = "&" + m[0].slice(5);
            addFinding("warning", pos, "Double-escaped entity",
              "“" + m[0] + "” is escaped twice — readers will literally see “" + fixed + "” on the page instead of the character. The corrected copy collapses exactly one level, to " + fixed + ".");
            edits.push({ start: pos, end: pos + m[0].length, replacement: fixed, line: lineOf(pos),
              desc: "collapsed one level of double-escaping: " + m[0] + " → " + fixed });
            return pos + m[0].length;
          }
          m = rest.match(/^&(amp|lt|gt|quot|apos);/);
          if (m) return pos + m[0].length;
          m = rest.match(/^&#(\d+);/);
          if (m) {
            var cp = parseInt(m[1], 10);
            if (cp > 0 && cp < 0x110000) { try { noteEntChar(String.fromCodePoint(cp), pos, m[0]); } catch (e) {} }
            return pos + m[0].length;
          }
          m = rest.match(/^&#x([0-9a-fA-F]+);/);
          if (m) {
            var cp2 = parseInt(m[1], 16);
            if (cp2 > 0 && cp2 < 0x110000) { try { noteEntChar(String.fromCodePoint(cp2), pos, m[0]); } catch (e) {} }
            return pos + m[0].length;
          }
          m = rest.match(/^&([A-Za-z][A-Za-z0-9]+);/);
          if (m) {
            if (KNOWN[m[1]]) {
              if (ENTITY_TO_CHAR[m[1]]) noteEntChar(ENTITY_TO_CHAR[m[1]], pos, m[0]);
              return pos + m[0].length;
            }
            addFinding("warning", pos, "Unknown entity",
              "“" + m[0] + "” is not a recognized HTML entity — browsers render unknown entities literally, so readers will see “" + m[0] + "” on the page.");
            notFixed.push({ line: lineOf(pos), text: "Unknown entity " + m[0] + " left as-is — the character you meant can't be guessed safely." });
            return pos + m[0].length;
          }
          var where = inUrlAttr
            ? " inside a URL in an attribute — a bare & in a query string can split the URL's parameters the wrong way; write it as &amp;"
            : " in the text — it does not start a valid entity; write it as &amp;";
          addFinding("warning", pos, "Unescaped &",
            "Bare “&”" + where + ". Context: " + context(pos));
          edits.push({ start: pos, end: pos + 1, replacement: "&amp;", line: lineOf(pos),
            desc: "changed bare & to &amp;" });
          return pos + 1;
        }

        function scanValue(start, end, attrName) {
          var inUrl = (attrName === "href" || attrName === "src" || attrName === "action");
          var p = start;
          while (p < end) {
            if (src[p] === "&") { p = handleAmp(p, inUrl); continue; }
            var s = String.fromCodePoint(src.codePointAt(p));
            noteRawChar(s, p);
            p += s.length;
          }
        }

        function checkJs(attrName, value, idx) {
          if (attrName !== "href" && attrName !== "src") return;
          var v = value.replace(/^[\s\x00-\x20]+/, "").toLowerCase();
          if (v.indexOf("javascript:") === 0) {
            addFinding("blocker", idx, "javascript: URL",
              "This " + attrName + " points to a javascript: URL, which runs script when clicked — a classic injection hole in generated pages. Replace it with a normal https: link or a button.");
            notFixed.push({ line: lineOf(idx), text: "javascript: URL in " + attrName + " left as-is — choosing a safe replacement target is your call, not a mechanical fix." });
          }
        }

        function parseComment(pos) {
          var end = src.indexOf("-->", pos + 4);
          if (end === -1) {
            addFinding("blocker", pos, "Unclosed comment",
              "This comment opens with <!-- but never closes with -->. Everything after it can be swallowed as comment text and vanish from the page.");
            notFixed.push({ line: lineOf(pos), text: "Unclosed comment left as-is — where the comment should end is a judgment call." });
            return n;
          }
          var bodyStart = pos + 4;
          var k = src.indexOf("--", bodyStart);
          while (k !== -1 && k < end) {
            addFinding("warning", k, "Double hyphen inside comment",
              "A “--” inside a comment body can end the comment early in some parsers and leak the rest into the page. Use a single hyphen or reword.");
            notFixed.push({ line: lineOf(k), text: "“--” inside a comment left as-is — rewording comment text is not a mechanical fix." });
            k = src.indexOf("--", k + 2);
          }
          return end + 3;
        }

        function parseTag(pos) {
          var j = pos + 1;
          if (src[j] === "!" || src[j] === "?") {
            var gt = src.indexOf(">", j);
            return gt === -1 ? n : gt + 1;
          }
          if (src[j] === "/") j++;
          while (j < n && !/[\s/>]/.test(src[j])) j++;
          var quoteFlagged = false;
          while (j < n) {
            while (j < n && /\s/.test(src[j])) j++;
            if (j >= n) break;
            var c = src[j];
            if (c === ">") return j + 1;
            if (c === "/") { if (src[j + 1] === ">") return j + 2; j++; continue; }
            if (c === "\"" || c === "'") {
              if (!quoteFlagged) {
                quoteFlagged = true;
                addFinding("blocker", j, "Raw quote in attribute",
                  "A stray quote is floating inside this tag — an attribute value almost certainly contains a raw quote that ends the value early and breaks the tag. Escape inner quotes as &quot; or reword the value.");
                notFixed.push({ line: lineOf(j), text: "Raw quote inside an attribute left as-is — fixing it means deciding where the value really ends." });
              }
              j++; continue;
            }
            var nameStart = j;
            while (j < n && !/[\s=\/>"']/.test(src[j])) j++;
            if (j === nameStart) { j++; continue; }
            var attrName = src.slice(nameStart, j).toLowerCase();
            while (j < n && /\s/.test(src[j])) j++;
            if (src[j] === "=") {
              j++;
              while (j < n && /\s/.test(src[j])) j++;
              var q = src[j];
              if (q === "\"" || q === "'") {
                var close = src.indexOf(q, j + 1);
                var gtIdx = src.indexOf(">", j + 1);
                if (close === -1 || (gtIdx !== -1 && gtIdx < close)) {
                  var vend = gtIdx === -1 ? n : gtIdx;
                  scanValue(j + 1, vend, attrName);
                  checkJs(attrName, src.slice(j + 1, vend), nameStart);
                  return gtIdx === -1 ? n : gtIdx + 1;
                }
                scanValue(j + 1, close, attrName);
                checkJs(attrName, src.slice(j + 1, close), nameStart);
                j = close + 1;
                /* Peek: junk containing a quote right after a quoted value means
                   the value almost certainly held a raw quote. A following
                   name= (a real next attribute) is normal and never flagged —
                   only a token with a quote but no "=" counts as spill. */
                var k = j;
                while (k < n && /\s/.test(src[k])) k++;
                if (k < n && src[k] !== ">" && src[k] !== "/") {
                  var ts = k;
                  while (k < n && !/[\s>]/.test(src[k])) k++;
                  var token = src.slice(ts, k);
                  if (token.indexOf("=") === -1 && (token.indexOf("\"") !== -1 || token.indexOf("'") !== -1)) {
                    if (!quoteFlagged) {
                      quoteFlagged = true;
                      addFinding("blocker", ts, "Raw quote in attribute value",
                        "The " + attrName + " attribute appears to contain a raw " + (q === "\"" ? "double" : "single") + " quote: the value ends early at that quote and the rest (“" + token + "”) spills into the tag as junk. Escape inner quotes as &quot; or reword the value.");
                      notFixed.push({ line: lineOf(ts), text: "Attribute " + attrName + " with a raw quote inside left as-is — the real end of the value can't be determined mechanically." });
                    }
                  }
                }
              } else {
                var vstart = j;
                while (j < n && !/[\s>]/.test(src[j])) j++;
                var uval = src.slice(vstart, j);
                scanValue(vstart, j, attrName);
                checkJs(attrName, uval, nameStart);
                /* A bare word right after an unquoted value means the value
                   most likely contained a space. */
                var k2 = j;
                while (k2 < n && /\s/.test(src[k2])) k2++;
                if (k2 < n && src[k2] !== ">" && src[k2] !== "/") {
                  var ts2 = k2;
                  while (k2 < n && !/[\s=\/>]/.test(src[k2])) k2++;
                  var tok2 = src.slice(ts2, k2);
                  var kk = k2;
                  while (kk < n && /\s/.test(src[kk])) kk++;
                  var followedByEquals = src[kk] === "=";
                  if (tok2 && !followedByEquals && !BOOLEAN_ATTRS[tok2.toLowerCase()]) {
                    addFinding("blocker", vstart, "Unquoted attribute value with spaces",
                      "The " + attrName + " attribute value is unquoted and appears to contain a space (“" + uval + " " + tok2 + " …”) — browsers read only “" + uval + "” as the value and treat the rest as junk attributes. Put the full value in quotes.");
                    notFixed.push({ line: lineOf(vstart), text: "Unquoted " + attrName + " value left as-is — adding quotes is not mechanical here, because the value's true end is ambiguous." });
                  }
                }
              }
            }
          }
          return j;
        }

        var i = 0;
        while (i < n) {
          if (src.startsWith("<!--", i)) { i = parseComment(i); continue; }
          var c = src[i];
          if (c === "<") {
            var nx = src[i + 1] || "";
            var isTag = /[A-Za-z]/.test(nx) || nx === "!" || nx === "?" || (nx === "/" && /[A-Za-z]/.test(src[i + 2] || ""));
            if (isTag) { i = parseTag(i); continue; }
            addFinding("blocker", i, "Raw < in text",
              "Raw “<” typed as text — browsers may read it as the start of a tag and swallow what follows. Use &lt; instead. Context: " + context(i));
            edits.push({ start: i, end: i + 1, replacement: "&lt;", line: lineOf(i),
              desc: "escaped raw < in text as &lt;" });
            i++; continue;
          }
          if (c === ">") {
            addFinding("blocker", i, "Raw > in text",
              "Raw “>” typed as text, outside any tag. Escape it as &gt; so it can never be mistaken for the end of a tag. Context: " + context(i));
            edits.push({ start: i, end: i + 1, replacement: "&gt;", line: lineOf(i),
              desc: "escaped raw > in text as &gt;" });
            i++; continue;
          }
          if (c === "&") { i = handleAmp(i, false); continue; }
          var s = String.fromCodePoint(src.codePointAt(i));
          noteRawChar(s, i);
          i += s.length;
        }

        /* Check 5: same character written raw in one place, as an entity in another. */
        Object.keys(rawChars).forEach(function (ch) {
          if (entChars[ch]) {
            findings.push({ sev: "info", line: rawChars[ch], check: "Same character, two styles",
              msg: "The character “" + ch + "” is written literally on line " + rawChars[ch] + " but as the entity " + entChars[ch].form + " on line " + entChars[ch].line + ". Both render the same — this is a consistency note, not an error. Pick one style and stick to it." });
          }
        });

        var rank = { blocker: 0, warning: 1, info: 2 };
        findings.sort(function (a, b) { return (a.line - b.line) || (rank[a.sev] - rank[b.sev]); });

        var counts = { blocker: 0, warning: 0, info: 0 };
        findings.forEach(function (f) { counts[f.sev]++; });

        var byStartDesc = edits.slice().sort(function (a, b) { return b.start - a.start; });
        var corrected = src;
        byStartDesc.forEach(function (e) {
          corrected = corrected.slice(0, e.start) + e.replacement + corrected.slice(e.end);
        });
        var receipt = edits.slice().sort(function (a, b) { return a.start - b.start; });

        var verdict;
        if (counts.blocker > 0) verdict = "DO NOT PUBLISH — ESCAPING RISKS";
        else if (counts.warning > 0) verdict = "PUBLISH WITH FIXES";
        else verdict = "SAFE TO PUBLISH";

        return { findings: findings, counts: counts, corrected: corrected, receipt: receipt, notFixed: notFixed, verdict: verdict };
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "BROKEN_EXAMPLE": (typeof BROKEN_EXAMPLE !== 'undefined' ? BROKEN_EXAMPLE : undefined), "CLEAN_EXAMPLE": (typeof CLEAN_EXAMPLE !== 'undefined' ? CLEAN_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-html-escaping-entity-safety-auditortm',
  name: 'J-Dawgs HTML Escaping & Entity Safety Auditor',
  description: '',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "BROKEN_EXAMPLE": __core["BROKEN_EXAMPLE"], "CLEAN_EXAMPLE": __core["CLEAN_EXAMPLE"] }
};
