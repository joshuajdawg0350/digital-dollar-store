'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs MySQL Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var RISKY_EXAMPLE = [
          "# Worked example — a risky server configuration.",
          "# It grades DO NOT DEPLOY. Do not run a real server like this.",
          "",
          "[mysqld]",
          "user = mysql",
          "port = 3306",
          "datadir = /var/lib/mysql",
          "socket = /var/run/mysqld/mysqld.sock",
          "",
          "# Anyone who can reach the port can connect — no password checks at all.",
          "skip-grant-tables",
          "",
          "# Listen on every network interface.",
          "bind-address = 0.0.0.0",
          "",
          "local_infile = ON",
          "secure_file_priv =",
          "general_log = ON",
          "general_log_file = /var/log/mysql/general.log",
          "allow-suspicious-udfs = ON",
          ""
        ].join("\n");

        var CLEAN_EXAMPLE = [
          "# Worked example — a hardened server configuration.",
          "# It grades SAFE TO DEPLOY: zero blockers, zero warnings.",
          "",
          "[mysqld]",
          "user = mysql",
          "port = 3306",
          "datadir = /var/lib/mysql",
          "socket = /var/run/mysqld/mysqld.sock",
          "",
          "# Local connections only.",
          "bind-address = 127.0.0.1",
          "",
          "local_infile = OFF",
          "secure_file_priv = /var/lib/mysql-files",
          "general_log = OFF",
          "automatic_sp_privileges = OFF",
          "",
          "# TLS required for every client connection.",
          "require_secure_transport = ON",
          "ssl_ca = /etc/mysql/ssl/ca.pem",
          "ssl_cert = /etc/mysql/ssl/server-cert.pem",
          "ssl_key = /etc/mysql/ssl/server-key.pem",
          ""
        ].join("\n");

        var AUDITED_SECTIONS = ["mysqld", "server"];

        // Keys this auditor recognizes inside [mysqld] / [server]. Anything else
        // in those sections is reported NOT AUDITED by name — never guessed.
        var KNOWN_KEYS = {};
        [
          "user", "port", "socket", "pid_file", "datadir", "basedir", "tmpdir",
          "bind_address", "skip_networking", "mysqlx", "mysqlx_bind_address", "mysqlx_port",
          "skip_grant_tables", "skip_name_resolve", "skip_host_cache",
          "local_infile", "secure_file_priv", "secure_auth",
          "general_log", "general_log_file", "log_output", "log_error", "log_error_verbosity",
          "slow_query_log", "slow_query_log_file", "long_query_time", "log_queries_not_using_indexes",
          "log_bin", "binlog_format", "binlog_expire_logs_seconds", "expire_logs_days", "server_id",
          "sync_binlog", "gtid_mode", "enforce_gtid_consistency",
          "require_secure_transport", "ssl_ca", "ssl_capath", "ssl_cert", "ssl_key", "ssl_cipher",
          "ssl_crl", "ssl_crlpath", "tls_version", "tls_ciphersuites", "have_openssl", "have_ssl",
          "allow_suspicious_udfs", "automatic_sp_privileges",
          "max_connections", "max_connect_errors", "max_allowed_packet", "max_user_connections",
          "wait_timeout", "interactive_timeout", "connect_timeout",
          "innodb_buffer_pool_size", "innodb_log_file_size", "innodb_flush_log_at_trx_commit",
          "innodb_file_per_table", "innodb_strict_mode", "innodb_io_capacity",
          "key_buffer_size", "table_open_cache", "thread_cache_size", "open_files_limit",
          "character_set_server", "collation_server", "default_storage_engine",
          "default_authentication_plugin", "authentication_policy",
          "sql_mode", "explicit_defaults_for_timestamp", "transaction_isolation",
          "event_scheduler", "performance_schema", "disabled_storage_engines",
          "plugin_dir", "plugin_load_add", "init_connect", "init_file",
          "symbolic_links", "skip_symbolic_links", "query_cache_size", "query_cache_type",
          "lower_case_table_names", "default_time_zone", "ft_min_word_len",
          "password_history", "password_reuse_interval", "password_require_current",
          "validate_password_policy", "validate_password_length",
          "master_info_repository", "relay_log_info_repository", "read_only", "super_read_only",
          "skip_slave_start", "innodb_read_only", "version", "version_comment",
          "large_files_support", "external_locking", "skip_external_locking",
          "delay_key_write", "bulk_insert_buffer_size", "join_buffer_size", "sort_buffer_size",
          "read_buffer_size", "read_rnd_buffer_size", "tmp_table_size", "max_heap_table_size",
          "net_buffer_length", "thread_stack", "back_log", "host_cache_size"
        ].forEach(function (k) { KNOWN_KEYS[k] = true; });

        var PASSWORD_KEY = /(password|passwd|pwd|passphrase)/;
        // Password *policy* settings — they tune the password rules and hold no
        // credential value, so they are never flagged as stored passwords.
        var PASSWORD_POLICY = {};
        [
          "password_history", "password_reuse_interval", "password_require_current",
          "default_password_lifetime", "password_expire", "validate_password_policy",
          "validate_password_length", "validate_password_number_count",
          "validate_password_mixed_case_count", "validate_password_special_char_count",
          "validate_password_dictionary_file", "validate_password_check_user_name"
        ].forEach(function (k) { PASSWORD_POLICY[k] = true; });
        function isPasswordKey(keyNorm) {
          return PASSWORD_KEY.test(keyNorm) && !PASSWORD_POLICY[keyNorm];
        }

        function normKey(k) {
          return k.trim().toLowerCase().replace(/-/g, "_");
        }

        function parseConfig(text) {
          var rawLines = text.split(/\r?\n/);
          var sections = [];
          var entries = [];
          var directives = [];
          var current = null;
          rawLines.forEach(function (raw, idx) {
            var lineNo = idx + 1;
            var t = raw.trim();
            if (!t) return;
            if (t.charAt(0) === "#" || t.charAt(0) === ";") return;
            if (t.charAt(0) === "!") {
              directives.push({ line: lineNo, name: t.split(/\s+/)[0] });
              return;
            }
            var sec = t.match(/^\[([^\]]+)\]\s*(?:[#;].*)?$/);
            if (sec) {
              current = { name: sec[1].trim(), norm: sec[1].trim().toLowerCase(), line: lineNo };
              sections.push(current);
              return;
            }
            var eq = raw.indexOf("=");
            var keyPart, value = null, hasEq = false;
            if (eq >= 0) {
              hasEq = true;
              keyPart = raw.slice(0, eq);
              var v = raw.slice(eq + 1).replace(/\s+[#;].*$/, "").trim();
              if (v.length >= 2 &&
                  ((v.charAt(0) === '"' && v.charAt(v.length - 1) === '"') ||
                   (v.charAt(0) === "'" && v.charAt(v.length - 1) === "'"))) {
                v = v.slice(1, -1);
              }
              value = v;
            } else {
              keyPart = raw.replace(/\s+[#;].*$/, "");
            }
            var keyRaw = keyPart.trim();
            if (!keyRaw) return;
            entries.push({
              section: current ? current.norm : null,
              sectionName: current ? current.name : null,
              keyRaw: keyRaw,
              keyNorm: normKey(keyRaw),
              value: value,
              hasEq: hasEq,
              line: lineNo
            });
          });
          return { lineCount: rawLines.length, sections: sections, entries: entries, directives: directives };
        }

        function boolOf(entry) {
          if (!entry) return null;
          if (!entry.hasEq) return true; // a bare flag means enabled
          var v = (entry.value || "").trim().toLowerCase();
          if (v === "on" || v === "true" || v === "yes" || v === "1") return true;
          if (v === "off" || v === "false" || v === "no" || v === "0" || v === "") return false;
          return true;
        }

        function audit(text) {
          var parsed = parseConfig(text);
          var findings = []; // {level, lines:[], title, detail}
          function add(level, lines, title, detail) {
            findings.push({ level: level, lines: lines, title: title, detail: detail });
          }
          function occ(keyNorm) {
            return parsed.entries.filter(function (e) {
              return AUDITED_SECTIONS.indexOf(e.section) >= 0 && e.keyNorm === keyNorm;
            });
          }
          function eff(keyNorm) {
            var o = occ(keyNorm);
            return o.length ? o[o.length - 1] : null;
          }
          function linesOf(list) { return list.map(function (e) { return e.line; }); }

          var hasServerSection = parsed.sections.some(function (s) {
            return AUDITED_SECTIONS.indexOf(s.norm) >= 0;
          });

          if (!hasServerSection) {
            add("BLOCKER", [],
              "No [mysqld] section found in the pasted text",
              "There is no server section to grade. Paste the part of the file under [mysqld] (or [server]) — settings under [client] and other sections configure client programs, not the server.");
          } else {

            /* (1) skip-grant-tables */
            var sgt = eff("skip_grant_tables");
            if (!sgt) {
              add("INFO", [],
                "skip-grant-tables is not present",
                "Login authentication is not bypassed by this file.");
            } else if (boolOf(sgt)) {
              add("BLOCKER", linesOf(occ("skip_grant_tables")),
                "skip-grant-tables is enabled — authentication is bypassed",
                "With grant tables skipped, the server performs no password or privilege checks: anyone who can reach it connects with full privileges, and account-management statements are disabled. Remove this option outside a supervised password-recovery window.");
            } else {
              add("INFO", [sgt.line],
                "skip-grant-tables is present but switched OFF (line " + sgt.line + ")",
                "Grant tables load normally, so login authentication is enforced.");
            }

            /* (2) bind-address exposure */
            var skipNet = eff("skip_networking");
            var bind = eff("bind_address");
            if (skipNet && boolOf(skipNet)) {
              add("INFO", [skipNet.line],
                "skip-networking is ON (line " + skipNet.line + ") — no TCP listener at all",
                "The server accepts socket connections only, so bind-address exposure does not apply.");
            } else if (!bind) {
              add("WARNING", [],
                "No bind-address is set under [mysqld]",
                "Without an explicit bind-address, MySQL's default is to listen on all network interfaces. Whether that is reachable from the internet depends on firewall rules and user grants — both live outside this file and were not graded.");
            } else {
              var bv = (bind.value || "").trim();
              var bvl = bv.toLowerCase();
              if (bvl === "0.0.0.0" || bvl === "::" || bvl === "*") {
                add("WARNING", linesOf(occ("bind_address")),
                  "bind-address = " + bv + " — the server listens on every network interface",
                  "Any host that can route to this machine can attempt a connection. Whether that is reachable from the internet depends on firewall rules and user grants — both live outside this file and were not graded. Bind to 127.0.0.1 unless remote clients genuinely need access.");
              } else if (bvl === "127.0.0.1" || bvl === "::1" || bvl === "localhost") {
                add("INFO", linesOf(occ("bind_address")),
                  "bind-address = " + bv + " — loopback only",
                  "Only processes on this machine can connect over TCP. Firewall rules and user grants live outside this file and were not graded.");
              } else {
                add("INFO", linesOf(occ("bind_address")),
                  "bind-address = " + bv + " — one specific interface",
                  "The server listens only on that address. Whether that interface is public depends on the machine and its firewall rules — outside this file and not graded.");
              }
            }

            /* (3) local_infile */
            var li = eff("local_infile");
            if (!li) {
              add("INFO", [],
                "local_infile is not enabled in this file",
                "LOAD DATA LOCAL is not switched on server-side by anything pasted here.");
            } else if (boolOf(li)) {
              add("WARNING", linesOf(occ("local_infile")),
                "local_infile is enabled (line " + li.line + ")",
                "With LOAD DATA LOCAL allowed, a client the server talks to can ask the connecting client to read local files (rogue-server file read). Leave it OFF unless an application genuinely loads local data files.");
            } else {
              add("INFO", [li.line],
                "local_infile is OFF (line " + li.line + ")",
                "LOAD DATA LOCAL file reads are refused server-side.");
            }

            /* (4) secure_file_priv */
            var sfp = eff("secure_file_priv");
            if (!sfp) {
              add("WARNING", [],
                "secure_file_priv is not set",
                "Unset, nothing in this file restricts LOAD DATA INFILE, SELECT ... INTO OUTFILE, or LOAD_FILE() to a single directory — file import/export follows the server account's filesystem access. Set it to one dedicated directory, or to NULL to disable file import/export.");
            } else {
              var sv = sfp.hasEq ? (sfp.value || "").trim() : "";
              if (sv === "") {
                add("WARNING", linesOf(occ("secure_file_priv")),
                  "secure_file_priv is set to an empty value (line " + sfp.line + ")",
                  "An empty secure_file_priv leaves file import/export unrestricted: LOAD DATA INFILE, SELECT ... INTO OUTFILE, and LOAD_FILE() can reach any file the server account can read or write. Set it to one dedicated directory, or to NULL to disable file import/export.");
              } else if (sv.toUpperCase() === "NULL") {
                add("INFO", linesOf(occ("secure_file_priv")),
                  "secure_file_priv = NULL (line " + sfp.line + ") — file import/export disabled",
                  "The hardened state: the server refuses LOAD DATA INFILE and SELECT ... INTO OUTFILE entirely.");
              } else {
                add("INFO", linesOf(occ("secure_file_priv")),
                  "secure_file_priv restricts file access to " + sv + " (line " + sfp.line + ")",
                  "The hardened state: file import/export is confined to that one directory.");
              }
            }

            /* (5) general_log */
            var gl = eff("general_log");
            var glf = eff("general_log_file");
            var glDest = glf && glf.value
              ? "the file " + glf.value + " (line " + glf.line + ")"
              : "the default general log file in the data directory";
            if (!gl) {
              add("INFO", [],
                "general_log is not enabled in this file",
                "The query log that records every statement is not switched on here.");
            } else if (boolOf(gl)) {
              add("WARNING", linesOf(occ("general_log")),
                "general_log is enabled (line " + gl.line + ") — every query is written to " + glDest,
                "The general query log captures full statement text, including literal values in INSERT and UPDATE statements — passwords, tokens, and personal data end up in a plain-text log. Keep it off in production; enable it briefly for debugging only.");
            } else {
              add("INFO", [gl.line],
                "general_log is OFF (line " + gl.line + ")",
                "Queries are not being captured to a log file by this configuration.");
            }

            /* (6) TLS posture */
            var rst = eff("require_secure_transport");
            var sslKeys = ["ssl_ca", "ssl_capath", "ssl_cert", "ssl_key", "ssl_cipher"].filter(function (k) {
              var e = eff(k);
              return e && e.hasEq && (e.value || "").trim() !== "";
            });
            if (rst && boolOf(rst)) {
              add("INFO", [rst.line],
                "require_secure_transport is ON (line " + rst.line + ")",
                "Clients must connect over TLS; unencrypted connections are refused.");
            } else if (sslKeys.length) {
              add("INFO", linesOf(sslKeys.map(function (k) { return eff(k); })),
                "TLS material is configured (" + sslKeys.map(function (k) { return k.replace(/_/g, "-"); }).join(", ") + "), but secure transport is not required",
                "Encrypted connections are available, yet with require_secure_transport " +
                (rst ? "switched OFF (line " + rst.line + ")" : "not set") +
                ", clients may still connect unencrypted. Set require_secure_transport = ON to refuse plain connections.");
            } else {
              add("WARNING", rst ? [rst.line] : [],
                "Unencrypted connections are accepted — no TLS is configured",
                "require_secure_transport is " + (rst ? "switched OFF (line " + rst.line + ")" : "absent") +
                " and no ssl-* settings appear in this file, so clients connect in plain text and credentials and data cross the network readable to anyone on the path.");
            }

            /* (7) allow-suspicious-udfs / automatic_sp_privileges */
            var asu = eff("allow_suspicious_udfs");
            if (asu && boolOf(asu)) {
              add("WARNING", linesOf(occ("allow_suspicious_udfs")),
                "allow-suspicious-udfs is enabled (line " + asu.line + ")",
                "This lets user-defined functions load from shared libraries that contain no function-symbol metadata — a known privilege-escalation aid once an attacker has any file-write foothold. Enable it only if you load UDF libraries you fully trust.");
            }
            var asp = eff("automatic_sp_privileges");
            if (asp && boolOf(asp)) {
              add("INFO", [asp.line],
                "automatic_sp_privileges is enabled (line " + asp.line + ")",
                "Noted: creating a stored routine automatically grants its creator EXECUTE and ALTER ROUTINE privileges on it. Convenient, but it hands out privileges without an explicit GRANT.");
            } else if (asp) {
              add("INFO", [asp.line],
                "automatic_sp_privileges is OFF (line " + asp.line + ")",
                "Stored-routine creators get no automatic EXECUTE / ALTER ROUTINE grants.");
            }
          }

          /* (8) password-shaped values — key name only, value never shown */
          parsed.entries.forEach(function (e) {
            if (isPasswordKey(e.keyNorm)) {
              add("WARNING", [e.line],
                "A value is stored under the key '" + e.keyRaw + "'" +
                  (e.sectionName ? " in [" + e.sectionName + "]" : "") + " (line " + e.line + ")",
                "Flagged by key name only — the value itself is never shown in this audit or its report. A credential sitting in a config file is readable by anyone who can read the file; move it to a protected option file (owner-only permissions) or a login path, and rotate it if this file has been shared.");
            }
          });

          /* Duplicate keys — last value wins, both lines named */
          var seen = {};
          parsed.entries.forEach(function (e) {
            if (AUDITED_SECTIONS.indexOf(e.section) < 0) return;
            var id = e.section + "|" + e.keyNorm;
            (seen[id] = seen[id] || []).push(e);
          });
          Object.keys(seen).forEach(function (id) {
            var list = seen[id];
            if (list.length < 2) return;
            var last = list[list.length - 1];
            add("INFO", linesOf(list),
              "Duplicate key '" + last.keyRaw + "' in [" + last.sectionName + "] — set on lines " +
                linesOf(list).join(" and "),
              "MySQL uses the last value when a key repeats, so the value on line " + last.line +
                " is the one graded above; the earlier setting" + (list.length > 2 ? "s are" : " is") +
                " silently overridden.");
          });

          /* NOT AUDITED — sections, keys, and include directives, by name */
          var notAudited = [];
          parsed.sections.forEach(function (s) {
            if (AUDITED_SECTIONS.indexOf(s.norm) < 0) {
              notAudited.push({
                lines: [s.line],
                title: "Section [" + s.name + "] (line " + s.line + ")",
                detail: "Only [mysqld] and [server] are graded as server configuration. The settings under [" + s.name + "] were not audited — no judgement is made about them."
              });
            }
          });
          var unknownKeys = {};
          parsed.entries.forEach(function (e) {
            if (AUDITED_SECTIONS.indexOf(e.section) < 0) return;
            if (KNOWN_KEYS[e.keyNorm] || isPasswordKey(e.keyNorm)) return;
            var id = e.section + "|" + e.keyNorm;
            (unknownKeys[id] = unknownKeys[id] || []).push(e);
          });
          Object.keys(unknownKeys).forEach(function (id) {
            var list = unknownKeys[id];
            var first = list[0];
            notAudited.push({
              lines: linesOf(list),
              title: "Key '" + first.keyRaw + "' in [" + first.sectionName + "] (line" +
                (list.length > 1 ? "s " + linesOf(list).join(", ") : " " + first.line) + ")",
              detail: "This key is outside this auditor's rule set, so it was not audited — no judgement is made about it. Check it against your server version's documentation."
            });
          });
          parsed.directives.forEach(function (d) {
            notAudited.push({
              lines: [d.line],
              title: "Directive " + d.name + " (line " + d.line + ")",
              detail: "This pulls other files into the configuration at server startup. Their contents were not pasted, so their settings were not audited."
            });
          });

          var blockers = findings.filter(function (f) { return f.level === "BLOCKER"; }).length;
          var warnings = findings.filter(function (f) { return f.level === "WARNING"; }).length;
          var infos = findings.filter(function (f) { return f.level === "INFO"; }).length;
          var verdict, verdictClass;
          if (blockers > 0) { verdict = "DO NOT DEPLOY"; verdictClass = "blocker"; }
          else if (warnings > 0) { verdict = "DEPLOY WITH FIXES"; verdictClass = "warning"; }
          else { verdict = "SAFE TO DEPLOY"; verdictClass = "ok"; }

          var byLine = function (a, b) {
            var la = a.lines.length ? a.lines[0] : 0;
            var lb = b.lines.length ? b.lines[0] : 0;
            return la - lb;
          };
          findings.sort(function (a, b) {
            var order = { BLOCKER: 0, WARNING: 1, INFO: 2 };
            if (order[a.level] !== order[b.level]) return order[a.level] - order[b.level];
            return byLine(a, b);
          });
          notAudited.sort(byLine);

          return {
            verdict: verdict,
            verdictClass: verdictClass,
            counts: { blocker: blockers, warning: warnings, info: infos, na: notAudited.length },
            findings: findings,
            notAudited: notAudited,
            lineCount: parsed.lineCount
          };
        }

        function lineLabel(lines) {
          if (!lines || !lines.length) return "No line — setting absent from the file";
          if (lines.length === 1) return "Line " + lines[0];
          return "Lines " + lines.join(", ");
        }

        function verdictSentence(result) {
          if (result.verdict === "DO NOT DEPLOY") {
            return "At least one blocker must be fixed before this configuration goes anywhere near a live server.";
          }
          if (result.verdict === "DEPLOY WITH FIXES") {
            return "No blockers, but one or more warnings should be fixed before this configuration is deployed.";
          }
          return "No blockers and no warnings in what the file says. The limits below still apply — accounts and grants live in the database, not in this file.";
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "CLEAN_EXAMPLE": (typeof CLEAN_EXAMPLE !== 'undefined' ? CLEAN_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-mysql-server-config-safety-auditortm',
  name: 'J-Dawgs MySQL Server Config Safety Auditor',
  description: 'The server only complains when it fails to start; ours grades a pasted my.cnf anywhere — skip-grant-tables, bind exposure, local_infile, secure_file_priv, general_log, and TLS — into one deploy verdict, with duplicate keys graded last-value-wins.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "CLEAN_EXAMPLE": __core["CLEAN_EXAMPLE"] }
};
