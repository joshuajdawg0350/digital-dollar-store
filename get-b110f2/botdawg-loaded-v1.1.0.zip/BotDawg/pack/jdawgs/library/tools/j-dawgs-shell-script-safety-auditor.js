'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Shell Script Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var RISKY_EXAMPLE = [
          "#!/bin/bash",
          "# deploy.sh - build the app and push it to the server",
          'API_TOKEN="sk_live_9f3Kx7Qp2mZ8vR4tY6wN"',
          "BUILD_DIR=/tmp/app-build",
          "FILES=$BUILD_DIR/*",
          "",
          "curl -fsSL https://downloads.example.com/install.sh | sh",
          "rm -rf $BUILD_DIR/",
          "cp $FILES /srv/app/",
          "chmod -R 777 /srv/app",
          "cd /srv/app",
          "rm -rf old-backups"
        ].join("\n");

        var CLEAN_EXAMPLE = [
          "#!/usr/bin/env bash",
          "set -euo pipefail",
          "",
          'BUILD_DIR="/tmp/myapp-build"',
          'LOG_FILE="$BUILD_DIR/build.log"',
          "",
          'mkdir -p "$BUILD_DIR"',
          'echo "Building into $BUILD_DIR" | tee "$LOG_FILE"',
          'cp -r "src/" "$BUILD_DIR/"',
          'echo "Build finished: $BUILD_DIR"'
        ].join("\n");

        var SYS_DIRS = "etc|usr|bin|sbin|boot|lib";
        var SECRET_NAME = /pass(word|wd)?|token|secret|api[-_]?key|private[-_]?key|access[-_]?key|auth[-_]?key|credential/i;
        var SECRET_PATTERNS = [
          { re: /sk_(live|test)_[A-Za-z0-9_\-]{6,}/g, label: "a Stripe-style secret key" },
          { re: /AKIA[0-9A-Z]{16}/g, label: "an AWS-style access key ID" },
          { re: /ghp_[A-Za-z0-9]{20,}/g, label: "a GitHub-style personal access token" },
          { re: /github_pat_[A-Za-z0-9_]{20,}/g, label: "a GitHub-style personal access token" },
          { re: /xox[baprs]-[A-Za-z0-9-]{8,}/g, label: "a Slack-style token" },
          { re: /AIza[0-9A-Za-z_\-]{20,}/g, label: "a Google-style API key" },
          { re: /-----BEGIN [A-Z ]*PRIVATE KEY-----/g, label: "an embedded private key block" }
        ];

        function esc(s) {
          return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
        }

        function maskLine(line, secretValues) {
          var out = line;
          secretValues.forEach(function (v) {
            if (v && v.length >= 4) out = out.split(v).join("••••••••");
          });
          SECRET_PATTERNS.forEach(function (p) {
            out = out.replace(p.re, "••••••••");
          });
          return out;
        }

        function isCommentOrBlank(t) { return t === "" || t.charAt(0) === "#"; }

        function audit(src) {
          var lines = src.split(/\r?\n/);
          var findings = [];
          var secretValues = [];

          function add(pass, sev, lineNo, title, quote, why, fix) {
            findings.push({ pass: pass, sev: sev, line: lineNo, title: title, quote: quote, why: why, fix: fix });
          }

          // ---- script-level facts ----
          var hasSetE = false, hasPipefail = false;
          var hasChecksum = /sha256sum|sha512sum|shasum|md5sum|gpg\b[^|]*--verify|cosign\s+verify|checksum|signature/i.test(src);
          lines.forEach(function (raw) {
            var t = raw.trim();
            if (isCommentOrBlank(t)) return;
            var m = t.match(/^set\s+(.+)$/);
            if (m) {
              var toks = m[1].split(/\s+/);
              for (var i = 0; i < toks.length; i++) {
                var tk = toks[i];
                if (/^-[a-zA-Z]+$/.test(tk) && tk.indexOf("e") !== -1) hasSetE = true;
                if (tk === "-o" && toks[i + 1] === "errexit") hasSetE = true;
                if (tk === "-o" && toks[i + 1] === "pipefail") hasPipefail = true;
                if (/pipefail/.test(tk)) hasPipefail = true;
              }
            }
          });
          var hasShebang = /^#!/.test(lines[0] || "");

          var destructiveLines = [], downloadLines = [], pipeLines = [];

          // ---- PASS 1 ----
          lines.forEach(function (raw, idx) {
            var lineNo = idx + 1;
            var t = raw.trim();
            if (isCommentOrBlank(t)) return;
            var flaggedPipe = false, flaggedWrite = false;

            // Secrets: NAME=value assignments
            var am = t.match(/^(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*$/);
            var secretOnLine = false;
            if (am && SECRET_NAME.test(am[1])) {
              var rawVal = am[2];
              var val = rawVal.replace(/^["']|["']$/g, "");
              if (val.length >= 4 && val.charAt(0) !== "$" && !/^(changeme|change-me|example|placeholder|your[-_]|xxx+|\*+|<)/i.test(val)) {
                secretValues.push(rawVal); secretValues.push(val);
                add(1, "BLOCKER", lineNo, "Hardcoded secret in the script (" + am[1] + ")",
                  maskLine(raw, secretValues),
                  "A credential is written into the script in plain text. Anyone who receives this file — or any log, paste, or repo it lands in — has the secret. It is shown masked here, by key name only.",
                  "Move the secret out of the script: read " + am[1] + " from an environment variable or a permissions-locked secrets file, and rotate this value — once a secret is in a file, treat it as exposed.");
                secretOnLine = true;
              }
            }
            // Secrets: credential-looking literals
            if (!secretOnLine) {
              for (var pi = 0; pi < SECRET_PATTERNS.length; pi++) {
                var p = SECRET_PATTERNS[pi];
                p.re.lastIndex = 0;
                var lm = raw.match(p.re);
                if (lm) {
                  lm.forEach(function (v) { secretValues.push(v); });
                  add(1, "BLOCKER", lineNo, "Credential-looking literal in the script",
                    maskLine(raw, secretValues),
                    "This line contains what looks like " + p.label + ", embedded directly in the script. It is shown masked here — the value itself never needs to be in the file.",
                    "Remove the literal, load the credential from the environment or a secrets store at run time, and rotate it: a secret that has travelled inside a script should be treated as leaked.");
                  break;
                }
              }
            }

            // Remote code pipes
            if (/\b(curl|wget)\b[^|;]*\|\s*(?:sudo\s+)?(sh|bash|zsh|dash|ash|python3?|perl|ruby|node|php)\b/.test(t) ||
                /\b(sh|bash)\s+<\(\s*(curl|wget)\b/.test(t) ||
                /eval\s+[^;]*(curl|wget)/.test(t)) {
              add(1, "BLOCKER", lineNo, "Downloaded code is piped straight into an interpreter",
                maskLine(raw, secretValues),
                "Whatever the server (or anyone who compromises it, or the connection) returns is executed immediately, unreviewed, with this user's full permissions. There is no chance to read it first.",
                "Download to a file as its own step, read the file, verify its published checksum or signature, and only then run it: curl -fsSLO <url> ; sha256sum -c <checksums> ; sh <file>.");
              flaggedPipe = true;
            }

            // dd to a device
            if (/\bdd\b/.test(t) && /of=\/dev\/[^\s"']+/.test(t)) {
              add(1, "BLOCKER", lineNo, "dd writes directly to a device",
                maskLine(raw, secretValues),
                "dd with of=/dev/… overwrites the raw device — a wrong device name here erases a disk, silently and irreversibly.",
                "Confirm the exact target device first (lsblk), and write to an image file (of=./disk.img) unless overwriting that specific device is truly the intent.");
            }
            // mkfs
            if (/\bmkfs(\.[a-z0-9]+)?\b/.test(t) || /\bwipefs\b/.test(t)) {
              add(1, "BLOCKER", lineNo, "Filesystem format command",
                maskLine(raw, secretValues),
                "mkfs erases the target device and lays down a fresh filesystem. In a script, a wrong or shifted variable turns this into data loss with no prompt.",
                "Take formatting out of the script and run it manually against a verified device name, after a backup — or at minimum guard it behind an explicit typed confirmation.");
            }

            // rm analysis
            var rmM = t.match(/(?:^|[;&|]\s*)(?:sudo\s+)?rm\s+([^;&|]+)/);
            if (rmM) {
              destructiveLines.push(lineNo);
              var toks = rmM[1].split(/\s+/).filter(Boolean);
              var recursive = false, force = false, targets = [];
              toks.forEach(function (tk) {
                if (tk === "--recursive") recursive = true;
                else if (tk === "--force") force = true;
                else if (/^-[a-zA-Z]+$/.test(tk)) { if (tk.indexOf("r") !== -1 || tk.indexOf("R") !== -1) recursive = true; if (tk.indexOf("f") !== -1) force = true; }
                else targets.push(tk);
              });
              var worst = null;
              targets.forEach(function (tg) {
                var clean = tg.replace(/^["']|["']$/g, "");
                if (clean === "/" || clean === "/*" || clean === "~" || clean === "$HOME" || clean === "${HOME}") {
                  worst = { sev: "BLOCKER", title: "rm aimed at root or the home directory",
                    why: "The delete target is " + clean + " itself. Run as written, this attempts to wipe the whole filesystem or the user's entire home directory.",
                    fix: "Name the exact subdirectory to clear, print it and list it (echo, ls) before deleting, and never let a bare / or $HOME reach rm." };
                } else if (recursive && /\$[A-Za-z_{]/.test(tg) && tg.charAt(0) !== '"' && tg.charAt(0) !== "'") {
                  if (!worst || worst.sev !== "BLOCKER") {
                    var varName = (tg.match(/\$({)?([A-Za-z_][A-Za-z0-9_]*)/) || [])[2] || "the variable";
                    worst = { sev: "BLOCKER", title: "rm -rf on an unquoted variable path (" + tg + ")",
                      why: "The target is built from $" + varName + ", unquoted. If " + varName + " is empty or unset when this runs, a target like $" + varName + "/ collapses to / and rm -rf starts deleting from the root of the filesystem.",
                      fix: "Quote it and guard it: use \"${" + varName + ":?variable is empty}\" so the script dies if it is unset, check [ -n \"$" + varName + "\" ] && [ \"$" + varName + "\" != \"/\" ], then rm -rf \"$" + varName + "/\"." };
                  }
                } else if (recursive && new RegExp("^/(" + SYS_DIRS + ")(/|$)").test(clean)) {
                  if (!worst) worst = { sev: "BLOCKER", title: "Recursive delete on a system path",
                    why: "This recursively deletes inside a system directory (" + clean + "). That can remove parts of the operating system itself, not just the app's files.",
                    fix: "Point the delete at a path inside your own project or data directory, and let the OS package manager own system paths." };
                } else if (recursive && force) {
                  if (!worst) worst = { sev: "WARNING", title: "rm -rf deletes without asking",
                    why: "Recursive + forced delete: everything under the target goes, with no prompt and no undo. A wrong working directory or a stale path makes this bite.",
                    fix: "Echo and ls the target before deleting, quote it, and while testing use rm -r without -f so the shell confirms each removal." };
                }
              });
              if (worst) add(1, worst.sev, lineNo, worst.title, maskLine(raw, secretValues), worst.why, worst.fix);
            }

            // chmod 777
            var chM = t.match(/(?:^|[;&|]\s*)(?:sudo\s+)?chmod\s+([^;&|]+)/);
            if (chM) {
              var ctoks = chM[1].split(/\s+/).filter(Boolean);
              var crec = ctoks.some(function (x) { return x === "--recursive" || (/^-[a-zA-Z]+$/.test(x) && (x.indexOf("R") !== -1)); });
              var has777 = ctoks.some(function (x) { return /^[0-7]{3,4}$/.test(x) && /777$/.test(x); }) || /a\+rwx|o\+w/.test(chM[1]);
              if (has777 && crec) {
                destructiveLines.push(lineNo);
                add(1, "BLOCKER", lineNo, "chmod -R 777 makes everything world-writable",
                  maskLine(raw, secretValues),
                  "Every file and folder under the target becomes readable, writable, and executable by every user and process on the machine — any compromised account can replace the app's own code with its own.",
                  "Use least privilege instead: chmod -R u=rwX,go=rX (755/644 in practice), and open write access only on the single folder that genuinely needs it.");
              } else if (has777) {
                destructiveLines.push(lineNo);
                add(1, "WARNING", lineNo, "chmod 777 makes the target world-writable",
                  maskLine(raw, secretValues),
                  "Mode 777 lets any user or process on the machine modify the target — including replacing a file the script later executes.",
                  "Use 755 for programs and directories, 644 for data files, and grant write access to a group instead of to everyone.");
              }
            }

            // chown -R on system paths
            var coM = t.match(/(?:^|[;&|]\s*)(?:sudo\s+)?chown\s+([^;&|]+)/);
            if (coM) {
              var kotoks = coM[1].split(/\s+/).filter(Boolean);
              var korec = kotoks.some(function (x) { return x === "--recursive" || (/^-[a-zA-Z]+$/.test(x) && x.indexOf("R") !== -1); });
              var sysTarget = kotoks.some(function (x) { return new RegExp("^/(" + SYS_DIRS + ")(/|$)").test(x.replace(/^["']|["']$/g, "")); });
              if (korec && sysTarget) {
                destructiveLines.push(lineNo);
                add(1, "BLOCKER", lineNo, "chown -R on a system path",
                  maskLine(raw, secretValues),
                  "Recursively changing ownership inside a system directory can break the OS and silently strip the permission boundaries other programs rely on.",
                  "Leave ownership of system paths to the package manager; chown -R only directories your own app owns.");
              }
            }

            // Writes to system paths
            var writeHit = />>?\s*\/(etc|usr|bin|sbin|boot|lib)\b/.test(t) ||
              /\btee\s+[^|]*\/(etc|usr|bin|sbin|boot|lib)\b/.test(t) ||
              (function () {
                var cm = t.match(/(?:^|[;&|]\s*)(?:sudo\s+)?(cp|mv|install)\s+([^;&|]+)/);
                if (!cm) return false;
                var parts = cm[2].split(/\s+/).filter(Boolean);
                var last = (parts[parts.length - 1] || "").replace(/^["']|["']$/g, "");
                return new RegExp("^/(" + SYS_DIRS + ")(/|$)").test(last);
              })();
            if (writeHit && !flaggedWrite) {
              add(1, "WARNING", lineNo, "Write into a system path",
                maskLine(raw, secretValues),
                "This writes directly into a system directory (/etc, /usr, /bin, /boot class paths). It needs root to succeed, affects the whole machine rather than just this app, and is hard to undo cleanly.",
                "Write to a user-owned location instead; if a system file truly must change, stage the new file in a temp path, review it, and install it with one deliberate, visible step.");
              flaggedWrite = true;
            }

            // sudo
            if (/\bsudo\b/.test(t)) {
              add(1, "WARNING", lineNo, "Runs a command with sudo",
                maskLine(raw, secretValues),
                "sudo gives this step root power: a mistake, a bad path, or a hijacked download stops being an app problem and becomes a whole-machine problem. A script that sudos freely also trains its operator to type the password without thinking.",
                "Keep sudo off the script as a whole; put it only on the single command that truly needs root, and let everything else run as the normal user.");
            }

            // Downloads
            if (/\b(curl|wget)\b/.test(t) && /https?:\/\//.test(t)) {
              downloadLines.push(lineNo);
              if (!flaggedPipe && !hasChecksum) {
                add(1, "WARNING", lineNo, "Download with no checksum or signature check",
                  maskLine(raw, secretValues),
                  "The script downloads a file and nothing anywhere in the script verifies a checksum or a signature for it — whatever arrives is trusted as-is. (A warning, not a proven fault: verification might happen outside this script.)",
                  "After downloading, verify before use: compare against the publisher's sha256 checksum (sha256sum -c) or check a detached signature, and fail the script if it does not match.");
              }
            }

            if (/[^|]\|[^|]/.test(t)) pipeLines.push(lineNo);
          });

          // Missing error handling (script-level, Pass 1)
          var firstRiskLine = destructiveLines.concat(downloadLines).sort(function (a, b) { return a - b; })[0];
          if (!hasSetE && (destructiveLines.length || downloadLines.length)) {
            add(1, "WARNING", firstRiskLine, "No set -e: failures will not stop the script",
              maskLine(lines[firstRiskLine - 1] || "", secretValues),
              "The script performs destructive or download steps but never sets set -e. If an early step fails — a download dies, a directory is missing — the script keeps going and runs the later steps against a half-finished state.",
              "Add set -e on its own line right after the shebang (combine as set -euo pipefail in bash), so the first failure stops the run.");
          }
          if (!hasPipefail && pipeLines.length && (downloadLines.length || destructiveLines.length)) {
            var pl = pipeLines[0];
            add(1, "WARNING", pl, "No set -o pipefail: a failed pipe stage looks like success",
              maskLine(lines[pl - 1] || "", secretValues),
              "A pipeline's exit status is its last command's status. Without pipefail, a download that fails at the left of a pipe can still 'succeed' overall, and the script proceeds as if the data arrived.",
              "Add set -o pipefail (or use set -euo pipefail in bash) so any failing stage fails the whole pipeline.");
          }

          // ---- PASS 2 ----
          if (!hasShebang) {
            add(2, "WARNING", 1, "Missing shebang",
              maskLine(lines[0] || "", secretValues),
              "The first line does not name an interpreter (#!/bin/bash or similar). Whoever runs the file gets whatever shell happens to invoke it, and bash-isms can fail — or worse, half-work — under a different shell.",
              "Add a first line naming the interpreter the script was written for, e.g. #!/usr/bin/env bash.");
          }

          // Precompute cd-risk: cd without guard + later relative-path destructive command
          var cdRisk = {};
          lines.forEach(function (raw, idx) {
            var t = raw.trim();
            if (isCommentOrBlank(t)) return;
            if (/^cd\s+\S+/.test(t) && !/(&&|\|\|)/.test(raw)) {
              for (var j = idx + 1; j < lines.length; j++) {
                var lt = lines[j].trim();
                if (isCommentOrBlank(lt)) continue;
                var dm = lt.match(/(?:^|[;&|]\s*)(?:sudo\s+)?(rm|mv|cp|chmod|chown)\s+([^;&|]+)/);
                if (dm) {
                  var parts = dm[2].split(/\s+/).filter(function (x) { return x.charAt(0) !== "-"; });
                  var rel = parts.some(function (x) { var c = x.replace(/^["']|["']$/g, ""); return c && c.charAt(0) !== "/" && c.charAt(0) !== "$" && c.charAt(0) !== "~"; });
                  if (rel) { cdRisk[idx] = j + 1; break; }
                }
              }
            }
          });

          lines.forEach(function (raw, idx) {
            var lineNo = idx + 1;
            var t = raw.trim();
            if (isCommentOrBlank(t)) return;

            // Spaces around = in assignments
            if (!/==/.test(t)) {
              var sm = t.match(/^(?:export\s+|local\s+)?([A-Za-z_][A-Za-z0-9_]*)(\s*)=(\s*)(\S.*)?$/);
              if (sm && (sm[2] !== "" || sm[3] !== "") && sm[4] !== undefined) {
                add(2, "WARNING", lineNo, "Spaces around = in an assignment",
                  maskLine(raw, secretValues),
                  "In shell, NAME = value is not an assignment — it runs NAME as a command with = and the value as arguments. The variable is never set, and whatever runs later sees it empty.",
                  "Remove the spaces: write " + sm[1] + "=value with nothing on either side of the =.");
              }
            }

            // Unquoted variable expansions
            var isAssign = /^(?:export\s+|local\s+|declare\s+)?[A-Za-z_][A-Za-z0-9_]*=/.test(t);
            if (!isAssign && !/^\[\[/.test(t) && !/^case\b/.test(t)) {
              var stripped = raw.replace(/"[^"]*"/g, '""').replace(/'[^']*'/g, "''");
              var vars = [], vm, vre = /\$(?:\{([A-Za-z_][A-Za-z0-9_]*)[^}]*\}|([A-Za-z_][A-Za-z0-9_]*))/g;
              while ((vm = vre.exec(stripped)) !== null) {
                var vn = vm[1] || vm[2];
                if (vars.indexOf(vn) === -1) vars.push(vn);
              }
              if (vars.length) {
                add(2, "WARNING", lineNo, "Unquoted variable expansion (" + vars.map(function (v) { return "$" + v; }).join(", ") + ")",
                  maskLine(raw, secretValues),
                  "Unquoted, the expansion is word-split and glob-expanded after substitution: a value containing spaces becomes several arguments, and an empty value vanishes — commands end up acting on different paths than the ones written.",
                  "Wrap each expansion in double quotes — " + vars.map(function (v) { return "\"$" + v + "\""; }).join(", ") + " — so the value is always passed as exactly one argument.");
              }
            }

            // ~ inside quotes
            if (/["'][^"'\n]*~(?:\/|["'])/.test(raw)) {
              add(2, "WARNING", lineNo, "Tilde inside quotes never expands",
                maskLine(raw, secretValues),
                "A ~ only expands to the home directory when it is unquoted at the start of a word. Inside quotes it stays a literal tilde character, so the path points at a folder actually named ~ — which usually does not exist.",
                "Use \"$HOME/…\" instead of \"~/…\" so the path expands to the real home directory.");
            }

            // Backticks
            if (raw.indexOf("`") !== -1) {
              add(2, "INFO", lineNo, "Backtick substitution where $() is clearer",
                maskLine(raw, secretValues),
                "Backticks still work, but they nest badly and are easy to misread next to quotes. Info only — this is a clarity note, not a fault.",
                "Rewrite `command` as $(command): it nests cleanly and reads the same everywhere.");
            }

            // cd without failure handling
            if (cdRisk[idx] !== undefined && !hasSetE) {
              add(2, "WARNING", lineNo, "cd with no failure handling, before relative-path destructive commands",
                maskLine(raw, secretValues),
                "This cd is not guarded with && or ||, and the script has no set -e. If the cd fails, the script keeps running in the wrong directory — and a later command (line " + cdRisk[idx] + ") acts on a relative path there, deleting or overwriting whatever happens to match.",
                "Guard the change of directory: cd <path> || exit 1 — or chain the next step with && — so a failed cd stops the script before anything relative runs.");
            }
          });

          var rank = { BLOCKER: 0, WARNING: 1, INFO: 2 };
          findings.sort(function (a, b) {
            if (a.pass !== b.pass) return a.pass - b.pass;
            if (rank[a.sev] !== rank[b.sev]) return rank[a.sev] - rank[b.sev];
            return a.line - b.line;
          });

          var counts = { BLOCKER: 0, WARNING: 0, INFO: 0 };
          findings.forEach(function (f) { counts[f.sev]++; });
          var verdict = counts.BLOCKER > 0 ? "DO NOT RUN" : (counts.WARNING > 0 ? "RUN WITH FIXES" : "SAFE TO RUN");
          return { findings: findings, counts: counts, verdict: verdict, lineCount: lines.length };
        }

        function buildReport(result, lineCount) {
          var out = [];
          out.push("J-DAWGS SHELL SCRIPT SAFETY AUDITOR - AUDIT REPORT");
          out.push("==================================================");
          out.push("Verdict: " + result.verdict);
          out.push("Blockers: " + result.counts.BLOCKER + "  |  Warnings: " + result.counts.WARNING + "  |  Info: " + result.counts.INFO);
          out.push("Lines audited: " + lineCount);
          out.push("");
          if (result.findings.length === 0) {
            out.push("FINDINGS");
            out.push("--------");
            out.push("None. These checks found no risks in the script.");
            out.push("(SAFE TO RUN means no risks were found by these checks - not a guarantee.)");
          } else {
            out.push("FINDINGS");
            out.push("--------");
            result.findings.forEach(function (f) {
              out.push("");
              out.push("[" + f.sev + "] Pass " + f.pass + " - Line " + f.line + " - " + f.title);
              out.push("  Line: " + f.quote.replace(/^\s+/, ""));
              out.push("  Why:  " + f.why);
              out.push("  Fix:  " + f.fix);
            });
            out.push("");
            out.push("CHECKLIST BEFORE RUNNING");
            out.push("------------------------");
            checklistItems(result).forEach(function (item, i) {
              out.push((i + 1) + ". [ ] Line " + item.line + ": " + item.fix);
            });
          }
          out.push("");
          out.push("Note: heuristic audit of pasted text - not a full shell parser, not a");
          out.push("replacement for a real linter, and the script was never executed.");
          return out.join("\n");
        }

        function checklistItems(result) {
          var rank = { BLOCKER: 0, WARNING: 1, INFO: 2 };
          var items = result.findings.slice().sort(function (a, b) {
            if (rank[a.sev] !== rank[b.sev]) return rank[a.sev] - rank[b.sev];
            return a.line - b.line;
          });
          var seen = {}, out = [];
          items.forEach(function (f) {
            var key = f.line + "|" + f.fix;
            if (!seen[key]) { seen[key] = true; out.push(f); }
          });
          return out;
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "CLEAN_EXAMPLE": (typeof CLEAN_EXAMPLE !== 'undefined' ? CLEAN_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-shell-script-safety-auditor',
  name: 'J-Dawgs Shell Script Safety Auditor',
  description: 'Grades a pasted shell script\'s run-safety posture (destructive commands, remote pipes, masked secrets) plus correctness pitfalls, one run verdict',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "CLEAN_EXAMPLE": __core["CLEAN_EXAMPLE"] }
};
