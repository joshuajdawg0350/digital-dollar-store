'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs MCP Permission Least-Privilege Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the analyze function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var $ = function (id) { return document.getElementById(id); };
      var inputEl = $("configInput");
      var statusEl = $("statusMsg");
      var resultsEl = $("results");

      var overrides = {};        // "server::tool" -> corrected class
      var lastConfig = null;     // last successfully parsed config object
      var lastReportText = "";

      /* ---------------- samples ---------------- */

      var DANGEROUS_SAMPLE = {
        mcpServers: {
          "github": {
            command: "npx",
            args: ["-y", "@modelcontextprotocol/server-github"],
            env: { GITHUB_PERSONAL_ACCESS_TOKEN: "REPLACE_WITH_YOUR_TOKEN" },
            tools: [
              "get_file_contents", "list_issues", "search_code",
              "push_files", "create_pull_request", "merge_pull_request",
              "delete_file"
            ]
          },
          "filesystem": {
            command: "npx",
            args: ["-y", "@modelcontextprotocol/server-filesystem", "/Users/joshua"],
            env: { GITHUB_PERSONAL_ACCESS_TOKEN: "REPLACE_WITH_YOUR_TOKEN" },
            tools: ["read_file", "list_directory", "write_file", "move_file", "delete_file"]
          }
        }
      };

      var MINIMAL_SAMPLE = {
        mcpServers: {
          "docs-lookup": {
            command: "npx",
            args: ["-y", "@example/mcp-docs-server", "--read-only", "/home/dev/projects/handbook"],
            readOnly: true,
            env: { DOCS_API_KEY: "REPLACE_WITH_YOUR_KEY" },
            tools: ["search_docs", "read_page", "get_toc", "list_sections"]
          }
        }
      };

      /* ---------------- helpers ---------------- */

      function esc(s) {
        return String(s)
          .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
          .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
      }

      function tokensOf(name) {
        return String(name)
          .replace(/([a-z0-9])([A-Z])/g, "$1_$2")
          .toLowerCase()
          .split(/[^a-z0-9]+/)
          .filter(Boolean);
      }

      var CLASS_TOKENS = [
        ["DELETE", ["delete", "remove", "destroy", "drop", "erase", "purge", "unlink", "revoke", "wipe", "trash", "kill", "terminate"]],
        ["EXECUTE", ["exec", "execute", "shell", "bash", "sh", "zsh", "terminal", "command", "cmd", "run", "spawn", "eval", "process", "powershell", "script"]],
        ["WRITE", ["write", "create", "update", "edit", "push", "merge", "send", "post", "upload", "add", "set", "modify", "commit", "publish", "move", "rename", "insert", "patch", "approve", "deploy", "invite", "assign", "make", "save", "store", "put", "close", "reopen", "fork", "apply", "submit", "register", "append"]],
        ["READ", ["get", "list", "read", "search", "find", "query", "view", "describe", "show", "lookup", "check", "status", "info", "load", "retrieve", "count", "print", "cat", "ls", "head", "inspect", "fetchdata"]],
        ["NETWORK", ["fetch", "http", "https", "request", "browse", "browser", "crawl", "scrape", "web", "url", "download", "curl", "wget", "proxy", "webhook", "ping", "socket", "connect"]]
      ];

      function classifyTool(name) {
        var toks = tokensOf(name);
        var i, j, set;
        for (i = 0; i < CLASS_TOKENS.length; i++) {
          set = CLASS_TOKENS[i][1];
          for (j = 0; j < toks.length; j++) {
            if (set.indexOf(toks[j]) !== -1) return CLASS_TOKENS[i][0];
          }
        }
        return "UNKNOWN";
      }

      /* Secret-value detection: a value is inspected ONLY to decide whether it
         must be flagged. It is never rendered; the flag shows key name + the
         first 3 characters, masked. */
      function looksLikeSecret(value) {
        if (typeof value !== "string") return false;
        var v = value.trim();
        if (!v) return false;
        // Obvious placeholders are fine.
        if (/^(replace|your|placeholder|example|sample|dummy|test|xxx+|changeme|todo|none|null|undefined|insert|put-your|enter-your)/i.test(v)) return false;
        if (/^\$\{.+\}$/.test(v) || /^<.+>$/.test(v)) return false; // ${VAR} / <placeholder>
        if (/REPLACE|YOUR[_-]?(KEY|TOKEN|SECRET|PASSWORD)|PLACEHOLDER|EXAMPLE/i.test(v)) return false;
        // Known live-key prefixes and key material.
        if (/^(sk-|sk_|ghp_|gho_|ghu_|ghs_|ghr_|github_pat_|AKIA|ASIA|xox[baprs]-|AIza|-----BEGIN)/.test(v)) return true;
        if (v.indexOf("-----BEGIN") !== -1) return true;
        // Long, spaceless, high-variety string reads as a real credential.
        if (v.length >= 24 && !/\s/.test(v)) {
          var classes = 0;
          if (/[a-z]/.test(v)) classes++;
          if (/[A-Z]/.test(v)) classes++;
          if (/[0-9]/.test(v)) classes++;
          if (/[^A-Za-z0-9]/.test(v)) classes++;
          if (classes >= 3) return true;
          if (v.length >= 32 && classes >= 2) return true;
        }
        return false;
      }

      function toolNamesOf(server) {
        var t = server.tools;
        var names = [];
        if (Array.isArray(t)) {
          t.forEach(function (item) {
            if (typeof item === "string") names.push(item);
            else if (item && typeof item === "object" && typeof item.name === "string") names.push(item.name);
          });
        } else if (t && typeof t === "object") {
          names = Object.keys(t);
        }
        return names;
      }

      function argsOf(server) {
        return Array.isArray(server.args) ? server.args.map(String) : [];
      }

      function envOf(server) {
        return (server.env && typeof server.env === "object" && !Array.isArray(server.env)) ? server.env : {};
      }

      function hasReadOnlySignal(server, args) {
        if (server.readOnly === true || server.readonly === true || server["read-only"] === true) return true;
        for (var i = 0; i < args.length; i++) {
          if (/^--?read[-_]?only$/i.test(args[i]) || /^--?readonly$/i.test(args[i])) return true;
        }
        return false;
      }

      // Classify one filesystem-ish path argument.
      function pathVerdict(p) {
        var s = p.trim();
        if (s === "/" || s === "/*") return { broad: true, why: "the filesystem root — every file on the machine" };
        if (s === "~" || s === "~/" || s === "$HOME" || s === "%USERPROFILE%") return { broad: true, why: "the entire home directory" };
        if (/^\/(Users|home)\/[^\/]+\/?$/.test(s)) return { broad: true, why: "a whole home directory (" + s + ")" };
        if (/^[A-Za-z]:\\?$/.test(s) || /^[A-Za-z]:\/$/.test(s)) return { broad: true, why: "a whole drive root (" + s + ")" };
        if (/^[A-Za-z]:\\Users\\[^\\]+\/?$/.test(s)) return { broad: true, why: "a whole home directory (" + s + ")" };
        if (s === "/etc" || s === "/var" || s.indexOf("/System") === 0) return { broad: true, why: "a system directory (" + s + ")" };
        return { broad: false };
      }

      function isPathArg(a) {
        return /^(\/|~|\$HOME|[A-Za-z]:[\\/])/.test(a) && !/^--/.test(a);
      }

      var LOOKUP_NAME = /(search|lookup|look-up|docs|doc-|reader|read|query|fetch|find|browser|web|wiki|reference|index)/i;
      var PRIVATE_NAME = /(github|gitlab|bitbucket|drive|gmail|mail|slack|notion|dropbox|database|postgres|mysql|mongo|redis|s3|aws|gcp|azure|vault|bank|salesforce|linear|jira)/i;
      var CRED_KEY = /(TOKEN|KEY|SECRET|PASSWORD|PASSWD|AUTH|PAT|CREDENTIAL|SESSION|COOKIE)/i;
      var BROAD_KEY = /(ADMIN|FULL|ROOT|MASTER|SUPER|ALL_ACCESS|OWNER)/i;

      /* ---------------- analysis ---------------- */

      function analyze(config) {
        var serversObj = (config.mcpServers && typeof config.mcpServers === "object") ? config.mcpServers : config;
        var names = Object.keys(serversObj).filter(function (k) {
          return serversObj[k] && typeof serversObj[k] === "object";
        });

        // Credential key -> servers using it (names only, never values).
        var keyToServers = {};
        names.forEach(function (n) {
          Object.keys(envOf(serversObj[n])).forEach(function (k) {
            (keyToServers[k] = keyToServers[k] || []).push(n);
          });
        });

        var servers = names.map(function (name) {
          return analyzeServer(name, serversObj[name], keyToServers);
        });

        // Cross-server toxic flow: shared credential where, across the servers
        // sharing it, read + private + write/delete coexist.
        Object.keys(keyToServers).forEach(function (key) {
          var holders = keyToServers[key];
          if (holders.length < 2 || !CRED_KEY.test(key)) return;
          var byName = {};
          servers.forEach(function (s) { byName[s.name] = s; });
          var hasRead = false, hasWrite = false, hasPrivate = false;
          holders.forEach(function (hn) {
            var s = byName[hn];
            if (!s) return;
            if (s.counts.READ > 0) hasRead = true;
            if (s.counts.WRITE > 0 || s.counts.DELETE > 0 || s.counts.EXECUTE > 0) hasWrite = true;
            if (s.privateSignal) hasPrivate = true;
          });
          if (hasRead && hasWrite && hasPrivate) {
            holders.forEach(function (hn) {
              var s = byName[hn];
              if (!s) return;
              if (!s.findings.some(function (f) { return f.id === "toxic-cross"; })) {
                s.findings.push({
                  id: "toxic-cross", sev: "high",
                  title: "TOXIC FLOW (shared credential): one credential key — " + key + " — is shared by " + holders.length + " servers (" + holders.join(", ") + "), and across them readable content, private data, and a write/delete path all sit under that single credential. Anything one server can read can be carried to anything another can write. Give each server its own narrowly-scoped credential, or drop the write tools.",
                  evidence: "env key \"" + key + "\" appears in: " + holders.join(", ")
                });
                s.score += 4;
              }
            });
          }
        });

        servers.forEach(function (s) {
          s.verdict = s.score <= 0 ? "MINIMAL" : (s.score >= 6 ? "DANGEROUS" : "BROAD");
        });

        var worst = "MINIMAL";
        servers.forEach(function (s) {
          if (s.verdict === "DANGEROUS") worst = "DANGEROUS";
          else if (s.verdict === "BROAD" && worst === "MINIMAL") worst = "BROAD";
        });

        return { servers: servers, overall: worst, keyToServers: keyToServers };
      }

      function analyzeServer(name, server, keyToServers) {
        var args = argsOf(server);
        var env = envOf(server);
        var envKeys = Object.keys(env);
        var command = typeof server.command === "string" ? server.command : "";
        var url = typeof server.url === "string" ? server.url : "";
        var findings = [];
        var score = 0;

        /* --- secret values pasted (flagged, never echoed) --- */
        var secretFlags = [];
        envKeys.forEach(function (k) {
          if (looksLikeSecret(env[k])) {
            secretFlags.push({ key: k, masked: String(env[k]).trim().slice(0, 3) + "••••••••" });
          }
        });
        if (secretFlags.length) {
          score += 5;
          findings.push({
            id: "live-secret", sev: "high",
            title: "VALUE LOOKS LIKE A LIVE SECRET — rotate it, it was pasted somewhere it should not be. Key(s): " + secretFlags.map(function (f) { return f.key + " (" + f.masked + ")"; }).join(", ") + ". This auditor never displays env values; the masked prefix above is all that is shown. Treat the real value as burned: revoke and reissue it at the provider, then store the replacement outside the config (secret manager or OS keychain) and reference a placeholder here.",
            evidence: "env key name(s): " + secretFlags.map(function (f) { return f.key; }).join(", ") + " — value matched a live-secret pattern (known prefix or long high-entropy string)"
          });
        }

        /* --- tool inventory --- */
        var rawTools = toolNamesOf(server);
        var hasToolList = rawTools.length > 0 || Array.isArray(server.tools) || (server.tools && typeof server.tools === "object");
        var tools = rawTools.map(function (tn) {
          var key = name + "::" + tn;
          var cls = overrides.hasOwnProperty(key) ? overrides[key] : classifyTool(tn);
          return { name: tn, cls: cls, auto: classifyTool(tn), corrected: overrides.hasOwnProperty(key) };
        });
        var counts = { READ: 0, WRITE: 0, DELETE: 0, EXECUTE: 0, NETWORK: 0, UNKNOWN: 0 };
        tools.forEach(function (t) { counts[t.cls]++; });
        var hasWriteClass = counts.WRITE + counts.DELETE + counts.EXECUTE > 0;

        if (!hasToolList) {
          score += 2;
          findings.push({
            id: "no-tool-list", sev: "med",
            title: "Tool list not in config — classification limited to server/command signals. Without the tool list, nobody can confirm this server is minimal: whatever the package exposes at runtime is what the agent gets. Add the server's tool list to the config (or export it from the server) and re-audit before connecting.",
            evidence: "no \"tools\" array on server \"" + name + "\"; only command/args/env could be checked"
          });
          // Command-level signals still count.
          var cmdStr = (command + " " + args.join(" ")).toLowerCase();
          if (/(^|[\s\/\\])(bash|sh|zsh|powershell|cmd)(\.exe)?($|[\s])/.test(cmdStr) || /shell|terminal/.test(cmdStr)) {
            score += 3;
            findings.push({
              id: "shell-command", sev: "high",
              title: "The server command itself is a shell/terminal — that is execute access by construction, whatever its tool list says.",
              evidence: "command: " + (command || "(none)") + " " + args.join(" ")
            });
          }
          if (/filesystem|file-system|server-filesystem/.test(cmdStr)) {
            findings.push({
              id: "fs-signal", sev: "med",
              title: "Filesystem server package detected from the command — its real reach is set by the path arguments below and by tools not listed here.",
              evidence: "command: " + (command || "(none)") + " " + args.join(" ")
            });
          }
        }

        /* --- per-class findings --- */
        var byClass = function (c) { return tools.filter(function (t) { return t.cls === c; }).map(function (t) { return t.name; }); };
        var deleteTools = byClass("DELETE"), execTools = byClass("EXECUTE"),
            writeTools = byClass("WRITE"), netTools = byClass("NETWORK"), unkTools = byClass("UNKNOWN");

        if (deleteTools.length) {
          score += Math.min(6, deleteTools.length * 3);
          findings.push({
            id: "delete-tools", sev: "high",
            title: "DELETE-class tools are enabled: " + deleteTools.join(", ") + ". Deletion is the blast radius that cannot be undone by an apology — drop these unless the task truly requires destroying things.",
            evidence: "tools classified DELETE: " + deleteTools.join(", ")
          });
        }
        if (execTools.length) {
          score += Math.min(6, execTools.length * 3);
          findings.push({
            id: "exec-tools", sev: "high",
            title: "EXECUTE/shell tools are enabled: " + execTools.join(", ") + ". A shell tool inherits the whole machine — every file, every credential the OS user can reach — not just this server's stated job.",
            evidence: "tools classified EXECUTE: " + execTools.join(", ")
          });
        }
        if (writeTools.length) {
          score += Math.min(6, writeTools.length * 2);
          findings.push({
            id: "write-tools", sev: "med",
            title: "WRITE-class tools are enabled: " + writeTools.join(", ") + ". Each one is a way for anything the agent reads — including hostile content — to change the outside world.",
            evidence: "tools classified WRITE: " + writeTools.join(", ")
          });
        }
        if (netTools.length) {
          score += Math.min(2, netTools.length);
          findings.push({
            id: "net-tools", sev: "low",
            title: "NETWORK-class tools are enabled: " + netTools.join(", ") + ". Outbound network access is the exfiltration route in most agent incidents — keep it only where the job needs it.",
            evidence: "tools classified NETWORK: " + netTools.join(", ")
          });
        }
        if (unkTools.length) {
          score += Math.min(3, unkTools.length);
          findings.push({
            id: "unknown-tools", sev: "med",
            title: "Tools whose names do not reveal what they do: " + unkTools.join(", ") + ". UNKNOWN is not safe — it is unreviewed. Classify each one in the inventory above (or from the server's docs) before connecting.",
            evidence: "tools classified UNKNOWN: " + unkTools.join(", ")
          });
        }

        /* --- lookup-shaped job holding write/delete --- */
        if (LOOKUP_NAME.test(name) && (writeTools.length || deleteTools.length)) {
          score += 2;
          findings.push({
            id: "lookup-write", sev: "high",
            title: "Job mismatch: the server's name reads like a lookup/search job (\"" + name + "\"), yet it carries write/delete tools (" + writeTools.concat(deleteTools).join(", ") + "). A lookup job should hold read tools only — the write tools are pure extra blast radius.",
            evidence: "server name \"" + name + "\" vs write/delete tools: " + writeTools.concat(deleteTools).join(", ")
          });
        }

        /* --- broad filesystem paths --- */
        var broadPaths = [], scopedPaths = [];
        args.forEach(function (a) {
          if (!isPathArg(a)) return;
          var pv = pathVerdict(a);
          if (pv.broad) broadPaths.push({ arg: a, why: pv.why }); else scopedPaths.push(a);
        });
        if (broadPaths.length) {
          score += 3;
          findings.push({
            id: "broad-path", sev: "high",
            title: "Filesystem access points at " + broadPaths.map(function (b) { return b.why; }).join("; ") + ". Point the server at the one project folder the task needs — a home directory hands it documents, SSH keys, browser data, and every other project's files in one grant.",
            evidence: "args: " + broadPaths.map(function (b) { return b.arg; }).join(", ")
          });
        }

        /* --- credential scope signals --- */
        var broadKeys = envKeys.filter(function (k) { return BROAD_KEY.test(k); });
        if (broadKeys.length) {
          score += 3;
          findings.push({
            id: "broad-cred", sev: "high",
            title: "Env key name(s) suggest a broad-scope credential: " + broadKeys.join(", ") + " (names containing ADMIN / FULL / ROOT / MASTER read as all-access at the provider). Swap in a credential scoped to only what this server's job needs.",
            evidence: "env key name(s): " + broadKeys.join(", ") + " — key names only; values are never read for display"
          });
        }
        // A scope note the user added to the config itself.
        var noteText = "";
        ["note", "scope", "scopeNote", "description"].forEach(function (f) {
          if (typeof server[f] === "string") noteText += " " + server[f];
        });
        if (/(classic\s*pat|full[\s-]?access|all\s+repos|every\s+repo|admin\s+access|root\s+access)/i.test(noteText)) {
          score += 3;
          findings.push({
            id: "scope-note", sev: "high",
            title: "The config's own scope note describes a broad credential (classic PAT / full access / all repos). A classic all-repo token behind an agent is the whole account in one string — use a fine-grained token scoped to only the repos/projects this task needs.",
            evidence: "note in config: \"" + noteText.trim().slice(0, 140) + "\""
          });
        }

        /* --- read-only signal --- */
        var roSignal = hasReadOnlySignal(server, args);
        if (hasWriteClass && !roSignal) {
          score += 2;
          findings.push({
            id: "no-readonly", sev: "med",
            title: "No read-only signal (no readOnly flag, no --read-only arg) on a server that has write/delete/execute tools. If this server supports a read-only mode, turning it on makes the write tools inert even if one gets called.",
            evidence: "readOnly flag: absent · args checked: " + (args.join(" ") || "(none)")
          });
        }

        /* --- shared credential --- */
        var sharedKeys = envKeys.filter(function (k) {
          return keyToServers[k] && keyToServers[k].length > 1 && CRED_KEY.test(k);
        });
        if (sharedKeys.length) {
          score += 2;
          findings.push({
            id: "shared-cred", sev: "med",
            title: "Credential key(s) shared with other servers: " + sharedKeys.map(function (k) {
              return k + " (also on: " + keyToServers[k].filter(function (x) { return x !== name; }).join(", ") + ")";
            }).join("; ") + ". One leaked or abused key now opens every server that shares it.",
            evidence: "env key name(s) appearing on multiple servers: " + sharedKeys.join(", ")
          });
        }

        /* --- toxic flow within this server --- */
        var credPresent = envKeys.some(function (k) { return CRED_KEY.test(k); });
        var privateSignal = credPresent || PRIVATE_NAME.test(name) || PRIVATE_NAME.test(command);
        if (counts.READ > 0 && hasWriteClass && privateSignal) {
          score += 4;
          findings.push({
            id: "toxic", sev: "high",
            title: "TOXIC FLOW: this one server, under one credential, can (1) read content — including untrusted content it did not write, (2) reach private data behind its credential, and (3) write/delete with that same credential (" + writeTools.concat(deleteTools, execTools).join(", ") + "). Those three together are the classic prompt-injection exfiltration path: hostile content it reads can steer it to ship private data out through its own write tools. Break any one leg — drop the write tools, split the credential, or make it read-only.",
            evidence: "read tools: " + byClass("READ").join(", ") + " · credential env key(s): " + (envKeys.join(", ") || "(none)") + " · write/delete/execute: " + writeTools.concat(deleteTools, execTools).join(", ")
          });
        }

        /* --- remote server --- */
        if (url) {
          var host = url.replace(/^https?:\/\//, "").split("/")[0];
          findings.push({
            id: "remote", sev: "low",
            title: "Remote server: this entry connects over the network to " + host + " instead of running a local command. Everything the agent sends it leaves this machine — confirm the operator is who you think it is.",
            evidence: "url host: " + host
          });
          score += 1;
        }

        return {
          name: name, server: server, command: command, args: args, url: url,
          envKeys: envKeys, secretFlags: secretFlags,
          tools: tools, counts: counts, hasToolList: hasToolList,
          findings: findings, score: score, roSignal: roSignal,
          scopedPaths: scopedPaths, privateSignal: privateSignal,
          verdict: "MINIMAL"
        };
      }

      /* ---------------- minimal setup ---------------- */

      function minimalSetupText(s) {
        var lines = [];
        var readTools = s.tools.filter(function (t) { return t.cls === "READ"; }).map(function (t) { return t.name; });
        var dropTools = s.tools.filter(function (t) { return t.cls !== "READ"; });
        lines.push("[" + s.name + "]");
        if (s.hasToolList) {
          lines.push("  Allowlist (READ tools only): " + (readTools.length ? readTools.join(", ") : "(none — this server exposes no read tools; do not connect it for a lookup job)"));
          if (dropTools.length) {
            lines.push("  Drop these tools, one by one, from the allowlist:");
            dropTools.forEach(function (t) { lines.push("    - " + t.name + "  [" + t.cls + "]"); });
          } else {
            lines.push("  Drop: nothing — every listed tool is READ-class.");
          }
        } else {
          lines.push("  Allowlist: cannot be built — the tool list is not in the config. Get the server's tool list, allowlist its READ tools only, and re-audit.");
        }
        if (!s.roSignal) {
          lines.push("  Read-only: add --read-only if this server supports it — check its docs (support varies by server; do not assume the flag exists). If it has no read-only mode, the allowlist above is your only gate, so keep it tight.");
        } else {
          lines.push("  Read-only: a read-only signal is already present in this config — keep it on.");
        }
        if (s.envKeys.length) {
          lines.push("  Credential: use a token scoped to only the repos/projects this task needs, issued for this server alone (key(s) seen: " + s.envKeys.join(", ") + "). Set the value outside the shared config file and reference a placeholder here.");
        } else {
          lines.push("  Credential: none declared in env. If this server needs one, use a token scoped to only the repos/projects this task needs.");
        }
        if (s.scopedPaths.length) {
          lines.push("  Path scope: already project-scoped (" + s.scopedPaths.join(", ") + ") — keep it that narrow.");
        }
        return lines.join("\n");
      }

      /* ---------------- report text ---------------- */

      function buildReport(result) {
        var out = [];
        out.push("J-DAWGS MCP PERMISSION LEAST-PRIVILEGE AUDIT");
        out.push("Overall verdict: " + result.overall + " (the worst server drives the overall verdict)");
        out.push("Servers audited: " + result.servers.length);
        out.push("");
        result.servers.forEach(function (s) {
          out.push("==================================================");
          out.push("SERVER: " + s.name + " — " + s.verdict + " (risk score " + s.score + ")");
          out.push("Command: " + (s.command ? (s.command + " " + s.args.join(" ")).trim() : (s.url ? "remote: " + s.url.replace(/^https?:\/\//, "").split("/")[0] : "(none in config)")));
          out.push("Env keys (names only — values never shown): " + (s.envKeys.length ? s.envKeys.join(", ") : "(none)"));
          s.secretFlags.forEach(function (f) {
            out.push("  !! VALUE LOOKS LIKE A LIVE SECRET on key " + f.key + " (" + f.masked + ") — rotate it, it was pasted somewhere it should not be.");
          });
          out.push("");
          out.push("Tool inventory:");
          if (s.hasToolList && s.tools.length) {
            s.tools.forEach(function (t) {
              out.push("  - " + t.name + "  [" + t.cls + "]" + (t.corrected ? " (corrected by reviewer; name-pattern said " + t.auto + ")" : ""));
            });
          } else {
            out.push("  Tool list not in config — classification limited to server/command signals.");
          }
          out.push("Counts: READ " + s.counts.READ + " · WRITE " + s.counts.WRITE + " · DELETE " + s.counts.DELETE + " · EXECUTE " + s.counts.EXECUTE + " · NETWORK " + s.counts.NETWORK + " · UNKNOWN " + s.counts.UNKNOWN);
          out.push("");
          out.push("Findings:");
          if (s.findings.length) {
            s.findings.forEach(function (f) { out.push("  ! " + f.title); out.push("    Evidence: " + f.evidence); });
          } else {
            out.push("  None. No risk findings from the signals in this config.");
          }
          out.push("");
          out.push("Minimal setup:");
          out.push(minimalSetupText(s));
          out.push("");
        });
        out.push("==================================================");
        out.push("Limits: classification is by tool-name pattern and can be wrong — the per-tool list exists so a human/agent corrects it. This audit reads only the pasted config; it cannot see what a token can actually do at the provider (only the provider knows its scopes), and it does not connect to or test any server.");
        out.push("Built by J-Dawgs™, © 2026 Joshua Dawson.");
        return out.join("\n");
      }

      /* ---------------- rendering ---------------- */

      var CLASS_LABELS = ["READ", "WRITE", "DELETE", "EXECUTE", "NETWORK", "UNKNOWN"];

      function render(result) {
        resultsEl.hidden = false;

        var ob = $("overallBox");
        ob.className = "overall v-" + result.overall.toLowerCase();
        $("overallVerdict").textContent = "Overall verdict: " + result.overall;
        var nD = result.servers.filter(function (s) { return s.verdict === "DANGEROUS"; }).length;
        var nB = result.servers.filter(function (s) { return s.verdict === "BROAD"; }).length;
        var nM = result.servers.length - nD - nB;
        $("overallSub").textContent = result.servers.length + " server(s) audited — " + nD + " dangerous, " + nB + " broad, " + nM + " minimal. Fix the worst server first; the minimal setup for every server is at the bottom.";

        // Loud top-level alert if any pasted value looked like a live secret.
        var anySecrets = [];
        result.servers.forEach(function (s) { s.secretFlags.forEach(function (f) { anySecrets.push(s.name + " / " + f.key + " (" + f.masked + ")"); }); });
        var sa = $("secretAlert");
        if (anySecrets.length) {
          sa.innerHTML = '<div class="banner" style="margin-top:16px;" role="alert"><p class="banner-title">Live secret pasted</p><p>VALUE LOOKS LIKE A LIVE SECRET — rotate it, it was pasted somewhere it should not be. Affected key(s): ' + esc(anySecrets.join(", ")) + '. The values are never shown — only the key name and a masked 3-character prefix. Revoke and reissue at the provider before anything else.</p></div>';
        } else { sa.innerHTML = ""; }

        var cardsHtml = result.servers.map(function (s) {
          var h = '<div class="panel server-card">';
          h += '<div class="server-head"><span class="server-name">' + esc(s.name) + '</span>';
          h += '<span class="verdict-chip ' + s.verdict.toLowerCase() + '">' + s.verdict + '</span></div>';
          var cmdLine = s.command ? (s.command + " " + s.args.join(" ")).trim() : (s.url ? "remote server — " + s.url.replace(/^https?:\/\//, "").split("/")[0] : "(no command in config)");
          h += '<p class="server-meta">' + esc(cmdLine) + '</p>';
          h += '<p class="score-line">Risk score ' + s.score + ' · READ ' + s.counts.READ + ' · WRITE ' + s.counts.WRITE + ' · DELETE ' + s.counts.DELETE + ' · EXECUTE ' + s.counts.EXECUTE + ' · NETWORK ' + s.counts.NETWORK + ' · UNKNOWN ' + s.counts.UNKNOWN + '</p>';

          // Tool inventory
          h += '<div class="sub-block"><h3>Permission inventory — every tool, classified</h3>';
          if (s.hasToolList && s.tools.length) {
            h += '<ul class="tool-list">';
            s.tools.forEach(function (t) {
              var key = s.name + "::" + t.name;
              h += '<li class="tool-row"><span class="tool-name">' + esc(t.name) + '</span>';
              h += '<span class="class-chip ' + t.cls + '">' + t.cls + '</span>';
              h += '<label style="font-size:0.8rem;color:var(--muted);">correct it: <select data-server="' + esc(s.name) + '" data-tool="' + esc(t.name) + '" aria-label="Classification for ' + esc(t.name) + '">';
              CLASS_LABELS.forEach(function (c) {
                h += '<option value="' + c + '"' + (c === t.cls ? " selected" : "") + '>' + c + '</option>';
              });
              h += '</select></label>';
              if (t.corrected) h += '<span style="font-size:0.8rem;color:var(--muted);">(name-pattern said ' + t.auto + ')</span>';
              h += '</li>';
            });
            h += '</ul>';
            h += '<p class="note-line">Classification is by name pattern and can be wrong — change any row and the verdict, findings, and minimal setup recompute instantly.</p>';
          } else {
            h += '<p class="note-line">Tool list not in config — classification limited to server/command signals. Add the server\'s tool list and re-audit to get the full inventory.</p>';
          }
          h += '</div>';

          // Env
          h += '<div class="sub-block"><h3>Env keys (names only — values never shown)</h3>';
          if (s.envKeys.length) {
            h += '<ul class="env-list">';
            s.envKeys.forEach(function (k) {
              var flag = null;
              s.secretFlags.forEach(function (f) { if (f.key === k) flag = f; });
              h += '<li>' + esc(k);
              if (flag) {
                h += ' <span style="font-family:var(--mono);">' + esc(flag.masked) + '</span>';
                h += '<span class="secret-flag">VALUE LOOKS LIKE A LIVE SECRET — rotate it, it was pasted somewhere it should not be.</span>';
              } else {
                h += ' <span class="env-ok">— value not shown</span>';
              }
              h += '</li>';
            });
            h += '</ul>';
          } else {
            h += '<p class="note-line">No env keys in this server entry.</p>';
          }
          h += '</div>';

          // Findings
          h += '<div class="sub-block"><h3>Risk findings</h3>';
          if (s.findings.length) {
            h += '<ul class="findings">';
            s.findings.forEach(function (f) {
              h += '<li><span class="sev ' + f.sev + '"></span><span class="finding-title">' + esc(f.title) + '</span>';
              h += '<span class="finding-evidence">Evidence: ' + esc(f.evidence) + '</span></li>';
            });
            h += '</ul>';
          } else {
            h += '<p class="clean-line">No findings. Read-only tools, a read-only signal, and a narrow scope — this is what minimal looks like.</p>';
          }
          h += '</div>';

          h += '</div>';
          return h;
        }).join("");
        $("serverCards").innerHTML = cardsHtml;

        // Re-classification controls recompute everything.
        var selects = $("serverCards").querySelectorAll("select[data-tool]");
        Array.prototype.forEach.call(selects, function (sel) {
          sel.addEventListener("change", function () {
            overrides[sel.getAttribute("data-server") + "::" + sel.getAttribute("data-tool")] = sel.value;
            if (lastConfig) render(analyze(lastConfig));
          });
        });

        $("setupPre").textContent = result.servers.map(minimalSetupText).join("\n\n");
        lastReportText = buildReport(result);
        $("reportPre").textContent = lastReportText;
      }

      /* ---------------- run / status ---------------- */

      function setStatus(msg, kind) {
        statusEl.textContent = msg || "";
        statusEl.className = "status-msg" + (kind ? " " + kind : "");
        statusEl.style.display = msg ? "block" : "none";
      }

      function runAudit() {
        var raw = inputEl.value.trim();
        if (!raw) {
          resultsEl.hidden = true;
          setStatus("Nothing to audit yet — the config box is empty. Paste an MCP config (JSON with an mcpServers map), or load the Dangerous sample or the Minimal sample to see how the auditor scores.", "info");
          inputEl.focus();
          return;
        }
        var parsed;
        try {
          parsed = JSON.parse(raw);
        } catch (e) {
          resultsEl.hidden = true;
          setStatus("That is not valid JSON — nothing was audited.\nParser said: " + e.message + "\nFix the JSON and run the audit again. (Common causes: trailing commas, single quotes, or a comment line — strict JSON allows none of those.)", "error");
          return;
        }
        if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
          resultsEl.hidden = true;
          setStatus("The JSON parsed, but it is not a config object. Expected a top-level object like { \"mcpServers\": { \"server-name\": { ... } } }.", "error");
          return;
        }
        var serversObj = (parsed.mcpServers && typeof parsed.mcpServers === "object" && !Array.isArray(parsed.mcpServers)) ? parsed.mcpServers : parsed;
        var serverNames = Object.keys(serversObj).filter(function (k) { return serversObj[k] && typeof serversObj[k] === "object" && !Array.isArray(serversObj[k]); });
        if (!serverNames.length) {
          resultsEl.hidden = true;
          setStatus("The JSON parsed, but no servers were found in it. Expected an \"mcpServers\" map whose values are server objects (command / args / env / tools). Nothing was audited.", "error");
          return;
        }
        setStatus("", "");
        lastConfig = parsed;
        render(analyze(parsed));
        resultsEl.scrollIntoView({ behavior: "smooth", block: "start" });
      }
  return { "analyze": (typeof analyze !== 'undefined' ? analyze : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "DANGEROUS_SAMPLE": (typeof DANGEROUS_SAMPLE !== 'undefined' ? DANGEROUS_SAMPLE : undefined), "MINIMAL_SAMPLE": (typeof MINIMAL_SAMPLE !== 'undefined' ? MINIMAL_SAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["analyze"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-mcp-permission-auditor',
  name: 'J-Dawgs MCP Permission Least-Privilege Auditor',
  description: 'Paste an MCP config before you connect it: it scores every server\'s blast radius, flags write/delete/execute tools, broad paths and shared credentials (the toxic-flow pattern), and outputs a read-only allowlist. Env values are never shown — key names only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["analyze"]) return { ok: false, output: null, summary: 'Extracted core has no analyze function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "DANGEROUS_SAMPLE": __core["DANGEROUS_SAMPLE"], "MINIMAL_SAMPLE": __core["MINIMAL_SAMPLE"] }
};
