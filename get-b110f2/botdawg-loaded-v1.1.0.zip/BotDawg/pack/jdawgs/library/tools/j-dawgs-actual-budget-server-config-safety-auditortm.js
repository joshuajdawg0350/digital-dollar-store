'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Actual Budget Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var RISKY = [
        "# Actual Budget sync server - RISKY worked example (do not deploy this)",
        "ACTUAL_TOKEN_SECRET=secret123",
        "ACTUAL_PASSWORD=budget1",
        "ACTUAL_SERVER_URL=http://budget.mydomain.com:5006",
        "ACTUAL_OPEN_REGISTRATION=true",
        "ACTUAL_TRUSTED_PROXIES=*",
        "ACTUAL_HTTPS=false",
        "ACTUAL_HOSTNAME=0.0.0.0",
        "ACTUAL_PORT=5006",
        "ACTUAL_SERVER_FILES=/data/server-files",
        "ACTUAL_USER_FILES=/data/user-files"
      ].join("\n");

      var HARDENED = [
        "# Actual Budget sync server - HARDENED worked example",
        "ACTUAL_TOKEN_SECRET=kX9mQ2vLp8sR4nW7jH3dF6aZ1bC5eG0tY9uI2oP4qS7wN3x",
        "ACTUAL_PASSWORD_HASH=$2b$12$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy",
        "ACTUAL_SERVER_URL=https://budget.mydomain.com",
        "ACTUAL_OPEN_REGISTRATION=false",
        "ACTUAL_TRUSTED_PROXIES=127.0.0.1,10.0.0.5",
        "ACTUAL_HTTPS=true",
        "ACTUAL_HTTPS_KEY=/certs/privkey.pem",
        "ACTUAL_HTTPS_CERT=/certs/fullchain.pem",
        "ACTUAL_HOSTNAME=127.0.0.1",
        "ACTUAL_PORT=5006",
        "ACTUAL_SERVER_FILES=/data/server-files",
        "ACTUAL_USER_FILES=/data/user-files",
        "ACTUAL_DATA_DIR=/data"
      ].join("\n");

      // Normalized key (uppercase, alphanumerics only) -> category
      var KEYMAP = {
        ACTUALTOKENSECRET:"tokenSecret", TOKENSECRET:"tokenSecret",
        ACTUALPASSWORD:"password", PASSWORD:"password", LOGINPASSWORD:"password",
        ACTUALLOGINPASSWORD:"password", SERVERPASSWORD:"password",
        ACTUALPASSWORDHASH:"passwordHash", PASSWORDHASH:"passwordHash", HASHEDPASSWORD:"passwordHash",
        ACTUALSERVERURL:"serverUrl", SERVERURL:"serverUrl",
        ACTUALOPENREGISTRATION:"openRegistration", OPENREGISTRATION:"openRegistration",
        ACTUALALLOWREGISTRATION:"openRegistration", ALLOWREGISTRATION:"openRegistration",
        ALLOWOPENREGISTRATION:"openRegistration",
        ACTUALTRUSTEDPROXIES:"trustedProxies", TRUSTEDPROXIES:"trustedProxies",
        ACTUALHTTPS:"https", HTTPS:"https", USEHTTPS:"https", ACTUALUSEHTTPS:"https",
        ACTUALHTTPSKEY:"httpsKey", HTTPSKEY:"httpsKey", TLSKEY:"httpsKey", ACTUALTLSKEY:"httpsKey",
        ACTUALHTTPSCERT:"httpsCert", HTTPSCERT:"httpsCert", TLSCERT:"httpsCert", ACTUALTLSCERT:"httpsCert",
        ACTUALHOSTNAME:"hostname", HOSTNAME:"hostname", HOST:"hostname",
        ACTUALPORT:"port", PORT:"port",
        ACTUALSERVERFILES:"serverFiles", SERVERFILES:"serverFiles",
        ACTUALUSERFILES:"userFiles", USERFILES:"userFiles",
        ACTUALDATADIR:"dataDir", DATADIR:"dataDir"
      };
      var SECRET_CATS = { tokenSecret:true, password:true, passwordHash:true };

      function normKey(k){ return k.toUpperCase().replace(/[^A-Z0-9]/g,""); }

      function parseConfig(text){
        var entries = [];
        var lines = text.split(/\r?\n/);
        for (var i=0;i<lines.length;i++){
          var raw = lines[i];
          var t = raw.replace(/^\s+|\s+$/g,"");
          if (!t || t.charAt(0)==="#" || t.indexOf("//")===0) continue;
          if (t==="{" || t==="}" || t==="[object Object]") continue;
          var m = t.match(/^"?([A-Za-z0-9_.\-]+)"?\s*[:=]\s*(.*)$/);
          if (!m) continue;
          var key = m[1];
          var rest = m[2].replace(/\s+$/,"");
          var value;
          if (rest.charAt(0)==='"' || rest.charAt(0)==="'"){
            var q = rest.charAt(0);
            var end = rest.indexOf(q,1);
            value = end>0 ? rest.slice(1,end) : rest.slice(1);
          } else {
            value = rest.replace(/,\s*$/,"").replace(/\}\s*$/,"").replace(/^\s+|\s+$/g,"");
          }
          var nk = normKey(key);
          var cat = KEYMAP[nk] || null;
          var isSecret = !!SECRET_CATS[cat] || /SECRET|PASSWORD|PASSWD|APIKEY|PRIVATEKEY/.test(nk);
          entries.push({ line:i+1, key:key, norm:nk, cat:cat, value:value, secret:isSecret });
        }
        return entries;
      }

      function truthy(v){ return /^(true|yes|1|on|enabled)$/i.test(v.replace(/\s/g,"")); }
      function falsy(v){ return /^(false|no|0|off|disabled)$/i.test(v.replace(/\s/g,"")); }
      function looksHashed(v){ return /^\$(2[aby]|argon2|scrypt)/.test(v) || /^pbkdf2/i.test(v) || /^[a-f0-9]{64}$/i.test(v); }
      function looksPlaceholder(v){
        return /change.?me|example|placeholder|your[-_ ]|todo|replace.?me|insert[-_ ]|xxx+|letmein/i.test(v) || /^<.*>$/.test(v);
      }

      function audit(text){
        var entries = parseConfig(text);
        var findings = []; // {line|null, severity, key, title, detail, fix}
        var passes = [];
        var secrets = [];
        var byCat = {};
        entries.forEach(function(e){
          if (e.secret && e.value) secrets.push({ key:e.key, line:e.line, length:e.value.length });
          if (e.cat && !byCat[e.cat]) byCat[e.cat] = e;
          else if (e.cat && byCat[e.cat]) { /* keep first */ }
        });
        var recognized = entries.filter(function(e){ return !!e.cat; }).length;

        function add(line, sev, key, title, detail, fix){
          findings.push({ line:line, severity:sev, key:key, title:title, detail:detail, fix:fix });
        }

        // --- Token secret ---
        var tok = byCat.tokenSecret;
        if (tok){
          if (looksPlaceholder(tok.value)){
            add(tok.line,"CRITICAL",tok.key,"Token secret is a placeholder / example value",
              "Key "+tok.key+" on line "+tok.line+" holds a placeholder-style value (length "+tok.value.length+"). Anyone who has seen the example config knows this secret.",
              "Generate a fresh random secret of at least 32 characters (e.g. openssl rand -hex 32) and set it only on the server.");
          } else if (tok.value.length < 16){
            add(tok.line,"CRITICAL",tok.key,"Token secret is far too short",
              "Key "+tok.key+" on line "+tok.line+" is only "+tok.value.length+" characters long. Short token secrets can be guessed or brute-forced, and the server will accept this silently.",
              "Replace it with a random secret of at least 32 characters (e.g. openssl rand -hex 32). Report shows length only — the value is never displayed here.");
          } else if (tok.value.length < 32){
            add(tok.line,"HIGH",tok.key,"Token secret is short",
              "Key "+tok.key+" on line "+tok.line+" is "+tok.value.length+" characters long — below the 32-character floor for a sync token secret.",
              "Rotate to a random secret of at least 32 characters and restart the server so sessions re-issue.");
          } else {
            passes.push(tok.key+" (line "+tok.line+"): token secret present at "+tok.value.length+" characters — meets the 32-character floor. Value not shown.");
          }
        } else {
          add(null,"HIGH","ACTUAL_TOKEN_SECRET","No token secret found in the pasted config",
            "No ACTUAL_TOKEN_SECRET / tokenSecret line was found. If the server falls back to a default or an empty secret, sync tokens are forgeable.",
            "Set ACTUAL_TOKEN_SECRET to a random value of at least 32 characters in the server environment, not in a file committed to git.");
        }

        // --- Login password ---
        var pw = byCat.password, pwh = byCat.passwordHash;
        if (pwh){
          if (looksHashed(pwh.value)){
            passes.push(pwh.key+" (line "+pwh.line+"): login password is stored as a hash ("+pwh.value.length+" characters). Value not shown.");
          } else {
            add(pwh.line,"MEDIUM",pwh.key,"Password-hash setting does not look like a hash",
              "Key "+pwh.key+" on line "+pwh.line+" is "+pwh.value.length+" characters but does not match a known hash format (bcrypt / argon2 / scrypt / pbkdf2). It may be a plaintext password stored under a hash name.",
              "Let the server hash the password itself, or generate a real bcrypt/argon2 hash — never store the plaintext under a hash key.");
          }
        }
        if (pw){
          if (looksPlaceholder(pw.value) || pw.value.length < 12){
            add(pw.line,"CRITICAL",pw.key,"Login password is too weak",
              "Key "+pw.key+" on line "+pw.line+" holds a plaintext password of only "+pw.value.length+" characters. The server accepts short passwords without complaint, and this one would fall to a quick guessing attack.",
              "Use a unique password of at least 16 characters from a password manager, and prefer a hashed password setting where the server supports it. Value not shown.");
          } else if (pw.value.length < 16){
            add(pw.line,"HIGH",pw.key,"Login password is short and in plaintext",
              "Key "+pw.key+" on line "+pw.line+" holds a plaintext password of "+pw.value.length+" characters.",
              "Lengthen it to at least 16 characters and store it hashed where supported. Value not shown.");
          } else {
            add(pw.line,"MEDIUM",pw.key,"Login password stored in plaintext",
              "Key "+pw.key+" on line "+pw.line+" holds a plaintext password ("+pw.value.length+" characters). Anyone who reads this config file owns the login.",
              "Move the password into a hashed setting or a secrets file with owner-only permissions, and keep the config out of version control. Value not shown.");
          }
        }
        if (!pw && !pwh){
          add(null,"MEDIUM","ACTUAL_PASSWORD","No login password setting found",
            "No password or password-hash line was found in the pasted config. If password login is unset or defaulted, the first visitor may be able to claim the server.",
            "Set a strong login password (16+ characters, hashed where supported) before the server is reachable by anyone else.");
        }

        // --- Server URL / scheme ---
        var url = byCat.serverUrl;
        if (url){
          if (/^http:\/\//i.test(url.value)){
            add(url.line,"HIGH",url.key,"Server URL uses plaintext http://",
              "Key "+url.key+" on line "+url.line+" points at an http:// address. Budgets, passwords, and sync tokens crossing that link travel unencrypted.",
              "Serve the sync server over https:// — directly with certificates, or behind a reverse proxy that terminates TLS — and update the URL to match.");
          } else if (/^https:\/\//i.test(url.value)){
            passes.push(url.key+" (line "+url.line+"): server URL uses https://.");
          } else {
            add(url.line,"MEDIUM",url.key,"Server URL has no clear scheme",
              "Key "+url.key+" on line "+url.line+" does not start with https://, so its transport cannot be confirmed from the config.",
              "Set the full URL including the https:// scheme exactly as clients will reach the server.");
          }
        } else {
          add(null,"MEDIUM","ACTUAL_SERVER_URL","No server URL set",
            "No ACTUAL_SERVER_URL / serverUrl line was found. Behind a proxy or with a custom domain, a missing or wrong URL breaks login redirects and can push clients to an insecure address.",
            "Set ACTUAL_SERVER_URL to the exact https:// address clients use to reach the server.");
        }

        // --- HTTPS ---
        var https = byCat.https;
        if (https){
          if (falsy(https.value)){
            add(https.line,"HIGH",https.key,"HTTPS is switched off in the config",
              "Key "+https.key+" on line "+https.line+" disables HTTPS on the server itself. That is only safe if a separate reverse proxy in front of it terminates TLS — nothing in this config shows one.",
              "Either enable HTTPS with a certificate and key, or put the server behind a TLS-terminating reverse proxy and bind it to localhost.");
          } else if (truthy(https.value)){
            if (byCat.httpsKey && byCat.httpsCert){
              passes.push(https.key+" (line "+https.line+"): HTTPS enabled with both a certificate and a key configured.");
            } else {
              add(https.line,"MEDIUM",https.key,"HTTPS enabled but certificate / key not both set",
                "HTTPS is on (line "+https.line+") but the pasted config does not show both a certificate and a key path, so the server may fail to start or fall back.",
                "Set both the HTTPS certificate and key paths (or confirm the proxy — not the server — terminates TLS).");
            }
          }
        } else {
          add(null,"MEDIUM","ACTUAL_HTTPS","HTTPS is not mentioned in the pasted config",
            "No HTTPS setting appears in these lines. If TLS is not terminated by a reverse proxy either, logins and budget data cross the network in plaintext.",
            "Enable HTTPS on the server or in front of it, and make sure the server URL uses https://.");
        }

        // --- Open registration ---
        var reg = byCat.openRegistration;
        if (reg){
          if (truthy(reg.value)){
            add(reg.line,"CRITICAL",reg.key,"Open registration is ON",
              "Key "+reg.key+" on line "+reg.line+" lets anyone who can reach the server create an account. On a public address, the first stranger to find it can get in before you do.",
              "Turn open registration off after creating your own account — set it to false and restart the server.");
          } else if (falsy(reg.value)){
            passes.push(reg.key+" (line "+reg.line+"): open registration is off.");
          }
        } else {
          add(null,"INFO","ACTUAL_OPEN_REGISTRATION","Open registration not mentioned",
            "No registration setting appears in the pasted config, so its state comes from the server default for your version.",
            "Confirm in your version's docs that registration is closed after your account exists, and set it explicitly to false.");
        }

        // --- Trusted proxies ---
        var tp = byCat.trustedProxies;
        if (tp){
          var tpv = tp.value.replace(/\s/g,"");
          if (tpv==="*" || tpv==="0.0.0.0/0" || tpv==="::/0" || /0\.0\.0\.0\/0/.test(tpv)){
            add(tp.line,"CRITICAL",tp.key,"Trusted proxies set to wildcard",
              "Key "+tp.key+" on line "+tp.line+" trusts every proxy. Any client can then spoof forwarding headers, and rate limits, logs, and IP-based checks will believe the spoofed address.",
              "List only the exact proxy addresses you run (for example 127.0.0.1 or your reverse proxy's IP) — never a wildcard.");
          } else {
            passes.push(tp.key+" (line "+tp.line+"): trusted proxies are a specific list, not a wildcard.");
          }
        } else {
          add(null,"INFO","ACTUAL_TRUSTED_PROXIES","Trusted proxies not mentioned",
            "No trusted-proxies setting appears in the pasted config. That is the safer default when the server is directly exposed.",
            "If you add a reverse proxy later, trust only that proxy's exact address — never a wildcard.");
        }

        // --- Bind address ---
        var host = byCat.hostname;
        if (host){
          if (host.value==="0.0.0.0" || host.value==="::"){
            add(host.line,"MEDIUM",host.key,"Server binds to every network interface",
              "Key "+host.key+" on line "+host.line+" listens on all interfaces. Combined with http or open registration, the whole network — or internet, if the port is forwarded — can reach the login page.",
              "Bind to 127.0.0.1 when a local reverse proxy fronts the server, and check the firewall / port-forwarding before exposing it.");
          } else {
            passes.push(host.key+" (line "+host.line+"): bind address is not a wildcard.");
          }
        }

        // --- Data directories ---
        var hasData = byCat.serverFiles || byCat.userFiles || byCat.dataDir;
        [["serverFiles","ACTUAL_SERVER_FILES"],["userFiles","ACTUAL_USER_FILES"],["dataDir","ACTUAL_DATA_DIR"]].forEach(function(pair){
          var e = byCat[pair[0]];
          if (e && (e.value==="/" || e.value==="." || /^\/tmp\b/.test(e.value))){
            add(e.line,"HIGH",e.key,"Data directory points somewhere unsafe or temporary",
              "Key "+e.key+" on line "+e.line+" points at the filesystem root, the working directory, or /tmp. Budgets stored there can be wiped with temp files or exposed to every process on the box.",
              "Point data directories at a dedicated folder owned by the server user (for example /data) and back it up.");
          }
        });
        if (!hasData){
          add(null,"MEDIUM","ACTUAL_SERVER_FILES","No data directory set",
            "No server-files, user-files, or data-dir line was found. In a container, unset data paths often land on ephemeral storage that disappears when the container is replaced.",
            "Set the data directories to a persistent volume and verify a backup restores before trusting it with real budgets.");
        } else {
          passes.push("Data storage: at least one data directory is set explicitly.");
        }

        // --- Any other http:// URL lines ---
        entries.forEach(function(e){
          if (e.cat!=="serverUrl" && /^http:\/\//i.test(e.value) && /URL|HOST|ENDPOINT/i.test(e.norm)){
            add(e.line,"HIGH",e.key,"Another address uses plaintext http://",
              "Key "+e.key+" on line "+e.line+" uses an http:// address.",
              "Switch it to https:// or confine it to a trusted local network segment.");
          }
        });

        // --- Verdict ---
        var counts = { CRITICAL:0, HIGH:0, MEDIUM:0, LOW:0, INFO:0 };
        findings.forEach(function(f){ counts[f.severity]++; });
        var verdict, why;
        if (entries.length===0 || recognized < 2){
          verdict = "NOT ENOUGH TO GRADE";
          why = "The pasted text does not contain enough recognizable Actual Budget server settings to grade (found "+recognized+" known setting"+(recognized===1?"":"s")+" across "+entries.length+" parsed line"+(entries.length===1?"":"s")+"). Paste the server's environment or config lines — token secret, server URL, registration, proxies, HTTPS — or load a worked example above.";
        } else if (counts.CRITICAL>0){
          verdict = "DO NOT DEPLOY";
          why = counts.CRITICAL+" critical finding"+(counts.CRITICAL===1?"":"s")+" must be fixed before this config goes anywhere reachable. Fix every critical and high item, then re-audit.";
        } else if (counts.HIGH>0 || counts.MEDIUM>0){
          verdict = "DEPLOY WITH FIXES";
          why = "No critical findings, but "+(counts.HIGH+counts.MEDIUM)+" high/medium item"+((counts.HIGH+counts.MEDIUM)===1?"":"s")+" should be fixed before this config is exposed beyond a trusted local network.";
        } else {
          verdict = "SAFE TO DEPLOY";
          why = "No critical, high, or medium findings in the pasted lines, and every core check passed. This grades the pasted config text only — it does not verify a live deployment.";
        }
        return { verdict:verdict, why:why, findings:findings, passes:passes, secrets:secrets, counts:counts, recognized:recognized, parsedLines:entries.length };
      }

      function scrub(str, entries){
        var out = str;
        entries.forEach(function(e){
          if (e.secret && e.value && e.value.length>=4){
            out = out.split(e.value).join("[redacted — "+e.value.length+" chars]");
          }
        });
        return out;
      }
      function countLeaks(str, entries){
        var n = 0;
        entries.forEach(function(e){
          if (e.secret && e.value && e.value.length>=4){
            var idx = 0;
            while (true){ var p = str.indexOf(e.value, idx); if (p<0) break; n++; idx = p+1; }
          }
        });
        return n;
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-actual-budget-server-config-safety-auditortm',
  name: 'J-Dawgs Actual Budget Server Config Safety Auditor',
  description: 'Host tools only tell you the server started; ours grades a pasted Actual Budget server config offline into one deploy verdict — secrets by key name/line/length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
