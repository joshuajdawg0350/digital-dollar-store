'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs CockroachDB Node Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Built-in examples (line numbers are part of the grade) ---------- */
      var RISKY_EXAMPLE = [
        "cockroach start-single-node \\",
        "  --insecure \\",
        "  --listen-addr=0.0.0.0:26257 \\",
        "  --advertise-addr=0.0.0.0:26257 \\",
        "  --http-addr=0.0.0.0:8080 \\",
        "  --store=path=/tmp/cockroach-data",
        "# Planned use: production database for the order app - more nodes to be added later."
      ].join("\n");

      var HARDENED_EXAMPLE = [
        "# Secure production node - node 1 of a 3-node cluster",
        "cockroach start \\",
        "  --certs-dir=/etc/cockroach/certs \\",
        "  --listen-addr=db1.internal:26257 \\",
        "  --advertise-addr=db1.internal:26257 \\",
        "  --sql-addr=db1.internal:26257 \\",
        "  --http-addr=127.0.0.1:8080 \\",
        "  --join=db1.internal:26257,db2.internal:26257,db3.internal:26257 \\",
        "  --store=path=/var/lib/cockroach/data,attrs=ssd \\",
        "  --locality=region=us-east,zone=us-east-1a \\",
        "  --cache=25% \\",
        "  --max-sql-memory=25% \\",
        "  --background"
      ].join("\n");

      /* ---------- Known node-start flags (public CockroachDB CLI surface) ---------- */
      var BOOL_FLAGS = {
        "insecure": true, "background": true, "init": true,
        "disable-cluster-name-verification": true
      };
      var VALUE_FLAGS = {
        "certs-dir": true, "listen-addr": true, "advertise-addr": true,
        "http-addr": true, "sql-addr": true, "join": true, "store": true,
        "locality": true, "cache": true, "max-sql-memory": true,
        "external-io-dir": true, "log-dir": true, "log-config-file": true,
        "attrs": true, "locality-advertise-addr": true,
        "advertise-sql-addr": true, "cluster-name": true,
        "listening-url-file": true, "port": true, "http-port": true,
        "cert-principal-map": true, "max-disk-temp-storage": true,
        "temp-dir": true, "clock-device": true, "pid-file": true
      };
      var SECRET_FLAG_NAMES = {
        "password": true, "passwd": true, "secret": true, "token": true,
        "api-key": true, "apikey": true, "access-token": true,
        "auth-token": true, "license-key": true, "client-key": true
      };
      var YAML_KEYS = {};
      Object.keys(BOOL_FLAGS).forEach(function (k) { YAML_KEYS[k] = "bool"; });
      Object.keys(VALUE_FLAGS).forEach(function (k) { YAML_KEYS[k] = "value"; });

      var SEV_RANK = { "BLOCKER": 0, "WARNING": 1, "NOT RECOGNIZED": 2, "NOT PARSED": 3, "NOTE": 4 };

      function finding(sev, line, title, detail, fix) {
        return { severity: sev, line: line, title: title, detail: detail, fix: fix || "" };
      }

      /* ---------- Secret scanning: value is measured, never kept ---------- */
      function scanSecrets(line, n, findings) {
        var m, i;
        var uri = /(?:postgres(?:ql)?|cockroachdb):\/\/[^\s:\/@]+:([^\s@]+)@/gi;
        while ((m = uri.exec(line)) !== null) {
          findings.push(finding("BLOCKER", n,
            "Plaintext secret in paste — connection-string password",
            "Key name: connection-string password · Line " + n + " · Value length: " + m[1].length + " characters. The value itself is never shown in these findings, the report, or the JSON export.",
            "Move the password out of the pasted config into a secret store or environment-managed credential, and rotate it — anything pasted in plaintext should be treated as exposed."));
        }
        var kv = /([A-Za-z][A-Za-z0-9_-]*?(?:password|passwd|pwd|secret|api[-_]?key|access[-_]?token|auth[-_]?token|license[-_]?key|client[-_]?key))\s*[:=]\s*("([^"]*)"|'([^']*)'|(\S+))/gi;
        while ((m = kv.exec(line)) !== null) {
          var val = m[3] !== undefined ? m[3] : (m[4] !== undefined ? m[4] : (m[5] || ""));
          if (/^(true|false)$/i.test(val)) continue;
          findings.push(finding("BLOCKER", n,
            "Plaintext secret in paste — key '" + m[1].toLowerCase() + "'",
            "Key name: " + m[1].toLowerCase() + " · Line " + n + " · Value length: " + val.length + " characters. The value itself is never shown in these findings, the report, or the JSON export.",
            "Remove the plaintext value from the config, supply it through a secret store or protected environment instead, and rotate it — anything pasted in plaintext should be treated as exposed."));
        }
        var flagEq = /--(password|passwd|secret|token|api[-_]?key|access[-_]?token|auth[-_]?token|license[-_]?key)=(\S+)/gi;
        while ((m = flagEq.exec(line)) !== null) {
          findings.push(finding("BLOCKER", n,
            "Plaintext secret in paste — flag '--" + m[1].toLowerCase() + "'",
            "Key name: --" + m[1].toLowerCase() + " · Line " + n + " · Value length: " + m[2].length + " characters. The value itself is never shown in these findings, the report, or the JSON export.",
            "Remove the plaintext value from the command line (command lines are visible to other local users and land in shell history and unit files), supply it through a secret store instead, and rotate it."));
        }
        if (/-----BEGIN [A-Z ]*PRIVATE KEY-----/.test(line)) {
          findings.push(finding("BLOCKER", n,
            "Plaintext secret in paste — private key material",
            "Key name: PEM private key block · Line " + n + " · A -----BEGIN PRIVATE KEY----- block starts on this line. Key contents are never shown in these findings, the report, or the JSON export.",
            "Keep private keys in the certs directory with tight file permissions — never inline in a pasted config — and treat any key pasted in plaintext as exposed and rotate it."));
        }
        for (i = 0; i < findings.length; i++) { /* no-op guard */ }
      }

      /* ---------- Shell-ish tokenizer (quotes honored; null = unterminated quote) ---------- */
      function tokenize(s) {
        var out = [], cur = "", q = null, has = false, i, c;
        for (i = 0; i < s.length; i++) {
          c = s[i];
          if (q) {
            if (c === q) { q = null; } else { cur += c; }
            has = true;
          } else if (c === '"' || c === "'") {
            q = c; has = true;
          } else if (/\s/.test(c)) {
            if (has || cur) { out.push(cur); cur = ""; has = false; }
          } else { cur += c; has = true; }
        }
        if (q) return null;
        if (has || cur) out.push(cur);
        return out;
      }

      function parseBool(v) {
        if (v === true) return true;
        if (typeof v === "string") {
          if (/^(true|yes|1)$/i.test(v)) return true;
          if (/^(false|no|0)$/i.test(v)) return false;
        }
        return null;
      }

      function parseAddr(v) {
        if (typeof v !== "string" || !v) return null;
        var host = v, port = null, m = v.match(/^(.*):(\d+)$/);
        if (m) { host = m[1]; port = parseInt(m[2], 10); }
        host = host.replace(/^\[/, "").replace(/\]$/, "");
        return { host: host, port: port };
      }
      function isAllInterfaces(a) {
        return a && (a.host === "" || a.host === "0.0.0.0" || a.host === "::" || a.host === "*");
      }
      function isLoopback(a) {
        return a && (a.host === "127.0.0.1" || a.host === "localhost" || a.host === "::1");
      }

      /* ---------- Detection: is this a CockroachDB node config at all? ---------- */
      function looksLikeCockroach(raw) {
        if (/cockroach/i.test(raw)) return true;
        if (/start-single-node/.test(raw)) return true;
        var known = 0, names = Object.keys(BOOL_FLAGS).concat(Object.keys(VALUE_FLAGS)), i, re;
        for (i = 0; i < names.length; i++) {
          re = new RegExp("(^|[\\s\"'])--" + names[i] + "(?=[=\\s]|$)", "m");
          if (re.test(raw)) known++;
        }
        if (known >= 2) return true;
        if (known >= 1 && /\bstart\b/.test(raw)) return true;
        var yamlHits = 0, ykeys = Object.keys(YAML_KEYS);
        for (i = 0; i < ykeys.length; i++) {
          re = new RegExp("^\\s*" + ykeys[i].replace(/-/g, "[-_]") + "\\s*:", "m");
          if (re.test(raw)) yamlHits++;
        }
        return yamlHits >= 2;
      }

      /* ---------- Main audit ---------- */
      function audit(raw) {
        var findings = [], passed = [];
        var lines = raw.split(/\r?\n/);
        var settings = {};   // name -> {value, line}
        var command = null, commandLine = 0;
        var pendingFlag = null; // {name, line}
        var handledAny = false;
        var n, rawLine, line, trimmed, cont, tokens, i;

        function setSetting(name, value, lineNo) {
          settings[name] = { value: value, line: lineNo };
          handledAny = true;
        }

        function parseFlagTokens(toks, lineNo) {
          var strays = 0, j, tok, name, eq, val;
          for (j = 0; j < toks.length; j++) {
            tok = toks[j];
            if (tok.indexOf("--") === 0) {
              eq = tok.indexOf("=");
              name = (eq >= 0 ? tok.slice(2, eq) : tok.slice(2)).toLowerCase();
              val = eq >= 0 ? tok.slice(eq + 1) : null;
              if (!/^[a-z0-9][a-z0-9-]*$/.test(name)) {
                findings.push(finding("NOT PARSED", lineNo,
                  "Line " + lineNo + " could not be parsed",
                  "A token starting with '--' on this line is not a well-formed flag, so nothing on the line was trusted.",
                  "Fix the flag's spelling or quoting on line " + lineNo + " and re-audit."));
                continue;
              }
              if (SECRET_FLAG_NAMES[name]) {
                var sval = val;
                if (sval === null && j + 1 < toks.length && toks[j + 1].indexOf("--") !== 0) { sval = toks[j + 1]; j++; }
                findings.push(finding("BLOCKER", lineNo,
                  "Plaintext secret in paste — flag '--" + name + "'",
                  "Key name: --" + name + " · Line " + lineNo + " · Value length: " + (sval ? sval.length : 0) + " characters. The value itself is never shown in these findings, the report, or the JSON export.",
                  "Remove the plaintext value from the command line, supply it through a secret store instead, and rotate it."));
                continue;
              }
              if (BOOL_FLAGS[name]) {
                setSetting(name, val === null ? true : val, lineNo);
              } else if (VALUE_FLAGS[name]) {
                if (val !== null) setSetting(name, val, lineNo);
                else if (j + 1 < toks.length && toks[j + 1].indexOf("--") !== 0) { setSetting(name, toks[j + 1], lineNo); j++; }
                else pendingFlag = { name: name, line: lineNo };
              } else {
                findings.push(finding("NOT RECOGNIZED", lineNo,
                  "Flag '--" + name + "' is NOT RECOGNIZED",
                  "Line " + lineNo + " uses --" + name + ", which is not a known CockroachDB node-start flag. It was not guessed at and none of its effects were graded.",
                  "Check the spelling against the CockroachDB version you run, remove the flag, or replace it with the supported flag for what you meant."));
                if (val === null && j + 1 < toks.length && toks[j + 1].indexOf("--") !== 0) j++; // swallow its value
              }
            } else if (tok === "start" || tok === "start-single-node") {
              if (!command) { command = tok; commandLine = lineNo; }
              handledAny = true;
            } else if (tok.indexOf("cockroach") >= 0 || tok.indexOf("/") >= 0) {
              handledAny = true; // binary path
            } else {
              strays++;
            }
          }
          return strays;
        }

        for (n = 1; n <= lines.length; n++) {
          rawLine = lines[n - 1];
          scanSecrets(rawLine, n, findings);
          trimmed = rawLine.trim();
          if (!trimmed) continue;
          if (trimmed.charAt(0) === "#") continue; // comment
          cont = /\\$/.test(trimmed);
          line = cont ? trimmed.replace(/\\$/, "").trim() : trimmed;

          if (/^\[.*\]$/.test(line)) { handledAny = true; continue; } // systemd section header

          // Pending value-flag from a previous line takes this line's first token.
          if (pendingFlag && line.indexOf("--") !== 0) {
            var ptoks = tokenize(line);
            if (ptoks && ptoks.length) {
              setSetting(pendingFlag.name, ptoks[0], pendingFlag.line);
              pendingFlag = null;
              if (ptoks.length > 1) parseFlagTokens(ptoks.slice(1), n);
              continue;
            }
          }

          // key=value (systemd keys, env-style, ExecStart)
          var kv = line.match(/^([A-Za-z][A-Za-z0-9_-]*)=(.*)$/);
          if (kv) {
            var key = kv[1], rest = kv[2];
            var normKey = key.toLowerCase().replace(/_/g, "-");
            if (/^execstart/i.test(key)) {
              var etoks = tokenize(rest);
              if (etoks === null) {
                findings.push(finding("NOT PARSED", n,
                  "Line " + n + " could not be parsed",
                  "The ExecStart value on this line has an unterminated quote, so the launch command could not be read.",
                  "Close the quote on line " + n + " and re-audit."));
              } else parseFlagTokens(etoks, n);
            } else if (YAML_KEYS[normKey]) {
              setSetting(normKey, rest.replace(/^["']|["']$/g, ""), n);
            }
            handledAny = true;
            continue;
          }

          // YAML-style key: value
          var ym = line.match(/^([A-Za-z][A-Za-z0-9_-]*)\s*:\s+(\S.*)$/);
          if (ym && line.indexOf("--") !== 0) {
            var ykey = ym[1].toLowerCase().replace(/_/g, "-");
            var yval = ym[2].replace(/^["']|["']$/g, "");
            if (YAML_KEYS[ykey]) setSetting(ykey, yval, n);
            else findings.push(finding("NOT RECOGNIZED", n,
              "Setting '" + ym[1] + "' is NOT RECOGNIZED",
              "Line " + n + " sets '" + ym[1] + "', which is not a known CockroachDB node setting name. It was not guessed at and its effect was not graded.",
              "Check the setting name against your CockroachDB version, or remove the line."));
            handledAny = true;
            continue;
          }

          // Token-based lines: command lines, flag lines, continuations.
          tokens = tokenize(line);
          if (tokens === null) {
            findings.push(finding("NOT PARSED", n,
              "Line " + n + " could not be parsed",
              "This line has an unterminated quote, so none of it was trusted.",
              "Close the quote on line " + n + " and re-audit."));
            continue;
          }
          var isCommandish = line.indexOf("--") === 0 || /cockroach/.test(line) ||
            tokens[0] === "start" || tokens[0] === "start-single-node" ||
            (n > 1 && /\\$/.test(lines[n - 2].trim()));
          if (isCommandish) {
            var strays = parseFlagTokens(tokens, n);
            if (strays > 0) {
              findings.push(finding("NOT PARSED", n,
                "Line " + n + " could not be parsed in full",
                "Part of this line did not read as a flag, a value, or part of the launch command, so that part was not graded.",
                "Rewrite line " + n + " as plain flags (one --flag=value per setting) and re-audit."));
            }
          } else {
            findings.push(finding("NOT PARSED", n,
              "Line " + n + " could not be parsed",
              "This line does not read as a flag, a key=value setting, a YAML-style setting, or part of the launch command, so it was not graded.",
              "Rewrite line " + n + " in one of those forms, or remove it if it does not belong in the node config."));
          }
        }

        if (pendingFlag) {
          findings.push(finding("NOT PARSED", pendingFlag.line,
            "Line " + pendingFlag.line + " could not be parsed in full",
            "Flag --" + pendingFlag.name + " on line " + pendingFlag.line + " has no value anywhere in the paste, so it was not graded.",
            "Give --" + pendingFlag.name + " a value, or remove the flag."));
        }

        if (!looksLikeCockroach(raw) || (!handledAny && !command)) {
          return {
            verdict: "NOT ENOUGH TO GRADE",
            why: "This paste does not read as a CockroachDB node config. No cockroach start / start-single-node command, no known node-start flags, and no node settings were found in it, so there is nothing here this auditor can grade.",
            findings: [], passed: [], counts: null, notCockroach: true
          };
        }

        /* ---------- Posture grading ---------- */
        var insecureS = settings["insecure"];
        var insecureVal = insecureS ? parseBool(insecureS.value) : null;
        var insecureOn = insecureVal === true;
        var certsS = settings["certs-dir"];
        var hasCerts = !!certsS;

        if (insecureOn) {
          findings.push(finding("BLOCKER", insecureS.line,
            "--insecure is set — the node runs with no authentication and no encryption",
            "Line " + insecureS.line + " turns on insecure mode. In insecure mode CockroachDB does not authenticate clients and does not encrypt traffic; anyone who can reach the node's ports owns the data. Nothing else in the paste can offset this.",
            "Remove --insecure and start the node with --certs-dir pointing at a real CA-signed certs directory."));
        } else if (insecureVal === false) {
          passed.push("Insecure mode is explicitly off (line " + insecureS.line + ").");
        } else {
          passed.push("No --insecure flag in the paste — insecure mode is not switched on.");
        }

        if (!insecureOn && !hasCerts) {
          findings.push(finding("WARNING", commandLine || 1,
            "No --certs-dir in the paste, and insecure mode is off",
            "With --insecure off, a CockroachDB node needs certificates to start securely, but the paste names no --certs-dir. Either the certs come from somewhere outside this paste (a wrapper, an environment file), or the node will not start in secure mode at all.",
            "Add --certs-dir with the path to the node's certs directory, or confirm in writing where the certs are supplied from before deploying."));
        }
        if (hasCerts && !insecureOn) {
          passed.push("--certs-dir is present (line " + certsS.line + ") — the node has a certificates home for secure mode.");
        }
        if (hasCerts && insecureOn) {
          findings.push(finding("NOTE", certsS.line,
            "--certs-dir is set but ignored while --insecure is on",
            "Line " + certsS.line + " names a certs directory, but insecure mode (line " + insecureS.line + ") switches certificate checks off, so those certs protect nothing.",
            "Once --insecure is removed, the certs directory on line " + certsS.line + " takes effect."));
        }

        // Address binds
        var addrFlags = [
          { name: "listen-addr", label: "SQL / inter-node listener" },
          { name: "advertise-addr", label: "Advertised address other nodes dial" },
          { name: "sql-addr", label: "SQL listener" },
          { name: "http-addr", label: "HTTP / Admin UI listener" }
        ];
        var anyBind = false, anyAllIface = false;
        var sqlPort = 26257, httpPort = 8080, sqlHost = null, httpHost = null;
        addrFlags.forEach(function (af) {
          var s = settings[af.name];
          if (!s) return;
          anyBind = true;
          var a = parseAddr(String(s.value));
          if (!a) return;
          if (af.name === "listen-addr" || af.name === "sql-addr") { if (a.port) sqlPort = a.port; sqlHost = a.host; }
          if (af.name === "http-addr") { if (a.port) httpPort = a.port; httpHost = a.host; }
          if (isAllInterfaces(a)) {
            anyAllIface = true;
            if (insecureOn) {
              findings.push(finding("BLOCKER", s.line,
                "--" + af.name + " is bound to all interfaces (0.0.0.0) while --insecure is on",
                "Line " + s.line + " binds the " + af.label.toLowerCase() + " to every network interface, and insecure mode (line " + insecureS.line + ") means no authentication and no encryption on it. This port is open to the whole network exactly as pasted.",
                "Bind --" + af.name + " to a specific internal address, turn --insecure off, and put the node behind a firewall that only allows the cluster and your SQL clients."));
            } else if (!hasCerts) {
              findings.push(finding("WARNING", s.line,
                "--" + af.name + " is bound to all interfaces (0.0.0.0) with no certs posture in the paste",
                "Line " + s.line + " binds the " + af.label.toLowerCase() + " to every network interface, and the paste shows no --certs-dir, so nothing in the paste proves this port is authenticated or encrypted.",
                "Add --certs-dir, bind --" + af.name + " to a specific internal address where you can, and firewall the port to the cluster and your SQL clients."));
            } else if (af.name === "advertise-addr") {
              findings.push(finding("WARNING", s.line,
                "--advertise-addr is 0.0.0.0, which other nodes cannot dial",
                "Line " + s.line + " advertises 0.0.0.0. An advertise address is the address other nodes use to reach this one, and 0.0.0.0 is a bind wildcard, not a routable address — peers will fail to connect.",
                "Set --advertise-addr to this node's real reachable hostname or IP and its inter-node port."));
            } else if (af.name === "http-addr") {
              findings.push(finding("NOTE", s.line,
                "Admin UI port " + httpPort + " is bound to all interfaces (--http-addr)",
                "Line " + s.line + " exposes the HTTP Admin UI on every interface. Certificates are configured, but the UI login page is still reachable from anywhere that can route to this host.",
                "Bind --http-addr to a management address or 127.0.0.1 and reach the UI through a tunnel or bastion, or firewall port " + httpPort + " to admin networks only."));
            } else {
              findings.push(finding("NOTE", s.line,
                "--" + af.name + " is bound to all interfaces (0.0.0.0)",
                "Line " + s.line + " binds the " + af.label.toLowerCase() + " to every interface. Certificates are in place, so the port is authenticated and encrypted; the exposure is a firewall question, not a crypto one.",
                "Confirm the firewall only allows the other cluster nodes and your SQL clients to reach this port."));
            }
          }
        });
        if (anyBind && !anyAllIface) {
          passed.push("No address in the paste is bound to 0.0.0.0 — listeners name specific addresses.");
        }
        if (settings["http-addr"] && isLoopback(parseAddr(String(settings["http-addr"].value)))) {
          passed.push("Admin UI (--http-addr, line " + settings["http-addr"].line + ") is bound to loopback only.");
        }
        if (anyBind) {
          findings.push(finding("NOTE", commandLine || 1,
            "Ports named in this paste",
            "SQL port " + sqlPort + (sqlHost ? " on " + sqlHost : "") + " · HTTP / Admin UI port " + httpPort + (httpHost ? " on " + httpHost : "") + ". These are the only ports this paste opens; anything else a firewall rule allows is outside what was graded."));
        }

        // start-single-node wording
        if (command === "start-single-node") {
          var prodMatch = raw.match(/\bproduction\b|\bprod\b|multi[-\s]?node|\b\d+\s*[- ]?nodes?\b|more nodes|cluster of/i);
          if (prodMatch) {
            findings.push(finding("WARNING", commandLine,
              "start-single-node is paired with production / multi-node wording",
              "Line " + commandLine + " starts the node with start-single-node — a one-node mode with no replication — while the paste also talks about production or multiple nodes (\"" + prodMatch[0] + "\"). A single node is a single point of failure: one dead disk or host takes the whole database down.",
              "For anything production or multi-node, run 'cockroach start' with --certs-dir and a --join list naming at least three nodes. Keep start-single-node for local development and throwaway data only."));
          } else {
            findings.push(finding("NOTE", commandLine,
              "start-single-node mode",
              "Line " + commandLine + " uses start-single-node: one node, no replication. That is a fine fit for local development and throwaway data, and a fragile one for anything you would miss.",
              "If this data matters, move to 'cockroach start' with --join across at least three nodes."));
          }
        }

        // --join posture
        var joinS = settings["join"];
        if (joinS) {
          var joinVal = String(joinS.value);
          var targets = joinVal.split(",").map(function (t) { return t.trim(); }).filter(Boolean);
          if (/insecure/i.test(joinVal)) {
            findings.push(finding("BLOCKER", joinS.line,
              "--join points at an insecure node",
              "Line " + joinS.line + " names a join target described as insecure. Joining through an insecure node means this node bootstraps its trust from a node that does not authenticate — the cluster's identity is only as strong as that first handshake.",
              "Point --join at secure nodes started with --certs-dir and no --insecure, and rebuild any node that was started in insecure mode."));
          } else if (targets.length === 1) {
            findings.push(finding("WARNING", joinS.line,
              "--join names a single join target",
              "Line " + joinS.line + " lists exactly one node to join through. If that one node is down or unreachable when this node starts, this node cannot join the cluster — and a one-node list often means the rest of the cluster was never written down.",
              "List at least two or three existing nodes in --join (ideally every other node) so a single outage cannot strand this node at startup."));
          } else if (targets.length >= 2) {
            passed.push("--join names " + targets.length + " targets (line " + joinS.line + ") — no single join point of failure.");
          }
        } else if (command === "start") {
          findings.push(finding("NOTE", commandLine,
            "No --join in the paste",
            "A 'cockroach start' node with no --join reads as a first / bootstrap node (or the join list lives outside this paste). That is correct for exactly one node in a new cluster and wrong for every node after it.",
            "If this is not the first node of a new cluster, add --join naming the existing nodes."));
        }

        // background / locality / store — noted only when present in the paste
        if (settings["background"]) {
          findings.push(finding("NOTE", settings["background"].line,
            "--background is set — the node daemonizes",
            "Line " + settings["background"].line + " sends the node into the background. Under systemd or another supervisor that is usually doubled supervision; run in the foreground there so the supervisor owns restarts and logs.",
            "If a supervisor manages this node, drop --background; if you start it by hand, keep it and make sure the log directory is watched."));
        }
        if (settings["locality"]) {
          var tiers = String(settings["locality"].value).split(",").filter(Boolean).length;
          findings.push(finding("NOTE", settings["locality"].line,
            "--locality is set (" + tiers + " tier" + (tiers === 1 ? "" : "s") + ")",
            "Line " + settings["locality"].line + " declares the node's locality. Locality only pays off when every node declares a consistent tier scheme and your tables' survival goals use it — a locality on one node alone changes nothing.",
            "Confirm every node in the cluster declares locality with the same tier keys in the same order."));
        }
        if (settings["store"]) {
          var storeVal = String(settings["store"].value);
          var pathMatch = storeVal.match(/path=([^,]+)/);
          var storePath = pathMatch ? pathMatch[1] : storeVal;
          if (/^\/tmp\b/.test(storePath) || /^tmp\b/.test(storePath)) {
            findings.push(finding("WARNING", settings["store"].line,
              "Store path is under /tmp",
              "Line " + settings["store"].line + " puts the node's data store at " + storePath + ". /tmp is wiped on reboot and cleaned by the OS on many systems — the node's data would go with it.",
              "Move the store to a durable, dedicated path (for example /var/lib/cockroach/data) on a disk that is backed up or replicated."));
          } else {
            findings.push(finding("NOTE", settings["store"].line,
              "Store path: " + storePath,
              "Line " + settings["store"].line + " sets the data store. Confirm the path is on a durable disk with room to grow — CockroachDB writes its data, logs-adjacent temp files, and replication traffic against it.",
              "Confirm the disk behind " + storePath + " is monitored for free space before this goes live."));
          }
        }

        findings.sort(function (a, b) {
          if (SEV_RANK[a.severity] !== SEV_RANK[b.severity]) return SEV_RANK[a.severity] - SEV_RANK[b.severity];
          return a.line - b.line;
        });

        var counts = { BLOCKER: 0, WARNING: 0, "NOT RECOGNIZED": 0, "NOT PARSED": 0, NOTE: 0 };
        findings.forEach(function (f) { counts[f.severity]++; });

        var verdict, why;
        if (counts.BLOCKER > 0) {
          verdict = "DO NOT DEPLOY";
          why = counts.BLOCKER + " blocker" + (counts.BLOCKER === 1 ? "" : "s") + " in this paste would go live exactly as written. Fix every blocker, then re-audit before this node starts.";
        } else if (counts.WARNING > 0 || counts["NOT RECOGNIZED"] > 0 || counts["NOT PARSED"] > 0) {
          verdict = "DEPLOY WITH FIXES";
          why = "No blockers, but " + (counts.WARNING + counts["NOT RECOGNIZED"] + counts["NOT PARSED"]) + " item" + ((counts.WARNING + counts["NOT RECOGNIZED"] + counts["NOT PARSED"]) === 1 ? "" : "s") + " need" + ((counts.WARNING + counts["NOT RECOGNIZED"] + counts["NOT PARSED"]) === 1 ? "s" : "") + " attention first — warnings to fix, plus anything marked NOT RECOGNIZED or NOT PARSED, which this auditor will not guess at.";
        } else {
          verdict = "SAFE TO DEPLOY";
          why = "No blockers, no warnings, nothing unrecognized or unparsed. The posture written in this paste — secure mode, certs in place, specific binds — is the posture the node will start with.";
        }
        return { verdict: verdict, why: why, findings: findings, passed: passed, counts: counts, notCockroach: false };
      }

      /* ---------- Report + JSON (built only from findings, so secrets can't leak) ---------- */
      function buildReport(r) {
        var out = [];
        out.push("J-Dawgs CockroachDB Node Config Safety Auditor\u2122 — audit report");
        out.push("Verdict: " + r.verdict);
        out.push(r.why);
        out.push("");
        if (r.counts) {
          out.push("Counts: " + r.counts.BLOCKER + " blocker(s), " + r.counts.WARNING + " warning(s), " +
            r.counts["NOT RECOGNIZED"] + " not recognized, " + r.counts["NOT PARSED"] + " not parsed, " + r.counts.NOTE + " note(s)");
          out.push("");
        }
        if (r.findings.length) {
          out.push("FINDINGS");
          r.findings.forEach(function (f) {
            out.push("[" + f.severity + "] Line " + f.line + " — " + f.title);
            out.push("  " + f.detail);
            if (f.fix) out.push("  Fix: " + f.fix);
          });
          out.push("");
        }
        if (r.passed.length) {
          out.push("CHECKS THAT PASSED");
          r.passed.forEach(function (p) { out.push("- " + p); });
          out.push("");
        }
        out.push("Scope: this tool parses pasted text only. It never connects to a cluster, never starts a node, and checks nothing on disk or on the network. Secrets found in a paste are reported by key name, line number, and value length only — never by value.");
        return out.join("\n");
      }
      function buildJSON(r) {
        return JSON.stringify({
          tool: "J-Dawgs CockroachDB Node Config Safety Auditor\u2122",
          verdict: r.verdict,
          verdict_detail: r.why,
          counts: r.counts,
          findings: r.findings.map(function (f) {
            return { severity: f.severity, line: f.line, title: f.title, detail: f.detail, fix: f.fix };
          }),
          checks_passed: r.passed,
          scope: "Parses pasted text only; never connects to a cluster. Secrets are reported by key name, line number, and value length only — never by value."
        }, null, 2);
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-cockroachdb-node-config-safety-auditor',
  name: 'J-Dawgs CockroachDB Node Config Safety Auditor',
  description: 'Grades pasted CockroachDB node startup flags / systemd / YAML fully offline into one deploy verdict — --insecure flagged as a blocker, all-interface binds checked against certs posture, certs-dir presence, join-list posture, and port exposure, with unknown flags marked NOT RECOGNIZED and plaintext s',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
