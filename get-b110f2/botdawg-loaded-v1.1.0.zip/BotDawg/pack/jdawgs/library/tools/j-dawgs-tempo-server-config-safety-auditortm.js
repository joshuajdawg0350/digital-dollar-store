'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Tempo Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        'use strict';

        var TEMPO_TOP_LEVEL = {
          auth_enabled: 1, server: 1, compactor: 1, distributor: 1, ingester: 1,
          querier: 1, query_frontend: 1, frontend_worker: 1, storage: 1,
          overrides: 1, metrics_generator: 1, memberlist: 1, usage_report: 1,
          internal_server: 1
        };
        var SEV_RANK = { BLOCKER: 0, HIGH: 1, WARNING: 2, INFO: 3 };

        /* ---------- subset YAML reader ---------- */

        function stripComment(v) {
          v = v.replace(/\s+$/, '');
          if (v.charAt(0) === '"' || v.charAt(0) === "'") return v;
          var idx = v.indexOf(' #');
          if (idx >= 0) v = v.slice(0, idx);
          return v.replace(/\s+$/, '');
        }
        function cleanValue(v) {
          v = stripComment(String(v).trim()).trim();
          if (v.length >= 2) {
            var a = v.charAt(0), b = v.charAt(v.length - 1);
            if ((a === '"' && b === '"') || (a === "'" && b === "'")) return v.slice(1, -1);
          }
          return v;
        }
        var KEY_RE = /^([A-Za-z0-9_][A-Za-z0-9_.\-]*)\s*:\s*(.*)$/;

        function parseTempo(text) {
          var lines = String(text).split(/\r?\n/);
          var entries = [];
          var notParsed = [];
          var stack = [];
          var listCounts = {};
          function currentPath() { return stack.length ? stack[stack.length - 1].path : ''; }
          for (var i = 0; i < lines.length; i++) {
            var lineNo = i + 1;
            var raw = lines[i];
            var trimmed = raw.replace(/^\s+/, '').replace(/\s+$/, '');
            if (!trimmed || trimmed.charAt(0) === '#') continue;
            var indent = raw.match(/^\s*/)[0].length;
            if (trimmed === '-' || trimmed.indexOf('- ') === 0) {
              var rest = trimmed === '-' ? '' : trimmed.slice(2).replace(/^\s+/, '');
              while (stack.length && stack[stack.length - 1].indent >= indent) stack.pop();
              var parent = currentPath();
              var ck = parent + '@' + indent;
              var idx = listCounts[ck] || 0;
              listCounts[ck] = idx + 1;
              var itemPath = parent ? parent + '[' + idx + ']' : '[' + idx + ']';
              stack.push({ indent: indent, path: itemPath, isList: true });
              if (rest) {
                var lm = rest.match(KEY_RE);
                if (lm) {
                  entries.push({ path: itemPath + '.' + lm[1], key: lm[1], value: cleanValue(lm[2]), line: lineNo, section: false });
                } else {
                  entries.push({ path: itemPath, key: '(list value)', value: cleanValue(rest), line: lineNo, section: false, listScalar: true });
                }
              }
              continue;
            }
            var m = trimmed.match(KEY_RE);
            if (!m) { notParsed.push({ line: lineNo }); continue; }
            var key = m[1];
            var val = cleanValue(m[2]);
            while (stack.length) {
              var t = stack[stack.length - 1];
              if (t.indent > indent || (t.indent === indent && !t.isList)) stack.pop(); else break;
            }
            var par = currentPath();
            var path = par ? par + '.' + key : key;
            var isSection = (val === '');
            entries.push({ path: path, key: key, value: isSection ? null : val, line: lineNo, section: isSection });
            if (isSection) stack.push({ indent: indent, path: path, isList: false });
          }
          return { entries: entries, notParsed: notParsed, lineCount: lines.length };
        }

        /* ---------- helpers over parsed entries ---------- */

        function byPath(entries, path) {
          for (var i = 0; i < entries.length; i++) if (entries[i].path === path) return entries[i];
          return null;
        }
        function underPrefix(entries, prefix) {
          var out = [];
          for (var i = 0; i < entries.length; i++) {
            var p = entries[i].path;
            if (p === prefix || p.indexOf(prefix + '.') === 0 || p.indexOf(prefix + '[') === 0) out.push(entries[i]);
          }
          return out;
        }
        function byKey(entries, key) {
          var out = [];
          for (var i = 0; i < entries.length; i++) if (entries[i].key === key) out.push(entries[i]);
          return out;
        }
        function isTrue(v) { return String(v).toLowerCase() === 'true'; }
        function isFalse(v) { return String(v).toLowerCase() === 'false'; }
        function isEnvRef(v) { return /\$\{[^}]*\}/.test(v) || /^\$[A-Za-z_][A-Za-z0-9_]*$/.test(v); }
        function isWideValue(v) {
          if (v == null) return false;
          var s = String(v).replace(/["'\[\]]/g, ' ').trim();
          if (!s) return false;
          var first = s.split(/[\s,]+/)[0];
          var host = first;
          var pm = first.match(/^(.*):(\d+)$/);
          if (pm) host = pm[1];
          host = host.replace(/^\[/, '').replace(/\]$/, '');
          return host === '0.0.0.0' || host === '::' || host === '*';
        }
        function durationHours(v) {
          if (v == null) return null;
          var s = String(v).trim().toLowerCase();
          if (/^[-+]?\d+(\.\d+)?$/.test(s)) return parseFloat(s);
          var mult = { y: 8760, w: 168, d: 24, h: 1, m: 1 / 60, s: 1 / 3600, ms: 1 / 3600000 };
          var re = /(\d+(?:\.\d+)?)(y|w|d|h|ms|m|s)/g;
          var total = 0, matched = false, mm;
          while ((mm = re.exec(s)) !== null) { total += parseFloat(mm[1]) * mult[mm[2]]; matched = true; }
          return matched ? total : null;
        }
        function tlsConfigured(entries, prefix) {
          var cert = byPath(entries, prefix + '.cert_file');
          return !!(cert && !cert.section && cert.value && !isEnvRef(cert.value) ? true : (cert && !cert.section && cert.value));
        }

        /* ---------- the audit ---------- */

        function audit(text) {
          var findings = [];
          function add(severity, line, path, message, fix) {
            findings.push({ severity: severity, line: line, path: path, message: message, fix: fix });
          }

          var trimmedAll = String(text).trim();
          if (!trimmedAll) {
            return { verdict: 'NOT ENOUGH TO GRADE', reason: 'The paste is empty — there is no configuration to grade.', findings: [], notParsed: [], lineCount: 0 };
          }
          if (trimmedAll.charAt(0) === '{' || trimmedAll.charAt(0) === '[') {
            return { verdict: 'NOT ENOUGH TO GRADE', reason: 'The paste looks like JSON, not a tempo.yaml-style YAML config. Export or convert the configuration to YAML and paste that instead.', findings: [], notParsed: [], lineCount: String(text).split(/\r?\n/).length };
          }

          var parsed = parseTempo(text);
          var entries = parsed.entries;
          var topKeys = {};
          entries.forEach(function (e) {
            if (e.path.indexOf('.') === -1 && e.path.indexOf('[') === -1) topKeys[e.key] = true;
          });
          var recognized = Object.keys(topKeys).some(function (k) { return TEMPO_TOP_LEVEL[k]; });
          var leafCount = entries.filter(function (e) { return !e.section; }).length;
          if (!recognized || leafCount === 0) {
            return { verdict: 'NOT ENOUGH TO GRADE', reason: 'Nothing in the paste reads as a Grafana Tempo configuration — none of the top-level Tempo blocks (server, distributor, ingester, compactor, storage, overrides, metrics_generator, memberlist, auth_enabled) were found. Prose, other tools’ configs, and fragments cannot be graded as a Tempo deployment.', findings: [], notParsed: parsed.notParsed, lineCount: parsed.lineCount };
          }

          /* exposure picture, used by several checks */
          var httpAddr = byPath(entries, 'server.http_listen_address');
          var grpcAddr = byPath(entries, 'server.grpc_listen_address');
          var httpWide = !!(httpAddr && isWideValue(httpAddr.value));
          var grpcWide = !!(grpcAddr && isWideValue(grpcAddr.value));
          var httpTls = tlsConfigured(entries, 'server.http_tls_config');
          var grpcTls = tlsConfigured(entries, 'server.grpc_tls_config');
          var receiverEndpoints = underPrefix(entries, 'distributor.receivers').filter(function (e) { return e.key === 'endpoint' && !e.section; });
          var receiverWide = receiverEndpoints.some(function (e) { return isWideValue(e.value); });
          var memberBinds = byKey(entries, 'bind_addr').filter(function (e) { return e.path.indexOf('memberlist') === 0; });
          var memberWide = memberBinds.some(function (e) { return isWideValue(e.value); });
          var listenersExposed = httpWide || grpcWide || receiverWide || memberWide;

          /* auth_enabled */
          var auth = byPath(entries, 'auth_enabled');
          if (auth && isFalse(auth.value)) {
            if (listenersExposed) {
              add('BLOCKER', auth.line, 'auth_enabled',
                'auth_enabled is false — tenant authentication / multi-tenancy is off — while at least one listener is bound to all interfaces. Anyone who can reach the port can read and write traces as any tenant.',
                'Set auth_enabled: true and require the X-Scope-OrgID tenant header through your gateway, and bind listeners to a private interface (see the listener findings below).');
            } else {
              add('HIGH', auth.line, 'auth_enabled',
                'auth_enabled is false — tenant authentication / multi-tenancy is off. Any client that can reach Tempo can read and write traces without a tenant identity.',
                'Set auth_enabled: true and pass a tenant (X-Scope-OrgID) from an authenticating gateway, or keep Tempo on a fully private network segment and document that choice.');
            }
          } else if (!auth) {
            add('INFO', 1, 'auth_enabled',
              'auth_enabled is not stated anywhere in the config. Tempo’s default is false, so unless another part of the file turns it on, tenant authentication is off.',
              'State auth_enabled explicitly — true for any shared or reachable deployment — so the posture is a decision, not a default.');
          }

          /* server listeners + TLS */
          [[httpAddr, 'server.http_listen_address', 'HTTP', httpTls, 'server.http_tls_config'],
           [grpcAddr, 'server.grpc_listen_address', 'gRPC', grpcTls, 'server.grpc_tls_config']].forEach(function (row) {
            var entry = row[0];
            if (!entry || entry.section) return;
            if (isWideValue(entry.value)) {
              if (!row[3]) {
                add('HIGH', entry.line, row[1],
                  row[1] + ' is bound to ' + entry.value + ' (all interfaces) and no TLS posture is configured (' + row[4] + ' is absent or its cert_file is empty). The ' + row[2] + ' API is reachable in plaintext from anywhere that can route to this host.',
                  'Bind to a private address (for example 127.0.0.1 or a VPC-only IP), or keep the wide bind and configure ' + row[4] + ' with cert_file and key_file so the listener serves TLS.');
              } else {
                add('WARNING', entry.line, row[1],
                  row[1] + ' is bound to ' + entry.value + ' (all interfaces). TLS is configured, but the ' + row[2] + ' API is still exposed on every interface.',
                  'Bind to the narrowest address that still serves your clients (loopback or a private subnet), and let a gateway own the public edge.');
              }
            }
          });
          ['server.http_tls_config', 'server.grpc_tls_config'].forEach(function (p) {
            var sec = byPath(entries, p);
            if (sec && sec.section) {
              var cert = byPath(entries, p + '.cert_file');
              if (!cert || cert.section || !cert.value) {
                add('WARNING', sec.line, p,
                  p + ' is present but cert_file is missing or empty, so the TLS block configures nothing — the listener falls back to plaintext.',
                  'Set cert_file (and key_file) under ' + p + ' to real certificate paths, or remove the empty block so the missing TLS posture is not disguised.');
              }
            }
          });

          /* distributor receivers */
          var distributorTls = underPrefix(entries, 'distributor').some(function (e) { return e.key === 'cert_file' && e.value; });
          receiverEndpoints.forEach(function (e) {
            if (isWideValue(e.value)) {
              if (!distributorTls) {
                add('HIGH', e.line, e.path,
                  'Distributor receiver endpoint ' + e.value + ' is bound to all interfaces with no TLS configured for the distributor. Producers will push traces in plaintext to a port anyone can reach.',
                  'Bind the receiver to a private address, or configure TLS for the receiver protocols, and firewall the ingest ports to known producers.');
              } else {
                add('WARNING', e.line, e.path,
                  'Distributor receiver endpoint ' + e.value + ' is bound to all interfaces (TLS material is present elsewhere in the distributor block).',
                  'Bind the receiver to the narrowest address your producers can reach.');
              }
            }
          });

          /* memberlist */
          memberBinds.forEach(function (e) {
            if (isWideValue(e.value)) {
              add('WARNING', e.line, e.path,
                'memberlist bind_addr is ' + e.value + ' — the gossip ring listens on all interfaces, so any reachable host can attempt to join or probe the cluster ring.',
                'Set memberlist.bind_addr to a private interface address and restrict the memberlist port (default 7946) to cluster members only.');
            }
          });

          /* compactor retention */
          var retentionEntries = underPrefix(entries, 'compactor').filter(function (e) { return e.key === 'block_retention' && !e.section; });
          var retentionEnabledEntries = underPrefix(entries, 'compactor').filter(function (e) { return e.key === 'retention_enabled' && !e.section; });
          var compactorSec = byPath(entries, 'compactor');
          retentionEnabledEntries.forEach(function (e) {
            if (isFalse(e.value)) {
              add('HIGH', e.line, e.path,
                'retention_enabled is false under the compactor — trace retention is switched off, so blocks are kept forever and storage grows without bound.',
                'Remove retention_enabled: false (or set it true) and set compaction block_retention to the period you actually intend to keep traces.');
            }
          });
          if (retentionEntries.length === 0) {
            add('WARNING', compactorSec ? compactorSec.line : 1, 'compactor.compaction.block_retention',
              'compaction block_retention is not set anywhere under compactor. With no retention stated, there is no configured point at which old trace blocks are deleted — storage growth is unbounded and data-retention expectations are undocumented.',
              'Set compactor.compaction.block_retention to an explicit period (for example 720h for 30 days) that matches your retention policy.');
          } else {
            retentionEntries.forEach(function (e) {
              var hrs = durationHours(e.value);
              if (hrs === 0) {
                add('HIGH', e.line, e.path,
                  'compaction block_retention is 0 — in Tempo a zero retention disables block deletion, so trace blocks are kept forever and storage grows without bound.',
                  'Set block_retention to the real retention period (for example 336h or 720h). If infinite retention is deliberate, say so in a comment and budget the storage.');
              } else if (hrs !== null && hrs >= 87600) {
                add('HIGH', e.line, e.path,
                  'compaction block_retention is ' + e.value + ' — at or beyond 87600h (10 years) that is effectively infinite retention: old traces effectively never expire.',
                  'Set block_retention to the period your policy actually requires (30–90 days is typical), or document the exception and its storage budget.');
              } else if (hrs === null) {
                add('WARNING', e.line, e.path,
                  'compaction block_retention value “' + e.value + '” could not be read as a duration by this auditor, so the retention posture cannot be confirmed.',
                  'Write block_retention as a plain Go-style duration (for example 720h) so both Tempo and reviewers read the same number.');
              }
            });
          }

          /* ingestion / limits posture */
          var limitChecks = [
            { keys: ['max_traces_per_user'], label: 'max_traces_per_user (per-tenant trace cap)' },
            { keys: ['max_bytes_per_trace'], label: 'max_bytes_per_trace (per-trace size cap)' },
            { keys: ['ingestion_rate_limit_bytes', 'rate_limit_bytes'], label: 'ingestion rate limit (ingestion_rate_limit_bytes / rate_limit_bytes)' },
            { keys: ['ingestion_burst_size_bytes', 'burst_size_bytes'], label: 'ingestion burst limit (ingestion_burst_size_bytes / burst_size_bytes)' }
          ];
          var missingLimits = [];
          limitChecks.forEach(function (lc) {
            var found = lc.keys.some(function (k) { return byKey(entries, k).some(function (e) { return !e.section; }); });
            if (!found) missingLimits.push(lc.label);
          });
          if (missingLimits.length) {
            var overridesSec = byPath(entries, 'overrides');
            var ingesterSec = byPath(entries, 'ingester');
            add('WARNING', overridesSec ? overridesSec.line : (ingesterSec ? ingesterSec.line : 1), 'overrides',
              'Unbounded ingestion posture — these limits are not set anywhere in the config: ' + missingLimits.join('; ') + '. One noisy or hostile tenant can ingest without a cap and crowd out everyone else.',
              'Set the missing limits under overrides (defaults or per-tenant): ingestion rate/burst, max_traces_per_user, and max_bytes_per_trace sized to your tenants’ real traffic.');
          }

          /* plaintext credentials in storage.trace — value NEVER reported */
          var SECRET_KEYS = { secret_key: 1, storage_account_key: 1, service_account: 1, keyfile: 1, password: 1, client_secret: 1 };
          underPrefix(entries, 'storage.trace').forEach(function (e) {
            if (e.section || !SECRET_KEYS[e.key]) return;
            var v = e.value || '';
            if (!v || isEnvRef(v)) return;
            if ((e.key === 'service_account' || e.key === 'keyfile') && /^[\w.\-\/\\:]+$/.test(v) && v.length <= 200 && v.indexOf('{') === -1) {
              add('INFO', e.line, e.path,
                'storage credential key “' + e.key + '” references a file path rather than inline contents. That is the safe pattern — the file itself is outside what a pasted config can show.',
                'Keep the key file outside the config, readable only by the Tempo process user.');
              return;
            }
            add('BLOCKER', e.line, e.path,
              'Plaintext credential in the trace storage config: key “' + e.key + '” holds a literal secret value ' + v.length + ' characters long. (The value is deliberately not shown here, in the text report, or in the JSON export.) Anyone who can read this config file — repo, backup, ticket, screenshot — has your object-storage credentials.',
              'Replace the literal value with an environment-variable reference such as ${ENV_VAR_NAME} (or your secret manager’s injection), rotate the exposed credential, and purge it from wherever this config has been copied.');
          });

          /* metrics_generator */
          var mgEntries = underPrefix(entries, 'metrics_generator');
          if (mgEntries.length) {
            var mgSec = byPath(entries, 'metrics_generator');
            var rwUrls = mgEntries.filter(function (e) { return e.key === 'url' && !e.section; });
            rwUrls.forEach(function (e) {
              var u = e.value || '';
              if (/^http:\/\//i.test(u)) {
                var host = u.replace(/^http:\/\//i, '').split(/[\/?#]/)[0];
                add('HIGH', e.line, e.path,
                  'metrics_generator remote_write sends generated metrics over plaintext http:// (host: ' + host + '). Service-graph and span metrics leave the host unencrypted and can be tampered with in transit.',
                  'Point remote_write at the https:// endpoint of your metrics backend, or keep the plaintext endpoint on a private, encrypted overlay network and document that choice.');
              }
            });
            var hasStoragePath = mgEntries.some(function (e) { return e.key === 'path' && e.path.indexOf('storage') !== -1 && !e.section; });
            if (!rwUrls.length && !hasStoragePath) {
              add('WARNING', mgSec ? mgSec.line : 1, 'metrics_generator',
                'metrics_generator is configured but states neither a storage path nor a remote_write target, so where the generated metrics go is unstated — the generator’s output posture is undefined.',
                'State the posture explicitly: metrics_generator.storage.path for local WAL plus a remote_write block (https) to your metrics backend.');
            }
          }

          /* query frontend / querier search posture */
          var searchEnabled = byKey(entries, 'search_enabled').some(function (e) { return !e.section && isTrue(e.value); });
          var searchSections = entries.filter(function (e) { return e.section && (e.path === 'query_frontend.search' || e.path === 'querier.search'); });
          if (searchEnabled || searchSections.length) {
            var hasSearchLimits = entries.some(function (e) {
              return !e.section && (e.key === 'max_result_limit' || e.key === 'default_result_limit' || e.key === 'max_duration' || e.key === 'query_timeout') && e.path.indexOf('search') !== -1;
            });
            if (!hasSearchLimits) {
              var anchor = searchSections.length ? searchSections[0] : byKey(entries, 'search_enabled')[0];
              add('INFO', anchor ? anchor.line : 1, anchor ? anchor.path : 'search_enabled',
                'Trace search is enabled but no search limits (result limits, max duration, or query timeout) are stated, so expensive tenant searches are unbounded by anything visible in this config.',
                'State query_frontend.search limits (default_result_limit, max_result_limit, max_duration) sized to your cluster.');
            }
          }

          /* duplicate keys */
          var seen = {};
          entries.forEach(function (e) {
            if (e.path.indexOf('[') !== -1) return;
            if (seen[e.path]) {
              add('WARNING', e.line, e.path,
                'Duplicate key “' + e.path + '” — first defined on line ' + seen[e.path] + ', repeated on line ' + e.line + '. YAML readers silently keep only one of the two values, so the running config may not be the one on the page.',
                'Delete one of the two definitions (lines ' + seen[e.path] + ' and ' + e.line + ') and keep the value you actually intend.');
            } else {
              seen[e.path] = e.line;
            }
          });

          findings.sort(function (a, b) { return (SEV_RANK[a.severity] - SEV_RANK[b.severity]) || (a.line - b.line); });

          var counts = { BLOCKER: 0, HIGH: 0, WARNING: 0, INFO: 0 };
          findings.forEach(function (f) { counts[f.severity]++; });
          var verdict, reason;
          if (counts.BLOCKER > 0) {
            verdict = 'DO NOT DEPLOY';
            reason = counts.BLOCKER + ' blocker finding(s) must be fixed before this config goes anywhere near a real deployment.';
          } else if (counts.HIGH > 0 || counts.WARNING > 0) {
            verdict = 'DEPLOY WITH FIXES';
            reason = 'No blockers, but ' + (counts.HIGH + counts.WARNING) + ' high/warning finding(s) should be fixed first.';
          } else {
            verdict = 'SAFE TO DEPLOY';
            reason = findings.length ? 'No blocker, high, or warning findings — only informational notes.' : 'No findings. Every posture this auditor checks is stated and sound in the pasted config.';
          }
          return { verdict: verdict, reason: reason, findings: findings, notParsed: parsed.notParsed, lineCount: parsed.lineCount, counts: counts };
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-tempo-server-config-safety-auditortm',
  name: 'J-Dawgs Tempo Server Config Safety Auditor',
  description: 'Grades a pasted Grafana Tempo tempo.yaml fully offline into one deploy verdict — auth_enabled off, all-interface listeners without TLS, disabled compactor retention, unbounded ingestion, and plaintext storage credentials shown by key name, line, and length only. Those faults pass silently when a con',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
