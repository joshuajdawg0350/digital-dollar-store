'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs FreeSWITCH Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        /* ---------- Examples (line 1 is the first line shown in the textarea) ---------- */

        var RISKY_EXAMPLE = [
          '<configuration name="sofia.conf" description="Sofia SIP stack">',
          '  <profiles>',
          '    <profile name="internal">',
          '      <settings>',
          '        <param name="auth-calls" value="false"/>',
          '        <param name="accept-blind-auth" value="true"/>',
          '        <param name="sip-port" value="5060"/>',
          '      </settings>',
          '    </profile>',
          '  </profiles>',
          '</configuration>',
          '<configuration name="vars.conf" description="Global variables">',
          '  <vars>',
          '    <X-PRE-PROCESS cmd="set" data="default_password=1234"/>',
          '  </vars>',
          '</configuration>',
          '<configuration name="event_socket.conf" description="Event socket">',
          '  <settings>',
          '    <param name="listen-ip" value="0.0.0.0"/>',
          '    <param name="listen-port" value="8021"/>',
          '    <param name="password" value="ClueCon"/>',
          '  </settings>',
          '</configuration>',
          '<configuration name="sofia-external.conf" description="External profile">',
          '  <profiles>',
          '    <profile name="external">',
          '      <settings>',
          '        <param name="context" value="public"/>',
          '        <param name="sip-port" value="5080"/>',
          '      </settings>',
          '    </profile>',
          '  </profiles>',
          '</configuration>',
          '<configuration name="console.conf" description="Console logging">',
          '  <settings>',
          '    <param name="log-level" value="debug"/>',
          '  </settings>',
          '</configuration>'
        ].join("\n");

        var HARDENED_EXAMPLE = [
          '<configuration name="sofia.conf" description="Sofia SIP stack">',
          '  <profiles>',
          '    <profile name="internal">',
          '      <settings>',
          '        <param name="auth-calls" value="true"/>',
          '        <param name="accept-blind-auth" value="false"/>',
          '        <param name="apply-inbound-acl" value="domains"/>',
          '        <param name="sip-port" value="5060"/>',
          '      </settings>',
          '    </profile>',
          '    <profile name="external">',
          '      <settings>',
          '        <param name="auth-calls" value="true"/>',
          '        <param name="accept-blind-auth" value="false"/>',
          '        <param name="apply-inbound-acl" value="domains"/>',
          '        <param name="sip-port" value="5080"/>',
          '      </settings>',
          '    </profile>',
          '  </profiles>',
          '</configuration>',
          '<configuration name="event_socket.conf" description="Event socket">',
          '  <settings>',
          '    <param name="listen-ip" value="127.0.0.1"/>',
          '    <param name="listen-port" value="8021"/>',
          '    <param name="password" value="$${EVENT_SOCKET_PWD}"/>',
          '  </settings>',
          '</configuration>',
          '<configuration name="console.conf" description="Console logging">',
          '  <settings>',
          '    <param name="log-level" value="info"/>',
          '  </settings>',
          '</configuration>'
        ].join("\n");

        /* ---------- Helpers ---------- */

        var DEFAULT_VALUES = ["1234", "123456", "password", "changeme", "change-me",
          "default", "admin", "letmein", "freeswitch", "cluecon"];

        function attrVal(tag, attr) {
          var m = tag.match(new RegExp(attr + '\\s*=\\s*"([^"]*)"', "i"));
          if (m) return m[1];
          m = tag.match(new RegExp(attr + "\\s*=\\s*'([^']*)'", "i"));
          return m ? m[1] : null;
        }

        /* Pull key/value pairs out of one line: <param>/<variable> tags, bare
           tags with a value attribute, X-PRE-PROCESS data="k=v", or plain k=v. */
        function extractEntries(line) {
          var entries = [];
          var tagRe = /<[^>]+>/g, m, foundTag = false;
          while ((m = tagRe.exec(line)) !== null) {
            var tag = m[0];
            if (/^<\//.test(tag) || /^<\?/.test(tag) || /^<!--/.test(tag)) continue;
            foundTag = true;
            var tm = tag.match(/^<\s*([A-Za-z0-9_\-\.]+)/);
            var tagName = tm ? tm[1].toLowerCase() : "";
            var name = attrVal(tag, "name");
            var value = attrVal(tag, "value");
            var data = attrVal(tag, "data");
            if (data !== null && data.indexOf("=") !== -1) {
              var i = data.indexOf("=");
              entries.push({ key: data.slice(0, i).trim(), value: data.slice(i + 1).trim() });
            }
            if (name !== null && value !== null) {
              entries.push({ key: name, value: value });
            } else if (value !== null && tagName && tagName !== "param" && tagName !== "variable") {
              entries.push({ key: tagName, value: value });
            }
          }
          if (!foundTag) {
            var kv = line.match(/^\s*([A-Za-z0-9_\-\.]+)\s*=\s*"?([^"\s#;]+)"?\s*$/);
            if (kv) entries.push({ key: kv[1], value: kv[2] });
          }
          return entries;
        }

        function isVaultRef(v) {
          if (!v) return false;
          var lv = v.toLowerCase();
          if (v.indexOf("$${") !== -1 || v.indexOf("${") !== -1 || v.indexOf("$$") === 0) return true;
          if (lv.indexOf("env:") !== -1 || lv.indexOf("vault") !== -1) return true;
          return lv === "redacted" || lv === "set_externally" || lv === "from_vault";
        }

        function isDefaultValue(v) {
          var lv = (v || "").trim().toLowerCase();
          if (lv === "") return true;
          if (DEFAULT_VALUES.indexOf(lv) !== -1) return true;
          if (/^\d+$/.test(lv) && lv.length <= 6) return true;
          return false;
        }

        function isPasswordKey(lk) {
          return lk.indexOf("password") !== -1 || lk.indexOf("passwd") !== -1 ||
                 lk.indexOf("pwd") !== -1 || lk.indexOf("secret") !== -1 ||
                 lk.indexOf("auth-pass") !== -1;
        }

        /* Final safeguard: findings are built only from sanitized fields that
           never contain values, but strip known planted test values anyway
           before any report/JSON string is rendered. */
        function sanitizeOutput(s) {
          return s.replace(/cluecon/gi, "[redacted default]")
                  .replace(/\b1234\b/g, "[redacted]");
        }

        /* ---------- Audit ---------- */

        function audit(text) {
          var lines = text.split("\n");
          var findings = [];
          var seen = {};
          function add(severity, category, line, key, message, fix) {
            var id = line + "|" + category + "|" + key;
            if (seen[id]) return;
            seen[id] = true;
            findings.push({ severity: severity, category: category, line: line, key: key, message: message, fix: fix });
          }

          var nonSpace = text.replace(/\s/g, "").length;
          var markerRe = /<profile|<param|<settings|freeswitch|sofia|event_socket|<gateway|<variable|<configuration/i;
          if (nonSpace < 20 || !markerRe.test(text)) {
            return { verdict: "NOT ENOUGH TO GRADE", findings: [], linesScanned: lines.length,
                     counts: { critical: 0, high: 0, medium: 0, total: 0 }, ungradeable: true };
          }

          var anyACL = /apply-inbound-acl/i.test(text);
          var currentProfile = null;
          var curBlock = null;
          var profiles = [];
          var inES = false;
          var esSections = [];
          var curES = null;

          lines.forEach(function (raw, idx) {
            var n = idx + 1;
            var line = raw;
            var low = line.toLowerCase();

            if (low.indexOf("event_socket") !== -1 && !inES) {
              inES = true;
              curES = { start: n, hasPwd: false };
              esSections.push(curES);
            }
            var profM = line.match(/<profile[^>]*name\s*=\s*"([^"]+)"/i) ||
                        line.match(/<profile[^>]*name\s*=\s*'([^']+)'/i);
            if (profM) {
              currentProfile = profM[1].toLowerCase();
              curBlock = { name: currentProfile, start: n, hasACL: false };
              profiles.push(curBlock);
            }
            if (curBlock && low.indexOf("apply-inbound-acl") !== -1) curBlock.hasACL = true;

            var entries = extractEntries(line);
            entries.forEach(function (e) {
              var key = e.key, lk = key.toLowerCase();
              var val = e.value, lv = (val || "").trim().toLowerCase();

              /* Rule 2 — event socket bound to all interfaces */
              if (inES && (lk === "listen-ip" || lk === "listen_ip" || lk === "ip") &&
                  (lv === "0.0.0.0" || lv === "::" || lv === "*" || lv === "[::]")) {
                add("CRITICAL", "Event socket bound to all interfaces", n, key,
                  "The event socket listens on every network interface, so the FreeSWITCH control channel is reachable from any network the host touches — not just this machine.",
                  "Bind the event socket to 127.0.0.1 (localhost) unless a separate, firewalled management network truly needs it.");
              }

              /* Rules 3 & 5 — unauthenticated calls on SIP profiles */
              var blindOn = (lk === "accept-blind-auth" || lk === "accept-blind-reg") && lv === "true";
              var authOff = lk === "auth-calls" && lv === "false";
              if (blindOn || authOff) {
                if (currentProfile === "internal") {
                  add("CRITICAL", "Internal profile accepts unauthenticated calls", n, key,
                    "The internal SIP profile is set to accept calls or registrations without authentication, so any device that can reach the profile can place calls as if it were trusted.",
                    "Set auth-calls to true and accept-blind-auth / accept-blind-reg to false on the internal profile, and require digest authentication.");
                } else if (currentProfile === "external") {
                  add("HIGH", "External SIP profile exposure", n, key,
                    "The external SIP profile weakens authentication on the profile that faces untrusted networks.",
                    "Require authentication on the external profile and keep blind auth / blind registration acceptance off.");
                }
              }

              /* Rules 1, 4, 6, 7 — credential posture (value never used in output) */
              if (isPasswordKey(lk)) {
                if (inES && curES) curES.hasPwd = true;
                if (!isVaultRef(val)) {
                  if (isDefaultValue(val)) {
                    if (inES) {
                      add("CRITICAL", "Event socket default password", n, key,
                        "The event socket is protected by a known default event-socket password or placeholder (identified by key name and line only — the value is never shown). Anyone who can reach the port can try the well-known defaults.",
                        "Set a long, unique event-socket password, deliver it through a vault or environment reference instead of the config file, and restrict who can reach the event-socket port.");
                    } else {
                      add("CRITICAL", "Default or placeholder credential", n, key,
                        "A password-like setting uses a known default, placeholder, empty, or very short numeric value (identified by key name and line only — the value is never shown).",
                        "Replace it with a long, unique secret and reference it from a vault or environment variable instead of writing the value into the config.");
                    }
                  } else if (inES) {
                    add("HIGH", "Event socket credential in pasted config", n, key,
                      "The event socket has a password written directly in the pasted config (value never shown). Confirm it is strong, unique, and rotated — pasted configs tend to get copied and shared.",
                      "Use a long random event-socket password delivered via a vault or environment reference, and bind the socket to localhost.");
                  } else {
                    add("HIGH", "Credential present in pasted config", n, key,
                      "A credential is written directly in the pasted configuration (value never shown). Confirm it is strong, unique, and rotated — pasted configs tend to get copied and shared.",
                      "Move the secret to a vault or environment reference, and rotate it if this config has been shared.");
                  }
                }
              }

              /* Rule 8 — verbose debug logging */
              if (lk.indexOf("log") !== -1 && (lv === "debug" || lv === "9")) {
                add("MEDIUM", "Verbose debug logging", n, key,
                  "Debug-level logging is enabled. Debug logs can record call details and other sensitive data, and they add load on a production server.",
                  "Set logging back to info, notice, or warning for production.");
              }
              if (lk === "debug-presence" && lv !== "0" && lv !== "false" && lv !== "") {
                add("MEDIUM", "Verbose debug logging", n, key,
                  "Presence debugging is switched on, which floods the logs with per-device presence detail on a production server.",
                  "Turn debug-presence off for production.");
              }
            });

            /* Plain-text logging fallback, e.g. "sofia loglevel 9" */
            if (entries.length === 0 && /\blog/i.test(line) && /\b(debug|9)\b/i.test(line)) {
              add("MEDIUM", "Verbose debug logging", n, "loglevel",
                "Debug-level logging is enabled. Debug logs can record call details and other sensitive data, and they add load on a production server.",
                "Set logging back to info, notice, or warning for production.");
            }

            if (low.indexOf("</profile>") !== -1) { currentProfile = null; curBlock = null; }
            if (inES && (low.indexOf("</configuration>") !== -1 || low.indexOf("</section>") !== -1)) {
              inES = false; curES = null;
            }
          });

          /* Rule 5 — external profile without an ACL in its own block */
          profiles.forEach(function (p) {
            if (p.name === "external" && !p.hasACL) {
              add("HIGH", "External SIP profile exposure", p.start, "apply-inbound-acl (missing)",
                "The external profile has no inbound ACL applied in its block, so nothing in the pasted config limits which source networks can reach the profile that faces untrusted networks.",
                "Add an apply-inbound-acl param to the external profile pointing at a maintained ACL list.");
            }
            /* Rule 9 — no ACL anywhere in the pasted config */
            if ((p.name === "internal" || p.name === "external") && !anyACL) {
              add("MEDIUM", "SIP profile missing ACL", p.start, "apply-inbound-acl (missing)",
                "No apply-inbound-acl appears anywhere in the pasted config, so this SIP profile shows no inbound access-control list.",
                "Apply an inbound ACL (for example the domains list) on each SIP profile.");
            }
          });

          /* Rule 7 — event socket section with no password param at all */
          esSections.forEach(function (s) {
            if (!s.hasPwd) {
              add("HIGH", "Event socket has no password", s.start, "password (missing)",
                "An event socket section is present, but no password param was found in it — the control channel may accept connections without a password.",
                "Add a strong password param to the event socket settings.");
            }
          });

          var rank = { CRITICAL: 0, HIGH: 1, MEDIUM: 2 };
          findings.sort(function (a, b) {
            if (a.line !== b.line) return a.line - b.line;
            return rank[a.severity] - rank[b.severity];
          });

          var counts = { critical: 0, high: 0, medium: 0, total: findings.length };
          findings.forEach(function (f) {
            if (f.severity === "CRITICAL") counts.critical++;
            else if (f.severity === "HIGH") counts.high++;
            else if (f.severity === "MEDIUM") counts.medium++;
          });

          var verdict;
          if (counts.critical > 0) verdict = "DO NOT DEPLOY";
          else if (counts.high > 0 || counts.medium > 0) verdict = "DEPLOY WITH FIXES";
          else verdict = "SAFE TO DEPLOY";

          return { verdict: verdict, findings: findings, linesScanned: lines.length,
                   counts: counts, ungradeable: false };
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-freeswitch-server-config-safety-auditor',
  name: 'J-Dawgs FreeSWITCH Server Config Safety Auditor',
  description: 'Grades pasted FreeSWITCH XML config offline — SIP profile exposure, event-socket bind/password, default credentials by key/line only — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
