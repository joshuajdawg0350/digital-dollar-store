'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Vikunja Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Worked examples (inputs only; never rendered as output) ---------- */
      var RISKY_EXAMPLE = [
        '# Vikunja config — copied from a tutorial, about to go live',
        'service:',
        '  interface: ":3456"',
        '  publicurl: "http://tasks.example.com/"',
        '  jwtsecret: "change-me"',
        '  enableregistration: true',
        'database:',
        '  type: "postgres"',
        '  host: "db.internal"',
        '  password: "vikunja123"',
        'mailer:',
        '  enabled: true',
        '  host: "mail.example.com"',
        '  port: 25',
        '  forcessl: false',
        'log:',
        '  level: "debug"'
      ].join('\n');

      var HARDENED_EXAMPLE = [
        '# Vikunja config — hardened for production',
        'service:',
        '  interface: "127.0.0.1:3456"',
        '  publicurl: "https://tasks.example.com/"',
        '  jwtsecret: "kX9f2mQ7vR4tZ8wP1nB6sD3hJ5yU0aVcXeLgTqWo"',
        '  enableregistration: false',
        '  maxitemsperpage: 50',
        'database:',
        '  type: "postgres"',
        '  host: "db.internal"',
        '  password: "G7!vQ2#xL9pR4&zK8w"',
        'ratelimit:',
        '  enabled: true',
        '  limit: 100',
        'mailer:',
        '  enabled: true',
        '  host: "mail.example.com"',
        '  port: 465',
        '  forcessl: true',
        'log:',
        '  level: "info"'
      ].join('\n');

      var PITCHES = {
        pitchStore: "AI Tool Store — working tools built for agents and the people who run them, including the J-Dawgs Vikunja Server Config Safety Auditor™: https://muse.ai/s/ai-tool-store-xng6xkxwjkxl2xab/UoF72OkKI7j33Q2ITxmrZyIr4nv40QtYfj2AgESh_k8",
        pitchExchange: "J-Dawgs Agent Exchange — hire an agent to do the work, or list your own agent for hire: https://muse.ai/s/j-dawgs-agent-exchange-ih6xlnihzxdhxc/ZbleqxFHRE0NcswaBkyN13y9lLp5rPAgHTb6t8ii-PY",
        pitchBundle: "The Serve It, Note It, Paint It Right Stack — three J-Dawgs tools in one bundle: serve it, note it, paint it right. Get the stack at the AI Tool Store: https://muse.ai/s/ai-tool-store-xng6xkxwjkxl2xab/UoF72OkKI7j33Q2ITxmrZyIr4nv40QtYfj2AgESh_k8"
      };

      /* ---------- Parsing ---------- */
      var KNOWN_SECTIONS = {
        service:1, database:1, mailer:1, log:1, auth:1, cors:1, files:1,
        redis:1, keyvalue:1, ratelimit:1, openid:1, metrics:1, migration:1,
        avatar:1, legal:1, backgrounds:1, defaultsettings:1, webhook:1
      };

      function cleanVal(v){
        v = (v == null ? "" : String(v)).trim();
        if (v.length >= 2){
          var q = v.charAt(0);
          if ((q === '"' || q === "'") && v.charAt(v.length - 1) === q){
            return v.slice(1, -1);
          }
          if (q === '"' || q === "'"){
            var end = v.indexOf(q, 1);
            if (end > 0) return v.slice(1, end);
          }
        }
        var hash = v.indexOf(' #');
        if (hash >= 0) v = v.slice(0, hash).trim();
        return v;
      }

      function parseConfig(text){
        var lines = String(text).split(/\r?\n/);
        var entries = [];
        var stack = [];
        function stackPath(){ return stack.map(function(s){ return s.key; }).join('.'); }
        lines.forEach(function(raw, idx){
          var lineNo = idx + 1;
          var envM = raw.match(/^\s*-?\s*(VIKUNJA_[A-Z0-9_]+)\s*=\s*(.*)$/i);
          if (envM){
            var parts = envM[1].toUpperCase().replace(/^VIKUNJA_/, '').split('_');
            var section = parts[0].toLowerCase();
            var leaf = parts.slice(1).join('').toLowerCase();
            entries.push({
              path: leaf ? section + '.' + leaf : section,
              value: cleanVal(envM[2]),
              line: lineNo, section: false, recognized: true
            });
            return;
          }
          var m = raw.match(/^(\s*)([A-Za-z0-9_.\-]+)\s*:\s*(.*)$/);
          if (!m) return;
          var indent = m[1].replace(/\t/g, '  ').length;
          var key = m[2].toLowerCase();
          var val = m[3];
          while (stack.length && stack[stack.length - 1].indent >= indent) stack.pop();
          if (val === ''){
            stack.push({ indent: indent, key: key });
            var sp = stackPath();
            entries.push({
              path: sp, value: '', line: lineNo, section: true,
              recognized: !!KNOWN_SECTIONS[sp.split('.')[0]]
            });
          } else {
            var base = stackPath();
            var path = base ? base + '.' + key : key;
            entries.push({
              path: path, value: cleanVal(val), line: lineNo, section: false,
              recognized: !!KNOWN_SECTIONS[path.split('.')[0]]
            });
          }
        });
        return { lines: lines, entries: entries };
      }

      function getEntry(entries, path){
        var sectionEntry = null;
        for (var i = 0; i < entries.length; i++){
          if (entries[i].path === path){
            if (!entries[i].section) return entries[i];
            if (!sectionEntry) sectionEntry = entries[i];
          }
        }
        return sectionEntry;
      }
      function anyPath(entries, needle){
        return entries.some(function(e){ return e.path.indexOf(needle) >= 0; });
      }
      function isTrue(v){
        v = String(v).toLowerCase();
        return v === 'true' || v === 'yes' || v === 'on' || v === '1';
      }
      function isEnvRef(v){ return typeof v === 'string' && v.charAt(0) === '$'; }

      /* ---------- Audit ---------- */
      var SEV_RANK = { BLOCKER: 0, HIGH: 1, WARNING: 2, INFO: 3 };

      function audit(text){
        var parsed = parseConfig(text);
        var entries = parsed.entries;
        var recognizedCount = entries.filter(function(e){ return e.recognized; }).length;
        var findings = [];
        function add(sev, entry, key, msg, fix){
          findings.push({
            severity: sev,
            line: entry ? entry.line : null,
            key: key,
            finding: msg,
            fix: fix
          });
        }

        if (recognizedCount === 0){
          return {
            verdict: 'NOT ENOUGH TO GRADE',
            lineCount: parsed.lines.length,
            keyCount: 0,
            findings: []
          };
        }

        /* JWT secret — value never rendered, length only */
        var jwt = getEntry(entries, 'service.jwtsecret');
        if (!jwt || jwt.value === ''){
          add('BLOCKER', jwt, 'service.jwtsecret',
            'JWT secret is not set. Vikunja cannot sign login tokens safely without one.',
            'Set a long random JWT secret (32+ characters) and keep it out of version control.');
        } else if (!isEnvRef(jwt.value)){
          var low = jwt.value.toLowerCase();
          var isPlaceholder =
            low.indexOf('change-me') >= 0 || low.indexOf('changeme') >= 0 ||
            low.indexOf('change_me') >= 0 || low === 'secret' ||
            low.indexOf('example') >= 0 || low.indexOf('please-change') >= 0 ||
            low.indexOf('your-secret') >= 0;
          if (isPlaceholder){
            add('BLOCKER', jwt, 'service.jwtsecret',
              'JWT secret matches a well-known placeholder value (' + jwt.value.length + ' characters). Anyone who has seen the tutorial it came from can forge login tokens.',
              'Replace it with a freshly generated random secret of 32+ characters.');
          } else if (jwt.value.length < 32){
            add('HIGH', jwt, 'service.jwtsecret',
              'JWT secret is short: ' + jwt.value.length + ' characters (minimum 32). Short secrets can be brute-forced.',
              'Generate a random secret of at least 32 characters.');
          }
        }

        /* Interface binding */
        var iface = getEntry(entries, 'service.interface');
        if (iface && iface.value !== '' && !isEnvRef(iface.value)){
          var host = iface.value.split(':')[0];
          if (host === '0.0.0.0' || host === '' || host === '::' || host === '*'){
            add('HIGH', iface, 'service.interface',
              'Interface "' + iface.value + '" binds Vikunja to all network interfaces, so it answers on every network the machine touches — including the public internet if nothing else blocks it.',
              'Bind to 127.0.0.1 (e.g. "127.0.0.1:3456") and let your reverse proxy face the internet, or firewall the port.');
          }
        }

        /* Public URL */
        var pu = getEntry(entries, 'service.publicurl');
        if (pu && pu.value !== '' && /^http:\/\//i.test(pu.value)){
          add('HIGH', pu, 'service.publicurl',
            'Public URL "' + pu.value + '" uses http:// instead of https://. Links, invites, and password resets will point at an unencrypted address.',
            'Serve Vikunja over HTTPS and set publicurl to the https:// address.');
        }

        /* Open registration */
        var er = getEntry(entries, 'service.enableregistration');
        if (er && isTrue(er.value)){
          add('HIGH', er, 'service.enableregistration',
            'Public registration is enabled (enableregistration: true). Anyone on the internet can create an account on your server.',
            'Set enableregistration to false once your users exist, or put the instance behind a restricted network.');
        }

        /* Database password — value never rendered, length only */
        var dbType = getEntry(entries, 'database.type');
        var isSqlite = dbType && /sqlite/i.test(dbType.value);
        if (!isSqlite){
          var dbp = getEntry(entries, 'database.password');
          var dbSection = getEntry(entries, 'database');
          if (dbSection && (!dbp || dbp.value === '')){
            add('WARNING', dbp || dbSection, 'database.password',
              'No database password is set for a non-SQLite database.',
              'Set a strong database password, or supply it through your secret manager / environment.');
          } else if (dbp && dbp.value !== '' && !isEnvRef(dbp.value) && dbp.value.length < 12){
            add('BLOCKER', dbp, 'database.password',
              'Plaintext database password is short: ' + dbp.value.length + ' characters. A password this short, sitting in a plain config file, is the first thing an attacker tries.',
              'Rotate it now: use a generated password of 16+ characters and supply it via environment or secret file, not the config.');
          }
        }

        /* Log level */
        var ll = getEntry(entries, 'log.level');
        if (ll && String(ll.value).toLowerCase() === 'debug'){
          add('WARNING', ll, 'log.level',
            'Log level is set to debug. Debug logs are noisy and can record request details and tokens you do not want on disk.',
            'Run production at info level (or warn); raise to debug only while troubleshooting.');
        }

        /* Mailer TLS */
        if (anyPath(entries, 'mailer.')){
          var fs = getEntry(entries, 'mailer.forcessl');
          var portE = getEntry(entries, 'mailer.port');
          var hostE = getEntry(entries, 'mailer.host');
          var portNum = portE ? parseInt(portE.value, 10) : NaN;
          var tlsOk = (fs && isTrue(fs.value)) || portNum === 465;
          if (!tlsOk){
            add('WARNING', fs || hostE, 'mailer.forcessl',
              'Mailer does not force TLS. Mail — including password-reset links — can cross the network unencrypted.',
              'Set mailer forcessl to true (or use port 465) so SMTP is always encrypted.');
          }
          var stv = getEntry(entries, 'mailer.skiptlsverify');
          if (stv && isTrue(stv.value)){
            add('WARNING', stv, 'mailer.skiptlsverify',
              'Mailer skips TLS certificate verification, so a man-in-the-middle can intercept mail traffic.',
              'Set skiptlsverify to false and fix the certificate problem instead.');
          }
        }

        /* Defaults noted as INFO */
        if (!anyPath(entries, 'ratelimit')){
          add('INFO', null, 'ratelimit',
            'No rate-limit settings found — Vikunja built-in defaults apply.',
            'Optional: set explicit rate limits sized for your instance.');
        }
        if (!anyPath(entries, 'maxitems')){
          add('INFO', null, 'service.maxitemsperpage',
            'No max-items-per-page setting found — the built-in default applies.',
            'Optional: set service.maxitemsperpage explicitly so the limit is a decision, not a surprise.');
        }

        findings.sort(function(a, b){
          var r = SEV_RANK[a.severity] - SEV_RANK[b.severity];
          if (r !== 0) return r;
          return (a.line || 99999) - (b.line || 99999);
        });

        var hasBlockerOrHigh = findings.some(function(f){ return f.severity === 'BLOCKER' || f.severity === 'HIGH'; });
        var hasWarning = findings.some(function(f){ return f.severity === 'WARNING'; });
        var verdict = hasBlockerOrHigh ? 'DO NOT DEPLOY' : (hasWarning ? 'DEPLOY WITH FIXES' : 'SAFE TO DEPLOY');
        return {
          verdict: verdict,
          lineCount: parsed.lines.length,
          keyCount: recognizedCount,
          findings: findings
        };
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-vikunja-server-config-safety-auditortm',
  name: 'J-Dawgs Vikunja Server Config Safety Auditor',
  description: 'Host tools only tell you the server started; ours grades a pasted Vikunja config offline into one deploy verdict — secrets by key name/line/length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
