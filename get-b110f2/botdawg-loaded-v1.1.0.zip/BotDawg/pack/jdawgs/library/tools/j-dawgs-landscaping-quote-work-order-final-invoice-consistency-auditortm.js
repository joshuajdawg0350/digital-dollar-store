'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Landscaping Quote, Work Order & Final Invoice Consistency Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

/* ---------- Examples (every figure independently recomputed) ----------
   CONSISTENT:
     Mowing 85 x 8 = 680.00 ; Mulch 10 x 45 = 450.00 ; Subtotal 680+450 = 1,130.00
     Tax 6% of 1,130.00 = 67.80 ; Total 1,130.00 + 67.80 = 1,197.80
     Deposit 300.00 credited ; Balance 1,197.80 - 300.00 = 897.80  => SAFE TO PAY
   INCONSISTENT:
     Quote:  Mowing 75 x 12 = 900.00 ; Mulch 8 x 50 = 400.00 ; Subtotal 1,300.00
             Tax 6% of 1,300.00 = 78.00 ; Total 1,378.00 ; Deposit 250.00
     Invoice: Mowing 90 x 14 = 1,260.00 ; Mulch 400.00 ; Fuel 45.00 ; Disposal 60.00
             Subtotal 1,260+400+45+60 = 1,765.00 ; Tax 6% = 105.90 ; Total 1,870.90
             Total over quote: 1,870.90 - 1,378.00 = 492.90 ; Deposit NOT credited
             Balance if credited: 1,870.90 - 250.00 = 1,620.90  => DO NOT PAY YET
------------------------------------------------------------------------ */
var EXAMPLE_GOOD = {
quote:
"QUOTE #Q-1042 \u2014 GreenScape Landscaping\n" +
"Date: October 12, 2026\n" +
"Customer: Maple Street HOA\n" +
"\n" +
"Services:\n" +
"- Lawn mowing \u2014 $85 per visit x 8 visits = $680.00\n" +
"- Mulch \u2014 10 yards x $45 per yard = $450.00\n" +
"\n" +
"Frequency: weekly, 8 visits\n" +
"Subtotal: $1,130.00\n" +
"Tax (6%): $67.80\n" +
"Total: $1,197.80\n" +
"Deposit / Prepayment: $300.00 paid October 12, 2026\n" +
"Balance due after deposit: $897.80",
workorder:
"WORK ORDER #WO-1042 \u2014 GreenScape Landscaping\n" +
"Date: November 2, 2026\n" +
"Customer: Maple Street HOA\n" +
"\n" +
"Services completed:\n" +
"- Lawn mowing \u2014 $85 per visit x 8 visits = $680.00\n" +
"- Mulch \u2014 10 yards x $45 per yard = $450.00\n" +
"\n" +
"Visits completed: 8 visits\n" +
"Frequency: weekly\n" +
"Prepayment received: $300.00",
invoice:
"FINAL INVOICE #INV-1042 \u2014 GreenScape Landscaping\n" +
"Date: November 3, 2026\n" +
"Customer: Maple Street HOA\n" +
"\n" +
"- Lawn mowing \u2014 $85 per visit x 8 visits = $680.00\n" +
"- Mulch \u2014 10 yards x $45 per yard = $450.00\n" +
"\n" +
"Subtotal: $1,130.00\n" +
"Tax (6%): $67.80\n" +
"Total: $1,197.80\n" +
"Less prepayment credited: -$300.00\n" +
"Balance due: $897.80"
};

var EXAMPLE_BAD = {
quote:
"QUOTE #Q-2091 \u2014 GreenScape Landscaping\n" +
"Date: October 5, 2026\n" +
"Customer: Johnson Residence\n" +
"\n" +
"Services:\n" +
"- Lawn mowing \u2014 $75 per visit x 12 visits = $900.00\n" +
"- Mulch \u2014 8 yards x $50 per yard = $400.00\n" +
"\n" +
"Frequency: weekly, 12 visits\n" +
"Subtotal: $1,300.00\n" +
"Tax (6%): $78.00\n" +
"Total: $1,378.00\n" +
"Deposit / Prepayment: $250.00 paid October 5, 2026",
workorder:
"WORK ORDER #WO-2091 \u2014 GreenScape Landscaping\n" +
"Date: November 1, 2026\n" +
"Customer: Johnson Residence\n" +
"\n" +
"Services completed:\n" +
"- Lawn mowing \u2014 $90 per visit x 14 visits = $1,260.00\n" +
"- Mulch \u2014 8 yards x $50 per yard = $400.00\n" +
"\n" +
"Visits completed: 14 visits\n" +
"Frequency: weekly\n" +
"Prepayment received: $250.00",
invoice:
"FINAL INVOICE #INV-2091 \u2014 GreenScape Landscaping\n" +
"Date: November 2, 2026\n" +
"Customer: Johnson Residence\n" +
"\n" +
"- Lawn mowing \u2014 $90 per visit x 14 visits = $1,260.00\n" +
"- Mulch \u2014 8 yards x $50 per yard = $400.00\n" +
"- Fuel surcharge: $45.00\n" +
"- Disposal fee: $60.00\n" +
"\n" +
"Subtotal: $1,765.00\n" +
"Tax (6%): $105.90\n" +
"Total: $1,870.90\n" +
"Balance due: $1,870.90"
};

var WORKED_TEXT =
"=== QUOTE ===\n" + EXAMPLE_BAD.quote + "\n\n" +
"=== WORK ORDER ===\n" + EXAMPLE_BAD.workorder + "\n\n" +
"=== FINAL INVOICE ===\n" + EXAMPLE_BAD.invoice + "\n\n" +
"EXPECTED VERDICT: DO NOT PAY YET\n" +
"- Invoice total $1,870.90 \u2212 Quote total $1,378.00 = $492.90 over the quote.\n" +
"- PREPAYMENT NOT CREDITED: $250.00 deposit stated on the quote and work order appears nowhere as a credit on the invoice. Balance due $1,870.90 \u2212 $250.00 owed credit = $1,620.90 is the balance if the deposit is applied.\n" +
"- INVOICE-ONLY FEE: Fuel surcharge $45.00 (also Disposal fee $60.00) \u2014 on the invoice only; fees total $45.00 + $60.00 = $105.00.\n" +
"- Rate and count both moved: $75 per visit on the quote \u2192 $90 per visit billed = $15.00 more per visit; 12 visits quoted \u2192 14 visits billed = 2 extra visits.";

/* ---------- Parsing helpers ---------- */
function $(id){ return document.getElementById(id); }
function lines(text){ return String(text||"").split(/\r?\n/); }
function moneyNums(str){
  var out=[], m, re=/\$?\s?\d{1,3}(?:,\d{3})*\.\d{2}|\$\s?\d[\d,]*/g;
  while((m=re.exec(str))!==null){ var v=parseFloat(m[0].replace(/[$,\s]/g,"")); if(!isNaN(v)) out.push(v); }
  return out;
}
function lastMoney(str){ var a=moneyNums(str); return a.length?a[a.length-1]:null; }
function fmt(n){ if(n===null||n===undefined||isNaN(n)) return "not stated"; var s=Math.abs(n).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g,","); return (n<0?"-$":"$")+s; }
function round2(n){ return Math.round(n*100)/100; }
function near(a,b){ return Math.abs(a-b)<=0.02; }

function extractTotal(text){
  var ls=lines(text), found=null;
  for(var i=0;i<ls.length;i++){ var L=ls[i];
    if(/\btotal\b/i.test(L) && !/subtotal/i.test(L)){ var v=lastMoney(L); if(v!==null) found=v; } }
  return found;
}
function extractSubtotal(text){
  var ls=lines(text), found=null;
  for(var i=0;i<ls.length;i++){ if(/subtotal/i.test(ls[i])){ var v=lastMoney(ls[i]); if(v!==null) found=v; } }
  return found;
}
function extractTax(text){
  var ls=lines(text), rate=null, amount=null;
  for(var i=0;i<ls.length;i++){ var L=ls[i];
    if(/tax/i.test(L)){ var rm=L.match(/(\d+(?:\.\d+)?)\s*%/); if(rm) rate=parseFloat(rm[1]);
      var v=lastMoney(L); if(v!==null) amount=v; } }
  return {rate:rate, amount:amount};
}
function extractDeposit(text){
  var ls=lines(text), found=null;
  for(var i=0;i<ls.length;i++){ var L=ls[i];
    if(/(deposit|prepayment|prepaid)/i.test(L) && !/balance/i.test(L) && !/credited/i.test(L)){
      var v=lastMoney(L); if(v!==null) found=v; } }
  return found;
}
function extractCredited(text){
  var ls=lines(text), found=null;
  for(var i=0;i<ls.length;i++){ var L=ls[i];
    if(/(prepayment|deposit|prepaid|credit)/i.test(L) && /(credit|less|applied|received|-)/i.test(L)){
      var v=lastMoney(L); if(v!==null) found=Math.abs(v); } }
  return found;
}
function extractBalance(text){
  var ls=lines(text), found=null;
  for(var i=0;i<ls.length;i++){ var L=ls[i];
    if(/(balance due|amount due|balance:)/i.test(L)){ var v=lastMoney(L); if(v!==null) found=v; } }
  return found;
}
function extractVisits(text){
  var counts={}, m, re=/(\d+(?:\.\d+)?)\s*visits?\b/gi, best=null, bestN=0;
  while((m=re.exec(text))!==null){ var v=parseFloat(m[1]); counts[v]=(counts[v]||0)+1;
    if(counts[v]>bestN){ bestN=counts[v]; best=v; } }
  return best;
}
function extractFrequency(text){
  var t=String(text||"").toLowerCase();
  if(t.indexOf("twice a week")>=0||t.indexOf("twice weekly")>=0) return "twice weekly";
  if(t.indexOf("bi-weekly")>=0||t.indexOf("biweekly")>=0||t.indexOf("every two weeks")>=0||t.indexOf("every 2 weeks")>=0) return "every two weeks";
  if(t.indexOf("weekly")>=0||t.indexOf("every week")>=0) return "weekly";
  if(t.indexOf("twice a month")>=0||t.indexOf("twice monthly")>=0) return "twice monthly";
  if(t.indexOf("monthly")>=0||t.indexOf("every month")>=0) return "monthly";
  return null;
}

var SERVICE_MAP=[
  ["Lawn mowing",["lawn mowing","mowing"]],
  ["Mulch",["mulch"]],
  ["Leaf removal",["leaf removal","leaf clean"]],
  ["Hedge / shrub trimming",["hedge","shrub trim","bush trim"]],
  ["Fertilization",["fertil"]],
  ["Aeration",["aerat"]],
  ["Seeding",["seeding","overseed"]],
  ["Weeding / weed control",["weeding","weed control"]],
  ["Pruning",["prun"]],
  ["Edging",["edging"]],
  ["Tree work",["tree trim","tree removal","tree service"]],
  ["Sod / turf",["sod"]]
];
function serviceKeyFor(labelLower){
  for(var i=0;i<SERVICE_MAP.length;i++){ var kws=SERVICE_MAP[i][1];
    for(var j=0;j<kws.length;j++){ if(labelLower.indexOf(kws[j])>=0) return SERVICE_MAP[i][0]; } }
  return null;
}
function extractServices(text){
  var t=String(text||"").toLowerCase(), out=[];
  for(var i=0;i<SERVICE_MAP.length;i++){ var kws=SERVICE_MAP[i][1];
    for(var j=0;j<kws.length;j++){ if(t.indexOf(kws[j])>=0){ out.push(SERVICE_MAP[i][0]); break; } } }
  return out;
}
var FEE_MAP=[
  ["Fuel surcharge",["fuel"]],
  ["Disposal fee",["disposal"]],
  ["Trip fee",["trip fee","trip charge","travel fee","travel charge"]],
  ["Service-call fee",["service call","service-call","servicecall"]],
  ["Delivery fee",["delivery fee","delivery charge"]],
  ["Environmental fee",["environmental"]]
];
function extractFees(text){
  var ls=lines(text), out=[];
  for(var i=0;i<ls.length;i++){ var L=ls[i], low=L.toLowerCase();
    if(!/(fee|surcharge|charge)/i.test(L)) continue;
    var v=lastMoney(L); if(v===null) continue;
    for(var j=0;j<FEE_MAP.length;j++){ var kws=FEE_MAP[j][1], hit=false;
      for(var k=0;k<kws.length;k++){ if(low.indexOf(kws[k])>=0){ hit=true; break; } }
      if(hit){ out.push({name:FEE_MAP[j][0], amount:v, line:L.trim()}); break; } } }
  return out;
}
function extractLineItems(text){
  var ls=lines(text), out=[];
  for(var i=0;i<ls.length;i++){ var L=ls[i];
    if(!/[x\u00D7]/i.test(L) || L.indexOf("=")<0) continue;
    var rate=null, qty=null;
    var mA=L.match(/\$\s?([\d,]+(?:\.\d+)?)\s*(?:per\s+[a-z]+)?\s*[x\u00D7]\s*(\d+(?:\.\d+)?)/i);
    var mB=L.match(/(\d+(?:\.\d+)?)\s*(?:yards?|bags?|units?|loads?|sq\.?\s*ft\.?)?\s*[x\u00D7]\s*\$\s?([\d,]+(?:\.\d+)?)/i);
    if(mA){ rate=parseFloat(mA[1].replace(/,/g,"")); qty=parseFloat(mA[2]); }
    else if(mB){ qty=parseFloat(mB[1]); rate=parseFloat(mB[2].replace(/,/g,"")); }
    else continue;
    var eq=L.slice(L.indexOf("=")+1); var stated=lastMoney(eq);
    if(stated===null||rate===null||qty===null) continue;
    var rawLabel=L.replace(/^[\s\-\u2022\*]+/,"");
    var parts=rawLabel.split(/[\u2014\u2013]/); var label=(parts[0]||rawLabel).replace(/:$/,"").trim();
    if(!label) label="Line item";
    var key=serviceKeyFor(label.toLowerCase())||label;
    out.push({label:label, key:key, rate:rate, qty:qty, stated:stated, computed:round2(rate*qty)});
  }
  return out;
}
function parseDoc(text){
  return {
    present: String(text||"").trim().length>0,
    total: extractTotal(text), subtotal: extractSubtotal(text),
    tax: extractTax(text), deposit: extractDeposit(text),
    credited: extractCredited(text), balance: extractBalance(text),
    visits: extractVisits(text), frequency: extractFrequency(text),
    services: extractServices(text), fees: extractFees(text),
    items: extractLineItems(text)
  };
}

/* ---------- Audit ---------- */
function audit(qText,wText,iText){
  var Q=parseDoc(qText), W=parseDoc(wText), I=parseDoc(iText);
  var docs=[["Quote",Q],["Work Order",W],["Final Invoice",I]];
  var presentCount=docs.filter(function(d){return d[1].present;}).length;
  var missing=docs.filter(function(d){return !d[1].present;}).map(function(d){return d[0];});
  var findings=[], passed=[];
  function crit(title,detail){ findings.push({severity:"critical",title:title,detail:detail}); }
  function warn(title,detail){ findings.push({severity:"warning",title:title,detail:detail}); }
  function ok(title,detail){ passed.push({title:title,detail:detail}); }

  var result={ verdict:"NOT ENOUGH TO COMPARE", presentCount:presentCount, missing:missing,
    figures:{}, findings:findings, passed:passed };

  if(presentCount<=1){
    crit("NOT ENOUGH TO COMPARE",
      presentCount===0 ? "No documents were pasted. Paste at least the quote and the final invoice \u2014 all three documents for a full audit."
                       : "Only one document was pasted ("+docs.filter(function(d){return d[1].present;})[0][0]+"). A consistency audit needs at least two documents to compare; all three \u2014 quote, work order, and final invoice \u2014 for a verdict you can pay on.");
    result.verdict="NOT ENOUGH TO COMPARE";
    fillFigures(result,Q,W,I);
    return result;
  }

  if(missing.length===1){
    warn("MISSING DOCUMENT: "+missing[0],
      "No "+missing[0].toLowerCase()+" was pasted, so checks that need it could not run. With only two documents the verdict is capped at PAY WITH FIXES, even if everything pasted agrees.");
  }

  /* Totals: quote vs invoice */
  if(Q.total!==null && I.total!==null){
    var diff=round2(I.total-Q.total);
    if(near(diff,0)){ ok("Totals match","Invoice total "+fmt(I.total)+" \u2212 Quote total "+fmt(Q.total)+" = $0.00. The invoice total equals the approved quote total."); }
    else if(diff>0){
      var d="Invoice total "+fmt(I.total)+" \u2212 Quote total "+fmt(Q.total)+" = "+fmt(diff)+" over the quote.";
      if(diff>=50) crit("INVOICE TOTAL OVER QUOTE", d+" That is "+fmt(diff)+" more than the approved price, before any credit is applied.");
      else warn("Invoice total over quote", d);
    } else {
      ok("Invoice total under quote","Invoice total "+fmt(I.total)+" \u2212 Quote total "+fmt(Q.total)+" = \u2212"+fmt(Math.abs(diff))+". The invoice total is "+fmt(Math.abs(diff))+" below the quote total.");
    }
  } else if(Q.present && I.present){
    warn("Totals could not be compared","A total was "+(Q.total===null?"not stated on the quote":"not stated on the invoice")+", so the quote-vs-invoice total check could not run. No figure was invented to fill the gap.");
  }

  /* Per-doc internal arithmetic: line items, subtotal, tax, total */
  var docList=[["quote",Q],["work order",W],["invoice",I]];
  docList.forEach(function(pair){
    var name=pair[0], D=pair[1]; if(!D.present) return;
    D.items.forEach(function(it){
      var d=round2(it.stated-it.computed);
      var isMaterial=/mulch|material|yard|bag/i.test(it.label+" "+it.key);
      var kind=isMaterial?"Materials quantity \u00D7 unit price":"Rate \u00D7 count";
      if(near(d,0)){ ok(kind+" checks out ("+name+": "+it.label+")", fmt(it.rate)+" \u00D7 "+it.qty+" = "+fmt(it.computed)+", and the "+name+" states "+fmt(it.stated)+"."); }
      else warn(kind+" does not recompute ("+name+": "+it.label+")", fmt(it.rate)+" \u00D7 "+it.qty+" = "+fmt(it.computed)+", but the "+name+" states "+fmt(it.stated)+" \u2014 off by "+fmt(Math.abs(d))+".");
    });
    if(D.subtotal!==null && D.items.length){
      var feeSum = (name==="invoice") ? round2(D.fees.reduce(function(s,f){return s+f.amount;},0)) : 0;
      var itemSum = round2(D.items.reduce(function(s,it){return s+it.stated;},0));
      var sum = round2(itemSum+feeSum);
      var sd=round2(sum-D.subtotal);
      if(near(sd,0)){ ok("Subtotal recomputes ("+name+")","Line items "+fmt(itemSum)+(feeSum?" + fees "+fmt(feeSum):"")+" = "+fmt(sum)+", matching the stated subtotal "+fmt(D.subtotal)+"."); }
      else warn("Subtotal does not recompute ("+name+")","Line items "+fmt(itemSum)+(feeSum?" + fees "+fmt(feeSum):"")+" = "+fmt(sum)+", but the stated subtotal is "+fmt(D.subtotal)+" \u2014 off by "+fmt(Math.abs(sd))+".");
    }
    if(D.tax.rate!==null && D.tax.amount!==null && D.subtotal!==null){
      var compTax=round2(D.subtotal*D.tax.rate/100);
      var td=round2(D.tax.amount-compTax);
      if(near(td,0)){ ok("Tax recomputes ("+name+")", D.tax.rate+"% of subtotal "+fmt(D.subtotal)+" = "+fmt(compTax)+", matching the stated tax "+fmt(D.tax.amount)+"."); }
      else warn("Tax does not recompute ("+name+")", D.tax.rate+"% of subtotal "+fmt(D.subtotal)+" = "+fmt(compTax)+", but the stated tax is "+fmt(D.tax.amount)+" \u2014 off by "+fmt(Math.abs(td))+".");
    }
    if(D.subtotal!==null && D.tax.amount!==null && D.total!==null){
      var compTotal=round2(D.subtotal+D.tax.amount);
      if(near(compTotal,D.total)){ ok("Total recomputes ("+name+")","Subtotal "+fmt(D.subtotal)+" + tax "+fmt(D.tax.amount)+" = "+fmt(compTotal)+", matching the stated total "+fmt(D.total)+"."); }
      else warn("Total does not recompute ("+name+")","Subtotal "+fmt(D.subtotal)+" + tax "+fmt(D.tax.amount)+" = "+fmt(compTotal)+", but the stated total is "+fmt(D.total)+".");
    }
  });

  /* Cross-document rate and quantity comparison per service */
  function itemMap(D){ var m={}; D.items.forEach(function(it){ m[it.key]=it; }); return m; }
  var qMap=itemMap(Q), wMap=itemMap(W), iMap=itemMap(I);
  var keys={}; Object.keys(qMap).forEach(function(k){keys[k]=1;}); Object.keys(iMap).forEach(function(k){keys[k]=1;}); Object.keys(wMap).forEach(function(k){keys[k]=1;});
  Object.keys(keys).forEach(function(k){
    var q=qMap[k], w=wMap[k], iv=iMap[k];
    if(q && iv){
      if(!near(q.rate,iv.rate)){
        var rd=round2(iv.rate-q.rate);
        var perUnit = /mowing/i.test(k) ? " per visit" : " per unit";
        if(rd>0) crit("RATE INCREASED: "+k, fmt(q.rate)+perUnit+" on the quote \u2192 "+fmt(iv.rate)+perUnit+" on the invoice = "+fmt(rd)+" more"+perUnit+". At the invoice quantity of "+iv.qty+", the rate increase alone adds "+fmt(rd)+" \u00D7 "+iv.qty+" = "+fmt(round2(rd*iv.qty))+". Line totals: "+fmt(iv.stated)+" (invoice) \u2212 "+fmt(q.stated)+" (quote) = "+fmt(round2(iv.stated-q.stated))+".");
        else warn("Rate changed: "+k, fmt(q.rate)+perUnit+" on the quote \u2192 "+fmt(iv.rate)+perUnit+" on the invoice = "+fmt(Math.abs(rd))+" less"+perUnit+". Line totals: "+fmt(iv.stated)+" (invoice) \u2212 "+fmt(q.stated)+" (quote) = "+fmt(round2(iv.stated-q.stated))+".");
      }
      if(!near(q.qty,iv.qty)){
        var qd=round2(iv.qty-q.qty);
        if(qd>0) warn("Quantity grew: "+k,"Quantity "+q.qty+" on the quote \u2192 "+iv.qty+" on the invoice = "+qd+" more. Line totals: "+fmt(iv.stated)+" (invoice) \u2212 "+fmt(q.stated)+" (quote) = "+fmt(round2(iv.stated-q.stated))+".");
        else warn("Quantity shrank: "+k,"Quantity "+q.qty+" on the quote \u2192 "+iv.qty+" on the invoice = "+Math.abs(qd)+" fewer. Line totals: "+fmt(iv.stated)+" (invoice) \u2212 "+fmt(q.stated)+" (quote) = "+fmt(round2(iv.stated-q.stated))+".");
      }
      if(near(q.rate,iv.rate) && near(q.qty,iv.qty) && near(q.stated,iv.stated)){
        ok("Rate and quantity agree: "+k, fmt(q.rate)+" \u00D7 "+q.qty+" = "+fmt(q.stated)+" on both the quote and the invoice.");
      }
    }
    if(q && w && !near(q.rate,w.rate)){
      warn("Rate differs on the work order: "+k, fmt(q.rate)+" on the quote \u2192 "+fmt(w.rate)+" on the work order = "+fmt(Math.abs(round2(w.rate-q.rate)))+(w.rate>q.rate?" more":" less")+" per unit, before the invoice was even written.");
    }
  });

  /* Visit count and frequency across documents */
  var visitPairs=[["quote",Q],["work order",W],["invoice",I]].filter(function(p){return p[1].present && p[1].visits!==null;});
  if(Q.visits!==null){
    [["work order",W],["invoice",I]].forEach(function(pair){
      var D=pair[1]; if(!D.present||D.visits===null) return;
      if(!near(Q.visits,D.visits)){
        var vd=round2(D.visits-Q.visits);
        if(vd>0) crit("VISIT COUNT GREW ("+pair[0]+")","Visit count: "+Q.visits+" visits on the quote \u2192 "+D.visits+" visits on the "+pair[0]+" = "+vd+" more visits than quoted.");
        else warn("Visit count shrank ("+pair[0]+")","Visit count: "+Q.visits+" visits on the quote \u2192 "+D.visits+" visits on the "+pair[0]+" = "+Math.abs(vd)+" fewer visits than quoted.");
      }
    });
    var allSame = visitPairs.every(function(p){return near(p[1].visits,Q.visits);});
    if(allSame && visitPairs.length>1) ok("Visit count agrees","Every pasted document states "+Q.visits+" visits.");
  }
  if(Q.frequency){
    [["work order",W],["invoice",I]].forEach(function(pair){
      var D=pair[1]; if(!D.present||!D.frequency) return;
      if(D.frequency!==Q.frequency) warn("Frequency changed ("+pair[0]+")","Service frequency: \u201C"+Q.frequency+"\u201D on the quote \u2192 \u201C"+D.frequency+"\u201D on the "+pair[0]+". The schedule itself changed, not just the price.");
    });
    var fSame=[["work order",W],["invoice",I]].every(function(pair){return !pair[1].present||!pair[1].frequency||pair[1].frequency===Q.frequency;});
    if(fSame) ok("Frequency agrees","Frequency is stated as \u201C"+Q.frequency+"\u201D wherever a pasted document names it.");
  }

  /* Services: invoice-only and missing */
  if(I.present){
    var known={}; Q.services.forEach(function(s){known[s]=1;}); W.services.forEach(function(s){known[s]=1;});
    I.services.forEach(function(s){
      if(!known[s]) warn("INVOICE-ONLY service: "+s, s+" is billed on the invoice but appears in neither the quote nor the work order. It was never quoted and never recorded as done.");
    });
    var quoted={}; Q.services.forEach(function(s){quoted[s]="the quote";}); W.services.forEach(function(s){ if(!quoted[s]) quoted[s]="the work order"; });
    Object.keys(quoted).forEach(function(s){
      if(I.services.indexOf(s)<0) warn("Service missing from the invoice: "+s, s+" appears on "+quoted[s]+" but not on the invoice. Either the work was not billed, or the invoice is incomplete.");
    });
    if(Q.present && I.services.length && I.services.every(function(s){return known[s];}) && Object.keys(quoted).every(function(s){return I.services.indexOf(s)>=0;})){
      ok("Service list agrees","The services on the invoice are exactly the services on the quote / work order: "+I.services.join(", ")+".");
    }
  }

  /* Invoice-only fees */
  if(I.present && I.fees.length){
    var feeTotal=0, feeParts=[];
    I.fees.forEach(function(f){
      feeTotal=round2(feeTotal+f.amount); feeParts.push(fmt(f.amount));
      var inQuote = Q.present && extractFees(qText).some(function(x){return x.name===f.name;});
      var inWO = W.present && extractFees(wText).some(function(x){return x.name===f.name;});
      if(!inQuote && !inWO) crit("INVOICE-ONLY FEE: "+f.name, f.name+" "+fmt(f.amount)+" appears on the invoice only \u2014 it is on neither the quote nor the work order. ("+f.line+")");
      else ok("Fee was quoted: "+f.name, f.name+" "+fmt(f.amount)+" on the invoice also appears on "+(inQuote?"the quote":"the work order")+".");
    });
    if(I.fees.length>1) findings.push({severity: findings.some(function(x){return x.severity==="critical"&&x.title.indexOf("INVOICE-ONLY FEE")===0;})?"critical":"warning",
      title:"Invoice fees total", detail:"Fees on the invoice: "+feeParts.join(" + ")+" = "+fmt(feeTotal)+"."});
  }

  /* Prepayment / deposit credit check */
  var deposit = (Q.deposit!==null?Q.deposit:(W.deposit!==null?W.deposit:null));
  var depositSource = Q.deposit!==null ? "the quote" : (W.deposit!==null ? "the work order" : null);
  if(deposit!==null && deposit>0){
    if(!I.present){
      warn("Prepayment credit could not be checked","A prepayment / deposit of "+fmt(deposit)+" is stated on "+depositSource+", but no final invoice was pasted, so whether it was credited cannot be checked.");
    } else if(I.credited===null || I.credited===0){
      var balShould = I.total!==null ? round2(I.total-deposit) : null;
      crit("PREPAYMENT NOT CREDITED: "+fmt(deposit),
        "A prepayment / deposit of "+fmt(deposit)+" is stated on "+depositSource+", but no credit for it appears anywhere on the invoice."+
        (I.balance!==null && balShould!==null ? " Balance due "+fmt(I.balance)+" \u2212 "+fmt(deposit)+" owed credit = "+fmt(balShould)+" is the balance if the deposit is applied." :
         (balShould!==null ? " Invoice total "+fmt(I.total)+" \u2212 "+fmt(deposit)+" owed credit = "+fmt(balShould)+" is what would be owed if the deposit is applied." : "")));
    } else if(near(I.credited,deposit)){
      ok("Prepayment credited","Deposit / prepayment "+fmt(deposit)+" stated on "+depositSource+" \u2212 "+fmt(I.credited)+" credited on the invoice = $0.00 outstanding. The prepayment was credited in full.");
    } else {
      var rem=round2(deposit-I.credited);
      if(rem>0) warn("Prepayment only partly credited","Deposit / prepayment "+fmt(deposit)+" \u2212 "+fmt(I.credited)+" credited on the invoice = "+fmt(rem)+" still not credited.");
      else warn("Credit exceeds the stated deposit","Credited on the invoice "+fmt(I.credited)+" \u2212 deposit stated "+fmt(deposit)+" = "+fmt(round2(I.credited-deposit))+" more credited than the deposit on record.");
    }
  }

  /* Balance due recompute on the invoice */
  if(I.present && I.total!==null && I.balance!==null){
    var creditedAmt = I.credited||0;
    var expectedBal = round2(I.total-creditedAmt);
    if(near(expectedBal,I.balance)){
      ok("Balance due recomputes","Invoice total "+fmt(I.total)+(creditedAmt?" \u2212 prepayment credited "+fmt(creditedAmt):" \u2212 $0.00 credited")+" = "+fmt(expectedBal)+", matching the stated balance due "+fmt(I.balance)+".");
    } else {
      warn("Balance due does not recompute","Invoice total "+fmt(I.total)+" \u2212 prepayment credited "+fmt(creditedAmt)+" = "+fmt(expectedBal)+" expected balance, but the invoice states balance due "+fmt(I.balance)+" \u2014 off by "+fmt(Math.abs(round2(I.balance-expectedBal)))+".");
    }
  }

  /* Verdict */
  var hasCrit=findings.some(function(f){return f.severity==="critical";});
  var hasWarn=findings.some(function(f){return f.severity==="warning";});
  if(hasCrit) result.verdict="DO NOT PAY YET";
  else if(hasWarn) result.verdict="PAY WITH FIXES";
  else result.verdict="SAFE TO PAY";
  if(presentCount===2 && result.verdict==="SAFE TO PAY") result.verdict="PAY WITH FIXES";

  fillFigures(result,Q,W,I);
  return result;
}
function fillFigures(r,Q,W,I){
  var deposit=(Q.deposit!==null?Q.deposit:(W.deposit!==null?W.deposit:null));
  r.figures={
    quoteTotal:Q.total, workOrderTotal:W.total, invoiceTotal:I.total,
    totalDifference:(Q.total!==null&&I.total!==null)?round2(I.total-Q.total):null,
    quoteSubtotal:Q.subtotal, invoiceSubtotal:I.subtotal,
    depositStated:deposit, creditedOnInvoice:I.credited,
    uncredited:(deposit!==null)?round2(deposit-(I.credited||0)):null,
    invoiceBalanceDue:I.balance,
    expectedBalance:(I.total!==null)?round2(I.total-(I.credited||0)):null,
    invoiceFeesTotal:I.fees.length?round2(I.fees.reduce(function(s,f){return s+f.amount;},0)):null,
    quoteVisits:Q.visits, workOrderVisits:W.visits, invoiceVisits:I.visits
  };
}

/* ---------- Rendering ---------- */
var lastResult=null, lastJSON="";

function verdictClass(v){
  return v==="SAFE TO PAY"?"safe":v==="PAY WITH FIXES"?"fixes":v==="DO NOT PAY YET"?"donot":"notenough";
}
function verdictWhy(r){
  if(r.verdict==="SAFE TO PAY") return "All three documents agree on every figure that could be recomputed from the pastes. Nothing over, nothing missing, the prepayment is credited, and the balance due recomputes.";
  if(r.verdict==="PAY WITH FIXES") return r.missing.length? "The pasted documents were compared, but the "+r.missing.join(", ")+" is missing, so the verdict is capped at PAY WITH FIXES. Fix the findings below \u2014 and get the missing document \u2014 before paying in full."
    : "The documents mostly agree, but the findings below need fixing or explaining before you pay in full.";
  if(r.verdict==="DO NOT PAY YET") return "Serious mismatches between the quote, the work order, and the invoice \u2014 starting with the headline findings below. Do not pay until the invoice is corrected and re-issued.";
  return "At least two of the three documents are needed before anything can be compared.";
}
function esc(s){ return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"); }

function render(r){
  lastResult=r;
  var box=$("verdict-box"); box.className="verdict "+verdictClass(r.verdict);
  $("verdict-label").textContent=r.verdict;
  $("verdict-why").textContent=verdictWhy(r);
  var F=r.figures, rows=[];
  function row(label,amount,how){ rows.push("<tr><td>"+esc(label)+"</td><td class=\"money\">"+esc(amount)+"</td><td>"+esc(how)+"</td></tr>"); }
  row("Quote total", fmt(F.quoteTotal), "As stated on the quote paste");
  row("Invoice total", fmt(F.invoiceTotal), "As stated on the invoice paste");
  if(F.totalDifference!==null) row("Difference (invoice \u2212 quote)", fmt(F.totalDifference), fmt(F.invoiceTotal)+" \u2212 "+fmt(F.quoteTotal)+" = "+fmt(F.totalDifference)+(F.totalDifference>0?" over":F.totalDifference<0?" under":" \u2014 match"));
  else row("Difference (invoice \u2212 quote)","not computable","A total is missing from one of the pastes");
  row("Deposit / prepayment stated", fmt(F.depositStated), "Stated on the quote or work order");
  row("Credited on invoice", fmt(F.creditedOnInvoice), "Credit line found on the invoice paste");
  if(F.depositStated!==null) row("Prepayment still uncredited", fmt(F.uncredited), fmt(F.depositStated)+" \u2212 "+fmt(F.creditedOnInvoice||0)+" credited = "+fmt(F.uncredited));
  row("Invoice balance due (stated)", fmt(F.invoiceBalanceDue), "As stated on the invoice paste");
  if(F.expectedBalance!==null) row("Balance due (recomputed)", fmt(F.expectedBalance), fmt(F.invoiceTotal)+" \u2212 "+fmt(F.creditedOnInvoice||0)+" credited = "+fmt(F.expectedBalance));
  if(F.invoiceFeesTotal!==null) row("Fees on the invoice", fmt(F.invoiceFeesTotal), "Sum of fee lines found on the invoice paste");
  if(F.quoteVisits!==null||F.invoiceVisits!==null) row("Visit count (quote \u2192 invoice)", (F.quoteVisits===null?"not stated":F.quoteVisits)+" \u2192 "+(F.invoiceVisits===null?"not stated":F.invoiceVisits), "Visit counts as stated in the pastes");
  $("figures-body").innerHTML=rows.join("");

  var fh=$("findings");
  if(!r.findings.length){ fh.innerHTML="<p class=\"small\">No discrepancies found in the pasted figures.</p>"; }
  else fh.innerHTML=r.findings.map(function(f){
    return "<div class=\"finding "+f.severity+"\"><span class=\"badge "+f.severity+"\">"+(f.severity==="critical"?"Headline":"Fix")+"</span><span class=\"ft\">"+esc(f.title)+"</span><div class=\"fd\">"+esc(f.detail)+"</div></div>";
  }).join("");
  var ph=$("passed");
  ph.innerHTML=r.passed.length? r.passed.map(function(p){ return "<li><strong>"+esc(p.title)+".</strong> "+esc(p.detail)+"</li>"; }).join("") : "<li class=\"small\">No checks passed \u2014 see the findings.</li>";

  /* Text report */
  var L=[];
  L.push("J-DAWGS LANDSCAPING QUOTE, WORK ORDER & FINAL INVOICE CONSISTENCY AUDIT");
  L.push("Verdict: "+r.verdict);
  L.push("Documents pasted: "+r.presentCount+" of 3"+(r.missing.length?" \u2014 missing: "+r.missing.join(", "):""));
  L.push("");
  L.push("KEY FIGURES (recomputed from the pastes)");
  L.push("Quote total: "+fmt(F.quoteTotal));
  L.push("Invoice total: "+fmt(F.invoiceTotal));
  if(F.totalDifference!==null) L.push("Difference: "+fmt(F.invoiceTotal)+" - "+fmt(F.quoteTotal)+" = "+fmt(F.totalDifference));
  L.push("Deposit / prepayment stated: "+fmt(F.depositStated));
  L.push("Credited on invoice: "+fmt(F.creditedOnInvoice));
  if(F.expectedBalance!==null) L.push("Balance due recomputed: "+fmt(F.invoiceTotal)+" - "+fmt(F.creditedOnInvoice||0)+" credited = "+fmt(F.expectedBalance)+" (invoice states: "+fmt(F.invoiceBalanceDue)+")");
  L.push("");
  L.push("FINDINGS");
  if(!r.findings.length) L.push("- None. Every recomputed figure agrees.");
  r.findings.forEach(function(f){ L.push("- ["+f.severity.toUpperCase()+"] "+f.title+": "+f.detail); });
  L.push("");
  L.push("CHECKS THAT PASSED");
  if(!r.passed.length) L.push("- None.");
  r.passed.forEach(function(p){ L.push("- "+p.title+": "+p.detail); });
  L.push("");
  L.push("Scope: this audit compares only what the pasted text states. It does not judge whether the work was done well and does not verify the business exists.");
  $("report-text").textContent=L.join("\n");

  lastJSON=JSON.stringify({
    tool:"J-Dawgs Landscaping Quote, Work Order & Final Invoice Consistency Auditor",
    verdict:r.verdict,
    documentsPasted:r.presentCount, missingDocuments:r.missing,
    figures:{
      quoteTotal:F.quoteTotal, invoiceTotal:F.invoiceTotal, totalDifference:F.totalDifference,
      depositStated:F.depositStated, creditedOnInvoice:F.creditedOnInvoice, uncredited:F.uncredited,
      invoiceBalanceDueStated:F.invoiceBalanceDue, balanceDueRecomputed:F.expectedBalance,
      invoiceFeesTotal:F.invoiceFeesTotal,
      visits:{quote:F.quoteVisits, workOrder:F.workOrderVisits, invoice:F.invoiceVisits}
    },
    findings:r.findings, checksPassed:r.passed
  },null,2);
}

function runAudit(){
  var r=audit($("doc-quote").value,$("doc-workorder").value,$("doc-invoice").value);
  render(r);
  $("run-status").textContent="Audit complete \u2014 verdict: "+r.verdict+".";
}
function loadExample(ex){
  $("doc-quote").value=ex.quote; $("doc-workorder").value=ex.workorder; $("doc-invoice").value=ex.invoice;
  runAudit();
}
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_GOOD": (typeof EXAMPLE_GOOD !== 'undefined' ? EXAMPLE_GOOD : undefined), "EXAMPLE_BAD": (typeof EXAMPLE_BAD !== 'undefined' ? EXAMPLE_BAD : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-landscaping-quote-work-order-final-invoice-consistency-auditortm',
  name: 'J-Dawgs Landscaping Quote, Work Order & Final Invoice Consistency Auditor',
  description: 'Quoting and invoicing tools each grade their own document alone; ours cross-checks the quote, the work order, and the final invoice against each other — totals, rate × visits, prepayment credit, invoice-only fees — with the arithmetic shown, into one pay verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_GOOD": __core["EXAMPLE_GOOD"], "EXAMPLE_BAD": __core["EXAMPLE_BAD"] }
};
