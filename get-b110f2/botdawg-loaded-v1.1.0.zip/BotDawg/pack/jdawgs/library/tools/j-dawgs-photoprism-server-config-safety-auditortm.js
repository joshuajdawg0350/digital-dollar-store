'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs PhotoPrism Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------------- Examples ---------------- */

      var RISKY_EXAMPLE = [
        "PHOTOPRISM_AUTH_MODE=public",
        "PHOTOPRISM_ADMIN_PASSWORD=photoprism",
        "PHOTOPRISM_SITE_URL=http://photos.example.internal",
        "PHOTOPRISM_HTTP_HOST=0.0.0.0",
        "PHOTOPRISM_DATABASE_PASSWORD=db-s3cret-planted-991",
        "PHOTOPRISM_DISABLE_TLS=true",
        "PHOTOPRISM_DEBUG=true"
      ].join("\n");

      var HARDENED_EXAMPLE = [
        "PHOTOPRISM_AUTH_MODE=password",
        "PHOTOPRISM_ADMIN_PASSWORD=${PHOTOPRISM_ADMIN_PASSWORD}",
        "PHOTOPRISM_SITE_URL=https://photos.example.internal",
        "PHOTOPRISM_HTTP_HOST=127.0.0.1",
        "PHOTOPRISM_DATABASE_PASSWORD_FILE=/run/secrets/photoprism_db_password",
        "PHOTOPRISM_DISABLE_TLS=false",
        "PHOTOPRISM_DEBUG=false"
      ].join("\n");

      var PROSE_EXAMPLE = [
        "This server will hold the family photo archive once it is running.",
        "We plan to put it on the home network sometime next month and",
        "share the link with relatives when everything looks ready."
      ].join("\n");

      var PLACEHOLDER_PASSWORDS = ["admin","photoprism","changeme","password","example","test"];
      var SEV_RANK = { "BLOCKER":0, "HIGH":1, "WARNING":2, "INFO":3 };

      /* ---------------- Parsing ---------------- */

      function parseConfig(text){
        var entries = [];
        var unparsed = [];
        var rawLines = String(text == null ? "" : text).split(/\r?\n/);
        for (var i = 0; i < rawLines.length; i++){
          var lineNo = i + 1;
          var s = rawLines[i].replace(/^\s+/, "");
          if (s === "") continue;
          if (s.charAt(0) === "#") continue;
          var t = s.replace(/^-\s+/, "");
          t = t.replace(/^export\s+/, "");
          var m = t.match(/^([A-Za-z_][A-Za-z0-9_]*)\s*(=|:)\s*(.*)$/);
          if (!m){ unparsed.push(lineNo); continue; }
          var key = m[1].toUpperCase();
          var val = m[3].trim();
          var q = val.charAt(0);
          if ((q === '"' || q === "'") && val.lastIndexOf(q) > 0){
            val = val.slice(1, val.lastIndexOf(q));
          } else {
            var hashIdx = val.indexOf(" #");
            if (hashIdx >= 0) val = val.slice(0, hashIdx).trim();
          }
          entries.push({ line: lineNo, key: key, value: val });
        }
        return { entries: entries, unparsed: unparsed };
      }

      function isRecognized(key){
        return key.indexOf("PHOTOPRISM_") === 0 || key === "DATABASE_URL";
      }
      function isTrueVal(v){
        var s = String(v).trim().toLowerCase();
        return s === "true" || s === "1" || s === "yes" || s === "on";
      }
      function isRefVal(v){
        var s = String(v).trim();
        return s.indexOf("${") === 0 && s.indexOf("}") > 2;
      }
      function findEntry(entries, key){
        for (var i = 0; i < entries.length; i++){
          if (entries[i].key === key) return entries[i];
        }
        return null;
      }

      /* ---------------- Audit engine ----------------
         Secret-safety invariant: findings, passes, and reports are built
         only from key names, line numbers, and value LENGTHS for any
         password-bearing key. Raw secret values are never copied into
         a finding object. */

      function audit(text){
        var parsed = parseConfig(text);
        var entries = parsed.entries;
        var recognized = [];
        var i, e;
        for (i = 0; i < entries.length; i++){
          if (isRecognized(entries[i].key)) recognized.push(entries[i]);
        }

        var findings = [];
        var passes = [];
        function addFinding(sev, line, key, reason, fix){
          findings.push({ severity: sev, line: line, key: key, reason: reason, fix: fix });
        }
        function addPass(line, key, text){
          passes.push({ line: line, key: key, text: text });
        }

        if (recognized.length === 0){
          return {
            verdict: "NOT ENOUGH TO GRADE",
            verdictWhy: "The paste is empty, prose, or contains no recognizable PhotoPrism keys, so there is nothing honest to grade. Paste environment-style PHOTOPRISM_* lines (or docker-compose environment lines) and audit again.",
            findings: findings, passes: passes,
            unparsed: parsed.unparsed, recognizedCount: 0,
            counts: { BLOCKER:0, HIGH:0, WARNING:0, INFO:0 }
          };
        }

        /* Gather the entries the checks care about. */
        var authMode   = findEntry(entries, "PHOTOPRISM_AUTH_MODE");
        var adminPass  = findEntry(entries, "PHOTOPRISM_ADMIN_PASSWORD");
        var adminFile  = findEntry(entries, "PHOTOPRISM_ADMIN_PASSWORD_FILE");
        var siteUrl    = findEntry(entries, "PHOTOPRISM_SITE_URL");
        var httpHost   = findEntry(entries, "PHOTOPRISM_HTTP_HOST");
        var disableTls = findEntry(entries, "PHOTOPRISM_DISABLE_TLS");
        var dbPass     = findEntry(entries, "PHOTOPRISM_DATABASE_PASSWORD");
        var dbPassFile = findEntry(entries, "PHOTOPRISM_DATABASE_PASSWORD_FILE");
        var dbUrl      = findEntry(entries, "PHOTOPRISM_DATABASE_URL") || findEntry(entries, "DATABASE_URL");
        var debugE     = findEntry(entries, "PHOTOPRISM_DEBUG");
        var traceE     = findEntry(entries, "PHOTOPRISM_TRACE");
        var experE     = findEntry(entries, "PHOTOPRISM_EXPERIMENTAL");

        var siteIsHttps = !!(siteUrl && /^https:\/\//i.test(siteUrl.value.trim()));
        var hostAllInterfaces = !!(httpHost && /^(0\.0\.0\.0|::|\[::\])$/.test(httpHost.value.trim()));
        var networkExposed = hostAllInterfaces || !!siteUrl;

        /* --- Auth posture --- */
        if (authMode){
          var mode = authMode.value.trim().toLowerCase();
          if (mode === "public"){
            addFinding("BLOCKER", authMode.line, "PHOTOPRISM_AUTH_MODE",
              "Auth mode is set to public: anyone who can reach the server can browse the photo library with no login at all.",
              "Set PHOTOPRISM_AUTH_MODE=password and restart behind a login before the server is reachable by anyone you do not fully trust.");
          } else if (mode === "password"){
            addPass(authMode.line, "PHOTOPRISM_AUTH_MODE", "Auth mode requires a password login.");
          } else if (mode === ""){
            addFinding("WARNING", authMode.line, "PHOTOPRISM_AUTH_MODE",
              "Auth mode is present but empty, so the effective login posture is unclear from the config alone.",
              "Set PHOTOPRISM_AUTH_MODE=password explicitly so the login requirement is stated, not assumed.");
          } else {
            addFinding("WARNING", authMode.line, "PHOTOPRISM_AUTH_MODE",
              "Auth mode is set to a value this auditor does not recognize, so the login posture cannot be confirmed from the config.",
              "Use PHOTOPRISM_AUTH_MODE=password (never public) so the login requirement is explicit.");
          }
        } else if (networkExposed){
          var anchor = httpHost || siteUrl;
          addFinding("BLOCKER", anchor.line, "PHOTOPRISM_AUTH_MODE",
            "No auth mode is set anywhere in the paste, but the server is network-exposed (a bind host or site URL is configured). A missing auth posture on an exposed server means login protection cannot be confirmed.",
            "Add PHOTOPRISM_AUTH_MODE=password to the config before deploying.");
        } else {
          addFinding("WARNING", null, "PHOTOPRISM_AUTH_MODE",
            "No auth mode is set in the pasted config. It may be supplied elsewhere, but from this paste the login posture is unstated.",
            "Add PHOTOPRISM_AUTH_MODE=password to the config so the login requirement travels with it.");
        }

        /* --- Admin password (value never rendered; length only) --- */
        if (adminPass){
          var apVal = adminPass.value;
          if (isRefVal(apVal)){
            addPass(adminPass.line, "PHOTOPRISM_ADMIN_PASSWORD", "Admin password is supplied via a ${...} reference rather than written in the config.");
          } else {
            var apLen = apVal.length;
            var apLower = apVal.trim().toLowerCase();
            var isPlaceholder = PLACEHOLDER_PASSWORDS.indexOf(apLower) >= 0;
            if (isPlaceholder){
              addFinding("BLOCKER", adminPass.line, "PHOTOPRISM_ADMIN_PASSWORD",
                "The admin password (length " + apLen + ") is a well-known example/placeholder value. It is the first thing an attacker tries.",
                "Replace it with a unique password of at least 12 characters, ideally supplied via a ${...} reference or a secrets file instead of written in the config.");
            } else if (apLen < 12){
              addFinding("BLOCKER", adminPass.line, "PHOTOPRISM_ADMIN_PASSWORD",
                "The admin password is only " + apLen + " characters long — under the 12-character minimum. Short admin passwords fall to guessing quickly.",
                "Use a unique admin password of at least 12 characters (longer is better), ideally supplied via a ${...} reference or a secrets file.");
            } else {
              addPass(adminPass.line, "PHOTOPRISM_ADMIN_PASSWORD", "Admin password is at least 12 characters (length " + apLen + ") and is not a known example/placeholder value. Its actual strength and whether it is the password in use are not verified.");
            }
          }
        } else if (adminFile){
          addPass(adminFile.line, "PHOTOPRISM_ADMIN_PASSWORD_FILE", "Admin password is supplied from a file reference rather than written in the config.");
        } else {
          addFinding("WARNING", null, "PHOTOPRISM_ADMIN_PASSWORD",
            "No admin password (or file/reference for one) appears in the pasted config. It may be set elsewhere, but it is not evidenced here.",
            "Set PHOTOPRISM_ADMIN_PASSWORD to a unique value of at least 12 characters — preferably via a ${...} reference or PHOTOPRISM_ADMIN_PASSWORD_FILE — or confirm where it is set before deploying.");
        }

        /* --- Site URL scheme --- */
        if (siteUrl){
          var urlVal = siteUrl.value.trim();
          if (/^http:\/\//i.test(urlVal)){
            addFinding("HIGH", siteUrl.line, "PHOTOPRISM_SITE_URL",
              "The site URL uses plain http:// (" + urlVal + "). Logins and photos cross the network unencrypted, where they can be read or tampered with in transit.",
              "Serve the site over https:// — terminate TLS at a reverse proxy or the server itself — and update PHOTOPRISM_SITE_URL to the https:// address.");
          } else if (siteIsHttps){
            addPass(siteUrl.line, "PHOTOPRISM_SITE_URL", "Site URL uses https://, so traffic is encrypted in transit.");
          } else {
            addFinding("WARNING", siteUrl.line, "PHOTOPRISM_SITE_URL",
              "The site URL does not start with http:// or https://, so its transport security cannot be confirmed from the config.",
              "Set PHOTOPRISM_SITE_URL to the full https:// address the server is reached at.");
          }
        }

        /* --- TLS disabled --- */
        if (disableTls){
          if (isTrueVal(disableTls.value)){
            addFinding("HIGH", disableTls.line, "PHOTOPRISM_DISABLE_TLS",
              "TLS is explicitly disabled. Combined with any network exposure, credentials and photos travel unencrypted.",
              "Set PHOTOPRISM_DISABLE_TLS=false (or remove the line) and make sure https is terminated at the server or a reverse proxy in front of it.");
          } else {
            addPass(disableTls.line, "PHOTOPRISM_DISABLE_TLS", "TLS is not disabled by this setting.");
          }
        }

        /* --- Bind host --- */
        if (httpHost){
          var hostVal = httpHost.value.trim();
          if (hostAllInterfaces){
            if (siteIsHttps){
              addPass(httpHost.line, "PHOTOPRISM_HTTP_HOST", "Binds all interfaces (" + hostVal + "), but the https:// site URL indicates a TLS-terminating reverse proxy posture in front of it. Confirm the proxy is the only intended entry point.");
            } else {
              addFinding("WARNING", httpHost.line, "PHOTOPRISM_HTTP_HOST",
                "The server binds all interfaces (" + hostVal + "), so it answers on every network the machine is attached to — and no https/proxy posture is stated in this config to stand in front of it.",
                "Bind to 127.0.0.1 and put a TLS-terminating reverse proxy in front, or confirm a firewall restricts who can reach this port.");
            }
          } else if (hostVal === "127.0.0.1" || hostVal.toLowerCase() === "localhost" || hostVal === "::1"){
            addPass(httpHost.line, "PHOTOPRISM_HTTP_HOST", "Binds to a local interface only (" + hostVal + "), so a proxy or tunnel is required to reach it — the safer default.");
          } else {
            addPass(httpHost.line, "PHOTOPRISM_HTTP_HOST", "Binds to a specific interface (" + hostVal + ") rather than all interfaces.");
          }
        }

        /* --- Database password (value never rendered; length only) --- */
        if (dbPass){
          if (isRefVal(dbPass.value)){
            addPass(dbPass.line, "PHOTOPRISM_DATABASE_PASSWORD", "Database password is supplied via a ${...} reference rather than written in the config.");
          } else {
            addFinding("HIGH", dbPass.line, "PHOTOPRISM_DATABASE_PASSWORD",
              "The database password is written in plaintext in the config (length " + dbPass.value.length + "). Anyone who reads this file — a backup, a repo, a screenshot — has the database credential.",
              "Move it out of the file: supply it via a ${...} environment reference or PHOTOPRISM_DATABASE_PASSWORD_FILE pointing at a secrets file, and rotate the exposed password.");
          }
        } else if (dbPassFile){
          addPass(dbPassFile.line, "PHOTOPRISM_DATABASE_PASSWORD_FILE", "Database password is supplied from a file reference rather than written in the config.");
        }
        if (dbUrl){
          var urlStr = dbUrl.value.trim();
          var um = urlStr.match(/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\/([^:@/?#]+):([^@/?#]*)@/);
          if (um){
            var urlPw = um[2];
            if (isRefVal(urlPw) || urlPw.indexOf("${") >= 0){
              addPass(dbUrl.line, dbUrl.key, "Database URL carries its password as a reference, not a literal value.");
            } else {
              addFinding("HIGH", dbUrl.line, dbUrl.key,
                "The database URL embeds a plaintext password (password length " + urlPw.length + "). The URL itself is now a credential: it leaks into logs, shell history, and process listings.",
                "Remove the password from the URL and supply it via a ${...} reference or a separate password setting backed by a secrets file; rotate the exposed password.");
            }
          } else if (/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//.test(urlStr)){
            addPass(dbUrl.line, dbUrl.key, "Database URL contains no embedded password in its authority section.");
          }
        }

        /* --- Debug / trace / experimental --- */
        if (debugE){
          if (isTrueVal(debugE.value)){
            addFinding("WARNING", debugE.line, "PHOTOPRISM_DEBUG",
              "Debug mode is on. Debug output can expose internal paths, settings, and request detail, and it costs performance.",
              "Set PHOTOPRISM_DEBUG=false for deployment; turn it on only while actively troubleshooting.");
          } else {
            addPass(debugE.line, "PHOTOPRISM_DEBUG", "Debug mode is off.");
          }
        }
        if (traceE && isTrueVal(traceE.value)){
          addFinding("WARNING", traceE.line, "PHOTOPRISM_TRACE",
            "Trace logging is on — even more verbose than debug, and just as capable of leaking internal detail into logs.",
            "Set PHOTOPRISM_TRACE=false for deployment.");
        } else if (traceE){
          addPass(traceE.line, "PHOTOPRISM_TRACE", "Trace logging is off.");
        }
        if (experE && isTrueVal(experE.value)){
          addFinding("INFO", experE.line, "PHOTOPRISM_EXPERIMENTAL",
            "Experimental features are enabled. They can change behavior or disappear between releases, which is a stability risk on a server holding a real photo archive.",
            "Set PHOTOPRISM_EXPERIMENTAL=false for a production archive unless you specifically need an experimental feature.");
        } else if (experE){
          addPass(experE.line, "PHOTOPRISM_EXPERIMENTAL", "Experimental features are off.");
        }

        /* --- Sort worst-first, then by line --- */
        findings.sort(function(a, b){
          var r = SEV_RANK[a.severity] - SEV_RANK[b.severity];
          if (r !== 0) return r;
          var la = a.line == null ? 9999 : a.line;
          var lb = b.line == null ? 9999 : b.line;
          return la - lb;
        });
        passes.sort(function(a, b){
          var la = a.line == null ? 9999 : a.line;
          var lb = b.line == null ? 9999 : b.line;
          return la - lb;
        });

        var counts = { BLOCKER:0, HIGH:0, WARNING:0, INFO:0 };
        for (i = 0; i < findings.length; i++) counts[findings[i].severity]++;

        var verdict, verdictWhy;
        if (counts.BLOCKER > 0){
          verdict = "DO NOT DEPLOY";
          verdictWhy = counts.BLOCKER + " blocker finding" + (counts.BLOCKER === 1 ? "" : "s") + " must be fixed before this config goes anywhere near a network. Deploying as-is would expose the photo library or its credentials.";
        } else if (counts.HIGH > 0 || counts.WARNING > 0){
          verdict = "DEPLOY WITH FIXES";
          verdictWhy = "No blockers, but " + (counts.HIGH + counts.WARNING) + " high/warning finding" + ((counts.HIGH + counts.WARNING) === 1 ? "" : "s") + " should be fixed first. Nothing here is safe to ignore on a server holding personal photos.";
        } else {
          verdict = "SAFE TO DEPLOY";
          verdictWhy = "No blocker, high, or warning findings in the pasted config. This grades the pasted text only — it does not verify the running server matches it.";
        }

        return {
          verdict: verdict, verdictWhy: verdictWhy,
          findings: findings, passes: passes,
          unparsed: parsed.unparsed, recognizedCount: recognized.length,
          counts: counts
        };
      }

      /* ---------------- Reports ---------------- */

      function lineLabel(line){
        return line == null ? "not set" : "line " + line;
      }

      function buildTextReport(result){
        var out = [];
        out.push("PhotoPrism Server Config Safety Auditor — Audit Report");
        out.push("=======================================================");
        out.push("Verdict: " + result.verdict);
        out.push(result.verdictWhy);
        out.push("");
        out.push("Recognized PhotoPrism keys in paste: " + result.recognizedCount);
        out.push("Counts: BLOCKER " + result.counts.BLOCKER +
                 " · HIGH " + result.counts.HIGH +
                 " · WARNING " + result.counts.WARNING +
                 " · INFO " + result.counts.INFO);
        out.push("");
        out.push("FINDINGS (worst first)");
        out.push("-----------------------");
        if (result.findings.length === 0){
          out.push("None.");
        } else {
          for (var i = 0; i < result.findings.length; i++){
            var f = result.findings[i];
            out.push("[" + f.severity + "] " + lineLabel(f.line) + " · " + f.key);
            out.push("  " + f.reason);
            out.push("  Fix: " + f.fix);
          }
        }
        out.push("");
        out.push("PASSED CHECKS");
        out.push("-------------");
        if (result.passes.length === 0){
          out.push("None.");
        } else {
          for (var j = 0; j < result.passes.length; j++){
            var p = result.passes[j];
            out.push("[PASS] " + lineLabel(p.line) + " · " + p.key + " — " + p.text);
          }
        }
        out.push("");
        out.push("NOT PARSED");
        out.push("----------");
        if (result.unparsed.length === 0){
          out.push("None — every non-blank, non-comment line parsed.");
        } else {
          out.push("Lines not parsed as key/value pairs (content never guessed): " + result.unparsed.join(", "));
        }
        out.push("");
        out.push("Scope note: this report grades the pasted text only. It never connected to a server and does not verify any password is actually in use. Password values are never included — findings name the key, the line, and the value length only.");
        return out.join("\n");
      }

      function buildJsonReport(result){
        var obj = {
          tool: "J-Dawgs PhotoPrism Server Config Safety Auditor",
          verdict: result.verdict,
          verdict_detail: result.verdictWhy,
          recognized_photoprism_keys: result.recognizedCount,
          counts: {
            blocker: result.counts.BLOCKER,
            high: result.counts.HIGH,
            warning: result.counts.WARNING,
            info: result.counts.INFO
          },
          findings: result.findings.map(function(f){
            return { severity: f.severity, line: f.line, key: f.key, reason: f.reason, fix: f.fix };
          }),
          passed_checks: result.passes.map(function(p){
            return { line: p.line, key: p.key, detail: p.text };
          }),
          not_parsed_lines: result.unparsed.slice(),
          scope_note: "Grades pasted text only; never connected to a server; password values are never included — key name, line, and value length only."
        };
        return JSON.stringify(obj, null, 2);
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined), "PROSE_EXAMPLE": (typeof PROSE_EXAMPLE !== 'undefined' ? PROSE_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-photoprism-server-config-safety-auditortm',
  name: 'J-Dawgs PhotoPrism Server Config Safety Auditor',
  description: 'Grades a pasted PhotoPrism server config offline into one deploy verdict, with secrets reported by key name, line, and length only, never values.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"], "PROSE_EXAMPLE": __core["PROSE_EXAMPLE"] }
};
