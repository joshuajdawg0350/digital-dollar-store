'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Syncthing Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";
/* ---------- Examples (line numbers in findings refer to these exact lines) ---------- */
var RISKY = [
'<configuration version="37">',
'  <folder id="family-photos" label="Family Photos" path="/data/photos" type="sendreceive">',
'    <device id="DEVICEA-1111111-2222222-3333333-4444444-5555555-6666666-7777777"></device>',
'    <device id="LAPTOPX-8888888-9999999-AAAAAAA-BBBBBBB-CCCCCCC-DDDDDDD-EEEEEEE"></device>',
'    <minDiskFree unit="%">1</minDiskFree>',
'    <versioning type="">',
'    </versioning>',
'    <fsyncEnabled>false</fsyncEnabled>',
'  </folder>',
'  <device id="DEVICEA-1111111-2222222-3333333-4444444-5555555-6666666-7777777" name="my-pc"><address>dynamic</address></device>',
'  <gui enabled="true" tls="false">',
'    <address>0.0.0.0:8384</address>',
'    <user></user>',
'    <password></password>',
'  </gui>',
'  <options>',
'    <listenAddress>tcp://0.0.0.0:22000</listenAddress>',
'    <globalAnnounceEnabled>true</globalAnnounceEnabled>',
'    <localAnnounceEnabled>true</localAnnounceEnabled>',
'    <relaysEnabled>true</relaysEnabled>',
'    <natEnabled>true</natEnabled>',
'    <globalAnnounceServer>default</globalAnnounceServer>',
'  </options>',
'  <frobnicateWidget enabled="yes"></frobnicateWidget>',
'</configuration>'
].join("\n");

var HARDENED = [
'<configuration version="37">',
'  <folder id="documents" label="Documents" path="/data/docs" type="sendreceive">',
'    <device id="DEVICEA-1111111-2222222-3333333-4444444-5555555-6666666-7777777"></device>',
'    <versioning type="simple">',
'      <param key="keep" val="5"></param>',
'    </versioning>',
'    <fsyncEnabled>true</fsyncEnabled>',
'  </folder>',
'  <device id="DEVICEA-1111111-2222222-3333333-4444444-5555555-6666666-7777777" name="my-pc"><address>dynamic</address></device>',
'  <gui enabled="true" tls="true">',
'    <address>127.0.0.1:8384</address>',
'    <user>admin</user>',
'    <password>$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy</password>',
'  </gui>',
'  <options>',
'    <listenAddress>tcp://127.0.0.1:22000</listenAddress>',
'    <globalAnnounceEnabled>false</globalAnnounceEnabled>',
'    <localAnnounceEnabled>false</localAnnounceEnabled>',
'    <relaysEnabled>false</relaysEnabled>',
'    <natEnabled>false</natEnabled>',
'  </options>',
'</configuration>'
].join("\n");

/* ---------- Helpers ---------- */
function esc(s){return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");}
function tagVal(line,tag){var m=line.match(new RegExp("<"+tag+">([\\s\\S]*?)</"+tag+">"));return m?m[1].trim():null;}
function attrVal(line,attr){var m=line.match(new RegExp(attr+"=\"([^\"]*)\""));return m?m[1]:null;}
function jsonVal(line,key){
  var m=line.match(new RegExp("\\\""+key+"\\\"\\s*:\\s*(\\\"[^\\\"]*\\\"|true|false|null|[0-9]+)"));
  if(!m)return null; var v=m[1]; if(v.charAt(0)==='"')v=v.slice(1,-1); return v;
}
function keyVal(line,key){ /* XML tag, JSON key, or ENV key */
  var v=tagVal(line,key); if(v!==null)return v;
  v=jsonVal(line,key); if(v!==null)return v;
  var m=line.match(new RegExp("^\\s*(?:Environment=)?\"?"+key+"=([^\"\\s]+)")); if(m)return m[1];
  return null;
}
function hostOf(addr){
  if(!addr)return "";
  var a=addr.replace(/^tcp:\/\//,"").replace(/^https?:\/\//,"");
  if(a.charAt(0)==="["){var e=a.indexOf("]");return a.slice(1,e);}
  var i=a.lastIndexOf(":"); return i>0?a.slice(0,i):a;
}
function isLoopbackHost(h){return h==="127.0.0.1"||h==="localhost"||h==="::1"||/^127\./.test(h);}
function isAllHost(h){return h==="0.0.0.0"||h==="::"||h===""||h==="*";}

var KNOWN_TAGS={configuration:1,folder:1,device:1,fielsystemtype:1,filesystemtype:1,versioning:1,param:1,fspath:1,mindiskfree:1,fsyncenabled:1,gui:1,address:1,user:1,password:1,tls:1,apikey:1,options:1,listenaddress:1,globalannounceenabled:1,localannounceenabled:1,relaysenabled:1,natenabled:1,globalannounceserver:1,localannounceport:1,localannouncemcaddr:1,announceLANAddresses:1,relays:1,ignoreddevice:1,ignoredfolder:1,order:1,syncownership:1,sendownership:1,maxsendkbps:1,maxrecvkbps:1,uraccepted:1,restartonwakeup:1,autoupgradintervalh:1,keepTemporariesH:1,cacheIgnoredFiles:1,progressupdateinterval:1,limitBandwidthInLan:1,databaseTuning:1,maxConcurrentScans:1,crashReportingEnabled:1,stunServer:1,stunKeepaliveStartS:1,defaultfolder:1,defaultdevice:1,folderDevices:1,encryptionPassword:1,remoteIgnoredFolder:1,hashers:1,copiers:1,pullerDelayS:1,pullerPauseS:1,maxconflicts:1,disableSparseFiles:1,disableTempIndexes:1,paused:1,markerName:1,syncOwnership:1,sendOwnership:1,weakHashSelectionMethod:1,blockIndexing:1,caseSensitiveFS:1,junctionsAsDirs:1,syncXattrs:1,sendXattrs:1,xattrFilter:1,watchForChanges:1,scanProgressIntervalS:1,scanOwnership:1};

/* ---------- Auditor ---------- */
function auditConfig(text){
  var findings=[], protections=[], notChecked=[];
  function F(sev,line,key,title,detail,fix){findings.push({severity:sev,line:line,key:key,title:title,detail:detail,fix:fix});}
  function P(line,what){protections.push({line:line,what:what});}

  if(!text || !text.trim()){
    return {verdict:"NOT ENOUGH TO GRADE",reason:"Empty paste — there is nothing to grade. Paste a config.xml, GUI/options JSON, or environment/systemd lines and audit again.",format:"none",findings:[],protections:[],notChecked:[],counts:{BLOCKER:0,WARNING:0,INFO:0,"NOT PARSED":0}};
  }
  var recognizable=/syncthing|<configuration|<gui|<folder|globalAnnounce|localAnnounce|relaysEnabled|natEnabled|listenAddress|"gui"\s*:|"options"\s*:|"folders"\s*:|STGUI_|SYNCTHING_|<options/i.test(text);
  if(!recognizable){
    return {verdict:"NOT ENOUGH TO GRADE",reason:"No recognizable Syncthing keys in this paste — no <configuration>, <gui>, <folder>, options keys, or STGUI_/SYNCTHING_ lines were found. This looks like unrelated text, so nothing was graded and nothing was assumed.",format:"unknown",findings:[],protections:[],notChecked:[],counts:{BLOCKER:0,WARNING:0,INFO:0,"NOT PARSED":0}};
  }

  var lines=text.split("\n");
  var format="unknown";
  var t=text.trim();
  if(t.charAt(0)==="{"||/"(gui|options|folders|devices)"\s*:/.test(text)) format="JSON";
  else if(/<configuration|<gui|<folder|<options/.test(text)) format="XML (config.xml)";
  else if(/STGUI_|SYNCTHING_|Environment=|\[Service\]|\[Unit\]/.test(text)) format="environment / systemd";

  var checked={guiAddress:false,guiTls:false,guiAuth:false,listen:false,global:false,local:false,relays:false,nat:false,versioning:false,fsync:false,devices:false,folderType:false};

  /* Pass 1: collect defined devices + folder structure */
  var definedDevices={}, folderRefs=[], folders=[], curFolder=null, inGui=false, guiLine=null;
  var gui={address:null,addressLine:null,tls:null,tlsLine:null,userPresent:false,passwordState:"absent",passwordLine:null,passwordLen:0};
  var listenSeen=false;

  lines.forEach(function(raw,idx){
    var n=idx+1, line=raw, low=line.toLowerCase();

    if(/<folder[\s>]/.test(line)||/"folders"\s*:/.test(line)){
      curFolder={id:attrVal(line,"id")||jsonVal(line,"id")||"(unnamed)",line:n,hasVersioning:false,versioningBadLine:null};
      folders.push(curFolder);
      var ftype=attrVal(line,"type")||jsonVal(line,"type");
      if(ftype){checked.folderType=true;
        if(ftype!=="sendreceive"){
          var expM=line.match(/expected[:=]\s*([a-z]+)/i);
          if(expM&&expM[1].toLowerCase()!==ftype.toLowerCase()){
            F("WARNING",n,"folder.type","Folder type contradicts its stated marker","Folder \""+curFolder.id+"\" is type \""+ftype+"\" but the same line states expected \""+expM[1]+"\". One of them is wrong.","Set the folder type to what the marker states, or fix the marker.");
          }else{
            F("INFO",n,"folder.type","Folder type is \""+ftype+"\"","Folder \""+curFolder.id+"\" uses type \""+ftype+"\" rather than the default \"sendreceive\". That is a legitimate mode — this note only confirms it was seen.","No fix needed if \""+ftype+"\" is what you intended for this folder.");
          }
        }
      }
    }
    if(/<\/folder>/.test(line)) curFolder=null;

    var isDeviceTag=/<device[\s>]/.test(line);
    if(isDeviceTag){
      var did=attrVal(line,"id");
      if(did){
        if(curFolder){folderRefs.push({id:did,line:n,folder:curFolder.id});}
        else{definedDevices[did]=n;}
      }
    }
    if(curFolder&&/<versioning[\s>]/.test(line)){
      curFolder.hasVersioning=true;
      var vt=attrVal(line,"type");
      if(vt===""||vt===null){curFolder.versioningBadLine=n;}
      else{P(n,"Folder \""+curFolder.id+"\" has versioning type \""+vt+"\" set.");checked.versioning=true;}
    }
    var fsyncV=keyVal(line,"fsyncEnabled");
    if(fsyncV!==null){checked.fsync=true;
      if(fsyncV==="false"||fsyncV==="0"){F("WARNING",n,"fsyncEnabled","fsync is off","fsyncEnabled is false — after a crash or power loss, recently written files carry more risk of silent corruption.","Set <fsyncEnabled>true</fsyncEnabled> unless you have measured a real performance need to disable it.");}
      else{P(n,"fsyncEnabled is true — writes are flushed to disk.");}
    }

    /* GUI block tracking */
    if(/<gui[\s>]/.test(line)||/"gui"\s*:\s*\{/.test(line)){inGui=true;guiLine=n;
      var tlsAttr=attrVal(line,"tls");
      if(tlsAttr!==null){gui.tls=tlsAttr;gui.tlsLine=n;checked.guiTls=true;}
    }
    if(/<\/gui>/.test(line)) inGui=false;
    if(inGui||/<gui[\s>]/.test(line)){
      var ga=tagVal(line,"address")||jsonVal(line,"address");
      if(ga!==null&&gui.address===null){gui.address=ga;gui.addressLine=n;checked.guiAddress=true;}
      var tlsTag=keyVal(line,"tls");
      if(tlsTag!==null&&gui.tls===null){gui.tls=tlsTag;gui.tlsLine=n;checked.guiTls=true;}
      if(/<user>/.test(line)||/"user"\s*:/.test(line)){
        var uv=tagVal(line,"user"); if(uv===null)uv=jsonVal(line,"user");
        gui.userPresent=!!(uv&&uv.length);
      }
      if(/<password>/.test(line)||/"password"\s*:/.test(line)||/"apikey"\s*:/.test(line)){
        var pv=tagVal(line,"password"); var pkey="password";
        if(pv===null){pv=jsonVal(line,"password");}
        if(pv===null){pv=tagVal(line,"apikey");pkey="apikey";}
        gui.passwordLine=n;
        if(pv===null||pv===""){gui.passwordState="empty";}
        else{
          gui.passwordLen=pv.length;
          if(/^\$2[aby]\$/.test(pv)&&pv.length>=50){gui.passwordState="bcrypt";}
          else{gui.passwordState="plaintext";gui.passwordKey=pkey;}
        }
        checked.guiAuth=true;
      }
    }
    /* ENV-style GUI keys */
    var envAddr=line.match(/STGUI_ADDRESS\s*=\s*(\S+)/); if(envAddr&&gui.address===null){gui.address=envAddr[1];gui.addressLine=n;checked.guiAddress=true;guiLine=guiLine||n;}
    var envTls=line.match(/STGUI_TLS\s*=\s*(\S+)/); if(envTls){gui.tls=envTls[1];gui.tlsLine=n;checked.guiTls=true;}
    var envPw=line.match(/STGUI_PASSWORD\s*=\s*(\S*)/); if(envPw){gui.passwordLine=n;checked.guiAuth=true;
      if(!envPw[1]){gui.passwordState="empty";}else{gui.passwordLen=envPw[1].length;gui.passwordState=/^\$2[aby]\$/.test(envPw[1])?"bcrypt":"plaintext";gui.passwordKey="STGUI_PASSWORD";}}

    /* listenAddress */
    var la=keyVal(line,"listenAddress");
    if(la!==null){listenSeen=true;checked.listen=true;
      var lh=hostOf(la);
      if(isAllHost(lh)||la==="default"){
        F("WARNING",n,"listenAddress","Sync listener is open on all interfaces","listenAddress is \""+la+"\" — the sync port accepts connections arriving on every network interface of this machine, not just trusted ones.","Bind it to a specific interface address, or firewall the sync port (default 22000) to known peers.");
      }else if(isLoopbackHost(lh)){P(n,"listenAddress is bound to loopback only ("+la+").");}
      else{P(n,"listenAddress is bound to a specific address ("+la+"), not all interfaces.");}
    }

    /* Options booleans */
    var g=keyVal(line,"globalAnnounceEnabled");
    if(g!==null){checked.global=true;
      if(g==="true"){F("WARNING",n,"globalAnnounceEnabled","Global discovery is ON","This device announces itself to Syncthing's public global discovery servers, which learn this device's ID and IP addresses so unknown peers can find it.","Set <globalAnnounceEnabled>false</globalAnnounceEnabled> if every peer can be reached by direct address or local discovery.");}
      else{P(n,"Global discovery is off — this device does not announce itself to public discovery servers.");}
    }
    var l=keyVal(line,"localAnnounceEnabled");
    if(l!==null){checked.local=true;
      if(l==="true"){F("INFO",n,"localAnnounceEnabled","Local discovery is ON","This device broadcasts its presence on the local network, so other devices on the same LAN can find it — and anything on that LAN can see that it is running.","Leave it on for home LANs; turn it off on shared or untrusted networks.");}
      else{P(n,"Local discovery broadcasts are off.");}
    }
    var r=keyVal(line,"relaysEnabled");
    if(r!==null){checked.relays=true;
      if(r==="true"){F("WARNING",n,"relaysEnabled","Relaying is ON","When a direct connection fails, sync traffic can be routed through public relay servers run by third parties. Contents stay encrypted, but strangers' servers carry the traffic and learn both endpoints.","Set <relaysEnabled>false</relaysEnabled> if your devices can always reach each other directly or by local discovery.");}
      else{P(n,"Relaying is off — sync traffic is never routed through third-party relay servers.");}
    }
    if(/<relayServers>|"relayServers"\s*:/.test(line)&&checked.relays!==true){/* relay server list seen */}
    var nat=keyVal(line,"natEnabled");
    if(nat!==null){checked.nat=true;
      if(nat==="true"){F("WARNING",n,"natEnabled","NAT / UPnP port mapping is ON","The device asks the router to open an inbound port mapping automatically, punching a path from the internet to this machine that you did not open by hand.","Set <natEnabled>false</natEnabled> and open ports deliberately if you need inbound connections.");}
      else{P(n,"NAT / UPnP automatic port mapping is off.");}
    }

    /* NOT PARSED: unknown or malformed XML-ish lines */
    if(format.indexOf("XML")===0){
      var tr=line.trim();
      if(tr.charAt(0)==="<"&&tr.indexOf(">")===-1&&tr.length>1){
        F("NOT PARSED",n,"(line)","Line looks malformed and was not parsed","This line opens markup that never closes on the same line, so the auditor did not guess at its meaning.","Fix the markup, or split the element so it parses cleanly, then re-audit.");
      }else{
        var tm=tr.match(/^<\/?([A-Za-z][A-Za-z0-9]*)/);
        if(tm&&!KNOWN_TAGS[tm[1].toLowerCase()]&&tm[1].toLowerCase()!=="xml"){
          F("NOT PARSED",n,tm[1],"Unrecognized element was not parsed","<"+tm[1]+"> is not a Syncthing configuration element this auditor recognizes, so its contents were ignored — not assumed safe, not assumed dangerous.","Check for a typo. If this element is real, review it by hand against the Syncthing config documentation.");
        }
      }
    }
  });

  /* Folder-level versioning gaps */
  folders.forEach(function(f){
    if(f.versioningBadLine){
      F("WARNING",f.versioningBadLine,"versioning","Folder has versioning switched off in practice","Folder \""+f.id+"\" has a <versioning> element with an empty type — that means no old versions are kept. An accidental delete or overwrite on any peer propagates with nothing to restore from.","Set a versioning type (for example \"simple\" or \"staggered\") with a keep count on this folder.");
      checked.versioning=true;
    }else if(!f.hasVersioning){
      F("WARNING",f.line,"versioning","Folder has no versioning at all","Folder \""+f.id+"\" declares no <versioning> element. Deletes and overwrites from any peer leave no older copy to restore.","Add versioning to this folder (for example type \"simple\", keep 5) if its contents matter.");
    }
  });

  /* Device trust: folder refs not defined elsewhere in the paste */
  if(folderRefs.length){checked.devices=true;
    folderRefs.forEach(function(ref){
      if(definedDevices[ref.id]){P(ref.line,"Folder \""+ref.folder+"\" shares with a device that is defined in this same paste (line "+definedDevices[ref.id]+") — known to the paste; real-world trust is still yours to confirm.");}
      else{F("WARNING",ref.line,"device","Folder shared with a device the paste never defines","Folder \""+ref.folder+"\" is shared with device "+ref.id+", but that device is never defined anywhere else in this paste. From the paste alone, who owns it and whether it should receive these files is unknown.","Confirm that device belongs to someone who should have this folder. If you cannot name its owner, remove it from the folder.");}
    });
  }

  /* GUI verdict logic */
  if(gui.address!==null){
    var host=hostOf(gui.address), loop=isLoopbackHost(host), all=isAllHost(host), network=!loop;
    var tlsOn=(gui.tls==="true"||gui.tls==="1");
    if(all||network){
      if(!tlsOn){
        F("BLOCKER",gui.addressLine,"gui.address","GUI is reachable from the network without TLS","The GUI address \""+gui.address+"\" binds beyond loopback, and TLS is "+(gui.tls===null?"not stated (treated as off)":"off")+" on line "+(gui.tlsLine||gui.addressLine)+". Login traffic and the session cross the network unencrypted.","Bind the GUI to 127.0.0.1, or set tls=\"true\" on the <gui> element and use HTTPS — do not run it reachable and unencrypted.");
      }else{
        F("WARNING",gui.addressLine,"gui.address","GUI is reachable from the network (TLS is on)","The GUI address \""+gui.address+"\" binds beyond loopback. TLS is on, which protects the traffic, but the login page itself is still exposed to anyone who can reach the machine.","Bind the GUI to 127.0.0.1 and reach it over SSH or a VPN unless remote GUI access is genuinely needed.");
      }
    }else{
      P(gui.addressLine,"GUI is bound to loopback only ("+gui.address+") — not reachable from the network.");
      if(tlsOn)P(gui.tlsLine||gui.addressLine,"GUI TLS is on.");
    }
    /* password posture */
    if(gui.passwordState==="empty"||gui.passwordState==="absent"){
      if(network){
        F("BLOCKER",gui.passwordLine||gui.addressLine,"gui.password","Network-reachable GUI has no password set","The GUI can be reached beyond loopback, but the paste shows "+(gui.passwordState==="empty"?"an empty <password> element":"no GUI user/password at all")+". Anyone who can reach the address can open the console, change settings, and read or delete synced files.","Set a GUI username and a strong password before this config runs anywhere the address is reachable.");
      }else{
        F("WARNING",gui.passwordLine||gui.addressLine,"gui.password","GUI has no password set","The GUI is loopback-only, which limits exposure, but it has no password — any local process or user on this machine can open the console.","Set a GUI username and password anyway; loopback is a smaller door, not a locked one.");
      }
    }else if(gui.passwordState==="plaintext"){
      F(network?"BLOCKER":"WARNING",gui.passwordLine,gui.passwordKey||"password","GUI password looks like plaintext, not a bcrypt hash","Key \""+(gui.passwordKey||"password")+"\" on line "+gui.passwordLine+" holds a value of length "+gui.passwordLen+" that does not look like a Syncthing bcrypt hash ($2a$/$2b$/$2y$, ~60 characters). The value itself is never shown in this report. A plaintext or short value here means either a weak password or a password stored readable in the file.","Set the GUI password from inside Syncthing so it is stored as a bcrypt hash, and use a long, unique password.");
    }else if(gui.passwordState==="bcrypt"){
      P(gui.passwordLine,"GUI password is set and stored as a bcrypt hash (reported by key name and length only — value never shown).");
      if(!gui.userPresent){F("INFO",gui.passwordLine,"gui.user","Password hash present but no GUI username seen","A bcrypt password hash is set, but no non-empty GUI <user> was found in the paste.","Confirm a GUI username is set alongside the password.");}
    }
    if(gui.tls!==null&&checked.guiTls&&network&&tlsOn){/* covered above */}
  }

  if(!checked.guiAddress)notChecked.push("GUI listen address — no <address> inside a <gui> block (or STGUI_ADDRESS) appears in the paste.");
  if(!checked.guiTls)notChecked.push("GUI TLS — no tls setting for the GUI appears in the paste.");
  if(!checked.guiAuth)notChecked.push("GUI user / password — no GUI credential elements appear in the paste.");
  if(!checked.listen)notChecked.push("Sync listenAddress — no <listenAddress> appears in the paste.");
  if(!checked.global)notChecked.push("Global discovery (globalAnnounceEnabled) — not present in the paste.");
  if(!checked.local)notChecked.push("Local discovery (localAnnounceEnabled) — not present in the paste.");
  if(!checked.relays)notChecked.push("Relaying (relaysEnabled) — not present in the paste.");
  if(!checked.nat)notChecked.push("NAT / UPnP (natEnabled) — not present in the paste.");
  if(!checked.versioning)notChecked.push("Folder versioning — no folder versioning posture could be confirmed from the paste.");
  if(!checked.fsync)notChecked.push("fsync (fsyncEnabled) — not present in the paste.");
  if(!checked.devices)notChecked.push("Folder device sharing — no folder <device> entries appear in the paste.");
  if(!checked.folderType)notChecked.push("Folder types — no folder type attributes appear in the paste.");

  findings.sort(function(a,b){return a.line-b.line;});
  var counts={BLOCKER:0,WARNING:0,INFO:0,"NOT PARSED":0};
  findings.forEach(function(f){counts[f.severity]=(counts[f.severity]||0)+1;});
  var verdict, reason;
  if(counts.BLOCKER>0){verdict="DO NOT RUN";reason=counts.BLOCKER+" blocking finding"+(counts.BLOCKER>1?"s":"")+" must be fixed before this configuration runs. Every finding is listed below at its line.";}
  else if(counts.WARNING>0||counts["NOT PARSED"]>0){verdict="RUN WITH FIXES";reason="Nothing here is an outright blocker, but "+(counts.WARNING+counts["NOT PARSED"])+" item"+((counts.WARNING+counts["NOT PARSED"])>1?"s":"")+" should be fixed or reviewed before this runs unattended.";}
  else{verdict="SAFE TO RUN";reason="No blockers and no warnings in what the paste shows. Protections verified from the paste are listed below; anything absent is listed as NOT CHECKED, not assumed safe.";}
  return {verdict:verdict,reason:reason,format:format,findings:findings,protections:protections,notChecked:notChecked,counts:counts};
}

/* ---------- Rendering ---------- */
var lastResult=null, lastText="";
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-syncthing-config-safety-auditortm',
  name: 'J-Dawgs Syncthing Config Safety Auditor',
  description: 'Syncthing\'s own checks only answer will-it-start on the host; ours grades a pasted config.xml offline (GUI bind/TLS/password posture, discovery and relay exposure, folder sharing) and returns one run verdict with a located fix list.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
