'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs OpenBao Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var RISKY = [
        '# Risky OpenBao server config — do not ship this',
        'ui            = true',
        '',
        'listener "tcp" {',
        '  address     = "0.0.0.0:8200"',
        '  tls_disable = true',
        '}',
        '',
        'storage "file" {',
        '  path = "/var/openbao/data"',
        '}',
        '',
        'disable_mlock = true',
        'api_addr      = "http://203.0.113.10:8200"',
        '',
        'seal "awskms" {',
        '  region     = "us-east-1"',
        '  access_key = "AKIA-PLAINTEXT-EXAMPLE"',
        '  secret_key = "plaintext-secret-key-value-1234"',
        '}'
      ].join("\n");
      // In the risky example above, tls_disable sits on line 6 — the BLOCKER line.

      var HARDENED = [
        '# Hardened OpenBao server config',
        'ui = true',
        '',
        'listener "tcp" {',
        '  address         = "10.0.4.12:8200"',
        '  cluster_address = "10.0.4.12:8201"',
        '  tls_cert_file   = "/etc/openbao/tls/server.crt"',
        '  tls_key_file    = "/etc/openbao/tls/server.key"',
        '  tls_min_version = "tls12"',
        '}',
        '',
        'storage "raft" {',
        '  path    = "/var/openbao/raft"',
        '  node_id = "openbao-node-1"',
        '}',
        '',
        'seal "awskms" {',
        '  region     = "us-east-1"',
        '  access_key = "${env:AWS_ACCESS_KEY_ID}"',
        '  secret_key = "${env:AWS_SECRET_ACCESS_KEY}"',
        '}',
        '',
        'disable_mlock = false',
        'api_addr      = "https://10.0.4.12:8200"',
        'cluster_addr  = "https://10.0.4.12:8201"',
        '',
        'telemetry {',
        '  prometheus_retention_time = "24h"',
        '  disable_hostname          = true',
        '}'
      ].join("\n");

      var KNOWN_KEYS = {
        ui: 1, api_addr: 1, cluster_addr: 1, disable_mlock: 1, disable_cache: 1,
        log_level: 1, log_format: 1, pid_file: 1, raw_storage_endpoint: 1,
        address: 1, cluster_address: 1, tls_disable: 1, tls_cert_file: 1,
        tls_key_file: 1, tls_client_ca_file: 1, tls_min_version: 1, tls_max_version: 1,
        tls_require_and_verify_client_cert: 1, x_forwarded_for_authorized_addrs: 1,
        unauthenticated_metrics_access: 1, path: 1, node_id: 1, performance_multiplier: 1,
        retry_join: 1, leader_api_addr: 1, leader_tls_servername: 1, leader_ca_cert_file: 1,
        leader_client_cert_file: 1, leader_client_key_file: 1, autopilot_reconcile_interval: 1,
        prometheus_retention_time: 1, disable_hostname: 1, usage_gauge_period: 1,
        maximum_gauge_cardinality: 1, region: 1, kms_key_id: 1, endpoint: 1,
        max_lease_ttl: 1, default_lease_ttl: 1, cluster_name: 1, cluster_cipher_suites: 1,
        plugin_directory: 1, entropy_source: 1, sealwrap: 1, schema: 1, table: 1,
        connection_url: 1, ha_enabled: 1, redirect_addr: 1, service_registration: 1
      };
      var KNOWN_BLOCKS = {
        listener: 1, storage: 1, seal: 1, telemetry: 1, audit: 1, service_registration: 1,
        raft: 1, file: 1, consul: 1, inmem: 1, postgresql: 1, mysql: 1, etcd: 1,
        awskms: 1, azurekeyvault: 1, gcpckms: 1, tcp: 1, unix: 1, retry_join: 1
      };
      var STORAGE_TYPES = { raft: 1, file: 1, consul: 1, inmem: 1, postgresql: 1, mysql: 1, etcd: 1, zookeeper: 1, dynamodb: 1, s3: 1, azure: 1, gcs: 1, cassandra: 1, cockroachdb: 1 };
      var CRED_KEY_RE = /password|secret|token|access_key|secret_key/i;
      var SEV_RANK = { BLOCKER: 0, HIGH: 1, WARNING: 2, INFO: 3 };

      function isTruthy(v) {
        var s = String(v).toLowerCase();
        return s === "true" || s === "1";
      }
      function hostOf(addr) {
        if (!addr) return "";
        var a = String(addr).trim();
        if (a.charAt(0) === "[") {
          var end = a.indexOf("]");
          return end > 0 ? a.slice(1, end) : a;
        }
        var idx = a.lastIndexOf(":");
        return idx > 0 ? a.slice(0, idx) : a;
      }
      function isLocalhost(host) {
        return host === "localhost" || host === "127.0.0.1" || host === "::1";
      }
      function isAllInterfaces(host) {
        return host === "0.0.0.0" || host === "::";
      }
      function urlHost(url) {
        var m = String(url).match(/^[a-z][a-z0-9+.-]*:\/\/([^\/:?#]+)/i);
        if (!m) return "";
        var h = m[1];
        if (h.charAt(0) === "[") return h.slice(1, h.indexOf("]"));
        return h;
      }
      function isEnvRef(value) {
        var v = String(value).trim();
        return v.indexOf("${") === 0 || /^env:/i.test(v) || /^\$[A-Z_][A-Z0-9_]*$/.test(v) || /\$\{\s*env\s*:/i.test(v);
      }

      function parseConfig(text) {
        var lines = String(text).split(/\r?\n/);
        var settings = [];
        var blocks = [];
        var stack = [];
        var notParsed = [];
        var recognized = 0;
        for (var i = 0; i < lines.length; i++) {
          var lineNo = i + 1;
          var line = lines[i].trim();
          if (!line) continue;
          if (line.charAt(0) === "#") continue;
          if (line.indexOf("//") === 0) continue;
          if (/^\},?$/.test(line)) {
            if (stack.length) stack.pop();
            recognized++;
            continue;
          }
          var m = line.match(/^([A-Za-z_][\w-]*)\s*(?:"([^"]*)")?\s*\{\s*$/);
          if (m) {
            var b = { type: m[1].toLowerCase(), name: (m[2] || "").toLowerCase(), line: lineNo, settings: [] };
            blocks.push(b); stack.push(b);
            if (KNOWN_BLOCKS[b.type]) recognized++;
            continue;
          }
          m = line.match(/^"([^"]+)"\s*:\s*\{\s*$/);
          if (m) {
            var bj = { type: m[1].toLowerCase(), name: "", line: lineNo, settings: [] };
            blocks.push(bj); stack.push(bj);
            if (KNOWN_BLOCKS[bj.type]) recognized++;
            continue;
          }
          m = line.match(/^"?([A-Za-z_][\w.-]*)"?\s*=\s*(.+)$/);
          if (!m) m = line.match(/^"([^"]+)"\s*:\s*(.+?)\s*,?\s*$/);
          if (m) {
            var key = m[1];
            var rawVal = m[2].trim();
            if (rawVal.charAt(rawVal.length - 1) === ",") rawVal = rawVal.slice(0, -1).trim();
            var val = rawVal;
            if (val.length >= 2 && val.charAt(0) === '"' && val.charAt(val.length - 1) === '"') {
              val = val.slice(1, -1);
            }
            var s = {
              key: key, keyLower: key.toLowerCase(), value: val,
              line: lineNo, block: stack.length ? stack[stack.length - 1] : null
            };
            settings.push(s);
            if (s.block) s.block.settings.push(s);
            if (KNOWN_KEYS[s.keyLower]) recognized++;
            continue;
          }
          notParsed.push(lineNo);
        }
        return { settings: settings, blocks: blocks, notParsed: notParsed, recognized: recognized, lineCount: lines.length };
      }

      function blockSetting(block, key) {
        for (var i = 0; i < block.settings.length; i++) {
          if (block.settings[i].keyLower === key) return block.settings[i];
        }
        return null;
      }
      function topSetting(settings, key) {
        for (var i = 0; i < settings.length; i++) {
          if (!settings[i].block && settings[i].keyLower === key) return settings[i];
        }
        return null;
      }
      function anySetting(settings, key) {
        for (var i = 0; i < settings.length; i++) {
          if (settings[i].keyLower === key) return settings[i];
        }
        return null;
      }

      function audit(text) {
        var parsed = parseConfig(text);
        var settings = parsed.settings;
        var findings = [];
        function add(sev, line, rule, title, detail, fix) {
          findings.push({ severity: sev, line: line, rule: rule, title: title, detail: detail, fix: fix });
        }

        var listeners = [];
        var storages = [];
        parsed.blocks.forEach(function (b) {
          if (b.type === "listener" || b.type === "tcp" || b.type === "unix") listeners.push(b);
          if (b.type === "storage" || STORAGE_TYPES[b.type]) {
            storages.push({ block: b, backend: b.type === "storage" ? (b.name || "storage") : b.type });
          }
        });

        var clusterAddrSetting = anySetting(settings, "cluster_addr");
        var clusterPresent = !!clusterAddrSetting;
        listeners.forEach(function (L) {
          if (blockSetting(L, "cluster_address")) clusterPresent = true;
        });
        var tlsAvailable = listeners.some(function (L) {
          var td = blockSetting(L, "tls_disable");
          return blockSetting(L, "tls_cert_file") && !(td && isTruthy(td.value));
        });

        // Listener rules
        listeners.forEach(function (L) {
          var addrS = blockSetting(L, "address");
          var tdS = blockSetting(L, "tls_disable");
          var td = tdS && isTruthy(tdS.value);
          var host = addrS ? hostOf(addrS.value) : "127.0.0.1";
          var addrDesc = addrS ? addrS.value : "(no address set — OpenBao default)";
          if (td) {
            if (isLocalhost(host)) {
              add("HIGH", tdS.line, "listener-tls-disable",
                "Listener has TLS disabled (localhost only)",
                'Listener "' + (L.name || L.type) + '" on ' + addrDesc + " sets tls_disable. The address is localhost-only, which limits exposure, but any local process or tunnel can still read vault traffic in plaintext.",
                "Remove tls_disable (or set it to false) and configure tls_cert_file and tls_key_file, even for localhost listeners.");
            } else {
              add("BLOCKER", tdS.line, "listener-tls-disable",
                "Listener has TLS disabled on a reachable address",
                'Listener "' + (L.name || L.type) + '" is bound to ' + addrDesc + " with tls_disable = true. API and cluster traffic — including tokens and secrets — crosses the network in plaintext.",
                "Set tls_disable = false and provide tls_cert_file and tls_key_file for this listener before deploying.");
            }
          } else {
            if (isAllInterfaces(host)) {
              add("WARNING", addrS ? addrS.line : L.line, "listener-all-interfaces",
                "Listener bound to all interfaces (TLS enabled)",
                'Listener "' + (L.name || L.type) + '" binds to ' + addrDesc + ". TLS is enabled, so traffic is encrypted, but the API port answers on every network interface.",
                "Bind the listener to a specific address, or confirm the all-interfaces exposure is intended and restricted by firewall rules.");
            }
            var missing = [];
            if (!blockSetting(L, "tls_cert_file")) missing.push("tls_cert_file");
            if (!blockSetting(L, "tls_key_file")) missing.push("tls_key_file");
            if (missing.length) {
              add("WARNING", L.line, "listener-missing-tls-files",
                "TLS not disabled, but " + missing.join(" and ") + " missing",
                'Listener "' + (L.name || L.type) + '" does not set tls_disable, yet ' + missing.join(" and ") + (missing.length > 1 ? " are" : " is") + " not configured. The server would fail to start or fall back in ways this paste cannot show.",
                "Add " + missing.join(" and ") + " pointing at the certificate and private key for this listener.");
            }
          }
          var caS = blockSetting(L, "cluster_address");
          if (caS && td) {
            add("HIGH", caS.line, "cluster-listener-no-tls",
              "Cluster listener runs without TLS",
              "This listener declares a cluster_address while tls_disable = true, so raft cluster traffic between nodes is unencrypted.",
              "Enable TLS on the listener (tls_cert_file / tls_key_file, tls_disable = false) so cluster traffic is encrypted.");
          }
          var umaS = blockSetting(L, "unauthenticated_metrics_access");
          if (umaS && isTruthy(umaS.value)) {
            if (isLocalhost(host)) {
              add("INFO", umaS.line, "telemetry-unauthenticated-local",
                "Unauthenticated metrics access on a localhost listener",
                "unauthenticated_metrics_access = true lets anything that can reach this listener read telemetry without a token. The listener is localhost-only, which limits who that is.",
                "No fix required if localhost-only exposure is intended; otherwise set unauthenticated_metrics_access = false.");
            } else {
              add("WARNING", umaS.line, "telemetry-unauthenticated-exposed",
                "Telemetry listener exposed on all reachable interfaces",
                "unauthenticated_metrics_access = true on a listener bound to " + addrDesc + " lets anyone who can reach the port read telemetry with no token.",
                "Set unauthenticated_metrics_access = false, or move metrics to a localhost-only listener.");
            }
          }
        });

        // disable_mlock
        var mlockS = anySetting(settings, "disable_mlock");
        if (mlockS && isTruthy(mlockS.value)) {
          add("HIGH", mlockS.line, "disable-mlock",
            "disable_mlock = true — memory can swap to disk",
            "With mlock disabled, the OS may page vault memory — including decrypted secrets — out to disk swap, where it can persist after shutdown.",
            "Set disable_mlock = false and grant the server the IPC_LOCK capability (or run it where mlock is permitted).");
        }

        // Plaintext credentials — key name, line, and length only. Never the value.
        settings.forEach(function (s) {
          if (!CRED_KEY_RE.test(s.key)) return;
          if (s.value === "") return;
          if (isEnvRef(s.value)) {
            add("INFO", s.line, "credential-env-ref",
              'Credential "' + s.key + '" uses an environment reference',
              'The value of "' + s.key + '" is an environment/secret reference rather than a literal, so no plaintext credential sits in the config. (Value withheld; ' + s.value.length + " characters as pasted.)",
              "No fix required — keep credentials referenced, not written out.");
          } else {
            add("HIGH", s.line, "credential-plaintext",
              'Plaintext credential in key "' + s.key + '"',
              'Key "' + s.key + '" holds a literal credential value (' + s.value.length + " characters). The value itself is never shown in this report. Anyone who reads this config file owns the credential.",
              'Replace the literal with an environment reference such as ${env:VAR_NAME} or a secret-manager lookup, and rotate the exposed credential — it has been sitting in plaintext.');
          }
        });

        // Storage rules
        var raftPresent = false;
        storages.forEach(function (st) {
          if (st.backend === "file") {
            add("WARNING", st.block.line, "storage-file",
              "File storage backend in a production posture",
              'storage "file" keeps all vault data in plain files on one host: no replication, no integrated high availability, and backups are only as good as your own copying.',
              'Move production data to integrated storage (storage "raft") or a supported replicated backend; keep file storage for development only.');
          }
          if (st.backend === "raft") {
            raftPresent = true;
            if (!blockSetting(st.block, "node_id")) {
              add("WARNING", st.block.line, "storage-raft-no-node-id",
                'Raft storage without a node_id',
                'storage "raft" has no node_id, so the node takes a default identity — a recurring source of confusion and collision when rebuilding or clustering nodes.',
                'Set a stable, unique node_id for this server inside the storage "raft" block.');
            }
          }
        });
        if (clusterPresent && raftPresent && !tlsAvailable) {
          var cLine = clusterAddrSetting ? clusterAddrSetting.line : null;
          if (!cLine) {
            for (var li = 0; li < listeners.length; li++) {
              var cs = blockSetting(listeners[li], "cluster_address");
              if (cs) { cLine = cs.line; break; }
            }
          }
          add("HIGH", cLine || 1, "raft-cluster-tls-absent",
            "Integrated storage cluster traffic has no TLS",
            "A cluster listener / cluster_addr is configured with raft integrated storage, but no listener provides tls_cert_file — the TLS that integrated storage uses for cluster_addr is absent, so node-to-node replication is unencrypted or cannot form.",
            "Configure tls_cert_file and tls_key_file on the listener (with tls_disable = false) so cluster traffic over cluster_addr is encrypted.");
        }

        // Telemetry notes
        parsed.blocks.forEach(function (b) {
          if (b.type !== "telemetry") return;
          var prt = blockSetting(b, "prometheus_retention_time");
          if (prt) {
            add("INFO", prt.line, "telemetry-prometheus",
              "Prometheus retention set — check the metrics posture",
              "prometheus_retention_time is set, so metrics are being kept for scraping. In the Vault family the metrics endpoint is unauthenticated unless the listener posture restricts it — confirm who can reach it.",
              "No fix required if the metrics endpoint is reachable only where you intend; otherwise restrict the listener or require a token.");
          }
          var dh = blockSetting(b, "disable_hostname");
          if (dh && isTruthy(dh.value)) {
            add("INFO", dh.line, "telemetry-disable-hostname",
              "telemetry disable_hostname = true",
              "Hostname labels are stripped from metrics. That is a reasonable privacy/cardinality choice; it also makes per-host alerting harder.",
              "No fix required — noted so the choice is deliberate.");
          }
        });

        // ui over plain HTTP
        var uiS = anySetting(settings, "ui");
        if (uiS && isTruthy(uiS.value) && listeners.length) {
          var allPlain = listeners.every(function (L) {
            var td = blockSetting(L, "tls_disable");
            return td && isTruthy(td.value);
          });
          if (allPlain) {
            add("WARNING", uiS.line, "ui-over-http",
              "Web UI enabled while the only listener is plain HTTP",
              "ui = true serves the web console, and every listener has TLS disabled — browsers will send root tokens and credentials to it over plaintext HTTP.",
              "Enable TLS on the listener before exposing the UI, or set ui = false.");
          }
        }

        // api_addr / cluster_addr scheme
        ["api_addr", "cluster_addr"].forEach(function (key) {
          var s = anySetting(settings, key);
          if (!s) return;
          if (/^http:\/\//i.test(s.value)) {
            var h = urlHost(s.value);
            if (isLocalhost(h)) {
              add("INFO", s.line, key + "-http-localhost",
                key + " uses http:// for a localhost address",
                key + " points at " + h + " over plain HTTP. On a single-host setup that stays on the loopback interface.",
                "No fix required for localhost-only use; switch to https:// before this address leaves the host.");
            } else {
              add("HIGH", s.line, key + "-http",
                key + " uses http:// for a non-localhost host",
                key + " is set to an http:// address on " + (h || "a remote host") + ". Clients and cluster peers will send tokens and secrets to it unencrypted, and redirects can strand callers on plaintext.",
                "Set " + key + " to the https:// address that matches the listener's TLS certificate.");
            }
          }
        });

        findings.sort(function (a, b) {
          if (SEV_RANK[a.severity] !== SEV_RANK[b.severity]) return SEV_RANK[a.severity] - SEV_RANK[b.severity];
          return a.line - b.line;
        });

        var counts = { BLOCKER: 0, HIGH: 0, WARNING: 0, INFO: 0 };
        findings.forEach(function (f) { counts[f.severity]++; });

        var verdict, verdictClass, verdictDetail;
        if (parsed.recognized === 0) {
          verdict = "NOT ENOUGH TO GRADE";
          verdictClass = "none";
          verdictDetail = "No recognizable OpenBao keys were found in the paste. Grade needs at least one OpenBao setting or block (listener, storage, seal, telemetry, ui, api_addr, disable_mlock…).";
        } else if (counts.BLOCKER > 0) {
          verdict = "DO NOT DEPLOY";
          verdictClass = "no";
          verdictDetail = counts.BLOCKER + " blocker finding" + (counts.BLOCKER === 1 ? "" : "s") + " must be fixed before this config goes anywhere near production.";
        } else if (counts.HIGH > 0 || counts.WARNING > 0) {
          verdict = "DEPLOY WITH FIXES";
          verdictClass = "fixes";
          verdictDetail = "No blockers, but " + (counts.HIGH + counts.WARNING) + " finding" + ((counts.HIGH + counts.WARNING) === 1 ? "" : "s") + " should be fixed before or at deploy time.";
        } else {
          verdict = "SAFE TO DEPLOY";
          verdictClass = "safe";
          verdictDetail = "No BLOCKER, HIGH, or WARNING findings in the pasted config. INFO notes, if any, are awareness items only.";
        }

        return {
          verdict: verdict, verdictClass: verdictClass, verdictDetail: verdictDetail,
          findings: findings, counts: counts, notParsed: parsed.notParsed,
          recognized: parsed.recognized, lineCount: parsed.lineCount
        };
      }

      function buildReport(r) {
        var out = [];
        out.push("J-Dawgs OpenBao Server Config Safety Auditor — audit report");
        out.push("Verdict: " + r.verdict);
        out.push("Findings: BLOCKER " + r.counts.BLOCKER + " · HIGH " + r.counts.HIGH + " · WARNING " + r.counts.WARNING + " · INFO " + r.counts.INFO + " · NOT PARSED lines " + r.notParsed.length);
        out.push("");
        if (!r.findings.length) {
          out.push("Findings: none.");
        } else {
          out.push("Findings:");
          r.findings.forEach(function (f, i) {
            out.push((i + 1) + ". [" + f.severity + "] Line " + f.line + " — " + f.title);
            out.push("   " + f.detail);
            out.push("   Fix: " + f.fix);
          });
        }
        out.push("");
        var fixes = r.findings.filter(function (f) { return f.severity !== "INFO"; });
        if (fixes.length) {
          out.push("Fix list:");
          fixes.forEach(function (f, i) {
            out.push((i + 1) + ". (Line " + f.line + ", " + f.severity + ") " + f.fix);
          });
          out.push("");
        }
        out.push("Lines not parsed (content withheld): " + (r.notParsed.length ? r.notParsed.join(", ") : "none"));
        out.push("Credential values are never printed: credential findings show key name, line, and character length only.");
        out.push("Heuristic text audit of pasted text — not a full HCL parse, not a check of any running server.");
        return out.join("\n");
      }

      function buildJSON(r) {
        return JSON.stringify({
          tool: "J-Dawgs OpenBao Server Config Safety Auditor",
          auditType: "heuristic text audit of pasted config (not a full HCL parse)",
          verdict: r.verdict,
          counts: {
            BLOCKER: r.counts.BLOCKER, HIGH: r.counts.HIGH,
            WARNING: r.counts.WARNING, INFO: r.counts.INFO,
            notParsedLines: r.notParsed.length
          },
          linesAudited: r.lineCount,
          findings: r.findings.map(function (f) {
            return { line: f.line, severity: f.severity, rule: f.rule, title: f.title, detail: f.detail, fix: f.fix };
          }),
          notParsedLines: r.notParsed,
          secrecy: "Credential values are never included; credential findings carry key name, line, and value length only."
        }, null, 2);
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-openbao-server-config-safety-auditor',
  name: 'J-Dawgs OpenBao Server Config Safety Auditor',
  description: 'Grades a pasted OpenBao server config fully offline into one deploy verdict — listeners running with tls_disable, disable_mlock, plaintext storage credentials, cluster TLS posture, and telemetry exposure — with secrets reported by key name, line, and length only, never by value. OpenBao only exercis',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
