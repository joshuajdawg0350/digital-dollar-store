'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs EMQX Broker Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

var RISKY = [
"# Risky example - do not deploy a broker like this",
"node.name = \"emqx@127.0.0.1\"",
"node.cookie = \"emqxsecretcookie\"",
"mqtt.allow_anonymous = true",
"listeners.tcp.default.bind = 0.0.0.0:1883",
"dashboard.listeners.http.bind = 0.0.0.0:18083",
"dashboard.default_password = \"abc123\"",
"listeners.tcp.default.max_connections = infinity"
].join("\n");

var HARDENED = [
"# Hardened example",
"node.name = \"emqx@10.0.0.12\"",
"node.cookie = ${EMQX_NODE_COOKIE}",
"cluster.discovery_strategy = static",
"cluster.static.seeds = \"emqx@10.0.0.12, emqx@10.0.0.13\"",
"mqtt.allow_anonymous = false",
"authentication.1.mechanism = password_based",
"authentication.1.backend = built_in_database",
"authentication.1.user_id_type = username",
"dashboard.default_password = ${EMQX_DASHBOARD_PASSWORD}",
"listeners.tcp.default.bind = 127.0.0.1:1883",
"listeners.tcp.default.max_connections = 512",
"listeners.ssl.default.bind = 127.0.0.1:8883",
"listeners.ssl.default.ssl_options.verify_peer = verify_peer",
"listeners.ssl.default.ssl_options.keyfile = /etc/emqx/certs/key.pem",
"listeners.ssl.default.ssl_options.certfile = /etc/emqx/certs/cert.pem",
"listeners.ssl.default.ssl_options.cacertfile = /etc/emqx/certs/cacert.pem",
"dashboard.listeners.https.bind = 127.0.0.1:18084",
"listeners.tcp.default.rate_limit.max_conn_rate = 100"
].join("\n");

var DEFAULT_SECRETS = ["password","passw0rd","admin","public","emqx","default","changeme","secret","letmein","123456","12345678","abc123","emqxsecretcookie","cookie","erlangcookie"];
var RELEVANT = ["emqx","mqtt","listener","dashboard","authentication","authorization","allow_anonymous","node","cluster","cookie","ssl","tls","broker","zone","overload","rate_limit","ratelimit"];

function stripQuotes(v){
  v = v.trim();
  if(v.length>=2 && ((v.charAt(0)==='"' && v.charAt(v.length-1)==='"') || (v.charAt(0)==="'" && v.charAt(v.length-1)==="'"))){
    return v.slice(1,-1);
  }
  return v;
}
function isEnvSub(v){
  return v.indexOf("${") !== -1 || v.indexOf("$env") !== -1;
}
function isTrue(v){ v=v.toLowerCase(); return v==="true"||v==="yes"||v==="on"||v==="1"; }
function isFalse(v){ v=v.toLowerCase(); return v==="false"||v==="no"||v==="off"||v==="0"; }

function parseConfig(text){
  var entries = [], notParsed = [];
  var lines = text.split(/\r?\n/);
  for(var i=0;i<lines.length;i++){
    var lineNo = i+1;
    var raw = lines[i];
    var t = raw.trim();
    if(t===""){ continue; }
    if(t.charAt(0)==="#" ){ continue; }
    if(t.indexOf("//")===0){ continue; }
    if(t==="{" || t==="}" || t.charAt(t.length-1)==="{"){ continue; }
    var key=null, value=null;
    var eq = t.indexOf("=");
    if(eq>0){
      key = t.slice(0,eq).trim();
      value = t.slice(eq+1).trim();
    } else {
      var m = t.match(/^([^:\s][^:]*):\s+(.+)$/);
      if(m){ key=m[1].trim(); value=m[2].trim(); }
      else if(t.charAt(t.length-1)===":"){ continue; }
    }
    if(key===null || key==="" || value===null){
      notParsed.push({line:lineNo});
      continue;
    }
    // Strip trailing inline comment markers outside quotes is skipped for safety; strip a trailing comma (HOCON lists use separate lines).
    if(value.charAt(value.length-1)==="," ){ value = value.slice(0,-1).trim(); }
    entries.push({ line:lineNo, key:key, keyLower:key.toLowerCase(), value:stripQuotes(value), valueRaw:value });
  }
  return {entries:entries, notParsed:notParsed, totalLines:lines.length};
}

function isSecretKey(k){
  if(k.indexOf("file")!==-1) return false;               // keyfile / certfile are paths, not secrets
  if(k.indexOf("hash")!==-1 || k.indexOf("algorithm")!==-1 || k.indexOf("mechanism")!==-1) return false;
  if(k.indexOf("cookie")!==-1) return false;              // cookie judged by its own rule
  return k.indexOf("password")!==-1 || k.indexOf("secret")!==-1 || k.indexOf("token")!==-1 || /(^|[._\-])key($|[._\-])/.test(k) || k.indexOf("_key")!==-1 || k.indexOf("key_")!==-1;
}
function isCookieKey(k){
  return k.indexOf("cookie")!==-1;
}

function audit(text){
  var findings = [];
  function add(sev, line, key, msg, fix){
    findings.push({severity:sev, line:(line==null?null:line), key:(key||null), message:msg, fix:fix});
  }
  if(!text || text.trim()===""){
    return {verdict:"NOT ENOUGH TO GRADE", findings:[], counts:{BLOCKER:0,HIGH:0,WARNING:0,INFO:0},
      note:"Nothing was pasted. Paste an EMQX config (emqx.conf key = value lines, or EMQX environment / docker-compose style lines) and audit again — an empty paste cannot be graded."};
  }
  var parsed = parseConfig(text);
  var entries = parsed.entries;
  var relevant = 0;
  entries.forEach(function(e){
    for(var j=0;j<RELEVANT.length;j++){ if(e.keyLower.indexOf(RELEVANT[j])!==-1){ relevant++; break; } }
  });
  if(entries.length===0 || relevant<2){
    return {verdict:"NOT ENOUGH TO GRADE", findings:[], counts:{BLOCKER:0,HIGH:0,WARNING:0,INFO:0},
      note:"This paste does not look like an EMQX config: "+entries.length+" setting line(s) parsed, "+relevant+" with recognizable EMQX keys, "+parsed.notParsed.length+" line(s) could not be parsed. Paste emqx.conf contents or EMQX_* environment lines so the settings can be graded."};
  }

  function hasKey(substr){ return entries.some(function(e){ return e.keyLower.indexOf(substr)!==-1; }); }
  function findKeys(substr){ return entries.filter(function(e){ return e.keyLower.indexOf(substr)!==-1; }); }

  // --- Anonymous access + authentication presence ---
  var anonEntries = findKeys("allow_anonymous");
  var anonTrue = anonEntries.filter(function(e){ return isTrue(e.value); });
  anonTrue.forEach(function(e){
    add("BLOCKER", e.line, e.key, "Anonymous access is allowed ("+e.key+" = true): anyone who can reach the broker can connect, publish, and subscribe with no credentials.",
      "Set "+e.key+" = false and configure an authentication backend so every client must log in.");
  });
  if(anonEntries.length && anonTrue.length===0){
    add("INFO", anonEntries[0].line, anonEntries[0].key, "Anonymous access is disabled ("+anonEntries[0].key+" is not true).", "No change needed.");
  }
  if(!hasKey("authentication")){
    add("HIGH", null, null, "No authentication configuration found: no setting in the paste defines how clients prove who they are.",
      "Add an authentication backend (for example a built-in database or HTTP authenticator) and require it on every listener.");
  }

  // --- TLS listener presence ---
  var tlsPresent = entries.some(function(e){
    return (e.keyLower.indexOf("listener")!==-1 && (e.keyLower.indexOf("ssl")!==-1 || e.keyLower.indexOf("tls")!==-1 || e.keyLower.indexOf("wss")!==-1))
      || e.value.indexOf("8883")!==-1;
  });

  // --- MQTT listeners on all interfaces ---
  entries.forEach(function(e){
    var isListenerBind = e.keyLower.indexOf("listener")!==-1 && (e.keyLower.indexOf("bind")!==-1 || e.keyLower.indexOf("tcp")!==-1);
    var isPlain = e.keyLower.indexOf("ssl")===-1 && e.keyLower.indexOf("tls")===-1 && e.keyLower.indexOf("dashboard")===-1;
    if(isListenerBind && isPlain && e.value.indexOf("0.0.0.0")!==-1){
      if(!tlsPresent){
        add("HIGH", e.line, e.key, "MQTT listener is bound to all interfaces ("+e.key+" = "+e.value+") and no TLS listener exists in this config: traffic is reachable from every network and travels unencrypted.",
          "Bind the plaintext listener to a restricted address or disable it, and add an SSL/TLS listener (port 8883) for external clients.");
      } else {
        add("WARNING", e.line, e.key, "Plaintext MQTT listener is bound to all interfaces ("+e.key+" = "+e.value+") alongside a TLS listener: clients can still connect unencrypted.",
          "Restrict the plaintext listener to localhost / a private interface, or disable it so clients must use TLS.");
      }
    }
  });

  // --- verify_peer disabled on TLS listeners ---
  entries.forEach(function(e){
    if(e.keyLower.indexOf("verify_peer")!==-1 || e.keyLower.indexOf("verify")!==-1){
      var v = e.value.toLowerCase();
      if(isFalse(e.value) || v==="verify_none" || v==="disable" || v==="disabled"){
        add("WARNING", e.line, e.key, "TLS peer verification is disabled ("+e.key+"): the broker will accept certificates it cannot verify, weakening client-certificate authentication.",
          "Set verify_peer to verify_peer and provide a CA certificate file so client certificates are checked.");
      }
    }
  });

  // --- Dashboard exposure ---
  var dashBinds = entries.filter(function(e){ return e.keyLower.indexOf("dashboard")!==-1 && e.value.indexOf("0.0.0.0")!==-1; });
  dashBinds.forEach(function(e){
    add("HIGH", e.line, e.key, "Dashboard listener is bound to all interfaces ("+e.key+" = "+e.value+"): the admin console is reachable from every network that can route to this host.",
      "Bind the dashboard to 127.0.0.1 or a private management address, and reach it through a VPN or SSH tunnel.");
  });
  var dashPresent = hasKey("dashboard");
  var dashTls = entries.some(function(e){ return e.keyLower.indexOf("dashboard")!==-1 && (e.keyLower.indexOf("https")!==-1 || e.keyLower.indexOf("ssl")!==-1 || e.keyLower.indexOf("tls")!==-1); });
  if(dashPresent && !dashTls){
    var firstDash = findKeys("dashboard")[0];
    add("WARNING", firstDash.line, firstDash.key, "Dashboard appears to be served over plain HTTP with no dashboard TLS/HTTPS listener in this config: admin credentials and session tokens cross the network unencrypted.",
      "Serve the dashboard over HTTPS (dashboard HTTPS listener with a certificate), or keep it on localhost only.");
  }

  // --- Plaintext secrets (value never reported) ---
  entries.forEach(function(e){
    if(!isSecretKey(e.keyLower)) return;
    if(isEnvSub(e.valueRaw)) return;
    if(e.value==="") return;
    var len = e.value.length;
    var isDefault = DEFAULT_SECRETS.indexOf(e.value.toLowerCase())!==-1;
    if(isDefault || len<8){
      add("BLOCKER", e.line, e.key, "Secret in key \""+e.key+"\" is a plaintext "+(isDefault?"example/default":"very short")+" value (length "+len+" only; the value is never shown): it can be guessed or is publicly known.",
        "Replace it with a unique value of at least 16 characters supplied through an environment variable, e.g. "+e.key+" = ${ENV_VAR}.");
    } else if(len<12){
      add("HIGH", e.line, e.key, "Secret in key \""+e.key+"\" is plaintext and short (length "+len+" only; the value is never shown).",
        "Use a unique value of at least 16 characters supplied through an environment variable, e.g. "+e.key+" = ${ENV_VAR}.");
    } else {
      add("HIGH", e.line, e.key, "Secret in key \""+e.key+"\" is stored as a plaintext literal (length "+len+" only; the value is never shown): anyone who reads this file learns it.",
        "Move it out of the file into an environment variable, e.g. "+e.key+" = ${ENV_VAR}, and rotate the exposed value.");
    }
  });

  // --- Node cookie / clustering ---
  var cookieEntries = entries.filter(function(e){ return isCookieKey(e.keyLower); });
  if(cookieEntries.length===0){
    add("HIGH", null, null, "No Erlang node cookie is stated: clustered nodes either cannot join, or fall back to a well-known default cookie that lets any Erlang node join the cluster.",
      "Set node.cookie to a long, unique, private value (supplied via environment variable) that is identical on every cluster node.");
  } else {
    cookieEntries.forEach(function(e){
      if(isEnvSub(e.valueRaw)){
        add("INFO", e.line, e.key, "Node cookie is supplied by environment substitution, not written in the file.", "No change needed; keep the real cookie value out of the config file.");
        return;
      }
      var len = e.value.length;
      var isDefault = DEFAULT_SECRETS.indexOf(e.value.toLowerCase())!==-1;
      if(isDefault || len<12){
        add("HIGH", e.line, e.key, "Node cookie in key \""+e.key+"\" is "+(isDefault?"a known default":"too short")+" (length "+len+" only; the value is never shown): anyone who knows or guesses it can join the Erlang cluster.",
          "Set a unique cookie of at least 20 random characters, supplied via environment variable, identical on every node, and rotate it if it was ever shared.");
      } else {
        add("WARNING", e.line, e.key, "Node cookie in key \""+e.key+"\" is a plaintext literal in the file (length "+len+" only; the value is never shown).",
          "Move the cookie into an environment variable, e.g. "+e.key+" = ${EMQX_NODE_COOKIE}.");
      }
    });
  }
  if(!hasKey("discovery")){
    add("INFO", null, null, "Cluster discovery strategy: NOT STATED in the paste, so how nodes find each other cannot be judged.",
      "If this broker clusters, state the discovery strategy explicitly (static, DNS, etcd, …) so it can be reviewed.");
  }

  // --- max_connections / rate limiting ---
  var mcEntries = findKeys("max_connections");
  if(mcEntries.length===0){
    add("INFO", null, null, "max_connections: NOT STATED in the paste, so the connection ceiling cannot be judged.",
      "Set an explicit max_connections per listener sized to the host, so a connection flood cannot exhaust the broker.");
  } else {
    mcEntries.forEach(function(e){
      var v = e.value.toLowerCase();
      var num = parseInt(e.value,10);
      if(v==="infinity" || v==="unlimited" || v==="0" || (!isNaN(num) && num>100000)){
        add("WARNING", e.line, e.key, "max_connections is effectively unbounded ("+e.key+" = "+e.value+"): a connection flood can exhaust file descriptors and memory.",
          "Set a finite max_connections sized to the host (and pair it with a connection rate limit).");
      }
    });
  }
  var rlEntries = entries.filter(function(e){ return e.keyLower.indexOf("rate_limit")!==-1 || e.keyLower.indexOf("ratelimit")!==-1 || e.keyLower.indexOf("limiter")!==-1; });
  if(rlEntries.length===0 && !hasKey("overload")){
    add("INFO", null, null, "Rate limiting: NOT STATED in the paste, so connection / message rate protection cannot be judged.",
      "Configure listener rate limits (max connection rate and message rate) so one client cannot flood the broker.");
  } else {
    rlEntries.forEach(function(e){
      if(isFalse(e.value) || e.value==="0"){
        add("WARNING", e.line, e.key, "Rate limiting is disabled or zero ("+e.key+" = "+e.value+").",
          "Set a positive connection / message rate limit appropriate for your clients.");
      }
    });
  }

  // --- TLS posture note when listeners exist but no TLS at all and not already covered ---
  var anyListener = hasKey("listener");
  if(anyListener && tlsPresent){
    add("INFO", null, null, "A TLS listener is present in this config.", "No change needed.");
  }

  // --- Not parsed lines ---
  parsed.notParsed.forEach(function(np){
    add("INFO", np.line, null, "NOT PARSED: line "+np.line+" is not a recognizable key = value setting, so it was not graded.",
      "Check the line for a missing \"=\" or a typo; settings on unparsed lines are not in effect as written.");
  });

  var order = {BLOCKER:0, HIGH:1, WARNING:2, INFO:3};
  findings.sort(function(a,b){
    if(order[a.severity]!==order[b.severity]) return order[a.severity]-order[b.severity];
    var la = a.line==null?99999:a.line, lb = b.line==null?99999:b.line;
    return la-lb;
  });
  var counts = {BLOCKER:0,HIGH:0,WARNING:0,INFO:0};
  findings.forEach(function(f){ counts[f.severity]++; });

  var verdict, note;
  if(counts.BLOCKER>0){
    verdict = "DO NOT DEPLOY";
    note = counts.BLOCKER+" blocker(s) must be fixed before this broker is exposed to any network.";
  } else if(counts.HIGH>0 || counts.WARNING>0){
    verdict = "DEPLOY WITH FIXES";
    note = "No blockers, but "+(counts.HIGH+counts.WARNING)+" high/warning finding(s) should be fixed before production use.";
  } else {
    verdict = "SAFE TO DEPLOY";
    note = "No blocker, high, or warning findings in the pasted settings. This grades the pasted text only — it does not prove a running broker is secure.";
  }
  return {verdict:verdict, findings:findings, counts:counts, note:note};
}

function buildTextReport(r){
  var out = [];
  out.push("J-Dawgs EMQX Broker Config Safety Auditor - Report");
  out.push("Verdict: "+r.verdict);
  out.push("Counts: BLOCKER "+r.counts.BLOCKER+" | HIGH "+r.counts.HIGH+" | WARNING "+r.counts.WARNING+" | INFO "+r.counts.INFO);
  out.push("Note: "+r.note);
  out.push("Secrets are reported by key name, line, and value length only - values never appear in this report.");
  out.push("");
  if(r.findings.length===0){ out.push("No findings."); }
  r.findings.forEach(function(f,i){
    out.push((i+1)+". ["+f.severity+"] Line "+(f.line==null?"not stated":f.line)+(f.key?" | Key: "+f.key:""));
    out.push("   "+f.message);
    out.push("   Fix: "+f.fix);
  });
  return out.join("\n");
}
function buildJsonReport(r){
  return JSON.stringify({
    tool:"J-Dawgs EMQX Broker Config Safety Auditor",
    verdict:r.verdict,
    counts:r.counts,
    note:r.note,
    secretHandling:"Secrets are reported by key name, line, and value length only; secret values never appear in this report.",
    findings:r.findings.map(function(f){
      return {severity:f.severity, line:f.line, key:f.key, message:f.message, fix:f.fix};
    })
  }, null, 2);
}
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-emqx-broker-config-safety-auditor',
  name: 'J-Dawgs EMQX Broker Config Safety Auditor',
  description: 'Grades a pasted EMQX MQTT broker config fully offline — listener and dashboard exposure, authentication posture, and TLS all graded, with secrets shown by name, line, and length only — into one deploy verdict: SAFE TO DEPLOY / DEPLOY WITH FIXES / DO NOT DEPLOY.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
