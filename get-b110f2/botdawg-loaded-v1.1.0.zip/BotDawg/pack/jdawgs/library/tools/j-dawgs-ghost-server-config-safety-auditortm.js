'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Ghost Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

var RISKY = [
'{',
'  "url": "http://blog.example.com",',
'  "server": {',
'    "port": 2368,',
'    "host": "0.0.0.0"',
'  },',
'  "database": {',
'    "client": "mysql",',
'    "connection": {',
'      "host": "127.0.0.1",',
'      "user": "ghost",',
'      "password": "short1",',
'      "database": "ghost_prod"',
'    }',
'  },',
'  "mail": {',
'    "transport": "SMTP",',
'    "options": {',
'      "service": "Mailgun",',
'      "auth": {',
'        "user": "postmaster@example.com",',
'        "pass": "mailpass"',
'      }',
'    }',
'  },',
'  "token": "changeme"',
'}'
].join('\n');

var HARDENED = [
'{',
'  "url": "https://blog.example.com",',
'  "admin": {',
'    "url": "https://admin.example.com"',
'  },',
'  "server": {',
'    "port": 2368,',
'    "host": "127.0.0.1"',
'  },',
'  "database": {',
'    "client": "mysql",',
'    "connection": {',
'      "host": "127.0.0.1",',
'      "user": "ghost",',
'      "password": "${DATABASE_PASSWORD}",',
'      "database": "ghost_prod"',
'    }',
'  },',
'  "mail": {',
'    "transport": "SMTP",',
'    "options": {',
'      "auth": {',
'        "user": "postmaster@example.com",',
'        "pass": "${MAIL_PASSWORD}"',
'      }',
'    }',
'  }',
'}'
].join('\n');

var PROSE = 'hello this is just a blog post about my day';
var EXAMPLE_WORDS = ['changeme','password','example','test','123456','letmein','admin123','secret123'];
var SEV_ORDER = {CRITICAL:0, HIGH:1, MEDIUM:2, LOW:3};

function isPlaceholder(v){
  if(typeof v !== 'string') return false;
  var s = v.trim();
  return s.indexOf('${') !== -1 || s.indexOf('process.env') !== -1 || /^\$[A-Za-z_][A-Za-z0-9_]*$/.test(s) || s.indexOf('{{') !== -1;
}
function isExampleValue(v){
  if(typeof v !== 'string') return false;
  var s = v.toLowerCase();
  for(var i=0;i<EXAMPLE_WORDS.length;i++){ if(s.indexOf(EXAMPLE_WORDS[i]) !== -1) return true; }
  return false;
}
function findLineSequential(lines, rawKey, startIdx){
  for(var i=startIdx;i<lines.length;i++){
    if(lines[i].indexOf('"'+rawKey+'"') !== -1) return i;
  }
  for(var j=0;j<lines.length;j++){
    if(lines[j].indexOf('"'+rawKey+'"') !== -1) return j;
  }
  return 0;
}
function flattenJSON(obj, prefix, rawKeyPath, out, lines, state){
  var keys = Object.keys(obj);
  for(var i=0;i<keys.length;i++){
    var k = keys[i];
    var val = obj[k];
    var path = prefix ? prefix + '.' + k : k;
    var rp = rawKeyPath.concat([k]);
    if(val !== null && typeof val === 'object' && !Array.isArray(val)){
      flattenJSON(val, path, rp, out, lines, state);
    } else {
      var idx = findLineSequential(lines, k, state.pos);
      state.pos = idx;
      out.push({key:path, rawKey:k, value: (val===null?'':String(val)), line: idx+1, isNum: typeof val==='number'});
    }
  }
}
function parseInput(raw){
  var lines = raw.split('\n');
  var trimmed = raw.trim();
  var entries = [];
  var format = 'unknown';
  var parseable = false;
  if(trimmed.charAt(0) === '{'){
    try{
      var obj = JSON.parse(trimmed);
      if(obj && typeof obj === 'object'){
        var state = {pos:0};
        flattenJSON(obj, '', [], entries, lines, state);
        format = 'json';
        parseable = entries.length > 0;
      }
    }catch(e){ parseable = false; format='json-invalid'; }
  }
  if(!parseable && format !== 'json'){
    var envEntries = [];
    for(var i=0;i<lines.length;i++){
      var line = lines[i].trim();
      if(!line || line.charAt(0)==='#') continue;
      var eq = line.indexOf('=');
      if(eq > 0){
        var key = line.slice(0,eq).trim();
        var val = line.slice(eq+1).trim();
        if((val.charAt(0)==='"' && val.charAt(val.length-1)==='"') || (val.charAt(0)==="'" && val.charAt(val.length-1)==="'")) val = val.slice(1,-1);
        if(/^[A-Za-z0-9_\.\-]+$/.test(key)){
          envEntries.push({key:key, rawKey:key, value:val, line:i+1, isNum:false});
        }
      }
    }
    if(envEntries.length >= 1){ entries = envEntries; format='env'; parseable = true; }
  }
  return {entries:entries, format:format, parseable:parseable, lines:lines};
}
function normKey(k){ return k.toLowerCase().replace(/__/g,'.').replace(/-/g,'_'); }
function audit(raw){
  var parsed = parseInput(raw);
  var entries = parsed.entries;
  var findings = [];
  function add(line, sev, key, msg, fix, len){
    var f = {line:line, severity:sev, key:key, message:msg, fix:fix};
    if(typeof len === 'number') f.valueLength = len;
    findings.push(f);
  }
  // Too few keys / prose
  var recognised = 0;
  var recogWords = ['url','server','database','mail','node_env','admin','host','port','client','connection','transport'];
  for(var r=0;r<entries.length;r++){
    var nk0 = normKey(entries[r].key);
    for(var w=0;w<recogWords.length;w++){ if(nk0.indexOf(recogWords[w])!==-1){ recognised++; break; } }
  }
  if(!parsed.parseable || entries.length < 2 || recognised < 1){
    return {verdict:'NOT ENOUGH TO GRADE', findings:[], counts:{CRITICAL:0,HIGH:0,MEDIUM:0,LOW:0}, format:parsed.format, entryCount:entries.length};
  }
  function findEntry(pred){
    for(var i=0;i<entries.length;i++){ if(pred(normKey(entries[i].key), entries[i])) return entries[i]; }
    return null;
  }
  function findAll(pred){
    var out=[]; for(var i=0;i<entries.length;i++){ if(pred(normKey(entries[i].key), entries[i])) out.push(entries[i]); } return out;
  }
  var urlEntry = findEntry(function(nk){ return nk==='url' || nk==='url'.toLowerCase(); });
  // top-level url: key exactly url or ends .url but not admin
  if(!urlEntry){
    var cands = findAll(function(nk){ return nk.slice(-4)==='.url' && nk.indexOf('admin')===-1; });
    if(cands.length) urlEntry = cands[0];
  }
  var adminEntry = findEntry(function(nk){ return nk.indexOf('admin')!==-1 && nk.indexOf('url')!==-1; });
  var hostEntry = findEntry(function(nk){ return nk.indexOf('server')!==-1 && nk.indexOf('host')!==-1; });
  var dbEntries = findAll(function(nk){ return nk.indexOf('database')!==-1; });
  var dbPassEntry = findEntry(function(nk){ return nk.indexOf('database')!==-1 && (nk.indexOf('password')!==-1 || nk.slice(-5)==='.pass' || nk.indexOf('pass')!==-1); });
  var mailPassEntry = findEntry(function(nk){ return nk.indexOf('mail')!==-1 && (nk.indexOf('pass')!==-1 || nk.indexOf('password')!==-1); });
  var nodeEnvEntry = findEntry(function(nk){ return nk==='node_env'; });
  var flaggedKeys = {};

  // URL
  if(!urlEntry){
    add(1,'LOW','url','Missing url — Ghost needs a public url to build links and serve the site.','Set url to your full public https address, e.g. the https form of your domain.');
  } else if(urlEntry.value.toLowerCase().indexOf('http://')===0){
    add(urlEntry.line,'HIGH','url','The url uses http:// instead of https:// — traffic, logins, and admin sessions would travel unencrypted.','Change url to https:// and put the site behind a valid TLS certificate / reverse proxy.');
  }
  // Server host
  if(hostEntry){
    var hv = hostEntry.value.trim();
    if(hv==='0.0.0.0' || hv==='::' || hv==='*' || hv.toLowerCase()==='all'){
      add(hostEntry.line,'HIGH',hostEntry.key,'Server host binds to all interfaces (all-interface bind) — Ghost would listen on every network interface.','Bind to 127.0.0.1 and expose Ghost only through a reverse proxy, unless you have a deliberate reason to bind wider.');
    }
  }
  // Database presence
  if(dbEntries.length===0){
    add(1,'LOW','database','Missing database section — no database client/connection keys were found.','Add a database section with client and connection settings; keep the password as an env reference.');
  }
  // DB password
  if(dbPassEntry && !isPlaceholder(dbPassEntry.value) && dbPassEntry.value.length>0){
    flaggedKeys[dbPassEntry.key+'@'+dbPassEntry.line]=true;
    var dl = dbPassEntry.value.length;
    if(isExampleValue(dbPassEntry.value)){
      add(dbPassEntry.line,'CRITICAL',dbPassEntry.key,'Database password is an example / guessable value in plaintext (length '+dl+'). Reported by key, line, and length only.','Replace it with a strong unique password supplied via an environment variable reference such as ${DATABASE_PASSWORD}.',dl);
    } else if(dl < 12){
      add(dbPassEntry.line,'HIGH',dbPassEntry.key,'Database password is in plaintext and short (length '+dl+', under 12). Reported by key, line, and length only.','Move it to an environment variable reference and use a password of at least 12 characters.',dl);
    } else if(dl < 32){
      add(dbPassEntry.line,'LOW',dbPassEntry.key,'Database password is present in plaintext (length '+dl+'). Reported by key, line, and length only.','Prefer an environment variable reference over a plaintext value in the config file.',dl);
    } else {
      add(dbPassEntry.line,'LOW',dbPassEntry.key,'Database password is present in plaintext but long (length '+dl+'). Reported by key, line, and length only.','Prefer an environment variable reference over a plaintext value in the config file.',dl);
    }
  }
  // Mail password
  if(mailPassEntry && !isPlaceholder(mailPassEntry.value) && mailPassEntry.value.length>0){
    flaggedKeys[mailPassEntry.key+'@'+mailPassEntry.line]=true;
    var ml = mailPassEntry.value.length;
    if(isExampleValue(mailPassEntry.value)){
      add(mailPassEntry.line,'CRITICAL',mailPassEntry.key,'Mail / SMTP auth password is an example / guessable value in plaintext (length '+ml+'). Reported by key, line, and length only.','Replace it and supply it via an environment variable reference such as ${MAIL_PASSWORD}.',ml);
    } else if(ml < 12){
      add(mailPassEntry.line,'HIGH',mailPassEntry.key,'Mail / SMTP auth password is in plaintext and short (length '+ml+', under 12). Reported by key, line, and length only.','Move it to an environment variable reference and rotate it to at least 12 characters.',ml);
    } else {
      add(mailPassEntry.line,'LOW',mailPassEntry.key,'Mail / SMTP auth password is present in plaintext (length '+ml+'). Reported by key, line, and length only.','Prefer an environment variable reference over a plaintext value in the config file.',ml);
    }
  }
  // Admin URL
  if(!adminEntry){
    add(1,'MEDIUM','admin__url','No admin URL separation — no admin url key was found, so the admin panel shares the public url.','Set admin__url (or admin url in JSON) to a separate https admin address if you separate admin traffic; otherwise note this as an accepted risk.');
  } else if(adminEntry.value.toLowerCase().indexOf('http://')===0){
    add(adminEntry.line,'HIGH',adminEntry.key,'Admin URL uses http:// instead of https:// — admin sessions would travel unencrypted.','Change the admin URL to https://.');
  }
  // NODE_ENV env-style only
  if(parsed.format==='env'){
    if(!nodeEnvEntry){
      add(1,'MEDIUM','NODE_ENV','NODE_ENV is missing in this env-style config — Ghost may not run in production mode.','Set NODE_ENV=production for a production deploy.');
    } else if(nodeEnvEntry.value.trim().toLowerCase()!=='production'){
      add(nodeEnvEntry.line,'MEDIUM',nodeEnvEntry.key,'NODE_ENV is not set to production.','Set NODE_ENV=production for a production deploy.');
    }
  }
  // Generic secret-like
  for(var g=0; g<entries.length; g++){
    var e = entries[g];
    var nk = normKey(e.key);
    var isSecretKey = nk.indexOf('password')!==-1 || nk.indexOf('secret')!==-1 || nk.indexOf('token')!==-1 || nk.indexOf('auth')!==-1 || nk.indexOf('pass')!==-1;
    if(!isSecretKey) continue;
    if(flaggedKeys[e.key+'@'+e.line]) continue;
    if(isPlaceholder(e.value) || e.value.length===0) continue;
    // skip auth user / auth object non-secret subkeys like mail auth user already not pass; user key doesn't contain those words except auth in path
    // mail...auth.user contains 'auth' — its value is a username, not a secret. Skip keys ending in .user / .username
    if(nk.slice(-5)==='.user' || nk.slice(-9)==='.username' || nk.slice(-5)==='_user') continue;
    var vl = e.value.length;
    if(isExampleValue(e.value)){
      add(e.line,'CRITICAL',e.key,'Secret-like value is an example / guessable value (length '+vl+'). Reported by key, line, and length only.','Replace it with a strong unique value supplied via an environment variable reference.',vl);
    } else if(vl < 8){
      add(e.line,'HIGH',e.key,'Secret-like value is short (length '+vl+', under 8). Reported by key, line, and length only.','Use a longer unique value (12+ characters) supplied via an environment variable reference.',vl);
    }
  }

  findings.sort(function(a,b){
    if(SEV_ORDER[a.severity]!==SEV_ORDER[b.severity]) return SEV_ORDER[a.severity]-SEV_ORDER[b.severity];
    return a.line-b.line;
  });
  var counts={CRITICAL:0,HIGH:0,MEDIUM:0,LOW:0};
  for(var c=0;c<findings.length;c++) counts[findings[c].severity]++;

  var verdict;
  if(counts.CRITICAL>=1 || counts.HIGH>=2) verdict='DO NOT DEPLOY';
  else if(counts.HIGH>=1 || counts.MEDIUM>=1) verdict='DEPLOY WITH FIXES';
  else if(urlEntry && dbEntries.length>0) verdict='SAFE TO DEPLOY';
  else verdict='DEPLOY WITH FIXES';
  return {verdict:verdict, findings:findings, counts:counts, format:parsed.format, entryCount:entries.length};
}
function buildTextReport(result){
  var lines=[];
  lines.push('J-Dawgs Ghost Server Config Safety Auditor — Report');
  lines.push('Verdict: '+result.verdict);
  lines.push('Format detected: '+result.format+' | Config keys found: '+result.entryCount);
  lines.push('Counts: CRITICAL '+result.counts.CRITICAL+' | HIGH '+result.counts.HIGH+' | MEDIUM '+result.counts.MEDIUM+' | LOW '+result.counts.LOW+' | Total '+result.findings.length);
  lines.push('Secrets: reported by key name, line, and length only. No secret values are included in this report.');
  lines.push('--- Findings (sorted by severity) ---');
  if(result.findings.length===0) lines.push('No findings.');
  for(var i=0;i<result.findings.length;i++){
    var f=result.findings[i];
    var s='['+f.severity+'] Line '+f.line+' | Key: '+f.key;
    if(typeof f.valueLength==='number') s+=' | Value length: '+f.valueLength;
    s+=' | '+f.message+' | Fix: '+f.fix;
    lines.push(s);
  }
  return lines.join('\n');
}
function buildJsonReport(result){
  return JSON.stringify({tool:'J-Dawgs Ghost Server Config Safety Auditor', verdict:result.verdict, format:result.format, entryCount:result.entryCount, counts:result.counts, totalFindings:result.findings.length, secretHandling:'Secrets reported by key name, line, and length only. No secret values included.', findings:result.findings}, null, 2);
}
var lastResult=null, lastText='', lastJson='';
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_WORDS": (typeof EXAMPLE_WORDS !== 'undefined' ? EXAMPLE_WORDS : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-ghost-server-config-safety-auditortm',
  name: 'J-Dawgs Ghost Server Config Safety Auditor',
  description: '',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_WORDS": __core["EXAMPLE_WORDS"] }
};
