'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Fireplace Installation Proposal, Work Record & Final Invoice Consistency Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";
      var MINOR_LIMIT = 100;

      function round2(n){ return Math.round(n * 100) / 100; }
      function fmt(n){
        if (n === null || n === undefined || isNaN(n)) return "—";
        var neg = n < 0; var v = Math.abs(round2(n));
        var s = v.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        return (neg ? "-$" : "$") + s;
      }
      function fmtNum(n){
        var v = round2(n);
        return (v % 1 === 0) ? String(v) : String(v);
      }
      function parseAmount(s){
        if (s === null || s === undefined) return NaN;
        var t = String(s).replace(/[$,\s]/g, "");
        if (t === "") return NaN;
        var v = parseFloat(t);
        return isNaN(v) ? NaN : v;
      }
      function keyOf(name){ return name.trim().toLowerCase().replace(/\s+/g, " "); }

      function parseDoc(text){
        var doc = { items: [], depositPaid: null, depositCredit: null, errors: [], hasContent: false };
        if (!text || !text.trim()) return doc;
        var lines = text.split(/\r?\n/);
        var saw = false;
        for (var i = 0; i < lines.length; i++){
          var raw = lines[i];
          var line = raw.trim();
          if (line === "" || line.charAt(0) === "#") continue;
          saw = true;
          var dm = line.match(/^deposit\s+(paid|credit)\s*:\s*(.+)$/i);
          if (dm){
            var amt = parseAmount(dm[2]);
            if (isNaN(amt)){ doc.errors.push("Line " + (i + 1) + ": deposit amount could not be read — “" + line + "”"); continue; }
            if (dm[1].toLowerCase() === "paid") doc.depositPaid = amt; else doc.depositCredit = amt;
            continue;
          }
          var parts = null;
          if (line.indexOf("—") >= 0) parts = line.split("—");
          else if (line.indexOf("–") >= 0) parts = line.split("–");
          else if (line.indexOf(" - ") >= 0) parts = line.split(" - ");
          if (!parts || parts.length !== 3){
            doc.errors.push("Line " + (i + 1) + ": not in “Item — Qty — Unit price” format — “" + line + "”");
            continue;
          }
          var name = parts[0].trim();
          var qty = parseAmount(parts[1]);
          var price = parseAmount(parts[2]);
          if (name === "" || isNaN(qty) || isNaN(price)){
            doc.errors.push("Line " + (i + 1) + ": name, quantity, or unit price could not be read — “" + line + "”");
            continue;
          }
          doc.items.push({ name: name, key: keyOf(name), qty: qty, price: price, total: round2(qty * price), lineNo: i + 1 });
        }
        doc.hasContent = saw && (doc.items.length > 0 || doc.depositPaid !== null || doc.depositCredit !== null);
        return doc;
      }

      function groupItems(items){
        var map = {}; var order = [];
        for (var i = 0; i < items.length; i++){
          var it = items[i];
          if (!map[it.key]){ map[it.key] = { name: it.name, key: it.key, lines: [], totalQty: 0, total: 0 }; order.push(it.key); }
          map[it.key].lines.push(it);
          map[it.key].totalQty += it.qty;
          map[it.key].total = round2(map[it.key].total + it.total);
        }
        return { map: map, order: order };
      }
      function docTotal(doc){
        var t = 0; for (var i = 0; i < doc.items.length; i++) t += doc.items[i].total;
        return round2(t);
      }

      function audit(propText, workText, invText){
        var prop = parseDoc(propText), work = parseDoc(workText), inv = parseDoc(invText);
        var missing = [];
        if (!prop.hasContent) missing.push("Proposal");
        if (!work.hasContent) missing.push("Work Record");
        if (!inv.hasContent) missing.push("Final Invoice");

        var propG = groupItems(prop.items), workG = groupItems(work.items), invG = groupItems(inv.items);
        var workPresent = work.hasContent, invPresent = inv.hasContent;

        var findings = { qty: [], labor: [], deposit: [], dup: [], only: [] };
        var cQty = 0, cLabor = 0, cDeposit = 0, cDup = 0, cOnly = 0;

        /* Invoice-only set (check 5) — decided first so nothing double-counts. */
        var onlyKeys = {};
        if (invPresent){
          for (var oi = 0; oi < invG.order.length; oi++){
            var ok = invG.order[oi];
            if (ok === "labor") continue;
            if (!propG.map[ok] && !workG.map[ok]) onlyKeys[ok] = true;
          }
        }

        /* Check 4 — duplicates (Labor excluded: labor is settled by check 2 alone). */
        var dupKeys = {};
        if (invPresent){
          for (var di = 0; di < invG.order.length; di++){
            var dk = invG.order[di];
            if (dk === "labor" || onlyKeys[dk]) continue;
            var g = invG.map[dk];
            if (g.lines.length > 1){
              dupKeys[dk] = true;
              for (var dl = 1; dl < g.lines.length; dl++){
                var ln = g.lines[dl];
                cDup = round2(cDup + ln.total);
                findings.dup.push(g.name + ", duplicate line " + (dl + 1) + " (invoice line " + ln.lineNo + "): " + fmtNum(ln.qty) + " × " + fmt(ln.price) + " = " + fmt(ln.total) + " charged again.");
              }
            }
          }
        }

        /* Check 5 — invoice-only fees: full billed total. */
        if (invPresent){
          for (var fi = 0; fi < invG.order.length; fi++){
            var fk = invG.order[fi];
            if (!onlyKeys[fk]) continue;
            var fg = invG.map[fk];
            cOnly = round2(cOnly + fg.total);
            var partsTxt = [];
            for (var fl = 0; fl < fg.lines.length; fl++) partsTxt.push(fmtNum(fg.lines[fl].qty) + " × " + fmt(fg.lines[fl].price));
            findings.only.push(fg.name + ": " + partsTxt.join(" + ") + " = " + fmt(fg.total) + " billed, and it appears in neither the Proposal nor the Work Record.");
          }
        }

        /* Check 1 — quantities billed above installed (needs the Work Record). */
        if (invPresent && workPresent){
          for (var qi = 0; qi < invG.order.length; qi++){
            var qk = invG.order[qi];
            if (qk === "labor" || dupKeys[qk] || onlyKeys[qk]) continue;
            var qg = invG.map[qk];
            var wrQty = workG.map[qk] ? workG.map[qk].totalQty : 0;
            var excess = round2(qg.totalQty - wrQty);
            if (excess > 0){
              var unit = qg.lines[0].price;
              var amt = round2(excess * unit);
              cQty = round2(cQty + amt);
              findings.qty.push(qg.name + ": billed " + fmtNum(qg.totalQty) + ", installed per Work Record " + fmtNum(wrQty) + " → excess " + fmtNum(excess) + " × " + fmt(unit) + " = " + fmt(amt) + ".");
            }
          }
        }

        /* Check 2 — labor billed above work-record hours × rate. */
        var laborDetail = null;
        if (invPresent && workPresent){
          var invLabor = invG.map["labor"], workLabor = workG.map["labor"];
          var billed = invLabor ? invLabor.total : 0;
          var correct = workLabor ? workLabor.total : 0;
          if (invLabor || workLabor){
            laborDetail = { billed: billed, correct: correct,
              billedTxt: invLabor ? fmtNum(invLabor.totalQty) + " hrs × " + fmt(invLabor.lines[0].price) + " = " + fmt(billed) : "no Labor line on the invoice = " + fmt(0),
              correctTxt: workLabor ? fmtNum(workLabor.totalQty) + " hrs × " + fmt(workLabor.lines[0].price) + " = " + fmt(correct) : "no Labor line on the Work Record = " + fmt(0) };
            if (billed > correct){
              cLabor = round2(billed - correct);
              findings.labor.push("Labor billed " + laborDetail.billedTxt + "; Work Record shows " + laborDetail.correctTxt + " → " + fmt(billed) + " − " + fmt(correct) + " = " + fmt(cLabor) + " overbilled.");
            }
          }
        }

        /* Check 3 — uncredited deposit. */
        var paidVals = [];
        if (prop.depositPaid !== null) paidVals.push(prop.depositPaid);
        if (work.depositPaid !== null) paidVals.push(work.depositPaid);
        var depositPaid = paidVals.length ? Math.max.apply(null, paidVals) : null;
        var depositCredit = inv.depositCredit !== null ? inv.depositCredit : (invPresent ? 0 : null);
        if (depositPaid !== null && depositCredit !== null && depositPaid > depositCredit){
          cDeposit = round2(depositPaid - depositCredit);
          findings.deposit.push("Deposit paid " + fmt(depositPaid) + " − deposit credit on the invoice " + fmt(depositCredit) + " = " + fmt(cDeposit) + " never credited back.");
        }

        var total = round2(cQty + cLabor + cDeposit + cDup + cOnly);

        /* Reconciliation: claimed due vs correct due. */
        var invTotal = docTotal(inv);
        var claimedDue = invPresent ? round2(invTotal - (depositCredit || 0)) : null;
        var correctCharges = workPresent ? docTotal(work) : null;
        var correctDue = (workPresent && depositPaid !== null) ? round2(correctCharges - depositPaid)
          : (workPresent ? correctCharges : null);
        var reconDiff = (claimedDue !== null && correctDue !== null) ? round2(claimedDue - correctDue) : null;

        var parseErrors = []
          .concat(prop.errors.map(function(e){ return "Proposal — " + e; }))
          .concat(work.errors.map(function(e){ return "Work Record — " + e; }))
          .concat(inv.errors.map(function(e){ return "Final Invoice — " + e; }));

        var verdict, vclass;
        if (missing.length > 0){ verdict = "PAY WITH FIXES"; vclass = "fixes"; }
        else if (total === 0 && parseErrors.length === 0){ verdict = "SAFE TO PAY"; vclass = "safe"; }
        else if (total === 0){ verdict = "PAY WITH FIXES"; vclass = "fixes"; }
        else if (total <= MINOR_LIMIT){ verdict = "PAY WITH FIXES"; vclass = "fixes"; }
        else { verdict = "DO NOT PAY YET"; vclass = "donot"; }

        return {
          missing: missing, verdict: verdict, vclass: vclass, total: total,
          components: [
            { n: 1, name: "Quantities billed above installed", amount: cQty, lines: findings.qty },
            { n: 2, name: "Labor billed above hours × rate", amount: cLabor, lines: findings.labor },
            { n: 3, name: "Uncredited deposit", amount: cDeposit, lines: findings.deposit },
            { n: 4, name: "Duplicate charges", amount: cDup, lines: findings.dup },
            { n: 5, name: "Invoice-only fees", amount: cOnly, lines: findings.only }
          ],
          invTotal: invPresent ? invTotal : null,
          depositPaid: depositPaid, depositCredit: depositCredit,
          claimedDue: claimedDue, correctCharges: correctCharges, correctDue: correctDue, reconDiff: reconDiff,
          parseErrors: parseErrors,
          workPresent: workPresent, invPresent: invPresent
        };
      }

      function esc(s){ return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-fireplace-installation-proposal-work-record-final-invoice-consistency-auditortm',
  name: 'J-Dawgs Fireplace Installation Proposal, Work Record & Final Invoice Consistency Auditor',
  description: '',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
