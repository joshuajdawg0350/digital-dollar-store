'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Headscale Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var RISKY = [
        "# RISKY demo config — fake values only, do not deploy",
        "server_url: http://headscale.example.com:8080",
        "listen_addr: 0.0.0.0:8080",
        "metrics_listen_addr: 0.0.0.0:9090",
        "debug_listen_addr: 0.0.0.0:6060",
        "log:",
        "  level: debug",
        "noise:",
        "  private_key: \"DEMO-NOISE-PRIVATE-KEY-DO-NOT-USE-0123456789\"",
        "derp:",
        "  auto_update_enabled: true",
        "  server:",
        "    enabled: true",
        "    stun_listen_addr: 0.0.0.0:3478",
        "oidc:",
        "  issuer: http://idp.example.com",
        "  client_id: headscale",
        "  client_secret: \"demo123\"",
        "database:",
        "  type: postgres",
        "  postgres:",
        "    host: db.internal",
        "    pass: \"demo-db-pass-123\"",
        "prefixes:",
        "  v4: 100.64.0.0/10",
        "  v6: fd7a:115c:a1e0::/48",
        "# legacy list left in place — overlaps the prefixes above",
        "ip_prefixes:",
        "  - 100.96.0.0/11",
        "  - fd7a:115c:a1e0:8000::/49"
      ].join("\n");

      var HARDENED = [
        "# HARDENED demo config — fake values only",
        "server_url: https://headscale.example.com",
        "listen_addr: 127.0.0.1:8080",
        "metrics_listen_addr: 127.0.0.1:9090",
        "log:",
        "  level: info",
        "noise:",
        "  private_key_path: /var/lib/headscale/noise_private.key",
        "derp:",
        "  auto_update_enabled: false",
        "  server:",
        "    enabled: false",
        "oidc:",
        "  issuer: https://idp.example.com",
        "  client_id: headscale",
        "  client_secret_path: /run/secrets/headscale_oidc_secret",
        "database:",
        "  type: sqlite",
        "policy:",
        "  mode: file",
        "  path: /etc/headscale/policy.hujson",
        "prefixes:",
        "  v4: 100.64.0.0/10",
        "  v6: fd7a:115c:a1e0::/48",
        "dns:",
        "  magic_dns: true",
        "  base_domain: tail.example.com"
      ].join("\n");

      var $ = function(id){ return document.getElementById(id); };
      $("ex-risky").textContent = RISKY;
      $("ex-hardened").textContent = HARDENED;

      /* ---------- minimal YAML reader (line-based, keeps line numbers) ---------- */
      function stripVal(v){
        v = (v || "").trim();
        if (!v) return "";
        var q = v.charAt(0);
        if ((q === '"' || q === "'") && v.indexOf(q, 1) > 0) return v.slice(1, v.indexOf(q, 1));
        var h = v.indexOf(" #");
        if (h >= 0) v = v.slice(0, h);
        return v.trim();
      }

      function parseConfig(text){
        var lines = text.split(/\r?\n/);
        var entries = [];
        var stack = []; // {indent, path}
        lines.forEach(function(raw, idx){
          var lineNo = idx + 1;
          var t = raw.trim();
          if (!t || t.charAt(0) === "#") return;
          var indent = raw.match(/^ */)[0].length;
          var lm = t.match(/^-\s+(.*)$/);
          if (lm){
            var parent = stack.length ? stack[stack.length - 1].path : "";
            entries.push({ path: parent + "[]", key: "(list item)", value: stripVal(lm[1]), line: lineNo, listItem: true, parentPath: parent });
            return;
          }
          var m = t.match(/^([A-Za-z0-9_.\-]+)\s*:\s*(.*)$/);
          if (!m) return;
          var key = m[1];
          while (stack.length && stack[stack.length - 1].indent >= indent) stack.pop();
          var parentPath = stack.length ? stack[stack.length - 1].path : "";
          var path = parentPath ? parentPath + "." + key : key;
          var value = stripVal(m[2] || "");
          entries.push({ path: path, key: key, value: value, line: lineNo, listItem: false });
          if (value === "") stack.push({ indent: indent, path: path });
        });
        return { entries: entries, lineCount: lines.length };
      }

      function byPath(entries, path){
        for (var i = 0; i < entries.length; i++) if (entries[i].path === path) return entries[i];
        return null;
      }
      function bySuffix(entries, suffix){
        for (var i = 0; i < entries.length; i++) if (entries[i].path === suffix || entries[i].path.slice(-(suffix.length + 1)) === "." + suffix) return entries[i];
        return null;
      }
      function allInterfaces(v){
        if (!v) return false;
        var host = v.replace(/^\[/, "").split(":")[0];
        // value forms: 0.0.0.0:8080, :8080, [::]:8080, :::8080
        return v.indexOf("0.0.0.0") === 0 || v.charAt(0) === ":" || v.indexOf("[::]") === 0 || v.indexOf("::") === 0;
      }
      function isLocal(v){
        return /^(127\.0\.0\.1|localhost|\[::1\]|::1)/.test(v || "");
      }

      /* ---------- IP / CIDR math ---------- */
      function ipv4ToBig(ip){
        var p = ip.split(".");
        if (p.length !== 4) return null;
        var n = 0n;
        for (var i = 0; i < 4; i++){
          var o = Number(p[i]);
          if (!Number.isInteger(o) || o < 0 || o > 255 || p[i] === "") return null;
          n = (n << 8n) + BigInt(o);
        }
        return n;
      }
      function ipv6ToBig(ip){
        var halves = ip.split("::");
        if (halves.length > 2) return null;
        var left = halves[0] ? halves[0].split(":") : [];
        var right = halves.length === 2 && halves[1] ? halves[1].split(":") : [];
        if (halves.length === 1 && left.length !== 8) return null;
        var missing = 8 - left.length - right.length;
        if (missing < 0) return null;
        var parts = left.concat(Array(missing).fill("0"), right);
        if (parts.length !== 8) return null;
        var n = 0n;
        for (var i = 0; i < 8; i++){
          if (!/^[0-9a-fA-F]{1,4}$/.test(parts[i])) return null;
          n = (n << 16n) + BigInt(parseInt(parts[i], 16));
        }
        return n;
      }
      function parseCIDR(s){
        var bits = s.split("/");
        if (bits.length !== 2) return null;
        var is6 = bits[0].indexOf(":") >= 0;
        var base = is6 ? ipv6ToBig(bits[0]) : ipv4ToBig(bits[0]);
        var plen = Number(bits[1]);
        var max = is6 ? 128 : 32;
        if (base === null || !Number.isInteger(plen) || plen < 0 || plen > max) return null;
        var size = 1n << BigInt(max - plen);
        var start = base - (base % size);
        return { fam: is6 ? 6 : 4, start: start, end: start + size - 1n, raw: s };
      }

      /* ---------- the audit ---------- */
      var SEV_ORDER = { CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3, INFO: 4 };

      function audit(text){
        var parsed = parseConfig(text);
        var E = parsed.entries;
        var findings = [];
        var passes = [];
        function add(sev, entry, keyLabel, issue, fix, secretLen){
          findings.push({
            severity: sev,
            line: entry ? entry.line : null,
            key: keyLabel,
            issue: issue,
            fix: fix,
            secret: (secretLen != null) ? { key: keyLabel, line: entry ? entry.line : null, length: secretLen } : null
          });
        }

        /* server_url */
        var su = byPath(E, "server_url");
        if (!su || !su.value){
          add("HIGH", su, "server_url", "server_url is missing or empty — clients cannot be told a trustworthy control-server address.", "Set server_url to the full public https URL of this Headscale server.");
        } else if (/^http:\/\//i.test(su.value)){
          var host = su.value.replace(/^http:\/\//i, "").split(/[:\/]/)[0];
          if (host === "localhost" || host === "127.0.0.1"){
            add("MEDIUM", su, "server_url", "server_url uses plain http (localhost only). Fine on a bench, never in production — node keys and OIDC flows cross this URL.", "Use an https server_url for anything beyond a local test.");
          } else {
            add("CRITICAL", su, "server_url", "server_url uses plain http. The control URL is handed to every node; over http it can be intercepted or redirected, and OIDC sign-in rides on it.", "Serve Headscale over https (TLS certificate or a TLS-terminating reverse proxy) and set server_url to the https address.");
          }
        } else if (/^https:\/\//i.test(su.value)){
          passes.push("server_url uses https.");
        } else {
          add("HIGH", su, "server_url", "server_url does not start with https:// — its scheme is not a secure one.", "Set server_url to the full public https URL of this Headscale server.");
        }

        /* listen addresses */
        var la = byPath(E, "listen_addr");
        if (la && la.value && allInterfaces(la.value)){
          add("MEDIUM", la, "listen_addr", "listen_addr binds all interfaces. That is normal only when Headscale itself faces the network; if a reverse proxy fronts it, the raw port is reachable directly and bypasses the proxy.", "Bind to 127.0.0.1 when a reverse proxy fronts Headscale, or firewall the port deliberately.");
        } else if (la && la.value && isLocal(la.value)){
          passes.push("listen_addr is bound to localhost.");
        }
        var ma = byPath(E, "metrics_listen_addr");
        if (ma && ma.value && allInterfaces(ma.value)){
          add("CRITICAL", ma, "metrics_listen_addr", "The metrics endpoint binds all interfaces. Prometheus metrics expose node names, counts, and internal state to anyone who can reach the port.", "Bind metrics_listen_addr to 127.0.0.1 (localhost) and scrape it locally or over the tailnet.");
        } else if (ma && ma.value && isLocal(ma.value)){
          passes.push("metrics_listen_addr is bound to localhost.");
        }
        var da = byPath(E, "debug_listen_addr");
        if (da && da.value && allInterfaces(da.value)){
          add("CRITICAL", da, "debug_listen_addr", "The debug endpoint binds all interfaces. Go debug/pprof endpoints hand out goroutine dumps, memory profiles, and runtime internals.", "Bind debug_listen_addr to 127.0.0.1, or remove it entirely when you are not debugging.");
        } else if (da && da.value && isLocal(da.value)){
          passes.push("debug_listen_addr is bound to localhost.");
        } else if (!da){
          passes.push("No debug_listen_addr is configured.");
        }

        /* log level */
        var lvl = bySuffix(E, "log.level") || byPath(E, "log_level");
        if (lvl && /^(debug|trace)$/i.test(lvl.value)){
          add("MEDIUM", lvl, lvl.path, "Log level is \"" + lvl.value.toLowerCase() + "\". Debug logging on a control server is verbose enough to capture node keys, IPs, and auth-flow detail in plain log files.", "Run at info (or warn) in production; raise to debug only while troubleshooting, then set it back.");
        } else if (lvl && lvl.value){
          passes.push("Log level is " + lvl.value.toLowerCase() + ", not debug.");
        }

        /* DERP */
        var au = bySuffix(E, "derp.auto_update_enabled");
        if (au && /^true$/i.test(au.value)){
          add("MEDIUM", au, "derp.auto_update_enabled", "DERP map auto-update is on. The relay map can change underneath a running server with no review, pulling in relays you never vetted.", "Turn auto_update_enabled off and update the DERP map deliberately, on your schedule.");
        } else if (au){
          passes.push("DERP auto_update_enabled is off.");
        }
        var stun = bySuffix(E, "derp.server.stun_listen_addr");
        var derpOn = bySuffix(E, "derp.server.enabled");
        if (stun && stun.value && allInterfaces(stun.value) && derpOn && /^true$/i.test(derpOn.value)){
          add("MEDIUM", stun, "derp.server.stun_listen_addr", "The embedded DERP server's STUN listener binds all interfaces. STUN on UDP answers strangers' requests and can be used for reflection/amplification abuse.", "Only expose STUN if you deliberately run a public DERP relay; otherwise disable the embedded DERP server or restrict the port at the firewall.");
        }

        /* OIDC */
        var issuer = bySuffix(E, "oidc.issuer");
        if (issuer && /^http:\/\//i.test(issuer.value)){
          add("HIGH", issuer, "oidc.issuer", "The OIDC issuer URL uses plain http. Identity tokens are validated against an endpoint fetched over an insecure channel.", "Use the https issuer URL your identity provider publishes.");
        }
        var ocs = bySuffix(E, "oidc.client_secret");
        if (ocs && ocs.value){
          var len = ocs.value.length;
          if (len < 32){
            add("CRITICAL", ocs, "oidc.client_secret", "OIDC client_secret is stored in plaintext in this config AND is short (" + len + " characters — the value itself is never shown). A short secret is guessable; a plaintext one leaks with any copy of this file.", "Move the secret out of config.yaml into oidc.client_secret_path (a root-only file) or an environment-provided file, rotate it, and use a long random value (32+ characters).", len);
          } else {
            add("HIGH", ocs, "oidc.client_secret", "OIDC client_secret is stored in plaintext in this config (" + len + " characters — the value itself is never shown). Anyone who reads this file owns your identity-provider client.", "Move the secret into oidc.client_secret_path (a root-only file) and rotate the secret at the provider.", len);
          }
        } else if (bySuffix(E, "oidc.client_secret_path")){
          passes.push("OIDC client secret comes from a file (client_secret_path), not plaintext in the config.");
        }

        /* generic secret scan — values are never copied into findings */
        var secretKeyRe = /(^|_)(private_key|client_secret|password|passwd|pass|api_key|apikey|secret|token)$/i;
        E.forEach(function(e){
          if (e.listItem || !e.value) return;
          if (/_path$/i.test(e.key) || /_file$/i.test(e.key)) return;
          if (e.path === "oidc.client_secret") return; // handled above
          if (!secretKeyRe.test(e.key)) return;
          if (/^\$\{?[A-Za-z_][A-Za-z0-9_]*\}?$/.test(e.value)) { passes.push(e.path + " is an environment reference, not a stored value."); return; }
          var L = e.value.length;
          if (/private_key/i.test(e.key)){
            add("CRITICAL", e, e.path, "A private key is written inline in this config (" + L + " characters — the value itself is never shown). Private keys belong in root-only key files; in a config they get copied, backed up, and committed.", "Move the key into its own root-only file and point the matching *_path setting at it. Rotate the key — treat the inline copy as exposed.", L);
          } else {
            add("HIGH", e, e.path, "A secret value is stored in plaintext in this config (" + L + " characters — the value itself is never shown).", "Move it to a root-only file or environment-provided secret, and rotate it.", L);
          }
        });
        if (bySuffix(E, "noise.private_key_path")) passes.push("Noise private key is referenced by file path, not stored inline.");

        /* policy */
        var polPath = bySuffix(E, "policy.path") || byPath(E, "acl_policy_path");
        var polMode = bySuffix(E, "policy.mode");
        if (polMode && /^database$/i.test(polMode.value)){
          passes.push("ACL policy is managed in the database (policy.mode: database).");
        } else if (polPath && polPath.value){
          passes.push("An ACL policy file is configured.");
        } else if (polPath || polMode || byPath(E, "policy")){
          add("HIGH", polPath || polMode, "policy.path", "A policy section exists but no policy file path is set. Headscale can start with no ACL policy in force.", "Set policy.path to your policy file (or policy.mode: database) so an ACL policy is actually loaded at startup.");
        } else {
          add("MEDIUM", null, "policy", "No ACL policy is configured anywhere in this file (checked the whole config). Without a policy, Headscale's default posture decides who can reach what — and that default is permissive.", "Add a policy section (mode: file with a path, or mode: database) and load an ACL policy that says who can talk to what.");
        }

        /* prefixes + overlap */
        var cidrs = [];
        ["prefixes.v4", "prefixes.v6"].forEach(function(p){
          var e = byPath(E, p);
          if (e && e.value){
            e.value.replace(/^\[|\]$/g, "").split(",").forEach(function(s){
              s = s.trim(); if (s) cidrs.push({ raw: s, entry: e });
            });
          }
        });
        E.forEach(function(e){
          if (e.listItem && (e.parentPath === "ip_prefixes" || e.parentPath === "prefixes")) cidrs.push({ raw: e.value, entry: e });
        });
        var ranges = [];
        cidrs.forEach(function(c){
          var r = parseCIDR(c.raw);
          if (!r){
            add("HIGH", c.entry, c.entry.path.replace("[]", ""), "Prefix \"" + c.raw + "\" is not a valid CIDR range, so allocation from it is undefined.", "Fix the prefix to a valid CIDR, e.g. 100.64.0.0/10 or fd7a:115c:a1e0::/48.");
          } else ranges.push({ r: r, entry: c.entry });
        });
        for (var i = 0; i < ranges.length; i++){
          for (var j = i + 1; j < ranges.length; j++){
            var a = ranges[i], b = ranges[j];
            if (a.r.fam !== b.r.fam) continue;
            if (a.r.start <= b.r.end && b.r.start <= a.r.end){
              add("HIGH", b.entry, b.entry.path.replace("[]", ""), "IP prefixes overlap: " + a.r.raw + " (line " + a.entry.line + ") and " + b.r.raw + " (line " + b.entry.line + ") cover some of the same addresses. Nodes can be handed colliding IPs.", "Shrink or move one of the prefixes so the v" + a.r.fam + " ranges are fully separate.");
            }
          }
        }
        if (ranges.length >= 2 && !findings.some(function(f){ return /overlap/i.test(f.issue); })) passes.push("Configured IP prefixes do not overlap.");
        if (ranges.length === 0) add("MEDIUM", null, "prefixes", "No IP prefixes are configured (checked the whole config). Headscale needs v4/v6 prefixes to allocate node addresses.", "Set prefixes.v4 (e.g. 100.64.0.0/10) and prefixes.v6 (e.g. fd7a:115c:a1e0::/48).");

        /* DNS sanity */
        var md = bySuffix(E, "dns.magic_dns");
        var bd = bySuffix(E, "dns.base_domain") || byPath(E, "dns_config.base_domain");
        if (md && /^true$/i.test(md.value) && (!bd || !bd.value)){
          add("MEDIUM", md, "dns.magic_dns", "MagicDNS is on but no dns.base_domain is set, so node names have no domain to live under.", "Set dns.base_domain (e.g. tail.example.com) or turn MagicDNS off.");
        }

        findings.sort(function(x, y){ return (SEV_ORDER[x.severity] - SEV_ORDER[y.severity]) || ((x.line || 0) - (y.line || 0)); });
        var counts = { CRITICAL: 0, HIGH: 0, MEDIUM: 0, LOW: 0, INFO: 0 };
        findings.forEach(function(f){ counts[f.severity]++; });
        var verdict = counts.CRITICAL > 0 ? "DO NOT SERVE" : (findings.length > 0 ? "SERVE WITH FIXES" : "SAFE TO SERVE");
        return { verdict: verdict, findings: findings, passes: passes, counts: counts, keyCount: E.length, lineCount: parsed.lineCount };
      }

      /* ---------- rendering ---------- */
      var lastResult = null;
      var lastReport = "", lastJSON = "";

      function esc(s){
        return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
      }
      function buildReport(r){
        var out = [];
        out.push("J-Dawgs Headscale Server Config Safety Auditor — Report");
        out.push("Verdict: " + r.verdict);
        out.push("Findings: " + r.findings.length + " (Critical " + r.counts.CRITICAL + ", High " + r.counts.HIGH + ", Medium " + r.counts.MEDIUM + ", Low " + r.counts.LOW + ")");
        out.push("Scanned: " + r.lineCount + " lines, " + r.keyCount + " settings. Secrets are reported by key name, line, and length only — values are never included.");
        out.push("");
        if (!r.findings.length) out.push("No findings. Every check in this audit passed.");
        r.findings.forEach(function(f, i){
          out.push((i + 1) + ". [" + f.severity + "] " + f.key + (f.line ? " — line " + f.line : " — whole file"));
          out.push("   Issue: " + f.issue);
          out.push("   Fix: " + f.fix);
          if (f.secret) out.push("   Secret: key \"" + f.secret.key + "\", line " + f.secret.line + ", value length " + f.secret.length + " characters (value not shown).");
        });
        if (r.passes.length){
          out.push("");
          out.push("Checks that passed:");
          r.passes.forEach(function(p){ out.push("- " + p); });
        }
        return out.join("\n");
      }
      function buildJSON(r){
        return JSON.stringify({
          tool: "J-Dawgs Headscale Server Config Safety Auditor",
          verdict: r.verdict,
          counts: { critical: r.counts.CRITICAL, high: r.counts.HIGH, medium: r.counts.MEDIUM, low: r.counts.LOW, info: r.counts.INFO, total: r.findings.length },
          scanned: { lines: r.lineCount, settings: r.keyCount },
          secretsPolicy: "Secrets are reported by key name, line, and value length only. Secret values are never included.",
          findings: r.findings.map(function(f){
            var o = { severity: f.severity, line: f.line, key: f.key, issue: f.issue, fix: f.fix };
            if (f.secret) o.secret = { key: f.secret.key, line: f.secret.line, valueLength: f.secret.length };
            return o;
          }),
          passedChecks: r.passes
        }, null, 2);
      }

      function runAudit(){
        var text = $("cfg").value;
        if (!text.trim()){
          $("status").textContent = "Paste a config first — or load one of the worked examples.";
          return;
        }
        var r = audit(text);
        lastResult = r;
        lastReport = buildReport(r);
        lastJSON = buildJSON(r);
        var v = $("verdict");
        v.className = "verdict show " + (r.verdict === "SAFE TO SERVE" ? "safe" : (r.verdict === "DO NOT SERVE" ? "dont" : "fixes"));
        $("vlabel").textContent = r.verdict;
        $("vsummary").textContent = r.verdict === "SAFE TO SERVE"
          ? "Every check in this audit passed. Start it when you're ready."
          : r.verdict === "DO NOT SERVE"
            ? "Critical problems below would go live the moment this server starts. Fix them first."
            : "Nothing critical — but fix the items below before this config serves real nodes.";
        $("vcounts").innerHTML =
          "<span><strong>" + r.findings.length + "</strong> findings</span>" +
          "<span>Critical <strong>" + r.counts.CRITICAL + "</strong></span>" +
          "<span>High <strong>" + r.counts.HIGH + "</strong></span>" +
          "<span>Medium <strong>" + r.counts.MEDIUM + "</strong></span>" +
          "<span>Scanned <strong>" + r.lineCount + "</strong> lines · <strong>" + r.keyCount + "</strong> settings</span>";
        var fc = $("findings");
        if (!r.findings.length){
          fc.innerHTML = "<p>No findings — every check passed.</p>";
        } else {
          fc.innerHTML = r.findings.map(function(f){
            return "<div class=\"finding\"><div class=\"fhead\"><span class=\"sev " + f.severity + "\">" + f.severity + "</span>" +
              "<span class=\"fkey\">" + esc(f.key) + "</span>" +
              "<span class=\"fline\">" + (f.line ? "line " + f.line : "whole file") + "</span></div>" +
              "<p>" + esc(f.issue) + "</p>" +
              "<p class=\"fix\"><strong>Fix:</strong> " + esc(f.fix) + "</p></div>";
          }).join("");
        }
        $("passes").innerHTML = r.passes.length ? r.passes.map(function(p){ return "<li>" + esc(p) + "</li>"; }).join("") : "<li>None recorded.</li>";
        $("results-card").hidden = false;
        $("copystatus").textContent = "";
        $("status").textContent = "Audit complete — verdict: " + r.verdict + ".";
        v.scrollIntoView({ block: "nearest", behavior: "smooth" });
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-headscale-server-config-safety-auditor',
  name: 'J-Dawgs Headscale Server Config Safety Auditor',
  description: 'Host tools only tell you the daemon started; ours grades a pasted Headscale config.yaml offline into one serve verdict — all-interface listen addresses, plaintext vs TLS server URL, embedded private keys and secrets by key name/line/length only, and ACL/DERP posture.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
