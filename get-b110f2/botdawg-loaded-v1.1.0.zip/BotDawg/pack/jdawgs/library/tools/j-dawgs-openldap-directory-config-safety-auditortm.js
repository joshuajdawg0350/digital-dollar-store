'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs OpenLDAP Directory Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";
var $=function(id){return document.getElementById(id);};
var input=$("configInput"), reportOut=$("reportOut"), findingsArea=$("findingsArea"), resultArea=$("resultArea");
var styleBadge=$("styleBadge"), countBadge=$("countBadge"), statusMsg=$("statusMsg"), copyMsg=$("copyMsg"), pitchMsg=$("pitchMsg");

var RISKY=[
"# Risky worked example - FAKE values only, never use these",
"database mdb",
'suffix "dc=example,dc=org"',
'rootdn "cn=admin,dc=example,dc=org"',
"rootpw example-plaintext-secret",
"directory /var/lib/ldap",
"access to * by * read"
].join("\n");

var CLEAN=[
"dn: cn=config",
"objectClass: olcGlobal",
"olcTLSCertificateFile: /etc/ldap/tls/server.crt",
"olcTLSCertificateKeyFile: /etc/ldap/tls/server.key",
"olcTLSCACertificateFile: /etc/ldap/tls/ca.crt",
"olcTLSCipherSuite: HIGH:!aNULL:!MD5:!RC4",
"olcDisallows: bind_anon",
"olcRequires: authc",
"olcSizeLimit: 500",
"olcTimeLimit: 3600",
"",
"dn: olcDatabase={1}mdb,cn=config",
"objectClass: olcMdbConfig",
"olcSuffix: dc=example,dc=org",
"olcRootDN: cn=admin,dc=example,dc=org",
"olcRootPW: {SSHA}FAKEhashedExampleValueNotARealHash1234567890",
'olcAccess: to attrs=userPassword by self write by anonymous auth by dn="cn=admin,dc=example,dc=org" write by * none',
'olcAccess: to * by dn="cn=admin,dc=example,dc=org" write by users read by * none'
].join("\n");

function esc(s){return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");}
function stripQuotes(v){v=String(v||"").trim(); if(v.length>=2&&v.charAt(0)==='"'&&v.charAt(v.length-1)==='"')v=v.slice(1,-1); return v;}
function canon(key){var k=String(key||"").toLowerCase(); if(k.indexOf("olc")===0)k=k.slice(3); return k;}
function isHash(v){return /^\{(SSHA512|SSHA|SHA|SMD5|MD5|CRYPT|ARGON2|PBKDF2|BCRYPT|SHA512-CRYPT)\}/i.test(v);}

/* Build logical lines: LDIF continuations (leading single space) and slapd.conf
   indented "by ..." continuations join the previous logical line. */
function logicalLines(raw){
  var phys=raw.split(/\r?\n/); var out=[];
  for(var i=0;i<phys.length;i++){
    var line=phys[i]; var trimmed=line.trim();
    var startsWs=/^[ \t]/.test(line);
    if(startsWs && trimmed && out.length){
      var prev=out[out.length-1];
      if(prev.kind!=="comment" && prev.kind!=="blank"){
        /* In LDIF a continuation is exactly one leading space; in slapd.conf an
           indented continuation belongs to the rule above it. Join both. */
        prev.text=prev.text+" "+trimmed; prev.endLine=i+1; continue;
      }
    }
    if(!trimmed){out.push({startLine:i+1,endLine:i+1,text:"",kind:"blank"});continue;}
    if(trimmed.charAt(0)==="#"){out.push({startLine:i+1,endLine:i+1,text:trimmed,kind:"comment"});continue;}
    out.push({startLine:i+1,endLine:i+1,text:trimmed,kind:"line"});
  }
  return out;
}

function parseLogical(L){
  /* Returns {key, canon, value, isLDIF, base64} or null if unparseable. */
  var t=L.text;
  var m=t.match(/^([A-Za-z][A-Za-z0-9\-]*)\s*::\s*(.*)$/);
  if(m)return{key:m[1],canon:canon(m[1]),value:m[2].trim(),isLDIF:true,base64:true};
  m=t.match(/^([A-Za-z][A-Za-z0-9\-]*)\s*:\s*(.*)$/);
  if(m && /^(olc|dn$|objectclass)/i.test(m[1]) || (m && t.indexOf(":")>-1 && !/^\S+\s+\S/.test(t.split(":")[0]) && /^[A-Za-z][A-Za-z0-9\-]*:/.test(t))){
    /* LDIF attribute line: key followed by colon */
    if(m)return{key:m[1],canon:canon(m[1]),value:m[2].trim(),isLDIF:true,base64:false};
  }
  m=t.match(/^([A-Za-z][A-Za-z0-9_\-]*)\s+(.+)$/);
  if(m)return{key:m[1],canon:canon(m[1]),value:m[2].trim(),isLDIF:false,base64:false};
  m=t.match(/^([A-Za-z][A-Za-z0-9_\-]*):\s*(.*)$/);
  if(m)return{key:m[1],canon:canon(m[1]),value:m[2].trim(),isLDIF:true,base64:false};
  m=t.match(/^([A-Za-z][A-Za-z0-9_\-]*)$/);
  if(m)return{key:m[1],canon:canon(m[1]),value:"",isLDIF:false,base64:false,noValue:true};
  return null;
}

function parseACL(text,line){
  var targetMatch=text.match(/\bto\s+(.+?)(?=\s+by\s+|$)/i);
  var target=targetMatch?targetMatch[1].trim():"";
  var clauses=[]; var re=/\bby\s+(\S+)\s+([^\s]+)/gi; var cm;
  while((cm=re.exec(text))!==null){clauses.push({who:cm[1],access:cm[2]});}
  var lowTarget=target.toLowerCase();
  return{
    line:line,target:target,clauses:clauses,
    targetIsStar:lowTarget==="*"||/^attrs?\s*=\s*\*$/.test(lowTarget),
    targetIsUP:/userpassword/i.test(target),
    coversUP:/userpassword/i.test(target)||lowTarget==="*",
    hasBy:clauses.length>0
  };
}
function accessGrantsReadWrite(a){return /read|write|manage|add|delete/i.test(a)||/^=?[rw]/i.test(a)||a.toLowerCase()==="=rw"||a.toLowerCase()==="=rwx";}
function clauseIsBroad(c){return (c.who==="*"||/^anonymous$/i.test(c.who))&&accessGrantsReadWrite(c.access);}

function audit(raw){
  var res={state:"empty",style:null,findings:[],malformed:[],acls:[],counts:{BLOCKER:0,WARNING:0,INFO:0}};
  if(!raw||!raw.trim()){res.state="empty";return res;}
  var logical=logicalLines(raw);
  var parsed=[]; var ldifHints=0, slapdHints=0, knownHits=0;
  var known={access:1,rootdn:1,rootpw:1,tlscertificatefile:1,tlscacertificatefile:1,tlsciphersuite:1,tlscertificatekeyfile:1,database:1,suffix:1,disallow:1,disallows:1,require:1,requires:1,sizelimit:1,timelimit:1,referral:1,security:1,directory:1,index:1,include:1,moduleload:1,modulepath:1,pidfile:1,argsfile:1,loglevel:1,overlay:1};
  logical.forEach(function(L){
    if(L.kind!=="line")return;
    var p=parseLogical(L);
    if(!p){res.malformed.push({line:L.startLine,reason:"line does not match a known directive shape (key + value, or LDIF key: value)"});return;}
    p.line=L.startLine; p.rawText=L.text; parsed.push(p);
    if(p.isLDIF)ldifHints++; else slapdHints++;
    if(known[p.canon])knownHits++;
    if(/^olc/i.test(p.key))knownHits++;
    if(p.noValue && (p.canon==="rootpw"||p.canon==="rootdn"||p.canon==="access")){res.malformed.push({line:L.startLine,reason:p.key+" has no value — NOT PARSED as a usable directive"});}
  });
  if(knownHits===0){res.state="notaudited";return res;}
  res.state="audited";
  res.style=ldifHints>slapdHints?"cn=config LDIF":(slapdHints>0?"slapd.conf":"cn=config LDIF");
  res.parsed=parsed;

  function F(sev,line,title,detail){res.findings.push({severity:sev,line:line,title:title,detail:detail});}

  /* Collect */
  var rootdns=[],rootpws=[],certs=[],cas=[],ciphers=[],disallows=[],requires=[],sizelimits=[],timelimits=[],suffixes=[],referrals=[];
  parsed.forEach(function(p){
    var c=p.canon;
    if(c==="access"){var acl=parseACL(p.isLDIF?p.value:p.key+" "+p.value,p.line); /* for LDIF value already starts 'to ...'; for slapd rebuild full */
      if(!p.isLDIF){acl=parseACL("access "+p.value,p.line);} res.acls.push(acl); acl.parsed=p;}
    else if(c==="rootdn")rootdns.push(p);
    else if(c==="rootpw")rootpws.push(p);
    else if(c==="tlscertificatefile")certs.push(p);
    else if(c==="tlscacertificatefile"||c==="tlscacertificatepath")cas.push(p);
    else if(c==="tlsciphersuite")ciphers.push(p);
    else if(c==="disallow"||c==="disallows")disallows.push(p);
    else if(c==="require"||c==="requires")requires.push(p);
    else if(c==="sizelimit")sizelimits.push(p);
    else if(c==="timelimit")timelimits.push(p);
    else if(c==="suffix")suffixes.push(p);
    else if(c==="referral")referrals.push(p);
  });

  /* ACL checks */
  var plaintextRoot=false;
  rootpws.forEach(function(p){ if(!p.base64 && !isHash(stripQuotes(p.value))) plaintextRoot=true; });

  if(res.acls.length===0){
    F("WARNING",null,"No access rules found","No access / olcAccess rule was found in the pasted text. Without explicit rules, access falls back to server defaults — state the intended access explicitly before deploying.");
  }
  res.acls.forEach(function(acl){
    if(!acl.hasBy){res.malformed.push({line:acl.line,reason:"access rule has no 'by' clause — NOT PARSED as a complete ACL"});return;}
    acl.clauses.forEach(function(cl){
      if(clauseIsBroad(cl)){
        var whoLabel=cl.who==="*"?"* (everyone, including anonymous)":"anonymous";
        F("BLOCKER",acl.line,"ACL grants "+whoLabel+" "+cl.access+" access","Rule at line "+acl.line+" grants "+whoLabel+" '"+cl.access+"' to target '"+acl.target+"'. Anyone who can reach the directory — no login needed for the anonymous case — gets that access.");
      } else if(cl.who==="*"&&/auth/i.test(cl.access)&&acl.targetIsUP){
        /* anonymous auth on userPassword is the normal pattern - no finding here */
      }
    });
  });
  /* userPassword protection, first-match-wins */
  if(res.acls.length){
    var covering=res.acls.filter(function(a){return a.coversUP&&a.hasBy;});
    if(!covering.length){
      F("WARNING",null,"userPassword is not covered by any rule","No rule's target covers attrs=userPassword and no rule targets * , so password hashes fall back to defaults. Add an explicit restrictive userPassword rule before any broad rule.");
    }else{
      var first=covering[0];
      var firstBroad=first.clauses.some(clauseIsBroad);
      var firstIsUPRule=first.targetIsUP;
      var restrictiveUP=res.acls.filter(function(a){return a.targetIsUP&&!a.clauses.some(clauseIsBroad);})[0];
      if(firstBroad){
        F("BLOCKER",first.line,"userPassword is exposed by the first matching rule","OpenLDAP is first-match-wins: the first rule covering userPassword is the broad rule at line "+first.line+" (target '"+first.target+"'). Because it matches first, any protective userPassword rule later in the file never takes effect for those requests, and password hashes get the broad rule's access.");
      }else if(firstIsUPRule){
        F("INFO",first.line,"userPassword has a restrictive first rule","The first rule covering userPassword is the restrictive rule at line "+first.line+", and it grants no read/write to * or anonymous — the pattern a password attribute needs (self / anonymous auth only).");
      }else{
        F("INFO",first.line,"userPassword is covered by a non-broad first rule","The first rule covering userPassword (line "+first.line+", target '"+first.target+"') grants no read/write to * or anonymous.");
      }
      if(restrictiveUP && first!==restrictiveUP && !firstBroad){
        /* covered above generically */
      }
      if(restrictiveUP && first!==restrictiveUP && firstBroad){
        F("WARNING",restrictiveUP.line,"Protective userPassword rule is shadowed","A restrictive userPassword rule exists at line "+restrictiveUP.line+", but the broad rule at line "+first.line+" comes first. First-match-wins means the broad rule decides — move the userPassword rule above it.");
      }
    }
  }

  /* Root account */
  if(rootdns.length===0){
    F("INFO",null,"No rootdn found","No rootdn / olcRootDN was found in the pasted text. That can be fine (for example cn=config admin via SASL/EXTERNAL) — it is noted, not graded as a fault.");
  }
  rootdns.forEach(function(p){F("INFO",p.line,"Root DN present ("+p.key+")","Root DN declared at line "+p.line+". Its password handling is graded separately; the DN itself is not a secret.");});
  rootpws.forEach(function(p){
    var v=stripQuotes(p.value); var len=v.length;
    if(p.base64){F("INFO",p.line,"Root password is base64-encoded in LDIF ("+p.key+")","At line "+p.line+", "+p.key+" uses LDIF base64 encoding (length "+len+" characters as pasted). A text audit cannot see a hash prefix inside base64, so the hash grade is NOT SETTLED from this text — the value itself is never shown.");return;}
    if(isHash(v)){F("INFO",p.line,"Hashed root password ("+p.key+")","At line "+p.line+", "+p.key+" carries a hash prefix (length "+len+" characters) rather than plain text. The value is never shown in this report.");}
    else{F("BLOCKER",p.line,"Plaintext root password ("+p.key+")","At line "+p.line+", "+p.key+" is in PLAIN TEXT (length "+len+" characters — value never shown). Anyone who reads this file owns the directory root account. Replace it with a hashed value (for example a {SSHA} hash from slappasswd) and protect the file.");}
  });
  if(rootdns.length&&rootpws.length===0){
    F("INFO",rootdns[0].line,"Root DN with no root password in this text","A rootdn is present but no rootpw / olcRootPW appears in the pasted text — root authentication may be handled outside this file.");
  }

  /* TLS */
  var hasTLS=certs.length>0||cas.length>0;
  if(!hasTLS){
    if(plaintextRoot){F("BLOCKER",null,"No TLS certificate — and a plaintext root password is present","No TLSCertificateFile / olcTLSCertificateFile (and no CA file) was found, so there is no TLS certificate configured in this text and credentials may cross the wire in clear. That escalates to a BLOCKER here because a plaintext rootpw is also present in the same config.");}
    else{F("WARNING",null,"No TLS certificate configured","No TLSCertificateFile / olcTLSCertificateFile (and no olcTLSCACertificateFile) was found in the pasted text. Without TLS, bind credentials may cross the wire in clear unless the server is reached only over a protected channel (ldaps / StartTLS enforced elsewhere) — nothing in this text shows that.");}
  }else{
    certs.forEach(function(p){F("INFO",p.line,"TLS certificate file present ("+p.key+")","Declared at line "+p.line+". This audit checks that a certificate is named — it cannot verify the file exists or that the certificate is valid.");});
    cas.forEach(function(p){F("INFO",p.line,"TLS CA file present ("+p.key+")","Declared at line "+p.line+".");});
  }
  ciphers.forEach(function(p){
    var raw=p.value; var tokens=raw.split(":");
    var enabledWeak=[], warnWeak=[];
    tokens.forEach(function(tok){var t=tok.trim(); if(!t)return; if(t.charAt(0)==="!"||t.charAt(0)==="-")return;
      if(/EXPORT/i.test(t)||/\bNULL\b|aNULL|eNULL/i.test(t)||/SSLv3/i.test(t))enabledWeak.push(t);
      else if(/TLSv1\.0|TLSv1\.1/i.test(t)||/^TLSv1$/i.test(t))warnWeak.push(t);});
    if(!enabledWeak.length && !warnWeak.length && /(SSLv3|TLSv1\.0)/i.test(raw)){
      /* raw mentions but all negated or part of a floor expression like TLSv1.2+ ; check bare patterns */
      if(/(^|[^!\-\d\.])SSLv3/.test(raw))enabledWeak.push("SSLv3");
    }
    if(enabledWeak.length){F("BLOCKER",p.line,"Weak ciphers enabled in cipher suite ("+p.key+")","At line "+p.line+", the cipher suite enables: "+enabledWeak.join(", ")+". SSLv3, EXPORT, and NULL ciphers offer no real protection — remove them.");}
    else if(warnWeak.length){F("WARNING",p.line,"Outdated TLS versions in cipher suite ("+p.key+")","At line "+p.line+", the cipher suite names: "+warnWeak.join(", ")+". TLSv1.0 / TLSv1.1 are outdated — set a TLSv1.2-or-higher floor.");}
    else{F("INFO",p.line,"Cipher suite names no enabled weak ciphers ("+p.key+")","At line "+p.line+", no enabled SSLv3 / TLSv1.0 / EXPORT / NULL entries were found (negated entries count as disabled).");}
  });

  /* disallow / require — stated logic: correct value present = INFO good;
     directive present without the value = WARNING; absent = INFO note. */
  if(disallows.length){
    disallows.forEach(function(p){
      if(/bind_anon/i.test(p.value))F("INFO",p.line,"Anonymous bind explicitly disallowed ("+p.key+")","At line "+p.line+", bind_anon is disallowed — anonymous clients cannot bind at all.");
      else F("WARNING",p.line,"disallow present but bind_anon not disallowed ("+p.key+")","At line "+p.line+", a disallow / olcDisallows setting exists but does not include bind_anon, so anonymous bind is not switched off there.");
    });
  }else{
    F("INFO",null,"No disallow bind_anon in this text","Anonymous bind is not switched off by a disallow directive in the pasted text. That can still be safe if the ACLs grant anonymous nothing beyond auth — it is noted so the posture is a choice, not an accident.");
  }
  if(requires.length){
    requires.forEach(function(p){
      if(/\bauthc\b/i.test(p.value))F("INFO",p.line,"Authentication required ("+p.key+")","At line "+p.line+", authc is required — operations need an authenticated identity.");
      else F("WARNING",p.line,"require present but authc not required ("+p.key+")","At line "+p.line+", a require / olcRequires setting exists but does not include authc.");
    });
  }else{
    F("INFO",null,"No require authc in this text","No require authc was found. Noted under the same logic as disallow: present-and-correct is strongest; absent is an INFO note, not a fault by itself.");
  }

  /* Limits */
  if(!sizelimits.length)F("INFO",null,"No sizelimit set","No sizelimit / olcSizeLimit was found — search results are bounded only by defaults. Setting an explicit limit is a small hardening step.");
  if(!timelimits.length)F("INFO",null,"No timelimit set","No timelimit / olcTimeLimit was found — searches are bounded only by defaults.");

  /* Suffix / rootdn mismatch */
  if(suffixes.length&&rootdns.length){
    var suf=stripQuotes(suffixes[0].value).toLowerCase();
    var rd=stripQuotes(rootdns[0].value).toLowerCase();
    if(rd===suf||rd.slice(-(suf.length+1))===","+suf||rd.slice(-suf.length)===suf && rd.charAt(rd.length-suf.length-1)===","){
      F("INFO",rootdns[0].line,"Root DN sits inside the database suffix","The rootdn at line "+rootdns[0].line+" ends with the database suffix declared at line "+suffixes[0].line+" — they agree.");
    }else{
      F("WARNING",rootdns[0].line,"Root DN does not end with the database suffix","The rootdn at line "+rootdns[0].line+" does not end with the suffix declared at line "+suffixes[0].line+". A rootdn outside its database suffix is a common cause of a root bind that silently does not work as expected — check both values (values compared, suffix/rootdn are identifiers, not secrets).");
    }
  }
  /* Referrals */
  referrals.forEach(function(p){
    var v=stripQuotes(p.value);
    if(/^ldaps:\/\//i.test(v))F("INFO",p.line,"Referral uses ldaps:// ("+p.key+")","At line "+p.line+", the referral is encrypted (ldaps://).");
    else if(/^ldap:\/\//i.test(v))F("WARNING",p.line,"Referral points to plain ldap:// ("+p.key+")","At line "+p.line+", the referral sends clients to a plaintext ldap:// address — credentials following that referral may cross in clear. Prefer ldaps://.");
    else F("INFO",p.line,"Referral present ("+p.key+")","At line "+p.line+", a referral is declared; its scheme was not ldap:// or ldaps:// in the pasted text.");
  });

  /* Malformed */
  res.malformed.forEach(function(mn){F("WARNING",mn.line,"NOT PARSED — line "+mn.line,mn.reason+". That line contributed nothing to the grade.");});

  var order={BLOCKER:0,WARNING:1,INFO:2};
  res.findings.sort(function(a,b){if(order[a.severity]!==order[b.severity])return order[a.severity]-order[b.severity];return (a.line||99999)-(b.line||99999);});
  res.findings.forEach(function(f){res.counts[f.severity]++;});
  if(res.counts.BLOCKER)res.verdict="DO NOT DEPLOY";
  else if(res.counts.WARNING)res.verdict="DEPLOY WITH FIXES";
  else res.verdict="SAFE TO DEPLOY";
  return res;
}

function buildReport(res,raw){
  var lines=[];
  lines.push("J-Dawgs OpenLDAP Directory Config Safety Auditor(TM) - Report");
  lines.push("============================================================");
  if(res.state==="empty"){lines.push("No config was pasted. Nothing was audited and no verdict was produced.");return lines.join("\n");}
  if(res.state==="notaudited"){lines.push("Verdict: NOT AUDITED");lines.push("The pasted text was not recognized as a slapd.conf or a cn=config LDIF config (no known OpenLDAP directives were found). No verdict was fabricated.");return lines.join("\n");}
  lines.push("Verdict: "+res.verdict);
  lines.push("Style detected: "+res.style);
  lines.push("Counts: "+res.counts.BLOCKER+" BLOCKER, "+res.counts.WARNING+" WARNING, "+res.counts.INFO+" INFO");
  lines.push("");
  lines.push("How ACL order works: OpenLDAP evaluates access rules in file order and the");
  lines.push("first rule whose 'to' target matches a request decides it (first-match-wins).");
  lines.push("Later rules for the same target are not consulted for that request.");
  lines.push("");
  lines.push("Findings (line numbers refer to the pasted text):");
  if(!res.findings.length)lines.push("  (none)");
  res.findings.forEach(function(f){
    lines.push("  ["+f.severity+"] "+(f.line?("Line "+f.line+": "):"") + f.title);
    lines.push("      "+f.detail);
  });
  lines.push("");
  lines.push("Secret handling: root password values are never printed in this report -");
  lines.push("directive name, line, and length only.");
  lines.push("Limit: heuristic text audit of the pasted text only. It does not connect to");
  lines.push("a directory, does not test a live bind, and does not run slapd/slaptest.");
  return lines.join("\n");
}

function verdictClass(v){if(v==="SAFE TO DEPLOY")return"safe";if(v==="DEPLOY WITH FIXES")return"fixes";if(v==="DO NOT DEPLOY")return"no";return"none";}

function render(){
  var raw=input.value;
  var n=raw?raw.split(/\r?\n/).length:0;
  countBadge.textContent=n+(n===1?" line":" lines");
  var res=audit(raw);
  styleBadge.textContent="Style: "+(res.state==="audited"?res.style:(res.state==="notaudited"?"not recognized":"not detected yet"));
  if(res.state==="empty"){
    resultArea.innerHTML='<div class="verdict none"><div class="eyebrow" style="color:var(--muted)">No verdict</div><div class="vtitle">Paste a config to audit</div><p class="muted" style="margin:0">Nothing to grade yet — no verdict is produced for empty input.</p></div>';
    findingsArea.innerHTML='<p class="muted">No findings — nothing was pasted.</p>';
    reportOut.value=""; statusMsg.textContent=""; return res;
  }
  if(res.state==="notaudited"){
    resultArea.innerHTML='<div class="verdict na"><div class="eyebrow" style="color:var(--muted)">Not audited</div><div class="vtitle">NOT AUDITED</div><p style="margin:0">This text was not recognized as a slapd.conf or a cn=config LDIF config — no known OpenLDAP directives were found. No verdict was fabricated. Paste a real config (directives like <code>access</code>, <code>rootdn</code>, <code>olcAccess:</code>) and audit again.</p></div>';
    findingsArea.innerHTML='<p class="muted">No findings — the input was not audited.</p>';
    reportOut.value=buildReport(res,raw); statusMsg.textContent="Input not recognized — NOT AUDITED."; return res;
  }
  var html='<div class="verdict '+verdictClass(res.verdict)+'"><div class="eyebrow" style="color:inherit;opacity:.75">Verdict · '+esc(res.style)+'</div><div class="vtitle">'+esc(res.verdict)+'</div>';
  html+='<div class="counts"><span class="badge">'+res.counts.BLOCKER+' BLOCKER</span><span class="badge">'+res.counts.WARNING+' WARNING</span><span class="badge">'+res.counts.INFO+' INFO</span><span class="badge">'+res.acls.length+' ACL rule'+(res.acls.length===1?"":"s")+' in order</span></div>';
  html+='<p style="margin:0" class="small">ACLs are graded in file order — first-match-wins, so an early broad rule shadows any protective rule below it. Secret values never appear below: name, line, and length only.</p></div>';
  resultArea.innerHTML=html;
  if(!res.findings.length){findingsArea.innerHTML='<p class="muted">No findings.</p>';}
  else{
    findingsArea.innerHTML=res.findings.map(function(f){
      return '<article class="finding"><div class="top"><span class="sev '+f.severity+'">'+f.severity+'</span>'+(f.line?'<span class="linechip">Line '+f.line+'</span>':"")+'<strong>'+esc(f.title)+'</strong></div><p>'+esc(f.detail)+'</p></article>';
    }).join("");
  }
  reportOut.value=buildReport(res,raw);
  statusMsg.textContent="Audit complete: "+res.verdict+" ("+res.counts.BLOCKER+" blocker, "+res.counts.WARNING+" warning, "+res.counts.INFO+" info).";
  return res;
}
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-openldap-directory-config-safety-auditortm',
  name: 'J-Dawgs OpenLDAP Directory Config Safety Auditor',
  description: 'Grades a pasted slapd.conf or cn=config LDIF offline: ACL breadth read first-match-wins, plaintext vs hashed rootpw flagged by name and line only (values never shown), and TLS posture — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
