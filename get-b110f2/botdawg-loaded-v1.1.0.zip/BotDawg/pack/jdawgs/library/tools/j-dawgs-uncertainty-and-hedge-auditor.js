'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Uncertainty & Hedge Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ================= samples ================= */

      var SAMPLE_BAD = [
        "The migration is complete and the new system always responds instantly.",
        "Load testing proved the platform handles 40,000 concurrent users with zero downtime, and performance improved by 38%.",
        "We verified the database and everything is confirmed working.",
        "The failover process eliminates outages completely, so customers will never lose data.",
        "Revenue grew to $2.4 million in March 2024 with no signs of slowing.",
        "In practice, some failover steps might fail in unknown network conditions, and the user counts could be off."
      ].join(" ");

      var SAMPLE_GOOD = [
        "I checked the dipstick three times on 2026-10-19, wiping and re-inserting it each time, and the fluid looked pink rather than red [owner's photo log, 2026-10-19].",
        "The level sat near the top mark, roughly 2 mm below it, measured against the marks stamped on the dipstick itself.",
        "According to the owner's manual, the fluid should be checked hot, in Park, with the engine running, and I followed that procedure.",
        "Whether the slight color change means wear is unknown; the manual does not give a color standard.",
        "A transmission shop quoted $180 for a fluid analysis (quote from the shop counter, 2026-10-20), which might show metal content, though I have not decided whether to pay for it.",
        "Some shudder at low speed could be unrelated to the fluid, and I cannot confirm the cause without that test."
      ].join(" ");

      /* ================= patterns ================= */

      var DOT = "\u0001"; // placeholder for protected periods (decimals)

      var ABS_RE = /\b(always|never|guaranteed|guarantee|definitely|certainly|proves|proved|proven|confirmed|verified|absolutely|undoubtedly|eliminates|ensures)\b|100\s?%/gi;
      var VERIFY_RE = /\b(verified|confirmed|checked|tested)\b/i;
      var HEDGE_RE = /\b(may|might|could|unknown|unverified|not sure|unclear|uncertain)\b/i;
      var UNCERTAINTY_RE = /\b(may|might|could|possibly|perhaps|probably|likely|unlikely|unknown|uncertain|uncertainty|appears?|seems?|roughly|approximately|not sure|unclear|estimate|estimated|unverified|not yet confirmed|not confirmed)\b/i;

      // Evidence markers that let a sentence keep its certainty (class 1).
      var EVIDENCE_TESTS = [
        { re: /\[[^\]]*\]/, label: "a citation-like bracket" },
        { re: /https?:\/\/|www\./i, label: "a URL" },
        { re: /\b(according to|per the|reported by|manual states|label reads|source)\b/i, label: "a source phrase" },
        { re: /\b(checked|measured|observed|recorded|counted|weighed|timed|inspected|documented|photographed)\b/i, label: "a check / measurement word" },
        { re: /\d[\d,.]*\s?(mm|cm|km|kg|mg|lb|lbs|oz|ft|yd|mph|psi|rpm|hz|khz|mhz|volts?|amps?|watts?|seconds?|minutes?|hours?|days?|weeks?|months?|years?|users?|customers?|units?|people|requests?|orders?|times?|percent)\b/i, label: "a number with a unit" }
      ];

      // Source / evidence markers that can support a number (class 2) — checked
      // in the number's own sentence and its immediate neighbours.
      var SOURCE_RE = /\[[^\]]*\]|https?:\/\/|www\.|\b(according to|per the|sources?|reported by|reported|from the|manual|label|receipt|invoice|datasheet|spec sheet|published|survey|study|records|data from|quoted|quote|cited|citation|checked|measured|observed|recorded|counted)\b/i;

      // Detail cues that make a verification claim real (class 3): what was
      // checked, or how.
      var VERIFY_DETAIL_TESTS = [
        /\[[^\]]*\]/,
        /https?:\/\/|www\./i,
        /\d/,
        /\b(according to|procedure|measured|observed|inspected|compared|against|using|via|opened|ran|counted|weighed|timed|drained|removed|listened|watched|photographed|logged|recorded|wiping|wiped|re-inserting|followed|looked up|searched|each time)\b/i
      ];

      var STRONG_EXTRA_RE = /\b(eliminates|ensures|guarantees|zero|perfect|flawless|completely|will never)\b/i;

      var NUMBER_PATTERNS = [
        /\$\s?\d[\d,]*(\.\d+)?\s?(million|billion|thousand)?/g,
        /\d[\d,]*(\.\d+)?\s?%/g,
        /\b(January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2}(st|nd|rd|th)?,?\s+\d{4}\b/g,
        /\b(January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{4}\b/g,
        /\b\d{4}-\d{2}-\d{2}\b/g,
        /\b\d{1,2}\/\d{1,2}\/\d{2,4}\b/g,
        /\b\d[\d,]*(\.\d+)?\b/g
      ];

      var STOPWORDS = {};
      ("the a an and or but of to in on for with is are was were be been being it its this that these those " +
       "will would can has have had not no so as at by from some any all still just than then there here they them " +
       "their we our you your i he she his her into over under about practice everything something anyone everyone " +
       "each other more most very too also now out up down off did does do done get got one two first").split(" ")
       .forEach(function (w) { STOPWORDS[w] = true; });

      /* ================= helpers ================= */

      function splitSentences(text) {
        var t = String(text).replace(/\s+/g, " ").trim();
        if (!t) return [];
        t = t.replace(/(\d)\.(\d)/g, "$1" + DOT + "$2"); // protect decimals like 2.4
        t = t.replace(/\b(Mr|Mrs|Ms|Dr|St|vs)\./g, "$1" + DOT);
        var raw = t.split(/(?<=[.!?])\s+/);
        var out = [];
        raw.forEach(function (s) {
          s = s.split(DOT).join(".").trim();
          if (s) out.push(s);
        });
        return out;
      }

      function wordCount(text) {
        var m = String(text).trim().match(/\S+/g);
        return m ? m.length : 0;
      }

      function hasEvidence(sentence) {
        for (var i = 0; i < EVIDENCE_TESTS.length; i++) {
          if (EVIDENCE_TESTS[i].re.test(sentence)) return EVIDENCE_TESTS[i].label;
        }
        return null;
      }

      function hasVerifyDetail(sentence) {
        for (var i = 0; i < VERIFY_DETAIL_TESTS.length; i++) {
          if (VERIFY_DETAIL_TESTS[i].test(sentence)) return true;
        }
        return false;
      }

      // Absolute words in a sentence, ignoring negated "verified / confirmed"
      // (e.g. "not verified" is honesty, not overreach).
      function absoluteMatches(sentence) {
        var found = [];
        var re = new RegExp(ABS_RE.source, "gi");
        var m;
        while ((m = re.exec(sentence)) !== null) {
          var word = m[0].toLowerCase().replace(/\s+/g, " ");
          if (word === "verified" || word === "confirmed") {
            var before = sentence.slice(Math.max(0, m.index - 30), m.index).toLowerCase();
            if (/\b(not|never|cannot|can't|cant|did not|haven't|hasn't|no)\s+(\w+\s+)?$/.test(before.trim() + " ") ||
                /\b(not|never|cannot|can't|did not)\b[^.]*$/.test(before)) {
              continue;
            }
          }
          if (found.indexOf(word) === -1) found.push(word);
        }
        return found;
      }

      function findNumbers(sentence) {
        // Mask bracketed spans so citation contents are not treated as claims.
        var masked = sentence.replace(/\[[^\]]*\]/g, function (s) { return s.replace(/\d/g, " "); });
        var hits = [];
        var spans = [];
        NUMBER_PATTERNS.forEach(function (re) {
          var r = new RegExp(re.source, "g");
          var m;
          while ((m = r.exec(masked)) !== null) {
            var start = m.index, end = m.index + m[0].length;
            var overlap = spans.some(function (sp) { return start < sp[1] && end > sp[0]; });
            if (!overlap && m[0].trim()) {
              spans.push([start, end]);
              hits.push(m[0].trim());
            }
            if (r.lastIndex === m.index) r.lastIndex++;
          }
        });
        return hits;
      }

      function contentWords(sentence) {
        var set = {};
        var words = sentence.toLowerCase().replace(/[^a-z0-9\s-]/g, " ").split(/\s+/);
        words.forEach(function (w) {
          if (w.length < 4) return;
          var stem = w.replace(/ies$/, "y").replace(/(es|s)$/, "");
          if (stem.length < 4) stem = w;
          if (!STOPWORDS[w] && !STOPWORDS[stem]) set[stem] = true;
        });
        return set;
      }

      function sharedWords(a, b) {
        var out = [];
        for (var k in a) { if (b[k]) out.push(k); }
        return out;
      }

      function esc(s) {
        return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
                        .replace(/"/g, "&quot;");
      }

      /* ================= the audit ================= */

      function audit(text) {
        var sentences = splitSentences(text);
        var findings = { c1: [], c2: [], c3: [], c4: [], c5: [] };
        var notes = sentences.map(function () { return []; }); // honest-version notes per sentence

        sentences.forEach(function (s, i) {
          var n = i + 1;

          /* Class 1 — certainty overreach */
          var abs = absoluteMatches(s);
          if (abs.length && !hasEvidence(s)) {
            findings.c1.push({
              sentence: n, quote: s,
              why: "Absolute word" + (abs.length > 1 ? "s" : "") + " — " +
                   abs.map(function (w) { return "“" + w + "”"; }).join(", ") +
                   " — but the sentence carries no evidence marker: no citation or URL, no checked / measured / observed, no number with a unit, no source phrase."
            });
            notes[i].push("certainty stated here with no evidence given in this draft — treat as unverified");
          }

          /* Class 2 — unsupported numbers */
          var nums = findNumbers(s);
          if (nums.length) {
            var near = [sentences[i - 1] || "", s, sentences[i + 1] || ""].join(" ");
            if (!SOURCE_RE.test(near)) {
              findings.c2.push({
                sentence: n, quote: s,
                why: "Number" + (nums.length > 1 ? "s" : "") + " stated — " +
                     nums.map(function (x) { return "“" + x + "”"; }).join(", ") +
                     " — with no source or evidence marker in this sentence or the ones either side of it."
              });
              notes[i].push("figure stated here without a source — treat as unverified");
            }
          }

          /* Class 3 — fake verification */
          var vm = s.match(VERIFY_RE);
          if (vm) {
            var beforeV = s.slice(0, s.toLowerCase().indexOf(vm[0].toLowerCase()));
            var negated = /\b(not|never|cannot|can't|did not|haven't|hasn't|no)\b[^.]*$/i.test(beforeV);
            if (!negated && !hasVerifyDetail(s)) {
              findings.c3.push({
                sentence: n, quote: s,
                why: "“" + vm[0] + "” claims a check happened, but the sentence gives no method, no measurement, and no reference for how the check was done — naming a target is not the same as showing the work."
              });
              notes[i].push("a check is claimed here, but how it was done is not stated");
            }
          }
        });

        /* Class 4 — buried hedges */
        var strongIdx = [];
        sentences.forEach(function (s, i) {
          var isStrong = (absoluteMatches(s).length > 0 || STRONG_EXTRA_RE.test(s)) && !HEDGE_RE.test(s);
          if (isStrong) strongIdx.push(i);
        });
        sentences.forEach(function (s, j) {
          if (!HEDGE_RE.test(s)) return;
          var hedgeWords = s.match(new RegExp(HEDGE_RE.source, "gi")) || [];
          strongIdx.forEach(function (i) {
            if (i >= j) return;
            var shared = sharedWords(contentWords(sentences[i]), contentWords(s));
            if (shared.length) {
              findings.c4.push({
                sentence: i + 1, quote: sentences[i],
                pairSentence: j + 1, pairQuote: s,
                why: "Sentence " + (i + 1) + " states this flatly. Sentence " + (j + 1) +
                     " later walks it back on the same topic (“" + shared.slice(0, 3).join("”, “") +
                     "”) with hedge words — " + hedgeWords.join(", ") +
                     ". A reader who stops early takes home the strong version."
              });
              notes[i].push("this draft later qualifies this claim — see sentence " + (j + 1));
            }
          });
        });

        /* Class 5 — missing calibration */
        var wc = wordCount(text);
        if ((wc >= 120 || sentences.length >= 7) && !UNCERTAINTY_RE.test(text)) {
          findings.c5.push({
            sentence: null, quote: null,
            why: "This is a factual draft of " + wc + " words across " + sentences.length +
                 " sentences, and it contains no uncertainty language anywhere — no may, might, could, likely, roughly, unknown, or unverified. Real-world drafts almost always have something unknown; zero hedges is itself a warning sign."
          });
        }

        var total = findings.c1.length + findings.c2.length + findings.c3.length + findings.c4.length;
        var verdict, verdictClass, verdictWhy;
        if (findings.c3.length > 0 || findings.c4.length > 0 || findings.c1.length >= 3 || total >= 6) {
          verdict = "DO NOT SHIP AS FACT";
          verdictClass = "bad";
          verdictWhy = "The draft contains claims worded as settled fact that its own text does not support — " +
            "including " +
            [findings.c3.length ? "verification claims with no check behind them" : null,
             findings.c4.length ? "strong claims quietly walked back later" : null,
             findings.c1.length ? "absolute wording with no evidence attached" : null]
             .filter(Boolean).join(", ") + ". Soften or source these before anyone relies on them.";
        } else if (total > 0 || findings.c5.length > 0) {
          verdict = "OVERCONFIDENT IN PLACES";
          verdictClass = "mid";
          verdictWhy = "Most of the draft holds up, but the flagged sentences claim more than the text supports. " +
            "Soften the wording or attach the evidence, then it can ship.";
        } else {
          verdict = "CALIBRATED";
          verdictClass = "ok";
          verdictWhy = "No overreach found: certainty words are backed by evidence markers in the same text, " +
            "numbers sit next to sources, checks say what was checked, and the unknowns are stated out loud. " +
            "Remember — this means the wording is honest, not that the claims are true.";
        }

        /* Honest version: soften flagged sentences only, add wording only. */
        var honestParts = sentences.map(function (s, i) {
          if (!notes[i].length) return { text: s, notes: [] };
          var uniq = [];
          notes[i].forEach(function (x) { if (uniq.indexOf(x) === -1) uniq.push(x); });
          var body = s.replace(/[.!?]+$/, "");
          var punct = (s.match(/[.!?]+$/) || ["."])[0];
          return { text: body, notes: uniq, punct: punct };
        });

        return {
          sentences: sentences, findings: findings, total: total,
          verdict: verdict, verdictClass: verdictClass, verdictWhy: verdictWhy,
          honestParts: honestParts, wordCount: wc
        };
      }

      /* ================= rendering ================= */

      var CLASS_INFO = [
        { key: "c1", num: "1", name: "Certainty overreach", desc: "Absolute words, no evidence marker in the sentence." },
        { key: "c2", num: "2", name: "Unsupported numbers", desc: "Percentages, counts, money, or dates with no source nearby." },
        { key: "c3", num: "3", name: "Fake verification", desc: "“Verified / confirmed / checked / tested” without saying what or how." },
        { key: "c4", num: "4", name: "Buried hedges", desc: "A strong claim quietly contradicted or qualified later." },
        { key: "c5", num: "5", name: "Missing calibration", desc: "A long factual draft with zero uncertainty language anywhere." }
      ];

      function honestHTML(parts) {
        return parts.map(function (p) {
          if (!p.notes || !p.notes.length) return esc(p.text);
          var notes = p.notes.map(function (n) { return "(" + n + ")"; }).join(" ");
          return esc(p.text) + ' <span class="note">' + esc(notes) + "</span>" + esc(p.punct || ".");
        }).join(" ");
      }

      function honestPlain(parts) {
        return parts.map(function (p) {
          if (!p.notes || !p.notes.length) return p.text;
          var notes = p.notes.map(function (n) { return "(" + n + ")"; }).join(" ");
          return p.text + " " + notes + (p.punct || ".");
        }).join(" ");
      }

      function buildReport(text, r) {
        var L = [];
        L.push("J-DAWGS UNCERTAINTY & HEDGE AUDITOR(TM) - AUDIT REPORT");
        L.push("======================================================");
        L.push("Verdict: " + r.verdict);
        L.push("Draft: " + r.wordCount + " words, " + r.sentences.length + " sentences.");
        L.push("");
        L.push("COUNTS");
        CLASS_INFO.forEach(function (ci) {
          L.push("  " + ci.num + ". " + ci.name + ": " + r.findings[ci.key].length);
        });
        L.push("");
        L.push("FINDINGS");
        var any = false;
        CLASS_INFO.forEach(function (ci) {
          r.findings[ci.key].forEach(function (f) {
            any = true;
            L.push("");
            L.push("[" + ci.num + " - " + ci.name.toUpperCase() + "]" +
                   (f.sentence ? " Sentence " + f.sentence : " Whole draft"));
            if (f.quote) L.push('"' + f.quote + '"');
            if (f.pairQuote) {
              L.push("  ...later, sentence " + f.pairSentence + ":");
              L.push('"' + f.pairQuote + '"');
            }
            L.push("Why flagged: " + f.why);
          });
        });
        if (!any) L.push("  None. No overreach found in the wording of this draft.");
        L.push("");
        L.push("HONEST VERSION (flagged sentences softened with added uncertainty wording only)");
        L.push("-------------------------------------------------------------------------------");
        L.push(honestPlain(r.honestParts));
        L.push("");
        L.push("Limits: keyword/pattern analysis only. This audit cannot tell whether a claim");
        L.push("is actually true - only whether the wording earns its confidence. A CALIBRATED");
        L.push("verdict is not a fact-check.");
        L.push("");
        L.push("(c) 2026 Joshua Dawson - J-Dawgs Uncertainty & Hedge Auditor(TM)");
        return L.join("\n");
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "SAMPLE_BAD": (typeof SAMPLE_BAD !== 'undefined' ? SAMPLE_BAD : undefined), "SAMPLE_GOOD": (typeof SAMPLE_GOOD !== 'undefined' ? SAMPLE_GOOD : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-uncertainty-and-hedge-auditor',
  name: 'J-Dawgs Uncertainty & Hedge Auditor',
  description: '',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "SAMPLE_BAD": __core["SAMPLE_BAD"], "SAMPLE_GOOD": __core["SAMPLE_GOOD"] }
};
