'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Ghostfolio Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Built-in examples (exact texts; line numbers are deterministic) ---------- */
      var RISKY_EXAMPLE = [
        "# Ghostfolio - risky example",
        "DATABASE_URL=postgresql://ghostfolio:dbpass123@db:5432/ghostfolio",
        "REDIS_HOST=redis",
        "REDIS_PORT=6379",
        "REDIS_PASSWORD=redispass123",
        "ACCESS_TOKEN_SALT=short",
        "JWT_SECRET_KEY=abc123",
        "HOST=0.0.0.0",
        "PORT=3333",
        "LOG_LEVEL=debug",
        "this line is not a config line"
      ].join("\n");

      var HARDENED_EXAMPLE = [
        "# Ghostfolio - hardened example",
        "DATABASE_URL=${DATABASE_URL}",
        "REDIS_HOST=127.0.0.1",
        "REDIS_PORT=6379",
        "REDIS_PASSWORD_FILE=/run/secrets/redis_password",
        "ACCESS_TOKEN_SALT=${ACCESS_TOKEN_SALT}",
        "JWT_SECRET_KEY=${JWT_SECRET_KEY}",
        "HOST=127.0.0.1",
        "PORT=3333",
        "LOG_LEVEL=info"
      ].join("\n");

      /* ---------- Audit engine (deterministic; no network, no storage) ---------- */
      var KNOWN_KEYS = ["DATABASE_URL", "REDIS_HOST", "REDIS_PORT", "REDIS_PASSWORD",
        "ACCESS_TOKEN_SALT", "JWT_SECRET_KEY", "HOST", "PORT", "NODE_ENV", "LOG_LEVEL"];
      var RECOGNISED_PARTS = ["OIDC", "AUTH", "JWT", "SECRET", "TOKEN", "PASSWORD", "SALT"];
      var SECRET_PARTS = ["SECRET", "TOKEN", "PASSWORD", "SALT"];
      var WEAK_VALUES = ["change-me", "changeme", "secret", "password", "example", "test", "your-secret", "your_secret"];
      var SEV_RANK = { "BLOCKER": 0, "HIGH": 1, "WARNING": 2, "INFO": 3 };

      function containsAny(s, parts) {
        for (var i = 0; i < parts.length; i++) { if (s.indexOf(parts[i]) >= 0) return true; }
        return false;
      }
      function isRecognised(key) {
        return KNOWN_KEYS.indexOf(key) >= 0 || containsAny(key, RECOGNISED_PARTS);
      }
      function isSecretKey(key) {
        return key === "DATABASE_URL" || key === "REDIS_PASSWORD" ||
          key === "ACCESS_TOKEN_SALT" || key === "JWT_SECRET_KEY" ||
          containsAny(key, SECRET_PARTS);
      }
      function isRef(v) { return /^\$\{[^}]*\}$/.test(v); }
      function isValidPort(v) {
        if (!/^\d+$/.test(v)) return false;
        var n = parseInt(v, 10);
        return n >= 1 && n <= 65535;
      }
      function dbHost(v) {
        var m = v.match(/^[A-Za-z][A-Za-z0-9+.-]*:\/\/([^/]*)/);
        if (!m) return "";
        var auth = m[1];
        var at = auth.lastIndexOf("@");
        if (at >= 0) auth = auth.slice(at + 1);
        if (auth.charAt(0) === "[") {
          var end = auth.indexOf("]");
          return (end > 0 ? auth.slice(1, end) : auth).toLowerCase();
        }
        var c = auth.indexOf(":");
        return (c >= 0 ? auth.slice(0, c) : auth).toLowerCase();
      }

      function parseConfig(text) {
        var entries = [], notParsed = [];
        var lines = String(text).split(/\r?\n/);
        for (var i = 0; i < lines.length; i++) {
          var n = i + 1;
          var line = lines[i].trim();
          if (line === "") continue;
          if (line.charAt(0) === "#") continue;
          if (line.indexOf("export ") === 0) line = line.slice(7).trim();
          var eq = line.indexOf("="), co = line.indexOf(":");
          var sep = -1;
          if (eq >= 0 && co >= 0) sep = Math.min(eq, co);
          else sep = Math.max(eq, co);
          if (sep < 0) { notParsed.push(n); continue; }
          var key = line.slice(0, sep).trim().toUpperCase();
          var value = line.slice(sep + 1).trim();
          if (value.length >= 2) {
            var q = value.charAt(0);
            if ((q === '"' || q === "'") && value.charAt(value.length - 1) === q) {
              value = value.slice(1, -1);
            }
          }
          if (!key) { notParsed.push(n); continue; }
          entries.push({ line: n, key: key, value: value });
        }
        return { entries: entries, notParsed: notParsed };
      }

      function auditConfig(text) {
        var parsed = parseConfig(text);
        var findings = [];
        function add(sev, line, key, msg, len) {
          findings.push({ severity: sev, line: line, key: key, message: msg, length: (len === undefined ? null : len) });
        }
        var present = {}, recognised = {}, i, e;
        for (i = 0; i < parsed.entries.length; i++) {
          e = parsed.entries[i];
          present[e.key] = true;
          if (isRecognised(e.key)) recognised[e.key] = true;
        }
        var recognisedCount = Object.keys(recognised).length;

        for (i = 0; i < parsed.notParsed.length; i++) {
          add("INFO", parsed.notParsed[i], "—", "NOT PARSED — line could not be parsed as KEY=VALUE");
        }

        if (!present["ACCESS_TOKEN_SALT"] && !present["ACCESS_TOKEN_SALT_FILE"]) {
          add("BLOCKER", 0, "ACCESS_TOKEN_SALT", "ACCESS_TOKEN_SALT is missing — Ghostfolio needs a strong access token salt; add one of at least 32 random characters (line reported as 0: missing).");
        }
        if (!present["JWT_SECRET_KEY"] && !present["JWT_SECRET_KEY_FILE"]) {
          add("BLOCKER", 0, "JWT_SECRET_KEY", "JWT_SECRET_KEY is missing — session tokens cannot be signed safely without it; add one of at least 32 random characters (line reported as 0: missing).");
        }

        for (i = 0; i < parsed.entries.length; i++) {
          e = parsed.entries[i];
          var key = e.key, v = e.value, line = e.line;

          if (/_FILE$/.test(key)) {
            add("INFO", line, key, key + " loads its value from a file — externalised secret (safe pattern).");
            continue;
          }
          if (isRef(v)) {
            add("INFO", line, key, key + " uses a ${...} reference — externalised secret (safe pattern).");
            continue;
          }

          if (key === "ACCESS_TOKEN_SALT" || key === "JWT_SECRET_KEY") {
            if (v.length === 0) {
              add("HIGH", line, key, key + " has an empty value — set a strong random value of at least 32 characters.", 0);
            } else if (WEAK_VALUES.indexOf(v.toLowerCase()) >= 0) {
              add("BLOCKER", line, key, key + " matches a known weak or example placeholder value — replace it with a strong random value of at least 32 characters.", v.length);
            } else if (v.length < 32) {
              add("BLOCKER", line, key, key + " is too brief — plaintext length " + v.length + " characters; use at least 32 random characters.", v.length);
            }
            continue;
          }

          if (key === "DATABASE_URL") {
            if (v.length === 0) {
              add("HIGH", line, key, "DATABASE_URL has an empty value — Ghostfolio cannot reach its database without it.", 0);
              continue;
            }
            var m = v.match(/:\/\/[^:@/\s]+:([^@/\s]*)@/);
            if (m && m[1].length > 0 && !isRef(m[1])) {
              add("HIGH", line, key, "DATABASE_URL contains a plaintext password (password length " + m[1].length + ") — move the password into a secret store or a ${...} reference; the value itself is never shown.", m[1].length);
            }
            var host = dbHost(v);
            if (host === "localhost" || host === "127.0.0.1" || host === "::1") {
              add("INFO", line, key, "DATABASE_URL points at a local database host (" + host + ") — local-only, not reachable from other machines.");
            }
            continue;
          }

          if (key === "REDIS_PASSWORD") {
            if (v.length === 0) {
              add("HIGH", line, key, "REDIS_PASSWORD has an empty value — set a real password or remove the key.", 0);
            } else {
              add("HIGH", line, key, "REDIS_PASSWORD is set in plaintext (value length " + v.length + ") — externalise it with a ${...} reference or a _FILE secret; the value itself is never shown.", v.length);
            }
            continue;
          }

          if (isSecretKey(key) && v.length === 0) {
            add("HIGH", line, key, key + " is a secret key with an empty value — set a value or remove the key.", 0);
          }
          if (key === "HOST") {
            if (v === "0.0.0.0") {
              add("WARNING", line, key, "HOST is 0.0.0.0 — the app binds to every network interface, which risks public exposure. Put it behind a TLS reverse proxy, or bind to 127.0.0.1 if it only serves locally.");
            } else if (v === "127.0.0.1" || v.toLowerCase() === "localhost") {
              add("INFO", line, key, "HOST is " + v + " — local-only bind, not reachable from other machines.");
            }
          }
          if (key === "LOG_LEVEL") {
            var ll = v.toLowerCase();
            if (ll === "debug" || ll === "verbose") {
              add("WARNING", line, key, "LOG_LEVEL is " + ll + " — verbose logging can leak sensitive detail in production; use info or warn instead.");
            }
          }
          if (key === "NODE_ENV" && v.toLowerCase() === "development") {
            add("WARNING", line, key, "NODE_ENV is development — production deploys should run with NODE_ENV=production.");
          }
          if ((key === "REDIS_PORT" || key === "PORT") && !isValidPort(v)) {
            add("WARNING", line, key, key + " is set to \"" + v + "\", which is not a valid port number — a port must be a whole number from 1 to 65535.");
          }
        }

        findings.sort(function (a, b) {
          if (a.line !== b.line) return a.line - b.line;
          return SEV_RANK[a.severity] - SEV_RANK[b.severity];
        });

        var counts = { "BLOCKER": 0, "HIGH": 0, "WARNING": 0, "INFO": 0 };
        for (i = 0; i < findings.length; i++) counts[findings[i].severity]++;

        var verdict;
        if (recognisedCount < 3) verdict = "NOT ENOUGH TO GRADE";
        else if (counts.BLOCKER > 0) verdict = "DO NOT DEPLOY";
        else if (counts.HIGH > 0 || counts.WARNING > 0) verdict = "DEPLOY WITH FIXES";
        else verdict = "SAFE TO DEPLOY";

        return { verdict: verdict, recognisedCount: recognisedCount, counts: counts, findings: findings };
      }

      function buildReport(r) {
        var out = [];
        out.push("J-Dawgs Ghostfolio Server Config Safety Auditor — Audit Report");
        out.push("Verdict: " + r.verdict);
        out.push("Recognised Ghostfolio keys: " + r.recognisedCount);
        out.push("Counts: BLOCKER " + r.counts.BLOCKER + " · HIGH " + r.counts.HIGH + " · WARNING " + r.counts.WARNING + " · INFO " + r.counts.INFO);
        out.push("");
        out.push("Findings (sorted by line):");
        if (r.findings.length === 0) out.push("  (none)");
        for (var i = 0; i < r.findings.length; i++) {
          var f = r.findings[i];
          out.push("[" + f.severity + "] Line " + f.line + " — " + f.key + ": " + f.message);
        }
        out.push("");
        out.push("Secret values are never included in this report — key names, line numbers, and value lengths only.");
        return out.join("\n");
      }

      function buildJSON(r) {
        return JSON.stringify({
          tool: "J-Dawgs Ghostfolio Server Config Safety Auditor",
          verdict: r.verdict,
          recognisedKeys: r.recognisedCount,
          counts: r.counts,
          findings: r.findings
        }, null, 2);
      }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-ghostfolio-server-config-safety-auditortm',
  name: 'J-Dawgs Ghostfolio Server Config Safety Auditor',
  description: 'Grades a pasted Ghostfolio server config (env settings) offline into one deploy verdict, with secrets reported by key name, line, and length only, never values.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
