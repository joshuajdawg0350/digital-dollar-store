'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Fluent Bit Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";
function $(id){return document.getElementById(id);}
function esc(s){return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");}

/* ---------- Worked examples (line numbers matter — keep them exact) ---------- */
var RISKY_EXAMPLE = [
"# J-Dawgs worked example - risky edge collector (fluent-bit.conf)",
"[SERVICE]",
"    Flush        5",
"    Daemon       On",
"    Log_Level    info",
"    HTTP_Server  On",
"    HTTP_Listen  0.0.0.0",
"    HTTP_Port    2020",
"",
"[INPUT]",
"    Name         forward",
"    Listen       0.0.0.0",
"    Port         24224",
"",
"[INPUT]",
"    Name         tail",
"    Path         /var/log/app/*.log",
"    Tag          app.*",
"",
"[OUTPUT]",
"    Name         es",
"    Match        *",
"    Host         logs.example.net",
"    Port         9200",
"    tls          Off",
"    tls.verify   Off",
"    HTTP_Passwd  correct-horse-battery-staple-42",
"",
"[OUTPUT]",
"    Name         datadog",
"    Match        *",
"    Host         http-intake.logs.datadoghq.com",
"    apikey       dd-api-key-0123456789abcdef0123",
"    tls          On"
].join("\n");

var HARDENED_EXAMPLE = [
"# J-Dawgs worked example - hardened collector (fluent-bit.conf)",
"[SERVICE]",
"    Flush        5",
"    Daemon       On",
"    Log_Level    info",
"    HTTP_Server  On",
"    HTTP_Listen  127.0.0.1",
"    HTTP_Port    2020",
"    storage.path /var/lib/fluent-bit/storage",
"",
"[PARSER]",
"    Name         app_json",
"    Format       json",
"    Time_Key     time",
"    Time_Format  %Y-%m-%dT%H:%M:%S.%L%z",
"",
"[INPUT]",
"    Name         forward",
"    Listen       127.0.0.1",
"    Port         24224",
"    Shared_Key   ${FORWARD_SHARED_KEY}",
"",
"[INPUT]",
"    Name              tail",
"    Path              /var/log/app/*.log",
"    Tag               app.*",
"    Parser            app_json",
"    Mem_Buf_Limit     64MB",
"",
"[OUTPUT]",
"    Name          es",
"    Match         *",
"    Host          logs.example.net",
"    Port          9200",
"    tls           On",
"    tls.verify    On",
"    HTTP_User     ${ES_USER}",
"    HTTP_Passwd   ${ES_PASSWD}",
"    storage.type  filesystem"
].join("\n");

var SHARE_TEXT = [
"Serve It, Pipe It, List It Honest Stack \u2014 J-Dawgs Asterisk PBX Config Safety Auditor\u2122 + J-Dawgs Fluent Bit Config Safety Auditor\u2122 + J-Dawgs Real Estate Listing & Disclosure Consistency Auditor\u2122: check the phone system, check the log pipeline, cross-check the listing before anyone signs.",
"",
"One-line pitches:",
"- J-Dawgs Asterisk PBX Config Safety Auditor\u2122 \u2014 paste the PBX config, get one safety verdict with line-numbered findings before the phones go live.",
"- J-Dawgs Fluent Bit Config Safety Auditor\u2122 \u2014 paste a fluent-bit.conf or fluent-bit.yaml, get one deploy verdict grading the log pipeline's security posture, entirely offline.",
"- J-Dawgs Real Estate Listing & Disclosure Consistency Auditor\u2122 \u2014 cross-check the listing against the disclosures so mismatches surface before anyone signs.",
"",
"AI Tool Store by J-Dawgs \u2014 browser tools built for AI agents: https://muse.ai/s/ai-tool-store-xng6xkxwjkxl2xab/UoF72OkKI7j33Q2ITxmrZyIr4nv40QtYfj2AgESh_k8",
"J-Dawgs Agent Exchange \u2014 hire a verified agent service, or list your own: https://muse.ai/s/j-dawgs-agent-exchange-ih6xlnihzxdhxc/ZbleqxFHRE0NcswaBkyN13y9lLp5rPAgHTb6t8ii-PY"
].join("\n");

/* ---------- Small helpers ---------- */
function canon(k){return String(k).toLowerCase().replace(/_/g,".");}
function isOn(v){return /^(on|true|yes|1)$/i.test(String(v).trim());}
function isOff(v){return /^(off|false|no|0)$/i.test(String(v).trim());}
function isEnvRef(v){var t=String(v).trim();return /^\$\{[^}]*\}$/.test(t)||/^\$[A-Za-z_][A-Za-z0-9_]*$/.test(t);}
function stripQ(v){var t=String(v).trim();if(t.length>=2&&((t.charAt(0)==='"'&&t.charAt(t.length-1)==='"')||(t.charAt(0)==="'"&&t.charAt(t.length-1)==="'")))return t.slice(1,-1);return t;}
function getE(sec,ck){var f=null;if(!sec)return null;for(var i=0;i<sec.entries.length;i++){if(canon(sec.entries[i].key)===ck)f=sec.entries[i];}return f;}
function pluginName(sec){var e=getE(sec,"name");return e?e.value.trim().toLowerCase():"";}

/* ---------- Parsers ---------- */
var KNOWN_SECTIONS={SERVICE:1,INPUT:1,FILTER:1,OUTPUT:1,PARSER:1,MULTILINE_PARSER:1};

function parseClassic(lines){
  var sections=[],notParsed=[],includes=[],cur=null;
  function newSec(type,line){cur={type:type,line:line,entries:[],name:null};sections.push(cur);}
  lines.forEach(function(raw,i){
    var ln=i+1,t=raw.trim();
    if(!t||t.charAt(0)==="#")return;
    if(/^@INCLUDE\b/i.test(t)){includes.push({line:ln,target:t.replace(/^@INCLUDE\s+/i,"")});return;}
    if(/^@SET\b/i.test(t))return;
    var m=t.match(/^\[([A-Za-z_]+)\]$/);
    if(m){
      var ty=m[1].toUpperCase();
      if(!KNOWN_SECTIONS[ty]){notParsed.push({line:ln,why:"Unknown section header \u2014 this auditor grades [SERVICE], [INPUT], [FILTER], [OUTPUT], [PARSER] and [MULTILINE_PARSER] only"});newSec("UNKNOWN",ln);}
      else newSec(ty,ln);
      return;
    }
    if(t.charAt(0)==="["){notParsed.push({line:ln,why:"Malformed section header"});return;}
    var kv=t.match(/^([A-Za-z][A-Za-z0-9_.\-]*)\s+(\S[\s\S]*)$/);
    if(kv){
      if(!cur){notParsed.push({line:ln,why:"Key\u2013value line appears before any [SECTION] header"});return;}
      var e={key:kv[1],value:kv[2].trim(),line:ln};cur.entries.push(e);
      if(canon(e.key)==="name"&&!cur.name)cur.name=e.value;
      return;
    }
    notParsed.push({line:ln,why:"Line does not match the section / key\u2013value format"});
  });
  return {format:"classic fluent-bit.conf",sections:sections,notParsed:notParsed,includes:includes};
}

function parseYaml(lines){
  var sections=[],notParsed=[],cur=null,mode=null,listType=null;
  function newSec(type,line){cur={type:type,line:line,entries:[],name:null};sections.push(cur);}
  function addEntry(sec,key,val,ln){var e={key:key,value:stripQ(val),line:ln};sec.entries.push(e);if(canon(key)==="name"&&!sec.name)sec.name=e.value;}
  lines.forEach(function(raw,i){
    var ln=i+1;
    if(!raw.trim()||raw.trim().charAt(0)==="#")return;
    var indent=raw.length-raw.replace(/^\s+/,"").length;
    var t=raw.trim();
    if(/:\s*[|>]\s*$/.test(t)){notParsed.push({line:ln,why:"YAML block scalar (multi-line value) \u2014 NOT PARSED"});return;}
    var m=t.match(/^([A-Za-z_][A-Za-z0-9_.\-]*):\s*(.*)$/);
    if(indent===0){
      if(m){
        var k=m[1].toLowerCase();
        if(k==="service"){newSec("SERVICE",ln);mode="service";listType=null;return;}
        if(k==="pipeline"){mode="pipeline";listType=null;cur=null;return;}
        if(k==="parsers"){mode="list";listType="PARSER";cur=null;return;}
        if(k==="env"){mode="env";cur=null;return;}
        mode="other";cur=null;listType=null;
        notParsed.push({line:ln,why:"Top-level YAML key this auditor does not grade"});
        return;
      }
      notParsed.push({line:ln,why:"YAML line not understood"});return;
    }
    if(mode==="env")return;
    if(mode==="pipeline"&&m&&t.charAt(0)!=="-"){
      var pk=m[1].toLowerCase();
      if(pk==="inputs"){listType="INPUT";cur=null;return;}
      if(pk==="outputs"){listType="OUTPUT";cur=null;return;}
      if(pk==="filters"){listType="FILTER";cur=null;return;}
      if(pk==="parsers"){listType="PARSER";cur=null;return;}
    }
    if(mode==="list"||(mode==="pipeline"&&listType)){
      if(t.charAt(0)==="-"){
        var item=t.replace(/^-\s*/,"");
        newSec(listType,ln);
        var im=item.match(/^([A-Za-z_][A-Za-z0-9_.\-]*):\s*(.*)$/);
        if(im)addEntry(cur,im[1],im[2],ln);
        else if(item)notParsed.push({line:ln,why:"YAML list item not understood"});
        return;
      }
      if(m&&cur){
        if(m[2]===""){notParsed.push({line:ln,why:"Nested YAML mapping \u2014 NOT PARSED"});return;}
        addEntry(cur,m[1],m[2],ln);return;
      }
      notParsed.push({line:ln,why:"YAML line not understood"});return;
    }
    if(mode==="service"){
      if(m){
        if(m[2]===""){notParsed.push({line:ln,why:"Nested YAML mapping under service \u2014 NOT PARSED"});return;}
        addEntry(cur,m[1],m[2],ln);return;
      }
      notParsed.push({line:ln,why:"YAML line not understood"});return;
    }
    notParsed.push({line:ln,why:"YAML line outside a block this auditor grades \u2014 NOT PARSED"});
  });
  return {format:"fluent-bit.yaml",sections:sections,notParsed:notParsed,includes:[]};
}

/* ---------- Audit engine ---------- */
var NETWORK_OUTPUTS={es:1,opensearch:1,http:1,forward:1,splunk:1,kafka:1,tcp:1,syslog:1,loki:1,gelf:1,influxdb:1,datadog:1,stackdriver:1,azure:1,logzio:1,sumologic:1,nrlogs:1,firehose:1,kinesis:1,mqtt:1,nats:1,redis:1,chronicle:1};
var LISTEN_INPUTS={tcp:1,syslog:1,http:1,udp:1,forward:1};
var SECRET_KEY_RE=/(password|passwd|pwd|api[-_.]?key|apikey|secret|shared[-_.]?key|access[-_.]?key|token|private[-_.]?key|credential)/i;
var SINGLETON_KEYS={"http.server":1,"http.listen":1,"http.port":1,"flush":1,"log.level":1,"daemon":1,"listen":1,"port":1,"host":1,"tls":1,"tls.verify":1,"shared.key":1,"storage.type":1,"mem.buf.limit":1,"name":1,"match":1,"tag":1,"path":1,"parser":1};
var SENSITIVE_SRC=/auth|secure|passwd|shadow|secret|token|payment|billing|card|health|medical|private/i;

function audit(text){
  var findings=[],notSet=[],notVerified=[],notAudited=[];
  function F(sev,line,title,why,fix,tag){findings.push({sev:sev,line:line||null,title:title,why:why,fix:fix,tag:tag||null});}
  function NS(s){if(notSet.indexOf(s)===-1)notSet.push(s);}

  var lines=String(text).split(/\r?\n/);
  if(!String(text).trim())return {empty:true};
  var hasClassic=/\[[A-Za-z_]+\]/.test(text);
  var parsed=hasClassic?parseClassic(lines):parseYaml(lines);
  var sections=parsed.sections;

  parsed.includes.forEach(function(inc){
    F("INFO",inc.line,"@INCLUDE target is NOT AUDITED: "+inc.target,
      "This tool grades only the text pasted here. The included file's contents are never loaded, so anything it sets \u2014 inputs, outputs, secrets, TLS \u2014 is outside this verdict.",
      "Paste the included file's contents into this auditor as well, or merge the files before deploying.","NOT AUDITED");
    notAudited.push("@INCLUDE "+inc.target+" (line "+inc.line+")");
  });
  var npShown=Math.min(parsed.notParsed.length,12);
  for(var npi=0;npi<npShown;npi++){
    F("WARNING",parsed.notParsed[npi].line,"NOT PARSED \u2014 line could not be graded",
      parsed.notParsed[npi].why+". The line is reported, never guessed: whatever it was meant to set is not covered by this verdict.",
      "Fix the line so it follows the config format, then re-run the audit.","NOT PARSED");
  }
  if(parsed.notParsed.length>npShown){
    F("WARNING",null,"NOT PARSED \u2014 "+(parsed.notParsed.length-npShown)+" more lines could not be graded",
      "Only the first "+npShown+" unparseable lines are listed individually. Every one of them is outside this verdict.",
      "Fix the listed lines first, then re-run \u2014 the rest will surface.","NOT PARSED");
  }

  /* Duplicate [SERVICE] sections + conflicting repeated keys */
  var svcSections=sections.filter(function(s){return s.type==="SERVICE";});
  if(svcSections.length>1){
    F("WARNING",svcSections[1].line,"Duplicate [SERVICE] section",
      "The file carries more than one [SERVICE] block (first at line "+svcSections[0].line+"). Which settings win is NOT PARSED from the file alone.",
      "Merge everything into a single [SERVICE] section.","NOT PARSED");
  }
  sections.forEach(function(sec){
    var byKey={};
    sec.entries.forEach(function(e){var ck=canon(e.key);if(!byKey[ck])byKey[ck]=[];byKey[ck].push(e);});
    Object.keys(byKey).forEach(function(ck){
      var arr=byKey[ck];
      if(arr.length<2||!SINGLETON_KEYS[ck])return;
      var vals={},distinct=0;
      arr.forEach(function(e){if(!vals[e.value]){vals[e.value]=1;distinct++;}});
      var lineList=arr.map(function(e){return e.line;}).join(", ");
      if(distinct>1){
        F("WARNING",arr[1].line,"Conflicting repeated key \u201C"+arr[0].key+"\u201D in one ["+sec.type+"] section",
          "The key is set "+arr.length+" times with different values (lines "+lineList+"). Which value the author intended is NOT PARSED \u2014 Fluent Bit applies the last one it reads, which may not be the one on the line you checked.",
          "Delete the extra lines so the key appears exactly once.","NOT PARSED");
      }else{
        F("INFO",arr[1].line,"Repeated key \u201C"+arr[0].key+"\u201D in one ["+sec.type+"] section",
          "The key appears "+arr.length+" times with the same value (lines "+lineList+"). Harmless, but noisy.",
          "Remove the duplicates.","");
      }
    });
  });

  var svc=svcSections[0]||null;
  if(!svc)NS("No [SERVICE] section in this text \u2014 service-level settings are NOT SET IN FILE here");

  /* [SERVICE] HTTP monitoring server */
  if(svc){
    var httpSrv=getE(svc,"http.server"),httpListen=getE(svc,"http.listen");
    if(httpSrv&&isOn(httpSrv.value)){
      var authInSvc=svc.entries.some(function(e){return /user|passwd|password|auth/i.test(e.key);});
      if(httpListen&&httpListen.value.trim()==="0.0.0.0"){
        if(!authInSvc){
          F("BLOCKER",httpListen.line,"Monitoring/API HTTP server is open to every interface, with no authentication in [SERVICE]",
            "HTTP_Server is On (line "+httpSrv.line+") and HTTP_Listen is 0.0.0.0, so the Fluent Bit monitoring/API endpoint answers on every network interface \u2014 and no authentication key exists in the [SERVICE] section. Anyone who can reach this host can query pipeline stats and endpoints.",
            "Bind it to localhost (HTTP_Listen 127.0.0.1), or turn HTTP_Server Off, or put an authenticated reverse proxy in front of it.");
        }else{
          F("WARNING",httpListen.line,"Monitoring/API HTTP server listens on 0.0.0.0",
            "HTTP_Server is On and HTTP_Listen is 0.0.0.0, so the endpoint answers on every interface. Authentication keys exist in [SERVICE], but whether they actually protect this endpoint is NOT VERIFIED from the file.",
            "Prefer HTTP_Listen 127.0.0.1 unless remote monitoring is genuinely required.");
        }
      }else if(httpListen&&/^(127\.0\.0\.1|localhost|::1)$/i.test(httpListen.value.trim())){
        F("INFO",httpListen.line,"HTTP_Server is bound to localhost \u2014 the safer posture",
          "HTTP_Listen is "+httpListen.value.trim()+", so the monitoring/API endpoint only answers on this host itself.",
          "No change needed. Reach it over SSH or a local tunnel instead of widening the bind.");
      }else if(httpListen){
        F("INFO",httpListen.line,"HTTP_Server is bound to one specific address",
          "HTTP_Listen names a single address rather than 0.0.0.0. Who can actually reach that address depends on the network, which is NOT VERIFIED here.",
          "Confirm the address is on a trusted interface; localhost is the safest bind.");
      }else{
        F("WARNING",httpSrv.line,"HTTP_Server is On but HTTP_Listen is NOT SET IN FILE",
          "The file turns the monitoring/API endpoint on without saying which interface it binds, so the exposure is NOT VERIFIED from the file.",
          "Set HTTP_Listen 127.0.0.1 explicitly so the bind is a decision, not a default.");
        NS("HTTP_Listen in [SERVICE] while HTTP_Server is On");
      }
    }else if(!httpSrv){
      NS("HTTP_Server in [SERVICE] \u2014 NOT SET IN FILE, so the monitoring endpoint's state is not stated in this text");
    }
    /* Verbose logging */
    var ll=getE(svc,"log.level");
    if(ll&&/^(debug|trace)$/i.test(ll.value.trim())){
      var sensitive=sections.some(function(s){
        if(s.type!=="INPUT")return false;
        var p=getE(s,"path");
        return pluginName(s)==="syslog"||(p&&SENSITIVE_SRC.test(p.value));
      });
      if(sensitive){
        F("WARNING",ll.line,"Log_Level is "+ll.value.trim().toLowerCase()+" while inputs carry sensitive-looking sources",
          "Debug/trace logging can write record payloads and internal detail into Fluent Bit's own log, and this file has inputs that read sensitive-looking sources (for example auth-style logs). The log file becomes a second copy of the data.",
          "Run production at Log_Level info (or warn), and raise verbosity only while actively debugging.");
      }else{
        F("INFO",ll.line,"Log_Level is "+ll.value.trim().toLowerCase()+" \u2014 verbose logging is on",
          "Debug/trace output can include payload content. No sensitive-looking input source was found in this file, but verbosity in production is still worth a second look.",
          "Prefer Log_Level info in production.");
      }
    }
  }

  /* Secrets \u2014 key name and line only; values are NEVER rendered */
  sections.forEach(function(sec){
    sec.entries.forEach(function(e){
      var rawKey=e.key,lk=rawKey.toLowerCase();
      if(/(_file|\.file|_path|\.path)$/.test(lk))return;
      var val=e.value;
      if(SECRET_KEY_RE.test(rawKey)){
        if(isEnvRef(val))return;
        if(!val||/^[*x\u2022._\-\s]+$/i.test(val)||/^(changeme|change-me|placeholder|example|redacted|todo|your[-_ ].*)$/i.test(val))return;
        var len=val.length;
        if(len<12){
          F("BLOCKER",e.line,"Plaintext secret in the file: key \u201C"+rawKey+"\u201D \u2014 and it is short",
            "A secret is written directly in this config (["+sec.type+"] section). Reported by key name and length only \u2014 the value is never shown here. It is "+len+" characters long, which is short for a credential, and it now exists wherever this file is copied, backed up, or committed.",
            "Move the secret to an environment variable reference (${...}) or a secrets file outside the config \u2014 and rotate it, because it has existed in plain text.");
        }else{
          F("WARNING",e.line,"Plaintext secret in the file: key \u201C"+rawKey+"\u201D",
            "A secret is written directly in this config (["+sec.type+"] section). Reported by key name and length only \u2014 the value is never shown here ("+len+" characters). Anyone who can read this file has the credential.",
            "Move the secret to an environment variable reference (${...}) or a secrets file outside the config \u2014 and rotate it, because it has existed in plain text.");
        }
        return;
      }
      if(canon(rawKey)==="header"&&/(bearer\s+\S{6,}|api[-_ ]?key\s*[:=]?\s*\S{6,})/i.test(val)){
        F("WARNING",e.line,"Credentials embedded in a Header value",
          "This Header line carries what looks like a live credential (the value is never shown here). Headers set in the config are secrets too.",
          "Move the credential to an environment variable reference and rotate it.");
        return;
      }
      if(/:\/\/[^\s\/:@]+:[^\s\/@]{3,}@/.test(val)){
        F("WARNING",e.line,"Password embedded in a URL value",
          "A value in this config embeds a password inside a URL (the value is never shown here). URLs get logged, copied, and committed far more casually than secret files do.",
          "Take the password out of the URL and supply it through a dedicated key fed by an environment variable.");
      }
    });
  });

  /* Inputs \u2014 exposure, shared keys, parsers */
  var referencedParsers={};
  sections.forEach(function(sec){sec.entries.forEach(function(e){var ck=canon(e.key);if(ck==="parser"||ck==="docker.mode.parser")referencedParsers[e.value.trim().toLowerCase()]=1;});});
  sections.forEach(function(sec){
    if(sec.type!=="INPUT")return;
    var name=pluginName(sec)||"(unnamed)";
    var listen=getE(sec,"listen");
    var hasTls=sec.entries.some(function(e){return canon(e.key).indexOf("tls")===0;});
    if(name==="forward"){
      var shared=getE(sec,"shared.key");
      if(!shared){
        F("BLOCKER",listen?listen.line:sec.line,"Forward input has no Shared_Key \u2014 it accepts logs from anyone who can reach it",
          "The forward input receives log records over the network, and Shared_Key is NOT SET IN FILE, so nothing authenticates senders. "+(listen&&listen.value.trim()==="0.0.0.0"?"It also listens on 0.0.0.0 (every interface).":"")+"Forged records can be injected straight into the pipeline.",
          "Set a strong Shared_Key on the input and the matching key on every legitimate sender \u2014 or bind the input to localhost / a private interface.");
        NS("Shared_Key on the forward input (section at line "+sec.line+")");
      }else if(listen&&listen.value.trim()==="0.0.0.0"){
        if(hasTls){
          F("INFO",listen.line,"Forward input listens on 0.0.0.0 with a Shared_Key and TLS settings present",
            "Senders are authenticated by the Shared_Key and TLS settings exist in this input. The port is still reachable from every interface \u2014 the firewall decides the rest, and that is NOT VERIFIED here.",
            "Restrict the port at the firewall to known senders where you can.");
        }else{
          F("WARNING",listen.line,"Forward input listens on 0.0.0.0 \u2014 Shared_Key set, but no TLS on the input",
            "The Shared_Key authenticates senders, but no tls.* settings exist in this input, so forwarded records cross the network unencrypted.",
            "Configure TLS on the forward input (tls.crt_file / tls.key_file and peer verification) or restrict the listener to a private interface.");
        }
      }
      if(!listen)NS("Listen on the forward input (section at line "+sec.line+") \u2014 bind address NOT SET IN FILE");
    }else if(LISTEN_INPUTS[name]){
      if(listen&&listen.value.trim()==="0.0.0.0"){
        if(hasTls){
          F("INFO",listen.line,"\u201C"+name+"\u201D input listens on 0.0.0.0, with TLS settings present in the file",
            "The listener is open on every interface, but TLS settings exist for it in this file. Who can reach the port is a firewall question \u2014 NOT VERIFIED here.",
            "Restrict the port at the firewall to known senders where you can.");
        }else{
          F("WARNING",listen.line,"\u201C"+name+"\u201D input listens on 0.0.0.0 with no TLS in this file",
            "Any host that can reach this port can send it log records, unencrypted and unauthenticated as far as this file shows. Injected records land in the same pipeline as real ones.",
            "Bind it to a specific/private interface (Listen), configure TLS on the input, or firewall the port to known senders.");
        }
      }else if(!listen){
        NS("Listen on the \u201C"+name+"\u201D input (section at line "+sec.line+") \u2014 bind address NOT SET IN FILE, so which interfaces it binds is NOT VERIFIED");
      }
    }
    var dockerMode=getE(sec,"docker.mode");
    if(dockerMode&&isOn(dockerMode.value)&&!getE(sec,"docker.mode.parser")){
      F("WARNING",dockerMode.line,"Docker_Mode is On with no Docker_Mode_Parser",
        "This input reads Docker container logs in Docker mode, but no Docker_Mode_Parser is set in the file, so container JSON log lines are not parsed into structured fields by this config.",
        "Set Docker_Mode_Parser to the name of a [PARSER] defined for the container log format.");
    }
    if(name==="tail"&&!getE(sec,"parser")&&!getE(sec,"docker.mode.parser")){
      F("INFO",sec.line,"Tail input has no Parser set",
        "No Parser (or Docker_Mode_Parser) is referenced on this tail input, so lines pass through as raw message text. That is only a gap if you expected structured fields \u2014 the file itself shows nothing being parsed here.",
        "If the log format is known (JSON, Apache, syslog\u2026), define a [PARSER] and reference it with Parser on this input.");
    }
  });

  /* Defined-but-unreferenced parsers */
  sections.forEach(function(sec){
    if(sec.type!=="PARSER")return;
    var nm=getE(sec,"name");
    if(nm&&!referencedParsers[nm.value.trim().toLowerCase()]){
      F("INFO",sec.line,"Parser \u201C"+nm.value.trim()+"\u201D is defined but never referenced in this file",
        "No input or filter in the pasted text names this parser. An @INCLUDE file could still use it \u2014 that is NOT VERIFIED here.",
        "Reference it from the input that needs it, or remove the dead definition.");
    }
  });

  /* Outputs \u2014 transport encryption + buffering posture */
  var usesFilesystem=false;
  sections.forEach(function(sec){
    if(sec.type!=="OUTPUT")return;
    var name=pluginName(sec)||"(unnamed)";
    var dispName=name;
    var hostE=getE(sec,"host");
    var hostLocal=hostE&&/^(127\.0\.0\.1|localhost|::1)$/i.test(hostE.value.trim());
    var hostShown=hostE&&/^[A-Za-z0-9._\-]+$/.test(hostE.value.trim())?hostE.value.trim():null;
    var where=hostShown?" to "+hostShown:"";
    if(NETWORK_OUTPUTS[name]){
      var tlsE=getE(sec,"tls"),verE=getE(sec,"tls.verify");
      var tlsOff=tlsE&&isOff(tlsE.value),tlsOn=tlsE&&isOn(tlsE.value),verOff=verE&&isOff(verE.value);
      var uriE=getE(sec,"uri");
      if(uriE&&/^http:\/\//i.test(uriE.value.trim())){
        F("BLOCKER",uriE.line,"\u201C"+dispName+"\u201D output destination URI starts with http:// \u2014 plaintext",
          "The destination URI is written with the http:// scheme, so records are sent unencrypted"+where+".",
          "Use the https:// endpoint and set tls On with tls.verify On.");
      }
      if(tlsOff&&verOff){
        F("BLOCKER",tlsE.line,"\u201C"+dispName+"\u201D output sends in plaintext, and certificate verification is off too (tls Off + tls.verify Off, line "+verE.line+")",
          "tls is Off, so records cross the network unencrypted"+where+" \u2014 and tls.verify is also Off, so even if TLS were enabled later, the destination's certificate would not be checked.",
          "Set tls On and tls.verify On for this output.");
      }else if(tlsOff){
        F(hostLocal?"WARNING":"BLOCKER",tlsE.line,"\u201C"+dispName+"\u201D output has tls Off \u2014 records are sent unencrypted",
          hostLocal?"The destination in this file is on the same host, which limits exposure \u2014 but the traffic is still plaintext on the box.":"tls is explicitly Off on a network output"+where+", so log records \u2014 which often carry exactly the data you least want copied \u2014 cross the network in the clear.",
          "Set tls On and tls.verify On for this output.");
      }else if(!tlsE){
        F(hostLocal?"INFO":"WARNING",sec.line,"tls is NOT SET IN FILE on the \u201C"+dispName+"\u201D output",
          "This network output's section never mentions tls, so the file does not prove records are encrypted in transit"+where+". Whether the destination demands TLS is NOT VERIFIED \u2014 this tool never connects.",
          "Set tls On and tls.verify On explicitly so the encryption is a decision in the file, not a plugin default.");
        NS("tls on the \u201C"+dispName+"\u201D output (section at line "+sec.line+")");
        if(verOff){
          F("WARNING",verE.line,"tls.verify is Off while tls itself is NOT SET IN FILE on the \u201C"+dispName+"\u201D output",
            "Verification is switched off for a connection whose encryption is not even switched on in the file \u2014 the weakest combination the config can express.",
            "Set tls On and tls.verify On for this output.");
        }
      }else if(tlsOn&&verOff){
        F("WARNING",verE.line,"\u201C"+dispName+"\u201D output encrypts (tls On) but does not verify the destination (tls.verify Off)",
          "Traffic is encrypted, but any certificate is accepted, so a man-in-the-middle can terminate the connection and read the records anyway"+where+".",
          "Set tls.verify On so the destination's certificate is checked.");
      }
    }
    var stE=getE(sec,"storage.type"),memE=getE(sec,"mem.buf.limit");
    if(stE&&/^filesystem$/i.test(stE.value.trim()))usesFilesystem=true;
    if(!stE&&!memE){
      F("WARNING",sec.line,"\u201C"+dispName+"\u201D output has no filesystem buffering and no memory limit \u2014 data-loss posture",
        "storage.type is NOT SET IN FILE and Mem_Buf_Limit is NOT SET IN FILE on this output. As a posture, that means buffering lives in memory with no stated cap: if the destination stalls or the host restarts, buffered records can be dropped. That is a risk the file's silence creates, not proof records will be lost.",
        "Add storage.type filesystem on the output (plus storage.path under [SERVICE]) for disk-backed buffering, or at least a Mem_Buf_Limit sized for the host.");
      NS("storage.type and Mem_Buf_Limit on the \u201C"+dispName+"\u201D output (section at line "+sec.line+")");
    }else if(!stE&&memE){
      F("INFO",memE.line,"\u201C"+dispName+"\u201D output sets Mem_Buf_Limit, but storage.type is NOT SET IN FILE",
        "The memory buffer is capped, which is good \u2014 but memory-only buffering still loses buffered records on a crash or restart.",
        "Add storage.type filesystem if these records must survive a restart.");
    }
  });
  if(usesFilesystem&&svc&&!getE(svc,"storage.path")){
    F("INFO",svc.line,"storage.type filesystem is used, but storage.path is NOT SET IN FILE in [SERVICE]",
      "Outputs ask for filesystem buffering, yet the service section never names the storage directory, so where the buffered data lands is left to defaults.",
      "Set storage.path under [SERVICE] to a directory with room and the right permissions.");
    NS("storage.path in [SERVICE] while outputs use storage.type filesystem");
  }

  notVerified.push("Whether any downstream server actually requires or correctly serves TLS \u2014 this tool never connects to it");
  notVerified.push("Actual network reachability of every listener from other hosts \u2014 firewalls and routing live outside the file");
  notVerified.push("The real values behind ${...} environment references, and whether they are set on the host");
  if(sections.some(function(s){return getE(s,"parsers.file");}))notVerified.push("The contents of the parsers file named by Parsers_File \u2014 it is not part of the pasted text");

  var counts={BLOCKER:0,WARNING:0,INFO:0};
  findings.forEach(function(f){counts[f.sev]++;});
  var verdict=counts.BLOCKER>0?"DO NOT DEPLOY":(counts.WARNING>0?"DEPLOY WITH FIXES":"SAFE TO DEPLOY");
  var rank={BLOCKER:0,WARNING:1,INFO:2};
  findings.sort(function(a,b){if(rank[a.sev]!==rank[b.sev])return rank[a.sev]-rank[b.sev];return (a.line||99999)-(b.line||99999);});
  return {verdict:verdict,findings:findings,counts:counts,notSet:notSet,notVerified:notVerified,notAudited:notAudited,
    format:parsed.format,sections:sections.length,lines:lines.length,notParsedCount:parsed.notParsed.length};
}

/* ---------- Rendering ---------- */
var lastResult=null,lastReport="";

function sevWord(s){return s;}
function render(res){
  lastResult=res;
  var pill=$("verdictPill");
  if(!res||res.empty){
    pill.textContent="Nothing to audit";pill.className="verdict-pill";
    $("chipBlocker").innerHTML="Blockers <b>0</b>";$("chipWarning").innerHTML="Warnings <b>0</b>";
    $("chipInfo").innerHTML="Info <b>0</b>";$("chipNotParsed").innerHTML="Not parsed <b>0</b>";
    $("sbMeta").textContent="Paste a config and run the audit";
    $("findingsBox").innerHTML='<div class="empty-note">The input is empty. Paste a fluent-bit.conf or fluent-bit.yaml \u2014 or load one of the worked examples \u2014 then run the audit.</div>';
    $("fixesBox").innerHTML='<div class="empty-note">No fixes yet \u2014 run an audit first.</div>';
    $("coverageBox").innerHTML='<div class="empty-note">Coverage notes appear after an audit.</div>';
    $("reportPre").textContent="Run an audit to generate the report.";$("reportFallback").value="";lastReport="";
    return;
  }
  pill.textContent=res.verdict;
  pill.className="verdict-pill "+(res.verdict==="DO NOT DEPLOY"?"v-bad":res.verdict==="DEPLOY WITH FIXES"?"v-warn":"v-ok");
  $("chipBlocker").innerHTML="Blockers <b>"+res.counts.BLOCKER+"</b>";
  $("chipWarning").innerHTML="Warnings <b>"+res.counts.WARNING+"</b>";
  $("chipInfo").innerHTML="Info <b>"+res.counts.INFO+"</b>";
  $("chipNotParsed").innerHTML="Not parsed <b>"+res.notParsedCount+"</b>";
  $("sbMeta").textContent=res.format+" \u00B7 "+res.sections+" sections \u00B7 "+res.lines+" lines";

  if(!res.findings.length){
    $("findingsBox").innerHTML='<div class="empty-note">No findings. Nothing in the pasted text tripped a check \u2014 see the Coverage &amp; limits panel for what this tool could not verify.</div>';
  }else{
    $("findingsBox").innerHTML=res.findings.map(function(f){
      return '<article class="finding"><div class="f-head"><span class="sev '+f.sev+'">'+sevWord(f.sev)+'</span>'+
        (f.line?'<span class="linechip">Line '+f.line+'</span>':'<span class="linechip">File-wide</span>')+
        (f.tag?'<span class="tagchip">'+esc(f.tag)+'</span>':'')+
        '<h3>'+esc(f.title)+'</h3></div><p>'+esc(f.why)+'</p><p class="fix"><b>Fix:</b> '+esc(f.fix)+'</p></article>';
    }).join("");
  }
  if(!res.findings.length){
    $("fixesBox").innerHTML='<div class="empty-note">Nothing to fix in the pasted text.</div>';
  }else{
    $("fixesBox").innerHTML='<ol class="fixlist">'+res.findings.map(function(f){
      return '<li>'+esc(f.fix)+' <span class="fl-where">\u2014 '+(f.line?"line "+f.line:"file-wide")+", "+f.sev.toLowerCase()+'</span></li>';
    }).join("")+'</ol>';
  }
  var cov='<h3>Format detected</h3><p>'+esc(res.format)+' \u00B7 '+res.sections+' sections parsed \u00B7 '+res.lines+' lines read \u00B7 '+res.notParsedCount+' line(s) NOT PARSED.</p>';
  cov+='<h3>NOT SET IN FILE</h3>';
  cov+=res.notSet.length?'<ul class="cov-list">'+res.notSet.map(function(s){return '<li>'+esc(s)+'</li>';}).join("")+'</ul>':'<p class="muted">Every key this auditor looks for was present or not applicable.</p>';
  cov+='<h3>NOT VERIFIED by this tool</h3><ul class="cov-list">'+res.notVerified.map(function(s){return '<li>'+esc(s)+'</li>';}).join("")+'</ul>';
  cov+='<h3>NOT AUDITED</h3>';
  cov+=res.notAudited.length?'<ul class="cov-list">'+res.notAudited.map(function(s){return '<li>'+esc(s)+'</li>';}).join("")+'</ul>':'<p class="muted">No @INCLUDE lines in the pasted text.</p>';
  cov+='<h3>What this tool does not do</h3><ul class="cov-list"><li>It does not connect to any host and does not run Fluent Bit.</li><li>It does not verify any downstream server, its certificate, or its TLS.</li><li>It cannot see @INCLUDE files, parsers files, or environment values on the host.</li><li>It grades the pasted text only \u2014 a SAFE TO DEPLOY verdict describes this file, not the machine it lands on.</li></ul>';
  $("coverageBox").innerHTML=cov;

  var out=[];
  out.push("J-Dawgs Fluent Bit Config Safety Auditor\u2122 \u2014 audit report");
  out.push("Format detected: "+res.format+" \u00B7 Sections parsed: "+res.sections+" \u00B7 Lines read: "+res.lines+" \u00B7 NOT PARSED lines: "+res.notParsedCount);
  out.push("VERDICT: "+res.verdict);
  out.push("Counts: "+res.counts.BLOCKER+" BLOCKER \u00B7 "+res.counts.WARNING+" WARNING \u00B7 "+res.counts.INFO+" INFO");
  out.push("");
  out.push("FINDINGS");
  if(!res.findings.length)out.push("(none)");
  res.findings.forEach(function(f,i){
    out.push((i+1)+". ["+f.sev+"] "+(f.line?"Line "+f.line:"File-wide")+(f.tag?" ["+f.tag+"]":"")+" \u2014 "+f.title);
    out.push("   Why: "+f.why);
    out.push("   Fix: "+f.fix);
  });
  out.push("");
  out.push("NOT SET IN FILE");
  if(!res.notSet.length)out.push("(none)");
  res.notSet.forEach(function(s){out.push("- "+s);});
  out.push("");
  out.push("NOT VERIFIED BY THIS TOOL");
  res.notVerified.forEach(function(s){out.push("- "+s);});
  if(res.notAudited.length){out.push("");out.push("NOT AUDITED");res.notAudited.forEach(function(s){out.push("- "+s);});}
  out.push("");
  out.push("Audited locally in the browser \u2014 nothing was uploaded or saved. Secret values are never printed in this report: findings name the key and its line only.");
  lastReport=out.join("\n");
  $("reportPre").textContent=lastReport;
  $("reportFallback").value=lastReport;
}
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-fluent-bit-config-safety-auditortm',
  name: 'J-Dawgs Fluent Bit Config Safety Auditor',
  description: 'Grades a pasted fluent-bit.conf/yaml offline — open HTTP monitoring server, plaintext output TLS, secrets by key name/line only, exposed inputs — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
