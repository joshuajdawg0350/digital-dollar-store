'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Overseerr Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Built-in examples (fake keys, safe to publish) ---------- */

      var RISKY_EXAMPLE = [
        '{',
        '  "main": {',
        '    "applicationTitle": "Overseerr",',
        '    "applicationUrl": "http://203.0.113.40:5055",',
        '    "host": "0.0.0.0",',
        '    "port": 5055,',
        '    "useSsl": false,',
        '    "trustProxy": true,',
        '    "csrfProtection": false,',
        '    "sessionSecret": "changeme",',
        '    "localLogin": true,',
        '    "allowSignup": true,',
        '    "defaultPermissions": 130',
        '  },',
        '  "plex": {',
        '    "name": "Home Plex",',
        '    "ip": "192.168.1.50",',
        '    "port": 32400,',
        '    "useSsl": false,',
        '    "authToken": "FAKEPLEXTOKENa1b2c3d4e5f6"',
        '  },',
        '  "radarr": [',
        '    { "name": "Radarr", "hostname": "192.168.1.50", "port": 7878, "apiKey": "FAKERADARRKEY00112233445566778899", "useSsl": false }',
        '  ],',
        '  "sonarr": [',
        '    { "name": "Sonarr", "hostname": "192.168.1.50", "port": 8989, "apiKey": "FAKESONARRKEY99887766554433221100", "useSsl": false }',
        '  ],',
        '  "notifications": {',
        '    "discord": { "enabled": true, "webhookUrl": "https://discord.com/api/webhooks/1234567890/FAKEWEBHOOKTOKENabcdef" },',
        '    "telegram": { "enabled": true, "botToken": "123456789:FAKEBOTTOKENzzzzzz", "chatId": "5551234" },',
        '    "email": { "enabled": true, "smtpHost": "smtp.example.com", "authPass": "fake-mail-password-123" }',
        '  }',
        '}'
      ].join("\n");

      var HARDENED_EXAMPLE = [
        '{',
        '  "main": {',
        '    "applicationTitle": "Overseerr",',
        '    "applicationUrl": "https://requests.example.com",',
        '    "host": "127.0.0.1",',
        '    "port": 5055,',
        '    "useSsl": true,',
        '    "trustProxy": true,',
        '    "csrfProtection": true,',
        '    "sessionSecret": "${OVERSEERR_SESSION_SECRET}",',
        '    "localLogin": true,',
        '    "allowSignup": false,',
        '    "defaultPermissions": 32',
        '  },',
        '  "plex": {',
        '    "name": "Home Plex",',
        '    "ip": "127.0.0.1",',
        '    "port": 32400,',
        '    "useSsl": true,',
        '    "authToken": "${PLEX_TOKEN}"',
        '  },',
        '  "radarr": [',
        '    { "name": "Radarr", "hostname": "127.0.0.1", "port": 7878, "apiKey": "${RADARR_API_KEY}", "useSsl": true }',
        '  ],',
        '  "sonarr": [',
        '    { "name": "Sonarr", "hostname": "127.0.0.1", "port": 8989, "apiKey": "${SONARR_API_KEY}", "useSsl": true }',
        '  ],',
        '  "notifications": {',
        '    "discord": { "enabled": false, "webhookUrl": "" },',
        '    "telegram": { "enabled": false, "botToken": "${TELEGRAM_BOT_TOKEN}", "chatId": "" },',
        '    "email": { "enabled": true, "smtpHost": "smtp.example.com", "authPass": "${SMTP_PASSWORD}" }',
        '  }',
        '}'
      ].join("\n");

      /* Fake secret values used by the risky example. The self-test uses this
         list to prove none of them ever leak into a report. */
      var EXAMPLE_SECRETS = [
        "FAKEPLEXTOKENa1b2c3d4e5f6",
        "FAKERADARRKEY00112233445566778899",
        "FAKESONARRKEY99887766554433221100",
        "FAKEWEBHOOKTOKENabcdef",
        "FAKEBOTTOKENzzzzzz",
        "fake-mail-password-123",
        "changeme"
      ];

      /* ---------- Parsing ---------- */

      function cleanValue(raw) {
        var v = String(raw).trim();
        if (v.charAt(v.length - 1) === ",") v = v.slice(0, -1).trim();
        if (v.length >= 2) {
          var first = v.charAt(0), last = v.charAt(v.length - 1);
          if ((first === '"' && last === '"') || (first === "'" && last === "'")) {
            v = v.slice(1, -1);
          }
        }
        return v;
      }

      function normKey(key) {
        return String(key).toLowerCase().replace(/[^a-z0-9]/g, "");
      }

      function parseConfig(text) {
        var entries = [];
        var lines = String(text).split(/\r?\n/);
        var jsonRe = /"([^"\\]+)"\s*:\s*("(?:[^"\\]|\\.)*"|-?\d+(?:\.\d+)?|true|false|null)/g;
        for (var i = 0; i < lines.length; i++) {
          var raw = lines[i];
          var lineNo = i + 1;
          var foundJson = false;
          var m;
          jsonRe.lastIndex = 0;
          while ((m = jsonRe.exec(raw)) !== null) {
            foundJson = true;
            entries.push({ line: lineNo, key: m[1], nkey: normKey(m[1]), value: cleanValue(m[2]) });
          }
          if (foundJson) continue;
          var envM = raw.match(/^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_.\-]*)\s*=\s*(.+)$/);
          if (envM) {
            entries.push({ line: lineNo, key: envM[1], nkey: normKey(envM[1]), value: cleanValue(envM[2]) });
            continue;
          }
          var yM = raw.match(/^\s*([A-Za-z][A-Za-z0-9_.\-]*)\s*:\s+(\S.*)$/);
          if (yM) {
            entries.push({ line: lineNo, key: yM[1], nkey: normKey(yM[1]), value: cleanValue(yM[2]) });
          }
        }
        return entries;
      }

      /* ---------- Value helpers ---------- */

      function isTruthy(v) { return /^(true|yes|on|1|enabled)$/i.test(String(v).trim()); }
      function isFalsy(v) { return /^(false|no|off|0|disabled)$/i.test(String(v).trim()); }
      function isEmptyish(v) {
        var s = String(v).trim();
        return s === "" || /^(null|none|disabled|~|undefined)$/i.test(s);
      }
      function isReference(v) {
        var s = String(v).trim();
        return /^\$\{[^}]+\}$/.test(s) || /^(env|vault|file|secret|keychain):/i.test(s);
      }
      function isAllInterfaces(v) {
        var s = String(v).trim();
        return s === "0.0.0.0" || s === "::" || s === "*" || s === "[::]";
      }
      function isLoopback(v) {
        var s = String(v).trim().toLowerCase();
        return s === "127.0.0.1" || s === "localhost" || s === "::1";
      }

      var EXAMPLE_WORDS = ["changeme", "change-me", "change_me", "secret", "password", "passwd",
        "example", "test", "testing", "default", "overseerr", "jellyseerr", "placeholder",
        "your-secret-here", "yoursecrethere", "todo", "xxx", "123456", "12345678", "letmein", "admin"];

      function isExampleSecret(v) {
        var s = String(v).trim().toLowerCase();
        if (EXAMPLE_WORDS.indexOf(s) !== -1) return true;
        return s.indexOf("changeme") !== -1 || s.indexOf("example") !== -1 ||
               s.indexOf("placeholder") !== -1 || s.indexOf("your-") !== -1;
      }

      /* ---------- Secret classification ----------
         Returns a human label for credential-type keys, or null.
         Session-type secrets are graded by strength instead of presence. */
      var SESSION_KEYS = { sessionsecret: 1, csrfsecret: 1, jwtsecret: 1, secretkey: 1, appsecret: 1, secret: 1 };

      function secretClass(nkey) {
        if (SESSION_KEYS[nkey]) return null;
        if (nkey === "authtoken" || nkey === "plextoken" || nkey === "plexauthtoken" || nkey === "plexusertoken") return "Plex token";
        if (nkey === "apikey") return "Service API key";
        if (nkey === "webhookurl" || nkey === "webhook" || nkey === "webhooktoken") return "Notification webhook (carries a token in the URL)";
        if (nkey === "bottoken") return "Notification bot token";
        if (nkey === "applicationtoken" || nkey === "userkey" || nkey === "apitoken" ||
            nkey === "accesstoken" || nkey === "refreshtoken" || nkey === "token" ||
            nkey === "pushovertoken" || nkey === "gotifytoken") return "Access token";
        if (nkey === "authpass" || nkey === "smtppassword" || nkey === "emailpassword" ||
            nkey === "password" || nkey === "passwd") return "Password";
        if (nkey === "vapidprivatekey" || nkey === "privatekey") return "Private key";
        if (nkey === "clientsecret") return "Client secret";
        return null;
      }

      var KNOWN_KEYS = {
        host: 1, bind: 1, bindaddress: 1, listenaddress: 1, port: 1, baseurl: 1,
        applicationurl: 1, applicationtitle: 1, usessl: 1, ssl: 1, https: 1,
        trustproxy: 1, reverseproxy: 1, behindproxy: 1, proxy: 1,
        csrfprotection: 1, csrf: 1, defaultpermissions: 1, defaultrole: 1,
        allowsignup: 1, publicsignup: 1, enablesignup: 1, signupenabled: 1,
        openregistration: 1, allowregistration: 1, locallogin: 1, newplexlogin: 1,
        nodeenv: 1, environment: 1, debug: 1, hostname: 1, ip: 1, name: 1,
        enabled: 1, smtphost: 1, chatid: 1, cacheimages: 1, hideavailable: 1,
        region: 1, originallanguage: 1, partialrequestsenabled: 1
      };

      function isRecognized(e) {
        if (KNOWN_KEYS[e.nkey] || SESSION_KEYS[e.nkey] || secretClass(e.nkey)) return true;
        return /plex|radarr|sonarr|discord|telegram|slack|notification|pushover|gotify|webpush/.test(e.nkey);
      }

      /* ---------- The audit ---------- */

      function auditConfig(text) {
        var entries = parseConfig(text);
        var findings = [];
        var recognized = 0;
        var i, e;

        for (i = 0; i < entries.length; i++) if (isRecognized(entries[i])) recognized++;

        function add(severity, line, key, title, detail, fix) {
          findings.push({ severity: severity, line: line, key: key, title: title, detail: detail, fix: fix });
        }
        function firstEntry(names) {
          for (var j = 0; j < entries.length; j++) if (names.indexOf(entries[j].nkey) !== -1) return entries[j];
          return null;
        }
        function anyEntry(pred) {
          for (var j = 0; j < entries.length; j++) if (pred(entries[j])) return entries[j];
          return null;
        }

        if (recognized < 3) {
          return {
            verdict: "NOT ENOUGH TO GRADE",
            recognized: recognized,
            findings: [{
              severity: "minor", line: 0, key: "—",
              title: "Too little recognizable Overseerr config to grade",
              detail: "The pasted text yielded " + recognized + " recognizable Overseerr setting(s). A grade needs the network, login/session, and service sections of the config.",
              fix: "Paste more of the config — ideally the full settings block, including host/port, application URL, session/CSRF settings, default permissions, and the Plex / Radarr / Sonarr / notification sections."
            }],
            counts: { critical: 0, major: 0, minor: 1 }
          };
        }

        /* --- Posture evidence gathered across the whole paste --- */
        var hostEntry = firstEntry(["host", "bind", "bindaddress", "listenaddress"]);
        var urlEntry = firstEntry(["applicationurl", "baseurl", "externalurl", "appurl"]);
        var sslEntry = anyEntry(function (x) {
          return (x.nkey === "usessl" || x.nkey === "ssl" || x.nkey === "https" || x.nkey === "tlsenabled") && isTruthy(x.value);
        });
        var proxyEntry = anyEntry(function (x) {
          return (x.nkey === "reverseproxy" || x.nkey === "behindproxy") && isTruthy(x.value);
        });
        var urlIsHttps = urlEntry && /^https:\/\//i.test(urlEntry.value);
        var urlIsHttp = urlEntry && /^http:\/\//i.test(urlEntry.value);
        var tlsEvidence = !!(sslEntry || proxyEntry || urlIsHttps);
        var proxyEvidence = tlsEvidence;
        var exposed = hostEntry && isAllInterfaces(hostEntry.value);

        /* --- Rule: bind exposure --- */
        if (exposed && !tlsEvidence) {
          add("critical", hostEntry.line, hostEntry.key,
            "App bound to all network interfaces over plain HTTP",
            "The bind host is set to listen on every interface, and nothing in the pasted config shows TLS or a reverse proxy in front of it. Anyone who can reach this machine's IP can reach the Overseerr login page — and everything typed into it — in the clear.",
            "Bind to 127.0.0.1 and put Overseerr behind a reverse proxy that serves HTTPS, or enable TLS in the app. Do not expose the raw port to a network you do not fully control.");
        } else if (exposed && tlsEvidence) {
          add("minor", hostEntry.line, hostEntry.key,
            "App bound to all network interfaces",
            "The bind host listens on every interface. TLS or proxy evidence exists elsewhere in the config, but the raw app port is still reachable directly, bypassing that protection.",
            "Bind to 127.0.0.1 (or a private interface) so the proxy is the only way in, and firewall the app port.");
        }
        if (!hostEntry && firstEntry(["port"])) {
          var portE = firstEntry(["port"]);
          add("minor", portE.line, portE.key,
            "No bind host in the pasted text",
            "A port is set but no bind/listen host appears, so the application's default listen address applies — for Overseerr that means all interfaces unless you changed it elsewhere.",
            "Set the bind host explicitly (127.0.0.1 when a reverse proxy fronts the app) so the exposure is a decision, not a default.");
        }

        /* --- Rule: public URL over plain HTTP --- */
        if (urlIsHttp && !isLoopback(urlEntry.value.replace(/^http:\/\//i, "").split(/[:\/]/)[0])) {
          add("major", urlEntry.line, urlEntry.key,
            "Application URL is plain HTTP",
            "The public application URL uses http://, so logins, session cookies, and request traffic to that address travel unencrypted.",
            "Serve Overseerr over HTTPS (reverse proxy with a valid certificate is the usual route) and update the application URL to the https:// address.");
        }

        /* --- Rule: session / CSRF secret posture --- */
        var sessionEntry = anyEntry(function (x) { return !!SESSION_KEYS[x.nkey]; });
        if (!sessionEntry) {
          add("major", 0, "sessionSecret",
            "No session/CSRF secret found in the pasted text",
            "No session secret, CSRF secret, or signing key appears anywhere in the paste. If the deployment truly runs without one (or with a built-in default), sessions can be forged and logins cannot be trusted.",
            "Set a long, random, deployment-only session secret (32+ characters) through your secret store or environment, and confirm CSRF protection is enabled. If the secret lives in a part of the config you did not paste, this finding does not apply.");
        } else if (!isReference(sessionEntry.value) && !isEmptyish(sessionEntry.value)) {
          if (isExampleSecret(sessionEntry.value)) {
            add("critical", sessionEntry.line, sessionEntry.key,
              "Session secret is a known example value",
              "The session/CSRF secret at this line is a placeholder or example word (reported by length only: " + sessionEntry.value.length + " characters). Anyone who has seen the same example can forge sessions for this server.",
              "Replace it with a fresh random secret of at least 32 characters, unique to this deployment, and restart the server so old sessions die.");
          } else if (sessionEntry.value.length < 32) {
            add("critical", sessionEntry.line, sessionEntry.key,
              "Session secret is too short",
              "The session/CSRF secret at this line is " + sessionEntry.value.length + " characters long. Short secrets are guessable and brute-forceable, and this one guards every login session.",
              "Generate a random secret of at least 32 characters (64 is better) and store it in your secret store or environment, not in a shared example file.");
          }
        }
        var csrfEntry = firstEntry(["csrfprotection", "csrf"]);
        if (csrfEntry && isFalsy(csrfEntry.value)) {
          add("major", csrfEntry.line, csrfEntry.key,
            "CSRF protection is turned off",
            "With CSRF protection disabled, a malicious page in a logged-in admin's browser can make Overseerr change settings or approve requests using that admin's session.",
            "Turn CSRF protection back on. If a proxy or client breaks with it enabled, fix that integration instead of disabling the protection.");
        }

        /* --- Rule: trustProxy / forwarded headers --- */
        var tpEntry = firstEntry(["trustproxy"]);
        if (tpEntry && isTruthy(tpEntry.value) && !proxyEvidence) {
          add("major", tpEntry.line, tpEntry.key,
            "trustProxy is on, but nothing shows a proxy in front",
            "trustProxy tells Overseerr to believe X-Forwarded-For and similar headers from whoever connects. With no reverse proxy in front, any visitor can send those headers themselves and spoof their IP — defeating IP-based rate limits, bans, and audit logs.",
            "Either put Overseerr behind a real reverse proxy that sets (and strips inbound) forwarded headers, or turn trustProxy off.");
        }
        if (tpEntry && isFalsy(tpEntry.value) && urlIsHttps) {
          add("minor", tpEntry.line, tpEntry.key,
            "trustProxy is off behind an HTTPS address",
            "The application URL is https:// (so a proxy is likely terminating TLS), but trustProxy is off — Overseerr will see the proxy's IP for every visitor, so per-IP rate limiting and logs lose their meaning.",
            "If a reverse proxy really fronts this app, turn trustProxy on and make sure the proxy is the only thing that can reach the app port.");
        }

        /* --- Rule: public signup --- */
        var signupEntry = anyEntry(function (x) {
          return ["allowsignup", "publicsignup", "enablesignup", "signupenabled", "openregistration", "allowregistration"].indexOf(x.nkey) !== -1 && isTruthy(x.value);
        });
        if (signupEntry) {
          add("major", signupEntry.line, signupEntry.key,
            "Public signup / open registration is enabled",
            "Anyone who can reach the server can create an account. On a request manager, a stranger's account is a foothold: they can file requests, probe the library, and wait for a permissions mistake.",
            "Turn public signup off. Create accounts yourself, or let people in through Plex sign-in with an explicit allow-list.");
        }

        /* --- Rule: default permissions for new users --- */
        var permEntry = anyEntry(function (x) {
          return x.nkey === "defaultpermissions" || x.nkey === "defaultrole" || x.nkey === "defaultuserpermissions";
        });
        if (permEntry) {
          var pv = permEntry.value;
          var asNum = parseInt(pv, 10);
          if (!isNaN(asNum) && String(asNum) === String(pv).trim()) {
            if (asNum & 2) {
              add("critical", permEntry.line, permEntry.key,
                "Default permissions hand new users the ADMIN bit",
                "Overseerr permissions are a bit flag; the value at this line (" + asNum + ") includes bit 2, which is ADMIN. Every new account created under these defaults starts as a full administrator.",
                "Set default permissions to the request-only bit (32) — or 0 — and grant extra rights per user, by hand, after you know who they are.");
            }
            if (asNum & 896) { /* 128 + 256 + 512: auto-approve bits */
              add("major", permEntry.line, permEntry.key,
                "Default permissions auto-approve new users' requests",
                "The permission value at this line (" + asNum + ") includes one or more auto-approve bits (128 / 256 / 512). New users' movie and TV requests would download with no human ever looking at them.",
                "Remove the auto-approve bits from the defaults. Give auto-approve only to specific trusted users.");
            }
          } else if (/admin/i.test(pv)) {
            add("critical", permEntry.line, permEntry.key,
              "Default role for new users is admin",
              "The default permissions/role at this line name an admin-level role, so every new account starts with full control of the server and its connected services.",
              "Set the default role to a plain requester role and promote people individually.");
          } else if (/auto.?approve/i.test(pv)) {
            add("major", permEntry.line, permEntry.key,
              "Default permissions auto-approve new users' requests",
              "The default permissions at this line include auto-approve, so new users' requests download with no human review.",
              "Remove auto-approve from the defaults; grant it per user.");
          }
        }

        /* --- Rule: plaintext third-party secrets (value NEVER reported) --- */
        for (i = 0; i < entries.length; i++) {
          e = entries[i];
          var cls = secretClass(e.nkey);
          if (!cls) continue;
          if (isEmptyish(e.value) || isReference(e.value)) continue;
          add("major", e.line, e.key,
            cls + " stored in plaintext",
            "This key holds a live-looking credential as a literal value in the config text (reported by length only: " + e.value.length + " characters; the value itself is never shown). Anyone who can read this file — a backup, a screenshot, a pasted debug log — holds the credential.",
            "Move the credential into a secret store or environment variable and reference it from the config, restrict the config file's permissions, and rotate the credential if this text has ever been shared.");
        }

        /* --- Rule: development posture --- */
        var envEntry = anyEntry(function (x) {
          return (x.nkey === "nodeenv" || x.nkey === "environment" || x.nkey === "appenv") && /^(development|dev|debug)$/i.test(x.value);
        });
        if (envEntry) {
          add("major", envEntry.line, envEntry.key,
            "Server is set to a development environment",
            "A development posture typically enables verbose errors and relaxed checks, and can leak stack traces and internals to visitors.",
            "Set the environment to production for any deployment other people can reach.");
        }
        var debugEntry = anyEntry(function (x) { return x.nkey === "debug" && isTruthy(x.value); });
        if (debugEntry) {
          add("minor", debugEntry.line, debugEntry.key,
            "Debug mode is on",
            "Debug output can expose paths, settings, and request details to anyone who can trigger an error page.",
            "Turn debug off for deployment; enable it only while actively troubleshooting.");
        }

        /* --- Verdict --- */
        var counts = { critical: 0, major: 0, minor: 0 };
        var order = { critical: 0, major: 1, minor: 2 };
        for (i = 0; i < findings.length; i++) counts[findings[i].severity]++;
        findings.sort(function (a, b) {
          if (order[a.severity] !== order[b.severity]) return order[a.severity] - order[b.severity];
          return a.line - b.line;
        });
        var verdict = counts.critical > 0 ? "DO NOT DEPLOY"
          : (counts.major > 0 || counts.minor > 0) ? "DEPLOY WITH FIXES"
          : "SAFE TO DEPLOY";
        return { verdict: verdict, recognized: recognized, findings: findings, counts: counts };
      }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined), "EXAMPLE_SECRETS": (typeof EXAMPLE_SECRETS !== 'undefined' ? EXAMPLE_SECRETS : undefined), "EXAMPLE_WORDS": (typeof EXAMPLE_WORDS !== 'undefined' ? EXAMPLE_WORDS : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-overseerr-server-config-safety-auditortm',
  name: 'J-Dawgs Overseerr Server Config Safety Auditor',
  description: 'Overseerr\'s own checks only answer whether the service starts on the host; ours grades a pasted Overseerr settings or config fully offline — sign-in left open, a short or example API key, plaintext Plex, Sonarr, and Radarr credentials — into one deploy verdict, with secrets shown by key name, line, ',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"], "EXAMPLE_SECRETS": __core["EXAMPLE_SECRETS"], "EXAMPLE_WORDS": __core["EXAMPLE_WORDS"] }
};
