'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs YADIFA Authoritative DNS Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Worked examples (line numbers are exact by construction) ---------- */

      var RISKY_EXAMPLE = [
        "<main>",
        "listen 0.0.0.0",
        "daemon off",
        "user root",
        "allow-transfer any",
        "allow-update 0.0.0.0/0",
        "allow-notify any",
        "statistics on",
        "queries-log all",
        "</main>",
        "<key>",
        "name badkey",
        "algorithm hmac-md5",
        "secret c2VjcmV0",
        "</key>",
        "<zone>",
        "domain example.com",
        "</zone>"
      ].join("\n");

      var HARDENED_EXAMPLE = [
        "<main>",
        "listen 127.0.0.1",
        "daemon on",
        "user yadifa",
        "allow-transfer 192.0.2.10",
        "allow-update none",
        "allow-notify 192.0.2.10",
        "statistics off",
        "</main>",
        "<key>",
        "name goodkey",
        "algorithm hmac-sha256",
        "secret aGVsbG9Xb3JsZEhhcmRlbmVkU2VjcmV0S2V5MTIzNDU2Nzg=",
        "</key>",
        "<zone>",
        "domain example.com",
        "dnssec on",
        "</zone>"
      ].join("\n");

      /* ---------- Parsing + audit (pure, no I/O) ---------- */

      var KNOWN_KEYS = new Set([
        "listen","daemon","user","username","daemon-user","uid","gid",
        "allow-transfer","allow-update","allow-notify","allow-query","allow-query-on",
        "allow-control","control","statistics","queries-log","querieslog","log",
        "port","dns-port","edns","dnssec","dnssec-policy","dnssec-mode",
        "name","algorithm","secret","domain","type","file","master","masters",
        "acl","channel","channels","server","address","tsig","key","keys",
        "directory","pid-file","pidfile","hostname","version","notify","also-notify",
        "allow","deny","xfr","update","journal","database","zonefile","signing",
        "max-tcp-connections","tcp-connections","rate-limit","rrl","chroot","logpath"
      ]);

      var BARE_KEYS = new Set(["daemon"]);

      var EXAMPLE_SECRETS = new Set([
        "changeme","secret","example","aaaa","base64secret==","password","test","demo"
      ]);

      function valueTokens(value) {
        return String(value).toLowerCase().split(/[\s;{},"]+/).filter(function (t) { return t.length > 0; });
      }

      function isOpenValue(value) {
        var tk = valueTokens(value);
        return tk.indexOf("any") >= 0 || tk.indexOf("0.0.0.0/0") >= 0 ||
               tk.indexOf("::/0") >= 0 || tk.indexOf("*") >= 0;
      }

      function isOpenNetwork(value) {
        var tk = valueTokens(value);
        return tk.indexOf("0.0.0.0/0") >= 0 || tk.indexOf("::/0") >= 0;
      }

      function isOnValue(value) {
        var tk = valueTokens(value);
        return tk.indexOf("on") >= 0 || tk.indexOf("yes") >= 0 || tk.indexOf("true") >= 0 ||
               tk.indexOf("1") >= 0 || tk.indexOf("enabled") >= 0 || tk.indexOf("enable") >= 0;
      }

      function isOffValue(value) {
        var tk = valueTokens(value);
        return tk.indexOf("off") >= 0 || tk.indexOf("no") >= 0 || tk.indexOf("none") >= 0 ||
               tk.indexOf("disabled") >= 0 || tk.indexOf("false") >= 0 || tk.indexOf("0") >= 0;
      }

      /* Redact any secret value in a line of text before it is stored or shown. */
      function redactSecretText(text) {
        return String(text).replace(/(secret\s+)\S+/gi, function (m, head) { return head + "[REDACTED]"; });
      }

      function cleanSecretValue(value) {
        var v = String(value).split("#")[0].trim();
        v = v.replace(/^["']/, "").replace(/["';]+$/, "");
        var parts = v.split(/\s+/);
        return parts.length ? parts[0] : "";
      }

      function auditConfig(text) {
        var findings = [];
        var commented = [];
        var notParsed = [];
        var directives = [];
        var sectionsSeen = [];
        var zoneOpenLines = [];
        var current = null;
        var recognized = false;

        var rawText = (text === null || text === undefined) ? "" : String(text);
        var lines = rawText.split(/\r\n|\r|\n/);

        for (var i = 0; i < lines.length; i++) {
          var lineNo = i + 1;
          var t = lines[i].trim();

          if (t === "") continue;

          if (t.charAt(0) === "#") {
            commented.push({ line: lineNo, text: redactSecretText(t) });
            continue;
          }

          var closeM = t.match(/^<\/\s*([A-Za-z0-9_-]+)\s*>$/);
          if (closeM) { current = null; continue; }

          var openM = t.match(/^<\s*([A-Za-z0-9_-]+)\s*[^>]*>$/);
          if (openM) {
            current = { name: openM[1].toLowerCase(), line: lineNo };
            sectionsSeen.push(current.name);
            recognized = true;
            if (current.name === "zone") zoneOpenLines.push(lineNo);
            continue;
          }

          if (t === "{" || t === "}") continue;

          var kv = t.match(/^([A-Za-z][A-Za-z0-9_-]*)\s+(.+)$/);
          if (kv) {
            var key = kv[1].toLowerCase();
            var value = kv[2].trim();
            var knownKey = KNOWN_KEYS.has(key);
            /* Inside a section, a key-value-shaped line whose key is not a
               recognizable YADIFA key (and not an ACL / channel entry name or
               a block definition) cannot be placed — report it NOT PARSED. */
            var freeformSection = current && (current.name === "acl" || current.name === "channels");
            if (current && !knownKey && !freeformSection && value.indexOf("{") < 0) {
              notParsed.push(lineNo);
              continue;
            }
            directives.push({ line: lineNo, section: current ? current.name : null, key: key, value: value, raw: t });
            if (knownKey) recognized = true;
            continue;
          }

          if (/^[A-Za-z][A-Za-z0-9_-]*$/.test(t) && BARE_KEYS.has(t.toLowerCase())) {
            directives.push({ line: lineNo, section: current ? current.name : null, key: t.toLowerCase(), value: "", raw: t });
            recognized = true;
            continue;
          }

          if (current) notParsed.push(lineNo);
        }

        /* Pass 1: is anything wide open? (drives listen severity escalation) */
        var openAclPresent = directives.some(function (d) {
          if ((d.key === "allow-transfer" || d.key === "allow-update" || d.key === "allow-notify" ||
               d.key === "allow-query" || d.key === "allow-control") && isOpenValue(d.value)) return true;
          if (d.section === "acl" && isOpenValue(d.raw)) return true;
          if (d.key === "acl" && isOpenValue(d.value)) return true;
          return false;
        });

        function add(severity, line, check, message) {
          findings.push({ line: line, severity: severity, check: check, message: message });
        }

        /* Pass 2: the checks, in file order */
        var currentKeyName = null;
        var hasDnssecSetting = false;
        var dnssecOffLine = 0;

        directives.forEach(function (d) {
          var tk = valueTokens(d.value);

          if (d.key === "dnssec" || d.key === "dnssec-policy" || d.key === "dnssec-mode") {
            hasDnssecSetting = true;
            if (isOffValue(d.value)) dnssecOffLine = d.line;
          }

          /* 1. Wildcard listen */
          if (d.key === "listen") {
            var wild = tk.indexOf("0.0.0.0") >= 0 || tk.indexOf("*") >= 0 || d.value.indexOf("::") >= 0;
            if (wild) {
              add(openAclPresent ? "CRITICAL" : "HIGH", d.line, "Wildcard listen address",
                "listen is set to a wildcard address (" + d.value + "), so the server answers on every network interface. " +
                (openAclPresent
                  ? "Combined with the open access rules in this config, that exposure is critical."
                  : "Bind it to the specific addresses that should serve DNS."));
            }
          }

          /* 2. Open zone transfer */
          if (d.key === "allow-transfer" && isOpenValue(d.value)) {
            add("CRITICAL", d.line, "Open zone transfer (allow-transfer)",
              "allow-transfer is open (" + d.value + "). Anyone who can reach this server can download the full zone. Restrict transfers to trusted secondary servers by address.");
          }

          /* 3. Open dynamic update */
          if (d.key === "allow-update" && isOpenValue(d.value)) {
            add("CRITICAL", d.line, "Open dynamic update (allow-update)",
              "allow-update is open (" + d.value + "). Anyone who can reach this server can try to change zone records. Refuse updates or restrict them to named, TSIG-signed sources.");
          }

          /* 4. Open notify / query */
          if ((d.key === "allow-notify" || d.key === "allow-query" || d.key === "allow-query-on") && isOpenValue(d.value)) {
            add(isOpenNetwork(d.value) ? "CRITICAL" : "HIGH", d.line,
              "Open access (" + d.key + ")",
              d.key + " is open (" + d.value + "), so this server accepts " +
              (d.key === "allow-notify" ? "notifications" : "queries") +
              " from anywhere. Restrict it to the addresses that legitimately need it.");
          }

          /* 5. Open ACL definition */
          if ((d.section === "acl" && isOpenValue(d.raw) && d.key !== "allow-transfer" && d.key !== "allow-update") ||
              (d.key === "acl" && isOpenValue(d.value))) {
            add("CRITICAL", d.line, "Open ACL definition",
              "This ACL entry is open to any source (" + redactSecretText(d.raw) + "). Any rule that trusts this ACL trusts the whole internet.");
          }

          /* 6. TSIG keys */
          if (d.section === "key" && d.key === "name") {
            currentKeyName = tk.length ? d.value.split(/\s+/)[0] : null;
          }
          if (d.key === "algorithm" && d.section === "key") {
            if (d.value.toLowerCase().indexOf("hmac-md5") >= 0) {
              add("HIGH", d.line, "Weak TSIG algorithm",
                "TSIG key \"" + (currentKeyName || "unnamed") + "\" uses hmac-md5, a weak algorithm that should no longer protect zone transfers or updates. Move to hmac-sha256.");
            }
          }
          if (d.key === "secret") {
            var secretVal = cleanSecretValue(d.value);
            var keyLabel = (d.section === "key" && currentKeyName) ? currentKeyName : "unnamed";
            if (secretVal.length < 16 || EXAMPLE_SECRETS.has(secretVal.toLowerCase())) {
              add("HIGH", d.line, "Short or example TSIG secret",
                "TSIG secret for key \"" + keyLabel + "\" on line " + d.line + " is only " + secretVal.length +
                " characters long" + (EXAMPLE_SECRETS.has(secretVal.toLowerCase()) ? " and matches a well-known example value" : "") +
                ". Short or example secrets can be guessed. Use a long, randomly generated secret (reported here by length only — the value is never printed).");
            }
          }

          /* 7. Statistics / query-log exposure */
          if (d.key === "statistics" && isOnValue(d.value)) {
            add("MEDIUM", d.line, "Statistics enabled",
              "statistics is on. Server statistics reveal query volumes and zone details; make sure the statistics output is not reachable by the public.");
          }
          if ((d.key === "queries-log" || d.key === "querieslog") && !isOffValue(d.value)) {
            add("MEDIUM", d.line, "Query logging enabled",
              "queries-log is set (" + d.value + "). Full query logs record every name clients look up — a privacy and data-exposure risk if the log is readable by anyone but the operator.");
          }
          if (d.section === "channels") {
            var rawLow = d.raw.toLowerCase();
            var mentionsData = d.key === "queries" || d.key === "statistics" ||
              rawLow.indexOf("queries") >= 0 || rawLow.indexOf("statistics") >= 0;
            var toSink = rawLow.indexOf("file") >= 0 || rawLow.indexOf("syslog") >= 0;
            if (mentionsData && toSink) {
              add("HIGH", d.line, "Logging channel exposes queries/statistics",
                "This <channels> entry routes queries or statistics to a file or syslog sink. Anyone who can read that sink learns what clients are resolving; lock down its permissions and retention.");
            }
          }

          /* 8. Running as root */
          if (d.key === "user" || d.key === "username" || d.key === "daemon-user" || d.key === "uid") {
            if (tk.indexOf("root") >= 0 || tk.indexOf("0") >= 0) {
              add("HIGH", d.line, "Server runs as root",
                "The daemon user is set to \"" + d.value + "\". A DNS server reachable from the network should run as a dedicated unprivileged user, so a compromise does not hand over the whole machine.");
            }
          }

          /* 9. Port / control exposure */
          if ((d.key === "port" || d.key === "dns-port") && tk.length && tk[0] !== "53") {
            add("MEDIUM", d.line, "Non-standard DNS port",
              "port is set to " + tk[0] + " instead of 53. That is sometimes deliberate (for example behind a redirect), but resolvers expect authoritative DNS on port 53 — confirm this is intentional.");
          }
          if ((d.key === "allow-control" || d.key === "control") && isOpenValue(d.value)) {
            add("MEDIUM", d.line, "Control channel open",
              d.key + " is open (" + d.value + "). A remotely reachable control channel should be bound to localhost or a management address only.");
          }

          /* 10. EDNS posture */
          if (d.key === "edns" && isOffValue(d.value)) {
            add("LOW", d.line, "EDNS disabled",
              "edns is disabled. Modern resolvers and DNSSEC validation rely on EDNS; turning it off can cause resolution failures and fallback behavior.");
          }
        });

        /* 10 (cont). DNSSEC posture notes — notes only, never force DO NOT SERVE */
        if (zoneOpenLines.length > 0 && !hasDnssecSetting) {
          add("LOW", zoneOpenLines[0], "DNSSEC posture not stated",
            "No dnssec or dnssec-policy setting appears for the zone starting on this line. Note: zone signing state lives partly outside this file (key storage, signing policy, and the zone itself), so this auditor cannot confirm whether the zone is actually signed.");
        } else if (dnssecOffLine > 0) {
          add("LOW", dnssecOffLine, "DNSSEC switched off in config",
            "A dnssec setting is present but switched off. Note: zone signing state lives partly outside this file, so this auditor cannot confirm the signing state of the zone from the config alone.");
        }

        findings.sort(function (a, b) { return a.line - b.line; });

        /* Verdict */
        var verdict;
        if (!recognized) {
          verdict = "NOT ENOUGH TO GRADE";
        } else if (findings.some(function (f) { return f.severity === "CRITICAL"; })) {
          verdict = "DO NOT SERVE";
        } else if (findings.some(function (f) { return f.severity === "HIGH"; })) {
          verdict = "SERVE WITH FIXES";
        } else {
          verdict = "SAFE TO SERVE";
        }

        return { verdict: verdict, findings: findings, commented: commented, notParsed: notParsed };
      }

      window.__auditConfig = auditConfig;

      /* ---------- Report builders ---------- */

      function countSeverity(findings, sev) {
        return findings.filter(function (f) { return f.severity === sev; }).length;
      }

      function buildTextReport(result) {
        var out = [];
        out.push("J-Dawgs YADIFA Authoritative DNS Server Config Safety Auditor\u2122 — Audit Report");
        out.push("Generated locally in your browser. Nothing was uploaded or saved.");
        out.push("");
        out.push("VERDICT: " + result.verdict);
        out.push("Findings: " + result.findings.length +
          " (CRITICAL " + countSeverity(result.findings, "CRITICAL") +
          ", HIGH " + countSeverity(result.findings, "HIGH") +
          ", MEDIUM " + countSeverity(result.findings, "MEDIUM") +
          ", LOW " + countSeverity(result.findings, "LOW") + ")");
        out.push("");
        if (result.findings.length) {
          out.push("FINDINGS");
          result.findings.forEach(function (f) {
            out.push("[" + f.severity + "] Line " + f.line + " — " + f.check + ": " + f.message);
          });
        } else {
          out.push("FINDINGS");
          out.push("No active findings.");
        }
        out.push("");
        out.push("COMMENTED / NOT ACTIVE LINES: " + result.commented.length);
        result.commented.forEach(function (c) {
          out.push("Line " + c.line + ": " + c.text);
        });
        out.push("");
        out.push("NOT PARSED LINES: " + (result.notParsed.length ? result.notParsed.join(", ") : "none"));
        out.push("");
        out.push("LIMITS: This report covers the pasted config text only. It does not start YADIFA, validate zone files, check live DNS, or guarantee DNSSEC signing state — zone signing state lives partly outside this file. TSIG secrets are reported by key name, line, and length only; secret values never appear in this report.");
        return out.join("\n");
      }

      function buildJsonExport(result) {
        return {
          tool: "J-Dawgs YADIFA Authoritative DNS Server Config Safety Auditor\u2122",
          verdict: result.verdict,
          summary: {
            findings: result.findings.length,
            critical: countSeverity(result.findings, "CRITICAL"),
            high: countSeverity(result.findings, "HIGH"),
            medium: countSeverity(result.findings, "MEDIUM"),
            low: countSeverity(result.findings, "LOW"),
            commentedLines: result.commented.length,
            notParsedLines: result.notParsed.length
          },
          findings: result.findings.map(function (f) {
            return { line: f.line, severity: f.severity, check: f.check, message: f.message };
          }),
          commented: result.commented.map(function (c) {
            return { line: c.line, status: "COMMENTED / NOT ACTIVE", text: c.text };
          }),
          notParsed: result.notParsed.slice()
        };
      }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined), "EXAMPLE_SECRETS": (typeof EXAMPLE_SECRETS !== 'undefined' ? EXAMPLE_SECRETS : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-yadifa-authoritative-dns-server-config-safety-auditortm',
  name: 'J-Dawgs YADIFA Authoritative DNS Server Config Safety Auditor',
  description: 'Grades a pasted yadifad.conf offline — open transfer/update ACLs, weak TSIG, root daemon — into one serve verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"], "EXAMPLE_SECRETS": __core["EXAMPLE_SECRETS"] }
};
