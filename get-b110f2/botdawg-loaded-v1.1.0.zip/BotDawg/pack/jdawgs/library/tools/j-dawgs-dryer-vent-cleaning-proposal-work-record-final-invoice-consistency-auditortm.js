'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Dryer Vent Cleaning Proposal, Work Record & Final Invoice Consistency Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- helpers ---------- */
      function round2(n){ return Math.round((n + Number.EPSILON) * 100) / 100; }
      function money(n){
        var v = round2(n);
        var s = Math.abs(v).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        return (v < 0 ? "-$" : "$") + s;
      }
      function num(n){ return String(Math.round(n * 100) / 100); }
      function normLabel(s){ return s.toLowerCase().replace(/[^a-z0-9 ]+/g, " ").replace(/\s+/g, " ").trim(); }
      function firstPlainNumber(line){
        var s = line.replace(/\$\s*[\d,]+(?:\.\d{1,2})?/g, " ");
        var m = s.match(/[\d]+(?:\.\d+)?/);
        return m ? parseFloat(m[0]) : null;
      }
      function esc(s){
        return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
      }

      var ADDONS = [
        { key: "birdGuard",  name: "Bird guard",           keys: ["bird guard", "birdguard"] },
        { key: "boosterFan", name: "Booster fan cleaning", keys: ["booster fan"] },
        { key: "roofTerm",   name: "Roof termination",     keys: ["roof termination"] }
      ];

      /* ---------- parser ---------- */
      function pushItem(doc, label, amount, key, isField){
        if (isField){
          for (var i = 0; i < doc.items.length; i++){
            if (doc.items[i].key === key){ doc.items[i].amount = amount; doc.items[i].label = label; return doc.items[i]; }
          }
        }
        var it = { label: label, key: key, amount: amount, counted: false };
        doc.items.push(it);
        return it;
      }
      function itemByKey(doc, key){
        for (var i = 0; i < doc.items.length; i++){ if (doc.items[i].key === key) return doc.items[i]; }
        return null;
      }

      function parseDoc(text, kind){
        var doc = {
          kind: kind, present: !!(text && text.trim().length > 0),
          ventFeet: null, ventRate: null, ventCharge: null,
          stories: null, storiesCharge: null,
          laborHours: null, laborRate: null, laborCharge: null,
          depositPaid: null, depositCredited: null, total: null,
          addons: {}, items: [], included: []
        };
        ADDONS.forEach(function(a){ doc.addons[a.key] = { amount: null, done: null }; });
        if (!doc.present) return doc;

        var lines = text.split(/\r?\n/);
        lines.forEach(function(raw){
          var line = raw.trim();
          if (!line) return;
          var low = line.toLowerCase();
          var label = (line.split(":")[0] || "").toLowerCase();
          var amounts = [];
          var m, re = /\$\s*([\d,]+(?:\.\d{1,2})?)/g;
          while ((m = re.exec(line)) !== null){ amounts.push(parseFloat(m[1].replace(/,/g, ""))); }
          var i, a, key;

          /* total */
          if (label.indexOf("total") !== -1){
            if (amounts.length) doc.total = amounts[amounts.length - 1];
            return;
          }
          /* deposit */
          if (label.indexOf("deposit") !== -1){
            if (!amounts.length) return;
            if (low.indexOf("paid") !== -1) doc.depositPaid = amounts[0];
            else if (low.indexOf("credit") !== -1) doc.depositCredited = amounts[0];
            else if (kind === "invoice") doc.depositCredited = amounts[0];
            else doc.depositPaid = amounts[0];
            return;
          }
          /* add-ons */
          for (i = 0; i < ADDONS.length; i++){
            a = ADDONS[i];
            var hit = false;
            for (var k = 0; k < a.keys.length; k++){ if (label.indexOf(a.keys[k]) !== -1){ hit = true; break; } }
            if (!hit) continue;
            var rec = doc.addons[a.key];
            if (amounts.length) rec.amount = amounts[0];
            if (/\bnot\b|n't|\bnone\b|not installed|not done|never/.test(low)) rec.done = false;
            else if (/installed|done|complete|completed|cleaned|fitted|yes/.test(low)) rec.done = true;
            if (rec.amount !== null) pushItem(doc, a.name, rec.amount, "addon:" + a.key, true);
            return;
          }
          /* labor */
          if (low.indexOf("labor") !== -1 || low.indexOf("labour") !== -1){
            var hr = line.match(/([\d]+(?:\.\d+)?)\s*(?:hrs?|hours?)\b/i);
            if (label.indexOf("rate") !== -1){
              if (amounts.length) doc.laborRate = amounts[0];
            } else if (label.indexOf("charge") !== -1 || label.indexOf("billed") !== -1){
              if (amounts.length) doc.laborCharge = amounts[amounts.length - 1];
              if (hr) doc.laborHours = parseFloat(hr[1]);
            } else if (label.indexOf("hour") !== -1){
              var hn = firstPlainNumber(line);
              if (hn !== null) doc.laborHours = hn;
              if (hr) doc.laborHours = parseFloat(hr[1]);
            } else {
              if (hr) doc.laborHours = parseFloat(hr[1]);
              var rm = line.match(/\$\s*([\d.]+)\s*(?:\/|per)\s*(?:hr|hour)/i);
              if (rm) doc.laborRate = parseFloat(rm[1]);
              var em = line.match(/=\s*\$\s*([\d,]+(?:\.\d{1,2})?)/);
              if (em) doc.laborCharge = parseFloat(em[1].replace(/,/g, ""));
              else if (amounts.length === 1 && doc.laborRate === null) doc.laborCharge = amounts[0];
            }
            if (doc.laborCharge !== null) pushItem(doc, "Labor", doc.laborCharge, "labor", true);
            return;
          }
          /* vent run */
          if (low.indexOf("vent") !== -1){
            var ftM = line.match(/([\d]+(?:\.\d+)?)\s*(?:ft\b|feet\b)/i);
            if (ftM) doc.ventFeet = parseFloat(ftM[1]);
            else if ((label.indexOf("feet") !== -1 || label.indexOf("run") !== -1) && amounts.length === 0){
              var vn = firstPlainNumber(line);
              if (vn !== null) doc.ventFeet = vn;
            }
            var vrM = line.match(/\$\s*([\d.]+)\s*(?:\/\s*ft|per\s*(?:ft|foot))/i);
            if (vrM) doc.ventRate = parseFloat(vrM[1]);
            if (label.indexOf("rate") !== -1 && amounts.length && doc.ventRate === null) doc.ventRate = amounts[0];
            var veM = line.match(/=\s*\$\s*([\d,]+(?:\.\d{1,2})?)/);
            if (veM) doc.ventCharge = parseFloat(veM[1].replace(/,/g, ""));
            else if (label.indexOf("charge") !== -1 && amounts.length) doc.ventCharge = amounts[amounts.length - 1];
            if (doc.ventCharge !== null) pushItem(doc, "Vent run", doc.ventCharge, "vent", true);
            return;
          }
          /* stories */
          if (label.indexOf("stories") !== -1 || label.indexOf("story") !== -1){
            if (amounts.length === 0){
              var sn = firstPlainNumber(line);
              if (sn !== null) doc.stories = sn;
            } else {
              if (label.indexOf("fee") === -1 && label.indexOf("charge") === -1){
                var sn2 = firstPlainNumber(line);
                if (sn2 !== null) doc.stories = sn2;
              }
              doc.storiesCharge = amounts[amounts.length - 1];
              pushItem(doc, "Stories", doc.storiesCharge, "stories", true);
            }
            return;
          }
          /* generic line */
          var rawLabel = (line.split(":")[0] || line).trim();
          if (amounts.length){
            pushItem(doc, rawLabel, amounts[amounts.length - 1], "gen:" + normLabel(rawLabel), false);
          } else if (/included|no charge/.test(low)){
            doc.included.push(normLabel(rawLabel));
          }
        });
        return doc;
      }

      /* ---------- cross-check engine ---------- */
      function audit(pText, wText, iText){
        var p = parseDoc(pText, "proposal");
        var w = parseDoc(wText, "work");
        var inv = parseDoc(iText, "invoice");
        var findings = [];
        var passes = [];
        function add(check, title, severity, delta, arithmetic){
          findings.push({ check: check, title: title, severity: severity, delta: round2(delta), arithmetic: arithmetic });
        }

        var docs = [
          { name: "Proposal", doc: p }, { name: "Work Record", doc: w }, { name: "Final Invoice", doc: inv }
        ];
        var presentNames = docs.filter(function(d){ return d.doc.present; }).map(function(d){ return d.name; });
        var missingNames = docs.filter(function(d){ return !d.doc.present; }).map(function(d){ return d.name; });

        if (presentNames.length < 2){
          return {
            verdict: "NOT ENOUGH TO COMPARE",
            note: "Only " + presentNames.length + " of the 3 documents pasted. Missing: " + missingNames.join(", ") + ". Paste at least two documents to cross-check.",
            overcharge: 0, findings: [], passes: [],
            compared: presentNames, missing: missingNames
          };
        }

        /* 1 · vent feet billed above cleaned */
        if (inv.present && w.present && inv.ventFeet !== null && w.ventFeet !== null){
          if (inv.ventFeet > w.ventFeet){
            var overFt = round2(inv.ventFeet - w.ventFeet);
            var rate = inv.ventRate || p.ventRate ||
              (inv.ventCharge !== null && inv.ventFeet ? round2(inv.ventCharge / inv.ventFeet) : null) ||
              (p.ventCharge !== null && p.ventFeet ? round2(p.ventCharge / p.ventFeet) : null);
            if (rate){
              var d1 = round2(overFt * rate);
              add("vent-feet", "Vent run billed above feet cleaned", "major", d1,
                num(inv.ventFeet) + " ft billed − " + num(w.ventFeet) + " ft cleaned = " + num(overFt) + " ft × " + money(rate) + "/ft = " + money(d1) + " billed for vent run that was never cleaned.");
            } else {
              add("vent-feet", "Vent run billed above feet cleaned", "major", 0,
                num(inv.ventFeet) + " ft billed − " + num(w.ventFeet) + " ft cleaned = " + num(overFt) + " ft over — no per-foot rate found in the pastes to price it, so it is flagged at $0.00.");
            }
          } else {
            passes.push("Vent feet: " + num(inv.ventFeet) + " ft billed ≤ " + num(w.ventFeet) + " ft cleaned.");
          }
        }

        /* 2 · stories billed above recorded */
        var billedStories = inv.stories !== null ? inv.stories : p.stories;
        if (w.present && w.stories !== null && billedStories !== null){
          if (billedStories > w.stories){
            var extraSt = billedStories - w.stories;
            var perStory = (inv.storiesCharge !== null && inv.stories) ? round2(inv.storiesCharge / inv.stories)
              : (p.storiesCharge !== null && p.stories) ? round2(p.storiesCharge / p.stories) : null;
            if (perStory){
              var d2 = round2(extraSt * perStory);
              add("stories", "Stories billed above stories recorded", "major", d2,
                num(billedStories) + " stories billed − " + num(w.stories) + " stories recorded = " + num(extraSt) + " × " + money(perStory) + " per story = " + money(d2) + ".");
            } else {
              add("stories", "Stories billed above stories recorded", "major", 0,
                num(billedStories) + " stories billed − " + num(w.stories) + " stories recorded = " + num(extraSt) + " extra — no per-story price found in the pastes to price it, so it is flagged at $0.00.");
            }
          } else {
            passes.push("Stories: " + num(billedStories) + " billed = " + num(w.stories) + " recorded.");
          }
        }

        /* 3 · add-ons billed but not recorded as done */
        if (inv.present && w.present){
          ADDONS.forEach(function(a){
            var billed = inv.addons[a.key].amount;
            if (billed === null || billed <= 0) return;
            if (w.addons[a.key].done === true){
              passes.push(a.name + ": billed " + money(billed) + " and recorded as done.");
              return;
            }
            var it = itemByKey(inv, "addon:" + a.key);
            if (it) it.counted = true;
            var explicit = w.addons[a.key].done === false;
            add("addon-not-done", a.name + " billed but not recorded as done", "critical", billed,
              a.name + " billed " + money(billed) + " on the invoice, but the work record " +
              (explicit ? "states it was NOT done" : "never records it as done") +
              " → the full " + money(billed) + " should not be owed.");
          });
        }

        /* 4 · labor charged above hours × rate */
        if (inv.present && w.present && inv.laborCharge !== null && w.laborHours !== null){
          var lrate = inv.laborRate || p.laborRate ||
            (p.laborCharge !== null && p.laborHours ? round2(p.laborCharge / p.laborHours) : null) ||
            (inv.laborHours ? round2(inv.laborCharge / inv.laborHours) : null);
          if (lrate){
            var expected = round2(w.laborHours * lrate);
            if (inv.laborCharge > expected + 0.004){
              var d4 = round2(inv.laborCharge - expected);
              add("labor", "Labor charged above recorded hours × rate", "major", d4,
                money(inv.laborCharge) + " billed − (" + num(w.laborHours) + " hrs × " + money(lrate) + " = " + money(expected) + ") = " + money(d4) + " of labor charged beyond the recorded time.");
            } else {
              passes.push("Labor: " + money(inv.laborCharge) + " billed ≤ " + num(w.laborHours) + " hrs × " + money(lrate) + " = " + money(expected) + ".");
            }
          }
        }

        /* 5 · deposit paid but not credited */
        if (p.present && inv.present && p.depositPaid !== null && p.depositPaid > 0){
          var credited = inv.depositCredited || 0;
          if (p.depositPaid > credited + 0.004){
            var d5 = round2(p.depositPaid - credited);
            add("deposit", "Deposit paid but not credited", credited === 0 ? "critical" : "major", d5,
              money(p.depositPaid) + " deposit paid − " + money(credited) + " credited on the invoice = " + money(d5) + " of your deposit never came back off the bill.");
          } else {
            passes.push("Deposit: " + money(p.depositPaid) + " paid and " + money(credited) + " credited.");
          }
        }

        /* 6 · duplicate fees */
        if (inv.present){
          var byKey = {};
          inv.items.forEach(function(it){
            if (it.key.indexOf("gen:") !== 0) return;
            (byKey[it.key] = byKey[it.key] || []).push(it);
          });
          Object.keys(byKey).forEach(function(k){
            var arr = byKey[k];
            if (arr.length > 1){
              var extra = 0;
              for (var i = 1; i < arr.length; i++){ extra += arr[i].amount; arr[i].counted = true; }
              add("duplicate", "Duplicate fee on the invoice: " + arr[0].label, "major", round2(extra),
                "\"" + arr[0].label + "\" appears " + arr.length + " times on the invoice (" +
                arr.map(function(x){ return money(x.amount); }).join(" + ") + ") → the extra " + money(round2(extra)) + " is the same fee charged twice.");
            }
          });
          if (p.present){
            inv.items.forEach(function(it){
              if (it.key.indexOf("gen:") !== 0 || it.counted) return;
              if (p.included.indexOf(normLabel(it.label)) !== -1){
                it.counted = true;
                add("duplicate", "Fee marked included on the proposal, then charged: " + it.label, "major", it.amount,
                  "\"" + it.label + "\" is marked included on the signed proposal, then charged " + money(it.amount) + " on the invoice → " + money(it.amount) + " charged for something already included.");
              }
            });
          }
        }

        /* 7 · invoice-only charges */
        if (p.present && inv.present){
          inv.items.forEach(function(it){
            if (it.counted) return;
            var explained = false;
            if (it.key === "vent") explained = (p.ventCharge !== null || p.ventFeet !== null);
            else if (it.key === "labor") explained = (p.laborCharge !== null || p.laborHours !== null);
            else if (it.key === "stories") explained = (p.storiesCharge !== null || p.stories !== null);
            else if (it.key.indexOf("addon:") === 0){
              var ak = it.key.slice(6);
              explained = !!(p.addons[ak] && p.addons[ak].amount !== null);
            } else {
              var nl = normLabel(it.label);
              explained = p.items.some(function(pi){ return normLabel(pi.label) === nl; });
            }
            if (!explained){
              it.counted = true;
              add("invoice-only", "Invoice-only charge: " + it.label, "major", it.amount,
                "\"" + it.label + "\" is billed " + money(it.amount) + " on the invoice but appears nowhere on the signed proposal → " + money(it.amount) + " was never agreed to.");
            }
          });
        }

        /* 8 · invoice total re-add */
        if (inv.present && inv.total !== null && inv.items.length){
          var sum = 0;
          inv.items.forEach(function(it){ sum += it.amount; });
          sum = round2(sum);
          var cred = inv.depositCredited || 0;
          var expectedTotal = round2(sum - cred);
          var diff = round2(inv.total - expectedTotal);
          if (Math.abs(diff) > 0.005){
            if (diff > 0){
              add("total-readd", "Invoice total does not re-add", "major", diff,
                "Line items re-add to " + money(sum) + " − deposit credited " + money(cred) + " = " + money(expectedTotal) + ", but the stated invoice total is " + money(inv.total) + " → " + money(diff) + " unexplained.");
            } else {
              add("total-readd", "Invoice total does not re-add", "minor", 0,
                "Line items re-add to " + money(sum) + " − deposit credited " + money(cred) + " = " + money(expectedTotal) + ", but the stated invoice total is " + money(inv.total) + " → the stated total is " + money(round2(-diff)) + " less than the paperwork supports. In your favor, but the invoice does not reconcile.");
            }
          } else {
            passes.push("Invoice total: line items re-add to " + money(sum) + " − deposit credited " + money(cred) + " = the stated " + money(inv.total) + ".");
          }
        }

        var overcharge = 0;
        findings.forEach(function(f){ overcharge += f.delta; });
        overcharge = round2(overcharge);

        var verdict, note = "";
        if (findings.length === 0){
          if (presentNames.length === 3){
            verdict = "SAFE TO PAY";
            note = "All three documents agree on every check that could run, and the deposit is credited.";
          } else {
            verdict = "PAY WITH FIXES";
            note = "The two pasted documents agree, but the " + missingNames.join(", ") + " was never pasted, so the check is incomplete — two documents cap at PAY WITH FIXES.";
          }
        } else if (findings.some(function(f){ return f.severity === "critical"; }) || overcharge >= 100){
          verdict = "DO NOT PAY YET";
          note = "Documented problems total " + money(overcharge) + ". Get the invoice corrected before paying.";
        } else {
          verdict = "PAY WITH FIXES";
          note = "Fixable discrepancies total " + money(overcharge) + ". Have the invoice corrected, then pay the corrected amount.";
        }
        if (presentNames.length === 2 && findings.length > 0){
          note += " (Only 2 of 3 documents pasted — missing: " + missingNames.join(", ") + ".)";
        }

        return {
          verdict: verdict, note: note, overcharge: overcharge,
          findings: findings, passes: passes,
          compared: presentNames, missing: missingNames
        };
      }

      /* ---------- examples (hand-checked) ---------- */
      var EX_BAD_P = [
        "Vent run feet: 25",
        "Vent rate: $6.00 per ft",
        "Vent charge: $150.00",
        "Stories: 2",
        "Bird guard: $45.00",
        "Labor hours: 2",
        "Labor rate: $85.00",
        "Labor charge: $170.00",
        "Deposit paid: $75.00",
        "Proposal total: $365.00"
      ].join("\n");
      var EX_BAD_W = [
        "Vent run feet cleaned: 20",
        "Stories: 2",
        "Bird guard: NOT installed",
        "Labor hours: 1.5"
      ].join("\n");
      var EX_BAD_I = [
        "Vent run feet: 25",
        "Vent charge: $150.00",
        "Bird guard: $45.00",
        "Labor hours: 3",
        "Labor charge: $255.00",
        "Lint alarm fee: $35.00",
        "Deposit credited: $0.00",
        "Invoice total: $485.00"
      ].join("\n");

      var EX_GOOD_P = EX_BAD_P;
      var EX_GOOD_W = [
        "Vent run feet cleaned: 25",
        "Stories: 2",
        "Bird guard: installed",
        "Labor hours: 2"
      ].join("\n");
      var EX_GOOD_I = [
        "Vent run feet: 25",
        "Vent charge: $150.00",
        "Bird guard: $45.00",
        "Labor hours: 2",
        "Labor charge: $170.00",
        "Deposit credited: $75.00",
        "Invoice total: $290.00"
      ].join("\n");
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-dryer-vent-cleaning-proposal-work-record-final-invoice-consistency-auditortm',
  name: 'J-Dawgs Dryer Vent Cleaning Proposal, Work Record & Final Invoice Consistency Auditor',
  description: 'Ours cross-checks a dryer vent cleaning proposal against its work record and the final invoice — with arithmetic shown across all pastes — into one pay verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
