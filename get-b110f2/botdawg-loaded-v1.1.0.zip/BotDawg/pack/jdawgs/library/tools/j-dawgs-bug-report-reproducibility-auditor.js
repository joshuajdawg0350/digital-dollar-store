'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Bug Report Reproducibility Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

  "use strict";

  var WEAK_EXAMPLE = [
    "Title: It broke",
    "",
    "The app is broken. It just doesn't work sometimes. Please fix it ASAP, it's really annoying."
  ].join("\n");

  var STRONG_EXAMPLE = [
    "Title: Export to CSV crashes with NullReferenceException when the report contains an empty Notes field",
    "",
    "Steps to reproduce:",
    "1. Open ReportBuilder in LedgerLite and create a report with one row where the Notes field is left empty.",
    "2. Click File > Export > Export to CSV.",
    "3. Choose a save location and click Save.",
    "4. Observe the crash dialog before the file is written.",
    "",
    "Expected behavior: The export completes and a CSV file is written, with an empty cell for the empty Notes field.",
    "",
    "Actual behavior: The application crashes immediately on clicking Save. No CSV file is created and all unsaved report edits are lost.",
    "",
    "Environment: LedgerLite 4.2.1 on Windows 11 (64-bit), Chrome 130.0 browser, .NET 8 runtime.",
    "",
    "Evidence: Error dialog text: \"NullReferenceException: Object reference not set to an instance of an object at LedgerLite.Export.CsvWriter.WriteRow()\". Full stack trace and a screenshot of the crash dialog are attached. Console log excerpt: \"[Export] Begin write row 1 -> Unhandled exception\".",
    "",
    "Frequency / scope: Happens every time, 5 out of 5 attempts. Affects all users who export a report containing at least one empty Notes field; exports with every Notes field filled in succeed.",
    "",
    "Regression: Yes. This export worked in LedgerLite 4.1.0 (last good version); it was first seen broken in 4.2.0 after the export rewrite."
  ].join("\n");

  var input = document.getElementById("input");
  var errBox = document.getElementById("err");
  var results = document.getElementById("results");
  var lastAudit = null;

  document.getElementById("worked-in").textContent = WEAK_EXAMPLE;

  function showErr(msg){
    errBox.textContent = msg;
    errBox.classList.add("show");
  }
  function hideErr(){ errBox.classList.remove("show"); errBox.textContent=""; }

  function sentences(text){
    return text.replace(/\s+/g," ").split(/(?<=[.!?])\s+/).map(function(s){return s.trim();}).filter(Boolean);
  }
  function firstMatch(re, text){
    var m = text.match(re);
    return m ? m[0] : null;
  }
  function findSentence(list, re){
    for (var i=0;i<list.length;i++){ if (re.test(list[i])) return list[i]; }
    return null;
  }

  var VAGUE_TITLE = /^(it broke|it's broken|it is broken|broken|it doesn't work|it does not work|not working|doesn't work|something is wrong|something wrong|bug|error|help|it fails|it failed|problem)$/i;

  function audit(text){
    var lines = text.split(/\n/);
    var nonEmpty = lines.map(function(l){return l.trim();}).filter(Boolean);
    var sents = sentences(text);
    var lower = text.toLowerCase();
    var sections = [];

    /* ---------- 1. Title / summary ---------- */
    var titleLine = null;
    for (var i=0;i<nonEmpty.length;i++){
      var tm = nonEmpty[i].match(/^(?:#{1,6}\s*)?(?:title|summary)\s*[:\-]\s*(.+)$/i);
      if (tm){ titleLine = tm[1].trim(); break; }
    }
    if (!titleLine && nonEmpty.length){
      var first = nonEmpty[0].replace(/^#{1,6}\s*/,"").trim();
      if (first.length <= 140 && !/^(steps|environment|expected|actual|evidence|frequency|regression)\b/i.test(first)) titleLine = first;
    }
    var titleSec;
    if (!titleLine){
      titleSec = {grade:"MISSING", note:"No title or opening summary line was found.", extract:null};
    } else {
      var words = titleLine.split(/\s+/).filter(Boolean);
      var stripped = titleLine.replace(/[.!]+$/,"").trim();
      if (words.length < 4 || VAGUE_TITLE.test(stripped)){
        titleSec = {grade:"WEAK", quote:titleLine, note:"The title names no feature, action, or specific symptom — a reproducer cannot tell what broke or where.", extract:titleLine};
      } else if (words.length < 6 && !/(crash|fail|error|wrong|missing|duplicate|blank|empty|slow|freeze|hang|incorrect|lost|leak)/i.test(titleLine)){
        titleSec = {grade:"WEAK", quote:titleLine, note:"The title is short and does not name an observable symptom (crash, wrong value, missing output, freeze…).", extract:titleLine};
      } else {
        titleSec = {grade:"PRESENT", note:"Title states a specific symptom: “"+titleLine+"”.", extract:titleLine};
      }
    }
    sections.push({key:"title", name:"1 · Title / summary of the symptom", sec:titleSec});

    /* ---------- 2. Steps to reproduce ---------- */
    var numbered = lines.filter(function(l){ return /^\s*(?:step\s*)?\d+[\.\)]\s+\S/.test(l); });
    var stepBlock = [];
    var inSteps = false;
    lines.forEach(function(l){
      if (/steps?\s*(to\s+reproduce)?\s*:/i.test(l)) { inSteps = true; return; }
      if (inSteps){
        if (/^(expected|actual|environment|evidence|frequency|regression)\b/i.test(l.trim())) { inSteps = false; return; }
        if (/^\s*(?:\d+[\.\)]|[-•*])\s+\S/.test(l)) stepBlock.push(l.trim());
      }
    });
    var stepLines = numbered.length >= stepBlock.length ? numbered.map(function(l){return l.trim();}) : stepBlock;
    var seqSent = findSentence(sents, /\bfirst\b[^.]*\bthen\b/i);
    var stepsSec;
    if (stepLines.length >= 2){
      stepsSec = {grade:"PRESENT", note:stepLines.length+" sequenced steps detected — a reproducer can follow them in order.", extract:stepLines.join("\n")};
    } else if (stepLines.length === 1){
      stepsSec = {grade:"WEAK", quote:stepLines[0], note:"Only one step is given; a reproduction almost always needs the full sequence that leads to the failure.", extract:stepLines[0]};
    } else if (seqSent){
      stepsSec = {grade:"PRESENT", note:"Sequenced actions detected in prose (“first … then …”). Numbering them would make them easier to follow, but the sequence is there.", extract:seqSent};
    } else {
      var vagueStep = findSentence(sents, /\b(when i|when you|i tried to|i was trying|do something|just use|using the app)\b/i);
      if (vagueStep){
        stepsSec = {grade:"WEAK", quote:vagueStep, note:"An action is hinted at, but there is no ordered sequence of steps that leads to the failure.", extract:null};
      } else {
        stepsSec = {grade:"MISSING", note:"No numbered steps, bullet sequence, or “first… then…” actions were found.", extract:null};
      }
    }
    sections.push({key:"steps", name:"2 · Steps to reproduce", sec:stepsSec});

    /* ---------- 3. Expected behavior ---------- */
    var expSent = findSentence(sents, /\b(expected|should have|should be|should\s+\w+|supposed to|ought to|meant to)\b/i);
    var expSec;
    if (!expSent){
      expSec = {grade:"MISSING", note:"What should have happened is never stated, so there is no target to reproduce against.", extract:null};
    } else {
      var after = expSent.replace(/^.*?expected( behavior)?\s*(is|:)?\s*/i,"");
      if (/^(work|work properly|be fine|not break|be ok|be okay|function|happen)\.?$/i.test(after.trim()) || (expSent.split(/\s+/).length <= 5 && /\b(work|fine|ok)\b/i.test(expSent))){
        expSec = {grade:"WEAK", quote:expSent, note:"Expected behavior is claimed but only in vague terms — state the concrete correct outcome.", extract:expSent};
      } else {
        expSec = {grade:"PRESENT", note:"Expected behavior is stated: “"+expSent+"”", extract:expSent};
      }
    }
    sections.push({key:"expected", name:"3 · Expected behavior", sec:expSec});

    /* ---------- 4. Actual behavior ---------- */
    var actSent = findSentence(sents, /\b(actual( behavior)?|instead|what happens|happens is|result is)\b/i);
    var crashSent = findSentence(sents, /\b(crash|crashes|crashed|freezes|froze|hangs|shows an error|error message|blank page|nothing happens|data is lost|are lost)\b/i);
    var actSec;
    if (actSent){
      actSec = {grade:"PRESENT", note:"Actual behavior is stated: “"+actSent+"”", extract:actSent};
    } else if (crashSent){
      actSec = {grade:"PRESENT", note:"The observable failure is described: “"+crashSent+"”", extract:crashSent};
    } else {
      var vagueAct = findSentence(sents, /\b(doesn't work|does not work|just doesn't|it broke|is broken|not working|won't work)\b/i);
      if (vagueAct){
        actSec = {grade:"WEAK", quote:vagueAct, note:"The failure is asserted but nothing observable is described — what appears on screen, what is lost, what error shows?", extract:null};
      } else {
        actSec = {grade:"MISSING", note:"What actually happens (the observable failure) is never described.", extract:null};
      }
    }
    sections.push({key:"actual", name:"4 · Actual behavior", sec:actSec});

    /* ---------- 5. Environment ---------- */
    var versionHit = firstMatch(/\b(?:version\s*)?v?\d+\.\d+(?:\.\d+)?\b/i, text);
    var osHit = firstMatch(/\b(Windows\s*\d*|macOS\s*[\d.]*|Mac OS|Linux|Ubuntu\s*[\d.]*|Debian|Fedora|iOS\s*\d*|Android\s*\d*)\b/i, text);
    var runtimeHit = firstMatch(/\b(Node\.?js\s*\d*|Python\s*\d[\d.]*|Java\s*\d+|\.NET\s*\d+|Chrome\s*\d+|Firefox\s*\d+|Safari\s*\d+|Edge\s*\d+|Ruby\s*\d[\d.]*|PHP\s*\d[\d.]*|PostgreSQL\s*\d*|MySQL\s*\d*)\b/i, text);
    var envLabel = findSentence(sents, /\benvironment\b/i) || findSentence(sents, /\bon (Windows|macOS|Linux|iOS|Android)\b/i);
    var envPoints = (versionHit?1:0)+(osHit?1:0)+(runtimeHit?1:0);
    var envParts = [];
    if (versionHit) envParts.push("version “"+versionHit.trim()+"”");
    if (osHit) envParts.push("OS “"+osHit.trim()+"”");
    if (runtimeHit) envParts.push("runtime / browser “"+runtimeHit.trim()+"”");
    var envSec;
    if (envPoints >= 2){
      envSec = {grade:"PRESENT", note:"Environment names "+envParts.join(", ")+".", extract:envLabel};
    } else if (envPoints === 1){
      envSec = {grade:"WEAK", quote:(versionHit||osHit||runtimeHit).trim(), note:"Only one environment detail was found ("+envParts[0]+"). Add the product + version and the OS / runtime so the setup can be matched.", extract:envLabel};
    } else {
      envSec = {grade:"MISSING", note:"No product version, operating system, or runtime / browser is named anywhere.", extract:null};
    }
    sections.push({key:"environment", name:"5 · Environment (product / version / OS / runtime)", sec:envSec});

    /* ---------- 6. Evidence ---------- */
    var hasStack = /(traceback|stack trace|at\s+[\w.$]+\s*\(|\.java:\d+|\.py",\s*line\s*\d+|line\s+\d+\s+in\s+\w+)/i.test(text);
    var errText = firstMatch(/"[^"]{12,}?(exception|error|failed|null|undefined)[^"]*"/i, text) ||
                  firstMatch(/\b\w*(Exception|Error)\b[:\s][^\n"]{4,}/, text) ||
                  firstMatch(/\b(error|exception)[:\s][^\n]{6,}/i, text);
    var hasShot = /\b(screenshot|screen shot|screen recording|video|attached|attachment|recording)\b/i.test(text);
    var hasLog = /\b(log excerpt|console log|log file|logs? show|log output)\b/i.test(text);
    var hasCode = /\b(HTTP\s*[45]\d\d|error code\s*\S+|0x[0-9a-fA-F]{4,}|exit code\s*\d+)\b/.test(text);
    var evLabel = findSentence(sents, /\b(evidence|screenshot|stack trace|error|log)\b/i);
    var evSec;
    if (hasStack || errText || hasCode || (hasShot && (hasLog || errText))){
      var bits = [];
      if (errText) bits.push("quoted error text");
      if (hasStack) bits.push("a stack trace");
      if (hasLog) bits.push("a log excerpt");
      if (hasShot) bits.push("an attachment / screenshot mention");
      if (hasCode) bits.push("an error / status code");
      evSec = {grade:"PRESENT", note:"Evidence found: "+bits.join(", ")+".", extract:evLabel};
    } else if (hasShot || hasLog){
      evSec = {grade:"PRESENT", note:"Evidence is referenced ("+(hasShot?"screenshot / attachment mentioned":"log mentioned")+").", extract:evLabel};
    } else {
      var vagueEv = findSentence(sents, /\b(there was an error|an error occurred|got an error|some error|error message appeared)\b/i);
      if (vagueEv){
        evSec = {grade:"WEAK", quote:vagueEv, note:"An error is mentioned but its exact text is never quoted — paste the message, log lines, or stack trace verbatim.", extract:null};
      } else {
        evSec = {grade:"MISSING", note:"No error text, log excerpt, stack trace, or screenshot is quoted or mentioned.", extract:null};
      }
    }
    sections.push({key:"evidence", name:"6 · Evidence (error text / log / stack trace / screenshot)", sec:evSec});

    /* ---------- 7. Frequency / scope ---------- */
    var freqSent = findSentence(sents, /\b(always|every time|each time|sometimes|often|rarely|intermittent\w*|once|twice|\d+\s*(out of|\/)\s*\d+|reproduc\w*\s+\d|frequency)\b/i);
    var scopeSent = findSentence(sents, /\b(all users|only .*users|affects|affected|scope|every user|some users|any user|all accounts|only when|whenever)\b/i);
    var freqSec;
    if (freqSent && (/\b(always|every time|each time|\d+\s*(out of|\/)\s*\d+)\b/i.test(freqSent) || scopeSent)){
      freqSec = {grade:"PRESENT", note:"Frequency / scope stated: “"+freqSent+"”"+(scopeSent && scopeSent!==freqSent ? " Scope: “"+scopeSent+"”" : ""), extract:freqSent};
    } else if (freqSent){
      freqSec = {grade:"WEAK", quote:freqSent.match(/\b(sometimes|often|rarely|intermittently|once in a while)\b/i) ? freqSent.match(/\b(sometimes|often|rarely|intermittently|once in a while)\b/i)[0] : freqSent, note:"A frequency word appears, but with no rate (e.g. 5 of 5 attempts) and no statement of who or what is affected.", extract:freqSent};
    } else if (scopeSent){
      freqSec = {grade:"WEAK", quote:scopeSent, note:"Scope is hinted at, but how often the failure occurs is never stated.", extract:scopeSent};
    } else {
      freqSec = {grade:"MISSING", note:"Neither how often it happens nor who / what is affected is stated.", extract:null};
    }
    sections.push({key:"frequency", name:"7 · Frequency / scope", sec:freqSec});

    /* ---------- 8. Regression note ---------- */
    var regClaim = findSentence(sents, /\b(regression|used to work|worked before|previously worked|worked fine (before|until)|broke after|broken since|since (the )?(update|upgrade|release|version)|stopped working after|last worked|worked in)\b/i);
    var regSec;
    if (!regClaim){
      regSec = {grade:"NA", note:"The draft never claims this used to work, so no regression note is required.", extract:null, applicable:false};
    } else {
      var lastGood = firstMatch(/\b(last good version|worked in|last worked)[^.,;\n]*/i, text) || firstMatch(/\bv\d+\.\d+(?:\.\d+)?\b/, regClaim);
      if (lastGood || /\b\d+\.\d+\b/.test(regClaim)){
        regSec = {grade:"PRESENT", note:"Regression is claimed and pinned down: “"+regClaim+"”", extract:regClaim, applicable:true};
      } else {
        regSec = {grade:"WEAK", quote:regClaim, note:"A regression is claimed, but no last good version, date, or update is named — say when it last worked.", extract:regClaim, applicable:true};
      }
    }
    sections.push({key:"regression", name:"8 · Regression note (only if a regression is claimed)", sec:regSec});

    /* ---------- Verdict ---------- */
    var core = sections.slice(0,7).map(function(s){return s.sec;});
    var missingCount = core.filter(function(s){return s.grade==="MISSING";}).length;
    var weakCount = core.filter(function(s){return s.grade==="WEAK";}).length;
    var stepsMissing = sections[1].sec.grade === "MISSING";
    var regBad = regSec.applicable && regSec.grade !== "PRESENT";
    var verdict, why;
    if (stepsMissing || missingCount >= 3){
      verdict = "NOT REPRODUCIBLE YET";
      why = "A reproducer cannot recreate this failure from the draft alone: " +
        (stepsMissing ? "there are no usable steps to reproduce" : "") +
        (stepsMissing && missingCount ? ", and " : "") +
        (missingCount ? missingCount+" of the seven core sections are missing entirely" : "") +
        ". Fill in the [MISSING: …] items in the skeleton below before filing.";
    } else if (missingCount === 0 && weakCount === 0 && !regBad){
      verdict = "READY TO FILE";
      why = "Every section a reproducer needs is present and specific" + (regSec.applicable ? ", including the regression note" : "") + ". The skeleton below is the same report, tidied into file-ready sections.";
    } else {
      verdict = "FILE WITH FIXES";
      var issues = [];
      core.forEach(function(s,idx){ if (s.grade!=="PRESENT") issues.push(sections[idx].name.split("·")[1].trim().toLowerCase()+" is "+s.grade.toLowerCase()); });
      if (regBad) issues.push("the regression note is "+regSec.grade.toLowerCase());
      why = "The core of the report is there, but fix these before filing: "+issues.join("; ")+". The skeleton below marks exactly what to add.";
    }

    /* ---------- Skeleton ---------- */
    function slot(secObj, missingMsg){
      return secObj.extract ? secObj.extract : "[MISSING: "+missingMsg+"]";
    }
    var skel = [];
    skel.push("Title: " + (titleSec.extract ? titleSec.extract : "[MISSING: a one-line summary naming the feature, the action, and the specific symptom]"));
    skel.push("");
    skel.push("Steps to reproduce:");
    skel.push(slot(stepsSec, "the exact ordered steps — starting point, each action in order, ending with the action that triggers the failure"));
    skel.push("");
    skel.push("Expected behavior:");
    skel.push(slot(expSec, "the concrete correct outcome that should have happened"));
    skel.push("");
    skel.push("Actual behavior:");
    skel.push(slot(actSec, "what observably happens instead — what appears on screen, what is lost or wrong"));
    skel.push("");
    skel.push("Environment:");
    skel.push(slot(envSec, "product name and version, operating system, and runtime / browser with versions"));
    skel.push("");
    skel.push("Evidence:");
    skel.push(slot(evSec, "the exact error message text, a log excerpt or stack trace, or a screenshot — quoted verbatim"));
    skel.push("");
    skel.push("Frequency / scope:");
    skel.push(slot(freqSec, "how often it happens (e.g. every time, 3 of 5 attempts) and who or what is affected"));
    skel.push("");
    skel.push("Regression:");
    if (!regSec.applicable){
      skel.push("No regression claimed in the original report.");
    } else {
      skel.push(slot(regSec, "the last version, date, or update in which this still worked"));
    }
    skel.push("");
    skel.push("---");
    skel.push("Original report (preserved verbatim):");
    skel.push(text);

    return { sections: sections, verdict: verdict, why: why, skeleton: skel.join("\n") };
  }

  function gradeClass(g){
    return g==="PRESENT" ? "present" : g==="WEAK" ? "weak" : g==="MISSING" ? "missing" : "na";
  }
  function gradeLabel(g){ return g==="NA" ? "NOT APPLICABLE" : g; }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "WEAK_EXAMPLE": (typeof WEAK_EXAMPLE !== 'undefined' ? WEAK_EXAMPLE : undefined), "STRONG_EXAMPLE": (typeof STRONG_EXAMPLE !== 'undefined' ? STRONG_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-bug-report-reproducibility-auditor',
  name: 'J-Dawgs Bug Report Reproducibility Auditor',
  description: 'Paste a draft bug report; get one verdict (READY TO FILE / FILE WITH FIXES / NOT REPRODUCIBLE YET), per-section grades, and a file-ready skeleton that keeps every fact and marks only genuinely missing pieces — never invents steps or versions.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "WEAK_EXAMPLE": __core["WEAK_EXAMPLE"], "STRONG_EXAMPLE": __core["STRONG_EXAMPLE"] }
};
