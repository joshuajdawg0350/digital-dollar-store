'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs MongoDB Connection String Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var RISKY = "mongodb://appuser:FakePass-Example7@db1.example.com:27017/shopdb?tls=false&retryWrites=false";
      var CLEAN = "mongodb+srv://db2.example.com/shopdb?tls=true&retryWrites=true&w=majority&journal=true";

      var KNOWN = {
        tls:1, ssl:1, authsource:1, authmechanism:1, authmechanismproperties:1,
        retrywrites:1, w:1, wtimeoutms:1, journal:1, j:1,
        replicaset:1, directconnection:1, loadbalanced:1,
        connecttimeoutms:1, sockettimeoutms:1, serverselectiontimeoutms:1,
        maxpoolsize:1, minpoolsize:1, maxidletimems:1, waitqueuetimeoutms:1,
        appname:1, readpreference:1, readpreferencetags:1, localthresholdms:1,
        heartbeatfrequencyms:1, compressors:1, zlibcompressionlevel:1,
        srvmaxhosts:1, srvservicename:1,
        tlsinsecure:1, tlsallowinvalidcertificates:1, tlsallowinvalidhostnames:1,
        tlscafile:1, tlscertificatekeyfile:1, tlscertificatekeyfilepassword:1,
        proxyhost:1, proxyport:1, proxyusername:1, proxypassword:1,
        uuidrepresentation:1, readconcernlevel:1, retryreads:1,
        maxstalenessseconds:1, servermonitoringmode:1, timeoutms:1
      };
      // Option values that are safe to echo in findings (never secrets).
      var ECHOABLE = { tls:1, ssl:1, retrywrites:1, w:1, journal:1, j:1, authsource:1, replicaset:1, readpreference:1, directconnection:1 };

      var input = document.getElementById("uri-input");
      var results = document.getElementById("results");
      var redactedWrap = document.getElementById("redacted-wrap");
      var redactedOut = document.getElementById("redacted-out");
      var reportWrap = document.getElementById("report-wrap");
      var reportOut = document.getElementById("report-out");

      function fail(pos, reason){ return { ok:false, position:pos, reason:reason }; }

      function isLocalHost(h){
        var x = h.toLowerCase();
        return x === "localhost" || x === "127.0.0.1" || x === "::1" || x.indexOf("127.") === 0 || x.slice(-10) === ".localhost";
      }

      function pctErrorPos(str, base){
        // returns absolute position of a bad % sequence in str, or -1
        for (var i=0;i<str.length;i++){
          if (str.charAt(i) === "%"){
            var hex = str.substr(i+1,2);
            if (!/^[0-9a-fA-F]{2}$/.test(hex)) return base + i;
            i += 2;
          }
        }
        return -1;
      }

      function parseUri(raw){
        var s = raw.replace(/^\s+|\s+$/g, "");
        if (!s) return fail(0, "the input is empty — paste a full connection string.");
        var i;
        for (i=0;i<s.length;i++){
          var c = s.charCodeAt(i);
          if (c <= 32){ return fail(i, "connection strings cannot contain spaces or control characters — percent-encode them (a space is %20)."); }
        }
        var scheme = null, schemeLen = 0;
        if (s.indexOf("mongodb+srv://") === 0){ scheme = "mongodb+srv"; schemeLen = 14; }
        else if (s.indexOf("mongodb://") === 0){ scheme = "mongodb"; schemeLen = 10; }
        else {
          return fail(0, "unrecognized scheme — a MongoDB connection string starts with mongodb:// or mongodb+srv://.");
        }
        var rest = s.slice(schemeLen);
        var authEnd = rest.length;
        for (i=0;i<rest.length;i++){
          if (rest.charAt(i) === "/" || rest.charAt(i) === "?"){ authEnd = i; break; }
        }
        var authority = rest.slice(0, authEnd);
        if (!authority) return fail(schemeLen, "no host found after the scheme.");

        var username = null, password = null, hasPasswordField = false;
        var hostsPart = authority, hostsBase = schemeLen;
        var atIdx = authority.lastIndexOf("@");
        if (atIdx >= 0){
          var userinfo = authority.slice(0, atIdx);
          hostsPart = authority.slice(atIdx + 1);
          hostsBase = schemeLen + atIdx + 1;
          if (!userinfo) return fail(schemeLen, "the user info before @ is empty.");
          var colon = userinfo.indexOf(":");
          var rawUser = colon >= 0 ? userinfo.slice(0, colon) : userinfo;
          var rawPass = colon >= 0 ? userinfo.slice(colon + 1) : null;
          if (!rawUser) return fail(schemeLen, "the username before : is empty.");
          var badPct = pctErrorPos(rawUser, schemeLen);
          if (badPct >= 0) return fail(badPct, "invalid percent-encoding in the username — a % must be followed by two hex digits.");
          if (rawPass !== null){
            badPct = pctErrorPos(rawPass, schemeLen + colon + 1);
            if (badPct >= 0) return fail(badPct, "invalid percent-encoding in the password — a % must be followed by two hex digits.");
          }
          try { username = decodeURIComponent(rawUser); } catch(e){ username = rawUser; }
          if (rawPass !== null){ hasPasswordField = true; password = rawPass; }
          if (!hostsPart) return fail(hostsBase, "no host found after @.");
        }

        // Hosts
        var hostTokens = hostsPart.split(",");
        var hosts = [], off = 0;
        for (i=0;i<hostTokens.length;i++){
          var tok = hostTokens[i], tokPos = hostsBase + off; off += tok.length + 1;
          if (!tok) return fail(tokPos, "empty entry in the host list (check for a doubled or trailing comma).");
          var host = tok, port = null, portPos = -1;
          if (tok.charAt(0) === "["){
            var close = tok.indexOf("]");
            if (close < 0) return fail(tokPos, "an IPv6 host in [ ] is missing its closing bracket.");
            host = tok.slice(1, close);
            var after = tok.slice(close + 1);
            if (after){
              if (after.charAt(0) !== ":") return fail(tokPos + close + 1, "unexpected characters after an IPv6 host — expected :port or the end of the host.");
              port = after.slice(1); portPos = tokPos + close + 2;
            }
          } else {
            var firstColon = tok.indexOf(":");
            if (firstColon >= 0){
              if (tok.indexOf(":", firstColon + 1) >= 0) return fail(tokPos + firstColon, "a host has more than one colon — IPv6 addresses must be wrapped in [ ].");
              host = tok.slice(0, firstColon);
              port = tok.slice(firstColon + 1); portPos = tokPos + firstColon + 1;
            }
          }
          if (!host) return fail(tokPos, "a host entry is empty.");
          if (port !== null){
            if (!/^[0-9]+$/.test(port)) return fail(portPos, "the port is not a number.");
            var pnum = parseInt(port, 10);
            if (pnum < 1 || pnum > 65535) return fail(portPos, "the port is outside the valid range 1–65535.");
          }
          hosts.push({ host: host, port: port, pos: tokPos, local: isLocalHost(host) });
        }
        if (scheme === "mongodb+srv"){
          if (hosts.length > 1) return fail(hosts[1].pos, "a mongodb+srv:// string names exactly one host — the SRV record supplies the rest.");
          if (hosts[0].port !== null) return fail(hosts[0].pos, "a mongodb+srv:// string must not carry a port — the SRV record supplies it.");
        }

        // Path / database
        var tail = rest.slice(authEnd);
        var database = null, queryStr = null, queryBase = -1;
        if (tail.charAt(0) === "/"){
          var q = tail.indexOf("?");
          var dbPart = q >= 0 ? tail.slice(1, q) : tail.slice(1);
          database = dbPart ? dbPart : null;
          if (q >= 0){ queryStr = tail.slice(q + 1); queryBase = schemeLen + authEnd + q + 1; }
        } else if (tail.charAt(0) === "?"){
          queryStr = tail.slice(1); queryBase = schemeLen + authEnd + 1;
        }

        // Options
        var options = [], optMap = {};
        if (queryStr){
          var pairs = queryStr.split("&"), poff = 0;
          for (i=0;i<pairs.length;i++){
            var pair = pairs[i], pPos = queryBase + poff; poff += pair.length + 1;
            if (!pair) return fail(pPos, "empty entry in the option list (check for a doubled or trailing &).");
            var eq = pair.indexOf("=");
            if (eq < 0) return fail(pPos, "an option in the query string has no =value — every option must be written name=value.");
            var key = pair.slice(0, eq), val = pair.slice(eq + 1);
            if (!key) return fail(pPos, "an option has an empty name.");
            var opt = { key: key, lower: key.toLowerCase(), value: val, pos: pPos };
            options.push(opt);
            optMap[opt.lower] = opt; // last one wins, like the drivers
          }
        }

        return {
          ok: true, scheme: scheme, schemeLen: schemeLen, hosts: hosts,
          username: username, password: password, hasPasswordField: hasPasswordField,
          database: database, options: options, optMap: optMap,
          atIdx: atIdx, userinfoColon: (atIdx >= 0 ? userinfoColonOf(authority) : -1),
          trimmed: s
        };
      }
      function userinfoColonOf(authority){
        var at = authority.lastIndexOf("@");
        var ui = authority.slice(0, at);
        return ui.indexOf(":");
      }

      function redact(p){
        if (!p.ok || !p.hasPasswordField || !p.password) return p.trimmed;
        var start = p.schemeLen + p.userinfoColon + 1;
        var end = p.schemeLen + p.atIdx;
        return p.trimmed.slice(0, start) + "***" + p.trimmed.slice(end);
      }

      function optVal(p, name){
        var o = p.optMap[name];
        return o ? o.value : null;
      }
      function boolOpt(p, name){
        var v = optVal(p, name);
        if (v === null) return null;
        var x = v.toLowerCase();
        if (x === "true") return true;
        if (x === "false") return false;
        return null; // non-boolean value; treated as set-but-unreadable
      }

      function audit(raw){
        var p = parseUri(raw);
        if (!p.ok){
          return { parseError: p, verdict: "COULD NOT PARSE", vclass: "parse", findings: [
            { sev: "parse", label: "COULD NOT PARSE",
              text: "Position " + p.position + ": " + p.reason + " Fix the string and audit again — nothing else in it was graded, because a malformed string cannot be trusted to mean what it appears to say." }
          ], parsed: null, redacted: null };
        }

        var findings = [];
        function add(sev, label, text){ findings.push({ sev: sev, label: label, text: text }); }

        var allLocal = p.hosts.every(function(h){ return h.local; });
        var anyLocal = p.hosts.some(function(h){ return h.local; });
        var hasCreds = p.username !== null;
        var hasPassword = p.hasPasswordField && p.password && p.password.length > 0;

        // --- Credentials ---
        if (hasPassword){
          add("exposed", "EXPOSED",
            "A username (\"" + p.username + "\") and a password are embedded directly in this string. The password is masked here and everywhere in this tool's output — it is never printed. Treat the real password as compromised anywhere this string has been pasted, logged, screenshotted, or committed.");
          add("exposed", "SHARING RISK",
            "Credentials-in-URI risk: a connection string carrying a password gets copied into tickets, chats, shell history, config files, and error logs, and every copy is a working key. Move the password into a secret store or environment variable and hand out only the redacted version below.");
        } else if (hasCreds && p.hasPasswordField){
          add("fix", "FIX",
            "A username (\"" + p.username + "\") is embedded with an empty password field. Remove the dangling \":@\" or supply credentials through your secret store instead — an empty password in a URI invites misconfiguration.");
          add("info", "INFO",
            "Credentials-in-URI note: even a username alone travels with every copy of the string. Usernames are not secrets, but keeping identity out of shared strings reduces what a leaked copy reveals.");
        } else if (hasCreds){
          add("info", "INFO",
            "A username (\"" + p.username + "\") is embedded with no password. A username alone is not a secret, so this does not block sharing — but anyone holding the string still learns a valid login name.");
        } else {
          add("ok", "OK",
            "No embedded credentials: the string carries no username or password, so a copy of it does not hand anyone a working login. Credentials must be supplied separately (secret store, environment, or driver prompt) — the safer arrangement.");
        }

        // --- TLS posture ---
        var tlsB = boolOpt(p, "tls"), sslB = boolOpt(p, "ssl");
        var tlsSet = optVal(p, "tls") !== null || optVal(p, "ssl") !== null;
        var tlsOff = tlsB === false || sslB === false;
        var tlsOn = tlsB === true || sslB === true;
        if (tlsB !== null && sslB !== null && tlsB !== sslB){
          add("fix", "FIX", "tls and ssl disagree (one is true, the other false). They are aliases for the same switch — set only one of them so the string says one thing.");
        }
        if (tlsSet && tlsB === null && sslB === null && !tlsOff && !tlsOn){
          add("fix", "FIX", "A tls/ssl option is present but its value is not true or false, so this audit cannot confirm the TLS posture. Set tls=true explicitly.");
        }
        if (tlsOff){
          if (allLocal){
            add("info", "LOCALHOST EXCEPTION",
              "tls/ssl is explicitly false, but every host in this string is local (localhost / 127.x / ::1), so traffic never leaves this machine and the TLS-off blocker does not apply. The moment any host becomes a remote machine, this same setting becomes a blocker.");
          } else {
            add("blocker", "BLOCKER",
              "tls/ssl is explicitly FALSE and at least one host is not local, so credentials and data would cross the network unencrypted. Set tls=true before this string is used anywhere off this machine." + (p.scheme === "mongodb+srv" ? " It also contradicts mongodb+srv://, which expects TLS — most drivers reject or override it." : ""));
          }
        } else if (tlsOn){
          add("ok", "OK", "TLS is explicitly on (tls/ssl=true)" + (p.scheme === "mongodb+srv" ? ", matching the mongodb+srv:// expectation." : "."));
        } else {
          if (p.scheme === "mongodb+srv"){
            add("ok", "OK", "No tls option is set, and mongodb+srv:// turns TLS on by default, so the connection is encrypted unless something overrides it.");
          } else if (allLocal){
            add("info", "LOCALHOST EXCEPTION",
              "TLS is not mentioned, and every host is local (localhost / 127.x / ::1): plaintext stays on this machine, which is the normal local-development posture. Add tls=true before pointing this string at any remote host.");
          } else {
            add("fix", "FIX",
              "TLS is not enabled: plain mongodb:// leaves TLS off unless tls=true is set, and at least one host is not local — credentials and data would cross the network unencrypted. Add tls=true (or switch to mongodb+srv://, which enables it by default).");
          }
        }
        if (anyLocal && !allLocal){
          add("info", "INFO", "This string mixes local and non-local hosts. The localhost exception covers only the local entries — the non-local hosts are graded on the full network rules above.");
        }

        // --- authSource ---
        if (hasCreds){
          var asrc = optVal(p, "authsource");
          if (asrc === null){
            add("info", "INFO",
              "Missing authSource: with credentials present and no authSource option, drivers authenticate against the database in the path" + (p.database ? " (\"" + p.database + "\")" : "") + ", or \"admin\" when the path names none. If the user was created in a different database (commonly admin), logins will fail — set authSource explicitly to remove the guesswork.");
          } else {
            add("ok", "OK", "authSource is set (\"" + asrc + "\"), so the authentication database is unambiguous.");
          }
        }

        // --- Write posture (INFO) ---
        var rw = optVal(p, "retrywrites");
        add("info", "INFO", "retryWrites posture: " + (rw === null
          ? "not set — drivers default to true for replica sets and Atlas-style deployments, so retryable writes are retried once automatically."
          : "explicitly " + rw + (rw.toLowerCase() === "false" ? " — retryable writes will NOT be retried automatically; a transient network error can surface as a failed write your application must handle." : ".")));
        var w = optVal(p, "w");
        if (w !== null && w === "0"){
          add("fix", "FIX", "w=0 means unacknowledged writes: the driver does not wait for the server to confirm, so a write can be lost silently. Use w=1 or w=majority unless you have deliberately accepted that loss.");
        } else {
          add("info", "INFO", "w (write concern) posture: " + (w === null
            ? "not set — the driver/cluster default applies (typically acknowledgment by the primary, or majority on managed clusters)."
            : "explicitly " + w + "."));
        }
        var j = optVal(p, "journal"); if (j === null) j = optVal(p, "j");
        add("info", "INFO", "journal posture: " + (j === null
          ? "not set — journaling follows the w setting and server defaults; writes are not specifically required to hit the journal before acknowledgment."
          : "explicitly " + j + (j.toLowerCase() === "true" ? " — writes must be journaled before acknowledgment, the more durable choice." : ".")));

        // --- SRV / host notes ---
        add("info", "INFO", "Parsed as: scheme " + p.scheme + "://, host" + (p.hosts.length > 1 ? "s " : " ") +
          p.hosts.map(function(h){ return h.host + (h.port ? ":" + h.port : "") + (h.local ? " (local)" : ""); }).join(", ") +
          (p.database ? ", database \"" + p.database + "\"" : ", no database in the path") + ".");

        // --- Unknown options ---
        var unknown = [];
        var seenUnknown = {};
        p.options.forEach(function(o){ if (!KNOWN[o.lower] && !seenUnknown[o.lower]){ seenUnknown[o.lower] = 1; unknown.push(o.key); } });
        unknown.forEach(function(name){
          add("na", "NOT AUDITED", "Option \"" + name + "\" is outside this auditor's rule set, so it was NOT AUDITED — its value is not shown and its effect on safety was not judged. Check it against the MongoDB connection-string documentation yourself.");
        });

        // --- Verdict ---
        var verdict, vclass;
        if (hasPassword){ verdict = "DO NOT SHARE — CREDENTIALS EXPOSED"; vclass = "exposed"; }
        else if (findings.some(function(f){ return f.sev === "blocker" || f.sev === "fix"; })){ verdict = "USE WITH FIXES"; vclass = "fixes"; }
        else { verdict = "SAFE TO USE & SHARE"; vclass = "safe"; }

        return { verdict: verdict, vclass: vclass, findings: findings, parsed: p, redacted: redact(p) };
      }

      function esc(t){
        return t.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
      }

      function buildReport(r){
        var lines = [];
        lines.push("J-Dawgs MongoDB Connection String Safety Auditor — Report");
        lines.push("Parsed as text only, in the browser. Nothing was uploaded, saved, or connected to.");
        lines.push("");
        lines.push("VERDICT: " + r.verdict);
        lines.push("");
        if (r.parsed){
          var p = r.parsed;
          lines.push("Scheme: " + p.scheme + "://");
          lines.push("Hosts: " + p.hosts.map(function(h){ return h.host + (h.port ? ":" + h.port : "") + (h.local ? " (local)" : ""); }).join(", "));
          lines.push("Database: " + (p.database ? p.database : "(none in path)"));
          if (p.username !== null){
            lines.push("Credentials: username \"" + p.username + "\" embedded; password " + (p.hasPasswordField && p.password ? "present — MASKED, never printed in this report" : (p.hasPasswordField ? "field present but empty" : "not present")) + ".");
          } else {
            lines.push("Credentials: none embedded.");
          }
          lines.push("");
        }
        lines.push("FINDINGS:");
        r.findings.forEach(function(f){ lines.push("- [" + f.label + "] " + f.text); });
        lines.push("");
        if (r.redacted){
          lines.push("SHARE-SAFE REDACTED STRING (password replaced with ***):");
          lines.push(r.redacted);
        } else {
          lines.push("SHARE-SAFE REDACTED STRING: unavailable — the string could not be parsed.");
        }
        return lines.join("\n");
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-mongodb-connection-string-safety-auditor',
  name: 'J-Dawgs MongoDB Connection String Safety Auditor',
  description: 'Compass and URI parsers parse and connect; ours grades a pasted connection string\'s credential and TLS posture offline — password always masked — into one use/share verdict plus a share-safe redacted string, without connecting.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
