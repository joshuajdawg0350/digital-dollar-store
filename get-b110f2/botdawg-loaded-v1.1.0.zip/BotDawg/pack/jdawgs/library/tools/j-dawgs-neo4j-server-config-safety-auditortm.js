'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Neo4j Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------------- Worked examples ---------------- */

      var EXAMPLE_RISKY = [
        "# Risky example — this config loads fine and is wide open.",
        "# Every problem below is found by the audit at its line.",
        "dbms.security.auth_enabled=false",
        "server.default_listen_address=0.0.0.0",
        "server.http.enabled=true",
        "server.bolt.tls_level=DISABLED",
        "dbms.security.procedures.unrestricted=apoc.*",
        "dbms.security.allow_csv_import_from_file_urls=true",
        "dbms.security.initial_password=Planted-Passw0rd-7734",
        "server.memory.heap.initial_size=512m",
        "server.memory.heap.max_size=1g"
      ].join("\n");

      var EXAMPLE_HARDENED = [
        "# Hardened example — private bind, auth on, TLS on, scoped procedures.",
        "dbms.security.auth_enabled=true",
        "server.default_listen_address=127.0.0.1",
        "server.http.enabled=false",
        "server.https.enabled=true",
        "server.bolt.tls_level=REQUIRED",
        "dbms.security.procedures.unrestricted=dbms.schema.*",
        "dbms.security.procedures.allowlist=dbms.schema.*",
        "dbms.security.allow_csv_import_from_file_urls=false",
        "auth_minimum_password_length=12",
        "server.memory.heap.initial_size=2g",
        "server.memory.heap.max_size=2g",
        "server.memory.pagecache.size=1g"
      ].join("\n");

      /* ---------------- Helpers ---------------- */

      var SECRET_RE = /password|secret|token/i;
      /* A key that merely sets a password *policy* (e.g. minimum_password_length)
         holds a number, not a credential — it is graded on its value, not masked. */
      function isSecretKey(key) { return SECRET_RE.test(key) && key.indexOf("length") === -1; }

      function trim(s) { return String(s).replace(/^\s+|\s+$/g, ""); }
      function lower(s) { return String(s).toLowerCase(); }
      function parseBool(v) {
        var t = lower(trim(v));
        if (t === "true") return true;
        if (t === "false") return false;
        return null;
      }
      function fmtBytes(n) {
        return String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
      }
      function humanBytes(n) {
        var units = ["bytes", "KiB", "MiB", "GiB", "TiB"];
        var v = n, i = 0;
        while (v >= 1024 && i < units.length - 1) { v = v / 1024; i++; }
        if (i === 0) return fmtBytes(n) + " bytes";
        var r = Math.round(v * 100) / 100;
        return fmtBytes(n) + " bytes (" + r + " " + units[i] + ")";
      }
      /* Neo4j sizes: plain number = bytes; suffixes k/m/g/t are powers of 1024. */
      function parseSize(raw) {
        var m = /^(\d+(?:\.\d+)?)\s*([kmgt]i?b?|b)?$/i.exec(trim(raw));
        if (!m) return null;
        var mult = 1;
        var suf = lower(m[2] || "");
        if (suf.charAt(0) === "k") mult = 1024;
        else if (suf.charAt(0) === "m") mult = 1024 * 1024;
        else if (suf.charAt(0) === "g") mult = 1024 * 1024 * 1024;
        else if (suf.charAt(0) === "t") mult = 1024 * 1024 * 1024 * 1024;
        return Math.round(parseFloat(m[1]) * mult);
      }
      function isLoopbackHost(host) {
        var h = lower(trim(host)).replace(/^\[|\]$/g, "");
        return h === "127.0.0.1" || h === "localhost" || h === "::1" || h === "";
      }
      function isPrivateHost(host) {
        var h = lower(trim(host)).replace(/^\[|\]$/g, "");
        if (isLoopbackHost(h)) return true;
        if (/^10\.\d+\.\d+\.\d+$/.test(h)) return true;
        if (/^192\.168\.\d+\.\d+$/.test(h)) return true;
        var m172 = /^172\.(\d+)\.\d+\.\d+$/.exec(h);
        if (m172 && +m172[1] >= 16 && +m172[1] <= 31) return true;
        if (/\.local$/.test(h) || /\.internal$/.test(h) || /\.lan$/.test(h)) return true;
        return false;
      }
      function hostOfAddress(addr) {
        var a = trim(addr);
        var idx = a.lastIndexOf(":");
        if (idx > 0 && /^\d+$/.test(a.slice(idx + 1))) return a.slice(0, idx);
        return a;
      }

      /* ---------------- Parser ---------------- */

      function parseConfig(text) {
        var lines = String(text).split(/\r?\n/);
        var entries = {};        /* key -> {value, line, occurrences:[{value,line}]} */
        var order = [];
        var notParsed = [];      /* {line, text} */
        var duplicates = [];     /* {key, lines:[..]} */
        for (var i = 0; i < lines.length; i++) {
          var lineNo = i + 1;
          var raw = lines[i];
          var t = trim(raw);
          if (t === "") continue;
          if (t.charAt(0) === "#") continue;
          var eq = t.indexOf("=");
          if (eq <= 0) { notParsed.push({ line: lineNo, text: t }); continue; }
          var key = trim(t.slice(0, eq));
          var value = trim(t.slice(eq + 1));
          if (key === "" || /\s/.test(key)) { notParsed.push({ line: lineNo, text: t }); continue; }
          if (!entries[key]) { entries[key] = { value: value, line: lineNo, occurrences: [] }; order.push(key); }
          entries[key].occurrences.push({ value: value, line: lineNo });
          entries[key].value = value;
          entries[key].line = lineNo;
        }
        Object.keys(entries).forEach(function (k) {
          if (entries[k].occurrences.length > 1) {
            duplicates.push({ key: k, lines: entries[k].occurrences.map(function (o) { return o.line; }) });
          }
        });
        return { entries: entries, order: order, notParsed: notParsed, duplicates: duplicates };
      }

      /* ---------------- Graded-key registry ---------------- */

      var FIXED_GRADED = {
        "dbms.security.auth_enabled": true,
        "server.default_listen_address": true,
        "server.bolt.enabled": true,
        "server.bolt.listen_address": true,
        "server.bolt.advertised_address": true,
        "server.bolt.tls_level": true,
        "server.http.enabled": true,
        "server.http.listen_address": true,
        "server.http.advertised_address": true,
        "server.https.enabled": true,
        "server.https.listen_address": true,
        "server.https.advertised_address": true,
        "dbms.security.procedures.unrestricted": true,
        "dbms.security.procedures.allowlist": true,
        "dbms.security.allow_csv_import_from_file_urls": true,
        "server.allow_csv_import_from_file_urls": true,
        "server.memory.heap.initial_size": true,
        "server.memory.heap.max_size": true,
        "server.memory.pagecache.size": true
      };
      function isGraded(key) {
        if (FIXED_GRADED[key]) return true;
        if (isSecretKey(key)) return true;
        if (key.indexOf("http_access_control") !== -1) return true;
        if (key.indexOf("minimum_password_length") !== -1) return true;
        return false;
      }

      /* Curated absent-key notes: [key, default note] */
      var NOT_SET_NOTES = [
        ["dbms.security.auth_enabled", "Neo4j's default is authentication enabled. The audit above relies on that default; setting it explicitly true removes the doubt."],
        ["server.default_listen_address", "Neo4j 5 defaults to localhost only. Neo4j 3.x bound all interfaces by default, so set this explicitly rather than trusting any default."],
        ["server.bolt.tls_level", "Neo4j's default is DISABLED — Bolt traffic is not encrypted unless this is set."],
        ["server.https.enabled", "Neo4j's default is disabled — no HTTPS connector until this is set true."],
        ["dbms.security.procedures.unrestricted", "Neo4j's default leaves no procedures unrestricted."],
        ["dbms.security.procedures.allowlist", "Neo4j's default has no procedure allowlist."],
        ["dbms.security.allow_csv_import_from_file_urls / server.allow_csv_import_from_file_urls", "Neither spelling is set. Neo4j's shipped default has allowed LOAD CSV from file URLs in many versions — set it false explicitly if file-URL import is not needed."]
      ];

      /* ---------------- Audit ---------------- */

      function audit(text) {
        var parsed = parseConfig(text);
        var E = parsed.entries;
        var findings = [];
        function add(sev, key, lines, title, detail, fix) {
          findings.push({ severity: sev, key: key, lines: lines, title: title, detail: detail, fix: fix });
        }
        function get(key) { return E[key] || null; }

        /* --- Secrets first: presence noted, value never copied anywhere --- */
        parsed.order.forEach(function (key) {
          if (isSecretKey(key)) {
            add("WARNING", key, [E[key].line],
              "Secret value sits in the config file",
              "This key's name marks it as a secret (it contains “password”, “secret”, or “token”). It is reported by key name and line only — its value is never shown in these findings, the reports, or any drift output.",
              "Move the value out of neo4j.conf into a secrets manager or your deployment's secret injection, and rotate it — it has been sitting in a plain-text file.");
          }
        });

        /* --- Authentication --- */
        var authEntry = get("dbms.security.auth_enabled");
        var authDisabled = false, authKnown = false;
        if (!authEntry) {
          add("INFO", "dbms.security.auth_enabled", [],
            "Authentication setting not set in file",
            "dbms.security.auth_enabled is NOT SET IN FILE. Neo4j's default is authentication enabled, so sign-in is still required unless something outside this file turns it off. This note is informational — it is not a failure.",
            "Set dbms.security.auth_enabled=true explicitly so the posture does not depend on a default.");
        } else {
          var ab = parseBool(authEntry.value);
          if (ab === false) {
            authDisabled = true; authKnown = true;
            add("BLOCKER", "dbms.security.auth_enabled", [authEntry.line],
              "Authentication is disabled",
              "dbms.security.auth_enabled=false turns off Neo4j's sign-in entirely. Anyone who can reach a connector can read and write the graph with no credentials at all.",
              "Set dbms.security.auth_enabled=true and restart Neo4j. Then set the initial admin password with neo4j-admin before first use.");
          } else if (ab === true) {
            authKnown = true;
          } else {
            add("WARNING", "dbms.security.auth_enabled", [authEntry.line],
              "Authentication value not recognized",
              "The value on this line is neither true nor false, so this tool cannot confirm the authentication posture from the file.",
              "Set dbms.security.auth_enabled=true (or false only for a throwaway local experiment that never leaves the machine).");
          }
        }

        /* --- Listen / exposure --- */
        var listenEntry = get("server.default_listen_address");
        var defaultExternal = false, listenSet = false;
        if (listenEntry) {
          listenSet = true;
          defaultExternal = !isLoopbackHost(listenEntry.value);
        }
        function connectorExternal(listenKey) {
          var le = get(listenKey);
          if (le) return !isLoopbackHost(hostOfAddress(le.value));
          return defaultExternal;
        }
        var httpEntry = get("server.http.enabled");
        var httpEnabled = httpEntry ? parseBool(httpEntry.value) : null; /* null = not set; Neo4j default is enabled */
        var httpOn = httpEnabled === true || (httpEntry === null);
        var httpsEntry = get("server.https.enabled");
        var httpsOn = httpsEntry ? parseBool(httpsEntry.value) === true : false;
        var httpExternal = connectorExternal("server.http.listen_address");
        var boltExternal = connectorExternal("server.bolt.listen_address");

        if (listenEntry && defaultExternal) {
          var pairings = [];
          if (authDisabled) pairings.push("authentication is disabled (line " + authEntry.line + ")");
          if (httpOn) pairings.push("plain HTTP is served (line " + (httpEntry ? httpEntry.line : "not set — Neo4j's default serves plain HTTP") + ")");
          if (pairings.length) {
            add("BLOCKER", "server.default_listen_address", [listenEntry.line],
              "All-interface bind paired with an open door",
              "server.default_listen_address=" + listenEntry.value + " binds every connector to all network interfaces, and it is paired with: " + pairings.join("; ") + ". That pairing is the exposure: the server is reachable from the network with a weakened or missing gate in front of it.",
              "Bind to 127.0.0.1 (or a private interface) unless remote access is truly required; if it is required, put TLS and authentication in front first, then bind.");
          } else {
            add("WARNING", "server.default_listen_address", [listenEntry.line],
              "Connectors bound to all interfaces",
              "server.default_listen_address=" + listenEntry.value + " makes Bolt, HTTP, and HTTPS reachable on every network interface. Authentication is on and plain HTTP is off, so this is exposure to manage, not an open door.",
              "Confirm every attached network is trusted. Prefer 127.0.0.1 plus a reverse proxy or SSH tunnel for remote access.");
          }
        }
        if (!listenEntry) {
          add("INFO", "server.default_listen_address", [],
            "Listen address not set in file",
            "server.default_listen_address is NOT SET IN FILE. Neo4j 5's default binds connectors to localhost only; Neo4j 3.x defaulted to all interfaces. Which default you get depends on the version on the host.",
            "Set server.default_listen_address explicitly — 127.0.0.1 for local-only, or a specific private address when remote access is intended.");
        }

        /* --- HTTP / HTTPS --- */
        if (httpEntry && httpEnabled === true) {
          if (httpExternal) {
            add("BLOCKER", "server.http.enabled", [httpEntry.line],
              "Plain HTTP served on an external bind",
              "server.http.enabled=true serves the browser and REST traffic unencrypted, and the HTTP connector is bound beyond this machine. Credentials and graph data cross the network in the clear, paired with the external bind on line " + (listenEntry ? listenEntry.line : "—") + ".",
              "Set server.http.enabled=false and serve server.https.enabled=true with a certificate, or bind HTTP to 127.0.0.1 only.");
          } else if (!httpsOn) {
            add("WARNING", "server.http.enabled", [httpEntry.line],
              "Plain HTTP enabled with no HTTPS",
              "server.http.enabled=true and HTTPS is not enabled in this file, so the web interface and REST API are served without encryption. On a loopback-only bind the exposure is this machine; the habit is still worth fixing before the bind ever widens.",
              "Enable server.https.enabled=true with a certificate and set server.http.enabled=false, or keep HTTP loopback-only and reach it through a tunnel.");
          } else {
            add("INFO", "server.http.enabled", [httpEntry.line],
              "Plain HTTP still on alongside HTTPS",
              "HTTPS is enabled, but plain HTTP is also served. Anything sent to the HTTP port is unencrypted.",
              "Set server.http.enabled=false once clients are on HTTPS, or redirect HTTP to HTTPS at a proxy.");
          }
        } else if (!httpEntry && defaultExternal) {
          add("BLOCKER", "server.http.enabled", [listenEntry.line],
            "Plain HTTP on by default, on an external bind",
            "server.http.enabled is NOT SET IN FILE, and Neo4j's default serves plain HTTP. Paired with the all-interface bind on line " + listenEntry.line + ", unencrypted HTTP is reachable from the network by default.",
            "Set server.http.enabled=false explicitly and serve HTTPS, or narrow server.default_listen_address to 127.0.0.1.");
        }
        if (httpEntry && httpEnabled === null) {
          add("WARNING", "server.http.enabled", [httpEntry.line],
            "HTTP enabled value not recognized",
            "The value on this line is neither true nor false, so the HTTP connector's state cannot be confirmed from the file.",
            "Set server.http.enabled to an explicit true or false — false is the safe default posture.");
        }

        /* --- Bolt TLS --- */
        var boltTls = get("server.bolt.tls_level");
        if (boltTls) {
          var tlsVal = trim(boltTls.value).toUpperCase();
          if (tlsVal === "DISABLED") {
            if (boltExternal) {
              add("BLOCKER", "server.bolt.tls_level", [boltTls.line],
                "Bolt encryption disabled on an external bind",
                "server.bolt.tls_level=DISABLED sends Bolt traffic — including credentials at sign-in — unencrypted, and the Bolt connector is bound beyond this machine. Anyone on the path can read the session.",
                "Set server.bolt.tls_level=REQUIRED with a certificate for the Bolt connector, or bind Bolt to 127.0.0.1 only.");
            } else {
              add("WARNING", "server.bolt.tls_level", [boltTls.line],
                "Bolt encryption disabled",
                "server.bolt.tls_level=DISABLED leaves Bolt traffic unencrypted. The bind is private in this file, so exposure is limited to this machine and its local network path — but the setting travels with the file if the bind ever widens.",
                "Set server.bolt.tls_level=OPTIONAL or REQUIRED with a certificate, even for local use, so the posture survives a bind change.");
            }
          } else if (tlsVal !== "OPTIONAL" && tlsVal !== "REQUIRED") {
            add("WARNING", "server.bolt.tls_level", [boltTls.line],
              "Bolt TLS level not recognized",
              "The value on this line is not DISABLED, OPTIONAL, or REQUIRED, so Bolt's encryption posture cannot be confirmed from the file.",
              "Set server.bolt.tls_level to OPTIONAL or REQUIRED (REQUIRED for any non-loopback bind).");
          }
        } else if (boltExternal) {
          add("WARNING", "server.bolt.tls_level", [listenEntry ? listenEntry.line : 0].filter(function (n) { return n > 0; }),
            "Bolt TLS not set, on an external bind",
            "server.bolt.tls_level is NOT SET IN FILE, and Neo4j's default is DISABLED — while the Bolt connector is bound beyond this machine. Bolt sessions, credentials included, run unencrypted by default.",
            "Set server.bolt.tls_level=REQUIRED with a certificate, or bind Bolt to 127.0.0.1.");
        }

        /* --- Advertised addresses --- */
        ["server.bolt.advertised_address", "server.http.advertised_address", "server.https.advertised_address"].forEach(function (key) {
          var e = get(key);
          if (!e) return;
          var host = hostOfAddress(e.value);
          if (!isPrivateHost(host)) {
            add("INFO", key, [e.line],
              "Advertised address is a public host",
              key + " tells clients to connect to " + e.value + ", which does not look like a private or loopback address. That is correct for a public deployment — and a leak of your internal layout if it is not one.",
              "Confirm this host is meant to be public. For private deployments, advertise a private hostname or VPN name instead.");
          }
        });

        /* --- Procedures --- */
        var unr = get("dbms.security.procedures.unrestricted");
        var allow = get("dbms.security.procedures.allowlist");
        if (unr) {
          var parts = unr.value.split(",").map(trim).filter(function (s) { return s !== ""; });
          var broad = parts.some(function (p) { var lp = lower(p); return lp === "*" || lp.indexOf("apoc") === 0; });
          if (broad) {
            if (authDisabled) {
              add("BLOCKER", "dbms.security.procedures.unrestricted", [unr.line],
                "Unrestricted APOC procedures with authentication disabled",
                "dbms.security.procedures.unrestricted=" + unr.value + " lifts the sandbox on powerful procedures — including APOC's file, import, and system procedures — and authentication is disabled on line " + authEntry.line + ". Anyone who can reach the server can run them, unauthenticated.",
                "Turn authentication back on (dbms.security.auth_enabled=true) and narrow unrestricted to the exact procedures needed, e.g. a named list instead of apoc.*.");
            } else {
              add("WARNING", "dbms.security.procedures.unrestricted", [unr.line],
                "Broadly unrestricted procedures",
                "dbms.security.procedures.unrestricted=" + unr.value + " lifts the sandbox on a wide family of procedures. Any authenticated user — including low-privilege ones where roles are loose — can run them.",
                "Narrow the list to the exact procedures the workload needs and pair it with dbms.security.procedures.allowlist.");
            }
          } else {
            add("INFO", "dbms.security.procedures.unrestricted", [unr.line],
              "Unrestricted procedures are narrowly scoped",
              "dbms.security.procedures.unrestricted=" + unr.value + " is scoped to a named namespace rather than * or apoc.*.",
              "No change needed. Re-check this list whenever a new procedure family is added.");
          }
          if (!allow) {
            add("INFO", "dbms.security.procedures.allowlist", [unr.line],
              "No procedure allowlist while unrestricted is set",
              "dbms.security.procedures.unrestricted is set on line " + unr.line + ", but dbms.security.procedures.allowlist is NOT SET IN FILE. Without an allowlist, the unrestricted list is the only gate on procedure execution.",
              "Add dbms.security.procedures.allowlist naming exactly the procedures ordinary users may run.");
          }
        }

        /* --- CSV file-URL import --- */
        ["dbms.security.allow_csv_import_from_file_urls", "server.allow_csv_import_from_file_urls"].forEach(function (key) {
          var e = get(key);
          if (!e) return;
          var b = parseBool(e.value);
          if (b === true) {
            add("WARNING", key, [e.line],
              "LOAD CSV from file URLs is enabled",
              key + "=true lets any user who can run Cypher read local files through LOAD CSV with file: URLs — config files, keys, and anything else the Neo4j process can read.",
              "Set " + key + "=false unless a workload truly needs file-URL import; prefer importing from the import directory instead.");
          } else if (b === null) {
            add("WARNING", key, [e.line],
              "CSV file-URL import value not recognized",
              "The value on this line is neither true nor false, so the file-URL import posture cannot be confirmed from the file.",
              "Set " + key + "=false explicitly.");
          }
        });

        /* --- HTTP access control / CORS-style keys --- */
        parsed.order.forEach(function (key) {
          if (key.indexOf("http_access_control") === -1) return;
          var e = E[key];
          if (trim(e.value) === "*") {
            add("WARNING", key, [e.line],
              "HTTP access control allows any origin",
              key + " is set to *, which lets any website make cross-origin requests to this server's HTTP API from a visitor's browser.",
              "Restrict " + key + " to the exact origins that need access, or remove the setting to use Neo4j's default.");
          }
        });

        /* --- Minimum password length --- */
        parsed.order.forEach(function (key) {
          if (key.indexOf("minimum_password_length") === -1) return;
          var e = E[key];
          var n = parseInt(trim(e.value), 10);
          if (isNaN(n)) {
            add("WARNING", key, [e.line],
              "Minimum password length not parsed",
              "The value on this line is NOT PARSED as a number, so the password-length floor cannot be confirmed.",
              "Set " + key + " to a whole number of 8 or more.");
          } else if (n < 8) {
            add("WARNING", key, [e.line],
              "Minimum password length is weak",
              key + "=" + n + " allows passwords shorter than 8 characters.",
              "Raise " + key + " to at least 8 — 12 or more is the better floor.");
          }
        });

        /* --- Memory arithmetic --- */
        var heapI = get("server.memory.heap.initial_size");
        var heapM = get("server.memory.heap.max_size");
        var heapIBytes = heapI ? parseSize(heapI.value) : null;
        var heapMBytes = heapM ? parseSize(heapM.value) : null;
        if (heapI && heapIBytes === null) {
          add("WARNING", "server.memory.heap.initial_size", [heapI.line],
            "Heap initial size not parsed",
            "The value “" + heapI.value + "” is NOT PARSED as a Neo4j size (examples that parse: 512m, 2g, 1073741824). Its byte value cannot be checked.",
            "Write the size as a number with a k, m, or g suffix, e.g. server.memory.heap.initial_size=2g.");
        }
        if (heapM && heapMBytes === null) {
          add("WARNING", "server.memory.heap.max_size", [heapM.line],
            "Heap max size not parsed",
            "The value “" + heapM.value + "” is NOT PARSED as a Neo4j size (examples that parse: 512m, 2g, 1073741824). Its byte value cannot be checked.",
            "Write the size as a number with a k, m, or g suffix, e.g. server.memory.heap.max_size=2g.");
        }
        if (heapI && heapM && heapIBytes !== null && heapMBytes !== null) {
          var linesBoth = [heapI.line, heapM.line];
          if (heapIBytes > heapMBytes) {
            add("BLOCKER", "server.memory.heap.initial_size / server.memory.heap.max_size", linesBoth,
              "Heap initial size is larger than heap max size",
              "Arithmetic: initial_size " + heapI.value + " = " + humanBytes(heapIBytes) + "; max_size " + heapM.value + " = " + humanBytes(heapMBytes) + ". Initial exceeds max by " + fmtBytes(heapIBytes - heapMBytes) + " bytes — the JVM cannot start with an initial heap bigger than its maximum, so the server will not start well, if at all.",
              "Set initial_size no larger than max_size. Matching them exactly (both " + heapM.value + ") is the usual production choice.");
          } else if (heapIBytes !== heapMBytes) {
            add("INFO", "server.memory.heap.initial_size / server.memory.heap.max_size", linesBoth,
              "Heap initial and max differ",
              "Arithmetic: initial_size " + heapI.value + " = " + humanBytes(heapIBytes) + "; max_size " + heapM.value + " = " + humanBytes(heapMBytes) + ". The heap can grow by " + fmtBytes(heapMBytes - heapIBytes) + " bytes at run time. That is legal, but a fixed heap avoids resize pauses.",
              "Optional: set initial_size equal to max_size for a fixed heap.");
          } else {
            add("INFO", "server.memory.heap.initial_size / server.memory.heap.max_size", linesBoth,
              "Heap initial and max match",
              "Arithmetic: initial_size " + heapI.value + " = " + humanBytes(heapIBytes) + "; max_size " + heapM.value + " = " + humanBytes(heapMBytes) + ". Equal — a fixed heap, the usual production choice.",
              "No change needed.");
          }
        }
        var pc = get("server.memory.pagecache.size");
        if (pc) {
          var pcBytes = parseSize(pc.value);
          if (pcBytes === null) {
            add("WARNING", "server.memory.pagecache.size", [pc.line],
              "Pagecache size not parsed",
              "The value “" + pc.value + "” is NOT PARSED as a Neo4j size (examples that parse: 512m, 2g, 1073741824).",
              "Write the size as a number with a k, m, or g suffix, e.g. server.memory.pagecache.size=1g.");
          } else {
            add("INFO", "server.memory.pagecache.size", [pc.line],
              "Pagecache size",
              "Parsed: " + pc.value + " = " + humanBytes(pcBytes) + ". Size the pagecache to hold as much of the graph as the host's free RAM allows, after the heap is accounted for.",
              "No change needed unless the host's RAM says otherwise.");
          }
        }

        /* --- Duplicates --- */
        parsed.duplicates.forEach(function (d) {
          add("WARNING", d.key, d.lines.slice(),
            "Duplicate key — last value wins",
            d.key + " appears on lines " + d.lines.join(" and ") + ". Neo4j applies the LAST value in the file (line " + d.lines[d.lines.length - 1] + "); the earlier line is dead text that will mislead the next reader. The audit above graded the last value.",
            "Delete the earlier occurrence and keep one line for " + d.key + ".");
        });

        /* --- Not parsed lines --- */
        parsed.notParsed.forEach(function (np) {
          add("WARNING", "(line " + np.line + ")", [np.line],
            "Line not parsed — excluded from the audit",
            "This line is NOT PARSED: it is not a comment and not a key=value line, so it was excluded from the audit. If it was meant to be a setting, Neo4j will not apply it either — and a typo'd security key fails silently in exactly this way.",
            "Rewrite it as key=value, comment it out with #, or delete it.");
        });

        /* --- Sort: BLOCKER, WARNING, INFO; then by first line --- */
        var rank = { BLOCKER: 0, WARNING: 1, INFO: 2 };
        findings.sort(function (a, b) {
          if (rank[a.severity] !== rank[b.severity]) return rank[a.severity] - rank[b.severity];
          var la = a.lines.length ? a.lines[0] : 9999, lb = b.lines.length ? b.lines[0] : 9999;
          return la - lb;
        });

        var counts = { BLOCKER: 0, WARNING: 0, INFO: 0 };
        findings.forEach(function (f) { counts[f.severity]++; });
        var verdict = counts.BLOCKER > 0 ? "DO NOT DEPLOY" : (counts.WARNING > 0 ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY");

        var notAudited = parsed.order.filter(function (k) { return !isGraded(k); })
          .map(function (k) { return { key: k, line: E[k].line }; });

        var notSet = [];
        NOT_SET_NOTES.forEach(function (pair) {
          var keyName = pair[0];
          var present = keyName.split(" / ").some(function (k) { return !!E[k]; });
          if (!present) notSet.push({ key: keyName, note: pair[1] });
        });

        return {
          verdict: verdict,
          counts: counts,
          findings: findings,
          notParsed: parsed.notParsed,
          notAudited: notAudited,
          notSet: notSet,
          parsed: parsed
        };
      }

      /* ---------------- Drift ---------------- */

      function drift(parsedA, parsedB) {
        var added = [], removed = [], changed = [], unchangedCount = 0;
        var keysB = {}, keysA = {};
        parsedB.order.forEach(function (k) { keysB[k] = true; });
        parsedA.order.forEach(function (k) { keysA[k] = true; });
        parsedB.order.forEach(function (k) {
          if (!keysA[k]) added.push({ key: k, lineB: parsedB.entries[k].line, value: parsedB.entries[k].value });
        });
        parsedA.order.forEach(function (k) {
          if (!keysB[k]) { removed.push({ key: k, lineA: parsedA.entries[k].line, value: parsedA.entries[k].value }); return; }
          var va = parsedA.entries[k].value, vb = parsedB.entries[k].value;
          if (va !== vb) changed.push({ key: k, lineA: parsedA.entries[k].line, lineB: parsedB.entries[k].line, valueA: va, valueB: vb });
          else unchangedCount++;
        });
        return { added: added, removed: removed, changed: changed, unchangedCount: unchangedCount };
      }

      /* ---------------- Reports ---------------- */

      function shownValue(key, value) { return isSecretKey(key) ? "(value hidden — secret key)" : value; }

      function buildTextReport(result, driftResult) {
        var out = [];
        out.push("J-Dawgs Neo4j Server Config Safety Auditor™ - Audit Report");
        out.push("Verdict: " + result.verdict);
        out.push("Findings: " + result.counts.BLOCKER + " BLOCKER, " + result.counts.WARNING + " WARNING, " + result.counts.INFO + " INFO");
        out.push("");
        out.push("FINDINGS");
        if (!result.findings.length) out.push("  (none)");
        result.findings.forEach(function (f, i) {
          out.push("");
          out.push((i + 1) + ". [" + f.severity + "] " + f.key + (f.lines.length ? " (line" + (f.lines.length > 1 ? "s" : "") + " " + f.lines.join(", ") + ")" : " (not set in file)"));
          out.push("   " + f.title);
          out.push("   " + f.detail);
          out.push("   Fix: " + f.fix);
        });
        out.push("");
        out.push("NOT PARSED LINES");
        if (!result.notParsed.length) out.push("  (none)");
        result.notParsed.forEach(function (np) { out.push("  Line " + np.line + ": NOT PARSED — excluded from the audit."); });
        out.push("");
        out.push("NOT AUDITED KEYS (read, not graded)");
        if (!result.notAudited.length) out.push("  (none)");
        result.notAudited.forEach(function (n) { out.push("  " + n.key + " (line " + n.line + ")"); });
        out.push("");
        out.push("NOT SET IN FILE");
        if (!result.notSet.length) out.push("  (none)");
        result.notSet.forEach(function (n) { out.push("  " + n.key + " — " + n.note); });
        if (driftResult) {
          out.push("");
          out.push("DRIFT (second config vs. first config)");
          out.push("  Added: " + driftResult.added.length + ", Removed: " + driftResult.removed.length + ", Changed: " + driftResult.changed.length + ", Unchanged: " + driftResult.unchangedCount);
          driftResult.added.forEach(function (d) { out.push("  ADDED   " + d.key + " (second config, line " + d.lineB + ") = " + shownValue(d.key, d.value)); });
          driftResult.removed.forEach(function (d) { out.push("  REMOVED " + d.key + " (first config, line " + d.lineA + ") = " + shownValue(d.key, d.value)); });
          driftResult.changed.forEach(function (d) { out.push("  CHANGED " + d.key + " (first line " + d.lineA + ", second line " + d.lineB + "): " + shownValue(d.key, d.valueA) + " -> " + shownValue(d.key, d.valueB)); });
        }
        out.push("");
        out.push("Secret-key values are never shown in this report. This tool parses pasted text only; it does not connect to a database, start Neo4j, or test credentials.");
        return out.join("\n");
      }

      function buildJsonReport(result, driftResult) {
        var obj = {
          tool: "J-Dawgs Neo4j Server Config Safety Auditor",
          verdict: result.verdict,
          counts: { blockers: result.counts.BLOCKER, warnings: result.counts.WARNING, info: result.counts.INFO },
          findings: result.findings.map(function (f) {
            return { severity: f.severity, key: f.key, lines: f.lines, title: f.title, detail: f.detail, fix: f.fix };
          }),
          notParsedLines: result.notParsed.map(function (np) { return { line: np.line, status: "NOT PARSED" }; }),
          notAuditedKeys: result.notAudited,
          notSetInFile: result.notSet,
          drift: null
        };
        if (driftResult) {
          obj.drift = {
            added: driftResult.added.map(function (d) { return { key: d.key, lineInSecond: d.lineB, value: shownValue(d.key, d.value) }; }),
            removed: driftResult.removed.map(function (d) { return { key: d.key, lineInFirst: d.lineA, value: shownValue(d.key, d.value) }; }),
            changed: driftResult.changed.map(function (d) { return { key: d.key, lineInFirst: d.lineA, lineInSecond: d.lineB, valueInFirst: shownValue(d.key, d.valueA), valueInSecond: shownValue(d.key, d.valueB) }; }),
            unchangedCount: driftResult.unchangedCount
          };
        }
        return JSON.stringify(obj, null, 2);
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "EXAMPLE_RISKY": (typeof EXAMPLE_RISKY !== 'undefined' ? EXAMPLE_RISKY : undefined), "EXAMPLE_HARDENED": (typeof EXAMPLE_HARDENED !== 'undefined' ? EXAMPLE_HARDENED : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-neo4j-server-config-safety-auditortm',
  name: 'J-Dawgs Neo4j Server Config Safety Auditor',
  description: 'Neo4j startup only answers whether the config loads; this grades a pasted neo4j.conf anywhere — auth disabled, all-interface Bolt/HTTP with no TLS, unrestricted APOC procedures, heap arithmetic in bytes, secrets by key name and line only — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "EXAMPLE_RISKY": __core["EXAMPLE_RISKY"], "EXAMPLE_HARDENED": __core["EXAMPLE_HARDENED"] }
};
