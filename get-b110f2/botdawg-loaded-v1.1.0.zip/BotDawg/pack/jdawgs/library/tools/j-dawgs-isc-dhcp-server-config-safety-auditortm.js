'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs ISC DHCP Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

    // === AUDIT CORE START ===
    function ipToInt(s) {
      var m = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(String(s).trim());
      if (!m) return null;
      var parts = [Number(m[1]), Number(m[2]), Number(m[3]), Number(m[4])];
      for (var i = 0; i < 4; i++) { if (parts[i] > 255) return null; }
      return ((parts[0] * 256 + parts[1]) * 256 + parts[2]) * 256 + parts[3];
    }
    function intToIp(n) {
      return [Math.floor(n / 16777216) % 256, Math.floor(n / 65536) % 256, Math.floor(n / 256) % 256, n % 256].join(".");
    }
    function isContiguousMask(maskInt) {
      var inv = (~maskInt) >>> 0;
      return (inv & (inv + 1)) === 0;
    }
    function stripComment(line) {
      var inStr = false, out = "";
      for (var i = 0; i < line.length; i++) {
        var c = line.charAt(i);
        if (c === '"') inStr = !inStr;
        if (c === "#" && !inStr) break;
        out += c;
      }
      return out;
    }
    function scanStatements(text) {
      var clean = text.split(/\r?\n/).map(stripComment).join("\n");
      var out = [];
      var cur = "", startLine = null, line = 1, inStr = false;
      function flush(kind, atLine) {
        var t = cur.replace(/\s+/g, " ").trim();
        if (t || kind === "open") {
          out.push({ kind: kind, text: t, line: (startLine === null ? atLine : startLine) });
        }
        cur = ""; startLine = null;
      }
      for (var i = 0; i < clean.length; i++) {
        var c = clean.charAt(i);
        if (c === "\n") { line++; cur += " "; continue; }
        if (c === '"') { inStr = !inStr; if (startLine === null) startLine = line; cur += c; continue; }
        if (!inStr && c === "{") { flush("open", line); continue; }
        if (!inStr && c === ";") { flush("stmt", line); continue; }
        if (!inStr && c === "}") {
          if (cur.trim()) flush("stmt", line);
          out.push({ kind: "close", text: "", line: line });
          continue;
        }
        if (startLine === null && !/\s/.test(c)) startLine = line;
        cur += c;
      }
      if (cur.trim()) flush("stmt", line);
      return out;
    }
    function redactQuoted(s) {
      return s.replace(/"[^"]*"/g, '"…"');
    }
    var KNOWN_PATTERNS = [
      /^log-facility\s+\S+$/, /^filename\s+/, /^server-name\s+/, /^next-server\s+/,
      /^pid-file-name\s+/, /^lease-file-name\s+/, /^db-time-format\s+/,
      /^server-identifier\s+/, /^use-host-decl-names\s+/, /^get-lease-hostnames\s+/,
      /^ping-check\s+/, /^update-static-leases\s+/, /^update-optimization\s+/,
      /^dynamic-bootp-lease-(cutoff|length)\s+/, /^boot-unknown-clients\s+/,
      /^one-lease-per-client\s+/, /^stash-agent-options\s+/,
      /^adaptive-lease-time-threshold\s+/, /^do-forward-updates\s+/, /^do-reverse-updates\s+/,
      /^ddns-(domainname|rev-domainname|hostname|ttl)\s+/,
      /^min-secs\s+/, /^min-lease-time\s+/, /^lease-time\s+/, /^offering-time\s+/,
      /^omapi-port\s+/, /^omapi-key\s+/, /^key\s+\S+$/, /^local-(port|address)\s+/,
      /^algorithm\s+/, /^always-(broadcast|reply-rfc1048)\s+/,
      /^(address|peer address)\s+/, /^max-response-delay\s+/, /^max-unacked-updates\s+/,
      /^mclt\s+/, /^split\s+/, /^hba\s+/, /^load balance max seconds\s+/,
      /^max-lease-misbalance\s+/, /^max-lease-ownership\s+/,
      /^min-balance\s+/, /^max-balance\s+/, /^primary$/, /^secondary$/,
      /^failover peer\s+"[^"]+"$/, /^set\s+/, /^unset\s+/, /^break$/,
      /^execute\s*\(/, /^match\s+/, /^subclass\s+/, /^vendor-option-space\s+/,
      /^space\s+/, /^server-duid\s+/, /^host\s+\S+$/, /^if\s+/, /^elsif\s+/,
      /^else$/, /^on\s+/, /^deny declines$/, /^ignore\s+\S+/
    ];
    function isKnown(s) {
      for (var i = 0; i < KNOWN_PATTERNS.length; i++) {
        if (KNOWN_PATTERNS[i].test(s)) return true;
      }
      return false;
    }

    function auditConfig(text) {
      var findings = [];
      function add(sev, tag, line, msg) {
        findings.push({ sev: sev, tag: tag, line: line, msg: msg });
      }
      var stmts = scanStatements(text);
      var stack = [];
      var subnets = [];
      var ranges = [];
      var hosts = [];
      var optionAddrs = []; // {name, value, line}
      var globalOptions = {}; // name -> first line (global scope only)
      var authoritativeSeen = false;
      var notAuthoritativeLine = null;
      var defLease = null, maxLease = null; // {val, line}
      var statementCount = 0;

      function findCtx(type) {
        for (var i = stack.length - 1; i >= 0; i--) {
          if (stack[i].type === type) return stack[i];
        }
        return null;
      }

      for (var si = 0; si < stmts.length; si++) {
        var st = stmts[si];
        if (st.kind === "close") {
          var closed = stack.pop();
          if (closed) {
            if (closed.type === "host") hosts.push(closed);
            if (closed.type === "failover") {
              if (closed.port === null || closed.peerPort === null) {
                var missing = [];
                if (closed.port === null) missing.push('"port"');
                if (closed.peerPort === null) missing.push('"peer port"');
                add("blocker", "FAILOVER", closed.line,
                  'Failover peer "' + closed.name + '" (block opened on line ' + closed.line + ', checked at line ' + st.line + ') is missing ' + missing.join(" and ") +
                  '. A failover pair needs both a port it listens on and a peer port it talks to; without the pair the two servers cannot sync leases, and clients can be handed the same address twice.');
              } else {
                add("info", "FAILOVER", closed.line,
                  'Failover peer "' + closed.name + '" (line ' + closed.line + ') sets both port ' + closed.port.val + ' (line ' + closed.port.line + ') and peer port ' + closed.peerPort.val + ' (line ' + closed.peerPort.line + ').');
              }
            }
          }
          continue;
        }
        if (st.kind === "open") {
          var t = st.text, m;
          if ((m = /^subnet\s+(\S+)\s+netmask\s+(\S+)$/.exec(t))) {
            var sip = ipToInt(m[1]), smask = ipToInt(m[2]);
            var sctx = { type: "subnet", line: st.line, ipStr: m[1], maskStr: m[2], ipInt: sip, maskInt: smask, netInt: null, bcastInt: null };
            if (sip === null || smask === null) {
              add("blocker", "SUBNET", st.line, 'Subnet declaration on line ' + st.line + ' — "' + m[1] + ' netmask ' + m[2] + '" — is not a valid IPv4 address / netmask pair, so nothing inside this block could be checked against real bounds.');
            } else {
              sctx.netInt = (sip & smask) >>> 0;
              sctx.bcastInt = (sctx.netInt | ((~smask) >>> 0)) >>> 0;
              subnets.push(sctx);
              if (!isContiguousMask(smask)) {
                add("warning", "QUESTION", st.line, 'Line ' + st.line + ': netmask ' + m[2] + ' is not a contiguous mask (its 1-bits are not all on the left). dhcpd expects a normal mask — is this the mask you meant?');
              } else if (sctx.netInt !== sip) {
                add("warning", "QUESTION", st.line, 'Line ' + st.line + ': subnet is declared as ' + m[1] + ', but with netmask ' + m[2] + ' the network address is ' + intToIp(sctx.netInt) + ' (' + m[1] + ' = ' + sip + '; ' + sip + ' AND ' + smask + ' = ' + sctx.netInt + '). Did you mean to declare ' + intToIp(sctx.netInt) + '?');
              }
            }
            stack.push(sctx);
          } else if ((m = /^host\s+(\S+)$/.exec(t))) {
            stack.push({ type: "host", name: m[1], line: st.line, fixed: [], macs: [] });
          } else if ((m = /^failover\s+peer\s+"([^"]+)"/.exec(t))) {
            stack.push({ type: "failover", name: m[1], line: st.line, port: null, peerPort: null });
          } else if ((m = /^key\s+"?([^"\s]+)"?/.exec(t))) {
            stack.push({ type: "key", name: m[1], line: st.line });
          } else if (/^pool$/.test(t)) {
            stack.push({ type: "pool", line: st.line });
          } else if (/^group\b/.test(t)) {
            stack.push({ type: "group", line: st.line });
          } else if (/^shared-network\b/.test(t)) {
            stack.push({ type: "shared", line: st.line });
          } else {
            stack.push({ type: "generic", line: st.line });
          }
          continue;
        }
        // --- plain statement ---
        statementCount++;
        var s = st.text, ln = st.line, mm;

        // Secrets first, before anything can echo the value.
        if (/(^|\s)(shared-)?secret\b/.test(s)) {
          var kctx = findCtx("key");
          var kname = kctx ? kctx.name : "(no enclosing key block)";
          add("info", "SECRET", ln,
            'Line ' + ln + ': a secret value is set for key "' + kname + '". The value is deliberately not shown here or anywhere in the report — anyone holding this config file holds the key, so store and share the file itself like a password.');
          continue;
        }
        if (s === "authoritative") { authoritativeSeen = true; continue; }
        if (s === "not authoritative") { authoritativeSeen = true; notAuthoritativeLine = ln; continue; }
        if ((mm = /^default-lease-time\s+(\d+)$/.exec(s))) {
          if (stack.length === 0) defLease = { val: Number(mm[1]), line: ln };
          continue;
        }
        if ((mm = /^max-lease-time\s+(\d+)$/.exec(s))) {
          if (stack.length === 0) maxLease = { val: Number(mm[1]), line: ln };
          continue;
        }
        if ((mm = /^option\s+([\w-]+)\s*(.*)$/.exec(s))) {
          var oname = mm[1], orest = mm[2].trim();
          if (/^code\s+\d+/.test(orest)) continue; // option-space definition, not a value
          if (stack.length === 0) {
            if (Object.prototype.hasOwnProperty.call(globalOptions, oname)) {
              add("warning", "DUPLICATE", ln,
                'Global option "' + oname + '" is set on line ' + globalOptions[oname] + ' and again on line ' + ln + '. dhcpd resolves duplicates last-in-file, so the value on line ' + ln + ' is the one that takes effect and the line ' + globalOptions[oname] + ' value is dead. Delete the one you do not mean.');
            } else {
              globalOptions[oname] = ln;
            }
          }
          if (oname === "routers" || oname === "domain-name-servers") {
            var vals = orest.split(",");
            for (var vi = 0; vi < vals.length; vi++) {
              var v = vals[vi].trim();
              if (v) optionAddrs.push({ name: oname, value: v, line: ln, ipInt: ipToInt(v) });
            }
          }
          continue;
        }
        if (/^range\b/.test(s)) {
          if ((mm = /^range\s+(dynamic-bootp\s+)?(\S+)\s+(\S+)$/.exec(s))) {
            var rs = ipToInt(mm[2]), re = ipToInt(mm[3]);
            if (rs === null || re === null) {
              add("warning", "NOT PARSED", ln, 'Line ' + ln + ': NOT PARSED — this range statement ("' + redactQuoted(s) + '") does not hold two valid IPv4 addresses, so its bounds were not checked.');
            } else {
              ranges.push({ start: rs, end: re, startStr: mm[2], endStr: mm[3], line: ln, subnet: findCtx("subnet") });
            }
          } else {
            add("warning", "NOT PARSED", ln, 'Line ' + ln + ': NOT PARSED — this range statement ("' + redactQuoted(s) + '") could not be read, so its bounds were not checked.');
          }
          continue;
        }
        if ((mm = /^fixed-address\s+(.+)$/.exec(s))) {
          var hctx = findCtx("host");
          var fval = mm[1].split(",")[0].trim();
          var fint = ipToInt(fval);
          if (hctx) hctx.fixed.push({ raw: fval, ipInt: fint, line: ln });
          continue;
        }
        if ((mm = /^hardware\s+ethernet\s+(\S+)$/.exec(s))) {
          var hctx2 = findCtx("host");
          var macNorm = mm[1].toLowerCase().replace(/-/g, ":");
          if (hctx2) hctx2.macs.push({ raw: mm[1], norm: macNorm, line: ln });
          continue;
        }
        if ((mm = /^ddns-update-style\s+(\S+)$/.exec(s))) {
          add("info", "POSTURE", ln, 'Line ' + ln + ': ddns-update-style is "' + mm[1] + '" — this server ' + (mm[1] === "none" ? "will not update DNS records when it hands out leases." : 'will try to update DNS records when it hands out leases, in the "' + mm[1] + '" style.') );
          continue;
        }
        if ((mm = /^(allow|deny|ignore)\s+booting$/.exec(s))) {
          add("info", "POSTURE", ln, 'Line ' + ln + ': booting posture is "' + mm[1] + ' booting" — ' + (mm[1] === "allow" ? "this server will answer boot (BOOTP) requests." : "this server will refuse boot (BOOTP) requests.") );
          continue;
        }
        var fctx = findCtx("failover");
        if (fctx && (mm = /^peer\s+port\s+(\d+)$/.exec(s))) { fctx.peerPort = { val: Number(mm[1]), line: ln }; continue; }
        if (fctx && (mm = /^port\s+(\d+)$/.exec(s))) { fctx.port = { val: Number(mm[1]), line: ln }; continue; }
        if (/^(allow|deny)\s+/.test(s)) continue; // other allow/deny postures: read, no finding
        if (isKnown(s)) continue;
        add("warning", "NOT PARSED", ln,
          'Line ' + ln + ': NOT PARSED — this statement was not recognized, so nothing on it was checked: "' + redactQuoted(s.length > 90 ? s.slice(0, 90) + "…" : s) + '". If it matters to how this server behaves, check it by hand.');
      }
      // Unclosed host/failover blocks at end of file still count.
      for (var ui = 0; ui < stack.length; ui++) {
        if (stack[ui].type === "host") hosts.push(stack[ui]);
        if (stack[ui].type === "failover") {
          var uf = stack[ui];
          if (uf.port === null || uf.peerPort === null) {
            var umiss = [];
            if (uf.port === null) umiss.push('"port"');
            if (uf.peerPort === null) umiss.push('"peer port"');
            add("blocker", "FAILOVER", uf.line, 'Failover peer "' + uf.name + '" (block opened on line ' + uf.line + ', and never closed) is missing ' + umiss.join(" and ") + '. A failover pair needs both ports to sync leases.');
          }
        }
      }

      // (1) Authoritative posture
      if (!authoritativeSeen) {
        add("warning", "AUTHORITATIVE", null,
          'No line: "authoritative;" does not appear anywhere in this file. Without it, this server will not firmly tell a client that its old lease is no longer valid, so clients can cling to stale addresses and sit through long timeouts — and if a rogue or leftover DHCP server is on the same wire, this one will not win the argument. If this server is the intended authority for its subnets, add "authoritative;" at the top level.');
      } else if (notAuthoritativeLine !== null) {
        add("warning", "AUTHORITATIVE", notAuthoritativeLine,
          'Line ' + notAuthoritativeLine + ': this file explicitly says "not authoritative;". This server will stay quiet instead of telling clients their old leases are wrong, which means slow recoveries and stale addresses after any change. That is the right setting only for a standby or testing server.');
      }

      // (2) Pool sanity
      for (var ri = 0; ri < ranges.length; ri++) {
        var r = ranges[ri];
        if (r.start > r.end) {
          add("blocker", "POOL", r.line, 'Line ' + r.line + ': range ' + r.startStr + ' – ' + r.endStr + ' runs backwards (' + r.startStr + ' = ' + r.start + ' is greater than ' + r.endStr + ' = ' + r.end + '), so the pool hands out nothing.');
        }
        if (r.subnet && r.subnet.netInt !== null) {
          var sn = r.subnet;
          if (r.start < sn.netInt || r.end > sn.bcastInt) {
            add("blocker", "POOL", r.line,
              'Line ' + r.line + ': range ' + r.startStr + ' – ' + r.endStr + ' falls outside its subnet. The subnet ' + sn.ipStr + ' netmask ' + sn.maskStr + ' spans ' + intToIp(sn.netInt) + ' (' + sn.netInt + ') to ' + intToIp(sn.bcastInt) + ' (' + sn.bcastInt + '), but the range runs ' + r.start + ' to ' + r.end + '. Addresses outside the subnet cannot be routed by this server\'s clients.');
          }
        } else if (!r.subnet) {
          add("info", "POOL", r.line, 'Line ' + r.line + ': range ' + r.startStr + ' – ' + r.endStr + ' is not inside any subnet block, so its bounds could not be checked against a subnet.');
        }
      }
      for (var a = 0; a < ranges.length; a++) {
        for (var b = a + 1; b < ranges.length; b++) {
          var ra = ranges[a], rb = ranges[b];
          var os = Math.max(ra.start, rb.start), oe = Math.min(ra.end, rb.end);
          if (os <= oe) {
            add("blocker", "POOL", rb.line,
              'Lines ' + ra.line + ' and ' + rb.line + ': two dynamic pools overlap. Line ' + ra.line + ' hands out ' + ra.startStr + ' – ' + ra.endStr + ' (' + ra.start + '–' + ra.end + '); line ' + rb.line + ' hands out ' + rb.startStr + ' – ' + rb.endStr + ' (' + rb.start + '–' + rb.end + '). They share ' + intToIp(os) + ' – ' + intToIp(oe) + ' (' + os + '–' + oe + '), so the same address can be leased twice.');
          }
        }
      }
      for (var hi = 0; hi < hosts.length; hi++) {
        var hh = hosts[hi];
        for (var fi = 0; fi < hh.fixed.length; fi++) {
          var fx = hh.fixed[fi];
          if (fx.ipInt === null) continue;
          for (var rj = 0; rj < ranges.length; rj++) {
            var rr = ranges[rj];
            if (fx.ipInt >= rr.start && fx.ipInt <= rr.end) {
              add("blocker", "POOL", rr.line,
                'Line ' + rr.line + ' vs line ' + fx.line + ': the dynamic pool ' + rr.startStr + ' – ' + rr.endStr + ' (' + rr.start + '–' + rr.end + ') contains ' + fx.raw + ' (' + fx.ipInt + '), which host "' + hh.name + '" reserves as its fixed-address on line ' + fx.line + '. The pool can lease that address to a stranger while the reserved host also expects it.');
            }
          }
        }
      }

      // (3) Fixed-address and MAC conflicts
      var byIp = {}, byMac = {};
      for (var h2 = 0; h2 < hosts.length; h2++) {
        var host2 = hosts[h2];
        for (var f2 = 0; f2 < host2.fixed.length; f2++) {
          var fx2 = host2.fixed[f2];
          if (fx2.ipInt === null) continue;
          if (byIp[fx2.ipInt] && byIp[fx2.ipInt].host !== host2) {
            var prev = byIp[fx2.ipInt];
            add("blocker", "CONFLICT", fx2.line,
              'Lines ' + prev.line + ' and ' + fx2.line + ': fixed-address ' + fx2.raw + ' is assigned to two hosts — "' + prev.host.name + '" (line ' + prev.line + ') and "' + host2.name + '" (line ' + fx2.line + '). Both machines will claim the same address.');
          } else if (!byIp[fx2.ipInt]) {
            byIp[fx2.ipInt] = { host: host2, line: fx2.line };
          }
        }
        for (var m2 = 0; m2 < host2.macs.length; m2++) {
          var mc = host2.macs[m2];
          if (byMac[mc.norm] && byMac[mc.norm].host !== host2) {
            var pm = byMac[mc.norm];
            add("blocker", "CONFLICT", mc.line,
              'Lines ' + pm.line + ' and ' + mc.line + ': hardware ethernet ' + mc.raw + ' appears in two host blocks — "' + pm.host.name + '" (line ' + pm.line + ') and "' + host2.name + '" (line ' + mc.line + '). dhcpd matches hosts by this address, so one block silently shadows the other.');
          } else if (!byMac[mc.norm]) {
            byMac[mc.norm] = { host: host2, line: mc.line };
          }
        }
      }

      // (4) Option sanity — questions, never certainties
      for (var oi = 0; oi < optionAddrs.length; oi++) {
        var oa = optionAddrs[oi];
        if (oa.ipInt === null) {
          add("warning", "QUESTION", oa.line,
            'Line ' + oa.line + ': option ' + oa.name + ' lists "' + oa.value + '", which is not a valid IPv4 address (each of the four numbers must be 0–255). Is that a typo — or a hostname written where an address was meant?');
        } else if (subnets.length > 0) {
          var inside = false;
          for (var sni = 0; sni < subnets.length; sni++) {
            if (subnets[sni].netInt !== null && oa.ipInt >= subnets[sni].netInt && oa.ipInt <= subnets[sni].bcastInt) { inside = true; break; }
          }
          if (!inside) {
            var declared = subnets.map(function (x) { return x.ipStr + " netmask " + x.maskStr; }).join("; ");
            add("warning", "QUESTION", oa.line,
              'Line ' + oa.line + ': option ' + oa.name + ' points at ' + oa.value + ', which sits outside every subnet declared in this file (declared: ' + declared + '). That can be perfectly right — a router or DNS server often lives on another segment — but is it the address you meant clients to use?');
          }
        }
      }

      // (5) Lease-time extremes
      var THIRTY_DAYS = 2592000;
      function fmtDur(sec) {
        if (sec % 86400 === 0) return sec + " seconds (" + (sec / 86400) + (sec === 86400 ? " day" : " days") + ")";
        if (sec >= 86400) return sec + " seconds (about " + Math.round(sec / 864) / 100 + " days)";
        if (sec % 3600 === 0) return sec + " seconds (" + (sec / 3600) + " hours)";
        return sec + " seconds";
      }
      if (defLease === null) {
        add("warning", "LEASE", null, 'No line: "default-lease-time" is not set at the top level of this file. A client that does not ask for a specific lease length gets whatever the daemon falls back to — set it explicitly so the behavior is the one you chose.');
      } else if (defLease.val > THIRTY_DAYS) {
        add("warning", "LEASE", defLease.line, 'Line ' + defLease.line + ': default-lease-time is ' + fmtDur(defLease.val) + ' — over 30 days. Clients can hold addresses for a month or more, so a busy pool can run dry while addresses sit with machines that left long ago.');
      }
      if (maxLease === null) {
        add("warning", "LEASE", null, 'No line: "max-lease-time" is not set at the top level of this file. Without a ceiling, a client can ask for — and get — a lease far longer than you intended.');
      } else if (maxLease.val > THIRTY_DAYS) {
        add("warning", "LEASE", maxLease.line, 'Line ' + maxLease.line + ': max-lease-time is ' + fmtDur(maxLease.val) + ' — over 30 days. Any client that asks can hold an address that long.');
      }
      if (defLease !== null && maxLease !== null && maxLease.val < defLease.val) {
        add("blocker", "LEASE", maxLease.line,
          'Lines ' + defLease.line + ' and ' + maxLease.line + ': max-lease-time (' + maxLease.val + ' seconds, line ' + maxLease.line + ') is smaller than default-lease-time (' + defLease.val + ' seconds, line ' + defLease.line + '). The ceiling sits below the standard offer, so lease negotiation contradicts itself.');
      }

      var sevRank = { blocker: 0, warning: 1, info: 2 };
      findings.sort(function (x, y) {
        if (sevRank[x.sev] !== sevRank[y.sev]) return sevRank[x.sev] - sevRank[y.sev];
        var lx = x.line === null ? 0 : x.line, ly = y.line === null ? 0 : y.line;
        return lx - ly;
      });
      var blockers = findings.filter(function (f) { return f.sev === "blocker"; }).length;
      var warnings = findings.filter(function (f) { return f.sev === "warning"; }).length;
      var infos = findings.filter(function (f) { return f.sev === "info"; }).length;
      var verdict = blockers > 0 ? "DO NOT DEPLOY" : (warnings > 0 ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY");
      return { verdict: verdict, findings: findings, blockers: blockers, warnings: warnings, infos: infos, statements: statementCount };
    }

    function buildReport(result) {
      var out = [];
      out.push("J-Dawgs ISC DHCP Server Config Safety Auditor™ — Audit Report");
      out.push("Verdict: " + result.verdict);
      out.push("Findings: " + result.blockers + " blocker(s), " + result.warnings + " warning(s), " + result.infos + " note(s), across " + result.statements + " statement(s) read.");
      out.push("");
      if (result.findings.length === 0) {
        out.push("No findings. Every check this audit runs came back clean.");
      }
      for (var i = 0; i < result.findings.length; i++) {
        var f = result.findings[i];
        var label = f.sev === "blocker" ? "BLOCKER" : (f.sev === "warning" ? "WARNING" : "NOTE");
        out.push("[" + label + " · " + f.tag + "] " + f.msg);
        out.push("");
      }
      out.push("Audited locally in the browser with the J-Dawgs ISC DHCP Server Config Safety Auditor™. Nothing was uploaded or saved, and no secret values are included in this report.");
      out.push("© 2026 Joshua Dawson");
      return out.join("\n");
    }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-isc-dhcp-server-config-safety-auditortm',
  name: 'J-Dawgs ISC DHCP Server Config Safety Auditor',
  description: 'dhcpd -t needs the daemon installed and stops at load validity; ours grades a pasted dhcpd.conf offline — pool overlaps, fixed-address conflicts, lease posture — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
