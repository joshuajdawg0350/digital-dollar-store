'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Gitea Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        /* ---------- Worked examples (all values fake) ---------- */
        var RISKY = [
          "; Risky sample app.ini - loaded for demonstration. Every value below is fake.",
          "[server]",
          "PROTOCOL = http",
          "DOMAIN = git.example.com",
          "ROOT_URL = http://git.example.com/",
          "SSH_PORT = 22",
          "",
          "[service]",
          "DISABLE_REGISTRATION = false",
          "REQUIRE_SIGNIN_VIEW = false",
          "ENABLE_CAPTCHA = false",
          "",
          "[security]",
          "INSTALL_LOCK = false",
          "SECRET_KEY = changeme",
          "",
          "[database]",
          "DB_TYPE = mysql",
          "HOST = 127.0.0.1:3306",
          "NAME = gitea",
          "USER = gitea",
          "PASSWD = canary-pass-4815"
        ].join("\n");

        var HARDENED = [
          "; Hardened sample app.ini - every value below is fake.",
          "[server]",
          "PROTOCOL = https",
          "DOMAIN = git.example.com",
          "ROOT_URL = https://git.example.com/",
          "SSH_DOMAIN = git.example.com",
          "SSH_PORT = 2222",
          "DISABLE_SSH = false",
          "",
          "[service]",
          "DISABLE_REGISTRATION = true",
          "REQUIRE_SIGNIN_VIEW = true",
          "ENABLE_CAPTCHA = true",
          "",
          "[security]",
          "INSTALL_LOCK = true",
          "SECRET_KEY = fake-hardened-secret-7f3a9c1e5b8d2046aa91",
          "INTERNAL_TOKEN = fake-hardened-token-51bd08c3f6a947e2c0d5",
          "",
          "[database]",
          "DB_TYPE = sqlite3",
          "PATH = /data/gitea/gitea.db",
          "",
          "[repository]",
          "ALLOW_LOCALNETWORKS = false"
        ].join("\n");

        var EDGE = [
          "; Edge-case sample - a duplicate key, a commented-out key, and a broken line.",
          "[security]",
          "; INSTALL_LOCK = true",
          "SECRET_KEY = fake-edge-secret-0a1b2c3d4e5f60718293a4b5",
          "INTERNAL_TOKEN = fake-edge-token-9f8e7d6c5b4a39281706f5e4",
          "",
          "[service]",
          "DISABLE_REGISTRATION = true",
          "DISABLE_REGISTRATION = false",
          "REQUIRE_SIGNIN_VIEW = true",
          "this line is not a setting at all"
        ].join("\n");

        /* Keys this auditor actually consults, per section. Anything else is NOT AUDITED. */
        var AUDITED = {
          "server": { "PROTOCOL": 1, "ROOT_URL": 1, "DOMAIN": 1, "SSH_DOMAIN": 1, "SSH_PORT": 1, "DISABLE_SSH": 1, "CERT_FILE": 1, "KEY_FILE": 1, "ENABLE_LETSENCRYPT": 1 },
          "service": { "DISABLE_REGISTRATION": 1, "REQUIRE_SIGNIN_VIEW": 1, "ENABLE_CAPTCHA": 1 },
          "security": { "INSTALL_LOCK": 1, "SECRET_KEY": 1, "INTERNAL_TOKEN": 1 },
          "database": { "PASSWD": 1 },
          "repository": { "ALLOW_LOCALNETWORKS": 1 },
          "admin": { "DISABLE_REGULAR_ORG_CREATION": 1 }
        };

        var PLACEHOLDERS = {
          "changeme": 1, "changethis": 1, "change-me": 1, "pleasechangeme": 1,
          "secret": 1, "secretkey": 1, "yoursecretkey": 1, "your-secret-key": 1,
          "password": 1, "passwd": 1, "letmein": 1, "default": 1, "example": 1,
          "sample": 1, "placeholder": 1, "todo": 1, "test": 1, "testing": 1,
          "gitea": 1, "internaltoken": 1, "internal-token": 1, "replaceme": 1,
          "insertsecrethere": 1, "xxxx": 1, "xxxxxxxx": 1, "12345678": 1, "123456789": 1
        };
        var SECRET_MIN = 16;

        /* ---------- INI parsing ---------- */
        function parseIni(text) {
          var lines = text.split(/\r\n|\r|\n/);
          var sections = {};      // name -> { key -> [ {value, line} ] }
          var sectionNames = [];  // in first-seen order
          var malformed = [];     // line numbers
          var commentLines = 0;
          var keyCount = 0;
          var current = null;

          function ensureSection(name) {
            if (!Object.prototype.hasOwnProperty.call(sections, name)) {
              sections[name] = {};
              sectionNames.push(name);
            }
          }

          for (var i = 0; i < lines.length; i++) {
            var lineNo = i + 1;
            var t = lines[i].replace(/^\s+|\s+$/g, "");
            if (t === "") continue;
            var c0 = t.charAt(0);
            if (c0 === ";" || c0 === "#") { commentLines++; continue; }
            if (c0 === "[") {
              var m = t.match(/^\[([^\]]+)\]\s*$/);
              if (m) {
                current = m[1].replace(/^\s+|\s+$/g, "").toLowerCase();
                ensureSection(current);
              } else {
                malformed.push(lineNo);
              }
              continue;
            }
            var eq = t.indexOf("=");
            if (eq <= 0) { malformed.push(lineNo); continue; }
            var key = t.slice(0, eq).replace(/^\s+|\s+$/g, "").toUpperCase();
            var value = t.slice(eq + 1).replace(/^\s+|\s+$/g, "");
            if (key === "" || /\s/.test(key)) { malformed.push(lineNo); continue; }
            if (value.length >= 2) {
              var q = value.charAt(0);
              if ((q === '"' || q === "'") && value.charAt(value.length - 1) === q) {
                value = value.slice(1, -1);
              }
            }
            if (current === null) { current = ""; ensureSection(""); }
            var bucket = sections[current];
            if (!bucket[key]) bucket[key] = [];
            bucket[key].push({ value: value, line: lineNo });
            keyCount++;
          }
          return {
            sections: sections, sectionNames: sectionNames,
            malformed: malformed, commentLines: commentLines,
            keyCount: keyCount, totalLines: lines.length
          };
        }

        function entries(P, section, key) {
          var s = P.sections[section];
          if (!s || !s[key]) return null;
          return s[key];
        }
        function eff(P, section, key) {
          var e = entries(P, section, key);
          return e ? e[e.length - 1] : null;
        }
        function isTrue(v) { return /^(true|yes|on|1)$/i.test(v); }
        function isFalse(v) { return /^(false|no|off|0)$/i.test(v); }
        function boolState(e) {
          if (!e) return "absent";
          if (isTrue(e.value)) return "true";
          if (isFalse(e.value)) return "false";
          return "other";
        }
        function hostOf(s) {
          var h = String(s).replace(/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//, "");
          h = h.split("/")[0];
          if (h.indexOf("@") >= 0) h = h.slice(h.lastIndexOf("@") + 1);
          h = h.split(":")[0];
          return h.toLowerCase();
        }
        function isPublicHost(h) {
          return !!h && h !== "localhost" && h !== "127.0.0.1" && h !== "::1" && h !== "[::1]";
        }
        function safeUrl(s) {
          return String(s).replace(/(\/\/)[^/@\s]*@/, "$1");
        }
        function locOf(section, key, e) {
          var base = "[" + section + "] " + key;
          if (!e) return base + " — NOT SET IN FILE";
          return base + " — line " + e.line;
        }

        /* ---------- Audit ---------- */
        function audit(text) {
          var P = parseIni(text);
          var F = []; // {sev, esc, loc, title, detail, fix}
          function add(sev, loc, title, detail, fix, esc) {
            F.push({ sev: sev, loc: loc, title: title, detail: detail, fix: fix || "", esc: !!esc });
          }

          /* Duplicate keys in the same section */
          P.sectionNames.forEach(function (sn) {
            var bucket = P.sections[sn];
            Object.keys(bucket).forEach(function (key) {
              var list = bucket[key];
              if (list.length > 1) {
                var nums = list.map(function (x) { return "line " + x.line; }).join(" and ");
                add("WARNING", "[" + (sn || "no section") + "] " + key + " — " + nums,
                  "Duplicate key: " + key + " is set " + list.length + " times in [" + (sn || "no section") + "]",
                  "The same key appears on " + nums + ". INI loaders read the last value as the effective one, so the value on line " + list[list.length - 1].line + " is what this audit grades — the earlier line is dead text that will mislead the next person who edits this file.",
                  "Delete the stale line and keep exactly one " + key + " setting in [" + (sn || "no section") + "].");
              }
            });
          });

          /* [security] INSTALL_LOCK */
          var lock = eff(P, "security", "INSTALL_LOCK");
          var lockState = boolState(lock);
          if (!lock) {
            add("BLOCKER", locOf("security", "INSTALL_LOCK", null),
              "INSTALL_LOCK is not set — the installer stays open",
              "INSTALL_LOCK is NOT SET IN FILE, and Gitea's documented default is false: the web installer remains reachable, so anyone who can reach the instance can re-run setup and take it over.",
              "Add INSTALL_LOCK = true under [security] once installation is complete.");
          } else if (lockState === "false") {
            add("BLOCKER", locOf("security", "INSTALL_LOCK", lock),
              "INSTALL_LOCK = false — the installer stays open",
              "With the install lock off, the web installer remains reachable and anyone who can reach the instance can re-run setup and take it over.",
              "Set INSTALL_LOCK = true under [security].");
          } else if (lockState === "true") {
            add("OK", locOf("security", "INSTALL_LOCK", lock),
              "Install lock is on",
              "INSTALL_LOCK = true: the web installer is closed off.",
              "");
          } else {
            add("BLOCKER", locOf("security", "INSTALL_LOCK", lock),
              "INSTALL_LOCK has an unreadable value",
              "The value on this line is not a recognizable true/false, so the audit cannot confirm the installer is locked.",
              "Set INSTALL_LOCK = true under [security], spelled exactly like that.");
          }

          /* [security] secrets — value NEVER rendered; graded by presence/length/placeholder only */
          ["SECRET_KEY", "INTERNAL_TOKEN"].forEach(function (key) {
            var e = eff(P, "security", key);
            if (!e) {
              add("BLOCKER", locOf("security", key, null),
                key + " is not set",
                key + " is NOT SET IN FILE. The paste gives no evidence of a strong, deliberate secret, and this auditor grades only what the file states.",
                "Generate a long random value (32+ characters) and set " + key + " under [security]. Keep it out of version control.");
              return;
            }
            var v = e.value;
            var norm = v.toLowerCase().replace(/[\s_]+/g, "");
            var placeholder = !!PLACEHOLDERS[v.toLowerCase()] || !!PLACEHOLDERS[norm] || /^(.)\1+$/.test(v);
            if (v === "") {
              add("BLOCKER", locOf("security", key, e),
                key + " is set but empty",
                "An empty " + key + " gives the instance no real secret to sign and verify with. (The value is never shown in this report.)",
                "Generate a long random value (32+ characters) and set " + key + " under [security].");
            } else if (placeholder) {
              add("BLOCKER", locOf("security", key, e),
                key + " is a well-known placeholder",
                "The value on this line matches a well-known placeholder (" + v.length + " characters). Placeholders are public knowledge — anyone can forge what this key protects. (The value itself is never shown in this report.)",
                "Replace it with a generated random value of 32+ characters, unique to this instance.");
            } else if (v.length < SECRET_MIN) {
              add("BLOCKER", locOf("security", key, e),
                key + " is too short (" + v.length + " characters)",
                "At " + v.length + " characters, this secret is short enough to brute-force. Gitea-generated secrets run far longer. (The value itself is never shown in this report.)",
                "Replace it with a generated random value of 32+ characters.");
            } else {
              add("OK", locOf("security", key, e),
                key + " is present and plausibly strong",
                "Present, " + v.length + " characters, and not a known placeholder. Graded by length and placeholder match only — the value is never shown.",
                "");
            }
          });

          /* [service] registration / sign-in view / captcha */
          var disReg = eff(P, "service", "DISABLE_REGISTRATION");
          var disRegState = boolState(disReg);
          var regOpen = disRegState !== "true";
          if (disRegState === "true") {
            add("OK", locOf("service", "DISABLE_REGISTRATION", disReg),
              "Self-registration is disabled",
              "DISABLE_REGISTRATION = true: new accounts can only be created by an admin.",
              "");
          } else if (!disReg) {
            add("WARNING", locOf("service", "DISABLE_REGISTRATION", null),
              "Registration is open by default (DISABLE_REGISTRATION not set)",
              "DISABLE_REGISTRATION is NOT SET IN FILE, and Gitea's documented default is false — anyone who can reach the instance can create an account.",
              "If this instance is not meant to be public, set DISABLE_REGISTRATION = true under [service].");
          } else {
            add("WARNING", locOf("service", "DISABLE_REGISTRATION", disReg),
              "Registration is open (DISABLE_REGISTRATION = false)",
              "Anyone who can reach the instance can create an account.",
              "If this instance is not meant to be public, set DISABLE_REGISTRATION = true under [service].");
          }

          var signin = eff(P, "service", "REQUIRE_SIGNIN_VIEW");
          var signinState = boolState(signin);
          var signinRequired = signinState === "true";
          if (regOpen && !signinRequired) {
            add("WARNING",
              locOf("service", "REQUIRE_SIGNIN_VIEW", signin),
              "No sign-in required to view — paired with open registration",
              (signin ? "REQUIRE_SIGNIN_VIEW = false" : "REQUIRE_SIGNIN_VIEW is NOT SET IN FILE (Gitea's documented default is false)") +
              ", so anonymous visitors can browse public content without an account. Combined with open registration, the whole instance is effectively public to anyone who finds the address.",
              "Set REQUIRE_SIGNIN_VIEW = true under [service] if repositories and code should only be visible to signed-in users.",
              true);
          } else if (signinRequired) {
            add("OK", locOf("service", "REQUIRE_SIGNIN_VIEW", signin),
              "Sign-in is required to view content",
              "REQUIRE_SIGNIN_VIEW = true: anonymous visitors see a login page, not your code.",
              "");
          } else {
            add("INFO", locOf("service", "REQUIRE_SIGNIN_VIEW", signin),
              "Anonymous viewing is on, but registration is closed",
              "REQUIRE_SIGNIN_VIEW is not true, so signed-out visitors can read public repositories. With registration disabled that is a common, deliberate posture for a public code host.",
              "Set REQUIRE_SIGNIN_VIEW = true under [service] if even public content should sit behind a login.");
          }

          var captcha = eff(P, "service", "ENABLE_CAPTCHA");
          var captchaState = boolState(captcha);
          if (regOpen) {
            if (captchaState === "true") {
              add("OK", locOf("service", "ENABLE_CAPTCHA", captcha),
                "Captcha is on for sign-ups",
                "ENABLE_CAPTCHA = true: bot sign-ups meet at least one speed bump.",
                "");
            } else {
              add("WARNING", locOf("service", "ENABLE_CAPTCHA", captcha),
                "No captcha while registration is open",
                (captcha ? "ENABLE_CAPTCHA = false" : "ENABLE_CAPTCHA is NOT SET IN FILE") +
                " and registration is open, so scripted sign-ups face no friction at all.",
                "Set ENABLE_CAPTCHA = true under [service], or disable registration.");
            }
          }

          /* [server] protocol / TLS / SSH */
          var tlsAnywhere =
            (eff(P, "server", "PROTOCOL") && eff(P, "server", "PROTOCOL").value.toLowerCase() === "https") ||
            (eff(P, "server", "ROOT_URL") && /^https:\/\//i.test(eff(P, "server", "ROOT_URL").value)) ||
            (!!eff(P, "server", "CERT_FILE") && eff(P, "server", "CERT_FILE").value !== "") ||
            (!!eff(P, "server", "KEY_FILE") && eff(P, "server", "KEY_FILE").value !== "") ||
            (eff(P, "server", "ENABLE_LETSENCRYPT") && isTrue(eff(P, "server", "ENABLE_LETSENCRYPT").value));

          var proto = eff(P, "server", "PROTOCOL");
          var rootUrl = eff(P, "server", "ROOT_URL");
          var domain = eff(P, "server", "DOMAIN");
          var publicHost = null;
          if (rootUrl && isPublicHost(hostOf(rootUrl.value))) publicHost = hostOf(rootUrl.value);
          else if (domain && isPublicHost(hostOf(domain.value))) publicHost = hostOf(domain.value);

          if (!proto) {
            add("INFO", locOf("server", "PROTOCOL", null),
              "PROTOCOL not set — Gitea serves plain HTTP by default",
              "PROTOCOL is NOT SET IN FILE; Gitea's documented default is http. Whether that is a problem depends on what sits in front of the instance, which a paste cannot show.",
              "Set PROTOCOL explicitly under [server] so the next reader does not have to guess.");
          } else if (proto.value.toLowerCase() === "http") {
            if (publicHost) {
              add("WARNING", locOf("server", "PROTOCOL", proto),
                "Plain HTTP on a public address",
                "PROTOCOL = http while " + (rootUrl ? "ROOT_URL (" + safeUrl(rootUrl.value) + ", line " + rootUrl.line + ")" : "DOMAIN (" + domain.value + ", line " + domain.line + ")") +
                " points at a public host. Logins, sessions, and code cross the network unencrypted." +
                (tlsAnywhere ? "" : " Nothing anywhere in this paste indicates TLS — no https, no certificate files, no Let's Encrypt."),
                "Serve the instance over https: terminate TLS at Gitea (PROTOCOL = https with CERT_FILE/KEY_FILE, or ENABLE_LETSENCRYPT) or at a reverse proxy, and make ROOT_URL an https address.",
                !tlsAnywhere);
            } else {
              add("INFO", locOf("server", "PROTOCOL", proto),
                "HTTP on a local-only address",
                "PROTOCOL = http, but no public ROOT_URL or DOMAIN appears in the paste, so this reads as a local or internal deployment.",
                "If this instance is ever exposed publicly, switch to https first.");
            }
          } else if (proto.value.toLowerCase() === "https") {
            add("OK", locOf("server", "PROTOCOL", proto),
              "Gitea itself serves HTTPS",
              "PROTOCOL = https: traffic to the instance is encrypted end to end.",
              "");
          } else {
            add("INFO", locOf("server", "PROTOCOL", proto),
              "PROTOCOL = " + proto.value + " — noted, not graded further",
              "This transport is outside the http/https exposure check.",
              "");
          }
          if (rootUrl && /^https:\/\//i.test(rootUrl.value) && (!proto || proto.value.toLowerCase() !== "http")) {
            if (!proto || proto.value.toLowerCase() !== "https") {
              add("INFO", locOf("server", "ROOT_URL", rootUrl),
                "ROOT_URL is an https address",
                "ROOT_URL (" + safeUrl(rootUrl.value) + ") uses https, which indicates TLS in front of the instance even though PROTOCOL is not https.",
                "");
            }
          }

          var sshDomain = eff(P, "server", "SSH_DOMAIN");
          var sshPort = eff(P, "server", "SSH_PORT");
          if (sshDomain || sshPort) {
            var bits = [];
            if (sshDomain) bits.push("SSH_DOMAIN = " + sshDomain.value + " (line " + sshDomain.line + ")");
            if (sshPort) bits.push("SSH_PORT = " + sshPort.value + " (line " + sshPort.line + ")");
            add("INFO", locOf("server", sshPort ? "SSH_PORT" : "SSH_DOMAIN", sshPort || sshDomain),
              "SSH access is configured: " + bits.join(", "),
              "Git-over-SSH is part of a normal Gitea deployment. This note simply records the exposed endpoint from the paste so it is a decision, not a surprise — make sure the firewall and key-only authentication posture on the host match it.",
              "");
          }
          var disableSsh = eff(P, "server", "DISABLE_SSH");
          if (disableSsh) {
            if (isTrue(disableSsh.value)) {
              add("INFO", locOf("server", "DISABLE_SSH", disableSsh),
                "SSH is disabled in this config",
                "DISABLE_SSH = true: git operations run over HTTP(S) only.",
                "");
            } else if (isFalse(disableSsh.value)) {
              add("OK", locOf("server", "DISABLE_SSH", disableSsh),
                "DISABLE_SSH = false — normal, not a risk by itself",
                "SSH stays available for git operations. That is the standard Gitea posture and is not flagged as a risk; the SSH endpoint above is noted for awareness only.",
                "");
            }
          }

          /* [database] PASSWD — value NEVER rendered */
          var passwd = eff(P, "database", "PASSWD");
          if (passwd) {
            if (passwd.value !== "") {
              add("WARNING", locOf("database", "PASSWD", passwd),
                "Database password sits in plaintext in app.ini",
                "A non-empty PASSWD is present under [database]. Anyone who can read this file — a backup, a screenshot, a pasted config in a chat — holds the database credential. The value is never shown in this report.",
                "Move the credential out of the file: use your platform's secret store or environment-based secret file, restrict app.ini permissions to the service account, and rotate this password since it has now existed in plaintext.");
            } else {
              add("INFO", locOf("database", "PASSWD", passwd),
                "PASSWD is present but empty",
                "No plaintext database password is stored on this line. That is expected for sqlite or socket/trust authentication setups.",
                "");
            }
          } else if (P.sections["database"]) {
            add("OK", locOf("database", "PASSWD", null).replace(" — NOT SET IN FILE", ""),
              "No plaintext PASSWD under [database]",
              "PASSWD is NOT SET IN FILE, so no database password is sitting in this config.",
              "");
          }

          /* [repository] — only what the paste states */
          var localNet = eff(P, "repository", "ALLOW_LOCALNETWORKS");
          if (localNet) {
            if (isTrue(localNet.value)) {
              add("WARNING", locOf("repository", "ALLOW_LOCALNETWORKS", localNet),
                "ALLOW_LOCALNETWORKS = true — services may reach the local network",
                "With local networks allowed, webhooks and migrations can be pointed at internal addresses, which turns a repo setting into a way to probe the host's own network.",
                "Set ALLOW_LOCALNETWORKS = false under [repository] unless you have a specific internal service that needs it.");
            } else if (isFalse(localNet.value)) {
              add("OK", locOf("repository", "ALLOW_LOCALNETWORKS", localNet),
                "Local-network access for services is off",
                "ALLOW_LOCALNETWORKS = false: webhooks and migrations cannot be aimed at internal addresses.",
                "");
            }
          }

          /* [admin] — only what the paste states */
          var orgCreate = eff(P, "admin", "DISABLE_REGULAR_ORG_CREATION");
          if (orgCreate) {
            if (isFalse(orgCreate.value)) {
              add("WARNING", locOf("admin", "DISABLE_REGULAR_ORG_CREATION", orgCreate),
                "Any user can create organizations",
                "DISABLE_REGULAR_ORG_CREATION = false: every account holder can spin up organizations. On an instance with open registration, that multiplies the surface for spam and squatting.",
                "Set DISABLE_REGULAR_ORG_CREATION = true under [admin] if organizations should be admin-approved.");
            } else if (isTrue(orgCreate.value)) {
              add("OK", locOf("admin", "DISABLE_REGULAR_ORG_CREATION", orgCreate),
                "Regular users cannot create organizations",
                "DISABLE_REGULAR_ORG_CREATION = true: organization creation is an admin act.",
                "");
            }
          }

          /* NOT AUDITED list */
          var notAudited = [];
          P.sectionNames.forEach(function (sn) {
            var known = AUDITED[sn];
            var bucket = P.sections[sn];
            Object.keys(bucket).forEach(function (key) {
              if (!known || !known[key]) {
                bucket[key].forEach(function (en) {
                  notAudited.push("line " + en.line + " — [" + (sn === "" ? "no section" : sn) + "] " + key + " — NOT AUDITED");
                });
              }
            });
            if (!known && sn !== "") {
              // whole section unknown: its keys are listed above; add a section-level note once
              notAudited.push("[" + sn + "] — section not covered by this auditor — NOT AUDITED");
            }
          });
          if (P.sections["repository"] && !localNet) {
            notAudited.push("[repository] ALLOW_LOCALNETWORKS — not stated in the paste — NOT SETTLED (repository network posture not graded)");
          }
          if (!P.sections["repository"]) {
            notAudited.push("[repository] — section absent from the paste — NOT AUDITED");
          }
          if (P.sections["admin"] && !orgCreate) {
            notAudited.push("[admin] DISABLE_REGULAR_ORG_CREATION — not stated in the paste — NOT SETTLED (user creation posture not graded)");
          }
          if (!P.sections["admin"]) {
            notAudited.push("[admin] — section absent from the paste — NOT AUDITED");
          }
          if (!P.sections["database"]) {
            notAudited.push("[database] — section absent from the paste — NOT AUDITED");
          }

          var order = { "BLOCKER": 0, "WARNING": 1, "INFO": 2, "OK": 3 };
          F.sort(function (a, b) { return order[a.sev] - order[b.sev]; });

          var counts = { BLOCKER: 0, WARNING: 0, INFO: 0, OK: 0 };
          F.forEach(function (f) { counts[f.sev]++; });

          var verdict = counts.BLOCKER > 0 ? "DO NOT DEPLOY" : (counts.WARNING > 0 ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY");
          return { parsed: P, findings: F, counts: counts, verdict: verdict, notAudited: notAudited };
        }

        /* ---------- Report text (secret values are never included) ---------- */
        function reportText(R) {
          var out = [];
          out.push("J-Dawgs Gitea Server Config Safety Auditor - Audit Report");
          out.push("Verdict: " + R.verdict);
          out.push("Findings: " + R.counts.BLOCKER + " BLOCKER, " + R.counts.WARNING + " WARNING, " + R.counts.INFO + " INFO, " + R.counts.OK + " OK");
          out.push("Parsed " + R.parsed.totalLines + " lines, " + R.parsed.keyCount + " settings. " +
            R.parsed.commentLines + " commented line(s) treated as NOT SET. " +
            R.parsed.malformed.length + " line(s) NOT PARSED and excluded.");
          out.push("Secret values (SECRET_KEY, INTERNAL_TOKEN, database PASSWD) are never printed in this report.");
          out.push("");
          R.findings.forEach(function (f) {
            out.push("[" + f.sev + (f.esc ? " - ESCALATED" : "") + "] " + f.loc);
            out.push("  " + f.title);
            out.push("  " + f.detail);
            if (f.fix) out.push("  Fix: " + f.fix);
            out.push("");
          });
          if (R.notAudited.length) {
            out.push("NOT AUDITED:");
            R.notAudited.forEach(function (n) { out.push("  " + n); });
            out.push("");
          }
          if (R.parsed.malformed.length) {
            out.push("NOT PARSED (excluded): " + R.parsed.malformed.map(function (n) { return "line " + n; }).join(", "));
          }
          return out.join("\n");
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-gitea-server-config-safety-auditortm',
  name: 'J-Dawgs Gitea Server Config Safety Auditor',
  description: 'Gitea startup only answers whether the config loads; this grades a pasted app.ini offline, anywhere — INSTALL_LOCK posture, secret keys measured by length only, and registration and sign-in posture — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
