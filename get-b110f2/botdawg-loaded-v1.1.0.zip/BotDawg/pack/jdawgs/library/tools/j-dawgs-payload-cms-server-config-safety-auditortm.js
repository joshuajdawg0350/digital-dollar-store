'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Payload CMS Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        /* ---------- Deterministic examples (line numbers are stable) ---------- */
        var RISKY_LINES = [
          "// Risky Payload CMS config + env (example)",                              // line 1
          "PAYLOAD_SECRET=changeme",                                                  // line 2
          "DATABASE_URI=mongodb://admin:hunter2pass@db.internal:27017/payload",       // line 3
          "serverURL: 'http://cms.example.com',",                                     // line 4
          "cors: ['*'],",                                                             // line 5
          "csrf: ['*'],",                                                             // line 6
          "debug: true,",                                                             // line 7
          "graphQL: { disablePlaygroundInProduction: false },",                       // line 8
          "upload: { limits: { fileSize: 1048576000 } }"                              // line 9
        ];
        var RISKY_TEXT = RISKY_LINES.join("\n");

        var HARDENED_LINES = [
          "// Hardened Payload CMS config + env (example)",                           // line 1
          "PAYLOAD_SECRET=kX9f2mQ7vR4tZ8wN3pL6sD1hJ5bV0cXeKm9aQwEr",                  // line 2 (40 chars)
          "DATABASE_URI=mongodb://db.internal:27017/payload",                         // line 3 (no credentials in URI)
          "serverURL: 'https://cms.example.com',",                                    // line 4
          "cors: ['https://example.com'],",                                           // line 5
          "csrf: ['https://example.com'],",                                           // line 6
          "debug: false,",                                                            // line 7
          "graphQL: { disablePlaygroundInProduction: true },",                        // line 8
          "rateLimit: { max: 100, window: 900000 },",                                 // line 9
          "upload: { limits: { fileSize: 5000000 } }"                                 // line 10
        ];
        var HARDENED_TEXT = HARDENED_LINES.join("\n");

        var PROSE_TEXT = "Just some plain prose about gardening, the weather, and weekend plans with friends and family. Nothing technical in here at all.";

        var KNOWN_DEFAULTS = ["secret", "changeme", "test", "example", "payload", "default", "password", "letmein", "your-secret", "supersecret", "payloadsecret"];
        var UPLOAD_MAX_BYTES = 25000000;

        /* ---------- Audit engine ---------- */
        function findKeyLine(lines, re) {
          for (var i = 0; i < lines.length; i++) { if (re.test(lines[i])) return i; }
          return -1;
        }
        function blockWindow(lines, start, maxLines) {
          var out = [];
          for (var i = start; i < lines.length && i < start + maxLines; i++) {
            out.push(lines[i]);
            if (i > start && (lines[i].indexOf("]") > -1 || lines[i].indexOf("}") > -1)) break;
          }
          return out.join("\n");
        }
        function extractValue(text, key) {
          var re = new RegExp(key + "\\s*[:=]\\s*['\"]?([^\\s'\",}]+)");
          var m = text.match(re);
          return m ? m[1] : null;
        }

        function audit(text) {
          var lines = String(text || "").split("\n");
          var findings = [];
          function add(severity, check, line, message, fix) {
            findings.push({ severity: severity, check: check, line: line, message: message, fix: fix });
          }

          /* How much of this looks like a Payload config at all? */
          var signals = 0;
          var signalRes = [/PAYLOAD_SECRET/, /DATABASE_URI/, /serverURL/, /cors/i, /csrf/i, /debug/i, /graphQL/i, /rateLimit/i, /upload/i];
          for (var s = 0; s < signalRes.length; s++) { if (signalRes[s].test(text)) signals++; }
          if (signals < 2) {
            return { verdict: "NOT ENOUGH TO GRADE", findings: [], counts: countFindings([]), signals: signals };
          }

          /* PAYLOAD_SECRET */
          var secretIdx = findKeyLine(lines, /PAYLOAD_SECRET/);
          var secretVal = extractValue(text, "PAYLOAD_SECRET");
          if (secretIdx === -1) {
            add("CRITICAL", "PAYLOAD_SECRET missing", null,
              "No PAYLOAD_SECRET was found anywhere in the pasted text. Payload signs sessions and tokens with this secret, so the server cannot be trusted without one.",
              "Set PAYLOAD_SECRET in the server environment to a long random value (32 characters or more) that exists nowhere in code or docs.");
          } else if (secretVal && secretVal.indexOf("process.env") !== 0) {
            if (KNOWN_DEFAULTS.indexOf(secretVal.toLowerCase()) > -1) {
              add("CRITICAL", "PAYLOAD_SECRET known default value", secretIdx + 1,
                "PAYLOAD_SECRET at line " + (secretIdx + 1) + ", length " + secretVal.length + ", matches a known example/default value that anyone can guess.",
                "Replace PAYLOAD_SECRET at line " + (secretIdx + 1) + " with a fresh random value of at least 32 characters, generated only for this deployment.");
            }
            if (secretVal.length < 32) {
              add("HIGH", "PAYLOAD_SECRET too short", secretIdx + 1,
                "PAYLOAD_SECRET at line " + (secretIdx + 1) + " has length " + secretVal.length + ", which is under the 32-character minimum. Short secrets are practical to brute-force.",
                "Regenerate PAYLOAD_SECRET at line " + (secretIdx + 1) + " with at least 32 random characters.");
            }
          }

          /* DATABASE_URI */
          var dbIdx = findKeyLine(lines, /DATABASE_URI/);
          var dbVal = extractValue(text, "DATABASE_URI");
          if (dbIdx === -1) {
            add("CRITICAL", "DATABASE_URI missing", null,
              "No DATABASE_URI was found anywhere in the pasted text, so there is no database connection string to grade — and a Payload server cannot run without one.",
              "Provide DATABASE_URI through the server environment, with credentials supplied by your secrets manager rather than written into the config.");
          } else if (dbVal && dbVal.indexOf("process.env") !== 0) {
            var um = dbVal.match(/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\/([^/@]+)@/);
            if (um && um[1].indexOf(":") > -1) {
              var pwLen = um[1].substring(um[1].indexOf(":") + 1).length;
              add("CRITICAL", "DATABASE_URI plaintext password", dbIdx + 1,
                "DATABASE_URI at line " + (dbIdx + 1) + " embeds a plaintext password in the URI (password length " + pwLen + "). Anyone who can read this config — a repo, a screenshot, a log — has full database credentials.",
                "Remove the password from DATABASE_URI at line " + (dbIdx + 1) + ": keep the URI free of credentials and inject the password from a secrets manager or a locked-down environment variable, then rotate the exposed password.");
            }
          }

          /* serverURL */
          var suIdx = findKeyLine(lines, /serverURL/);
          if (suIdx === -1) {
            add("HIGH", "serverURL missing", null,
              "No serverURL was found in the pasted text. Payload builds links, cookies, and redirects from serverURL, so leaving it unset can produce wrong or insecure URLs in production.",
              "Set serverURL to the exact public https:// address of this deployment.");
          } else if (/http:\/\//.test(lines[suIdx]) && !/https:\/\//.test(lines[suIdx])) {
            add("HIGH", "serverURL not HTTPS", suIdx + 1,
              "serverURL at line " + (suIdx + 1) + " uses http:// instead of https://. Admin sessions and login tokens would travel unencrypted.",
              "Change serverURL at line " + (suIdx + 1) + " to the https:// address and make sure the server is actually served over TLS.");
          }

          /* CORS wildcard */
          var corsIdx = findKeyLine(lines, /cors/i);
          if (corsIdx > -1) {
            var corsWin = blockWindow(lines, corsIdx, 8);
            if (/['"]?\*['"]?/.test(corsWin)) {
              add("HIGH", "CORS wildcard origin", corsIdx + 1,
                "The CORS origins at line " + (corsIdx + 1) + " contain a wildcard \"*\", which lets any website on the internet call this API from a visitor's browser.",
                "Replace the wildcard at line " + (corsIdx + 1) + " with the explicit list of origins that should be allowed, e.g. cors: ['https://your-site.com'].");
            }
          }

          /* CSRF wildcard */
          var csrfIdx = findKeyLine(lines, /csrf/i);
          if (csrfIdx > -1) {
            var csrfWin = blockWindow(lines, csrfIdx, 8);
            if (/['"]?\*['"]?/.test(csrfWin)) {
              add("HIGH", "CSRF wildcard origin", csrfIdx + 1,
                "The CSRF origins at line " + (csrfIdx + 1) + " contain a wildcard \"*\", which disables Payload's cross-site request forgery origin check for every site.",
                "Replace the wildcard at line " + (csrfIdx + 1) + " with the explicit list of trusted origins, e.g. csrf: ['https://your-site.com'].");
            }
          }

          /* Debug mode */
          var debugIdx = findKeyLine(lines, /debug\s*[:=]\s*['"]?true\b/i);
          if (debugIdx > -1) {
            add("HIGH", "Debug mode enabled", debugIdx + 1,
              "Debug mode is switched on at line " + (debugIdx + 1) + ". Debug output leaks internal paths, queries, and config detail to anyone who can trigger an error.",
              "Set debug to false at line " + (debugIdx + 1) + " for production, and only enable it temporarily on a private staging copy.");
          }

          /* GraphQL playground */
          var gqlIdx = findKeyLine(lines, /graphQL/i);
          if (gqlIdx > -1) {
            var gqlWin = blockWindow(lines, gqlIdx, 8);
            var playgroundOn = /playground\s*[:=]\s*true/i.test(gqlWin);
            var disabledInProd = /disablePlaygroundInProduction\s*[:=]\s*true/i.test(gqlWin);
            if (playgroundOn || !disabledInProd) {
              add("MEDIUM", "GraphQL playground not disabled", gqlIdx + 1,
                "The GraphQL config at line " + (gqlIdx + 1) + " does not disable the GraphQL playground in production. A live playground hands attackers an interactive map of your whole API schema.",
                "Add graphQL: { disablePlaygroundInProduction: true } at line " + (gqlIdx + 1) + " so the playground is off in production.");
            }
          }

          /* Rate limiting */
          if (!/rateLimit/i.test(text)) {
            add("MEDIUM", "Rate limiting missing", null,
              "No rateLimit config appears anywhere in the pasted text. Without rate limiting, login and API endpoints can be hammered by brute-force and scraping traffic.",
              "Add a rateLimit config to the Payload config, e.g. rateLimit: { max: 100, window: 900000 }, tuned to your real traffic.");
          }

          /* Upload limits */
          var upIdx = findKeyLine(lines, /upload/i);
          if (upIdx === -1) {
            add("MEDIUM", "Upload limits missing", null,
              "No upload config appears anywhere in the pasted text, so uploaded file sizes fall back to defaults you have not chosen or reviewed.",
              "Add an upload config with explicit limits, e.g. upload: { limits: { fileSize: 5000000 } } (5 MB), sized to what your users actually need.");
          } else {
            var upWin = blockWindow(lines, upIdx, 10);
            var fsMatch = upWin.match(/fileSize\s*[:=]\s*(\d+)/);
            if (/Infinity|unlimited/i.test(upWin)) {
              add("MEDIUM", "Upload limit unlimited", upIdx + 1,
                "The upload config at line " + (upIdx + 1) + " leaves file size unlimited. One huge upload can fill the disk and take the server down.",
                "Set a concrete fileSize limit at line " + (upIdx + 1) + ", e.g. upload: { limits: { fileSize: 5000000 } }.");
            } else if (fsMatch) {
              var size = parseInt(fsMatch[1], 10);
              if (size > UPLOAD_MAX_BYTES) {
                add("MEDIUM", "Upload limit excessively large", upIdx + 1,
                  "The upload fileSize limit at line " + (upIdx + 1) + " is " + size + " bytes (about " + Math.round(size / 1000000) + " MB), far beyond what content uploads normally need, and it invites disk-filling abuse.",
                  "Lower the fileSize limit at line " + (upIdx + 1) + " to the largest file your users genuinely need — 5 MB (5000000) covers most images and documents.");
              }
            } else {
              add("MEDIUM", "Upload limits missing", upIdx + 1,
                "An upload config exists at line " + (upIdx + 1) + " but no fileSize limit was found in it, so upload sizes are effectively unbounded by your config.",
                "Add limits inside the upload config at line " + (upIdx + 1) + ", e.g. limits: { fileSize: 5000000 }.");
            }
          }

          findings.sort(function (a, b) {
            var la = a.line === null ? 100000 : a.line;
            var lb = b.line === null ? 100000 : b.line;
            return la - lb;
          });

          var counts = countFindings(findings);
          var verdict;
          if (counts.CRITICAL > 0) verdict = "DO NOT DEPLOY";
          else if (findings.length > 0) verdict = "DEPLOY WITH FIXES";
          else verdict = "SAFE TO DEPLOY";
          return { verdict: verdict, findings: findings, counts: counts, signals: signals };
        }

        function countFindings(findings) {
          var c = { CRITICAL: 0, HIGH: 0, MEDIUM: 0, LOW: 0, total: findings.length };
          for (var i = 0; i < findings.length; i++) { if (c[findings[i].severity] !== undefined) c[findings[i].severity]++; }
          return c;
        }

        /* ---------- Report / JSON (never contain secret values) ---------- */
        function buildReport(result) {
          var out = [];
          out.push("J-Dawgs Payload CMS Server Config Safety Auditor - Audit Report");
          out.push("Verdict: " + result.verdict);
          out.push("Findings: " + result.counts.total + " total (Critical: " + result.counts.CRITICAL + ", High: " + result.counts.HIGH + ", Medium: " + result.counts.MEDIUM + ", Low: " + result.counts.LOW + ")");
          out.push("");
          if (result.findings.length === 0) {
            out.push("No findings.");
          } else {
            for (var i = 0; i < result.findings.length; i++) {
              var f = result.findings[i];
              out.push((i + 1) + ". [" + f.severity + "] " + f.check + " - " + (f.line === null ? "Not present in pasted text" : "Line " + f.line));
              out.push("   " + f.message);
              out.push("   Fix: " + f.fix);
            }
          }
          out.push("");
          out.push("Generated offline in the browser. Secret values are never included in this report - secrets are referenced only by key name, line number, and value length.");
          return out.join("\n");
        }
        function buildJSON(result) {
          var obj = {
            tool: "J-Dawgs Payload CMS Server Config Safety Auditor",
            verdict: result.verdict,
            counts: { critical: result.counts.CRITICAL, high: result.counts.HIGH, medium: result.counts.MEDIUM, low: result.counts.LOW, total: result.counts.total },
            findings: result.findings.map(function (f) {
              return { line: f.line, severity: f.severity, check: f.check, message: f.message, fix: f.fix };
            })
          };
          return JSON.stringify(obj, null, 2);
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-payload-cms-server-config-safety-auditortm',
  name: 'J-Dawgs Payload CMS Server Config Safety Auditor',
  description: 'Grades a pasted Payload CMS config/env offline into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
