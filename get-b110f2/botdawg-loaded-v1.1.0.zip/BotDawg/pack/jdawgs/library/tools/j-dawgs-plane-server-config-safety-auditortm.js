'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Plane Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Built-in worked examples ---------- */

      var RISKY_EXAMPLE = [
        "# Plane server — set up in a hurry, not yet hardened",
        "WEB_URL=http://plane.example.com",
        "SECRET_KEY=example-short",
        "DATABASE_URL=postgres://plane:hunter2pw@db.example.com:5432/plane",
        "REDIS_URL=redis://:redispass99@redis.example.com:6379/0",
        "CORS_ALLOWED_ORIGINS=*",
        "DEBUG=1",
        "ENABLE_SIGNUP=true"
      ].join("\n");

      var HARDENED_EXAMPLE = [
        "# Plane server — hardened",
        "WEB_URL=https://plane.example.com",
        "CORS_ALLOWED_ORIGINS=https://plane.example.com",
        "SECRET_KEY=${SECRET_KEY}",
        "DATABASE_URL=${DATABASE_URL}",
        "REDIS_URL=${REDIS_URL}",
        "EMAIL_HOST_PASSWORD=${EMAIL_HOST_PASSWORD}",
        "DEBUG=0",
        "ENABLE_SIGNUP=false",
        "DISABLE_WORKSPACE_CREATION=true"
      ].join("\n");

      /* ---------- Recognized Plane keys ---------- */

      var RECOGNIZED = {};
      [
        "SECRET_KEY","DJANGO_SECRET_KEY",
        "DATABASE_URL","PGDATABASE_URL","PGPASSWORD","PGHOST","PGDATABASE","PGUSER","PGPORT",
        "REDIS_URL","REDIS_HOST","REDIS_PORT",
        "WEB_URL","APP_BASE_URL","CORS_ALLOWED_ORIGINS",
        "DEBUG","DJANGO_DEBUG",
        "ENABLE_SIGNUP","DISABLE_WORKSPACE_CREATION",
        "EMAIL_HOST","EMAIL_HOST_USER","EMAIL_HOST_PASSWORD","EMAIL_PORT","EMAIL_USE_TLS","EMAIL_FROM",
        "SMTP_HOST","SMTP_USER","SMTP_PASSWORD","SMTP_PORT",
        "AWS_ACCESS_KEY_ID","AWS_SECRET_ACCESS_KEY","AWS_REGION","AWS_S3_BUCKET_NAME","AWS_S3_ENDPOINT_URL",
        "MINIO_ROOT_USER","MINIO_ROOT_PASSWORD","MINIO_ACCESS_KEY","MINIO_SECRET_KEY","MINIO_ENDPOINT",
        "FILE_SIZE_LIMIT","GUNICORN_WORKERS","SENTRY_DSN"
      ].forEach(function(k){ RECOGNIZED[k] = true; });

      function baseKey(key){
        return key.replace(/_FILE$/, "");
      }
      function isRecognized(key){
        return !!RECOGNIZED[baseKey(key)];
      }

      /* ---------- Value helpers (values are measured, never printed) ---------- */

      function isReference(value){
        return value.indexOf("${") !== -1;
      }
      function isTruthy(value){
        return /^(1|true|yes|on)$/i.test(value.trim());
      }
      function isFalsy(value){
        return /^(0|false|no|off)$/i.test(value.trim());
      }
      function unquote(value){
        if (value.length >= 2){
          var first = value.charAt(0), last = value.charAt(value.length - 1);
          if ((first === '"' && last === '"') || (first === "'" && last === "'")){
            return value.slice(1, -1);
          }
        }
        return value;
      }
      // Returns the password embedded in a URL, or null. Used for length only.
      function urlPassword(value){
        var m = value.match(/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\/([^/?#]*)/);
        if (!m) return null;
        var authority = m[1];
        var at = authority.lastIndexOf("@");
        if (at < 0) return null;
        var userinfo = authority.slice(0, at);
        var colon = userinfo.indexOf(":");
        if (colon < 0) return null;
        var pw = userinfo.slice(colon + 1);
        try { pw = decodeURIComponent(pw); } catch (e) { /* keep raw length */ }
        return pw;
      }
      function urlHost(value){
        var m = value.match(/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\/([^/?#:]+)/);
        return m ? m[1].toLowerCase() : null;
      }
      function urlScheme(value){
        var m = value.match(/^([a-zA-Z][a-zA-Z0-9+.-]*):\/\//);
        return m ? m[1].toLowerCase() : null;
      }
      function isLocalHost(host){
        return host === "localhost" || host === "127.0.0.1" || host === "::1" ||
               (host !== null && /\.local$/.test(host));
      }

      /* ---------- Parser ----------
         Accepts KEY=value, "export KEY=value", YAML-ish "KEY: value",
         and docker-compose list items "- KEY=value" / "- KEY".
         Lines that fit none of these are NOT PARSED: reported by line
         number only (their contents are never echoed) and excluded. */

      function parseConfig(text){
        var entries = [];      // every parsed setting, in order
        var notParsed = [];    // line numbers only
        var lines = String(text).split(/\r?\n/);
        for (var i = 0; i < lines.length; i++){
          var lineNo = i + 1;
          var t = lines[i].trim();
          if (t === "" || t.charAt(0) === "#") continue;
          if (t.indexOf("- ") === 0) t = t.slice(2).trim();       // compose list item
          if (/^export\s+/.test(t)) t = t.replace(/^export\s+/, "");
          if (/^[A-Za-z0-9_.\/-]+:\s*$/.test(t)) continue;        // YAML structure line, e.g. "environment:"
          var m = t.match(/^([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/);
          if (!m) m = t.match(/^([A-Za-z_][A-Za-z0-9_]*)\s*:\s+(.+)$/);
          if (!m){
            var bare = t.match(/^([A-Za-z_][A-Za-z0-9_]*)$/);     // "- KEY" pass-through in compose
            if (bare){
              entries.push({ key: bare[1], value: "", bare: true, line: lineNo });
              continue;
            }
            notParsed.push(lineNo);
            continue;
          }
          entries.push({ key: m[1], value: unquote(m[2].trim()), bare: false, line: lineNo });
        }
        // Last occurrence wins.
        var effective = {};
        var order = [];
        entries.forEach(function(e){
          if (!effective[e.key]) order.push(e.key);
          effective[e.key] = e;
        });
        return { entries: entries, notParsed: notParsed, effective: effective, order: order };
      }

      /* ---------- Auditor ---------- */

      var SEV_RANK = { BLOCKER: 0, HIGH: 1, WARNING: 2, INFO: 3 };

      function audit(text){
        var parsed = parseConfig(text);
        var eff = parsed.effective;
        var findings = [];
        function add(severity, line, key, message, fix, valueLength){
          var f = { severity: severity, line: line, key: key, message: message, fix: fix };
          if (typeof valueLength === "number") f.valueLength = valueLength;
          findings.push(f);
        }

        // Not-parsed lines: by line number only, contents never shown.
        parsed.notParsed.forEach(function(lineNo){
          add("INFO", lineNo, "(unparsed line)",
            "This line is not in KEY=value form, so it was not parsed and none of its contents were checked.",
            "Rewrite the line as KEY=value (or KEY: value) and run the audit again so this setting gets graded too.");
        });

        // Duplicates: last wins, both line numbers named.
        var seen = {};
        parsed.entries.forEach(function(e){
          if (!seen[e.key]) seen[e.key] = [];
          seen[e.key].push(e.line);
        });
        Object.keys(seen).forEach(function(key){
          var ls = seen[key];
          if (ls.length > 1){
            add("INFO", ls[ls.length - 1], key,
              "This key is set " + ls.length + " times (lines " + ls.join(", ") + "). The last one — line " +
                ls[ls.length - 1] + " — is the one that takes effect, and it is the one graded here.",
              "Delete the earlier duplicate line(s) so the config says one thing in one place.");
          }
        });

        // Recognized-key count drives NOT ENOUGH TO GRADE.
        var recognizedCount = 0;
        parsed.order.forEach(function(key){ if (isRecognized(key)) recognizedCount++; });

        // Production signals: any URL-ish setting pointing at a real (non-local) host.
        var productionSignals = false;
        ["WEB_URL","APP_BASE_URL","DATABASE_URL","PGDATABASE_URL","REDIS_URL"].forEach(function(k){
          var e = eff[k];
          if (e){
            var h = urlHost(e.value);
            if (h && !isLocalHost(h)) productionSignals = true;
          }
        });
        var corsEntry = eff["CORS_ALLOWED_ORIGINS"];
        if (corsEntry){
          corsEntry.value.split(",").forEach(function(origin){
            var h = urlHost(origin.trim());
            if (h && !isLocalHost(h)) productionSignals = true;
          });
        }

        /* SECRET_KEY / DJANGO_SECRET_KEY */
        var secretEntry = eff["SECRET_KEY"] || eff["DJANGO_SECRET_KEY"];
        var secretFileEntry = eff["SECRET_KEY_FILE"] || eff["DJANGO_SECRET_KEY_FILE"];
        if (!secretEntry && !secretFileEntry){
          if (recognizedCount >= 3){
            add("BLOCKER", null, "SECRET_KEY",
              "No SECRET_KEY (or DJANGO_SECRET_KEY) is set anywhere in this configuration. Plane cannot sign sessions safely without one.",
              "Set SECRET_KEY to a fresh random value of at least 32 characters — 50 or more is better — and load it from an environment reference or a *_FILE secret rather than pasting it in plaintext.");
          }
        } else if (secretFileEntry && !secretEntry){
          add("INFO", secretFileEntry.line, secretFileEntry.key,
            "The Django secret key is supplied through a *_FILE secret reference, not pasted in plaintext. Treated as safe.",
            "No change needed — keep loading it from the secret file.");
        } else {
          var sv = secretEntry.value;
          if (secretEntry.bare){
            add("INFO", secretEntry.line, secretEntry.key,
              "The secret key is passed through from the environment at deploy time rather than pasted here. Treated as safe.",
              "No change needed — just make sure the value on the host is long and random.");
          } else if (isReference(sv)){
            add("INFO", secretEntry.line, secretEntry.key,
              "The secret key is supplied as a ${…} reference, not pasted in plaintext. Treated as safe.",
              "No change needed — keep the real value in your secret store, at 32 characters or more.");
          } else if (sv === ""){
            add("BLOCKER", secretEntry.line, secretEntry.key,
              "SECRET_KEY is present but empty. An empty secret key signs nothing.",
              "Set SECRET_KEY to a fresh random value of at least 32 characters, loaded from an environment reference or a *_FILE secret.",
              0);
          } else {
            var reasons = [];
            if (sv.length < 32) reasons.push("it is only " + sv.length + " characters long (32 is the minimum)");
            var badWords = ["example","changeme","change_me","change-me","default","insecure"];
            var lower = sv.toLowerCase();
            for (var b = 0; b < badWords.length; b++){
              if (lower.indexOf(badWords[b]) !== -1){
                reasons.push("it contains a placeholder word (\"example\", \"changeme\", \"default\", or \"insecure\")");
                break;
              }
            }
            if (reasons.length){
              add("BLOCKER", secretEntry.line, secretEntry.key,
                "The Django secret key is not safe to deploy: " + reasons.join(", and ") + ". Anyone who guesses it can forge sessions.",
                "Generate a fresh random secret of 50+ characters and load it from an environment reference or a *_FILE secret instead of pasting it in plaintext.",
                sv.length);
            } else {
              add("INFO", secretEntry.line, secretEntry.key,
                "The secret key is " + sv.length + " characters long with no placeholder words. That clears the length bar.",
                "Even so, a reference or *_FILE secret is safer than plaintext in a config file — consider moving it.",
                sv.length);
            }
          }
        }

        /* DATABASE_URL / PGDATABASE_URL */
        ["DATABASE_URL","PGDATABASE_URL"].forEach(function(k){
          var e = eff[k];
          if (!e || e.bare || isReference(e.value) || e.value === "") return;
          var pw = urlPassword(e.value);
          if (pw !== null && pw !== "" && !isReference(pw)){
            if (pw.length < 12){
              add("BLOCKER", e.line, k,
                "This database address carries a plaintext password of only " + pw.length +
                  " characters — plaintext in the file, and under the 12-character floor, so this finding rates BLOCKER (the plaintext exposure alone would rate HIGH). The password itself is never shown here.",
                "Move the database password into a secret reference or *_FILE secret, and make it 12 characters or longer — then rotate it, because the old one has been sitting in plaintext.",
                pw.length);
            } else {
              add("HIGH", e.line, k,
                "This database address carries a plaintext password (" + pw.length +
                  " characters) typed right into the URL. Anyone who can read this file has the database password. The password itself is never shown here.",
                "Move the database password into a secret reference or *_FILE secret, and rotate it — it has been sitting in plaintext.",
                pw.length);
            }
          }
        });

        /* PGPASSWORD */
        (function(){
          var e = eff["PGPASSWORD"];
          if (!e || e.bare || isReference(e.value) || e.value === "") return;
          add("HIGH", e.line, "PGPASSWORD",
            "The Postgres password is pasted in plaintext (" + e.value.length + " characters). The value itself is never shown here.",
            "Load PGPASSWORD from a secret reference or *_FILE secret, and rotate it — it has been sitting in plaintext.",
            e.value.length);
        })();

        /* REDIS_URL */
        (function(){
          var e = eff["REDIS_URL"];
          if (!e || e.bare || isReference(e.value) || e.value === "") return;
          var pw = urlPassword(e.value);
          if (pw !== null && pw !== "" && !isReference(pw)){
            add("HIGH", e.line, "REDIS_URL",
              "This Redis address carries a plaintext password (" + pw.length +
                " characters) typed right into the URL. The password itself is never shown here.",
              "Move the Redis password into a secret reference or *_FILE secret, and rotate it — it has been sitting in plaintext.",
              pw.length);
          }
        })();

        /* WEB_URL / APP_BASE_URL */
        ["WEB_URL","APP_BASE_URL"].forEach(function(k){
          var e = eff[k];
          if (!e || e.bare || e.value === "") return;
          var v = e.value;
          var scheme = urlScheme(v);
          var host = urlHost(v);
          if (!scheme || !host){
            add("INFO", e.line, k,
              "This value does not look like a full http(s) address, so its transport safety could not be graded.",
              "Set it to the full public address of the Plane server, starting with https://.");
            return;
          }
          if (scheme === "http" && !isLocalHost(host)){
            add("HIGH", e.line, k,
              "This address uses plain http:// on a public host (" + host + "). Logins and session cookies cross the network unencrypted.",
              "Put the server behind https:// (a reverse proxy with a real certificate) and update this address to the https:// one.");
          } else if (isLocalHost(host) && productionSignals){
            add("WARNING", e.line, k,
              "This address points at localhost, but other settings in this config point at real production hosts. Links Plane generates (invites, password resets) would send people to their own machine.",
              "Set this to the real public https:// address of the Plane server.");
          } else if (isLocalHost(host)){
            add("INFO", e.line, k,
              "This address points at localhost. Fine for a local test; a deployed server needs its real public address here.",
              "Before deploying, set this to the public https:// address of the Plane server.");
          }
        });

        /* CORS_ALLOWED_ORIGINS */
        (function(){
          var e = eff["CORS_ALLOWED_ORIGINS"];
          if (!e || e.bare || e.value === "") return;
          var origins = e.value.split(",").map(function(s){ return s.trim(); }).filter(function(s){ return s !== ""; });
          origins.forEach(function(origin){
            if (origin === "*"){
              add("HIGH", e.line, "CORS_ALLOWED_ORIGINS",
                "CORS is set to \"*\" — any website on the internet is allowed to talk to this Plane server as your logged-in users.",
                "Replace \"*\" with the one real origin of your Plane web app, e.g. the same https:// address as WEB_URL.");
              return;
            }
            var scheme = urlScheme(origin), host = urlHost(origin);
            if (scheme === "http" && host && !isLocalHost(host)){
              add("HIGH", e.line, "CORS_ALLOWED_ORIGINS",
                "One CORS origin (" + host + ") uses plain http://, so a downgraded page can be trusted by the API.",
                "Use the https:// origin for the Plane web app here.");
            } else if (host && isLocalHost(host) && productionSignals){
              add("WARNING", e.line, "CORS_ALLOWED_ORIGINS",
                "One CORS origin points at localhost while other settings look like production. The real web app would be blocked, and a local page would be trusted.",
                "Replace the localhost origin with the real public https:// origin of the Plane web app.");
            }
          });
        })();

        /* DEBUG / DJANGO_DEBUG */
        ["DEBUG","DJANGO_DEBUG"].forEach(function(k){
          var e = eff[k];
          if (!e || e.bare) return;
          if (isTruthy(e.value)){
            add("HIGH", e.line, k,
              "Debug mode is ON. Debug error pages can hand out stack traces, settings, and pieces of secrets to anyone who triggers an error.",
              "Set " + k + "=0 (or false) before this server faces anyone but you.");
          }
        });

        /* Signup / workspace-creation posture */
        (function(){
          var e = eff["ENABLE_SIGNUP"];
          if (e && !e.bare && isTruthy(e.value)){
            add("WARNING", e.line, "ENABLE_SIGNUP",
              "Open signup is ON. Anyone who finds this server's address can create an account on it.",
              "If this server is for a known team, set ENABLE_SIGNUP=false and invite people instead.");
          }
          var d = eff["DISABLE_WORKSPACE_CREATION"];
          if (d && !d.bare && isFalsy(d.value)){
            add("WARNING", d.line, "DISABLE_WORKSPACE_CREATION",
              "Workspace creation is open: every signed-up user can spin up their own workspace on your server.",
              "If this server hosts one team, set DISABLE_WORKSPACE_CREATION=true so only admins create workspaces.");
          }
        })();

        /* Mail + storage secret keys, plaintext: by name and length only */
        [
          { key: "EMAIL_HOST_PASSWORD", label: "The email (SMTP) account password" },
          { key: "SMTP_PASSWORD", label: "The SMTP account password" },
          { key: "AWS_SECRET_ACCESS_KEY", label: "An AWS secret access key" },
          { key: "MINIO_SECRET_KEY", label: "A MinIO secret key" },
          { key: "MINIO_ROOT_PASSWORD", label: "The MinIO root password" }
        ].forEach(function(item){
          var e = eff[item.key];
          if (!e || e.bare) return;
          if (!e.value || isReference(e.value)) return;
          add("HIGH", e.line, item.key,
            item.label + " is pasted in plaintext (" + e.value.length + " characters). The value itself is never shown here.",
            "Load it from a secret reference or a " + item.key + "_FILE secret instead, and rotate it — it has been sitting in plaintext.",
            e.value.length);
        });
        // *_FILE variants of those keys are safe by design.
        Object.keys(eff).forEach(function(k){
          if (/_FILE$/.test(k) && isRecognized(k)){
            var already = findings.some(function(f){ return f.key === k; });
            if (!already){
              add("INFO", eff[k].line, k,
                "This secret is supplied through a *_FILE secret reference, not pasted in plaintext. Treated as safe.",
                "No change needed — keep loading it from the secret file.");
            }
          }
        });

        /* Verdict */
        findings.sort(function(a, b){
          var r = SEV_RANK[a.severity] - SEV_RANK[b.severity];
          if (r !== 0) return r;
          var la = a.line === null ? 0 : a.line;
          var lb = b.line === null ? 0 : b.line;
          return la - lb;
        });
        var counts = { BLOCKER: 0, HIGH: 0, WARNING: 0, INFO: 0 };
        findings.forEach(function(f){ counts[f.severity]++; });

        var verdict, verdictClass;
        if (recognizedCount < 3){
          verdict = "NOT ENOUGH TO GRADE";
          verdictClass = "unknown";
        } else if (counts.BLOCKER > 0){
          verdict = "DO NOT DEPLOY";
          verdictClass = "no";
        } else if (counts.HIGH > 0 || counts.WARNING > 0){
          verdict = "DEPLOY WITH FIXES";
          verdictClass = "fixes";
        } else {
          verdict = "SAFE TO DEPLOY";
          verdictClass = "safe";
        }

        return {
          verdict: verdict,
          verdictClass: verdictClass,
          findings: findings,
          counts: counts,
          recognizedKeys: recognizedCount,
          parsedSettings: parsed.entries.length,
          linesNotParsed: parsed.notParsed.length
        };
      }

      /* ---------- Report + JSON builders (built from findings only —
           secret values can never get in, because findings never hold them) ---------- */

      function findingLine(f){
        var loc = f.line === null ? "Not present" : "Line " + f.line;
        var s = "[" + f.severity + "] " + loc + " · " + f.key + " — " + f.message;
        if (typeof f.valueLength === "number") s += " (value length: " + f.valueLength + " characters)";
        return s + "\n  Fix: " + f.fix;
      }
      function findingsText(result){
        return result.findings.map(findingLine).join("\n");
      }
      function buildReport(result){
        var out = [];
        out.push("J-Dawgs Plane Server Config Safety Auditor™ — audit report");
        out.push("Verdict: " + result.verdict);
        out.push("Recognized Plane keys: " + result.recognizedKeys +
                 " · Settings parsed: " + result.parsedSettings +
                 " · Lines not parsed: " + result.linesNotParsed);
        out.push("Findings: " + result.counts.BLOCKER + " BLOCKER · " + result.counts.HIGH +
                 " HIGH · " + result.counts.WARNING + " WARNING · " + result.counts.INFO + " INFO");
        out.push("");
        out.push("FINDINGS");
        if (result.findings.length === 0) out.push("(none)");
        result.findings.forEach(function(f){ out.push(findingLine(f)); });
        out.push("");
        out.push("Graded offline from pasted text only. This tool never connects to a server.");
        out.push("Secret values are never shown in this report — findings name the key, the line, and the value length only.");
        return out.join("\n");
      }
      function buildJSON(result){
        var obj = {
          tool: "J-Dawgs Plane Server Config Safety Auditor™",
          verdict: result.verdict,
          recognizedKeys: result.recognizedKeys,
          parsedSettings: result.parsedSettings,
          linesNotParsed: result.linesNotParsed,
          counts: result.counts,
          findings: result.findings.map(function(f){
            var o = {
              severity: f.severity,
              line: f.line,
              key: f.key,
              message: f.message,
              fix: f.fix
            };
            if (typeof f.valueLength === "number") o.valueLength = f.valueLength;
            return o;
          }),
          note: "Secret values are never included — findings carry the key name, line, and value length only."
        };
        return JSON.stringify(obj, null, 2);
      }

      /* ---------- Rendering ---------- */

      function esc(s){
        return String(s).replace(/[&<>"']/g, function(c){
          return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
        });
      }

      var lastResult = null;
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined), "RISKY_EXAMPLE": (typeof RISKY_EXAMPLE !== 'undefined' ? RISKY_EXAMPLE : undefined), "HARDENED_EXAMPLE": (typeof HARDENED_EXAMPLE !== 'undefined' ? HARDENED_EXAMPLE : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-plane-server-config-safety-auditortm',
  name: 'J-Dawgs Plane Server Config Safety Auditor',
  description: 'Grades a pasted Plane server config offline into one deploy verdict, secrets by key name/line/length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: { "RISKY_EXAMPLE": __core["RISKY_EXAMPLE"], "HARDENED_EXAMPLE": __core["HARDENED_EXAMPLE"] }
};
