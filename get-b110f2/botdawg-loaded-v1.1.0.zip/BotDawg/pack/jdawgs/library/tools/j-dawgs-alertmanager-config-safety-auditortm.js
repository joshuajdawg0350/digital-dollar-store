'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Alertmanager Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var RISKY_LINES = [
          '# RISKY alertmanager.yml - do not deploy',
          'global:',
          "  smtp_smarthost: 'smtp.example.com:587'",
          "  smtp_from: 'alerts@example.com'",
          "  smtp_auth_username: 'alerts@example.com'",
          "  smtp_auth_password: 'PlainSmtpPass123!'",
          "  slack_api_url: 'http://hooks.slack.com/services/FAKE'",
          'route:',
          "  group_by: ['...']",
          '  group_wait: 5s',
          '  group_interval: 10s',
          '  repeat_interval: 720h',
          "  receiver: 'missing-oncall'",
          '  routes:',
          '    - match:',
          '        severity: critical',
          "      receiver: 'team-email'",
          '    - match:',
          '        severity: critical',
          "      receiver: 'team-email'",
          'receivers:',
          "  - name: 'team-email'",
          '    email_configs:',
          "      - to: 'team@example.com'",
          "  - name: 'empty-hook'",
          "  - name: 'insecure-hook'",
          '    webhook_configs:',
          "      - url: 'http://hooks.example.com/alert'",
          '        send_resolved: true',
          "  - name: 'pd-hook'",
          '    pagerduty_configs:',
          "      - routing_key: 'pd-fake-key-abcdef123456'",
          'inhibit_rules:',
          '  - source_match:',
          "      severity: 'critical'",
          '    target_match:',
          "      severity: 'warning'",
          "    equal: ['alertname']"
        ];

        var HARDENED_LINES = [
          'global:',
          "  smtp_smarthost: 'smtp.example.com:587'",
          "  smtp_from: 'alerts@example.com'",
          "  smtp_auth_username: 'alerts@example.com'",
          "  smtp_auth_password_file: '/run/secrets/smtp_password'",
          "  slack_api_url_file: '/run/secrets/slack_url'",
          'route:',
          "  group_by: ['alertname', 'cluster']",
          '  group_wait: 30s',
          '  group_interval: 5m',
          '  repeat_interval: 4h',
          "  receiver: 'team-email'",
          '  routes:',
          '    - match:',
          '        severity: critical',
          "      receiver: 'pd-hook'",
          'receivers:',
          "  - name: 'team-email'",
          '    email_configs:',
          "      - to: 'team@example.com'",
          "  - name: 'pd-hook'",
          '    pagerduty_configs:',
          "      - routing_key_file: '/run/secrets/pd_key'",
          '        send_resolved: true',
          '    webhook_configs:',
          "      - url: 'https://hooks.example.com/alert'",
          '        send_resolved: true',
          'inhibit_rules:',
          '  - source_match:',
          "      severity: 'critical'",
          '    target_match:',
          "      severity: 'warning'",
          "    equal: ['alertname']"
        ];

        var SEV_ORDER = { CRITICAL: 0, WARNING: 1, INFO: 2 };
        var SECRET_KEYS = {
          smtp_auth_password: true, api_key: true, routing_key: true,
          service_key: true, integration_key: true, auth_token: true,
          access_token: true, client_secret: true, password: true, token: true
        };

        function indentOf(line) {
          var m = line.match(/^[ ]*/);
          return m ? m[0].length : 0;
        }
        function isBlankOrComment(line) {
          var t = line.replace(/^\s+/, "");
          return t === "" || t.charAt(0) === "#";
        }
        function keyOf(line) {
          var m = line.match(/^\s*(-\s+)?([A-Za-z_][A-Za-z0-9_-]*)\s*:\s?(.*)$/);
          if (!m) return null;
          return { dash: !!m[1], key: m[2], value: m[3] || "" };
        }
        function cleanValue(v) {
          v = (v == null ? "" : String(v)).replace(/^\s+|\s+$/g, "");
          if (v.charAt(0) === "'") {
            var e = v.indexOf("'", 1);
            return e === -1 ? v.slice(1) : v.slice(1, e);
          }
          if (v.charAt(0) === '"') {
            var e2 = v.indexOf('"', 1);
            return e2 === -1 ? v.slice(1) : v.slice(1, e2);
          }
          var h = v.indexOf(" #");
          if (h !== -1) v = v.slice(0, h);
          return v.replace(/\s+$/g, "");
        }
        function isExemptSecret(val) {
          if (!val) return true;
          if (val.indexOf("${") !== -1 || val.indexOf("$(") !== -1) return true;
          if (val.indexOf("_file") !== -1) return true;
          var low = val.toLowerCase();
          if (low.indexOf("redacted") !== -1) return true;
          if (low.indexOf("change_me") !== -1 || low.indexOf("changeme") !== -1) return true;
          if (low.indexOf("placeholder") !== -1) return true;
          if (low === "example") return true;
          return false;
        }
        var DUR_FACTORS = { ms: 0.001, s: 1, m: 60, h: 3600, d: 86400, w: 604800, y: 31536000 };
        function fmtNum(n) {
          return Number(n).toLocaleString("en-US");
        }
        function parseDuration(rawStr) {
          var s = cleanValue(rawStr).replace(/\s+/g, "");
          if (!s) return null;
          var re = /(\d+(?:\.\d+)?)(ms|s|m|h|d|w|y)/g;
          var parts = [], total = 0, consumed = "", m;
          while ((m = re.exec(s)) !== null) {
            var n = parseFloat(m[1]);
            parts.push({ n: n, unit: m[2], text: m[0] });
            total += n * DUR_FACTORS[m[2]];
            consumed += m[0];
          }
          if (parts.length === 0 || consumed !== s) return null;
          var expr;
          if (parts.length === 1) {
            expr = parts[0].text + " = " + parts[0].n + " × " + DUR_FACTORS[parts[0].unit] + " = " + fmtNum(total) + "s";
          } else {
            expr = cleanValue(rawStr) + " = " + parts.map(function (p) {
              return "(" + p.n + " × " + DUR_FACTORS[p.unit] + ")";
            }).join(" + ") + " = " + fmtNum(total) + "s";
          }
          return { seconds: total, expr: expr };
        }
        function schemeHost(url) {
          var m = String(url).match(/^https?:\/\/[^\/'"\s]+/i);
          return m ? m[0] : "the URL on this line";
        }

        function auditConfig(text) {
          var raw = typeof text === "string" ? text : "";
          var lines = raw.split(/\r?\n/);
          var nonEmpty = lines.filter(function (l) { return l.trim().length > 0; });
          var result = {
            verdict: "NOT ENOUGH TO GRADE",
            linesAudited: 0,
            counts: { CRITICAL: 0, WARNING: 0, INFO: 0 },
            findings: []
          };
          if (raw.trim().length === 0 || nonEmpty.length < 3 || raw.trim().length < 20) {
            return result;
          }
          var recognizable = /(^|\n)\s*(global|route|routes|receivers|inhibit_rules|receiver|group_by|group_wait|group_interval|repeat_interval|smtp_smarthost|smtp_from|slack_api_url|email_configs|webhook_configs|pagerduty_configs|slack_configs|mute_time_intervals|templates?)\s*:/.test(raw);
          if (!recognizable) {
            return result;
          }
          result.linesAudited = lines.length;

          var findings = [];
          function add(sev, cat, line, title, expl, fix, extra) {
            var f = { severity: sev, category: cat, line: line, title: title, explanation: expl, fix: fix };
            if (extra) { for (var k in extra) { f[k] = extra[k]; } }
            findings.push(f);
          }

          var i, j;

          /* ---- NOT PARSED detection (explicit YAML shapes this reader cannot follow) ---- */
          for (i = 0; i < lines.length; i++) {
            var ln = lines[i];
            if (isBlankOrComment(ln)) continue;
            var kind = null, kindTitle = null;
            if (/^[ \t]*\t/.test(ln)) { kind = "tab"; kindTitle = "Tab indentation — NOT PARSED / NOT AUDITED"; }
            else if (/^\s*-?\s*<<\s*:/.test(ln)) { kind = "merge"; kindTitle = "YAML merge key — NOT PARSED / NOT AUDITED"; }
            else if (/:\s*[&*][A-Za-z0-9_-]+/.test(ln) || /^\s*-\s+[&*][A-Za-z0-9_-]+/.test(ln)) { kind = "anchor"; kindTitle = "YAML anchor or alias — NOT PARSED / NOT AUDITED"; }
            else if (/:\s*[|>][+-]?\d*\s*$/.test(ln.replace(/\s+$/, ""))) { kind = "block"; kindTitle = "Multi-line block scalar — NOT PARSED / NOT AUDITED"; }
            if (kind) {
              add("INFO", "Not Parsed", i + 1, kindTitle,
                "This line uses a YAML feature (" + (kind === "tab" ? "tab indentation" : kind === "merge" ? "a merge key (<<:)" : kind === "anchor" ? "an anchor or alias (& / *)" : "a block scalar (| or >)") + ") that this subset reader cannot follow, so anything this line would have contributed to grading was NOT PARSED / NOT AUDITED rather than guessed. The rest of the file was audited normally.",
                "If this line matters to the grade, rewrite it in plain expanded YAML (spaces for indentation, values written out in full, no anchors or block scalars) and audit again — and still run amtool check-config on the target host.");
            }
          }

          /* ---- Section map (top-level keys at indent 0) ---- */
          var sections = []; // {name, startIdx, endIdx} endIdx exclusive
          for (i = 0; i < lines.length; i++) {
            if (indentOf(lines[i]) === 0 && !isBlankOrComment(lines[i])) {
              var kk = keyOf(lines[i]);
              if (kk) sections.push({ name: kk.key, start: i, end: lines.length });
            }
          }
          for (i = 0; i < sections.length - 1; i++) sections[i].end = sections[i + 1].start;
          function section(name) {
            for (var s = 0; s < sections.length; s++) if (sections[s].name === name) return sections[s];
            return null;
          }

          /* ---- Global section facts ---- */
          var gSec = section("global");
          var hasGlobal = !!gSec;
          var hasSmarthost = false;
          var slackLine = 0, slackValue = "";
          if (gSec) {
            for (i = gSec.start + 1; i < gSec.end; i++) {
              var gk = keyOf(lines[i]);
              if (!gk) continue;
              if (gk.key === "smtp_smarthost") hasSmarthost = true;
              if (gk.key === "slack_api_url") { slackLine = i + 1; slackValue = cleanValue(gk.value); }
            }
          }

          /* ---- Receivers ---- */
          var receiverNames = {}; // name -> true
          var receiverEntries = []; // {name, nameLine, start, end}
          var hasEmailConfigs = false, firstEmailLine = 0;
          var rSec = section("receivers");
          if (rSec) {
            var entryStarts = [];
            var entryIndent = -1;
            for (i = rSec.start + 1; i < rSec.end; i++) {
              if (isBlankOrComment(lines[i])) continue;
              if (/^\s*-\s/.test(lines[i])) {
                var ind = indentOf(lines[i]);
                if (entryIndent === -1) entryIndent = ind;
                if (ind === entryIndent) entryStarts.push(i);
              }
            }
            for (j = 0; j < entryStarts.length; j++) {
              var st = entryStarts[j];
              var en = (j + 1 < entryStarts.length) ? entryStarts[j + 1] : rSec.end;
              var nm = "", nmLine = st + 1, hasContent = false, curConfig = "";
              for (var b = st; b < en; b++) {
                var bk = keyOf(lines[b]);
                if (!bk) continue;
                if (bk.key === "name" && !nm) { nm = cleanValue(bk.value); nmLine = b + 1; continue; }
                hasContent = true;
                if (/_configs$/.test(bk.key)) {
                  curConfig = bk.key;
                  if (bk.key === "email_configs") { hasEmailConfigs = true; if (!firstEmailLine) firstEmailLine = b + 1; }
                }
                if (bk.key === "url" && curConfig === "webhook_configs") {
                  var uval = cleanValue(bk.value);
                  if (/^http:\/\//i.test(uval)) {
                    add("WARNING", "Receivers", b + 1,
                      "Webhook uses http:// (not https)",
                      "This webhook_configs URL uses plain http (" + schemeHost(uval) + " — scheme and host only are shown, never a full URL), so alert payloads, which can carry sensitive detail, cross the network unencrypted and can be tampered with in transit.",
                      "Point the webhook at an https:// endpoint. If the receiver truly cannot do TLS, put it behind a TLS-terminating proxy instead of sending alerts in the clear.");
                  }
                }
              }
              if (nm) { receiverNames[nm] = true; }
              receiverEntries.push({ name: nm, nameLine: nmLine, hasContent: hasContent });
            }
          }
          receiverEntries.forEach(function (re) {
            if (re.name && !re.hasContent) {
              add("CRITICAL", "Receivers", re.nameLine,
                "Empty receiver — no delivery configs",
                "Receiver '" + re.name + "' is named but has no delivery configs at all — no email_configs, webhook_configs, pagerduty_configs, slack_configs, or any other *_configs block under it. Alerts routed to '" + re.name + "' are silently dropped.",
                "Add at least one delivery config under '" + re.name + "' (for example email_configs or webhook_configs), or remove the receiver and route its alerts somewhere that can actually deliver.");
            }
          });

          /* ---- Route tree ---- */
          var rtSec = section("route");
          var rootReceiver = null, rootReceiverLine = 0;
          var rootGroupBy = null, rootGroupWait = null, rootGroupInterval = null, rootRepeat = null;
          var childRoutes = []; // {receiverName, receiverLine, sig, dashLine}
          if (rtSec) {
            var routesIdx = -1;
            for (i = rtSec.start + 1; i < rtSec.end; i++) {
              var rk0 = keyOf(lines[i]);
              if (rk0 && rk0.key === "routes") { routesIdx = i; break; }
            }
            var rootEnd = routesIdx === -1 ? rtSec.end : routesIdx;
            for (i = rtSec.start + 1; i < rootEnd; i++) {
              var rk = keyOf(lines[i]);
              if (!rk || rk.dash) continue;
              if (rk.key === "receiver" && !rootReceiver) { rootReceiver = cleanValue(rk.value); rootReceiverLine = i + 1; }
              else if (rk.key === "group_by" && !rootGroupBy) rootGroupBy = { value: rk.value, line: i + 1 };
              else if (rk.key === "group_wait" && !rootGroupWait) rootGroupWait = { value: rk.value, line: i + 1 };
              else if (rk.key === "group_interval" && !rootGroupInterval) rootGroupInterval = { value: rk.value, line: i + 1 };
              else if (rk.key === "repeat_interval" && !rootRepeat) rootRepeat = { value: rk.value, line: i + 1 };
            }
            if (!rootReceiver) {
              add("CRITICAL", "Routing", rtSec.start + 1,
                "Root route has no receiver",
                "The top-level route: sets no receiver: of its own before its nested routes:. Any alert that matches no child route lands on a root route with nowhere to go — Alertmanager will not accept a route tree whose root cannot deliver.",
                "Give the root route a default receiver (for example receiver: 'team-email') that is defined under receivers:, so unmatched alerts always have a destination.");
            } else if (!receiverNames[rootReceiver]) {
              add("CRITICAL", "Routing", rootReceiverLine,
                "Route references undefined receiver",
                "The root route sends alerts to receiver '" + rootReceiver + "', but no receiver with that name is defined under receivers:. Alertmanager would refuse this config and, until it is fixed, those alerts have no destination.",
                "Define a receiver named '" + rootReceiver + "' under receivers:, or change the root route's receiver: to a name that is defined there.");
            }

            if (routesIdx !== -1) {
              var childStarts = [], childIndent = -1;
              for (i = routesIdx + 1; i < rtSec.end; i++) {
                if (isBlankOrComment(lines[i])) continue;
                if (/^\s*-\s/.test(lines[i])) {
                  var ci = indentOf(lines[i]);
                  if (childIndent === -1) childIndent = ci;
                  if (ci === childIndent) childStarts.push(i);
                }
              }
              for (j = 0; j < childStarts.length; j++) {
                var cs = childStarts[j];
                var ce = (j + 1 < childStarts.length) ? childStarts[j + 1] : rtSec.end;
                var cRecv = "", cRecvLine = cs + 1, sig = "";
                var matchIdx = -1, matchKey = "", matchVal = "";
                for (var c = cs; c < ce; c++) {
                  var ck = keyOf(lines[c]);
                  if (!ck) continue;
                  if (ck.key === "receiver" && !cRecv) { cRecv = cleanValue(ck.value); cRecvLine = c + 1; }
                  if ((ck.key === "match" || ck.key === "matchers" || ck.key === "match_re" || ck.key === "matchers_re") && matchIdx === -1) {
                    matchIdx = c; matchKey = ck.key; matchVal = ck.value;
                  }
                }
                if (matchIdx !== -1) {
                  var parts = [];
                  var mkIndent = indentOf(lines[matchIdx]);
                  if (cleanValue(matchVal)) parts.push(cleanValue(matchVal));
                  for (var d = matchIdx + 1; d < ce; d++) {
                    if (isBlankOrComment(lines[d])) continue;
                    if (indentOf(lines[d]) > mkIndent) parts.push(lines[d].replace(/^\s+|\s+$/g, ""));
                    else break;
                  }
                  sig = matchKey + "|" + parts.join(";");
                }
                childRoutes.push({ receiverName: cRecv, receiverLine: cRecvLine, sig: sig, dashLine: cs + 1 });
              }
              childRoutes.forEach(function (cr) {
                if (cr.receiverName && !receiverNames[cr.receiverName]) {
                  add("CRITICAL", "Routing", cr.receiverLine,
                    "Route references undefined receiver",
                    "A child route sends alerts to receiver '" + cr.receiverName + "', but no receiver with that name is defined under receivers:. Alerts matching that route have no destination.",
                    "Define a receiver named '" + cr.receiverName + "' under receivers:, or change this child route's receiver: to a name that is defined there.");
                }
              });
              var seenSig = {};
              childRoutes.forEach(function (cr, idx) {
                if (!cr.sig) return;
                if (seenSig.hasOwnProperty(cr.sig)) {
                  add("WARNING", "Routing", cr.receiverLine,
                    "Possibly unreachable child route (heuristic)",
                    "Heuristic only: this child route's matcher set is identical to an earlier child route's matcher set. Alertmanager evaluates child routes in order and, unless the earlier route sets continue: true, the first match wins — so this later route looks unreachable. This reader does not simulate the full route tree, so treat this as a prompt to check, not a proof.",
                    "If this route is meant to fire, give it a distinct matcher set or set continue: true on the earlier matching route. If it is a leftover duplicate, delete it.");
                } else {
                  seenSig[cr.sig] = idx;
                }
              });
            }

            /* group_by on the root route */
            if (rootGroupBy) {
              var gbRaw = rootGroupBy.value.replace(/^\s+|\s+$/g, "");
              var gbEmpty = /^\[\s*\]$/.test(gbRaw);
              var gbDots = gbRaw.indexOf("...") !== -1;
              if (gbEmpty || gbDots) {
                add("WARNING", "Routing", rootGroupBy.line,
                  "group_by disables or empties grouping",
                  gbDots
                    ? "group_by is ['...'] — the '...' entry tells Alertmanager to group on every label at once, which in practice disables useful grouping: almost every alert becomes its own group and pages multiply."
                    : "group_by is an empty list [], so alerts are not grouped by any label — every alert notifies on its own and pages multiply.",
                  "Group on a small, deliberate label set, for example group_by: ['alertname', 'cluster'], so related alerts arrive as one notification.");
              }
            }

            /* Timing on the root route */
            var gw = rootGroupWait ? parseDuration(rootGroupWait.value) : null;
            var gi = rootGroupInterval ? parseDuration(rootGroupInterval.value) : null;
            var ri = rootRepeat ? parseDuration(rootRepeat.value) : null;
            if (rootGroupWait && gw && gw.seconds < 10) {
              add("WARNING", "Timing", rootGroupWait.line,
                "group_wait too short — alerts fire before grouping settles",
                "group_wait is " + gw.expr + ". With less than 10s to wait, the first notification fires before related alerts have had a chance to arrive and group together, so one incident arrives as several separate pages.",
                "Raise group_wait to at least 10s — 30s is a common production value — so a burst of related alerts groups into one notification.");
            }
            if (rootGroupInterval && gi && gw && gi.seconds < gw.seconds) {
              add("WARNING", "Timing", rootGroupInterval.line,
                "group_interval shorter than group_wait",
                "group_interval is " + gi.expr + ", but group_wait is " + gw.expr + ". The interval between repeat notifications for a changed group should never be shorter than the initial wait — the ordering makes notification timing unpredictable.",
                "Set group_interval to at least group_wait, and typically much longer (5m is a common production value).");
            }
            if (rootGroupInterval && gi && gi.seconds < 60) {
              add("WARNING", "Timing", rootGroupInterval.line,
                "group_interval very short — notification spam risk",
                "group_interval is " + gi.expr + ". While a group keeps changing, Alertmanager can re-notify this often — under 60s turns one long incident into a stream of near-identical notifications and trains people to ignore the channel.",
                "Raise group_interval to at least 60s; 5m is a common production value.");
            }
            if (rootRepeat && ri) {
              if (ri.seconds > 86400) {
                add("CRITICAL", "Timing", rootRepeat.line,
                  "repeat_interval so long re-pages effectively never happen",
                  "repeat_interval is " + ri.expr + ". That is the arithmetic: once an alert group has been notified, Alertmanager waits that long before reminding anyone it is still firing. At over 24h (86400s), a firing alert that nobody acknowledged effectively never re-pages — it fires once and goes quiet.",
                  "Set repeat_interval to something operationally sane — commonly 4h to 12h, and never above 24h (86400s) — so a still-firing alert keeps reminding the on-call.");
              } else if (ri.seconds > 43200) {
                add("WARNING", "Timing", rootRepeat.line,
                  "repeat_interval longer than 12 hours",
                  "repeat_interval is " + ri.expr + ". That is between 12h (43200s) and 24h (86400s): a still-firing alert re-pages at most about once or twice a day, which is easy to sleep through and forget.",
                  "Bring repeat_interval down to 12h or less — 4h is a common production value — unless a once-a-day reminder is genuinely the intent.");
              }
            }
            if (!rootRepeat) {
              add("INFO", "Timing", rtSec.start + 1,
                "No repeat_interval on root route — Alertmanager default applies",
                "The root route sets no repeat_interval, so Alertmanager's built-in default decides how often a still-firing alert group re-notifies. That may be fine, but it should be a choice, not an accident.",
                "Set repeat_interval explicitly on the root route (4h is a common production value) so the re-page cadence is deliberate.");
            }
          }

          /* ---- Secrets (key name + line ONLY; value never rendered, never measured) ---- */
          var secretRe = /^\s*-?\s*(smtp_auth_password|api_key|routing_key|service_key|integration_key|auth_token|access_token|client_secret|password|token)\s*:\s*(.*)$/;
          for (i = 0; i < lines.length; i++) {
            if (isBlankOrComment(lines[i])) continue;
            var sm = lines[i].match(secretRe);
            if (!sm) continue;
            var sKey = sm[1];
            if (/_file$/.test(sKey)) continue;
            var sVal = cleanValue(sm[2]);
            if (isExemptSecret(sVal)) continue;
            add("CRITICAL", "Secrets", i + 1,
              "Plaintext secret in config key \"" + sKey + "\"",
              "Key \"" + sKey + "\" on this line is set to a literal secret value written directly in the config. Secret values are never shown in this audit — this finding reports only the key name and the line number. Anyone who can read this file (a backup, a screenshot, a leaked repo) already has the secret.",
              "Move the secret out of the config: use the *_file variant for this key where the receiver supports one (for example " + sKey + "_file) pointing at a restricted secrets file, or substitute the value from the environment at deploy time — and rotate the exposed secret, treating it as compromised.",
              { key: sKey, redacted: true });
          }

          /* ---- Inhibit rules ---- */
          var iSec = section("inhibit_rules");
          if (iSec) {
            var iStarts = [], iIndent = -1;
            for (i = iSec.start + 1; i < iSec.end; i++) {
              if (isBlankOrComment(lines[i])) continue;
              if (/^\s*-\s/.test(lines[i]) || /^\s*-\s*$/.test(lines[i])) {
                var ii = indentOf(lines[i]);
                if (iIndent === -1) iIndent = ii;
                if (ii === iIndent) iStarts.push(i);
              }
            }
            for (j = 0; j < iStarts.length; j++) {
              var ist = iStarts[j];
              var ien = (j + 1 < iStarts.length) ? iStarts[j + 1] : iSec.end;
              var hasSource = false, hasTarget = false, hasEqual = false;
              for (var ib = ist; ib < ien; ib++) {
                var ik = keyOf(lines[ib]);
                if (!ik) continue;
                if (ik.key === "source_match" || ik.key === "source_matchers") hasSource = true;
                if (ik.key === "target_match" || ik.key === "target_matchers") hasTarget = true;
                if (ik.key === "equal") hasEqual = true;
              }
              if (!hasSource) {
                add("CRITICAL", "Inhibit Rules", ist + 1,
                  "Inhibit rule missing source matcher — can never fire as intended",
                  "This inhibit_rules entry sets no source_match or source_matchers, so there is no definition of the alert that is supposed to do the inhibiting. The rule can never fire as intended, and Alertmanager may reject the config outright.",
                  "Add a source_match (or source_matchers) block to this rule describing the higher-severity alert that should inhibit the target.");
              }
              if (!hasTarget) {
                add("CRITICAL", "Inhibit Rules", ist + 1,
                  "Inhibit rule missing target matcher — can never fire as intended",
                  "This inhibit_rules entry sets no target_match or target_matchers, so there is no definition of the alert that is supposed to be silenced. The rule can never fire as intended, and Alertmanager may reject the config outright.",
                  "Add a target_match (or target_matchers) block to this rule describing the lower-severity alert that should be inhibited.");
              }
              if (!hasEqual) {
                add("INFO", "Inhibit Rules", ist + 1,
                  "Inhibit rule has no equal list",
                  "This inhibit_rules entry sets no equal: list, so the source alert inhibits the target only when every label matches — usually narrower than intended. That may be deliberate, but it should be a choice.",
                  "Add an equal: list (commonly equal: ['alertname']) naming the labels that must match for inhibition to apply.");
              }
            }
          }

          /* ---- Global posture ---- */
          if (!hasGlobal) {
            add("INFO", "Global", 1,
              "No global section — no shared SMTP/Slack defaults",
              "There is no top-level global: section, so there are no shared SMTP or Slack defaults for receivers to inherit. Receivers that rely on those defaults will be missing settings Alertmanager expects.",
              "Add a global: section with the shared defaults you rely on — smtp_smarthost and smtp_from for email, slack_api_url_file for Slack — or set the equivalents on each receiver.");
          } else {
            if (hasEmailConfigs && !hasSmarthost) {
              add("WARNING", "Global", firstEmailLine || 1,
                "Email receivers but no global smtp_smarthost",
                "The config defines email receivers (email_configs) but the global: section sets no smtp_smarthost, so Alertmanager has no default mail server to send alert email through.",
                "Set smtp_smarthost in the global: section (for example smtp_smarthost: 'smtp.example.com:587'), or set a smarthost on each email config that needs one.");
            }
            if (slackLine && /^http:\/\//i.test(slackValue)) {
              add("WARNING", "Global", slackLine,
                "Global slack_api_url uses http:// (not https)",
                "The global slack_api_url uses plain http (" + schemeHost(slackValue) + " — scheme and host only are shown, never the full URL, because a Slack webhook URL is itself a credential). Alert payloads cross the network unencrypted, and anyone who captures the URL can post to the channel.",
                "Use the https:// Slack webhook URL, and preferably load it with slack_api_url_file from a restricted secrets file instead of writing it into the config.");
            }
          }

          findings.sort(function (a, b) {
            if (SEV_ORDER[a.severity] !== SEV_ORDER[b.severity]) return SEV_ORDER[a.severity] - SEV_ORDER[b.severity];
            return a.line - b.line;
          });

          result.findings = findings;
          findings.forEach(function (f) { result.counts[f.severity]++; });
          if (result.counts.CRITICAL > 0) result.verdict = "DO NOT DEPLOY";
          else if (result.counts.WARNING > 0) result.verdict = "DEPLOY WITH FIXES";
          else result.verdict = "SAFE TO DEPLOY";
          return result;
        }

        function buildReport(r) {
          var out = [];
          out.push("J-Dawgs Alertmanager Config Safety Auditor - Audit Report");
          out.push("Verdict: " + r.verdict);
          out.push("Lines audited: " + r.linesAudited);
          out.push("Findings: " + r.counts.CRITICAL + " critical, " + r.counts.WARNING + " warning, " + r.counts.INFO + " info");
          out.push("");
          if (r.verdict === "NOT ENOUGH TO GRADE") {
            out.push("Not enough to grade: the pasted text was empty, shorter than 3 non-empty lines or 20 characters, or contained no recognizable alertmanager.yml keys (global / route / receivers / inhibit_rules). Nothing was graded, so all counts are zero — paste a real alertmanager.yml and audit again.");
          } else if (r.findings.length === 0) {
            out.push("No findings. No critical, warning, or info items were detected by the heuristic checks.");
          } else {
            r.findings.forEach(function (f, n) {
              out.push((n + 1) + ". [" + f.severity + "] Line " + f.line + " - " + f.category + ": " + f.title);
              out.push("   " + f.explanation);
              out.push("   Fix: " + f.fix);
              if (f.key) out.push("   Secret detail (redacted): key=" + f.key + ", line=" + f.line + ". Value never rendered.");
              out.push("");
            });
          }
          out.push("Note: heuristic subset-YAML text audit only - not a full YAML parser and not amtool; no live server was contacted. Secret values are never rendered anywhere in this audit: secret findings show only the key name and line number. Still run amtool check-config on the target host.");
          return out.join("\n");
        }

        function buildJson(r) {
          var obj = {
            tool: "J-Dawgs Alertmanager Config Safety Auditor",
            verdict: r.verdict,
            linesAudited: r.linesAudited,
            counts: { critical: r.counts.CRITICAL, warning: r.counts.WARNING, info: r.counts.INFO },
            redaction: "Secret values are never included. Secret findings carry the key name and line number only.",
            findings: r.findings.map(function (f) {
              var o = {
                severity: f.severity,
                category: f.category,
                line: f.line,
                title: f.title,
                explanation: f.explanation,
                fix: f.fix
              };
              if (f.key) { o.key = f.key; o.valueRedacted = true; }
              return o;
            })
          };
          return JSON.stringify(obj, null, 2);
        }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-alertmanager-config-safety-auditortm',
  name: 'J-Dawgs Alertmanager Config Safety Auditor',
  description: 'amtool/startup only answer will-it-load; ours grades a pasted alertmanager.yml anywhere — routing, receiver, secret, and timing posture — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
