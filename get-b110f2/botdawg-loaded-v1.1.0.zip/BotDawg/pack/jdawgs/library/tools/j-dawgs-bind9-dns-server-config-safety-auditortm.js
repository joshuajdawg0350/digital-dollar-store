'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs BIND9 DNS Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Built-in examples (one array entry per line, so the
         line numbers in the findings are exactly the lines you see) --- */
      var RISKY = [
        '// Risky example — recursion and zone transfers wide open.',
        'options {',
        '    directory "/var/cache/bind";',
        '    recursion yes;',
        '    allow-query { any; };',
        '    version "9.18.24";',
        '    listen-on { any; };',
        '};',
        '',
        'key "tsig-transfer-key" {',
        '    algorithm hmac-sha256;',
        '    secret "kX9Qm2ZXRISKYEXAMPLESECRET7f3aBcDeFgHiJkLmNoPqRsTuVwXyZ0123456789+/==";',
        '};',
        '',
        'zone "example.com" {',
        '    type master;',
        '    file "/var/lib/bind/db.example.com";',
        '    allow-transfer { any; };',
        '    allow-update { any; };',
        '};',
        '',
        'zone "example.com" {',
        '    type master;',
        '    file "/var/lib/bind/db.example.com.copy";',
        '};',
        '',
        'zone "internal.example.org" {',
        '    type master;',
        '    file "/var/lib/bind/db.internal";',
        '};',
        '',
        'include "/etc/bind/named.conf.local";'
      ].join("\n");

      var HARDENED = [
        '// Hardened example — authoritative-only, everything restricted.',
        'acl "trusted-clients" {',
        '    localhost;',
        '    192.168.10.0/24;',
        '};',
        '',
        'options {',
        '    directory "/var/cache/bind";',
        '    recursion no;',
        '    allow-query { localhost; 192.168.10.0/24; };',
        '    allow-transfer { none; };',
        '    version none;',
        '    dnssec-validation auto;',
        '    listen-on { 127.0.0.1; 192.168.10.2; };',
        '};',
        '',
        'zone "example.com" {',
        '    type primary;',
        '    file "/var/lib/bind/db.example.com";',
        '    allow-transfer { 192.168.10.3; };',
        '    allow-update { none; };',
        '};'
      ].join("\n");

      /* ---------- Known statement / directive names ------------------ */
      function setOf(list){ var o={}; for (var i=0;i<list.length;i++) o[list[i]]=1; return o; }

      var TOP_KNOWN = setOf(["options","controls","zone","key","acl","view","server",
        "logging","include","trusted-keys","managed-keys","dnssec-policy",
        "statistics-channels","http","plugin","masters","dlz","dyndb","lwres"]);

      var OPTIONS_KNOWN = setOf(["allow-new-zones","allow-notify","allow-query",
        "allow-query-cache","allow-query-cache-on","allow-recursion","allow-recursion-on",
        "allow-transfer","allow-update","allow-update-forwarding","also-notify",
        "also-notify-port","alt-transfer-source","answer-cookie","attach-cache",
        "auth-nxdomain","auto-dnssec","avoid-v4-udp-ports","avoid-v6-udp-ports",
        "bindkeys-file","blackhole","cache-file","catalog-zones","check-dup-records",
        "check-integrity","check-mx","check-mx-cname","check-names","check-sibling",
        "check-spf","check-srv-cname","check-wildcard","clients-per-query",
        "cookie-always","coresize","datasize","deallocate-on-exit",
        "deny-answer-addresses","deny-answer-aliases","directory",
        "disable-algorithms","disable-ds-digests","disable-empty-zone","dns64",
        "dnskey-sig-validity","dnsrps-enable","dnssec-accept-expired",
        "dnssec-dnskey-kskonly","dnssec-enable","dnssec-loadkeys-interval",
        "dnssec-lookaside","dnssec-must-be-secure","dnssec-policy",
        "dnssec-secure-to-insecure","dnssec-update-mode","dnssec-validation",
        "dnstap","dnstap-identity","dnstap-output","dnstap-verbosity","dnstap-version",
        "dump-db","dump-file","edns-udp-size","empty-contact","empty-server",
        "empty-zones-enable","fetch-glue","fetches-per-server","fetches-per-zone",
        "filter-aaaa","filter-aaaa-on-v4","filter-aaaa-on-v6",
        "flush-zones-on-shutdown","forward","forwarders","glue-cache",
        "heartbeat-interval","hostname","initial-working-directory",
        "interface-interval","ipv4only","keep-response-order","key-directory",
        "lame-ttl","listen-on","listen-on-v6","lmdb-mapsize","managed-keys-directory",
        "masterfile-format","masterfile-style","masters","match-mapped-addresses",
        "max-cache-size","max-cache-ttl","max-clients-per-query","max-journal-size",
        "max-ncache-ttl","max-recursion-depth","max-recursion-queries",
        "max-refresh-time","max-retry-time","max-stale-ttl","max-transfer-idle-in",
        "max-transfer-idle-out","max-transfer-time-in","max-transfer-time-out",
        "max-zone-ttl","memstatistics","memstatistics-file","message-compression",
        "min-cache-ttl","min-refresh-time","min-retry-time","min-roots",
        "minimal-any","minimal-responses","new-zones-directory","no-case-compress",
        "nocookie-udp-size","notify","notify-delay","notify-source","notify-source-v6",
        "notify-to-soa","nta-lifetime","nta-recheck","nxdomain-redirect","pid-file",
        "port","preferred-glue","prefetch","provide-ixfr","purge-keys",
        "qname-minimization","query-source","query-source-v6","querylog",
        "random-device","rate-limit","recursion","request-ixfr",
        "require-server-cookie","resolver-nonbackoff-tries","resolver-query-timeout",
        "resolver-retry-interval","response-cookie","response-padding",
        "response-policy","root-delegation-only","root-key-sentinel","rrset-order",
        "send-cookie","serial-query-rate","serial-update-method","server-id",
        "servfail-ttl","session-keyalg","session-keyfile","session-keyname",
        "sig-validity-interval","sortlist","stacksize","stale-answer-client-timeout",
        "stale-answer-enable","stale-answer-ttl","statistics-file",
        "suppress-initial-notify","synth-from-dns64","tcp-advertised-timeout",
        "tcp-clients","tcp-idle-timeout","tcp-initial-timeout",
        "tcp-keepalive-timeout","tcp-listen-queue","tcp-only","tcp-receive-buffer",
        "tcp-send-buffer","tkey-dhkey","tkey-domain","tkey-gssapi-credential",
        "tkey-gssapi-keytab","transfer-format","transfer-message-size",
        "transfer-source","transfer-source-v6","transfers-in","transfers-out",
        "transfers-per-ns","trust-anchor-file","update-check-ksk",
        "use-alt-transfer-source","use-v4-udp-ports","use-v6-udp-ports","v6-bias",
        "version","zone-statistics","zero-no-soa-ttl"]);

      var VIEW_EXTRA = setOf(["match-clients","match-destinations","match-recursive-only"]);

      var ZONE_KNOWN = setOf(["allow-notify","allow-query","allow-transfer",
        "allow-update","also-notify","also-notify-port","auto-dnssec",
        "check-dup-records","check-integrity","check-mx","check-names",
        "check-sibling","check-spf","check-wildcard","database","delegation-only",
        "dialup","dlz","dnssec-dnskey-kskonly","dnssec-loadkeys-interval",
        "dnssec-policy","dnssec-secure-to-insecure","dnssec-update-mode","file",
        "forward","forwarders","in-view","inline-signing","ixfr-from-differences",
        "journal","key-directory","masters","masterfile-format","masterfile-style",
        "max-journal-size","notify","notify-source","notify-source-v6","primaries",
        "serial-update-method","server-addresses","server-names",
        "sig-signing-nodes","sig-signing-signatures","sig-signing-type",
        "sig-validity-interval","type","update-policy","zone-statistics"]);

      var KEY_KNOWN = setOf(["algorithm","secret"]);

      /* ---------- Tokenizer ------------------------------------------ */
      function tokenize(text){
        var tokens = [], i = 0, line = 1, n = text.length;
        function isSpace(c){ return c===" "||c==="\t"||c==="\r"||c==="\f"||c==="\v"; }
        while (i < n){
          var c = text[i];
          if (c === "\n"){ line++; i++; continue; }
          if (isSpace(c)){ i++; continue; }
          if (c === "#"){ while (i<n && text[i]!=="\n") i++; continue; }
          if (c === "/" && text[i+1] === "/"){ while (i<n && text[i]!=="\n") i++; continue; }
          if (c === "/" && text[i+1] === "*"){
            i += 2;
            while (i<n && !(text[i]==="*" && text[i+1]==="/")){ if (text[i]==="\n") line++; i++; }
            i += 2; continue;
          }
          if (c==="{" || c==="}" || c===";"){ tokens.push({t:c, v:c, line:line}); i++; continue; }
          if (c === '"'){
            var s = '"', sl = line; i++;
            while (i<n && text[i] !== '"'){ if (text[i]==="\n") line++; s += text[i]; i++; }
            if (i<n){ s += '"'; i++; }
            tokens.push({t:"w", v:s, line:sl}); continue;
          }
          var st = line, w = "";
          while (i < n){
            var ch = text[i];
            if (ch==="\n" || isSpace(ch) || ch==="{" || ch==="}" || ch===";" || ch==='"' || ch==="#") break;
            if (ch==="/" && (text[i+1]==="/" || text[i+1]==="*")) break;
            w += ch; i++;
          }
          if (w === ""){ i++; continue; }
          tokens.push({t:"w", v:w, line:st});
        }
        return tokens;
      }

      /* ---------- Parser: statements as {head, body, line} trees ------ */
      function parseAll(tokens){
        var issues = [];   // {line} — lines with syntax this parser cannot settle
        var pos = { i: 0 };
        function parseNodes(top){
          var nodes = [];
          while (pos.i < tokens.length){
            var tk = tokens[pos.i];
            if (tk.t === "}"){
              pos.i++;
              if (top){ issues.push({line: tk.line}); continue; }
              return { nodes: nodes, closed: true };
            }
            if (tk.t === ";"){ pos.i++; continue; }
            if (tk.t === "{"){ issues.push({line: tk.line}); pos.i++; continue; }
            var node = { head: [], body: null, line: tk.line, malformed: false };
            var done = false;
            while (pos.i < tokens.length){
              var t2 = tokens[pos.i];
              if (t2.t === "w"){ node.head.push(t2); pos.i++; }
              else if (t2.t === "{"){
                pos.i++;
                var inner = parseNodes(false);
                node.body = inner.nodes;
                if (!inner.closed){ node.malformed = true; issues.push({line: node.line}); }
                if (pos.i < tokens.length && tokens[pos.i].t === ";") pos.i++;
                done = true; break;
              }
              else if (t2.t === ";"){ pos.i++; done = true; break; }
              else if (t2.t === "}"){
                node.malformed = true; issues.push({line: node.line});
                done = true; break;
              }
            }
            if (!done){ node.malformed = true; issues.push({line: node.line}); }
            nodes.push(node);
          }
          return { nodes: nodes, closed: false };
        }
        var res = parseNodes(true);
        return { nodes: res.nodes, issues: issues };
      }

      /* ---------- Small helpers --------------------------------------- */
      function unq(s){
        if (s && s.length >= 2 && s.charAt(0) === '"' && s.charAt(s.length-1) === '"')
          return s.slice(1, -1);
        return s;
      }
      function headVals(node){ var out=[]; for (var i=0;i<node.head.length;i++) out.push(node.head[i].v); return out; }
      function dirObj(node){
        var hv = headVals(node);
        var d = { name: (hv[0]||"").toLowerCase(), line: node.line,
                  vals: [], aml: null };
        for (var i=1;i<hv.length;i++) d.vals.push(unq(hv[i]));
        if (node.body){
          d.aml = [];
          for (var j=0;j<node.body.length;j++){
            var parts = [];
            for (var k=0;k<node.body[j].head.length;k++) parts.push(unq(node.body[j].head[k].v));
            d.aml.push(parts.join(" "));
          }
        }
        return d;
      }
      function amlHas(d, word){
        if (!d) return false;
        var i, s;
        if (d.aml){
          for (i=0;i<d.aml.length;i++){ s = d.aml[i].trim().toLowerCase(); if (s === word || s === "*") return word === "any" ? (s==="any"||s==="*") : s===word; }
          return false;
        }
        for (i=0;i<d.vals.length;i++){ if (d.vals[i].toLowerCase() === word) return true; }
        return false;
      }
      function lastDir(list, name){
        var found = null;
        for (var i=0;i<list.length;i++) if (list[i].name === name) found = list[i];
        return found;
      }
      function scalarVal(d){ return (d && d.vals.length) ? d.vals[0].toLowerCase() : null; }

      /* ---------- Semantic walk --------------------------------------- */
      function collect(nodes){
        var data = {
          optionDirs: [], viewDirs: [], zones: [], keys: [], includes: [],
          secrets: [], notParsedLines: {}, optionsLine: null
        };
        function markNotParsed(line){ data.notParsedLines[line] = 1; }

        function processDirs(blockNode, known, out){
          if (!blockNode.body) return;
          for (var i=0;i<blockNode.body.length;i++){
            var child = blockNode.body[i];
            if (child.malformed) continue;
            var hv = headVals(child);
            var nm = (hv[0]||"").toLowerCase();
            if (!known[nm]){ markNotParsed(child.line); continue; }
            out.push(dirObj(child));
          }
        }
        function processZone(node){
          var hv = headVals(node);
          var zone = { name: unq(hv[1] || "(unnamed)"), line: node.line, dirs: [] };
          processDirs(node, ZONE_KNOWN, zone.dirs);
          data.zones.push(zone);
        }
        function walkTop(list){
          for (var i=0;i<list.length;i++){
            var node = list[i];
            if (node.malformed) continue;
            var hv = headVals(node);
            var kw = (hv[0]||"").toLowerCase();
            if (kw === "options"){
              if (data.optionsLine === null) data.optionsLine = node.line;
              processDirs(node, OPTIONS_KNOWN, data.optionDirs);
            } else if (kw === "view"){
              if (node.body){
                for (var j=0;j<node.body.length;j++){
                  var ch = node.body[j];
                  if (ch.malformed) continue;
                  var chv = headVals(ch);
                  var cnm = (chv[0]||"").toLowerCase();
                  if (cnm === "zone") processZone(ch);
                  else if (cnm === "include") data.includes.push({ file: unq(chv[1]||""), line: ch.line });
                  else if (OPTIONS_KNOWN[cnm] || VIEW_EXTRA[cnm]) data.viewDirs.push(dirObj(ch));
                  else markNotParsed(ch.line);
                }
              }
            } else if (kw === "zone"){
              processZone(node);
            } else if (kw === "key"){
              data.keys.push({ name: unq(hv[1]||""), line: node.line });
              if (node.body){
                for (var k=0;k<node.body.length;k++){
                  var kc = node.body[k];
                  if (kc.malformed) continue;
                  var knm = (headVals(kc)[0]||"").toLowerCase();
                  if (!KEY_KNOWN[knm]) markNotParsed(kc.line);
                }
              }
            } else if (kw === "include"){
              data.includes.push({ file: unq(hv[1]||""), line: node.line });
            } else if (TOP_KNOWN[kw]){
              /* acl, controls, server, logging, and friends: parsed, accepted. */
            } else {
              markNotParsed(node.line);
            }
          }
        }
        function scanSecrets(list, keyName){
          for (var i=0;i<list.length;i++){
            var nd = list[i];
            var hv = headVals(nd);
            var nm = (hv[0]||"").toLowerCase();
            var ctx = keyName;
            if (nm === "key") ctx = unq(hv[1]||"");
            if ((nm === "secret" || nm === "password") && !nd.malformed){
              data.secrets.push({ keyName: keyName || "", directive: nm, line: nd.line });
            }
            if (nd.body) scanSecrets(nd.body, ctx);
          }
        }
        walkTop(nodes);
        scanSecrets(nodes, "");
        return data;
      }

      /* ---------- The audit ------------------------------------------- */
      function audit(text){
        var parsed = parseAll(tokenize(text));
        var data = collect(parsed.nodes);
        var i;
        for (i=0;i<parsed.issues.length;i++) data.notParsedLines[parsed.issues[i].line] = 1;

        var findings = [];
        function add(sev, line, title, fix, chip){
          findings.push({ sev: sev, line: line, title: title, fix: fix, chip: chip || sev });
        }

        var optLine = (data.optionsLine !== null) ? data.optionsLine : 1;
        function findOpt(name){
          return lastDir(data.optionDirs, name) || lastDir(data.viewDirs, name);
        }

        /* Secrets — name and line only, value never read into output. */
        for (i=0;i<data.secrets.length;i++){
          var sec = data.secrets[i];
          add("INFO", sec.line,
            "Secret stored in this file — " +
              (sec.keyName ? "key \u201C" + sec.keyName + "\u201D, " : "") +
              "reported by name and line only; the value is never shown.",
            "Keep key material out of shared copies of named.conf, restrict this file\u2019s permissions to the DNS service account, and rotate this key if the file has ever been pasted, emailed, or committed anywhere.",
            "SECRET");
        }

        /* Recursion / open resolver. */
        var recDir = findOpt("recursion");
        var recVal = scalarVal(recDir); /* "yes" | "no" | null */
        var aqDir = findOpt("allow-query");
        var arDir = findOpt("allow-recursion");
        if (recVal === "no"){
          if (arDir && amlHas(arDir, "any")){
            add("WARNING", arDir.line,
              "Contradictory recursion settings: recursion is off, but allow-recursion { any; } is still set.",
              "Remove the allow-recursion line, or set both deliberately — as written, the intent is unclear and a future edit could quietly re-open recursion.");
          }
        } else {
          var effDir = arDir || aqDir;
          var effName = arDir ? "allow-recursion" : "allow-query";
          if (!effDir){
            add("BLOCKER", recDir ? recDir.line : optLine,
              "Open resolver: recursion is " + (recVal === "yes" ? "on" : "not disabled") +
                " and no allow-query or allow-recursion restriction limits who may use it — anyone on the internet can make this server resolve for them.",
              "Restrict allow-query (and allow-recursion) to your own networks — for example localhost and your LAN ranges — or set recursion no on an authoritative-only server.");
          } else if (amlHas(effDir, "any")){
            add("BLOCKER", effDir.line,
              "Open resolver: recursion is on and " + effName + " { any; } lets any client in the world use this server recursively — the classic DNS amplification setup.",
              "Replace any; in " + effName + " with only the networks you intend to serve (localhost and your own address ranges), or set recursion no if this server is authoritative-only.");
          } else {
            add("INFO", effDir.line,
              "Recursion is on and limited by " + effName + " to a restricted list — not an open resolver.",
              "Confirm that list is exactly the clients you intend to serve, and nothing wider.");
          }
          if (!recDir){
            add("INFO", optLine,
              "recursion is not set explicitly in the pasted text.",
              "Set recursion yes or no deliberately — the posture you get by default depends on the BIND version and the surrounding statements.");
          }
        }

        /* Zone transfers. */
        var gtDir = lastDir(data.optionDirs, "allow-transfer") || lastDir(data.viewDirs, "allow-transfer");
        if (gtDir && amlHas(gtDir, "any")){
          add("BLOCKER", gtDir.line,
            "Zone transfers open to anyone: allow-transfer { any; } in the global options lets any host download every zone this server holds.",
            "Restrict the global allow-transfer to your secondary servers\u2019 addresses only, or set allow-transfer { none; }; and open transfers per zone where a secondary needs them.");
        }
        function isPrimary(zone){
          var t = scalarVal(lastDir(zone.dirs, "type"));
          if (t === "master" || t === "primary") return true;
          if (t) return false;
          return !!lastDir(zone.dirs, "file") && !lastDir(zone.dirs, "masters") && !lastDir(zone.dirs, "primaries");
        }
        for (i=0;i<data.zones.length;i++){
          var z = data.zones[i];
          var zt = lastDir(z.dirs, "allow-transfer");
          if (zt){
            if (amlHas(zt, "any")){
              add("BLOCKER", zt.line,
                "Zone transfers open to anyone for zone \u201C" + z.name + "\u201D: allow-transfer { any; } lets any host pull the full zone (AXFR).",
                "Restrict allow-transfer in this zone to your secondary servers\u2019 addresses, ideally paired with a TSIG key — or set it to { none; }; if nothing should copy this zone.");
            }
          } else if (!gtDir && isPrimary(z)){
            add("BLOCKER", z.line,
              "Primary zone \u201C" + z.name + "\u201D has no allow-transfer restriction — not in the zone and not in the global options — so anyone can request a full zone transfer.",
              "Add an allow-transfer listing only your secondary servers\u2019 addresses (or { none; };) in this zone or in the options block.");
          }
        }

        /* Dynamic updates. */
        function checkUpdate(dirs, where){
          var d = lastDir(dirs, "allow-update");
          if (d && amlHas(d, "any")){
            add("BLOCKER", d.line,
              "Dynamic updates open to anyone " + where + ": allow-update { any; } lets any host add, change, or delete records.",
              "Replace allow-update { any; } with a TSIG key reference (for example allow-update { key \"update-key\"; };) or { none; }; if dynamic updates are not needed.");
          }
        }
        checkUpdate(data.optionDirs, "in the global options");
        for (i=0;i<data.zones.length;i++)
          checkUpdate(data.zones[i].dirs, "in zone \u201C" + data.zones[i].name + "\u201D");

        /* Version disclosure. */
        var verDir = findOpt("version");
        if (!verDir){
          add("WARNING", optLine,
            "Version disclosure: no version option is set, so BIND answers version queries with its real version string — free reconnaissance for an attacker.",
            "Add version \"none\"; to the options block so version queries return nothing useful.");
        } else {
          var vv = verDir.vals.length ? verDir.vals[0] : "";
          if (vv.toLowerCase() === "none"){
            /* Deliberately refused — nothing to report. */
          } else if (/\d+\.\d+/.test(vv)){
            add("WARNING", verDir.line,
              "Version disclosure: the version option is set to a value that looks like a real BIND version number, so version queries advertise exactly what is running.",
              "Set version to \"none\"; so version queries are refused instead of answered.");
          } else if (vv !== ""){
            add("INFO", verDir.line,
              "The version option is set to a custom string rather than the real version.",
              "That is acceptable obfuscation; version \"none\"; is the stricter choice.");
          }
        }

        /* DNSSEC validation posture. */
        var dvDir = findOpt("dnssec-validation");
        if (!dvDir){
          add("INFO", optLine,
            "dnssec-validation is not set in the pasted text, so the validation posture cannot be graded from this file.",
            "Set dnssec-validation auto; (or yes) explicitly on a recursive server so the posture is deliberate, not inherited.");
        } else if (scalarVal(dvDir) === "no"){
          add("WARNING", dvDir.line,
            "DNSSEC validation is turned off: dnssec-validation no; means forged DNSSEC-signed answers are not caught by this resolver.",
            "Set dnssec-validation auto; so signed zones are validated against the root trust anchor.");
        }

        /* Duplicate zones. */
        var seenZones = {};
        for (i=0;i<data.zones.length;i++){
          var zn = data.zones[i];
          var key = zn.name.toLowerCase();
          if (seenZones[key]){
            add("WARNING", zn.line,
              "Duplicate zone: \u201C" + zn.name + "\u201D is defined at line " + seenZones[key] + " and again at line " + zn.line + ".",
              "Remove one of the two definitions — BIND will not load a configuration that defines the same zone twice in one view.");
          } else {
            seenZones[key] = zn.line;
          }
        }

        /* listen-on exposure. */
        var loDir = findOpt("listen-on");
        if (!loDir){
          add("INFO", optLine,
            "No listen-on restriction: by default named binds port 53 on every interface — every address the host has, not just the ones you meant to serve.",
            "Add a listen-on listing only the addresses this server should answer on, if the host has addresses that should not serve DNS.");
        } else if (amlHas(loDir, "any")){
          add("INFO", loDir.line,
            "listen-on { any; } — named answers on every interface the host has.",
            "That is fine on a single-purpose DNS host; on a multi-homed host, list only the addresses that should serve DNS.");
        }

        /* Included files are never audited. */
        for (i=0;i<data.includes.length;i++){
          add("INFO", data.includes[i].line,
            "Include statement NOT AUDITED: \u201C" + (data.includes[i].file || "(no file named)") +
              "\u201D is pulled in by this file, but its contents were not pasted and cannot be graded.",
            "Audit the included file separately — a clean verdict here says nothing about what that file adds.",
            "NOT AUDITED");
        }

        /* NOT PARSED lines. */
        var npLines = Object.keys(data.notParsedLines).map(Number).sort(function(a,b){ return a-b; });
        for (i=0;i<npLines.length;i++){
          add("WARNING", npLines[i],
            "Statement NOT PARSED: this auditor does not recognize the statement on this line, so it was not graded and not guessed at.",
            "Check this line by hand against the BIND9 Administrator Reference Manual — and treat the verdict as covering the rest of the file only.",
            "NOT PARSED");
        }

        /* Sort: BLOCKER, then WARNING (incl. NOT PARSED), then INFO; by line within. */
        var rank = { BLOCKER: 0, WARNING: 1, INFO: 2 };
        findings.sort(function(a, b){
          if (rank[a.sev] !== rank[b.sev]) return rank[a.sev] - rank[b.sev];
          return a.line - b.line;
        });

        var counts = { BLOCKER: 0, WARNING: 0, INFO: 0, NOTPARSED: 0 };
        for (i=0;i<findings.length;i++){
          if (findings[i].chip === "NOT PARSED") counts.NOTPARSED++;
          else counts[findings[i].sev]++;
        }
        var verdict = counts.BLOCKER > 0 ? "DO NOT DEPLOY"
          : (counts.WARNING > 0 || counts.NOTPARSED > 0) ? "DEPLOY WITH FIXES"
          : "SAFE TO DEPLOY";
        return { verdict: verdict, findings: findings, counts: counts,
                 lineCount: text.replace(/\n$/, "").split("\n").length };
      }

      /* ---------- Report rendering ------------------------------------ */
      function buildReport(r){
        var lines = [];
        lines.push("J-Dawgs BIND9 DNS Server Config Safety Auditor\u2122 — audit report");
        lines.push("Verdict: " + r.verdict);
        lines.push("Counts: " + r.counts.BLOCKER + " blocker(s), " + r.counts.WARNING +
          " warning(s), " + r.counts.NOTPARSED + " not parsed, " + r.counts.INFO + " info");
        lines.push("Lines audited: " + r.lineCount);
        lines.push("");
        if (!r.findings.length){
          lines.push("Findings: none. Nothing to fix in the pasted text.");
        } else {
          lines.push("Findings:");
          for (var i=0;i<r.findings.length;i++){
            var f = r.findings[i];
            var tag = (f.chip === "NOT PARSED") ? "NOT PARSED" : f.sev;
            lines.push("");
            lines.push("[" + tag + "] Line " + f.line + " — " + f.title);
            lines.push("  Fix: " + f.fix);
          }
        }
        lines.push("");
        lines.push("Limits: heuristic text audit of the pasted file only. BIND was not run, " +
          "DNS was not resolved, and included files were not audited. Secret values are " +
          "never printed — secrets are reported by key name and line only.");
        return lines.join("\n");
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-bind9-dns-server-config-safety-auditortm',
  name: 'J-Dawgs BIND9 DNS Server Config Safety Auditor',
  description: 'Grades a pasted named.conf offline — open-resolver and open zone-transfer BLOCKERs, allow-update scope, version disclosure, duplicate zones, and TSIG secrets reported by key name and line only — into one deploy verdict. named-checkconf needs BIND installed on a host and stops at whether the file par',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
