'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Warranty & Return Window Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";
        var DAY = 86400000;
        var MONTHS = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
        var WDAYS = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
        var DISCLAIMER = "This report is date arithmetic on the terms pasted into the J-Dawgs Warranty & Return Window Auditor only. It does not read receipts or retailer policies, and it is not legal advice.";

        function $(id) { return document.getElementById(id); }

        function parseDate(str) {
          if (!str) return null;
          var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(str);
          if (!m) return null;
          var d = new Date(Date.UTC(+m[1], +m[2] - 1, +m[3]));
          if (d.getUTCFullYear() !== +m[1] || d.getUTCMonth() !== +m[2] - 1 || d.getUTCDate() !== +m[3]) return null;
          return d;
        }
        function iso(d) {
          function p(n) { return (n < 10 ? "0" : "") + n; }
          return d.getUTCFullYear() + "-" + p(d.getUTCMonth() + 1) + "-" + p(d.getUTCDate());
        }
        function fmt(d) {
          return WDAYS[d.getUTCDay()] + ", " + MONTHS[d.getUTCMonth()] + " " + d.getUTCDate() + ", " + d.getUTCFullYear();
        }
        function fmtShort(d) {
          return MONTHS[d.getUTCMonth()] + " " + d.getUTCDate() + ", " + d.getUTCFullYear();
        }
        function addDays(d, n) { return new Date(d.getTime() + n * DAY); }
        function addMonths(d, n) {
          var y = d.getUTCFullYear(), mo = d.getUTCMonth() + n, day = d.getUTCDate();
          var ny = y + Math.floor(mo / 12), nmo = ((mo % 12) + 12) % 12;
          var last = new Date(Date.UTC(ny, nmo + 1, 0)).getUTCDate();
          return new Date(Date.UTC(ny, nmo, Math.min(day, last)));
        }
        function diffDays(a, b) { return Math.round((b.getTime() - a.getTime()) / DAY); }
        function dayWord(n) { return n === 1 ? "day" : "days"; }
        function statusText(deadline, asOf) {
          var d = diffDays(asOf, deadline);
          if (d > 0) return d + " " + dayWord(d) + " remaining as of " + fmtShort(asOf) + ".";
          if (d === 0) return "Closes today — " + fmtShort(asOf) + " is the last day.";
          return "Closed " + (-d) + " " + dayWord(-d) + " ago — overdue by " + (-d) + " " + dayWord(-d) + " as of " + fmtShort(asOf) + ".";
        }

        var CASES = {
          example: { purchase: "2026-09-01", delivery: "2026-09-06", window: "30", warranty: "12", discovered: "2026-10-20", reported: "2026-10-27", asof: "2026-11-05" },
          covered: { purchase: "2026-10-20", delivery: "", window: "30", warranty: "12", discovered: "2026-11-01", reported: "2026-11-02", asof: "2026-11-05" },
          warranty: { purchase: "2026-09-01", delivery: "2026-09-06", window: "30", warranty: "12", discovered: "2026-10-20", reported: "2026-10-27", asof: "2026-11-05" },
          closed: { purchase: "2024-01-15", delivery: "", window: "30", warranty: "12", discovered: "2025-03-01", reported: "2025-03-03", asof: "2026-11-05" },
          unsettleable: { purchase: "2026-10-01", delivery: "2026-09-28", window: "30", warranty: "12", discovered: "2026-10-20", reported: "2026-10-18", asof: "2026-11-05" }
        };

        function fillForm(c) {
          $("f-purchase").value = c.purchase;
          $("f-delivery").value = c.delivery;
          $("f-window").value = c.window;
          $("f-warranty").value = c.warranty;
          $("f-discovered").value = c.discovered;
          $("f-reported").value = c.reported;
          $("f-asof").value = c.asof;
        }

        function readInputs() {
          return {
            purchaseRaw: $("f-purchase").value,
            deliveryRaw: $("f-delivery").value,
            windowRaw: $("f-window").value.trim(),
            warrantyRaw: $("f-warranty").value.trim(),
            discoveredRaw: $("f-discovered").value,
            reportedRaw: $("f-reported").value,
            asofRaw: $("f-asof").value
          };
        }

        function audit() {
          var inp = readInputs();
          var reasons = [];

          var purchase = parseDate(inp.purchaseRaw);
          var delivery = parseDate(inp.deliveryRaw);
          var discovered = parseDate(inp.discoveredRaw);
          var reported = parseDate(inp.reportedRaw);
          var asOf = parseDate(inp.asofRaw);
          var winDays = inp.windowRaw === "" ? null : Number(inp.windowRaw);
          var warMonths = inp.warrantyRaw === "" ? null : Number(inp.warrantyRaw);

          if (!inp.purchaseRaw) reasons.push("Purchase date is missing — every window is counted from it.");
          else if (!purchase) reasons.push("Purchase date “" + inp.purchaseRaw + "” is not a real calendar date.");
          if (inp.deliveryRaw && !delivery) reasons.push("Delivery date “" + inp.deliveryRaw + "” is not a real calendar date.");
          if (winDays === null || isNaN(winDays)) reasons.push("Return window in days is missing — the seller's stated return period is required.");
          else if (!isFinite(winDays) || winDays < 0 || Math.floor(winDays) !== winDays) reasons.push("Return window must be a whole number of days, zero or more.");
          if (warMonths === null || isNaN(warMonths)) reasons.push("Warranty length in months is missing — the stated warranty length is required.");
          else if (!isFinite(warMonths) || warMonths < 0 || Math.floor(warMonths) !== warMonths) reasons.push("Warranty length must be a whole number of months, zero or more.");
          if (!inp.discoveredRaw) reasons.push("Defect discovered date is missing.");
          else if (!discovered) reasons.push("Defect discovered date “" + inp.discoveredRaw + "” is not a real calendar date.");
          if (!inp.reportedRaw) reasons.push("Defect reported date is missing.");
          else if (!reported) reasons.push("Defect reported date “" + inp.reportedRaw + "” is not a real calendar date.");
          if (!inp.asofRaw) reasons.push("“As of” date is missing — there is no date to judge the windows against.");
          else if (!asOf) reasons.push("“As of” date “" + inp.asofRaw + "” is not a real calendar date.");

          if (!reasons.length) {
            if (delivery && delivery.getTime() < purchase.getTime())
              reasons.push("Delivery date (" + fmtShort(delivery) + ") is before the purchase date (" + fmtShort(purchase) + ") — an item cannot arrive before it is bought, so one of these dates is wrong.");
            if (reported.getTime() < discovered.getTime())
              reasons.push("Defect reported date (" + fmtShort(reported) + ") is before the defect discovered date (" + fmtShort(discovered) + ") — a defect cannot be reported before it is found, so one of these dates is wrong.");
            if (discovered.getTime() < purchase.getTime())
              reasons.push("Defect discovered date (" + fmtShort(discovered) + ") is before the purchase date (" + fmtShort(purchase) + ") — the defect cannot predate the purchase.");
            if (purchase.getTime() > asOf.getTime())
              reasons.push("Purchase date (" + fmtShort(purchase) + ") is after the “as of” date (" + fmtShort(asOf) + ") — the audit cannot judge a purchase that has not happened yet.");
            if (discovered.getTime() > asOf.getTime())
              reasons.push("Defect discovered date (" + fmtShort(discovered) + ") is after the “as of” date (" + fmtShort(asOf) + ").");
            if (reported.getTime() > asOf.getTime())
              reasons.push("Defect reported date (" + fmtShort(reported) + ") is after the “as of” date (" + fmtShort(asOf) + ").");
          }
          return { inp: inp, purchase: purchase, delivery: delivery, discovered: discovered, reported: reported, asOf: asOf, winDays: winDays, warMonths: warMonths, reasons: reasons };
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-warranty-return-window-auditor',
  name: 'J-Dawgs Warranty & Return Window Auditor',
  description: 'Cross-checks purchase and delivery dates against the stated return window, warranty length, and defect discovery and report dates — every deadline computed with arithmetic shown — into one coverage verdict; date arithmetic on pasted terms only, not legal advice.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
