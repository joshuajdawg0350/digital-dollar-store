'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Electrical Installation Proposal, Work Record & Final Invoice Consistency Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";
      // ---------- Fixtures ----------
      var WORKED = {
        proposal: "Outlets | 6 | 185\nLabor | 1 | 1320\nPermit Fee | 1 | 150\nPanel Upgrade 100A | 1 | 1200\nDEPOSIT: $800",
        work: "Outlets | 6\nLabor | 1 | 12 | 110\nPanel Upgrade 100A | 1",
        invoice: "Outlets | 8 | 185\nLabor | 1 | 1920\nPermit Fee | 1 | 150\nPermit Fee | 1 | 150\nPanel Upgrade 100A | 1 | 1200"
      };
      var CLEAN = {
        proposal: "Outlets | 4 | 185\nLabor | 1 | 880\nPermit Fee | 1 | 150\nDEPOSIT: $300",
        work: "Outlets | 4\nLabor | 1 | 8 | 110",
        invoice: "Outlets | 4 | 185\nLabor | 1 | 880\nPermit Fee | 1 | 150\nDEPOSIT: $300"
      };

      // ---------- Helpers ----------
      function normLabel(s){ return String(s).toLowerCase().replace(/\s+/g," ").trim(); }
      function parseMoneyCents(s){
        if (s == null) return null;
        var t = String(s).replace(/[$,\s]/g,"");
        if (t === "" || isNaN(Number(t))) return null;
        return Math.round(Number(t) * 100);
      }
      function parseNum(s){
        if (s == null) return null;
        var t = String(s).replace(/[,\s]/g,"");
        if (t === "" || isNaN(Number(t))) return null;
        return Number(t);
      }
      function fmt(cents){
        var neg = cents < 0; var v = Math.abs(cents) / 100;
        var str = v.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        return (neg ? "-$" : "$") + str;
      }
      function fmtQty(n){
        if (Number.isInteger(n)) return String(n);
        return String(Math.round(n * 100) / 100);
      }
      function extractDepositCents(line){
        var after = line.indexOf(":") >= 0 ? line.slice(line.indexOf(":") + 1) : line;
        var c = parseMoneyCents(after);
        if (c != null) return Math.abs(c);
        var m = line.match(/([\d,]+(?:\.\d{1,2})?)/);
        return m ? Math.abs(parseMoneyCents(m[1])) : 0;
      }
      function tierOf(label){
        var m = String(label).match(/(\d+(?:\.\d+)?)\s*(?:a|amp|amps)\b/i);
        return m ? Number(m[1]) : null;
      }
      function baseName(label){
        return normLabel(String(label).replace(/\d+(?:\.\d+)?\s*(?:a|amp|amps)\b/ig, " "));
      }

      // ---------- Parsing ----------
      function parseMoneyDoc(text){
        var items = [], deposits = 0, valid = 0, bad = 0;
        String(text || "").split(/\r?\n/).forEach(function(raw){
          var line = raw.trim(); if (!line) return;
          if (/deposit/i.test(line) && line.indexOf("|") < 0){ deposits += extractDepositCents(line); valid++; return; }
          var parts = line.split("|").map(function(p){ return p.trim(); });
          if (parts.length >= 3){
            var qty = parseNum(parts[1]); var price = parseMoneyCents(parts[2]);
            if (qty != null && price != null && parts[0]){
              if (/deposit/i.test(parts[0])){ deposits += Math.abs(Math.round(qty * price)); valid++; return; }
              items.push({ label: parts[0], norm: normLabel(parts[0]), qty: qty, unitCents: price, totalCents: Math.round(qty * price) });
              valid++; return;
            }
          }
          bad++;
        });
        return { items: items, depositsCents: deposits, validLines: valid, badLines: bad, present: String(text || "").trim().length > 0 };
      }
      function parseWorkDoc(text){
        var qtyMap = {}, laborMap = {}, deposits = 0, valid = 0, bad = 0;
        String(text || "").split(/\r?\n/).forEach(function(raw){
          var line = raw.trim(); if (!line) return;
          if (/deposit/i.test(line) && line.indexOf("|") < 0){ deposits += extractDepositCents(line); valid++; return; }
          var parts = line.split("|").map(function(p){ return p.trim(); });
          if (parts.length >= 4){
            var hours = parseNum(parts[2]); var rate = parseMoneyCents(parts[3]); var qd = parseNum(parts[1]);
            if (hours != null && rate != null && parts[0]){
              var n = normLabel(parts[0]);
              laborMap[n] = { label: parts[0], norm: n, qtyDone: qd, hours: hours, rateCents: rate, allowedCents: Math.round(hours * rate) };
              valid++; return;
            }
          }
          if (parts.length >= 2){
            var qty = parseNum(parts[1]);
            if (qty != null && parts[0]){
              var n2 = normLabel(parts[0]);
              if (!qtyMap[n2]) qtyMap[n2] = { label: parts[0], norm: n2, qty: 0 };
              qtyMap[n2].qty += qty; valid++; return;
            }
          }
          bad++;
        });
        return { qtyMap: qtyMap, laborMap: laborMap, depositsCents: deposits, validLines: valid, badLines: bad, present: String(text || "").trim().length > 0 };
      }
      function aggregate(items){
        var map = {};
        items.forEach(function(it){
          if (!map[it.norm]) map[it.norm] = { label: it.label, norm: it.norm, qty: 0, totalCents: 0, unitCents: it.unitCents, count: 0 };
          map[it.norm].qty += it.qty; map[it.norm].totalCents += it.totalCents; map[it.norm].count++;
        });
        return map;
      }

      // ---------- Audit engine ----------
      function audit(proposalText, workText, invoiceText){
        var prop = parseMoneyDoc(proposalText);
        var work = parseWorkDoc(workText);
        var inv = parseMoneyDoc(invoiceText);
        var docs = [
          { name: "Proposal", parsed: prop },
          { name: "Work Record", parsed: work },
          { name: "Final Invoice", parsed: inv }
        ];
        var missing = docs.filter(function(d){ return !d.parsed.present || d.parsed.validLines === 0; }).map(function(d){ return d.name; });
        var presentCount = 3 - docs.filter(function(d){ return !d.parsed.present; }).length;
        var totalValid = prop.validLines + work.validLines + inv.validLines;
        var findings = [];

        if (totalValid === 0 || presentCount < 2){
          return { verdict: "NOT ENOUGH TO COMPARE", totalCents: 0, findings: findings, missing: missing,
            counts: { proposal: prop.validLines, work: work.validLines, invoice: inv.validLines },
            note: totalValid === 0 ? "Nothing parsable was pasted. Use the line format above — LABEL | qty | unit price — in at least two documents."
                                   : "Only one document was pasted, so there is nothing to cross-check it against. Missing: " + missing.join(", ") + "." };
        }

        var propAgg = aggregate(prop.items);
        var invAgg = aggregate(inv.items);

        // (f) tier swaps first, so those labels are not double-flagged as invoice-only
        var tierInvoiceNorms = {};
        Object.keys(invAgg).forEach(function(n){
          var invItem = invAgg[n]; var invTier = tierOf(invItem.label);
          if (invTier == null) return;
          Object.keys(propAgg).forEach(function(pn){
            var pItem = propAgg[pn]; var pTier = tierOf(pItem.label);
            if (pTier == null) return;
            if (baseName(invItem.label) === baseName(pItem.label) && invItem.norm !== pItem.norm && invTier > pTier){
              var amt = Math.max(0, invItem.totalCents - pItem.totalCents);
              tierInvoiceNorms[n] = true;
              findings.push({ type: "tier-swap", title: "Tier swap: " + pItem.label + " proposed, " + invItem.label + " billed",
                arithmetic: "Billed " + fmt(invItem.totalCents) + " for “" + invItem.label + "” − proposed " + fmt(pItem.totalCents) + " for “" + pItem.label + "” (" + pTier + "A → " + invTier + "A) = " + fmt(amt) + " overcharge",
                amountCents: amt });
            }
          });
        });

        // (a) quantity billed above installed
        Object.keys(invAgg).forEach(function(n){
          if (work.laborMap[n]) return; // labor handled in (b)
          var rec = work.qtyMap[n]; if (!rec) return;
          var invItem = invAgg[n];
          if (invItem.qty > rec.qty){
            var extra = invItem.qty - rec.qty; var amt = Math.round(extra * invItem.unitCents);
            findings.push({ type: "quantity", title: "Quantity overage: " + invItem.label,
              arithmetic: "Billed " + fmtQty(invItem.qty) + " − installed " + fmtQty(rec.qty) + " = " + fmtQty(extra) + " extra × " + fmt(invItem.unitCents) + " = " + fmt(amt) + " overcharge",
              amountCents: amt });
          }
        });

        // (b) labor billed above recorded hours × rate
        Object.keys(work.laborMap).forEach(function(n){
          var lab = work.laborMap[n]; var invItem = invAgg[n]; if (!invItem) return;
          if (invItem.totalCents > lab.allowedCents){
            var amt = invItem.totalCents - lab.allowedCents;
            findings.push({ type: "labor", title: "Labor overage: " + lab.label,
              arithmetic: "Billed " + fmt(invItem.totalCents) + " − recorded " + fmtQty(lab.hours) + "h × " + fmt(lab.rateCents) + " = " + fmt(invItem.totalCents) + " − " + fmt(lab.allowedCents) + " = " + fmt(amt) + " overcharge",
              amountCents: amt });
          }
        });

        // (c) uncredited deposit
        var expectedDeposit = Math.max(prop.depositsCents, work.depositsCents);
        if (expectedDeposit > inv.depositsCents){
          var damt = expectedDeposit - inv.depositsCents;
          findings.push({ type: "deposit", title: "Uncredited deposit",
            arithmetic: "Deposit stated " + fmt(expectedDeposit) + " − credited on invoice " + fmt(inv.depositsCents) + " = " + fmt(damt) + " overcharge",
            amountCents: damt });
        }

        // (d) duplicate charges on the invoice
        var groups = {};
        inv.items.forEach(function(it){
          var key = it.norm + "|" + it.totalCents;
          if (!groups[key]) groups[key] = { label: it.label, totalCents: it.totalCents, count: 0 };
          groups[key].count++;
        });
        Object.keys(groups).forEach(function(k){
          var g = groups[k];
          if (g.count > 1){
            var amt = g.totalCents * (g.count - 1);
            findings.push({ type: "duplicate", title: "Duplicate charge: " + g.label,
              arithmetic: "Charged " + g.count + " × " + fmt(g.totalCents) + " = " + fmt(g.totalCents * g.count) + " − allowed " + fmt(g.totalCents) + " = " + fmt(amt) + " overcharge",
              amountCents: amt });
          }
        });

        // (e) invoice-only fees
        Object.keys(invAgg).forEach(function(n){
          if (propAgg[n] || work.qtyMap[n] || work.laborMap[n] || tierInvoiceNorms[n]) return;
          var invItem = invAgg[n];
          findings.push({ type: "invoice-only", title: "Invoice-only fee: " + invItem.label,
            arithmetic: "Billed " + fmt(invItem.totalCents) + " − allowed $0.00 (label appears in neither the proposal nor the work record) = " + fmt(invItem.totalCents) + " overcharge",
            amountCents: invItem.totalCents });
        });

        var total = findings.reduce(function(s, f){ return s + f.amountCents; }, 0);
        var verdict, note;
        if (total > 0){ verdict = "DO NOT PAY YET"; note = "Documented overcharge of " + fmt(total) + " across " + findings.length + " finding(s)." + (missing.length ? " Also missing: " + missing.join(", ") + "." : ""); }
        else if (missing.length){ verdict = "PAY WITH FIXES"; note = "No overcharge found in what was pasted, but the cross-check is incomplete. Missing: " + missing.join(", ") + "."; }
        else { verdict = "SAFE TO PAY"; note = "All three documents agree. Documented overcharge is $0.00."; }
        return { verdict: verdict, totalCents: total, findings: findings, missing: missing,
          counts: { proposal: prop.validLines, work: work.validLines, invoice: inv.validLines }, note: note };
      }

      // ---------- UI ----------
      var lastResult = null;
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-electrical-installation-proposal-work-record-final-invoice-consistency-auditortm',
  name: 'J-Dawgs Electrical Installation Proposal, Work Record & Final Invoice Consistency Auditor',
  description: 'Cross-checks an electrical job\'s proposal vs work record vs final invoice — quantities, labor, deposit credit, duplicates, invoice-only fees, and panel tier swaps — into one pay verdict with arithmetic shown.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
