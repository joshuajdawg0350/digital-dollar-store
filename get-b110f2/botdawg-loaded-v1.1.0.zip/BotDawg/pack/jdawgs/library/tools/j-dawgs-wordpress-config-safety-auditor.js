'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs WordPress Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

        "use strict";

        var SALT_NAMES = ["AUTH_KEY", "SECURE_AUTH_KEY", "LOGGED_IN_KEY", "NONCE_KEY",
                          "AUTH_SALT", "SECURE_AUTH_SALT", "LOGGED_IN_SALT", "NONCE_SALT"];
        var PLACEHOLDER = "put your unique phrase here";

        var RISKY = [
          "<?php",
          "// RISKY worked example for the auditor. Every secret below is FAKE.",
          "define( 'DB_NAME', 'risky_example_db' );",
          "define( 'DB_USER', 'root' );",
          "define( 'DB_PASSWORD', 'fake-password-do-not-use' );",
          "define( 'DB_HOST', 'localhost' );",
          "define( 'AUTH_KEY', 'put your unique phrase here' );",
          "define( 'SECURE_AUTH_KEY', 'put your unique phrase here' );",
          "define( 'LOGGED_IN_KEY', 'put your unique phrase here' );",
          "define( 'NONCE_KEY', 'put your unique phrase here' );",
          "define( 'AUTH_SALT', 'put your unique phrase here' );",
          "define( 'SECURE_AUTH_SALT', 'put your unique phrase here' );",
          "define( 'LOGGED_IN_SALT', 'put your unique phrase here' );",
          "define( 'NONCE_SALT', 'put your unique phrase here' );",
          "$table_prefix = 'wp_';",
          "define( 'WP_DEBUG', true );",
          "define( 'SAVEQUERIES', true );",
          "/* That is all, stop editing! Happy publishing. */",
          "require_once ABSPATH . 'wp-settings.php';"
        ].join("\n");

        var CLEAN = [
          "<?php",
          "// HARDENED worked example for the auditor. Every secret below is FAKE.",
          "define( 'DB_NAME', 'clean_example_db' );",
          "define( 'DB_USER', 'wp_app_user' );",
          "define( 'DB_PASSWORD', 'Fake!Db9Pass#wQ72zXmK4pR8sT6vN3b' );",
          "define( 'DB_HOST', 'localhost' );",
          "define( 'AUTH_KEY', 'kX9#mQ2vR7pL4&zW8sN1!bTd3fG6@hJk9qWe5rTy2uIo8pAsdF4gH7jKlZ1xC6vB' );",
          "define( 'SECURE_AUTH_KEY', 'P0oI9uYtR5eW3qA1sD8fG2hJkL6zX4cVbN7mQ0wErT3yU6iOpA9sD1fGhJ5kL8zX' );",
          "define( 'LOGGED_IN_KEY', 'mZ3xK8vBnQ6wE1rTyU9iO2pAsD5fG7hJkL0zX4cVbN8mQ3wErT6yU9iOpA2sD5fG' );",
          "define( 'NONCE_KEY', 'H7jK2lZ9xC4vB8nMqW1eR5tYuI3oP6aSdF0gH9jKlZ2xC7vBnM5qW8eRtY4uI1oP' );",
          "define( 'AUTH_SALT', 'aS6dF9gHjK3lZ7xCvB2nM5qWeR8tY1uIoP4aS6dFgH9jK2lZxC5vB8nMqW1eR4tY' );",
          "define( 'SECURE_AUTH_SALT', 'zX1cV4bNmQ7wE0rTyU3iO6pAsD9fG2hJkL5zX8cVbN1mQ4wErT7yU0iOpA3sD6fG' );",
          "define( 'LOGGED_IN_SALT', 'wE5rT8yUiO2pA5sDfG8hJ1kLzX4cV7bNmQ0wE3rTyU6iO9pAsD2fG5hJkL8zX1cV' );",
          "define( 'NONCE_SALT', 'tY9uI2oPaS5dF8gHjK1lZ4xCvB7nM0qWeR3tY6uIoP9aS2dFgH5jK8lZxC1vB4nM' );",
          "$table_prefix = 'jd7_';",
          "define( 'WP_DEBUG', false );",
          "define( 'DISALLOW_FILE_EDIT', true );",
          "define( 'FORCE_SSL_ADMIN', true );",
          "define( 'WP_AUTO_UPDATE_CORE', true );",
          "define( 'WP_POST_REVISIONS', 5 );",
          "if ( ! defined( 'ABSPATH' ) ) {",
          "\tdefine( 'ABSPATH', __DIR__ . '/' );",
          "}",
          "require_once ABSPATH . 'wp-settings.php';"
        ].join("\n");

        function lengthClass(len) {
          if (len < 32) return "short (under 32 characters)";
          if (len < 64) return "medium (32-63 characters)";
          return "long (64+ characters)";
        }

        function parseValue(token) {
          token = token.replace(/^\s+|\s+$/g, "");
          var first = token.charAt(0);
          if (first === "'" || first === '"') {
            var body = token.slice(1, token.length - 1);
            body = body.replace(/\\(.)/g, "$1");
            return { type: "string", value: body };
          }
          var low = token.toLowerCase();
          if (low === "true") return { type: "bool", value: true };
          if (low === "false") return { type: "bool", value: false };
          if (/^-?\d+$/.test(token)) return { type: "number", value: parseInt(token, 10) };
          return { type: "expr", value: token };
        }

        function parseConfig(text) {
          var lines = text.split(/\r?\n/);
          var defs = {};
          var prefix = null;
          var defineRe = /define\s*\(\s*['"]([A-Za-z0-9_]+)['"]\s*,\s*('(?:[^'\\]|\\.)*'|"(?:[^"\\]|\\.)*"|true|false|-?\d+|[^)]*?)\s*\)/i;
          var prefixRe = /\$table_prefix\s*=\s*('(?:[^'\\]|\\.)*'|"(?:[^"\\]|\\.)*")/;
          for (var i = 0; i < lines.length; i++) {
            var m = lines[i].match(defineRe);
            if (m && !defs[m[1]]) {
              defs[m[1]] = { parsed: parseValue(m[2]), line: i + 1 };
            }
            var pm = lines[i].match(prefixRe);
            if (pm && !prefix) {
              prefix = { parsed: parseValue(pm[1]), line: i + 1 };
            }
          }
          var hasAbspathGuard = /defined\s*\(\s*['"]ABSPATH['"]\s*\)/.test(text);
          return { defs: defs, prefix: prefix, hasAbspathGuard: hasAbspathGuard, lineCount: lines.length };
        }

        function audit(text) {
          var parsed = parseConfig(text);
          var defs = parsed.defs;
          var findings = [];
          function add(sev, line, title, detail) {
            findings.push({ sev: sev, line: line, title: title, detail: detail });
          }
          function get(name) { return defs[name] || null; }
          function isTrue(d) { return d && d.parsed.type === "bool" && d.parsed.value === true; }
          function isFalse(d) { return d && d.parsed.type === "bool" && d.parsed.value === false; }

          if (Object.keys(defs).length === 0 && !parsed.prefix) {
            add("REVIEW", null, "No define() statements found",
              "Nothing in the pasted text looks like a wp-config.php. Check that you pasted the whole file.");
          }

          // WP_DEBUG
          var wpDebug = get("WP_DEBUG");
          if (isTrue(wpDebug)) {
            add("BLOCKER", wpDebug.line, "WP_DEBUG is on",
              "Debug mode displays errors and internal paths to visitors. Set WP_DEBUG to false before this file goes anywhere near production.");
          } else if (!wpDebug) {
            add("REVIEW", null, "WP_DEBUG is not defined",
              "WordPress falls back to its default when the constant is missing. Define WP_DEBUG explicitly (false for production) so the posture is a decision, not an accident.");
          }

          // Table prefix
          if (!parsed.prefix) {
            add("REVIEW", null, "No $table_prefix found",
              "A wp-config.php normally sets $table_prefix. Its absence suggests the paste may be incomplete.");
          } else if (parsed.prefix.parsed.type === "string" && parsed.prefix.parsed.value === "wp_") {
            add("WARNING", parsed.prefix.line, "Default table prefix wp_",
              "wp_ is the prefix every automated attack tries first. Use a short custom prefix of letters, numbers, and underscores.");
          }

          // Salts and keys
          var seenSalts = {};
          for (var s = 0; s < SALT_NAMES.length; s++) {
            var name = SALT_NAMES[s];
            var d = get(name);
            if (!d) {
              add("BLOCKER", null, name + " is missing",
                "Without this key WordPress falls back to weak or database-stored values. Generate a unique random value for it.");
              continue;
            }
            if (d.parsed.type !== "string") {
              add("REVIEW", d.line, name + " is not a plain string",
                "The value could not be graded as text. Keys and salts should be long random strings.");
              continue;
            }
            var val = d.parsed.value;
            if (val.toLowerCase() === PLACEHOLDER) {
              add("BLOCKER", d.line, name + " is still the placeholder",
                "This constant still holds the literal phrase \"put your unique phrase here\", which ships in every default install and is public knowledge. Replace it with a unique random value.");
              continue;
            }
            if (val.length === 0) {
              add("BLOCKER", d.line, name + " is empty",
                "An empty key or salt provides no protection. Generate a unique random value for it.");
              continue;
            }
            if (seenSalts[val]) {
              add("WARNING", d.line, name + " reuses another key's value",
                "This value is identical to " + seenSalts[val] + " (value not shown). Every key and salt must be unique, or one leak compromises both.");
            } else {
              seenSalts[val] = name;
            }
            if (val.length < 32) {
              add("WARNING", d.line, name + " is short",
                "Graded by length class only (value never shown): " + lengthClass(val.length) + ". Aim for 64 random characters.");
            } else if (val.length < 64) {
              add("REVIEW", d.line, name + " could be longer",
                "Graded by length class only (value never shown): " + lengthClass(val.length) + ". The usual target is 64 random characters.");
            }
          }

          // DB_PASSWORD — name and line only, masked value
          var dbPass = get("DB_PASSWORD");
          if (!dbPass) {
            add("WARNING", null, "DB_PASSWORD is not defined",
              "A wp-config.php normally defines DB_PASSWORD. Its absence suggests the paste may be incomplete.");
          } else if (dbPass.parsed.type === "string") {
            if (dbPass.parsed.value.length === 0) {
              add("WARNING", dbPass.line, "DB_PASSWORD is empty",
                "An empty database password is flagged by constant name and line. Set a real password on the database account.");
            } else {
              add("INFO", dbPass.line, "DB_PASSWORD recorded (masked)",
                "Flagged by constant name and line only. Masked: " + dbPass.parsed.value.slice(0, 2) + "••• · length class: " + lengthClass(dbPass.parsed.value.length) + ". The full value is never printed anywhere in this audit.");
            }
          } else {
            add("INFO", dbPass.line, "DB_PASSWORD recorded",
              "Flagged by constant name and line only. The value is set by an expression and is never printed anywhere in this audit.");
          }

          // DB_USER root
          var dbUser = get("DB_USER");
          if (dbUser && dbUser.parsed.type === "string" && dbUser.parsed.value.toLowerCase() === "root") {
            add("WARNING", dbUser.line, "DB_USER is root",
              "WordPress is connecting as the database superuser, so any SQL flaw reaches every database on the server. Create a dedicated user with rights only to this site's database.");
          }

          // DISALLOW_FILE_EDIT
          var dfe = get("DISALLOW_FILE_EDIT");
          if (!dfe) {
            add("WARNING", null, "DISALLOW_FILE_EDIT is not set",
              "Without it, anyone who reaches the WordPress admin can edit theme and plugin PHP from the dashboard. Add define( 'DISALLOW_FILE_EDIT', true );");
          } else if (isFalse(dfe)) {
            add("WARNING", dfe.line, "DISALLOW_FILE_EDIT is off",
              "The dashboard file editor is enabled. Set DISALLOW_FILE_EDIT to true so a compromised admin account cannot rewrite code.");
          }

          // FORCE_SSL_ADMIN
          var fsa = get("FORCE_SSL_ADMIN");
          if (!fsa) {
            add("REVIEW", null, "FORCE_SSL_ADMIN is not set",
              "Worth a deliberate look: setting FORCE_SSL_ADMIN to true forces encrypted logins and admin sessions. Confirm your host serves the admin over HTTPS, then set it.");
          } else if (isFalse(fsa)) {
            add("WARNING", fsa.line, "FORCE_SSL_ADMIN is off",
              "Admin sessions are not forced onto HTTPS. Set FORCE_SSL_ADMIN to true once the site has a working certificate.");
          }

          // Auto-update posture
          var auc = get("WP_AUTO_UPDATE_CORE");
          var aud = get("AUTOMATIC_UPDATER_DISABLED");
          if (isTrue(aud)) {
            add("WARNING", aud.line, "Automatic updater is disabled",
              "AUTOMATIC_UPDATER_DISABLED is true, which switches off every automatic update, security releases included. Re-enable it or commit to a strict manual patch schedule.");
          } else if (!auc && !aud) {
            add("REVIEW", null, "No auto-update posture in the config",
              "Neither WP_AUTO_UPDATE_CORE nor AUTOMATIC_UPDATER_DISABLED appears, so update behavior is left to WordPress and host defaults. State the posture in the file so it survives a host change.");
          } else if (auc) {
            if (isFalse(auc)) {
              add("WARNING", auc.line, "Core auto-updates are off",
                "WP_AUTO_UPDATE_CORE is false, so security releases wait for a human. Turn core auto-updates on, or patch on a strict schedule.");
            } else if (auc.parsed.type === "string" && auc.parsed.value.toLowerCase() === "major") {
              add("REVIEW", auc.line, "Core auto-updates include major releases",
                "WP_AUTO_UPDATE_CORE is set to 'major', which also auto-installs major version jumps. That is a valid choice, but make it a deliberate one with backups in place.");
            }
          }

          // SAVEQUERIES
          var sq = get("SAVEQUERIES");
          if (isTrue(sq)) {
            add("WARNING", sq.line, "SAVEQUERIES is on",
              "Every database query is being stored in memory on every page load — a real performance cost and a log of your data structures. Turn it off outside of short debugging sessions.");
          }

          // WP_POST_REVISIONS
          var rev = get("WP_POST_REVISIONS");
          if (!rev) {
            add("INFO", null, "WP_POST_REVISIONS is not set",
              "Revisions are unlimited by default, so the posts table grows forever. A small cap such as 5 keeps history without the bloat.");
          } else if (isTrue(rev)) {
            add("INFO", rev.line, "WP_POST_REVISIONS is unbounded",
              "Set to true, revisions accumulate without limit. A small numeric cap keeps the database lean.");
          }

          // ABSPATH guard
          if (!parsed.hasAbspathGuard) {
            add("WARNING", null, "No ABSPATH guard found",
              "The standard guard — if ( ! defined( 'ABSPATH' ) ) — does not appear. It keeps the file from doing anything when loaded outside WordPress.");
          }

          var order = { BLOCKER: 0, WARNING: 1, REVIEW: 2, INFO: 3 };
          findings.sort(function (a, b) {
            if (order[a.sev] !== order[b.sev]) return order[a.sev] - order[b.sev];
            var la = a.line === null ? 100000 : a.line;
            var lb = b.line === null ? 100000 : b.line;
            return la - lb;
          });

          var counts = { BLOCKER: 0, WARNING: 0, REVIEW: 0, INFO: 0 };
          for (var f = 0; f < findings.length; f++) counts[findings[f].sev]++;

          var verdict, vclass;
          if (counts.BLOCKER > 0) { verdict = "DO NOT DEPLOY"; vclass = "bad"; }
          else if (counts.WARNING > 0 || counts.REVIEW > 0) { verdict = "DEPLOY WITH FIXES"; vclass = "fixes"; }
          else { verdict = "SAFE TO DEPLOY"; vclass = "ok"; }

          return { verdict: verdict, vclass: vclass, counts: counts, findings: findings, lineCount: parsed.lineCount };
        }

        function buildReport(r) {
          var out = [];
          out.push("J-Dawgs WordPress Config Safety Auditor — audit report");
          out.push("Verdict: " + r.verdict);
          out.push("Counts: " + r.counts.BLOCKER + " blocker(s), " + r.counts.WARNING + " warning(s), " +
                   r.counts.REVIEW + " review item(s), " + r.counts.INFO + " info note(s)");
          out.push("Lines scanned: " + r.lineCount);
          out.push("Heuristic text audit only — no PHP was run and nothing was uploaded. Secret values are masked.");
          out.push("");
          if (r.findings.length === 0) {
            out.push("No findings.");
          }
          for (var i = 0; i < r.findings.length; i++) {
            var f = r.findings[i];
            var where = f.line === null ? "Not present in file" : "Line " + f.line;
            out.push("[" + f.sev + "] " + where + " — " + f.title);
            out.push("    " + f.detail);
          }
          return out.join("\n");
        }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-wordpress-config-safety-auditor',
  name: 'J-Dawgs WordPress Config Safety Auditor',
  description: 'Live-site WordPress scanners need a published site and scan the running install; this grades a pasted wp-config.php anywhere, before deploy — WP_DEBUG, placeholder salts, the default wp_ prefix, file-edit posture, DB_PASSWORD flagged by name only with values masked — into one verdict. It runs no PHP',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
