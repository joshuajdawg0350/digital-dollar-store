'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Penpot Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var RISKY = [
        "PENPOT_PUBLIC_URI=http://design.example.internal",
        "PENPOT_FLAGS=enable-prepl enable-backend-api-doc",
        "PENPOT_SECRET_KEY=change-me-example",
        "PENPOT_DATABASE_URI=postgresql://penpot:dbpass123@postgres:5432/penpot",
        "PENPOT_REDIS_URI=redis://:redispass@redis:6379/0",
        "PENPOT_SMTP_HOST=smtp.example.internal",
        "PENPOT_SMTP_USERNAME=penpot@example.internal",
        "PENPOT_SMTP_PASSWORD=mailpass123",
        "PENPOT_DISABLE_EMAIL_CONFIRMATION=true",
        "PENPOT_TELEMETRY_ENABLED=true"
      ].join("\n");

      var HARDENED = [
        "PENPOT_PUBLIC_URI=https://design.example.com",
        "PENPOT_FLAGS=disable-prepl",
        "PENPOT_SECRET_KEY=a94f8c2e71b04d6f9a3c5e8207b1d94f6a0c3e5b7182d4f90a6c8e2b5071d3f4a6",
        "PENPOT_DATABASE_URI=postgresql://penpot:${PENPOT_DB_PASSWORD}@postgres:5432/penpot",
        "PENPOT_REDIS_URI=redis://:${PENPOT_REDIS_PASSWORD}@redis:6379/0",
        "PENPOT_SMTP_HOST=smtp.example.com",
        "PENPOT_SMTP_USERNAME=penpot@example.com",
        "PENPOT_SMTP_PASSWORD=${SMTP_PASSWORD_FROM_VAULT}",
        "PENPOT_DISABLE_EMAIL_CONFIRMATION=false",
        "PENPOT_ENABLE_PREPL=false",
        "PENPOT_TELEMETRY_ENABLED=false"
      ].join("\n");

      var PROSE = [
        "The design server is ready to launch tomorrow morning.",
        "Everything looked fine when we checked it last week.",
        "Ship it and we will deal with any problems after."
      ].join("\n");

      function isPlaceholder(v){ return v.indexOf("${") !== -1 || v === "***" || v === "REDACTED"; }
      function truthy(v){ var s = String(v).trim().toLowerCase(); return s==="true"||s==="1"||s==="yes"||s==="on"||s==="enabled"; }
      function falsy(v){ var s = String(v).trim().toLowerCase(); return s==="false"||s==="0"||s==="no"||s==="off"||s==="disabled"; }

      function parseConfig(text){
        var lines = String(text||"").split(/\r?\n/);
        var entries = [], unparsable = [];
        for (var i=0;i<lines.length;i++){
          var lineNo = i+1;
          var trimmed = lines[i].trim();
          if (!trimmed) continue;
          if (trimmed.charAt(0) === "#") continue;
          var s = trimmed.replace(/^-\s+/, "");
          if (/^[A-Za-z_][A-Za-z0-9_-]*:$/.test(s)) continue; /* structural YAML key, e.g. environment: */
          var m = s.match(/^([A-Za-z_][A-Za-z0-9_]*)\s*[:=]\s*(.*)$/);
          if (!m){ unparsable.push(lineNo); continue; }
          var value = m[2].trim();
          if (value.length>=2 && ((value.charAt(0)==='"' && value.charAt(value.length-1)==='"') || (value.charAt(0)==="'" && value.charAt(value.length-1)==="'"))){
            value = value.slice(1,-1);
          }
          value = value.replace(/,\s*$/, "");
          entries.push({ key: m[1].toUpperCase(), value: value, line: lineNo });
        }
        return { entries: entries, unparsable: unparsable, totalLines: lines.length };
      }

      function uriPassword(uri){
        var m = String(uri).match(/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\/([^\/]*)/);
        if (!m) return null;
        var authority = m[1];
        var at = authority.lastIndexOf("@");
        if (at === -1) return null;
        var userinfo = authority.slice(0, at);
        var colon = userinfo.indexOf(":");
        if (colon === -1) return null;
        var pw = userinfo.slice(colon+1);
        return pw.length ? pw : null;
      }

      function audit(text){
        var parsed = parseConfig(text);
        var entries = parsed.entries;
        var recognized = entries.filter(function(e){ return e.key.indexOf("PENPOT_") === 0; });
        var byKey = {};
        entries.forEach(function(e){ byKey[e.key] = e; });
        var findings = [];
        function add(sev, key, line, title, detail, fix){
          findings.push({ severity: sev, key: key, line: line, title: title, detail: detail, fix: fix });
        }

        if (recognized.length === 0){
          if (parsed.unparsable.length){
            add("info","—",null,"Nothing here could be read as a Penpot setting",
              "Lines " + parsed.unparsable.join(", ") + " could not be parsed as KEY=value or KEY: value settings, and no PENPOT_ setting was found at all.",
              "Paste the server configuration itself — the PENPOT_ environment lines from your .env file or docker-compose environment block.");
          } else {
            add("info","—",null,"No configuration was provided",
              "The input is empty (or only blank lines and comments), so there is nothing to grade.",
              "Paste the PENPOT_ environment lines from your .env file or docker-compose environment block.");
          }
          return finish("NOT ENOUGH TO GRADE", parsed, recognized, findings);
        }

        /* --- PENPOT_PUBLIC_URI --- */
        var uri = byKey["PENPOT_PUBLIC_URI"];
        if (!uri){
          add("warning","PENPOT_PUBLIC_URI",null,"No public URI is set",
            "PENPOT_PUBLIC_URI is missing, so Penpot will guess the address it is reached at — links in emails and shared files can come out wrong.",
            "Set PENPOT_PUBLIC_URI to the full https:// address users reach the server at.");
        } else if (/^http:\/\//i.test(uri.value)){
          var host = (uri.value.match(/^http:\/\/([^\/:?#]+)/i)||[])[1] || "";
          if (host === "localhost" || host === "127.0.0.1"){
            add("warning","PENPOT_PUBLIC_URI",uri.line,"Public URI uses http on localhost",
              "Line " + uri.line + ": PENPOT_PUBLIC_URI uses plain http. That is fine on localhost for a local test, and unsafe the moment the server is reachable from anywhere else.",
              "Keep http only for throwaway local tests; use https:// before anyone else can reach the server.");
          } else {
            add("critical","PENPOT_PUBLIC_URI",uri.line,"Public URI uses plain http, not https",
              "Line " + uri.line + ": PENPOT_PUBLIC_URI starts with http://, so logins, sessions, and files travel unencrypted and can be read or hijacked in transit.",
              "Put the server behind https (a reverse proxy with a TLS certificate) and set PENPOT_PUBLIC_URI to the https:// address.");
          }
        } else if (/^https:\/\//i.test(uri.value)){
          add("pass","PENPOT_PUBLIC_URI",uri.line,"Public URI uses https",
            "Line " + uri.line + ": PENPOT_PUBLIC_URI uses https://, so traffic is encrypted in transit.","No change needed.");
        } else {
          add("warning","PENPOT_PUBLIC_URI",uri.line,"Public URI has no http/https scheme",
            "Line " + uri.line + ": PENPOT_PUBLIC_URI does not start with https://, so it is unclear how users reach the server.",
            "Set PENPOT_PUBLIC_URI to the full address including https://.");
        }

        /* --- PREPL via flags and dedicated key --- */
        var flags = byKey["PENPOT_FLAGS"];
        var preplFound = false;
        if (flags){
          var tokens = flags.value.toLowerCase().split(/[^a-z0-9-]+/).filter(Boolean);
          if (tokens.indexOf("enable-prepl") !== -1){
            preplFound = true;
            add("critical","PENPOT_FLAGS",flags.line,"The enable-prepl flag is switched on",
              "Line " + flags.line + ": PENPOT_FLAGS contains enable-prepl. The prepl is a live REPL endpoint into the running server — anyone who can reach it can run code inside your Penpot instance.",
              "Remove enable-prepl from PENPOT_FLAGS. Only turn it on briefly, locally, while debugging — never on a deployed server.");
          }
          if (tokens.indexOf("disable-email-confirmation") !== -1){
            add("critical","PENPOT_FLAGS",flags.line,"Email confirmation is disabled by flag",
              "Line " + flags.line + ": PENPOT_FLAGS disables email confirmation, so accounts can be registered with email addresses the registrant does not own.",
              "Remove the disable-email-confirmation flag from PENPOT_FLAGS.");
          }
        }
        var preplKey = byKey["PENPOT_ENABLE_PREPL"];
        if (preplKey && truthy(preplKey.value)){
          preplFound = true;
          add("critical","PENPOT_ENABLE_PREPL",preplKey.line,"Prepl is enabled",
            "Line " + preplKey.line + ": PENPOT_ENABLE_PREPL is on. The prepl is a live REPL endpoint into the running server — anyone who can reach it can run code inside your Penpot instance.",
            "Set PENPOT_ENABLE_PREPL=false (or remove the line). Only enable it briefly, locally, while debugging.");
        }
        if (!preplFound){
          add("pass","PENPOT_FLAGS / PENPOT_ENABLE_PREPL", flags ? flags.line : (preplKey ? preplKey.line : null),
            "Prepl is not enabled",
            "Neither PENPOT_FLAGS nor PENPOT_ENABLE_PREPL turns the prepl endpoint on.","No change needed.");
        }

        /* --- PENPOT_SECRET_KEY (value never rendered) --- */
        var secret = byKey["PENPOT_SECRET_KEY"];
        if (!secret){
          add("critical","PENPOT_SECRET_KEY",null,"No secret key is set",
            "PENPOT_SECRET_KEY is missing. Penpot signs sessions and tokens with this key; without a strong one you set yourself, sessions can be forged.",
            "Generate a long random value (at least 32 characters, ideally 50+) and set it as PENPOT_SECRET_KEY. Keep it out of version control.");
        } else if (isPlaceholder(secret.value)){
          add("pass","PENPOT_SECRET_KEY",secret.line,"Secret key is referenced, not written out",
            "Line " + secret.line + ": PENPOT_SECRET_KEY (length " + secret.value.length + ") is a placeholder reference, so the real value lives outside this file. Its strength cannot be graded from the text.",
            "Make sure the referenced value is long, random, and unique to this server.");
        } else {
          var banned = ["change-me","changeme","change_me","example","secret","password","penpot","default","insecure","letmein","12345","test"];
          var low = secret.value.toLowerCase();
          var hit = null;
          banned.forEach(function(b){ if (!hit && low.indexOf(b) !== -1) hit = b; });
          if (hit || secret.value.length < 32){
            var reasons = [];
            if (secret.value.length < 32) reasons.push("it is only " + secret.value.length + " characters long (minimum 32, ideally 50+)");
            if (hit) reasons.push("it contains a common example / guessable word");
            add("critical","PENPOT_SECRET_KEY",secret.line,"Secret key is too weak",
              "Line " + secret.line + ": PENPOT_SECRET_KEY (length " + secret.value.length + ") fails because " + reasons.join(" and ") + ". Anyone who guesses this key can forge sessions. (The value itself is never shown in this audit.)",
              "Replace it with a long random value of at least 32 characters (ideally 50+) generated for this server only, and keep it out of version control.");
          } else {
            add("pass","PENPOT_SECRET_KEY",secret.line,"Secret key length looks sound",
              "Line " + secret.line + ": PENPOT_SECRET_KEY is " + secret.value.length + " characters long with no common example word found. (The value itself is never shown in this audit.)",
              "No change needed — keep it unique to this server and out of version control.");
          }
        }

        /* --- DATABASE / REDIS URI passwords (password never rendered) --- */
        [["PENPOT_DATABASE_URI","database"],["PENPOT_REDIS_URI","Redis"]].forEach(function(pair){
          var key = pair[0], label = pair[1];
          var e = byKey[key];
          if (!e){
            if (key === "PENPOT_DATABASE_URI"){
              add("warning",key,null,"No database URI is set",
                "PENPOT_DATABASE_URI is missing, so it is not clear this config points Penpot at its database at all.",
                "Set PENPOT_DATABASE_URI to your PostgreSQL connection string, with the password supplied by reference rather than written into the URI.");
            }
            return;
          }
          var pw = uriPassword(e.value);
          if (pw === null){
            add("pass",key,e.line,"No password written into the " + label + " URI",
              "Line " + e.line + ": " + key + " carries no embedded password, so there is no credential sitting in this file to leak.",
              "No change needed.");
          } else if (isPlaceholder(pw)){
            add("pass",key,e.line,label.charAt(0).toUpperCase()+label.slice(1) + " password is referenced, not written out",
              "Line " + e.line + ": the password inside " + key + " is a placeholder reference (length " + pw.length + "), so the real credential lives outside this file.",
              "No change needed — keep the real password in your secrets store.");
          } else {
            add("warning",key,e.line,"Plaintext password inside the " + label + " URI",
              "Line " + e.line + ": " + key + " embeds a literal password (length " + pw.length + ") in the connection string. Anyone who sees this file — a repo, a backup, a screenshot — has the " + label + " password. (The password itself is never shown in this audit.)",
              "Move the password out of the URI: supply it through a secrets store or an environment reference such as ${...} in place of the literal password, and rotate the password that was written here, since it has been exposed in plaintext.");
          }
        });

        /* --- Email confirmation --- */
        var dec = byKey["PENPOT_DISABLE_EMAIL_CONFIRMATION"];
        if (dec && truthy(dec.value)){
          add("critical","PENPOT_DISABLE_EMAIL_CONFIRMATION",dec.line,"Email confirmation is disabled",
            "Line " + dec.line + ": PENPOT_DISABLE_EMAIL_CONFIRMATION is true, so anyone can register an account with an email address they do not own — a standing invitation to spam and impersonation accounts.",
            "Set PENPOT_DISABLE_EMAIL_CONFIRMATION=false (or remove the line) and make sure SMTP is configured so confirmation emails can actually be sent.");
        } else if (dec){
          add("pass","PENPOT_DISABLE_EMAIL_CONFIRMATION",dec.line,"Email confirmation is required",
            "Line " + dec.line + ": PENPOT_DISABLE_EMAIL_CONFIRMATION is not true, so new accounts must confirm their email address.","No change needed.");
        }

        /* --- SMTP password (value never rendered) --- */
        Object.keys(byKey).forEach(function(k){
          if (k.indexOf("PENPOT_SMTP_") === 0 && (k.indexOf("PASSWORD") !== -1 || k.indexOf("PASS") !== -1)){
            var e = byKey[k];
            if (isPlaceholder(e.value)){
              add("pass",k,e.line,"SMTP password is referenced, not written out",
                "Line " + e.line + ": " + k + " (length " + e.value.length + ") is a placeholder reference, so the real credential lives outside this file.","No change needed.");
            } else if (e.value.length){
              add("warning",k,e.line,"SMTP password sits in plaintext",
                "Line " + e.line + ": " + k + " holds a literal password (length " + e.value.length + ") in the config. Anyone who sees this file can send mail as your server. (The password itself is never shown in this audit.)",
                "Move the SMTP password into a secrets store or an environment reference such as ${...}, and rotate the password that was written here.");
            }
          }
        });

        /* --- Telemetry --- */
        var tel = byKey["PENPOT_TELEMETRY_ENABLED"];
        if (tel && truthy(tel.value)){
          add("warning","PENPOT_TELEMETRY_ENABLED",tel.line,"Telemetry is switched on",
            "Line " + tel.line + ": PENPOT_TELEMETRY_ENABLED is true, so the server sends telemetry data to the Penpot project. That may be fine — but it should be a decision, not a leftover default.",
            "If you do not want the server reporting telemetry, set PENPOT_TELEMETRY_ENABLED=false.");
        } else if (tel){
          add("pass","PENPOT_TELEMETRY_ENABLED",tel.line,"Telemetry is off",
            "Line " + tel.line + ": PENPOT_TELEMETRY_ENABLED is not true, so the server does not send telemetry.","No change needed.");
        }

        /* --- Unparsable lines --- */
        if (parsed.unparsable.length){
          add("info","—",null,"Some lines could not be parsed",
            "Lines " + parsed.unparsable.join(", ") + " are not KEY=value or KEY: value settings, so they were not graded. Their contents are not reproduced here.",
            "Check those lines in your file — if any of them was meant to be a setting, rewrite it as KEY=value.");
        }

        var crit = findings.filter(function(f){return f.severity==="critical";}).length;
        var warn = findings.filter(function(f){return f.severity==="warning";}).length;
        var verdict = crit > 0 ? "DO NOT DEPLOY" : (warn > 0 ? "DEPLOY WITH FIXES" : "SAFE TO DEPLOY");
        return finish(verdict, parsed, recognized, findings);
      }

      function finish(verdict, parsed, recognized, findings){
        var order = { critical:0, warning:1, info:2, pass:3 };
        findings.sort(function(a,b){ return order[a.severity]-order[b.severity] || ((a.line||9999)-(b.line||9999)); });
        return {
          verdict: verdict,
          counts: {
            critical: findings.filter(function(f){return f.severity==="critical";}).length,
            warning: findings.filter(function(f){return f.severity==="warning";}).length,
            info: findings.filter(function(f){return f.severity==="info";}).length,
            pass: findings.filter(function(f){return f.severity==="pass";}).length
          },
          parsedKeys: recognized.map(function(e){ return { key: e.key, line: e.line, valueLength: e.value.length }; }),
          unparsableLines: parsed.unparsable,
          findings: findings
        };
      }

      function buildTextReport(r){
        var out = [];
        out.push("J-Dawgs Penpot Server Config Safety Auditor\u2122 \u2014 audit report");
        out.push("Verdict: " + r.verdict);
        out.push("Findings: " + r.counts.critical + " critical, " + r.counts.warning + " warning, " + r.counts.info + " info, " + r.counts.pass + " passed.");
        out.push("Secrets: values are never included in this report. Secrets are reported by key name, line number, and length only.");
        out.push("");
        if (r.parsedKeys.length){
          out.push("Settings read (key, line, value length):");
          r.parsedKeys.forEach(function(k){ out.push("  - " + k.key + " \u2014 line " + k.line + ", value length " + k.valueLength); });
          out.push("");
        }
        if (r.unparsableLines.length){
          out.push("Unparsable lines (numbers only): " + r.unparsableLines.join(", "));
          out.push("");
        }
        out.push("Findings:");
        r.findings.forEach(function(f,i){
          out.push((i+1) + ". [" + f.severity.toUpperCase() + "] " + f.title + (f.line ? " (" + f.key + ", line " + f.line + ")" : " (" + f.key + ")"));
          out.push("   " + f.detail);
          out.push("   Fix: " + f.fix);
        });
        out.push("");
        out.push("Scope: offline text audit only. This tool does not start Penpot, connect to any server, or verify a live deployment.");
        return out.join("\n");
      }

      function buildJson(r){
        return JSON.stringify({
          tool: "J-Dawgs Penpot Server Config Safety Auditor\u2122",
          scope: "Offline text audit only. Does not start Penpot, connect to any server, or verify a live deployment.",
          secretsPolicy: "Secret values are never included. Secrets are reported by key name, line number, and length only.",
          verdict: r.verdict,
          counts: r.counts,
          parsedKeys: r.parsedKeys,
          unparsableLines: r.unparsableLines,
          findings: r.findings
        }, null, 2);
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-penpot-server-config-safety-auditortm',
  name: 'J-Dawgs Penpot Server Config Safety Auditor',
  description: 'Host tools only tell you the server started; ours grades a pasted Penpot server config offline into one deploy verdict — secrets by key name/line/length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
