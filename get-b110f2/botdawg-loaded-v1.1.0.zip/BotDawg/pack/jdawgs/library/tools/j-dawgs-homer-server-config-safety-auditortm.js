'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Homer Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Worked examples ---------- */

      var RISKY = [
        '# Risky worked example — a Homer config with planted problems.',
        '# The password and tokens below are FAKE, planted for grading practice.',
        'title: "Home Server"',
        'subtitle: "Everything on one page"',
        'logo: "assets/logo.png"',
        'services:',
        '  - name: "Admin Panels"',
        '    icon: "fas fa-server"',
        '    items:',
        '      - name: "Router"',
        '        subtitle: "Gateway console"',
        '        url: "http://192.168.1.1/admin"',
        '      - name: "NAS"',
        '        subtitle: "File station"',
        '        url: "http://admin:FAKEpass7391@192.168.1.50:5000/"',
        '      - name: "Plex"',
        '        subtitle: "Media server"',
        '        url: "https://plex.example.com/web?token=FAKEtokenAbCdEf123456"',
        '      - name: "Portainer"',
        '        subtitle: "Docker console"',
        '        url: "http://10.0.0.8:9000"',
        '        api_key: "FAKEapikeyXYZ987654321"',
        '      - name: "Public Docs"',
        '        subtitle: "External reference"',
        '        url: "https://example.com/docs"',
        'this line is not yaml and cannot be parsed'
      ].join("\n");
      /* Line map for the risky example (1-based):
         12 http + private 192.168.1.1 · 15 embedded credentials (password length 12) + http + private
         18 token query parameter (value length 21) · 21 http + private 10.0.0.8
         22 api_key field (value length 22) · 26 NOT PARSED · no proxy/auth mention anywhere */

      var HARDENED = [
        '# Hardened example — the same dashboard, cleaned up.',
        '# Homer has no login of its own: this page is served only behind',
        '# Traefik reverse proxy with Authelia forward-auth (oauth2) required.',
        'title: "Home Server"',
        'subtitle: "Everything on one page"',
        'logo: "assets/logo.png"',
        'services:',
        '  - name: "Admin Panels"',
        '    icon: "fas fa-server"',
        '    items:',
        '      - name: "Router"',
        '        subtitle: "Gateway console"',
        '        url: "https://router.home.example.com/admin"',
        '      - name: "NAS"',
        '        subtitle: "File station"',
        '        url: "https://nas.home.example.com/"',
        '      - name: "Plex"',
        '        subtitle: "Media server"',
        '        url: "https://plex.example.com/web"',
        '      - name: "Public Docs"',
        '        subtitle: "External reference"',
        '        url: "https://example.com/docs"'
      ].join("\n");

      var FIXES_CASE = [
        'title: "Home"',
        '# Served behind nginx reverse proxy with basic_auth required.',
        'services:',
        '  - name: "Links"',
        '    items:',
        '      - name: "Blog"',
        '        url: "http://blog.example.com/"',
        '      - name: "Docs"',
        '        url: "https://example.com/docs"'
      ].join("\n");

      var NON_HOMER = [
        "Grandma's pancake recipe",
        'Mix flour, eggs and milk in a big bowl.',
        'Fry on a hot pan until golden on both sides.',
        'Serve with butter and syrup.'
      ].join("\n");

      var PLANTED_SECRETS = ["FAKEpass7391", "FAKEtokenAbCdEf123456", "FAKEapikeyXYZ987654321"];

      /* ---------- Helpers ---------- */

      function classifyHost(host){
        if(!host) return {internal:false, kind:"unknown"};
        var h = host.toLowerCase();
        if(h === "localhost" || h === "::1" || h === "[::1]") return {internal:true, kind:"loopback"};
        if(/^(127\.)/.test(h)) return {internal:true, kind:"loopback"};
        if(/^169\.254\./.test(h) || /^fe80:/i.test(h)) return {internal:true, kind:"link-local"};
        if(/^0\.0\.0\.0$/.test(h)) return {internal:true, kind:"loopback"};
        var m = h.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
        if(m){
          var a = +m[1], b = +m[2];
          if(a === 10) return {internal:true, kind:"private"};
          if(a === 172 && b >= 16 && b <= 31) return {internal:true, kind:"private"};
          if(a === 192 && b === 168) return {internal:true, kind:"private"};
          return {internal:false, kind:"public-ip"};
        }
        if(/\.(local|lan|internal|home\.arpa|intranet)$/.test(h)) return {internal:true, kind:"internal-name"};
        return {internal:false, kind:"public"};
      }

      function parseUrl(raw){
        var m = raw.match(/^(https?):\/\/([^\/?#\s]+)([^\s]*)$/i);
        if(!m) return null;
        var scheme = m[1].toLowerCase();
        var authority = m[2];
        var rest = m[3] || "";
        var userinfo = null, hostport = authority;
        var at = authority.lastIndexOf("@");
        if(at >= 0){ userinfo = authority.slice(0, at); hostport = authority.slice(at + 1); }
        var host = hostport, port = null;
        if(hostport.charAt(0) === "["){
          var close = hostport.indexOf("]");
          host = hostport.slice(0, close + 1);
          if(hostport.charAt(close + 1) === ":") port = hostport.slice(close + 2);
        } else {
          var ci = hostport.lastIndexOf(":");
          if(ci >= 0 && /^\d+$/.test(hostport.slice(ci + 1))){ host = hostport.slice(0, ci); port = hostport.slice(ci + 1); }
        }
        var query = "";
        var qi = rest.indexOf("?");
        if(qi >= 0){ query = rest.slice(qi + 1).split("#")[0]; }
        var credLen = 0, userLen = 0;
        if(userinfo !== null){
          var c = userinfo.indexOf(":");
          if(c >= 0){ userLen = c; credLen = userinfo.length - c - 1; }
          else { userLen = userinfo.length; }
        }
        return { scheme:scheme, host:host, port:port, query:query,
                 hasUserinfo: userinfo !== null, userLen:userLen, credLen:credLen };
      }

      var TOKEN_KEY = /^(token|access[-_]?token|api[-_]?key|apikey|secret|client[-_]?secret|password|passwd|auth|session|access[-_]?key|key)$/i;
      var FIELD_KEY = /^(api[-_]?key|apikey|access[-_]?token|token|secret|client[-_]?secret|password|passwd)$/i;
      var POSTURE = /authelia|authentik|forward[-_ ]?auth|basic[-_ ]?auth|oauth|oidc|reverse[-_ ]?proxy|traefik|nginx|caddy|cloudflare access|wireguard|tailscale|\bvpn\b|allowlist|whitelist|single sign[- ]on|\bsso\b/i;
      var PLACEHOLDER = /^(changeme|change[-_ ]me|example|placeholder|xxx+|\*+|redacted|your[-_ ].*|none|null|true|false)$/i;

      /* ---------- Auditor ---------- */

      function audit(text){
        var findings = [];
        function add(sev, check, service, line, detail){
          findings.push({severity:sev, check:check, service:service || "(unknown)", line:line, detail:detail});
        }
        var raw = (text == null ? "" : String(text));
        if(raw.trim() === ""){
          return { gradeable:false, reason:"empty", verdict:"NOT ENOUGH TO GRADE",
                   findings:[], notParsed:[], counts:{critical:0,high:0,medium:0,low:0,info:0},
                   urls:0, https:0, http:0, linkMix:{internal:0, external:0}, proxyAuthMentioned:false, services:0 };
        }
        var homerSignal = /(^|\n)\s*services\s*:/.test(raw) || /(^|\n)\s*items\s*:/.test(raw)
          || /homer/i.test(raw) || /b4bz\/homer/.test(raw)
          || (/subtitle\s*:/.test(raw) && /url\s*:/.test(raw));
        var lines = raw.split(/\r?\n/);
        var notParsed = [];
        var currentService = "(unknown)";
        var serviceNames = {};
        var urlCount = 0, httpsCount = 0, httpCount = 0;
        var internal = 0, external = 0;
        var proxyAuth = POSTURE.test(raw);

        for(var i = 0; i < lines.length; i++){
          var lineNo = i + 1;
          var line = lines[i];
          var trimmed = line.trim();
          if(trimmed === "") continue;
          if(trimmed.charAt(0) === "#") continue;

          /* service / item name tracking */
          var nm = line.match(/(?:^|\s)name\s*:\s*"?([^"\n]+?)"?\s*$/);
          if(nm){ currentService = nm[1].trim(); serviceNames[currentService] = true; }

          /* parsability */
          var isList = /^\s*-\s+\S/.test(line);
          var isKey = /^\s*[A-Za-z0-9_."'\-]+\s*:\s*(.*)$/.test(line);
          var isEnv = /^\s*[A-Za-z_][A-Za-z0-9_]*\s*=/.test(line);
          var hasUrl = /https?:\/\//i.test(line);
          if(!isList && !isKey && !isEnv && !hasUrl){
            notParsed.push(lineNo);
            add("medium", "not-parsed", currentService, lineNo,
                "Line could not be parsed as config text — reported as NOT PARSED. Check it by hand; the grader skipped its content.");
            continue;
          }

          /* secret-bearing fields (non-URL lines) */
          if(!hasUrl){
            var fm = line.match(/^\s*-?\s*"?([A-Za-z0-9_\-]+)"?\s*[:=]\s*(.+?)\s*$/);
            if(fm && FIELD_KEY.test(fm[1])){
              var val = fm[2].replace(/^["']|["']$/g, "");
              if(val.length >= 4 && !PLACEHOLDER.test(val)){
                add("critical", "secret-field", currentService, lineNo,
                    "Field \"" + fm[1] + "\" holds a secret value of length " + val.length +
                    " in plain text. The value is never shown here — move it out of the dashboard config.");
              }
            }
          }

          /* URLs on this line */
          var urlMatches = line.match(/https?:\/\/[^\s"'\]<>,]+/gi) || [];
          for(var u = 0; u < urlMatches.length; u++){
            var p = parseUrl(urlMatches[u].replace(/[)\].,;]+$/, ""));
            if(!p) continue;
            urlCount++;
            var cls = classifyHost(p.host);
            if(cls.internal) internal++; else external++;
            var hostLabel = p.host + (p.port ? ":" + p.port : "");

            if(p.hasUserinfo && p.credLen > 0){
              add("critical", "embedded-credentials", currentService, lineNo,
                  "URL for " + hostLabel + " embeds a password of length " + p.credLen +
                  " (username length " + p.userLen + "). The credential itself is never shown — remove it from the URL.");
            } else if(p.hasUserinfo){
              add("high", "embedded-username", currentService, lineNo,
                  "URL for " + hostLabel + " embeds a username in the address. Remove userinfo from dashboard URLs.");
            }

            if(p.scheme === "http"){
              httpCount++;
              add(cls.internal ? "high" : "medium", "plain-http", currentService, lineNo,
                  "Service URL uses plain http:// to " + hostLabel +
                  (cls.internal ? " — an internal target, so credentials and sessions cross the network unencrypted."
                                 : " — traffic to this link is unencrypted."));
            } else { httpsCount++; }

            if(cls.internal){
              add(p.scheme === "http" ? "high" : "medium", "internal-target", currentService, lineNo,
                  "Service URL points at a " + cls.kind + " target (" + hostLabel +
                  "). If this dashboard is reachable from the internet, this link advertises an internal admin surface.");
            }

            if(p.query){
              var pairs = p.query.split("&");
              for(var q = 0; q < pairs.length; q++){
                var eq = pairs[q].indexOf("=");
                var k = eq >= 0 ? pairs[q].slice(0, eq) : pairs[q];
                var v = eq >= 0 ? pairs[q].slice(eq + 1) : "";
                var keyName = k;
                try { keyName = decodeURIComponent(k); } catch(e){}
                if(TOKEN_KEY.test(keyName) && v.length >= 4 && !PLACEHOLDER.test(v)){
                  add("critical", "token-in-url", currentService, lineNo,
                      "URL query parameter \"" + keyName + "\" carries a secret value of length " + v.length +
                      ". URLs get logged, bookmarked and shared — the value is never shown here; move it out of the link.");
                }
              }
            }
          }
        }

        if(!homerSignal){
          return { gradeable:false, reason:"not-homer", verdict:"NOT ENOUGH TO GRADE",
                   findings:[], notParsed:notParsed, counts:{critical:0,high:0,medium:0,low:0,info:0},
                   urls:urlCount, https:httpsCount, http:httpCount,
                   linkMix:{internal:internal, external:external}, proxyAuthMentioned:proxyAuth,
                   services:Object.keys(serviceNames).length };
        }

        if(!proxyAuth){
          add("high", "no-proxy-auth", "(whole config)", 0,
              "Nothing in the pasted text mentions a reverse proxy, forward-auth, basic auth, OAuth/OIDC, SSO, VPN or an allowlist. Homer has no login of its own — without a proxy in front of it, anyone who can reach the page sees every link on it.");
        }
        if(internal > 0 && external > 0){
          add("info", "link-mix", "(whole config)", 0,
              "Link mix: " + internal + " internal target(s) and " + external +
              " external target(s) share one page. Internal admin links on an internet-facing dashboard are a map of your network.");
        } else if(urlCount > 0){
          add("info", "link-mix", "(whole config)", 0,
              "Link mix: " + internal + " internal target(s) and " + external + " external target(s).");
        }

        var counts = {critical:0, high:0, medium:0, low:0, info:0};
        findings.forEach(function(f){ counts[f.severity] = (counts[f.severity] || 0) + 1; });
        findings.sort(function(a, b){
          var order = {critical:0, high:1, medium:2, low:3, info:4};
          if(order[a.severity] !== order[b.severity]) return order[a.severity] - order[b.severity];
          return (a.line || 0) - (b.line || 0);
        });

        var verdict;
        if(counts.critical > 0) verdict = "DO NOT DEPLOY";
        else if(counts.high > 0 || counts.medium > 0) verdict = "DEPLOY WITH FIXES";
        else verdict = "SAFE TO DEPLOY";

        return { gradeable:true, reason:"ok", verdict:verdict, findings:findings, notParsed:notParsed,
                 counts:counts, urls:urlCount, https:httpsCount, http:httpCount,
                 linkMix:{internal:internal, external:external}, proxyAuthMentioned:proxyAuth,
                 services:Object.keys(serviceNames).length };
      }

      /* ---------- Rendering ---------- */

      var VERDICT_CLASS = { "SAFE TO DEPLOY":"v-safe", "DEPLOY WITH FIXES":"v-fixes",
                            "DO NOT DEPLOY":"v-no", "NOT ENOUGH TO GRADE":"v-neg" };
      var VERDICT_BLURB = {
        "SAFE TO DEPLOY": "No check tripped on the pasted text. Homer still has no login of its own — keep it behind your authenticated reverse proxy.",
        "DEPLOY WITH FIXES": "Nothing fatal, but fix the findings below before this goes in front of other people.",
        "DO NOT DEPLOY": "Secrets or exposed internal surfaces were found in the pasted text. Fix the critical findings before this config goes anywhere.",
        "NOT ENOUGH TO GRADE": "The paste was empty or does not look like a Homer configuration, so there is nothing honest to grade."
      };

      function esc(s){ return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;"); }

      function toJSON(r){
        return {
          tool: "J-Dawgs Homer Server Config Safety Auditor",
          mode: "offline-heuristic-text-grading",
          gradeable: r.gradeable,
          verdict: r.verdict,
          counts: r.counts,
          urlsChecked: r.urls,
          httpsUrls: r.https,
          httpUrls: r.http,
          servicesSeen: r.services,
          linkMix: r.linkMix,
          proxyAuthMentioned: r.proxyAuthMentioned,
          notParsedLines: r.notParsed,
          findings: r.findings.map(function(f){
            return { severity:f.severity, check:f.check, service:f.service,
                     line: f.line > 0 ? f.line : null, detail:f.detail };
          }),
          note: "Secret values are never included: findings carry service name, line number and value length only."
        };
      }

      function toReport(r){
        var j = toJSON(r);
        var out = [];
        out.push("J-Dawgs Homer Server Config Safety Auditor — deploy report");
        out.push("Verdict: " + j.verdict);
        out.push("URLs checked: " + j.urlsChecked + " (https " + j.httpsUrls + ", http " + j.httpUrls + ")");
        out.push("Link mix: " + j.linkMix.internal + " internal, " + j.linkMix.external + " external");
        out.push("Reverse-proxy / auth mentioned: " + (j.proxyAuthMentioned ? "yes" : "no"));
        out.push("Findings: " + j.counts.critical + " critical, " + j.counts.high + " high, " +
                 j.counts.medium + " medium, " + j.counts.low + " low, " + j.counts.info + " info");
        if(j.notParsedLines.length) out.push("NOT PARSED lines: " + j.notParsedLines.join(", "));
        out.push("");
        if(j.findings.length === 0){ out.push("No findings."); }
        j.findings.forEach(function(f){
          out.push("[" + f.severity.toUpperCase() + "] " + (f.line ? "Line " + f.line + " · " : "") +
                   f.service + " · " + f.check + " — " + f.detail);
        });
        out.push("");
        out.push("Heuristic text grading, not a real YAML parser. Secret values are never shown.");
        return out.join("\n");
      }

      var lastResult = null;
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-homer-server-config-safety-auditortm',
  name: 'J-Dawgs Homer Server Config Safety Auditor',
  description: 'Grades a pasted Homer dashboard config offline into one deploy verdict — credentials embedded in service URLs, http links to internal panels, token fields, and missing proxy-auth posture checked, with secrets shown by name, line, and length only. Homer only exercises a config by serving the dashboar',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
