'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Deck Installation Proposal, Work Record & Final Invoice Consistency Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";
/* ---------- formatting helpers ---------- */
function fmt(n){ return "$" + Math.abs(n).toLocaleString("en-US",{minimumFractionDigits:2,maximumFractionDigits:2}); }
function num(n){ return Number(n).toLocaleString("en-US",{maximumFractionDigits:2}); }
function round2(n){ return Math.round(n*100)/100; }

/* ---------- parsing ---------- */
function moneyVals(line){
  var out=[], m, re=/(-)?\s*\$\s*(-?[\d,]+\.?\d*)/g;
  while((m=re.exec(line))!==null){
    var v=parseFloat(m[2].replace(/,/g,""));
    if(m[1]==="-" && v>0) v=-v; /* a minus written before the $, as in -$1,500.00 */
    out.push(v);
  }
  return out;
}
function extractQty(line){
  var pats=[
    /qty[:\s]*([\d,]+\.?\d*)/i,
    /([\d,]+\.?\d*)\s*(?:sq\.?\s*ft|square feet|linear\s*ft|lin\.?\s*ft|posts?|footings?|boards?|steps?|stairs?|hours?|hrs?)\b/i,
    /([\d,]+\.?\d*)\s*[x\u00d7]\b/i
  ];
  for(var i=0;i<pats.length;i++){ var m=line.match(pats[i]); if(m) return parseFloat(m[1].replace(/,/g,"")); }
  return null;
}
function extractUnit(line){
  var m=line.match(/@\s*\$?\s*([\d,]+\.?\d*)/);
  if(m) return parseFloat(m[1].replace(/,/g,""));
  m=line.match(/rate[:\s]*\$?\s*([\d,]+\.?\d*)/i);
  if(m) return parseFloat(m[1].replace(/,/g,""));
  m=line.match(/\$\s*([\d,]+\.?\d*)\s*(?:each|per|\/)/i);
  if(m) return parseFloat(m[1].replace(/,/g,""));
  return null;
}
function classify(line){
  var s=line.toLowerCase();
  if(/deposit/.test(s)) return "deposit";
  if(/permit/.test(s)) return "permit";
  if(/labor|labour/.test(s)) return "labor";
  if(/footing/.test(s)) return "footings";
  if(/railing|\brail\b/.test(s)) return "railing";
  if(/stair|step/.test(s)) return "stairs";
  if(/\bposts?\b/.test(s)) return "posts";
  if(/deck board|decking|deck surface|sq\.?\s*ft|square feet/.test(s)) return "decking";
  if(/total|balance|amount due/.test(s)) return "total";
  if(/fee|charge|surcharge/.test(s)) return "fee";
  return "other";
}
function parseDoc(text){
  var doc={ items:{}, fees:[], totals:[], raw:text||"" };
  var lines=(text||"").split(/\r?\n/);
  for(var i=0;i<lines.length;i++){
    var raw=lines[i].trim(); if(!raw) continue;
    var cat=classify(raw);
    var mv=moneyVals(raw);
    var qty=extractQty(raw), unit=extractUnit(raw);
    /* A stated line total exists only when the line says so explicitly:
       a money figure after "=", or a second money figure beyond the unit
       rate. A rate-only line such as "36 hours @ $65.00" states no total. */
    var statedTotal=null;
    var eqIdx=raw.indexOf("=");
    if(eqIdx>=0){
      var afterEq=moneyVals(raw.slice(eqIdx+1));
      if(afterEq.length) statedTotal=afterEq[afterEq.length-1];
    } else if(unit!==null){
      if(mv.length>=2) statedTotal=mv[mv.length-1];
    } else if(mv.length){
      statedTotal=mv[mv.length-1];
    }
    var item={ raw:raw, cat:cat, qty:qty, unit:unit, total:statedTotal, monies:mv };
    if(cat==="fee"){ doc.fees.push(item); }
    else if(cat==="total"){ doc.totals.push(item); }
    else {
      if(!doc.items[cat]) doc.items[cat]=[];
      doc.items[cat].push(item);
    }
  }
  return doc;
}
function firstItem(doc,cat){ return (doc.items[cat]&&doc.items[cat][0])||null; }
function sumCat(doc,cat){
  var arr=doc.items[cat]||[], s=0, found=false;
  for(var i=0;i<arr.length;i++){ if(arr[i].total!==null){ s+=arr[i].total; found=true; } }
  return found? s : null;
}
var MATERIALS=[
  ["composite",/composite/i],
  ["pressure-treated",/pressure[\s-]?treated/i],
  ["cedar",/cedar/i],
  ["redwood",/redwood/i],
  ["PVC / vinyl",/\bpvc\b|vinyl/i],
  ["aluminum",/aluminum|aluminium/i]
];
function matsIn(text){
  var out=[];
  for(var i=0;i<MATERIALS.length;i++){ if(MATERIALS[i][1].test(text||"")) out.push(MATERIALS[i][0]); }
  return out;
}
function overlap(a,b){ for(var i=0;i<a.length;i++){ if(b.indexOf(a[i])>=0) return true; } return false; }

/* ---------- the audit ---------- */
var CAT_LABEL={ decking:"Decking (boards / sq ft)", posts:"Posts", footings:"Footings", railing:"Railing (linear ft)", stairs:"Stairs / steps" };

function audit(pText,wText,iText){
  var findings=[];
  var docsPresent=0;
  if((pText||"").trim()) docsPresent++;
  if((wText||"").trim()) docsPresent++;
  if((iText||"").trim()) docsPresent++;
  if(docsPresent<2){
    return { verdict:"NOT ENOUGH TO COMPARE", overcharge:0, findings:[], docsPresent:docsPresent,
      note:"Only "+docsPresent+" of 3 documents were pasted. Cross-checking needs at least two documents — ideally all three." };
  }
  var P=parseDoc(pText), W=parseDoc(wText), I=parseDoc(iText);
  var over=0;
  function add(title,detail,amount,sev){
    findings.push({title:title,detail:detail,amount:(amount===null?null:round2(amount)),sev:sev});
    if(amount!==null && amount>0) over=round2(over+amount);
  }

  /* 1 · quantities billed above recorded */
  var cats=["decking","posts","footings","railing","stairs"];
  for(var c=0;c<cats.length;c++){
    var cat=cats[c], inv=firstItem(I,cat), rec=firstItem(W,cat);
    if(inv && rec && inv.qty!==null && rec.qty!==null && inv.qty>rec.qty+0.001){
      var unit=inv.unit;
      if(unit===null && inv.total!==null && inv.qty) unit=round2(inv.total/inv.qty);
      var diff=round2(inv.qty-rec.qty);
      if(unit!==null){
        add(CAT_LABEL[cat]+" — billed above installed",
          "Invoice bills "+num(inv.qty)+" but the work record shows "+num(rec.qty)+" installed. Excess: "+num(inv.qty)+" \u2212 "+num(rec.qty)+" = "+num(diff)+", at "+fmt(unit)+" each = "+fmt(diff*unit)+" billed for quantity the record does not show.",
          diff*unit,"high");
      } else {
        add(CAT_LABEL[cat]+" — billed above installed",
          "Invoice bills "+num(inv.qty)+" but the work record shows "+num(rec.qty)+" installed (excess "+num(diff)+"). No unit price appears in the pasted text, so this is flagged without a dollar figure.",
          null,"high");
      }
    }
  }

  /* 2 · material mismatch (flagged by name, never priced without price evidence) */
  var pM=matsIn(pText), wM=matsIn(wText), iM=matsIn(iText);
  var swapParts=[];
  if(pM.length && wM.length && !overlap(pM,wM)) swapParts.push("proposed "+pM.join(", ")+" but recorded "+wM.join(", "));
  if(iM.length && wM.length && !overlap(iM,wM)) swapParts.push("billed "+iM.join(", ")+" but recorded "+wM.join(", "));
  if(swapParts.length){
    add("Material mismatch — "+swapParts.join("; "),
      "The documents name different decking materials: "+swapParts.join("; ")+". No price difference between these materials appears in the pasted text, so this finding is flagged by name only and adds nothing to the overcharge total. Do not settle until the material on the invoice matches the material in the record.",
      null,"high");
  }

  /* 3 · labor billed above recorded hours x rate */
  var invL=firstItem(I,"labor"), recL=firstItem(W,"labor");
  if(invL && recL && invL.qty!==null && recL.qty!==null && invL.qty>recL.qty+0.001){
    var rate=invL.unit!==null? invL.unit : recL.unit;
    if(rate!==null){
      var billedVal=invL.total!==null? invL.total : round2(invL.qty*rate);
      var recVal=round2(recL.qty*rate);
      var laborOver=round2(billedVal-recVal);
      if(laborOver>0){
        add("Labor — billed above recorded hours \u00d7 rate",
          "Invoice bills "+num(invL.qty)+" hours; the work record shows "+num(recL.qty)+" hours worked. Recorded value: "+num(recL.qty)+" \u00d7 "+fmt(rate)+" = "+fmt(recVal)+". Billed: "+fmt(billedVal)+". Difference: "+fmt(billedVal)+" \u2212 "+fmt(recVal)+" = "+fmt(laborOver)+".",
          laborOver,"high");
      }
    } else if(invL.total!==null){
      add("Labor — billed hours above recorded hours",
        "Invoice bills "+num(invL.qty)+" hours; the work record shows "+num(recL.qty)+" hours worked. No hourly rate appears in the pasted text, so this is flagged without a dollar figure.",
        null,"high");
    }
  }

  /* 4 · permit fees duplicated */
  var invPermit=sumCat(I,"permit"), invPermitCount=(I.items["permit"]||[]).length;
  var basePermit=sumCat(P,"permit"); if(basePermit===null) basePermit=sumCat(W,"permit");
  if(invPermit!==null && basePermit!==null && invPermit>basePermit+0.01){
    add("Permit fee — charged more than once",
      "The invoice carries "+invPermitCount+" permit line(s) totalling "+fmt(invPermit)+", while the proposal / work record shows the permit once at "+fmt(basePermit)+". Duplicate amount: "+fmt(invPermit)+" \u2212 "+fmt(basePermit)+" = "+fmt(invPermit-basePermit)+".",
      invPermit-basePermit,"med");
  } else if(invPermitCount>1 && invPermit!==null){
    add("Permit fee — appears "+invPermitCount+" times on the invoice",
      "The invoice lists the permit "+invPermitCount+" times, totalling "+fmt(invPermit)+". No single permit figure appears in the other documents to price the duplicate against, so this is flagged without adding to the total.",
      null,"med");
  }

  /* 5 · deposit paid but not credited */
  var paidDep=null;
  var pDep=sumCat(P,"deposit"), wDep=sumCat(W,"deposit");
  if(pDep!==null) paidDep=pDep;
  if(wDep!==null) paidDep=(paidDep===null? wDep : Math.max(paidDep,wDep));
  var iDep=sumCat(I,"deposit");
  var credited=(iDep===null? 0 : Math.abs(iDep));
  if(paidDep!==null && paidDep>0 && credited<paidDep-0.01){
    add("Deposit — paid but not credited on the invoice",
      "Documents show a deposit paid of "+fmt(paidDep)+". The invoice credits "+fmt(credited)+" of it. Missing credit: "+fmt(paidDep)+" \u2212 "+fmt(credited)+" = "+fmt(paidDep-credited)+".",
      paidDep-credited,"high");
  }

  /* 6 · invoice-only fees */
  var otherText=((pText||"")+" \n "+(wText||"")).toLowerCase();
  for(var f=0;f<I.fees.length;f++){
    var fee=I.fees[f]; if(fee.total===null) continue;
    var stemM=fee.raw.toLowerCase().match(/([a-z][a-z\- ]*?)\s*(?:fee|charge|surcharge)/);
    var stem=stemM? stemM[1].trim().split(/\s+/).pop() : "";
    if(stem && otherText.indexOf(stem)<0){
      add("Invoice-only fee — \""+fee.raw.replace(/\s+/g," ").slice(0,60)+"\"",
        "This fee of "+fmt(fee.total)+" appears on the final invoice and in neither the proposal nor the work record (the word \""+stem+"\" appears in neither document). Full amount counted: "+fmt(fee.total)+".",
        fee.total,"med");
    } else if(!stem){
      add("Invoice-only fee — \""+fee.raw.replace(/\s+/g," ").slice(0,60)+"\"",
        "This fee of "+fmt(fee.total)+" appears on the final invoice; it could not be matched to any line in the proposal or work record. Full amount counted: "+fmt(fee.total)+".",
        fee.total,"med");
    }
  }

  /* 7 · arithmetic errors in line totals (all documents; only invoice overstatements are priced) */
  var docList=[["Proposal",P],["Work Record",W],["Final Invoice",I]];
  for(var d=0;d<docList.length;d++){
    var dname=docList[d][0], ddoc=docList[d][1];
    var allItems=[];
    for(var k in ddoc.items){ for(var j=0;j<ddoc.items[k].length;j++) allItems.push(ddoc.items[k][j]); }
    for(var q=0;q<allItems.length;q++){
      var it=allItems[q];
      if(it.qty!==null && it.unit!==null && it.total!==null){
        var expected=round2(it.qty*it.unit);
        var diffA=round2(it.total-expected);
        if(Math.abs(diffA)>0.01){
          if(dname==="Final Invoice" && diffA>0){
            add("Arithmetic error — "+dname+" line \""+it.raw.replace(/\s+/g," ").slice(0,60)+"\"",
              num(it.qty)+" \u00d7 "+fmt(it.unit)+" = "+fmt(expected)+", but the line states "+fmt(it.total)+". Overstated by "+fmt(it.total)+" \u2212 "+fmt(expected)+" = "+fmt(diffA)+".",
              diffA,"med");
          } else {
            add("Arithmetic error — "+dname+" line \""+it.raw.replace(/\s+/g," ").slice(0,60)+"\"",
              num(it.qty)+" \u00d7 "+fmt(it.unit)+" = "+fmt(expected)+", but the line states "+fmt(it.total)+" (difference "+fmt(Math.abs(diffA))+"). This line is not on the final invoice, so nothing is added to the overcharge total.",
              null,"low");
          }
        }
      }
    }
  }

  /* 8 · invoice total vs sum of its own lines */
  if(I.totals.length){
    var stated=I.totals[0].total;
    var sumLines=0, anyLine=false;
    for(var k2 in I.items){ for(var j2=0;j2<I.items[k2].length;j2++){ if(I.items[k2][j2].total!==null){ sumLines+=I.items[k2][j2].total; anyLine=true; } } }
    for(var f2=0;f2<I.fees.length;f2++){ if(I.fees[f2].total!==null){ sumLines+=I.fees[f2].total; anyLine=true; } }
    sumLines=round2(sumLines);
    if(stated!==null && anyLine && Math.abs(stated-sumLines)>0.01){
      var tDiff=round2(stated-sumLines);
      if(tDiff>0){
        add("Invoice total does not match its own lines",
          "The invoice lines add to "+fmt(sumLines)+", but the stated invoice total is "+fmt(stated)+". Difference: "+fmt(stated)+" \u2212 "+fmt(sumLines)+" = "+fmt(tDiff)+".",
          tDiff,"med");
      } else {
        add("Invoice total does not match its own lines",
          "The invoice lines add to "+fmt(sumLines)+", but the stated invoice total is "+fmt(stated)+" (difference "+fmt(Math.abs(tDiff))+" in your favour). Flagged for correction; nothing added to the overcharge total.",
          null,"low");
      }
    }
  }

  /* verdict */
  var hasHigh=false;
  for(var v=0;v<findings.length;v++){ if(findings[v].sev==="high") hasHigh=true; }
  var verdict;
  if(findings.length===0) verdict="SAFE TO PAY";
  else if(hasHigh || over>=500) verdict="DO NOT PAY YET";
  else verdict="PAY WITH FIXES";
  return { verdict:verdict, overcharge:round2(over), findings:findings, docsPresent:docsPresent, note:"" };
}

/* ---------- worked examples ---------- */
var EX_BAD_P=[
"PROPOSAL \u2014 Deck Installation",
"Decking (composite): 320 sq ft @ $18.00 = $5,760.00",
"Posts: 10 posts @ $85.00 = $850.00",
"Footings: 10 footings @ $120.00 = $1,200.00",
"Railing: 60 linear ft @ $45.00 = $2,700.00",
"Stairs: 5 steps @ $180.00 = $900.00",
"Labor: 40 hours @ $65.00 = $2,600.00",
"Permit fee: $350.00",
"Deposit paid: $2,000.00",
"Proposal total: $14,360.00"
].join("\n");
var EX_BAD_W=[
"WORK RECORD \u2014 Deck Installation",
"Decking installed (pressure-treated): 300 sq ft",
"Posts installed: 10 posts",
"Footings installed: 8 footings",
"Railing installed: 60 linear ft",
"Stairs installed: 5 steps",
"Labor worked: 36 hours @ $65.00",
"Permit fee paid: $350.00",
"Deposit received: $2,000.00"
].join("\n");
var EX_BAD_I=[
"FINAL INVOICE \u2014 Deck Installation",
"Decking (composite): 340 sq ft @ $18.00 = $6,120.00",
"Posts: 10 posts @ $85.00 = $850.00",
"Footings: 12 footings @ $120.00 = $1,440.00",
"Railing: 60 linear ft @ $45.00 = $2,800.00",
"Stairs: 5 steps @ $180.00 = $900.00",
"Labor: 44 hours @ $65.00 = $2,860.00",
"Permit fee: $350.00",
"Permit fee (county): $350.00",
"Disposal fee: $275.00",
"Deposit credit: $0.00",
"Invoice total: $15,945.00"
].join("\n");

var EX_OK_P=[
"PROPOSAL \u2014 Deck Installation",
"Decking (composite): 300 sq ft @ $18.00 = $5,400.00",
"Posts: 10 posts @ $85.00 = $850.00",
"Footings: 10 footings @ $120.00 = $1,200.00",
"Railing: 60 linear ft @ $45.00 = $2,700.00",
"Stairs: 5 steps @ $180.00 = $900.00",
"Labor: 36 hours @ $65.00 = $2,340.00",
"Permit fee: $350.00",
"Deposit paid: $1,500.00",
"Proposal total: $13,740.00"
].join("\n");
var EX_OK_W=[
"WORK RECORD \u2014 Deck Installation",
"Decking installed (composite): 300 sq ft",
"Posts installed: 10 posts",
"Footings installed: 10 footings",
"Railing installed: 60 linear ft",
"Stairs installed: 5 steps",
"Labor worked: 36 hours @ $65.00",
"Permit fee paid: $350.00",
"Deposit received: $1,500.00"
].join("\n");
var EX_OK_I=[
"FINAL INVOICE \u2014 Deck Installation",
"Decking (composite): 300 sq ft @ $18.00 = $5,400.00",
"Posts: 10 posts @ $85.00 = $850.00",
"Footings: 10 footings @ $120.00 = $1,200.00",
"Railing: 60 linear ft @ $45.00 = $2,700.00",
"Stairs: 5 steps @ $180.00 = $900.00",
"Labor: 36 hours @ $65.00 = $2,340.00",
"Permit fee: $350.00",
"Deposit credit: -$1,500.00",
"Invoice total: $12,240.00"
].join("\n");

/* ---------- rendering ---------- */
var VERDICT_CLASS={ "SAFE TO PAY":"v-safe", "PAY WITH FIXES":"v-fixes", "DO NOT PAY YET":"v-donot", "NOT ENOUGH TO COMPARE":"v-notenough" };
var VERDICT_BLURB={
  "SAFE TO PAY":"Every quantity, material, hour, fee, deposit, and line total in the invoice is supported by the proposal and the work record. No documented overcharge was found.",
  "PAY WITH FIXES":"The invoice is broadly supported, but the findings below need correcting first. Pay the corrected amount, not the stated total.",
  "DO NOT PAY YET":"Serious mismatches were found between the invoice and the other documents. Hold payment until each finding below is resolved in writing.",
  "NOT ENOUGH TO COMPARE":"Fewer than two documents were pasted, so there is nothing to cross-check. Paste at least the work record and the final invoice."
};
var lastResult=null;

function esc(s){ return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"); }

function buildReport(r){
  var lines=[];
  lines.push("DECK INSTALLATION CONSISTENCY AUDIT \u2014 REPORT");
  lines.push("Verdict: "+r.verdict);
  lines.push("Documented overcharge: "+fmt(r.overcharge)+" (summed only from figures shown in the pasted documents)");
  lines.push("Documents compared: "+r.docsPresent+" of 3");
  lines.push("");
  if(r.note) lines.push(r.note);
  if(!r.findings.length && r.verdict==="SAFE TO PAY"){
    lines.push("Findings: none. Quantities, materials, labor, permit, deposit, fees, and line arithmetic all agree across the pasted documents.");
  }
  for(var i=0;i<r.findings.length;i++){
    var f=r.findings[i];
    lines.push((i+1)+". "+f.title);
    lines.push("   "+f.detail);
    lines.push("   Counted toward overcharge: "+(f.amount===null? "not priced \u2014 no price evidence in the pasted text" : fmt(f.amount)));
  }
  lines.push("");
  lines.push("Note: this report compares only the pasted text. It does not verify work performed in the real world.");
  return lines.join("\n");
}
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-deck-installation-proposal-work-record-final-invoice-consistency-auditortm',
  name: 'J-Dawgs Deck Installation Proposal, Work Record & Final Invoice Consistency Auditor',
  description: 'Cross-checks a deck installation proposal against the work record and final invoice — decking and materials billed vs installed, labor above hours × rate, uncredited deposit, duplicate and invoice-only fees, arithmetic shown — into one pay verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
