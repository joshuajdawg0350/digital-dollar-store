'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs etcd Cluster Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

  "use strict";

  var RISKY = [
    "# Risky worked example - a member that would start, but should not ship",
    "name: etcd-node-1",
    "data-dir: /var/lib/etcd",
    "listen-client-urls: http://0.0.0.0:2379",
    "advertise-client-urls: http://0.0.0.0:2379",
    "listen-peer-urls: http://0.0.0.0:2380",
    "initial-advertise-peer-urls: http://10.0.0.11:2380",
    "initial-cluster: etcd-node-1=http://10.0.0.11:2380,etcd-node-2=http://10.0.0.12:2380",
    "initial-cluster-state: new",
    "snapshot-count: 100000",
    "auth-token: simple",
    "root-password: hunter2-never-shown"
  ].join("\n");

  var CLEAN = [
    "# Hardened worked example - TLS everywhere, odd quorum, token set",
    "name: etcd-node-1",
    "data-dir: /var/lib/etcd",
    "listen-client-urls: https://10.0.0.11:2379",
    "advertise-client-urls: https://etcd-node-1.internal:2379",
    "listen-peer-urls: https://10.0.0.11:2380",
    "initial-advertise-peer-urls: https://10.0.0.11:2380",
    "cert-file: /etc/etcd/pki/server.crt",
    "key-file: /etc/etcd/pki/server.key",
    "client-cert-auth: true",
    "trusted-ca-file: /etc/etcd/pki/ca.crt",
    "peer-cert-file: /etc/etcd/pki/peer.crt",
    "peer-key-file: /etc/etcd/pki/peer.key",
    "peer-trusted-ca-file: /etc/etcd/pki/ca.crt",
    "peer-client-cert-auth: true",
    "initial-cluster: etcd-node-1=https://10.0.0.11:2380,etcd-node-2=https://10.0.0.12:2380,etcd-node-3=https://10.0.0.13:2380",
    "initial-cluster-token: cluster-token-value-never-shown",
    "initial-cluster-state: new",
    "snapshot-count: 10000",
    "max-snapshots: 10"
  ].join("\n");

  var KNOWN = {};
  ("name,data-dir,wal-data-dir,listen-client-urls,advertise-client-urls,listen-peer-urls," +
   "initial-advertise-peer-urls,cert-file,key-file,client-cert-auth,trusted-ca-file,auto-tls," +
   "client-cert-allowed-hostname,peer-cert-file,peer-key-file,peer-client-cert-auth,peer-trusted-ca-file," +
   "peer-auto-tls,auth-token,auth-token-ttl,initial-cluster,initial-cluster-token,initial-cluster-state," +
   "snapshot-count,max-snapshots,max-wals,quota-backend-bytes,max-txn-ops,max-request-bytes," +
   "election-timeout,heartbeat-interval,discovery,discovery-fallback,discovery-proxy,strict-reconfig-check," +
   "enable-v2,enable-pprof,metrics,listen-metrics-urls,log-level,logger,log-outputs,cors,host-whitelist," +
   "cipher-suites,tls-min-version,tls-max-version,grpc-keepalive-min-time,auto-compaction-mode," +
   "auto-compaction-retention,compaction-sleep-interval,experimental-enable-lease-checkpoint," +
   "experimental-distributed-tracing-enabled").split(",").forEach(function(k){ KNOWN[k]=true; });

  var input = document.getElementById("input");
  var findingsBox = document.getElementById("findings");
  var verdictBox = document.getElementById("verdictBox");
  var verdictWord = document.getElementById("verdictWord");
  var verdictWhy = document.getElementById("verdictWhy");
  var countsBox = document.getElementById("counts");
  var reportBox = document.getElementById("report");
  var runStatus = document.getElementById("runStatus");
  var copyStatus = document.getElementById("copyStatus");
  var pitchStatus = document.getElementById("pitchStatus");

  function isSecretKey(k){
    return /password|passwd|secret/.test(k) || k === "initial-cluster-token";
  }
  function looksLikeKeyMaterial(v){
    return /-----BEGIN [A-Z ]*(PRIVATE KEY|CERTIFICATE)/.test(v || "");
  }
  function truthy(v){ return /^(true|yes|on|1)$/i.test((v||"").trim()); }
  function falsy(v){ return /^(false|no|off|0)$/i.test((v||"").trim()); }
  function unquote(v){
    v = (v||"").trim();
    if (v.length >= 2 && ((v.charAt(0)==='"' && v.charAt(v.length-1)==='"') || (v.charAt(0)==="'" && v.charAt(v.length-1)==="'"))) {
      return v.slice(1,-1);
    }
    return v;
  }
  function hasWildcard(v){ return /0\.0\.0\.0/.test(v||"") || /\[::\]/.test(v||""); }
  function hasHttp(v){ return /(^|[,\s])http:\/\//i.test(v||""); }
  function hasHttps(v){ return /(^|[,\s])https:\/\//i.test(v||""); }

  function parse(text){
    var entries = {};   // key -> {value, line}
    var order = [];
    var findings = [];
    var unknown = {};   // key -> [lines]
    var lines = text.split(/\r?\n/);
    for (var i = 0; i < lines.length; i++){
      var lineno = i + 1;
      var raw = lines[i];
      var line = raw.trim();
      if (!line || line.charAt(0) === "#") continue;
      var key = null, value = null;
      var m;
      if (line.indexOf("--") === 0){
        m = line.match(/^--([A-Za-z0-9][A-Za-z0-9._-]*)(?:=(.*)|\s+(.*))?$/);
        if (m){ key = m[1].toLowerCase(); value = (m[2] !== undefined ? m[2] : (m[3] !== undefined ? m[3] : "")); }
      } else {
        m = line.match(/^([A-Za-z0-9][A-Za-z0-9._-]*)\s*:\s*(.*)$/);
        if (m){ key = m[1].toLowerCase(); value = m[2]; }
      }
      if (key === null){
        findings.push({sev:"NOT PARSED", line:lineno,
          msg:"Line " + lineno + " is not a key: value line or a --flag line this auditor can read. It was skipped, not guessed at.",
          fix:"Rewrite it as key: value (or --key value), or remove it if it is not part of the config."});
        continue;
      }
      value = unquote(value);
      if (isSecretKey(key) && value){
        findings.push({sev:"SECRET", line:lineno,
          msg:"Secret-bearing key \"" + key + "\" is set on line " + lineno + ". Reported by key name and line only — the value is never shown in these findings or the report.",
          fix:"Keep the value out of shared pastes and tickets; rotate it if this config has already been shared with the value visible."});
        if (!KNOWN[key]) continue;
      }
      if (!KNOWN[key]){
        if (!unknown[key]) unknown[key] = [];
        unknown[key].push(lineno);
        continue;
      }
      if (entries[key]){
        findings.push({sev:"DUPLICATE", line:lineno,
          msg:"Key \"" + key + "\" is set on line " + entries[key].line + " and again on line " + lineno + ". Resolved last-value-wins: the line " + lineno + " value is the one audited, matching how etcd reads the file.",
          fix:"Delete the stale \"" + key + "\" line so the file says one thing."});
      } else {
        order.push(key);
      }
      entries[key] = { value: value, line: lineno };
      if (!isSecretKey(key) && looksLikeKeyMaterial(value)){
        findings.push({sev:"SECRET", line:lineno,
          msg:"Key \"" + key + "\" on line " + lineno + " appears to hold certificate or key material inline. Reported by key name and line only — the content is never shown.",
          fix:"Move key material into files on the host and reference the paths (cert-file / key-file) instead of pasting contents into the config."});
      }
    }
    Object.keys(unknown).forEach(function(k){
      findings.push({sev:"NOT AUDITED", line:unknown[k][0],
        msg:"Key \"" + k + "\" (line" + (unknown[k].length > 1 ? "s " + unknown[k].join(", ") : " " + unknown[k][0]) + ") is not a key this auditor knows. It was not graded — silence about a key is never a pass.",
        fix:"Check \"" + k + "\" against the etcd configuration reference for your version by hand."});
    });
    return { entries: entries, findings: findings };
  }

  function audit(text){
    var parsed = parse(text);
    var e = parsed.entries;
    var f = parsed.findings;
    function get(k){ return e[k] ? e[k].value : null; }
    function lineOf(k){ return e[k] ? e[k].line : null; }
    function present(k){ return e[k] && e[k].value !== ""; }

    /* --- Client TLS --- */
    var clientTLS = present("cert-file") && present("key-file");
    var anyClientTLSMaterial = present("cert-file") || present("key-file") || present("trusted-ca-file") || truthy(get("auto-tls"));
    var lcu = get("listen-client-urls"), acu = get("advertise-client-urls");
    if (lcu !== null && hasWildcard(lcu) && !clientTLS && !present("trusted-ca-file")){
      f.push({sev:"BLOCKER", line:lineOf("listen-client-urls"),
        msg:"listen-client-urls (line " + lineOf("listen-client-urls") + ") binds the client port to 0.0.0.0 — every network interface — and no client TLS is configured: cert-file, key-file, and trusted-ca-file are all absent. Anyone who can reach the port can read and write the cluster in plain text.",
        fix:"Set cert-file, key-file, and trusted-ca-file for client TLS, or bind listen-client-urls to a specific interface instead of 0.0.0.0."});
    } else if (lcu !== null && hasHttp(lcu) && !anyClientTLSMaterial){
      f.push({sev:"WARNING", line:lineOf("listen-client-urls"),
        msg:"listen-client-urls (line " + lineOf("listen-client-urls") + ") serves plain HTTP and no client TLS material (cert-file / key-file / trusted-ca-file) is named anywhere in the config. Client traffic is unencrypted.",
        fix:"Serve client URLs over https with cert-file and key-file set, ideally with trusted-ca-file and client-cert-auth: true."});
    } else if (lcu !== null && hasHttps(lcu) && !clientTLS){
      f.push({sev:"WARNING", line:lineOf("listen-client-urls"),
        msg:"listen-client-urls (line " + lineOf("listen-client-urls") + ") uses https, but a complete client TLS pair is not named (cert-file and key-file must both be set). The member may fail to start or fall back in ways this text audit cannot see.",
        fix:"Set both cert-file and key-file to the member's client certificate and key."});
    }
    if (acu !== null && hasWildcard(acu)){
      f.push({sev:"WARNING", line:lineOf("advertise-client-urls"),
        msg:"advertise-client-urls (line " + lineOf("advertise-client-urls") + ") advertises 0.0.0.0 to clients. Clients are told to connect to a wildcard address, which is not a routable destination and leaks the bind-anywhere posture.",
        fix:"Advertise the member's real reachable hostname or IP, matching its certificate."});
    }
    if (present("cert-file") && !present("key-file")){
      f.push({sev:"WARNING", line:lineOf("cert-file"),
        msg:"cert-file is set (line " + lineOf("cert-file") + ") but key-file is absent. A certificate without its private key cannot serve TLS.",
        fix:"Set key-file to the private key that matches cert-file."});
    }
    if (present("key-file") && !present("cert-file")){
      f.push({sev:"WARNING", line:lineOf("key-file"),
        msg:"key-file is set (line " + lineOf("key-file") + ") but cert-file is absent. A private key without its certificate cannot serve TLS.",
        fix:"Set cert-file to the certificate that matches key-file."});
    }
    if (truthy(get("client-cert-auth")) && !present("trusted-ca-file")){
      f.push({sev:"WARNING", line:lineOf("client-cert-auth"),
        msg:"client-cert-auth is true (line " + lineOf("client-cert-auth") + ") but trusted-ca-file is absent, so there is no CA named to verify client certificates against.",
        fix:"Set trusted-ca-file to the CA that signs your client certificates."});
    } else if (clientTLS && !truthy(get("client-cert-auth"))){
      f.push({sev:"INFO", line:lineOf("cert-file"),
        msg:"Client TLS is configured (cert-file line " + lineOf("cert-file") + "), but client-cert-auth is not set to true, so clients are not required to present certificates. Encryption is on; client identity checks are not.",
        fix:"If clients should prove identity, set client-cert-auth: true with trusted-ca-file. If access is controlled another way, this note is your record of the choice."});
    }

    /* --- Peer TLS --- */
    var peerTLS = present("peer-cert-file") && present("peer-key-file");
    var anyPeerTLSMaterial = peerTLS || present("peer-trusted-ca-file") || truthy(get("peer-auto-tls"));
    var lpu = get("listen-peer-urls");
    if (lpu !== null && hasWildcard(lpu) && !anyPeerTLSMaterial){
      f.push({sev:"WARNING", line:lineOf("listen-peer-urls"),
        msg:"listen-peer-urls (line " + lineOf("listen-peer-urls") + ") binds peer traffic to 0.0.0.0 and no peer TLS is configured (peer-cert-file, peer-key-file, and peer-trusted-ca-file are all absent). Member-to-member traffic is exposed in plain text on every interface.",
        fix:"Set peer-cert-file, peer-key-file, and peer-trusted-ca-file, or bind listen-peer-urls to the cluster's private interface."});
    } else if (lpu !== null && hasHttp(lpu) && !anyPeerTLSMaterial){
      f.push({sev:"WARNING", line:lineOf("listen-peer-urls"),
        msg:"listen-peer-urls (line " + lineOf("listen-peer-urls") + ") uses plain HTTP and no peer TLS material is named anywhere in the config. Anything that can reach the peer port can speak to the cluster as a peer.",
        fix:"Serve peer URLs over https with peer-cert-file and peer-key-file set and peer-trusted-ca-file naming the peer CA."});
    }
    if (present("peer-cert-file") && !present("peer-key-file")){
      f.push({sev:"WARNING", line:lineOf("peer-cert-file"),
        msg:"peer-cert-file is set (line " + lineOf("peer-cert-file") + ") but peer-key-file is absent. A certificate without its private key cannot serve peer TLS.",
        fix:"Set peer-key-file to the private key that matches peer-cert-file."});
    }
    if (present("peer-key-file") && !present("peer-cert-file")){
      f.push({sev:"WARNING", line:lineOf("peer-key-file"),
        msg:"peer-key-file is set (line " + lineOf("peer-key-file") + ") but peer-cert-file is absent. A private key without its certificate cannot serve peer TLS.",
        fix:"Set peer-cert-file to the certificate that matches peer-key-file."});
    }
    if (peerTLS && present("peer-trusted-ca-file")){
      f.push({sev:"INFO", line:lineOf("peer-cert-file"),
        msg:"Peer TLS is configured: peer-cert-file (line " + lineOf("peer-cert-file") + "), peer-key-file, and peer-trusted-ca-file are all named. This audit checks that the files are named, not that they are valid — it cannot verify certificates.",
        fix:"No action. Verify the files themselves on the host before you rely on them."});
    }

    /* --- Auth --- */
    var at = get("auth-token");
    if (at !== null && falsy(at)){
      f.push({sev:"WARNING", line:lineOf("auth-token"),
        msg:"auth-token is explicitly disabled (line " + lineOf("auth-token") + "). Token-based request authentication posture is turned off by this line — combined with etcd user auth this weakens who can prove who they are to the cluster.",
        fix:"Remove the disabling value, or set auth-token to a real scheme (for example jwt with signing keys) if token auth is part of your design."});
    } else if (at !== null && /^simple$/i.test(at.trim())){
      f.push({sev:"INFO", line:lineOf("auth-token"),
        msg:"auth-token is set to \"simple\" (line " + lineOf("auth-token") + "). Simple tokens are a basic scheme with known limits; a signed JWT scheme is the stronger posture for exposed clusters.",
        fix:"Consider auth-token with jwt signing keys if this cluster is reachable beyond a trusted network."});
    }
    f.push({sev:"NOT SETTLED", line:null,
      msg:"Whether etcd user authentication itself is enabled is NOT SETTLED by this file: etcd turns auth on at runtime (etcdctl user / role setup, then auth enable), not with a config key, and no line in a pasted config can prove it either way. This auditor will not guess your version's defaults.",
      fix:"Confirm auth state against the running cluster with etcdctl auth status before you rely on it."});

    /* --- Initial cluster --- */
    var ic = get("initial-cluster");
    var memberCount = 0;
    if (ic !== null && ic.trim() !== ""){
      memberCount = ic.split(",").filter(function(s){ return s.trim() !== ""; }).length;
      if (memberCount % 2 === 0){
        f.push({sev:"WARNING", line:lineOf("initial-cluster"),
          msg:"initial-cluster (line " + lineOf("initial-cluster") + ") lists " + memberCount + " members — an even count. Quorum for " + memberCount + " members is " + (Math.floor(memberCount/2)+1) + ", so this cluster tolerates " + (memberCount - (Math.floor(memberCount/2)+1)) + " failure(s), no more than the " + (memberCount-1) + "-member cluster below it, while costing an extra member.",
          fix:"Run an odd member count (3 or 5) so every member you pay for buys failure tolerance."});
      } else {
        f.push({sev:"INFO", line:lineOf("initial-cluster"),
          msg:"initial-cluster (line " + lineOf("initial-cluster") + ") lists " + memberCount + " member(s) — an odd count, so quorum is " + (Math.floor(memberCount/2)+1) + " and the cluster tolerates " + Math.floor(memberCount/2) + " member failure(s)." + (memberCount === 1 ? " A single member has no fault tolerance at all: if it dies, the cluster is down." : ""),
          fix:"No action on the count. Keep the count odd as the cluster grows."});
      }
    }
    if (!present("initial-cluster-token")){
      f.push({sev:"WARNING", line:null,
        msg:"initial-cluster-token is missing. Without a cluster token, members identify their cluster only by the member list, and a stray or reused member from another cluster is easier to mistake for one of yours.",
        fix:"Set initial-cluster-token to a unique value for this cluster — the same on every founding member. Its value is a secret: this auditor reports it by key name and line only."});
    }
    var ics = get("initial-cluster-state");
    if (ics !== null){
      var stateVal = ics.trim().toLowerCase();
      if (stateVal !== "new" && stateVal !== "existing"){
        f.push({sev:"QUESTION", line:lineOf("initial-cluster-state"),
          msg:"initial-cluster-state (line " + lineOf("initial-cluster-state") + ") is set to a value this auditor does not recognize as \"new\" or \"existing\". Is that a typo, or a value from a different etcd version?",
          fix:"Set initial-cluster-state to new for a founding member, or existing for a member joining a cluster that already runs."});
      } else if (stateVal === "existing" && ic === null){
        f.push({sev:"QUESTION", line:lineOf("initial-cluster-state"),
          msg:"initial-cluster-state is \"existing\" (line " + lineOf("initial-cluster-state") + "), but no initial-cluster member list appears in this config. Is this member joining a running cluster whose list is supplied another way (flags, environment, discovery), or is the list missing by mistake? This auditor flags the mismatch as a question — it does not assert which is true.",
          fix:"If the list is supplied elsewhere, this note is your record. If not, add initial-cluster naming every founding member."});
      } else if (stateVal === "existing"){
        f.push({sev:"INFO", line:lineOf("initial-cluster-state"),
          msg:"initial-cluster-state is \"existing\" (line " + lineOf("initial-cluster-state") + "): this member is joining a cluster that already runs. That posture only works if the cluster was told about the new member first (member add) — a pasted config cannot prove that step happened.",
          fix:"Confirm the member was added to the running cluster before starting it with state existing."});
      }
    }

    /* --- Snapshot posture --- */
    if (present("snapshot-count")){
      f.push({sev:"INFO", line:lineOf("snapshot-count"),
        msg:"snapshot-count is set (line " + lineOf("snapshot-count") + ") to " + get("snapshot-count") + ": the member snapshots after that many Raft entries. Higher values mean fewer snapshots and more WAL to replay on restart; lower values snapshot more often.",
        fix:"No action unless restarts are slow (lower it) or snapshot I/O is a problem (raise it)."});
    } else {
      f.push({sev:"INFO", line:null,
        msg:"snapshot-count is not set, so the etcd default for your version applies. This auditor reports the posture as unset rather than guessing the number your version ships.",
        fix:"Set snapshot-count explicitly if you want the same snapshot behavior across versions."});
    }
    if (present("max-snapshots")){
      f.push({sev:"INFO", line:lineOf("max-snapshots"),
        msg:"max-snapshots is set (line " + lineOf("max-snapshots") + ") to " + get("max-snapshots") + ": that is how many snapshot files the member keeps on disk. More kept snapshots means more disk held by history.",
        fix:"No action unless disk pressure says otherwise."});
    }
    return { entries: e, findings: f };
  }

  var RANK = { "BLOCKER":0, "WARNING":1, "QUESTION":2, "DUPLICATE":3, "SECRET":4, "NOT SETTLED":5, "INFO":6, "NOT AUDITED":7, "NOT PARSED":8 };
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-etcd-cluster-config-safety-auditor',
  name: 'J-Dawgs etcd Cluster Config Safety Auditor',
  description: 'Grades a pasted etcd config (YAML or flags) offline: 0.0.0.0 client listeners without TLS as BLOCKER, peer TLS, auth honestly NOT SETTLED when the version default is unknown, quorum arithmetic, secrets by key name only — into one deploy verdict.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
