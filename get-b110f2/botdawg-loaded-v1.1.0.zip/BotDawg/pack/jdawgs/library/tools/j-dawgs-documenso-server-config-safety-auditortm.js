'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Documenso Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the auditConfig function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ================= Parsing ================= */

      var PLACEHOLDER_MARKERS = ["example","changeme","change-me","your-","placeholder","test"];

      function isPlaceholder(value){
        var s = value.toLowerCase();
        for (var i = 0; i < PLACEHOLDER_MARKERS.length; i++){
          if (s.indexOf(PLACEHOLDER_MARKERS[i]) !== -1) return true;
        }
        return false;
      }

      function cleanValue(raw){
        var v = raw.replace(/^\s+/, "").replace(/\s+$/, "");
        if (v.length >= 2){
          var first = v.charAt(0), last = v.charAt(v.length - 1);
          if ((first === '"' && last === '"') || (first === "'" && last === "'")){
            return v.slice(1, -1);
          }
        }
        /* Unquoted value: drop a trailing " # comment". */
        var hashAt = v.indexOf(" #");
        if (hashAt !== -1) v = v.slice(0, hashAt).replace(/\s+$/, "");
        return v;
      }

      function parseConfig(text){
        var lines = String(text).split(/\r\n|\r|\n/);
        var entries = [];
        var malformed = [];
        for (var i = 0; i < lines.length; i++){
          var lineNo = i + 1;
          var t = lines[i].replace(/^\s+/, "").replace(/\s+$/, "");
          if (t === "") continue;
          if (t.charAt(0) === "#") continue;
          var body = t.replace(/^export\s+/, "");
          var m = body.match(/^([A-Za-z_][A-Za-z0-9_.\-]*)\s*=\s*(.*)$/);
          if (m){
            entries.push({ key: m[1], value: cleanValue(m[2]), line: lineNo });
          } else {
            var tokens = body.split(/\s+/);
            var firstTok = tokens[0];
            var allCapsKey = /^[A-Z][A-Z0-9_]{2,}$/.test(firstTok);
            var underscored = /^[A-Za-z_][A-Za-z0-9_]*_[A-Za-z0-9_]*$/.test(firstTok);
            if ((allCapsKey || underscored) && tokens.length <= 3){
              malformed.push({ line: lineNo, token: firstTok });
            }
          }
        }
        return { entries: entries, malformed: malformed, totalLines: lines.length };
      }

      function isRelevantKey(key){
        var K = key.toUpperCase();
        return K.indexOf("NEXTAUTH") !== -1 ||
               K.indexOf("ENCRYPTION") !== -1 ||
               K.indexOf("DATABASE") !== -1 ||
               K.indexOf("SIGNING") !== -1 ||
               K.indexOf("SIGNUP") !== -1 ||
               K.indexOf("WEBAPP") !== -1 ||
               K.indexOf("DOCUMENSO") !== -1 ||
               K.indexOf("NEXT_PUBLIC") === 0 ||
               K.indexOf("NEXT_PRIVATE") === 0;
      }

      /* ================= Audit ================= */

      function auditConfig(text){
        var parsed = parseConfig(text);
        var entries = parsed.entries;
        var findings = [];

        function add(severity, key, line, message, valueLength, extra){
          var f = {
            severity: severity,
            key: key,
            line: line,
            message: message,
            valueLength: (valueLength === undefined ? null : valueLength)
          };
          if (extra){ for (var k in extra){ if (Object.prototype.hasOwnProperty.call(extra, k)) f[k] = extra[k]; } }
          findings.push(f);
        }

        var relevantCount = 0;
        entries.forEach(function(e){ if (isRelevantKey(e.key)) relevantCount++; });

        var gradeable = entries.length >= 3 && relevantCount > 0;
        if (!gradeable){
          return {
            verdict: "NOT ENOUGH TO GRADE",
            gradeable: false,
            findings: [],
            counts: { critical: 0, warning: 0, total: 0, configLines: entries.length, relevantKeys: relevantCount, totalLines: parsed.totalLines }
          };
        }

        /* Duplicates */
        var firstSeenLine = {};
        entries.forEach(function(e){
          if (firstSeenLine[e.key] !== undefined){
            add("WARNING", e.key, e.line,
              "Duplicate key: this later definition overrides the earlier one on line " + firstSeenLine[e.key] + ". Keep one definition so the effective value is unambiguous.",
              e.value.length);
          } else {
            firstSeenLine[e.key] = e.line;
          }
        });

        /* Malformed lines */
        parsed.malformed.forEach(function(mf){
          add("WARNING", mf.token, mf.line,
            "Malformed line: it looks like a setting but has no = sign, so a server reading this file will ignore it.",
            null);
        });

        var sawNextAuth = false, sawPrimaryEncryption = false, sawWebappUrl = false, sawDatabaseUrl = false;

        entries.forEach(function(e){
          var K = e.key.toUpperCase();
          var v = e.value;
          var lv = v.toLowerCase();

          if (K === "NEXTAUTH_SECRET"){
            sawNextAuth = true;
            if (isPlaceholder(v)){
              add("CRITICAL", e.key, e.line, "NEXTAUTH_SECRET looks like a placeholder or example value, not a real secret. Generate a long random secret instead.", v.length);
            } else if (v.length < 32){
              add("CRITICAL", e.key, e.line, "NEXTAUTH_SECRET is too short (" + v.length + " characters). It needs at least 32 characters of real randomness.", v.length);
            }
            return;
          }

          if (K.indexOf("WEBAPP_URL") !== -1){
            sawWebappUrl = true;
            if (lv.indexOf("http://") === 0){
              add("CRITICAL", e.key, e.line, "NEXT_PUBLIC_WEBAPP_URL starts with http:// — session cookies and signing links would travel unencrypted. It must use https://.", v.length);
            } else if (lv.indexOf("localhost") !== -1 || lv.indexOf("127.0.0.1") !== -1){
              add("WARNING", e.key, e.line, "NEXT_PUBLIC_WEBAPP_URL points at localhost / 127.0.0.1. Fine on a dev machine, wrong for a public deployment — links in emails would point at the visitor's own machine.", v.length);
            }
            return;
          }

          if (K === "DATABASE_URL" || /DATABASE_URL$/.test(K)){
            sawDatabaseUrl = true;
            var um = v.match(/^[a-zA-Z][a-zA-Z0-9+.\-]*:\/\/([^@\/?#]+)@/);
            if (um){
              var colonAt = um[1].indexOf(":");
              if (colonAt !== -1){
                var pw = um[1].slice(colonAt + 1);
                if (pw.length > 0){
                  add("WARNING", e.key, e.line,
                    "The database URL embeds a password in plaintext inside the connection string. Anyone who can read this file has the database password; prefer a secret store or a password-free URL plus separate credentials.",
                    v.length, { passwordLength: pw.length });
                }
              }
            }
            if (/sslmode\s*=\s*disable/i.test(v)){
              add("WARNING", e.key, e.line, "The database URL sets sslmode=disable, turning off TLS for the database connection.", v.length);
            } else if (!(/sslmode\s*=\s*(require|verify-ca|verify-full)/i.test(v) || /[?&]ssl\s*=\s*true/i.test(v))){
              add("WARNING", e.key, e.line, "The database URL shows no TLS indication (no sslmode=require or equivalent), so the database connection may run unencrypted.", v.length);
            }
            return;
          }

          if (K.indexOf("SIGNUP") !== -1){
            var truthy = (lv === "true" || lv === "1" || lv === "yes" || lv === "on");
            var falsy  = (lv === "false" || lv === "0" || lv === "no" || lv === "off");
            var open = false;
            if (K.indexOf("DISABLE") !== -1){ open = falsy; }
            else { open = truthy; }
            if (open){
              add("WARNING", e.key, e.line, "Public signup is open: anyone on the internet can register an account on this deployment. Disable signup unless open registration is deliberate.", v.length);
            }
            return;
          }

          if (K.indexOf("SIGNING") !== -1 && K.indexOf("PASSWORD") !== -1){
            if (v.length > 0){
              add("CRITICAL", e.key, e.line, "A signing-certificate password is stored in plaintext in this configuration. Anyone with this file can sign documents as you; move it to a secret store and rotate it.", v.length);
            }
            return;
          }

          if (K.indexOf("ENCRYPTION") !== -1 && K.indexOf("KEY") !== -1){
            if (K === "NEXT_PRIVATE_ENCRYPTION_KEY") sawPrimaryEncryption = true;
            if (isPlaceholder(v)){
              add("CRITICAL", e.key, e.line, "This encryption key looks like a placeholder or example value, not a real key. Generate a long random key instead.", v.length);
            } else if (v.length < 32){
              add("CRITICAL", e.key, e.line, "This encryption key is too short (" + v.length + " characters). Encryption keys need at least 32 characters of real randomness.", v.length);
            }
            return;
          }

          if (/SECRET|KEY|PASSWORD|TOKEN/.test(K)){
            if (isPlaceholder(v)){
              add("WARNING", e.key, e.line, "This secret-like value looks like a placeholder or example value. Replace it with a real, generated secret.", v.length);
            } else if (v.length < 16){
              add("WARNING", e.key, e.line, "This secret-like value is short (" + v.length + " characters). Secrets under 16 characters are easy to guess or brute-force.", v.length);
            }
            return;
          }
        });

        /* Missing-key checks */
        if (!sawNextAuth){
          add("CRITICAL", "NEXTAUTH_SECRET", null, "NEXTAUTH_SECRET is missing entirely. Without it the auth layer has no secret to sign session tokens with.", null);
        }
        if (!sawPrimaryEncryption){
          add("CRITICAL", "NEXT_PRIVATE_ENCRYPTION_KEY", null, "The primary encryption key (NEXT_PRIVATE_ENCRYPTION_KEY) is missing. Stored data cannot be encrypted without it.", null);
        }
        if (!sawWebappUrl){
          add("WARNING", "NEXT_PUBLIC_WEBAPP_URL", null, "NEXT_PUBLIC_WEBAPP_URL is missing. The app cannot build correct links (invites, signing emails) without its public URL.", null);
        }
        if (!sawDatabaseUrl){
          add("WARNING", "DATABASE_URL", null, "No database URL (DATABASE_URL or a variant) is present. A Documenso server has nowhere to store its data.", null);
        }

        var critical = 0, warning = 0;
        findings.forEach(function(f){ if (f.severity === "CRITICAL") critical++; else warning++; });

        var verdict;
        if (critical > 0) verdict = "DO NOT DEPLOY";
        else if (warning > 0) verdict = "DEPLOY WITH FIXES";
        else verdict = "SAFE TO DEPLOY";

        return {
          verdict: verdict,
          gradeable: true,
          findings: findings,
          counts: { critical: critical, warning: warning, total: findings.length, configLines: entries.length, relevantKeys: relevantCount, totalLines: parsed.totalLines }
        };
      }

      /* ================= Report builders ================= */

      function buildReport(result){
        return {
          tool: "J-Dawgs Documenso Server Config Safety Auditor",
          auditedAt: new Date().toISOString(),
          verdict: result.verdict,
          counts: {
            critical: result.counts.critical,
            warning: result.counts.warning,
            findings: result.counts.total,
            configLines: result.counts.configLines,
            relevantKeys: result.counts.relevantKeys,
            totalLines: result.counts.totalLines
          },
          note: "Findings carry value lengths only. Secret values are never included in this report.",
          findings: result.findings.map(function(f){
            var o = { severity: f.severity, key: f.key, line: f.line, message: f.message, valueLength: f.valueLength };
            if (f.passwordLength !== undefined) o.passwordLength = f.passwordLength;
            return o;
          })
        };
      }

      function buildSummaryText(result){
        var out = [];
        out.push("J-Dawgs Documenso Server Config Safety Auditor — findings summary");
        out.push("Verdict: " + result.verdict);
        out.push("Counts: " + result.counts.critical + " critical, " + result.counts.warning + " warning, " +
                 result.counts.configLines + " config lines, " + result.counts.relevantKeys + " Documenso-relevant keys.");
        if (!result.gradeable){
          out.push("Not enough recognizable configuration to grade.");
        } else if (result.findings.length === 0){
          out.push("Findings: none.");
        } else {
          out.push("Findings:");
          result.findings.forEach(function(f){
            var lineTxt = (f.line === null || f.line === undefined) ? "not present (missing)" : ("line " + f.line);
            var lenTxt = (f.valueLength === null || f.valueLength === undefined) ? "" : (" (value length: " + f.valueLength + ")");
            out.push("[" + f.severity + "] " + f.key + " — " + lineTxt + " — " + f.message + lenTxt);
          });
        }
        return out.join("\n");
      }
  return { "auditConfig": (typeof auditConfig !== 'undefined' ? auditConfig : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["auditConfig"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-documenso-server-config-safety-auditortm',
  name: 'J-Dawgs Documenso Server Config Safety Auditor',
  description: 'Grades a pasted Documenso server config offline into one deploy verdict, secrets by key name/line/length only.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["auditConfig"]) return { ok: false, output: null, summary: 'Extracted core has no auditConfig function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
