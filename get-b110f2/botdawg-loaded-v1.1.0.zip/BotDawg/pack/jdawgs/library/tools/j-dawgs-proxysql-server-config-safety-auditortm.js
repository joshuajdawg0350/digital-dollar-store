'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs ProxySQL Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

"use strict";

var RISKY = [
'# Risky worked example — a config that should never ship as-is.',
'datadir="/var/lib/proxysql"',
'',
'admin_variables=',
'{',
'    admin_credentials="admin:admin"',
'    mysql_ifaces="0.0.0.0:6032"',
'    monitor_username="root"',
'    monitor_password="admin"',
'    web_enabled="true"',
'    web_port="6080"',
'    restapi_enabled="true"',
'    restapi_port="6070"',
'}',
'',
'mysql_variables=',
'{',
'    threads=4',
'    interfaces="0.0.0.0:6033"',
'    monitor_connect_interval=2000',
'}',
'',
'mysql_servers =',
'(',
'    { address="db1.internal", port=3306, hostgroup=10, status="ONLINE", max_connections=200 }',
')',
'',
'mysql_users =',
'(',
'    { username="app", password="password", default_hostgroup=10, active=1 },',
'    { username="report", password="123456", default_hostgroup=20, active=1 }',
')',
'',
'# The line below is commented out on purpose: it must NOT be graded.',
'# monitor_password="this-commented-line-is-ignored"'
].join('\n');

var HARDENED = [
'# Hardened worked example — bound to localhost, strong unique secrets,',
'# hashed user passwords, web and REST surfaces off, TLS posture stated.',
'datadir="/var/lib/proxysql"',
'errorlog="/var/lib/proxysql/proxysql.log"',
'',
'admin_variables=',
'{',
'    admin_credentials="proxysql_admin:Kx9mQ2vL8pR4nT7wZ1yH6sD3fG5jB0a"',
'    mysql_ifaces="127.0.0.1:6032"',
'    monitor_username="proxysql_monitor"',
'    monitor_password="Mz7kQ9vL2pR8nT4wZ6yH1sD5fG3jB9aQ"',
'    web_enabled="false"',
'    restapi_enabled="false"',
'    hash_passwords="true"',
'}',
'',
'mysql_variables=',
'{',
'    threads=4',
'    interfaces="127.0.0.1:6033"',
'    have_ssl="true"',
'    ssl_p2s_ca="/etc/proxysql/certs/ca.pem"',
'    ssl_p2s_cert="/etc/proxysql/certs/server-cert.pem"',
'    ssl_p2s_key="/etc/proxysql/certs/server-key.pem"',
'    monitor_connect_interval=2000',
'    monitor_ping_interval=1000',
'}',
'',
'mysql_servers =',
'(',
'    { address="db1.internal", port=3306, hostgroup=10, status="ONLINE", use_ssl=1, max_connections=200 }',
')',
'',
'mysql_users =',
'(',
'    { username="app", password="*4ACFE3202A5FF5CF467898FC58AAB1D615029441", default_hostgroup=10, active=1, use_ssl=1 }',
')'
].join('\n');

var WEAK = ['admin','password','passwd','proxysql','root','changeme','change_me','change-me',
  'example','default','test','testing','letmein','123456','12345678','123456789','qwerty',
  'secret','monitor','mysql','pass','admin123','proxysql123','welcome','demo'];

function isWeakSecret(pw){
  if(!pw) return true;
  var l = pw.toLowerCase();
  if(WEAK.indexOf(l) !== -1) return true;
  if(l.indexOf('example') !== -1 || l.indexOf('changeme') !== -1 || l.indexOf('change-me') !== -1 || l.indexOf('default') !== -1) return true;
  if(/^(.)\1+$/.test(pw)) return true;
  if(/^\d+$/.test(pw) && pw.length < 12) return true;
  return false;
}
function looksHashed(v){
  if(!v) return false;
  if(v.charAt(0) === '*') return true;
  if(v.charAt(0) === '$') return true;
  if(/^sha256:/i.test(v) || /^scram/i.test(v)) return true;
  if(v.length >= 40 && /^[0-9a-fA-F]+$/.test(v)) return true;
  return false;
}
function truthy(v){
  var l = String(v).toLowerCase();
  return l === 'true' || l === '1' || l === 'yes' || l === 'on';
}

var SIGNAL_TERMS = ['proxysql','datadir','admin_variables','mysql_variables','admin_credentials',
  'mysql_ifaces','monitor_username','monitor_password','mysql_servers','mysql_users',
  'mysql_query_rules','hostgroup','6032','6033'];

function audit(text){
  var rawLines = text.split(/\r?\n/);
  var findings = [];
  var seen = {};
  function add(sev, check, line, key, title, message, fix, secretLength){
    var id = check + '|' + line + '|' + key;
    if(seen[id]) return;
    seen[id] = true;
    var f = { severity: sev, check: check, line: line, key: key, title: title, message: message, fix: fix };
    if(typeof secretLength === 'number') f.secretLength = secretLength;
    findings.push(f);
  }

  // Active (non-comment) lines only — commented-out lines are never graded.
  var active = [];
  var signalText = '';
  for(var i = 0; i < rawLines.length; i++){
    var trimmed = rawLines[i].replace(/^\s+/, '');
    var isComment = trimmed.charAt(0) === '#' || trimmed.indexOf('//') === 0;
    if(!isComment && trimmed !== ''){
      active.push({ n: i + 1, text: rawLines[i] });
      signalText += rawLines[i].toLowerCase() + '\n';
    }
  }
  var signal = 0;
  for(var s = 0; s < SIGNAL_TERMS.length; s++){
    if(signalText.indexOf(SIGNAL_TERMS[s]) !== -1) signal++;
  }

  var result = { verdict: '', signalTerms: signal, lineCount: rawLines.length, findings: findings };
  if(signal < 3){
    result.verdict = 'NOT ENOUGH TO GRADE';
    result.reason = 'Only ' + signal + ' of the ProxySQL signal terms this grader looks for (datadir, admin_variables, admin_credentials, mysql_ifaces, monitor account keys, mysql_servers / mysql_users, hostgroups, ports 6032/6033) appear in the active lines of this paste. That is not enough ProxySQL signal to grade honestly — paste a fuller proxysql.cnf-style configuration.';
    return finish(result);
  }

  var section = '';
  var hasTLS = false;
  var adminAllLine = 0, adminAllKey = '';
  var adminCredLine = 0, adminCredKey = '', adminPwLen = -1, adminPwWeak = false, hasAdminCreds = false;
  var surfaces = [];

  // First pass: TLS posture anywhere in active settings.
  active.forEach(function(L){
    var m, re = /([A-Za-z][A-Za-z0-9_\-\.]*)\s*=\s*"([^"]*)"/g;
    while((m = re.exec(L.text)) !== null){
      var k = m[1].toLowerCase();
      if((k.indexOf('ssl') !== -1 || k.indexOf('tls') !== -1) && m[2] !== '' && !/^(false|0|no|off)$/i.test(m[2])) hasTLS = true;
      if(k === 'have_ssl' && truthy(m[2])) hasTLS = true;
    }
  });

  var kvRe = /([A-Za-z][A-Za-z0-9_\-\.]*)\s*=\s*"([^"]*)"|([A-Za-z][A-Za-z0-9_\-\.]*)\s*=\s*'([^']*)'|([A-Za-z][A-Za-z0-9_\-\.]*)\s*=\s*([^\s,\}\)]+)/g;

  active.forEach(function(L){
    var sec = L.text.match(/^\s*(admin_variables|mysql_variables|mysql_servers|mysql_users|mysql_query_rules|mysql_replication_hostgroups)\b/i);
    if(sec) section = sec[1].toLowerCase();

    // Excessive privileges stated in an active line.
    if(/monitor/i.test(L.text) && /(all\s+privileges|grant\s+all|\bsuper\b)/i.test(L.text)){
      add('HIGH','monitor-excessive-privileges',L.n,'(statement)','Excessive privileges stated for the monitor account',
        'An active line in this paste states sweeping privileges (ALL PRIVILEGES / SUPER class) in connection with the monitor account. The monitor only needs to connect, ping, and read replication / health state.',
        'Re-state the monitor account with least privilege: connection, ping, and read-only health checks only — no SUPER, no ALL PRIVILEGES, no grant option.');
    } else if(/(all\s+privileges|grant\s+all)/i.test(L.text) && /(grant|privilege)/i.test(L.text)){
      add('MEDIUM','excessive-privileges-stated',L.n,'(statement)','Sweeping privileges stated in the paste',
        'An active line states ALL PRIVILEGES / GRANT ALL class access. Broad grants in a proxy config widen the blast radius of any leaked credential in the same file.',
        'Scope every account in this file to the exact privileges its job needs.');
    }

    var m;
    kvRe.lastIndex = 0;
    while((m = kvRe.exec(L.text)) !== null){
      var key = (m[1] || m[3] || m[5]);
      var val = (m[2] !== undefined ? m[2] : (m[4] !== undefined ? m[4] : m[6]));
      if(!key || val === undefined) continue;
      var k = key.toLowerCase();

      // --- Interfaces bound to all interfaces ---
      if(val.indexOf('0.0.0.0') !== -1){
        var isAdminIface = (k.indexOf('iface') !== -1 && (section === 'admin_variables' || k === 'mysql_ifaces')) || k === 'mysql_ifaces';
        var isIfaceKey = k.indexOf('iface') !== -1 || k.indexOf('interface') !== -1;
        if(isAdminIface){
          if(!adminAllLine){ adminAllLine = L.n; adminAllKey = key; }
          add('HIGH','interface-all-interfaces',L.n,key,'Admin interface bound to all interfaces (0.0.0.0)',
            'This listener accepts connections on every network interface. The ProxySQL admin interface is a full control plane — anyone who can reach this port can attempt admin logins and, with valid credentials, rewrite routing and users.',
            'Bind the admin interface to localhost or a dedicated management address (for example 127.0.0.1:6032), and firewall port 6032 to your management hosts only.');
        } else if(isIfaceKey){
          add('HIGH','interface-all-interfaces',L.n,key,'Proxy listener bound to all interfaces (0.0.0.0)',
            'This listener accepts connections on every network interface. That may be intended for application traffic, but it must be a deliberate, firewalled decision — not a leftover from an example config.',
            'If all-interface binding is not required, bind to the application-facing address only; if it is required, confirm firewall rules and TLS posture cover this listener.');
        } else {
          add('MEDIUM','bind-all-interfaces',L.n,key,'Setting binds to all interfaces (0.0.0.0)',
            'This setting references 0.0.0.0, which exposes the associated endpoint on every network interface.',
            'Replace 0.0.0.0 with the specific address this endpoint should listen on, or document and firewall the exposure.');
        }
      }

      // --- Admin credentials ---
      if(k === 'admin_credentials' || k === 'admin-admin_credentials' || k.slice(-17) === 'admin_credentials'){
        hasAdminCreds = true;
        var firstPair = val.split(';')[0];
        var colon = firstPair.indexOf(':');
        var pw = colon >= 0 ? firstPair.slice(colon + 1) : '';
        adminCredLine = L.n; adminCredKey = key; adminPwLen = pw.length;
        adminPwWeak = isWeakSecret(pw) || pw.length < 12;
        if(adminPwWeak){
          add('CRITICAL','admin-default-password',L.n,key,'Default, example, or short admin password',
            'The admin password in this credential pair is a known default/example value or is short (reported by length only: ' + pw.length + ' characters). The admin interface controls the whole proxy — a guessed admin login is a full compromise of routing, users, and backend credentials stored in the proxy.',
            'Set a unique admin password of at least 16 characters that appears in no example or documentation, and rotate any credential that was ever deployed with the example value.',
            pw.length);
        } else {
          add('LOW','admin-credential-in-file',L.n,key,'Admin credential stored in the config file',
            'An admin credential pair is present with a password length of ' + pw.length + ' characters (value never shown). Config-file credentials are only as safe as the file itself.',
            'Restrict the config file to owner-only permissions (0600), keep it out of source control, and rotate the admin password on staff changes.',
            pw.length);
        }
      }

      // --- Password keys: monitor, mysql_users, others ---
      if(k.indexOf('password') !== -1 && k !== 'hash_passwords'){
        if(val === ''){
          add('HIGH','empty-password',L.n,key,'Empty password set',
            'This password key is present but empty. An account with no password on a proxy that routes database traffic is an open door.',
            'Set a real password, or remove the account entirely if it is not used.');
        } else if(looksHashed(val)){
          // Hashed at rest in the file — no plaintext finding.
        } else {
          var weak = isWeakSecret(val) || val.length < 12;
          var strong = val.length >= 16 && !isWeakSecret(val);
          if(weak){
            add('HIGH','plaintext-weak-password',L.n,key,'Plaintext password that is default, example, or short',
              'This password is stored in plaintext and is a known default/example value or is short (reported by length only: ' + val.length + ' characters). Anyone who reads this file — a backup, a screenshot, a repo leak — gets a working credential.',
              'Replace it with a unique password of at least 16 characters, store the file with owner-only permissions, and rotate the credential anywhere it was deployed.',
              val.length);
          } else {
            add(strong ? 'LOW' : 'MEDIUM','plaintext-password',L.n,key,'Plaintext password in the config file',
              'This password is stored in plaintext (reported by length only: ' + val.length + ' characters; value never shown). For accounts that support it, ProxySQL accepts a hashed password value in the config file, which removes the reusable secret from disk.',
              'Prefer the hashed password form where the account type supports it; otherwise restrict the file to owner-only permissions (0600) and keep it out of backups and source control.',
              val.length);
          }
        }
      }

      // --- Monitor account identity ---
      if(k === 'monitor_username' && val.toLowerCase() === 'root'){
        add('HIGH','monitor-excessive-privileges',L.n,key,'Monitor account is the database superuser',
          'The monitor account is configured as the database superuser account. The monitor only connects, pings, and reads health/replication state — running it as the superuser means a leaked monitor credential, or a flaw in the monitoring path, reaches everything.',
          'Create a dedicated monitor account with only the privileges monitoring needs and point monitor_username at it.');
      }

      // --- Web / REST / stats surfaces ---
      if((k === 'web_enabled' || k === 'restapi_enabled' || k === 'mysql-restapi_enabled') && truthy(val)){
        surfaces.push({ line: L.n, key: key });
      }
      if(k === 'stats_credentials' || k === 'admin-stats_credentials'){
        var spw = val.indexOf(':') >= 0 ? val.slice(val.indexOf(':') + 1) : val;
        if(isWeakSecret(spw) || spw.length < 12){
          add('HIGH','stats-default-credentials',L.n,key,'Stats credentials are default, example, or short',
            'The stats/web credential is a known default/example value or is short (reported by length only: ' + spw.length + ' characters). Stats endpoints leak topology, hostgroups, and query digests.',
            'Set a unique stats password of at least 16 characters, or disable the web/stats surface if it is not used.',
            spw.length);
        }
      }
    }
  });

  // --- Combined: admin on all interfaces + weak admin password ---
  if(adminAllLine && adminPwWeak && adminCredLine){
    add('CRITICAL','admin-exposed-default-password',adminCredLine,adminCredKey,'Admin interface exposed on all interfaces with a default/example admin password',
      'The admin listener is bound to all interfaces (line ' + adminAllLine + ') and the admin password is a default, example, or short value (line ' + adminCredLine + ', length ' + adminPwLen + '). Together these are a remotely reachable control plane with a publicly known key — the single most dangerous state a ProxySQL config can ship in.',
      'Fix both halves before deploy: bind the admin interface to localhost or a management address, and set a unique admin password of at least 16 characters.',
      adminPwLen);
  }

  // --- Web / REST surfaces: TLS + authentication posture ---
  surfaces.forEach(function(sf){
    if(!hasTLS || !hasAdminCreds || adminPwWeak){
      var bits = [];
      if(!hasTLS) bits.push('no TLS posture (no ssl / tls settings) appears anywhere in the paste');
      if(!hasAdminCreds) bits.push('no admin credential is stated in the paste to authenticate against');
      if(adminPwWeak) bits.push('the admin credential it would rely on is default, example, or short');
      add('HIGH','web-surface-exposed',sf.line,sf.key,'Web / REST API surface enabled without a safe posture as stated',
        'This surface is switched on, and as stated in the paste ' + bits.join('; ') + '. An unauthenticated or unencrypted admin/stats surface exposes topology, query digests, and — on the REST/admin side — control of the proxy.',
        'Turn the surface off if it is not needed. If it is needed, state TLS settings in the config, protect it with a strong unique credential, and bind or firewall it to management hosts only.');
    } else {
      add('LOW','web-surface-enabled',sf.line,sf.key,'Web / REST API surface enabled',
        'This surface is switched on, and the paste does state TLS settings and a non-default admin credential. Enabled admin surfaces still widen the attack surface.',
        'Confirm the surface is bound or firewalled to management hosts only, and re-check it after any credential rotation.');
    }
  });

  // --- No TLS posture while endpoints are exposed ---
  if(!hasTLS && (adminAllLine || surfaces.length)){
    add('MEDIUM','no-tls-posture',adminAllLine || surfaces[0].line, adminAllKey || surfaces[0].key,'No TLS posture stated while endpoints are exposed',
      'The paste exposes an admin or web endpoint, but no ssl / tls setting appears in any active line. Admin traffic — including credential changes — would cross the network unencrypted wherever the endpoint is reachable.',
      'State the TLS settings for the proxy (certificate, key, and CA where applicable) and require SSL for admin and application listeners that leave localhost.');
  }

  // Verdict
  var hasCrit = findings.some(function(f){ return f.severity === 'CRITICAL'; });
  var hasFix = findings.some(function(f){ return f.severity === 'HIGH' || f.severity === 'MEDIUM'; });
  result.verdict = hasCrit ? 'DO NOT DEPLOY' : (hasFix ? 'DEPLOY WITH FIXES' : 'SAFE TO DEPLOY');
  return finish(result);

  function finish(r){
    var order = { CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3, INFO: 4 };
    r.findings.sort(function(a, b){ return (order[a.severity] - order[b.severity]) || (a.line - b.line); });
    r.counts = { CRITICAL: 0, HIGH: 0, MEDIUM: 0, LOW: 0, INFO: 0 };
    r.findings.forEach(function(f){ r.counts[f.severity]++; });
    return r;
  }
}

function esc(s){
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

var lastResult = null;
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-proxysql-server-config-safety-auditortm',
  name: 'J-Dawgs ProxySQL Server Config Safety Auditor',
  description: 'Grades a pasted ProxySQL configuration fully offline into one deploy verdict, with plaintext secrets shown by key name, line, and length only, never by value. ProxySQL only exercises a config by loading it into the proxy; this grades it before anything loads.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
