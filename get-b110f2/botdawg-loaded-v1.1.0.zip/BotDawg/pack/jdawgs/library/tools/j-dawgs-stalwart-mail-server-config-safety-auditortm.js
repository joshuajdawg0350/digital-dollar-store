'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Stalwart Mail Server Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      var RISKY = [
        '# RISKY EXAMPLE - a config shaped like this should not go live',
        '[server.listener.smtp]',
        'bind = ["[::]:25"]',
        'tls.implicit = false',
        'protocol = "smtp"',
        '',
        '[server.listener.submission]',
        'bind = ["0.0.0.0:587"]',
        'tls.implicit = false',
        'protocol = "submission"',
        '',
        '[server.listener.imap]',
        'bind = ["0.0.0.0:143"]',
        'tls.implicit = false',
        'protocol = "imap"',
        '',
        '[server.listener.management]',
        'bind = ["0.0.0.0:8080"]',
        'protocol = "http"',
        '',
        '[server.security]',
        'allow-plain-text-auth = true',
        '',
        '[session.rcpt]',
        'relay = true',
        '',
        '[authentication.fallback-admin]',
        'user = "admin"',
        'secret = "changeme-9917-planted"',
        '',
        '[spam-filter]',
        'enabled = false',
        '',
        '[rate-limit]',
        'enabled = false'
      ].join("\n");

      var HARDENED = [
        '# HARDENED EXAMPLE - the shape of a safer config',
        '[server.listener.smtp]',
        'bind = ["192.0.2.10:25"]',
        'protocol = "smtp"',
        'tls.required = true',
        '',
        '[server.listener.submission]',
        'bind = ["192.0.2.10:587"]',
        'protocol = "submission"',
        'tls.implicit = true',
        '',
        '[server.listener.imaps]',
        'bind = ["192.0.2.10:993"]',
        'protocol = "imap"',
        'tls.implicit = true',
        '',
        '[server.listener.management]',
        'bind = ["127.0.0.1:8080"]',
        'protocol = "http"',
        'tls.implicit = true',
        '',
        '[server.security]',
        'allow-plain-text-auth = false',
        'require-tls = true',
        '',
        '[session.rcpt]',
        'relay = false',
        'relay-allowed-hosts = ["192.0.2.0/24"]',
        '',
        '[authentication.fallback-admin]',
        'user = "admin"',
        'secret = "kX7mQ2vR9zL4pT8wN3sY6bH1dF5"',
        '',
        '[spam-filter]',
        'enabled = true',
        '',
        '[rate-limit]',
        'enabled = true',
        'max-connections = 10'
      ].join("\n");

      var input = document.getElementById('input');
      var inputMeta = document.getElementById('inputMeta');
      var verdictBox = document.getElementById('verdict');
      var verdictWord = document.getElementById('verdictWord');
      var verdictDetail = document.getElementById('verdictDetail');
      var chips = document.getElementById('chips');
      var findingsEl = document.getElementById('findings');
      var fixListEl = document.getElementById('fixList');
      var exportBox = document.getElementById('exportBox');
      var copyStatus = document.getElementById('copyStatus');
      var lastResult = null;

      function updateMeta(){
        var t = input.value;
        var n = t === '' ? 0 : t.split('\n').length;
        inputMeta.textContent = n + (n === 1 ? ' line' : ' lines');
      }
      input.addEventListener('input', updateMeta);

      /* ---------- parsing ---------- */

      function parseScalar(raw){
        raw = raw.trim();
        if (raw.length >= 2 && raw.charAt(0) === '"' ){
          var end = raw.lastIndexOf('"');
          if (end > 0) return raw.slice(1, end);
        }
        if (raw.length >= 2 && raw.charAt(0) === "'"){
          var end2 = raw.lastIndexOf("'");
          if (end2 > 0) return raw.slice(1, end2);
        }
        return raw;
      }

      function bracketBalance(s){
        var d = 0, inStr = false, q = '';
        for (var i = 0; i < s.length; i++){
          var c = s.charAt(i);
          if (inStr){ if (c === q) inStr = false; continue; }
          if (c === '"' || c === "'"){ inStr = true; q = c; continue; }
          if (c === '[') d++;
          if (c === ']') d--;
        }
        return d;
      }

      function parseToml(text){
        var lines = text.split('\n');
        var entries = [], notParsed = [], section = '';
        var pending = 0;
        for (var i = 0; i < lines.length; i++){
          var lineNo = i + 1;
          var raw = lines[i];
          var t = raw.trim();
          if (pending > 0){
            pending += bracketBalance(t);
            if (pending < 0) pending = 0;
            continue;
          }
          if (t === '' || t.charAt(0) === '#' || t.charAt(0) === ';') continue;
          if (t.charAt(0) === '['){
            var m = t.match(/^\[([^\]]+)\]\s*(#.*)?$/);
            if (m){ section = m[1].trim().replace(/^"|"$/g,''); continue; }
            notParsed.push(lineNo); continue;
          }
          var eq = t.indexOf('=');
          if (eq > 0){
            var key = t.slice(0, eq).trim().replace(/^"|"$/g,'');
            var valRaw = t.slice(eq + 1).trim();
            if (!/^[A-Za-z0-9_.\-\[\]]+$/.test(key) || valRaw === ''){ notParsed.push(lineNo); continue; }
            var bal = bracketBalance(valRaw);
            if (bal > 0) pending = bal;
            entries.push({
              path: section ? section + '.' + key : key,
              key: key,
              lastKey: key.split('.').pop(),
              section: section,
              value: parseScalar(valRaw),
              rawValue: valRaw,
              line: lineNo
            });
            continue;
          }
          notParsed.push(lineNo);
        }
        return { entries: entries, notParsed: notParsed, lineCount: lines.length };
      }

      function flattenJson(obj, prefix, entries, lines, state){
        Object.keys(obj).forEach(function(k){
          var v = obj[k];
          var path = prefix ? prefix + '.' + k : k;
          var line = findJsonLine(lines, k, state);
          if (v !== null && typeof v === 'object' && !Array.isArray(v)){
            flattenJson(v, path, entries, lines, state);
          } else {
            var val;
            if (Array.isArray(v)) val = v.map(function(x){ return String(x); }).join(', ');
            else val = String(v);
            entries.push({ path: path, key: k, lastKey: k, section: prefix, value: val, rawValue: val, line: line });
          }
        });
      }
      function findJsonLine(lines, key, state){
        var needle = '"' + key + '"';
        for (var i = state.idx; i < lines.length; i++){
          if (lines[i].indexOf(needle) !== -1){ state.idx = i; return i + 1; }
        }
        for (var j = 0; j < lines.length; j++){
          if (lines[j].indexOf(needle) !== -1) return j + 1;
        }
        return 1;
      }

      /* ---------- check helpers ---------- */

      function isFalseVal(v){ v = String(v).trim().toLowerCase(); return v === 'false' || v === 'disabled' || v === 'none' || v === 'off' || v === 'no'; }
      function isTrueVal(v){ v = String(v).trim().toLowerCase(); return v === 'true' || v === 'enabled' || v === 'yes' || v === 'on'; }
      function isAllInterface(v){
        v = String(v);
        return v.indexOf('0.0.0.0') !== -1 || v.indexOf('[::]:') !== -1 || v.trim() === '::' || v.indexOf('"*"') !== -1 || v.indexOf("'*'") !== -1;
      }
      function portOf(v){
        var m = String(v).match(/:(\d{2,5})(?=["'\],\s]|$)/);
        return m ? parseInt(m[1], 10) : null;
      }
      var SECRET_KEY = /(password|passwd|secret|api[-_]?key|access[-_]?key|private[-_]?key|token|credential)/i;
      var PLACEHOLDERS = ['changeme','change-me','change_me','placeholder','example','your-password','your_password','replace-me','replace_me','todo','xxx','123456','password','letmein','default'];

      function audit(text){
        var findings = [];
        function add(sev, line, check, detail, fix){
          findings.push({ severity: sev, line: line, check: check, detail: detail, fix: fix });
        }

        if (!text || text.trim() === ''){
          return { verdict: 'NOT ENOUGH TO GRADE', format: 'none', findings: [], fixes: [], lineCount: 0, counts: null,
                   detail: 'The box is empty. Paste a config (or load an example) and audit again.' };
        }

        var trimmed = text.trim();
        var format, entries = [], notParsed = [], lines = text.split('\n');

        if (trimmed.charAt(0) === '{'){
          format = 'JSON';
          try {
            var obj = JSON.parse(text);
            flattenJson(obj, '', entries, lines, { idx: 0 });
          } catch (e) {
            add('BLOCKER', 1, 'NOT PARSED', 'This input looked like JSON but could not be parsed, so nothing in it was graded. The auditor did not guess at its meaning.', 'Fix the JSON syntax, then audit again.');
            return finish('DO NOT DEPLOY', format, findings, lines.length, 'The JSON could not be parsed at all.');
          }
        } else {
          format = 'TOML';
          var parsed = parseToml(text);
          entries = parsed.entries; notParsed = parsed.notParsed;
        }

        notParsed.forEach(function(ln){
          add('WARNING', ln, 'NOT PARSED', 'Line ' + ln + ' could not be understood as a setting, a section, or a comment, so it was not graded. Its contents were not guessed at and are not shown here.', 'Fix the syntax of line ' + ln + ' so it reads as a valid setting, then audit again.');
        });

        /* global signals */
        var plaintextAllowed = false, plaintextLine = 0;
        var globalTlsOff = false;
        entries.forEach(function(e){
          var k = (e.path + ' ' + e.key).toLowerCase();
          if (/plain/.test(k) && isTrueVal(e.value)){ plaintextAllowed = true; plaintextLine = e.line; }
          if (/allow[-_]?plain/.test(k) && isTrueVal(e.value)){ plaintextAllowed = true; plaintextLine = e.line; }
          if (/tls/.test(e.lastKey.toLowerCase()) && isFalseVal(e.value) && !/listener/.test(e.path.toLowerCase())) globalTlsOff = true;
        });

        /* listeners */
        var groups = {}, groupOrder = [];
        entries.forEach(function(e){
          var segs = e.path.split('.');
          for (var i = 0; i < segs.length - 1; i++){
            if (segs[i].toLowerCase() === 'listener' || segs[i].toLowerCase() === 'listeners'){
              var gid = segs.slice(0, i + 2).join('.');
              if (!groups[gid]){ groups[gid] = { id: gid, name: segs[i + 1], entries: [] }; groupOrder.push(gid); }
              groups[gid].entries.push(e);
              break;
            }
          }
        });

        groupOrder.forEach(function(gid){
          var g = groups[gid];
          var name = g.name || gid;
          var binds = [], tlsOffLine = 0, tlsOptionalLine = 0, protocol = '', firstLine = g.entries.length ? g.entries[0].line : 0;
          g.entries.forEach(function(e){
            var lk = e.lastKey.toLowerCase();
            if (lk === 'bind' || lk === 'address' || lk === 'host' || lk === 'listen') binds.push(e);
            if (lk === 'protocol') protocol = String(e.value).toLowerCase();
            if (lk.indexOf('tls') !== -1 || e.key.toLowerCase().indexOf('tls') !== -1){
              if (isFalseVal(e.value)) tlsOffLine = e.line;
              if (String(e.value).toLowerCase().indexOf('optional') !== -1) tlsOptionalLine = e.line;
              if (lk.indexOf('optional') !== -1 && isTrueVal(e.value)) tlsOptionalLine = e.line;
            }
          });
          var typeStr = (name + ' ' + protocol).toLowerCase();
          var ports = binds.map(function(b){ return portOf(b.rawValue); });
          var isAdmin = /admin|management|manage|http/.test(typeStr) || ports.indexOf(8080) !== -1;
          var isMail = /smtp|submission|imap|pop/.test(typeStr) || ports.some(function(p){ return [25,465,587,143,993,110,995].indexOf(p) !== -1; });
          var isSubmissionOrImap = /submission|imap/.test(typeStr) || ports.some(function(p){ return [465,587,143,993].indexOf(p) !== -1; });

          if (tlsOffLine && isMail){
            add('BLOCKER', tlsOffLine, 'TLS disabled on a mail listener',
              'The "' + name + '" listener has TLS turned off. Mail and logins on this listener can cross the network unencrypted.',
              'Turn TLS on for the "' + name + '" listener (implicit TLS or required STARTTLS) and give it a valid certificate.');
          } else if (tlsOffLine){
            add('WARNING', tlsOffLine, 'TLS disabled on a listener',
              'The "' + name + '" listener has TLS turned off.',
              'Turn TLS on for the "' + name + '" listener.');
          }
          if (tlsOptionalLine && isSubmissionOrImap){
            add('BLOCKER', tlsOptionalLine, 'TLS optional on submission/IMAP',
              'The "' + name + '" listener treats TLS as optional, so clients can still connect and log in without encryption.',
              'Make TLS required on the "' + name + '" listener.');
          } else if (tlsOptionalLine){
            add('WARNING', tlsOptionalLine, 'TLS optional on a listener',
              'The "' + name + '" listener treats TLS as optional.',
              'Make TLS required on the "' + name + '" listener where clients log in.');
          }

          binds.forEach(function(b){
            if (!isAllInterface(b.rawValue)) return;
            if (isAdmin){
              add('BLOCKER', b.line, 'Admin interface exposed on all interfaces',
                'The "' + name + '" (admin/management) listener is bound to all network interfaces, so the admin surface is reachable from anywhere the network allows.',
                'Bind the "' + name + '" listener to localhost (127.0.0.1) or a private management address only.');
            }
            if (tlsOffLine || plaintextAllowed || globalTlsOff){
              add('BLOCKER', b.line, 'All-interface bind with weak encryption/auth',
                'The "' + name + '" listener is bound to all network interfaces while TLS is off or plain-text authentication is allowed elsewhere in this config. That combination exposes unencrypted logins to the whole network.',
                'Bind the "' + name + '" listener to a specific interface, and turn TLS on / plain-text auth off.');
            } else if (!isAdmin) {
              add('WARNING', b.line, 'Listener bound to all interfaces',
                'The "' + name + '" listener is bound to all network interfaces (0.0.0.0 / [::]). That is normal for a public mail port, but it means every other setting on this listener is internet-facing.',
                'Confirm the "' + name + '" listener is meant to be public; otherwise bind it to a specific interface.');
            }
          });
          if (!binds.length && isMail){
            add('INFO', firstLine, 'No bind found for a listener',
              'No bind/address line was found for the "' + name + '" listener, so its exposure could not be graded.',
              'Set an explicit bind for the "' + name + '" listener so its exposure is a deliberate choice.');
          }
        });

        /* plaintext auth (global) */
        if (plaintextAllowed){
          add('BLOCKER', plaintextLine, 'Plain-text authentication allowed',
            'This config allows plain-text authentication, so passwords can be sent without encryption on any connection that is not protected by TLS.',
            'Disallow plain-text authentication and require TLS before login.');
        }

        /* auth disabled */
        entries.forEach(function(e){
          var lk = e.lastKey.toLowerCase();
          if ((lk === 'auth' || lk === 'authentication' || lk === 'require-auth') && isFalseVal(e.value)){
            add('BLOCKER', e.line, 'Authentication not required',
              'Setting "' + e.key + '" (line ' + e.line + ') turns authentication off or makes it not required.',
              'Require authentication for submission and account access.');
          }
        });

        /* relay */
        var relayEntries = entries.filter(function(e){ return /relay/.test((e.path + ' ' + e.key).toLowerCase()); });
        if (!relayEntries.length){
          add('WARNING', 0, 'No relay restrictions found',
            'Nothing in this config says who may relay mail through this server. Silence is not a restriction — the server default decides.',
            'Add explicit relay restrictions: relay only for authenticated users and trusted hosts.');
        } else {
          relayEntries.forEach(function(e){
            var v = String(e.value).toLowerCase();
            if (isTrueVal(e.value) || v === 'open' || v === 'unrestricted' || v === 'any' || v === 'all' || e.rawValue.indexOf('0.0.0.0/0') !== -1 || e.rawValue.indexOf('::/0') !== -1){
              add('BLOCKER', e.line, 'Open relay posture',
                'Setting "' + e.key + '" (line ' + e.line + ') leaves relaying open or unrestricted. An open relay gets a server blocklisted fast and lets strangers send mail as you.',
                'Restrict relaying to authenticated users and named trusted hosts only.');
            }
          });
        }

        /* secrets — key name, line, length ONLY. The value is never copied into any finding. */
        entries.forEach(function(e){
          if (!SECRET_KEY.test(e.key) && !SECRET_KEY.test(e.lastKey)) return;
          var val = String(e.value);
          var len = val.length;
          var lower = val.toLowerCase();
          var isPlaceholder = PLACEHOLDERS.some(function(p){ return lower === p || lower.indexOf(p) === 0 || lower.indexOf(p) !== -1 && p.length >= 8; });
          var keyName = e.lastKey;
          if (isPlaceholder){
            add('BLOCKER', e.line, 'Placeholder secret',
              'Secret key "' + keyName + '" on line ' + e.line + ' holds a placeholder-style value (length ' + len + '). Anyone who has seen a sample config can guess it. (The value itself is never shown in this audit.)',
              'Replace the value of "' + keyName + '" (line ' + e.line + ') with a long, unique, randomly generated secret.');
          } else if (len < 16){
            add('BLOCKER', e.line, 'Short secret',
              'Secret key "' + keyName + '" on line ' + e.line + ' is only ' + len + ' characters long. Short secrets are guessable. (The value itself is never shown in this audit.)',
              'Replace the value of "' + keyName + '" (line ' + e.line + ') with a secret of at least 24 random characters.');
          } else {
            add('INFO', e.line, 'Secret present',
              'Secret key "' + keyName + '" on line ' + e.line + ' is set (value length ' + len + '). Its length looks reasonable; the value itself is never shown in this audit.',
              'No change needed for length. Keep the value out of shared copies of this config.');
          }
        });

        /* rate limiting / anti-spam */
        var hasRate = false, hasSpam = false;
        entries.forEach(function(e){
          var p = (e.path + ' ' + e.key).toLowerCase();
          if (/rate|throttle|limit/.test(p)){
            hasRate = true;
            if (isFalseVal(e.value)){
              add('WARNING', e.line, 'Rate limiting disabled',
                'Setting "' + e.key + '" (line ' + e.line + ') disables a rate limit or throttle, leaving the server open to brute-force logins and floods.',
                'Turn rate limiting on for logins and connections.');
            }
          }
          if (/spam|abuse|milter|rspamd|greylist/.test(p)){
            hasSpam = true;
            if (isFalseVal(e.value)){
              add('WARNING', e.line, 'Anti-spam disabled',
                'Setting "' + e.key + '" (line ' + e.line + ') disables an anti-spam or anti-abuse control.',
                'Turn anti-spam filtering on before this server faces the internet.');
            }
          }
        });
        if (!hasRate){
          add('WARNING', 0, 'No rate limiting found',
            'No rate-limit, throttle, or connection-limit setting appears in this config. Without one, login guessing and connection floods are unthrottled.',
            'Add rate limiting for authentication attempts and connections.');
        }
        if (!hasSpam){
          add('WARNING', 0, 'No anti-spam setting found',
            'No anti-spam or anti-abuse setting appears in this config.',
            'Enable anti-spam filtering (and greylisting where it fits) before deploying.');
        }

        var blockers = findings.filter(function(f){ return f.severity === 'BLOCKER'; }).length;
        var verdict, detail;
        if (blockers > 0){
          verdict = 'DO NOT DEPLOY';
          detail = blockers + (blockers === 1 ? ' blocker' : ' blockers') + ' found. Fix every blocker before this config goes on a live server.';
        } else if (findings.some(function(f){ return f.severity === 'WARNING'; })){
          verdict = 'DEPLOY WITH FIXES';
          detail = 'No blockers, but warnings need attention first — see the fix list.';
        } else {
          verdict = 'SAFE TO DEPLOY';
          detail = 'No blockers and no warnings. This grades the safety settings in the pasted text only — it is not a promise the config will load.';
        }
        return finish(verdict, format, findings, lines.length, detail);
      }

      function finish(verdict, format, findings, lineCount, detail){
        var rank = { BLOCKER: 0, WARNING: 1, INFO: 2 };
        findings.sort(function(a, b){
          var r = rank[a.severity] - rank[b.severity];
          return r !== 0 ? r : (a.line || 0) - (b.line || 0);
        });
        var fixes = [], seen = {};
        findings.forEach(function(f){
          if (f.severity === 'INFO') return;
          if (!seen[f.fix]){ seen[f.fix] = true; fixes.push(f.fix); }
        });
        return { verdict: verdict, format: format, findings: findings, fixes: fixes, lineCount: lineCount, detail: detail,
                 counts: {
                   blocker: findings.filter(function(f){ return f.severity === 'BLOCKER'; }).length,
                   warning: findings.filter(function(f){ return f.severity === 'WARNING'; }).length,
                   info: findings.filter(function(f){ return f.severity === 'INFO'; }).length,
                   notParsed: findings.filter(function(f){ return f.check === 'NOT PARSED'; }).length
                 } };
      }

      /* ---------- rendering ---------- */

      function esc(s){
        return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
      }

      function render(result){
        lastResult = result;
        verdictWord.textContent = result.verdict;
        verdictDetail.textContent = result.detail || '';
        verdictBox.className = result.verdict === 'SAFE TO DEPLOY' ? 'safe'
          : result.verdict === 'DEPLOY WITH FIXES' ? 'fixes'
          : result.verdict === 'DO NOT DEPLOY' ? 'danger' : 'neutral';
        verdictBox.id = 'verdict';
        if (result.counts){
          chips.innerHTML =
            '<span class="chip b">BLOCKER ' + result.counts.blocker + '</span>' +
            '<span class="chip w">WARNING ' + result.counts.warning + '</span>' +
            '<span class="chip i">INFO ' + result.counts.info + '</span>' +
            '<span class="chip">NOT PARSED ' + result.counts.notParsed + '</span>' +
            '<span class="chip">' + esc(result.format) + ' · ' + result.lineCount + ' lines</span>';
        } else chips.innerHTML = '';

        if (!result.findings.length){
          findingsEl.innerHTML = '<p class="meta">No findings.</p>';
        } else {
          findingsEl.innerHTML = result.findings.map(function(f){
            var sevLabel = f.check === 'NOT PARSED' ? 'NOT PARSED' : f.severity;
            var sevClass = f.check === 'NOT PARSED' ? 'NOTPARSED' : f.severity;
            return '<div class="finding"><span class="sev ' + sevClass + '">' + sevLabel + '</span> ' +
              '<span class="line-no">' + (f.line ? 'Line ' + f.line : 'Whole config') + '</span> — <strong>' + esc(f.check) + '</strong><br>' +
              esc(f.detail) + '<span class="fix">Fix: ' + esc(f.fix) + '</span></div>';
          }).join('');
        }

        if (!result.fixes.length){
          fixListEl.innerHTML = '<li class="meta">Nothing to fix.</li>';
        } else {
          fixListEl.innerHTML = result.fixes.map(function(fx){ return '<li>' + esc(fx) + '</li>'; }).join('');
        }
        exportBox.value = reportText(result);
      }

      function reportText(r){
        var out = [];
        out.push('J-Dawgs Stalwart Mail Server Config Safety Auditor\u2122 - Audit Report');
        out.push('Verdict: ' + r.verdict);
        out.push('Format detected: ' + r.format + ' | Lines audited: ' + r.lineCount);
        if (r.counts) out.push('Counts: BLOCKER ' + r.counts.blocker + ' | WARNING ' + r.counts.warning + ' | INFO ' + r.counts.info + ' | NOT PARSED ' + r.counts.notParsed);
        out.push('');
        out.push('Findings:');
        if (!r.findings.length) out.push('  (none)');
        r.findings.forEach(function(f, i){
          out.push('  ' + (i + 1) + '. [' + (f.check === 'NOT PARSED' ? 'NOT PARSED' : f.severity) + '] ' + (f.line ? 'Line ' + f.line : 'Whole config') + ' - ' + f.check + ': ' + f.detail);
        });
        out.push('');
        out.push('Fix list:');
        if (!r.fixes.length) out.push('  (nothing to fix)');
        r.fixes.forEach(function(fx, i){ out.push('  ' + (i + 1) + '. ' + fx); });
        out.push('');
        out.push('Note: secrets are reported by key name, line number, and value length only. No secret value appears in this report.');
        return out.join('\n');
      }

      function jsonText(r){
        return JSON.stringify({
          tool: 'J-Dawgs Stalwart Mail Server Config Safety Auditor\u2122',
          verdict: r.verdict,
          formatDetected: r.format,
          linesAudited: r.lineCount,
          counts: r.counts || { blocker: 0, warning: 0, info: 0, notParsed: 0 },
          findings: r.findings.map(function(f){
            return { severity: f.check === 'NOT PARSED' ? 'NOT PARSED' : f.severity, line: f.line, check: f.check, detail: f.detail, fix: f.fix };
          }),
          fixList: r.fixes,
          secretHandling: 'Secrets are reported by key name, line number, and value length only. No secret value is included in this export.'
        }, null, 2);
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-stalwart-mail-server-config-safety-auditortm',
  name: 'J-Dawgs Stalwart Mail Server Config Safety Auditor',
  description: 'Stalwart\'s own checks only answer whether the mail server starts on the host; ours grades a pasted Stalwart mail server config (TOML/JSON) fully offline — listener and TLS posture, authentication and storage settings, plaintext secrets shown by key name/line/length only — into one deploy verdict: SA',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
