'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Tree Removal Proposal, Work Record & Final Invoice Consistency Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

      "use strict";

      /* ---------- Example documents (exact) ---------- */
      var INC_PROPOSAL = "Tree Removal Proposal — GreenCut Tree Service\nOak tree removal: $800.00\nPine tree removal: $600.00\nMaple tree removal: $700.00\nStump grinding: $150.00 per stump x 3 stumps = $450.00\nHauling and debris removal: $250.00\nCrane rental: $500.00\nDeposit paid: $400.00\nProposal total: $3,300.00";
      var INC_WORK = "Work Record — GreenCut Tree Service\nTrees removed: 2 (Oak, Pine)\nStumps ground: 2\nLabor: 6 hours x $75.00 per hour = $450.00\nEquipment used: chainsaw, chipper\nHauling done: yes\nCrane used: no";
      var INC_INVOICE = "Final Invoice — GreenCut Tree Service\nOak tree removal: $900.00\nPine tree removal: $600.00\nMaple tree removal: $700.00\nStump grinding: $450.00\nLabor: $650.00\nCrane rental: $500.00\nHauling and debris removal: $250.00\nHauling and debris removal: $250.00\nAdmin fee: $75.00\nInvoice total: $4,375.00\nDeposit credit: $0.00";

      var OK_PROPOSAL = "Tree Removal Proposal — GreenCut Tree Service\nOak tree removal: $800.00\nPine tree removal: $600.00\nStump grinding: $150.00 per stump x 2 stumps = $300.00\nHauling and debris removal: $250.00\nDeposit paid: $300.00\nProposal total: $1,950.00";
      var OK_WORK = "Work Record — GreenCut Tree Service\nTrees removed: 2 (Oak, Pine)\nStumps ground: 2\nLabor: 5 hours x $80.00 per hour = $400.00\nEquipment used: chainsaw, chipper\nHauling done: yes\nCrane used: no";
      var OK_INVOICE = "Final Invoice — GreenCut Tree Service\nOak tree removal: $800.00\nPine tree removal: $600.00\nStump grinding: $300.00\nLabor: $400.00\nHauling and debris removal: $250.00\nInvoice total: $2,350.00\nDeposit credit: $300.00";

      /* ---------- Helpers ---------- */
      var TREE_TYPES = ["oak", "pine", "maple", "elm", "ash", "birch", "cedar", "walnut", "hickory", "poplar", "willow", "spruce", "fir", "cherry", "apple", "pecan", "magnolia", "dogwood", "redwood", "palm", "locust", "sycamore", "cottonwood", "juniper", "cypress", "beech", "chestnut", "mesquite", "eucalyptus"];
      var EQUIP_KEYWORDS = ["crane", "bucket truck", "aerial lift", "excavator", "skid steer", "chipper", "trencher", "loader"];

      function round2(n) { return Math.round(n * 100) / 100; }
      function money(n) {
        var neg = n < 0; var v = Math.abs(round2(n));
        var s = v.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        return (neg ? "-$" : "$") + s;
      }
      function cap(s) { return s ? s.charAt(0).toUpperCase() + s.slice(1) : s; }
      function titleLabel(s) {
        return s.split(/\s+/).map(function (w) { return w ? cap(w) : w; }).join(" ");
      }
      function trimNum(n) {
        if (Math.abs(n - Math.round(n)) < 0.001) return String(Math.round(n));
        return String(round2(n));
      }
      function amountsIn(str) {
        var out = [], re = /\$\s*([\d,]+(?:\.\d{1,2})?)/g, m;
        while ((m = re.exec(str)) !== null) out.push(parseFloat(m[1].replace(/,/g, "")));
        return out;
      }
      function lineAmount(line) {
        var amts = amountsIn(line);
        if (!amts.length) return null;
        var eq = line.lastIndexOf("=");
        if (eq >= 0) {
          var after = amountsIn(line.slice(eq + 1));
          if (after.length) return after[0];
        }
        return amts[amts.length - 1];
      }
      function lineLabel(line) {
        var s = line.split("$")[0];
        s = s.replace(/[:=\-—]\s*$/, "").trim().toLowerCase().replace(/\s+/g, " ");
        return s;
      }
      function treeTypeIn(text) {
        var low = " " + text.toLowerCase() + " ";
        for (var i = 0; i < TREE_TYPES.length; i++) {
          if (new RegExp("\\b" + TREE_TYPES[i] + "\\b").test(low)) return TREE_TYPES[i];
        }
        if (/\btree\b/.test(low)) return "tree";
        return null;
      }

      /* Per-tree prices: lines naming a tree type (or "tree") with a dollar amount. */
      function treePrices(text) {
        var map = {}, order = [];
        text.split(/\r?\n/).forEach(function (line) {
          var low = line.toLowerCase();
          if (low.indexOf("total") >= 0) return;
          var amt = lineAmount(line);
          if (amt === null) return;
          var t = treeTypeIn(line);
          if (!t) return;
          if (t === "tree" && !/removal|removing|cut|fell/.test(low)) return;
          if (!(t in map)) { map[t] = { price: amt }; order.push(t); }
          else { map[t].price = amt; }
        });
        return { map: map, order: order };
      }

      function parseWork(text) {
        var w = { treesRemoved: null, removedNames: [], stumpsGround: null,
                  laborHours: null, laborRate: null, laborExpected: null,
                  craneUsed: null, equipmentText: "" };
        var m;
        m = text.match(/trees removed:\s*(\d+)/i);
        if (m) w.treesRemoved = parseInt(m[1], 10);
        m = text.match(/trees removed:[^\n]*\(([^)]*)\)/i);
        if (m) {
          w.removedNames = m[1].split(",").map(function (s) { return s.trim().toLowerCase(); }).filter(function (s) { return s.length > 0; });
        }
        m = text.match(/stumps ground:\s*(\d+)/i);
        if (m) w.stumpsGround = parseInt(m[1], 10);
        m = text.match(/labor:[^\n]*?(\d+(?:\.\d+)?)\s*hours?\s*x\s*\$([\d,]+(?:\.\d{1,2})?)/i);
        if (m) {
          w.laborHours = parseFloat(m[1]);
          w.laborRate = parseFloat(m[2].replace(/,/g, ""));
          w.laborExpected = round2(w.laborHours * w.laborRate);
        }
        m = text.match(/crane used:\s*(yes|no)/i);
        if (m) w.craneUsed = (m[1].toLowerCase() === "yes");
        m = text.match(/equipment used:\s*(.*)/i);
        if (m) w.equipmentText = m[1].toLowerCase();
        if (w.craneUsed === null && w.equipmentText.indexOf("crane") >= 0) w.craneUsed = true;
        return w;
      }

      /* ---------- The audit ---------- */
      function audit(proposalText, workText, invoiceText) {
        var hasP = !!(proposalText && proposalText.trim().length > 0);
        var hasW = !!(workText && workText.trim().length > 0);
        var hasI = !!(invoiceText && invoiceText.trim().length > 0);
        var present = (hasP ? 1 : 0) + (hasW ? 1 : 0) + (hasI ? 1 : 0);
        var missing = [];
        if (!hasP) missing.push("Proposal");
        if (!hasW) missing.push("Work Record");
        if (!hasI) missing.push("Final Invoice");

        if (present < 2) {
          return { verdict: "NOT ENOUGH TO COMPARE", total: 0, findings: [], missing: missing, present: present };
        }

        var P = proposalText || "", W = workText || "", I = invoiceText || "";
        var pLow = P.toLowerCase(), wLow = W.toLowerCase();
        var findings = [];
        var propTrees = treePrices(P), invTrees = treePrices(I);
        var work = parseWork(W);

        /* Proposal extras: stump rate (default $150) and deposit paid. */
        var stumpRate = 150, m;
        m = P.match(/stump[^\n]*\$\s*([\d,]+(?:\.\d{1,2})?)\s*per stump/i);
        if (m) stumpRate = parseFloat(m[1].replace(/,/g, ""));
        var depositPaid = 0;
        m = P.match(/deposit paid:\s*\$\s*([\d,]+(?:\.\d{1,2})?)/i);
        if (m) depositPaid = parseFloat(m[1].replace(/,/g, ""));

        /* Invoice charge lines (exclude totals and the deposit credit line). */
        var charges = [];
        I.split(/\r?\n/).forEach(function (raw) {
          var amt = lineAmount(raw);
          if (amt === null) return;
          var label = lineLabel(raw);
          if (!label) return;
          if (label.indexOf("total") >= 0) return;
          if (label.indexOf("deposit") >= 0) return;
          charges.push({ raw: raw.trim(), label: label, amount: amt, dup: false, equip: false });
        });
        var depositCredit = 0;
        m = I.match(/deposit credit:\s*\$\s*([\d,]+(?:\.\d{1,2})?)/i);
        if (m) depositCredit = parseFloat(m[1].replace(/,/g, ""));

        function findCharge(substr) {
          for (var i = 0; i < charges.length; i++) {
            if (charges[i].label.indexOf(substr) >= 0) return charges[i];
          }
          return null;
        }

        /* (a) + (b): per-tree — billed but not removed, and price increases. */
        var notRemoved = {};
        if (hasI) {
          invTrees.order.forEach(function (t) {
            var info = invTrees.map[t];
            var flaggedNR = false;
            if (hasW && work.treesRemoved !== null && work.removedNames.length > 0 && t !== "tree" &&
                work.removedNames.indexOf(t) < 0) {
              flaggedNR = true;
            }
            if (flaggedNR) {
              notRemoved[t] = true;
              findings.push({
                check: "Tree billed but not removed",
                details: cap(t) + " tree removal billed " + money(info.price) + " on the invoice, but the work record lists trees removed as " +
                  work.removedNames.map(cap).join(", ") + " — " + cap(t) + " is not among them. Overcharge = " + money(info.price) + ".",
                amount: info.price, severe: true
              });
              return;
            }
            if (hasP && propTrees.map[t]) {
              var diff = round2(info.price - propTrees.map[t].price);
              if (diff > 0) {
                findings.push({
                  check: "Per-tree price increase",
                  details: cap(t) + " tree removal: invoice " + money(info.price) + " − proposal " + money(propTrees.map[t].price) + " = " + money(diff) + ".",
                  amount: diff, severe: false
                });
              }
            }
          });
          /* Count fallback: no tree names listed in the work record. */
          if (hasW && work.treesRemoved !== null && work.removedNames.length === 0 &&
              invTrees.order.length > work.treesRemoved) {
            invTrees.order.slice(work.treesRemoved).forEach(function (t) {
              if (notRemoved[t]) return;
              notRemoved[t] = true;
              findings.push({
                check: "Tree billed but not removed",
                details: "Invoice bills " + invTrees.order.length + " trees but the work record shows only " + work.treesRemoved +
                  " trees removed. " + cap(t) + " tree removal billed " + money(invTrees.map[t].price) + " is beyond the removed count. Overcharge = " + money(invTrees.map[t].price) + ".",
                amount: invTrees.map[t].price, severe: true
              });
            });
          }
        }

        /* (c) Stump grinding billed above stumps ground. */
        var stumpLine = findCharge("stump");
        if (hasI && hasW && stumpLine && work.stumpsGround !== null) {
          var expectedStump = round2(work.stumpsGround * stumpRate);
          var overStump = round2(stumpLine.amount - expectedStump);
          if (overStump > 0) {
            var billedStumps = stumpRate > 0 ? stumpLine.amount / stumpRate : 0;
            findings.push({
              check: "Stump grinding overbilled",
              details: "Stump grinding billed " + money(stumpLine.amount) + " = " + trimNum(billedStumps) + " stumps at " + money(stumpRate) +
                " per stump (proposal rate), but the work record shows " + work.stumpsGround + " stumps ground. (" + trimNum(billedStumps) +
                " − " + work.stumpsGround + ") × " + money(stumpRate) + " = " + money(overStump) + ".",
              amount: overStump, severe: false
            });
          }
        }

        /* (d) Labor billed above hours × crew rate from the work record. */
        var laborLine = findCharge("labor");
        if (hasI && hasW && laborLine && work.laborExpected !== null) {
          var overLabor = round2(laborLine.amount - work.laborExpected);
          if (overLabor > 0) {
            findings.push({
              check: "Labor overbilled",
              details: "Labor billed " + money(laborLine.amount) + " on the invoice, but the work record shows " + trimNum(work.laborHours) +
                " hours × " + money(work.laborRate) + " per hour = " + money(work.laborExpected) + ". " + money(laborLine.amount) +
                " − " + money(work.laborExpected) + " = " + money(overLabor) + ".",
              amount: overLabor, severe: false
            });
          }
        }

        /* (e) Crane / equipment billed but not recorded as used. */
        if (hasI && hasW) {
          charges.forEach(function (l) {
            for (var k = 0; k < EQUIP_KEYWORDS.length; k++) {
              var kw = EQUIP_KEYWORDS[k];
              if (l.label.indexOf(kw) < 0) continue;
              l.equip = true;
              var used;
              if (kw === "crane") {
                used = (work.craneUsed === true);
              } else {
                var neg = new RegExp(kw.replace(/\s+/g, "\\s+") + "\\s+used:\\s*no");
                if (neg.test(wLow)) used = false;
                else used = wLow.indexOf(kw) >= 0;
              }
              if (!used) {
                var note = (kw === "crane" && work.craneUsed === false)
                  ? "the work record says \"Crane used: no\""
                  : "the work record does not record a " + kw + " as used";
                findings.push({
                  check: cap(kw) + " billed but not used",
                  details: titleLabel(l.label) + " billed " + money(l.amount) + " on the invoice, but " + note + ". Overcharge = " + money(l.amount) + ".",
                  amount: l.amount, severe: (kw === "crane")
                });
              }
              break;
            }
          });
        }

        /* (f) Deposit paid but not credited. */
        if (hasP && hasI && depositPaid > 0) {
          var uncredited = round2(depositPaid - depositCredit);
          if (uncredited > 0) {
            findings.push({
              check: "Uncredited deposit",
              details: "Deposit paid per proposal: " + money(depositPaid) + ". Deposit credit on invoice: " + money(depositCredit) +
                ". " + money(depositPaid) + " − " + money(depositCredit) + " = " + money(uncredited) + " never credited.",
              amount: uncredited, severe: true
            });
          }
        }

        /* (g) Duplicate charges: same label and amount twice on the invoice. */
        if (hasI) {
          var groups = {}, gorder = [];
          charges.forEach(function (l) {
            var key = l.label + "|" + l.amount.toFixed(2);
            if (!groups[key]) { groups[key] = []; gorder.push(key); }
            groups[key].push(l);
          });
          gorder.forEach(function (key) {
            var g = groups[key];
            if (g.length > 1) {
              g.forEach(function (x) { x.dup = true; });
              var amt = round2(g[0].amount * (g.length - 1));
              findings.push({
                check: "Duplicate charge",
                details: "\"" + titleLabel(g[0].label) + "\" at " + money(g[0].amount) + " appears " + g.length +
                  " times on the invoice. Duplicate = " + money(g[0].amount) + " × (" + g.length + " − 1) = " + money(amt) + ".",
                amount: amt, severe: false
              });
            }
          });
        }

        /* (h) Invoice-only fees: on the invoice, in neither proposal nor work record. */
        if (hasI && hasP) {
          charges.forEach(function (l) {
            if (l.dup || l.equip) return;
            if (l.label.indexOf("stump") >= 0) return;
            if (l.label.indexOf("labor") >= 0) return;
            var t = treeTypeIn(l.label);
            if (t) {
              if (!propTrees.map[t] && !notRemoved[t]) {
                findings.push({
                  check: "Invoice-only charge",
                  details: "\"" + titleLabel(l.label) + "\" " + money(l.amount) + " is billed on the invoice but appears in neither the proposal nor the work record. Overcharge = " + money(l.amount) + ".",
                  amount: l.amount, severe: false
                });
              }
              return;
            }
            if (pLow.indexOf(l.label) >= 0) return;
            if (wLow.indexOf(l.label) >= 0) return;
            findings.push({
              check: "Invoice-only fee",
              details: "\"" + titleLabel(l.label) + "\" " + money(l.amount) + " appears on the invoice but in neither the proposal nor the work record. Overcharge = " + money(l.amount) + ".",
              amount: l.amount, severe: false
            });
          });
        }

        var total = round2(findings.reduce(function (s, f) { return s + f.amount; }, 0));

        var verdict;
        if (present === 2) {
          verdict = "PAY WITH FIXES";
        } else {
          var severe = findings.some(function (f) { return f.severe; });
          if (total >= 200 || severe) verdict = "DO NOT PAY YET";
          else if (total > 0) verdict = "PAY WITH FIXES";
          else verdict = "SAFE TO PAY";
        }
        return { verdict: verdict, total: total, findings: findings, missing: missing, present: present };
      }

      /* ---------- Report text ---------- */
      function buildReport(r) {
        var lines = [];
        lines.push("J-Dawgs Tree Removal Proposal, Work Record & Final Invoice Consistency Auditor™");
        lines.push("Verdict: " + r.verdict);
        if (r.missing.length && r.present === 2) lines.push("Missing: " + r.missing.join(", "));
        lines.push("Total overcharge: " + money(r.total));
        lines.push("");
        if (r.findings.length === 0) {
          lines.push("Findings: none.");
        } else {
          lines.push("Findings:");
          r.findings.forEach(function (f, i) {
            lines.push((i + 1) + ". " + f.check + " — " + f.details + " Overcharge: " + money(f.amount));
          });
        }
        lines.push("");
        lines.push("Total overcharge: " + money(r.total));
        lines.push("Note: this audit compares numbers and items mentioned in the pasted text only. It does not verify work was actually done on site and is not legal advice.");
        return lines.join("\n");
      }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-tree-removal-proposal-work-record-final-invoice-consistency-auditortm',
  name: 'J-Dawgs Tree Removal Proposal, Work Record & Final Invoice Consistency Auditor',
  description: 'Cross-checks a tree-removal proposal vs work record vs final invoice into one pay verdict with arithmetic shown (documented example overcharge $2,375.00).',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
