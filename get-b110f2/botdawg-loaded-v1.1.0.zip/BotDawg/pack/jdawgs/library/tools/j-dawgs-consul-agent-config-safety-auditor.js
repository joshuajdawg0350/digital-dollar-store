'use strict';
/* BotDawg Tool Library — callable core extracted from the J-Dawgs tool "J-Dawgs Consul Agent Config Safety Auditor".
 * Extraction method: the tool page's own pure-logic section (examples, parsers and
 * the audit function, up to the DOM-wiring section) is wrapped unchanged; the
 * module wrapper, headless stubs and call adapter below are new code. Tested with
 * the tool's own shipped examples where present — see TEST-RESULTS.md in the pack. */

function __stubEl() {
  return new Proxy(function () {}, {
    get: function (t, p) {
      if (p === 'style') return {};
      if (p === 'classList') return { add: function () {}, remove: function () {}, toggle: function () {}, contains: function () { return false; } };
      if (p === 'children' || p === 'options' || p === 'files') return [];
      if (p === 'value' || p === 'textContent' || p === 'innerHTML' || p === 'innerText') return (typeof globalThis.__botdawgInputText === 'string' ? globalThis.__botdawgInputText : '');
      if (p === 'length') return 0;
      if (p === Symbol.toPrimitive) return function () { return ''; };
      return __stubEl();
    },
    set: function () { return true; },
    apply: function () { return __stubEl(); }
  });
}
if (typeof document === 'undefined') {
  globalThis.document = {
    getElementById: function () { return __stubEl(); },
    querySelector: function () { return __stubEl(); },
    querySelectorAll: function () { return []; },
    createElement: function () { return __stubEl(); },
    addEventListener: function () {},
    body: __stubEl(), documentElement: __stubEl(), activeElement: null
  };
}
if (typeof navigator === 'undefined') { globalThis.navigator = { userAgent: 'botdawg-tool-library', clipboard: undefined }; }
if (typeof window === 'undefined') { globalThis.window = globalThis; }
if (typeof localStorage === 'undefined') { globalThis.localStorage = { getItem: function () { return null; }, setItem: function () {}, removeItem: function () {} }; }

const __core = (function () {

  "use strict";

  var STORE_URL = "https://muse.ai/s/ai-tool-store-xng6xkxwjkxl2xab/UoF72OkKI7j33Q2ITxmrZyIr4nv40QtYfj2AgESh_k8";
  var EXCHANGE_URL = "https://muse.ai/s/j-dawgs-agent-exchange-ih6xlnihzxdhxc/ZbleqxFHRE0NcswaBkyN13y9lLp5rPAgHTb6t8ii-PY";

  var RISKY = [
    "# Risky worked example - not safe to ship",
    "datacenter = \"dc1\"",
    "data_dir = \"/tmp/consul\"",
    "node_name = \"node-1\"",
    "server = true",
    "bootstrap_expect = 1",
    "bind_addr = \"0.0.0.0\"",
    "client_addr = \"0.0.0.0\"",
    "ui = true",
    "acl {",
    "  enabled = true",
    "  default_policy = \"allow\"",
    "  tokens {",
    "    agent = \"11111111-2222-3333-4444-555555555555\"",
    "  }",
    "}",
    "verify_incoming = false",
    "verify_outgoing = false",
    "cert_file = \"/etc/consul.d/tls/server.pem\"",
    "custom_datacenter_tag = \"blue\"",
    "this line is not a valid config directive"
  ].join("\n");

  var CLEAN = [
    "# Hardened worked example",
    "datacenter = \"dc1\"",
    "data_dir = \"/opt/consul/data\"",
    "node_name = \"consul-server-1\"",
    "server = true",
    "bootstrap_expect = 3",
    "bind_addr = \"10.0.1.10\"",
    "client_addr = \"127.0.0.1\"",
    "encrypt = \"nzrEHXK44F+mwZ00ty4I9aHG2T5HsC+MWhnm07QH8sg=\"",
    "retry_join = [\"10.0.1.11\", \"10.0.1.12\"]",
    "log_level = \"INFO\"",
    "ui_config {",
    "  enabled = false",
    "}",
    "acl {",
    "  enabled = true",
    "  default_policy = \"deny\"",
    "  down_policy = \"extend-cache\"",
    "}",
    "verify_incoming = true",
    "verify_outgoing = true",
    "verify_server_hostname = true",
    "ca_file = \"/etc/consul.d/tls/ca.pem\"",
    "cert_file = \"/etc/consul.d/tls/server.pem\"",
    "key_file = \"/etc/consul.d/tls/server-key.pem\"",
    "auto_encrypt {",
    "  allow_tls = true",
    "}"
  ].join("\n");

  var KNOWN_BLOCKS = {
    "acl":1, "tokens":1, "addresses":1, "ports":1, "ui_config":1, "tls":1,
    "defaults":1, "internal_rpc":1, "grpc":1, "https":1, "auto_encrypt":1,
    "auto_config":1, "autopilot":1, "connect":1, "ca_config":1, "dns_config":1,
    "service_ttl":1, "http_config":1, "response_headers":1, "telemetry":1,
    "serf_lan":1, "serf_wan":1, "performance":1, "limits":1, "request_limits":1,
    "unix_sockets":1, "snapshot_agent":1, "storage":1, "audit":1, "sink":1,
    "peering":1, "raft":1, "consul":1, "authorization":1
  };

  var KNOWN_LEAF = {};
  var leafList = [
    "datacenter","data_dir","node_name","node_id","server","bootstrap","bootstrap_expect",
    "bind_addr","client_addr","advertise_addr","advertise_addr_wan","translate_wan_addrs",
    "retry_join","retry_join_wan","retry_max_attempts","retry_max_attempts_wan",
    "start_join","start_join_wan","rejoin_after_leave","leave_on_terminate","skip_leave_on_interrupt",
    "encrypt","encrypt_verify_incoming","encrypt_verify_outgoing",
    "log_level","log_json","log_file","log_rotate_bytes","log_rotate_duration","log_rotate_max_files",
    "enable_syslog","syslog_facility","pid_file","enable_debug","disable_update_check","check_update_interval",
    "recursors","recursor_timeout","recursor_strategy","domain","alt_domain","server_name","ui",
    "verify_incoming","verify_outgoing","verify_incoming_http","verify_incoming_rpc","verify_server_hostname",
    "cert_file","key_file","ca_file","ca_path",
    "disable_anonymous_signature","disable_cache","disable_coordinates","disable_host_node_id",
    "disable_http_from","disable_keyring_file","disable_per_network_metrics","disable_remote_exec",
    "enable_script_checks","enable_local_script_checks","enable_remote_script_checks",
    "enable_central_service_config","enable_agent_tls_for_checks","enable_hostname","use_node_hostname",
    "session_ttl_min","node_meta","segment","primary_datacenter","primary_gateways",
    "default_query_time","max_stale","txn_max_req_len","raft_multiplier","version",
    "config_dir","config_file","acl_datacenter","acl_default_policy","acl_down_policy","acl_ttl",
    "acl_token","acl_agent_token","acl_master_token","acl_replication_token",
    "enabled","default_policy","down_policy","token_ttl","policy_ttl","role_ttl","node_ttl",
    "enable_token_persistence","enable_key_list_policy","enable_token_replication",
    "agent","master","agent_master","default","dns","replication","initial_management",
    "agent_recovery","node_recovery","config_file_service_registration",
    "tls","allow_tls","dns_san","ip_san","intro_token","intro_token_file","server_addresses",
    "http","https","grpc","grpc_tls","rpc","serf_lan","serf_wan","sidecar_min_port","sidecar_max_port",
    "expose_min_port","expose_max_port","proxy_min_port","proxy_max_port",
    "content_path","metrics_provider","metrics_proxy","dashboard_url_templates",
    "min_version","cipher_suites","curve_preferences","handshake_timeout","disable_sni",
    "ca_provider","enable_mesh_gateway_wan_federation",
    "allow_stale","enable_truncate","only_passing","use_cache","cache_max_age","disable_compression",
    "a_record_limit","udp_answer_limit","enable_additional_node_meta_txt",
    "prometheus_retention_time","disable_hostname","metrics_prefix","filter_default",
    "dogstatsd_addr","dogstatsd_tags","statsd_address","statsite_address","disable_per_host_stats","enable_host_metrics",
    "cleanup_dead_servers","last_contact_threshold","max_trailing_logs","min_quorum",
    "server_stabilization_time","redundancy_zone_tag","disable_upgrade_migration","upgrade_version_tag",
    "rpc_hold_timeout","leave_drain_time","filter_max_concurrent",
    "http_max_conns_per_client","https_handshake_timeout","rpc_handshake_timeout",
    "rpc_max_conns_per_client","rpc_rate","rpc_max_burst","rpc_max_req_len",
    "block_endpoints","allow_write_http_from","x_forwarded_for_header",
    "group","mode","user","interval","retain","disable_compaction","compress_level",
    "gossip_interval","gossip_nodes","probe_interval","probe_timeout","suspicion_mult",
    "broadcast_timeout","retransmit_mult","dampening_period",
    "local","hsm","type","path","library","pin","slot","is_primary","address","cluster_id","peer_name"
  ];
  for (var li = 0; li < leafList.length; li++) KNOWN_LEAF[leafList[li]] = 1;

  var input = document.getElementById("configInput");
  var verdictBox = document.getElementById("verdictBox");
  var verdictWord = document.getElementById("verdictWord");
  var verdictWhy = document.getElementById("verdictWhy");
  var countsRow = document.getElementById("countsRow");
  var findingsWrap = document.getElementById("findingsWrap");
  var findingsList = document.getElementById("findingsList");
  var reportBox = document.getElementById("reportBox");
  var auditStatus = document.getElementById("auditStatus");
  var copyStatus = document.getElementById("copyStatus");
  var pitchStatus = document.getElementById("pitchStatus");

  var SEV_RANK = { "BLOCKER":0, "NOT PARSED":1, "WARNING":2, "NOT AUDITED":3, "INFO":4, "GOOD":5 };

  function addFinding(list, sev, line, title, detail, fix){
    list.push({ sev:sev, line:line, title:title, detail:detail, fix:fix });
  }

  function stripComment(line){
    var inStr = false;
    for (var i = 0; i < line.length; i++){
      var c = line.charAt(i);
      if (inStr){
        if (c === "\\") { i++; continue; }
        if (c === "\"") inStr = false;
        continue;
      }
      if (c === "\"") { inStr = true; continue; }
      if (c === "#") return line.slice(0, i);
      if (c === "/" && line.charAt(i + 1) === "/" && (i === 0 || line.charAt(i - 1) === " " || line.charAt(i - 1) === "\t")) {
        return line.slice(0, i);
      }
    }
    return line;
  }

  function unquote(v){
    v = v.replace(/^\s+/, "").replace(/\s+$/, "");
    if (v.charAt(v.length - 1) === ",") v = v.slice(0, -1).replace(/\s+$/, "");
    if (v.length >= 2 && v.charAt(0) === "\"" && v.charAt(v.length - 1) === "\""){
      return v.slice(1, -1).replace(/\\"/g, "\"").replace(/\\\\/g, "\\");
    }
    if (v.length >= 2 && v.charAt(0) === "'" && v.charAt(v.length - 1) === "'"){
      return v.slice(1, -1);
    }
    return v;
  }

  function parseConfig(text){
    var lines = text.split(/\r?\n/);
    var entries = [];
    var blockEvents = [];
    var malformed = [];
    var pemLines = [];
    var stack = [];
    var inArray = false;
    var inPem = false;
    var i, n, raw, t;

    function stackPath(){
      var parts = [];
      for (var s = 0; s < stack.length; s++) parts.push(stack[s].name);
      return parts.join(".");
    }
    function stackKnown(){
      for (var s = 0; s < stack.length; s++) if (!stack[s].known) return false;
      return true;
    }
    function recordEntry(key, rawValue, lineNo){
      var prefix = stackPath();
      var path = prefix ? prefix + "." + key : key;
      var leafKnown = !!KNOWN_LEAF[key.toLowerCase()];
      var known = leafKnown && stackKnown();
      entries.push({
        key: key.toLowerCase(),
        path: path,
        value: unquote(rawValue),
        rawValue: rawValue,
        line: lineNo,
        known: known,
        unknownBlockAncestor: !stackKnown()
      });
    }

    for (i = 0; i < lines.length; i++){
      raw = lines[i];
      n = i + 1;

      if (inPem){
        if (/-----END/.test(raw)) inPem = false;
        continue;
      }
      if (/-----BEGIN [A-Z ]*(PRIVATE KEY|CERTIFICATE)/.test(raw)){
        inPem = true;
        pemLines.push(n);
        continue;
      }

      t = stripComment(raw).replace(/^\s+/, "").replace(/\s+$/, "");
      if (t === "") continue;

      if (inArray){
        if (t.indexOf("]") !== -1) inArray = false;
        continue;
      }

      // A lone opening brace/bracket (the root of a JSON document) is structural.
      if (t === "{" || t === "[") continue;

      if (t === "}" || t === "}," || t === "]" || t === "],"){
        if (stack.length) stack.pop();
        continue;
      }

      // Block open: "name {" (HCL) or "\"name\": {" (JSON), possibly one-line with contents.
      var isBlockOpen = false;
      var blockName = null;
      var afterBrace = "";
      var bm = t.match(/^"?([A-Za-z0-9_-]+)"?\s*:?\s*(?:"[^"]*"\s*)?\{(.*)$/);
      if (bm){
        var rest = bm[2].replace(/^\s+/, "").replace(/\s+$/, "");
        if (rest === "" || rest === ","){
          isBlockOpen = true; blockName = bm[1].toLowerCase(); afterBrace = "";
        } else if (rest.charAt(rest.length - 1) === "}" || rest.charAt(rest.length - 1) === ","){
          // one-line block: name { key = value }
          var inner = rest.replace(/\}\s*,?\s*$/, "");
          isBlockOpen = true; blockName = bm[1].toLowerCase(); afterBrace = inner;
        }
      }
      if (isBlockOpen){
        var bKnown = !!KNOWN_BLOCKS[blockName];
        var prefix2 = stackPath();
        blockEvents.push({
          name: blockName,
          path: prefix2 ? prefix2 + "." + blockName : blockName,
          line: n,
          known: bKnown && stackKnown(),
          unknownBlockAncestor: !stackKnown()
        });
        stack.push({ name: blockName, known: bKnown, line: n });
        if (afterBrace){
          var parts = afterBrace.split(",");
          for (var p = 0; p < parts.length; p++){
            var pm = parts[p].match(/^\s*"?([A-Za-z0-9_.-]+)"?\s*[:=]\s*(.+?)\s*$/);
            if (pm) recordEntry(pm[1], pm[2], n);
          }
          stack.pop();
        }
        continue;
      }

      var mAssign = t.match(/^"?([A-Za-z0-9_.-]+)"?\s*=\s*(.+)$/) || t.match(/^"([^"]+)"\s*:\s*(.+)$/);
      if (mAssign){
        var val = mAssign[2].replace(/\s+$/, "");
        if (val.charAt(0) === "[" && val.indexOf("]") === -1) inArray = true;
        recordEntry(mAssign[1], val, n);
        continue;
      }

      malformed.push(n);
    }

    return { entries: entries, blockEvents: blockEvents, malformed: malformed, pemLines: pemLines, lineCount: lines.length };
  }

  function audit(text){
    var findings = [];
    var parsed = parseConfig(text);
    var entries = parsed.entries;
    var i, e;

    // Effective config: last value wins per full path.
    var eff = {};
    var occurrences = {};
    for (i = 0; i < entries.length; i++){
      e = entries[i];
      eff[e.path] = e;
      if (!occurrences[e.path]) occurrences[e.path] = [];
      occurrences[e.path].push(e);
    }
    function get(path){ return eff[path] || null; }
    function leafEntries(leaf){
      var out = [];
      for (var j = 0; j < entries.length; j++) if (entries[j].key === leaf) out.push(entries[j]);
      return out;
    }
    function lastLeaf(leaf){
      var ls = leafEntries(leaf);
      return ls.length ? ls[ls.length - 1] : null;
    }
    function truthy(entry){ return !!entry && entry.value.toLowerCase() === "true"; }
    function falsy(entry){ return !!entry && entry.value.toLowerCase() === "false"; }

    var serverEntry = get("server");
    var bootstrapEntry = get("bootstrap");
    var expectEntry = get("bootstrap_expect");
    var isServer = truthy(serverEntry) || truthy(bootstrapEntry) || !!expectEntry;
    var modeWord = isServer ? "server" : "client";

    // --- Malformed lines: NOT PARSED, contents never echoed ---
    for (i = 0; i < parsed.malformed.length; i++){
      addFinding(findings, "NOT PARSED", parsed.malformed[i], "Line could not be parsed — NOT PARSED",
        "This line is neither a comment, a block, nor a key = value pair in HCL style or JSON style, so the audit skipped it and did not guess at its meaning. Its contents are not reproduced here, in case the line holds something sensitive.",
        "Fix the line into a valid directive (or remove it), then re-audit. A config with unparsed lines cannot be attested.");
    }

    // --- Inline private-key / certificate material ---
    for (i = 0; i < parsed.pemLines.length; i++){
      addFinding(findings, "WARNING", parsed.pemLines[i], "Inline PEM material pasted in the config (contents not shown)",
        "A PEM block (certificate or private key material) starts on this line. The audit reports the location only and never reproduces the contents. Key material pasted into config text tends to travel with every copy of the file.",
        "Move key material into a protected file and reference it with key_file / cert_file / ca_file instead.");
    }

    // --- Unrecognized blocks: NOT AUDITED ---
    for (i = 0; i < parsed.blockEvents.length; i++){
      var be = parsed.blockEvents[i];
      if (!be.known && !be.unknownBlockAncestor){
        addFinding(findings, "NOT AUDITED", be.line, "Block not covered by this auditor — NOT AUDITED: " + be.path,
          "The block " + be.path + " is outside this auditor's rule set. Its contents were scanned for secrets and duplicates, but no safety judgment was made on the block itself.",
          "Review this block by hand against the Consul documentation, or remove it if it is not needed.");
      }
    }

    // --- Unrecognized directives: NOT AUDITED ---
    for (i = 0; i < entries.length; i++){
      e = entries[i];
      if (!e.known && !e.unknownBlockAncestor){
        addFinding(findings, "NOT AUDITED", e.line, "Directive not covered by this auditor — NOT AUDITED: " + e.path,
          "The directive " + e.path + " is outside this auditor's rule set, so no safety judgment was made on it. It may be a newer Consul option, a plugin setting, or a typo for a known key — a misspelled security key fails silently in a real config.",
          "Check the spelling against the Consul agent configuration reference, and review the setting by hand.");
      }
    }

    // --- Duplicates: last value wins, both lines named ---
    for (var path in occurrences){
      var occ = occurrences[path];
      if (occ.length > 1){
        var lineNums = [];
        for (var o = 0; o < occ.length; o++) lineNums.push(occ[o].line);
        addFinding(findings, "WARNING", occ[occ.length - 1].line, "Duplicate key: " + path + " (lines " + lineNums.join(" and ") + ")",
          "The key " + path + " is set on lines " + lineNums.join(", ") + ". The audit graded the last value (line " + occ[occ.length - 1].line + "), because Consul resolves duplicates last-value-wins — the earlier setting is silently shadowed.",
          "Delete the setting you do not mean, so the file says one thing in one place.");
      }
    }

    // --- Secrets: key name and line only, value never printed ---
    for (i = 0; i < entries.length; i++){
      e = entries[i];
      var isTokenKey = e.path.indexOf("token") !== -1 || e.key.indexOf("token") !== -1;
      var hasPemValue = /BEGIN [A-Z ]*(PRIVATE KEY|CERTIFICATE)/.test(e.rawValue);
      if (isTokenKey && e.value !== "" && e.value.indexOf("${") !== 0){
        addFinding(findings, "WARNING", e.line, "Secret in config text: " + e.path + " (value not shown)",
          "The key " + e.path + " carries a literal secret value on this line. The value is never printed in these findings or in the report. Anyone who can read this config file holds the token.",
          "Confirm this file is access-controlled and excluded from general backups and repos; rotate the token if the file has been shared.");
      } else if (hasPemValue){
        addFinding(findings, "WARNING", e.line, "Secret in config text: " + e.path + " (value not shown)",
          "The value of " + e.path + " contains PEM material. The contents are never printed here.",
          "Move the material into a protected file and reference the file instead.");
      }
    }

    // --- Gossip encryption ---
    var enc = get("encrypt");
    if (!enc){
      if (isServer){
        addFinding(findings, "BLOCKER", serverEntry ? serverEntry.line : 1, "Gossip encryption is off: no encrypt key (whole-config check)",
          "This is a " + modeWord + " agent and no encrypt key appears anywhere in the pasted config, so serf gossip traffic is unencrypted — any host that can reach the serf ports can read membership traffic and attempt to join.",
          "Generate a key with consul keygen, set encrypt on every agent in the cluster to the same key, and restart the agents.");
      } else {
        addFinding(findings, "WARNING", 1, "Gossip encryption is off: no encrypt key (whole-config check)",
          "This is a client agent and no encrypt key appears in the pasted config, so its gossip traffic is unencrypted and it cannot join a cluster that requires encryption.",
          "Set encrypt to the same key the rest of the cluster uses.");
      }
    } else {
      var raw = enc.value.replace(/\s+/g, "");
      var decoded = -1;
      try {
        var bin = atob(raw);
        decoded = bin.length;
      } catch (err) { decoded = -1; }
      if (decoded === -1 || (decoded !== 16 && decoded !== 32)){
        addFinding(findings, "WARNING", enc.line, "Gossip key present but weak or malformed: encrypt (value not shown)",
          decoded === -1
            ? "An encrypt key is set on this line, but it does not decode as base64, so Consul would reject it or the cluster cannot share it. The value itself is never shown here."
            : "An encrypt key is set on this line, but it decodes to " + decoded + " bytes; Consul gossip keys are 16 or 32 bytes of base64. Short or hand-typed keys are guessable. The value itself is never shown here.",
          "Replace it with a fresh consul keygen key on every agent. This audit cannot verify the key matches the rest of the cluster — only that its shape is right.");
      } else {
        addFinding(findings, "GOOD", enc.line, "Gossip encryption key present: encrypt (value not shown)",
          "An encrypt key is set and decodes to " + decoded + " bytes, the expected shape for a Consul gossip key. The audit cannot verify it matches the other agents' keys.",
          "No action needed on shape. Confirm out of band that every agent in the cluster uses the same key.");
      }
    }

    // --- ACL ---
    var aclEnabled = null;
    var aclBlockEntries = leafEntries("enabled");
    for (i = 0; i < entries.length; i++){
      if (entries[i].path === "acl.enabled") aclEnabled = entries[i];
    }
    var defaultPolicy = get("acl.default_policy") || get("acl_default_policy");
    if (defaultPolicy && defaultPolicy.value.toLowerCase() === "allow"){
      addFinding(findings, "BLOCKER", defaultPolicy.line, "ACL default_policy is allow",
        "With the default policy set to allow, any request or agent without an explicit denying policy is permitted — ACLs are present but the door is open by default.",
        "Set default_policy to \"deny\" inside the acl block and grant access through explicit policies and tokens.");
    } else if (defaultPolicy && defaultPolicy.value.toLowerCase() === "deny"){
      addFinding(findings, "GOOD", defaultPolicy.line, "ACL default_policy is deny",
        "The ACL default policy is deny, so access requires an explicit policy grant — the posture Consul recommends for production.",
        "No action needed.");
    }
    if (aclEnabled && truthy(aclEnabled) && !defaultPolicy){
      addFinding(findings, "WARNING", aclEnabled.line, "ACLs enabled but no default_policy set",
        "The acl block enables ACLs but never sets default_policy in the pasted text. When it is unset, Consul's effective fallback is allow, which quietly undoes the point of enabling ACLs.",
        "Set default_policy to \"deny\" in the acl block.");
    }
    if (!aclEnabled || falsy(aclEnabled)){
      if (isServer){
        addFinding(findings, "WARNING", aclEnabled ? aclEnabled.line : 1, "ACLs are not enabled on this server (whole-config check)",
          "No acl block with enabled = true appears in the pasted config, so this server runs without ACL enforcement: any client that can reach it can read and write the catalog and KV store, subject only to network reachability.",
          "Enable ACLs (acl { enabled = true, default_policy = \"deny\" }) and bootstrap tokens before exposing this server.");
      } else {
        addFinding(findings, "INFO", aclEnabled ? aclEnabled.line : 1, "No ACL block in this client config (whole-config check)",
          "Client agents commonly leave ACL settings to the servers; if the cluster enforces ACLs, this agent will need a token configured to register and run checks.",
          "No action if the cluster does not use ACLs; otherwise add the acl block and a token reference.");
      }
    }

    // --- UI + client_addr combination ---
    var uiConfigEnabled = get("ui_config.enabled");
    var legacyUi = get("ui");
    var uiOn = truthy(uiConfigEnabled) || truthy(legacyUi);
    var uiLine = uiConfigEnabled && truthy(uiConfigEnabled) ? uiConfigEnabled.line : (legacyUi ? legacyUi.line : 0);
    var clientAddr = get("client_addr");
    var clientWildcard = !!clientAddr && clientAddr.value === "0.0.0.0";
    var comboFired = false;
    if (uiOn && clientWildcard){
      comboFired = true;
      if (isServer){
        addFinding(findings, "BLOCKER", uiLine, "UI enabled on all interfaces (client_addr 0.0.0.0)",
          "The UI is enabled (line " + uiLine + ") and client_addr is 0.0.0.0 (line " + clientAddr.line + "), so the web UI and the HTTP API are reachable on every network interface of a server. Without ACLs and TLS in front of it, that is an open control surface.",
          "Bind client_addr to loopback or a management network, put the UI behind an authenticated proxy, or disable the UI on servers.");
      } else {
        addFinding(findings, "WARNING", uiLine, "UI enabled on all interfaces (client_addr 0.0.0.0)",
          "The UI is enabled (line " + uiLine + ") and client_addr is 0.0.0.0 (line " + clientAddr.line + "), so the web UI and HTTP API are reachable on every network interface of this client.",
          "Bind client_addr to loopback unless remote UI access is deliberate and protected.");
      }
    } else if (uiOn && !clientAddr){
      addFinding(findings, "INFO", uiLine, "UI enabled; client_addr not set",
        "The UI is enabled but client_addr does not appear in the pasted text, so Consul's default of loopback (127.0.0.1) applies and the UI stays local to the host.",
        "No action needed. If another config file sets client_addr, re-check the combination there.");
    } else if (uiOn && clientAddr && !clientWildcard){
      addFinding(findings, "GOOD", uiLine, "UI enabled on a restricted client_addr",
        "The UI is enabled and client_addr is a specific address (" + clientAddr.value + ") rather than all interfaces, so UI reachability is limited to that interface.",
        "Confirm that interface is a trusted network.");
    }

    // --- Wildcard binds ---
    var bindAddr = get("bind_addr");
    if (bindAddr && bindAddr.value === "0.0.0.0"){
      if (isServer){
        addFinding(findings, "WARNING", bindAddr.line, "bind_addr is 0.0.0.0 on a server",
          "The server binds serf and RPC on every interface. That is sometimes necessary in containers and multi-homed hosts, but it means every reachable network can attempt cluster traffic.",
          "Bind to the cluster network address, or keep 0.0.0.0 only behind firewall rules that restrict the serf and RPC ports to cluster members.");
      } else {
        addFinding(findings, "INFO", bindAddr.line, "bind_addr is 0.0.0.0 on a client",
          "This client binds gossip on every interface. Common in containers, but worth a deliberate decision on shared hosts.",
          "No action if the host's networks are all trusted; otherwise bind to a specific address.");
      }
    }
    if (clientAddr && clientWildcard && !comboFired){
      addFinding(findings, "WARNING", clientAddr.line, "client_addr is 0.0.0.0",
        "The HTTP API, DNS interface, and (if enabled) the UI listen on every interface. On a " + modeWord + " agent, anything that can reach this host can query the API unless ACLs and TLS restrict it.",
        "Bind client_addr to loopback or a management network, or confirm ACLs plus TLS are enforced before this is reachable.");
    }
    if (clientAddr && !clientWildcard && (clientAddr.value === "127.0.0.1" || clientAddr.value === "::1")){
      addFinding(findings, "GOOD", clientAddr.line, "client_addr is bound to loopback",
        "The HTTP API and UI (if enabled) are reachable only from the host itself.",
        "No action needed.");
    }

    // --- TLS verification ---
    var viList = leafEntries("verify_incoming");
    var voList = leafEntries("verify_outgoing");
    var vi = viList.length ? viList[viList.length - 1] : null;
    var vo = voList.length ? voList[voList.length - 1] : null;
    if (vi && falsy(vi)){
      if (isServer){
        addFinding(findings, "BLOCKER", vi.line, "verify_incoming is false on a server",
          "With verify_incoming false, this server does not verify client certificates on incoming RPC and API connections, so TLS encrypts the pipe without authenticating who is on the other end.",
          "Set verify_incoming to true and distribute the CA and certificates, or use auto_encrypt on clients with allow_tls here.");
      } else {
        addFinding(findings, "WARNING", vi.line, "verify_incoming is false",
          "Incoming connections to this agent are not certificate-verified, so TLS here encrypts without authenticating callers.",
          "Set verify_incoming to true once certificates are distributed.");
      }
    } else if (vi && truthy(vi)){
      addFinding(findings, "GOOD", vi.line, "verify_incoming is true",
        "Incoming RPC is certificate-verified.",
        "No action needed.");
    } else {
      addFinding(findings, "WARNING", 1, "verify_incoming is not set (whole-config check)",
        "verify_incoming does not appear in the pasted text, and Consul's default for it is false — incoming connections are not certificate-verified unless another config file sets it.",
        "Set verify_incoming to true in this file or confirm the file that sets it ships with this one.");
    }
    if (vo && falsy(vo)){
      addFinding(findings, "WARNING", vo.line, "verify_outgoing is false",
        "This agent does not verify the certificates of servers it connects to, so a spoofed server on the network can be accepted as a cluster member endpoint.",
        "Set verify_outgoing to true and provide the CA file.");
    } else if (vo && truthy(vo)){
      addFinding(findings, "GOOD", vo.line, "verify_outgoing is true",
        "Outgoing RPC is certificate-verified against the configured CA.",
        "No action needed.");
    } else {
      if (isServer){
        addFinding(findings, "WARNING", 1, "verify_outgoing is not set (whole-config check)",
          "verify_outgoing does not appear in the pasted text, and Consul's default for it is false — this server does not verify peer certificates on outgoing RPC unless another file sets it.",
          "Set verify_outgoing to true in this file or confirm the file that sets it ships with this one.");
      } else {
        addFinding(findings, "INFO", 1, "verify_outgoing is not set (whole-config check)",
          "verify_outgoing does not appear in the pasted text; Consul's default is false. Client agents commonly inherit this from a shared TLS file.",
          "Confirm a shared config sets it, or set verify_outgoing to true here.");
      }
    }
    var vsh = lastLeaf("verify_server_hostname");
    if (vsh && falsy(vsh)){
      addFinding(findings, "WARNING", vsh.line, "verify_server_hostname is false",
        "Outgoing TLS connections skip hostname verification, weakening the certificate check even when verify_outgoing is on.",
        "Set verify_server_hostname to true (the default) unless a documented exception applies.");
    } else if (vsh && truthy(vsh)){
      addFinding(findings, "GOOD", vsh.line, "verify_server_hostname is true",
        "Server hostname verification is on for outgoing TLS.",
        "No action needed.");
    }
    var evi = get("encrypt_verify_incoming");
    if (evi && falsy(evi)){
      addFinding(findings, "WARNING", evi.line, "encrypt_verify_incoming is false",
        "Gossip encryption verification on incoming messages is off, so unencrypted gossip from non-members can be accepted during migration windows — a state that should not be permanent.",
        "Set encrypt_verify_incoming back to true once every agent has the gossip key.");
    }
    var evo = get("encrypt_verify_outgoing");
    if (evo && falsy(evo)){
      addFinding(findings, "WARNING", evo.line, "encrypt_verify_outgoing is false",
        "Gossip encryption verification on outgoing messages is off — a migration setting that should not be permanent.",
        "Set encrypt_verify_outgoing back to true once every agent has the gossip key.");
    }

    // --- TLS cert files: referenced but incomplete ---
    var tlsKeys = ["ca_file", "cert_file", "key_file"];
    var tlsPresent = [];
    var tlsMissing = [];
    var tlsFirstLine = 0;
    for (i = 0; i < tlsKeys.length; i++){
      var tk = lastLeaf(tlsKeys[i]);
      if (tk && tk.value !== "") { tlsPresent.push(tlsKeys[i]); if (!tlsFirstLine) tlsFirstLine = tk.line; }
      else tlsMissing.push(tlsKeys[i]);
    }
    var aeTls = get("auto_encrypt.tls");
    var aeAllow = get("auto_encrypt.allow_tls");
    var aeBlock = null;
    for (i = 0; i < parsed.blockEvents.length; i++) if (parsed.blockEvents[i].name === "auto_encrypt") aeBlock = parsed.blockEvents[i];
    if (tlsPresent.length > 0 && tlsMissing.length > 0 && !truthy(aeTls)){
      addFinding(findings, "WARNING", tlsFirstLine, "TLS file set is incomplete",
        "The config references " + tlsPresent.join(", ") + " but not " + tlsMissing.join(" or ") + ". A partial set usually means TLS was half-configured: the agent may fail to start, or start without the verification the author intended.",
        "Reference the complete set (ca_file, cert_file, key_file), or switch clients to auto_encrypt and remove the partial references.");
    } else if (tlsPresent.length === 3){
      addFinding(findings, "GOOD", tlsFirstLine, "TLS file set is complete",
        "All three TLS files are referenced: ca_file, cert_file, and key_file. This audit checks references only — it cannot verify the files exist or that the certificates are valid.",
        "No action needed on references. Verify file presence and expiry on the host.");
    } else if (tlsPresent.length === 0 && vi && truthy(vi) && !truthy(aeTls) && !truthy(aeAllow)){
      addFinding(findings, "WARNING", vi.line, "verify_incoming is on but no CA file is referenced",
        "Verification is enabled but no ca_file (or ca_path) appears in the pasted text and auto_encrypt is not enabled, so as pasted the agent has no CA to verify against. The CA may live in another config file.",
        "Add ca_file to this file, or confirm the companion file that carries it deploys with this one.");
    }
    if (aeBlock){
      if (!truthy(aeTls) && !truthy(aeAllow)){
        addFinding(findings, "WARNING", aeBlock.line, "auto_encrypt block enables nothing",
          "An auto_encrypt block is present but neither tls (clients) nor allow_tls (servers) is set true inside it, so auto-encrypt is referenced but not actually in effect.",
          "Set tls = true inside auto_encrypt on clients, or allow_tls = true on servers — or remove the block.");
      } else {
        addFinding(findings, "GOOD", aeBlock.line, truthy(aeAllow) ? "auto_encrypt allow_tls is on (server side)" : "auto_encrypt tls is on (client side)",
          "Auto-encrypt is enabled, so agent certificates are issued by the Connect CA instead of hand-distributed files.",
          "No action needed. Confirm the servers run allow_tls and the CA is initialized.");
      }
    }

    // --- Sort and verdict ---
    findings.sort(function(a, b){
      if (SEV_RANK[a.sev] !== SEV_RANK[b.sev]) return SEV_RANK[a.sev] - SEV_RANK[b.sev];
      return a.line - b.line;
    });

    var counts = { "BLOCKER":0, "WARNING":0, "GOOD":0, "NOT AUDITED":0, "NOT PARSED":0, "INFO":0 };
    for (i = 0; i < findings.length; i++) counts[findings[i].sev]++;

    var verdict, cls, why;
    if (counts.BLOCKER > 0 || counts["NOT PARSED"] > 0){
      verdict = "DO NOT DEPLOY"; cls = "bad";
      var bits = [];
      if (counts.BLOCKER > 0) bits.push(counts.BLOCKER + (counts.BLOCKER === 1 ? " blocker" : " blockers"));
      if (counts["NOT PARSED"] > 0) bits.push(counts["NOT PARSED"] + " unparsed line(s)");
      why = bits.join(" and ") + " found. Fix every blocker and re-audit before this config goes near a live cluster.";
    } else if (counts.WARNING > 0 || counts["NOT AUDITED"] > 0){
      verdict = "DEPLOY WITH FIXES"; cls = "warn";
      why = "No blockers, but " + (counts.WARNING + counts["NOT AUDITED"]) + " warning / not-audited finding(s) need a fix or a deliberate review before deployment.";
    } else {
      verdict = "SAFE TO DEPLOY"; cls = "good";
      why = "No blocker, warning, NOT AUDITED, or NOT PARSED finding fired on the pasted text (" + counts.GOOD + " positive confirmation(s)). This is a text audit, not a proof — the agent still deserves a startup check against a real cluster.";
    }
    return { findings: findings, counts: counts, verdict: verdict, cls: cls, why: why, lineCount: parsed.lineCount, isServer: isServer };
  }

  function buildReport(result){
    var out = [];
    out.push("J-Dawgs Consul Agent Config Safety Auditor - audit report");
    out.push("Verdict: " + result.verdict);
    out.push("Agent mode detected: " + (result.isServer ? "server" : "client"));
    out.push("Lines scanned: " + result.lineCount);
    out.push("Counts: BLOCKER " + result.counts.BLOCKER + " | WARNING " + result.counts.WARNING + " | NOT PARSED " + result.counts["NOT PARSED"] + " | NOT AUDITED " + result.counts["NOT AUDITED"] + " | INFO " + result.counts.INFO + " | GOOD " + result.counts.GOOD);
    out.push("Note: offline text audit only. Nothing was uploaded; no cluster was contacted and Consul was not run. Secret values are never printed in this report - secrets are named by key and line only. NOT AUDITED means the directive is outside this auditor's rule set; NOT PARSED means the line could not be read and was not guessed.");
    out.push("");
    if (!result.findings.length){
      out.push("Findings: none.");
    } else {
      out.push("Findings:");
      for (var i = 0; i < result.findings.length; i++){
        var f = result.findings[i];
        out.push("");
        out.push((i + 1) + ". Line " + f.line + " [" + f.sev + "] " + f.title);
        out.push("   " + f.detail);
        out.push("   Fix: " + f.fix);
      }
    }
    return out.join("\n");
  }
  return { "audit": (typeof audit !== 'undefined' ? audit : undefined), "buildReport": (typeof buildReport !== 'undefined' ? buildReport : undefined) };
})();

function __pickText(input) {
  if (typeof input === 'string') return input;
  if (!input || typeof input !== 'object') return '';
  return input.text ?? input.config ?? input.content ?? input.input ?? input.source ?? '';
}
function __stringValues(input) {
  if (!input || typeof input !== 'object') return [];
  return Object.keys(input).filter(k => k !== 'text').map(k => input[k]).filter(v => typeof v === 'string');
}
function __callEntry(text, input) {
  const fn = __core["audit"];
  const attempts = [
    function () { return fn(text); },
    function () { return fn(input); },
    function () { return fn.apply(null, __stringValues(input)); },
    function () { return fn(text, input); },
    function () { return fn(text.split(/\r?\n/)); },
    function () { return fn([text]); },
    function () { return fn(text, {}); }
  ];
  let lastErr = null, vacuous = null;
  for (const a of attempts) {
    try {
      const r = a();
      if (r === undefined || r === null) continue;
      if (__isVacuous(r)) { if (vacuous === null) vacuous = r; continue; }
      return r;
    } catch (e) { lastErr = e; }
  }
  if (vacuous !== null) return vacuous;
  throw lastErr || new Error('entry returned nothing');
}
function __isVacuous(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return false;
  const keys = Object.keys(r);
  if (!keys.length) return true;
  if (r.verdict || r.state || r.summary || r.report) return false;
  return keys.every(k => {
    const v = r[k];
    if (Array.isArray(v)) return v.length === 0;
    if (typeof v === 'number') return v === 0;
    if (typeof v === 'string') return v.length === 0;
    if (v && typeof v === 'object') return Object.keys(v).length === 0;
    return v === false || v === null || v === undefined;
  });
}
function __summarize(r) {
  if (r && typeof r === 'object') {
    const f = Array.isArray(r.findings) ? r.findings.length : undefined;
    const v = r.verdict || r.state || 'done';
    return f !== undefined ? (v + ' — ' + f + ' finding(s)') : String(v);
  }
  return String(r).slice(0, 200);
}
module.exports = {
  id: 'j-dawgs-consul-agent-config-safety-auditor',
  name: 'J-Dawgs Consul Agent Config Safety Auditor',
  description: 'Grades a pasted Consul agent config (HCL or JSON) offline: gossip encryption, ACL default policy, TLS verify posture, UI/wildcard-bind exposure, secrets by key name only — into one deploy verdict. consul validate is host-bound and stops at will-it-load; ours grades a pasted config anywhere.',
  inputSpec: 'Give input.text: the full text the tool audits (a config file, listing, transcript or document, depending on the tool). Multi-part tools also accept their named parts as extra string fields on input. Returns the tool\'s verdict, findings and full report.',
  run: function (input) {
    const text = __pickText(input);
    globalThis.__botdawgInputText = text;
    if (!__core["audit"]) return { ok: false, output: null, summary: 'Extracted core has no audit function.' };
    let r;
    try { r = __callEntry(text, (input && typeof input === 'object') ? input : { text }); }
    catch (e) { return { ok: false, output: null, summary: 'Run failed: ' + (e && e.message) }; }
    let out = null;
    if (typeof __core.buildReport === 'function') { try { const rep = __core.buildReport(r); if (typeof rep === 'string') out = rep; } catch (e) { /* fall through */ } }
    if (out === null) out = (typeof r === 'string') ? r : JSON.stringify(r, null, 2);
    return { ok: true, output: out, summary: __summarize(r), _raw: r };
  },
  __examples: {  }
};
